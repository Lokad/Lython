
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
prev=lab.parent/"direct-suite-bindings-20261123"/"comparison"
profile=lab.parent/"function-optional-attributes-20261122"/"profile"/"quiet"
quiet=out/"quiet"
quiet.mkdir()
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
def committed(folder,leaf):return git("show",f"origin/master:benchmarks/results/{folder}/{leaf}")
def receipt(folder):
    record=json.loads(committed(folder,"archive-receipt.json"))
    assert all(record[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(committed(folder,"observations.tgz"))==record["archiveSHA256"]
    return record["archiveSHA256"]

donor=read(prev/"quiet/config.json")
previous="2026-11-23-direct-suite-bindings"
csv="2026-11-22-csv-literal-field-scan"
profile_name="2026-11-23-function-storage-attribution"
archivesha=receipt(previous)
prior=json.loads(committed(previous,"source.json"))
assert prior["imageFiles"]==donor["identity"]["imageFiles"]
previous_name=donor["root"].split("/")[-1]
retire=[]
for role,folder in (("reference",csv),("candidate",previous)):
    b=gzip.decompress(committed(folder,"candidate-core.dll.gz"))
    assert sha(b)==prior["imageFiles"][role][core]
    retire.append(dict(paths=[previous_name+"/"+role+"/"+core],bytes=len(b),sha256=sha(b),links=1,
                       archives={previous_name+"/observations.tgz":archivesha}))
profile_digest=receipt(profile_name)
trace=read(profile/"config.json")["root"].split("/")[-1]+"/observations.tgz"
trace_bytes=committed(profile_name,"observations.tgz")
assert sha(trace_bytes)==profile_digest==h(profile/"observations.tgz")
retire.append(dict(paths=[trace],bytes=len(trace_bytes),sha256=profile_digest,links=1,archives={trace:profile_digest}))
tree=repo/".git/agent-worktrees/direct-single-def-default-20261123"
before=read(out/"identity.json")
reference=before["reference"]
candidate=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert candidate.startswith("c3e8cbcf7") and not git("status","--porcelain",cwd=tree)
assert not git("diff","--name-only","a12b552bc",reference,"--","src","tests")
assert git("rev-parse",candidate+"^").decode().strip()==reference
patch=git("diff","--binary",reference,candidate,"--","src","tests")
assert sha(patch)==before["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
files=before["imageFiles"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
assert not {r["sha256"] for r in retire}&{m[core]for m in files.values()}
catalog=out/"representative.json"
ids=[row["id"] for row in read(catalog)["cases"]]
jobs=[(ids[0],"warm"),(ids[0],"compile-run")]+[(name,"warm")for name in ids[1:]]
assert len(jobs)==6
save(out/"jobs.json",jobs)
shutil.copyfile(catalog,quiet/"representative.json")
for role in files:
    image=out/f"frozen-{role}"
    proof=read(out/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["catalogSha256"]==h(catalog) and proof["caseCount"]==len(ids)
    assert len(files[role])==32 and {n:h(image/n)for n in files[role]}==files[role]
    (quiet/role).mkdir()
    shutil.copyfile(image/core,quiet/role/core)
identity={**before,"sourceRevision":reference+" versus "+candidate,"candidate":candidate,"patchBase":reference,
    "purpose":"Avoid eagerly allocating the tuple for a compiled dynamic singleton positional default.",
    "normalAdapterPin":"0.4.0","coreSHA256":{r+s:m[core]for r,m in files.items()for s in ("","-control")},
    "catalogs":{"representative.json":{"sha256":h(catalog)}}}
save(quiet/"identity.json",identity)
root="/home/lokad/lython-bench-checks/singleton-positional-default-b1428-20261123"
unit="lython-b1428-singleton-positional-default-20261123"
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(prev/"quiet"/leaf).read_text(encoding="utf-8").replace(donor["root"],root).replace(donor["unit"],unit)
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json" for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
    write(quiet/leaf,code.replace("Direct suite bindings","Singleton positional defaults"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core,"reference/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as t:
    for n in parts:t.add(quiet/n,arcname=n)
cfg={**donor,"root":root,"unit":unit,"identity":identity,"source":donor["root"],"sourceRole":"reference",
     "sourceFiles":prior["imageFiles"]["reference"],"sourceCatalogSHA256":prior["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":archivesha,"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(prev/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1427-fixtures","b1428-fixtures"))
write(out/"launch.py",(prev/"launch.py").read_text(encoding="utf-8").replace("Direct suite bindings","Singleton positional defaults"))
write(out/"summarize.py",(prev/"summarize.py").read_text(encoding="utf-8"))
print(candidate,root,cfg["unpackedBytes"],flush=True)

