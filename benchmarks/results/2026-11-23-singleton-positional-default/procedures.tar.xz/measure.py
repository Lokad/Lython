
from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/direct-single-def-default-20261123"
base=lab.parent/"function-optional-attributes-20261122"/"refined-comparison"
default_controls=lab.parent/"definition-annotation-transport-20261122"/"comparison/quiet/representative.json"
out=lab/"comparison"
out.mkdir()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)

manifest=read(base/"identity.json")
known=manifest["imageFiles"]["candidate"]
old=base/"frozen-candidate"
assert len(known)==32 and {n:h(old/n)for n in known}==known
original=read(base/"representative.json")
ids=("scripts.annotated-rule-closures.nested-factories.postponed",
     "scripts.annotated-rule-closures.nested-factories",
     "scripts.factory-observed-defaults",
     "scripts.ordinary-fully-supplied-helper",
     "scripts.csv-invoice.method-policy.quoted-control")
cases={r["id"]:r for r in original["cases"]+read(default_controls)["cases"]}
catalog=out/"representative.json"
save(catalog,{**original,"cases":[cases[id]for id in ids]})
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==manifest["protocolSHA256"]
head=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert head.startswith("c5486a9a3") and not git("diff","--name-only","a12b552bc",head,"--","src","tests")
patch=git("diff","--binary","HEAD","--","src","tests",cwd=tree)
assert patch.count(b"diff --git ")==6
(out/"source.patch").write_bytes(patch)
core="Lokad.Lython.dll"
images={}
results={}
for role,config in (("reference","reference-build"),("candidate","windows")):
    built=lab/f"{config}/bin/Lokad.Lython/release_net11.0"/core
    image=out/f"frozen-{role}"
    image.mkdir()
    files={**known,core:h(built)}
    for name in files:shutil.copyfile(built if name==core else old/name,image/name)
    assert files=={n:h(image/n)for n in files}
    images[role]=files
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="ValidatedAllocation"+suffix
        shutil.copyfile(old/n,image/n)
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=90)
    verify=read(proof)
    assert verify["state"]=="Completed" and verify["caseCount"]==len(ids) and verify["catalogSha256"]==h(catalog)
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==len(ids) and all(row["sharedBudgetBaselineRestored"] for row in rows)
    results[role]=rows
    assert files=={n:h(image/n)for n in files}
save(out/"identity.json",dict(reference=head,sourcePatchSHA256=h(out/"source.patch"),imageFiles=images,
                             protocolSHA256=h(protocol),catalogSHA256=h(catalog)))
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"],a,b,b-a,round(100*(b/a-1),3),before["peakExecutionMemoryBytes"],after["peakExecutionMemoryBytes"],flush=True)

