from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / "comparison"
quiet = comparison / "quiet"
dest = repo / "benchmarks/results/2026-11-23-direct-owned-capture"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = read(comparison / "identity.json")
terminal = read(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 224
assert read(lab / "executable-parity.json")["identicalCodeObjects"] == 149
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    for name, digest in files.items():
        assert sha((lab / role / name).read_bytes()) == digest
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
present = not subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", "src"], cwd=repo)
source = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"],
    identity["candidate"], "--", "src", "tests"], cwd=repo)
(lab / "comparison/production.patch").write_bytes(source)
(dest / "identity.json").write_text(json.dumps(dict(identity, retainedRevision=head if present else None,
    productionPatchSHA256=sha(source)),
    indent=2) + "\n", encoding="utf-8", newline="\n")
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(quiet / file, dest / file)
shutil.copyfile(lab / "allocation-summary-six.json", dest / "allocation-summary.json")
for file in ("executable-parity.json",):
    shutil.copyfile(lab / file, dest / file)
for file in ("admission.json","representation-evidence.json"):
    shutil.copyfile(lab / file, dest / file)
(dest / "candidate-core.dll.gz").write_bytes(gzip.compress(core, mtime=0))
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for file in ("archive.py", "freeze.py", "stage.py", "quiet.py", "summarize.py", "allocations.py",
            "test-platform.py", "test-capture.py", "check-shapes.py", "admission.py",
            "probe.py", "probe.patch", "probe-build.log", "probe.log", "probe-second.log", "probe-final.log",
            "catalog.json", "eager-admission-catalog.json", "postponed-admission-catalog.json",
            "candidate-build-first.log", "candidate-build-second.log", "freeze-build.log",
            "inspection-catalog.json", "cpython-identity-golden.txt", "donor-inventory.log",
            "windows-white-first.log", "ubuntu-white-first.log",
            "windows-capture-cancellation-first.log", "ubuntu-capture-cancellation-first.log",
            "windows-capture-cancellation.log", "ubuntu-capture-cancellation.log", "cancellation-test.patch",
            "windows-white.log", "windows-public.log", "ubuntu-white.log", "ubuntu-public.log",
            "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/production.patch",
            "comparison/quiet/launch.log", "comparison/quiet/observe-not-before",
            "comparison/quiet/staging.log"):
        archive.add(lab / file, arcname=file, recursive=False)
    for role in ("reference", "candidate"):
        for suffix in ("-allocation-six.json", "-executable.json"):
            file = role + suffix
            archive.add(lab / file, arcname=file, recursive=False)
assert sha(gzip.decompress((dest / "candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest, "retained" if present else "private")
