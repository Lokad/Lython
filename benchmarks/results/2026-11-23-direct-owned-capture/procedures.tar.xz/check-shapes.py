from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(r".git/agent-notes/review-20261031/direct-owned-capture-20261123").resolve()
notes=lab.parent
source=notes/"native-direct-integer-return-refined-20261122/inspect/bin/Release/net11.0"
manifest = json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))
roles={}
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
for role in ("reference","candidate"):
    image=lab/role
    for name,digest in manifest["imageFiles"][role].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==digest
    for path in source.glob("Inspect.*"):
        shutil.copyfile(path,image/path.name)
    output=lab/(role+"-executable.json")
    subprocess.run([dotnet,image/"Inspect.dll",lab/"inspection-catalog.json",output],
        env=env,check=True,timeout=45)
    result=json.loads(output.read_text(encoding="utf-8"))
    assert result["coreSHA256"] == manifest["coreSHA256"][role]
    roles[role]=result["rows"]
assert roles["reference"]==roles["candidate"]
shapes = sum(len(case["codes"]) for case in roles["candidate"])
report = {"scripts":len(roles["candidate"]), "identicalCodeObjects":shapes,
    "coreHashes":manifest["coreSHA256"]}
(lab/"executable-parity.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(shapes, "identical code tapes, operand facts, slots, native flags and handler layouts")
