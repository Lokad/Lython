from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/direct-owned-capture-20261123"
prior=lab.parent/"reachable-operand-forwarding-20261123"
attribution=lab.parent/"retained-factory-construction-20261123"
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
proof=json.loads((prior/"comparison/identity.json").read_text(encoding="utf-8"))
hash_file=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
image=lab/"probe-image"
image.mkdir(exist_ok=True)
core="Lokad.Lython.dll"
for name,digest in proof["imageFiles"]["candidate"].items():
    original=prior/"candidate"/name
    assert hash_file(original)==digest
    source=tree/"src/Lokad.Lython/bin/Release/net11.0"/name if name==core else original
    shutil.copyfile(source,image/name)
hashes={name:hash_file(image/name) for name in proof["imageFiles"]["candidate"]}
assert [n for n in hashes if hashes[n]!=proof["imageFiles"]["candidate"][n]]==[core]
protocol_path=repo/"benchmarks/cpython-worker.py"
assert hash_file(protocol_path)==proof["cpythonWorkerSHA256"]
spec=importlib.util.spec_from_file_location("protocol",protocol_path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
source=attribution/"catalog.json"
catalog=lab/"catalog.json"
shutil.copyfile(source,catalog)
worker=image/"Lokad.Lython.Benchmarks.dll"
results=[]
for case in json.loads(catalog.read_text(encoding="utf-8"))["cases"]:
    with tempfile.TemporaryDirectory(prefix="lython-capture-probe-") as fixture:
        command=[dotnet,worker,"--compare","worker","--catalog",catalog]
        # Serialize the existing protocol so process exit and stderr can be
        # collected in one bounded call without risking pipe deadlock.
        from io import BytesIO
        stdin=BytesIO()
        fields={k:case[k] for k in ("sourceSha256","fixtureSha256","expectedOutputSha256")}
        protocol.write_frame(stdin,dict(protocolVersion=2,requestId=1,operation="verify",caseId=case["id"],lane="warm",iterations=1,**fields))
        protocol.write_frame(stdin,dict(protocolVersion=2,requestId=2,operation="batch",caseId=case["id"],lane="warm",iterations=1,**fields))
        protocol.write_frame(stdin,dict(protocolVersion=2,requestId=3,operation="quit"))
        run=subprocess.run(command,cwd=fixture,env=env,input=stdin.getvalue(),capture_output=True,timeout=25)
        assert run.returncode==0,(run.stderr.decode("utf-8"),run.stdout[-2000:])
        stdout=BytesIO(run.stdout)
        ready=protocol.read_frame(stdout)
        assert ready["status"]=="Ready" and ready["catalogSha256"]==hash_file(catalog)
        assert any(lib["sha256"]==hashes[core] for lib in ready["libraries"])
        verified=protocol.read_frame(stdout)
        assert verified["status"]=="Equivalent"
        batch=protocol.read_frame(stdout)
        closed=protocol.read_frame(stdout)
        assert batch["status"]=="Completed" and closed["status"]=="Closed"
        assert batch["completedInvocations"]==1 and batch["actualOutputSha256"]==case["expectedOutputSha256"]
        output=run.stderr.decode("utf-8")
        match=re.search(r"capture-representations total=(\d+) unpublished=(\d+)",output)
        assert match,(case["id"],output)
        total, unpublished = map(int,match.groups())
        results.append(dict(case=case["id"],total=total,unpublishedInteger=unpublished,batch=batch,
                            verified=verified,closed=closed,diagnostic=output))
        print(case["id"],total,unpublished,flush=True)
(lab/"representation-evidence.json").write_text(json.dumps(dict(sourceRevision="2dbdc963c",
    image=hashes, patch=hash_file(lab/"probe.patch"),catalog=hash_file(catalog),cases=results),indent=2)+"\n",
    encoding="utf-8",newline="\n")
