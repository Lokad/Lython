from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.with_name("raw-expression-retirement-20261124")
prepare = (donor / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('lab.with_name("shared-literal-decoding-20261124") / "refinement"', 'lab.with_name("raw-expression-retirement-20261124")')
prepare = prepare.replace('head.startswith("9e3e85e44")', 'head.startswith("33264df8d")')
begin = prepare.index('generic="diagnostic.')
end = prepare.index('case=dict(', begin)
prepare = prepare[:begin] + '''generic="diagnostic.regex-original-unicode-window"
compiled="scripts.regex-log-search.compiled"
invoice="scripts.csv-invoice.method-policy.quoted-control"
jobs=[[generic,"warm"],[compiled,"warm"],[invoice,"warm"],[generic,"compile-run"]]
catalog=read(lab.with_name("regex-operation-dispatch-20261124")/"comparison/quiet/representative.json")
controls=[row for row in catalog["cases"] if row["id"] in {compiled,invoice}]
assert len(controls)==2
source="""import re
text = 'é😀a|' * 1024
pattern = re.compile(r'(?<=(?P<prefix>é))(?P<item>😀a)|(?P<missing>Z)')
matches = list(pattern.finditer(text, 1, len(text) - 1))
re.purge()
print(len(matches), sum(m.start() for m in matches), sum(m.end('prefix') for m in matches))
print(matches[0].regs, matches[-1].regs, matches[0].pos, matches[0].endpos)
print(matches[0].string is text, matches[-1].group('item'), matches[0].group('missing'))
parts = pattern.split(text)
print(len(parts), parts[:5], parts[-4:])
text_after, count = pattern.subn(lambda m: m.group('prefix'), text, count=17)
print(count, len(text_after), text_after[:12], text_after[-12:])
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=10,check=True)
assert not golden.stderr and golden.stdout.startswith("1024 2096128 2096128\\n"), golden.stdout
fixture=json.dumps({"size":1024,"text":None},separators=(",",":"))
''' + prepare[end:]
prepare = prepare.replace('size=96,source=source', 'size=1024,source=source')
prepare = prepare.replace('Generic class headers have no file fixture.', 'The Unicode regex window has no file fixture.')
prepare = prepare.replace('b"-    private static object EvaluateExpression("', 'b"+            internal bool Next()"')
prepare = prepare.replace('Remove the orphaned syntax evaluator and lower argument expansion directly', 'Bind provider cursor validation and projection to the original subject and window')
prepare = prepare.replace('shared-literal-decoding-b1639-20261124', 'raw-expression-retirement-b1640-20261124')
prepare = prepare.replace('root="raw-expression-retirement-b1640-20261124"', 'root="regex-cursor-original-b1641-20261124"')
prepare = prepare.replace('replace("b1639-fixtures","b1640-fixtures")', 'replace("b1640-fixtures","b1641-fixtures")')
prepare = prepare.replace('24aadf0bcd806af2aeeda2eb04321816ccb79ef4d9ef8ecf0e7b1a3598ed856f', 'aad3b1cf2a0f02cb81e237cb052e5a8e7143b22876d77d62c02b39933e9498ac')
prepare = prepare.replace('replace("lython-b1639-shared-literal-decoding","lython-b1640-raw-expression-retirement").replace("b1639-","b1640-")', 'replace("lython-b1640-raw-expression-retirement","lython-b1641-regex-cursor-original").replace("b1640-","b1641-")')
archive = (donor / "archive.py").read_text(encoding="utf-8").replace('2026-11-24-raw-expression-retirement', '2026-11-24-regex-cursor-original')
for name, source in (("prepare.py", prepare), ("archive.py", archive), ("allocations.py", (donor / "allocations.py").read_text(encoding="utf-8"))):
    compile(source, name, "exec")
    (lab / name).write_text(source, encoding="utf-8", newline="\n")
