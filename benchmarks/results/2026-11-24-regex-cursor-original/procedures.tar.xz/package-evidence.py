from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
out = root / "benchmarks/results/2026-11-24-regex-cursor-original"
quiet = lab / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(quiet / "identity.json")
patch = subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=root)
assert patch == (lab / "candidate.patch").read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
for role, files in identity["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == files
    verify = read(lab / "comparison" / (role + "-verify.json"))
    assert verify["state"] == "Completed" and verify["caseCount"] == 3
    assert verify["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
for path in (quiet / "identity.json", lab / "allocation-summary.json"):
    shutil.copyfile(path, out / path.name)
names = ["package-evidence.py", "make-trial.py", "prepare.py", "prepare.log", "quiet.py", "archive.py", "allocations.py",
         "candidate.patch", "reference-allocation.json", "candidate-allocation.json",
         "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/quiet/storage-custody.json"]
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive} == {
        name: sha(lab / name) for name in names}
print("Verified the measured source patch, both complete images and the archived procedures.")
