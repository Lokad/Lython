from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("raw-expression-retirement-20261124")
previous = donor / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda data: hashlib.sha256(data.encode("utf-8")).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
base = read(previous / "identity.json")
core = "Lokad.Lython.dll"
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("33264df8d")
assert subprocess.check_output(["git","diff","--binary",base["sourceRevision"],head,"--","src","tests"],cwd=repo)==(donor/"candidate.patch").read_bytes()
reference = base["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == reference
current = lab/"windows/bin/Lokad.Lython/release_net11.0"/core
images = {"reference": reference, "candidate": reference | {core:sha(current)}}
assert images["candidate"][core] != reference[core]
for role, files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(current if role=="candidate" and name==core else donor/"candidate"/name,image/name)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files

generic="diagnostic.regex-original-unicode-window"
compiled="scripts.regex-log-search.compiled"
invoice="scripts.csv-invoice.method-policy.quoted-control"
jobs=[[generic,"warm"],[compiled,"warm"],[invoice,"warm"],[generic,"compile-run"]]
catalog=read(lab.with_name("regex-operation-dispatch-20261124")/"comparison/quiet/representative.json")
controls=[row for row in catalog["cases"] if row["id"] in {compiled,invoice}]
assert len(controls)==2
source="""import re
text = 'é😀a|' * 1024
pattern = re.compile(r'(?<=(?P<prefix>é))(?P<item>😀a)|(?P<missing>Z)')
matches = list(pattern.finditer(text, 1, len(text) - 1))
re.purge()
print(len(matches), sum(m.start() for m in matches), sum(m.end('prefix') for m in matches))
print(matches[0].regs, matches[-1].regs, matches[0].pos, matches[0].endpos)
print(matches[0].string is text, matches[-1].group('item'), matches[0].group('missing'))
parts = pattern.split(text)
print(len(parts), parts[:5], parts[-4:])
text_after, count = pattern.subn(lambda m: m.group('prefix'), text, count=17)
print(count, len(text_after), text_after[:12], text_after[-12:])
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=10,check=True)
assert not golden.stderr and golden.stdout.startswith("1024 2096128 2096128\n"), golden.stdout
fixture=json.dumps({"size":1024,"text":None},separators=(",",":"))
case=dict(id=generic,family="scripts",category="whole-script",scale="small",size=1024,source=source,
    fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode("utf-8")),
    expectedOutputUtf8Bytes=len(golden.stdout.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout))
catalog["cases"]=[case,*controls]
catalog["fixtureEncoding"]="Canonical base64 file maps in both existing controls. The Unicode regex window has no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
assert b"+            internal bool Next()" in patch.read_bytes()
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(patch),
    purpose="Bind provider cursor validation and projection to the original subject and window",
    imageFiles=images,expectedCPythonSHA256=base["expectedCPythonSHA256"],cpythonWorkerSHA256=base["cpythonWorkerSHA256"],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")},
    catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(previous/"collect.py").read_text(encoding="utf-8").replace("b1640-fixtures","b1641-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(previous/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
for role in images:
    output=lab/"comparison"/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
        "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked["state"]=="Completed" and checked["caseCount"]==3
    assert checked["catalogSha256"]==sha(expected) and checked["launched"]["library"]["sha256"]==images[role][core]
staged=quiet/"payload.tar.gz"
with tarfile.open(staged,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="regex-cursor-original-b1641-20261124",
    reference="raw-expression-retirement-b1640-20261124",payloadSHA256=sha(staged),payloadBytes=staged.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(donor/"quiet.py").read_text(encoding="utf-8")
receipt=read(previous/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(previous/"observations.tar.xz")==receipt["archiveSHA256"]
assert "aad3b1cf2a0f02cb81e237cb052e5a8e7143b22876d77d62c02b39933e9498ac" in launch
launch=launch.replace("aad3b1cf2a0f02cb81e237cb052e5a8e7143b22876d77d62c02b39933e9498ac",receipt["archiveSHA256"])
launch=launch.replace("lython-b1640-raw-expression-retirement","lython-b1641-regex-cursor-original").replace("b1640-","b1641-")
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Verified 32 files per image and three complete CPython goldens.")
