from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'prepare.py'
text=path.read_text(encoding='utf-8-sig')
needle="    write(name,s)\nassert b'\\r'"
replace="""    if name in ('archive-owned.py','retrieve.py'):
        s=s.replace("len(raw['jobs'])==3","len(raw['jobs'])==4").replace("['jobs']==3","['jobs']==4").replace('jobs=3,','jobs=4,')
    write(name,s)
assert b'\\r'"""
assert text.count(needle)==1
text=text.replace(needle,replace)
compile(text,path,'exec')
path.write_text(text,encoding='utf-8',newline='\n')
