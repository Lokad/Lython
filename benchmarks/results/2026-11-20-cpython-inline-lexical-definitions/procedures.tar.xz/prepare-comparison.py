from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.parent/'lexical-delivery-cpython'
read=lambda p:p.read_text(encoding='utf-8-sig')
def write(name, text):
    compile(text,name,'exec')
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
ids=['scripts.annotated-rule-closures','scripts.annotated-rule-closures.nested-factories',
     'scripts.annotated-rule-closures.postponed','scripts.csv-invoice.large']
prepare=read(previous/'prepare.py')
prepare=prepare.replace('single-lexical-class-cells','shared-lexical-definitions')
prepare=prepare.replace('lexical-delivery-cpython-b1200','factory-delivery-cpython-b1203').replace('lython-b1200-lexical-delivery-cpython','lython-b1203-factory-delivery-cpython')
prepare=prepare.replace("assert commit.startswith('f65be4da5')","assert pair['candidateCommit'].startswith('32c5f2ef7')")
prepare=prepare.replace("trial/'catalog.json','representative.json'","trial/'comparison-catalog.json','representative.json'")
prepare=prepare.replace("trial/'candidate-verify.json','verify.json'","trial/'candidate-comparison-verify.json','verify.json'")
prepare=prepare.replace("pair['casesSHA256']==load(lab/'verify.json')['catalogSha256']","donor['catalogSHA256']==load(lab/'verify.json')['catalogSha256']")
prepare=prepare.replace("ids=['scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures','scripts.csv-invoice.large']",'ids='+repr(ids))
prepare=prepare.replace('Lexical class-cell delivery against stock CPython','Shared lexical definition delivery against stock CPython')
prepare=prepare.replace(".replace('B1190','B1200')",".replace('B1190','B1203')")
prepare=prepare.replace('scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures')
prepare=prepare.replace("        s=s.replace('n*.25/max','n*.4/max')","        s=s.replace('n*.25/max','n*.4/max')")
prepare=prepare.replace("'seconds=225'","'seconds=260'").replace("'before 225'","'before 260'").replace('class delivery comparison','factory delivery comparison')
prepare=prepare.replace("s=s.replace('lython-b1190-fixtures','lython-b1200-fixtures')","s=s.replace('lython-b1190-fixtures','lython-b1203-fixtures')")
write('prepare.py',prepare)
archive=read(previous/'archive.py')
archive=archive.replace('cpython-lexical-class-cells','cpython-inline-lexical-definitions').replace('B1200','B1203')
archive=archive.replace('receipt["jobs"] == 3','receipt["jobs"] == 4').replace('len(raw["jobs"]) == 3 and len(cases) == 5','len(raw["jobs"]) == 4 and len(cases) == 4')
archive=archive.replace("['scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures','scripts.csv-invoice.large']",repr(ids))
archive=archive.replace('scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures')
archive=archive.replace('assert len(rows) == 5','assert len(rows) == 6').replace('verifiedBatches=100','verifiedBatches=120')
archive=archive.replace('../2026-11-20-lexical-class-cells/measured-core.dll.gz','../2026-11-20-inline-lexical-definitions/measured-core.dll.gz')
write('archive.py',archive)
print('Prepared a six-phase refresh using the exact retained image and four verified goldens.')
