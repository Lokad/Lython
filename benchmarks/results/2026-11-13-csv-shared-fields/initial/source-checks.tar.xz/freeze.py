from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'immutable-repeat-r307';baseline=json.loads((old/'index-corrected/candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();sources={p:sha(p)for p in names};assert len(sources)==572
changed=[p for p,h in sources.items()if h!=baseline['sources'][p]];assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs'],changed
for role in ['reference','candidate']:
 shutil.copytree(old/'candidate',r/role,copy_function=os.link)
 (r/role/'Lokad.Lython.dll').unlink()
 shutil.copyfile(old/'index-corrected/Lokad.Lython.dll'if role=='reference'else Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'),r/role/'Lokad.Lython.dll')
shutil.copy2(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R308 CSV long fields share one immutable packed row payload using existing UTF8 windows; inline fields unchanged',sources=sources,changed=changed,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=baseline['coreSHA256'])
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
print(identity['coreSHA256'],changed,flush=True)
