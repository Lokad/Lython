from pathlib import Path
import base64,csv,hashlib,io,json,struct,subprocess,tempfile
r=Path(__file__).parent;old=r.parent/'immutable-repeat-r307';catalog=json.loads((old/'catalog-existing.json').read_text(encoding='utf-8'));case=next(c for c in catalog['cases']if c['id']=='scripts.csv-invoice.large').copy();fixture=json.loads(case['fixtureJson']);original=base64.b64decode(fixture['inputFiles']['input.csv']).decode('utf-8')
reader=csv.DictReader(io.StringIO(original,newline=''));fields=reader.fieldnames;assert fields
output=io.StringIO(newline='');writer=csv.DictWriter(output,fieldnames=fields+['description','document_path','owner_note'],lineterminator='\n');writer.writeheader();count=0
for i,row in enumerate(reader):
 row.update(description=f'Record {i:05d}: matériel café😀, reference "invoice"',document_path=f'/workspace/accounts/team-{i%7}/exports/invoice-{i:05d}.csv',owner_note=f'contact person-{i%13:02d}@example.invalid — approved for review')
 writer.writerow(row);count+=1
assert count==4096
data=output.getvalue().encode('utf-8');fixture['inputFiles']['input.csv']=base64.b64encode(data).decode('ascii');case['id']='scripts.csv-invoice.rich-text';case['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'));case['fixtureSha256']=hashlib.sha256(case['fixtureJson'].encode('utf-8')).hexdigest()
with tempfile.TemporaryDirectory(prefix='lython-rich-invoice-golden-')as folder:
 (Path(folder)/'input.csv').write_bytes(data)
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr;assert done.stdout==case['expectedOutput']
 for name,value in fixture['outputFiles'].items():assert (Path(folder)/name).read_bytes()==base64.b64decode(value)
case['scale']='rich-text'
catalog['cases']=[c for c in catalog['cases']if c['id']!='scripts.file-search.guarded-helper.large']+[case];assert len(catalog['cases'])==8
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'rich-fixture.json').write_text(json.dumps(dict(case=case['id'],sourceSHA256=case['sourceSha256'],sameScriptAsOriginalInvoice=True,records=count,inputBytes=len(data),additionalFields=3,expectedOutput=case['expectedOutput'],expectedFilesSHA256=case['expectedFilesSha256'],independentPythonVersion=subprocess.check_output(['C:/Python313/python.exe','-V'],text=True).strip(),purpose='Representative descriptive/path/note CSV columns, all eagerly materialized by both runtimes; original short-field controls retained'),indent=2)+'\n',encoding='utf-8')
print(count,'records;',len(data),'input bytes; exact original invoice source/output and independent CPython golden.',flush=True)
