from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'arithmetic-source-r305/b661';out=r/'b663';out.mkdir()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/csv-shared-b663-20261113';oldroot='/home/lokad/lython-bench-checks/integer-b661-20261113'
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));selected={'scripts.csv-invoice.rich-text','scripts.csv-invoice.large','scripts.text-summary-helpers.nonlocal-counter.large'};catalog['cases']=[c for c in catalog['cases']if c['id']in selected];assert len(catalog['cases'])==3
(out/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='Committed14dd45b7/93a6d134 versus uncommitted21d0be4f CSV shared long fields; exact sources, initial final-baseline qualification running',purpose='Text-rich invoice warm/fresh, original invoice/captured controls; source-pair only',coreSHA256={k:source['referenceSHA256']if k.startswith('reference')else source['coreSHA256']for k in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=hashlib.sha256((out/'representative.json').read_bytes()).hexdigest(),sourceIdentitySHA256=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest(),referenceSourceIdentitySHA256=hashlib.sha256((r.parent/'immutable-repeat-r307/index-corrected/candidate-identity.json').read_bytes()).hexdigest(),productionSourceArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.csv-invoice.rich-text','warm'],['scripts.csv-invoice.rich-text','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
code=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root);a=code.index('jobs=');b=code.index('\nenv =',a);code=code[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+code[b:]
code=code.replace('Pre-admitted integer kernel; invoice warm/fresh, captured and JSON controls; exact source-pair, no external ratio','CSV shared long fields; text-rich invoice warm/fresh, original invoice/captured controls; exact source-pair, no external ratio');ast.parse(code);(out/'collect.py').write_text(code,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh']:(out/name).write_text((old/name).read_text(encoding='utf-8').replace(oldroot,root),encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']};files.update({'current-core.dll':r/'candidate-core.dll','reference-core.dll':r.parent/'immutable-repeat-r307/index-corrected/Lokad.Lython.dll','source-identity.json':r/'candidate-identity.json','reference-source-identity.json':r.parent/'immutable-repeat-r307/index-corrected/candidate-identity.json','cpython-worker.py':old/'retrieved/cpython-worker.py'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['groups']
config=dict(root=root,unit='lython-b663-csv-shared-20261113',sourceRoot='/home/lokad/lython-bench-checks/integer-b661-20261113',sourceCoreSHA256=json.loads((old/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate'],identity=identity,retire=retire,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b661','b663').replace('B661','B663')
code=code.replace("config['identity']['coreSHA256']['reference']","config['sourceCoreSHA256']").replace("assert before>252*1024*1024+config['unpackedBytes']+2*1024*1024","assert before+sum(p['allocatedBytes']for p in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024")
at=code.index('  root.mkdir()')if '  root.mkdir()'in code else code.index(' root.mkdir()')
addition=''' # Retire only exact, superseded/unqualified cores whose bytes are already
 # independently verified in tracked canonical archives; qualified images stay.
 for row in config['retire']:
  actual=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    p=Path(folder)/name;s=p.lstat()
    if(s.st_dev,s.st_ino)==(row['device'],row['inode']):actual.append(str(p.relative_to(base)))
  assert sorted(actual)==sorted(row['aliases'])and len(actual)==row['links']==2
  for p in [base/a for a in row['aliases']]:
   s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links'],row['bytes'])and digest(p)==row['sha256']==row['canonical']['sha256']
 for row in config['retire']:
  for i,a in enumerate(row['aliases']):
   p=base/a;s=p.lstat();assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links']-i,row['bytes'])and digest(p)==row['sha256'];p.unlink()
'''
code=code[:at]+addition+code[at:]
code=code.replace("os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')","os.link(root/('reference-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')")
code=code.replace("  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]","  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]")
code=code.replace("retired=[]","retired=config['retire']")
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
for name in ['retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace('integer-b661-20261113','csv-shared-b663-20261113').replace('lython-b661-integer-20261113','lython-b663-csv-shared-20261113').replace('B661','B663');ast.parse(code);(out/name).write_text(code,encoding='utf-8')
print('B663 prepared: four jobs, three-case catalog; unpacked',config['unpackedBytes'],'fresh idle lease/canonical retirement proof required.',flush=True)
