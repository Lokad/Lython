from pathlib import Path
import ast,json,subprocess,sys
r=Path(__file__).parent;old=r.parent/'arithmetic-source-r305';target=r.parent/'immutable-repeat-r307';code=(old/'save-delivery.py').read_text(encoding='utf-8')
code=code.replace('2026-11-13-integer-admission/delivery','2026-11-13-immutable-repetition/delivery').replace("r/'candidate-identity.json'","r/'index-corrected/candidate-identity.json'").replace("r/'candidate-sources.tar.xz'","r/'index-corrected/candidate-sources.tar.xz'").replace("r/'candidate-core.dll'","r/'index-corrected/Lokad.Lython.dll'")
at=code.index("(out/'README.md').write_text(");code=code[:at]+'''(out/'README.md').write_text('''+repr('''# Immutable repetition delivery

Runtime **14dd45b7**, frozen final core **93a6d134**, is fully qualified by
[CI43390871843](https://github.com/Lokad/Lython/actions/runs/43390871843): Windows
and Ubuntu actual.NET11/.NET10 ordinary tests, original stress scales and installed
Release package consumers pass. All572frozen production inputs match the exact CI
head with explicit checkout normalization. Terminal, full logs and16individual-step
count lines are cached. Generated metadata can change hashes; CI byte identity is
not inferred from matching sources. A later CSV prototype does not change this
source-specific qualification.

Admission now precedes immutable bytes allocation for owned/unowned inputs. Shared
bounded copying preserves text/tuple semantics and funding; native index overflow
follows independent Python checks. Final192internal/339public focused cases pass.
Initial6f desktop clocks retain their own source label and establish no controlled
CPU gain. No new runtime or external ratio is inferred from them.

Reuse this delivery; no unchanged full replay is needed. Broader performance and
independent regex work remain active. Publication/tagging remain postponed.

[Terminal](ci-terminal.json), [full logs](ci-logs.zip),
[step counts](test-counts.json), [source proof](source-proof.json).
''')+''',encoding='utf-8')
print('14dd45b7 GREEN;572frozen sources match;16individual-step counts; all delivery gates verified.',flush=True)
'''
ast.parse(code);(target/'save-delivery.py').write_text(code,encoding='utf-8');subprocess.run([sys.executable,'-X','utf8',str(target/'save-delivery.py')],check=True)
p=Path('benchmarks/results/2026-11-13-immutable-repetition/validation.json');d=json.loads(p.read_text(encoding='utf-8'));d['fullPlatformStressInstalledPackageQualification']='GREEN43390871843; exact14dd45b7/93a6d134; cached delivery source proof';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=Path('benchmarks/results/2026-11-13-immutable-repetition/README.md');s=p.read_text(encoding='utf-8').replace('remains postponed. Full platform/stress/installed-package qualification is next;\nthe earlier3a GREEN does not qualify this source.', 'remains postponed. Full platform/stress/installed-package qualification is now\nGREEN43390871843 for exact14dd45b7/93a6d134. [Cached delivery](delivery/README.md).');p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Fully qualified current committed runtime |');b=s.index('\n',a);s=s[:a]+'''| Fully qualified current committed runtime | **14dd45b7/93a6d134**, GREEN43390871843: Windows/Ubuntu actual.NET11/10 ordinary tests, original stress and installed Release consumers.572frozen production inputs match the CI head; terminal/logs/16step counts cached. [Delivery](benchmarks/results/2026-11-13-immutable-repetition/delivery/README.md). |'''+s[b:]
a=s.index('| Current committed delivery candidate |');b=s.index('\n',a);s=s[:a]+'''| Current uncommitted prototype | **R308/21d0be4f**, one production file: CSV long fields share one immutable row payload.117internal/372public focused CSV cases and eight complete scripts/both APIs pass. Rich-field allocation−3.50%; desktop elapsed adverse. Controlled four-job B663 is running; do not promote before its retain/refine/withdraw decision. |'''+s[b:]
a=s.index('1. **Close R307');b=s.index('\n2. **R308',a);s=s[:a]+'''1. **R307 delivery CLOSED.** Three immutable fill loops and tuple's redundant late
   admission are replaced by one bounded copy kernel. Owned/unowned bytes preflight
   before allocation, initial input/result aliases remain funded, native index
   overflow follows CPython. Final192internal/339public checks plus full delivery
   are GREEN. Initial6f clocks stay diagnostic/source-labelled. Preserve failed
   oversized-count expectations; no unchanged qualification or retiming replay.
'''+s[b:]
s=s.replace('**R308 selected: shared CSV long-field backing (prototype next).**','**R308 selected: shared CSV long-field backing (controlled comparison running).**')
s=s.replace('   Stop with retain/refine/withdraw and explicit control-regression debt;', '   Current21d0be4f:117internal/372public checks pass; eight scripts/both APIs pass,\n   rich-field allocation−3.50%. Desktop rich elapsed is adverse; preserve all rows.\n   B663 uses exact93a6 reference, rich warm/fresh and original invoice/captured\n   controls,300sowner/180sfirst observation. Two exact superseded/unqualified cores\n   are retired only after tracked-archive byte/all-alias/inode/UID verification\n   under a fresh idle lease; qualified images/floors preserved.\n   Stop with retain/refine/withdraw and explicit control-regression debt;')
p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8').replace('Incorrect initial oversized-count expectations survive; full\ndelivery is pending and the broader performance objective remains open.', 'Incorrect initial oversized-count expectations survive; full delivery is\nGREEN43390871843 for14dd45b7/93a6d134. The broader performance objective remains open.');p.write_text(s,encoding='utf-8')
paths=['benchmarks/results/2026-11-13-immutable-repetition/delivery','benchmarks/results/2026-11-13-immutable-repetition/validation.json','benchmarks/results/2026-11-13-immutable-repetition/README.md','benchmarks/EXPERIMENTS.md']
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','commit','-m','Record qualified immutable repetition delivery [skip ci]'],check=True)
