from pathlib import Path
import json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-csv-shared-fields/initial');out.mkdir(parents=True)
for name in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:
 shutil.copy2(r/'b663'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if not p.is_file()or set(relative.parts)&{'bin','obj','candidate','reference','b663'}:continue
  if p.suffix in {'.py','.json','.log','.cs','.csproj','.txt','.dll','.xz','.md'}:a.add(p,arcname=relative.as_posix())
(out/'README.md').write_text('''# Shared CSV field backing: first controlled phase

Uncommitted R308/frozen21d0be4f against fully qualified14dd45b7/93a6d134.
One production file packs all non-inline text fields into one immutable row array
using existing UTF8 windows. Short fields remain inline; admission/working overlap,
grammar/error order and row adoption unchanged. No new ownership infrastructure.
Retaining one field pins the row's long payload; the batch already retains charges.

117internal/372public actual.NET11 Release CSV checks pass: new row-admission
refusal/cancellation, long Unicode offsets/aliases, later input and scratch cleanup,
genuine delayed reads plus existing numeric/header/error/protocol coverage. An initial
test-host conditional type error is preserved and corrected before measurements.

Eight complete scripts/both APIs pass. The new text-rich invoice uses the exact
original script/output:4096records/823388B, three realistic description/path/note
columns, independent CPython3.13.2 goldens. It closes a fixture gap; original short
invoice/CSV/text/JSON/report controls remain. No new benchmark framework.
Rich allocation−3.50% both APIs, other allocation flat. Desktop rich elapsed is
adverse(+2.8..4.7%sync,+6.2..11.3%async), with moving/adverse controls preserved.

| Whole script / phase | Quiet elapsed | Wider process CPU | Reference/candidate spread; max IQR |
| --- | ---: | ---: | --- |
| Text-rich invoice warm |−2.41..−0.28%|−1.75..+0.13%|0.86/1.31%;1.29%|
| Text-rich invoice compile + run |−1.71..0%|−1.85..+1.85%|1.63/0.09%;1.67%|
| Original invoice warm |−3.95..−0.49%|−5.09..+0.31%|3.34/0.15%;1.06%|
| Captured text warm |−7.91..+0.11%|−7.85..+0.29%|7.65/0.39%;1.43%|

B663 completes four jobs169.459s within300s owner,2026-11-13UTC, quietF4as_v7/
Ubuntu24.04.4/fourEPYC9V45vCPUs/16GiB/no swap, ordinary.NET11RC3 GC/tiering,
unchangedfec79worker/adapter0.4. Five rotating500ms rounds,5s warmups(12captured),
two processes/image. Ranges all four medians, not confidence intervals. Warm includes
mediated RAM-file I/O, full stdout/file checks and prior-result cleanup; fresh adds
compile/compiled-owner disposal. Startup/reset/staging/final cache cleanup excluded.
Wider CPU includes reset/protocol. No CPython performance or embedding-latency claim.

All identity/golden/balance/quiet/join/persistent-SHA archive gates pass. No users
or RAM fixtures remain. To stage exact93a6reference plus21candidate, only superseded/
unqualified628ab680/2f34a48f cores are retired after tracked-canonical archive bytes,
all aliases/inodes/UIDs and fresh idle lease verification. Qualified cores remain;
OS240MiB/evidence12MiB/staging floors are unchanged. All proofs survive in source
evidence. Final free267374592B.

Decision is refinement, not promotion or a CPU failure verdict. Controlled results
do not reproduce desktop adversity, but CPU/fresh cross zero and captured reference
spread is7.65%. One coherent simplification follows: derive sizing from completed
field descriptors, deleting persistent byte counters/reset invariants. Retain
this original phase and allow one changed-source confirmation before a final
retain/refine/withdraw decision. No unchanged retiming/full qualification replay.

[Raw observations](observations.tgz), [computed rows](summary.json),
[exact source/bits/checks/failed conditions](source-checks.tar.xz).
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');at=s.index('[Shared immutable repetition]');s=s[:at]+'''[CSV shared long-field backing, first phase](results/2026-11-13-csv-shared-fields/initial/README.md)
uses existing UTF8 windows to remove per-long-field byte arrays.117internal/372public
CSV checks and eight scripts/both APIs pass; rich-field allocation−3.50%. B663 four
controlled jobs169.459s does not reproduce desktop adversity, but CPU/fresh cross
zero and captured controls move7.65%. One state-removal refinement is selected;
no promotion/CPU claim or fixed-percentage veto. All original adverse rows survive.

'''+s[at:];p.write_text(s,encoding='utf-8')
subprocess.run(['git','add','--',str(out),'benchmarks/EXPERIMENTS.md'],check=True);subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','commit','-m','Preserve initial shared CSV backing evidence and refinement decision [skip ci]'],check=True)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('**R308 selected: shared CSV long-field backing (controlled comparison running).**','**R308 selected: shared CSV long-field backing (one state-removal refinement).**')
at=s.index('   Current21d0be4f:');end=s.index('   Stop with retain/refine/withdraw',at)
s=s[:at]+'''   Initial21d0be4f:117internal/372public checks/eight scripts both APIs pass;
   allocation−3.50%, desktop rich elapsed adverse. B663 completes169.459s/full gates:
   rich warm−2.41..−0.28%, fresh−1.71..0%, widerCPU crosses zero; captured reference
   spread7.65%. Original adverse data retained, no CPU claim/promotion.
   [Initial exact evidence](benchmarks/results/2026-11-13-csv-shared-fields/initial/README.md).

   One refinement: derive result/shared sizes from complete field descriptors;
   delete persistent _stringBytes/_sharedPayloadLength counters and all reset
   invariants. Preserve output admission before allocation, long-field sharing,
   short-field inline representation and callback/error order. The extra descriptor
   pass is a CPU tradeoff requiring changed-source confirmation, not an automatic
   promotion. Reuse focused CSV regressions/short rich+original controls; preserve
  21bits and all failed/original conditions. End with a retain/withdraw/debt decision.
'''+s[end:];p.write_text(s,encoding='utf-8')
