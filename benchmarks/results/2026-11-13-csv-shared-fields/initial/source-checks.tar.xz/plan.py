from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');r=Path(__file__).parent;(r/'previous-plan.md').write_text(s,encoding='utf-8')
at=s.index('2. **Next substantial redesign:');s=s[:at]+'''2. **R308 selected: shared CSV long-field backing (prototype next).** Source
   proves that native/in-place CSV decoding and bulk row admission already exist,
   but FinishRecord still allocates a separate byte array for every field above
   PyString's8-byte inline tier. Replace those independent arrays with one packed
   immutable row payload, using existing managed UTF8 string windows. Short fields
   stay inline; quoted/numeric parsing, descriptors and row adoption stay shared.
   Eliminate N−1long-field arrays per row; no new parser, cache, owner graph or
   public API. This is an allocation/GC/transport hypothesis, not measured CPU
   dominance on the current short-field fixtures.

   Retain current conservative admission (all string/row bytes, working overlap)
   before allocating the packed array, publish only complete rows, and keep the
   whole backing funded while any field survives. Retaining one field pins the
   row's long payload; current batch ownership already conservatively retains its
   charges. Independent projection/retained owners must still be established first.
   Preserve field offsets/Unicode, quotes/escapes/newlines, QUOTE_NONNUMERIC error
   order, mutable headers, subsequent rows/scratch cleanup, cancellation, terminal
   refusal and delayed I/O. Existing copy-based array-per-field code must disappear
   from the long-field branch, with no compatibility switches.

   Focused CSV public/internal regressions plus direct row-admission refusal/
   cancellation and retained-field independence. Add one text-rich variant of the
   existing complete invoice fixture (same script) to measure the affected storage;
   keep original short-field invoice, CSV and captured-text controls. Reuse fixed
   worker/goldens/quiet VM, short bounded source-pair, allocation separate from CPU.
   Stop with retain/refine/withdraw and explicit control-regression debt; no fixed
   percentage veto, repeated framework/campaign or implied CPython ratio.

'''+s[at:];s=s.replace('2. **Next substantial redesign:', '**Remaining substantial redesign source gates:**')
p.write_text(s,encoding='utf-8');print('R308 selected with exact removed storage, tradeoff and bounded acceptance.',flush=True)
