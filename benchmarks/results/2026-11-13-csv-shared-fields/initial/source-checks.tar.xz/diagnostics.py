from pathlib import Path
import ast,subprocess,sys
r=Path(__file__).parent;old=r.parent/'immutable-repeat-r307'
for name in ['diagnostic.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8');ast.parse(code);(r/name).write_text(code,encoding='utf-8')
for phase in ['warm-sync','warm-async']:
 subprocess.run([sys.executable,'-X','utf8',str(r/'diagnostic.py'),phase],check=True)
subprocess.run([sys.executable,'-X','utf8',str(r/'summarize.py')],check=True)
