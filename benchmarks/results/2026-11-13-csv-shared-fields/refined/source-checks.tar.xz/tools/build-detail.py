from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).parent.parent/'pytools'))
import psutil
p=psutil.Process(69696)
for c in [p]+p.children(recursive=True):
    print(c.pid,c.ppid(),c.name(),c.cmdline(),c.cpu_times(),flush=True)
