from pathlib import Path
import hashlib, subprocess
r=Path(__file__).parent
p='src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs'
current=Path(p).read_bytes()
assert hashlib.sha256(current).hexdigest()==__import__('json').loads((r/'refined/candidate-identity.json').read_text(encoding='utf-8'))['sources'][p]
(r/'refined/CsvModule.prototype.cs').write_bytes(current)
Path(p).write_bytes(subprocess.check_output(['git','show','14dd45b7:'+p]))
assert not subprocess.check_output(['git','diff','--',p])
code=(r/'check.py').read_text(encoding='utf-8').replace('focused-','restored-').replace("args+=['-m:1']", "args+=['-m:1','--no-incremental']")
(r/'restored-check.py').write_text(code,encoding='utf-8')
print('Production CSV restored exactly to qualified14dd45b7; useful semantic regressions retained; forced nonincremental rebuild required.',flush=True)
