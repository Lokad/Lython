from pathlib import Path
import datetime
p=Path(__file__).parent/'refined/warm-sync'
now=datetime.datetime.now(datetime.timezone.utc)
for f in sorted(p.glob('*')):
    print(f.name,f.stat().st_size,round(now.timestamp()-f.stat().st_mtime,1),'s since update')
