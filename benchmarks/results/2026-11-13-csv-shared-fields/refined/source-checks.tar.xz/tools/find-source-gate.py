from pathlib import Path
p=Path(__file__).parent.parent
for f in p.iterdir():
    if f.is_dir() and any(x in f.name for x in ['r302','r306','invoice','captured-cpu']):
        print(f)
        print('  '+', '.join(x.name for x in f.iterdir()))
