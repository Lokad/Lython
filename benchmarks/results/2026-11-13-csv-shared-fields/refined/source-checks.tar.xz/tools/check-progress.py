from pathlib import Path
import datetime
p=Path(__file__).parent
for f in sorted(p.glob('restored-*.log')):
    print(f.name, f.stat().st_size, f.read_text(encoding='utf-8',errors='replace')[-1200:])
