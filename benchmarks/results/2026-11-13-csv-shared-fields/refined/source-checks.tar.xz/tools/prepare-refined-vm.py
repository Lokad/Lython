from pathlib import Path
import ast, hashlib, json, subprocess, tarfile

r = Path(__file__).parent
old = r / 'b663'
image = r / 'refined'
out = r / 'b664'
out.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = json.loads((image / 'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(p) == h for p, h in source['sources'].items())
canonical = 'benchmarks/results/2026-11-13-csv-shared-fields/initial/source-checks.tar.xz'
subprocess.run(['git', 'ls-files', '--error-unmatch', canonical], check=True, stdout=subprocess.DEVNULL)
expected = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))['coreSHA256']
with tarfile.open(canonical) as archive:
    matches = [m for m in archive.getmembers() if m.isfile() and m.name.endswith('candidate-core.dll') and hashlib.sha256(archive.extractfile(m).read()).hexdigest() == expected]
assert len(matches) == 1
proof = dict(path='csv-shared-b663-20261113/candidate/Lokad.Lython.dll', sha256=expected,
    canonical=dict(canonical=canonical, member=matches[0].name, bytes=matches[0].size, sha256=expected))
inspect = (r / 'inspect-vm.py').read_text(encoding='utf-8')
start = inspect.index("code='''") + len("code='''")
end = inspect.index("'''.replace('SPECS'", start)
code = inspect[start:end].replace('SPECS', repr([proof]))
(out / 'inspect-vm-command.py').write_text(code, encoding='utf-8')
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
done = subprocess.run(ssh + ['python3 -'], input=code, text=True, encoding='utf-8', capture_output=True)
assert done.returncode == 0, done.stderr
(out / 'retirement-inspection.json').write_text(done.stdout, encoding='utf-8')
retire = json.loads(done.stdout)['groups']
root = '/home/lokad/lython-bench-checks/csv-shared-refined-b664-20261113'
oldroot = '/home/lokad/lython-bench-checks/csv-shared-b663-20261113'
identity = json.loads((old / 'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Fully qualified14dd45b7/93a6d134 versus uncommitted277cb5a5 descriptor-derived CSV shared long fields; exact source-pair',
    coreSHA256={k: source['referenceSHA256'] if k.startswith('reference') else source['coreSHA256'] for k in identity['coreSHA256']},
    sourceIdentitySHA256=sha(image / 'candidate-identity.json'), productionSourceArchiveSHA256=sha(image / 'candidate-sources.tar.xz'))
(out / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    code = (old / name).read_text(encoding='utf-8').replace(oldroot, root).replace('lython-b663-csv-shared-20261113', 'lython-b664-csv-shared-refined-20261113').replace('B663', 'B664')
    if name.endswith('.py'): ast.parse(code)
    (out / name).write_text(code, encoding='utf-8', newline='\n')
files = {n: out / n for n in ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']}
files.update({'current-core.dll': image / 'candidate-core.dll', 'source-identity.json': image / 'candidate-identity.json'})
with tarfile.open(out / 'payload.tgz', 'w:gz') as archive:
    for name, p in files.items(): archive.add(p, arcname=name)
config = dict(root=root, unit='lython-b664-csv-shared-refined-20261113', sourceRoot=oldroot, sourceCoreSHA256=source['referenceSHA256'],
    identity=identity, retire=retire, payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=sha(out / 'payload.tgz'), unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out / 'config.json').write_text(json.dumps(config, indent=2)+'\n', encoding='utf-8')
code = (old / 'launch.py').read_text(encoding='utf-8').replace('b663', 'b664').replace("source/'candidate'", "source/'reference'")
code = code.replace("os.link(root/('reference-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')",
    "os.link(source/'reference/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')")
marker = "  assert digest(root/'current-core.dll')"
assert marker in code
at = code.index(marker)
addition = "  for name in ['representative.json','reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)\n"
code = code[:at]+addition+code[at:]
ast.parse(code)
(out / 'launch.py').write_text(code, encoding='utf-8')
print('B664 prepared; fresh idle lease, exact canonical superseded21 retirement, qualified93 preserved; unpacked bytes', config['unpackedBytes'], flush=True)
