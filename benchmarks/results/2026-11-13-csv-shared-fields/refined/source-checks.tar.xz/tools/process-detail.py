from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).parent.parent/'pytools'))
import psutil
for p in psutil.process_iter(['pid','ppid','name']):
    if p.info['name'].lower() in ['dotnet.exe','python.exe']:
        p.info.update(cmdline=p.cmdline(),cpu_times=p.cpu_times())
        args=' '.join(p.info['cmdline'] or [])
        if 'csv-shared-fields-r308' in args or 'complete-jobs.dll' in args or 'Lython.Tests' in args or 'csc.dll' in args:
            print(json.dumps({k:str(v) if k=='cpu_times' else v for k,v in p.info.items()}))
