from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).parent.parent/'pytools'))
import psutil
for pid in [54448,30024]:
    print('Inspecting',pid,flush=True)
    try:
        p=psutil.Process(pid)
        print(p.name(),p.cmdline(),p.cpu_times(),p.status(),flush=True)
    except psutil.NoSuchProcess: print('No longer running',flush=True)
