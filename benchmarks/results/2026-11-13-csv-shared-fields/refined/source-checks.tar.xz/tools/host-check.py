from pathlib import Path
import shutil,datetime
for folder in [Path('C:/Users/JoannesVermorel/.dotnet/tools'),Path('.git/agent-notes/review-20261031')]:
    print(folder,[p.name for p in folder.glob('*stack*')]+[p.name for p in folder.glob('*trace*')])
for drive in ['C:/','D:/']:print(drive,shutil.disk_usage(drive))
for p in [Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'),Path('src/Lokad.Lython/obj/Release/net11.0/Lokad.Lython.dll')]:
    print(p,p.stat().st_size,datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc))
