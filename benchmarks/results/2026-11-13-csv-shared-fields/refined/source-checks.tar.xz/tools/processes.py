import subprocess
script = 'Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "dotnet.exe" -or ($_.Name -eq "python.exe" -and $_.CommandLine -match "diagnostic") } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress'
p=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,text=True,encoding='utf-8',timeout=20)
print(p.stdout,p.stderr)
