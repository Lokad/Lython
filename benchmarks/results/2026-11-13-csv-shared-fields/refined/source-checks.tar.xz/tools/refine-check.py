from pathlib import Path
import ast,subprocess,sys
r=Path(__file__).parent;code=(r/'check.py').read_text(encoding='utf-8').replace("'focused-'+kind","'refined-'+kind");ast.parse(code);(r/'refined-check.py').write_text(code,encoding='utf-8');subprocess.run([sys.executable,'-X','utf8',str(r/'refined-check.py')],check=True)
