from pathlib import Path
import os,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
with(r/'restored-build-stack.log').open('w',encoding='utf-8')as f:
    try:
        done=subprocess.run(['C:/Users/JoannesVermorel/.dotnet/tools/dotnet-stack.exe','report','--process-id','41628'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=20)
        print('Build-stack diagnostic exit',done.returncode,flush=True)
    except subprocess.TimeoutExpired:
        print('Build-stack diagnostic timed out; target not changed.',flush=True)
