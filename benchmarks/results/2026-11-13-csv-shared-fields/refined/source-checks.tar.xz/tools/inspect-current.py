from pathlib import Path
import subprocess

p = Path(__file__).parent
for f in p.glob('refined*'):
    print(f, f.stat().st_size)
    if f.suffix == '.log':
        print(f.read_text(encoding='utf-8', errors='replace')[-2000:])
print(Path('PLAN.md').read_text(encoding='utf-8'))
subprocess.run(['git', 'diff', '--', 'src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs'])
