from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

r = Path(__file__).parent
out = r / 'refined'
out.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
sources = {p: sha(p) for p in baseline['sources']}
changed = [p for p, h in sources.items() if h != baseline['sources'][p]]
assert changed == ['src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs']
for role in ['reference', 'candidate']:
    shutil.copytree(r / 'reference', out / role, copy_function=os.link)
    if role == 'candidate':
        (out / role / 'Lokad.Lython.dll').unlink()
        shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', out / role / 'Lokad.Lython.dll')
shutil.copyfile(out / 'candidate/Lokad.Lython.dll', out / 'candidate-core.dll')
identity = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    description='R308 descriptor-derived final sizing removes persistent parser byte counters/resets; shared immutable long-field backing',
    sources=sources, changed=changed, coreSHA256=sha(out / 'candidate-core.dll'), referenceSHA256=baseline['referenceSHA256'])
assert identity['coreSHA256'] != baseline['coreSHA256']
(out / 'candidate-identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
with tarfile.open(out / 'candidate-sources.tar.xz', 'w:xz') as archive:
    for p in sources: archive.add(p, arcname=p)
code = (r / 'diagnostic.py').read_text(encoding='utf-8')
code = code.replace("r.parent/'bulk-utf16", "r.parent.parent/'bulk-utf16").replace("r.parent/'composed-native", "r.parent.parent/'composed-native")
(out / 'diagnostic.py').write_text(code, encoding='utf-8')
shutil.copyfile(r / 'catalog.json', out / 'catalog.json')
print(identity['coreSHA256'], '572 source inputs frozen; refined117internal/372public CSV pass', flush=True)
