from pathlib import Path
import ast
r=Path(__file__).parent
code=(r.parent/'b663/launch.py').read_text(encoding='utf-8').replace('b663','b664').replace("source/'candidate'","source/'reference'")
code=code.replace("source/'candidate/Lokad.Lython.dll'", "source/'reference/Lokad.Lython.dll'")
code=code.replace("os.link(root/('reference-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')", "os.link(source/'reference/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')")
marker=" assert digest(root/'current-core.dll')"
assert marker in code
at=code.index(marker)
code=code[:at]+" for name in ['representative.json','reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)\n"+code[at:]
ast.parse(code)
(r/'launch.py').write_text(code,encoding='utf-8')
print('Prepared changed-source confirmation; only refined core staged, reference/catalog/aux reused.',flush=True)
