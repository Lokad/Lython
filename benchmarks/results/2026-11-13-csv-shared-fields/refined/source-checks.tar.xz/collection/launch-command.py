from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/csv-shared-refined-b664-20261113', 'unit': 'lython-b664-csv-shared-refined-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/csv-shared-b663-20261113', 'sourceCoreSHA256': '93a6d13483515e82313ef9136ab3b96d5b432218d7b3461f95d79dbf12df417e', 'identity': {'sourceRevision': 'Fully qualified14dd45b7/93a6d134 versus uncommitted277cb5a5 descriptor-derived CSV shared long fields; exact source-pair', 'coreSHA256': {'reference': '93a6d13483515e82313ef9136ab3b96d5b432218d7b3461f95d79dbf12df417e', 'candidate': '277cb5a5dc430b6b4d891a7e53c29f7a1136d84241dfa9f3f44c535640cf7801', 'reference-control': '93a6d13483515e82313ef9136ab3b96d5b432218d7b3461f95d79dbf12df417e', 'candidate-control': '277cb5a5dc430b6b4d891a7e53c29f7a1136d84241dfa9f3f44c535640cf7801'}, 'auxiliaryFiles': {'Azure.Core.dll': '1d6df436afdc73c30d476be938f6513c90ef8fc884a7bae280091a9bed0a5490', 'Azure.Identity.dll': '31574a3d35ffeb0e25a00ebb317937222fe5283b91af608613f2e3bf0f26c50a', 'BenchmarkDotNet.Annotations.dll': '97974c60500f53a3c7d142088b22d815aae7aac729de69f4b497132cc436594f', 'BenchmarkDotNet.dll': '599ded314fe77dbc17318557e787cf660c1fcb0d69be39994ea462ca95745896', 'CommandLine.dll': '8a55501cd1a1590a4bd93a17c6fdd2c01a0ed5bff1aea9036bdc78d98c9a3fad', 'deniszykov.WebSocketListener.dll': 'c86cfb93e32192ae12fb1a132b4ae785a7d2f325e8583c03c99abf8e832d25d6', 'Dia2Lib.dll': '6c4cac68010fe032218efe5e9fcf46eef9f77bfaa5f3bd33f03c5ff77d5a8fac', 'Gee.External.Capstone.dll': '6dfda67784598de9677173b89d0692593935f1a4024d36040c95dea48c1b5965', 'Iced.dll': 'f058c01321b4cdfc9b9151879e88e59571c8d0ba176fbcf95bc936a8f3d073ed', 'Lokad.Lython.Benchmarks.deps.json': 'b47f293f779ce46eefa92c6eb775842efe363be212c35bf7d155d0b89734d450', 'Lokad.Lython.Benchmarks.dll': 'fec79afdb8425f18aa962d5ff9a3e51ae52f519072ea9d9db8ab69a0c52b69a6', 'Lokad.Lython.Benchmarks.runtimeconfig.json': 'c2ecf2430d6785354d9099b35eef9d6ac3d72f2089dc3dc9fd723558265b83d0', 'Lokad.Lython.Utf8Regex.dll': '9f7282ade883f103956efaf7e46182f7705fb7675f1f46963b9c42ae5aae7f94', 'Lokad.Utf8Regex.dll': 'af5fb1e550cf23559bc7e26ef3d895b45e5ef98d57bcf46b414785a6e24cc857', 'Lokad.Utf8Regex.PythonRe.dll': '96e45b20c1db361a9b3b94bd557405b413510801bdb1488ae5b15d6aae7aedfe', 'Microsoft.Bcl.AsyncInterfaces.dll': 'bf58b47923b2f520c766ca905f68a1a65d217c4d828f05db538c41129cacf9d9', 'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f', 'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613', 'Microsoft.Diagnostics.FastSerialization.dll': 'e5bdad179ce97180646f37f357cb7b449f5baaf76f185eb09510eeafc5b773e1', 'Microsoft.Diagnostics.NETCore.Client.dll': 'e2cc9e1f6c97b3c4ee45ebabaa92408eb9b2fc81cb08ceeb342fe48bf79db15f', 'Microsoft.Diagnostics.Runtime.dll': '52d5f113180bb0f70b1a9b10608aef93b187364ac689885d2d3c734102d850a2', 'Microsoft.Diagnostics.Tracing.TraceEvent.dll': '92401392ce1887c3483a3c0085e6cc3656ee39da1be539943096ebabbad6ea21', 'Microsoft.Identity.Client.dll': '5795027e9ae95eececb310a4fed3c502bb368039d186ab0884f64b7792b84717', 'Microsoft.Identity.Client.Extensions.Msal.dll': '07109a2f30df782300077a567ade47cbd0a0502c75cd7c8a62192f7d64bb004e', 'Microsoft.IdentityModel.Abstractions.dll': '24e97b54b6b5c234a124a336757e3116617ac6c30b655cdae74517dc2ecb5746', 'Perfolizer.dll': '4a5508174e2b90a651a29e1de0d2ad88236daaaae01070cd6fc8ca3c36beaa36', 'Pragmastat.dll': '7217e206e47de8a0335f58513019d5805a6e52ca2e8f127e2cc3944f1742bb2e', 'System.ClientModel.dll': 'dec5e22b71a1685c5e6e97cd28b629f0aa6703fb87b6950df28e79fc1804290c', 'System.Memory.Data.dll': '2c1035b0106dbb2de7913d151e06071ed617bb58bbb3d6cd46a2dd0f6a03617b', 'System.Security.Cryptography.ProtectedData.dll': '80566f0839ece5946e66bf9f00d723e59e371ba1341a18e00c7c7a7c49298e1d', 'TraceReloggerLib.dll': '6830c0f1d3f3c17719181e73dd5cfa8ccbb3f3c575329d2120576545103467b5'}, 'catalogSHA256': '154b8903f4f77b8c7b57dc6436e67f32ec1f28df1a0d2e252903f941883fe9b1', 'imageSourceArchiveSHA256': 'eab21a1282fa9c09bb43e126e23cbe236662cc5350c8f73760e737e3df54ddf7', 'sourceIdentitySHA256': '4511b19203e40e7ff5cf47eb2d23393a73c41026c9d0b781302b34fe4b9f82d5', 'productionSourceArchiveSHA256': '16b7e7143fa1bd4c72d3d4d2b3e5a02dca6c73403fd6664a840301af1ae8c893', 'purpose': 'Text-rich invoice warm/fresh, original invoice/captured controls; source-pair only', 'referenceSourceIdentitySHA256': '330d49bd89176eaeacff0c75d5f1ebf4bec64fd27da54ecb530de84676e07728'}, 'retire': [{'path': 'csv-shared-b663-20261113/candidate/Lokad.Lython.dll', 'sha256': '21d0be4f052508186f6b0eec6fad7858737e1317ecefe0cb1867c3350a81bccd', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-csv-shared-fields/initial/source-checks.tar.xz', 'member': 'candidate-core.dll', 'bytes': 5677568, 'sha256': '21d0be4f052508186f6b0eec6fad7858737e1317ecefe0cb1867c3350a81bccd'}, 'device': 66305, 'inode': 845821, 'links': 2, 'bytes': 5677568, 'allocatedBytes': 5681152, 'allAliasesInBase': True, 'aliases': ['csv-shared-b663-20261113/current-core.dll', 'csv-shared-b663-20261113/candidate/Lokad.Lython.dll']}], 'payloadBytes': 1922642, 'payloadSHA256': 'bc214b60802583b5200c6bd55a3d0cb1cbd3bdf385de38c241c85dc820a1e2dc', 'unpackedBytes': 5768862}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 assert digest(source/'reference/Lokad.Lython.dll')==config['sourceCoreSHA256']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'reference'/name)==sha
 before=shutil.disk_usage(base).free
 assert before+sum(p['allocatedBytes']for p in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 # Retire only exact, superseded/unqualified cores whose bytes are already
 # independently verified in tracked canonical archives; qualified images stay.
 for row in config['retire']:
  actual=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    p=Path(folder)/name;s=p.lstat()
    if(s.st_dev,s.st_ino)==(row['device'],row['inode']):actual.append(str(p.relative_to(base)))
  assert sorted(actual)==sorted(row['aliases'])and len(actual)==row['links']==2
  for p in [base/a for a in row['aliases']]:
   s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links'],row['bytes'])and digest(p)==row['sha256']==row['canonical']['sha256']
 for row in config['retire']:
  for i,a in enumerate(row['aliases']):
   p=base/a;s=p.lstat();assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links']-i,row['bytes'])and digest(p)==row['sha256'];p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for name in ['representative.json','reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)
 assert digest(root/'current-core.dll')==config['identity']['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  shutil.copytree(source/'reference',root/role,copy_function=os.link,ignore=shutil.ignore_patterns('Lokad.Lython.dll'))
  os.link(source/'reference/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(root/role/name)==sha
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=config['retire']),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b664-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
