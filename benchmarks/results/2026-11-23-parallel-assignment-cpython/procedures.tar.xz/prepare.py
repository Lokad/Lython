from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'closed-defaults-cpython-20261123/prepare.py'
source = template.read_text(encoding='utf-8')
start = source.index("tracked = 'benchmarks/results/")
stop = source.index("files = proof['imageFiles']['candidate']", start)
source = source[:start] + """tracked = 'benchmarks/results/2026-11-23-parallel-assignment-operands/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
proof = json.loads(pushed('identity.json'))
prefix = ''
if proof['retainedRevision'] is None:
    proof = json.loads(pushed('refined-identity.json'))
    prefix = 'refined-'
    donor = donor / 'refinement'
original = json.loads(pushed(prefix + 'terminal-status.json'))['receipt']
assert original['complete'] and original['allWorkersJoined'] and original['archivedAndVerifiedUnderLease']
assert sha(pushed(prefix + 'observations.tar.xz')) == original['archiveSHA256']
head = git('rev-parse', 'origin/master').decode().strip()
retained = proof['retainedRevision']
assert not git('diff', '--name-only', head, retained, '--', 'src')
assert not git('diff', '--name-only', retained, proof['candidate'], '--', 'src')
""" + source[stop:]
start = source.index("catalog = read(old / 'representative.json')")
stop = source.index("dotnet = Path.home()", start)
source = source[:start] + """catalog = read(donor / 'comparison/representative.json')
explicit = 'scripts.csv-meter-report.explicit-float'
typed = 'scripts.csv-meter-report.typed-ascii'
names = {explicit, typed}
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in names]
assert {row['id'] for row in catalog['cases']} == names
catalog_path = quiet / 'representative.json'
write(catalog_path, catalog)
write(quiet / 'jobs.json', [[explicit, 'warm'], [explicit, 'compile-run'], [explicit, 'compile'], [typed, 'warm']])

""" + source[stop:]
for old, new in (
    ("donor = lab.parent / 'direct-closed-defaults-20261123'", "donor = lab.parent / 'parallel-assignment-operands-20261123'"),
    ("verified['caseCount'] == 4", "verified['caseCount'] == 2"),
    ("root = 'closed-defaults-cpython-b1516-20261123'", "root = 'parallel-assignment-cpython-b1518-resolved-20261123'"),
    ("'len(jobs) == 7'", "'len(jobs) == 4'"),
    ("'<368,'", "'<220,'"),
    ("'lython-b1516-fixtures'", "'lython-b1518-fixtures'"),
    ("'CPython checkpoint after direct owner transfer'", "'CPython checkpoint after direct assignment lowering'"),
    ("'len(raw[\"jobs\"])==7'", "'len(raw[\"jobs\"])==4'"),
    ("'receipt[\"warmJobs\"]==7'", "'receipt[\"warmJobs\"]==4'"),
    ("original='direct-closed-defaults-b1515-20261123'", "original=('parallel-assignment-refined-b1517-20261123' if prefix else 'parallel-assignment-b1517-20261123')"),
    ("reference='retained-call-cpython-b1510-20261123'", "reference='direct-closed-defaults-b1515-20261123'"),

    ("adapt(donor / 'repeat/quiet.py'", "adapt(lab.parent / 'direct-closed-defaults-20261123/repeat/quiet.py'"),
    ("lython-b1516-closed-defaults-cpython-20261123", "lython-b1518-parallel-assignment-cpython-20261123"),
    ("'.+b1516-'", "'.+b1518-'"),
    ("'lython-b1516-stage-'", "'lython-b1518-stage-'"),
    ("'Seven bounded lanes'", "'Four bounded lanes'"),
    ("('RuntimeMaxSec=275', 'RuntimeMaxSec=410'), ('seconds=225', 'seconds=370')",
     "('106 * 1024 * 1024', '89 * 1024 * 1024'), ('A 106 MiB', 'An 89 MiB'), ('RuntimeMaxSec=275', 'RuntimeMaxSec=260'), ('seconds=225', 'seconds=210')"),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'))

