from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / 'current-mixed-cpython-b1978-20261128'
regex = lab.parent / 'current-regex-cpython-b1985-20261128/comparison/quiet'
matched = lab.parent / 'generator-only-dispatch-b1993-20261128/comparison'
donor = matched / 'quiet'
quiet = lab / 'comparison/quiet'
stage = 'script-landed-runtime-cpython-b1994-20261128'
minimum_after_stage = 3_450_000


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def manifest(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def git(*arguments):
    return check_output(['git', *arguments], cwd=repo)


revision = git('rev-parse', 'HEAD').decode().strip()
assert revision.startswith('8633debf8') and not git('status', '--porcelain')
identity = read(donor / 'identity.json')
assert sha256(git('diff', '--binary', identity['sourceRevision'], revision, '--', 'src', 'tests')).hexdigest() == identity['sourcePatchSHA256']
status = read(donor / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert receipt['archiveSHA256'] == digest(donor / 'observations.tar.xz')
image = identity['imageFiles']['candidate']
assert len(image) == 32 and manifest(matched / 'candidate') == image

quiet.mkdir(parents=True)
frozen = quiet / 'local-image'
copytree(matched / 'candidate', frozen)
assert manifest(frozen) == image
assert all(not p.samefile(matched / 'candidate' / p.name) for p in frozen.iterdir())
prior = template / 'comparison/quiet'
catalog = read(prior / 'representative.json')
regex_catalog = read(regex / 'representative.json')
assert {k:v for k,v in catalog.items() if k != 'cases'} == {k:v for k,v in regex_catalog.items() if k != 'cases'}
cases = {row['id']: row for row in catalog['cases'] + regex_catalog['cases']}
jobs = [
    ['diagnostic.shipment-starmap-iterable-rows', 'warm-async'],
    ['scripts.regex-log-search.compiled', 'warm'],
    ['scripts.regex-log-search.module', 'warm'],
    ['scripts.config-edit.small', 'compile-run'],
]
catalog['cases'] = [cases[case] for case, _ in jobs]
write(quiet / 'representative.json', catalog)
write(quiet / 'jobs.json', jobs)
for name in ('run.sh', 'collect.py', 'cpython-worker.py'):
    copy2(prior / name, quiet / name)
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
write(quiet / 'identity.json', dict(sourceRevision=revision, productionHead=revision,
    purpose='Refresh staged CSV, regex log search and embedded configuration at the landed runtime.',
    imageFiles={'candidate': image}, coreSHA256={role: image['Lokad.Lython.dll'] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: checksum for name, checksum in image.items() if name != 'Lokad.Lython.dll'},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=identity['expectedCPythonSHA256'], cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'], measuredCorePatchSHA256=identity['sourcePatchSHA256']))

files = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json', 'cpython-worker.py', 'run.sh', 'collect.py')}
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in files.items())
expanded = sum(path.stat().st_size for path in files.values())
write(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'upload.json')['root'], donorFiles=image,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload),
    files={name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in files.items()},
    expandedBytes=expanded, minimumAfterStageBytes=minimum_after_stage, caseCount=4))
for name, replacements in (
    ('quiet-vm.py', [('lython-b1978-mixed-cpython', 'lython-b1994-landed-runtime-cpython'), ('+400000', '+250000')]),
    ('verify.sh', [(template.name, lab.name)]),
    ('summarize.py', [('e78a95b1bc5c2a12fcd373565298c965d16129f3', revision), ('5*1024*1024', str(minimum_after_stage))]),
):
    script = (template / name).read_text(encoding='utf-8')
    for old, new in replacements:
        assert script.count(old) == 1, (name, old)
        script = script.replace(old, new)
    (lab / name).write_text(script, encoding='utf-8', newline='\n')
print(revision, len(jobs), 'lanes and 32 donor files. Preflight free bytes required:', expanded + minimum_after_stage + 250_000)
