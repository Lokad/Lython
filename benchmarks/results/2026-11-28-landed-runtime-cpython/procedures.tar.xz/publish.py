from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
out = repo / 'benchmarks/results/2026-11-28-landed-runtime-cpython'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


identity = read(quiet / 'identity.json')
stage = read(quiet / 'stage-custody.json')
summary = read(quiet / 'summary.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
frozen = identity['imageFiles']['candidate']
assert identity['sourceRevision'] == summary['source'] == '8633debf8ce26fdc51e9617551c38cb5469b0a03'
assert len(frozen) == 32
assert {path.name: digest(path) for path in (quiet / 'local-image').iterdir()} == frozen
assert summary['timedBatches'] == 112 and summary['passedQuietCheck']
assert len(summary['rows']) == 4 and summary['rows'][-1]['lane'] == 'compile-run'
assert stage['reused'] == {'donor': 32} and stage['streamed']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['warmJobs'] == 4 and receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
for name in ('candidate-local-verify.json', 'candidate-remote-verify.json'):
    proof = read(quiet / name)
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == frozen['Lokad.Lython.dll']
    assert proof['launched']['adapter']['sha256'] == frozen['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']

procedures = {name: lab / name for name in ('prepare.py', 'quiet-vm.py', 'verify.sh',
    'summarize.py', 'publish.py')}
procedures.update({name: quiet / name for name in ('launch.log', 'upload.json', 'stage-custody.json',
    'candidate-local-verify.json', 'candidate-remote-verify.json', 'exit-code.txt', 'archive-receipt.json')})
assert all(path.is_file() for path in procedures.values())
out.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    copy2(quiet / name, out / name)
    assert digest(out / name) == digest(quiet / name)

with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified the full worker image, 112 batches, both golden receipts and archived procedures.')
