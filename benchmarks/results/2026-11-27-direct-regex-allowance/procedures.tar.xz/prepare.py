from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess


root = Path(__file__).resolve().parent
repo = root.parents[3]
source = root.parent / 'first-buffered-positional-pull-20261127/comparison'
regex_source = root.parent / 'pattern-one-shot-20261127/comparison/quiet'
pair = root / 'comparison'
pair.mkdir()
read = lambda path: json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def image(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def diff(*args):
    return subprocess.check_output(['git', 'diff', '--binary', *args], cwd=repo)


original = read(source / 'identity.json')
regex = read(regex_source / 'identity.json')
assert digest(regex_source / 'representative.json') == regex['catalogs']['representative.json']['sha256']
core = 'Lokad.Lython.dll'
adapter = 'Lokad.Lython.Utf8Regex.dll'
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert base.startswith('683e4eb2a')
assert sha256(diff(original['sourceRevision'], base, '--', 'src')).hexdigest() == original['sourcePatchSHA256']
patch = diff(base, '--', 'src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs')
assert b'using var allowance = new RegexAllowance(memoryOwner);' in patch
assert not diff(base, '--', 'src/Lokad.Lython')
(root / 'candidate.patch').write_bytes(patch)
(root / 'regression.patch').write_bytes(diff(base, '--', 'tests'))
assert image(source / 'candidate') == original['imageFiles']['candidate']
for role in ('reference', 'candidate'):
    copytree(source / 'candidate', pair / role)
bins = repo / 'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
fresh = bins / adapter
assert digest(fresh) == digest(repo / 'src/Lokad.Lython.Utf8Regex/bin/Release/net11.0' / adapter)
copyfile(fresh, pair / 'candidate' / adapter)
images = {role: image(pair / role) for role in ('reference', 'candidate')}
assert [name for name, before in images['reference'].items() if images['candidate'][name] != before] == [adapter]
for name in regex['signedPackageSHA256']:
    assert digest(bins / name) == images['reference'][name] == regex['imageFiles']['candidate'][name]
copyfile(source / 'cpython-worker.py', pair / 'cpython-worker.py')
assert digest(pair / 'cpython-worker.py') == original['cpythonWorkerSHA256'] == regex['cpythonWorkerSHA256']

catalog = read(regex_source / 'representative.json')
compiled = 'scripts.regex-log-search.compiled'
module = 'scripts.regex-log-search.module'
cursor = 'scripts.regex.cursor-records'
invoice = 'scripts.csv-invoice.method-policy.quoted-control'
jobs = [[compiled, 'warm'], [cursor, 'warm-async'], [module, 'warm-async'], [invoice, 'warm']]
cases = {case['id']: case for case in catalog['cases']}
catalog['cases'] = [cases[case] for case, _ in jobs]
write(pair / 'representative.json', catalog)
write(pair / 'jobs.json', {'warm': jobs})
identity = dict(sourceRevision=base, productionReference=base,
                sourcePatchSHA256=digest(root / 'candidate.patch'), imageFiles=images,
                coreSHA256={role+suffix: hashes[core] for role, hashes in images.items()
                            for suffix in ('', '-control')},
                cpythonWorkerSHA256=original['cpythonWorkerSHA256'], cpythonPath=original['cpythonPath'],
                expectedCPythonSHA256=original['expectedCPythonSHA256'],
                signedPackageSHA256=regex['signedPackageSHA256'],
                purpose='Remove the adapter child scope from independent one-shot matching calls.')
identity['catalogs'] = {name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')}
write(pair / 'identity.json', identity)
collector = (source / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('lython-b1883-first-argument-pull-', 'lython-b1884-direct-regex-allowance-')
compile(collector, 'collect.py', 'exec')
(pair / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
copyfile(source / 'run.sh', pair / 'run.sh')
assert b'\r' not in (pair / 'run.sh').read_bytes()

allocation = root / 'allocation'
allocation.mkdir()
witness = root.parent / 'pattern-one-shot-20261127/local/candidate-allocated'
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for path in witness.glob('ValidatedAllocation*'):
        copyfile(path, folder / path.name)
    assert (folder / 'ValidatedAllocation.dll').is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ('sync', 'async'):
    for case in catalog['cases']:
        case['runAsync'] = mode == 'async'
    selection = allocation / f'{mode}-catalog.json'
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f'{role}-{mode}.json'
        subprocess.run([sdk / 'dotnet.exe', folder / 'ValidatedAllocation.dll', folder, selection, report],
                       env=env, check=True, timeout=100)
        comparisons.append(read(report)['rows'])
    for before, after in zip(*comparisons, strict=True):
        assert before['id'] == after['id']
        assert before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row = dict(case=before['id'], mode=mode,
                   clr=[median(r['allocatedBytesPerInvocation']) for r in (before, after)],
                   peak=[r['peakExecutionMemoryBytes'] for r in (before, after)],
                   compiled=[r['compiledReservedBytes'] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / 'summary.json', rows)
