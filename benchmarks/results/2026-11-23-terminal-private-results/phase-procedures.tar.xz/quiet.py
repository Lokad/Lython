from pathlib import Path
import datetime
import hashlib
import io
import json
import shlex
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[4]
host="lokad@20.166.121.73"
root="/home/lokad/lython-bench-checks/terminal-private-results-b1471-confirm-20261123"
unit="lython-b1471-terminal-private-results-confirm-20261123"
previous=lab.parent/"comparison/quiet"
state=json.loads((previous/"terminal-status.json").read_text(encoding="utf-8"))
previous_archive=state["receipt"]["archiveSHA256"]
assert state["exitCode"]=="0" and state["receipt"]["complete"]
key=Path.home()/".ssh/id_lython-bench.pem"
options=["-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=14"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*options,host]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*options]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc)

if sys.argv[1]=="launch":
    identity=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
    assert sha(previous/"observations.tar.xz")==previous_archive
    assert sha(lab/"run.sh")==sha(previous/"run.sh") and b"\r" not in (lab/"run.sh").read_bytes()
    catalog=lab/"representative.json"
    files=("catalog.json","identity.json","collect.py","run.sh","jobs.json")
    for role in ("candidate","reference"):
        proof=json.loads((lab/(role+"-verify.json")).read_text(encoding="utf-8"))
        assert proof["state"]=="Completed" and proof["caseCount"]==6 and proof["catalogSha256"]==sha(catalog)
        assert proof["launched"]["library"]["sha256"]==identity["coreSHA256"][role]
    for role in ("candidate","reference"):
        image_files = identity["imageFiles"][role]
        assert len(image_files) == 32 and all(sha(lab.parent/role/name) == digest for name,digest in image_files.items())
    archive=io.BytesIO()
    with tarfile.open(fileobj=archive,mode="w:gz") as package:
        for name in files:
            package.add(lab/(catalog.name if name=="catalog.json" else name),
                        arcname=catalog.name if name=="catalog.json" else name,recursive=False)
    data=archive.getvalue()
    (lab/"payload.tgz").write_bytes(data)
    code=f"""
from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
root=Path({root!r})
prior=root.parent/'terminal-private-results-b1470-20261123'
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert digest(prior/'observations.tar.xz')=={previous_archive!r}
data=sys.stdin.buffer.read()
assert hashlib.sha256(data).hexdigest()=={hashlib.sha256(data).hexdigest()!r}
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert shutil.disk_usage(root.parent).free>=128*1024*1024
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data)) as package:
  assert set(package.getnames())=={{'representative.json','identity.json','collect.py','run.sh','jobs.json'}}
  package.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 for role,directory in [('reference','ordered-locals-snapshots-b1468-20261123'),('candidate','terminal-private-results-b1470-20261123')]:
  image=root.parent/directory/'candidate'
  assert all(digest(image/f)==expected for f,expected in identity['imageFiles'][role].items())
 assert digest(prior/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 os.link(prior/'cpython-worker.py',root/'cpython-worker.py')
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=290','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    result=subprocess.run(ssh+["python3 -c "+shlex.quote(code)],input=data,capture_output=True,timeout=25)
    (lab/"launch.log").write_bytes(result.stdout+result.stderr)
    print((result.stdout+result.stderr).decode(),end="")
    result.check_returncode()
    (lab/"observe-not-before").write_text((now()+datetime.timedelta(seconds=247)).isoformat(),encoding="utf-8")
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((lab/"observe-not-before").read_text(encoding="utf-8"))
    code=f"""
from pathlib import Path
import fcntl,json,subprocess
root=Path({root!r})
service=subprocess.run(['systemctl','show','{unit}.service','--property=ActiveState,Result,ExecMainStatus,MainPID'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service: print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  read=lambda n: (root/n).read_text().strip() if (root/n).exists() else None
  print(json.dumps(dict(live=False,service=service,exitCode=read('exit-code.txt'),receipt=json.loads(read('archive-receipt.json') or 'null'),
        fixtures=(root/'guest-fixtures').exists(),
        journal=subprocess.run(['journalctl','-u','{unit}.service','-n','25','--no-pager'],capture_output=True,text=True).stdout)))
"""
    output=subprocess.check_output(ssh+["python3 -c "+shlex.quote(code)],encoding="utf-8",timeout=25)
    report=json.loads(output)
    (lab/("status-"+now().strftime("%H%M%S")+".json")).write_text(output,encoding="utf-8")
    print(output,end="")
    if not report["live"] and report["receipt"] is not None:
        target=lab/"observations.tar.xz"
        subprocess.run(scp+[host+":"+root+"/observations.tar.xz",target],check=True,timeout=35)
        assert sha(target)==report["receipt"]["archiveSHA256"]
        (lab/"terminal-status.json").write_text(output,encoding="utf-8")
        assert report["exitCode"]=="0" and report["receipt"]["complete"] and not report["fixtures"]
