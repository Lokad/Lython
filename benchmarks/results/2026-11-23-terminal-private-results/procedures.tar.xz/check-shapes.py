from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(r".git/agent-notes/review-20261031/terminal-private-results-20261123").resolve()
notes=lab.parent
source=notes/"native-direct-integer-return-refined-20261122/inspect/bin/Release/net11.0"
manifest = json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))
roles={}
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
for role in ("reference","candidate"):
    image=lab/role
    for name,digest in manifest["imageFiles"][role].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==digest
    for path in source.glob("Inspect.*"):
        shutil.copyfile(path,image/path.name)
    output=lab/(role+"-executable.json")
    subprocess.run([dotnet,image/"Inspect.dll",lab/"inspection-catalog.json",output],
        env=env,check=True,timeout=45)
    result=json.loads(output.read_text(encoding="utf-8"))
    assert result["coreSHA256"] == manifest["coreSHA256"][role]
    roles[role]=result["rows"]
changes=[]
identical=0
for reference,candidate in zip(roles["reference"],roles["candidate"],strict=True):
    assert reference["id"]==candidate["id"]
    for left,right in zip(reference["codes"],candidate["codes"],strict=True):
        assert left["name"]==right["name"]
        fields=[key for key in left if left[key]!=right[key]]
        if fields:
            changes.append(dict(script=reference["id"],name=left["name"],fields=fields))
        else:
            identical+=1
report = {"scripts":len(roles["candidate"]),"identicalCodeObjects":identical,
    "changedCodeObjects":changes,"coreHashes":manifest["coreSHA256"]}
(lab/"executable-parity.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(identical,"identical code objects", len(changes),"changed")
for change in changes:
    print(change)
