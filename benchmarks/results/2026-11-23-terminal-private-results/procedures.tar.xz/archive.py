from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / "comparison"
quiet = comparison / "quiet"
dest = repo / "benchmarks/results/2026-11-23-terminal-private-results"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = read(comparison / "identity.json")
terminal = read(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 168
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    for name, digest in files.items():
        assert sha((lab / role / name).read_bytes()) == digest
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
retained = not subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", "src", "tests"], cwd=repo)
source = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"],
    identity["candidate"], "--", "src", "tests"], cwd=repo)
(comparison / "production.patch").write_bytes(source)
(dest / "identity.json").write_text(json.dumps(dict(identity, retainedRevision=head if retained else None,
    productionPatchSHA256=sha(source)), indent=2) + "\n", encoding="utf-8", newline="\n")
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(quiet / file, dest / file)
for file in ("compile-allocations.json", "allocation-summary-six.json", "executable-parity.json"):
    shutil.copyfile(lab / file, dest / file)
(dest / "candidate-core.dll.gz").write_bytes(gzip.compress(core, mtime=0))
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for file in ("archive.py","freeze.py","stage.py","quiet.py","summarize.py","compile-allocations.py","allocations.py",
            "test-platform.py","check-shapes.py","inspection-catalog.json","initial-inspection-catalog.json",
            "initial-inspection-failure.json","executable-inspection.log","semantic-golden.py","semantic-cpython.log",
            "reference-executable.json","candidate-executable.json","windows-white.log","windows-public.log",
            "ubuntu-white.log","ubuntu-public.log","regex-focused.log","reference-allocation-six.json",
            "candidate-allocation-six.json","comparison/reference-verify.json","comparison/candidate-verify.json",
            "comparison/production.patch","comparison/quiet/launch.log","comparison/quiet/observe-not-before"):
        archive.add(lab / file, arcname=file, recursive=False)
assert sha(gzip.decompress((dest / "candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest, "retained" if retained else "private")
