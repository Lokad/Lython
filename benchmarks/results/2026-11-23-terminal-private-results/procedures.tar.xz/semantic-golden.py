def private_factory(value):
    def child(arg=value): return arg
    return child
def recursive_factory(value):
    def child(depth=1):
        if depth: return child(depth - 1)
        return value
    return child
def protected_factory(value, observed):
    try:
        def child(arg=value): return arg
        return child
    finally:
        observed.append(locals()['child'])
value = []
private = private_factory(value)
recursive = recursive_factory(value)
observed = []
protected = protected_factory(value, observed)
assert private() is value and recursive() is value
assert protected() is value and observed[0] is protected
print('ok')
