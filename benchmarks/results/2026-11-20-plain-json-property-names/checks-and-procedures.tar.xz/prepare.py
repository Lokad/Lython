from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
root = notes.parents[2]
trial = root / ".git/agent-worktrees/private-json-property-layout"
donor = notes / "lexical-definition-delivery-cpython"
template = notes / "private-lexical-definition/refined"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def emit(path, content):
    if path.suffix == ".py":
        compile(content, str(path), "exec")
    path.write_text(content, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd)


assert not git("status", "--porcelain", cwd=trial).strip()
assert not git("diff", "--name-only", "46ccc2efa", "HEAD", "--",
               "benchmarks/Lokad.Lython.Benchmarks", "benchmarks/cpython-worker.py", cwd=trial).strip()
candidate = git("rev-parse", "HEAD", cwd=trial).decode().strip()
reference = load(donor / "identity.json")
source_config = load(donor / "config.json")
proof = load(donor / "archive-receipt.json")
assert proof["complete"] and proof["archivedAndVerifiedUnderLease"]
assert sha((donor / "observations.tgz").read_bytes()) == proof["archiveSHA256"]
ref_files = reference["imageFiles"]["candidate"]
assert len(ref_files) == 32
assert sha((donor / "representative.json").read_bytes()) == source_config["catalogSHA256"]

def retirement_proof(remote, evidence, archive_directory, core_directory, core_file):
    committed = "bded26620:benchmarks/results/" + evidence + "/"
    archive = git("cat-file", "blob", committed + archive_directory + "observations.tgz")
    receipt = json.loads(git("cat-file", "blob", committed + archive_directory + "archive-receipt.json"))
    canonical_core = core_directory + core_file
    binary = gzip.decompress(git("cat-file", "blob", committed + canonical_core))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert receipt["archiveSHA256"] == sha(archive)
    return dict(archivePath=f"{remote}/observations.tgz", canonicalArchiveSHA256=sha(archive),
                paths=[f"{remote}/candidate/{core}"], bytes=len(binary), links=1,
                sha256=sha(binary), optional=True,
                verifiedCanonicalGitImage=committed.split(":", 1)[1] + canonical_core)


retirements = [
    retirement_proof("private-lexical-definition-refined-b1230-20261120",
                     "2026-11-20-private-lexical-definition", "refinement/", "refinement/", "measured-core.dll.gz"),
    retirement_proof("default-storage-warm-confirmation-b1217-20261120",
                     "2026-11-20-default-operand-storage", "confirmation/", "", "measured-candidate-core.dll.gz"),
]
assert retirements[0]["sha256"] == load(template / "quiet/identity.json")["coreSHA256"]["candidate"]

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
manifest = lab / "representative.json"
catalog_hash = sha(manifest.read_bytes())
worker = donor / "cpython-worker.py"
protocol_hash = reference["cpythonWorkerSHA256"]
assert sha(worker.read_bytes()) == protocol_hash
jobs = [(case["id"], "warm") for case in load(manifest)["cases"]]
images = {}
q.mkdir()
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in ref_files:
        original = (trial / "src/Lokad.Lython/bin/Release/net11.0" / core if role == "candidate" and name == core
                    else donor / "frozen/candidate" / name)
        shutil.copyfile(original, image / name)
    hashes = {name: sha((image / name).read_bytes()) for name in ref_files}
    verification = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", worker, "--out", verification], env=env, check=True, timeout=100)
    result = load(verification)
    assert result["state"] == "Completed" and result["catalogSha256"] == catalog_hash
    for file in (notes / "private-lexical-definition/frozen/candidate").glob("ValidatedAllocation.*"):
        shutil.copyfile(file, image / file.name)
    allocation = lab / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, allocation],
                   env=env, check=True, timeout=120)
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha((image / name).read_bytes()) for name in ref_files} == hashes
    images[role] = hashes
assert images["reference"] == ref_files
assert [name for name in ref_files if images["candidate"][name] != ref_files[name]] == [core]

purpose = "Consume validated literal JSON property names from the existing record layout"
location = "/home/lokad/lython-bench-checks/private-json-property-layout-b1231-20261120"
unit = "lython-b1231-private-json-property-layout-20261120"
identity = dict(sourceRevision=reference["sourceRevision"] + " versus " + candidate,
                purpose=purpose, imageFiles=images, catalogSHA256=catalog_hash, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
old = load(template / "quiet/config.json")
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / "quiet" / name).replace(old["root"], location).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
        content = content.replace("len(jobs)==3", "len(jobs)==4").replace("Branch state ownership; ", "")
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()
(q / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, q / "candidate" / core)
shutil.copyfile(manifest, q / "representative.json")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for name in parts:
        archive.add(q / name, arcname=name)
config = dict(root=location, unit=unit, source=source_config["root"], sourceRole="candidate",
              sourceFiles=ref_files, sourceCatalogSHA256=source_config["catalogSHA256"],
              protocolSHA256=protocol_hash, catalogSHA256=catalog_hash, identity=identity,
              retireGroups=retirements, donorArchiveSHA256=proof["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=sha((q / "payload.tgz").read_bytes()),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
content = read(template / "quiet/remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1230-fixtures", "lython-b1231-fixtures")
assert "+64*1024*1024" in content
emit(q / "remote-launch.py", content)
launch = read(template / "launch-quiet.py").replace("seconds=252", "seconds=325")
launch = launch.replace("Refined lexical capture admission launched; no observation before 252 seconds.",
                        "JSON property-layout comparison launched; no observation before 325 seconds.")
emit(lab / "launch-quiet.py", launch)
summarize = read(template / "summarize-quiet.py").replace("len(raw['jobs'])==3", "len(raw['jobs'])==4")
emit(lab / "summarize-quiet.py", summarize)
print("Both 32-file images and four complete CPython goldens verified.")
