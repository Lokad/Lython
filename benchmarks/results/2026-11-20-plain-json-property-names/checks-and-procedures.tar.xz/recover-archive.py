from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

local = Path(__file__).resolve().parent / "quiet"
config = json.loads((local / "config.json").read_text(encoding="utf-8"))
failed = sorted(local.glob("observation-*.json"))
assert len(failed) == 1
original = json.loads(failed[0].read_text(encoding="utf-8"))
assert original["exitCode"] == "1" and not original["live"]
assert original["receipt"] is None and not original["remainingWorkers"] and not original["remainingTrace"]
key = Path.home() / ".ssh/<benchmark-ssh-key>"
host = "<benchmark-ssh-host>"
options = ["-i", str(key), "-o", "BatchMode=yes", "-o", "ConnectTimeout=15"]
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, subprocess
root = Path(CONFIG["root"])
with (root.parent / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert (root/"exit-code.txt").read_text().strip() == "1"
    assert not (root/"guest-fixtures").exists()
    assert not (root/"observations.tgz").exists()
    assert not (root/"archive-receipt.json").exists()
    assert subprocess.run(["pgrep", "-af", "[d]otnet.* --compare worker|[p]erf record"], capture_output=True).returncode == 1
    payload = root/"confirmation/confirmation.json"
    raw = json.loads(payload.read_bytes())
    assert raw["complete"] and len(raw["jobs"]) == len(EXPECTED)
    assert [job["case"] for job in raw["jobs"]] == EXPECTED
    assert all(job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28 for job in raw["jobs"])
    script = root / "archive-owned.py"
    original = script.read_text()
    assert "len(raw['jobs'])==3 " in original and "jobs=3," in original
    (root/"archive-recovery.json").write_text(json.dumps(dict(
        serviceExitCode=1, archiveAssertion="stale expected job count",
        plannedAndCollectedJobs=len(EXPECTED), retimed=False,
        rawSHA256=hashlib.sha256(payload.read_bytes()).hexdigest(),
        originalArchiverSHA256=hashlib.sha256(script.read_bytes()).hexdigest(),
        originalArchiverRetained=True,
    ), indent=2)+"\n")
    source = original.replace("len(raw['jobs'])==3 ", "len(raw['jobs'])==4 ").replace("jobs=3,", "jobs=4,")
    exec(compile(source, "recover-b1231-archive", "exec"), {"__file__": str(script)})
'''
catalog = json.loads((local / "representative.json").read_text(encoding="utf-8"))
cases = [case["id"] for case in catalog["cases"]]
remote = remote.replace('CONFIG["root"]', repr(config["root"])).replace("EXPECTED", repr(cases))
receipt = subprocess.run(["ssh", *options, host, "python3 -"], input=remote,
                         text=True, encoding="utf-8", capture_output=True)
assert receipt.returncode == 0, receipt.stderr
result = json.loads(receipt.stdout)
assert result["complete"] and result["jobs"] == len(cases) and result["archivedAndVerifiedUnderLease"]
for name in ("archive-receipt.json", "observations.tgz"):
    subprocess.run(["scp", *options, f'{host}:{config["root"]}/{name}', str(local / name)], check=True)
assert hashlib.sha256((local/"observations.tgz").read_bytes()).hexdigest() == result["archiveSHA256"]
out = local / "retrieved"
out.mkdir()
with tarfile.open(local/"observations.tgz") as archive:
    regular = [entry for entry in archive.getmembers() if entry.isfile() or entry.isdir()]
    archive.extractall(out, members=regular, filter="data")
record = json.loads((out/"archive-recovery.json").read_text(encoding="utf-8"))
assert record["rawSHA256"] == hashlib.sha256((out/"confirmation/confirmation.json").read_bytes()).hexdigest()
status = dict(original, receipt=result, evidenceRecovered=True, retimed=False)
(local/"terminal-status.json").write_text(json.dumps(status, indent=2)+"\n", encoding="utf-8", newline="\n")
print(receipt.stdout.strip())
