from pathlib import Path
import hashlib
import json
import tarfile

r = Path(__file__).resolve().parent
first = r / "quiet"
confirmation = r / "control"
q = confirmation / "quiet"
q.mkdir(parents=True)


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


previous = load(first / "config.json")
receipt = load(first / "archive-receipt.json")
assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(first / "observations.tgz")
summary = load(r / "quiet-summary.json")
case = next(row["case"] for row in summary["rows"] if row["case"].startswith("scripts.csv-invoice"))
assert next(row for row in summary["rows"] if row["case"] == case)["elapsedChangePercent"][0] > 0
location = "/home/lokad/lython-bench-checks/private-json-property-layout-control-b1232-20261120"
unit = "lython-b1232-json-property-layout-control-20261120"
identity = previous["identity"]
emit(q / "identity.json", json.dumps(identity, indent=2) + "\n")
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    text = read(first / name).replace(previous["root"], location).replace(previous["unit"], unit)
    if name == "collect.py":
        start = text.index("\njobs = ")
        end = text.index("\nassert len(jobs)", start)
        text = text[:start] + "\njobs = " + repr([(case, "warm")]) + text[end:]
        text = text.replace("len(jobs)==4", "len(jobs)==1")
    if name in ("archive-owned.py", "retrieve.py"):
        text = text.replace("==3", "==1").replace("jobs=3,", "jobs=1,")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = q / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(q / name, arcname=name)
config = dict(previous, root=location, unit=unit, source=previous["root"], sourceRole="reference",
              sourceCatalogSHA256=previous["catalogSHA256"], retireGroups=[], donorArchiveSHA256=receipt["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
emit(q / "config.json", json.dumps(config, indent=2) + "\n")
text = read(first / "remote-launch.py")
start = text.index("\nc=") + 1
end = text.index("\nb=Path(", start)
text = text[:start] + "c=" + repr(config) + text[end:]
text = text.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
text = text.replace("lython-b1231-fixtures", "lython-b1232-fixtures")
emit(q / "remote-launch.py", text)
emit(confirmation / "launch-quiet.py", read(r / "launch-quiet.py").replace("seconds=325", "seconds=94"))
emit(confirmation / "summarize-quiet.py", read(r / "summarize-quiet.py").replace("len(raw['jobs'])==4", "len(raw['jobs'])==1"))
print("One invoice control using both exact B1231 images and the original catalog.")
