from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "external"
out = repo / "benchmarks/results/2026-11-25-retained-workspace-cpython"
verify = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
identity = read(quiet / "identity.json")
terminal = read(quiet / "terminal-status.json")
summary = read(quiet / "summary.json")
assert summary["source"] == identity["productionSource"] == identity["sourceRevision"]
assert summary["timedBatches"] == 308 and len(summary["rows"]) == 11
assert terminal["exitCode"] == "0" and not terminal["live"] and not terminal["fixtures"]
assert verify(quiet / "observations.tar.xz") == terminal["receipt"]["archiveSHA256"]
assert {p.name: verify(p) for p in (lab / "candidate").iterdir()} == identity["imageFiles"]["candidate"]
out.mkdir(exist_ok=True)
for name in ("identity.json", "terminal-status.json", "summary.json", "observations.tar.xz"):
    shutil.copyfile(quiet / name, out / name)
files = [
    "prepare.py", "quiet.py", "archive.py", "verified-raw-replicas.json",
    *("external/" + name for name in (
        "candidate-verify.json", "collect.py", "identity.json", "jobs.json", "launch.log",
        "observe-not-before", "representative.json", "run.sh", "storage-custody.json",
        "summarize.py", "upload.json",
    )),
]
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in files:
        path = lab / name
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert archive.getnames() == files
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest() == verify(lab / name)
               for name in files)
assert verify(out / "observations.tar.xz") == terminal["receipt"]["archiveSHA256"]
print("Archived 308 verified measurements, identity and procedures.")
