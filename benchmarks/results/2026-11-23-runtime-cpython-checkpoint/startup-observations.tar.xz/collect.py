"""Run the existing fresh-process comparison on a verified checkpoint image."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

run = Path(__file__).resolve().parent
checkpoint = run.parent
identity = json.loads((checkpoint / "identity.json").read_text())
sdk = Path("/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148")
dotnet = sdk / "dotnet"
python = Path("/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13")
protocol = checkpoint / "cpython-worker.py"
image = checkpoint / "candidate"
assembly = image / "Lokad.Lython.Benchmarks.dll"
fixtures = run / "guest-fixtures"
environment = dict(os.environ, DOTNET_ROOT=str(sdk), TMPDIR=str(fixtures))
cases = json.loads((run / "catalog.json").read_text())
assert len(cases["cases"]) == 3

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_image():
    assert all(digest(image / name) == value for name, value in identity["imageFiles"]["candidate"].items())
    assert digest(protocol) == identity["cpythonWorkerSHA256"]
    assert digest(python) == identity["expectedCPythonSHA256"]

def quiet(stage):
    receipt = run / f"machine-{stage}.json"
    subprocess.run([dotnet, assembly, "--compare", "check-machine", "--out", receipt],
        env=environment, timeout=25, check=True)
    assert json.loads(receipt.read_text())["gate"]["quiet"]

def stop(*_):
    raise InterruptedError("Fresh-process collection interrupted")

signal.signal(signal.SIGTERM, stop)

with (checkpoint.parent / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert json.loads((checkpoint / "archive-receipt.json").read_text())["complete"]
    assert not any(k.startswith(("DOTNET_", "COMPlus_")) and k != "DOTNET_ROOT" for k in os.environ)
    verify_image()
    fixtures.mkdir()
    subprocess.run(["sudo", "-n", "mount", "-t", "tmpfs", "-o", "size=16m,mode=0700,uid=lokad,gid=lokad",
        "lython-b1451-startup-fixtures", fixtures], check=True)
    try:
        time.sleep(3)
        quiet("before")
        for round_index in range(7):
            order = round_index % len(cases["cases"])
            manifest = dict(cases, cases=cases["cases"][order:] + cases["cases"][:order])
            catalog = run / f"catalog-{round_index}.json"
            catalog.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            receipt = run / f"fresh-{round_index}.json"
            subprocess.run([dotnet, assembly, "--compare", "smoke-fresh", "--catalog", catalog,
                "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
                env=environment, timeout=30, check=True)
            result = json.loads(receipt.read_text())
            assert result["state"] == "Completed" and result["caseCount"] == 3 and len(result["rows"]) == 6
            assert result["launched"]["python"]["sha256"] == identity["expectedCPythonSHA256"]
            assert result["launched"]["library"]["sha256"] == identity["coreSHA256"]["candidate"]
            assert result["catalogSha256"] == digest(catalog)
        time.sleep(3)
        quiet("after")
        verify_image()
        assert not list(fixtures.iterdir())
    finally:
        subprocess.run(["sudo", "-n", "umount", fixtures], check=True)
        fixtures.rmdir()
    archive = run / "observations.tar.xz"
    import tarfile
    with tarfile.open(archive, "w:xz") as target:
        for entry in sorted(run.iterdir()):
            if entry.is_file() and entry != archive and entry.name != "run.sh":
                target.add(entry, arcname=entry.name)
        for directory in sorted(run.glob("fresh-*.json.inputs-*")):
            target.add(directory, arcname=directory.name)
    with tarfile.open(archive) as frozen:
        assert all(hashlib.sha256(frozen.extractfile(entry).read()).hexdigest() == digest(run / entry.name)
            for entry in frozen.getmembers() if entry.isfile())
    (run / "archive-receipt.json").write_text(json.dumps(dict(
        complete=True, repeats=7, jobs=42, quietBeforeAndAfter=True,
        ownedGuestFixturesReleased=True, archiveSHA256=digest(archive),
    ), indent=2) + "\n", encoding="utf-8")
