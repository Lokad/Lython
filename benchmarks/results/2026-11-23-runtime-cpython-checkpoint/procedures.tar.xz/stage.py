from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"cpython-branch-checkpoint-20261123/comparison"
donor=lab.parent/"reuse-private-word-admission-20261123/comparison"
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
assert not (quiet/"launch.log").exists()
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def get(path,name):return git("show",f"origin/master:benchmarks/results/{path}/{name}")
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
def archive(p):
    receipt=json.loads(get(p,"archive-receipt.json"))
    assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(get(p,"observations.tgz"))==receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

accepted="2026-11-23-reusable-private-word-admission"
source=json.loads(get(accepted,"source.json"))
assert source["outcome"]=="Retained"
retained=source["retainedRevision"]
assert not git("diff","--name-only",retained,"HEAD","--","src","tests")
prepared=lab/retained[:9]
proof=read(prepared/"verify.json")
catalog=quiet/"representative.json"
shutil.copyfile(prepared/"representative.json",catalog)
files=source["imageFiles"]["candidate"]
assert len(files)==32 and {n:h(donor/"frozen-candidate"/n)for n in files}==files
assert proof["state"]=="Completed" and proof["caseCount"]==8 and proof["catalogSha256"]==h(catalog)
assert proof["launched"]["library"]["sha256"]==files[core]
prev=read(prior/"quiet/config.json")
old=read(prior/"quiet/retrieved/confirmation/confirmation.json")
assert old["complete"] and len(old["jobs"])==10
python,={meta["executableSha256"] for j in old["jobs"] for name,meta in j["identities"].items() if name.startswith("CPython")}
assert python==prev["identity"]["expectedCPythonSHA256"]
branch="compiler.generated-read-only-branches"
sparse="scripts.config-generated-guards.medium.bad-0.sparse-lexical"
factory="scripts.annotated-rule-closures.nested-factories.postponed"
jobs=[
  (factory,"warm"),(branch,"compile"),("scripts.csv-meter-report.typed-ascii","warm"),
  ("diagnostic.text-summary.nonlocal-computed-width.large","warm"),(sparse,"compile-run"),
  ("scripts.csv-invoice.method-policy.quoted-control","warm"),(factory,"compile-run"),
  ("scripts.json-lines-shipment.expanded-options.large","warm"),
]
assert {case for case,_ in jobs} <= {c["id"] for c in read(catalog)["cases"]}
save(comparison/"jobs.json",jobs)
root="/home/lokad/lython-bench-checks/runtime-checkpoint-cpython-b1451-20261123"
unit="lython-b1451-runtime-checkpoint-cpython-20261123"
identity={**prev["identity"],"sourceRevision":retained,"candidate":retained,
    "purpose":"Refresh representative CPython comparison after borrowing native CSV windows and reusing private word admission.",
    "imageFiles":{"candidate":files},"coreSHA256":{role:files[core]for role in ("candidate","candidate-control")},
    "auxiliaryFiles":{n:x for n,x in files.items()if n!=core},
    "catalogs":{"representative.json":{"sha256":h(catalog)}},
    "B1443CatalogSHA256":prev["identity"]["catalogs"]["representative.json"]["sha256"],
    "expectedCPythonSHA256":python}
save(quiet/"identity.json",identity)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(prior/"quiet"/name).read_text(encoding="utf-8").replace(prev["root"],root).replace(prev["unit"],unit).replace("B1443","B1451")
    if name=="collect.py":
        a,b=s.index("    for case_id,lane in ["),s.index("        assert time.monotonic()-started<595")
        s=s[:a]+"    for case_id,lane in "+repr(jobs)+":\n"+s[b:]
        s=s.replace("started<595","started<480")
        s=s.replace("['CPython-control','candidate-control','CPython','candidate']",
                    "['candidate','CPython','candidate-control','CPython-control']")
    if name=="archive-owned.py":
        s=s.replace("len(raw['jobs'])==10","len(raw['jobs'])==8").replace("jobs=10,elapsed","jobs=8,elapsed")
    if name=="retrieve.py":
        s=s.replace("status['receipt']['jobs']==10","status['receipt']['jobs']==8")
    write(quiet/name,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as tar:
    for n in parts:tar.add(quiet/n,arcname=n)
inventory=read(lab/"quiet-inventory.json")
earlier="2026-11-23-compact-native-call-stack"
old_root="compact-native-call-stack-b1450-20261123"
path=old_root+"/candidate/"+core
earlier_src=json.loads(get(earlier,"source.json"))
assert earlier_src["outcome"]=="KeepPrivate"
earlier_core=gzip.decompress(get(earlier,"candidate-core.dll.gz"))
assert sha(earlier_core)==earlier_src["imageFiles"]["candidate"][core] and sha(earlier_core)!=files[core]
assert inventory["files"][path]["bytes"]==len(earlier_core) and inventory["files"][path]["links"]==1
retire=[dict(paths=[path],bytes=len(earlier_core),sha256=sha(earlier_core),links=1,
    archives={old_root+"/observations.tgz":archive(earlier)})]
donor_config=read(donor/"quiet/config.json")
cfg={**prev,"root":root,"unit":unit,"identity":identity,"source":donor_config["root"],
    "sourceRole":"candidate","sourceFiles":files,"sourceCatalogSHA256":source["catalogs"]["representative.json"]["sha256"],
    "donorArchiveSHA256":archive(accepted),"retireGroups":retire,"payloadBytes":payload.stat().st_size,
    "payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
assert inventory["freeBytes"]+len(earlier_core)>176160768+cfg["unpackedBytes"]+2*1024*1024+512*1024
save(quiet/"config.json",cfg)
s=(prior/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
s=(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1443-fixtures","b1451-fixtures").replace("RuntimeMaxSec=615","RuntimeMaxSec=500")
write(quiet/"remote-launch.py",s)
launch=(prior/"launch.py").read_text(encoding="utf-8")
write(comparison/"launch.py",launch.replace("seconds=580","seconds=470").replace("before 580 seconds","before 470 seconds").replace("B1443","B1451"))
print(root,cfg["unpackedBytes"],retained)
