from pathlib import Path
import hashlib, io, json, os, subprocess, sys, tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source_folder=sys.argv[1]
frozen=Path(sys.argv[2]).resolve()
def show(path):return subprocess.check_output(["git","show",path],cwd=repo)
def sha(data):return hashlib.sha256(data).hexdigest()
def file_hash(p):return sha(p.read_bytes())
def archived(directory):
    prefix=f"origin/master:benchmarks/results/{directory}"
    receipt=json.loads(show(prefix+"/archive-receipt.json"))
    package=show(prefix+"/observations.tgz")
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert sha(package)==receipt["archiveSHA256"]
    with tarfile.open(fileobj=io.BytesIO(package),mode="r:gz") as source:
        return json.load(source.extractfile("representative.json"))
source=json.loads(show(f"origin/master:benchmarks/results/{source_folder}/source.json"))
retained=source["retainedRevision"]
assert retained and source["outcome"]=="Retained"
assert not subprocess.check_output(["git","diff","--name-only",retained,"HEAD","--","src","tests"],cwd=repo)
files=source["imageFiles"]["candidate"]
assert len(files)==32 and {n:file_hash(frozen/n)for n in files}==files
catalog=archived("2026-11-23-branch-cpython-checkpoint")
ids={
    "compiler.generated-read-only-branches","scripts.config-generated-guards.medium.bad-0.sparse-lexical",
    "scripts.annotated-rule-closures.nested-factories.postponed","scripts.csv-invoice.method-policy.quoted-control",
    "scripts.csv-meter-report.typed-ascii","diagnostic.text-summary.nonlocal-computed-width.large",
    "scripts.json-lines-shipment.expanded-options.large",
}
catalog["cases"]=[c for c in catalog["cases"] if c["id"] in ids]
assert len(catalog["cases"])==7
config=next(c for c in archived("2026-11-23-abstract-state-snapshots")["cases"] if c["id"]=="scripts.config-edit.small")
catalog["cases"].append(config)
out=lab/retained[:9]
out.mkdir()
path=out/"representative.json"
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert file_hash(protocol)==source["protocolSHA256"]
proof=out/"verify.json"
subprocess.run([dotnet,frozen/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=100)
verified=json.loads(proof.read_text(encoding="utf-8"))
assert verified["state"]=="Completed" and verified["caseCount"]==8 and verified["catalogSha256"]==file_hash(path)
assert verified["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
assert {n:file_hash(frozen/n)for n in files}==files
identity=dict(retained=retained,verifiedSource=source["candidate"],imageFiles=files,
    protocolSHA256=source["protocolSHA256"],catalogSHA256=file_hash(path),catalogCases=[c["id"] for c in catalog["cases"]])
(out/"source.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
print(retained, "eight benchmark catalog goldens verify")
