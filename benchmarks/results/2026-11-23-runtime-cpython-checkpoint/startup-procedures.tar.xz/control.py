from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

local = Path(__file__).resolve().parent
quiet = local.parent / "comparison/quiet"
config = json.loads((quiet / "config.json").read_text(encoding="utf-8"))
checkpoint = config["root"]
unit = "lython-b1451-fresh-config-20261123"
remote = checkpoint + "/startup"
key = Path.home() / ".ssh/id_lython-bench.pem"
target = "lokad@20.166.121.73"
common = ["-i", str(key), "-o", "BatchMode=yes", "-o", "ConnectTimeout=15"]
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", *common, target, "python3 -"]
utc_now = lambda: datetime.datetime.now(datetime.timezone.utc)
bound = local / "observe-not-before"
def invoke(script):
    result = subprocess.run(ssh, input=script, encoding="utf-8", capture_output=True, timeout=30)
    assert result.returncode == 0, (result.stdout, result.stderr)
    return result.stdout

if sys.argv[1] == "launch":
    terminal = json.loads((quiet / "terminal-status.json").read_text(encoding="utf-8"))
    assert terminal["exitCode"] == "0" and terminal["receipt"]["complete"]
    payload = {
        "collect.py": (local / "collect.py").read_text(encoding="utf-8"),
        "run.sh": (local / "run.sh").read_text(encoding="utf-8"),
        "catalog.json": (local / "startup-cases.json").read_text(encoding="utf-8"),
    }
    output = invoke(f"from pathlib import Path\nimport fcntl, subprocess\nroot=Path({remote!r})\nunit={unit!r}\npayload={payload!r}\n" + """
with (root.parent.parent / "comparison-vm.lock").open("a") as lease:
 fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
 root.mkdir()
 for name, text in payload.items():
  (root / name).write_text(text, encoding="utf-8", newline="\n")
subprocess.run(["sudo", "-n", "systemd-run", "--unit=" + unit, "--property=User=lokad",
 "--property=WorkingDirectory=" + str(root), "--property=RuntimeMaxSec=180",
 "--property=TimeoutStopSec=30", "--property=KillMode=control-group", "/bin/sh", str(root / "run.sh")], check=True)
print(unit, flush=True)
""".replace('newline="\n"', 'newline="\\n"'))
    (local / "launch.log").write_text(output, encoding="utf-8")
    bound.write_text((utc_now() + datetime.timedelta(seconds=75)).isoformat(), encoding="utf-8")
    print(output.strip())
else:
    assert sys.argv[1] == "retrieve"
    assert utc_now() >= datetime.datetime.fromisoformat(bound.read_text(encoding="utf-8"))
    output = invoke(f"from pathlib import Path\nimport fcntl,json,subprocess\nroot=Path({remote!r})\nunit={unit!r}\n" + """
status = subprocess.run(["systemctl", "show", unit + ".service", "--property=ActiveState,SubState,Result,ExecMainStatus"],
 capture_output=True, text=True).stdout
if "ActiveState=active" in status:
 print(json.dumps(dict(live=True, status=status)))
else:
 with (root.parent.parent / "comparison-vm.lock").open("a") as lease:
  fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
  print(json.dumps(dict(live=False, status=status,
   exitCode=(root/"exit-code.txt").read_text().strip() if (root/"exit-code.txt").exists() else None,
   receipt=json.loads((root/"archive-receipt.json").read_text()) if (root/"archive-receipt.json").exists() else None,
   temporaryFixtures=(root/"guest-fixtures").exists(),
   journal=subprocess.run(["journalctl", "-u", unit+".service", "-n", "26", "--no-pager"],
    capture_output=True, text=True).stdout)))
""")
    receipt = json.loads(output)
    (local / ("terminal-" + utc_now().strftime("%H%M%S") + ".json")).write_text(output, encoding="utf-8")
    print(output)
    if receipt["live"]:
        raise SystemExit(0)
    assert receipt["exitCode"] == "0" and not receipt["temporaryFixtures"] and receipt["receipt"]["complete"]
    archive = local / "observations.tar.xz"
    subprocess.run(["C:/Windows/System32/OpenSSH/scp.exe", *common, target + ":" + remote + "/" + archive.name, archive],
        check=True, timeout=45)
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["receipt"]["archiveSHA256"]
