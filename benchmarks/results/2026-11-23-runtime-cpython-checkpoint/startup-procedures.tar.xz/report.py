from pathlib import Path
import hashlib
import json
import tarfile
from statistics import median, quantiles

root = Path(".git/agent-notes/review-20261031/cpython-runtime-checkpoint-20261123/startup")
read = lambda data: json.loads(data.decode("utf-8"))
terminal = read(sorted(root.glob("terminal-*.json"))[-1].read_bytes())
archive = root / "observations.tar.xz"
assert terminal["exitCode"] == "0" and not terminal["temporaryFixtures"]
receipt = terminal["receipt"]
assert receipt["complete"] and receipt["quietBeforeAndAfter"] and receipt["ownedGuestFixturesReleased"]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archiveSHA256"]
by_case = {}
order = []
with tarfile.open(archive) as package:
    for repeat in range(receipt["repeats"]):
        recorded = read(package.extractfile(f"fresh-{repeat}.json").read())
        manifest = package.extractfile(f"catalog-{repeat}.json").read()
        assert recorded["catalogSha256"] == hashlib.sha256(manifest).hexdigest()
        assert recorded["state"] == "Completed" and recorded["caseCount"] == 3
        cases = {case["id"]: case for case in read(manifest)["cases"]}
        sequence = []
        for row in recorded["rows"]:
            observation = row["observation"]
            response = observation["response"]
            case = cases[response["caseId"]]
            assert observation["status"] == "Equivalent" and response["completedInvocations"] == 1
            assert response["actualOutputSha256"] == case["expectedOutputSha256"]
            assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")
            sequence.append((case["id"], row["engine"]))
            by_case.setdefault(case["id"], {}).setdefault(row["engine"], []).append(
                observation["elapsedTicks"] * 1000 / observation["clockFrequency"])
        order.append(sequence)

summary = {}
for case, timings in by_case.items():
    assert all(len(engine) == receipt["repeats"] for engine in timings.values())
    left, right = timings["Lython"], timings["CPython"]
    summary[case] = dict(lythonMs=median(left), cpythonMs=median(right), ratio=median(left) / median(right),
        lythonRangeMs=(min(left), max(left)), cpythonRangeMs=(min(right), max(right)),
        lythonIqrMs=quantiles(left, n=4, method="inclusive")[::2],
        cpythonIqrMs=quantiles(right, n=4, method="inclusive")[::2])
    print(case, summary[case])
(root / "summary.json").write_text(json.dumps(dict(qualification="diagnostic",
    engineOrder="Lython first in each original smoke case, case order rotated", actualOrder=order,
    observations=receipt["jobs"], rows=summary), indent=2) + "\n", encoding="utf-8")
