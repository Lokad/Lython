from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();root=repo/'.git/agent-notes/review-20261031/regex-producer-050-r409';r=root/'fixtures-corrected';r.mkdir();sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+env['PATH'];rows=[]
for tfm in ['net11.0','net10.0']:
 for role in ['baseline','native']:
  image=r/'consumers'/tfm/role;image.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release'/tfm,image,copy_function=shutil.copyfile)
  # Immutable test image: copied output, pinned core/backend assets, private adapter.
  for p in (root/'assets'/tfm).iterdir():shutil.copyfile(p,image/p.name)
  adapter=root/role/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll';shutil.copyfile(adapter,image/adapter.name)
  shutil.copytree(repo/'tests/Fixtures/Workflows/RegexRewrite',image/'Fixtures/Workflows/RegexRewrite',copy_function=shutil.copyfile)
  identity={n:hashlib.sha256((image/n).read_bytes()).hexdigest()for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Lython.PublicApi.Tests.dll']}
  results=r/'results'/tfm/role;results.mkdir(parents=True);log=r/(role+'-public-'+tfm+'.log');start=time.monotonic()
  with log.open('w',encoding='utf-8',newline='\n')as stream:
   p=subprocess.run([sdk+'/dotnet.exe','vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:Category!=Stress&FullyQualifiedName~Regex','--Logger:trx;LogFileName=regex.trx','--ResultsDirectory:'+str(results)],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180,cwd=repo)
  row=dict(tfm=tfm,role=role,returncode=p.returncode,elapsedSeconds=time.monotonic()-start,identity=identity,log=log.name);rows.append(row);(r/'consumer-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
  print(tfm,role,'exit',p.returncode,'seconds',round(row['elapsedSeconds'],2),flush=True)
  print(log.read_text(encoding='utf-8')[-1300:],flush=True)
  assert p.returncode==0,(role,tfm)
