from pathlib import Path
import subprocess
r=Path(__file__).parent/'quiet'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['journalctl -u lython-b798-regex-ranges-20261115.service --no-pager -o cat -n 100'],capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr
(r/'failed-journal.txt').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
