from pathlib import Path
import hashlib,json,shutil
repo=Path.cwd();r=Path(__file__).parent;q=r/'comparison';q.mkdir()
# Reuse the existing full command-v2 worker and immutable auxiliaries.
f=repo/'.git/agent-notes/review-20261031/cased-preparation-r408/refined/candidate'
identities={}
for role in ['baseline','native']:
 d=q/role;d.mkdir()
 for p in f.iterdir():
  if p.is_file():shutil.copyfile(p,d/p.name)
 for p in (r/'assets/net11.0').iterdir():shutil.copyfile(p,d/p.name)
 shutil.copyfile(r/role/'bin/Release/net11.0/Lokad.Lython.Utf8Regex.dll',d/'Lokad.Lython.Utf8Regex.dll')
 identities[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()}
for n in identities['baseline']:
 if n!='Lokad.Lython.Utf8Regex.dll':assert identities['baseline'][n]==identities['native'][n],n
base=json.loads((f.parent/'catalog.json').read_text(encoding='utf-8'));template=base['cases'][0]
cases=[]
for name,source,expected in [
 ('scripts.regex-range.extract',r'''import re
text = 'é𝒜 item=12; item=34\n' * 256
total=0
count=0
for match in re.finditer(r'item=(?P<value>\d+)', text):
    total += int(match.group('value'))
    count += 1
print(count,total)
''','512 11776\n'),
 ('scripts.regex-range.rewrite',r'''import re
text = 'é𝒜 item=12; item=34\n' * 256
result = re.sub(r'item=(?P<value>\d+)', r'[\g<value>]', text)
print(len(result),result.count('[12]'),result.count('[34]'))
''',str(len('é𝒜 [12]; [34]\n'*256))+' 256 256\n')]:
 c=dict(template);c.update(id=name,family='scripts',category='complete-regex',scale='bounded',size=512,source=source,fixtureJson='{}',expectedOutput=expected)
 for field,src in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:c[field]=hashlib.sha256(c[src].encode()).hexdigest()
 for n in ['sourceUtf8Bytes','expectedOutputUtf8Bytes','fixtureTextUtf8Bytes','fixtureTextCodePoints','expectedFilesSha256']:c.pop(n,None)
 cases.append(c)
base['cases']=cases;base['fixtureEncoding']='R409 complete regex extraction/rewrite with independently calculated goldens; no I/O';(q/'catalog.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(q/'identity.json').write_text(json.dumps(dict(images=identities,coreUnchanged=True,onlyAdapterDiffers=True,producer='Exact unpublished0.5 immutable candidate',kind='Development backend comparison; not final package qualification'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Copied two full immutable worker images, identical except adapter; two complete Unicode/capture workloads.')
