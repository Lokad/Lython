from pathlib import Path
import datetime,json,shlex,subprocess
q=Path(__file__).parent/'quiet';config=json.loads((q/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
c=CONFIG
b=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==b and root.resolve()==root and not root.exists()and source.parent==b and source.resolve()==source
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in state and 'MainPID=0'in state
 for n,h in c['sourceFiles'].items():assert sha(source/'candidate'/n)==h,n
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 proof=c['retire'];ps=[b/n for n in proof['paths']];m=ps[0].lstat();expected={(m.st_dev,m.st_ino)}
 for p in ps:
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and s.st_nlink==proof['links']and(s.st_dev,s.st_ino)in expected and sha(p)==proof['sha256']
 aliases=[]
 for base,dirs,files in os.walk(b):
  for n in files:
   p=Path(base)/n;s=p.lstat()
   if(s.st_dev,s.st_ino)in expected:aliases.append(str(p.relative_to(b)))
 assert sorted(aliases)==sorted(proof['paths'])
 before=shutil.disk_usage(b).free;assert before+proof['bytes']>254*1024*1024+c['unpackedBytes']+65536
 for p in ps:p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 for role in ['reference','candidate']:
  for n,h in c['identity']['imageFiles'][role].items():
   p=root/role/n
   if not p.exists():os.link(root/'backend'/n if n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']else source/'candidate'/n,p)
   assert sha(p)==h,n
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=proof,freshIdleLease=True,allHashesPathsOwnershipLinksAndAliasesVerified=True,canonicalArchiveAndCurrentImagesPreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(b).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b798-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],root=str(root),freeBytes=shutil.disk_usage(b).free)))
'''.replace('CONFIG',repr(config))
(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=105)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
