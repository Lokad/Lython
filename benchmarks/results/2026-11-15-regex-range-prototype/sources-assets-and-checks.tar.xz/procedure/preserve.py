from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'corrected-quiet';out=repo/'benchmarks/results/2026-11-15-regex-range-prototype';out.mkdir()
ssh=['C:/Windows/System32/OpenSSH/scp.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['failed-observations.tgz','failure-cleanup.json']:
 p=subprocess.run(ssh+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/regex-ranges-b798-20261115/'+n,str(r/'quiet'/n)],capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr
cleanup=json.loads((r/'quiet/failure-cleanup.json').read_text(encoding='utf-8'));assert cleanup['allWorkersJoined']and cleanup['emptyRamFixtureArchivedBeforeUnmount']
assert hashlib.sha256((r/'quiet/failed-observations.tgz').read_bytes()).hexdigest()==cleanup['archiveSHA256']
for src,name in [(q/'summary.json','summary.json'),(q/'identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json'),(r/'comparison/allocation-summary.json','allocation-summary.json'),(r/'fixtures-corrected/consumer-checks.json','consumer-checks.json'),(r/'prototype-identity.json','prototype-identity.json'),(r/'nuget-versions.json','availability-at-capture.json'),(r/'quiet/failed-observations.tgz','original-failed-observations.tgz'),(r/'quiet/failure-cleanup.json','original-failure-cleanup.json')]:shutil.copyfile(src,out/name)
with tarfile.open(out/'sources-assets-and-checks.tar.xz','w:xz')as t:
 for role in ['baseline','native']:
  for n in ['Adapter.csproj','Utf8RegexProvider.cs']:t.add(r/role/n,arcname=role+'/'+n)
  for tfm in ['net11.0','net10.0']:t.add(r/role/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll',arcname=role+'/'+tfm+'/Lokad.Lython.Utf8Regex.dll')
 for p in (r/'assets').rglob('*.dll'):t.add(p,arcname='assets/'+p.relative_to(r/'assets').as_posix())
 for p in (r/'fixtures-corrected').rglob('*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
 for p in (r/'fixtures-corrected').glob('*.log'):t.add(p,arcname=p.relative_to(r).as_posix())
 for n in ['consumer-checks.json','baseline-public-net11.0.log']:t.add(r/n,arcname='original-fixture-failure/'+n)
 for n in ['catalog.json','baseline-allocation.json','native-allocation.json']:t.add(r/'comparison'/n,arcname='allocation/'+n)
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for sub in ['quiet','corrected-quiet']:
  for p in (r/sub).iterdir():
   if p.is_file()and p.suffix in ['.py','.json','.log','.txt','.sh']:t.add(p,arcname='procedure/'+sub+'/'+p.name)
 t.add(repo/'tests/Lokad.Lython.PublicApi.Tests/RegexAdapterCapabilityTests.cs',arcname='tests/RegexAdapterCapabilityTests.cs')
(out/'README.md').write_text('''# Development regex range adapter

R409, 2026-11-15. **Development prototype, not adopted normal adapter or final
released-package qualification.** Core remains decoupled and unchanged at fully
qualified1b82cd46/frozen0edc0c1c. Normal non-packable adapter remains on released0.4.
Both private adapters compile against the same exact unpublished0.5 candidate,
source dcfe880a accepted by its producer atc5e02a27; immutable asset hashes are
recorded. Separate sibling worktree edits are not consumed. No core release gate
or runtime dependency edge is added.

## Displacement and semantics

The native candidate advances directly into byte-range captures, removing detailed
captured-text projection, per-advance cancellation forwarding registration and
generic closure transport. It explicitly disposes compiled programs. The flag
bridge remains: parse Verbose and reported flag bits are independently meaningful;
EffectiveOptions alone cannot reconstruct that distinction. Four public controls
cover both mismatches and global inline flags, with cleanup returning the budget.

Keep the construction-token bridge and existing conservative MatchBytes/scope
funding. No new memory-management mechanism or work/time policy. New producer
allowance callbacks forbid regex reentry/nonthrowing-refund violations; direct
forwarding to reentrant host budgets remains unqualified. Native group-name
enumeration, cancellation during token-free cursor preparation and separate
one-match result ownership remain producer-specific limitations. UTF8 lookup is
not enumeration. The core's cooperating-provider interruption/unwind contract
remains separate from actual backend capabilities.

Each private source passes361public regex tests on actual.NET11 and10; unchanged
normal0.4 passes361each too. These cover Python semantics, windows/captures/flags,
cancellation and ownership/refusal. Original private test-image failure (357pass,
four missing workflow fixtures) is retained; adding those inputs corrects the
test image, not test assertions. No full core qualification is repeated.

## Complete affected scripts

| Script | Allocation / invocation before → native | Elapsed change | Wider process CPU change |
| --- | --- | --- | --- |
| Extract512named integer captures from Unicode text |423,411.5 →340,875.5B (−19.49%)|−24.76..−21.72%|−26.05..−20.73%|
| Rewrite512matches with named replacement groups |252,131.5 →169,595.5B (−32.74%)|−37.37..−33.55%|−36.62..−33.38%|

Source-pair development comparison, no CPython or cross-producer speedup claim.
Allocation is a separate local process-wide CLR counter diagnostic, five64-run
batches after full warmup; no forced collections. Full goldens/result cleanup,
unchanged compilation balance and final zero balance are asserted.

Quiet Azure F4as_v7/Ubuntu24.04.4, four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3
workstation GC/normal tiering. B799 finishes72.513s, two processes/source,5s
full-request warmup, five rotated0.5s batches. Exact core/producer/worker images,
source/input/output and execution boundary are identical except adapter. All
process-median pairings are retained; reference spreads2.28/4.12%, native1.73/1.90%.
Warm clocks include public synchronous Run, output validation and prior-result
cleanup; compilation/startup/reset/protocol/final cache teardown excluded. Wider
process CPU includes reset/protocol. No I/O, pending-operation latency, heap/RSS
or embedding-tail claim. All quiet/golden/budget/Closed/join/archive/cleanup gates
pass; terminal B799 cached, no workers or RAM fixtures remain.

Original B798 owner fails before Ready because custom fixture metadata omitted
required size/text. No timing observations exist. The failure/journal/catalog and
empty RAM fixture are archived under the idle lease before unmount; B799 corrects
only metadata. One exact historical38c0 binary with two aliases is retired after
fresh UID/path/hash/link/all-alias and committed archive/member proof. Current
images, evidence/toolchains and254/252MiBfloors remain. Both conditions are retained,
not silently rerun or relabeled. Producer publication holds only final adoption;
independent core/runtime development continues.

[All medians/controls](summary.json),[allocation](allocation-summary.json),
[immutable identities](prototype-identity.json),[focused checks](consumer-checks.json),
[source/assets/tests/procedure](sources-assets-and-checks.tar.xz),
[raw observations](observations.tgz),[original failure](original-failed-observations.tgz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

[R409 development native-range adapter](results/2026-11-15-regex-range-prototype/README.md)
qualifies private0.5baseline/candidate361public regex tests each actual11/10.
Complete extraction/replacement allocation−19.49/−32.74%; quiet B799elapsed
−24.76..−21.72%/−37.37..−33.55%, supportingCPU, all controls retained. Original
B798missing-metadata failure and test-image missing-fixture failure preserved.
Normal adapter stays0.4, core unchanged; final producer qualification remains
separate from contract correctness and this source-pair backend performance.
''')
q=repo/'PLAN.md';s=q.read_text(encoding='utf-8').replace('Four new public flag controls await commit.','Four new public flag controls are ready with passing focused checks.').replace('| Open measurement | R409 complete extraction/replacement allocations fall **19.49% / 32.74%**; no CPU claim. Quiet-VM **B798** compares the same two adapters, unchanged core/producer/input/boundary. Keep that owner; no duplicate collection. |','| Qualified development measurement | [R409 evidence](benchmarks/results/2026-11-15-regex-range-prototype/README.md): extraction/replacement allocation **−19.49% / −32.74%**; quiet B799 elapsed **−24.76..−21.72% / −37.37..−33.55%**, supporting CPU. Original missing-metadata B798 failure retained; corrected B799 terminal success,72.513s/all users cleaned. This is not final producer adoption. |')
s=s.replace('**Next gate: select a whole construction, transport or conversion path to remove.**','**R410 active: matched helper/counter decomposition B801.** Four complete scripts, same input/goldens/core, two independent processes each. Actual compiled facts confirm all main scopes remain unmirrored, all four retain dictionary-loop fusion, both helper variants are native-eligible. No enclosing namespace cliff is established. Original staging failure (no image directory; no workers/timing) is preserved. Keep current bounded owner; decide the displaced work from its observations, not the confounded CPython rows.\n\n**Next gate: select a whole construction, transport or conversion path to remove.**')
q.write_text(s,encoding='utf-8',newline='\n');print('Preserved private source/producer assets, both framework checks, allocation, controlled timing and original failures; normal adapter/core unchanged.')
