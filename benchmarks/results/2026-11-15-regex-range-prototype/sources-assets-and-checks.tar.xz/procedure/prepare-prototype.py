from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from xml.sax.saxutils import escape
repo=Path.cwd();r=repo/'.git/agent-notes/review-20261031/regex-producer-050-r409';assets=r/'assets';assets.mkdir();producer=Path('D:/code/utf8regex');accept=json.loads((producer/'bench/Experiments/Release050-20261115/acceptance.json').read_text(encoding='utf-8'));rows=[]
for tfm in ['net11.0','net10.0']:
 target=assets/tfm;target.mkdir()
 for id in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
  package=producer/'artifacts/nuget'/(id+'.0.5.0.nupkg');record=next(v for v in accept['Packages']if v['Id']==id and v['TargetFramework']==tfm);assert hashlib.sha256(package.read_bytes()).hexdigest().upper()==record['PackageSha256']
  with zipfile.ZipFile(package)as z:data=z.read('lib/'+tfm+'/'+id+'.dll')
  assert hashlib.sha256(data).hexdigest().upper()==record['AssemblySha256'];(target/(id+'.dll')).write_bytes(data);rows.append(dict(id=id,tfm=tfm,packageSHA256=record['PackageSha256'],assemblySHA256=record['AssemblySha256']))
 core=repo/'.git/agent-notes/review-20261031/cased-preparation-r408/refined/candidate/Lokad.Lython.dll'if tfm=='net11.0'else repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll';shutil.copyfile(core,target/'Lokad.Lython.dll')
source=(repo/'src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs').read_text(encoding='utf-8');candidate=source
# Keep the flag bridge: parsing Verbose can differ from reported bits.
old='''        catch (PythonRePatternException error)
        {
            token.ThrowIfCancellationRequested();
            throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message,
                ScalarErrorPosition(error.Position, utf8Pattern, patternSource?.Pattern, token));
        }''';assert old in candidate
candidate=candidate.replace(old,'''        catch (PythonRePatternException error)
        { throw PatternError(error, token, utf8Pattern, patternSource); }''',1)
needle='''    // PythonRe 0.4 reports UTF-16 offsets/-1.'''
helper='''    private static LythonRegexException PatternError(PythonRePatternException error, CancellationToken token,
        ReadOnlyMemory<byte> utf8Pattern = default, Utf8PythonRegex? patternSource = null)
    {
        token.ThrowIfCancellationRequested();
        return new LythonRegexException(LythonRegexFailure.Pattern, error.Message,
            ScalarErrorPosition(error.Position, utf8Pattern, patternSource?.Pattern, token));
    }

''';assert needle in candidate;candidate=candidate.replace(needle,helper+needle,1)
old='''            // The caller has drained subjects/cursors and metadata borrows.
            // PythonRe 0.4 owns only managed objects, with no program Dispose API.
            // Drop those references and retire their existing funded scope.
            if (Interlocked.Exchange(ref _regex, null) is null) return;
            _namedGroups = null;
            _owner.Dispose();''';assert old in candidate
candidate=candidate.replace(old,'''            // The caller has drained subjects/cursors and metadata borrows.
            if (Interlocked.Exchange(ref _regex, null) is not { } regex) return;
            try { regex.Dispose(); }
            finally { _namedGroups = null; _owner.Dispose(); }''',1)
needle='''        public void Dispose() { if (!_disposed) { _disposed = true; _owner.Dispose(); } }'''
helper='''        private static void CopyCaptures(Utf8PythonRangeMatch data, Span<LythonRegexCapture?> captures, CancellationToken token)
        {
            var groups = data.Groups;
            for (var i = 0; i < captures.Length; i++)
            {
                token.ThrowIfCancellationRequested();
                var group = groups[i];
                captures[i] = group.Success ? new(group.StartOffsetInBytes, group.EndOffsetInBytes) : null;
            }
        }

''';assert needle in candidate;candidate=candidate.replace(needle,helper+needle,1)
old='''                    using (Forward(token))
                    {
                        if (Backend(() => _cursor.MoveNext(), token, patternSource: _subject.Pattern.Regex))
                        {
                            var data = _cursor.Current;
                            CopyCaptures(data, captures, token);
                            lastIndex = data.LastIndex;
                            return true;
                        }
                    }''';assert old in candidate
candidate=candidate.replace(old,'''                    if (Advance(token, out var data))
                    {
                        CopyCaptures(data, captures, token);
                        lastIndex = data.LastIndex;
                        return true;
                    }''',1)
needle='''            private void Close()
            {''';assert needle in candidate
candidate=candidate.replace(needle,'''            private bool Advance(CancellationToken token, out Utf8PythonRangeMatch data)
            {
                try { return _cursor!.MoveNext(out data, token); }
                catch (PythonRePatternException error)
                { throw PatternError(error, token, patternSource: _subject.Pattern.Regex); }
                catch (ArgumentException error)
                { throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message); }
            }

'''+needle,1)
for role,code in [('baseline',source),('native',candidate)]:
 folder=r/role;folder.mkdir();(folder/'Utf8RegexProvider.cs').write_text(code,encoding='utf-8',newline='\n')
 project='''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFrameworks>net11.0;net10.0</TargetFrameworks>
    <AssemblyName>Lokad.Lython.Utf8Regex</AssemblyName>
    <Version>0.11.0</Version><AssemblyVersion>0.11.0.0</AssemblyVersion>
    <IsPackable>false</IsPackable><AllowUnsafeBlocks>false</AllowUnsafeBlocks>
    <EnableSourceControlManagerQueries>false</EnableSourceControlManagerQueries>
  </PropertyGroup>
  <ItemGroup>
'''
 for name in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:project+='    <Reference Include="'+name+'"><HintPath>../assets/$(TargetFramework)/'+name+'.dll</HintPath></Reference>\n'
 project+='  </ItemGroup>\n</Project>\n';(folder/'Adapter.csproj').write_text(project,encoding='utf-8',newline='\n')
(r/'prototype-identity.json').write_text(json.dumps(dict(producerVersion='Exact unpublished0.5candidate; no normal pin/source changed',assets=rows,core11SHA256=hashlib.sha256((assets/'net11.0/Lokad.Lython.dll').read_bytes()).hexdigest(),baselineSourceSHA256=hashlib.sha256(source.encode()).hexdigest(),nativeSourceSHA256=hashlib.sha256(candidate.encode()).hexdigest(),scope='Range-only cursor advances/current per-advance token, direct typed transport without Func closure, explicit program Dispose. Flag bridge and coarse preflight remain until actual producer contracts permit removal.',noProducerWorktreeOrCoreContractChanges=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Created two private nonpackable adapters against identical exact0.5assets/core; native ranges only, no normal0.4pin change.')
