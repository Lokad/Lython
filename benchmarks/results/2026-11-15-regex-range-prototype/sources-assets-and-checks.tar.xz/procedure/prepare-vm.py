from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet';q.mkdir(exist_ok=True);assert not(q/'launch.log').exists();old=r.parent/'cased-preparation-r408/refined-quiet';remote='/home/lokad/lython-bench-checks/regex-ranges-b798-20261115';unit='lython-b798-regex-ranges-20261115'
pair=json.loads((r/'comparison/identity.json').read_text(encoding='utf-8'))['images'];oldid=json.loads((old/'identity.json').read_text(encoding='utf-8'))
pair={role:{n:h for n,h in files.items()if n in oldid['auxiliaryFiles']or n=='Lokad.Lython.dll'}for role,files in pair.items()}
identity=dict(sourceRevision='R409 private0.5development adapters; unchanged qualified1b82/frozen0ed runtime',purpose='Remove detailed captured-text iteration projection and per-advance forwarding registration; complete Unicode extraction/replacement scripts; not final package adoption.',coreSHA256={k:pair['native'if k.startswith('candidate')else'baseline']['Lokad.Lython.dll']for k in ['reference','reference-control','candidate','candidate-control']},imageFiles=dict(reference=pair['baseline'],candidate=pair['native']),publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(r/'comparison/catalog.json',q/'representative.json')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('cased-preparation-b795-20261115','regex-ranges-b798-20261115').replace('lython-b795-refined-cased-preparation-20261115',unit).replace('B795','B798')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+"jobs=[['scripts.regex-range.extract','warm'],['scripts.regex-range.rewrite','warm']]\n"+s[b:]
  s=s.replace("identity['auxiliaryFiles'].items()","identity['imageFiles']['candidate'if label.startswith('candidate')else'reference'].items()")
  s=s.replace("catalog=root/('additional.json'if case_id=='scripts.text-summary.inline.large'else'representative.json')","catalog=root/'representative.json'")
  s=s.replace("catalog=root/('additional.json' if case_id=='scripts.text-summary.inline.large' else 'representative.json')","catalog=root/'representative.json'")
  s=s.replace(' < 290,',' < 110,')
 s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace("['jobs']==5","['jobs']==2").replace('jobs=5,','jobs=2,').replace("elapsedSeconds']<360","elapsedSeconds']<150")
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
# Exact old prototype bytes already committed in canonical immutable evidence.
archive='benchmarks/results/2026-11-14-native-owned-slots/source-checks.tar.xz';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();raw=(repo/archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(repo/archive)as t:core=t.extractfile('candidate-core.dll').read()
proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert hashlib.sha256(core).hexdigest()==proof['sha256']and len(core)==proof['bytes']and proof['links']==len(proof['paths'])==2
proof['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='candidate-core.dll');proof['allAliasesMustBeRecheckedUnderLease']=True
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
 for n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:t.add(r/'assets/net11.0'/n,arcname='backend/'+n)
 for role,src in [('reference','baseline'),('candidate','native')]:t.add(r/src/'bin/Release/net11.0/Lokad.Lython.Utf8Regex.dll',arcname=role+'/Lokad.Lython.Utf8Regex.dll')
with tarfile.open(q/'payload.tgz')as t:unpacked=sum(m.size for m in t if m.isfile())
config=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115',sourceFiles=dict(oldid['auxiliaryFiles'],**{'Lokad.Lython.dll':identity['coreSHA256']['candidate']}),identity=identity,retire=proof,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(dict(jobs=2,payloadBytes=config['payloadBytes'],unpackedBytes=unpacked,retireOnlyExactArchivedOldCoreBytes=proof['bytes']))
