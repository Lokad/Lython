from pathlib import Path
import ast,hashlib,json
r=Path(__file__).parent/'comparison';p=r/'catalog.json';d=json.loads(p.read_text(encoding='utf-8'))
for c in d['cases']:
 c['source']=c['source'].replace("item=34\n'", "item=34\\n'")
 ast.parse(c['source'])
 c['fixtureJson']='{"inputFiles":{},"outputFiles":{}}'
 c['expectedFilesSha256']=hashlib.sha256(bytes(4)).hexdigest()
 for n,s in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:c[n]=hashlib.sha256(c[s].encode()).hexdigest()
 # CPython is only an independent semantic check here, not a timing baseline.
 import contextlib,io
 out=io.StringIO()
 with contextlib.redirect_stdout(out):exec(c['source'],{})
 assert out.getvalue()==c['expectedOutput'],(c['id'],out.getvalue(),c['expectedOutput'])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Both complete scripts parse and produce independent goldens in CPython; explicit empty file host.')
