from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;old=r/'quiet';q=r/'corrected-quiet';q.mkdir();remote='/home/lokad/lython-bench-checks/regex-ranges-b799-20261115';unit='lython-b799-regex-ranges-20261115'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','identity.json']:
 s=(old/n).read_text(encoding='utf-8').replace('regex-ranges-b798-20261115','regex-ranges-b799-20261115').replace('lython-b798-regex-ranges-20261115',unit).replace('B798','B799')
 (q/n).write_text(s,encoding='utf-8',newline='\n')
d=json.loads((old/'representative.json').read_text(encoding='utf-8'))
for c in d['cases']:
 c['fixtureJson']='{"size":512,"text":null,"inputFiles":{},"outputFiles":{}}';c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
(q/'representative.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json']:t.add(q/n,arcname=n)
config=dict(root=remote,source='/home/lokad/lython-bench-checks/regex-ranges-b798-20261115',unit=unit,identity=json.loads((q/'identity.json').read_text(encoding='utf-8')),payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest())
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
c=CONFIG
b=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==b and root.resolve()==root and not root.exists()and source.parent==b and source.resolve()==source
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout;own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 state=subprocess.check_output(['systemctl','show','lython-b798-regex-ranges-20261115.service','--property=MainPID,Result,ActiveState'],text=True);assert 'MainPID=0'in state and 'Result=exit-code'in state and 'ActiveState=failed'in state
 assert not json.loads((source/'confirmation/confirmation.json').read_text())['jobs']
 fixture=source/'guest-fixtures';assert fixture.is_dir()and not list(fixture.iterdir())
 journal=subprocess.check_output(['journalctl','-u','lython-b798-regex-ranges-20261115.service','--no-pager','-o','cat'],text=True);(source/'failed-journal.txt').write_text(journal)
 with tarfile.open(source/'failed-observations.tgz','w:gz',dereference=True)as t:
  for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json','retirement-receipt.json','failed-journal.txt','exit-code.txt','confirmation']:t.add(source/n,arcname=n)
 with tarfile.open(source/'failed-observations.tgz')as t:assert not json.loads(t.extractfile('confirmation/confirmation.json').read())['jobs']
 assert shutil.disk_usage(b).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 (source/'failure-cleanup.json').write_text(json.dumps(dict(originalOwnerFailed=True,noTimingObservations=True,reason='Fixture metadata omitted required size/text; worker refuses before Ready',allWorkersJoined=True,emptyRamFixtureArchivedBeforeUnmount=True,originalEvidencePreserved=True,archiveSHA256=sha(source/'failed-observations.tgz')))+'\\n')
 for role,files in c['identity']['imageFiles'].items():
  for n,h in files.items():assert sha(source/role/n)==h,n
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 assert shutil.disk_usage(b).free>254*1024*1024+65536;root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 for role,files in c['identity']['imageFiles'].items():
  (root/role).mkdir()
  for n,h in files.items():os.link(source/role/n,root/role/n);assert sha(root/role/n)==h,n
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b799-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],originalFailurePreservedAndCleaned=True,freeBytes=shutil.disk_usage(b).free)))
'''.replace('CONFIG',repr(config))
(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=105)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
