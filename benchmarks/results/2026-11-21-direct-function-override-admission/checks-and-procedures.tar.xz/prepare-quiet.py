from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
prior = lab.parent / "callable-standard-overrides"
template = prior / "quiet"
quiet = lab / "quiet"
repo = lab.parents[3]
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


index = load(lab / "identity.json")
previous = load(template / "config.json")
receipt = load(template / "archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert receipt["archiveSHA256"] == sha(template / "observations.tgz")
images = index["imageFiles"]
source_files = previous["identity"]["imageFiles"]["reference"]
assert index["reference"].startswith("a3d0bfc34") and source_files == images["reference"]
assert len(source_files) == 32 and previous["protocolSHA256"] == index["pythonWorkerSHA256"]
assert [name for name in source_files if source_files[name] != images["candidate"][name]] == [core]
manifest = lab / "representative.json"
postponed = "scripts.annotated-rule-closures.nested-factories.postponed"
jobs = [
    (postponed, "warm"),
    (postponed, "compile-run"),
    ("scripts.annotated-rule-closures.nested-factories", "warm"),
    ("scripts.factory-wrapper-metadata", "warm"),
    ("scripts.dataclass-keyword-configuration.generated", "warm"),
]
assert all(case in {row["id"] for row in load(manifest)["cases"]} for case, _ in jobs)
for role, files in images.items():
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 6
    assert verification["catalogSha256"] == index["catalogSHA256"] == sha(manifest)

canonical = "benchmarks/results/2026-11-21-callable-standard-overrides/candidate-core.dll.gz"
retired = gzip.decompress(subprocess.check_output(["git", "show", "HEAD:" + canonical], cwd=repo))
retired_sha = hashlib.sha256(retired).hexdigest()
assert retired_sha == previous["identity"]["imageFiles"]["candidate"][core]
prior_name = Path(previous["root"]).name
retire = [dict(paths=[prior_name + "/candidate/" + core], links=1, bytes=len(retired), sha256=retired_sha,
               archives={prior_name + "/observations.tgz": receipt["archiveSHA256"]},
               verifiedCanonicalGitImage=canonical)]
root = "/home/lokad/lython-bench-checks/callable-direct-override-admission-b1283-20261121"
unit = "lython-b1283-callable-direct-override-admission-20261121"
quiet.mkdir(exist_ok=False)
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Direct admission of the first standard function override",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=index["catalogSHA256"],
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(template / name).replace(previous["root"], root).replace(previous["unit"], unit)
    if name == "collect.py":
        begin = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", begin)
        source = source[:begin] + "\njobs = " + repr(jobs) + source[end:]
    source = source.replace("len(jobs)==7", "len(jobs)==5").replace("len(raw['jobs'])==7", "len(raw['jobs'])==5")
    source = source.replace("jobs=7,elapsedSeconds", "jobs=5,elapsedSeconds").replace("status['receipt']['jobs']==7", "status['receipt']['jobs']==5")
    emit(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
(quiet / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, quiet / "candidate" / core)
shutil.copyfile(manifest, quiet / "representative.json")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=previous["root"], sourceRole="reference",
              sourceFiles=source_files, sourceCatalogSHA256=previous["catalogSHA256"],
              donorArchiveSHA256=receipt["archiveSHA256"], catalogSHA256=identity["catalogSHA256"], retireGroups=retire,
              protocolSource=previous["root"] + "/cpython-worker.py", protocolSHA256=index["pythonWorkerSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
source = read(template / "remote-launch.py")
begin = source.index("\nc=") + 1
end = source.index("\nb=Path(", begin)
source = source[:begin] + "c=" + repr(config) + source[end:]
emit(quiet / "remote-launch.py", source.replace("lython-b1282-fixtures", "lython-b1283-fixtures"))
emit(lab / "launch.py", read(prior / "launch.py").replace("410", "295")
     .replace("Function attribute storage comparison", "Direct override admission comparison"))
emit(lab / "summarize.py", read(prior / "summarize.py").replace("len(raw['jobs'])==7", "len(raw['jobs'])==5"))
