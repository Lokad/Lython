from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
work = repo / ".git/agent-worktrees/pinned-unicode-casing-20261121"
donor = lab.parent / "regex-program-equality"
allocation = lab.parent / "native-callback-entry/frozen/candidate"
core = "Lokad.Lython.dll"
manifest = lab / "representative.json"
protocol = repo / "benchmarks/cpython-worker.py"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def git(where, *args):
    return subprocess.check_output(["git", *args], cwd=where, text=True).strip()


ref_revision = git(repo, "rev-parse", "a3d0bfc34")
candidate_revision = git(work, "rev-parse", "HEAD")
assert ref_revision == git(repo, "rev-parse", "HEAD") and candidate_revision != ref_revision
assert not git(work, "status", "--porcelain")
donated = load(donor / "identity.json")
assert not git(repo, "diff", "--name-only", ref_revision, donated["candidate"], "--", "src")
files = donated["imageFiles"]["candidate"]
original = donor / "frozen/candidate"
assert len(files) == 32 and {name: sha(original / name) for name in files} == files
images = {}
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in files:
        source = original / name
        if role == "candidate" and name == core:
            source = work / "src/Lokad.Lython/bin/Release/net11.0" / core
        shutil.copyfile(source, image / name)
    hashes = {name: sha(image / name) for name in files}
    proof = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", protocol, "--out", proof], check=True, env=env, timeout=120)
    result = load(proof)
    assert result["state"] == "Completed" and result["caseCount"] == 6
    assert result["catalogSha256"] == sha(manifest)
    for probe in allocation.glob("ValidatedAllocation.*"):
        shutil.copyfile(probe, image / probe.name)
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   check=True, env=env, timeout=120)
    assert {name: sha(image / name) for name in files} == hashes
    images[role] = hashes
assert images["reference"] == files
assert [name for name in files if images["candidate"][name] != files[name]] == [core]
save(lab / "identity.json", dict(reference=ref_revision, referenceImageSource=donated["candidate"],
                                candidate=candidate_revision, catalogSHA256=sha(manifest),
                                pythonWorkerSHA256=sha(protocol), imageFiles=images))
previous, updated = (load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate"))
rows = []
for before, after in zip(previous, updated, strict=True):
    assert before["id"] == after["id"]
    assert before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    a, b = (statistics.median(row["allocatedBytesPerInvocation"]) for row in (before, after))
    rows.append(dict(case=before["id"], previousAllocation=a, candidateAllocation=b, allocationChangePercent=100*(b/a-1),
                     previousAccountedPeak=before["peakExecutionMemoryBytes"],
                     candidateAccountedPeak=after["peakExecutionMemoryBytes"], budgetReturnedToBaseline=True))
save(lab / "allocation-summary.json", rows)
for row in rows:
    print(row)
