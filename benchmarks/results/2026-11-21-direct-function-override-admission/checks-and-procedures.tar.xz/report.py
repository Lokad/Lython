from pathlib import Path
import json


lab = Path(__file__).resolve().parent
summary = json.loads((lab / "quiet/quiet-summary.json").read_text(encoding="utf-8"))
decision = json.loads((lab / "decision.json").read_text(encoding="utf-8"))["decision"]
allocations = {row["case"]: row["allocationChangePercent"]
               for row in json.loads((lab / "allocation-summary.json").read_text(encoding="utf-8"))}
names = {
    "scripts.annotated-rule-closures": "Eager rules",
    "scripts.annotated-rule-closures.nested-factories": "Eager nested factories",
    "scripts.annotated-rule-closures.nested-factories.postponed": "Postponed nested factories",
    "scripts.csv-invoice.large": "CSV invoice",
    "scripts.dataclass-keyword-configuration.generated": "Keyword dataclasses",
    "scripts.factory-wrapper-metadata": "Factory with wrapper metadata writes",
}


def percent(value):
    return f"{value:+.2f}%".replace("-", "−")


def extent(values):
    return percent(min(values)) + " to " + percent(max(values))


rows = [
    "| Complete script | Boundary | Elapsed change | CPU change | Local warm CLR allocation |",
    "| --- | --- | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    case = row["case"]
    warm = row["lane"] == "warm"
    rows.append(f"| {names[case]} | {'Warm' if warm else 'Compile to result'} | {extent(row['elapsedChangePercent'])}"
                f" | {extent(row['cpuChangePercent'])} | {percent(allocations[case]) if warm else '—'} |")
source = (lab / "report-template.md").read_text(encoding="utf-8")
report = source.replace("{{results}}", "\n".join(rows)).replace("{{decision}}", decision)
(lab / "README.md").write_text(report, encoding="utf-8", newline="\n")
