from pathlib import Path
import json

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/'benchmarks/results/2026-11-24-inline-defaults-cpython'
result=json.loads((out/'summary.json').read_text(encoding='utf-8'))
revision=result['source'][:9]
assert revision=='6b41db7b3' and result['timedBatches']==252
rows={(row['case'],row['lane']):row for row in result['rows']}
rules='scripts.rule-default-closures'
manifest='scripts.config-manifest.small'
text='diagnostic.text-summary.nonlocal-computed-width.large'
invoice='scripts.csv-invoice.method-policy.quoted-control'
classifier=next(case for case in {row[0] for row in rows} if case not in (rules,manifest,text,invoice))
workloads={rules:'Generated rules with defaults',manifest:'Configuration manifest',
    text:'Short Unicode word-count report with a nonlocal helper',invoice:'Quote-heavy CSV policy invoice',classifier:'Generated classifier'}
phase={'warm':'Warm','compile':'Compilation only','compile-run':'Compile-to-result'}

def times(values): return '–'.join(f'{ms:.5f}' for ms in values)+' ms'
def ratios(values): return '–'.join(f'{n:.3f}' for n in values)+'×'
def spreads(row): return f'{row["lythonControlPercent"]:.2f} / {row["cpythonControlPercent"]:.2f}%'
def prefix_status(row):
    spread=max(row['lythonControlPercent'],row['cpythonControlPercent'])
    if spread>=5: return f'Diagnostic. Worker spread up to {spread:.2f}%.'
    if row['ratio'][0]<=1<=row['ratio'][1]: return 'Diagnostic. Ratio spans parity.'
    return 'Diagnostic.'

report=[f'''# B1656 Representative scripts against CPython

This comparison measures Lython `{revision}` and stock CPython 3.13.16 on
November 24, 2026 UTC. The Azure F4as_v7 ran Ubuntu 24.04.4 and .NET 11 RC3.
Each lane uses two warmed workers per engine with seven rotated batches per
worker. Ranges span the four pairings of worker medians. Ratios divide
Lython by CPython elapsed or wider process CPU time.

| Script | Boundary | Lython | CPython | Elapsed ratio | Wider CPU ratio | Elapsed worker spread Lython / CPython |
| --- | --- | ---: | ---: | ---: | ---: | ---: |''']
for (case,lane),row in rows.items():
    report.append(f'| {workloads[case]} | {phase[lane]} | {times(row["lythonMs"])} | {times(row["cpythonMs"])} | {ratios(row["ratio"])} | {ratios(row["widerCpuRatio"])} | {spreads(row)} |')
report.append('''
Warm elapsed covers applicable RAM-backed I/O, verification of output and
files, and disposal of previous results. Lython uses a mediated file host
with efficient ranges and appends plus an active shared allowance. CPython
uses its file APIs. Compilation includes compiled-owner disposal. Time to
result measures both phases inside one request. Wider process CPU includes
fixture reset and request framing. Process startup and final teardown sit
outside these clocks.

The collection uses the exact candidate image from the
[paired comparison](../2026-11-24-inline-positional-default/README.md).
Its committed production source matches the measured patch and reference.
Both machine gates and all 252 batches pass. Complete goldens, worker
identity, CPython identity, worker joins, fixture cleanup and persistent
archive all verify. These figures are diagnostic. The prior broad
[CPython comparison](../2026-11-24-frontend-cpython/README.md) remains dated
and separate.

[Summary](summary.json) · [Identity](identity.json) ·
[Observations](observations.tar.xz) · [Terminal receipt](terminal-status.json) ·
[Procedures](procedures.tar.xz).
''')
(out/'README.md').write_text('\n'.join(report),encoding='utf-8',newline='\n')

file=repo/'docs/BENCHMARKS.md'
doc=file.read_text(encoding='utf-8')
for (case,lane),row in rows.items():
    if case==classifier: continue
    name=workloads[case]
    matching=[line for line in doc.splitlines() if line.startswith(f'| {name}') and '[B1643]. |' in line]
    if lane=='warm':
        matching=[line for line in matching if ' | Compile-to-result | ' not in line and ' | Compilation only | ' not in line]
    else: matching=[line for line in matching if f' | {phase[lane]} | ' in line]
    assert len(matching)==1,(case,lane,matching)
    original=matching[0]
    fields=original.split(' | ')
    assert len(fields)==6,fields
    fields[2:]=[times(row['lythonMs']),times(row['cpythonMs']),ratios(row['ratio']),prefix_status(row)+' [B1656]. |']
    doc=doc.replace(original,' | '.join(fields))
new=rows[classifier,'compile']
anchor=next(line for line in doc.splitlines() if line.startswith('| Generated comprehension rules,'))
source=f'{new["sourceUtf8Bytes"]:,} B of source'
label=workloads[classifier] + ', ' + source
added=' | '.join([f'| {label}', 'Compilation only', times(new['lythonMs']), times(new['cpythonMs']), ratios(new['ratio']), prefix_status(new)+' [B1656]. |'])
doc=doc.replace(anchor,added+'\n'+anchor)
start='two workers per engine. B1643 measures `b9b20aa98` and refreshes the manifest,\nshort report, quoted invoice and defaulted rules in the phases marked in\nthe tables.'
assert start in doc
doc=doc.replace(start,f'''two workers per engine. B1656 measures `{revision}` for the manifest,
short report, quoted invoice, defaulted rules and classifier in the marked
phases. Comprehension compilation uses `b9b20aa98`.''')
doc=doc.replace('[B1643] · [B1633]', '[B1656] · [B1643] · [B1633]')
anchor='[B1643]: ../benchmarks/results/2026-11-24-frontend-cpython/README.md'
assert anchor in doc
doc=doc.replace(anchor,'[B1656]: ../benchmarks/results/2026-11-24-inline-defaults-cpython/README.md\n'+anchor)
file.write_text(doc,encoding='utf-8',newline='\n')