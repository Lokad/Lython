from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
prior = notes/'json-shared-prefix-20261127/comparison'
workers = lab/'comparison'
workers.mkdir()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda p: sha256(p.read_bytes()).hexdigest()
image = lambda p: {f.name: sha(f) for f in p.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
pinned = read(prior/'identity.json')
base = git('rev-parse','HEAD').decode().strip()
assert sha256(git('diff','--binary',pinned['sourceRevision'],base,'--','src')).hexdigest()==pinned['sourcePatchSHA256']
patch = git('diff','--binary',base,'--','src')
assert b'outerFunctions' in patch and patch.count(b'diff --git ')==4
(lab/'candidate.patch').write_bytes(patch)
assert image(prior/'candidate')==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(prior/'candidate',workers/role)
fresh = repo/'src/Lokad.Lython/bin/Release/net11.0'/core
tested = repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(fresh)==sha(tested)!=sha(workers/'reference'/core)
shutil.copyfile(fresh,workers/'candidate'/core)
images = {role:image(workers/role) for role in ('reference','candidate')}
assert all(len(files)==32 for files in images.values())
assert [name for name,digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(prior/name,workers/name)
assert b'\r' not in (workers/'run.sh').read_bytes()
donor = notes/'current-frontend-profile-20261127/local'
catalog = read(donor/'catalog.json')
assert sha(donor/'catalog.json')==read(donor/'identity.json')['profileCatalogSHA256']
ordinary, _, guarded = catalog['cases']
nested = read(prior/'representative.json')['cases'][0]
source = 'totals = {}\n'
for group in range(128):
    source += f"if {group} % 3:\n    totals['recheck'] = totals.get('recheck', 0) + {group}\n"
    source += f"else:\n    totals['ok'] = totals.get('ok', 0) + {group}\n"
source += 'print(sorted(totals.items()))\n'
expected = subprocess.check_output([python,'-I','-X','utf8','-c',source]).decode('utf-8').replace('\r\n','\n')
plain = dict(ordinary, id='diagnostic.generated-guarded-configuration', source=source, expectedOutput=expected,
             size=128, fixtureJson='{"size":128,"text":null}', fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0)
for k, value in [('source',source),('expectedOutput',expected)]:
    plain[k+'Utf8Bytes']=len(value.encode('utf-8'))
    plain[k+'Sha256']=sha256(value.encode('utf-8')).hexdigest()
plain['fixtureSha256']=sha256(plain['fixtureJson'].encode('utf-8')).hexdigest()
catalog['cases']=[ordinary,guarded,plain,nested]
write(workers/'representative.json',catalog)
jobs=[(plain['id'],'compile'),(ordinary['id'],'compile'),(guarded['id'],'compile'),
      (guarded['id'],'compile-run'),(nested['id'],'warm')]
write(workers/'jobs.json',{'warm':jobs})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),productionReference=base,imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=sha(workers/'cpython-worker.py'),independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),
    verificationPythonSHA256=sha(python),purpose='Reuse syntax validation function discovery in name diagnostics. Compare generated modules and definitions.')
identity['catalogs']={name:{'sha256':sha(workers/name)} for name in ('representative.json','jobs.json')}
write(workers/'identity.json',identity)
collector=(prior/'collect.py').read_text(encoding='utf-8').replace('lython-b1889-json-shared-prefix-', 'lython-b1891-name-diagnostic-roots-')
compile(collector,'collect.py','exec')
(workers/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for role, files in images.items():
    report=workers/f'{role}-verify.json'
    subprocess.run([dotnet,workers/role/worker,'--compare','verify','--catalog',workers/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',workers/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
