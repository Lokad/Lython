from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib, json, subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
read=lambda p: json.loads(p.read_text(encoding='utf-8'))
identity=read(quiet/'identity.json')
cfg=read(quiet/'upload.json')
cfg.update(identity=identity, unit='lython-b1794-starmap-known-row-capacity-20261126',
           scripts={name:hashlib.sha256((quiet/name).read_bytes()).hexdigest() for name in ('collect.py','run.sh')})
code="""
from pathlib import Path
import fcntl, hashlib, json, shutil, subprocess
base=Path('/home/lokad/lython-bench-checks')
root=base/cfg['root']
unit=cfg['unit']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert base.resolve()==base and root.resolve()==root and root.parent==base
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=subprocess.check_output(['systemctl','show',unit+'.service',
                                   '--property=LoadState,ActiveState,MainPID'],text=True).splitlines()
    assert 'LoadState=not-found' in state and 'MainPID=0' in state,state
    assert not any((root/name).exists() for name in ('guest-fixtures','confirmation','exit-code.txt'))
    actual=json.loads((root/'identity.json').read_text())
    assert actual==cfg['identity']
    for role,files in actual['imageFiles'].items():
        assert len(files)==32 and {p.name:sha(p) for p in (root/role).iterdir()}==files
    for name,meta in actual['catalogs'].items():
        assert sha(root/name)==meta['sha256']
    for name,digest in cfg['scripts'].items():
        assert sha(root/name)==digest
    assert sha(root/'cpython-worker.py')==actual['cpythonWorkerSHA256']
    python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
    assert sha(python)==actual['expectedCPythonSHA256']
    verified=json.loads((root/'remote-verify.json').read_text())
    assert verified['state']=='Completed' and verified['caseCount']==4
    assert verified['catalogSha256']==actual['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256']==actual['coreSHA256']['candidate']
    free=shutil.disk_usage(base).free
    assert free>=cfg['minimumAfterStageBytes'],free
    print(json.dumps(dict(freeBeforeLaunchBytes=free,verifiedCases=4,imageFiles=[32,32],
                          firstPostStageFreeBytes=8966144,firstLaunch='Stopped before service at disk guard')),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=255','--property=TimeoutStopSec=20','--property=KillMode=control-group',
 '/bin/sh',str(root/'run.sh')],check=True)
"""
key=Path.home()/'.ssh/id_lython-bench.pem'
result=subprocess.run(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
    'lokad@20.166.121.73','python3 -'],input=f'cfg={cfg!r}\n'+code,encoding='utf-8',capture_output=True,timeout=54)
(quiet/'launch.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout,result.stderr)
result.check_returncode()
(quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=166)).isoformat(),encoding='utf-8')
