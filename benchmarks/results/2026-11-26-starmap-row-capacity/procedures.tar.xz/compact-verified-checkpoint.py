from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
sha = lambda b: hashlib.sha256(b).hexdigest()
claims = []
for target, root, unit in (
    ('2026-11-26-starmap-argument-buffer','starmap-argument-buffer-b1793-20261126',
     'lython-b1793-starmap-argument-buffer-20261126'),
):
    relative = 'benchmarks/results/'+target+'/observations.tar.xz'
    backup = repo/relative
    pushed = subprocess.check_output(['git','show','origin/master:'+relative],cwd=repo)
    assert backup.read_bytes() == pushed
    receipt = json.loads((backup.parent/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
    assert receipt['complete'] and receipt['archiveSHA256']==sha(pushed)
    with tarfile.open(backup) as bundle:
        expected = {item.name: sha(bundle.extractfile(item).read()) for item in bundle.getmembers()
                    if item.isfile() and item.name.startswith('confirmation/')}
    assert set(expected)=={'confirmation/confirmation.json','confirmation/fixture-filesystem.txt',
                           'confirmation/machine-after.json','confirmation/machine-before.json'}
    claims.append(dict(root=root, unit=unit, hash=receipt['archiveSHA256'], expected=expected))
script = """
from pathlib import Path
import fcntl, hashlib, json, shutil, subprocess, tarfile

base = Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha = lambda b: hashlib.sha256(b).hexdigest()
reports = []
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    for proof in claims:
        root = base/proof['root']
        expanded = root/'confirmation'
        archive = root/'observations.tar.xz'
        expected = proof['expected']
        assert root.parent==base and root.resolve()==root and expanded.resolve()==expanded
        assert not (root/'guest-fixtures').exists()
        state = subprocess.check_output(['systemctl','show',proof['unit']+'.service',
                                         '--property=ActiveState,MainPID'],text=True).splitlines()
        assert 'ActiveState=inactive' in state and 'MainPID=0' in state
        assert sha(archive.read_bytes())==proof['hash']
        receipt = json.loads((root/'archive-receipt.json').read_text())
        assert receipt['archiveSHA256']==proof['hash'] and receipt['complete']
        assert receipt['guestFixturesRemoved'] and receipt['allWorkersJoined']
        with tarfile.open(archive) as bundle:
            assert {p.relative_to(root).as_posix() for p in expanded.iterdir()}==set(expected)
            for name,digest in expected.items():
                path = root/name
                assert path.parent==expanded and path.resolve()==path and path.is_file()
                assert sha(path.read_bytes())==digest==sha(bundle.extractfile(name).read())

    for proof in claims:
        root = base/proof['root']
        before = shutil.disk_usage(base).free
        for name in proof['expected']:
            (root/name).unlink()
        (root/'confirmation').rmdir()
        assert sha((root/'observations.tar.xz').read_bytes())==proof['hash']
        reports.append(dict(before=before,after=shutil.disk_usage(base).free,proof=proof))
    print(json.dumps(reports))
"""
key = Path.home()/'.ssh/id_lython-bench.pem'
report = subprocess.check_output(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
                                  'lokad@20.166.121.73','python3 -'],
                                 input=f'claims={claims!r}\n'+script,encoding='utf-8',timeout=54)
(lab/'comparison/quiet/disk-custody.json').write_text(report,encoding='utf-8')
for entry in json.loads(report):
    print(entry['proof']['root'],entry['before'],entry['after'])
