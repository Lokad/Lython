from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

lab = Path(__file__).resolve().parent
first = lab / 'comparison/quiet'
repeat = lab / 'comparison/repeat'
repeat.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

base = '/home/lokad/lython-bench-checks'
source = 'starmap-known-row-capacity-b1794-20261126'
name = source + '-repeat'
unit = 'lython-b1794-starmap-known-row-capacity-repeat-20261126'
vm = os.environ['LYTHON_BENCH_HOST']
common = ['-i', os.environ['LYTHON_BENCH_IDENTITY'], '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=12']

def invoke(config, code):
    prefix = f'cfg={config!r}\n'
    return subprocess.check_output(['ssh', *common, vm, 'python3 -'],
                                   input=prefix + code, encoding='utf-8', timeout=57)

config = dict(base=base, source=source, name=name, unit=unit)
paths = """
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess
base=Path(cfg['base'])
source=base/cfg['source']
root=base/cfg['name']
unit=cfg['unit']
assert base.resolve()==base and root.parent==base and root.resolve()==root
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
"""
if sys.argv[1] == 'launch':
    original = read(first / 'identity.json')
    identity = read(first / 'identity.json')
    jobs = json.dumps({'warm': [
        ['diagnostic.shipment-bound-starmap', 'warm-async'],
        ['diagnostic.shipment-starmap-wide-lists', 'warm-async'],
    ]}, indent=2) + '\n'
    identity['catalogs']['jobs.json'] = dict(identity['catalogs']['jobs.json'],
        sha256=hashlib.sha256(jobs.encode()).hexdigest())
    if 'bytes' in identity['catalogs']['jobs.json']:
        identity['catalogs']['jobs.json']['bytes'] = len(jobs.encode())
    collector = (first / 'collect.py').read_text(encoding='utf-8')
    for prior,current in (
        ('len(jobs) == 4','len(jobs) == 2'),
        ('lython-b1794-fixtures','lython-b1794-repeat-fixtures'),
        ('warmupSeconds=5, targetBatchSeconds=.44','warmupSeconds=7, targetBatchSeconds=.62'),
    ):
        assert collector.count(prior)==1,prior
        collector=collector.replace(prior,current)
    assert collector != (first / 'collect.py').read_text(encoding='utf-8')
    compile(collector, 'collect.py', 'exec')
    for filename, data in [('identity.json', json.dumps(identity, indent=2) + '\n'),
                           ('jobs.json', jobs), ('collect.py', collector)]:
        (repeat / filename).write_text(data, encoding='utf-8', newline='\n')
    config.update(identity=identity, original=original, jobs=jobs, collector=collector,
                  archive=sha(first / 'observations.tar.xz'), launcher=sha(first / 'run.sh'))
    outcome = invoke(config, paths + """
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not (source/'guest-fixtures').exists()
 assert source.is_dir() and source.resolve()==source and source.parent==base
 assert shutil.disk_usage(base).free>=8_200_000
 receipt=json.loads((source/'archive-receipt.json').read_text())
 assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
 assert (source/'exit-code.txt').read_text().strip()=='0'
 assert receipt['archiveSHA256']==cfg['archive']==sha(source/'observations.tar.xz')
 assert json.loads((source/'identity.json').read_text())==cfg['original']
 verification=json.loads((source/'remote-verify.json').read_text())
 assert verification['state']=='Completed' and verification['caseCount']==4
 assert verification['catalogSha256']==cfg['identity']['catalogs']['representative.json']['sha256']
 assert verification['launched']['library']['sha256']==cfg['identity']['coreSHA256']['candidate']
 for role,files in cfg['identity']['imageFiles'].items():
  assert len(files)==32 and {p.name:sha(p) for p in (source/role).iterdir()}==files
 assert sha(source/'representative.json')==cfg['identity']['catalogs']['representative.json']['sha256']
 assert sha(source/'cpython-worker.py')==cfg['identity']['cpythonWorkerSHA256']
 assert sha(source/'run.sh')==cfg['launcher'] and b'\\r' not in (source/'run.sh').read_bytes()
 root.mkdir()
 for role in cfg['identity']['imageFiles']: (root/role).symlink_to(source/role,target_is_directory=True)
 for name in ('representative.json','cpython-worker.py','run.sh'): shutil.copyfile(source/name,root/name)
 for name in ('jobs','collector'):
  (root/('jobs.json' if name=='jobs' else 'collect.py')).write_text(cfg[name],encoding='utf-8',newline='\\n')
 (root/'identity.json').write_text(json.dumps(cfg['identity'],indent=2)+'\\n',encoding='utf-8',newline='\\n')
 print(json.dumps(dict(completeImageFilesPerSource=32,casesVerified=4,firstArchive=cfg['archive'],
                       freeBeforeLaunchBytes=shutil.disk_usage(base).free)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=175','--property=TimeoutStopSec=20','--property=KillMode=control-group',
 '/bin/sh',str(root/'run.sh')],check=True)
""")
    (repeat / 'launch.log').write_text(outcome, encoding='utf-8')
    print(outcome)
else:
    assert sys.argv[1] == 'retrieve'
    status = invoke(config, paths + """
state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],
                     capture_output=True,text=True,check=True).stdout
if 'ActiveState=active' in state:
 print(json.dumps(dict(live=True,service=state)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps(dict(live=False,service=state,exitCode=code.read_text().strip() if code.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','32','--no-pager'],capture_output=True,text=True).stdout)))
""")
    (repeat / f'retrieve-{datetime.now(timezone.utc):%H%M%S}.log').write_text(status, encoding='utf-8')
    result = json.loads(status)
    if not result['live']:
        (repeat / 'terminal-status.json').write_text(status, encoding='utf-8')
        if result['receipt']:
            archive = repeat / 'observations.tar.xz'
            subprocess.run(['scp', *common, f'{vm}:{base}/{name}/{archive.name}', archive], check=True, timeout=45)
            assert sha(archive) == result['receipt']['archiveSHA256']
    print(status)
