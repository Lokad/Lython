from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
run = lab / 'local'
project = lab / 'probe'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet, 'build', project / 'CompilerFacts.csproj', '-c', 'Release', '-f', 'net11.0'],
               cwd=project, env=env, check=True, timeout=60)
built = project / 'bin/Release/net11.0'
identity = read(run / 'identity.json')
output = {}
for role in ('reference', 'candidate'):
    destination = run / f'probe-{role}'
    destination.mkdir(exist_ok=True)
    for file in built.iterdir():
        if file.is_file():
            shutil.copyfile(file, destination/file.name)
    core = destination / 'Lokad.Lython.dll'
    shutil.copyfile(run / role / core.name, core)
    assert sha256(core.read_bytes()).hexdigest() == identity['imageFiles'][role][core.name]
    result = destination / 'observed.json'
    command = [dotnet, destination / 'CompilerFacts.dll', run / 'representative.json', result]
    if role == 'candidate':
        command.append(run / 'reference-limits.json')
    subprocess.run(command, cwd=destination, env=env, check=True, timeout=50)
    output[role] = read(result)
    if role == 'reference':
        write(run / 'reference-limits.json', {row['id']: row['testLimits'] for row in output[role]})

reference_cancel = read(run / 'probe-reference/cancellation.json')
assert reference_cancel == read(run / 'probe-candidate/cancellation.json')
assert reference_cancel['afterDispose'] == 0
summary = []
for left, right in zip(output['reference'], output['candidate'], strict=True):
    for key in ('id','peak','growth','testLimits','refusals'):
        assert left[key] == right[key], (left['id'], key)
    names_removed = 0
    prepared_reused = 0
    for before, after in zip(left['tape'], right['tape'], strict=True):
        actual = before['bindingSlots']
        visible = {name: slot for name, slot in actual.items() if not name.startswith('<')}
        assert after['bindingSlots'] == visible, (left['id'], before['name'])
        names_removed += len(actual) - len(visible)
        prepared_reused += bool(after['sharesPreparedMap'] and not before['sharesPreparedMap'])
        ignored = {'bindingSlots', 'sharesPreparedMap'}
        assert {k:v for k,v in before.items() if k not in ignored} == {k:v for k,v in after.items() if k not in ignored}, (left['id'], before['name'])
    summary.append(dict(id=left['id'], scopes=len(left['tape']), removedPrivateBindings=names_removed,
                        additionalSharedMaps=prepared_reused, budgetLevels=len(left['testLimits']),
                        compileClr=[median(left['allocated']), median(right['allocated'])],
                        compiledPeak=left['peak']))
guarded = next(row for row in summary if row['id']=='diagnostic.generated-guarded-report')
assert guarded['additionalSharedMaps'] == 96 and guarded['removedPrivateBindings'] == 192
assert guarded['compileClr'][0] > guarded['compileClr'][1]
write(run / 'compiler-parity.json', dict(cases=summary, cancellation=reference_cancel))
for row in summary[:3]:
    print(row, flush=True)
print(f"{len(summary)} compile cases, {sum(row['budgetLevels'] for row in summary)} budget levels.", flush=True)
