from hashlib import sha256
from pathlib import Path
import json
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
earlier = notes / 'deferred-placement-linearize-20261127'
last = notes / 'iterable-csv-records-20261127'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda text: sha256(text.encode('utf-8')).hexdigest()
base = read(earlier / 'local/representative.json')
ordinary_id = 'diagnostic.generated-ordinary-definitions'
search_id = 'scripts.file-search.large'
guarded_id = 'diagnostic.generated-guarded-report'
ordinary = next(row for row in base['cases'] if row['id'] == ordinary_id)
search = next(row for row in base['cases'] if row['id'] == search_id)

definitions = []
calls = []
for index in range(96):
    bound = index + 8
    definitions.append(f"""def classify_{index}(row):
    quantity = row['quantity']
    if {index} <= quantity < {bound}:
        return 1
    match row['status']:
        case 'hold':
            return -1
        case _:
            return 0
""")
    quantity = (index * 7) % 111
    status = 'hold' if index % 3 == 0 else 'ready'
    calls.append(f"classify_{index}({{'quantity':{quantity}, 'status':{status!r}}})")
source = '\n'.join(definitions) + '\nresults = [\n    ' + ',\n    '.join(calls) + '\n]\n'
source += "print(sum(results), results.count(1), results.count(-1))\n"
output = subprocess.run(['C:/Python313/python.exe', '-X', 'utf8', '-I', '-S', '-'], input=source,
                        check=True, capture_output=True, encoding='utf-8').stdout
fixture = json.loads(ordinary['fixtureJson'])
assert not fixture.get('inputFiles') and not fixture.get('outputFiles')
fixture['size'] = 96
serialized = json.dumps(fixture, ensure_ascii=False, separators=(',', ':'))
guarded = ordinary | dict(id=guarded_id, source=source, size=96, fixtureJson=serialized,
                          sourceUtf8Bytes=len(source.encode('utf-8')), sourceSha256=digest(source),
                          fixtureSha256=digest(serialized), expectedOutput=output,
                          expectedOutputUtf8Bytes=len(output.encode('utf-8')), expectedOutputSha256=digest(output))

def emit(name, text):
    path = lab / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8', newline='\n')

def write(name, data):
    emit(name, json.dumps(data, ensure_ascii=False, indent=2) + '\n')

write('representative.json', base | {'cases': [guarded, ordinary, search]})
write('fixture-census.json', dict(functions=len(definitions), scriptBytes=guarded['sourceUtf8Bytes'],
                                 calls=len(calls), stdout=output))

prep = (last / 'prepare.py').read_text(encoding='utf-8')
for before, after in (
    ("image_base=lab.with_name('inline-whole-regex-match-20261127')/'local'", "image_base=lab.with_name('iterable-csv-records-20261127')/'local'"),
    ("assert head.startswith('6bed7e6c0')", "assert head.startswith('43aef0247')"),
    ("assert pin['sourceRevision'].startswith('3cb9a1240')", "assert pin['sourceRevision'].startswith('6bed7e6c0')"),
    ("file_fed='scripts.csv-summary-functions.large'\nlist_input='diagnostic.csv-summary-list-input'\n"
     "iterator_input='diagnostic.csv-summary-iterator-input'\nquoted='scripts.csv-invoice.method-policy.quoted-control'",
     "ordinary='diagnostic.generated-ordinary-definitions'\nguarded='diagnostic.generated-guarded-report'\nsearch='scripts.file-search.large'"),
    ("{file_fed,list_input,iterator_input,quoted}", "{ordinary,guarded,search}"),
    ("lython-iterable-csv-records-fixture-", "lython-private-compiler-slots-fixture-"),
    ("[[file_fed,'warm-async'],[list_input,'warm'],[quoted,'warm'],[iterator_input,'warm-async']]",
     "[[ordinary,'compile'],[guarded,'compile'],[search,'compile-run'],[guarded,'compile-run']]"),
    ("['git','rev-parse','6bed7e6c0']", "['git','rev-parse','43aef0247']"),
    ("Use existing direct DictReader row admission for list and iterator input. Buffered and quoted inputs are controls.",
     "Keep physical compiler temporaries out of the lexical name map. Ordinary definitions are the control."),
    ("checked['caseCount']==4", "checked['caseCount']==3"),
):
    assert prep.count(before) == 1, before
    prep = prep.replace(before, after)
before = "peak=[r['peakExecutionMemoryBytes'] for r in (before,after)]"
assert prep.count(before) == 1
prep = prep.replace(before, before + ",compiled=[r['compiledReservedBytes'] for r in (before,after)]")
compile(prep,'prepare.py','exec')
emit('prepare.py', prep)
emit('stage.sh', (last / 'stage.sh').read_text(encoding='utf-8').replace('lython-iterable-csv-records-', 'lython-private-compiler-slots-'))
emit('summarize.py', (last / 'summarize.py').read_text(encoding='utf-8'))

probe = (earlier / 'probe/Program.cs').read_text(encoding='utf-8')
source_additions = '''sources.Add("namespace-protected-temporaries", """
    class Manager:
        def __enter__(self): return 7
        def __exit__(self, *args): return False
    def factory(manager, first):
        with manager as value:
            result = 0 < first < value
            def read():
                return value, result
            return read, locals()
    print(factory(Manager(), 2)[0]())
    """);
sources.Add("nested-protected-match-and-comprehension", """
    def records(values):
        for number in values:
            match number:
                case int() if 0 < number < 4:
                    yield number
    print(list(records([0, 1, 3, 4])))
    """);
'''
probe = probe.replace('var results = sources.Select(pair =>', source_additions + 'var results = sources.Select(pair =>')
probe = probe.replace('    return new { id = pair.Key, peak = stablePeak, growth, testLimits, tape, refusals };',
'''    for (var i = 0; i < 8; i++)
        using (var warm = engine.Compile(pair.Value))
            if (!warm.IsValid) throw new InvalidOperationException("Compilation warmup failed.");
    var allocated = new long[17];
    for (var i = 0; i < allocated.Length; i++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        using (var script = engine.Compile(pair.Value))
            if (!script.IsValid) throw new InvalidOperationException("Compilation diagnostic changed during measurement.");
        allocated[i] = GC.GetAllocatedBytesForCurrentThread() - before;
    }
    return new { id = pair.Key, peak = stablePeak, growth, testLimits, tape, refusals, allocated };''')
probe = probe.replace('locals = Read(code, "LocalNames"), closureNames = Read(code, "ClosureNames"),',
'''locals = Read(code, "LocalNames"), closureNames = Read(code, "ClosureNames"),
        bindingSlots = Read(code, "LocalNameToSlot"),
        sharesPreparedMap = ReferenceEquals(Read(code, "LocalNameToSlot"),
            Read(Read(code, "ScopeFacts")!, "PreparedLocalSlots")),''')
assert probe.count('sharesPreparedMap') == 1 and probe.count('AllocatedBytesForCurrentThread') == 2
emit('probe/Program.cs', probe)
project = (earlier / 'probe/CompilerFacts.csproj').read_text(encoding='utf-8')
emit('probe/CompilerFacts.csproj', project.replace('../reference/', '../local/reference/'))
