set -eu
lab="$1"
source="$lab/local"
target=$(mktemp -d "$HOME/lython-private-compiler-slots-repeat-XXXXXX")
for item in reference candidate representative.json identity.json cpython-worker.py run.sh collect.py; do
    cp -r "$source/$item" "$target/$item"
done
python3 - "$target" "$source/affinity.txt" <<'PY'
from hashlib import sha256
from pathlib import Path
import json
import os
import sys
import time

root=Path(sys.argv[1])
previous=int(Path(sys.argv[2]).read_text(encoding='ascii').strip())
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for role, manifest in identity['imageFiles'].items():
    observed={path.name:sha256(path.read_bytes()).hexdigest() for path in (root/role).iterdir()}
    assert observed==manifest,role
jobs={'warm':[
    ['diagnostic.generated-guarded-report','compile-run'],
    ['diagnostic.generated-ordinary-definitions','compile'],
    ['diagnostic.generated-guarded-report','compile'],
]}
(root/'jobs.json').write_text(json.dumps(jobs)+'\n',encoding='utf-8')
identity['catalogs']['jobs.json']['sha256']=sha256((root/'jobs.json').read_bytes()).hexdigest()
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
collector=root/'collect.py'
source=collector.read_text(encoding='utf-8')
assert source.count('len(jobs) == 4')==1
collector.write_text(source.replace('len(jobs) == 4','len(jobs) == 3'),encoding='utf-8')
assert b'\r' not in (root/'run.sh').read_bytes()
allowed=os.sched_getaffinity(0)-{previous}
assert allowed
def counters():
    result={}
    for line in Path('/proc/stat').read_text(encoding='ascii').splitlines():
        key,*fields=line.split()
        if key.startswith('cpu') and key[3:].isdigit() and int(key[3:]) in allowed:
            amounts=list(map(int,fields[:8]))
            result[int(key[3:])]=(sum(amounts), amounts[3]+amounts[4])
    assert set(result)==allowed
    return result
before=counters()
time.sleep(1.0)
after=counters()
busy={}
for cpu in sorted(allowed):
    total=after[cpu][0]-before[cpu][0]
    idle=after[cpu][1]-before[cpu][1]
    assert total>0
    busy[cpu]=1-idle/total
cpu=min(busy,key=lambda index:(busy[index],index))
(root/'affinity.txt').write_text(f'{cpu}\n',encoding='ascii')
(root/'affinity-observations.json').write_text(json.dumps(dict(previous=previous,chosen=cpu,busy=busy),indent=2)+'\n',encoding='utf-8')
PY
printf '%s\n' "$target"
cpu=$(cat "$target/affinity.txt")
taskset --cpu-list "$cpu" sh "$target/run.sh"
