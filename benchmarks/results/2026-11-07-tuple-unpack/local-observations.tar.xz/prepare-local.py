from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;target=r/'images/candidate';shutil.copytree(r/'images/before',target,copy_function=os.link)
(target/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
shutil.copyfile(target/'Lokad.Lython.dll',r/'current-core.dll')
catalog=json.loads((r.parent/'returned-record-calls-r69/representative.json').read_text(encoding='utf-8'))
ids=['scripts.csv-validated-records.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==i) for i in ids];assert len(catalog['cases'])==5
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='fd5ab1c1 plus R70 immutable tuple unpack borrowing',baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8')),
    coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate']},
    productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not any(x in ['bin','obj'] for x in p.parts)})
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
for name,prior in [('measure.py','admission-reentry-r53'),('assess-local.py','buffered-lines-r66')]:shutil.copyfile(r.parent/prior/name,r/name)
print(json.dumps(identity['coreSHA256']))
