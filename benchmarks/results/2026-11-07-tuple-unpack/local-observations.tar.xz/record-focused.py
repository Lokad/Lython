from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent
checks={}
for name,count in [('baseline-final-ordinary-net11',24),('internal-net11',824),('internal-net10',824),('public-net11',1104),('final-ordinary-net11',24),('public-net10',1106)]:
    log=(r/(name+'.log')).read_text(encoding='utf-8');match=re.search(r'Passed!\s+- Failed:\s+0, Passed:\s+(\d+)',log);assert match and int(match[1])==count,name
    checks[name]=dict(passed=count)
for target in ['net11.0','net10.0']:
    core=Path('src/Lokad.Lython/bin/Release')/target/'Lokad.Lython.dll'
    assert hashlib.sha256(core.read_bytes()).digest()==hashlib.sha256((Path('tools/LythonProbe/bin/Release')/target/'Lokad.Lython.dll').read_bytes()).digest()
(r/'focused.json').write_text(json.dumps(dict(checks=checks,matchingProbes=True,net11UnionPublic=1106,
    note='Initial1104public plus24final ordinary checks include2new refusal/reuse cases; net10full focused filter includes all1106. All24final ordinary regressions also pass on the baseline runtime.',
    finalLoadedCores={t:hashlib.sha256((Path('src/Lokad.Lython/bin/Release')/t/'Lokad.Lython.dll').read_bytes()).hexdigest() for t in ['net11.0','net10.0']}),indent=2)+'\n',encoding='utf-8')
print('824internal/1106public union per actual target, matching probes, baseline24 verified.')
