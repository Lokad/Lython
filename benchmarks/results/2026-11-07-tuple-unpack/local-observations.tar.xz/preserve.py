from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-tuple-unpack');out.mkdir(exist_ok=True)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete'] and receipt['jobs']==4
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','vm-identity.json','assessment.json','local-assessment.json','focused.json','pre-code-plan.md','contract.md']:
    shutil.copyfile(r/name,out/name)
with tarfile.open(out/'local-observations.tar.xz','w:xz') as a:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.log','.md','.patch']:a.add(p,arcname=p.name)
    for folder in ['warm-sync','warm-async']:a.add(r/folder,arcname=folder)
    a.add(r/'images/before/Lokad.Lython.dll',arcname='baseline-core.dll')
    a.add(r/'current-core.dll',arcname='current-core.dll')
    a.add('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',arcname='current-net10-core.dll')
raw=json.loads((r/'assessment.json').read_text(encoding='utf-8'))
table='| Complete job | Elapsed change across all process pairs | Baseline / current spread |\n| --- | ---: | ---: |\n'
for row in raw['jobs']:
    values=[v for vv in row['elapsedPercent'].values() for v in vv]
    table+=f"| {row['case'].removeprefix('scripts.')} / {row['lane']} | {min(values):+.2f} to {max(values):+.2f}% | {abs(row['baselineSpreadPercent']):.2f}% / {abs(row['candidateSpreadPercent']):.2f}% |\n"
(out/'README.md').write_text('''# Immutable tuple unpack transport — R70/B423

2026-11-07. Retained production change onfd5ab1c1; measured candidated6445fc5
(.NET11) /4b3fda59(.NET10). Exact source inventory/patch retained. Public API and
Python semantics unchanged; fewer unnecessary scratch admissions can avoid earlier
conservative rejection. This does not promise identical tiny-budget thresholds.

Exact builtin tuples already own immutable storage. Unpacking now borrows that
tuple directly, eliminating its checked iterator chain, leased List, backing copy
and shell/capacity reservation. A small local value retains either that owner or
the existing snapshot lease. Mutable/user-protocol sources still snapshot; starred
remainders admit their own capacity before target effects. No new budget, ledger,
pool, cached owner, policy or execution route. Sync/async assignments, loops,
annotations and JSON separators use the same immutable-storage rule. Existing
error translation remains for other inputs; no tuple-subclass protocol bypass.

**824internal/1,106public union per actual.NET11/10 pass**, with matching probes.
The first net11public run has1,104cases;24final ordinary tests include2new refusal/
reuse cases, yielding1,106distinct cases. All24final ordinary regressions pass on
the baseline core35cd0db3. Tuple/list controls preserve real target suspension,
cancellation, retained starred aliases, first terminal refusal despite finally
return, stopped target effects and shared-budget reuse. General iterator tail,
arity, generator, JSON and admission/ownership checks remain. No timeout/assertion
relaxation or architecture-only test replacement.

## Allocation / desktop diagnostic

Existing five-script driver, independent before/current/before-control assemblies
sharing process GC/CoreLib/hashing, both APIs and normal GC/tiering. All goldens,
shared balances, image isolation and owned fixture cleanup pass. Returned-record
CSV allocation **−13.57%sync /−14.40%async**; ordinary CSV/text/JSON/report allocation
is essentially unchanged. Desktop clocks are diagnostic: affected sync−5.97to+10.02%
with14.53%old-role drift, async−7.15to−1.50%; text is adverse+9.42–9.98%sync and
+5.31–8.34%async. Other adverse/variable controls remain in raw data. No desktop
CPU claim, discarded observation or causal explanation of that text result.

## Controlled complete-script source pair

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, unchanged7cf37ca5 manifest worker and
normal optional0.4adapter. Baseline15c04e2a matches fully qualified824fc6bb source;
local baseline35cd0db3 has the same production source andfd5ab1c1 metadata.
Two independent baseline/two current processes,5s warmup/role/job and7rotated150ms
rounds. **Four jobs complete in114.59seconds**. Negative elapsed means faster.

'''+table+'''
Affected elapsed improves across both candidate processes. The ordinary CSV/text
controls stay near baseline; this does not reproduce the adverse desktop text
result, whose cause remains unresolved. Preserve CSV+0.28%elapsed and+4.07%coarse
processCPU observations. Affected CPU direction is favorable but its10ms ticks,
outside-job protocol work and process variation do not establish a precise CPU
gain. No universal speedup, CPython multiplier or historic debt repayment claim.
Retain the complete storage-phase deletion and independently measured allocation/
controlled elapsed benefit. Larger ordinary call/frame consolidation stays open.

Warm includes public invocation, mediated RAM-file I/O, complete stdout/file
validation and prior-result cleanup; compile/startup/staging/reset/transport/final
cached teardown excluded. Desktop includes fixture reset/result disposal and must
not be compared by absolute time. Async uses completed host I/O here; real target
suspension is separately tested. No startup/RSS/pending-I/O/embedding-tail claim.

All source/actualReady/auxiliary/golden/quiet/Closed/exit/join/empty-fixture gates
pass. Persistent workers/records remain separate from the owned128MiB RAM fixtures;
all users finish and the mount is removed before archive verification under lease
and independently locally.150sowner+30stop+30margin; staging315,863,040B passes,
no reclaim or restart. Initial early local observation guard refused before any
service query; the same completed collection was subsequently retrieved once.

Full Windows/Ubuntu, original Stress and installed-package delivery is pending
for this new source; baseline's green receipt does not qualify it. Publication
postponed. B423 terminal/archived/verified; never query it again.

[Controlled assessment](assessment.json), [allocation/adverse desktop observations](local-assessment.json),
[focused checks](focused.json), [source/image identities](identity.json),
[VM identities](vm-identity.json), [pre-code plan](pre-code-plan.md), [contract](contract.md),
[VM archive](observations.tgz), [receipt](archive-receipt.json),
[local source/cores/tests/raw observations](local-observations.tar.xz).
''',encoding='utf-8')
receipt['localArchiveSHA256']=hashlib.sha256((out/'local-observations.tar.xz').read_bytes()).hexdigest()
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Immutable tuple unpack transport

[R70/B423](results/2026-11-07-tuple-unpack/README.md) removes exact tuple
unpacking's iterator/list/backing/reservation phase, retaining mutable/protocol
snapshots and funded starred storage.824internal/1,106public union per actual11/10,
matching probes and24public baseline regressions pass. Existing five-script
diagnostic: returned-record allocation−13.57%sync/−14.40%async, controls flat;
desktop text+9–10%sync/+5–8%async retained. Four-process VM pair114.59s/allgates:
affected elapsed−6.45–7.45%sync/−7.01–9.34%async; ordinary CSV+0.06–0.28%,
text−0.15–0.96%, coarseCPU mixed/controlCSV+4.07%. Retain complete-phase removal,
allocation and controlled affected elapsed; no universalCPU/CPython/debt claim.
New source full delivery pending; publication postponed. B423 terminal archived/
verified; no restart or additional collection. Larger activation roadmap stays open.
''',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');anchor='| Shared buffered-line execution'
s=s.replace(anchor,'| Immutable tuple unpacking / returned-record CSV | Allocation −13.57%sync/−14.40%async; controlled warm elapsed −6.45–7.45%sync/−7.01–9.34%async | Ordinary controls near baseline; adverse desktop text preserved, full new-source delivery pending. [R70](../benchmarks/results/2026-11-07-tuple-unpack/README.md) |\n'+anchor)
p.write_text(s,encoding='utf-8')
for p in [out/'README.md',Path('docs/BENCHMARKS.md')]:
    for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if '://'not in target and not target.startswith('#'):assert (p.parent/target.split('#',1)[0]).exists(),(p,target)
print('Retained exact tuple transport; all source/archive/link/measurement gates verified.')
