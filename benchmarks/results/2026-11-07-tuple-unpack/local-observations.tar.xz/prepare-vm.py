from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'buffered-lines-r66'
local=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in local['productionSources'].items())
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
ids=['scripts.csv-validated-records.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large']
catalog['cases']=[c for c in catalog['cases'] if c['id'] in ids]
(r/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
jobs=[(ids[0],'warm'),(ids[0],'warm-async'),(ids[1],'warm'),(ids[2],'warm')]
prior=json.loads((r.parent/'checkpoint-cpython-r67/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=local['sourceRevision'],sourcePairBaseline='824fc6bb fully qualified production/core15c04e2a; local baseline35cd0db3 has identical production sources but fd5ab1c1 metadata.',
    coreSHA256={'reference':prior['coreSHA256']['candidate'],'reference-control':prior['coreSHA256']['candidate'],'candidate':local['coreSHA256']['candidate'],'candidate-control':local['coreSHA256']['candidate']},
    auxiliaryFiles=prior['auxiliaryFiles'],productionSources=local['productionSources'],jobs=jobs,
    included='Public warm Run/RunAsync, mediated RAM I/O, complete goldens/prior-result cleanup; startup/compile/staging/reset/transport/final teardown excluded.')
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
def adapt(s):return s.replace('buffered-lines-b420','tuple-unpack-b423').replace('lython-b420-buffered-lines','lython-b423-tuple-unpack').replace('lython-b420-fixtures','lython-b423-fixtures')
def save(name,s):
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
s=adapt((old/'collect.py').read_text(encoding='utf-8'));a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
s=s.replace('targetBatchSeconds=.20, rounds=11','targetBatchSeconds=.15, rounds=7').replace('count*.20','count*.15').replace('range(11)','range(7)').replace('started < 210','started < 120').replace('R66 buffered-line sync/async source-pair confirmation; R65 included, compile and fresh separate, warm text control','R70 immutable tuple unpack transport; affected sync/async and ordinary CSV/text controls')
save('collect.py',s)
for name in ['archive-owned.py','run.sh','retrieve.py','launch.py','assess-vm.py']:
    s=adapt((old/name).read_text(encoding='utf-8')).replace('==6','==4').replace('jobs=6','jobs=4')
    if name=='launch.py':
        s=s.replace("reference=base/'syntax-validation-b418-20261107/candidate'", "reference=base/'checkpoint-cpython-b421-20261107/candidate'")
        s=s.replace('allSixJobsValidated','allFourJobsValidated').replace('ownerSeconds=240','ownerSeconds=150').replace('RuntimeMaxSec=240','RuntimeMaxSec=150').replace('seconds=300','seconds=210')
    save(name,s)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
shutil.copyfile(r/'source.patch',r/'vm-source.patch')
(r/'setup-contract.json').write_text(json.dumps(dict(minimumPersistentFreeBytes=256*1024*1024,ownedFixtureCapacityBytes=128*1024*1024,sourcePairJobs=4,ownerSeconds=150,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
(r/'contract.md').write_text('''R70/B423 one bounded complete-source comparison after immutable tuple unpack transport removal: returned-record CSV warm/warm-async; ordinary CSV and text warm controls. Two baseline/two candidate processes,5s warmup/role/job,7rotated150ms rounds, normal GC/tiering on quiet F4as_v7. Reuse exact qualified15c04e2a baseline/unchanged manifest worker/normal0.4 adapter, transfer one candidate core; local allocation diagnostic uses equivalent-source fd5ab1c1-metadata baseline35cd0db3 and separate clocks. Include public invocation, mediated RAM I/O, all goldens and prior-result cleanup; exclude compile/startup/staging/reset/transport/final teardown. Retain all process/IQR/adverse/quantized CPU results; no CPython table refresh, predicted saving or fixed percentage veto. Preserve immutable sources/cores/fixtures and loaded Ready identities. Source/golden/quiet/Closed/exit/join/emptyfixtures/archive gates, persistent records/workers separate from owned128MiB RAM fixtures,256MiB staging floor.150s owner+30stop+30margin, observe210s, no timeout restart. Join all users/unmount then archive under lease and independently locally. Retain/restored source plus explicit debt decision; full delivery batched at coherent boundary, publication postponed.
''',encoding='utf-8')
files=['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','focused.json','contract.md']
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for n in files:t.add(r/n,arcname=n)
    t.add(r/'vm-identity.json',arcname='identity.json');t.add(r/'vm-source.patch',arcname='source.patch')
print('Four-job current source pair prepared; baseline15c04e2a, candidate'+local['coreSHA256']['candidate'][:8])
