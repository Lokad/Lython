from pathlib import Path
import os,shutil,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
def run(name,args):
    with (r/(name+'.log')).open('w',encoding='utf-8') as log:done=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=log,stderr=subprocess.STDOUT)
    text=(r/(name+'.log')).read_text(encoding='utf-8');print(name,done.returncode,text[-1100:],flush=True);assert done.returncode==0
target=r/'tests-before';shutil.copytree('tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0',target,copy_function=os.link)
(target/'Lokad.Lython.dll').unlink();shutil.copyfile(r/'images/before/Lokad.Lython.dll',target/'Lokad.Lython.dll')
run('baseline-final-ordinary-net11',['vstest',str(target/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~OrdinaryUnpackingTests'])
run('probe-net10',['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net10.0'])
run('internal-net10',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net10.0','--filter','(FullyQualifiedName~Unpacking|FullyQualifiedName~Assignment|FullyQualifiedName~Starred|FullyQualifiedName~Json|FullyQualifiedName~Generator|FullyQualifiedName~Ownership)&Category!=Stress','--logger','console;verbosity=minimal'])
run('public-net10',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net10.0','--filter','(FullyQualifiedName~Unpacking|FullyQualifiedName~AssignmentTarget|FullyQualifiedName~Starred|FullyQualifiedName~Json|FullyQualifiedName~HeaderAssignment|FullyQualifiedName~ComparisonFileWorkerTests)&Category!=Stress','--logger','console;verbosity=minimal'])
