from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;prior=r.parent/'buffered-lines-r66/images/candidate'
image=r/'images/before';shutil.copytree(prior,image,copy_function=os.link)
(image/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
baseline=dict(sourceRevision='fd5ab1c1, production unchanged from fully qualified824fc6bb',coreSHA256=hashlib.sha256((image/'Lokad.Lython.dll').read_bytes()).hexdigest(),
    publicBaselineRegressionsPassed=22,net11=True,productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not any(x in ['bin','obj'] for x in p.parts)})
(r/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-code-plan.md')
print(baseline['coreSHA256'])
