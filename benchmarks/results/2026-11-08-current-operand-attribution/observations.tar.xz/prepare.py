from pathlib import Path
import ast,gzip,hashlib,json,math,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'ordinary-helper-r84';current=r.parent/'shared-cased-split-r92';b=current/'b453'
source=json.loads((current/'identity.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
d=json.loads((current/'catalog.json').read_text());d['cases']=[c for c in d['cases']if c['id']=='scripts.text-summary-rsplit-helpers.large'];assert len(d['cases'])==1
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=json.loads((b/'archive-receipt.json').read_text());assert receipt['complete']and hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
proof=dict(vmArchive='shared-cased-split-b453-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=source['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-shared-cased-split/observations.tar.xz (nested B453 archive)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='05d81b83',files={'Lokad.Lython.dll':source['coreSHA256']['candidate']},auxiliaryFiles=json.loads((b/'identity.json').read_text())['auxiliaryFiles'],productionSources=source['productionSources'],qualification='Focused semantics/ownership per actual11/10 pass; full delivery dispatched09:28:59UTC and independent.',purpose='One current ordinary-helper complete-script CPU trace after a bounded source gate; no normal-settings timing claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(current/'source.patch',r/'source.patch');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');shutil.copyfile(r/'selection.md',r/'contract.md');shutil.copyfile(r/'source-gate.md',r/'source-gate-evidence.md')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('ordinary-helper-cost-b447','current-operand-cost-b454').replace('lython-b447-ordinary-helper-cost','lython-b454-current-operand-cost').replace('lython-b447','lython-b454')
 if name=='launch.py':s=s.replace("source=(base/'combined-cpython-b446-20261108/candidate').resolve()","source=(base/'shared-cased-split-b453-20261108/candidate').resolve()")
 if name=='archive.py':s=s.replace('verified immutable B446 archive','verified immutable B453 archive')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
raw=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved').rglob('*')if p.is_file()and p.name!='current-core.dll')
estimate=math.ceil((raw+(old/'observations.tgz').stat().st_size)*1.25)
assert estimate<8*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,conservativeTraceArchiveEstimateBytes=estimate,reservedHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024,noEvidenceDeleted=True,archivedCoreReused=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md','source-gate-evidence.md']:a.add(r/name,arcname=name)
print('One6s current CPU trace prepared; measured prior raw+archive footprint+25% fits8MiB. No new core or framework.')
