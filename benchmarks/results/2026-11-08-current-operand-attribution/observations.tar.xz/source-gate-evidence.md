# R93 remaining complete call/frame phase — source gate

Inspected once during R92 delivery at05d81b83; no new runtime prototype selected.

- Calls/CallBinder.cs: ordinary argument presence lives in one inline64-bit word;
  only unusually wide signatures allocate overflow. No parallel small bool array.
- LythonRuntime.Calls.Binding.cs: positional calls copy existing operands directly
  once into final execution-owned cleared workspace; defaults are read live.
  Binding failure returns that workspace. General/keyword paths retain semantics.
- LythonRuntime.Executable.cs CreateExecutableWorkState: bound storage is already
  function locals; executable operand storage borrows that array. No separate
  second local array/copy to delete. Closure cells have their actual lifetime.
- LythonRuntime.Executable.Calls.cs BeginBoundCall: a native proof is not repeated
  after an attempted native call. Ordinary code starts with a local workstate and
  definition scope, promoting lexical context only at a genuine requirement.
  Cleanup precedes return/refund; real suspensions keep active workspace funded.
- PyFunctionBase InvokeBound remains needed for general callback/iterator routes;
  deleting it in favor of the immediate executable runner would broaden the
  redesign and must preserve guest protocols, generators, annotations and errors.

R86 CSV attribution(binding/work3.56%self/4.27%inclusive) and R88 source-shape
diagnostics do not demonstrate a dominant redundant binding/activation phase.
R71 arena/control/wide-carrier slowdowns remain relevant. Do not manufacture a
new pooled packet, refcount/owner inventory or tagged-value project from these
sources. No entire duplicated common phase remains to remove in this gate.

Next bounded action: one current complete ordinary text-helper CPU trace. R84
predates R89 and R92; no stable current attribution for choosing the next broad
execution/operand versus text phase. Current R90 comparison is1.80×CPython for
this unchanged source. A six-second CPU-clock/FP trace plus source inspection
may select a removable complete phase or conclude evidence is insufficient.
No new warm timing/CPython refresh or universal attribution from method names.
