# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment does not finish that objective. Active work below;
historical narratives, rejected designs, original failed conditions and raw data
stay in benchmarks/EXPERIMENTS.md and results. Docs describe current implementation.

## Actual delivery status

| Milestone | Actual status |
| --- | --- |
| Compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed/fully qualified. Native returns allocation−19.92/−19.31%, original elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original15.125ms adverse remains unexplained/preserved. No unchanged qualification replay. |
| Retained R62–R76 | Fully qualified; history preserves70267889,824fc6bb,7a81a629,f88191f7+a34f56b5,68d5bffe,33b6c191,79657355+c384956f,38f53c33/06651b11. Compiler facts/native calls/sequence/tuple storage, JSON floats, inline/final UTF-8 storage remain. R71 slower arenas/control/wide carriers, R72 coarseCPU+6.67%, R74 drift and all failed/adverse conditions remain evidence, not current performance claims. |
| R78/R79 | Fully qualified af481194+5b9d569a and913ea550: shared receiver declarations, callback/signature correctness fixes, native workstate before lexical contexts. Existing measured function optimizations preserved. Cached full-delivery receipts; details in EXPERIMENTS/results. |
| R80/R81 attribution; R82 prepared consumers | Attribution/source gates completed71445454; no unsupported namespace/value/accounting redesign selected. R82 production91f15a3e fully qualified CI42451722109; source consistency retained, allocation neutral, modest/mixed elapsed. |
| R77/R83 CPython checkpoints | Completed historical named-source38f53c33/91f15a3e comparisons; prior tables, inconclusive cases and failed conditions preserved. Current guide is R90 below. |
| R84/R85 | Canonical receivers02c76e52/coreaa4acebe, corrected7796a24f/corecc6b1b15 fully qualified CI42459221409. Failed original CI42457767068/logs retained. Corrected allocation45–52%lower; controlled elapsed22–24%lower belongs to earlier aa4, not cc6. Controls/debt remain explicit in results. |
| R86/R87/R88 | Complete CSV/helper/generated-code source gates committed7796a24f+16e14ee0; B449 terminal/archived/verified. No binder dominance or causal CPU claim. Existing record adoption/keys/batched fields remain. Text source-shape diagnostic selected the next coherent preparation cleanup, not a new arena/engine. |
| R89 | Committed/pushedac5aea97/core6a098198, fully qualified CI42463155006.397internal/2165public focused per actual11/10, both OSes/originalStress/installed core green. B451 affected elapsed−11–19%, CPU agrees, allocation neutral. Fused/report inconclusive, possible CSV+0.42–1.03% debt accepted. All initial/refined/adverse source/evidence preserved. |
| R90 | B452 complete:26jobs538.681s at committedac5aea97/core6a098198, CPython3.13.16. All gates/archive/local verification pass; no active users/fixtures. Current primary guide updated: separate compile/warm/result and I/O/cleanup, exact machine/source. Warm rsplit1.80×, guarded2.15×; other ordinary warm about1.00–1.67×. No single-change attribution or objective closure. |
| R91 source gate | Ordinary integer formatting already native UTF-8 on11/stack bridge10; valid escaped JSON already CopyString UTF-8. Large-integer JSON conversion remains outside ordinary fixtures. Builtin slots retain per-run owner/live namespace identity, so simple global sharing is invalid. No new cache/lazy-owner subsystem or prototype selected from this pass. |
| R92 | Committed/pushed05d81b83/core68f63d29, full delivery running (dispatched09:28:59UTC; first check>=09:33:59). Shared existing casing/split recipe replaces both native-only fused variants.128 public semantics/24 ownership per actual11/10 and3859 public11 pass. B453168.220s terminal/archived/locally verified; guarded allocation−12.74%, elapsed sync−3.48to−4.84%/async−6.78to−8.01%, CPU agrees. Fused/rsplit inconclusive, CSV−0.26to+1.07% possible debt, frontend elapsed unstable. All original desktop adverse results retained. No whole-goal closure. |
| Regex R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only. Normal optional0.4 pin/core unchanged; affected final released adapter qualification pending, independent implementation continues. |

Completed milestones and original evidence remain in benchmarks/EXPERIMENTS.md
and linked results; the table is delivery status, not a replay queue.
Latest fully qualified runtimeac5aea97, CI42463155006 green/cached09:02UTC:
Windows/Ubuntu actual11/10, originalStress and installed core consumers. Prior
CI42459221409/42457767068 and B450/B451/B452 are terminal/cached; never requery.
Never requery/re-dispatch terminal runs or imply that this qualifies later changes.
Allocation reduction, elapsed, coarseCPU and embedding latency are distinct.
R76's float debt and R79's CSV debt are separately accepted; unrelated gains do
not repay them. Preserve native-text/report/control uncertainty and adverse originals.

## Active deliverables

0. **R93: remaining call/frame phase source gate, then current attribution.**
   During R92 delivery, inspect the complete ordinary argument/binding/workstate
   lifetime once (~20min). Do not revive pooled arenas/control carriers. Preliminary
   source shows inline presence bits, one operand-to-final-workspace write, bound
   storage reused as locals and deferred lexical contexts already exist. Verify
   whether a whole duplicated phase remains; otherwise close with specific source
   evidence instead of proposing another packet/flag path. Existing CSV profile
   shows only distributed binding/frame costs, not dominance. If the gate selects
   no removable phase, one short current guarded/ordinary text CPU trace may locate
   the next coherent boundary. Preserve profile overhead/unknown/inlining limits;
   no timing claim from a trace. Bounded trace/source assessment, not a campaign.
   A selected redesign must name displaced implementation, affected complete
   scripts, semantic/cancellation/ownership checks and one controlled source pair.
   Temporary debt needs an explicit retain/correct/reject completion decision.

1. **R92: shared preparation for existing composed receiver calls.** First bounded
   source-design gate, then the smallest coherent migration if the gate supports it.
   R90 guarded helper is2.15×CPython; it checks line.isspace() then returns
   line.lower().split(). Its branch prevents the closed-body shortcut, so the
   ordinary engine still materializes the intermediate lowercase string and
   dispatches both calls. This extra predicate/algorithm differs from the fused
   helper: the ratio does not isolate fusion or function overhead.

   Hypothesis: reuse one immutable preparation for the existing lower/upper→split
   kernel through ordinary call metadata and native bodies, independent of whole-
   function straight-line eligibility. Eliminate intermediate storage and duplicate
   dispatch while deleting the old native-only fused op kinds/span/type branches.
   Preserve original executable instructions as the pre-effect dynamic path when
   exact native receiver/canonical-declaration proof fails. No fallback/retry after
   work, new kernel/name-marker series, engine, pool, owner or public option.

   Source gate (~30min, one design pass): verify existing mutable builder/call-site
   preparation can carry this small immutable recipe without another execution
   framework. Distinguish ephemeral immediate chains from forwarded locals whose
   binding remains observable on ordinary execution. Retain exact source spans,
   physical output/local-result publication, exception-region routing, managed
   stack admission and awaited operand cleanup. If this requires broad compiler/
   ownership redesign, stop the gate with the specific tradeoff and select another
   following boundary; do not retain dormant scaffolding or both fusion routes.

   Source gate accepted: prepare one immutable casing/split recipe on existing
   call sites before operand layout. Attach it to both calls only for immediate
   chains; forwarded-local native bodies retain the recipe only on the final
   call. Ordinary execution guards the original exact receiver/canonical method,
   executes once, and publishes through the final call's unchanged result slot.
   The native body uses the same recipe; delete both old fused operation kinds
   and their separate span/evaluation selection. No new kernel or runtime owner.

   Acceptance before timing: native/dynamic receivers, Unicode expansion/final
   sigma/whitespace, branches and protected cleanup, evaluation/error ordering,
   callable metadata/arity, real async protocols, current cancellation, first
   terminal refusal, retained aliases and budget reuse. Use existing focused
   Release tests plus genuine uncovered regressions. One short allocation/source
   comparison and bounded normal-settings VM pair: guarded ordinary text affected,
   existing fused text/rsplit/CSV/report controls. Record architectural removal,
   allocation, elapsed/CPU and control debt separately; allow justified refinement,
   not a fixed-percentage veto. Completion includes removal of displaced native
   machinery, current docs and one retained-source delivery checkpoint.

2. **Continue the substantial roadmap.** R89/R90 are closed milestones, not
   completion of the performance objective. Complete call/frame construction,
   operand transport, record construction, remaining bulk conversion and frontend
   analysis remain evidence-led boundaries below. R86–R88 show distributed costs,
   not binder dominance; do not revive arenas/control carriers or universal values
   from boxing alone. Existing CSV row/key adoption and batched storage remain.
   R91 source gate prevents repeating completed UTF-8 work or sharing owned type
   metadata incorrectly. Select a complete removable phase and bounded acceptance;
   no open-ended measurement/ownership audit. No new CPython refresh after every
   tweak: R90 is the current coherent checkpoint, with historical evidence linked.

3. **Independent regex track.** Core contract/native UTF-8 implementation stays
   independent. Missing producer publication defers only affected final adapter
   qualification; it does not block core correctness or non-regex implementation.
   Exact dev55 packages unchanged08:04UTC; do not repeat unchanged qualification.
   Publication/tagging remain postponed.

## Following substantial redesign boundaries

| Boundary | Selection and acceptance |
| --- | --- |
| Remaining calls/operand/scalar dispatch | Indexed operands/native returns/final slots and native workstate dispatch exist. Find a demonstrated complete remaining binding/transport or numeric phase; avoid pools/arenas and duplicated control routes already measured slower. Exact integer promotion, identity/type/projection, callbacks, reentry and alias funding must hold. Machine-integer handling is a hypothesis until current attribution supports its scope; no universal tagged-value replacement. |
| Per-record construction | Current source gate: shared RecordKeys and exclusive funded row-array adoption already remove the old bulk proposal's copying/key phase; it cannot be revived unchanged. Preserve its6–8% improvement/adverse control. Remaining identity checks protect mutable headers and admission reentry; no mutation-version inventory without current measured dominance. Select a genuinely remaining construction phase; preserve hooks/order/escaping aliases. |
| Remaining bulk text/JSON | Direct casing/lower-split/formatting/native parsing, JSON loop/shared scanner and final UTF-8 storage retained. Select a whole remaining conversion/storage phase, preserving Unicode/context/hooks/async I/O. Ordinary R61 JSON has no escaped tokens; do not optimize hypothetical dominance or add a name-marker series. |
| Frontend facts | R55/R58/R62/R65 already remove lexical/graph/validity/module work. Select demonstrated repeated analysis in compile-to-result workloads; preserve class/function/annotation scope and exact diagnostics, then delete displaced analysis. No speculative visitor/cache/parser/JIT project. |

Bounded confirmation/refinement or measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged control or inconclusive results establish
uncertainty, not a permanently failed design. Keep original failed conditions and
adverse results. Fixed percentages inform judgment, never automatically veto useful
simplification. Temporary regressions require an explicit completion milestone and
retain/correct/reject decision on remaining debt. Batch CPython refreshes at coherent
combined checkpoints with exact source/date/machine and separate compile, warm,
compile-to-result/startup; include I/O/validation/cleanup boundaries and uncertainty.
Current guide accurately names sourceac5aea97; do not remeasure after every tweak.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics: byte ranges/scalar positions/original
subject windows, flags/captures/replacements/errors, cache ownership/current tokens
and one provider through frontend/runtime/imports. Core has no Utf8Regex dependency;
adapter remains nonpackable. Contract tests, semantic compatibility and actual
backend performance are separate. Immutable development producers/adapter-local
bridges support development; missing publication does not stop independent work.

Exact dev55 gaps: DetailedData lacks separate preparation/working ownership;
native name lookup lacks enumeration; cursor creation retains its token despite
per-move tokens. Both dev55 package SHAs rechecked bit-identical08:04UTC; no
new supplied version or repeat qualification. Existing bridges remain justified. Qualify the final released
package's semantics, managed safety and actual performance when available. Normal
adapter0.4 pin unchanged pending justified promotion. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.

## Lasting constraints / checks

AGENTS.md governs fully managed safety/managed stack admission: no unsafe/Unsafe,
PInvoke/pointers/native probes. Preserve host capabilities, current cancellation,
checked representation bounds, XML depth, bounded I/O chunks and admitted projection.
Borrow shared allowance for coarse capacity/preflight/replacement storage; fund
retained aliases/caches/results and pending users until awaited cleanup. No caps,
hidden allowances/fuel/quotas/tracing/weak reclamation/forced GC. Initial streaming
uses host batches. First refusal is terminal through suppression/finally; never
retry or skip optional storage. Keep native refunds/cleanup available and awaited.

Focused Release iteration; matching probes when needed and explicit Stress exclusion
with custom filters. No overlapping local builds/tests/measurements; force a fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed consumers at retained boundaries. Explicit UTF-8.
Only core explicit Release pack to artifacts/nuget; no adapter packages/publication.
VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. B443 terminal/archived/
locally verified; no active user/fixture mount, never requery. Persistent evidence
separate from owned RAM; join/unmount/archive under lease and verify locally.
One byte-identical worker DLL was atomically hardlinked, freeing56MB while keeping
all paths/bytes/cores/sources/archives. No future deletion inferred. CI observations
>=5minutes apart; cached terminal runs never requeried or duplicate-dispatched.
