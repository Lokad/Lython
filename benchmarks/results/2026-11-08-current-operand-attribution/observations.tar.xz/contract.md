R93/B454: one current ordinary-helper CPU attribution after a source gate.
Committed05d81b83/core68f63d29, R92 focus passes; full delivery independent/running.
Current maintained ordinary rsplit text script is unchanged from R90(1.80×CPython).
Do not infer a bottleneck from the original larger ratio or presence of boxing.

Reuse existing6s CPU-clock/FP199Hz capture,6guest-second warmup,2s settle,
managed PerfMap3/JIT diagnostics. No source-pair elapsed/CPU improvement claim.
All raw stacks/maps/unknowns, actual guest CPU denominator and pre/post complete
goldens, source/core/auxiliary/Ready/runtime/Closed/exit/join/quiet/fixture/archive
checks remain required.120s owner+30stop+30margin, persistent raw storage; RAM
only guest fixtures/temporary CLR maps copied and verified before cleanup.
Exact existing B453 core/archive is checked then hardlinked, not copied again.
Measured R84 raw+archive+25% must fit8MiB above240MiB OS floor. No data deletion.

Stopping criterion: one trace/source assessment selects a whole removable phase
with semantic/cancellation/ownership acceptance and a bounded source pair, or
records precise insufficient evidence. No per-name kernel series, arena revival,
instruction-fuel/checkpoint removal or new memory subsystem. Inlined work belongs
to its enclosing symbol; inclusive shares overlap and are not causal sums.
