from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'helper-shape-r88/attribute-jit.py').read_text(encoding='utf-8')
s=s.replace("r=Path(__file__).resolve().parent;f=r/'retrieved/profiles/text-warm'", "r=Path(__file__).resolve().parent;f=r/'retrieved/profiles/text-warm'")
exec(compile(s,str(r/'map-generated-code.py'),'exec'))
