# R224 — changed-helper complete call/frame cost gate

R223 retains a2.61–2.62x warm external gap on captured-helper/counter text after
the R221 incoming-write simplification. Existing R211 ordinary-text attribution
does not prove this shape's costs. One warmed six-second wall CPU capture, exact
qualified4625/cb03, existing full-output/budget-checked worker and collector. Separate
useful text/hash/scalar work, frame/argument/operand construction, unknowns/inlining
and wider reset/protocol boundary. No elapsed source pair or speedup prediction.
Stop with a concrete complete removable phase and semantic acceptance, or explicit
uncertainty. Do not automatically extend native proofs or resurrect slower arenas.
90sowner/30stop/30margin; persistent raw maps/records/source and joined cleanup.
