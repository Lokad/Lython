from pathlib import Path
import bisect, collections, datetime, hashlib, json, re, shutil, subprocess, tarfile

repo=Path.cwd();root=Path(__file__).parent;b=root/'b569';p=b/'retrieved/profiles/text-warm'
out=repo/'benchmarks/results/2026-11-11-captured-helper-cost';out.mkdir(exist_ok=True)
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
record=json.loads((p/'record.json').read_text(encoding='utf-8'))
original=json.loads((p/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
entries=[]
for line in (p/'perf.map').read_text(encoding='utf-8').splitlines():
    start,size,name=line.split(' ',2);entries.append((int(start,16),int(size,16),name))
duplicate_starts=sum(n>1 for n in collections.Counter(a for a,_,_ in entries).values())
entries=sorted(set(entries));starts=[a for a,_,_ in entries];ends=[]
for a,n,_ in entries:ends.append(max(a+n,ends[-1] if ends else 0))
def resolve(address,native):
    i=bisect.bisect_right(starts,address)-1;names=set()
    while i>=0 and ends[i]>address:
        a,n,name=entries[i]
        if address<a+n:names.add(name)
        i-=1
    if len(names)==1:return next(iter(names)),False
    if names:return '<ambiguous mapped ranges>',True
    return native,False
samples=[];frames=[];tid=None;guest=set(record['guestTids'])
def finish():
    if tid in guest and frames:samples.append(frames.copy())
for line in (p/'perf-stacks.txt').read_text(encoding='utf-8').splitlines():
    h=re.fullmatch(r'(\d+)/(\d+)\s*',line)
    if h:finish();tid=h[2];frames=[]
    elif m:=re.match(r'\s+([0-9a-f]+)\s+(.*)',line):frames.append(resolve(int(m[1],16),m[2]))
finish()
counts=collections.Counter(sample[0][0] for sample in samples)
assert len(samples)==original['samples']==1166 and counts['[unknown]']==original['unknown']==49
rules=[('VM instruction prefix',['::ExecuteInstructionPrefix']),
('Operand/result transport',['::CompleteLocalResult','::ExecuteStackTransfer','::ExecuteInputInstruction','ExecutableValueStorage']),
('Native dictionary/hash',['::TryExecuteDictionaryAccumulation','::TryAccumulateWithoutAdmission','::ComputeStructuralHashCode','::FindNativeIndex']),
('Whitespace/casing',['PyStringOps::']),
('Call binding/entry',['::BindPositionalFunctionArguments','::BeginBoundCall','::BeginPendingCall']),
('Native call selection',['::TryExecuteNativeCall','::TryLoadDirectCallReceiver','::EvaluateNativeReturn']),
('Scalar arithmetic',['::AddExactIntegers','PyNumberOps::']),
('Monitor locking',['System.Threading.Monitor::']),('Unmapped',['[unknown]']),('Ambiguous map',['<ambiguous mapped ranges>'])]
groups=collections.Counter()
for name,n in counts.items():groups[next((label for label,needles in rules if any(s in name for s in needles)),'Other mapped leaves')]+=n
materializing=sum(any('PyStringOps::SplitCore' in frame[0] for frame in sample) for sample in samples)
private=sum(any('PrepareCasedWhitespaceIteration' in frame[0] for frame in sample) for sample in samples)
result=dict(sourceRevision='Qualified4625d83e/frozencb03fd47; changed captured-helper/counter script, laterR222 separate.',
    samples=len(samples),unknown=counts['[unknown]'],ambiguousLeafSamples=counts['<ambiguous mapped ranges>'],ambiguousFrames=sum(a for s in samples for _,a in s),duplicateMapStartGroups=duplicate_starts,
    wallCaptureSeconds=(datetime.datetime.fromisoformat(record['stoppedUtc'])-datetime.datetime.fromisoformat(record['startedUtc'])).total_seconds(),workerExecutionSeconds=receipt['capturedSeconds'],selectedThreadCPUSeconds=original['cpuSeconds'],allThreadCPU=record['threadCpuSeconds'],
    groups=[dict(name=k,samples=n,percent=100*n/len(samples))for k,n in groups.most_common()],allLeaves=counts.most_common(),
    stackPresence=dict(materializingSplitCore=materializing,privateCasedWhitespacePreparation=private),
    limits='Innermost groups include useful/inlined work and wider worker checks/reset/protocol; stack presence is overlapping ancestry, not removable CPU. All-containing-range mapping keeps stub aliases explicit; caller return addresses unadjusted. No elapsed comparison or speedup forecast.')
(out/'attribution.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
files=['src/Lokad.Lython/Frontend/ExecutableScript.CasedSplits.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs',
       'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.CasedSplits.cs',
       'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs',
       'src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs']
proof={}
for name in files:
    data=subprocess.check_output(['git','show','4625d83e:'+name]);current=(repo/name).read_bytes().replace(b'\r\n',b'\n')
    assert current==data.replace(b'\r\n',b'\n'),name
    proof[name]=hashlib.sha256(current).hexdigest()
(out/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
decision=dict(established=[
    'Ordinary calls already bind into reusable compiler-sized local/operand storage; deferred helper work does not construct a lexical context here.',
    'Closed native helper execution receives ConsumedByIteration; ordinary BeginBoundCall/CreateExecutableWorkState does not forward it to a direct returned cased split.',
    'This script reaches SplitCore and materializes a PyList/word-reference array/range storage before immediate caller iteration. Private preparation already exists and retains full preflight before first loop effect.',
    'Useful casing/scanning/word production remains required. SplitCore ancestry is not all removable cost; call entry alone is not shown to explain the entire external gap.'
],selected='R225: forward existing private iteration-consumption intent through ordinary direct returns; eliminate this per-record list/array/range construction phase without extending native-body proofs or adding a new backend.',
acceptance='Never expose a private iterator through ordinary calls/bindings/aliases; preserve exact list type/identity/mutation where observed, function/descriptor/default/exception order, finally/with cleanup/override, active cancellation, full preflight before caller loop effects, retained results/aliases, terminal refusal and shared allowance reuse.',
comparison='One existing complete-job before/after, warm sync/async and compile separate, changed text target plus unchanged ordinary text/CSV/report controls. Keep all adversity; quiet confirmation only when useful evidence justifies it. No predicted percentage.',
stop='Complete the forwarding across normal return/call execution with displaced transient construction absent on admitted private paths, or refine/withdraw if guest observability, cleanup or regression debt defeats coherent simplification. No partial new proof/dispatch layer promoted alone.')
(out/'source-gate.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','exact-copies.json','footprint.json','observe-not-before.json']:
    shutil.copyfile(b/name,out/name)
shutil.copyfile(b/'retrieved/space-recovery.json',out/'space-recovery.json')
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for f in root.rglob('*'):
        if f.is_file()and 'retrieved'not in f.parts and '__pycache__'not in f.parts and f.suffix!='.tgz':a.add(f,arcname=f.relative_to(root).as_posix())
    for name in files:a.add(repo/name,arcname='source-gate/'+name)
    a.add(repo/'PLAN.md',arcname='prospective-plan.md')
manifest={}
for name in ['observations.tgz','preparation.tar.xz']:
    f=out/name
    with tarfile.open(f)as a:
        for m in a.getmembers():
            if m.isfile():a.extractfile(m).read()
    manifest[name]=dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
(out/'archive-identity.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {g['name']} | {g['samples']} | {g['percent']:.2f}% |"for g in result['groups'])
readme=f'''# R224 — captured-helper text construction cost

2026-11-11, exact qualified4625d83e/cb03fd47. Same complete captured-helper/counter
script as R223; later R222 frontend source is separate. R211's ordinary native
helper profile did not establish this shape's costs. One warmed six-second wall
capture on the existing quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, ordinaryGC/tiering
with diagnostic perf-map logging; fixed worker/adapter, complete output/budget checks.

**1,166 actual execution-thread samples**,49unmapped(4.20%),5.86guest-thread CPU
seconds,5.936worker execution seconds. No malformed map rows. All containing map
ranges are considered; duplicate stub aliases remain explicit. Ambiguous leaves:
{result['ambiguousLeafSamples']}; ambiguous frames across all stacks:{result['ambiguousFrames']}.
[All leaves, coverage and overlapping ancestry](attribution.json).

| Innermost observed group | Samples | Share |
| --- | ---: | ---: |
{rows}

Useful/inlined work and wider checks/reset/protocol are included. These are not
removable-tax shares, exact per-type bytes, an elapsed comparison or a speedup
forecast. Native/unmapped gaps and unadjusted caller return addresses remain.

## Selected complete boundary

{materializing}stacks contain materializing SplitCore;{private}contain private cased-whitespace
preparation. Source confirms an actual boundary: closed native helper execution
receives immediate iteration-consumption intent; ordinary returned helper values
do not. The captured helper consequently constructs a list, word-reference array
and split-range storage before its caller immediately iterates it. Casing/scanning
and word production are useful and remain required; the ancestry count does not
measure only removable work.

Argument binding already reuses compiler-sized local/operand storage, and incoming
writes no longer need a lexical context. Do not assume another complete argument
copy or namespace. Native proofs still exclude captures; adding another such
special case is not the selected design. [Exact unchanged source](source-proof.json),
[source gate and acceptance](source-gate.json).

R225 will forward existing consumption intent through ordinary direct returns,
using the existing engine and private iteration representation. Remove transient
construction only when the returned object cannot enter an observable guest binding;
ordinary/list-valued calls, aliases and cleanup semantics remain exact. Preserve
full-word admission before loop effects, ownership across suspension/cleanup and
current cancellation. One bounded complete-job source pair with unchanged controls
will decide retention/refinement; no predicted gain or framework/option is added.

All identity, verification before/after, stable budget, quiet, Closed/zeroexit/join,
map-copy SHA, RAM unmount and archive-under-lease/local SHA checks pass. Terminal
service success is cached; no users or RAM fixtures remain.90sowner/30stop/30margin.
[Receipt](archive-receipt.json),[raw maps/stacks/records/core](observations.tgz),
[source/recipes](preparation.tar.xz),[archive hashes](archive-identity.json).
Only the exact committed B568 compressed archive was retired after a fresh idle
lease/path/UID/link/size/SHA proof; its canonical R223 archive remains intact.
Both protected qualified images are unchanged. Fixed240MiBfloor/12MiBsetupheadroom.
No runtime prototype, repeated full qualification, producer promotion or publication.
'''
(out/'README.md').write_text(readme,encoding='utf-8')
print(json.dumps(dict(samples=len(samples),groups=result['groups'],stackPresence=result['stackPresence'],ambiguousLeafSamples=result['ambiguousLeafSamples'],decision=decision['selected']),indent=2))
