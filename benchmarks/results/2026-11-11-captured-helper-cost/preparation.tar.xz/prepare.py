from pathlib import Path
import ast, datetime, hashlib, io, json, shlex, subprocess, tarfile

repo = Path.cwd(); r = Path(__file__).parent; out = r / 'b569'; out.mkdir()
old = r.parent / 'current-text-r211/b562'
source = repo / 'benchmarks/results/2026-11-11-text-cpython-checkpoint'
write = lambda p,s: p.write_text(s, encoding='utf-8', newline='\n')
catalog = json.loads((r.parent / 'text-cpython-r223/b568/representative.json').read_text(encoding='utf-8'))
catalog['cases'] = [next(c for c in catalog['cases'] if c['id'] == 'scripts.text-summary-helpers.nonlocal-counter.large')]
write(out / 'catalog.json', json.dumps(catalog, ensure_ascii=False, indent=2) + '\n')
identity = json.loads((source / 'identity.json').read_text(encoding='utf-8'))
identity = dict(sourceRevision='R224 changed captured-helper/counter text, exact frozencb03fd47, all568 production sources equal fully qualified4625d83e. CachedGREEN42942735331. LaterR222 frontend is separate; one six-second CPU attribution, not elapsed comparison.',
    coreSHA256=identity['coreSHA256']['candidate'], auxiliaryFiles=identity['auxiliaryFiles'], performanceQualified=False)
write(out / 'identity.json', json.dumps(identity, indent=2) + '\n')
write(out / 'contract.md', '''# R224 — changed-helper complete call/frame cost gate

R223 retains a2.61–2.62x warm external gap on captured-helper/counter text after
the R221 incoming-write simplification. Existing R211 ordinary-text attribution
does not prove this shape's costs. One warmed six-second wall CPU capture, exact
qualified4625/cb03, existing full-output/budget-checked worker and collector. Separate
useful text/hash/scalar work, frame/argument/operand construction, unknowns/inlining
and wider reset/protocol boundary. No elapsed source pair or speedup prediction.
Stop with a concrete complete removable phase and semantic acceptance, or explicit
uncertainty. Do not automatically extend native proofs or resurrect slower arenas.
90sowner/30stop/30margin; persistent raw maps/records/source and joined cleanup.
''')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py']:
    s = (old / name).read_text(encoding='utf-8').replace('current-text-b562-20261110','captured-text-b569-20261111').replace('lython-b562-current-text-20261110','lython-b569-captured-text-20261111')
    s = s.replace('scripts.text-summary-helpers.large','scripts.text-summary-helpers.nonlocal-counter.large')
    s = s.replace('[d]otnet.* --compare worker|[p]erf record', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py')
    if name == 'analyze-cpu-guest.py':
        # Preserve all CLR stub aliases and containing ranges, rather than silently
        # picking the last map start. The old raw collector itself is unchanged.
        s = s.replace('starts = [r[0] for r in ranges]', '''ranges = sorted(set(ranges))
starts = [r[0] for r in ranges]
prefix_end = []
for start,size,name in ranges:
    prefix_end.append(max(start+size,prefix_end[-1] if prefix_end else 0))''')
        a = s.index('    if index >= 0:'); b = s.index('    counts[symbol] += 1', a)
        s = s[:a] + '''    matches = set()
    while index >= 0 and prefix_end[index] > address:
        start,size,name = ranges[index]
        if start <= address < start+size: matches.add(name)
        index -= 1
    if len(matches) == 1: symbol = next(iter(matches))
    elif len(matches) > 1: symbol = '[ambiguous] ' + ' | '.join(sorted(matches))
''' + s[b:]
    if name.endswith('.py'): ast.parse(s)
    write(out / name, s)
with tarfile.open(out / 'payload.tgz','w:gz') as a:
    for name in ['catalog.json','identity.json','contract.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:
        a.add(out/name,arcname=name)
payload = (out/'payload.tgz').read_bytes()
canonical = 'benchmarks/results/2026-11-11-text-cpython-checkpoint/observations.tgz'
data = (repo/canonical).read_bytes()
assert data == subprocess.check_output(['git','show','HEAD:'+canonical])
retire = [dict(relative='text-cpython-b568-20261111/observations.tgz',canonical=canonical,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())]
config = dict(root='/home/lokad/lython-bench-checks/captured-text-b569-20261111',unit='lython-b569-captured-text-20261111',payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),identity=identity,retire=retire)
script = (old/'launch-command.py').read_text(encoding='utf-8')
tree = ast.parse(script)
node = next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='c' for t in n.targets))
lines=script.splitlines();lines[node.lineno-1:node.end_lineno]=['c='+repr(config)];script='\n'.join(lines)+'\n'
script=script.replace('current-text-b562-20261110','captured-text-b569-20261111').replace('lython-b562-current-text-20261110','lython-b569-captured-text-20261111').replace('lython-b562-fixtures','lython-b569-fixtures')
script=script.replace("source=base/'construction-cpython-b561-20261110/candidate'", "source=base/'text-cpython-b568-20261111/candidate'")
script=script.replace("canonicalCommit='6ca794be'", "canonicalCommit='6c11b5cf'")
script=script.replace('[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll', '[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py')
script=script.replace(" before=shutil.disk_usage(base).free;retired=[]", " protected=[(base/'json-string-b565-20261111/reference/Lokad.Lython.dll','c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'),(base/'json-cpython-b566-20261111/candidate/Lokad.Lython.dll','9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33')]\n for p,h in protected:assert hashlib.sha256(p.read_bytes()).hexdigest()==h\n before=shutil.disk_usage(base).free;retired=[]")
script=script.replace(" assert shutil.disk_usage(base).free>required", " for p,h in protected:assert hashlib.sha256(p.read_bytes()).hexdigest()==h\n assert shutil.disk_usage(base).free>required")
assert 'construction-cpython-b561' not in script and 'lexical-loop-b558' not in script and '0e2bc55b' not in script
ast.parse(script);write(out/'launch-command.py',script)
write(out/'exact-copies.json',json.dumps(retire,indent=2)+'\n')
write(out/'footprint.json',json.dumps(dict(payloadBytes=len(payload),requiredFreeBytes=252*1024*1024+max(128*1024+3*len(payload),128*1024+len(payload))),indent=2)+'\n')
print(json.dumps(dict(payloadBytes=len(payload),requiredFreeBytes=252*1024*1024+max(128*1024+3*len(payload),128*1024+len(payload)))))
