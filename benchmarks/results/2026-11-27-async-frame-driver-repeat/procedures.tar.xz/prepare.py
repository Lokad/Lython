from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess
import tarfile

notes = Path('.git/agent-notes/review-20261031').resolve()
repo = Path.cwd()
prior = notes/'async-frame-driver-20261127'
donor = prior/'comparison/quiet'
lab = notes/'async-frame-driver-repeat-20261127'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: sha256(p.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

original = read(donor/'identity.json')
receipt = read(donor/'terminal-status.json')['receipt']
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','archivedAndVerifiedUnderLease'))
assert sha(donor/'observations.tar.xz')==receipt['archiveSHA256']
assert sha(repo/'benchmarks/results/2026-11-27-async-frame-driver/observations.tar.xz')==receipt['archiveSHA256']
assert sha(prior/'local/candidate.patch')==original['sourcePatchSHA256']
images=original['imageFiles']
assert set(images)=={'reference','candidate'}
for role, expected in images.items():
    assert len(expected)==32 and {p.name:sha(p) for p in (prior/'local'/role).iterdir()}==expected
assert [name for name,digest in images['reference'].items() if images['candidate'][name]!=digest]==['Lokad.Lython.dll']
for name in ('collect.py','representative.json','run.sh','cpython-worker.py'):
    shutil.copyfile(donor/name,quiet/name)
assert sha(quiet/'representative.json')==original['catalogs']['representative.json']['sha256']
assert sha(quiet/'cpython-worker.py')==original['cpythonWorkerSHA256']
assert b'\r' not in (quiet/'run.sh').read_bytes()
# Reverse job positions while retaining the same inputs, engine rotation and clocks.
jobs=read(donor/'jobs.json')
assert len(jobs['warm'])==4
write(quiet/'jobs.json', {'warm':list(reversed(jobs['warm']))})
identity=original|dict(
    priorArchiveSHA256=receipt['archiveSHA256'],donorArchiveSHA256=receipt['archiveSHA256'],
    catalogs={name:dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')},
    purpose='Repeat the B1854 async frame-driver source pair in reverse lane order on the original frozen images.')
write(quiet/'identity.json',identity)
shutil.copyfile(prior/'summarize-quiet.py',lab/'summarize-quiet.py')
host=(prior/'quiet-vm.py').read_text(encoding='utf-8')
host=host.replace('lython-b1854-async-frame-driver-20261127','lython-b1863-async-frame-driver-20261127')
host=host.replace("assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles']",
    "assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles']['candidate']")
host=host.replace("""  target=root/role
  target.mkdir(exist_ok=True)""","""  origin=donor/role
  assert origin.resolve(strict=True)==origin
  assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles'][role]
  target=root/role
  target.mkdir(exist_ok=True)""")
host=host.replace("""   if (target/name).exists():
    assert role=='candidate' and name=='Lokad.Lython.dll' and sha(target/name)==digest
    continue
   assert cfg['donorFiles'][name]==digest""","""   assert cfg['donorFiles'][role][name]==digest""")
compile(host,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(host,encoding='utf-8',newline='\n')

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
for role, files in images.items():
    report=quiet/f'{role}-verify.json'
    subprocess.run([dotnet,prior/'local'/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
       quiet/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',
       quiet/'cpython-worker.py','--out',report],env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),
       cwd=repo,check=True,timeout=65)
    verified=read(report)
    assert verified['caseCount']==3 and verified['state']=='Completed'
    assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert verified['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']

names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for name in names: package.add(quiet/name,arcname=name)
manifest={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root='async-frame-driver-repeat-b1863-20261127',
    donor=read(donor/'upload.json')['root'],donorFiles=images,donorArchive=receipt['archiveSHA256'],
    payloadSHA256=sha(payload),files=manifest,expandedBytes=sum(row['length'] for row in manifest.values()),
    minimumAfterStageBytes=6*1024*1024))

