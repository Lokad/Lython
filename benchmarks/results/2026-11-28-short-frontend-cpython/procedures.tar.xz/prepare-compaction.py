from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'ownership-cpython-b1963-20261128'
text = (previous / 'compact-completed-images.py').read_text(encoding='utf-8')
start = text.index('for folder, remote, unit, role in (')
end = text.index('):\n    local =', start)
text = text[:start] + '''for folder, remote, unit, role in (
    ('current-checkpoint-b1932-20261128', 'script-cpython-quiet-b1932-20261128',
        'lython-b1932-current-cpython-retry', 'candidate'),
    ('module-surface-confirmation-b1948-20261128', 'script-module-surfaces-b1948-20261128',
        'lython-b1948-module-surfaces', 'reference'),
''' + text[end:]
compile(text, 'compact-completed-images.py', 'exec')
(lab / 'compact-completed-images.py').write_text(text, encoding='utf-8', newline='\n')
