from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'ownership-cpython-b1963-20261128'


def replace(text, old, new):
    assert old in text, old
    return text.replace(old, new)


def write(name, text):
    (lab / name).write_text(text, encoding='utf-8', newline='\n')
    assert b'\r' not in (lab / name).read_bytes()


prepare = (previous / 'prepare.py').read_text(encoding='utf-8')
for old, new in (
    ("'current-cpython-b1958-20261128'", "'ownership-cpython-b1963-20261128'"),
    ('script-cpython-quiet-b1963-20261128', 'script-cpython-quiet-b1968-20261128'),
    ("startswith('0b50e6fda')", "startswith('83042273c')"),
    ("for name in ('representative.json', 'cpython-worker.py', 'run.sh'):",
        "for name in ('cpython-worker.py', 'run.sh'):"),
    ("assert digest(quiet / 'representative.json') == identity['catalogs']['representative.json']['sha256']\n", ''),
    ("jobs = read(old / 'jobs.json')\nassert len(jobs) == 7\nwrite(quiet / 'jobs.json', jobs)", '''sources = [lab.parent / folder / 'comparison' for folder in (
    'builtin-name-slots-b1964-20261128', 'single-member-return-receiver-b1967-20261128')]
by_id = {}
for source in sources:
    catalog_path = source / 'representative.json'
    proof = read(source / 'identity.json')
    assert digest(catalog_path) == proof['catalogs'][catalog_path.name]['sha256']
    catalog = read(catalog_path)
    by_id.update({case['id']: case for case in catalog['cases']})
case_ids = ('diagnostic.file-search-first-line', 'scripts.config-edit.small', 'diagnostic.generated-member-report')
catalog['cases'] = [by_id[case] for case in case_ids]
jobs = [[case_ids[0], 'warm'], [case_ids[0], 'compile-run'], [case_ids[1], 'compile-run'], [case_ids[2], 'compile']]
write(quiet / 'representative.json', catalog)
write(quiet / 'jobs.json', jobs)'''),
    ('Refresh comparable shipment, JSON and compile-to-result lanes after generator ownership consolidation.',
        'Measure short file execution, compile to result and generated helper compilation after frontend consolidation.'),
    ("collector.count('len(jobs) == 7') == collector.count('lython-b1958-cpython-fixtures')",
        "collector.count('len(jobs) == 7') == collector.count('lython-b1963-cpython-fixtures')"),
    ("collector.replace('lython-b1958-cpython-fixtures', 'lython-b1963-cpython-fixtures')",
        "collector.replace('len(jobs) == 7', 'len(jobs) == 4').replace('lython-b1963-cpython-fixtures', 'lython-b1968-cpython-fixtures')"),
    ('caseCount=5', 'caseCount=3'),
    ("launch.replace('lython-b1958-current-cpython', 'lython-b1963-ownership-cpython')",
        "launch.replace('lython-b1963-ownership-cpython', 'lython-b1968-short-frontend-cpython').replace('RuntimeMaxSec=535','RuntimeMaxSec=370')"),
    ("summary.replace(identity['sourceRevision'], head)", '''summary.replace(identity['sourceRevision'], head)
    .replace('len(raw["jobs"])==7', 'len(raw["jobs"])==4').replace('["warmJobs"]==7','["warmJobs"]==4')
    .replace('==196', '==112').replace('["caseCount"]==5','["caseCount"]==3')'''),
    ('five expected output and file goldens', 'three expected output and file goldens'),
):
    prepare = replace(prepare, old, new)
compile(prepare, 'prepare.py', 'exec')
write('prepare.py', prepare)
