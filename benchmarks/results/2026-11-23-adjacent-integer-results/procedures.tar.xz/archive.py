from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-adjacent-integer-results'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
identity = read(lab / 'comparison/identity.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and terminal['exitCode'] == '0' and not terminal['fixtures']
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 140
assert all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in read(lab / 'allocation-summary-six.json'))
paths = git('diff', '--name-only', identity['sourceRevision'], identity['candidate'], '--', 'src', 'tests').decode().splitlines()
assert len(paths) == 6 and sum(path.startswith('src/') for path in paths) == 4
head = git('rev-parse', 'HEAD').decode().strip()
identity['retainedRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', 'src') else head
assert not git('diff', '--name-only', head, identity['candidate'], '--', 'tests')
identity['retainedTestRevision'] = head
patch = git('diff', '--binary', identity['sourceRevision'], identity['candidate'], '--', *paths)
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == expected for name, expected in files.items())
    core = lab / role / 'Lokad.Lython.dll'
    image = dest / 'candidate-core.dll.gz' if role == 'candidate' else dest.parent / '2026-11-23-retained-call-cpython/candidate-core.dll.gz'
    if role == 'candidate':
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
for name in ('allocation-summary-six.json', 'marked-tape-sites.json'):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in (
        'archive.py', 'prepare.py', 'stage.py', 'quiet.py', 'comparison.patch', 'summarize.py', 'allocations.py', 'allocations.log',
        'windows-frozen.log', 'windows-public.log', 'ubuntu-public.log', 'reference-allocation-six.json', 'candidate-allocation-six.json',
        'windows-retained.log', 'ubuntu-retained.log', 'retained-regression.patch',
        'initial-prepare.log', 'locked-image-prepare.log', 'prepare.log', 'stage.log', 'launch.log', 'retrieval.log',
        'comparison/reference-verify.json', 'comparison/candidate-verify.json', 'comparison/quiet/observe-not-before',
        'inspect/Program.cs', 'inspect/Inspect.csproj', 'inspect-cases.json', 'candidate-tape.json', 'reference-tape.json'):
        archive.add(lab / name, arcname=name)
print(dest, identity['retainedRevision'] or 'private')
