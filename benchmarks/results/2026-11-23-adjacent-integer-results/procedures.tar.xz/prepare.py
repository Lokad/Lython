from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import textwrap


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/adjacent-integer-results-20261123'
prior = lab.parent / 'csv-batched-markers-20261123'
shared = lab.parent / 'supplied-scalar-return-20261123'
source = lab.parent / 'retained-call-cpython-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
hash_bytes = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: hash_bytes(path.read_bytes())
dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
core = 'Lokad.Lython.dll'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


def copy_immutable(source, destination):
    if destination.exists():
        assert digest(destination) == digest(source), destination
    else:
        shutil.copyfile(source, destination)


def adapt(name, replacements):
    script = (prior / name).read_text(encoding='utf-8')
    for old, new in replacements:
        assert old in script, (name, old)
        script = script.replace(old, new)
    compile(script, name, 'exec')
    (lab / name).write_text(script, encoding='utf-8', newline='\n')


base = read(source / 'identity.json')
candidate = (lab / 'built-revision').read_text(encoding='utf-8-sig').strip()
assert not git('-C', tree, 'status', '--porcelain')
assert candidate == git('-C', tree, 'rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--name-only', base['sourceRevision'], candidate + '^', '--', 'src')
catalog = read(source / 'representative.json')
supplied = 'scripts.ordinary-fully-supplied-helper'
quoted = 'scripts.csv-invoice.method-policy.quoted-control'
short = 'diagnostic.text-summary.nonlocal-computed-width.large'
floating = 'scripts.csv-meter-report.explicit-float'
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in (supplied, quoted, short)]
catalog['cases'] += [row for row in read(prior / 'comparison/representative.json')['cases'] if row['id'] == floating]
assert {row['id'] for row in catalog['cases']} == {supplied, quoted, short, floating}
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', dict(warm=[[supplied, 'warm'], [supplied, 'compile-run'],
    [quoted, 'warm'], [short, 'compile-run'], [floating, 'warm']]))

protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == base['cpythonWorkerSHA256']
files = base['imageFiles']['candidate']
assert len(files) == 32
images = {}
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name, expected in files.items():
        old = source / 'candidate' / name
        assert digest(old) == expected
        if role == 'candidate' and name == core:
            old = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core
        copy_immutable(old, image / name)
    for name in ('ValidatedAllocation.dll', 'ValidatedAllocation.deps.json', 'ValidatedAllocation.runtimeconfig.json'):
        copy_immutable(shared / 'candidate' / name, image / name)
    images[role] = {name: digest(image / name) for name in files}
    receipt = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        comparison / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', protocol, '--out', receipt], env=env, timeout=90, check=True)
    proof = read(receipt)
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['launched']['library']['sha256'] == images[role][core]
    assert all(digest(image / name) == expected for name, expected in images[role].items())
assert [name for name in files if images['reference'][name] != images['candidate'][name]] == [core]
write(comparison / 'identity.json', dict(sourceRevision=base['sourceRevision'], sourceImageRevision=base['candidate'],
    candidate=candidate, purpose='B1513 adjacent integer argument publication', imageFiles=images,
    coreSHA256={key: files[core] for role, files in images.items() for key in (role, role + '-control')},
    cpythonWorkerSHA256=base['cpythonWorkerSHA256'], expectedCPythonSHA256=base['expectedCPythonSHA256'],
    catalogs={name: dict(sha256=digest(comparison / name)) for name in ('representative.json', 'jobs.json')}))

tracked = 'benchmarks/results/2026-11-23-csv-batched-markers/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
old_status = json.loads(pushed('terminal-status.json'))['receipt']
assert old_status['complete'] and old_status['allWorkersJoined'] and old_status['archivedAndVerifiedUnderLease']
assert hash_bytes(pushed('observations.tar.xz')) == old_status['archiveSHA256']
old_files = json.loads(pushed('identity.json'))['imageFiles']['candidate']
assert len(old_files) == 32 and all(digest(prior / 'candidate' / name) == expected for name, expected in old_files.items())
replica = gzip.decompress(pushed('candidate-core.dll.gz'))
assert hash_bytes(replica) == old_files[core]
retirement = dict(core=hash_bytes(replica), size=len(replica), archive=old_status['archiveSHA256'])
old_launch = (prior / 'quiet.py').read_text(encoding='utf-8')
old_retirement = old_launch[old_launch.index('   proof='):old_launch.index('   replica.unlink()')]
adapt('quiet.py', [
    (old_retirement, f"""   proof={retirement!r}
   earlier=base/'csv-batched-markers-b1511-20261123'
   replica=earlier/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['core']
   assert digest(earlier/'observations.tar.xz')==proof['archive']
   assert not (earlier/'guest-fixtures').exists()
"""),
    ('lython-b1511-csv-batched-markers-20261123', 'lython-b1513-adjacent-integer-results-20261123'),
    ('.+b1511-', '.+b1513-'), ('lython-b1511-stage-', 'lython-b1513-stage-'),
    ('Six bounded lanes', 'Five bounded lanes'), ('112 MiB', '106 MiB'), ('112 * 1024 * 1024', '106 * 1024 * 1024'),
    ('seconds=298', 'seconds=236'),
])
adapt('stage.py', [('csv-batched-markers-b1511-20261123', 'adjacent-integer-results-b1513-20261123'),
    ('lython-b1511-fixtures', 'lython-b1513-fixtures'), ('len(jobs) == 6', 'len(jobs) == 5')])
for name in ('allocations.py', 'summarize.py'):
    shutil.copyfile(prior / name, lab / name)

donor = lab.parent / 'closed-definition-return-20261123/inspect'
inspector = lab / 'inspect'
inspector.mkdir(exist_ok=True)
for name in ('Inspect.csproj', 'Program.cs', 'packages.lock.json'):
    shutil.copyfile(donor / name, inspector / name)
output = inspector / 'build'
subprocess.run([dotnet, 'build', inspector / 'Inspect.csproj', '-c', 'Release', '-o', output], env=env, timeout=75, check=True)
regression = tree / 'tests/Lokad.Lython.PublicApi.Tests/SharedIntegerChainTests.cs'
source_text = regression.read_text(encoding='utf-8').split('            def report(first, second):', 1)[1].split('            """,', 1)[0]
inspected = dict(cases=catalog['cases'] + [dict(id='protected-regression',
    source=textwrap.dedent('            def report(first, second):' + source_text))])
write(lab / 'inspect-cases.json', inspected)
for role in ('reference', 'candidate'):
    image = lab / role
    for name in ('Inspect.dll', 'Inspect.runtimeconfig.json', 'Inspect.deps.json'):
        shutil.copyfile(output / name, image / name)
    subprocess.run([dotnet, image / 'Inspect.dll', lab / 'inspect-cases.json', lab / (role + '-tape.json')],
        env=env, timeout=35, check=True)
    assert read(lab / (role + '-tape.json'))['coreSHA256'] == images[role][core]

shapes = {}
for role in images:
    tape = read(lab / (role + '-tape.json'))
    shapes[role] = {}
    for row in tape['rows']:
        codes = shapes[role][row['id']] = {}
        for body in row['codes']:
            marked = [op['index'] for op in body['arithmetic'] if body['tape'][op['index']]['_primaryOperand'] & 0x40000000]
            if marked:
                codes[body['name']] = marked
assert not any(shapes['reference'].values()), shapes
assert shapes['candidate'][supplied].get('<module>') == [13], shapes
assert shapes['candidate']['protected-regression'].get('calculate'), shapes
write(lab / 'marked-tape-sites.json', shapes)
