from pathlib import Path
import datetime
import gzip
import hashlib
import io
import tarfile
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
quiet=lab/"comparison/quiet"
configuration=json.loads((quiet/"upload.json").read_text(encoding="utf-8"))
remote="/home/lokad/lython-bench-checks"
unit="lython-b1513-adjacent-integer-results-20261123"
host="lokad@20.166.121.73"
key=Path.home()/".ssh/id_lython-bench.pem"
common=["-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=15"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*common,host,"python3 -"]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*common]
configuration["unit"]=unit
configuration["remote"]=remote
prefix="from pathlib import Path\nimport fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile,tempfile\nconfiguration="+repr(configuration)+"\nbase=Path(configuration['remote']).resolve()\nroot=base/configuration['root']\nunit=configuration['unit']\n"
now=lambda:datetime.datetime.now(datetime.timezone.utc)

def invoke(script):
    result=subprocess.run(ssh,input=prefix+script,encoding="utf-8",capture_output=True,timeout=35)
    assert result.returncode==0,(result.stdout,result.stderr)
    return result.stdout

if sys.argv[1]=="launch":
    payload=quiet/"payload.tar.gz"
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration["payloadSHA256"]
    uploaded=remote+"/.+b1513-"+configuration["payloadSHA256"][:12]+".tar.gz"
    if sys.argv[2:] != ["already-uploaded"]:
        subprocess.run(scp+[payload,host+":"+uploaded],check=True,timeout=35)
    receipt=invoke("payload=Path("+repr(uploaded)+")\n"+"""digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
reference=base/configuration['reference']
marker=reference/'archive-receipt.json'
donor=json.loads(marker.read_text())
assert donor['complete'] and digest(reference/'observations.tar.xz')==donor['archiveSHA256']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 free=shutil.disk_usage(base).free
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 with tempfile.TemporaryDirectory(prefix='lython-b1513-stage-', dir='/dev/shm') as spool_folder:
  spool=Path(spool_folder)/'upload.tar.gz'
  shutil.copyfile(payload,spool)
  assert digest(spool)==configuration['payloadSHA256']
  payload.unlink()
  free=shutil.disk_usage(base).free
  # Five bounded lanes write under 1 MiB of receipts. A 106 MiB
  # workspace margin covers that and keeps the frozen images.
  minimum_active = 106 * 1024 * 1024
  block = os.statvfs(base).f_frsize
  with tarfile.open(spool) as package:
   assert all(member.isfile() for member in package.getmembers())
   staged_bytes = sum(((member.size+block-1)//block)*block for member in package.getmembers())
  minimum = minimum_active + staged_bytes + 3 * 1024 * 1024

  if free < minimum:
   proof={'core': '15584cd74053a61d63fb42e7af1018289babcda8669ae046297b4a258b4e2d14', 'size': 5761536, 'archive': '0d526a3b4dc0ee3e1f5f9483422245a4440529f78c8006a02b9c66f228e71e3e'}
   earlier=base/'csv-batched-markers-b1511-20261123'
   replica=earlier/'candidate/Lokad.Lython.dll'
   info=replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['core']
   assert digest(earlier/'observations.tar.xz')==proof['archive']
   assert not (earlier/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['core'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,(free,'needs one core, publication archive and working-room floor')
  root.mkdir()
  with tarfile.open(spool) as archive:
   assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll'}
   archive.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 assert {label:list(files) for label,files in identity['imageFiles'].items()} == {
   'reference':list(identity['imageFiles']['reference']), 'candidate':list(identity['imageFiles']['reference'])}
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 image=root/'candidate';image.mkdir()
 for name,sha in identity['imageFiles']['reference'].items():
  src=reference/'candidate'/name
  assert digest(src)==sha, name
  if name!='Lokad.Lython.dll':
   assert sha==identity['imageFiles']['candidate'][name]
   os.link(src,image/name)
 core=image/'Lokad.Lython.dll'
 (root/'candidate-core.dll').rename(core)
 assert identity['imageFiles']['candidate'][core.name]==digest(core)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 assert shutil.disk_usage(base).free >= minimum_active + 3 * 1024 * 1024
 print(json.dumps(dict(freeBefore=free,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=350','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
""")
    (quiet/"launch.log").write_text(receipt,encoding="utf-8")
    started=now()
    (quiet/"observe-not-before").write_text((started+datetime.timedelta(seconds=236)).isoformat(),encoding="utf-8")
    print(receipt, unit)
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((quiet/"observe-not-before").read_text(encoding="utf-8"))
    state=invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=(root/'exit-code.txt')
  receipt=(root/'archive-receipt.json')
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
  receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
  journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    result=json.loads(state)
    (quiet/("status-"+now().strftime("%H%M%S")+".json")).write_text(state,encoding="utf-8")
    if not result["live"] and result["receipt"] is not None:
        name="observations.tar.xz"
        archive=quiet/name
        subprocess.run(scp+[host+":"+remote+"/"+configuration["root"]+"/"+name,archive],check=True,timeout=35)
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==result["receipt"]["archiveSHA256"]
        (quiet/"terminal-status.json").write_text(state,encoding="utf-8")
        assert not result["fixtures"] and result["exitCode"]=="0" and result["receipt"]["complete"],state
    print(state)
