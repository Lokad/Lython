set -eu
source_root=/mnt/d/code/Lython
target_root=/home/vermorel/lython-starmap-rows-8066Vm
test -d "$target_root/src/Lokad.Lython"
cd "$source_root"
cat "$source_root/.git/agent-notes/review-20261031/staged-list-yield-20261127/changed-source-files.txt" |
while IFS= read -r file; do
    cp -- "$file" "$target_root/$file"
    cmp -- "$file" "$target_root/$file"
done
cd "$target_root"
filter='Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~Generator|FullyQualifiedName~Map|FullyQualifiedName~AsyncMaterialization|FullyQualifiedName~Itertools|FullyQualifiedName~MemoryBudget|FullyQualifiedName~Cancellation|FullyQualifiedName~ResourceUnwind)'
"$HOME/.dotnet/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-restore --filter "$filter"
