from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import json
import os
import re
import tempfile
import textwrap
from unittest.mock import patch

source=Path('tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs').read_text(encoding='utf-8')
cases={
    'GeneratorListYieldKeepsAliasesAndAllowsCallbackToResumeSource': [(None, 'True True True sent True []\n')],
    'GeneratorListYieldKeepsStorageThroughSuspendedSourceOrCallback': [(False, 'True []\n'), (True, 'True []\n')],
}
outputs=[]
for name,data in cases.items():
    body=source.split(f'public async Task {name}',1)[1]
    match=re.search(r'const string source = """\n(.*?)\n\s*""";',body,re.S)
    assert match is not None
    script=textwrap.dedent(match[1])
    for pause_callback,expected in data:
        captured=StringIO()
        with tempfile.TemporaryDirectory(prefix='lython-list-yield-oracle-') as temporary:
            fixture=Path(temporary)/'pause'
            fixture.write_text('content',encoding='utf-8')
            real_open=open
            def open_fixture(path, *args, **kwargs):
                assert path=='/pause'
                return real_open(fixture, *args, **kwargs)
            with patch('builtins.open',open_fixture), redirect_stdout(captured):
                exec(script,{'pause_callback':pause_callback})
        actual=captured.getvalue()
        assert actual==expected, (name,pause_callback,actual,expected)
        outputs.append(dict(test=name,pauseCallback=pause_callback,stdout=actual))
out=Path(__file__).with_name('cpython-regression.json')
out.write_text(json.dumps(outputs,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'{len(outputs)} completed regression cases match CPython.')