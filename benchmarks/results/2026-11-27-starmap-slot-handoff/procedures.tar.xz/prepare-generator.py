from pathlib import Path

lab=Path(__file__).resolve().parent
source=(lab.with_name("aggregate-map-loop-20261127")/"prepare.py").read_text(encoding="utf-8")
start=source.index("file_fed=")
end=source.index("for name in", start)
source=source[:start]+"""file_fed='diagnostic.shipment-file-fed-map'
short='diagnostic.shipment-starmap-short-lists'
wide='diagnostic.shipment-starmap-wide-lists'
bound='diagnostic.shipment-bound-starmap'
catalog=read(repeat/'local/representative.json')
assert set(row['id'] for row in catalog['cases'])=={file_fed,short,wide,bound}
write(run/'representative.json',catalog)
"""+source[end:]
for before, after in (
    ("9f123d956", "36f7b175b"),
    ("lython-aggregate-map-fixture-", "lython-staged-list-fixture-"),
    ("[[file_fed,'warm-async'],[shipment,'warm-async'],[file_fed,'warm'],[bound,'warm-async'],[search,'warm']]", 
     "[[short,'warm-async'],[bound,'warm-async'],[wide,'warm-async'],[file_fed,'warm'],[wide,'warm']]"),
    ("Test numeric accumulation in the ready short-map loop with ordinary and bound shipment controls.", 
     "Transfer existing generator list-display operands once into the real callback workspace."),
):
    assert source.count(before)==1, before
    source=source.replace(before,after)
(lab/"prepare.py").write_text(source,encoding="utf-8",newline="\n")