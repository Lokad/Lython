set -eu
root=/home/lokad/lython-bench-checks/direct-dict-enumeration-narrow-b1255-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
