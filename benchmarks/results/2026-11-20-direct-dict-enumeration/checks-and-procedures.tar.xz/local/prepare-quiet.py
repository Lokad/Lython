import hashlib
import json
import shutil
import tarfile
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "native-dict-item-cursor/quiet"
donor = template
q = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def sha(content):
    return hashlib.sha256(content).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


index = load(lab / "identity.json")
assert index["reference"].startswith("ea04028b5") and index["candidate"].startswith("7a3476198")
old = load(template / "config.json")
donor_config = load(donor / "config.json")
donor_receipt = load(donor / "archive-receipt.json")
assert donor_receipt["complete"] and donor_receipt["archivedAndVerifiedUnderLease"]
assert donor_receipt["archiveSHA256"] == file_sha(donor / "observations.tgz")
source_files = donor_config["identity"]["imageFiles"]["candidate"]
protocol_root = lab.parent / "private-stable-parameter-captures/quiet"
protocol_config = load(protocol_root / "config.json")
protocol = protocol_config["protocolSHA256"]
assert index["pythonWorkerSHA256"] == protocol
manifest = lab / "representative.json"
assert file_sha(manifest) == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(source_files) == 32
    assert set(files) == set(source_files)
    assert [n for n in files if files[n] != source_files[n]] == [core]
    assert {n: file_sha(lab / "frozen" / role / n) for n in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed"
    assert verification["catalogSha256"] == index["catalogSHA256"]

proposals = []
root = "/home/lokad/lython-bench-checks/direct-dict-enumeration-b1254-20261120"
unit = "lython-b1254-direct-dict-enumeration-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Eliminate the ordinary dictionary iterator object in typed consumers",
                catalogSHA256=index["catalogSHA256"], imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: names[core] for role, names in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
jobs = [("scripts.json-normalized-records.sorted", "warm"), ("scripts.json-normalized-records.large", "warm")]
assert set(case for case, lane in jobs) <= {r["id"] for r in load(manifest)["cases"]}
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
        content = content.replace("accumulate 12 seconds", "accumulate 16 seconds").replace("warmupSeconds=12", "warmupSeconds=16")
        content = content.replace("min(warmed)<12", "min(warmed)<16").replace("warmed[i]>=12", "warmed[i]>=16")
    if name in ("collect.py", "archive-owned.py", "retrieve.py"):
        content = content.replace("==3", "==2").replace("jobs=3,", "jobs=2,")
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()

parts = ["identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh"]
shutil.copyfile(manifest, q / "representative.json")
for role in ("reference", "candidate"):
    (q / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, q / role / core)
    parts.append(f"{role}/{core}")
with tarfile.open(q / "payload.tgz", "w:gz") as payload:
    for part in parts:
        payload.add(q / part, arcname=part)
config = dict(root=root, unit=unit, source=donor_config["root"], sourceRole="candidate", sourceFiles=source_files,
              sourceCatalogSHA256=donor_config["catalogSHA256"], protocolSHA256=protocol, protocolSource=protocol_config["root"] + "/cpython-worker.py", catalogSHA256=index["catalogSHA256"],
              identity=identity, retireGroups=proposals, donorArchiveSHA256=donor_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / part).stat().st_size for part in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1251-fixtures", "lython-b1254-fixtures")
assert "proof['archives']" in content and "176160768+c['unpackedBytes']+32*1024*1024" in content

content = content.replace("source/'cpython-worker.py'", "Path(c['protocolSource'])")
assert "protocolSource" in content and "assert sha(source/'representative.json')" in content
assert all((q / role / core).is_file() for role in ("reference", "candidate"))
emit(q / "remote-launch.py", content)
launch = read(template.parent / "launch.py").replace("Dictionary item cursor comparison", "Direct dictionary enumeration comparison").replace("255", "215")
emit(lab / "launch.py", launch)
