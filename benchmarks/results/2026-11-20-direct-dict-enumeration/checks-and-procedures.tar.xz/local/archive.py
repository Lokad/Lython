from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
destination = repo / 'benchmarks/results/2026-11-20-direct-dict-enumeration'

def read(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(data): return hashlib.sha256(data).hexdigest()

initial = read(lab / 'identity.json')
for source, out, revision in ((lab, destination, '7a3476198'),
        (lab / 'narrow-frame', destination / 'narrow-frame', '6bf2947e8')):
    q = source / 'quiet'
    identity = read(source / 'identity.json')
    assert identity['reference'] == initial['reference'] and identity['reference'].startswith('ea04028b5')
    assert identity['catalogSHA256'] == initial['catalogSHA256']
    assert identity['imageFiles']['reference'] == initial['imageFiles']['reference']
    assert identity['candidate'].startswith(revision)
    assert read(q / 'identity.json')['imageFiles'] == identity['imageFiles']
    receipt = read(q / 'archive-receipt.json')
    assert receipt['jobs'] == 2
    assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved',
        'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
    assert receipt['archiveSHA256'] == sha((q / 'observations.tgz').read_bytes())
    out.mkdir(parents=True, exist_ok=True)
    for role, files in identity['imageFiles'].items():
        image = source / 'frozen' / role
        assert len(files) == 32
        assert {name: sha((image / name).read_bytes()) for name in files} == files
        if role == 'candidate':
            (out / 'measured-candidate-core.dll.gz').write_bytes(gzip.compress((image / 'Lokad.Lython.dll').read_bytes(), mtime=0))
    patch = subprocess.check_output(['git','diff','--binary',identity['reference'],identity['candidate'],'--','src'], cwd=repo)
    (source / 'candidate-source.patch').write_bytes(patch)
    summary = read(source / 'quiet-summary.json')
    summary.pop('retentionDecisionPending', None)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n',encoding='utf-8',newline='\n')
    for name in ('archive-receipt.json','observations.tgz','terminal-status.json'):
        shutil.copyfile(q / name, out / name)
    shutil.copyfile(source / 'allocation-summary.json', out / 'allocation-summary.json')
    files = ['prepare-quiet.py','launch.py','summarize.py','candidate-source.patch','identity.json','measure-local.py',
        'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
        'reference-compile-allocation.json','candidate-compile-allocation.json','test-ubuntu.sh',
        'public-windows.log','white-windows.log','public-ubuntu.log','white-ubuntu.log']
    if source == lab: files.extend(('prepare-catalog.py','representative.json','archive.py'))
    with tarfile.open(out / 'checks-and-procedures.tar.xz','w:xz') as bundle:
        for name in files: bundle.add(source / name, arcname='local/'+name)
        for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py',
            'retrieve.py','launch.log','observe-not-before.json'):
            bundle.add(q / name, arcname='quiet/'+name)
print('Both typed dictionary comparisons and all source identities archived.')
