#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/native-dict-item-cursor"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/direct-dict-enumeration"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~Dict|FullyQualifiedName~PublicProjection|FullyQualifiedName~NamespaceView|FullyQualifiedName~Regex)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~Dict|FullyQualifiedName~PublicProjection|FullyQualifiedName~NamespaceView|FullyQualifiedName~Regex)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"