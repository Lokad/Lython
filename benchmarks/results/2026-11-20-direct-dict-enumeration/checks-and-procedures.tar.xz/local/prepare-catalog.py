from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab.parent / 'native-dict-item-cursor'
catalog = json.loads((source / 'representative.json').read_text(encoding='utf-8'))
normalization, _, control = catalog['cases']
assert normalization['id'] == 'scripts.json-normalized-records.large'
script = normalization['source'].replace('ensure_ascii=False,', 'ensure_ascii=False, sort_keys=True,')
assert script != normalization['source']
fixture = json.loads(normalization['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-sorted-normalization-') as root:
    folder = Path(root)
    for name, data in fixture['inputFiles'].items():
        (folder / name).write_bytes(base64.b64decode(data))
    process = subprocess.run(['C:/Python313/python.exe', '-I', '-X', 'utf8', '-c', script], cwd=folder,
                             check=True, capture_output=True, encoding='utf-8', timeout=20)
    output = (folder / 'normalized.json').read_bytes()
    assert len(json.loads(output)) == normalization['size']
fixture['outputFiles'] = {'normalized.json': base64.b64encode(output).decode('ascii')}
encoded_fixture = json.dumps(fixture, separators=(',', ':'))
spec = importlib.util.spec_from_file_location('protocol', repo / 'benchmarks/cpython-worker.py')
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
sha = lambda text: hashlib.sha256(text.encode('utf-8')).hexdigest()
case = dict(normalization, id='scripts.json-normalized-records.sorted', source=script,
            fixtureJson=encoded_fixture, sourceUtf8Bytes=len(script.encode('utf-8')),
            expectedOutput=process.stdout, expectedOutputUtf8Bytes=len(process.stdout.encode('utf-8')),
            sourceSha256=sha(script), fixtureSha256=sha(encoded_fixture), expectedOutputSha256=sha(process.stdout),
            expectedFilesSha256=protocol.file_digest({'normalized.json': output}))
catalog['cases'] = [case, normalization, control]
(lab / 'representative.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(case['id'], case['size'], len(output), process.stdout.strip())
