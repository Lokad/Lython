from pathlib import Path
import ast,datetime,hashlib,json,re,shlex,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home.parent/'delivery-comparison-b395';root.mkdir()
old=home.parent/'delivery-comparison-b388';recent=home/'b394'
old_remote='/home/lokad/lython-bench-checks/delivery-comparison-b388-20261107'
remote='/home/lokad/lython-bench-checks/delivery-comparison-b395-20261107'
prior='/home/lokad/lython-bench-checks/receiver-methods-b394-20261107'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='fba865ef78ea91a5fdcdb39cd138d88125d7b22a'
assert not subprocess.check_output(['git','diff','--name-only','--','src'],text=True).strip()
checks=json.loads((home/'refined-focused.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
identity=json.loads((recent/'identity.json').read_text(encoding='utf-8'))
purpose='Representative CPython checkpoint after R36/R38/R40/R41; compile/warm/fresh separated, not causal per-change attribution'
identity.update(sourceRevision=head+'; frozen5d2ca8e1 from identical production, precommit SourceLink1971487a',purpose=purpose,
    delivery=dict(runId=42357660230,headSha=head,status='pending at setup; full Windows/Ubuntu actual11/10 Stress and installed consumers requested'),
    sourceSHA256={Path(name).as_posix():digest for name,digest in checks['productionSources'].items()})
identity['coreSHA256']={name:identity['coreSHA256'][name] for name in ['candidate','control']}
identity.pop('referenceSourceRevision',None)
def write(name,text):(root/name).write_text(text,encoding='utf-8',newline='\n')
write('identity.json',json.dumps(identity,indent=2)+'\n')
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'));assert len(catalog['cases'])==5
overlap={c['id']:c for c in json.loads((recent/'representative.json').read_text(encoding='utf-8'))['cases']}
for case in catalog['cases']:
    if case['id'] in overlap:
        for key in ['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']:assert case[key]==overlap[case['id']][key]
write('representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh']:
    s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote)
    s=s.replace('Representative CPython checkpoint after R30–R35; compile/warm/fresh separated, not causal per-change attribution',purpose)
    if name.endswith('.py'):ast.parse(s)
    write(name,s)
contract='''One existing fifteen-job/five-script CPython3.13.16 checkpoint on committedfba865ef production/frozen5d2ca8e1, precommit SourceLink1971487a. .NET11RC3, same worker7cf37ca5/host/normal optional0.4 adapter27211dbe in both Lython roles, normal GC/tiering. Source/images match the retained refined R41; one CPython and two identical Lython workers per job.5s warmup/role/job,7rotated150ms rounds. Separate compile, warm and compile-to-result. Warm/fresh include mediated RAM I/O, complete checks and prior-result cleanup; fresh adds compilation/program disposal. Startup/staging/reset/final cached teardown excluded. No median subtraction, startup/RSS/suspended-I/O/embedding-tail or compound per-change CPU claim. R40/R41 focused/Python/cancellation/refusal/alias/budget-reuse and controlled affected workloads pass; full CI42357660230 requested, pending at setup. R41 allocation approximately-29.47% both APIs, refined regex elapsed-8.64–10.80%; original CSV+2.05–3.41% and variable refined controls remain debt/uncertainty. Primary guide stays on B388 until actual results and coherent delivery qualification. Require every Ready/core/aux/reference/hash/golden/funding/quiet/Closed/exit/join/fixture/persistent under-lease archive gate.420s owner+30s stop+30s margin, observe after480s; no early service queries or restart on observation timeout. Preserve all adverse/missing/failed conditions. No new framework, producer certification or publication.'''
write('contract.md',contract+'\n')
write('setup-contract.json',json.dumps(dict(image=prior+'/candidate',jobs=15,ownerSeconds=420,stopSeconds=30,observeAfterSeconds=480,reason='Coherent R36/R38/R40/R41 retained checkpoint, primary CPython baseline refresh.'),indent=2)+'\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('Preparing primary B395 comparison.','Primary B395 planned:15existing jobs,420s owner+30s stop+30s margin;\nobserve after480s. Sourcefba865ef/frozen5d2ca8e1, normal0.4, unchanged3-role protocol.\nDuplicate old-source evidence copies retired after exact committed Git-blob checks;\n93MB free before setup. Every original exists in Git; current source/images untouched.')
p.write_text(s,encoding='utf-8',newline='\n');shutil.copy2(p,root/'pre-measurement-plan.md')
(root/'source.patch').write_bytes(subprocess.check_output(['git','show','--format=','--binary',head,'--','src','tests']))
with tarfile.open(root/'payload.tgz','w:gz') as t:
    for name in ['identity.json','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md','collect.py','archive-owned.py','run.sh','source.patch']:t.add(root/name,arcname=name)
payload=(root/'payload.tgz').read_bytes()
s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('/home/lokad/lython-bench-checks/canonical-format-instructions-b387-20261107',prior).replace('lython-b388-delivery-comparison-20261107','lython-b395-delivery-comparison-20261107')
s=re.sub(r'payload=sys.stdin.buffer.read\(\d+\+1\);assert len\(payload\)==\d+ and hashlib.sha256\(payload\).hexdigest\(\)==\x27[0-9a-f]+\x27',"payload=sys.stdin.buffer.read("+str(len(payload))+"+1);assert len(payload)=="+str(len(payload))+" and hashlib.sha256(payload).hexdigest()=='"+hashlib.sha256(payload).hexdigest()+"'",s)
s=s.replace("['candidate','cpython-worker.py','source.patch']","['candidate','cpython-worker.py']")
s=s.replace(" (root/'representative.json').symlink_to(base/'delivery-comparison-b373-20261107/representative.json')\n",'')
assert str(len(payload))+'+1' in s and "['candidate','cpython-worker.py']" in s
ast.parse(s);write('launch.py',s)
s=(home/'retrieve-b394.py').read_text(encoding='utf-8')
s=s.replace("root=Path(__file__).resolve().parent/'b394'","root=Path(__file__).resolve().parent")
s=s.replace('/home/lokad/lython-bench-checks/receiver-methods-b394-20261107',remote).replace('lython-b394-receiver-methods-20261107','lython-b395-delivery-comparison-20261107').replace("['jobs']==4","['jobs']==15")
write('retrieve.py',s)
print('B395 prepared;15 unchanged jobs/three roles, candidate/cpython links reuse qualified inputs, no collection started.')
