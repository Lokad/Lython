from pathlib import Path
r=Path(__file__).parent
s=(r/'retire-backed-up-vm-copies.py').read_text(encoding='utf-8')
s=s.replace('2026-11-07-regex-scalar-cursor/development.tgz','2026-11-07-receiver-methods/development.tgz').replace("member='baseline/net11.0/Lokad.Lython.dll'","member='initial/net11.0/Lokad.Lython.dll'")
s=s.replace('c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea','bfc2e42738c9e68b676686e6f93617a09fcccbd04cb5a7638a17312f704d2b8c')
a=s.index('specs=[');b=s.index('\nwith (base/',a)
s=s[:a]+"specs=[('receiver-methods-b393-20261107','candidate/Lokad.Lython.dll')]"+s[b:]
s=s.replace('receiver-methods-b393-20261107/retired-duplicate-cores.json','receiver-methods-b394-20261107/retired-initial-prototype.json')
s=s.replace('vm-retirement','vm-initial-retirement').replace('retire-backed-up-vm-command.py','retire-backed-up-initial-command.py')
s=s.replace("result=json.loads(done.stdout);assert result['freeAfter']>12*1024*1024","result=json.loads(done.stdout)")
s=s.replace('All three exact files','The exact file').replace('first unlink','unlink')
(r/'retire-initial-command.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'retire-initial-command.py'),'exec'),{'__file__':str(r/'retire-initial-command.py')})
