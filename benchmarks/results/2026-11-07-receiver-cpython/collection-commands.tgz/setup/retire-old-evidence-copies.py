from pathlib import Path
import json, subprocess
r=Path(__file__).parent
commit=subprocess.check_output(['git','rev-parse','da0ff811^{commit}'],text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor',commit,'HEAD'],check=True)
tree=subprocess.check_output(['git','ls-tree','-rz',commit,'--','benchmarks/results'])
files=[]
for entry in tree.split(b'\0'):
    if not entry:continue
    info,path=entry.split(b'\t',1);mode,kind,blob=info.decode().split()
    assert mode=='100644' and kind=='blob'
    files.append(dict(path=path.decode('utf-8'),gitBlob=blob))
assert files
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'delivery-da0ff811'
files=FILES;commit=COMMIT
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert root.resolve()==root and not root.is_symlink()
 verified=[]
 for row in files:
  path=root/row['path'];assert path.resolve()==path and path.is_relative_to(root/'benchmarks/results')
  for parent in [path,*path.parents]:
   assert not stat.S_ISLNK(parent.lstat().st_mode)
   if parent==root:break
  data=path.read_bytes();info=path.stat()
  assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\\0'+data).hexdigest()==row['gitBlob'],str(path)
  verified.append(dict(path=str(path),relative=row['path'],bytes=len(data),links=info.st_nlink,gitBlob=row['gitBlob']))
 before=shutil.disk_usage(base).free
 # All files are exact duplicates of committed Git blobs before any unlink.
 # Source, binaries, input catalogs and working evidence outside this one old
 # source checkout's benchmark-results tree remain untouched; keep directories.
 for row in verified:Path(row['path']).unlink()
 result=dict(backupCommit=commit,files=verified,freeBefore=before,freeAfter=shutil.disk_usage(base).free,bytesRetired=sum(v['bytes'] for v in verified),restore='git show '+commit+':<relative>',ownersEnded=True)
 (base/'receiver-methods-b394-20261107/retired-old-source-evidence-copies.json').write_text(json.dumps(result,indent=2)+'\\n')
 print(json.dumps(result))
'''.replace('FILES',repr(files)).replace('COMMIT',repr(commit))
(r/'retire-old-evidence-command.py').write_text(script,encoding='utf-8',newline='\n');compile(script,'retire','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'retire-old-evidence.stdout').write_text(done.stdout,encoding='utf-8');(r/'retire-old-evidence.stderr').write_text(done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
result=json.loads(done.stdout)
(r/'old-evidence-retirement.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:result[key] for key in ['backupCommit','freeBefore','freeAfter','bytesRetired']}))
