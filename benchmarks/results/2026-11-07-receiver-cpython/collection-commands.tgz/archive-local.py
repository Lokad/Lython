from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');o=repo/'benchmarks/results/2026-11-07-receiver-cpython';o.mkdir()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs']==15 and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','contract.md','summary.json']:shutil.copy2(r/name,o/name)
with tarfile.open(o/'collection-commands.tgz','w:gz') as t:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.md','.sh','.patch']:t.add(p,arcname=p.name)
    parent=r.parent/'builtin-methods-r41'
    for name in ['prepare-b395.py','launch-b395.py','retire-backed-up-initial-prototype.py','retire-initial-command.py','vm-initial-retirement.json','retire-old-evidence-copies.py','retire-old-evidence-command.py','old-evidence-retirement.json']:
        t.add(parent/name,arcname='setup/'+name)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
labels={'csv-summary-functions':'CSV/ordinary helper','text-summary-helpers':'Text/helpers','json-summary-helpers':'JSON-lines/helpers','report-render':'JSON-to-Markdown report','config-edit':'Configuration edit'}
lines=[]
for phase,title in [('compile-run','Compile plus one execution'),('warm','Warm execution'),('compile','Compilation/program disposal only')]:
    lines += ['## '+title,'','| Workload | Lython ms | CPython ms | Lython / CPython | Status; control / IQR |','| --- | ---: | ---: | ---: | --- |']
    for row in summary['timing']:
        if row['lane']!=phase:continue
        low,high=row['timeRangeMilliseconds'];a,b=row['ratioRange'];spread=max(row['iqrPercent'][k] for k in ['candidate','control'])
        lines.append(f"| {labels[row['case'].split('.')[1]]} |{low:.6f}–{high:.6f}|{row['medianMilliseconds']['CPython']:.6f}|{a:.2f}–{b:.2f}×|{row['status']};{row['controlPercent']:.2f}%/{spread:.2f}%|")
    lines += ['']
text='''# Representative CPython checkpoint after R41 — B395

2026-11-07. Committed productionfba865ef; frozen5d2ca8e1 has identical production
source with precommit SourceLink1971487a. Full source/image/aux identities preserved.
Worker7cf37ca5, adapter27211dbe, normal PythonRe0.4; no development producer bridge.
This refresh is independent of final adapter qualification and producer publication.

Same five maintained scripts, source/fixture/output/file hashes and checked protocol
as B388. Quiet AzureStandard_F4as_v7, Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,
16GiB/no swap, .NET11RC3 normal GC/tiering; CPython3.13.16 GCC13.3 PGO/LTO,
normal GIL/GC/no JIT/debug, -I -S -X utf8. One CPython and two independent identical
Lython workers per job,5s warmup/role/job,7rotated150ms rounds. Fifteen jobs complete
311.66s/all gates.420s owner+30s stop+30s margin, observed after480s. Archive verified
under lease and independently after retrieval; all workers joined/fixtures removed.

Warm/fresh elapsed includes mediated RAM I/O, complete guest work and output/file
checks, prior-result cleanup. Fresh adds compilation/program disposal; compile-only
excludes execution/I/O. Startup/staging/reset/transport/final cached program/result/
process teardown excluded. Imported modules persist in CPython; Lython isolates
execution imports. No source-cache workaround or identical-internals claim. Ratios
above1 mean slower. Ranges span two Lython-role medians, not confidence intervals.
Control is their absolute difference/candidate; IQR is the larger Lython-role value.
Diagnostic/Variable labels summarize short observations, not design veto thresholds.

Full CI42357660230 on exactfba865ef was pending at setup; ordinary platforms and
installed consumers passed by retrieval, original Stress still running. Attach its
terminal receipt independently; focused/measurement gates do not replace delivery.
No publication, startup/RSS/pending-I/O/embedding-tail or per-change causal CPU claim.

'''+'\n'.join(lines)+'''
Text remains the largest primary warm gap,1.75–1.79×, motivating one bounded
current-source text cost gate. Other current warm ratios:CSV1.19–1.23×,JSON1.04×,
report1.36–1.38×,config1.25×. Preserve variable fresh JSON/report/config and report
warm IQR8.69%, text role spread2.22%, CSV warm3.22%. This combined checkpoint does
not repay R41's original adverse CSV result or explain other historical controls.

Before this collection, an inactive first-prototype core and duplicate evidence
files inside one old delivery source checkout were retired only after exact hash/
link/path checks against already committed archives/Git blobs. All originals remain
recoverable byte-for-byte; source, current images, input catalogs and sole evidence
were retained. Setup receipts/restore paths are in collection-commands.

[Observations](observations.tgz), [summary](summary.json), [identities](identity.json),
[collection/setup commands](collection-commands.tgz), [owned archive receipt](archive-receipt.json)
and [previous primary B388](../2026-11-07-formatted-cpython/README.md) preserve all evidence.
'''
(o/'README.md').write_text(text,encoding='utf-8',newline='\n')
print('B395 immutable measurement evidence archived; primary guide waits for coherent delivery result.')
