# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
One completed experiment or delivery checkpoint does not complete this objective.

## Actual delivery status

- **Fully qualified through b0889a46:** terminal GREEN42351006316, Windows/Ubuntu
  Release, actual.NET11/10, original Stress both and installed package consumers.
  Shared compiler-fact correction, direct UTF8/storage, native helper returns and
  R20–R38 retained milestones are included. Earlier receipts remain historical;
  do not repeat qualification or query terminal runs for unchanged production.
- **R40 committed1971487a, focused/VM-qualified:** bidirectional scalar projection,
  Python goldens, active cancellation/funded cleanup and normal0.4 scaling/controls
  pass. Full delivery is batched with R41; b088 receipt excludes both.
- **R41 retained/committedfba865ef, full qualification pending:** shared receiver-method
  implementations/borrowed operands replace ten opaque markers, invocation chain,
  migrated capturing factories and ten orphaned guard helpers. Refinement removes
  its one-caller resolver/redundant no-argument checks. Current frozen5d2ca8e1/2aefaa39
  on actual11/10; earlierbfc2e427/f848abe1 and all adverse conditions retained.
  Refined121internal/506public per target plus earlier broader focused checks pass.
  Genuine suspension/current tokens, first refusal, aliases, defaults/metadata,
  argument effects, cleanup/budget reuse and native proofs remain. No API break.
- **Independent regex:** normal optional adapter remains nonpackable/pinned0.4,
  core decoupled. Immutabledev48/sourcef6b2175e previously passed85internal/488public
  per target on R30; not current-HEAD/final producer safety or CPU certification.
- **History:** benchmarks/EXPERIMENTS.md and immutable results hold full source pairs,
  failed conditions, refinements, adverse controls and rejected designs. No dormant
  routes/options remain for experiments. Slower call-arena/control lessons remain.

## Established measurements / debt

| Milestone | Established outcome | Limitation / decision |
| --- | --- | --- |
| Shared compiler facts | Shared inferred-value traversal fixes exponential work; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation−19.92/−19.31%; fully qualified | Earlier elapsed gains diagnostic, not transferable to HEAD. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retain | Original adverse15.125ms unexplained/preserved. |
| R20/R25 records | Shared keys/independent values; completed CSV arrays transfer. R25 allocation−7.31/−6.55%, native warm−7.72–8.04% | Selectively revisits old6–8% bulk rejection through coherent transfer. Coarse CPU/text controls mixed. |
| R29 calls | Synthetic native-helper completion phase removed; text warm−4.25–7.61%sync/−7.63–8.64%async vsR26 | Allocation flat; report/CSV uncertainty and older debt remain. |
| R30–R32 facts/layouts | Repeated class/parameter analysis/storage removed | Compilation storage grows; old moving text/CSV controls and adverse pairings remain debt. |
| R35 formatting | Dynamic complete report warm allocation~−15.35%, quiet elapsed−10.09–13.19% | Static warm favorable, fresh/text variable; CSV+0.13–2.36% accepted possible debt. Original B386/refinement preserved. |
| R38 annotation demand | Compile allocation−4.38–8.94%; report compile−6.51–8.02%, text−8.25–9.13%, config fresh−0.54–2.42% | Required full regex flow preserved after initial3failures; regex+304B/+0.117%, elapsed up to+1.66% accepted overhead. Warm text variable. Fully qualified. |
| R40 scalar cursor | Same0.4 backend: Unicode1,024warm−31.28–34.50%,4,096−65.54–68.53%,8,192−78.99–79.47%; allocation essentially flat/peaks identical | Growing-input diagnostic, not broad regex/isolated CPU/CPython claim. ASCII−0.16 to+6.31%/4.78%current spread, forward−3.38 to+2.96% variable; possible ASCII debt accepted. Full batch pending. |
| R41 receiver methods | Ten markers/guard helpers and migrated closures removed; allocation~−29.47% both APIs, refined regex warm−8.64–10.80% | JSON/text/CSV variable; original CSV+2.05–3.41% accepted possible debt. Focused/VM pass; full delivery pending. |

Primary CPython snapshot remains B388/exact42101cd5/frozen6ab7367f, before
R36/R38/R40/R41: CSV1.20x,text1.67–1.75x,JSON1.02–1.04x,report1.40–1.42x,
config1.26x warm CPython3.13.16; separate compile45–75us. Variable cases and source
labels stay explicit in docs/BENCHMARKS.md. Warm includes mediated RAM I/O/full
checks/prior-result cleanup; fresh adds compilation/program disposal. Startup,
staging/reset/final cached teardown excluded. No median subtraction, compound CPU
claim or algebraic debt repayment. Startup/pending-I/O/heap/embedding tails unmeasured.

R41 allocation controls within0.04%, every admitted peak identical. B393114.27s
and refinedB394114.47s/all4gates archived. Refined JSON−4.10 to+2.65%, text−1.34
to+1.05%, CSV−1.84 to+2.35% have variable roles. Preserve original B393 adverse
CSV/JSON and contradictory desktop clocks. Retain simplification/allocation/regex
elapsed gain; do not claim parity, isolated CPU or a proven explanation of debt.

## Priority 1 — deliver and continue whole-script work

1. R41 source/tests/current guides/evidence committed/pushedfba865ef; full CI
   42357660230 requested with Stress. Batch Windows/Ubuntu,
   actual11/10, original Stress and installed consumers with pendingR40. Keep
   working during CI; record its terminal result once. No publication/tagging.
2. Refresh the five maintained CPython complete CSV/text/JSON/report/config scripts
   at this coherent checkpoint, with separate compile/warm/fresh boundaries and
   unchanged controls/tooling. One bounded owned collection, preserve uncertainty;
   no new framework or per-microchange refresh. Use current frozen source/aux bits.
3. **Next R42 source/cost gate — complete text normalization→aggregation.** Highest
   primary representative warm gap remains text. Assess dictionary key/query work,
   scalar boxing/dispatch and materialization/transport before selecting a redesign.
   Source already has cased splitting, shared keys, direct/native calls, final slots,
   lazy contexts and idle workspaces. A focused existing6s CPU capture is justified
   only to distinguish these competing phases, retaining unknown/self/inclusive
   evidence. Do not repeat the closed aggregate CSV frame profile. Stop after that
   bounded fact: name material removable work/storage and displaced source before
   prototype, or explicitly move boundary. No arena, universal tags or new one-off
   opcode solely from allocation shares. A selected redesign must cover the complete
   phase, preserve Python/identity/order/protocols, current cancellation, terminal
   refusal/ownership, and remove its old route at a named completion milestone.
4. Follow the evidence across the remaining boundaries below. Each selected redesign
   needs affected representative scripts, semantic acceptance, precise allocation
   plus bounded quiet before/after/unchanged controls. Temporary setbacks require an
   explicit completion/debt decision. Continue after each milestone.

| Boundary | Existing evidence / work to eliminate | Acceptance |
| --- | --- | --- |
| Calls/frames/operands | R37 native slices already borrow; R39 CSV1127samples/58unknown does not establish dominant removable frame work. R41 removes a proven receiver construction phase | Remove real binding/context/continuation/transport work, not useful inclusive helper execution; closures, generators, stack/spans/borrows/suspension preserved. |
| Per-record storage | R20 shared keys and R25 completed CSV transfer delivered; ordinary JSON parsing synchronous | Remove an actual extra capacity/copy phase; duplicates/hooks/order/reentry/aliases/overlap preserved. Do not revive withdrawn masks/windows without new evidence. |
| Scalars/text | Boxed values and UTF8/string allocation are demonstrated; allocation shares alone do not explain CPU | Exact promotion, identity/hash/index/Unicode/context/publication and funded major storage; prefer whole phase over accumulating shortcuts. |
| Frontend/setup | Shared lexical/class/parameter facts, compiler-fact correction, R38 demand pruning and shared builtins already delivered. Imports already execute executable code; prepared class helpers already exist | Remove an actual duplicate walk/retained representation while preserving diagnostics/dead-scope regex facts and fresh mutable state. Measure compile separately. |

## Experimental policy

Timeouts, unstable unchanged controls and inconclusive observations mean uncertainty,
not permanent rejection. Allow bounded justified confirmation/refinement/measurement
correction, never repeated until favorable. Size for the quiet VM; preserve original
failed conditions/adverse results and source/image provenance. Fixed percentages
inform decisions, not automatic vetoes of useful simplification. Distinguish source
deletion, allocation, elapsed and CPU. Batch delivery checks at meaningful boundaries.

## Priority 2 — independent Lython regex architecture

Continue Lython-owned Python/nativeUTF8 semantics:byte ranges/scalar positions,
original windows, captures/replacements/errors/cache ownership and actual current-
token work. R40 projection and R41 method plumbing need no new producer release.
Development producers/adapter-local bridges support contract and semantic work;
missing published capabilities defer only affected final adapter qualification.

Missing capabilities:DetailedData has no independent Prepare working owner; native
names lack enumeration; cursors mix creation/current token authority. Exactdev48
adds no documented API removing these limits. Keep conservative preflight/local
conversion/qualified CTS bridge where needed; qualify released immutable inputs
and managed safety separately. No silent promotion, sibling edits, dialect fallback,
regex quotas, abandoned background work or dependence on producer publication.

## Constraints / current resources

AGENTS.md authoritative. Fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/
native probing. Managed stack/recursion, host mediation/contained paths, cycles,
current cancellation, coarse borrowed allowance/preflights/overlap, escaping aliases
and awaited users remain. First refused admission terminates the command. No tracing,
weak reclamation/forcedGC/fuel/quotas/caps/hidden allowance. Host-driven bounded batches;
XML depth constraint retained. No overlapping local builds/tests; preserve Stress.

Active full CI42357660230 onfba865ef; first status check spaced at least5minutes.
No local measurement/test or VM collection. Primary B395 planned:15existing jobs,420s owner+30s stop+30s margin;
observe after480s. Sourcefba865ef/frozen5d2ca8e1, normal0.4, unchanged3-role protocol.
Duplicate old-source evidence copies retired after exact committed Git-blob checks;
93MB free before setup. Every original exists in Git; current source/images untouched. Terminal
CI42351006316,42347124351 and earlier receipts cached:never query again. B385–B394
terminal/archived; no more service queries. B3936c834129/B394319fdd7e independently
verified; all users joined/fixtures removed. VM lokad@20.166.121.73,
key~/.ssh/id_lython-bench.pem. Limited disk:preflight next inputs/results headroom.
Only three exact inactive single-link oldc21cores retired; recovery from committed
1971487a R40 development.tgz, baseline/net11.0/Lokad.Lython.dll. Receipt in R41.
No archive/source/current core deleted. Persistent evidence; archive/verify RAM
under lease before removal. Record owner/stop/margin before observing; never restart
on observation timeout. Resume delivery/CPython refresh/R42; objective stays active.
