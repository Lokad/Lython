from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();proofs=[{'path': 'xml-select-b699-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-13-xml-selection/source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': 'c16b44f0dd59c5fd6063ab9d32d627635c351758b11472c6d289eee2c69faca5', 'bytes': 5710848}, {'path': 'retained-external-b683-20261113/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-13-builtin-core-definitions/factory-correction/source-checks.tar.xz', 'member': 'candidate-core.dll', 'sha256': '5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c', 'bytes': 5680640}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert len(aliases)==s.st_nlink
  assert all(any(prefix in name for prefix in ['xml-select-b698-','xml-select-b699-','xml-traversal-b700-','xml-traversal-b701-','retained-external-b683-','builtin-setup-corrected-b682-','positional-zip-b684-','positional-zip-b685-','whole-script-profile-b686-'])for name in aliases),(proof['path'],aliases)
  rows.append(dict(**proof,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512,aliases=aliases))
 print(json.dumps(dict(freshIdleLease=True,readOnly=True,freeBytes=shutil.disk_usage(base).free,retire=rows)))
