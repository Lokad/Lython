from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r=Path(__file__).parent;proofs=[]
historical=json.loads((r/'historical-image-proof.json').read_text(encoding='utf-8'))
for canonical,member,remote in [('benchmarks/results/2026-11-13-xml-selection/source-checks.tar.xz','candidate-core.dll','xml-select-b699-20261113/candidate/Lokad.Lython.dll'),(historical['canonical'],historical['member'],'retained-external-b683-20261113/candidate/Lokad.Lython.dll')]:
 p=Path(canonical);assert subprocess.check_output(['git','show','HEAD:'+canonical])==p.read_bytes()
 with tarfile.open(p)as t:data=t.extractfile(member).read()
 proofs.append(dict(path=remote,canonical=canonical,member=member,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
assert proofs[0]['sha256']=='c16b44f0dd59c5fd6063ab9d32d627635c351758b11472c6d289eee2c69faca5'
s=(r.parent/'xml-traversal-r330/retirement-inspection-command.py').read_text(encoding='utf-8');a=s.index('proofs=');b=s.index('\nwith(',a);s=s[:a]+'proofs='+repr(proofs)+s[b:]
s=s.replace("['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-']","['xml-select-b698-','xml-select-b699-','xml-traversal-b700-','xml-traversal-b701-','retained-external-b683-','builtin-setup-corrected-b682-','positional-zip-b684-','positional-zip-b685-','whole-script-profile-b686-']")
ast.parse(s);(r/'retirement-inspection-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=s,text=True,encoding='utf-8',capture_output=True)
old=r/'retirement-inspection.log'
if old.exists()and not(r/'missing-catalog-preflight.log').exists():(r/'missing-catalog-preflight.log').write_bytes(old.read_bytes())
elif old.exists()and not(r/'extra-alias-preflight.log').exists():(r/'extra-alias-preflight.log').write_bytes(old.read_bytes())
old.write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);(r/'retirement-inspection.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(d,flush=True)
