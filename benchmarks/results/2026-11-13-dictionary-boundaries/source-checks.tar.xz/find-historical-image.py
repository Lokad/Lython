from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;matches=[]
for filename in ['benchmarks/results/2026-11-13-builtin-core-definitions/factory-correction/source-checks.tar.xz','benchmarks/results/2026-11-13-fixed-definitions-cpython-checkpoint/collection-checks.tar.xz','benchmarks/results/2026-11-13-positional-zip/comparison/collection-and-images.tar.xz']:
 p=Path(filename);assert subprocess.check_output(['git','show','HEAD:'+filename])==p.read_bytes()
 with tarfile.open(p)as t:
  for m in t.getmembers():
   if m.isfile()and(m.name.endswith('candidate-core.dll')or m.name.endswith('Lokad.Lython.dll')):
    data=t.extractfile(m).read();sha=hashlib.sha256(data).hexdigest()
    if sha=='5a184a1d40a111ef2217f58789a66443fcc42540c850b79b562dcdb800ff740c':matches.append(dict(canonical=filename,member=m.name,sha256=sha,bytes=len(data)))
assert matches
(r/'historical-image-proof.json').write_text(json.dumps(matches[0],indent=2)+'\n',encoding='utf-8');print(matches,flush=True)
