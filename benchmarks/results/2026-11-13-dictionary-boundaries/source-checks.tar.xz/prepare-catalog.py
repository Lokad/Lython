from pathlib import Path
import json
r=Path(__file__).parent;prior=r.parent/'final-slot-binding-r326/b694/retrieved'
(r/'catalog.json').write_bytes((prior/'representative.json').read_bytes())
s=(r.parent/'xml-select-r329/verify-workers.py').read_text(encoding='utf-8');(r/'verify-workers.py').write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));assert len(catalog['cases'])==2
assert catalog['cases'][0]['id']=='scripts.text-summary-helpers.nonlocal-counter.large'and catalog['cases'][1]['id']=='scripts.file-search.large'
(r/'source-gate.json').write_text(json.dumps(dict(reference='R330/965c7e0f, final platform qualification separate',source=Path('src/Lokad.Lython/Runtime/PyDict.Accumulation.cs').read_text(encoding='utf-8'),scope='Remove redundant operation-internal polls and their span transport; preserve caller, long-work, post-binding/retirement, managed-stack and pre-admission checks.',workloads=[dict(id=c['id'],source=c['source'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'])for c in catalog['cases']],allocationNotMeasured=True),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
