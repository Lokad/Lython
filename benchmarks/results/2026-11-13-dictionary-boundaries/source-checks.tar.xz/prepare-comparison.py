from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'xml-traversal-r330/b701';out=r/'b702';out.mkdir()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='R331 frozen798edc1d vs committedR330/frozen965c7e0f; checked native dictionary boundary, no redundant operation-internal polls/spans; fixed B685 workers/adapter0.4'
identity['purpose']='Complete captured-text histogram and unchanged file-search control; same guest sources and clocks; allocation not measured; prior full reference qualification tracked separately'
identity['coreSHA256']={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in['reference','candidate','reference-control','candidate-control']}
identity['catalogSHA256']=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest();identity['referenceCase']=identity['variantCase']='scripts.text-summary-helpers.nonlocal-counter.large';identity['controlCase']='scripts.file-search.large';identity['sourceAndScriptDifferIntentionally']=False
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
oldroot='/home/lokad/lython-bench-checks/xml-traversal-b701-20261113';root='/home/lokad/lython-bench-checks/dictionary-boundaries-b702-20261113';unit='lython-b702-dictionary-boundaries-20261113'
for name in['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b701-xml-traversal-20261113',unit).replace('B701','B702')
 if name=='collect.py':s=s.replace("jobs=[['scripts.xml-records.findall.large','warm'],['scripts.xml-settings.large','warm']]","jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.file-search.large','warm']]")
 if name=='summarize.py':s=s.replace('sourceAndScriptDifferIntentionally=True','sourceAndScriptDifferIntentionally=False')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json');t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'candidate-identity.json',arcname='source-identity.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot=oldroot,unit=unit,identity=identity,retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['retire'],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
s=(r.parent/'xml-traversal-r330/b700/launch.py').read_text(encoding='utf-8')
s=s.replace("['xml-utf8-input-b696-','xml-utf8-input-b697-','xml-select-b698-','xml-select-b699-','positional-zip-b684-','positional-zip-b685-']","['xml-select-b698-','xml-select-b699-','xml-traversal-b700-','xml-traversal-b701-','retained-external-b683-','builtin-setup-corrected-b682-','positional-zip-b684-','positional-zip-b685-','whole-script-profile-b686-']").replace('lython-b700-fixtures','lython-b702-fixtures')
ast.parse(s);(out/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared unchanged text/search scripts,4roles per job,180s owner; current965 and new798 images remain funded/preserved.',flush=True)
