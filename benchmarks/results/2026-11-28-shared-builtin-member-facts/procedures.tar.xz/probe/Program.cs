using System.Collections;
using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var frontend = "Lokad.Lython.Frontend.";
var contracts = assembly.GetType(frontend + "StaticContracts", throwOnError: true)!;
var returnLookup = contracts.GetMethod("TryGetMemberReturnShape", all)!;
var kinds = assembly.GetType(frontend + "AbstractValueKind", throwOnError: true)!;
var valueType = assembly.GetType(frontend + "AbstractValue", throwOnError: true)!;
var makeValue = valueType.GetConstructors(all).Single(constructor => constructor.GetParameters().Length == 4);
var lookup = contracts.GetMethod("TryGetCallableContract", all)!;
var catalogKeys = new SortedSet<string>(StringComparer.Ordinal) { "__nonexistent_member__" };
foreach (var type in contracts.GetNestedTypes(all))
{
    if ((type.Name is "StringMemberCatalog" or "BytesMemberCatalog" or "ListMemberCatalog") && type.GetField("ByName", all)?.GetValue(null) is IDictionary names)
        foreach (var name in names.Keys) catalogKeys.Add((string)name);
    if (type.GetField("ByMember", all)?.GetValue(null) is not IDictionary catalog) continue;
    foreach (var key in catalog.Keys) catalogKeys.Add((string)Read(key, "MemberName")!);
}

var rows = new List<object>();
var returns = new List<object>();
var queries = 0;
foreach (var kind in Enum.GetValues(kinds))
{
    var parameters = makeValue.GetParameters();
    object? Default(int index) => parameters[index].ParameterType.IsValueType
        ? Activator.CreateInstance(parameters[index].ParameterType) : null;
    var receiver = makeValue.Invoke([kind, null, Default(2), Default(3)]);
    foreach (var member in catalogKeys)
    {
        queries++;
        object?[] returnArguments = [kind, member, null];
        if ((bool)returnLookup.Invoke(null, returnArguments)!)
            returns.Add(new { receiver = kind.ToString(), member, shape = returnArguments[2]!.ToString() });
        object?[] arguments = [receiver, member, null];
        if (!(bool)lookup.Invoke(null, arguments)!) continue;
        var contract = arguments[2]!;
        var shape = Read(Read(contract, "Shape")!, "Parameters")!;
        rows.Add(new { receiver = kind.ToString(), member, declared = Read(contract, "ReceiverKind")?.ToString(), code = Read(contract, "DiagnosticCode"),
            message = Read(contract, "Message"), mutation = Read(contract, "Mutation")?.ToString(),
            layout = shape.GetType().Name, parameters = JsonSerializer.SerializeToElement(shape, shape.GetType()) });
    }
}

var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string)])!;
string[] scripts =
[
    "return ' x '.strip('x', 'y')",
    "return str.strip(' x ', chars='x')",
    "return 'x'.startswith()",
    "return str.startswith('xyz', prefix='x')",
    "return '{value}'.format(value=5).count('5')",
    "return 'x'.split(maxsplit=1).append()",
    "return 'x'.find('a').bit_length(1)",
    "return 'x'.encode().decode()",
    "return 'x'.replace(old='x', new='a')",
    "return 'x'.__add__('y')",
    "return b'x'.hex(1, 2, 3)",
    "return bytes.hex(b'abc', sep=':')",
    "return bytes.fromhex('c3a9').decode()",
    "return b'a'.center(8, fillchar=b'_')",
    "return b'a,b'.split(b',').append()",
    "return list.append([], 1)",
    "return list.pop([1], 0)",
    "return [1].pop(0).bit_length(1)",
    "return [1].copy().append(2)",
    "return set.__or__(set(), set())",
    "return {1}.union({2})",
    "return [1].sort(key=str, reverse=True)",
    "return (5).bit_length(0)",
    "number=int('37')\nreturn number.bit_count(value=1)",
    "return True.bit_count(1)",
    "flag=bool('yes')\nreturn flag.bit_length(1)",
    "return (1.5).hex(3)",
    "value=float('1.5')\nreturn value.hex(4)",
    "value=int('2')\nreturn value.__round__(1, 2)",
    "return (1.5).__round__(1, 2)",
    "return (5).bit_length()",
    "value=float('1.5')\nreturn value.as_integer_ratio()",
    "value={}\nreturn value.get()",
];
var diagnostics = scripts.Select(source =>
{
    using var script = (IDisposable)compile.Invoke(engine, [source])!;
    return new { source, valid = Read(script, "IsValid"),
        diagnostics = JsonSerializer.SerializeToElement(Read(script, "Diagnostics")) };
}).ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(new { queries, members = catalogKeys.Count, rows, returns, diagnostics }));
static object? Read(object target, string property) => target.GetType().GetProperty(property, all)!.GetValue(target);
