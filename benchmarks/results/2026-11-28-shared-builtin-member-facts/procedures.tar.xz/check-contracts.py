from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
donor = lab.parent / 'string-member-facts-b1965-20261128/probe'
probe = lab / 'probe'
probe.mkdir(exist_ok=True)
for name in ('ContractProbe.csproj', 'packages.lock.json'):
    copy2(donor / name, probe / name)
source = (donor / 'Program.cs').read_text(encoding='utf-8')
assert source.count('type.Name == "StringMemberCatalog"') == 1
source = source.replace('type.Name == "StringMemberCatalog"',
    '(type.Name is "StringMemberCatalog" or "BytesMemberCatalog" or "ListMemberCatalog")')
anchor = '    "return (5).bit_length(0)",'
assert source.count(anchor) == 1
source = source.replace(anchor, '''    "return b'x'.hex(1, 2, 3)",
    "return bytes.hex(b'abc', sep=':')",
    "return bytes.fromhex('c3a9').decode()",
    "return b'a'.center(8, fillchar=b'_')",
    "return b'a,b'.split(b',').append()",
    "return list.append([], 1)",
    "return list.pop([1], 0)",
    "return [1].pop(0).bit_length(1)",
    "return [1].copy().append(2)",
    "return set.__or__(set(), set())",
    "return {1}.union({2})",
    "return [1].sort(key=str, reverse=True)",
''' + anchor)
(probe / 'Program.cs').write_text(source, encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / 'probe-build.log').open('wb') as log:
    subprocess.run([dotnet, 'build', probe / 'ContractProbe.csproj', '-c', 'Release'], env=env,
        check=True, timeout=60, stdout=log, stderr=subprocess.STDOUT)
program = probe / 'bin/Release/net11.0/ContractProbe.dll'
pair = lab / 'comparison'
identity = json.loads((pair / 'identity.json').read_bytes())
outputs = []
for role, image in identity['imageFiles'].items():
    folder = pair / role
    assert {path.name: sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()} == image
    output = lab / f'{role}-contracts.json'
    subprocess.run([dotnet, program, folder / 'Lokad.Lython.dll', output], env=env, check=True, timeout=20)
    outputs.append(output)
assert outputs[0].read_bytes() == outputs[1].read_bytes()
data = json.loads(outputs[0].read_bytes())
assert len(data['diagnostics']) == 33
for kind, callable_count, return_count in (('Bytes', 56, 38), ('BytesType', 56, 38),
    ('List', 27, 14), ('ListType', 27, 14), ('Set', 38, 29), ('SetType', 17, 16)):
    assert sum(row['receiver'] == kind for row in data['rows']) == callable_count
    assert sum(row['receiver'] == kind for row in data['returns']) == return_count
print(data['queries'], 'queries per surface', len(data['rows']), 'matching call results and',
    len(data['returns']), 'matching return results', len(data['diagnostics']), 'compiler cases')
