#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/shared-primitive-members-b1966-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Diagnostics|FullyQualifiedName~Bytes|FullyQualifiedName~Binary|FullyQualifiedName~List|FullyQualifiedName~StringMethods|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~StaticAnalysis|FullyQualifiedName~String|FullyQualifiedName~Bytes|FullyQualifiedName~Binding)' > "$lab/ubuntu-net11-whitebox.log" 2>&1
