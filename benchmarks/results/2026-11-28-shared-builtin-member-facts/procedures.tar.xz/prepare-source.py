from pathlib import Path
import re

lab = Path(__file__).resolve().parent
frontend = lab.parents[3] / 'src/Lokad.Lython/Frontend'
paths = {name: frontend / f'StaticContracts.{name}.cs' for name in (
    'CallableMembers', 'MemberReturns', 'MemberReturns.Core', 'MemberReturns.Extended', 'StringMembers', 'BuiltinMembers')}
texts = {name: path.read_text(encoding='utf-8') for name, path in paths.items() if path.exists()}
assert 'BuiltinMembers' not in texts


def replace(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


callables = texts['CallableMembers']
byte_pattern = re.compile(r'            contracts\.Add\(new StaticCallableContract\(AbstractValueKind\.(Bytes|BytesType), "([^"]+)", (.+)\)\);\n')
byte_methods = {kind: {} for kind in ('Bytes', 'BytesType')}
for kind, name, contract in byte_pattern.findall(callables):
    assert name not in byte_methods[kind]
    byte_methods[kind][name] = contract
assert len(byte_methods['Bytes']) == 56 and byte_methods['Bytes'] == byte_methods['BytesType']

list_pattern = re.compile(r'            Add(NonMutating)?ListCallableContract\(contracts, "([^"]+)", (.+)\);\n')
list_methods = {name: (not no_mutation, contract) for no_mutation, name, contract in list_pattern.findall(callables)}
assert len(list_methods) == 27

returns_pattern = re.compile(r'        new\(AbstractValueKind\.(BytesType|Bytes|ListType|List), "([^"]+)", (StaticReturnShape\.\w+)\),\n')
shapes = {kind: {} for kind in ('Bytes', 'BytesType', 'List', 'ListType')}
for name in ('MemberReturns.Core', 'MemberReturns.Extended'):
    for kind, member, shape in returns_pattern.findall(texts[name]):
        assert member not in shapes[kind]
        shapes[kind][member] = shape
    texts[name] = returns_pattern.sub('', texts[name])
assert len(shapes['Bytes']) == 38 and shapes['Bytes'] == shapes['BytesType']
assert len(shapes['List']) == 14 and shapes['List'] == shapes['ListType']
assert shapes['Bytes'].keys() <= byte_methods['Bytes'].keys()
assert shapes['List'].keys() <= list_methods.keys()
assert all(not re.search(r'new\(AbstractValueKind\.(?:Bytes|BytesType|List|ListType),\s*"', path.read_text(encoding='utf-8'))
    for path in frontend.glob('StaticContracts.CallableMembers.*.cs'))

byte_rows = []
for name, source in byte_methods['Bytes'].items():
    match = re.fullmatch(r'(\d+, \d+, "LA\d+", "[^"]+")(?:, parameterNames: \[(.*)\])?', source)
    assert match, (name, source)
    contract, parameters = match.groups()
    suffix = f', {parameters}' if parameters else ''
    byte_rows.append(f'            Add("{name}", {contract}, {shapes["Bytes"].get(name, "null")}{suffix});')

list_rows = []
for name, (mutates, source) in list_methods.items():
    match = re.fullmatch(r'(\d+, \d+, "LA\d+", "[^"]+")(?:, StaticMutationKind\.(\w+))?(.*)', source)
    assert match, (name, source)
    contract, mutation, parameters = match.groups()
    assert mutation == ('MutatesReceiver' if mutates else None), (name, mutation)
    assert not parameters or parameters.startswith(', "')
    list_rows.append(f'            Add("{name}", {contract}, {shapes["List"].get(name, "null")}, '
        f'StaticMutationKind.{mutation or "None"}{parameters});')

callables = replace(callables, '''        if (kind is AbstractValueKind.String or AbstractValueKind.StringType)
            return TryGetStringCallableContract(kind, memberName, out contract);''',
    '''        if (GetBuiltinMemberCatalog(kind) is { } members)
        {
            if (members.TryGetValue(memberName, out var member) && member.Call is { } call)
            {
                contract = call with { ReceiverKind = kind };
                return true;
            }

            contract = default;
            return false;
        }''')
callables = replace(callables, '''        var bytesAndLists = new List<StaticCallableContract>();
        AddBytesCallableContracts(bytesAndLists);
        AddListCallableContracts(bytesAndLists);

        var contracts = new Dictionary<StaticMemberContractKey, StaticCallableContract>(
            core.Length + data.Length + library.Length + bytesAndLists.Count);''',
    '''        var contracts = new Dictionary<StaticMemberContractKey, StaticCallableContract>(core.Length + data.Length + library.Length);''')
callables = replace(callables, '''        foreach (var member in bytesAndLists)
            contracts.Add(new(member.ReceiverKind, member.MemberName), member);
''', '')
start = callables.index('\n        static void AddBytesCallableContracts(')
assert callables.endswith('\n    }\n}\n')
texts['CallableMembers'] = callables[:start].rstrip() + '\n    }\n}\n'

texts['MemberReturns'] = replace(texts['MemberReturns'], '''        if (receiverKind is AbstractValueKind.String or AbstractValueKind.StringType)
        {
            if (StringMemberCatalog.ByName.TryGetValue(memberName, out var member) && member.Return is { } returns)''',
    '''        if (GetBuiltinMemberCatalog(receiverKind) is { } members)
        {
            if (members.TryGetValue(memberName, out var member) && member.Return is { } returns)''')

string_members = texts.pop('StringMembers')
start = string_members.index('\n    private static bool TryGetStringCallableContract(')
string_members = string_members[:start].rstrip()
string_members = replace(string_members, '''                var call = parameters.Length == 0
                    ? new StaticCallableContract(AbstractValueKind.String, name, minimum, maximum, "LA3147", message)
                    : new StaticCallableContract(AbstractValueKind.String, name, minimum, maximum, "LA3147", message, parameterNames: parameters);
                entries.Add(name, (call, returns));''',
    '''                entries.Add(name, (CreateBuiltinMemberCall(AbstractValueKind.String, name, minimum, maximum,
                    "LA3147", message, StaticMutationKind.None, parameters), returns));''')

texts['BuiltinMembers'] = string_members + '''

    private static class BytesMemberCatalog
    {
        internal static readonly Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> ByName = Create();

        private static Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> Create()
        {
            var entries = new Dictionary<string, (StaticCallableContract?, StaticReturnShape?)>(56, StringComparer.Ordinal);
''' + '\n'.join(byte_rows) + '''
            return entries;

            void Add(string name, int minimum, ArgumentCountLimit maximum, string code, string message,
                StaticReturnShape? returns, params string[] parameters)
            {
                entries.Add(name, (CreateBuiltinMemberCall(AbstractValueKind.Bytes, name, minimum, maximum,
                    code, message, StaticMutationKind.None, parameters), returns));
            }
        }
    }

    private static class ListMemberCatalog
    {
        internal static readonly Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> ByName = Create();

        private static Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)> Create()
        {
            var entries = new Dictionary<string, (StaticCallableContract?, StaticReturnShape?)>(27, StringComparer.Ordinal);
''' + '\n'.join(list_rows) + '''
            return entries;

            void Add(string name, int minimum, ArgumentCountLimit maximum, string code, string message,
                StaticReturnShape? returns, StaticMutationKind mutation, params string[] parameters)
            {
                entries.Add(name, (CreateBuiltinMemberCall(AbstractValueKind.List, name, minimum, maximum,
                    code, message, mutation, parameters), returns));
            }
        }
    }

    private static Dictionary<string, (StaticCallableContract? Call, StaticReturnShape? Return)>? GetBuiltinMemberCatalog(AbstractValueKind kind)
        => kind switch
        {
            AbstractValueKind.String or AbstractValueKind.StringType => StringMemberCatalog.ByName,
            AbstractValueKind.Bytes or AbstractValueKind.BytesType => BytesMemberCatalog.ByName,
            AbstractValueKind.List or AbstractValueKind.ListType => ListMemberCatalog.ByName,
            _ => null,
        };

    private static StaticCallableContract CreateBuiltinMemberCall(AbstractValueKind kind, string name, int minimum,
        ArgumentCountLimit maximum, string code, string message, StaticMutationKind mutation, string[] parameters)
        => parameters.Length == 0
            ? new StaticCallableContract(kind, name, minimum, maximum, code, message, mutation)
            : new StaticCallableContract(kind, name, minimum, maximum, code, message, mutation, parameters);
}
'''

for name, value in texts.items():
    paths[name].write_text(value, encoding='utf-8', newline='\n')
paths['StringMembers'].unlink()
print('Consolidated 83 callable and 52 return pairs into the same two receiver catalogs.')
