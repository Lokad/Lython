from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-shared-builtin-member-facts'
first = lab / 'comparison'
repeat = lab / 'repeat'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(first / 'identity.json')
for root in (first, repeat):
    image = read(root / 'identity.json')
    assert image['imageFiles'] == identity['imageFiles']
    assert image['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
    for role, files in image['imageFiles'].items():
        assert {path.name: digest(path) for path in (root / role).iterdir()} == files
    assert read(root / 'summary.json')['verifiedTimedBatches'] == 84
    receipt = read(root / 'archive-receipt.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256'] == digest(root / 'observations.tar.xz')

cold = read(lab / 'cold-allocation.json')
assert cold['verifiedCompilations'] == 28
assert all(row['after'] == [0, 0] and row['admitted'][0] == row['admitted'][1] for row in cold['summary'])
assert (lab / 'reference-contracts.json').read_bytes() == (lab / 'candidate-contracts.json').read_bytes()
contract = read(lab / 'reference-contracts.json')
assert contract['queries'] == 57408 and len(contract['rows']) == 962 and len(contract['returns']) == 596
assert len(contract['diagnostics']) == 33
for target in ('windows-net10', 'windows-net11', 'ubuntu-net11'):
    for suite, count in (('public', 1508), ('whitebox', 550)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
for name, path in {'cold-allocation.json': lab / 'cold-allocation.json',
    **{f'{label}-{name}': root / name for label, root in (('initial', first), ('repeat', repeat))
        for name in ('identity.json', 'summary.json', 'observations.tar.xz')}}.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.patch', '.sh')}
for label, root in (('initial', first), ('repeat', repeat)):
    procedures.update({f'{label}/{name}': root / name for name in
        ('reference-verify.json', 'candidate-verify.json', 'exit-code.txt', 'archive-receipt.json')})
procedures.update({name: first / name for name in ('config.json', 'codecs.json')})
procedures.update({f'probe/{name}': lab / 'probe' / name for name in ('ContractProbe.csproj', 'Program.cs')})
procedures.update({f'{role}-contracts.json': lab / f'{role}-contracts.json' for role in ('reference', 'candidate')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified both worker images, 168 timed batches, 28 first compiles, parity and focused targets.')
