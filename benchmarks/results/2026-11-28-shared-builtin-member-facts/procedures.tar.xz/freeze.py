from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output, run
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior_lab = lab.parent / 'string-member-facts-b1965-20261128'
prior = prior_lab / 'comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
new_source = 'src/Lokad.Lython/Frontend/StaticContracts.BuiltinMembers.cs'
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(prior / 'identity.json')
reference = git('rev-parse', 'HEAD').decode().strip()
assert reference.startswith('bf5123e6f')
assert digest(git('diff', '--binary', old['referenceRevision'], reference, '--', 'src')) == old['sourcePatchSHA256']
assert git('ls-files', '--others', '--exclude-standard', '--', 'src').decode().splitlines() == [new_source]
new_file = run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', new_source], cwd=repo, capture_output=True)
assert new_file.returncode == 1 and b'new file mode ' in new_file.stdout
patch = git('diff', '--binary', reference, '--', 'src') + new_file.stdout
assert patch.count(b'diff --git ') == 6
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(prior / 'candidate') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}

catalog_path = prior / 'representative.json'
assert hash_file(catalog_path) == old['catalogs']['representative.json']['sha256']
catalog = read(catalog_path)
cases = {case['id']: case for case in catalog['cases']}
canonical = lab / 'canonical.json'
cases.update({case['id']: case for case in read(canonical)['cases']})
jobs = [['codecs.utf16.small', 'compile'], ['struct.pack-unpack.small', 'compile'], ['scripts.config-edit.small', 'compile']]
catalog['cases'] = [cases[case] for case, _ in jobs]
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': jobs})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()

payloads = {'codecs.json': jobs[0][0], 'config.json': jobs[2][0]}
for name, case in payloads.items():
    save(pair / name, dict(catalog, cases=[cases[case]]))
save(pair / 'identity.json', dict(sourceRevision=reference, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json', *payloads)},
    canonicalCatalogSHA256=hash_file(canonical),
    purpose='Share bytes and list callable/return facts with their type forms and build only the requested family.'))
copy2(prior_lab / 'summarize.py', lab / 'summarize.py')
cold = (prior_lab / 'measure-cold.py').read_text(encoding='utf-8').replace("('config.json', 'file.json')", "('config.json', 'codecs.json')")
(lab / 'measure-cold.py').write_text(cold, encoding='utf-8', newline='\n')
print(reference, 'two verified worker images and three selected workloads')
