# R223 — source-labelled text CPython checkpoint

Question: what gaps remain for ordinary text and the captured-helper/nonlocal-counter
variant after the material R221 milestone? R221 before/after results alone do not
answer the CPython comparison or generalize to ordinary scripts.

Two existing complete scripts, identical source and complete fixtures/goldens on
both engines; separate compilation, warm and compile-to-result (six jobs). Reuse
fixed fec79 worker, normal adapter0.4, stock VM CPython3.13.16, actual.NET11RC3,
ordinaryGC/tiering, four independent engine/control processes. Five-second warmups,
seven rotated150msrounds. One210sowner/30stop/30margin collection; preserve failures
and all original medians/IQR/widerCPU. Any time-bound shortfall means incomplete
evidence and permits a justified bounded correction, not automatic rejection.

Time full mediated RAM-file I/O, exact output checks and prior-result cleanup;
exclude fixture reset, separate verification/protocol, startup and final cache
teardown. Compilation includes construction/disposal; independent phase medians
need not add. No pending-I/O, embedding tail, RSS or single-change speedup claim.

Use frozenR221 cb03fd47, whose568production hashes equal committed4625; existing
full source delivery42942735331 is still active. Finalize source qualification
from its terminal receipt, independently of later R222 frontend source. Do not
call this later HEAD. R222 is separately focused-qualified and awaits a later batch.

Refresh the affected ordinary-text CPython row and show the labelled captured-helper
variant separately; leave unrelated historical rows intact. Retain previouse543
observations and all controls. Stop when six jobs have identity/output/ownership/
quiet/Closed/zeroexit/join/RAMcleanup/archive-SHA gates, or record precise missing
evidence. Use the measurements to choose the next whole-script design question,
not another local patch chosen solely to keep experimenting.

No VM work has been launched. First acquire a fresh idle lease/inventory. B567 and
all prior runs are terminal/cached; never probe retired paths or query completed
services. Protected B565/referencec271 and B566/candidate9dadd images remain intact.
Only exact committed compressed duplicates may be considered for necessary space;
check actual path/UID/nlink/size/SHA, preserve240MiBfloor/12MiBsetupheadroom. Existing
worker/launch/retrieval machinery must be adapted explicitly, never replay stale
recipes that reference retired core aliases.
