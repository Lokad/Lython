from pathlib import Path
import json

repo = Path.cwd()
r = Path(__file__).parent
plan = repo / 'PLAN.md'
s = plan.read_text(encoding='utf-8')
s = s.replace('** No active VM workers.**', '** B568 text/CPython comparison is active.**')
s = s.replace('last checked02:15:28UTC,', 'last checked02:19:18UTC,')
s = s.replace('Next query no earlier02:20:28UTC.', 'Next query no earlier02:24:18UTC; enforce this locally before gh.')
s = s.replace('### R223 — next bounded text CPython checkpoint (prepared, not launched)', '### R223 — bounded text CPython checkpoint (active owned collection)')
s = s.replace('Fresh idle/disk lease first; no active VM work. Contract/catalog privately under\ntext-cpython-r223.', 'Fresh idle/disk lease passes. Six-job B568 acknowledged02:22:15.534UTC;\ndo not observe before02:26:45.534UTC (210owner+30stop+30margin). Contract/catalog\nprivately under text-cpython-r223. MainPID3532687; no overlapping VM work.')
s += '''
B568 active: /home/lokad/lython-bench-checks/text-cpython-b568-20261111,
unitlython-b568-text-cpython-20261111. Both protected images hash-verified. Setup
free265,764,864B; fixed240MiBfloor/12MiBsetupheadroom unchanged. Three exact committed
compressed duplicates B566/B567/B463 retired after fresh lease/path/UID/nlink/size/SHA
proof; their remote observations.tgz paths are now off limits. Canonical archives
remain intact. Local setup source-key/quoting and self-matching idle-guard failures
are preserved; no worker started until all guards passed. No collection restart.
'''
plan.write_text(s, encoding='utf-8')
p = r / 'b568/retrieve.py'
t = p.read_text(encoding='utf-8').replace('[d]otnet.* --compare worker|[p]erf record', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py')
p.write_text(t, encoding='utf-8')
print('PLAN records active owner/bounds and retired duplicate paths; retrieval also checks CPython workers.')
