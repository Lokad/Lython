from pathlib import Path
import hashlib, json

root = Path.cwd()
p = Path(__file__).parent
e = root / 'benchmarks/results/2026-11-11-incoming-lexical-stores'
catalog = json.loads((e / 'catalog.json').read_text(encoding='utf-8'))
ids = ['scripts.text-summary-helpers.large', 'scripts.text-summary-helpers.nonlocal-counter.large']
catalog['cases'] = [next(c for c in catalog['cases'] if c['id'] == name) for name in ids]
(p / 'representative.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
identity = json.loads((e / 'source-identity.json').read_text(encoding='utf-8'))
core = root / '.git/agent-notes/review-20261031/incoming-lexical-stores-r221/images/candidate/Lokad.Lython.dll'
assert hashlib.sha256(core.read_bytes()).hexdigest() == identity['coreSHA256']['candidate']
contract = '''# R223 — source-labelled text CPython checkpoint

Question: what gaps remain for ordinary text and the captured-helper/nonlocal-counter
variant after the material R221 milestone? R221 before/after results alone do not
answer the CPython comparison or generalize to ordinary scripts.

Two existing complete scripts, identical source and complete fixtures/goldens on
both engines; separate compilation, warm and compile-to-result (six jobs). Reuse
fixed fec79 worker, normal adapter0.4, stock VM CPython3.13.16, actual.NET11RC3,
ordinaryGC/tiering, four independent engine/control processes. Five-second warmups,
seven rotated150msrounds. One210sowner/30stop/30margin collection; preserve failures
and all original medians/IQR/widerCPU. Any time-bound shortfall means incomplete
evidence and permits a justified bounded correction, not automatic rejection.

Time full mediated RAM-file I/O, exact output checks and prior-result cleanup;
exclude fixture reset, separate verification/protocol, startup and final cache
teardown. Compilation includes construction/disposal; independent phase medians
need not add. No pending-I/O, embedding tail, RSS or single-change speedup claim.

Use frozenR221 cb03fd47, whose568production hashes equal committed4625; existing
full source delivery42942735331 is still active. Finalize source qualification
from its terminal receipt, independently of later R222 frontend source. Do not
call this later HEAD. R222 is separately focused-qualified and awaits a later batch.

Refresh the affected ordinary-text CPython row and show the labelled captured-helper
variant separately; leave unrelated historical rows intact. Retain previouse543
observations and all controls. Stop when six jobs have identity/output/ownership/
quiet/Closed/zeroexit/join/RAMcleanup/archive-SHA gates, or record precise missing
evidence. Use the measurements to choose the next whole-script design question,
not another local patch chosen solely to keep experimenting.

No VM work has been launched. First acquire a fresh idle lease/inventory. B567 and
all prior runs are terminal/cached; never probe retired paths or query completed
services. Protected B565/referencec271 and B566/candidate9dadd images remain intact.
Only exact committed compressed duplicates may be considered for necessary space;
check actual path/UID/nlink/size/SHA, preserve240MiBfloor/12MiBsetupheadroom. Existing
worker/launch/retrieval machinery must be adapted explicitly, never replay stale
recipes that reference retired core aliases.
'''
(p / 'contract.md').write_text(contract, encoding='utf-8')
plan = root / 'PLAN.md'
s = plan.read_text(encoding='utf-8')
s = s.replace('R222 frontend correction is focused-qualified,\n  awaiting commit and a later coherent full delivery boundary.',
              'R222 frontend correction is committed31e66aa6 and focused-qualified;\n  its full delivery joins a later coherent boundary.')
s = s.replace('last checked02:10:02UTC,\n  both platform jobs running actual.NET10 ordinary checks.',
              'last checked02:15:28UTC,\n+  both platforms passed ordinary actual.NET11/.NET10 and installed consumers;\n+  original stress still running. Next query no earlier02:20:28UTC.')
s = s.replace('Seven independent CPython goldens plus three target-isolation diagnostic cases.',
              'Seven independent CPython goldens plus target-isolation/global-barrier diagnostics.')
needle = '## Independent regex final-adapter track'
entry = '''### R223 — next bounded text CPython checkpoint (prepared, not launched)

R221 is a material retained boundary. Compare the existing ordinary text script
and its captured-helper/nonlocal-counter variant to stockCPython, six jobs with
compile/warm/compile-to-result separate. Identical complete scripts/fixtures/output
checks, fixed worker/adapter and ordinaryGC/tiering; controls per engine. This
answers remaining script-shape gaps without inferring external ratios from R221's
within-Lython change. Freeze/source-label4625's measuredcb03 core; R222 remains
separate. Refresh only affected guide coverage; preserve e543 and all adversity.
Use existing210sowner/30stop/30margin and required identity/ownership/quiet/join/SHA
gates. Stop at six usable jobs or precise missing evidence; justified bounded
correction is allowed. No new framework, profile campaign or broad unchanged test.
Fresh idle/disk lease first; no active VM work. Contract/catalog privately under
text-cpython-r223. Source qualification follows activeCI42942735331, never a new
status query against terminal runs. Use the result to prioritize P1; the broader
performance objective remains open after this measurement.

'''
assert needle in s
s = s.replace(needle, entry + needle, 1)
plan.write_text(s, encoding='utf-8')
print('Prepared two existing scripts and bounded R223 contract; PLAN updated. No VM launch.')
