# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent runtime simplification and substantial complete-script gains,
including compilation. An isolated experiment does not complete this objective.

## Actual delivery status

- **Committed runtime:** R221 `4625d83e`, pushed; R219 `1208a681` included.
  R221 removes incoming-write context promotion/name walks using existing cell
  owners. 672internal/2587public focused checks pass per actual.NET11/.NET10.
  R220/R221 evidence is committed2c58ab26. R222 frontend correction is committed31e66aa6 and focused-qualified;
  its full delivery joins a later coherent boundary.
- **Combined delivery active:** exact4625, CI42942735331; last checked02:19:18UTC,
+  both platforms passed ordinary actual.NET11/.NET10 and installed consumers;
+  original stress still running. Next query no earlier02:24:18UTC; enforce this locally before gh. Next query at least5min later. Windows/Ubuntu,
  both targets, original stress and installed Release consumers; keep working.
- **Fully qualified JSON milestone:** runtimee122bdf6, source7714144f,
  cachedGREEN42931921242: Windows/Ubuntu, actual.NET11/.NET10, original stress and
  installed Release consumers. Terminal inspected and cached01:01:22UTC. No replay
  or status query. Earlier42928757271 targeted b8 by mistake; correction preserved.
- R218 current affected CPython rows and original adverse data are committed57df6785.
- **Earlier qualified sources:** runtime69644713, cachedGREEN42918112217; prior
  e543bf15, cachedGREEN42898279287; R207439e91d9, cachedGREEN42888642699.
  Do not query completed runs again or repeat their unchanged qualification.
- **R219/R221 retained, focused-qualified; combined full delivery pending. No active VM workers.** B565/B566/B567 terminal receipts cached;
  all users joined, RAM fixtures removed. R214 variant fully withdrawn; independent
  semantic/alias coverage kept. All568 production sources were restored before R215.

### Recent completed milestones

| Milestone | Delivery / measured result |
| --- | --- |
| R207 lexical loop cleanup | Fully delivered439e91d9: direct same-suite jumps; real cleanup crossings still unwind. CSV allocation−2.47%, CPU uncertainty remains. |
| R208 tuple construction | Fully deliverede543: span constructors remove factory/array-only copying/late scalar admission; true adoption and suspending materialization remain. CSV allocation−3.04%; possible small CPU debt preserved. |
| R209 CSV/text CPython checkpoint | Complete at e543/0e: six jobs164.735s/all gates. WarmCSV1.04–1.07×, text1.36–1.47× CPython, variable controls; compile roughly1.07–1.10×. Historical source. |
| R210/R215 regex development qualification | Immutable dev66 then dev67; current contract/fsdecode fully qualified696. Validate86/524 and development AssumeValid86/528 per target;29-file normal-state isolation proofs. Normal adapter0.4 unchanged. |
| R211–R213 source/cost gates | Text1151samples/5.91%unknown; frontend visitors unchanged and distinct facts still needed. Captured-header reconstruction only serves yielding declarations. No ordinary-frame/frontend rewrite selected from absent costs. |
| R214 native bound-input borrow | Fully withdrawn: useful quiet bound-text elapsed−0.80..−1.58%, allocationflat, control CPU possible debt. Target-cell mutation/finally routing fails to simplify the necessary binder. Independent tests retained155internal/224public per target. |
| R216 call-presence gate | Complete: ordinary signatures use inline64-bit presence, not a parallel bool array. Explicit presence differs from default-filled values for real builtin consumers. No allocation-removal prototype justified. |
| R217 complete JSON string phase | Fully qualifiede122, cachedGREEN42931921242. Removes156net runtime lines and the backend rewrite/unescape/copy chain. Allocationflat; original sync escaped elapsed adversity preserved. Quiet escaped modestly favorable, plain/text uncertain; no general CPU gain. |
| R218 current JSON/report CPython checkpoint | Complete at e122/9dadd59b: six jobs165.178s/all gates. Report warm1.18–1.23×/complete1.09–1.13×; JSON-lines warm0.86–0.89×/complete0.86–0.88×. Variable; no single-change attribution. |

| Delivered milestone | Established result and remaining limits |
| --- | --- |
| Async startup workers | Fully delivered shared sync/async workers, released on genuine suspension. No per-run thread correction remains; historical setup timing is diagnostic, not a current useful-script claim. |
| Shared compiler facts | Corrected exponential shared-expression traversal; binding/module facts are reused. Ordinary CPU dominance is not implied. |
| Direct UTF-8 formatting/storage | Fully qualified. CLR allocation −8.67%; controlled elapsed/CPU about 5–8% lower. Original adverse 15.125 ms observation remains unexplained and preserved. No further unchanged retiming needed. |
| Native helper returns | Fully qualified. CLR allocation −19.92% sync / −19.31% async. Original elapsed changes are diagnostic, distinct from allocation. No remaining delivery check. |
| Shared binding, dictionary accumulation and receiver-aware entry | Fully qualified through 1a83. Removes redundant transport/table probes. Source-specific gains and possible control debt stay in the evidence. |
| Iterative JSON construction, R196 / 8d44 | Fully qualified. Recursive container completion and repeated leaf admission removed; allocation flat, report modestly benefits, other scripts uncertain. Earlier denial near managed nesting bounds is documented. |
| Ordinary-method contexts, R198 / 66eb | Fully qualified. Class-report allocation about −28.5%; quiet elapsed roughly −7–10% sync / −5–10% async, supporting wider CPU. Plain-report uncertainty and desktop adversity remain. |
| Wide enumerate preflight, f6798fd7 | Fully qualified. Funds the next wide magnitude before allocation; small increments remain direct. Preserves source pulls, retained aliases, terminal refusal and reuse. Not a whole-script speedup claim. |
| Private split iteration, R203 / dba779a5 | Fully qualified. Shared scanner/writer and existing iteration replace transient list/value arrays across direct/helper consumption. Allocation about −5.2%; quiet sync text elapsed −1–3% with supporting CPU. CSV flat; report/async uncertain. |
| CPython checkpoint, R197 | Complete: nine jobs / 245.513 s at exact 8d44/E294. Compilation, warm and compile-to-result separated. Historical source, not today's HEAD. |
| Regex core contract | Delivered independently of backend packages. Optional adapter remains non-packable. Final producer qualification is a separate track. |

Detailed evidence and adverse results: [experimental index](benchmarks/EXPERIMENTS.md).
Current source-labelled CPython comparisons: [benchmark guide](docs/BENCHMARKS.md).
R215's contract/fsdecode delivery and both development-adapter modes are preserved
in [its evidence](benchmarks/results/2026-11-10-regex-input-contract/README.md).
Prior plans/source gates remain in `.git/agent-notes/review-20261031/`; retain their
history without expanding this active plan or putting transient narratives in docs/.

## Decisions and unresolved evidence

- **R204 call-source transport is fully withdrawn.** Original quiet sync text
  regressed 5–6% with supporting CPU. One justified refinement leaves sync/CSV
  uncertain and async elapsed favorable; wider CPU mixed. Warm allocation flat;
  compile allocation +0.72–1.01%. All original/refined data, failed staging conditions,
  source variants and cleanup proofs survive. No mapped-source/packet layer or
  preparatory graph changes remain. This is a complexity/debt decision, not a ban.
- **R205 setup source gate is complete.** Fixed functions/signatures already shared;
  module variables contain only __name__/optional __file__. Mutable connected type
  graphs stay per execution. Existing config attribution does not show setup
  dominating; no new lazy namespace/type cache or unchanged profile is justified.
- **R206 allocation refresh is complete.** Qualified dba/101, two existing text/CSV
  scripts, unchanged collector, 256 warmups + 512 checked captures each. All goldens,
  zero-loss, Closed/join and cleanup checks pass. Strings, boxed integers, CSV
  records/value arrays and reservation objects remain material associations; the
  private split cursor is visible. These are statistical interval associations,
  not exact per-type byte shares or CPU costs. [Evidence](benchmarks/results/2026-11-10-current-allocation/README.md).
- R199's CPU shares include useful/inlined work and precede R203. They do not
  establish today's distribution or removable taxes. Frames/binding were not
  prominent. Preserve unknowns, control movement and wider-clock limitations.
- Bulk CSV's earlier 6–8% opportunity was revisited and delivered as canonical
  shared keys and funded row-array adoption (R25), with bounded whole-script
  evidence. The presumed second row copy is gone. Preserve older growth/control
  adversity; do not revive the unchanged prototype or discard it for a fixed threshold.
- Slower call-arena/call-control designs, dual scalar representation (R176), local
  integer sidecars (R188), cold-body variants (R200), JSON scanner (R201), and
  coarse host grants (R202) remain lessons. Their source/evidence is preserved;
  none is a dormant runtime backend or permanent prohibition on a new design.

## Prioritized delivery and redesign roadmap

### P0 — finish active combined R219/R221 delivery without blocking development

R217 delivery is complete: exact7714144f/runtimee122, cachedGREEN42931921242,
all required platform/target/stress/installed-consumer gates inspected. R218 guide
and evidence now record its qualification separately from later source. Never
query this terminal again. R219 and R221 are committed and focused-qualified; combined delivery42942735331
runs on exact4625. Inspect terminal required steps once, cache, and update evidence.
R222 correctness work continues independently; no unchanged qualification replay.

R217's entire displaced backend string parser is gone: Utf8JsonReader, lenient
4x scratch/rewrite/unescape buffers, temporary final copy, CLR-string fallback,
JsonException catches and backend coordinate remapping. One native validate/measure
pass fills admitted final UTF-8 storage. CPython EOF/error goldens found a real
truncated-escape correction. Unsupported unpaired surrogates now produce a clear
Python ValueError. Final coordinate walks add cooperative cancellation. Supported
values, hooks, record keys, offsets, refusal, retained aliases and reuse are covered.

Retain the simplification with explicit timing uncertainty: original desktop sync
escaped+3.15..5.80% adverse, async−2.15..2.38%; unchanged compileCSV+24..30% is not
attributed to JSON. Quiet escaped elapsed−1.85..−0.22%/widerCPU−5.30..−3.91%; plain
elapsed−3.67..+6.56%, text−3.44..+0.92%. Final cold cleanup follows measured images
and is labelled separately. [Source, all failures and checks](benchmarks/results/2026-11-11-json-string-decoder/README.md).

### P1 — Select and complete the next whole-script simplification

Return to current producer/consumer pipelines; no new timed prototype is selected
merely to keep an experiment moving. A bounded source/cost gate must identify a
complete removable phase, affected scripts and source-level acceptance, or record
explicit uncertainty. Existing text/report samples contain useful/inlined work and
unknowns; frame construction is not demonstrated dominant. Do not repeat unchanged
profiles or resurrect already-delivered setup/transport work without a new question.

| Boundary | Current facts / coherent deletion requirement |
| --- | --- |
| Calls/frames | Direct binding, deferred contexts, shared workspace and receiver-aware native entry already exist. R204 maps/packets regressed original text; R214 adds target mutation for a small gain. Select only an actual duplicated complete construction phase, without another sidecar/fast-path layer. |
| Operands/scalars | Boxed integers remain material allocations; old scalar CPU samples are modest. R176/R188 saved bytes without proving simpler/faster complete execution. Account for producers, consumers, identity/escape/materialization and public ingress, not a universal tagged-value rewrite by default. |
| Records | CSV already supplies raw rows, adopts funded capacity, shares keys and admits ordinary fields together. No presumed list shell, second values array or per-field admission needs reimplementation. Preserve mutable headers, distinct row values and reentrant admission. |
| Text | Casing/split/format write UTF-8 final storage; JSON valid-token paths avoid CLR strings. .NET11 numeric formatting uses UTF-8 TryFormat; the admitted .NET10 char bridge avoids its allocating inherited interface. A FormatBigInteger sample alone is not a temporary-string allocation. |
| Frontend | Shared scope/binding/module facts, precedence climbing, child enumeration and compact declaration metadata are delivered. Name/abstract visitors are byte-identical to R158 and retain different facts. No blind merge, eligibility-state revival or set-copy-only micro-optimization. |


The next selected milestone must state its hypothesis, actual work/storage and
displaced functions/fields, representative scripts, compile/retained-memory costs,
semantic acceptance and a bounded before/after with unchanged controls. No partial
preparatory layer is promoted alone. Cancellation, terminal refusal, aliases and
cleanup must stay effective in the changed path. Temporary regression debt is
acceptable only with a named completion boundary and final retain/refine/withdraw
decision. Remove the displaced-only machinery at that boundary.

Current source corrections: text hashing already uses cancellable bulk AddBytes;
receiver-independent builtin operations and cached hashes already exist. Instructions
are compact/register-like, with forwarded locals and existing shared workspaces.
R216's explicit argument-presence contract is real. Do not assume missing copies,
eager list shells, per-character strings or ordinary per-call namespaces.

### R220/R221 — completed source gate and retained lexical-store milestone

R220 reuses immutable R211 stacks: all64Monitor immediate callers uniquely mapped,
38aggregate split /26UTF8 string-line admission chains; no demonstrated duplicate
transition or contention. No new budget/grant policy. Original map guard retained.
[Evidence](benchmarks/results/2026-11-11-memory-lock-callers/README.md).

R221 `4625d83e` removes incoming-write context promotion, lexical walks and repeated
cell synchronization. Existing owner updates live slot/namespace once after operand
cleanup; real ownerless/namespace cases retain resolver. No new fields/owners/options.
Counter CSV/text/report complete variants: CLR allocation−41.4/47.9/27.5%; quiet
warm elapsed−16–17/19–21/12–15%, supporting widerCPU. Compilation allocation flat;
original desktop adversity preserved, ordinary-text control neutrality unresolved
(possible roughly+1.2% debt). Four quiet jobs145.631s, all identity/output/ownership/
quiet/join/archive gates pass. Source hashes match committed4625. 672internal/
2587public focused checks per actual target. Combined delivery active; do not
attribute these counter variants to old CPython rows or claim universal gains.
[Evidence](benchmarks/results/2026-11-11-incoming-lexical-stores/README.md).

### R222 — nonlocal rebinding diagnostics corrected; focused delivery complete

Scope validation already resolves every nonlocal target. Reuse that exact target
fact in local-name diagnostics; no new visitor or call-effect tracing. Cells with
nested nonlocal declarations use runtime unbound checks, including after delete,
handler clearing, transitive/class/generator callbacks. Genuine local/global
barriers and implicit class cells remain distinct. Read-only declared nonlocals
also conservatively defer diagnosis; ordinary certainly unbound locals keep LA3146.
This intentional diagnostic tradeoff is in docs/COMPATIBILITY.md. Runtime semantics,
ownership, cancellation and representation do not change; no performance claim.

Seven independent CPython goldens plus target-isolation/global-barrier diagnostics.
1393public and505internal focused checks pass on each actual.NET11/.NET10, including
cancellation/shared-memory tests; both APIs, sequential reuse and final zero balance.
Original R221 source/failure survives unchanged. No timing or repeated full delivery
is needed for this correctness fix; batch its platform qualification at the next
coherent source boundary. Source/check records: nonlocal-diagnostics-r222 privately.

### R219 — retained regex working-storage consolidation; batch qualification pending

Committed1208a681. The existing prepared subject owns one admitted coordinate
array and scalar cursor through actual cleanup, including pending replacement I/O.
ASCII needs no coordinate array. Two per-match arrays/scratch reservation, caller
cursor fields/ref forwarding and a duplicate match-construction overload are gone.
Retained matches remain independent; no new cache/owner/option/provider dependency.
Holding workspace across active iteration is conservative and documented.

64internal/397public regex checks pass on each actual target, including genuine
suspension, terminal refusal, active backward cancellation and budget reuse. New
Python goldens cover retained reverse reads/callbacks and late original windows.
Known0.4 reversed-window refusal and setup failures survive alongside passing core
provider-window tests. Unicode iteration CLR allocation−17.3..18.1% on both APIs;
compile and complete CSV/text allocation flat. Desktop controls up to52.28% and
compile/elapsed adversity preclude CPU/neutrality claims. No quiet confirmation,
CPython update or normal adapter promotion. Full platform/stress/installed-consumer
checks join the next coherent retained runtime boundary. [Evidence](benchmarks/results/2026-11-11-regex-projection-storage/README.md).

### P2 — Representative comparison coverage

R218 closes the affected JSON/report checkpoint after the material retained JSON
milestone. Fresh forced postcommit build7714144f, all568production sources equal
committede122, core9dadd59b; fixed fec79 worker, adapter0.4, CPython3.13.16. Six jobs,
three separate phases, four processes/job,5s warmup/7rotated150msrounds, all identity,
output, budget, quiet, Closed/join and archive gates pass. [Evidence](benchmarks/results/2026-11-11-json-cpython-checkpoint/README.md).

Only affected guide rows are refreshed; R209 CSV/text and older sources remain
labelled. Mediated RAM-file I/O, full timed output checks and prior-result cleanup
included; staging/reset, separate verification, protocol, startup and final cache
teardown excluded. Independent phase medians need not add. Pending I/O, RSS and
embedding tail latency remain unmeasured. Next targeted refresh follows a material
retained boundary, not every local experiment. No unchanged repeat is selected.

### R223 — bounded text CPython checkpoint (active owned collection)

R221 is a material retained boundary. Compare the existing ordinary text script
and its captured-helper/nonlocal-counter variant to stockCPython, six jobs with
compile/warm/compile-to-result separate. Identical complete scripts/fixtures/output
checks, fixed worker/adapter and ordinaryGC/tiering; controls per engine. This
answers remaining script-shape gaps without inferring external ratios from R221's
within-Lython change. Freeze/source-label4625's measuredcb03 core; R222 remains
separate. Refresh only affected guide coverage; preserve e543 and all adversity.
Use existing210sowner/30stop/30margin and required identity/ownership/quiet/join/SHA
gates. Stop at six usable jobs or precise missing evidence; justified bounded
correction is allowed. No new framework, profile campaign or broad unchanged test.
Fresh idle/disk lease passes. Six-job B568 acknowledged02:22:15.534UTC;
do not observe before02:26:45.534UTC (210owner+30stop+30margin). Contract/catalog
privately under text-cpython-r223. MainPID3532687; no overlapping VM work. Source qualification follows activeCI42942735331, never a new
status query against terminal runs. Use the result to prioritize P1; the broader
performance objective remains open after this measurement.

## Independent regex final-adapter track

Core contract/fsdecode delivery is fully qualified69644713, cachedGREEN42918112217.
Valid/stable UTF-8 borrows, original-subject windows, byte captures/scalar positions,
effective flags, current tokens and explicit ownership are delivered independently
of backend packages. Normal optional non-packable adapter stays0.4; no fallback dialect.
Immutable dev67/d8eb14a5 passes86internal/524public Validate and86/528 development
AssumeValid checks per actual target; each29-file normal-state proof passes.
Allocation flat; original/longer-warmup adversity and uncertainty remain in
[the R215 evidence](benchmarks/results/2026-11-10-regex-input-contract/README.md).
No unchanged producer qualification or normal pin promotion is selected.

Pending final capabilities remain precise:

- Separate single-match working ownership, independent of retained results.
- Native UTF-8 group-name enumeration; native lookup already exists.
- Token-independent cursor creation with cancellable preparation; per-move tokens
  exist, but None at creation does not prove interruption during preparation.

A native byte-range single-match migration must retire discarded DetailedData
projections and preserve exact Match/FullMatch alternative selection, original
windows, captures, cancellation and working/result funding. Filtering Search is
not equivalent. Development producers/adapter-local bridges may support this;
retire bridges when native APIs arrive and qualify an immutable released input.
Separate contract tests from final backend performance/safety assessment, including
producer SizeOf usage. Missing released APIs defer only affected final adapter
checks, never independent Lython development. Do not reopen memory infrastructure.

## Iteration and delivery

Timeouts, unstable controls and inconclusive samples establish uncertainty. Allow
bounded confirmation/refinement/correction when justified; retain original failures
and adversity. Percentages inform decisions rather than automatically veto useful
simplification. Distinguish deletion, allocation, demonstrated CPU, retained memory
and embedding latency. No blanket one-attempt/no-retiming/permanent closure rules.

Focused Release semantics/cancellation/ownership during development; never overlap
local build/test/timing. Force nonincremental builds after restored source. Batch
Windows/Ubuntu, actual11/10, original stress and installed Release consumers at
meaningful retained boundaries; keep working while CI runs. Observe active CI at
least5min apart, cache terminals, never query completed runs again.

## Lasting constraints and working storage

Fully managed/memory-safe: no unsafe C#, Unsafe APIs, raw pointers, P/Invoke or native
stack probing. Preserve managed stack, host-mediated capabilities, current-token
checkpoints through long work, cycle detection, XML depth, checked bounds and bounded
I/O chunks. No fuel/host quotas, independent caps/hidden allowances, heap tracing/root
inventories, weak reclamation, forced GC, retry after refusal or abandoned users.

Shared borrowed memory funds major capacity, replacement overlap, results/aliases/
caches/pending users until awaited cleanup. Scopes reserve zero. First refusal fails
the command with its structured origin despite suppression/finally returns; cleanup
stays available. Guest-raised MemoryError is catchable. Streaming uses bounded host
commands. Only core Release packages via tools/pack.ps1 to artifacts/nuget/; adapter
non-packable. Publication/tagging postponed.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent evidence; RAM only
for owned fixtures. B565/B566/B567 terminal/cached/no users or fixtures. Last proven free
262,021,120B after B567; fixed240MiBfloor/12MiBsetup headroom unchanged.
Protected qualified baseline is B565/reference b8/696, c27160d5, exact committed
R217 preparation baseline bytes and568source/config equivalence to cachedGREEN42918112217.
Final e122 image9dadd59b in B566 now has cachedGREEN42931921242 source qualification.
Protected baseline remains b8/696 until an owned exact-byte advancement is needed;
no VM work or baseline retirement is selected merely to change its label.
B566 recovery retires all superseded0e and measured JSON-prototype aliases and B565
compressed duplicate after canonical/all-alias/UID/path/size/SHA proof. Do not probe
retired paths again. R218 recovery preserves all detail; R217 preserves measured
and final images. Earlier2f9/101/Dbe/039/E294/379/67 aliases, B563 raw traces/map and
B558/B561/B562/B563/B564 compressed duplicates, B561/B564 confirmation and B562 map
remain retired/off limits. Fresh lease, identity, users joined and archive/SHA before
cleanup; no weakened disk guarantees.

B567 is terminal/cached: four jobs145.631s, all users joined, RAM removed, archive
SHA a161d644 verified locally. No repeat observation. Fresh1208 reference/exactR221
candidate retained; protected qualifiede122/B8 images unchanged. Three canonical
nested compressed duplicates B457/B453/B451 retired after idle lease/path/UID/nlink/
size/SHA proof: do not probe those remote archives again. Recipes, receipts, final
free-space proof and all adverse evidence are in the R221 canonical preparation.

B568 active: /home/lokad/lython-bench-checks/text-cpython-b568-20261111,
unitlython-b568-text-cpython-20261111. Both protected images hash-verified. Setup
free265,764,864B; fixed240MiBfloor/12MiBsetupheadroom unchanged. Three exact committed
compressed duplicates B566/B567/B463 retired after fresh lease/path/UID/nlink/size/SHA
proof; their remote observations.tgz paths are now off limits. Canonical archives
remain intact. Local setup source-key/quoting and self-matching idle-guard failures
are preserved; no worker started until all guards passed. No collection restart.
