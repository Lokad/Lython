from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/call-workspace-allocation-b283-20261105');root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b283-payload.tgz') as archive:archive.extractall(root,filter='data')
identity=json.loads((root/'identity.json').read_text())
base=root.parent/'call-workspace-b282-20261105'
for role in ('candidate','reference'):
    assert hashlib.sha256((base/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b283-call-workspace-allocation-20261105','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=45','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
