from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
prior = lab.with_name("csv-record-pull-20261125")
quiet = lab / "comparison/quiet"
donor = prior / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

jobs = {"warm": [
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
    ["diagnostic.shipment-routing-callbacks", "warm-async"],
    ["diagnostic.text-summary.nonlocal-computed-width.large", "warm-async"],
]}
save(quiet / "jobs.json", jobs)
identity = read(quiet / "identity.json")
assert identity["imageFiles"]["reference"] == read(donor / "identity.json")["imageFiles"]["reference"]
for role, files in identity["imageFiles"].items():
    assert {p.name: digest(p) for p in (lab / role).iterdir()} == files
    verification = read(lab / "comparison" / (role + "-verify.json"))
    assert verification["caseCount"] == 3 and verification["state"] == "Completed"
identity["catalogs"]["jobs.json"] = {"sha256": digest(quiet / "jobs.json")}
save(quiet / "identity.json", identity)
collector = (donor / "collect.py").read_text(encoding="utf-8").replace("b1706-fixtures", "b1706b-fixtures").replace("len(jobs) == 5", "len(jobs) == 3")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(donor / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
launcher = (prior / "quiet.py").read_text(encoding="utf-8").replace("b1706", "b1706b").replace(
    "lython-b1706b-csv-record-pull", "lython-b1706b-csv-record-pull-sync").replace(
    "seconds=190", "seconds=138").replace("RuntimeMaxSec=280", "RuntimeMaxSec=210")
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
save(lab / "verified-raw-replicas.json", [])
archive = (prior / "archive.py").read_text(encoding="utf-8").replace(
    "2026-11-25-csv-record-pull", "2026-11-25-csv-record-pull/sync").replace(
    '==receipt["warmJobs"]==5', '==receipt["warmJobs"]==3').replace("timedBatches=140,lanes=5", "timedBatches=84,lanes=3")
compile(archive, "archive.py", "exec")
write(lab / "archive.py", archive)
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="csv-record-pull-sync-b1706b-20261125",
    reference="csv-read-completed-prefix-b1704-20261125",
    payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
