from pathlib import Path
from statistics import median
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
bench = lab.parents[3]
confirm = lab.with_name("csv-record-pull-sync-confirm-20261125")
tree = bench / ".git/agent-worktrees/csv-record-pull-20261125"
out = bench / "benchmarks/results/2026-11-25-csv-record-pull/sync"
out.mkdir(exist_ok=True)
quiet = lab / "comparison/quiet"
rq = confirm / "comparison/quiet"

read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(quiet / "identity.json")
assert identity == read(rq / "identity.json")
assert all({p.name: digest(p) for p in (lab/role).iterdir()} == files for role, files in identity["imageFiles"].items())
assert digest(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab/"candidate.patch").read_bytes() == subprocess.check_output(["git","-C",tree,"diff","--binary","--","src"])
(lab/"test.patch").write_bytes(subprocess.check_output(["git","-C",tree,"diff","--binary","--","tests"]))

for n in ("identity.json","terminal-status.json","observations.tar.xz"):
    shutil.copyfile(quiet/n, out/n)
shutil.copyfile(lab/"allocation-summary.json",out/"allocation-summary.json")

results = {}
roles = set(identity["coreSHA256"])
for role, folder in (("first",quiet), ("repeat",rq)):
    status = read(folder/"terminal-status.json")
    assert not status["live"] and not status["fixtures"]
    assert digest(folder/"observations.tar.xz") == status["receipt"]["archiveSHA256"]
    with tarfile.open(folder/"observations.tar.xz") as archive:
        assert json.load(archive.extractfile("identity.json")) == identity
        assert archive.getmember("confirmation/confirmation.json").isfile()
        raw = json.load(archive.extractfile("confirmation/confirmation.json"))
        final = json.load(archive.extractfile("confirmation/machine-after.json"))["gate"]
        catalog = {c["id"]:c for c in json.load(archive.extractfile("representative.json"))["cases"]}
    outcome = {
        "complete": raw["complete"],
        "quietFinal": final["quiet"],
        "finalGateReasons": final["reasons"],
        "idleCpuPercent": [w["busyPercent"] for w in final["windows"]],
        "rows":[],
    }
    for job in raw["jobs"]:
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
        assert set(job["identities"]) == roles
        case = catalog[job["case"]]
        elapsed = {}; cpu = {}
        for engine, worker in job["identities"].items():
            assert next(v["sha256"] for v in worker["libraries"] if Path(v["path"]).name=="Lokad.Lython.dll") == identity["coreSHA256"][engine]
            samples = [s for s in job["samples"] if s["engine"] == engine]
            assert len(samples)==7
            for sample in samples:
                r=sample["response"]
                for key in ("sourceSha256","fixtureSha256","expectedOutputSha256"):
                    assert r[key]==case[key]
                assert r["status"]=="Completed" and r["actualOutputSha256"]==case["expectedOutputSha256"]
                assert r.get("actualFilesSha256")==case.get("expectedFilesSha256")
            elapsed[engine] = median(s["response"]["elapsedTicks"]*1000/s["response"]["clockFrequency"]/s["response"]["completedInvocations"] for s in samples)
            cpu[engine] = median(s["externalProcessCpuTicks"]*1000/s["externalCpuFrequency"]/s["response"]["completedInvocations"] for s in samples)
        def diff(values):
            effect = [100*(values[new]/values[old]-1)
                      for new in ("candidate", "candidate-control") for old in ("reference","reference-control")]
            return [min(effect), max(effect)]
        outcome["rows"].append(dict(case=job["case"],lane=job["lane"],elapsedPercent=diff(elapsed),cpuPercent=diff(cpu),
                                    elapsedMediansMs=elapsed, processCpuMediansMs=cpu))
    results[role] = outcome
assert len(results["first"]["rows"])==3 and not results["first"]["quietFinal"]
assert len(results["repeat"]["rows"])==3
if not results["repeat"]["complete"]:
    repeated = out/"confirmation"
    repeated.mkdir(exist_ok=True)
    for n in ("observations.tar.xz","terminal-status.json"):
        shutil.copyfile(rq/n,repeated/n)
(out/"comparison-summary.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8",newline="\n")

common = ["record-outcome.py","freeze.py","prepare.py","archive.py","quiet.py","allocations.py","allocation-catalog.json",
          "reference-allocation-final.json","candidate-allocation-final.json","candidate.patch","test.patch",
          "candidate-build.log","windows-focused.log","test-ubuntu.sh","ubuntu-net10-Lokad.Lython.Tests.log",
          "ubuntu-net10-Lokad.Lython.PublicApi.Tests.log","comparison/reference-verify.json","comparison/candidate-verify.json",
          "comparison/quiet/launch.log","comparison/quiet/storage-custody.json","comparison/quiet/upload.json"]
files = [(lab/name, name) for name in common]
files.extend((confirm/name, "confirmation/"+name) for name in (
    "quiet.py","archive.py","comparison/quiet/launch.log","comparison/quiet/storage-custody.json","comparison/quiet/upload.json"))
files.append((confirm.parent/"prepare-1706b-confirm.py", "confirmation/prepare.py"))
with tarfile.open(out/"procedures.tar.xz","w:xz") as a:
    for path,name in files: a.add(path,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as a:
    assert all(hashlib.sha256(a.extractfile(n).read()).hexdigest()==digest(p) for p,n in files)
print(json.dumps(results,indent=2))
