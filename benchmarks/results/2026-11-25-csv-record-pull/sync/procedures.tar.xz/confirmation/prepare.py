from pathlib import Path
import hashlib,json,shutil,tarfile
notes=Path(".git/agent-notes/review-20261031")
old=notes/"csv-record-pull-sync-20261125"
lab=notes/"csv-record-pull-sync-confirm-20261125"
q=lab/"comparison/quiet"
q.mkdir(parents=True,exist_ok=True)
stage=old/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding="utf-8",newline="\n")
terminal=read(stage/"terminal-status.json")
assert terminal["exitCode"]=="1" and not terminal["fixtures"] and not terminal["receipt"]["complete"]
assert sha(stage/"observations.tar.xz")==terminal["receipt"]["archiveSHA256"]
with tarfile.open(stage/"observations.tar.xz") as ar:
 assert json.load(ar.extractfile("confirmation/machine-after.json"))["gate"]["quiet"] is False
 for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh"):
  assert hashlib.sha256(ar.extractfile(name).read()).hexdigest()==sha(stage/name)
identity=read(stage/"identity.json")
for role,files in identity["imageFiles"].items():
 assert {p.name:sha(p) for p in (old/role).iterdir()}==files
 assert read(old/"comparison"/(role+"-verify.json"))["state"]=="Completed"
for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh"):
 shutil.copyfile(stage/name,q/name)
assert b"\r" not in (q/"run.sh").read_bytes()
launcher=(old/"quiet.py").read_text(encoding="utf-8").replace("b1706b","b1706bc").replace("seconds=138","seconds=159")
start=launcher.index("assert donor['complete']")
end=launcher.index("\nwith (base",start)
launcher=launcher[:start]+f"""assert not donor['complete'] and donor['guestFixturesRemoved'] and donor['archivedAndVerifiedUnderLease']
assert digest(reference/'observations.tar.xz')==donor['archiveSHA256']=={terminal['receipt']['archiveSHA256']!r}"""+launcher[end:]
launcher=launcher.replace(",'candidate-core.dll'", "")
a=launcher.index("   if name=='Lokad.Lython.dll'")
b=launcher.index("   assert digest(image/name)",a)
launcher=launcher[:a]+"   os.link(reference/role/name,image/name)\n"+launcher[b:]
launcher=launcher.replace("needs one core, receipts and working room","needs receipts and working room")
compile(launcher,"quiet.py","exec")
write(lab/"quiet.py",launcher)
write(lab/"verified-raw-replicas.json","[]\n")
archive=(old/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-csv-record-pull/sync","2026-11-25-csv-record-pull/sync/confirmation")
write(lab/"archive.py",archive)
payload=q/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as out:
 for name in ("identity.json","representative.json","jobs.json","collect.py","run.sh"):
  out.add(q/name,arcname=name)
write(q/"upload.json",json.dumps(dict(root="csv-record-pull-sync-b1706bc-20261125",
reference="csv-record-pull-sync-b1706b-20261125",payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size),
indent=2)+"\n")
