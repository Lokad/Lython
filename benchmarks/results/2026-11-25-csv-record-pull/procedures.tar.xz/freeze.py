from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/csv-record-pull-20261125"
prior = lab.with_name("retire-clr-cursor-adapter-20261125")
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)

def git(*args, cwd=repo):
    return subprocess.check_output(["git", *args], cwd=cwd)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

base = git("rev-parse", "308da2e40").decode().strip()
assert git("rev-parse", "HEAD", cwd=worktree).decode().strip() == base
prior_identity = json.loads((prior / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
changes = git("diff", "--name-only", "--", "src", cwd=worktree).decode().splitlines()
assert len(changes) == 2 and all(name.startswith("src/Lokad.Lython/") for name in changes), changes
source_patch = lab / "candidate.patch"
source_patch.write_bytes(git("diff", "--binary", "--", "src", cwd=worktree))
archive = lab / "base.zip"
root_files = set(git("ls-tree", "--name-only", base).decode().splitlines())
build_inputs = ("global.json", "Directory.Build.props", "Directory.Build.targets", "Directory.Build.rsp",
                "Directory.Packages.props", "NuGet.Config")
git("archive", "--format=zip", f"--output={archive}", base, "--",
    *[name for name in build_inputs if name in root_files], "src/Lokad.Lython")
frozen = lab / "frozen-candidate"
with zipfile.ZipFile(archive) as bundle:
    bundle.extractall(frozen)
    for name in changes:
        shutil.copyfile(worktree / name, frozen / name)
    for name in bundle.namelist():
        if name.endswith("/"):
            continue
        expected = (worktree / name).read_bytes() if name in changes else bundle.read(name)
        assert (frozen / name).read_bytes() == expected, name

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / "candidate-build.log").open("wb") as log:
    subprocess.run([dotnet, "build", "src/Lokad.Lython/Lokad.Lython.csproj", "-c", "Release", "-f", "net11.0",
                    "--no-incremental", "--artifacts-path", lab / "candidate-build"],
                   cwd=frozen, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180)
assert git("diff", "--binary", "--", "src", cwd=worktree) == source_patch.read_bytes()
core = lab / "candidate-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
previous = lab.with_name("csv-read-completed-prefix-20261125")
previous_identity = json.loads((previous / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
assert git("diff", "--binary", "701f0b1e5", "96d54066a", "--", "src") == (previous/"candidate.patch").read_bytes()
old = previous_identity["imageFiles"]["candidate"]
assert {p.name: sha(p) for p in (previous / "candidate").iterdir()} == old
baseline = previous / "candidate/Lokad.Lython.dll"
prior_identity = previous_identity
prior = previous
cores = {"reference": baseline, "candidate": core}
images = {role: old | {binary.name: sha(binary)} for role, binary in cores.items()}
for role, files in images.items():
    output = lab / role
    output.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(cores[role] if name == core.name else prior / "candidate" / name, output / name)
    assert {p.name:sha(p) for p in output.iterdir()} == files

catalog = quiet / "representative.json"
shutil.copyfile(lab / "input-catalog.json", catalog)
assert sha(catalog) == sha(lab / "input-catalog.json")
identity = dict(sourceRevision=base, comparisonRevision=git("rev-parse", "96d54066a").decode().strip(), sourcePatchSHA256=sha(source_patch), imageFiles=images,
                coreSHA256={role + suffix: files[core.name] for role, files in images.items() for suffix in ("", "-control")},
                expectedCPythonSHA256=prior_identity["expectedCPythonSHA256"], cpythonWorkerSHA256=prior_identity["cpythonWorkerSHA256"],
                catalogs={catalog.name: dict(sha256=sha(catalog))},
                purpose="Share CSV source progression and continue only after an outstanding pull")
(quiet / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
python_worker = repo / "benchmarks/cpython-worker.py"
assert sha(python_worker) == identity["cpythonWorkerSHA256"]
for role, files in images.items():
    evidence = lab / "comparison" / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
                    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", python_worker,
                    "--out", evidence], cwd=repo, env=env, check=True, timeout=65)
    report = json.loads(evidence.read_text(encoding="utf-8"))
    assert report["state"] == "Completed" and report["caseCount"] == 5
    assert report["launched"]["library"]["sha256"] == files[core.name]
    assert report["catalogSha256"] == sha(catalog)
print("Both complete images verified against five CPython goldens.")
