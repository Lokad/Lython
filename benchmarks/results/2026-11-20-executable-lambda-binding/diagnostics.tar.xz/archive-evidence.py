from pathlib import Path
import gzip
import hashlib
import json
import re
import tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-20-executable-lambda-binding')
read=lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
pair=read(lab/'frozen-identity.json')
assert pair['referenceCommit'].startswith('9b14997e4') and pair['candidateCommit'].startswith('5f42f319c')
assert pair['casesSHA256']==sha(lab/'catalog.json')
cases={row['id'] for row in read(lab/'catalog.json')['cases']}
assert len(cases)==3
helpers={}
for role, files in pair['images'].items():
    image=lab/'frozen'/role
    assert len(files)==32 and {name:sha(image/name) for name in files}==files
    checked=read(lab/f'{role}-verify.json')
    assert checked['state']=='Completed' and checked['catalogSha256']==pair['casesSHA256']
    rows=read(lab/f'{role}-allocation.json')['rows']
    assert {row['id'] for row in rows}==cases and all(row['sharedBudgetBaselineRestored'] for row in rows)
    helpers[role]={name:sha(image/name) for name in
                   ('ManagedRetention.dll','ManagedRetention.deps.json','ManagedRetention.runtimeconfig.json')}
    for repeat in (1,2):
        report=read(lab/f'{role}-retention-{repeat}.log')
        assert report['coreSha256']==files['Lokad.Lython.dll']
        rows=report['rows']
        assert {row['id'] for row in rows}==cases and all(row['sharedBudgetBaselineRestored'] for row in rows)
        assert all(len(row['liveBytes'])==len(row['allocatedBytes'])==5 for row in rows)
assert helpers['reference']==helpers['candidate']
for platform in ('windows','ubuntu'):
    for suite,count in [('Lokad.Lython.PublicApi.Tests',317),('Lokad.Lython.Tests',104)]:
        assert re.search(rf'Failed:\s+0, Passed:\s+{count},',(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig'))
reference_core=Path('benchmarks/results/2026-11-20-funded-definition-construction/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(reference_core.read_bytes())).hexdigest()==pair['images']['reference']['Lokad.Lython.dll']
out.mkdir(exist_ok=True)
summary=read(lab/'summary.json')
assert len(summary['rows'])==15
summary.update(retained='68215bac8',focusedTests={'windowsNet11':421,'ubuntuNet10':421},
               retentionHelper=helpers['candidate'],cores={role:files['Lokad.Lython.dll'] for role,files in pair['images'].items()})
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'diagnostics.tar.xz','w:xz',preset=6) as archive:
    for name in ('catalog.json','frozen-identity.json','archive-evidence.py','freeze-and-verify.py','freeze.log',
                 'candidate-build.log','retention-build.log','measured-source.patch','test-ubuntu.sh',
                 'managed-retention/ManagedRetention.csproj','managed-retention/Program.cs'):
        archive.add(lab/name,arcname=name)
    archive.add(lab.parent/'funded-definition-construction/candidate-build.log',arcname='reference-build.log')
    for role in pair['images']:
        for suffix in ('verify.json','verify.log','allocation.json','allocation.log','retention-1.log','retention-2.log'):
            name=f'{role}-{suffix}'
            archive.add(lab/name,arcname=name)
    for platform in ('windows','ubuntu'):
        for suite in ('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests'):
            name=f'{suite}-{platform}.log'
            archive.add(lab/name,arcname=name)
print('Verified four retained-memory processes, three goldens per image and both platform receipts.')
