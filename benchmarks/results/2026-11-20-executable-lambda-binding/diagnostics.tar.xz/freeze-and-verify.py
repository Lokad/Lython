import hashlib
import re
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
trial = repo / '.git/agent-worktrees/executable-lambda-binding'
prior = lab.parent / 'factory-ownership-profile'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args])

pair = read(prior/'identity.json')
reference = pair['sourceRevision']
candidate = git('-C', trial, 'rev-parse', 'HEAD').decode().strip()
assert reference.startswith('9b14997e4') and candidate.startswith('5f42f319c')
assert git('merge-base', reference, candidate).decode().strip() == reference
assert not git('-C', trial, 'status', '--porcelain')
assert not git('diff','--name-only',reference,candidate,'--','global.json','Directory.Build.props','Directory.Packages.props',
               'src/Lokad.Lython.Utf8Regex','benchmarks')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',reference,candidate))

catalog = read(lab.parent/'lowered-default-values/catalog.json')
validator = next(row for row in catalog['cases'] if row['id']=='scripts.config-generated-guards.medium')
catalog['cases']=[validator]
def case(identifier, source, size):
    result=subprocess.check_output(['C:/Python313/python.exe','-I','-X','utf8','-c',source]).decode('utf-8').replace('\r\n','\n')
    fixture=json.dumps(dict(size=size,text=None),separators=(',',':'))
    return dict(id=identifier,family='scripts',category='whole-script',scale='medium',size=size,
                source=source,fixtureJson=fixture,expectedOutput=result,sourceUtf8Bytes=len(source.encode('utf-8')),
                expectedOutputUtf8Bytes=len(result.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
                sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),
                fixtureSha256=hashlib.sha256(fixture.encode('utf-8')).hexdigest(),
                expectedOutputSha256=hashlib.sha256(result.encode('utf-8')).hexdigest())
count=128
lambdas=''.join(f"        lambda value, threshold=seed+{index}, *, labels=('rule-{index}',): (value+threshold, labels[0]),\n"
                for index in range(count))
rules="def make(seed):\n    return [\n"+lambdas+'''    ]
total = 0
characters = 0
rules = make(100)
for index, rule in enumerate(rules):
    value, label = rule(index)
    total += value
    characters += len(label)
print(total, characters)
'''
sort='''values = [(i % 7, i) for i in reversed(range(2048))]
values.sort(key=lambda row: row[0])
print(len(values), sum(i * item[1] for i, item in enumerate(values)))
'''
catalog['cases']=[case('scripts.lambda-rule-table.generated',rules,count),case('lists.stable-lambda-sort',sort,2048),validator]
manifest = lab/'catalog.json'
write(manifest,catalog)

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
files = pair['imageFiles']['candidate']
origin = prior/'candidate'
core = 'Lokad.Lython.dll'
assert len(files)==32 and {name:sha(origin/name) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for name in files:
        shutil.copyfile(origin/name,image/name)
    expected=files.copy()
    if role=='candidate':
        built=lab/'build-win/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(built,image/core)
        expected[core]=sha(built)
    for helper in (lab.parent/'method-format-frame/frozen/reference').glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    helper_dir=lab/'managed-retention/bin/Release/net11.0'
    helper_names=('ManagedRetention.dll','ManagedRetention.deps.json','ManagedRetention.runtimeconfig.json')
    helper_files={name:sha(helper_dir/name) for name in helper_names}
    for name in helper_files: shutil.copyfile(helper_dir/name,image/name)
    assert {name:sha(image/name) for name in helper_files}==helper_files
    def run(kind, arguments, environment=env):
        with (lab/(role+'-'+kind+'.log')).open('wb') as log:
            subprocess.run([dotnet,*arguments],env=environment,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    assert {name:sha(image/name) for name in expected}==expected
    verify=lab/(role+'-verify.json')
    run('verify',[image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
                  '--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py','--out',verify])
    verified=read(verify)
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    for repetition in (1,2):
        receipt=f'retention-{repetition}'
        run(receipt,[image/'ManagedRetention.dll',manifest],dict(env,DOTNET_TieredCompilation='0'))
        assert read(lab/(role+'-'+receipt+'.log'))['coreSha256']==expected[core]
    run('allocation',[image/'ValidatedAllocation.dll',image,manifest,lab/(role+'-allocation.json')])
    assert {name:sha(image/name) for name in expected}==expected
    images[role]=expected
assert images['reference'][core]!=images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
rows=[]
def summarize(boundary,metric,observations):
    for a,b in zip(*observations,strict=True):
        assert a['id']==b['id'] and a['sharedBudgetBaselineRestored'] and b['sharedBudgetBaselineRestored']
        before,after=[statistics.median(row[metric]) for row in (a,b)]
        row=dict(boundary=boundary,id=a['id'],referenceBytes=before,candidateBytes=after,changePct=100*(after/before-1))
        if 'peakExecutionMemoryBytes' in a:
            row.update(referencePeak=a['peakExecutionMemoryBytes'],candidatePeak=b['peakExecutionMemoryBytes'])
        rows.append(row)
        print(boundary,a['id'],f'{before:,} to {after:,} {row["changePct"]:+.2f}%')
for repetition in (1,2):
    observations=[read(lab/(role+f'-retention-{repetition}.log'))['rows'] for role in images]
    for metric in ('liveBytes','allocatedBytes'):
        summarize(f'{metric}-{repetition}',metric,observations)
summarize('warm-allocation','allocatedBytesPerInvocation',[read(lab/(role+'-allocation.json'))['rows'] for role in images])
write(lab/'summary.json',dict(reference=reference,candidate=candidate,verification='Three CPython goldens per full 32-file image.',rows=rows))
