namespace Lokad.Lython.Frontend;

internal static class StaticAnalyzer
{
    public static IReadOnlyList<LythonDiagnostic> Analyze(ScriptSyntax script, ILythonRegexProvider? regexProvider = null, Runtime.MemoryGovernor? governor = null, CancellationToken cancellationToken = default)
    {
        using var context = new StaticAnalysisContext(script, regexProvider, governor, cancellationToken);
        return Analyze(context);
    }

    internal static IReadOnlyList<LythonDiagnostic> Analyze(StaticAnalysisContext context)
    {
        var kinds = context.Script.PreparedAnalysisKinds;
        Check();
        if ((kinds & FrontendAnalysisKinds.Directives) != 0)
            StaticScopeDirectiveDiagnostics.Analyze(context);
        Check();
        StaticAbstractInterpreter.Analyze(context);
        Check();
        if ((kinds & FrontendAnalysisKinds.FunctionBindings) != 0)
            StaticNameBindingDiagnostics.Analyze(context);
        Check();
        return context.Diagnostics;

        void Check()
        {
            context.MemoryGovernor?.ThrowIfAdmissionFailed();
            PythonTokenization.CheckCancellation(context.CancellationToken, 0);
        }
    }

}
