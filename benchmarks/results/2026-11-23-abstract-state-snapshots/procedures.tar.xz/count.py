from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/abstract-binding-probe-20261123"
out=lab/"bindings-probe"
out.mkdir()
catalog=lab/"comparison/representative.json"
manifest=json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))["imageFiles"]["reference"]
source=tree/"src/Lokad.Lython/Frontend/AbstractState.cs"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet),
         PATH=str(sdk)+os.pathsep+os.environ["PATH"])
names=["Clones","ValueCopies","ValueEntries","LengthCopies","LengthEntries"]
def run(args,cwd=tree,**kw):subprocess.run(args,cwd=cwd,env=env,timeout=100,check=True,**kw)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,data):p.write_text(data,encoding="utf-8",newline="\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=tree)

instrumentation = "\n".join("    internal static int Diagnostic"+name+";" for name in names)+"\n"
for role, revision in (("reference","e8fd8b73f"),("candidate","2e5e316c1")):
    assert not git("status","--porcelain")
    run(["git","checkout","--detach",revision])
    physical=source.read_bytes()
    try:
        data=source.read_text(encoding="utf-8").replace("internal sealed class AbstractState\n{\n",
            "internal sealed class AbstractState\n{\n"+instrumentation)
        if role=="reference":
            a,b=data.index("    public AbstractState Clone()"),data.index("    // The caller relinquishes")
            original=data[a:b]
            assert "Clone() => new(" in original
            data=data[:a]+"""    public AbstractState Clone()
    {
        DiagnosticClones++;
        DiagnosticValueCopies++;
        DiagnosticValueEntries += _values.Count;
        DiagnosticLengthCopies++;
        DiagnosticLengthEntries += _sequenceLengths.Count;
        return new(new(_values, StringComparer.Ordinal), new(_sequenceLengths, StringComparer.Ordinal), AnalysisContext);
    }

"""+data[b:]
        else:
            data=data.replace("        _valuesShared = _sequenceLengthsShared = true;",
                "        DiagnosticClones++;\n        _valuesShared = _sequenceLengthsShared = true;")
            data=data.replace("            _values = new(_values, StringComparer.Ordinal);",
                "            DiagnosticValueCopies++;\n            DiagnosticValueEntries += _values.Count;\n"
                "            _values = new(_values, StringComparer.Ordinal);")
            data=data.replace("            _sequenceLengths = new(_sequenceLengths, StringComparer.Ordinal);",
                "            DiagnosticLengthCopies++;\n            DiagnosticLengthEntries += _sequenceLengths.Count;\n"
                "            _sequenceLengths = new(_sequenceLengths, StringComparer.Ordinal);")
        write(source,data)
        (out/f"{role}.patch").write_bytes(git("diff","--binary","--","src"))
        with (out/f"{role}-build.log").open("w",encoding="utf-8") as log:
            run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0",
                "--no-incremental","--artifacts-path",out/role],stdout=log,stderr=subprocess.STDOUT)
    finally:
        source.write_bytes(physical)
    assert not git("status","--porcelain")
    image=out/f"{role}-image"
    image.mkdir()
    reference=lab/"comparison/frozen-reference"
    assert {n:digest(reference/n) for n in manifest}==manifest
    for name in manifest:shutil.copyfile(reference/name,image/name)
    core=image/"Lokad.Lython.dll"
    shutil.copyfile(out/role/"bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll",core)
    assert [n for n in manifest if digest(image/n)!=manifest[n]]==["Lokad.Lython.dll"]
    write(image/"image-hashes.json",json.dumps({n:digest(image/n) for n in manifest},indent=2)+"\n")
project=out/"probe.csproj"
write(project,"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings></PropertyGroup>
  <ItemGroup><Reference Include="Lokad.Lython"><HintPath>reference-image/Lokad.Lython.dll</HintPath></Reference></ItemGroup>
  <ItemGroup><Compile Remove="**/-unused.cs;reference/**;candidate/**" /></ItemGroup>
</Project>
""")
write(out/"Program.cs",'''using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

var names = new[] { "Clones", "ValueCopies", "ValueEntries", "LengthCopies", "LengthEntries" };
var state = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Frontend.AbstractState", true)!;
var fields = names.Select(n => state.GetField("Diagnostic" + n, BindingFlags.NonPublic | BindingFlags.Static)!).ToArray();
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var engine = new LythonEngine();
var owner = new LythonMemoryBudget();
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    foreach (var field in fields) field.SetValue(null, 0);
    using (var result = engine.Compile(item.GetProperty("source").GetString()!, owner))
        if (!result.IsValid || result.Diagnostics.Count != 0) throw new InvalidOperationException("Diagnostics differ.");
    if (owner.ReservedBytes != 0) throw new InvalidOperationException("Allowance not reusable.");
    rows.Add(new { id = item.GetProperty("id").GetString(), counts = names.Zip(fields)
        .ToDictionary(pair => pair.First, pair => (int)pair.Second.GetValue(null)!) });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
''')
with (out/"probe-build.log").open("w",encoding="utf-8") as log:
    run([dotnet,"build",project,"-c","Release","--no-incremental"],cwd=out,stdout=log,stderr=subprocess.STDOUT)
for role in ("reference","candidate"):
    image=out/f"{role}-image"
    for p in (out/"bin/Release/net11.0").glob("probe.*"):shutil.copyfile(p,image/p.name)
    run([dotnet,image/"probe.dll",catalog,out/f"{role}-counts.json"],cwd=repo)
    assert {n:digest(image/n) for n in manifest}==json.loads((image/"image-hashes.json").read_text(encoding="utf-8"))
for a,b in zip(*(json.loads((out/f"{role}-counts.json").read_text(encoding="utf-8")) for role in ("reference","candidate")),strict=True):
    assert a["id"] == b["id"]
    print(a["id"],a["counts"],b["counts"])
