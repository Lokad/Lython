using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

var names = new[] { "Clones", "ValueCopies", "ValueEntries", "LengthCopies", "LengthEntries" };
var state = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Frontend.AbstractState", true)!;
var fields = names.Select(n => state.GetField("Diagnostic" + n, BindingFlags.NonPublic | BindingFlags.Static)!).ToArray();
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var engine = new LythonEngine();
var owner = new LythonMemoryBudget();
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    foreach (var field in fields) field.SetValue(null, 0);
    using (var result = engine.Compile(item.GetProperty("source").GetString()!, owner))
        if (!result.IsValid || result.Diagnostics.Count != 0) throw new InvalidOperationException("Diagnostics differ.");
    if (owner.ReservedBytes != 0) throw new InvalidOperationException("Allowance not reusable.");
    rows.Add(new { id = item.GetProperty("id").GetString(), counts = names.Zip(fields)
        .ToDictionary(pair => pair.First, pair => (int)pair.Second.GetValue(null)!) });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
