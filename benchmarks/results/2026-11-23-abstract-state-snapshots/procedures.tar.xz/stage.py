from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/abstract-state-snapshots-20261123"
out = lab / "comparison"
previous = lab.parent / "borrowed-csv-record-20261123" / "comparison-rebased"
quiet = out / "quiet"
quiet.mkdir(exist_ok=True)
assert not (quiet / 'launch.log').exists()
core = "Lokad.Lython.dll"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): write(p, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def write(p, source):
    if p.suffix == ".py": compile(source, str(p), "exec")
    p.write_text(source, encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)
def published(folder, name): return git("show", f"origin/master:benchmarks/results/{folder}/{name}")
def archive(folder):
    receipt = json.loads(published(folder, "archive-receipt.json"))
    if folder == "2026-11-08-primitive-cpython-checkpoint":
        with tarfile.open(fileobj=io.BytesIO(published(folder,"observations.tar.xz"))) as package:
            data = package.extractfile("observations.tgz").read()
    else:
        data = published(folder, "observations.tgz")
    assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
    assert sha(data) == receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

template = read(previous / "quiet/config.json")
donor = "2026-11-23-borrowed-csv-record"
prior = json.loads(published(donor, "source.json"))
assert prior["imageFiles"]["candidate"] == template["identity"]["imageFiles"]["candidate"]
before = read(out / "identity.json")
candidate = git("rev-parse", "HEAD", cwd=tree).decode().strip()
assert not git("status", "--porcelain", cwd=tree)
patch = git("diff", "--binary", before["patchBase"], candidate, "--", "src", "tests")
assert sha(patch) == before["sourcePatchSHA256"] and patch == (out/"source.patch").read_bytes()
files = before["imageFiles"]
assert prior["imageFiles"]["candidate"] == files["reference"] and len(files["reference"]) == 32
assert [n for n in files["reference"] if files["reference"][n] != files["candidate"][n]] == [core]

inventory = read(lab / "quiet-image-inventory.json")
def retirement_proof(paths, data, folders):
    stats=[inventory["files"][p]for p in paths]
    assert all(s["bytes"]==len(data) and s["links"]==len(paths) and
        (s["device"],s["inode"])==(stats[0]["device"],stats[0]["inode"]) for s in stats)
    return dict(paths=paths,bytes=len(data),sha256=sha(data),links=len(paths),
        archives={root+"/observations.tgz":archive(folder) for root,folder in folders.items()})

old = "2026-11-23-deferred-regex-coordinates-slots"
old_root = "deferred-regex-capture-b1441-20261123"
before_core = gzip.decompress(published(old, "candidate-core.dll.gz"))
assert sha(before_core) == json.loads(published(old,"source.json"))["imageFiles"]["candidate"][core]
assert sha(before_core) not in (manifest[core] for manifest in files.values())
retire = [retirement_proof([old_root+"/candidate/"+core],before_core,{old_root:old})]
catalog = out / "representative.json"
ids = [row["id"] for row in read(catalog)["cases"]]
assert len(ids) == 8
branch = "compiler.generated-read-only-branches"
sparse = next(x for x in ids if x.endswith("sparse-lexical"))
dataclass = next(x for x in ids if "dataclass" in x)
postponed = next(x for x in ids if x.endswith("nested-factories.postponed"))
config = next(x for x in ids if "config-edit" in x)
jobs = [(branch,"compile"),(dataclass,"compile"),(sparse,"compile"),(postponed,"compile"),
        (branch,"compile-run"),(dataclass,"compile-run"),(sparse,"compile-run"),(config,"compile-run")]
assert len(jobs)==8 and {name for name,_ in jobs} <= set(ids)
save(out / "jobs.json", jobs)
shutil.copyfile(catalog, quiet / "representative.json")
for role, manifest in files.items():
    image = out / f"frozen-{role}"
    proof = read(out / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["catalogSha256"] == digest(catalog) and proof["caseCount"] == len(ids)
    assert {n: digest(image / n) for n in manifest} == manifest

(quiet / "candidate").mkdir(exist_ok=True)
shutil.copyfile(out / "frozen-candidate" / core, quiet / "candidate" / core)
identity = {**before, "sourceRevision": before["reference"] + " versus " + candidate, "candidate": candidate,
    "purpose": "Share abstract value and sequence-length maps across read-only compiler branches until mutation.",
    "normalAdapterPin": "0.4.0", "coreSHA256": {r+s:m[core] for r,m in files.items() for s in ("", "-control")},
    "catalogs": {"representative.json": {"sha256": digest(catalog)}}}
save(quiet / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/abstract-state-snapshots-b1442-20261123"
unit = "lython-b1442-abstract-state-snapshots-20261123"
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    source = (previous / "quiet" / name).read_text(encoding="utf-8").replace(template["root"], root).replace(template["unit"], unit)
    if name == "collect.py":
        start, end = source.index("\njob_catalog ="), source.index("\nassert len(jobs)")
        source = source[:start] + "\njob_catalog = " + repr({id:"representative.json" for id in ids}) + "\njobs = " + repr(jobs) + source[end:]
        source = source.replace("if job_index % 2 != 0: labels.reverse()", "if job_index % 2 == 0: labels.reverse()").replace("len(jobs)==8", "len(jobs)==8")
    elif name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8").replace("jobs=8,elapsedSeconds", "jobs=8,elapsedSeconds")
    elif name == "retrieve.py":
        source = source.replace("status['receipt']['jobs']==8", "status['receipt']['jobs']==8")
    write(quiet / name, source.replace("Borrowed CSV records", "Abstract state snapshots"))
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "run.sh", "archive-owned.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts: bundle.add(quiet / name, arcname=name)
unpacked=sum((quiet / n).stat().st_size for n in parts)
minimum=176160768+unpacked+2*1024*1024+512*1024
assert inventory["freeBytes"]+sum(v["bytes"] for v in retire)>minimum
cfg = {**template, "root": root, "unit": unit, "identity": identity, "source": template["root"],
       "sourceFiles": files["reference"], "sourceCatalogSHA256": prior["catalogs"]["representative.json"]["sha256"],
       "donorArchiveSHA256": archive(donor), "retireGroups": retire, "payloadBytes": payload.stat().st_size,
       "payloadSHA256": digest(payload), "unpackedBytes": sum((quiet / n).stat().st_size for n in parts)}
save(quiet / "config.json", cfg)
seed = (previous / "quiet/remote-launch.py").read_text(encoding="utf-8")
a,b = seed.index("\nc=")+1, seed.index("\nb=Path(")
seed = (seed[:a] + "c=" + repr(cfg) + seed[b:]).replace("b1440-fixtures", "b1442-fixtures")
assert "b1442-fixtures" in seed
write(quiet / "remote-launch.py", seed)
launch = (previous / "launch.py").read_text(encoding="utf-8")
write(out / "launch.py", launch.replace("Borrowed CSV records", "Abstract state snapshots"))
summary = (previous / "summarize.py").read_text(encoding="utf-8")
write(out / "summarize.py", summary.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8"))
print(candidate, root, cfg["unpackedBytes"], sum(group["bytes"] for group in retire))
