from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("forwarded-positional-framed-20261124")
template = lab.with_name("closed-pairs-cpython-20261124")
output = lab / "external"
output.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, s: p.write_text(s, encoding="utf-8", newline="\n")
save = lambda p, v: write(p, json.dumps(v, indent=2, ensure_ascii=False) + "\n")
sealed = donor / "comparison/quiet"
receipt = read(sealed / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert digest(sealed / "observations.tar.xz") == receipt["archiveSHA256"]
source = subprocess.check_output(["git", "rev-parse", "6466fbb52"], cwd=repo, text=True).strip()
meta = read(sealed / "identity.json")
patch = subprocess.check_output(["git", "diff", "--binary", meta["sourceRevision"], source, "--", "src", "tests"], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == meta["sourcePatchSHA256"]
assert patch == (donor / "candidate.patch").read_bytes()
assert not subprocess.check_output(["git", "diff", source, "--", "src", "tests"], cwd=repo)
files = meta["imageFiles"]["candidate"]
frozen = lab / "candidate"
frozen.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(donor / "candidate" / name, frozen / name)
assert len(files) == 32 and {p.name: digest(p) for p in frozen.iterdir()} == files

remote_name = "forwarded-positional-cpython-b1625-20261124"
remote_donor = "forwarded-positional-framed-b1624-20261124"
identity = dict(sourceRevision=source, candidate=source, productionSource=source,
    frozenFromPatch=meta["sourcePatchSHA256"], sourceImageArchiveSHA256=receipt["archiveSHA256"],
    imageFiles={"candidate": files}, frozenImage="/home/lokad/lython-bench-checks/" + remote_name + "/candidate",
    auxiliaryFiles={name: value for name, value in files.items() if name != "Lokad.Lython.dll"},
    coreSHA256={key: meta["coreSHA256"][key] for key in ("candidate", "candidate-control")},
    expectedCPythonSHA256=meta["expectedCPythonSHA256"], cpythonWorkerSHA256=meta["cpythonWorkerSHA256"])
catalog = read(sealed / "representative.json")
order = ["scripts.rule-default-closures", "scripts.captured-rule-closures", "scripts.annotated-rule-closures",
         "diagnostic.text-summary.nonlocal-computed-width.large", "scripts.csv-invoice.method-policy.quoted-control"]
assert {case["id"] for case in catalog["cases"]} == set(order)
# Reverse the per-phase order once so no engine starts all lanes after the same mix.
jobs = [(case, phase) for phase, cases in (("warm", order), ("compile", order[::-1]), ("compile-run", order))
        for case in cases]
assert len(jobs) == 15
shutil.copyfile(sealed / "representative.json", output / "representative.json")
assert digest(output / "representative.json") == meta["catalogs"]["representative.json"]["sha256"]
save(output / "jobs.json", jobs)
identity["catalogs"] = {name: {"sha256": digest(output / name)} for name in ("representative.json", "jobs.json")}
save(output / "identity.json", identity)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == identity["cpythonWorkerSHA256"]
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
subprocess.run([dotnet, frozen / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
    "--catalog", output / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
    "--python-worker", protocol, "--out", output / "candidate-verify.json"], cwd=repo, env=env, check=True, timeout=80)
proof = read(output / "candidate-verify.json")
assert proof["state"] == "Completed" and proof["caseCount"] == len(order)
assert proof["launched"]["library"]["sha256"] == identity["coreSHA256"]["candidate"]
assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]

shutil.copyfile(template / "external/run.sh", output / "run.sh")
assert b"\r" not in (output / "run.sh").read_bytes()
collector = (template / "external/collect.py").read_text(encoding="utf-8")
collector = collector.replace("len(jobs) == 7", "len(jobs) == 15").replace("started<392", "started<475")
collector = collector.replace("b1597-fixtures", "b1625-fixtures").replace(
    "CPython checkpoint for the delivered closed pairs and captured-rule debt",
    "CPython checkpoint for delivered positional operand forwarding")
collector_start = collector.index("          counts={};warmups=[]")
collector_end = collector.index("          samples=[]", collector_start)
collector = collector[:collector_start] + """          counts={}; warmups=[]; warmed={w.label:0.0 for w in workers}
          for w in workers:
            w.lane=lane
            counts[w.label,lane]=1
          turn=0
          while min(warmed.values())<5:
            for offset in range(len(workers)):
              w=workers[(turn+offset)%len(workers)]
              if warmed[w.label]>=5:continue
              response=w.request('batch',counts[w.label,lane])
              warmups.append(dict(engine=w.label,lane=lane,response=response))
              seconds=w.last_request_seconds
              warmed[w.label]+=seconds
              counts[w.label,lane]=max(1,min(100000,math.ceil(counts[w.label,lane]*.28/max(seconds,.000001))))
            turn+=1
""" + collector[collector_end:]
collector = collector.replace("    for case_id,lane in jobs:", "    for index,(case_id,lane) in enumerate(jobs):")
collector = collector.replace("          workers=[Worker", "          if index%2:labels.reverse()\n          workers=[Worker")
collector = collector.replace("print(case_id,'phases'if diagnostic else 'unmodified','complete'", "print(case_id,lane,'complete'")
launcher = (template / "external.py").read_text(encoding="utf-8")
launcher = launcher.replace("closed-factory-pairs-entry-20261124/comparison/quiet", "forwarded-positional-framed-20261124/comparison/quiet")
launcher = launcher.replace("closed-factory-pairs-entry-b1596-20261124", remote_donor)
launcher = launcher.replace("closed-pairs-cpython-b1597-20261124", remote_name)
launcher = launcher.replace("lython-b1597-closed-pairs-cpython", "lython-b1625-forwarded-positional-cpython")
start = launcher.index(" if free < minimum:")
end = launcher.index(" assert shutil.disk_usage(base).free>=minimum", start)
launcher = launcher[:start] + " print(json.dumps(dict(freeBefore=free, required=minimum)))\n" + launcher[end:]
launcher = launcher.replace("RuntimeMaxSec=460", "RuntimeMaxSec=535").replace("seconds=405", "seconds=454")
summarizer = (template / "external/summarize.py").read_text(encoding="utf-8")
summarizer = summarizer.replace('len(raw["jobs"])==7 and receipt["warmJobs"]==7',
    'len(raw["jobs"])==15 and receipt["warmJobs"]==15')
for name, content in (("external.py", launcher), ("external/collect.py", collector), ("external/summarize.py", summarizer)):
    compile(content, name, "exec")
    write(lab / name, content)
for node in ast.walk(ast.parse(launcher)):
    if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.startswith("\nwith (base/"):
        compile(node.value, "remote-stage", "exec")
print("Prepared 15 short quiet lanes with five CPython goldens and attested sources.")
