from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
checkpoint = lab.parent / 'retained-cpython-r576'
predecessor = lab.parent / 'expanded-report-profile-r569'
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
read = lambda p: p.read_text(encoding='utf-8')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, content):
    if name.endswith('.py'):
        ast.parse(content)
    (lab / name).write_text(content, encoding='utf-8', newline='\n')

previous = load(predecessor / 'config.json')
source = load(checkpoint / 'config.json')
terminal = load(checkpoint / 'terminal-status.json')
assert not terminal['live'] and terminal['receipt']['complete']
receipt = load(checkpoint / 'archive-receipt.json')
assert terminal['receipt'] == receipt and receipt['archivedAndVerifiedUnderLease']
assert not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert sha(checkpoint / 'observations.tgz') == receipt['archiveSHA256']
catalog = checkpoint / 'representative.json'
catalog_sha = sha(catalog)
assert catalog_sha == source['catalogSHA256']
jobs = [('forwarding', 'scripts.report-forwarding.expanded', 'warm'),
        ('rules', 'scripts.rule-default-closures', 'warm')]
raw = load(checkpoint / 'retrieved/confirmation/confirmation.json')
for _, case_id, lane in jobs:
    case = next(c for c in load(catalog)['cases'] if c['id'] == case_id)
    job = next(j for j in raw['jobs'] if j['case'] == case_id)
    assert job['workersJoinedAndFixturesRemoved']
    for s in job['samples']:
        if s['lane'] == lane:
            assert s['response']['actualOutputSha256'] == case['expectedOutputSha256']
            assert s['response'].get('actualFilesSha256') == case.get('expectedFilesSha256')
shutil.copyfile(catalog, lab / 'catalog.json')
root = '/home/lokad/lython-bench-checks/post-defaults-attribution-b1003-20261118'
unit = 'lython-b1003-post-defaults-attribution-20261118'
image = source['identity']['imageFiles']['candidate']
assert len(image) == 32 and image['Lokad.Lython.dll'].startswith('6c4cb50a')
identity = dict(sourceRevision='53df085650c7f3c9bd8c41a0f7d6915b18aa1938',
                purpose='Current forwarding and rule-closure CPU attribution',
                coreSHA256={'candidate': image['Lokad.Lython.dll']},
                imageFiles={'candidate': image}, catalogSHA256=catalog_sha,
                diagnosticOnly=True, publicationHeld=True)
write('identity.json', json.dumps(identity, indent=2) + '\n')
labels = repr([name for name, _, _ in jobs])
ops = read(predecessor / 'ops-profile.py').replace(previous['root'], root)
ops = ops.replace("[('report', 'scripts.report-forwarding.expanded', 'warm')]", repr(jobs))
ops = ops.replace('count = 128', 'count = 128 if name == "forwarding" else 256')
assert repr(jobs) in ops
write('ops-profile.py', ops)
collect = read(predecessor / 'collect.py').replace(previous['root'], root)
collect = collect.replace("['report']", labels).replace('len(records)==1', 'len(records)==2')
collect = collect.replace("R569/B995 98da93f7dfe67a65920d0cb91435f7d23d313b0f/b62bfd52 expanded forwarding CPU attribution",
                          'R577/B1003 53df08565/6c4cb50a forwarding and rule-closure CPU attribution')
assert labels in collect and 'B1003' in collect
write('collect.py', collect)
write('run.sh', read(predecessor / 'run.sh').replace(previous['root'], root))
write('retrieve.py', read(predecessor / 'retrieve.py'))
analysis = read(predecessor / 'analyze.py').replace("['report']", labels)
analysis = analysis.replace("     'formatting':", """     'function construction':('ExecuteExecutableFunctionDefinition','CreateLoweredFunction','EvaluateFunctionDefaults','CaptureExecutableClosures','ChargeClosureRetention','ChargeFunctionValue','CreateLambdaFunction'),
     'lowered default path':('EvaluateDefaultsAsync',),
     'lowered expression dispatch':('EvaluateLoweredExpression','DispatchLoweredExpressionAsync','EvaluateLoweredBinary'),
     'prepared definition operation':('ExecutePreparedDefinitionOperationAsync',),
     'borrowed invocation':('InvokeOwnedExecutableTargetAsync','TryStartBoundInvocation','StartNativeCall','StartInline'),
     'function metadata':('CaptureFunctionDocstring','AttachTypeMetadata','CreateTypeScope','CaptureClosureMetadata'),
     'definition storage':('PendingFunctionDefaults','FunctionParameterLayout','FunctionBindingPlan','CaptureExecutableClosures'),
     'formatting':""")
write('analyze.py', analysis)
names = ['identity.json', 'catalog.json', 'ops-profile.py', 'collect.py', 'run.sh']
with tarfile.open(lab / 'payload.tgz', 'w:gz') as archive:
    for name in names:
        archive.add(lab / name, arcname=name)
expanded = sum((lab / name).stat().st_size for name in names)
assert receipt['freeBytesAfterArchive'] > 254 * 1024 * 1024 + expanded + 512 * 1024
config = dict(root=root, unit=unit, source=source['root'], sourceFiles=image,
              sourceCatalogSHA256=catalog_sha, catalogSHA256=catalog_sha,
              identity=identity, retireGroups=[], payloadBytes=(lab / 'payload.tgz').stat().st_size,
              payloadSHA256=sha(lab / 'payload.tgz'), unpackedBytes=expanded)
write('config.json', json.dumps(config, indent=2) + '\n')
launcher = read(predecessor / 'remote-launch.py')
left, right = launcher.index('\nc=') + 1, launcher.index('\nb=Path(')
launcher = launcher[:left] + 'c=' + repr(config) + launcher[right:]
launcher = launcher.replace('lython-b995-fixtures', 'lython-b1003-fixtures').replace('+65536', '+524288')
assert '+524288' in launcher
write('remote-launch.py', launcher)
launch = read(predecessor / 'launch.py')
launch = launch.replace('seconds=55', 'seconds=70').replace('Expanded-report CPU attribution', 'Post-defaults CPU attribution').replace('55seconds', '70 seconds')
write('launch.py', launch)
