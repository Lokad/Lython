from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = Path('benchmarks/results/2026-11-18-post-defaults-attribution')
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = load(lab / 'terminal-status.json')
receipt = load(lab / 'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ['complete', 'allWorkersJoined', 'quietBeforeAndAfter',
    'guestFixturesRemoved', 'archivedAndVerifiedUnderLease', 'ramTraceArchivedAndVerifiedBeforeUnmount'])
assert sha(lab / 'observations.tgz') == receipt['archiveSHA256']
for name in ['identity.json', 'catalog.json', 'ops-profile.py', 'collect.py', 'run.sh']:
    assert sha(lab / name) == sha(lab / 'retrieved' / name)
out.mkdir(exist_ok=True)
for name in ['attribution.json', 'terminal-status.json', 'archive-receipt.json', 'observations.tgz']:
    shutil.copyfile(lab / name, out / name)
with tarfile.open(out / 'procedures.tar.xz', 'w:xz', preset=6) as tar:
    for name in ['prepare.py', 'analyze.py', 'retrieve.py', 'archive.py', 'launch.log', 'observe-not-before.json']:
        tar.add(lab / name, arcname=name)

rows = {row['label']: row for row in load(lab / 'attribution.json')['rows']}
forwarding, rules = rows['forwarding'], rows['rules']
focus = lambda row, name: row['guestRuntimeFocus'][name]
(out / 'README.md').write_text(f'''# B1003 warm execution attribution after direct defaults

Profiled the exact B1002 image `53df08565` / `6c4cb50a` on the quiet Ubuntu
Azure F4as_v7 on 2026-11-18 UTC. The worker verified stdout and file goldens
before and after each profile. Each case warmed for at least eight seconds
before a five-second whole-batch CPU capture. Symbol maps and stacks were
archived and SHA-verified before RAM fixture removal. Both quiet gates passed
and all workers joined. The perf-map setting and whole-batch boundary make
this a diagnostic attribution exercise. [B1002 comparison](../2026-11-18-direct-defaults-cpython-checkpoint/README.md).

| Warm script | Runtime ancestry | Observation |
| --- | ---: | --- |
| Rule closures | {rules['guestRuntimeAncestry']} of {rules['sampleCount']} samples | {focus(rules,'lowered default path')} include lowered default evaluation and {focus(rules,'borrowed invocation')} include native or borrowed invocation. The closest resolved runtime method is the lowered expression dispatcher in 66 samples and the synchronous evaluator in 48. |
| Expanded forwarding | {forwarding['guestRuntimeAncestry']} of {forwarding['sampleCount']} samples | {focus(forwarding,'expanded argument construction and binding')} include expanded call construction or binding. The closest resolved runtime method is `BindFunctionArguments` in 48 samples and `AppendStarredDictionaryCore` in 29. |

The groups overlap and their counts include downstream work. Rule closure
defaults still evaluate ordinary function definitions through the lowered evaluator,
while executable lambdas already consume evaluated slots. The next prototype
should move executable `def` input evaluation onto the surrounding code and
share final definition construction, removing the ordinary lowered dispatch and
the captured-expression shells used by yielding definitions where feasible.
Function metadata appears in only {focus(rules,'function metadata')} resolved rule-closure samples.
Forwarding still warrants a complete expansion-to-invocation review. Its
directory reset and output checks do not account for most sampled worker CPU.

The final classifier narrowed the definition group to exclude invocation through
`PyFunctionBase` and classified lowered work from the original stacks. Offline
regeneration produced a new procedure-tar timestamp. The raw archive retains the
exact executed scripts and both measured worker identities. No timing comparison
was taken under profiling.

[Attribution](attribution.json) · [Raw traces and executed scripts](observations.tgz) ·
[Procedure and classifier](procedures.tar.xz) · [Terminal state](terminal-status.json)
''', encoding='utf-8', newline='\n')
