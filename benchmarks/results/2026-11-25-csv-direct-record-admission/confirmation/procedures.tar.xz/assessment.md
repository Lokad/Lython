The two CSV construction paths retain direct admission. Quoted invoice
allocates 262,144 fewer managed bytes per invocation. File-fed map allocates
130,904 fewer bytes and uses 1.70–5.13% less warm async CPU in the first block
and 5.30–8.38% less in confirmation. Plain reader and both quoted invoice
CPU phases remain inconclusive across the recorded conditions. The unchanged
text control uses 1.36–8.01% more CPU in the first block. Its confirmation
spans −6.55 to +8.66%, with candidate elapsed spread of 10.43%. The source of
that control movement remains unresolved.
