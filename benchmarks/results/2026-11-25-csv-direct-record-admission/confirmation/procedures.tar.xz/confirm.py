from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab / "comparison/quiet"
trial = lab / "confirmation-block"
quiet = trial / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, indent=2) + "\n")

identity = read(prior / "identity.json")
receipt = read(prior / "terminal-status.json")["receipt"]
assert receipt["complete"] and sha(prior / "observations.tar.xz") == receipt["archiveSHA256"]
for role, files in identity["imageFiles"].items():
    assert {path.name: sha(path) for path in (lab / role).iterdir()} == files
    verify = read(lab / "comparison" / (role + "-verify.json"))
    assert verify["state"] == "Completed" and verify["caseCount"] == 5
jobs = [('diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('diagnostic.invoice-plain-reader', 'warm'), ('diagnostic.shipment-file-fed-map', 'warm-async')]
save(quiet / "jobs.json", {"warm": jobs})
identity["catalogs"]["jobs.json"]["sha256"] = sha(quiet / "jobs.json")
save(quiet / "identity.json", identity)
for name in ("representative.json", "run.sh"):
    shutil.copyfile(prior / name, quiet / name)
assert sha(quiet / "representative.json") == identity["catalogs"]["representative.json"]["sha256"]
assert b"\r" not in (quiet / "run.sh").read_bytes()
collector = (prior / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 7", "len(jobs) == 3")
collector = collector.replace("5 seconds full-request", "7 seconds full-request").replace("warmupSeconds=5", "warmupSeconds=7")
collector = collector.replace("targetBatchSeconds=.48", "targetBatchSeconds=.52").replace("started < 323", "started < 180")
collector = collector.replace("job_index % 2 == 0", "job_index in (1, 2)").replace("b1719-fixtures", "b1719b-fixtures")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
launcher = (lab / "quiet.py").read_text(encoding="utf-8").replace(
    "lython-b1719-csv-direct-record-admission", "lython-b1719b-csv-direct-record-admission").replace("RuntimeMaxSec=365", "RuntimeMaxSec=215").replace(
    "seconds=288", "seconds=166").replace(",\'candidate-core.dll\'}", "}")
a = launcher.index("   if name=='Lokad.Lython.dll'")
b = launcher.index("   assert digest(image/name)", a)
launcher = launcher[:a] + "   os.link(reference/role/name,image/name)\n" + launcher[b:]
a = launcher.index("assert donor['archiveSHA256']=='")
b = launcher.index("\n", a)
launcher = launcher[:a] + "assert donor['archiveSHA256']==" + repr(receipt["archiveSHA256"]) + launcher[b:]
compile(launcher, "quiet.py", "exec")
write(trial / "quiet.py", launcher)
save(trial / "verified-raw-replicas.json", [])
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz") as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
save(quiet / "upload.json", dict(root="csv-direct-record-admission-b1719b-20261125",
     reference="csv-direct-record-admission-b1719-20261125", payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))

archive = (lab / "archive.py").read_text(encoding="utf-8").replace("root=lab.parents[3]", "root=lab.parents[4]").replace(
    'out=root/"benchmarks/results/2026-11-25-csv-direct-record-admission"', 'out=root/"benchmarks/results/2026-11-25-csv-direct-record-admission/confirmation"').replace(
    '==receipt["warmJobs"]==7', '==receipt["warmJobs"]==3').replace("timedBatches=196,lanes=7", "timedBatches=84,lanes=3")
compile(archive, "archive.py", "exec")
write(trial / "archive.py", archive)
