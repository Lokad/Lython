from pathlib import Path
import json
import sys

lab = Path(__file__).resolve().parent
out = lab.parents[3] / "benchmarks/results/2026-11-25-csv-direct-record-admission"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

case_names = {
    "diagnostic.shipment-file-fed-map": "File-fed CSV quantity map",
    "scripts.csv-invoice.method-policy.quoted-control": "Quoted CSV invoice",
    "diagnostic.shipment-routing-callbacks": "Shipment callback report",
    "diagnostic.text-summary.nonlocal-computed-width.large": "Nonlocal Unicode text control",
    "diagnostic.invoice-plain-reader": "Plain CSV reader",
}
def percent_range(values):
    return " to ".join(f"{v:+.2f}".replace("-", "−") for v in values) + "%"

def timing_table(path):
    rows = read(path)["rows"]
    result = [
        "| Workload and phase | Elapsed change | Wider CPU change | Reference / candidate elapsed spread |",
        "| --- | ---: | ---: | ---: |",
    ]
    for row in rows:
        label = case_names[row["case"]]
        lane = "warm async" if row["lane"] == "warm-async" else "warm sync"
        elapsed = percent_range(row["elapsedPercent"])
        cpu = percent_range(row["cpuPercent"])
        spread = " / ".join(f"{v:.2f}%" for v in row["sameSourceElapsedSpreadPercent"])
        result.append(f"| {label}, {lane} | {elapsed} | {cpu} | {spread} |")
    return "\n".join(result)

allocation = [
    "| Workload | Reference CLR bytes | Candidate CLR bytes | Reduction | Peak admitted bytes on both |",
    "| --- | ---: | ---: | ---: | ---: |",
]
for row in read(out / "allocation-summary.json"):
    a, b = row["allocationBytes"]
    peak, b_peak = row["peakAdmission"]
    assert peak == b_peak
    allocation.append(f"| {case_names[row['case']]} | {a:,} | {b:,} | {(a-b)/a:.2%} | {peak:,} |")
assessment = Path(sys.argv[1]).read_text(encoding="utf-8").strip()
content = f"""# B1719 Admit completed CSV row storage directly

Two fixed-size reservations use the governor's existing reserve, commit
and rollback operations. The parser admits complete row capacity before
construction. Native dictionary adoption separately admits its shell and
rechecks live header identity after the admission callback. A mismatch
refunds the shell and leaves the input owned. Both paths previously
allocated a managed reservation holder.

The reference is `36a4c681f`, including skipped-row retirement before refund
callbacks. The candidate patch and exact image hashes are archived below.
The two 32-file images differ only in the core DLL and both verify all five
CPython-derived goldens. Compilation allocation and retained admission
match. A separate local diagnostic measured these warm allocation totals.

{chr(10).join(allocation)}

The quiet Azure F4as_v7 ran Ubuntu 24.04.4 and .NET 11 RC3 on November 25,
2026 UTC. Each image has two workers. Each worker warms for five full-request
seconds in the first block and seven in confirmation, then contributes
seven rotated batches per phase. Ranges span the four worker-median
pairings. Warm elapsed includes mediated RAM-backed I/O, result verification
and cleanup. Wider CPU also includes fixture reset and request framing.

## First block

{timing_table(out / 'quiet-summary.json')}

## Reordered confirmation

{timing_table(out / 'confirmation/quiet-summary.json')}

{assessment}

Windows .NET 11 and Ubuntu .NET 10 each passed 560 focused Release checks
covering CSV semantics, terminal refusal, header reentry, alias funding and
cleanup. All 280 timed batches passed the golden checks. Both blocks verified
the persistent archives after workers joined and guest fixtures were removed.

[Exact identity](identity.json) · [Runtime allocation](allocation-summary.json) ·
[Compiler allocation](compile-allocation-summary.json) ·
[First timing](quiet-summary.json) · [First observations](quiet-observations.tar.xz) ·
[First terminal receipt](quiet-terminal-status.json) · [Procedures and patch](procedures.tar.xz) ·
[Confirmation timing](confirmation/quiet-summary.json) ·
[Confirmation observations](confirmation/quiet-observations.tar.xz) ·
[Confirmation terminal receipt](confirmation/quiet-terminal-status.json) ·
[Confirmation procedures](confirmation/procedures.tar.xz).
"""
(out / "README.md").write_text(content, encoding="utf-8", newline="\n")
