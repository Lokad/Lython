from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
source = lab.with_name("dictreader-completed-rows-20261125") / "confirm.py"
recipe = source.read_text(encoding="utf-8")

def amend(before, after):
    global recipe
    assert before in recipe, before
    recipe = recipe.replace(before, after)

amend(", ('scripts.csv-invoice.method-policy.quoted-control', 'warm')", "")
amend('"len(jobs) == 8", "len(jobs) == 4"', '"len(jobs) == 7", "len(jobs) == 3"')
amend('"started < 360", "started < 225"', '"started < 323", "started < 180"')
amend('"job_index in (0, 1, 3)"', '"job_index in (1, 2)"')
amend('"b1718-fixtures", "b1718b-fixtures"', '"b1719-fixtures", "b1719b-fixtures"')
amend('lython-b1718-dictreader-completed-rows", "lython-b1718b-dictreader-completed-rows', 
      'lython-b1719-csv-direct-record-admission", "lython-b1719b-csv-direct-record-admission')
amend("RuntimeMaxSec=390", "RuntimeMaxSec=365")
amend("RuntimeMaxSec=252", "RuntimeMaxSec=215")
amend("seconds=305", "seconds=288")
amend("seconds=195", "seconds=166")
amend(r""",'candidate-core.dll','reference-core.dll'""".replace("'", r"\'"),
      r""",'candidate-core.dll'""".replace("'", r"\'"))
amend("dictreader-completed-rows-b1718b", "csv-direct-record-admission-b1719b")
amend("dictreader-completed-rows-b1718", "csv-direct-record-admission-b1719")
amend("2026-11-25-dictreader-completed-rows", "2026-11-25-csv-direct-record-admission")
amend('==receipt["warmJobs"]==8', '==receipt["warmJobs"]==7')
amend('==receipt["warmJobs"]==4', '==receipt["warmJobs"]==3')
amend("timedBatches=224,lanes=8", "timedBatches=196,lanes=7")
amend("timedBatches=112,lanes=4", "timedBatches=84,lanes=3")
assert "b1718" not in recipe
(lab / "confirm.py").write_text(recipe, encoding="utf-8", newline="\n")
subprocess.run([sys.executable, "-X", "utf8", lab / "confirm.py"], check=True)
