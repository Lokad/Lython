from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
donor = lab.with_name("dictreader-completed-rows-20261125")
procedures = lab.with_name("closed-default-store-links-20261125")
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

identity = read(quiet / "identity.json")
for role, files in identity["imageFiles"].items():
    assert {path.name: sha(path) for path in (lab / role).iterdir()} == files
    verified = read(lab / "comparison" / (role + "-verify.json"))
    assert verified["state"] == "Completed" and verified["caseCount"] == 5

collector = (procedures / "comparison/quiet/collect.py").read_text(encoding="utf-8")
collector = collector.replace("b1711-fixtures", "b1719-fixtures").replace("len(jobs) == 8", "len(jobs) == 7")
collector = collector.replace("targetBatchSeconds=.59", "targetBatchSeconds=.48")
collector = collector.replace("started < 394", "started < 323")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(procedures / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
launcher = (donor / "quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("lython-b1718-dictreader-completed-rows", "lython-b1719-csv-direct-record-admission")
launcher = launcher.replace("b1718", "b1719").replace("if name=='Lokad.Lython.dll':", "if name=='Lokad.Lython.dll' and role=='candidate':").replace("reference/'candidate'/name", "reference/'reference'/name")
launcher = launcher.replace("'candidate-core.dll','reference-core.dll'}", "'candidate-core.dll'}")
launcher = launcher.replace("RuntimeMaxSec=390", "RuntimeMaxSec=365").replace("seconds=305", "seconds=288")
anchor = read(donor / "comparison/quiet/terminal-status.json")["receipt"]
assert anchor["complete"] and sha(donor / "comparison/quiet/observations.tar.xz") == anchor["archiveSHA256"]
a = launcher.index("assert donor['archiveSHA256']=='")
b = launcher.index("\n", a)
launcher = launcher[:a] + "assert donor['archiveSHA256']==" + repr(anchor["archiveSHA256"]) + launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
write(lab / "verified-raw-replicas.json", "[]\n")

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
write(quiet / "upload.json", json.dumps(dict(root="csv-direct-record-admission-b1719-20261125",
    reference="dictreader-completed-rows-b1718-20261125", payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size), indent=2) + "\n")
for name in ("compile-allocation.py", "allocations.py"):
    shutil.copyfile(procedures / name, lab / name)
