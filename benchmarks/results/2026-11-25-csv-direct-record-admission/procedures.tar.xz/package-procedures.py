from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-25-csv-direct-record-admission'
identity = json.loads((lab / 'comparison/quiet/identity.json').read_text(encoding='utf-8'))
assert identity['sourcePatchSHA256'] == hashlib.sha256((lab / 'candidate.patch').read_bytes()).hexdigest()
for source, name in (
    ('comparison/quiet/identity.json', 'identity.json'),
    ('allocation-summary.json', 'allocation-summary.json'),
    ('compile-allocation-summary.json', 'compile-allocation-summary.json'),
):
    shutil.copyfile(lab / source, out / name)
procedures = [
    'prepare-admission.py', 'freeze.py', 'prepare.py', 'quiet.py', 'archive.py',
    'package-procedures.py', 'candidate.patch', 'identity-source.json',
    'candidate-build.log', 'freeze.log', 'test-ubuntu.sh', 'launch-console.log',
    'retrieve.log', 'allocations.py', 'compile-allocation.py',
    'candidate-allocation-final.json', 'reference-allocation-final.json',
    'candidate-compiler-owner.json', 'reference-compiler-owner.json',
    'comparison/candidate-verify.json', 'comparison/reference-verify.json',
    'comparison/quiet/storage-custody.json',
]
procedures.extend(p.name for p in sorted(lab.glob('Lokad.Lython.*.log')))
assert len(procedures) == 26
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in procedures:
        bundle.add(lab / name, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as bundle:
    for name in procedures:
        assert bundle.extractfile(name).read() == (lab / name).read_bytes(), name
print('Verified all procedure archive members.')
