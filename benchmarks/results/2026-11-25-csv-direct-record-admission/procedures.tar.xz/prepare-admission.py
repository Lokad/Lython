from pathlib import Path
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/csv-direct-record-admission-20261125"
prior = lab.with_name("dictreader-inline-headers-20261125")
jobs = [
    ("diagnostic.shipment-file-fed-map", "warm-async"),
    ("scripts.csv-invoice.method-policy.quoted-control", "warm"),
    ("diagnostic.shipment-routing-callbacks", "warm-async"),
    ("diagnostic.text-summary.nonlocal-computed-width.large", "warm"),
    ("diagnostic.invoice-plain-reader", "warm"),
    ("diagnostic.shipment-file-fed-map", "warm"),
    ("scripts.csv-invoice.method-policy.quoted-control", "warm-async"),
]

def git(*args):
    return subprocess.check_output(["git", *args], cwd=worktree)

base = git("rev-parse", "36a4c681f").decode().strip()
assert git("diff", "--binary", base, "HEAD", "--", "src") == b""
patch = git("diff", "--binary", base, "--", "src")
assert patch.count(b"diff --git") == 2
(lab / "candidate.patch").write_bytes(patch)
(lab / "identity-source.json").write_text(json.dumps(dict(
    base=base, sourcePatchSHA256=hashlib.sha256(patch).hexdigest()), indent=2) + "\n",
    encoding="utf-8", newline="\n")

def edit(name, changes):
    text = (prior / name).read_text(encoding="utf-8")
    for before, after in changes:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

source = (prior / "freeze.py").read_text(encoding="utf-8")
edit("freeze.py", [
    ('".git/agent-worktrees/dictreader-inline-headers-20261125"', '".git/agent-worktrees/csv-direct-record-admission-20261125"'),
    ('assert paths == ["src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs"], paths',
     'assert paths == ["src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs", "src/Lokad.Lython/Runtime/PyDict.Records.cs"], paths'),
    (next(line for line in source.splitlines() if line.startswith("jobs =")), "jobs = " + repr(jobs)),
    ('== 4', '== 5'),
    ('Isolate completion of known DictReader field names without changing data-row transport',
     'Remove the short-lived reservation object from CSV row construction and native dictionary adoption'),
])
edit("prepare.py", [
    ('verified["caseCount"] == 4', 'verified["caseCount"] == 5'),
    ('"b1718c-fixtures"', '"b1719-fixtures"'),
    ('.replace("len(jobs) == 8", "len(jobs) == 5")', '.replace("len(jobs) == 8", "len(jobs) == 7")'),
    ('"started < 242"', '"started < 323"'),
    ('"lython-b1718c-dictreader-inline-headers"', '"lython-b1719-csv-direct-record-admission"'),
    ('launcher.replace("b1718", "b1718c")', 'launcher.replace("b1718", "b1719")'),
    ('"RuntimeMaxSec=275"', '"RuntimeMaxSec=365"'),
    ('"seconds=207"', '"seconds=288"'),
    ('root="dictreader-inline-headers-b1718c-20261125"', 'root="csv-direct-record-admission-b1719-20261125"'),
])
