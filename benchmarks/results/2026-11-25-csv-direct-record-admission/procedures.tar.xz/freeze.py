from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/csv-direct-record-admission-20261125"
donor = lab.with_name("dictreader-completed-rows-20261125")
catalog_donor = lab.with_name("native-dictionary-prepared-consumers-20261125")
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

base = git("rev-parse", "36a4c681f6720623f456abecd2d905ae2b32e57a").decode().strip()
assert git("diff", "--binary", base, "HEAD", "--", "src") == b""
def candidate_diff(*args):
    return subprocess.check_output(["git", "diff", *args, base, "--", "src"], cwd=worktree)

paths = candidate_diff("--name-only").decode().splitlines()
assert paths == ["src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs", "src/Lokad.Lython/Runtime/PyDict.Records.cs"], paths
patch = lab / "candidate.patch"
assert patch.read_bytes() == candidate_diff("--binary")
assert sha(patch) == read(lab / "identity-source.json")["sourcePatchSHA256"]
build_inputs = ("global.json", "Directory.Build.props", "Directory.Build.targets",
                "Directory.Build.rsp", "Directory.Packages.props", "NuGet.Config")
root_files = set(git("ls-tree", "--name-only", base).decode().splitlines())
archive = lab / "base.zip"
git("archive", "--format=zip", f"--output={archive}", base, "--",
    *[name for name in build_inputs if name in root_files], "src/Lokad.Lython")
old_identity = read(donor / "comparison/quiet/identity.json")
old_files = old_identity["imageFiles"]["reference"]
assert {file.name: sha(file) for file in (donor / "reference").iterdir()} == old_files

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
images = {}
assert old_identity["sourceRevision"] == base
reference = lab / "reference"
reference.mkdir(exist_ok=True)
for name, expected in old_files.items():
    shutil.copyfile(donor / "reference" / name, reference / name)
    assert sha(reference / name) == expected
images["reference"] = old_files
for role in ("candidate",):
    frozen = lab / ("frozen-" + role)
    with zipfile.ZipFile(archive) as bundle:
        bundle.extractall(frozen)
        if role == "candidate":
            for path in paths:
                shutil.copyfile(worktree / path, frozen / path)
        for name in bundle.namelist():
            if name.endswith("/"):
                continue
            expected = (worktree / name).read_bytes() if role == "candidate" and name in paths else bundle.read(name)
            assert (frozen / name).read_bytes() == expected, name
    build = lab / (role + "-build")
    with (lab / (role + "-build.log")).open("wb") as log:
        subprocess.run([dotnet, "build", "src/Lokad.Lython/Lokad.Lython.csproj", "-c", "Release", "-f", "net11.0",
                        "--no-incremental", "--artifacts-path", build], cwd=frozen, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=180)
    core = build / "bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in old_files:
        shutil.copyfile(core if name == core.name else donor / "reference" / name, image / name)
    images[role] = old_files | {core.name: sha(core)}
    assert {file.name: sha(file) for file in image.iterdir()} == images[role]
assert candidate_diff("--binary") == patch.read_bytes()
assert images["reference"] != images["candidate"]

jobs = [('diagnostic.shipment-file-fed-map', 'warm-async'), ('scripts.csv-invoice.method-policy.quoted-control', 'warm'), ('diagnostic.shipment-routing-callbacks', 'warm-async'), ('diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('diagnostic.invoice-plain-reader', 'warm'), ('diagnostic.shipment-file-fed-map', 'warm'), ('scripts.csv-invoice.method-policy.quoted-control', 'warm-async')]
catalog = read(catalog_donor / "input-catalog.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in {name for name, _ in jobs}]
assert len(catalog["cases"]) == 5
catalog_path = quiet / "representative.json"
save(catalog_path, catalog)
save(quiet / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, comparisonRevision=base, sourcePatchSHA256=sha(patch), imageFiles=images,
                coreSHA256={role + suffix: files["Lokad.Lython.dll"] for role, files in images.items()
                            for suffix in ("", "-control")},
                expectedCPythonSHA256=old_identity["expectedCPythonSHA256"],
                cpythonWorkerSHA256=old_identity["cpythonWorkerSHA256"],
                catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")},
                purpose="Remove the short-lived reservation object from CSV row construction and native dictionary adoption")
save(quiet / "identity.json", identity)
python_worker = repo / "benchmarks/cpython-worker.py"
assert sha(python_worker) == identity["cpythonWorkerSHA256"]
for role, files in images.items():
    evidence = lab / "comparison" / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", catalog_path, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", python_worker, "--out", evidence],
                   cwd=repo, env=env, check=True, timeout=65)
    report = read(evidence)
    assert report["state"] == "Completed" and report["caseCount"] == 5
    assert report["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
