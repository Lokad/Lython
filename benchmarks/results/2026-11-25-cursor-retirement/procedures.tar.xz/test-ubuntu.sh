set -eu
lab="$PWD/.git/agent-notes/review-20261031/retire-clr-cursor-adapter-20261125"
worktree="$PWD/.git/agent-worktrees/retire-clr-cursor-adapter-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/ubuntu-net10-$suite.log"
 if [ "$suite" = "Lokad.Lython.Tests" ]; then filter='(FullyQualifiedName~CombinatoricTupleAdmission|FullyQualifiedName~CursorDispatch|FullyQualifiedName~EnumerableState|FullyQualifiedName~IterationCancellation|FullyQualifiedName~CursorCleanup|FullyQualifiedName~NativeAggregateState|FullyQualifiedName~NativeAnyAllCleanup|FullyQualifiedName~PartialNativeListState|FullyQualifiedName~TeeAdmission|FullyQualifiedName~TupleDisplayOwnership|FullyQualifiedName~CompiledGeneratorExpression|FullyQualifiedName~CsvPrivateRecordOwnership|FullyQualifiedName~ExecutableAsyncIteratorCleanup|FullyQualifiedName~GeneratorExpressionAdmission|FullyQualifiedName~ListConstructionHandoff|FullyQualifiedName~CsvExhaustedInputLifetime)&Category!=Stress'
 else filter='(FullyQualifiedName~BufferedGeneratorContinuation|FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~Generator|FullyQualifiedName~Terminal|FullyQualifiedName~Admission|FullyQualifiedName~Csv)&Category!=Stress'
 fi
 if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
     tail -3 "$log"
 else
     tail -48 "$log"
     exit 1
 fi
done