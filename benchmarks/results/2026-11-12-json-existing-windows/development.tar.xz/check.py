from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent
env=os.environ.copy();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
dotnet=str(sdk/'dotnet.exe')
commands={
 'build':[dotnet,'build','Lokad.Lython.slnx','-c','Release','--no-incremental'],
 'build-tests':[dotnet,'build','Lokad.Lython.slnx','-c','Release'],
 'internal11':[dotnet,'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--filter','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~PyString|FullyQualifiedName~TextFile)'],
 'internal10':[dotnet,'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net10.0','--no-build','--filter','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~PyString|FullyQualifiedName~TextFile)'],
 'build-public':[dotnet,'build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release'],
 'public11':[dotnet,'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--no-build','--filter','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~ReaderWindow|FullyQualifiedName~ReturnedIteration)'],
 'public10':[dotnet,'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net10.0','--no-build','--filter','Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~ReaderWindow|FullyQualifiedName~ReturnedIteration)'],
}
label=sys.argv[1];step=label.split('.',1)[0];assert step in commands
p=r/(label+'.log');assert not p.exists(),p
with p.open('w',encoding='utf-8',newline='\n')as log:
 done=subprocess.run(commands[step],env=env,stdout=log,stderr=subprocess.STDOUT)
print('\n'.join(p.read_text(encoding='utf-8').splitlines()[-24:]),flush=True)
raise SystemExit(done.returncode)
