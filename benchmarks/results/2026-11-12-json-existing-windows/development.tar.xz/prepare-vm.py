from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=r/'b634';out.mkdir()
old=r.parent/'bulk-utf16-r276/b632'
config=json.loads((old/'config.json').read_text(encoding='utf-8'))
ident=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
root='/home/lokad/lython-bench-checks/json-existing-windows-b634-20261112';unit='lython-b634-json-existing-windows-20261112'
config.update(root=root,unit=unit,requiredFreeBytes=264*1024*1024,retire=[])
config['identity'].update(sourceRevision=ident['head']+'; R279 plain JSON strings over existing windows;2288 focused actual-target checks; desktop phases recorded separately',coreSHA256={label:ident['referenceSHA256'if label.startswith('reference')else'coreSHA256']for label in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.report-render.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.csv-validated-records.large','warm']]
def one(text,before,after):
    assert text.count(before)==1,(before,text.count(before))
    return text.replace(before,after)
collect=(old/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=one(collect,"purpose='R276 refined bulk UTF16 encoder only; common UTF8 writer and scalar count code restored exactly; same UTF16 Run/Async and UTF8 control, with all first-form adversity preserved.'","purpose='R279 JSON plain-token windows using existing string representation; report/JSON affected, captured-text/CSV controls; all adverse and uncertain results retained.'")
collect=one(collect,'affectedWarmupSeconds=12, targetBatchSeconds=.25','affectedWarmupSeconds=8, capturedWarmupSeconds=12, targetBatchSeconds=.5')
collect=one(collect,"< 200, 'Reserve40seconds for final owned work/cleanup.'","< 260, 'Reserve40seconds for final owned work/cleanup.'")
collect=one(collect,'count*.25/max','count*.5/max')
warmup_line=next(line for line in collect.splitlines()if 'end=time.monotonic()+'in line)
assert '12 if'in warmup_line
collect=collect.replace(warmup_line,'                count=1; end=time.monotonic()+(12 if case_id=="scripts.text-summary-helpers.nonlocal-counter.large" else 8 if case_id in ("scripts.report-render.large","scripts.json-summary-helpers.large") else 5); rows=[]')
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root).replace("==3 ","==4 ").replace('jobs=3','jobs=4')
ast.parse(archive);(out/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
shell=(old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root).replace('lython-b632-bulk-utf16-20261112',unit)
(out/'run.sh').write_text(shell,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
assert hashlib.sha256((out/'representative.json').read_bytes()).hexdigest()==config['identity']['catalogSHA256']
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
remote=(old/'remote-launch.py').read_text(encoding='utf-8').replace("base/'prepared-word-ranges-b628-20261112/candidate'","base/'bulk-utf16-b632-20261112/candidate'").replace('lython-b632-fixtures','lython-b634-fixtures').replace('jobs=3,ownerSeconds=240','jobs=4,ownerSeconds=300').replace('RuntimeMaxSec=240','RuntimeMaxSec=300')
ast.parse(remote.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(out/'remote-launch.py').write_text(remote,encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/bulk-utf16-b632-20261112',root).replace('lython-b632-bulk-utf16-20261112',unit).replace("['jobs']==3","['jobs']==4").replace("['elapsedSeconds']<300","['elapsedSeconds']<360").replace('B632 three-job','B634 four-job')
ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,payloadBytes=config['payloadBytes'],ownerSeconds=300,targetBatchSeconds=.5,source=config['identity']['sourceRevision'])))
