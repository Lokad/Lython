from pathlib import Path
import sys
r=Path(__file__).parent.resolve();source=(r/'warm-sync').resolve();target=(r/(sys.argv[1]if len(sys.argv)>1 else'failed-launch-warm-sync')).resolve()
assert source.parent==target.parent==r and source.is_dir()and not target.exists()
assert not list(source.glob('scripts.*.json'))
source.rename(target)
print('Initial assembly-path mistake preserved before any complete-job observation.')
