from pathlib import Path
import ast,json,shutil,tarfile,hashlib
r=Path(__file__).parent;old=r/'b634';out=r/'b635';out.mkdir()
root='/home/lokad/lython-bench-checks/json-existing-windows-b635-20261112';unit='lython-b635-json-window-async-20261112'
oldroot='/home/lokad/lython-bench-checks/json-existing-windows-b634-20261112'
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
jobs=[['scripts.report-render.large','warm-async'],['scripts.report-render.utf16.large','warm-async'],['scripts.csv-validated-records.large','warm-async']]
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R279 JSON plain-token windows using existing string representation; report/JSON affected, captured-text/CSV controls; all adverse and uncertain results retained.'","purpose='R279 unchanged source targeted async confirmation: original desktop UTF8/UTF16 report adversity; CSV async control; preserve B634 and original clocks.'")
collect=collect.replace("< 260, 'Reserve40seconds for final owned work/cleanup.'","< 200, 'Reserve40seconds for final owned work/cleanup.'")
collect=collect.replace('("scripts.report-render.large","scripts.json-summary-helpers.large")','("scripts.report-render.large","scripts.report-render.utf16.large")')
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b634-json-existing-windows-20261112',unit)
    if name=='archive-owned.py':text=text.replace("==4 ","==3 ").replace('jobs=4','jobs=3')
    if name=='retrieve.py':text=text.replace("['jobs']==4","['jobs']==3").replace("['elapsedSeconds']<360","['elapsedSeconds']<300").replace('B634 four-job','B635 three-job')
    if name.endswith('.py'):ast.parse(text)
    (out/name).write_text(text,encoding='utf-8',newline='\n')
for name in ['current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:shutil.copyfile(old/name,out/name)
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config=json.loads((old/'config.json').read_text(encoding='utf-8'))
config.update(root=root,unit=unit,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
remote=(old/'remote-launch.py').read_text(encoding='utf-8').replace('lython-b634-fixtures','lython-b635-fixtures').replace('jobs=4,ownerSeconds=300','jobs=3,ownerSeconds=240').replace('RuntimeMaxSec=300','RuntimeMaxSec=240')
(out/'remote-launch.py').write_text(remote,encoding='utf-8',newline='\n')
launch=(old/'launch.py').read_text(encoding='utf-8').replace('json-existing-windows-b634-launch.py','json-existing-windows-b635-launch.py').replace('timedelta(seconds=360)','timedelta(seconds=300)').replace('ownerSeconds=300','ownerSeconds=240')
ast.parse(launch);(out/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
summary=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace('jobs=4','jobs=3')
ast.parse(summary);(out/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')
print('Three targeted async jobs; exact same cores/catalog/profile; no synchronous retiming.')
