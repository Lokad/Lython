from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;decision=json.loads((r/'decision.json').read_text(encoding='utf-8'))
assert decision['retained']
out=Path('benchmarks/results/2026-11-12-json-existing-windows');out.mkdir(exist_ok=True)
for name in ['candidate-identity.json','source-gate.md','decision.json']:shutil.copyfile(r/name,out/name)
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/JsonStringTokenStorageTests.cs']))
with tarfile.open(out/'development.tar.xz','w:xz')as t:
    for path in sorted(r.iterdir()):
        if path.is_file()and path.suffix in ('.py','.log','.md','.json','.patch','.dll','.xz'):t.add(path,arcname=path.name)
    for phase in ['warm-sync','warm-async','fresh','compile','failed-launch-warm-sync','failed-witness-warm-sync']:
        t.add(r/phase,arcname=phase)
    for p in ['tests/Lokad.Lython.Tests/JsonWindowOwnershipTests.cs','tests/Lokad.Lython.PublicApi.Tests/JsonRetainedTextTests.cs']:
        t.add(p,arcname=p)
    for name in ['Program.cs','complete-jobs.csproj','packages.lock.json']:t.add(r/'tool'/name,arcname='tool/'+name)
for unit in ['b634','b635']:
    target=out/unit;target.mkdir(exist_ok=True)
    for name in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','inventory.json','extraction.json']:shutil.copyfile(r/unit/name,target/name)
    with tarfile.open(target/'preparation.tar.xz','w:xz')as t:
        for name in ['collect.py','archive-owned.py','remote-launch.py','launch.py','launch-command.py','launch.log','retrieve.py','summarize.py','config.json','observe-not-before.json']:t.add(r/unit/name,arcname=name)
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.rglob('*')if p.is_file()and p.name not in ('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Source/cores, focused checks, all diagnostic/adverse conditions and both controlled collections archived.')
