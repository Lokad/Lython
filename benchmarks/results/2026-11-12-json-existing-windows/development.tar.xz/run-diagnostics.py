from pathlib import Path
import subprocess,sys
r=Path(__file__).parent
for phase in ['warm-sync','warm-async','compile','fresh']:
    subprocess.run([sys.executable,'-X','utf8',str(r/'diagnostic.py'),phase],check=True)
