from pathlib import Path
import ast
r=Path(__file__).parent;old=r.parent/'bulk-utf16-r276'
text=(old/'refined/summarize.py').read_text(encoding='utf-8').replace("'measurements.json'","'stdout.json'")
(r/'summarize.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'b632/launch.py').read_text(encoding='utf-8').replace('annotation-demand-b632-launch.py','json-existing-windows-b634-launch.py').replace('timedelta(seconds=300)','timedelta(seconds=360)').replace('ownerSeconds=240','ownerSeconds=300')
ast.parse(text);(r/'b634/launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'b632/summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==3","len(raw['jobs'])==4").replace('jobs=3','jobs=4')
ast.parse(text);(r/'b634/summarize.py').write_text(text,encoding='utf-8',newline='\n')
