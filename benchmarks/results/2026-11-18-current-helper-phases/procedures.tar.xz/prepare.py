from pathlib import Path
from hashlib import sha256
import ast, io, json, shutil, subprocess, tarfile

repo = Path.cwd()
notes = repo / '.git/agent-notes/review-20261031'
lab = notes / 'current-helper-phases-r560'
old = notes / 'phase-attribution-r467'
source = notes / 'syntax-validity-r559'
read = lambda p: p.read_text(encoding='utf-8-sig')
sha = lambda data: sha256(data).hexdigest()

def put(name, text):
    if name.endswith('.py'): ast.parse(text)
    (lab / name).write_text(text, encoding='utf-8', newline='\n')

def save(name, data): put(name, json.dumps(data, indent=2) + '\n')

head = subprocess.check_output(['git','rev-parse','bfe076110'], text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',head,'HEAD','--','src','tests','tools'])
prior = json.loads(read(source / 'quiet/config.json'))
files = prior['identity']['imageFiles']['candidate']
assert len(files) == 32 and files['Lokad.Lython.dll'].startswith('610d403d')
assert all(sha((source/'frozen/candidate'/n).read_bytes()) == h for n,h in files.items())
catalog = source / 'representative.json'
assert sha(catalog.read_bytes()) == prior['catalogSHA256']
ids = {case['id'] for case in json.loads(read(catalog))['cases']}
helper = 'scripts.text-normalization.helper-list'; control = 'scripts.config-edit.small'
assert {helper,control} <= ids
for role in ('reference','candidate'):
    assert '4 cases, 0 failed cases' in read(source/f'{role}-verification.log')

ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
options=[]
for root_case, canonical in (
    ('trimmed-split-join-b981-20261118','2026-11-18-trimmed-split-join'),
    ('trimmed-split-cpython-b982-20261118','2026-11-18-normalization-cpython-checkpoint'),
    ('split-line-count-b983-20261118','2026-11-18-private-line-count'),
    ('line-count-cpython-b984-20261118','2026-11-18-line-count-cpython-checkpoint'),
):
    name=f'benchmarks/results/{canonical}/observations.tgz'
    committed=subprocess.check_output(['git','show','HEAD:'+name]); assert (repo/name).read_bytes()==committed
    with tarfile.open(fileobj=io.BytesIO(committed)) as tgz:
        member='confirmation/confirmation.json'; data=tgz.extractfile(member).read()
        json.loads(data)
    options.append(dict(canonical=name,canonicalSHA256=sha(committed),sha256=sha(data),bytes=len(data),
                        member=member,links=1,paths=[f'{root_case}/{member}'],optional=True,
                        kind='exact committed raw observation replica',committedBlobVerified=True))
inspect='''from pathlib import Path
import fcntl, hashlib, json, shutil, stat, os
base=Path('/home/lokad/lython-bench-checks').resolve()
with (base/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    rows=[]
    for proof in OPTIONS:
        path=base/proof['paths'][0]
        if not path.exists(): continue
        info=path.lstat()
        assert path.is_relative_to(base) and path.resolve()==path and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid()
        assert info.st_nlink==1 and info.st_size==proof['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256'],str(path)
        rows.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retireOptions=rows)))
'''.replace('OPTIONS',repr(options))
put('replica-proof.py',inspect)
space=json.loads(subprocess.check_output(ssh+['python3 -'],input=inspect.encode('utf-8'),timeout=50))
save('space.json',space)
identity=dict(sourceRevision=head,purpose='Current helper warm/compile-to-result in the same processes',
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    imageFiles={'candidate':files},auxiliaryFiles={n:h for n,h in files.items() if n!='Lokad.Lython.dll'},
    catalogSHA256=prior['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
save('identity.json',identity)
shutil.copyfile(catalog,lab/'representative.json')
worker=(repo/'benchmarks/cpython-worker.py').read_bytes()
with tarfile.open(source/'quiet/observations.tgz') as tgz:
    assert worker==tgz.extractfile('cpython-worker.py').read()
(lab/'cpython-worker.py').write_bytes(worker)
root='/home/lokad/lython-bench-checks/current-helper-phases-b986-20261118'
unit='lython-b986-current-helper-phases-20261118'
collect=read(old/'collect.py')
a=collect.index('\nunused_prior_jobs='); b=collect.index('\nenv =',a)
collect=collect[:a]+collect[b:]
collect=collect.replace("R467 same-process rotated warm/fresh phase attribution, not a source comparison or a replacement published baseline", "B986 same-process warm/fresh helper comparison with a configuration control")
collect=collect.replace("    for case_id in ['scripts.text-normalization.helper-list','scripts.report-render.helper-list']:\n      for diagnostic in [False,True]:",f"    for case_id,diagnostic in [({helper!r},False),({control!r},False),({helper!r},True)]:\n      if True:")
# Eliminate the nested loop's former indentation.
a,b=collect.index('      if True:'),collect.index('    time.sleep(3)\n    subprocess.run([str(dotnet),str(worker)',collect.index('      if True:'))
block=collect[a:b].splitlines()[1:]; collect=collect[:a]+'\n'.join(block)+'\n'+collect[b:]
collect=collect.replace("+(2 if diagnostic else 3)",f"+(2 if diagnostic else 8 if case_id=={helper!r} else 3)")
collect=collect.replace("for n,h in identity['imageFiles']['candidate'].items():", "assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()=="+repr(sha(worker))+"\n    for n,h in identity['imageFiles']['candidate'].items():")
put('collect.py',collect)
put('python-phases.py',read(old/'python-phases.py'))
put('archive-owned.py',read(old/'archive-owned.py').replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace('jobs=4,','jobs=3,').replace("[p]ython3.13.*cpython-worker.py'","[p]ython3.13.*(?:cpython-worker|python-phases).py'".replace('(?:','(')))
old_cfg=json.loads(read(old/'config.json'))
put('run.sh',read(old/'run.sh').replace(old_cfg['root'],root)); assert b'\r' not in (lab/'run.sh').read_bytes()
members=['collect.py','python-phases.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(lab/'payload.tgz','w:gz') as tgz:
    for n in members: tgz.add(lab/n,arcname=n)
needed=sum((lab/n).stat().st_size for n in members)
available=space['freeBytes']; chosen=[]
for item in space['retireOptions']:
    if available > 254*1024*1024+needed+131072: break
    chosen.append(item); available+=item['bytes']
assert available > 254*1024*1024+needed+131072
payload=lab/'payload.tgz'
cfg=dict(root=root,unit=unit,source=prior['root'],sourceRole='candidate',sourceFiles=files,
         sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=prior['catalogSHA256'],catalogSource=prior['root']+'/representative.json',
         identity=identity,retireGroups=chosen,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=needed)
save('config.json',cfg)
text=read(old/'remote-launch.py')
a,b=text.index('\nc=')+1,text.index('\nb=Path(')
text=text[:a]+'c='+repr(cfg)+text[b:]
text=text.replace("['reference','candidate']","['candidate']").replace('lython-b873-fixtures','lython-b986-fixtures').replace('RuntimeMaxSec=210','RuntimeMaxSec=230')
put('remote-launch.py',text)
put('launch.py',read(old/'launch.py').replace('R467','B986').replace('175','160'))
put('retrieve.py',read(old/'retrieve.py').replace("['jobs']==4","['jobs']==3").replace('B873','B986').replace("[p]erf record'","[p]erf record|[p]ython3.13.*(cpython-worker|python-phases).py'"))
put('analyze.py',read(old/'analyze.py').replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace('ccf20ba3/frozen7a599347, fully qualified runtime; no production changes',head+'/frozen610d403d; no comparison-time source changes').replace('R467/B873','R560/B986').replace('original B872','original B984'))
print('Verified complete image and reused catalog. VM recovery:', [(x['paths'][0],x['bytes']) for x in chosen])
