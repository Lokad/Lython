from pathlib import Path
import importlib.util,json,subprocess,tempfile
lab=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('protocol',lab/'cpython-worker.py')
wire=importlib.util.module_from_spec(spec);spec.loader.exec_module(wire)
cases={c['id']:c for c in json.loads((lab/'representative.json').read_text(encoding='utf-8'))['cases']}
case=cases['scripts.text-normalization.helper-list']; rows=[]
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-',dir=lab) as cwd:
    with subprocess.Popen(['C:/Python313/python.exe','-I','-S','-X','utf8',str(lab/'python-phases.py'),'--catalog',str(lab/'representative.json')],
                          cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
        assert wire.read_frame(proc.stdout)['status']=='Ready'
        for i,lane in enumerate(('warm','compile-run','warm'),1):
            request={k:case[k] for k in ('sourceSha256','fixtureSha256','expectedOutputSha256')}
            request.update(protocolVersion=2,requestId=i,operation='batch',caseId=case['id'],lane=lane,iterations=2)
            wire.write_frame(proc.stdin,request)
            row=wire.read_frame(proc.stdout); assert row['status']=='Completed' and row['requestId']==i and row['completedInvocations']==2,row
            assert row['actualOutputSha256']==case['expectedOutputSha256'] and row['actualFilesSha256']==case['expectedFilesSha256']
            assert row['phaseDiagnostics']['invocations']==2 and row['phaseDiagnostics']['compilations']==(0 if i==3 else 2 if i==2 else 1)
            rows.append(row)
        wire.write_frame(proc.stdin,dict(protocolVersion=2,requestId=4,operation='quit'))
        assert wire.read_frame(proc.stdout)['status']=='Closed'
        assert proc.wait(timeout=5)==0 and not proc.stderr.read()
(lab/'local-preflight.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print('Verified both phase frames and the reused warmed code in the same worker.')
