from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
dest = repo / "benchmarks/results/2026-11-23-regex-indexed-cursor-window"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = read(lab / "comparison/identity.json")
terminal = read(quiet / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(receipt[name] for name in ("complete", "archivedAndVerifiedUnderLease", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter"))
assert sha((quiet / "observations.tar.xz").read_bytes()) == receipt["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 168
assert all(row["peakAdmission"][0] == row["peakAdmission"][1] for row in read(lab / "allocation-summary-six.json"))
initial = read(lab / "initial-stage/terminal-status.json")
assert initial["exitCode"] == "1" and not initial["fixtures"] and "KeyError: 'purpose'" in initial["journal"]
assert sha((lab / "initial-stage/observations.tar.xz").read_bytes()) == initial["receipt"]["archiveSHA256"]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
paths = ("src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs", "tests/Lokad.Lython.PublicApi.Tests/RegexMatchIndexTests.cs")
source_diff = subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", *paths], cwd=repo)
identity["retainedRevision"] = None if source_diff else head
patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], identity["candidate"], "--", *paths], cwd=repo)
(lab / "comparison.patch").write_bytes(patch)
identity["comparisonPatchSHA256"] = sha(patch)
dest.mkdir(exist_ok=False)
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and all(sha((lab / role / name).read_bytes()) == digest for name, digest in files.items())
    core = lab / role / "Lokad.Lython.dll"
    image = dest / "candidate-core.dll.gz" if role == "candidate" else dest.parent / "2026-11-23-eager-isolated-definition/candidate-core.dll.gz"
    if role == "candidate":
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("observations.tar.xz", "summary.json", "terminal-status.json"):
    shutil.copyfile(quiet / name, dest / name)
shutil.copyfile(lab / "allocation-summary-six.json", dest / "allocation-summary-six.json")
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for name in (
        "prepare.py", "prepare-timing.py", "stage.py", "quiet.py", "retry.py", "corrected-quiet.py",
        "summarize.py", "allocations.py", "archive.py", "comparison.patch", "initial-stage",
        "windows-public.log", "windows-frozen.log", "test-ubuntu.sh", "ubuntu-public.log",
        "reference-verify.json", "candidate-verify.json", "reference-allocation-six.json",
        "candidate-allocation-six.json", "stage.log", "corrected-stage.log", "retrieval.log",
        "comparison/quiet/observe-not-before"):
        archive.add(lab / name, arcname=name)
print(dest, identity["retainedRevision"] or "private")
