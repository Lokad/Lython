from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "eager-isolated-definition-20261123"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")
python = "C:/Python313/python.exe"
with tarfile.open(repo / "benchmarks/results/2026-11-22-regex-borrowed-window/checks-and-procedures.tar.xz") as history:
    catalog = json.load(history.extractfile("representative.json"))
template = catalog["cases"][1]
script = """import re
text = 'aé漢😀x' * 512
INDEX
pattern = re.compile(r'(?<=(é))(漢)(?=(😀))')
score = 0
for pos in range(384, 1664):
    score += len(pattern.findall(text, pos, pos + 20))
    for match in pattern.finditer(text, pos, pos + 15):
        score += match.start(1) + match.end(3)
print(score)
"""
cases = []
for indexed in (True, False):
    source = script.replace("INDEX\n", "assert text[2] == '漢'\n" if indexed else "")
    completed = subprocess.run([python, "-I", "-X", "utf8", "-c", source], text=True,
                               encoding="utf-8", capture_output=True, timeout=10, check=True)
    stdout = completed.stdout
    case = dict(template, id=f"scripts.regex-bounded-cursor.{'indexed' if indexed else 'unindexed'}",
                source=source, sourceSha256=sha(source.encode("utf-8")), sourceUtf8Bytes=len(source.encode("utf-8")),
                expectedOutput=stdout, expectedOutputSha256=sha(stdout.encode("utf-8")),
                expectedOutputUtf8Bytes=len(stdout.encode("utf-8")))
    cases.append(case)
assert cases[0]["expectedOutput"] == cases[1]["expectedOutput"]
catalog["cases"] = cases + catalog["cases"]
fixture = lab / "representative.json"
write(fixture, catalog)

identity = read(prior / "comparison/identity.json")
expected = identity["imageFiles"]["candidate"]
tree = repo / ".git/agent-worktrees/regex-indexed-cursor-window-20261123"
head = subprocess.check_output(["git", "-C", tree, "rev-parse", "HEAD"], text=True, encoding="utf-8").strip()
assert not subprocess.check_output(["git", "-C", tree, "status", "--porcelain"])
assert not subprocess.check_output(["git", "diff", "--name-only", "b32bf6b6b", identity["candidate"], "--", "src"], cwd=repo)
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes()) == identity["cpythonWorkerSHA256"]
new_images = {}
for role in ("reference", "candidate"):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name, digest in expected.items():
        original = prior / "candidate" / name
        assert sha(original.read_bytes()) == digest
        if role == "candidate" and name == "Lokad.Lython.dll":
            original = lab / "frozen/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
        shutil.copyfile(original, image / name)
    for name in ("ValidatedAllocation.dll", "ValidatedAllocation.deps.json", "ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(prior / "candidate" / name, image / name)
    files = {name: sha((image / name).read_bytes()) for name in expected}
    new_images[role] = files
    receipt = lab / (role + "-verify.json")
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", fixture,
                    "--dotnet", dotnet, "--python", python, "--python-worker", protocol,
                    "--out", receipt], env=env, timeout=60, check=True)
    proof = read(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(catalog["cases"])
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert all(sha((image / name).read_bytes()) == digest for name, digest in files.items())
assert [name for name in expected if new_images["reference"][name] != new_images["candidate"][name]] == ["Lokad.Lython.dll"]
write(lab / "identity.json", dict(sourceRevision="b32bf6b6b", sourceImageRevision=identity["candidate"],
    candidate=head, catalogSha256=sha(fixture.read_bytes()), images=new_images,
    cpythonWorkerSHA256=identity["cpythonWorkerSHA256"], expectedCPythonSHA256=identity["expectedCPythonSHA256"]))
