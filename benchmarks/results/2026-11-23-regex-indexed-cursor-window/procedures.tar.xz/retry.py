from pathlib import Path
import datetime
import hashlib
import json
import shlex
import shutil
import subprocess

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
failed = lab / "initial-stage"
failed.mkdir(exist_ok=False)
for name in ("observations.tar.xz", "terminal-status.json", "launch.log", "collect.py", "run.sh", "upload.json"):
    shutil.copyfile(quiet / name, failed / name)
shutil.copyfile(lab / "retrieval.log", failed / "retrieval.log")
identity_path = lab / "comparison/identity.json"
shutil.copyfile(identity_path, failed / "identity.json")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
status = json.loads((failed / "terminal-status.json").read_text(encoding="utf-8"))
assert status["exitCode"] == "1" and not status["fixtures"] and "KeyError: 'purpose'" in status["journal"]
assert sha(failed / "observations.tar.xz") == status["receipt"]["archiveSHA256"]
identity = json.loads(identity_path.read_text(encoding="utf-8"))
identity["purpose"] = "B1506 borrow only already-owned UTF-8 indices for interior regex cursor bounds"
identity_text = json.dumps(identity, indent=2) + "\n"
identity_path.write_text(identity_text, encoding="utf-8", newline="\n")
receipt_path = quiet / "upload.json"
previous = json.loads(receipt_path.read_text(encoding="utf-8"))
corrected = dict(previous, root=previous["root"] + "-corrected")
old_unit = "lython-b1506-regex-indexed-cursor-window-20261123"
unit = old_unit + "-corrected"
code = f"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
old=base/{previous['root']!r}
root=base/{corrected['root']!r}
reference=base/{previous['reference']!r}
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
text={identity_text!r}
identity=json.loads(text)
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1' and not (old/'guest-fixtures').exists()
 assert digest(old/'observations.tar.xz')=={status['receipt']['archiveSHA256']!r}
 assert shutil.disk_usage(base).free>=120*1024*1024
 for role, image in [('reference',reference/'candidate'),('candidate',old/'candidate')]:
  assert all(digest(image/name)==expected for name,expected in identity['imageFiles'][role].items())
 for name in ('representative.json','jobs.json'):
  assert digest(old/name)==identity['catalogs'][name]['sha256']
 for name, expected in {dict((name, sha(failed/name)) for name in ('collect.py','run.sh'))!r}.items():
  assert digest(old/name)==expected
 assert digest(old/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert b'\\r' not in (old/'run.sh').read_bytes()
 root.mkdir()
 image=root/'candidate';image.mkdir()
 for name in identity['imageFiles']['candidate']:
  os.link(old/'candidate'/name,image/name)
 for name in ('collect.py','run.sh','representative.json','jobs.json','cpython-worker.py'):
  shutil.copyfile(old/name,root/name)
 (root/'identity.json').write_text(text,encoding='utf-8')
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad',
 '--property=RuntimeMaxSec=350','--property=TimeoutStopSec=20','--property=KillMode=control-group',
 '--property=WorkingDirectory='+str(root),'/bin/sh',str(root/'run.sh')],check=True)
"""
compile(code, "corrected remote stage", "exec")
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
result = subprocess.run(ssh + ["python3 -c " + shlex.quote(code)], capture_output=True, timeout=35)
(lab / "corrected-stage.log").write_bytes(result.stdout + result.stderr)
print((result.stdout + result.stderr).decode(), end="")
result.check_returncode()
receipt_path.write_text(json.dumps(corrected,indent=2)+"\n", encoding="utf-8", newline="\n")
launcher = (lab / "quiet.py").read_text(encoding="utf-8")
assert old_unit in launcher
(lab / "corrected-quiet.py").write_text(launcher.replace(old_unit, unit), encoding="utf-8", newline="\n")
gate = datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=298)
(quiet / "observe-not-before").write_text(gate.isoformat(), encoding="utf-8")
