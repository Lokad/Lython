from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "supplied-scalar-return-20261123"
comparison = lab / "comparison"
comparison.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda data: hashlib.sha256(data).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

catalog = read(lab / "representative.json")
case_ids = [item["id"] for item in catalog["cases"]]
assert len(case_ids) == 6 and len(set(case_ids)) == 6
shutil.copyfile(lab / "representative.json", comparison / "representative.json")
write(comparison / "jobs.json", {"warm": [[name, "warm"] for name in case_ids if "-bounded-search" not in name]
                                 + [[case_ids[0], "compile-run"]]})
identity = read(lab / "identity.json")
assert sha((comparison / "representative.json").read_bytes()) == identity["catalogSha256"]
images = identity["images"]
for role, hashes in images.items():
    assert all(sha((lab / role / name).read_bytes()) == digest for name, digest in hashes.items())
    proof = read(lab / (role + "-verify.json"))
    assert proof["state"] == "Completed" and proof["catalogSha256"] == identity["catalogSha256"]
    assert proof["launched"]["library"]["sha256"] == hashes["Lokad.Lython.dll"]
write(comparison / "identity.json", dict(identity, imageFiles=images,
    coreSHA256={key: images[role]["Lokad.Lython.dll"] for role in images for key in (role, role + "-control")},
    catalogs={name: dict(sha256=sha((comparison / name).read_bytes())) for name in ("representative.json", "jobs.json")}))

# A withdrawn comparison remains available in its pushed archive and in a
# full local immutable image. The VM can release its last unshared core
# working copy if necessary to stage this comparison.
older = "benchmarks/results/2026-11-23-eager-computed-definition/"
def pushed(name):
    return subprocess.check_output(["git", "show", "origin/master:" + older + name], cwd=repo)
proof = json.loads(pushed("identity.json"))
terminal = json.loads(pushed("terminal-status.json"))
digest = terminal["receipt"]["archiveSHA256"]
assert terminal["receipt"]["complete"] and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha(pushed("observations.tar.xz")) == digest
local = lab.parent / "eager-computed-definition-20261123/candidate"
assert all(sha((local / name).read_bytes()) == value for name, value in proof["imageFiles"]["candidate"].items())
core = gzip.decompress(pushed("candidate-core.dll.gz"))
assert sha(core) == proof["imageFiles"]["candidate"]["Lokad.Lython.dll"]
retire = dict(sha=sha(core), size=len(core), archive=digest)

def install(name, replacements):
    source = (template / name).read_text(encoding="utf-8")
    for old, new in replacements:
        assert old in source, (name, old)
        source = source.replace(old, new)
    compile(source, name, "exec")
    (lab / name).write_text(source, encoding="utf-8", newline="\n")

install("stage.py", [
    ("supplied-scalar-return-b1504-20261123", "regex-indexed-cursor-window-b1506-20261123"),
    ("'lython-b1504-fixtures'", "'lython-b1506-fixtures'"),
])
install("quiet.py", [
    ("lython-b1504-supplied-scalar-return-20261123", "lython-b1506-regex-indexed-cursor-window-20261123"),
    (".+b1504-", ".+b1506-"),
    ("lython-b1504-stage-", "lython-b1506-stage-"),
    ("  assert free >= minimum,", """
  if free < minimum:
   proof = RETIREMENT_PROOF
   withdrawn = base/'eager-computed-definition-b1501-20261123'
   replica = withdrawn/'candidate/Lokad.Lython.dll'
   info = replica.lstat()
   assert replica.resolve()==replica and stat.S_ISREG(info.st_mode)
   assert info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size==proof['size']
   assert digest(replica)==proof['sha']
   assert digest(withdrawn/'observations.tar.xz')==proof['archive']
   assert not (withdrawn/'guest-fixtures').exists()
   replica.unlink()
   free=shutil.disk_usage(base).free
   print(json.dumps(dict(retiredWorkingReplica=str(replica),sha256=proof['sha'],freeAfterRetirement=free)),flush=True)
  assert free >= minimum,""".replace("RETIREMENT_PROOF", repr(retire))),
])
for name in ("summarize.py", "allocations.py"):
    shutil.copyfile(template / name, lab / name)
