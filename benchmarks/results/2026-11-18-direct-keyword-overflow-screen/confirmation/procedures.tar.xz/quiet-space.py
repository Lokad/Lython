from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

repo = Path.cwd()
lab = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()

archives = []
prior_images = {
    "benchmarks/results/2026-11-18-csv-line-number/candidate-core.dll.gz",
    "benchmarks/results/2026-11-18-trimmed-split-join/candidate-core.dll.gz",
    "benchmarks/results/2026-11-18-private-line-count/candidate-core.dll.gz",
    "benchmarks/results/2026-11-18-syntax-validity-scratch/candidate-core.dll.gz",
}
for path in subprocess.check_output(
        ["git", "ls-files", "--", "benchmarks/results/*core.dll.gz", "benchmarks/results/*observations.tgz"],
        cwd=repo, text=True, encoding="utf-8").splitlines():
    if not path.startswith(("benchmarks/results/2026-11-17-", "benchmarks/results/2026-11-16-")) and path not in prior_images:
        continue
    compressed = subprocess.check_output(["git", "show", f"HEAD:{path}"], cwd=repo)
    assert (repo / path).read_bytes() == compressed
    binary = path.endswith(".dll.gz")
    image = gzip.decompress(compressed) if binary else compressed
    archives.append(dict(canonical=path, canonicalSHA256=sha(compressed), sha256=sha(image),
                         bytes=len(image), kind="exact committed superseded core replica" if binary else "exact committed observations archive replica",
                         committedBlobVerified=True, days=["20261116", "20261117", "20261118"] if path in prior_images
                         else ["20261116", "20261117"]))

remote = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proofs={p['sha256']:p for p in PROOFS}
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
sizes={p['bytes'] for p in proofs.values()}
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    known={}
    for parent,_,names in os.walk(root):
        for name in ('Lokad.Lython.dll','observations.tgz'):
            if name not in names:continue
            p=Path(parent)/name
            v=p.lstat()
            if v.st_size not in sizes or not stat.S_ISREG(v.st_mode) or v.st_uid!=os.getuid():continue
            key=(v.st_dev,v.st_ino)
            if key not in known:known[key]=[hashlib.sha256(p.read_bytes()).hexdigest(),v.st_nlink,[]]
            known[key][2].append(p.relative_to(root).as_posix())
    eligible=[]
    for observed,links,paths in known.values():
        if observed not in proofs or len(paths)!=links:continue
        # Keep any link outside these older benchmark images, even if archival identity matches.
        if not all(any(f'-{day}/' in path for day in proofs[observed]['days']) for path in paths):continue
        eligible.append(dict(proofs[observed],paths=sorted(paths),links=links))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=eligible),indent=2))
'''.replace("PROOFS", repr(archives))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]
result = subprocess.run(ssh + ["python3 -"], input=remote.encode("utf-8"), capture_output=True, timeout=85, check=True)
receipt = json.loads(result.stdout)
(lab / "quiet-space.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(receipt["freeBytes"], "bytes free")
for proof in receipt["replicas"]:
    print(proof["sha256"][:8], proof["links"], proof["bytes"], *proof["paths"])
