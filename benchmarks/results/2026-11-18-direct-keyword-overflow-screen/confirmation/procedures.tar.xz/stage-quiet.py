from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "lexical-binding-order-r563"
previous = donor / "quiet"
quiet = lab / "quiet"
quiet.mkdir(exist_ok=False)
def read(path):
    return path.read_text(encoding="utf-8")

def load(path):
    return json.loads(read(path))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, source):
    if path.suffix == ".py":
        ast.parse(source)
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

prior = load(previous / "config.json")
screen = load(lab / "frozen-identity.json")
space = load(lab / "quiet-space.json")
catalog = lab / "catalog.json"
images = screen["images"]
donor_image = prior["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert screen["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == donor_image | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)
    (quiet / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, quiet / role / core)

target = "scripts.report-forwarding.keywords"
control = "calls.positional.large"
jobs = [(target, "warm"), (control, "warm"), (target, "compile-run"), (target, "compile")]
identity = dict(sourceRevision="25d3005f8 versus the archived R565 prototype",
                purpose="R565 keyword forwarding paired elapsed and process CPU confirmation",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=sha(catalog),
                coreSHA256={label: images[role][core] for role in images for label in [role, role + "-control"]})
root = "/home/lokad/lython-bench-checks/keyword-forwarding-b990-20261118"
unit = "lython-b990-keyword-forwarding-20261118"
runner = read(previous / "collect.py").replace("Lexical binding order source pair", "Keyword forwarding source pair")
start = runner.index("\njobs = ")
end = runner.index("\nassert len(jobs)", start)
runner = (runner[:start] + "\njobs = " + repr(jobs) + runner[end:]).replace("len(jobs)==5", "len(jobs)==4")
write(quiet / "collect.py", runner)
write(quiet / "archive-owned.py", read(previous / "archive-owned.py").replace("==5", "==4").replace("jobs=5", "jobs=4"))
write(quiet / "run.sh", read(previous / "run.sh").replace(prior["root"], root))
assert b"\r" not in (quiet / "run.sh").read_bytes()
save(quiet / "identity.json", identity)
shutil.copyfile(catalog, quiet / "representative.json")
names = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         f"reference/{core}", f"candidate/{core}"]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in names:
        archive.add(quiet / name, arcname=name)
unpacked = sum((quiet / name).stat().st_size for name in names)
need = 254 * 1024 * 1024 + unpacked + 512 * 1024
available = space["freeBytes"]
selected = []
for candidate in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available >= need:
        break
    selected.append(candidate)
    available += candidate["bytes"]
assert available >= need, (available, need, space["replicas"])
config = dict(root=root, unit=unit, source=prior["root"], sourceRole="candidate", sourceFiles=donor_image,
              sourceCatalogSHA256=prior["catalogSHA256"], catalogSHA256=sha(catalog), identity=identity,
              retireGroups=selected, payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=unpacked)
save(quiet / "config.json", config)
launcher = read(previous / "remote-launch.py")
start = launcher.index("\nc=") + 1
end = launcher.index("\nb=Path(")
launcher = launcher[:start] + "c=" + repr(config) + launcher[end:]
launcher = launcher.replace("lython-b989-fixtures", "lython-b990-fixtures")
write(quiet / "remote-launch.py", launcher)
retrieve = read(previous / "retrieve.py").replace("==5", "==4").replace("Lexical binding order source pair", "Keyword forwarding source pair")
write(quiet / "retrieve.py", retrieve)
launch = read(donor / "launch.py").replace("Lexical binding order source pair", "Keyword forwarding source pair")
launch = launch.replace("seconds=255", "seconds=215").replace("before255seconds", "before 215 seconds")
write(lab / "launch-quiet.py", launch)
summarize = read(donor / "summarize.py").replace("len(raw['jobs'])==5", "len(raw['jobs'])==4")
summarize = summarize.replace("r/'summary.json'", "r/'quiet-summary.json'").replace(
    "archivalOnlyRecovery=None", "archivalOnlyRecovery=json.loads((r/'quiet/retrieved/retirement-receipt.json').read_text(encoding='utf-8'))")
write(lab / "summarize-quiet.py", summarize)
print("Staged", payload.stat().st_size, "bytes for the quiet pair, with", len(selected), "verified old replicas to reclaim")
