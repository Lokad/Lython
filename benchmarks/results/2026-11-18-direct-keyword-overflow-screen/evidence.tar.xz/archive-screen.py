from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "direct-variadics-r564/archive.py"
text = template.read_text(encoding="utf-8")
text = text.replace("direct-variadics-r564", "direct-keyword-overflow-r565")
text = text.replace("2026-11-18-direct-variadic-positionals", "2026-11-18-direct-keyword-overflow-screen")
text = text.replace("da1946b1c", "25d3005f8")
text = text.replace("output.mkdir()", "output.mkdir(exist_ok=True)")
text = text.replace('[("white", 29), ("public", 193), ("wsl", 29)]',
                    '[("white", 33), ("public-refined", 199), ("wsl", 33), ("awaited", 1)]')
old = r'assert re.search(r"Expected:\s+0\s+Actual:\s+704", read(lab / "baseline-regression.log"))'
assert old in text
text = text.replace(old, 'assert read(lab / "alias-baseline.log").count("False True") == 2')
program = lab / "archive.py"
program.write_text(text, encoding="utf-8", newline="\n")
exec(compile(text, str(program), "exec"))
