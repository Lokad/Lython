from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import tarfile

repo = Path.cwd()
lab = Path(__file__).resolve().parent
work = repo / ".git/agent-worktrees/direct-keyword-overflow-r565"
output = repo / "benchmarks/results/2026-11-18-direct-keyword-overflow-screen"
output.mkdir(exist_ok=True)

def read(path):
    return path.read_text(encoding="utf-8-sig")

def load(path):
    return json.loads(read(path))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def pct(before, after):
    return round(100 * (after / before - 1), 3)

for test, count in [("white", 33), ("public-refined", 199), ("wsl", 33), ("awaited", 1)]:
    for framework in ["net10.0", "net11.0"]:
        assert re.search(rf"Failed:\s+0, Passed:\s+{count}, Skipped:\s+0", read(lab / f"{test}-{framework}.log"))
assert read(lab / "alias-baseline.log").count("False True") == 2
identities = load(lab / "frozen-identity.json")
assert identities["casesSHA256"] == sha(lab / "catalog.json")
for role, image in identities["images"].items():
    assert len(image) == 32
    assert {k: sha(lab / "frozen" / role / k) for k in image} == image
    assert load(lab / f"{role}-verify.json")["state"] == "Completed"

reference = load(lab / "reference-allocation.json")["rows"]
candidate = load(lab / "candidate-allocation.json")["rows"]
allocation = []
for before, after in zip(reference, candidate, strict=True):
    assert before["id"] == after["id"]
    assert before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    before_alloc = statistics.median(before["allocatedBytesPerInvocation"])
    after_alloc = statistics.median(after["allocatedBytesPerInvocation"])
    before_peak, after_peak = before["peakExecutionMemoryBytes"], after["peakExecutionMemoryBytes"]
    allocation.append(dict(case=before["id"], allocationBefore=before_alloc, allocationAfter=after_alloc,
                           allocationDeltaPercent=pct(before_alloc, after_alloc), accountedPeakBefore=before_peak,
                           accountedPeakAfter=after_peak, accountedPeakDeltaPercent=pct(before_peak, after_peak)))

measurements = []
for path in sorted(lab.glob("micro-*.json")):
    data = load(path)
    assert data["state"] == "Completed" and len(data["summaries"]) == 3
    assert data["catalogSha256"] == identities["casesSHA256"]
    index = int(path.name.split("-")[1])
    by_role = {row["engine"]: row for row in data["summaries"]}
    before, after = ("baseline", "candidate") if index < 4 else ("candidate", "baseline")
    measures = [row for row in data["attempts"] if row["phase"] == "measure"]
    assert len(measures) == 21 and all(row["response"]["status"] == "Completed" for row in measures)
    measurements.append(dict(file=path.name, lane=data["lane"], case=measures[0]["response"]["caseId"],
                             reference=by_role[before], updated=by_role[after], CPython=by_role["CPython"],
                             elapsedDeltaPercent=pct(by_role[before]["medianMicroseconds"], by_role[after]["medianMicroseconds"])))
assert len(measurements) == 8
(lab / "source.patch").write_bytes(subprocess.check_output(
    ["git", "-C", work, "diff", "--binary", "25d3005f8", "--", "src", "tests"]))
save(output / "summary.json", dict(images=identities, sourcePatchSHA256=sha(lab / "source.patch"),
                                  allocation=allocation, timings=measurements, cpuMeasured=False))
with tarfile.open(output / "evidence.tar.xz", "w:xz", preset=6) as archive:
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix in (".json", ".log", ".py", ".patch"):
            archive.add(path, arcname=path.name)
print("Archived verified input images, source patch, both golden results, raw local timings and focused checks.")
