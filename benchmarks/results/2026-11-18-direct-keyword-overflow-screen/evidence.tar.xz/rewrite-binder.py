from pathlib import Path

path = Path(".git/agent-worktrees/direct-keyword-overflow-r565/src/Lokad.Lython/Runtime/LythonRuntime.Calls.Binding.cs")
source = path.read_text(encoding="utf-8-sig")
inside = source.index("        // Keyword overflow likewise materializes")
start = source.index("        var positionalIndex = 0;", inside)
kw_finish = source.index("        if (plan.VariadicDictionaryIndex >= 0)", start)
finish = source.index("\n    }", kw_finish)
binding = source[start:kw_finish].rstrip()
binding = binding.replace("out firstExtraPositional, out extraPositionalCount, out extraKeywords)",
    "out firstExtraPositional, out extraPositionalCount, ref extraKeywords, ref syntheticKeyBytes)")
binding = binding.replace("        if (plan.VariadicListIndex >= 0)\n",
    "        if (plan.VariadicDictionaryIndex >= 0) extraKeywords ??= new PyDict(context.MemoryGovernor, span);\n"
    "        if (plan.VariadicListIndex >= 0)\n", 1)
binding += """\n\n        if (extraKeywords is not null)
        {
            values[plan.VariadicDictionaryIndex].Object = extraKeywords;
            extraKeywords = null;
        }"""
source = source[:inside] + """        PyDict? extraKeywords = null;
        long syntheticKeyBytes = 0;
        try
        {
""" + "\n".join("    " + line if line else line for line in binding.splitlines()) + """
        }
        finally
        {
            // Only the unexposed dictionary and labels created by this bind
            // can be refunded here. Expanded keys have their original owners.
            if (extraKeywords is not null)
            {
                try { extraKeywords.DiscardUnpublishedStorage(); }
                finally { context.MemoryGovernor.Release(syntheticKeyBytes); }
            }
        }""" + source[finish:]
source = source.replace("out Dictionary<string, object>? extraKeywords)",
                        "ref PyDict? extraKeywords, ref long syntheticKeyBytes)")
source = source.replace("        extraKeywords = null;\n        var positionalIndex = 0;",
                        "        var positionalIndex = 0;")
old = """                extraKeywords ??= new Dictionary<string, object>(StringComparer.Ordinal);
                if (!extraKeywords.TryAdd(keywordName, argument.Value))
                {
                    throw CallErrors.MultipleValues(plan.CallableKind, plan.CallableName, keywordName, span);
                }
"""
new = """                var governor = context.MemoryGovernor;
                extraKeywords ??= new PyDict(governor, span);
                var key = argument.OriginalKeyword;
                if (key is null)
                {
                    key = PyString.FromString(keywordName, governor, span);
                    if (ReferenceEquals(key.OwnerMemoryGovernor, governor))
                        syntheticKeyBytes = checked(syntheticKeyBytes + key.CommittedOwnedBytes);
                }
                if (!extraKeywords.TryAddNativeString(key, argument.Value, context, span))
                    throw CallErrors.MultipleValues(plan.CallableKind, plan.CallableName, keywordName, span);
"""
assert old in source
source = source.replace(old, new)
path.write_text(source, encoding="utf-8", newline="\r\n")
