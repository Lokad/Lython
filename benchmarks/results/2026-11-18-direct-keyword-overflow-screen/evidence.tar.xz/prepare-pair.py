from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent / "direct-variadics-r564/measure.py"
text = old.read_text(encoding="utf-8")
text = text.replace("direct-variadics-r564", "direct-keyword-overflow-r565")
text = text.replace("scripts.report-forwarding.variadic", "scripts.report-forwarding.keywords")
text = text.replace("da1946b1c", "25d3005f8")
start = text.index('    source = r"""')
end = text.index('"""', start + len('    source = r"""')) + 3
text = text[:start] + r"""    source = r'''def line(label, **fields):
    return '{}\t{}\t{}\t{}\n'.format(label, fields['début'], fields['end'], fields['count'])

start_key = ''.join(['dé', 'but'])
end_key = ''.join(['e', 'nd'])
count_key = ''.join(['cou', 'nt'])
count = 0
with open('input.txt', encoding='utf-8') as source, open('report.txt', 'w', encoding='utf-8', newline='') as target:
    for record in source:
        label, start, end, count_text = record.rstrip('\n').split(',')
        fields = {start_key: start, end_key: end, count_key: count_text}
        target.write(line(label, **fields))
        count += 1
print(count)
'''""" + text[end:]
reference = '''replacement = (donor.parent / "direct-variadics-r564/frozen/candidate" / core_name
                       if role == "reference" else src / "src/Lokad.Lython/bin/Release/net11.0" / core_name)'''
text = text.replace('replacement = src / "src/Lokad.Lython/bin/Release/net11.0" / core_name', reference)
compile(text, str(lab / "measure.py"), "exec")
(lab / "measure.py").write_text(text, encoding="utf-8", newline="\n")
