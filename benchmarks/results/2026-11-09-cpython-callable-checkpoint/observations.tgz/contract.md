# R146 external checkpoint

Refresh four unchanged representative scripts, each compile/warm/compile-to-result:
12 short jobs, CPython plus two independent current Lython processes. Ordinary
GC/tiering; five-second warmup each and seven rotated150ms rounds. Same external
source/inputs/goldens, unchanged R136 worker/adapter/protocol and boundary. Warm
includes mediated RAM-file I/O, full output checking and prior-result cleanup;
compile includes construction/disposal; compile-to-result combines those phases.
Startup/reset/protocol/final teardown excluded. No per-change gain attribution.
Retain all previous guide rows and original adverse/failed conditions. Variable
controls remain uncertainty, not a design veto. No repeated class-source pairs.
Finite330s owner/30stop/30margin, expected255s; join all users, remove RAM, archive
under lease and independently verify local SHA. No floor/headroom relaxation.
Qualification independent; publication postponed. This checkpoint does not complete
the broader performance objective or block independent regex/frontend development.
