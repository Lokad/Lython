from pathlib import Path
import json,re
r=Path(__file__).parent
data=json.loads((r/'summary.json').read_text(encoding='utf-8'))
rows={(x['case'],x['lane']):x for x in data['timing']}
names={'scripts.csv-validated-records.large':'CSV validation/helper calls','scripts.text-summary-helpers.large':'Text summary/helpers',
       'scripts.report-render.large':'JSON-to-Markdown report','scripts.file-search.large':'Protected file search'}
reverse={value:key for key,value in names.items()}
table=0;result=[]
for line in (r/'prior-BENCHMARKS.md').read_text(encoding='utf-8').splitlines():
    if line.startswith('| Workload |'):table+=1
    if table in [1,2,3] and line.startswith('| ') and line.split('|')[1].strip() in reverse:
        cells=line.split('|');case=reverse[cells[1].strip()];lane={1:'compile-run',2:'warm',3:'compile'}[table]
        d=rows[case,lane];a,b=d['timeRangeMilliseconds'];py=d['medianMilliseconds']['CPython'];lo,hi=d['ratioRange']
        status=f"{d['status']}; {d['controlPercent']:.2f}% /{max(d['iqrPercent'].values()):.2f}%"
        size=cells[2].strip() if table==1 else None
        if case=='scripts.file-search.large' and table==1:size='2,049 lines /42,010 B; stop after 1,025'
        prefix=f'| {names[case]} | '+(size+' | ' if table==1 else '')
        times=f'{a*1000:.1f}–{b*1000:.1f} µs' if lane=='compile' else f'{a:.3f}–{b:.3f} ms'
        pyt=f'{py*1000:.1f} µs' if lane=='compile' else f'{py:.3f} ms'
        line=prefix+f'{times} | {pyt} | {lo:.2f}–{hi:.2f}× | `65ed` | {status} |'
    result.append(line)
s='\n'.join(result)+'\n'
a=s.index('**Sources:');b=s.index('The table measures',a)
s=s[:a]+'''**Sources: `65ed` = `65ed6cf7`, 2026-11-09; `4598` = `459813a3`, 2026-11-09;
`6f76` = `6f76f99d`, 2026-11-08.** All use CPython 3.13.16 and .NET 11 RC3 on the same reference VM.
'''+s[b:]
a=s.index('Each row reports a fixed source checkpoint');b=s.index('## Warm execution, compilation and startup',a)
s=s[:a]+f'''Each row reports its named source checkpoint, rather than arbitrary later HEAD.
Source `65ed` uses a fresh nonincremental post-commit Release core `082aaa7c`, with
the unchanged R136 worker/adapter and external source/fixtures/goldens. Focused
semantic, cancellation and ownership checks pass on actual .NET 11/10; its full
delivery found a lazy-type/module-super classification regression and109 raw-module
fixture cases per OS. Corrected58d3ec0f passes200 internal/752 public focused checks
per actual framework; its full Windows/Ubuntu, original Stress and installed-package
delivery checks are pending. These timings still describe65ed, not that correction.
Earlier `4598` and `6f76` sources are fully qualified. The later generator source
`081052fa`, with test correction `27353cfb`, also passes those full delivery gates.
Qualification and performance evidence are separate; comparing these checkpoint
ratios cannot attribute a gain to an individual optimization.

The [current checkpoint](../benchmarks/results/2026-11-09-cpython-callable-checkpoint/README.md)
refreshes validated CSV, text helpers, JSON report and protected file search:
twelve short jobs/{data['elapsedSeconds']:.3f}s. All quiet, output, ownership, cleanup
and archive gates pass. Its [prior guide](../benchmarks/results/2026-11-09-cpython-callable-checkpoint/prior-BENCHMARKS.md)
retains every displaced row and original source; the other four rows remain
historical. Variable controls and earlier adverse observations stay explicit.

'''+s[b:]
a=s.index('Actual.NET11RC3');b=s.index('\n\nIdentical scripts/fixtures',a)
s=s[:a]+'''Actual.NET11RC3 and isolated CPython3.13.16 use ordinary GC/tiering; five-second
warmup per role/job and seven rotated150msrounds. Current core082a uses frozen
worker22331 and optional0.4 adapter; no benchmark worker/adapter source changed
since R136. Older rows use their recorded workers. The external supplied catalog,
host operations, protocol and timing boundary are unchanged. This checkpoint
qualifies no newer regex producer.'''+s[b:]
a=s.index('The eight rows use');b=s.index('Guarded text and eager/streamed',a)
search=rows['scripts.file-search.large','warm']['ratioRange']
s=s[:a]+f'''Four of eight rows use65ed; CSV summary/JSON-lines remain6f76, and config/manifest
remain4598. Search has2,049 physical input lines but exits at line1,025; both engines
run that same early exit. The manifest has two small files. These inputs do not
establish large-tree/file throughput. Search warm execution remains{search[0]:.2f}–{search[1]:.2f}×;
the host-mediated whole-script ratio alone does not identify removable interpreter
cost. Startup, genuinely pending I/O and impact on other embedding work remain
unmeasured. R145's class-callable source-pair improvements below do not describe
these unchanged main scripts or settle earlier report regression attribution.
'''+s[b:]
for block in re.findall(r'(?:^\|.*\n)+',s,re.M):
    assert len({len(x.split('|')) for x in block.strip().splitlines()})==1
for target in re.findall(r'\]\(([^)]+)\)',s):
    if not target.startswith(('http:','https:','#')):assert (Path('docs')/target.split('#')[0]).exists(),target
assert s.count(' | `65ed` |')==12 and ' | `6d73` |' not in s
Path('docs/BENCHMARKS.md').write_text(s,encoding='utf-8',newline='\n')
print('Updated four fixed-source rows in all three tables; preserved older rows/evidence and verified links/columns.')
