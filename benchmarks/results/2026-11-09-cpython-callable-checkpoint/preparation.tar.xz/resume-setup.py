from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent
assert not (r/'observe-not-before.json').exists()
assert 'FileExistsError' in (r/'launch.log').read_text(encoding='utf-8')
expected=json.loads((r/'identity.json').read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz') as archive:
    payload_required=sum(((m.size+4095)//4096)*4096 for m in archive.getmembers())
source=(r/'launch-command.py').read_text(encoding='utf-8')
tail=source[source.index(" assert hashlib.sha256((root/'current-core.dll')"):]
tail=tail.replace(" (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')",
    " if not (root/'cpython-worker.py').is_symlink(): (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')")
remote='''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'cpython-checkpoint-b503-20261109'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.is_dir() and not root.is_symlink() and root.stat().st_uid==os.geteuid()
 assert not (root/'guest-fixtures').exists() and not (root/'started.utc').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 identity=json.loads((root/'identity.json').read_text())
 assert identity==EXPECTED
 payloadRequired=PAYLOAD_REQUIRED
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert (root/'representative.json').read_bytes()==(base/'cpython-checkpoint-b496-20261109/representative.json').read_bytes()
 if (root/'cpython-worker.py').exists(): assert (root/'cpython-worker.py').is_symlink() and (root/'cpython-worker.py').resolve()==(base/'prepared-call-layout-b384-20261107/cpython-worker.py').resolve()
'''.replace('EXPECTED',repr(expected)).replace('PAYLOAD_REQUIRED',str(payload_required))+tail
compile(remote,'resume-catalog-setup','exec')
(r/'resume-command-final.py').write_text(remote,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True)
(r/'resume-final.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8');print(done.stdout+done.stderr,flush=True)
assert done.returncode==0
now=datetime.now(timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+timedelta(seconds=390)).isoformat(),ownerSeconds=330,stopSeconds=30,marginSeconds=30),indent=2),encoding='utf-8')
(r/'setup-correction.json').write_text(json.dumps(dict(originalFailure='Payload already contains byte-identical catalog; old launcher attempted another hard link at the same path. Before fixture mounting/worker launch/timing.',correction='Under existing lease, verify idle/no started marker, exact identity/catalog/core/all auxiliaries; retain supplied catalog and resume remaining unchanged setup. No deletion/retry of admission, new measurement condition, source change or evidence loss.',ownerSeconds=330),indent=2),encoding='utf-8')
print('Observe after',(now+timedelta(seconds=390)).isoformat())
