from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-09-cpython-callable-checkpoint')
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']
for target,source in [('observations.tgz','observations.tgz'),('summary.json','summary.json'),('identity.json','identity.json'),
                      ('core-source.json','core-source.json'),('terminal.json','terminal-status.json'),('prior-BENCHMARKS.md','prior-BENCHMARKS.md')]:
    assert not (out/target).exists()
    shutil.copyfile(r/source,out/target)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file() and p.name not in ['observations.tgz','payload.tgz']:
            archive.add(p,arcname=p.name)
with tarfile.open(out/'preparation.tar.xz') as archive:
    assert all(name in archive.getnames() for name in ['launch.log','resume.log','resume-fixed.log','resume-final.log','resume-command.py','resume-command-fixed.py','resume-command-final.py','fresh-build.log'])
print('Archived twelve-job raw/core evidence, exact source, prior rows and all original setup failures.')
