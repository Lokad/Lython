from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).parent
old=r.parent/'cpython-checkpoint-r136'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip().startswith('65ed6cf7')
assert not subprocess.check_output(['git','diff','--','src/Lokad.Lython'],text=True)
with (r/'fresh-build.log').open('w',encoding='utf-8') as log:
    done=subprocess.run([env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'fresh-build.log').read_text(encoding='utf-8')[-4000:]
(r/'updates').mkdir()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'updates/Lokad.Lython.dll')
core=hashlib.sha256((r/'updates/Lokad.Lython.dll').read_bytes()).hexdigest()
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='65ed6cf7de5675e08fed112b355d60eb28e7c154',coreSHA256={'candidate':core,'candidate-control':core},
                metadata='Fresh nonincremental post-commit R145 Release core; unchanged R136 worker/adapter/deps and external catalog. No source-pair speedup attribution; qualification independent.')
(r/'identity.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
(r/'updates.json').write_text(json.dumps({'Lokad.Lython.dll':core},indent=2),encoding='utf-8')
shutil.copyfile(old/'representative.json',r/'representative.json')
shutil.copyfile('docs/BENCHMARKS.md',r/'prior-BENCHMARKS.md')
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py']:
    data=(old/name).read_text(encoding='utf-8').replace('cpython-checkpoint-b496-20261109','cpython-checkpoint-b503-20261109')
    data=data.replace('lython-b496-cpython-checkpoint-20261109','lython-b503-cpython-checkpoint-20261109')
    data=data.replace('cpython-checkpoint-b496-launch.py','cpython-checkpoint-b503-launch.py')
    data=data.replace('len(jobs)==9','len(jobs)==12').replace("len(r['jobs'])==9","len(r['jobs'])==12")
    data=data.replace("len(raw['jobs'])==9","len(raw['jobs'])==12").replace('len(external)==9','len(external)==12')
    data=data.replace("['receipt']['jobs']==9","['receipt']['jobs']==12").replace('jobs=9,','jobs=12,')
    data=data.replace('all9JobsValidated','all12JobsValidated').replace('ownerSeconds=270','ownerSeconds=330')
    data=data.replace('RuntimeMaxSec=270','RuntimeMaxSec=330').replace('seconds=330','seconds=390')
    data=data.replace(' < 240,',' < 300,').replace('lython-b490-fixtures','lython-b503-fixtures')
    if name=='collect.py':
        start=data.index('jobs=[');end=data.index('\nenv =',start)
        jobs=[[case,lane] for case in ['scripts.csv-validated-records.large','scripts.text-summary-helpers.large','scripts.report-render.large','scripts.file-search.large'] for lane in ['compile','warm','compile-run']]
        data=data[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==12 and all(case in cases for case,lane in jobs)\n'+data[end:]
        start=data.index("purpose='R136");end=data.index('\n                  warmupSeconds=',start)
        data=data[:start]+"purpose='R146 post-commit65ed6cf7 after shared generator/callable consolidation. Unchanged representative CSV validation, text, JSON report and protected file search against CPython3.13.16; separate compile/warm/compile-to-result. Same worker/adapter/protocol/catalog; original historical rows and controls retained. No individual source-gain attribution.',"+data[end:]
    if name=='launch.py':
        data=data.replace("reference=base/'native-booleans-b495-20261109/candidate'","reference=base/'cpython-checkpoint-b496-20261109/candidate'")
    if name=='archive-owned.py':
        data=data.replace(", 'fresh-il-proof.json', 'worker-source-diff.patch'",'')
    compile(data,name,'exec') if name.endswith('.py') else None
    (r/name).write_text(data,encoding='utf-8',newline='\n')
proof=dict(sourceRevision=identity['sourceRevision'],coreSHA256=core,freshNonincrementalBuild=True,
           productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj'not in p.parts},
           unchangedWorkerAdapterSourceDiff=subprocess.check_output(['git','diff','6d73c742','HEAD','--','benchmarks/Lokad.Lython.Benchmarks','src/Lokad.Lython.Utf8Regex'],text=True))
assert not proof['unchangedWorkerAdapterSourceDiff']
(r/'core-source.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
(r/'source.patch').write_text('No working production changes; committed65ed6cf7.\n',encoding='utf-8')
(r/'focused.json').write_text(json.dumps(dict(R145InternalPerFramework=357,R145PublicPerFramework=1722,additionalCompilerLambdaPerFramework=46,actualFrameworks=['net11.0','net10.0'],fullDeliveryCI=42586293361,fullDeliveryStatus='pending'),indent=2),encoding='utf-8')
(r/'sizing.json').write_text(json.dumps(dict(jobs=12,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=255,ownerSeconds=330),indent=2),encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=330,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,jobs=12),indent=2),encoding='utf-8')
plan='''# R146 external checkpoint

Refresh four unchanged representative scripts, each compile/warm/compile-to-result:
12 short jobs, CPython plus two independent current Lython processes. Ordinary
GC/tiering; five-second warmup each and seven rotated150ms rounds. Same external
source/inputs/goldens, unchanged R136 worker/adapter/protocol and boundary. Warm
includes mediated RAM-file I/O, full output checking and prior-result cleanup;
compile includes construction/disposal; compile-to-result combines those phases.
Startup/reset/protocol/final teardown excluded. No per-change gain attribution.
Retain all previous guide rows and original adverse/failed conditions. Variable
controls remain uncertainty, not a design veto. No repeated class-source pairs.
Finite330s owner/30stop/30margin, expected255s; join all users, remove RAM, archive
under lease and independently verify local SHA. No floor/headroom relaxation.
Qualification independent; publication postponed. This checkpoint does not complete
the broader performance objective or block independent regex/frontend development.
'''
for name in ['selection.md','contract.md','pre-measurement-plan.md']:(r/name).write_text(plan,encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz') as archive:
    for p in r.iterdir():
        if p.name!='payload.tgz':archive.add(p,arcname=p.name)
print('Fresh committed core',core,'twelve jobs; payload',(r/'payload.tgz').stat().st_size,'bytes')
