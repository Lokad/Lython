from collections import Counter
from pathlib import Path
import json

lab=Path(__file__).resolve().parent
def symbol(name):return name.split("(",1)[0].split("!",1)[-1]
roots=("LythonRuntime+ExecutionContext.TryExecute","LythonRuntime+NativeExecution.RunCore",
       "LythonRuntime+ExecutionContext.Run","LythonRuntime.ExecuteExecutableCodeObject")
def describe(path):
    data=json.loads(path.read_text(encoding="utf-8-sig"))
    names=[row["name"]for row in data["shared"]["frames"]]
    active=0.0
    intervals=0
    inclusive=Counter()
    exclusive=Counter()
    nearest=Counter()
    sampledFrames=Counter()
    largestInterval=0.0
    for profile in data["profiles"]:
        assert profile["unit"]=="milliseconds" and profile["type"]=="evented"
        frames=[]
        last=profile["startValue"]
        for event in profile["events"]:
            now=event["at"]
            duration=now-last
            if duration>0 and frames and any(any(root in f for root in roots) for f in frames):
                active+=duration
                intervals+=1
                largestInterval=max(largestInterval,duration)
                exclusive[symbol(frames[-1])]+=duration
                names_on_stack=[symbol(f) for f in frames if "Lokad.Lython.Runtime." in f]
                if names_on_stack:
                    nearest[names_on_stack[-1]]+=duration
                    sampledFrames[names_on_stack[-1]]+=1
                inclusive.update({f:duration for f in set(names_on_stack)})
            if event["type"]=="O":frames.append(names[event["frame"]])
            else:assert frames.pop()==names[event["frame"]]
            last=now
        assert not frames
    return dict(script=path.parent.name,runtimeAncestryThreadMilliseconds=active,intervals=intervals,
        nearestRuntime=nearest.most_common(22),intervalCountAttribution=sampledFrames.most_common(22),largestIntervalMilliseconds=largestInterval,exclusive=exclusive.most_common(20),inclusive=inclusive.most_common(30))
rows=[describe(lab/role/"warm.speedscope.json") for role in ("word-count","postponed-factories")]
(lab/"attribution.json").write_text(json.dumps(dict(source=json.loads((lab/"identity.json").read_text(encoding="utf-8"))["revision"],rows=rows,quietTiming=False),indent=2)+"\n",encoding="utf-8",newline="\n")
for row in rows:
    print(row["script"],round(row["runtimeAncestryThreadMilliseconds"],1),row["intervals"],"largest interval",row["largestIntervalMilliseconds"],row["intervalCountAttribution"][:4])
    for name,value in row["nearestRuntime"][:8]:print(f"  {value:.1f} {name}")
