from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.parent/"future-annotations-single-walk-20261122"/"comparison"
probe=lab.parent/"factory-worker-spread-20261122"
quiet=lab/"quiet"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,indent=2)+"\n")
def verified(folder):
    base=f"origin/master:benchmarks/results/{folder}"
    receipt=json.loads(git("show",base+"/archive-receipt.json"))
    assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert receipt["archiveSHA256"]==sha(git("show",base+"/observations.tgz"))
    return base,receipt["archiveSHA256"]

p=read(previous/"quiet/config.json")
old=read(previous/"quiet/identity.json")
verified_git,archive=verified("2026-11-22-future-validation-single-walk")
_,donor=verified("2026-11-22-callable-checkpoint-cpython")
assert old["imageFiles"]==json.loads(git("show",verified_git+"/source.json"))["imageFiles"]
old_core=gzip.decompress(git("show",verified_git+"/candidate-core.dll.gz"))
assert sha(old_core)==old["imageFiles"]["candidate"][core]
old_name=Path(p["root"]).name
retire=[dict(paths=[old_name+"/candidate/"+core],bytes=len(old_core),sha256=sha(old_core),links=1,
             archives={old_name+"/observations.tgz":archive})]
local=read(lab/"identity.json")
current=local["imageFiles"]["candidate"]
assert current=={n:h(lab/"frozen"/n) for n in current}
assert [n for n,d in old["imageFiles"]["reference"].items() if current[n]!=d]==[core]
outline=read(lab/"run-summary.json")
assert outline["sourceRevision"]==local["revision"] and outline["allProcessesJoined"]
catalog=lab/"catalog.json"
verification=read(lab/"verification.json")
assert verification["state"]=="Completed" and verification["caseCount"]==2
assert verification["catalogSha256"]==h(catalog)
jobs=[(row["id"],"warm")for row in read(catalog)["cases"]]
root="/home/lokad/lython-bench-checks/factory-text-attribution-b1422-20261122"
unit="lython-b1422-factory-text-attribution-20261122"
identity=dict(sourceRevision=local["revision"],reference=old["reference"],candidate=local["revision"],
              purpose="Check live managed attribution on the two outstanding measured workloads",
              normalAdapterPin="0.4.0",imageFiles=dict(reference=old["imageFiles"]["reference"],candidate=current),
              protocolSHA256=local["protocolSHA256"],coreSHA256={role+suffix:values[core]
                 for role,values in (("reference",old["imageFiles"]["reference"]),("candidate",current))for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":h(catalog)}})
quiet.mkdir()
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir()
shutil.copyfile(lab/"frozen"/core,quiet/"candidate"/core)
shutil.copyfile(probe/"warm_probe.py",quiet/"warm_probe.py")
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(previous/"quiet"/leaf).read_text(encoding="utf-8").replace(p["root"],root).replace(p["unit"],unit)
    code=code.replace("len(raw['jobs'])==6","len(raw['jobs'])==2").replace("jobs=6,","jobs=2,").replace("['jobs']==6","['jobs']==2")
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nenv =")
        code=code[:a]+"\njobs = "+repr(jobs)+"\n"+code[b:]
        code=code.replace("not any(self.identity['runtimeOverrides'].values())",
            "not any(v for k,v in self.identity['runtimeOverrides'].items() if k!='DOTNET_PerfMapEnabled')")
        code=code.replace("and k != 'DOTNET_ROOT' for k in env)","and k != 'DOTNET_ROOT' for k in env)\nenv['DOTNET_PerfMapEnabled']='3'")
        code=code[:code.index("with (root.parent/'comparison-vm.lock')")]+(lab/"collect-body.py").read_text(encoding="utf-8")
    code=code.replace("Future validation","Factory and text attribution")
    write(quiet/leaf,code)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","warm_probe.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for leaf in parts:t.add(quiet/leaf,arcname=leaf)
config={**p,"root":root,"unit":unit,"identity":identity,"donorArchiveSHA256":donor,
        "retireGroups":retire,"payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),
        "unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",config)
code=(previous/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(config)+code[b:]).replace("b1421-fixtures","b1422-fixtures")
    .replace("RuntimeMaxSec=425","RuntimeMaxSec=160"))
launch=(previous/"launch.py").read_text(encoding="utf-8").replace("Future validation","Factory and text attribution")
write(lab/"launch.py",launch.replace("seconds=380","seconds=100").replace("before 380 seconds","before 100 seconds"))
print(local["revision"],root,config["unpackedBytes"],flush=True)
