from pathlib import Path
import hashlib,json,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=lab.parent/"short-borrowed-text-probe-20261122"/"comparison"
images=read(base/"identity.json")
ref=base/"frozen-reference"
assert {n:sha(ref/n) for n in images["imageFiles"]["reference"]}==images["imageFiles"]["reference"]
latest=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert latest.startswith("3b45fdfc7")
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
core="Lokad.Lython.dll"
paths={n:ref/n for n in images["imageFiles"]["reference"]}
paths[core]=lab/"build"/"bin"/"Lokad.Lython"/"release_net11.0"/core
frozen=lab/"frozen"
frozen.mkdir(exist_ok=False)
for name,path in paths.items():shutil.copyfile(path,frozen/name)
manifest={n:sha(p) for n,p in paths.items()}
assert manifest=={n:sha(frozen/n) for n in paths}
info=dict(revision=latest,imageFiles={"candidate":manifest},protocolSHA256=images["protocolSHA256"])
(lab/"identity.json").write_text(json.dumps(info,indent=2)+"\n",encoding="utf-8",newline="\n")
previous=lab.parent/"current-retained-runtime-profile-20261122"/"profile.py"
script=previous.read_text(encoding="utf-8")
script=script.replace('(data/"2026-11-22-retained-source-cpython/source.json")','(lab/"identity.json")')
script=script.replace('lab.parent/"current-cpython-checkpoint-20261122/frozen"','lab/"frozen"')
script=script.replace('2026-11-22-retained-source-cpython/observations.tgz','2026-11-22-callable-checkpoint-cpython/observations.tgz')
script=script.replace('"scripts.annotated-rule-closures.nested-factories.postponed",\n     "scripts.csv-invoice.method-policy.quoted-control")','"scripts.annotated-rule-closures.nested-factories.postponed")')
script=script.replace('caseCount"]==3','caseCount"]==2').replace('("word-count","postponed-factories","quoted-invoice")','("word-count","postponed-factories")')
compile(script,str(lab/"profile.py"),"exec")
(lab/"profile.py").write_text(script,encoding="utf-8",newline="\n")
