from warm_probe import dump, medians, observe, preserve_maps, sample_profile, warm

with (root.parent/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def gate(name):
        subprocess.run([str(dotnet),str(worker),"--compare","check-machine","--out",str(out/name)],env=env,check=True)
        assert json.loads((out/name).read_text())["gate"]["quiet"]
    time.sleep(5)
    gate("machine-before.json")
    (out/"fixture-filesystem.txt").write_text(subprocess.check_output(
        ["findmnt","-T",str(owned_ram),"-o","TARGET,SOURCE,FSTYPE,OPTIONS"],text=True))
    started=time.monotonic()
    record=dict(sourceRevision=identity["sourceRevision"],purpose=identity["purpose"],
        warmupSeconds=8,perfMapMode=3,frequency=199,performanceQualified=False,complete=False,jobs=[])
    report=out/"confirmation.json"
    dump(report,record)
    labels=["candidate","candidate-control"]
    for index,(case_id,lane) in enumerate(jobs):
        job_folder=out/f"job-{index}"
        job_folder.mkdir()
        job=dict(case=case_id,lane=lane,profiles=[])
        record["jobs"].append(job)
        pids={}
        try:
            with contextlib.ExitStack() as stack:
                workers=[]
                for label in labels:
                    w=Worker(label,cases[case_id],lane,stack)
                    workers.append(w)
                    pids[label]=w.process.pid
                counts=[1]*len(workers)
                warmed=[0.0]*len(workers)
                warmups={label:[] for label in labels}
                warm(workers,counts,warmed,8,warmups,0)
                job.update(identities={w.label:w.identity for w in workers},warmupBatches=warmups)
                for w,count in zip(workers,counts,strict=True):
                    job["profiles"].append(sample_profile(w,count,job_folder/("profile-"+w.label),cpu_frequency))
                after=observe(workers,counts,2,cpu_frequency)
                job.update(postProfileBatches=after,postProfileMedians=medians(labels,after))
        finally:
            if pids:job["retiredTemporaryMaps"]=preserve_maps(pids,job_folder/"maps")
        job["workersJoinedAndFixturesRemoved"]=True
        dump(report,record)
    time.sleep(5)
    gate("machine-after.json")
    record.update(complete=True,elapsedSeconds=time.monotonic()-started)
    dump(report,record)
    assert not list(owned_ram.iterdir())
    subprocess.run(["sudo","-n","umount",str(owned_ram)],check=True)
    owned_ram.rmdir()
    subprocess.run(["python3",str(root/"archive-owned.py")],check=True)
