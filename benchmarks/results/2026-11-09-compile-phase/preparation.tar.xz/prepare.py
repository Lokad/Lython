from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'helper-cost-r123';image=r.parent/'declaration-layout-r127';root='compile-phase-b488-20261109';unit='lython-b488-compile-phase-20261109'
repl=lambda s:s.replace('helper-cost-b482-20261108',root).replace('lython-b482-helper-cost-20261108',unit).replace('lython-b482','lython-b488')
for name in ['ops-profile.py','analyze-cpu-guest.py','run.sh','archive.py','launch.py','retrieve.py']:
 s=repl((old/name).read_text(encoding='utf8'))
 if name=='ops-profile.py':
  s=s.replace('Initial current synchronous text CPU capture','Current compilation-only phase attribution')
  s=s.replace('("helper-warm", "scripts.csv-validated-records.large", "warm")','("helper-compile", "scripts.csv-validated-records.large", "compile")').replace('("inline-warm", "scripts.csv-validated-records-inline.large", "warm")','("config-compile", "scripts.config-edit.small", "compile")')
  s=s.replace('count = 64  #','count = 1024  #')
  s=s.replace('512 if lane == "compile" else 512','4096 if lane == "compile" else 512')
  s=s.replace('env["DOTNET_JitDisasm"]="ExecuteInstructionPrefix BeginBoundCall BindCallOperands CreateTupleFromStack"\n        env["DOTNET_JitStdOutFile"]=str(folder/"call-jit.txt")','')
  s=s.replace('["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]','["DOTNET_PerfMapEnabled"]')
  s=s.replace("expected['files']['Lokad.Lython.dll']","expected['coreSHA256']")
  s=s.replace("row['name'].startswith('Lython executio') and row['seconds'] > 0", "row['seconds'] > .5 and row['name'] not in {'.NET Tiered Com', '.NET Finalizer', '.NET Server GC', '.NET Background'}")
  s=s.replace('Expected actual named active guest worker threads.', 'Expected actual active compilation worker threads.')
 if name in ['archive.py','run.sh']:
  s=s.replace('helper-warm','helper-compile').replace('inline-warm','config-compile')
 if name=='archive.py':
  s=s.replace("assert len(record['redundantTemporaryMapsRetiredAfterJoin'])==2", "assert record['redundantTemporaryMapsRetiredAfterJoin']")
  s=s.replace("assert (p/'perf.map').stat().st_size>0 and (p/'perfinfo.map').stat().st_size>0", "assert (p/'perf.map').stat().st_size>0")
 if name=='launch.py':
  s=s.replace("source=(base/'function-lookups-b479-20261108/candidate').resolve()", "source=(base/'declaration-layout-b487-20261109/candidate').resolve()")
  s=s.replace("{**identity['auxiliaryFiles'],**identity['files']}", "{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}")
  s=s.replace('helper-cost-b482-launch-v2.py','compile-phase-b488-launch.py')
 (r/name).write_text(s,encoding='utf8',newline='\n')
catalog=json.loads((image/'catalog.json').read_text(encoding='utf8'))
oldcatalog=json.loads((r.parent/'checkpoint-cpython-r67/representative.json').read_text(encoding='utf8'))
catalog['cases']=[next(c for c in catalog['cases']if c['id']=='scripts.csv-validated-records.large'),next(c for c in oldcatalog['cases']if c['id']=='scripts.config-edit.small')]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf8')
b=json.loads((image/'b487/identity.json').read_text(encoding='utf8'))
i=dict(sourceRevision='8472935f',coreSHA256=b['coreSHA256']['candidate'],auxiliaryFiles=b['auxiliaryFiles'],catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),purpose='Compile-only phase attribution, not an elapsed comparison; current actual worker threads selected by CPU, no guest-thread assumption')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
proof=dict(vmArchive='declaration-layout-b487-20261109/observations.tgz',archiveSHA256=json.loads((image/'b487/terminal.json').read_text(encoding='utf8'))['receipt']['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256'])
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
(r/'selection.md').write_text('R128 compile-phase source gate: current847/coreac6b, existing validatedCSV helper and config-edit scripts, unchanged goldens/fixtures. Two6s CPU captures after6s warmup each; compile lane includes complete compilation and prior-script disposal, excludes guest execution/I/O. Public verification before/after and Closed/zero-budget cleanup retained. Normal GC/tiering, perf map diagnostic only. Attribute to actual active compiler workers rather than named guest threads. No elapsed claim. Stop with lexer/parser/analysis/lowering/executable/cleanup attribution and choose at most one coherent repeated phase, no new framework.180sowner+30stop+30observation.\n',encoding='utf8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
(r/'sizing.json').write_text(json.dumps(dict(jobs=2,warmupSecondsEach=6,captureSecondsEach=6,ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','core-source.json','selection.md','sizing.json','pre-measurement-plan.md']:a.add(r/name,arcname=name)
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','launch.py','retrieve.py']:compile((r/name).read_text(encoding='utf8'),name,'exec')
print('Prepared two bounded compile profiles, current core',i['coreSHA256'])
