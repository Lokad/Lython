from pathlib import Path
import bisect,collections,json,re
r=Path(__file__).parent;outputs=[]
phases=[('tokenization',['PythonTokenization+Reader::Read']),('parsing',['Frontend.Parser::','Frontend.Parser+']),('syntax validity',['SyntaxValidityDiagnostics::','GeneratorSyntaxDiagnostics::','ModernTypeSyntaxDiagnostics::','FutureImportSyntaxDiagnostics::']),('postponed annotation text',['PostponedAnnotationText::']),('lexical preparation',['LexicalScopePreparation::']),('annotation analysis',['AnnotationDiagnostics::']),('scope diagnostics',['StaticScopeDirectiveDiagnostics::']),('abstract analysis',['StaticAbstractInterpreter::']),('name diagnostics',['StaticNameBindingDiagnostics::']),('lowering',['LoweredScript::Lower','LoweredExpression::Lower','LoweredStatement::Lower']),('executable construction',['ExecutableScript::Compile','ExecutableScript+Builder::','ExecutableStackLayout::']),('compiled disposal',['LythonCompiledScript::Dispose'])]
for folder in sorted((r/'retrieved/profiles').iterdir()):
 record=json.loads((folder/'record.json').read_text(encoding='utf8'));tids=set(record['guestTids'])
 ranges=[]
 for line in (folder/'perf.map').read_text(encoding='utf8').splitlines():
  parts=line.split(' ',2)
  if len(parts)==3:ranges.append((int(parts[0],16),int(parts[1],16),parts[2]))
 ranges.sort();starts=[x[0]for x in ranges]
 def symbol(address,name):
  i=bisect.bisect_right(starts,address)-1
  return ranges[i][2]if i>=0 and address<ranges[i][0]+ranges[i][1]else name
 frames=[];active=False;counts=collections.Counter();inclusive=collections.Counter();callers=collections.Counter();samples=0;unknown=0
 def finish():
  global samples,unknown
  if not active or not frames:return
  samples+=1
  hits=[(i,phase)for i,f in enumerate(frames)for phase,keys in phases if any(k in f for k in keys)]
  # Assign each sample once to its innermost observed phase root; report inclusive separately.
  counts[min(hits)[1]if hits else'unassigned']+=1
  for phase in set(p for i,p in hits):inclusive[phase]+=1
  if frames[0]=='[unknown]':unknown+=1
  if 'ExpressionSyntaxTraversal+Enumerator::MoveNext' in frames[0]:
   callers[next((f for f in frames[1:]if 'ExpressionSyntaxTraversal'not in f),'<missing>')]+=1
 for line in (folder/'perf-stacks.txt').read_text(encoding='utf8').splitlines():
  header=re.fullmatch(r'\s*(\d+)/(\d+)\s*',line)
  if header:finish();frames=[];active=header[2]in tids;continue
  m=re.match(r'\s+([0-9a-f]+)\s+(.*)',line)
  if active and m:frames.append(symbol(int(m[1],16),m[2]))
 finish()
 out=dict(case=record['workload'],lane='compile',samples=samples,unknownLeaf=unknown,exclusiveObservedPhase=[dict(phase=p,samples=n,percent=100*n/samples)for p,n in counts.most_common()],inclusiveObservedPhase=dict(inclusive),expressionTraversalLeafCallers=callers.most_common(),limits='Diagnostic frame-pointer samples; inlining/truncation/unknown leaf IPs prevent exact attribution. Phase samples are not removable costs; normal GC and prior-script disposal included.')
 outputs.append(out);print(json.dumps(out,indent=2))
(r/'phase-assessment.json').write_text(json.dumps(outputs,indent=2)+'\n',encoding='utf8')
