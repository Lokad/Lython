from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'compile-phase-b488-20261109'
source=(base/'declaration-layout-b487-20261109/candidate').resolve()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not Path('/dev/shm/lython-b488').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(17137+1)
 assert len(payload)==17137 and hashlib.sha256(payload).hexdigest()=='04e2fce53433ecc74a2da6c4838c3e9662103577404f7ae4c045140f5b69c65c'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 proof=json.loads((root/'core-source.json').read_text());archive=base/proof['vmArchive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(proof['member']).read()).hexdigest()==proof['coreSHA256']
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 fixture=Path('/dev/shm/lython-b488');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b488-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=180,stopSeconds=30,observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=12)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b488-compile-phase-20261109',
 '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180',
 '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
