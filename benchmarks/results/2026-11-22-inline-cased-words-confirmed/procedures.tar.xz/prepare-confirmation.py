from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
import datetime

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab/"comparison/quiet"
owned=lab/"confirmation"
owned.mkdir(exist_ok=True)
base="/home/lokad/lython-bench-checks"
root=base+"/inline-cased-words-repeat-b1391-20261122"
unit="lython-b1391-confirm-cased-words-20261122"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):
    if not isinstance(value,str):value=json.dumps(value,indent=2)+"\n"
    if path.suffix==".py":compile(value,str(path),"exec")
    path.write_text(value,encoding="utf-8",newline="\n")

donor=read(old/"config.json")
receipt=read(old/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","quietBeforeAndAfter","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha((old/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
images=read(old/"identity.json")
frozen = {"reference":lab.parent/"record-and-text-profile-20261122/comparison/frozen-candidate",
          "candidate":lab/"comparison/frozen-candidate"}
for role,image in frozen.items():
    expected=images["imageFiles"][role]
    assert len(expected)==32 and {name:sha((image/name).read_bytes()) for name in expected}==expected
    for catalog, directory, file in [("representative.json",lab/"comparison","catalog.json"), ("dense.json",lab/"dense-line","catalog.json")]:
        proof=read(directory/f"{role}-verify.json")
        assert proof["state"]=="Completed" and proof["catalogSha256"]==sha((directory/file).read_bytes())
        if catalog=="dense.json":assert proof["caseCount"]==1
dense=(lab/"dense-line/catalog.json").read_bytes()
(owned/"dense.json").write_bytes(dense)
images["catalogs"]["dense.json"]={"sha256":sha(dense)}
images["purpose"]="Confirm the opposite warm effects of prepared word storage and add the dense-line boundary"
write(owned/"identity.json",images)

ids=[c["id"] for c in read(old/"representative.json")["cases"] if "map-callback" not in c["id"]]
dense_id,=[c["id"] for c in read(owned/"dense.json")["cases"]]
jobs=[(case,"warm") for case in [*ids,dense_id]]
catalogs={case:"representative.json" if case!=dense_id else "dense.json" for case,_ in jobs}
assert len(jobs)==4
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(old/name).read_text(encoding="utf-8").replace(donor["root"],root).replace(donor["unit"],unit)
    if name=="collect.py":
        a,b=code.index("\njob_catalog = "),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr(catalogs)+"\njobs = "+repr(jobs)+code[b:]
        code=code.replace("len(jobs)==5","len(jobs)==4").replace("if job_index % 2 == 0:", "if job_index % 2 != 0:")
        code=code.replace("time.monotonic()-started < 290","time.monotonic()-started < 222")
    elif name in ("archive-owned.py","retrieve.py"):
        code=code.replace("jobs=5,","jobs=4,").replace("['jobs']==5","['jobs']==4").replace("len(raw['jobs'])==5","len(raw['jobs'])==4")
    write(owned/name,code)
assert b"\r" not in (owned/"run.sh").read_bytes()
parts=("identity.json","dense.json","collect.py","archive-owned.py","run.sh")
payload=owned/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:bundle.add(owned/name,arcname=name)
unpacked=sum((owned/name).stat().st_size for name in parts)

known={}
for path in (repo/"benchmarks/results").glob("*/observations.tgz"):
    p=path.parent/"archive-receipt.json"
    if path.stat().st_size<400000 or not p.exists():continue
    info=read(p)
    if all(info.get(k) for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):
        known.setdefault(path.stat().st_size,[]).append((info["archiveSHA256"],path.parent.name))
query="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(BASE);known=KNOWN
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 found=[]
 for p in sorted(b.glob('*/observations.tgz'),key=lambda p:-p.stat().st_size):
  m=p.lstat()
  if m.st_size not in known or not stat.S_ISREG(m.st_mode) or m.st_nlink!=1 or m.st_uid!=os.getuid() or p.resolve()!=p:continue
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  folder=next((f for digest,f in known[m.st_size] if digest==h),None)
  if folder:found.append(dict(paths=[str(p.relative_to(b))],bytes=m.st_size,links=1,sha256=h,archives={},published=folder))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,found=found)))
""".replace("BASE",repr(base)).replace("KNOWN",repr(known))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
inventory=subprocess.check_output(ssh+["python3 -"],input=query.encode(),timeout=55)
(owned/"inventory.json").write_bytes(inventory)
free=json.loads(inventory)
target=176160768+unpacked+640*1024
available=free["free"]
retire=[]
for match in free["found"]:
    if available>target:break
    path=f"benchmarks/results/{match['published']}/observations.tgz"
    canonical=subprocess.check_output(["git","show","origin/master:"+path],cwd=repo)
    assert (len(canonical),sha(canonical))==(match["bytes"],match["sha256"])
    retire.append(match)
    available+=match["bytes"]
assert available>target
stage=dict(root=root,unit=unit,identity=images,source=donor["root"],donorArchiveSHA256=receipt["archiveSHA256"],
    sourceCatalogSHA256=images["catalogs"]["representative.json"]["sha256"],
    protocolSource=donor["protocolSource"],protocolSHA256=donor["protocolSHA256"],retireGroups=retire,
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
write(owned/"config.json",stage)
code=(old/"remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
code=code[:a]+"c="+repr(stage)+code[b:]
code=code.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    " for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
code=code.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
code=code.replace(" assert sha(root/'representative.json')==c['identity']['catalogs']['representative.json']['sha256']",
    " os.link(source/'representative.json',root/'representative.json')\n for leaf,info in c['identity']['catalogs'].items():assert sha(root/leaf)==info['sha256']")
code=code.replace("lython-b1390-fixtures","lython-b1391-fixtures").replace("RuntimeMaxSec=342","RuntimeMaxSec=285")
write(owned/"remote-launch.py",code)
launch=(lab/"comparison/launch.py").read_text(encoding="utf-8").replace("parent/'quiet'","parent/'confirmation'")
launch=launch.replace("294","238").replace("Prepared word storage","Prepared word storage confirmation")
write(lab/"launch-confirmation.py",launch)
print("Prepared four warm phases with both frozen images and both catalogs verified; archive replicas reserved",len(retire),flush=True)
