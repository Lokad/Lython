from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
folder=lab/"confirmation"
dest=repo/"benchmarks/results/2026-11-22-inline-cased-words-confirmed"
def read(p):return json.loads(p.read_text(encoding="utf-8"))
receipt=read(folder/"archive-receipt.json")
terminal=read(folder/"terminal-status.json")
digest=hashlib.sha256((folder/"observations.tgz").read_bytes()).hexdigest()
assert receipt==terminal["receipt"] and digest==receipt["archiveSHA256"]
assert terminal["exitCode"]=="0" and not terminal["remainingWorkers"] and not terminal["remainingTrace"]
assert all(receipt[k] for k in ("complete","quietBeforeAndAfter","allWorkersJoined","archivedAndVerifiedUnderLease"))
raw=read(folder/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and len(raw["jobs"])==receipt["jobs"]==4
assert all(len(job["samples"])==28 and job["workersJoinedAndFixturesRemoved"] for job in raw["jobs"])
identity=read(folder/"identity.json")
reference=read(repo/"benchmarks/results/2026-11-22-inline-cased-word-headers/source.json")
assert identity["imageFiles"]==reference["imageFiles"]
assert identity["catalogs"]["representative.json"]==reference["catalogs"]["representative.json"]
assert len(identity["catalogs"])==2
for case in raw["jobs"]:
    keys={i["catalogSha256"] for i in case["identities"].values()}
    assert keys=={identity["catalogs"]["dense.json" if "dense-line" in case["case"] else "representative.json"]["sha256"]}
revision="c097d73db"
patch=subprocess.check_output(["git","diff",revision+"^",revision,"--","src","tests"],cwd=repo)
assert hashlib.sha256(patch).hexdigest()==identity["sourcePatchSHA256"]
summary=read(folder/"quiet-summary.json")
assert len(summary["rows"])==4 and summary["complete"]
summary.pop("retentionDecisionPending")
summary.update(productionRevision=revision,outcome="retained for ownership simplification and dense memory benefit",timedBatches=112)
dest.mkdir(exist_ok=True)
for name in ("observations.tgz","archive-receipt.json","terminal-status.json"):
    shutil.copyfile(folder/name,dest/name)
(dest/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
files=("archive-b1391.py","prepare-confirmation.py","launch-confirmation.py","summarize-confirmation.py",
    *("confirmation/"+f for f in ("identity.json","config.json","inventory.json","dense.json",
        "collect.py","archive-owned.py","retrieve.py","run.sh","remote-launch.py","observe-not-before.json","launch.log")),
    "dense-line/summary.json")
with tarfile.open(dest/"procedures.tar.xz","w:xz")as bundle:
    for name in files:bundle.add(lab/name,arcname=name)
with tarfile.open(dest/"procedures.tar.xz") as bundle:assert set(bundle.getnames())==set(files)
