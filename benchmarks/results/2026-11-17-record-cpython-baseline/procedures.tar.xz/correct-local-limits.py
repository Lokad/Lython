from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'quiet';assert not(q/'launch.log').exists();before=r/'first-prepared-limits';before.mkdir()
for n in ['collect.py','remote-launch.py','config.json']:shutil.copyfile(q/n,before/n)
p=q/'collect.py';s=p.read_text(encoding='utf-8');assert 'time.monotonic()-started < 540'in s;p.write_text(s.replace('time.monotonic()-started < 540','time.monotonic()-started < 160'),encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'remote-launch.py';s=p.read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('RuntimeMaxSec=600','RuntimeMaxSec=210');assert 'RuntimeMaxSec=210'in s;ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
print('Verified3-job160s collector/210s service before launch; original reused limits preserved locally.')
