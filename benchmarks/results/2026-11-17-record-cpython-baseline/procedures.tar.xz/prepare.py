from pathlib import Path
import ast,gzip,hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'operand-transport-r497';old=prior/'quiet';current=r.parent/'constant-record-r499';q=r/'quiet';q.mkdir(exist_ok=False)
f=json.loads((current/'frozen/identity.json').read_text(encoding='utf-8'));files=f['imageFiles']['candidate']
assert len(files)==32 and all(hashlib.sha256((current/'frozen/candidate'/n).read_bytes()).hexdigest()==h for n,h in files.items())
catalog=json.loads((current/'catalog.json').read_text(encoding='utf-8'));case=next(c for c in catalog['cases']if c['id']=='scripts.json-record-transform.large')
assert (repo/'benchmarks/scripts/json-record-transform.py').read_text(encoding='utf-8')==case['source']
identity=dict(sourceRevision='Committedea8e9f91 production/frozencf847936; later commits evidence only. CPython3.13.16 external baseline.',purpose='Fill new maintained JSON record-transform baseline: compile,warm execution,compile-to-result. Existing six-case catalog and actual32file image verification reused; no source-change speedup inferred.',coreSHA256={role:files['Lokad.Lython.dll']for role in ['candidate','candidate-control']},imageFiles=dict(candidate=files),auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=f['sourceInputsArchiveSHA256'],productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.json-record-transform.large',lane]for lane in ['compile','warm','compile-run']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('time.monotonic()-started < 540','time.monotonic()-started < 160')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==12","len(raw['jobs'])==3").replace('jobs=12','jobs=3');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/record-cpython-b927-20261117';unit='lython-b927-record-cpython-20261117';oldconfig=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(oldconfig['root'],remote),encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-17-owned-transfer-dispatch/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);assert hashlib.sha256(data).hexdigest()!=files['Lokad.Lython.dll']
subjects=[dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True)]
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('json-cpython-b908-20261117','transfer-dispatch-b926-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout)
(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/transfer-dispatch-b926-20261117',sourceRole='reference',sourceFiles=files,sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
cpLink=" os.link(source/'cpython-worker.py',root/'cpython-worker.py')";assert cpLink in s
s=s.replace(cpLink,cpLink+"\n os.link(source/'representative.json',root/'representative.json')")
s=s.replace('lython-b919-fixtures','lython-b927-fixtures').replace('RuntimeMaxSec=600','RuntimeMaxSec=210')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8').replace('seconds=500','seconds=180').replace('before500seconds','before180seconds').replace('Twelve-job representative CPython checkpoint','Three-job record CPython checkpoint');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==12","['jobs']==3").replace('B919','B927');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==12","len(raw['jobs'])==3");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert "len(raw['jobs'])==3"in(q/'archive-owned.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=3,currentImage=files['Lokad.Lython.dll'][:8],customCatalogUnchangedAndPreviouslyVerified=True,oldIsolatedCoreOnly=groups[0]['paths'])))
