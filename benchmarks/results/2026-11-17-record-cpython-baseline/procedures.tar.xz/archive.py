from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-record-cpython-baseline';out.mkdir(exist_ok=False)
for n in ['summary.json'] :shutil.copyfile(r/n,out/n)
for n in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
source=repo/'benchmarks/results/2026-11-17-constant-record-keys';identity=json.loads((out/'identity.json').read_text(encoding='utf-8'));assert hashlib.sha256((source/'candidate-sources.tar.xz').read_bytes()).hexdigest()==identity['sourceInputsArchiveSHA256']
shutil.copyfile(source/'catalog.json',out/'catalog.json');shutil.copyfile(source/'candidate-preflight.json',out/'reused-preflight.json')
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or 'retrieved'in p.relative_to(r).parts:continue
  if p.suffix not in ['.py','.json','.log','.sh']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'));rows={x['lane']:x for x in summary['timing']}
def span(row,labels):
 vals=[row['medianMilliseconds'][n]for n in labels];return f'{min(vals):.3f}–{max(vals):.3f} ms'
def row_text(lane,phase):
 row=rows[lane];ratios=row['ratioRange'];status=f"Diagnostic; controls L/C {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; IQR≤{row['maxIqrPercent']:.2f}%"
 return f"| JSON-lines record transform | {phase} | {span(row,['candidate','candidate-control'])} | {span(row,['CPython','CPython-control'])} | {min(ratios):.2f}–{max(ratios):.2f}× | {status} |"
table='\n'.join(row_text(lane,phase)for lane,phase in [('compile','Compilation only'),('warm','Warm execution'),('compile-run','Compile-to-result')])
(out/'README.md').write_text('''# Maintained record-transform versus CPython

2026-11-17 UTC,B927; committedea8e9f91 production/frozencf847936 versus stock
CPython3.13.16(PGO/LTO,GIL,noJIT). Quiet AzureF4as_v7,4EPYC9V45vCPU/16GiB,
Ubuntu24.04.4/.NET11RC3. Three jobs116.40s, six-second rotated full-request warmups,
five rounds/two independent processes per engine, naturalGC/tiering. Existing
workers/protocol/catalog; no new framework or unchanged four-workload replay.

Complete maintained JSON record transform:4,096records/110,592B. It parses each
line, calls an ordinary helper returning a two-field dict, aggregates and writes
a validated report. Same independent JSON input/output/file goldens as the helper
aggregation; no predicted ratio from the earlier within-Lython improvements.

| Workload | Phase | Lython | CPython | Lython / CPython | Measurement status |
| --- | --- | ---: | ---: | ---: | --- |
'''+table+'''

Ratios use all combinations of process medians, not confidence intervals. Lython
warm2.93%/fresh3.31%same-source movement limits precision; original controls/CPU/
IQRs remain. No causal source improvement or general speedup is inferred. This
fills a missing named external baseline; it does not replace or relabel the valid
four-workload0d2a6ab7/8d26963c checkpoint. Current text/floating gaps remain visible.

Warm includes Run, mediated RAM I/O, all stdout/file golden checks and prior-result
cleanup. Fresh adds compile/compiled-owner disposal; compilation-only includes
compiled-owner disposal. Reset/protocol/startup/final cache teardown excluded;
processCPU wider. CPython native filesystem is uncontained; this is useful script
latency, not equal containment. Independent warmed medians are not additive.

All32frozen files(copies, including worker/optional adapter) and the unchanged
six-case catalog compare to the actual R499 verification before staging. Reuse
that exact image/catalog preflight, not a core-only guess. The maintained script
text equals catalog source. Identity/source-archive hashes identify measured
inputs; all585production inputs subsequently qualified at ea8e9f91 by full
Windows/Ubuntu actual11/10,originalstress/installed Release consumers. No rebuilt
binary equality is inferred. [Delivery](../2026-11-17-constant-record-keys/delivery/README.md),
[sources](../2026-11-17-constant-record-keys/candidate-sources.tar.xz).

Quiet/goldens/allowance/Closed/zero-exit/join gates pass. Persistent archive verified
under lease and locally; fixtures removed. Only exact committed unpromotedbfef
core replica retires; currentcfimage/catalog/toolchains and original adverse
evidence stay.254/252MiB guards unchanged. Reused collection/service limits were
corrected locally to160/210s before launching; original prepared limits retained.
No collection failed or condition was retimed. Terminal cached; publication held.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[catalog](catalog.json),[reused verification](reused-preflight.json),[procedures](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
guide=repo/'docs/BENCHMARKS.md';s=guide.read_text(encoding='utf-8');w=rows['warm'];ratios=w['ratioRange']
line=f"| JSON-lines record transform | 4,096 records / 110,592 B | {span(w,['candidate','candidate-control'])} | {span(w,['CPython','CPython-control'])} | {min(ratios):.2f}–{max(ratios):.2f}× | Diagnostic ea8/cf; controls L/C {w['lythonControlPercent']:.2f}/{w['cpythonControlPercent']:.2f}%; IQR≤{w['maxIqrPercent']:.2f}% |\n"
needle='| Numeric CSV quality report |';assert needle in s;s=s.replace(needle,line+needle,1)
s=s.replace('Measured **2026-11-17 UTC**, committed **0d2a6ab7 / frozen8d26963c**, stock', 'The CSV/text/aggregation/floating rows were measured **2026-11-17 UTC**, committed\n**0d2a6ab7 / frozen8d26963c**, stock')
needle='Warm clocks include Run, mediated RAM-backed file I/O'
addition='''The record-transform row is a separate **2026-11-17** checkpoint of qualified
**ea8e9f91 production / frozencf847936**, on the same machine/toolchains/boundaries:
three jobs116.40s. Its2.93%warm/3.31%fresh Lython control spread limits precision.
[Source, controls and raw data](../benchmarks/results/2026-11-17-record-cpython-baseline/README.md).

''';assert needle in s;s=s.replace(needle,addition+needle,1)
a=s.index('## Compilation and compile-to-result');left,right=s[:a],s[a:];sep='| --- | --- | ---: | ---: | ---: | --- |\n';assert sep in right
right=right.replace(sep,sep+row_text('compile','Compilation only')+'\n'+row_text('compile-run','Compile-to-result')+'\n',1);guide.write_text(left+right,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:h.write('\nR502 [record-transform CPython baseline](results/2026-11-17-record-cpython-baseline/README.md): qualifiedea8production/frozencf versus stockCPython3.13.16, threejobs116.40s/all actualimage/goldens/quiet/reuse/join/archive pass. Compile1.01–1.02×, warm0.88–0.91×,fresh0.90–0.93×; Lythoncontrols2.93/3.31%limit precision. Same complete4,096record/110,592B program includes mediatedI/O/goldens/resultcleanup, freshaddscompile/ownerdisposal; startup excluded/processCPUwider. Retain old0d fourrows/current gaps; no causal source gain or equal-containment claim. Guide adds this material missing baseline, no unchanged broad replay/publication.\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('Three\ncompile/warm/fresh jobs versus CPython3.13.16 running as B927,210sservice/160s\ncollector cap; first observation≥23:08:10UTC.', 'Completed B927 threejobs116.40s versus CPython3.13.16: compile1.01–1.02×,\nwarm0.88–0.91×,fresh0.90–0.93×. Controls2.93/3.31%limit Lython precision; all\ngoldens/quiet/reuse/join/archive checks pass. Guide/evidence updated; no replay.')
p.write_text(s,encoding='utf-8',newline='\n')
print(table);print('Targeted external baseline archived and guide refreshed; no unmeasured HEAD claim.')
