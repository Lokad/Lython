# R199 bounded current-text attribution

One existing complete text-summary/helper script, warmed6s/captured6s with current
039/66eb source, existing worker and perf protocol. All thread CPU/maps/raw leaves
retained; select actual CPU-active execution worker, never assume process main.
No elapsed source pair, CPython timing, compilation or startup. Whole-batch samples
include reset/protocol/validation wider than execution clocks; shares include useful
inlined work and are not removable taxes. Current CI pending, no qualification claim.
90sowner/30sstop/30smargin. Verify before/after, join/close, copy/SHA temporary maps,
quiet gates and persistent archive before RAM retirement. Stop after this capture
and one source gate; choose material work/storage deletion or record no justified
redesign. No unchanged recapture selected. Publication held.
