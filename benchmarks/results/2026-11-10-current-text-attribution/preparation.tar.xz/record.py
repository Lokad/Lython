from pathlib import Path
import bisect,collections,datetime,hashlib,json,re,shutil,tarfile
h=Path(__file__).parent;p=h/'b549';r=p/'retrieved/profiles/text-warm';repo=Path('D:/code/Lython');dest=repo/'benchmarks/results/2026-11-10-current-text-attribution';dest.mkdir()
receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
record=json.loads((r/'record.json').read_text(encoding='utf-8'));original=json.loads((r/'guest-cpu-leaves.json').read_text(encoding='utf-8'));ranges=[]
for line in(r/'perf.map').read_text(encoding='utf-8').splitlines():
 a,n,name=line.split(' ',2);ranges.append((int(a,16),int(n,16),name))
ranges.sort();starts=[a for a,n,name in ranges];counts=collections.Counter();tids=set(record['guestTids'])
for line in(r/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
 m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
 if not m or m[2]not in tids:continue
 address=int(m[3],16);i=bisect.bisect_right(starts,address)-1;symbol=m[4]
 if i>=0 and address<ranges[i][0]+ranges[i][1]:symbol=ranges[i][2]
 counts[symbol]+=1
assert counts.total()==original['samples']==1144 and counts['[unknown]']==71
rules=[('VM instruction prefix',['::ExecuteInstructionPrefix']),('Operand/result transport',['::CompleteLocalResult','::ExecuteStackTransfer','ExecutableValueStorage']),('Native dictionary/hash',['::TryExecuteDictionaryAccumulation','::TryAccumulateWithoutAdmission','::ComputeStructuralHashCode','::FindNativeIndex']),('Whitespace/casing',['PyStringOps::']),('Native call selection',['::TryExecuteNativeCall','::TryLoadDirectCallReceiver','::EvaluateNativeReturn']),('Scalar arithmetic',['::AddExactIntegers','PyNumberOps::']),('Monitor locking; caller not attributed',['System.Threading.Monitor::']),('Unmapped',['[unknown]'])]
groups=collections.Counter()
for name,count in counts.items():groups[next((label for label,needles in rules if any(n in name for n in needles)),'Other mapped leaves')]+=count
wall=(datetime.datetime.fromisoformat(record['stoppedUtc'])-datetime.datetime.fromisoformat(record['startedUtc'])).total_seconds()
attribution=dict(sourceRevision='Committed66ebdb4b source-equivalent frozen039; CI42822411897 pending at capture.',samples=counts.total(),unknown=71,wallCaptureSeconds=wall,workerExecutionSeconds=receipt['capturedSeconds'],selectedThreadCPUSeconds=original['cpuSeconds'],allThreadCPU=record['threadCpuSeconds'],groups=[dict(name=k,samples=v,percent=100*v/counts.total())for k,v in groups.most_common()],allLeaves=counts.most_common(),limits='Disjoint innermost groups contain useful/inlined work and wider reset/protocol/validation; no removable-tax, single-change or CPU speedup forecast. All unknowns/raw maps/stacks retained.')
(dest/'attribution.json').write_text(json.dumps(attribution,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['observations.tgz','archive-receipt.json','identity.json','terminal-status.json','extraction.json']:shutil.copyfile(p/name,dest/name)
with tarfile.open(dest/'preparation.tar.xz','w:xz')as a:
 for path in sorted(h.rglob('*')):
  if path.is_file()and'retrieved'not in path.relative_to(h).parts and path.name not in ['observations.tgz','payload.tgz']:a.add(path,arcname=path.relative_to(h).as_posix())
 for name in ['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs','src/Lokad.Lython/Runtime/LythonRuntime.Builtins.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs']:a.add(repo/name,arcname='source-gate/'+name)
rows='\n'.join(f"| {x['name']} | {x['samples']} | {x['percent']:.2f}% |"for x in attribution['groups'])
(dest/'README.md').write_text('''# R199 — current text CPU attribution and source gate

2026-11-10, committed66ebdb4b production source matches frozen039dc975; existing
complete text-summary/helper script, exact fixtures/output goldens and worker,
optional adapter0.4. F4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary GC/tiering plus
diagnostic perf-map logging. Full source CI42822411897 was pending at capture.
No new source optimization, elapsed comparison, CPython timing or compilation.

One warmed capture completes with1,144 execution-thread samples,71unmapped6.21%,
5.76threadCPU seconds. Worker execution clocks sum5.855seconds; the six-second
wall window also includes reset/protocol/validation. [All leaves/thread CPU](attribution.json),
[raw maps/stacks/record/core](observations.tgz), [receipt](archive-receipt.json),
[preparation/source gate](preparation.tar.xz). The actual CPU-active execution
thread is selected, never assumed to be process main. No malformed map lines.

| Innermost observed group | Samples | Share |
| --- | ---: | ---: |
'''+rows+'''

These disjoint groups include useful and inlined work, unknowns and the wider
worker boundary. They are not removable taxes or speedup forecasts. Monitor
samples have no proved caller attribution; do not automatically assign them to
memory admission. Binding/frame construction is not a prominent observed leaf.

Bounded source findings: whitespace range collection already computes case
capacity in the same scan; final words write direct UTF-8. Native string hashing
already takes the direct current-token path, not the general comparer/protocol
route. MemoryGovernor.Commit changes accounting categories without resizing the
shared lease. Do not recreate those optimizations or weaken admission/cancellation.
There is no demonstrated dominant duplicate frontend pass in this warm capture.

Next source assessment: reduce the hot instruction loop's cold operation body and
live temporaries while retaining the one executable engine. Current prefix/operand
work is material; R194's larger OSR frame and slower variants argue for examining
code/frame size before another control-loop change. This is a hypothesis, not a
predicted gain or selected replacement implementation. Define displaced cold cases,
semantic gates and a bounded complete-script comparison before editing. Broader
performance and independent regex work remain active; no unchanged recapture.

Verification before/after, normal close/join, quiet gates, temporary-map copy/SHA
before retirement, empty RAM unmount, persistent archive-under-lease and localSHA
verification all pass. No active VM users or RAM traces. No publication or adapter
pin change. No unchanged full-platform qualification is repeated for this source-only
attribution; pending qualification remains tracked separately.
''',encoding='utf-8',newline='\n')
exp=repo/'benchmarks/EXPERIMENTS.md';s=exp.read_text(encoding='utf-8');i=s.index('The [R198 ordinary-method context simplification]')
s=s[:i]+'''The [R199 current-text attribution](results/2026-11-10-current-text-attribution/README.md)
captures one six-second warm window,1144samples/6.21%unknown, all gates/join/SHA pass.
Instruction/operand transport, native dictionary/hash and text kernels remain
material; frames/binding are not prominent. Source gates confirm already-fused
case capacity, direct native hashing and no host resize on commit. No elapsed
gain, removed-tax estimate, source optimization or recapture is claimed.

'''+s[i:];exp.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(attribution['groups'],indent=2),flush=True)
