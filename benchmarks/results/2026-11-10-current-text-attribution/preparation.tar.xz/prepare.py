from pathlib import Path
import ast,datetime,hashlib,json,shlex,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b549';p.mkdir();old=h.parent/'report-construction-r195/b543';repo=Path('D:/code/Lython')
source=json.loads((h.parent/'deferred-method-r198/diagnostic/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
base=json.loads((h.parent/'deferred-method-r198/b548/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='Committed66ebdb4b production source matches all568 files; measured precommit039 core, not a rebuilt-binary identity. CI42822411897 pending.',coreSHA256=source['cores']['candidate'],auxiliaryFiles=base['auxiliaryFiles'],performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=json.loads((h.parent/'json-cpython-r197/representative.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.large'];assert len(catalog['cases'])==1
(p/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace('report-assessment-b543-20261110','current-text-b549-20261110').replace('lython-b543-report-assessment-20261110','lython-b549-current-text-20261110').replace('/dev/shm/lython-b543','/home/lokad/lython-bench-checks/current-text-b549-20261110/guest-fixtures')
 s=s.replace("['report-warm','report-compile','config-warm','config-compile']","['text-warm']").replace('report-warm report-compile config-warm config-compile','text-warm').replace('seconds<32','seconds<10').replace('total_capture_seconds > 32','total_capture_seconds > 10')
 if name=='ops-profile.py':
  a=s.index('for name, case_id, lane in ');b=s.index(':\n',a)
  s=s[:a]+"for name, case_id, lane in [(\"text-warm\", \"scripts.text-summary-helpers.large\", \"warm\")]"+s[b:]
  s=s.replace("guest = [row for row in record['threadCpuSeconds'] if row['seconds'] > .25 and (row['tid'] == str(process.pid) if lane == 'compile' else row['name'].startswith('Lython executio'))]","guest = [row for row in record['threadCpuSeconds'] if row['seconds'] > .25 and row['name'].startswith('Lython executio')]")
  assert "row['tid'] == str(process.pid)"not in s
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R199 bounded current-text attribution

One existing complete text-summary/helper script, warmed6s/captured6s with current
039/66eb source, existing worker and perf protocol. All thread CPU/maps/raw leaves
retained; select actual CPU-active execution worker, never assume process main.
No elapsed source pair, CPython timing, compilation or startup. Whole-batch samples
include reset/protocol/validation wider than execution clocks; shares include useful
inlined work and are not removable taxes. Current CI pending, no qualification claim.
90sowner/30sstop/30smargin. Verify before/after, join/close, copy/SHA temporary maps,
quiet gates and persistent archive before RAM retirement. Stop after this capture
and one source gate; choose material work/storage deletion or record no justified
redesign. No unchanged recapture selected. Publication held.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['identity.json','catalog.json','contract.md','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes();s=(old/'launch-command.py').read_text(encoding='utf-8').replace('report-assessment-b543-20261110','current-text-b549-20261110').replace('lython-b543-report-assessment-20261110','lython-b549-current-text-20261110').replace("source=base/'prefix-code-b541-20261110/candidate';fixture=Path('/dev/shm/lython-b543')","source=base/'deferred-method-b548-20261110/candidate';fixture=root/'guest-fixtures'")
start=s.index('copies=[');end=s.index("with(base/'comparison-vm.lock')",start);s=s[:start]+s[end:]
s=s.replace('14690',str(len(payload)+1)).replace('14689',str(len(payload))).replace('288dbdb586f2c6823cd1944b8f4fa126714a5dba80f1644502c417377be9830f',hashlib.sha256(payload).hexdigest()).replace('ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3',identity['coreSHA256'])
start=s.index('before=shutil.disk_usage(base).free;retire=[];');end=s.index(' with tarfile.open(fileobj=',start)
s=s[:start]+f'''before=shutil.disk_usage(base).free
 assert before>{(240+12)*1024*1024+3*len(payload)},before
 recovery=dict(beforeFreeBytes=before,freshIdleLease=True,allImagesPreserved=True,retiredFiles=[])
'''+s[end:]
s=s.replace('lython-b543-fixtures','lython-b549-fixtures').replace('captures=4,ownerSeconds=120','captures=1,ownerSeconds=90').replace('RuntimeMaxSec=120','RuntimeMaxSec=90')
s=s.replace(" (root/'setup.json').write_text", " assert setup['freeBytes']>(240+12)*1024*1024\n (root/'setup.json').write_text")
ast.parse(s);(p/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];stage='/home/lokad/lython-bench-checks/current-text-b549-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=s.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True);(p/'launch.log').write_bytes(r.stdout+b'\n'+r.stderr);assert r.returncode==0,r.stderr.decode('utf-8')
assert b'ActiveState=active'in r.stdout and b'MainPID=0'not in r.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=150)).isoformat(),ownerSeconds=90,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print(r.stdout.decode('utf-8'),flush=True);print('Observe after',(now+datetime.timedelta(seconds=150)).isoformat(),flush=True)
