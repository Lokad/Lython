from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'current-text-b549-20261110'
source=base/'deferred-method-b548-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not fixture.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 payload=sys.stdin.buffer.read(10054);assert len(payload)==10053 and hashlib.sha256(payload).hexdigest()=='a97666e543565d52ef589ba1ed49f3b547efef257795c922c90d9567a923fac7'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 before=shutil.disk_usage(base).free
 assert before>264271311,before
 recovery=dict(beforeFreeBytes=before,freshIdleLease=True,allImagesPreserved=True,retiredFiles=[])
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b549-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,captures=1,ownerSeconds=90,stopSeconds=30,marginSeconds=30,performanceQualified=False)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b549-current-text-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=90','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b549-current-text-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
