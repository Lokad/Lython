from pathlib import Path
import ast
h=Path(__file__).parent;p=h/'b549';old=h.parent/'report-construction-r195/b543/retrieve.py'
s=old.read_text(encoding='utf-8').replace('report-assessment-b543-20261110','current-text-b549-20261110').replace('lython-b543-report-assessment-20261110','lython-b549-current-text-20261110').replace("Path('/dev/shm/lython-b543').exists()","(root/'guest-fixtures').exists()").replace("['capturedSeconds']<32","['capturedSeconds']<10")
ast.parse(s);(p/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
plan=Path('D:/code/Lython/PLAN.md');s=plan.read_text(encoding='utf-8');i=s.index('## Next coherent redesigns')
s=s[:i]+'''## Active R199: current text attribution

One six-second warm capture using frozen039/source-equivalent committed66eb and
the existing worker/perf protocol. No new source optimization or elapsed/CPython
comparison. Actual CPU-active execution thread selected; all thread deltas, raw
leaves/maps and unknowns retained. Whole-batch samples include reset/protocol and
useful inlined work, not removable-tax estimates. CI qualification is pending.
Owned B549:90sowner/30sstop/30smargin, observe same handle only after
**2026-11-10 13:17:53.800UTC**. Preserve verify/close/join/quiet/archive/SHA and RAM
cleanup. Stop after this capture and a bounded source gate; choose a material
work/storage deletion or record why no justified redesign follows. No recapture
or broad measurement campaign selected. Publication remains held.

'''+s[i:];plan.write_text(s,encoding='utf-8',newline='\n')
print('Prepared retrieval and recorded bounded active attribution.')
