#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/owner-type-new-slots-b1990-20261128"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
filter='Category!=Stress&(FullyQualifiedName~SharedTypeSlotConcurrency|FullyQualifiedName~Constructor|FullyQualifiedName~SharedFixedLabel|FullyQualifiedName~BuiltinDefinitionIsolation|FullyQualifiedName~BuiltinTypeRecognition|FullyQualifiedName~DateTimeModule|FullyQualifiedName~RandomModule|FullyQualifiedName~FunctoolsModule|FullyQualifiedName~TimeModuleFunction|FullyQualifiedName~NewTypeOwnership|FullyQualifiedName~RawDescriptor|FullyQualifiedName~MetadataStringOwnership|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~FactorialAllocation|FullyQualifiedName~IntegerAdditionAdmission|FullyQualifiedName~ExactBytesSum)'
dotnet build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental --disable-build-servers > "$lab/ubuntu-core-build.log" 2>&1 || { tail -60 "$lab/ubuntu-core-build.log"; exit 1; }
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$suite-net11.0.log"
done
