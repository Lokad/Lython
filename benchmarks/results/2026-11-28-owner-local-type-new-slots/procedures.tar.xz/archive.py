from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import tarfile


lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-owner-local-type-new-slots'
comparison = lab / 'comparison'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


identity = read(comparison / 'identity.json')
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, image in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (comparison / role).iterdir()} == image
    verification = read(comparison / f'{role}-verify.json')
    assert verification['state'] == 'Completed' and verification['caseCount'] == 4
    assert verification['launched']['library']['sha256'] == image['Lokad.Lython.dll']
    assert verification['catalogSha256'] == identity['catalogs']['representative.json']['sha256']

assert read(lab / 'allocation.json')['verifiedCompilations'] == 42
assert read(lab / 'cold-summary.json')['verifiedInvocations'] == 48
assert read(comparison / 'summary.json')['verifiedTimedBatches'] == 140
assert read(comparison / 'archive-receipt.json')['archiveSHA256'] == digest(comparison / 'observations.tar.xz')
proof = read(lab / 'compile-traces.json')
for role, trace in proof.items():
    assert trace['sha256'] == digest(lab / f'compile-{role}.nettrace')
owners = {row[0] for row in proof['reference']['runtimeInitializers']} - {row[0] for row in proof['candidate']['runtimeInitializers']}
assert {'Lokad.Lython.Runtime.PyDateTimeOps', 'Lokad.Lython.Runtime.LythonRuntime+RandomModule',
        'Lokad.Lython.Runtime.LythonRuntime+PartialFactory', 'Lokad.Lython.Runtime.LythonRuntime+TimeStructTimeType'} <= owners
assert 'Lokad.Lython.Runtime.LythonRuntime' in owners
for log in lab.glob('*net*.log'):
    text = log.read_text(encoding='utf-8-sig')
    assert 'Failed:     0' in text and ('Passed:   611' if 'PublicApi' in log.name else 'Passed:   116') in text
assert len(list(lab.glob('*net*.log'))) == 6

out.mkdir(exist_ok=True)
for name, source in [('identity.json', comparison / 'identity.json'), ('warm-observations.tar.xz', comparison / 'observations.tar.xz'),
    ('warm-summary.json', comparison / 'summary.json'), *[(name, lab / name) for name in ('allocation.json', 'cold-summary.json', 'compile-traces.json')]]:
    copy2(source, out / name)
    assert digest(out / name) == digest(source)

paths = {file.name: file for file in lab.iterdir() if file.is_file() and file.suffix in
         ('.py', '.ps1', '.sh', '.json', '.log', '.patch', '.nettrace', '.stderr')}
for name in ('reference-verify.json', 'candidate-verify.json', 'archive-receipt.json', 'config.json', 'xml.json', 'generated.json'):
    paths[f'comparison/{name}'] = comparison / name
for name in ('ModuleProbe.csproj', 'Program.cs'):
    paths[f'probe/{name}'] = lab / 'probe' / name
for path in (lab / 'first-remote').iterdir():
    if path.is_file():
        paths[f'first-remote/{path.name}'] = path
quiet = comparison / 'quiet'
if (quiet / 'summary.json').exists():
    status = read(quiet / 'terminal-status.json')
    receipt = status['receipt']
    assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['quietBeforeAndAfter']
    assert read(quiet / 'summary.json')['verifiedTimedBatches'] == 112
    assert read(quiet / 'identity.json')['imageFiles'] == identity['imageFiles']
    assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
    for name in ('summary.json', 'identity.json', 'observations.tar.xz', 'terminal-status.json'):
        target = out / f'quiet-{name}'
        copy2(quiet / name, target)
        assert digest(target) == digest(quiet / name)
    for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log', 'reference-remote-verify.json',
                 'candidate-remote-verify.json', 'upload.json', 'collect.py', 'run.sh', 'jobs.json'):
        paths[f'quiet/{name}'] = quiet / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
print('Verified six test suites, five warm comparisons, two fresh comparisons, two traces and archive contents.')
