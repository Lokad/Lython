from hashlib import sha256
import json
from pathlib import Path


pair = Path(__file__).resolve().parent / 'comparison'


def read(name):
    return json.loads((pair / name).read_bytes())


def write(name, value):
    (pair / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n',
                             encoding='utf-8', newline='\n')


source = '''from datetime import date, timedelta
from functools import partial
from random import Random
from time import struct_time
owners = (date, timedelta, partial, Random, struct_time)
total = 0
for step in range(512):
    for owner in owners:
        total += len(owner.__new__.__qualname__)
print(total, date(2024, 1, 2).day, partial(pow, 2)(3))
'''
labels = ('date', 'timedelta', 'partial', 'Random', 'struct_time')
golden = f'{512 * sum(len(label) + len(".__new__") for label in labels)} 2 8\n'
fixture = '{"size":512,"text":null}'
case_id = 'diagnostic.builtin-constructor-descriptors'
catalog = read('representative.json')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] != 'diagnostic.builtin-module-imports']
catalog['cases'].append(dict(id=case_id, family='scripts', category='whole-script', scale='small', size=512,
    source=source, fixtureJson=fixture, expectedOutput=golden, sourceUtf8Bytes=len(source),
    expectedOutputUtf8Bytes=len(golden), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
    sourceSha256=sha256(source.encode()).hexdigest(), fixtureSha256=sha256(fixture.encode()).hexdigest(),
    expectedOutputSha256=sha256(golden.encode()).hexdigest(), expectedFilesSha256=None))
write('representative.json', catalog)
jobs = read('jobs.json')
jobs['warm'] = [[case_id if key == 'diagnostic.builtin-module-imports' else key, lane] for key, lane in jobs['warm']]
write('jobs.json', jobs)
identity = read('identity.json')
for name in ('representative.json', 'jobs.json'):
    identity['catalogs'][name]['sha256'] = sha256((pair / name).read_bytes()).hexdigest()
write('identity.json', identity)
