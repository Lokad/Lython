$lab='.git/agent-notes/review-20261031/owner-type-new-slots-b1990-20261128'
$sdk=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter='Category!=Stress&(FullyQualifiedName~SharedTypeSlotConcurrency|FullyQualifiedName~Constructor|FullyQualifiedName~SharedFixedLabel|FullyQualifiedName~BuiltinDefinitionIsolation|FullyQualifiedName~BuiltinTypeRecognition|FullyQualifiedName~DateTimeModule|FullyQualifiedName~RandomModule|FullyQualifiedName~FunctoolsModule|FullyQualifiedName~TimeModuleFunction|FullyQualifiedName~NewTypeOwnership|FullyQualifiedName~RawDescriptor|FullyQualifiedName~MetadataStringOwnership|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~FactorialAllocation|FullyQualifiedName~IntegerAdditionAdmission|FullyQualifiedName~ExactBytesSum)'
foreach ($tfm in 'net11.0','net10.0') {
  foreach ($suite in 'Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests') {
    $log="$lab/windows-$suite-$tfm.log"
    & $sdk test "tests/$suite/$suite.csproj" -c Release -f $tfm --filter $filter *> $log
    $code=$LASTEXITCODE
    if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 60; exit $code }
    Get-Content $log -Encoding utf8 -Tail 2
  }
}
