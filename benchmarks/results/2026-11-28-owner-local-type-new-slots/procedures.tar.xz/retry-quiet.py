from hashlib import sha256
import gzip
import json
from pathlib import Path
import shlex
from shutil import copy2
from subprocess import check_output


lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
old = lab.parent / 'fixed-row-local-bindings-20261126/comparison/quiet'
base = '/home/lokad/lython-bench-checks'
status = json.loads((old / 'terminal-status.json').read_bytes())
earlier = status['receipt']
assert not status['live'] and str(status['exitCode']) == '0' and not status['fixtures']
assert earlier['complete'] and earlier['allWorkersJoined'] and earlier['guestFixturesRemoved']
assert sha256((old / 'observations.tar.xz').read_bytes()).hexdigest() == earlier['archiveSHA256']
old_name = json.loads((old / 'upload.json').read_bytes())['root']
old_identity = json.loads((old / 'identity.json').read_bytes())
old_core = old_identity['imageFiles']['candidate']['Lokad.Lython.dll']
old_path = f'{base}/{old_name}/candidate/Lokad.Lython.dll'
ssh = ['ssh', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'ConnectTimeout=12', '-o', 'StrictHostKeyChecking=yes',
       'lokad@20.166.121.73']

packed = old / 'migrated-candidate-core.dll.gz'
if not packed.exists():
    content = check_output([*ssh, 'cat -- ' + shlex.quote(old_path)], timeout=35)
    assert sha256(content).hexdigest() == old_core
    with packed.open('xb') as stream:
        stream.write(gzip.compress(content, mtime=0))
assert sha256(gzip.decompress(packed.read_bytes())).hexdigest() == old_core

first = lab / 'first-remote'
terminal = json.loads((quiet / 'terminal-status.json').read_bytes())
receipt = terminal['receipt']
assert not terminal['live'] and str(terminal['exitCode']) == '1' and not terminal['fixtures']
assert not receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved']
assert sha256((quiet / 'observations.tar.xz').read_bytes()).hexdigest() == receipt['archiveSHA256']
first.mkdir(exist_ok=True)
for name in ('terminal-status.json', 'observations.tar.xz', 'archive-receipt.json', 'exit-code.txt', 'stage-custody.json', 'launch.log'):
    copy2(quiet / name, first / name)

name = json.loads((quiet / 'upload.json').read_bytes())['root']
identity = json.loads((quiet / 'identity.json').read_bytes())
config = dict(base=base, root=name, firstUnit='lython-b1990-owner-new-slots', unit='lython-b1990-owner-new-slots-confirm',
    failedArchive=receipt['archiveSHA256'], old=old_name, oldUnit='lython-b1783-fixed-row-local-bindings-20261126',
    oldArchive=earlier['archiveSHA256'], oldCore=old_core, packedSHA256=sha256(packed.read_bytes()).hexdigest(),
    images=identity['imageFiles'], catalogs=identity['catalogs'])
remote = f'cfg={config!r}\n' + r'''
from hashlib import sha256
from pathlib import Path
import fcntl, json, shutil, subprocess

base = Path(cfg['base'])
root = base / cfg['root']
old = base / cfg['old']
core = old / 'candidate/Lokad.Lython.dll'
assert base.resolve() == base and root.resolve() == root and old.resolve() == old and core.resolve() == core
assert root.parent == base and old.parent == base and root != old
def digest(path): return sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(path.is_mount() for path in base.glob('*/guest-fixtures'))
    for unit in ('firstUnit', 'oldUnit'):
        state = subprocess.run(['systemctl','is-active',cfg[unit]+'.service'], capture_output=True, text=True).stdout.strip()
        assert state in ('failed','inactive'), state
    assert (root/'exit-code.txt').read_text().strip() == '1' and (old/'exit-code.txt').read_text().strip() == '0'
    assert digest(root/'observations.tar.xz') == cfg['failedArchive'] and digest(old/'observations.tar.xz') == cfg['oldArchive']
    assert digest(core) == cfg['oldCore'] and core.stat().st_nlink == 1
    for role, files in cfg['images'].items():
        assert {path.name:digest(path) for path in (root/role).iterdir()} == files
        proof = json.loads((root/f'{role}-remote-verify.json').read_bytes())
        assert proof['state'] == 'Completed' and proof['caseCount'] == 4
        assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']
    for name, manifest in cfg['catalogs'].items(): assert digest(root/name) == manifest['sha256']
    record = dict(completedImage=cfg['old'], coreSHA256=cfg['oldCore'], packedSHA256=cfg['packedSHA256'],
                  removedBytes=core.stat().st_size, freeBefore=shutil.disk_usage(base).free)
    packed_report = old/'candidate-core-migration.json'
    with packed_report.open('x', encoding='utf-8') as stream:
        json.dump(record, stream, indent=2)
    core.unlink()
    record['freeAfter'] = shutil.disk_usage(base).free
    assert record['freeAfter'] >= 4*1024*1024, record
    kept = root/'first-attempt'
    kept.mkdir()
    for file in ('confirmation','archive-receipt.json','observations.tar.xz','exit-code.txt'):
        (root/file).rename(kept/file)
    assert digest(kept/'observations.tar.xz') == cfg['failedArchive']
    print(json.dumps(record), flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+cfg['unit'],'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=250','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')], check=True)
'''
compile(remote, '<frozen rerun after a confirmed disk-reserve failure>', 'exec')
result = check_output([*ssh, 'python3 -c ' + shlex.quote(remote)], timeout=50)
(lab / 'remote-retry.json').write_bytes(result)
runner = lab / 'quiet-vm.py'
program = runner.read_text(encoding='utf-8')
assert program.count("unit='lython-b1990-owner-new-slots'") == 1
runner.write_text(program.replace("unit='lython-b1990-owner-new-slots'", "unit='lython-b1990-owner-new-slots-confirm'"),
                  encoding='utf-8', newline='\n')
print(result.decode('utf-8'))
