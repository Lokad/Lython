from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import tarfile


lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
quiet = pair / 'quiet'
previous = lab.parent / 'borrow-fixed-arguments-b1986-20261128'
donor = previous / 'comparison/quiet'
root = 'script-owner-new-slots-b1990-20261128'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


identity = read(pair / 'identity.json')
donor_image = read(donor / 'identity.json')['imageFiles']['candidate']
receipt = read(donor / 'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(donor / 'observations.tar.xz')
assert receipt['complete'] and receipt['allWorkersJoined']
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
    assert {name for name in files if donor_image[name] != files[name]} == ({'Lokad.Lython.dll'} if role == 'candidate' else set())
    proof = read(pair / f'{role}-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']

quiet.mkdir()
identity.update(donorArchiveSHA256=receipt['archiveSHA256'], frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate')
identity['catalogs'] = {name: identity['catalogs'][name] for name in ('representative.json', 'jobs.json')}
for name in ('representative.json', 'cpython-worker.py'):
    copy2(pair / name, quiet / name)
for name in ('collect.py', 'run.sh'):
    copy2(donor / name, quiet / name)
assert b'\r' not in (quiet / 'run.sh').read_bytes()
jobs = [job for job in read(pair / 'jobs.json')['warm'] if job[0] != 'compiler.generated-read-only-branches']
assert len(jobs) == 4
save(quiet / 'jobs.json', list(reversed(jobs)))
identity['catalogs']['jobs.json']['sha256'] = digest(quiet / 'jobs.json')
save(quiet / 'identity.json', identity)
files = {name: quiet / name for name in ('identity.json', 'representative.json', 'cpython-worker.py', 'collect.py', 'run.sh', 'jobs.json')}
files['candidate/Lokad.Lython.dll'] = pair / 'candidate/Lokad.Lython.dll'
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
save(quiet / 'upload.json', dict(root=root, donor=read(donor / 'upload.json')['root'],
     donorArchive=identity['donorArchiveSHA256'], donorFiles=donor_image,
     minimumAfterStageBytes=800_000, expandedBytes=sum(path.stat().st_size for path in files.values()),
     caseCount=4, payloadSHA256=digest(payload),
     files={name: dict(sha256=digest(path), length=path.stat().st_size) for name, path in files.items()}))

script = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
(lab / 'quiet-vm.py').write_text(script.replace('lython-b1986-borrow-fixed', 'lython-b1990-owner-new-slots'),
                                  encoding='utf-8', newline='\n')
copy2(previous / 'summarize-quiet.py', lab / 'summarize-quiet.py')
print('Verified both immutable worker images and prepared four quiet warm lanes.')
