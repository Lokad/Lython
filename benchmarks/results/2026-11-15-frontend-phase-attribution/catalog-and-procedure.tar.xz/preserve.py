from pathlib import Path
import json,shutil,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'profile';out=repo/'benchmarks/results/2026-11-15-frontend-phase-attribution';out.mkdir()
for src,name in [(r/'attribution.json','attribution.json'),(q/'identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(src,out/name)
with tarfile.open(out/'catalog-and-procedure.tar.xz','w:xz')as t:
 for p in r.iterdir():
  if p.is_file():t.add(p,arcname=p.name)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='profile/'+p.name)
(out/'README.md').write_text('''# Public compilation phase attribution

R412/B804,2026-11-15. Unchanged qualified1b82cd46/frozen0edc0c1c. One existing
1,877B six-helper manifest plus an explicit generated23,531B/96-field configuration
normalizer. The latter is a compilation diagnostic, not a replacement representative
workload or proof that agents routinely generate its shape. Independent Python
normalization/output checks and worker full goldens pass before/after sampling.

| Nearest phase owning sampled CPU | Manifest /1,136samples | Validator /1,167samples |
| --- | --- | --- |
| Static/annotation analysis |408|256|
| Parse/tokenization |261|390|
| Executable preparation |235|315|
| Scope/syntax facts |153|137|
| Lowering |54|59|
| Other/CLR/protocol |25|10|

Leaf symbol unknown201/369, ambiguous0. Owning frames include useful, inlined and
native work; these are not exclusive CPU or removable shares. Executable stack
layout owns20/40samples and reachable-block collection is visible in the generated
case. This does not isolate full exception scans as a dominant stage; a temporary
region index is not selected merely because the loops look quadratic. Smaller
manifest has substantial shared traversal/fact-query costs too. Do not conflate
the local short cold-tier screen with quiet timing: all local observations and
the original missing-global fixture failure remain in the procedure archive.

The source gate finds a concrete independent redundancy: member/subscript/slice
receivers and indexes are lowered, discarded and lowered again during executable
store generation. Store targets also use a syntax-keyed expression dictionary,
and header execution reconstructs nested target wrappers/layouts. Syntax nodes
even construct lowered targets before lexical preparation. Select one coherent
prepared-store migration replacing those paths, rather than another region index
or general AST traversal framework. Keep augmented target semantics, actual target
order, scopes/lambdas, Python errors, async setters, refusal and joined cleanup.
No speedup is predicted by this profile; the implementation needs its own bounded
complete compilation/fresh/runtime comparison and semantic qualification.

Quiet F4as_v7/Ubuntu24.04.4/four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 ordinary
GC/tiering, explicit PerfMap diagnostic override. Two5s cpu-clock/fp199Hz captures
after≥8guest seconds compile warmup; fixed batches4096/512 can extend windows.
Actual compile clocks5.719/5.870s for28,672/2,048invocations are diagnostic, not
paired timing or a CPython comparison. Samples cover all active worker CPU threads;
full other-thread CPU/stacks remain. Clocks include public compilation/compiled-owner
cleanup, while profiling also sees protocol/GC/other worker work. No execution,
startup, heap/RSS, pending-I/O or embedding-tail comparison is established.

All quiet/golden/budget/Closed/join/archive gates pass. RAM traces/maps are archived
and byte-verified under the lease before unmount; no workers/fixtures remain.
Complete measured images are checked at staging and before each worker. No new
retirement or floor change. Terminal B804 is cached forever. No production edits,
repeated full runtime qualification or publication.

[Exact attribution](attribution.json),[identity](identity.json),[raw](observations.tgz),
[catalog/procedure/original local failure](catalog-and-procedure.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

[R412 public compilation attribution](results/2026-11-15-frontend-phase-attribution/README.md)
at unchanged1b82/0ed profiles existing manifest/generated96-field normalizer.
Static analysis/parsing/executable prep are mixed; region scans are not isolated
as a dominant stage, no index selected. Source finds duplicate target lowering,
syntax-keyed read tables and runtime target reconstruction. Select prepared-store
migration R413, not a traversal framework. B804all gates pass; RAM traces archived/
verified before unmount, all users joined. No CPU speedup or production change.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('**R412 active, bounded frontend gate:**');b=s.index('**Next gate:',a)
s=s[:a]+'''**R412 complete:** [compilation attribution](benchmarks/results/2026-11-15-frontend-phase-attribution/README.md), cached B804success/all users cleaned. Manifest1,136samples and generated validator1,167 show mixed parse/static/executable costs. Region scans are not isolated as dominant; no region index or new traversal framework selected. Original local fixture failure and all unknown/other-thread evidence preserved.

**R413 selected: prepare store targets once.** Ordinary member/subscript/slice
receivers/indexes are already lowered then discarded and lowered again in executable
construction. Header stores retain syntax-keyed read tables and rebuild nested
target wrappers/layouts per operation; syntax constructors prematurely perform
lowering. Replace these with a direct immutable prepared store tree used by compiler
and sync/async lowered execution. Prepare loop/with targets during lowering, remove
their eager syntax fields, expression dictionaries/structural hashing, redundant
compiler LowerExpression calls and obsolete header-target dispatch. Preserve real
raw-expression helpers; do not expand into a general compiler rewrite. Existing
augmented read-modify-write targets remain unless sharing them simplifies this
migration. Preserve RHS-before-target/left-to-right stores, partial effects, nested
starred targets, lambdas/class cells, annotations, genuine setter suspension, first
refusal and joined funded cleanup. Focused Release semantic/cancellation/ownership
checks both frameworks, then one bounded compilation/fresh comparison on existing
manifest and generated validator plus a runtime control; no predicted speedup.
Decide remaining regression debt explicitly and remove displaced machinery before
retention. Full delivery qualification only at the coherent retained boundary.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n');print('Preserved bounded phase attribution; selected complete prepared-store replacement in PLAN before code.')
