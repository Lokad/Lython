from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'text-loop-r407';q=r/'profile';q.mkdir();remote='/home/lokad/lython-bench-checks/frontend-regions-b804-20261115';unit='lython-b804-frontend-regions-20261115'
reference=json.loads((r.parent/'cased-preparation-r408/checkpoint/identity.json').read_text(encoding='utf-8'));identity=dict(sourceRevision='Unchanged qualified1b82cd46/frozen0edc0c1c; frontend attribution only',purpose='A4 bounded public compilation attribution, existing manifest versus explicit generated96-field normalizer; diagnose repeated exception-topology discovery, not a timing comparison.',coreSHA256=dict(candidate=reference['coreSHA256']['candidate']),auxiliaryFiles=reference['auxiliaryFiles'],catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'catalog.json').write_bytes((r/'catalog.json').read_bytes())
s=(old/'ops-profile.py').read_text(encoding='utf-8').replace('text-loop-b793-20261115','frontend-regions-b804-20261115')
s=s.replace("[('text','scripts.text-summary-helpers.nonlocal-counter.large','warm')]","[('manifest','scripts.config-manifest.small','compile'),('validator','scripts.config-generated-guards.medium','compile')]")
s='\n'.join(line for line in s.splitlines()if 'env["DOTNET_JitDisasm"]='not in line and 'env["DOTNET_JitStdOutFile"]='not in line)+'\n'
s=s.replace('["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]','["DOTNET_PerfMapEnabled"]')
s=s.replace('count = 512 # Existing complete script; bounded warmed CPU attribution, not a timing comparison.','count = 4096 if name == "manifest" else 512 # Same public compile boundary; enough warmup without oversized batches.')
s=s.replace("row['seconds'] > .25 and row['name'].startswith('Lython executio')","row['seconds'] > .25").replace("record['guestTids']","record['activeCpuTids']").replace("record['guestTid']","record['activeCpuTid']")
needle='        process = subprocess.Popen('
insert='''        expected_image = json.loads((candidate / 'identity.json').read_text())
        for filename, expected_hash in dict(expected_image['auxiliaryFiles'], **{'Lokad.Lython.dll': expected_image['coreSHA256']['candidate']}).items():
            assert hashlib.sha256((candidate/'candidate'/filename).read_bytes()).hexdigest() == expected_hash, filename
'''
assert needle in s;s=s.replace(needle,insert+needle,1);ast.parse(s);(q/'ops-profile.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('text-loop-b793-20261115','frontend-regions-b804-20261115').replace('lython-b793-text-loop-20261115',unit).replace('B793','B804').replace("['text']","['manifest','validator']").replace('Committed43bce13a/frozen9e890d18; R407 current text-loop interior attribution','Unchanged qualified1b82/frozen0ed; R412 public compilation attribution')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']:t.add(q/n,arcname=n)
config=dict(root=remote,source='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115',unit=unit,identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),sourceCatalogSHA256=hashlib.sha256((r.parent/'cased-preparation-r408/checkpoint/retrieved/representative.json').read_bytes()).hexdigest(),retire=[])
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');tree=ast.parse(code);assignment=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='config'for t in n.targets));lines=code.splitlines();lines[assignment.lineno-1:assignment.end_lineno]=['config='+repr(config)];code='\n'.join(lines)+'\n'
code=code.replace("config['identity']['catalogSHA256']","config['sourceCatalogSHA256']").replace(" os.link(source/'representative.json',root/'catalog.json')\n",'').replace('lython-b793-fixtures','lython-b804-fixtures')
ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
