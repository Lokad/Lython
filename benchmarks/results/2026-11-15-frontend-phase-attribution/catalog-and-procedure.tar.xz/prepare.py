from pathlib import Path
import base64,contextlib,hashlib,io,json
repo=Path.cwd();r=Path(__file__).parent;old=repo/'.git/agent-notes/review-20261031/arithmetic-r405/checkpoint/checkpoint-catalog.json';base=json.loads(old.read_text(encoding='utf-8'));template=next(c for c in base['cases']if c['id']=='scripts.config-manifest.small');cases=[template]
# A generated configuration normalizer is a compilation diagnostic. Keep its
# source shape/size explicit; it does not replace the representative catalog.
count=96;lines=['import json','def normalize(data):','    result = {}','    errors = []']
data={};expected={};errors=[]
for i in range(count):
 name='field_'+str(i);data[name]='bad'if i%19==0 else str(i-7)
 lines.extend(['    try:',f'        value = int(data.get({name!r}, 0))','    except (TypeError, ValueError):','        value = 0',f'        errors.append({name!r})','    if value < 0:',f'        errors.append({name!r})','        value = 0',f'    result[{name!r}] = value'])
 try:value=int(data[name])
 except ValueError:value=0;errors.append(name)
 if value<0:errors.append(name);value=0
 expected[name]=value
lines.append('    return result, errors')
namespace={};exec('\n'.join(lines),namespace);normalized,observedErrors=namespace['normalize'](data)
assert normalized==expected and observedErrors==errors
lines.extend(["with open('config.json') as source:",'    normalized, errors = normalize(json.load(source))',"print(len(normalized), sum(normalized.values()), len(errors))"])
source='\n'.join(lines)+'\n';golden=f'{count} {sum(expected.values())} {len(errors)}\n'
c=dict(template);c.update(id='scripts.config-generated-guards.medium',family='scripts',category='compile-diagnostic',scale='96-fields',size=count,source=source,fixtureJson=json.dumps(dict(size=count,text=None,inputFiles={'config.json':base64.b64encode(json.dumps(data).encode()).decode()},outputFiles={}),separators=(',',':')),expectedOutput=golden,expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest())
for n,k in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:c[n]=hashlib.sha256(c[k].encode()).hexdigest()
c['sourceUtf8Bytes']=len(source.encode());c['expectedOutputUtf8Bytes']=len(golden.encode());c['fixtureTextUtf8Bytes']=len(json.dumps(data).encode());c['fixtureTextCodePoints']=len(json.dumps(data));cases.append(c);base['cases']=cases
(r/'catalog.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print([(c['id'],len(c['source'].encode()))for c in cases])
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');needle='**Next gate: select a whole construction, transport or conversion path to remove.**';s=s.replace(needle,'''**R412 active, bounded frontend gate:** current stack-layout preparation scans all
exception regions per block, and native eligibility scans regions per instruction.
Use one generated96-field configuration normalizer plus the existing six-helper
manifest control to determine whether that repeated topology discovery is material.
This is explicitly a compilation diagnostic, not a replacement representative
benchmark. One bounded phase attribution; select one temporary compile-time region
index replacing the repeated scans if justified, otherwise record the measured
dominant stage and close this hypothesis. Preserve handler/finally/loop diagnostics,
actual function eligibility, current tokens/refusal and conservative admission.
No runtime cache, new allowance, policy switch or duplicate analysis framework.

'''+needle);p.write_text(s,encoding='utf-8',newline='\n')
