from pathlib import Path
import hashlib,importlib.util,io,json,os,platform,statistics,struct,subprocess,tempfile,time
repo=Path.cwd();r=Path(__file__).parent;catalog=r/'catalog.json';cases=json.loads(catalog.read_text(encoding='utf-8'))['cases'];image=repo/'.git/agent-notes/review-20261031/caller-workspace-r411/frozen/reference';identity=json.loads((image.parent/'identity.json').read_text(encoding='utf-8'))['images']['reference']
for n,h in identity.items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h,n
sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk
def packet(d):
 b=json.dumps(d).encode();return struct.pack('>I',len(b))+b
def read(stream):
 h=stream.read(4)
 if not h:return None
 n=struct.unpack('>I',h)[0];return json.loads(stream.read(n))
rows=[]
for case in cases:
 requests=[]
 for i,(op,count)in enumerate([('verify',2),('batch',128)]+[('batch',64)]*3):requests.append(dict(protocolVersion=2,requestId=i+1,operation=op,caseId=case['id'],lane='compile',iterations=count,**{k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}))
 requests.append(dict(protocolVersion=2,requestId=len(requests)+1,operation='quit'))
 with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as fixture:
  p=subprocess.run([sdk+'/dotnet.exe',str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','worker','--catalog',str(catalog)],input=b''.join(packet(d)for d in requests),capture_output=True,cwd=fixture,env=env,timeout=60)
 (r/(case['id']+'-worker.bin')).write_bytes(p.stdout)
 (r/(case['id']+'-worker.stderr')).write_bytes(p.stderr)
 if p.returncode:
  s=io.BytesIO(p.stdout);print('ready',read(s));print('first response',read(s),flush=True)
 assert p.returncode==0,p.stderr.decode('utf-8','replace');assert not p.stderr,p.stderr
 stream=io.BytesIO(p.stdout);ready=read(stream);assert ready['status']=='Ready';responses=[]
 for request in requests:
  d=read(stream);assert d['requestId']==request['requestId'],d
  expected='Closed'if request['operation']=='quit'else'Equivalent'if request['operation']=='verify'else'Completed';assert d['status']==expected,d
  responses.append(d)
 assert not stream.read()
 med=[d['elapsedTicks']/d['clockFrequency']/d['completedInvocations']*1000 for d in responses[2:-1]]
 source=case['source'];py=[]
 for _ in range(128):compile(source,'<diagnostic>','exec')
 for _ in range(3):
  begin=time.perf_counter()
  for _ in range(64):compile(source,'<diagnostic>','exec')
  py.append((time.perf_counter()-begin)*1000/64)
 rows.append(dict(case=case['id'],sourceBytes=len(source.encode()),lythonCompileMilliseconds=med,localCPythonCompileMilliseconds=py,ready=ready,responses=responses))
 print(case['id'],'Lython',statistics.median(med),'ms; local CPython',statistics.median(py),'ms',flush=True)
(r/'local-screen.json').write_text(json.dumps(dict(kind='Local phase diagnostic only, not quiet-VM or representative external qualification',localCPython=platform.python_version(),coreSHA256=identity['Lokad.Lython.dll'],allWorkersJoinedAndFixturesRemoved=True,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
