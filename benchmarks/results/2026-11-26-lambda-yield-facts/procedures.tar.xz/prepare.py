from pathlib import Path
from difflib import unified_diff
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/'candidate-source'
snapshot=lab/'source.zip'
revision='7045bcb35fe60369441704e047969feb99bffbf3'
subprocess.run(['git','archive','--format=zip','--output',snapshot,revision,'--','src','tests',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts','tools/LythonProbe',
    'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props',
    'global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in archive.namelist())
    archive.extractall(source)
changes=[]
def edit(name,replacements):
    relative='src/Lokad.Lython/Frontend/'+name
    path=source/relative
    old=path.read_text(encoding='utf-8')
    new=old
    for before,after in replacements:
        assert new.count(before)==1,(relative,before)
        new=new.replace(before,after)
    path.write_text(new,encoding='utf-8',newline='\n')
    changes.extend(unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),'a/'+relative,'b/'+relative))

edit('ScopeDirectiveFacts.cs',[
    ('''    private static ScopeDirectiveFacts CollectLambdaBindings(FunctionParameterLayout parameters, ExpressionSyntax body,
        CancellationToken cancellationToken)
    {
        var bindings = new List<string>(parameters.LayoutParameterNames);
        CollectExpressionBindings(body, bindings);
        return CompactLocalBindings(bindings, EmptyNames, EmptyNames, null, 0, cancellationToken);
    }

''',''),
    ('''        => lambda.PreparedScopeFacts = CollectLambdaBindings(parameters, lambda.Body, cancellationToken);''',
'''    {
        var bindings = new List<string>(parameters.LayoutParameterNames);
        lambda.IsGenerator = CollectExpressionBindings(lambda.Body, bindings, static (names, name) => names.Add(name));
        return lambda.PreparedScopeFacts = CompactLocalBindings(bindings, EmptyNames, EmptyNames, null, 0, cancellationToken);
    }'''),
    ('''    internal static void CollectExpressionBindings<TState>(ExpressionSyntax expression, TState state, Action<TState, string> add)
    {
        if (expression is LambdaExpressionSyntax lambda)
        {
            foreach (var parameter in lambda.Parameters)
                if (parameter.DefaultValue is not null) CollectExpressionBindings(parameter.DefaultValue, state, add);
            return;
        }

        if (expression is AssignmentExpressionSyntax assignment)
        {
            add(state, assignment.Name);
        }

        foreach (var child in ExpressionSyntaxTraversal.EnumerateChildren(expression))
        {
            CollectExpressionBindings(child, state, add);
        }
    }''',
'''    internal static bool CollectExpressionBindings<TState>(ExpressionSyntax expression, TState state, Action<TState, string> add)
    {
        var hasYield = expression is YieldExpressionSyntax;
        if (expression is LambdaExpressionSyntax lambda)
        {
            // Defaults still execute here. Nested lambda bodies own their facts.
            foreach (var parameter in lambda.Parameters)
                if (parameter.DefaultValue is { } value) hasYield |= CollectExpressionBindings(value, state, add);
            return hasYield;
        }

        if (expression is AssignmentExpressionSyntax assignment) add(state, assignment.Name);
        foreach (var child in ExpressionSyntaxTraversal.EnumerateChildren(expression))
            hasYield |= CollectExpressionBindings(child, state, add);
        return hasYield;
    }'''),
])
edit('Syntax.cs',[
    ('''    internal LoweredLambdaExpression? PreparedCallable { get; set; }''',
'''    internal bool IsGenerator { get; set; }
    internal LoweredLambdaExpression? PreparedCallable { get; set; }'''),
])
edit('ExecutableScript.Builder.cs',[
    ('''        // Lazy annotation expressions are outside the statement yield walk.
        var generator = GeneratorSyntaxFacts.ContainsYield(lambda.Body);
        var code = new Builder(compilation, lambda.ParameterLayout, null, ScopeDirectiveFactsCollector.ForLambda(lambda), generator: generator)''',
'''        var code = new Builder(compilation, lambda.ParameterLayout, null, ScopeDirectiveFactsCollector.ForLambda(lambda),
                generator: lambda.IsGenerator)'''),
    ('return CompleteLambdaDefinition(lambda, code, generator, ExecutableDefinitionKind.NamespaceLambda, literalPositionalDefaults);',
     'return CompleteLambdaDefinition(lambda, code, ExecutableDefinitionKind.NamespaceLambda, literalPositionalDefaults);'),
    ('ExecutableCodeObject code, bool generator, ExecutableDefinitionKind kind, PyTuple? literalPositionalDefaults)',
     'ExecutableCodeObject code, ExecutableDefinitionKind kind, PyTuple? literalPositionalDefaults)'),
    ('lambda.ParameterLayout, 0, generator, 0,','lambda.ParameterLayout, 0, lambda.IsGenerator, 0,'),
])
edit('ExecutableScript.SuspendingDefinitions.cs',[
    ('''                    var generator = GeneratorSyntaxFacts.ContainsYield(lambda.Body);
                    var code = CompileFunctionCode("<lambda>", lambda.ParameterLayout,
                        [], ScopeDirectiveFactsCollector.ForLambda(lambda), generator: generator,''',
'''                    var code = CompileFunctionCode("<lambda>", lambda.ParameterLayout,
                        [], ScopeDirectiveFactsCollector.ForLambda(lambda), generator: lambda.IsGenerator,'''),
    ('CompleteLambdaDefinition(lambda, code, generator, ExecutableDefinitionKind.Lambda, literals)',
     'CompleteLambdaDefinition(lambda, code, ExecutableDefinitionKind.Lambda, literals)'),
])
(lab/'candidate.patch').write_text(''.join(changes),encoding='utf-8',newline='\n')
