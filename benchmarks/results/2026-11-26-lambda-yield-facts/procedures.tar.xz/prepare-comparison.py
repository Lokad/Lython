from pathlib import Path
from statistics import median
import ast,hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
baseline=lab.with_name('direct-signed-argument-20261126')
frontend=lab.with_name('shared-name-binding-roots-20261126')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
known=read(baseline/'comparison/quiet/identity.json')['imageFiles']['candidate']
reference=baseline/'local/candidate'
assert len(known)==32 and {p.name:digest(p) for p in reference.iterdir()}==known
candidate=lab/'candidate-source/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
local=lab/'local'
local.mkdir()
ordinary='diagnostic.generated-ordinary-definitions'
rules='diagnostic.generated-record-rules-bindings'
sparse='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
manifest='scripts.file-manifest.small'
template=read(frontend/'representative.json')
available={case['id']:case for case in template['cases']}
available.update({case['id']:case for case in read(baseline/'local/representative.json')['cases']})
cases=[available[case] for case in (ordinary,rules,sparse,manifest)]
template['cases']=cases
catalog=local/'representative.json'
save(catalog,template)
inventory=[dict(case=case['id'],lambdaBodies=sum(isinstance(node,ast.Lambda) for node in ast.walk(ast.parse(case['source'])))) for case in cases]
save(lab/'lambda-inventory.json',inventory)
jobs=[[manifest,'compile'],[ordinary,'compile'],[rules,'compile'],[ordinary,'compile-run'],[sparse,'compile']]
save(local/'jobs.json',{'warm':jobs})
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
shutil.copyfile(worker,local/'cpython-worker.py')
compiler=lab.with_name('shared-literal-decoding-20261124')/'refinement/compiler-owner'
images={}
measurement={}
for role in ('reference','candidate'):
    image=local/role
    shutil.copytree(reference,image)
    if role=='candidate': shutil.copyfile(candidate,image/candidate.name)
    files={p.name:digest(p) for p in image.iterdir()}
    assert len(files)==32 and {name for name in files if files[name]!=known[name]}==({candidate.name} if role=='candidate' else set())
    images[role]=files
    proof=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],cwd=repo,env=env,check=True,timeout=70)
    report=read(proof)
    assert report['state']=='Completed' and report['caseCount']==4
    assert report['catalogSha256']==digest(catalog) and report['launched']['library']['sha256'].lower()==files[candidate.name]
    run=lab/(role+'-compiler-owner')
    run.mkdir()
    for file in compiler.glob('Inspect*'): shutil.copyfile(file,run/file.name)
    shutil.copyfile(image/candidate.name,run/candidate.name)
    result=lab/(role+'-compiler-allocation.json')
    subprocess.run([dotnet,run/'Inspect.dll',catalog,result],cwd=repo,env=env,check=True,timeout=60)
    data=read(result)
    assert data['coreSHA256']==files[candidate.name]
    measurement[role]=data['rows']
save(local/'identity.json',dict(sourceRevision='7045bcb35fe60369441704e047969feb99bffbf3',sourcePatchSHA256=digest(lab/'candidate.patch'),
     imageFiles=images,coreSHA256={role+extra:image[candidate.name] for role,image in images.items() for extra in ('','-control')},
     cpythonWorkerSHA256=digest(worker),catalogs={name:dict(sha256=digest(local/name)) for name in ('representative.json','jobs.json')},
     purpose='Compare reusing lambda generator facts from the existing lexical-binding walk.'))
summary=[]
for before,after in zip(measurement['reference'],measurement['candidate'],strict=True):
    assert before['id']==after['id']
    summary.append(dict(case=before['id'],allocatedBytes=[median(row['allocatedBytes']) for row in (before,after)],
                        retainedAdmission=[row['retainedAdmission'] for row in (before,after)]))
save(lab/'allocation-summary.json',summary)
print(json.dumps(dict(inventory=inventory,memory=summary)))
collector=(frontend/'local/collect.py').read_text(encoding='utf-8').replace('lython-name-binding-fixture-','lython-lambda-yield-fixture-')
compile(collector,'collect.py','exec')
(local/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(frontend/'local/run.sh',local/'run.sh')
runner=(frontend/'run-local.sh').read_text(encoding='utf-8').replace(frontend.name,lab.name)
(lab/'run-local.sh').write_text(runner,encoding='utf-8',newline='\n')
assert all(b'\r' not in p.read_bytes() for p in (local/'run.sh',lab/'run-local.sh'))
shutil.copyfile(frontend/'summarize.py',lab/'summarize.py')
