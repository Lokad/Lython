from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
prior=lab.with_name('post-row-cpython-20261126')
older=prior/'comparison/quiet'
donor=lab.with_name('json-ascii-character-20261126')
source=donor/'comparison/repeat'
image=donor/'local/candidate'

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,text): path.write_text(text,encoding='utf-8',newline='\n')
def save(path,value): write(path,json.dumps(value,indent=2)+'\n')

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='d370fef841a12d53087ab0fc3bf41da7a86d9084'
assert not subprocess.check_output(['git','status','--porcelain','--','src'],cwd=repo)
baseline=read(source/'identity.json')
patch=subprocess.check_output(['git','diff','--binary',baseline['sourceRevision'],head,'--','src'],cwd=repo)
assert hashlib.sha256(patch).hexdigest()==baseline['sourcePatchSHA256']==sha(donor/'candidate.patch')
settled=read(source/'terminal-status.json')
receipt=settled['receipt']
assert settled['exitCode']=='0' and not settled['live'] and not settled['fixtures']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
                                'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(source/'observations.tar.xz')
files=baseline['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
old=read(older/'identity.json')
remote_root='post-ascii-cpython-b1791-20261126'
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(older/name,quiet/name)
assert sha(quiet/'representative.json')==old['catalogs']['representative.json']['sha256']
assert sha(quiet/'cpython-worker.py')==sha(repo/'benchmarks/cpython-worker.py')==baseline['cpythonWorkerSHA256']
assert old['expectedCPythonSHA256']==baseline['expectedCPythonSHA256']
old_jobs=read(older/'jobs.json')
jobs=list(old_jobs)
jobs.insert(6,['scripts.rule-default-closures','warm-async'])
jobs.insert(9,['diagnostic.json-service-quantity-totals','warm-async'])
assert len(jobs)==12 and [row for row in jobs if row in old_jobs]==old_jobs
assert len({tuple(row) for row in jobs})==12
save(quiet/'jobs.json',jobs)
identity=dict(sourceRevision=head,productionSource=head,candidate=head,
    frozenImage=f'/home/lokad/lython-bench-checks/{remote_root}/candidate',
    auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
    imageFiles={'candidate':files},coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    donorArchiveSHA256=receipt['archiveSHA256'],sourcePatchSHA256=baseline['sourcePatchSHA256'],
    cpythonWorkerSHA256=baseline['cpythonWorkerSHA256'],expectedCPythonSHA256=baseline['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    priorExternalSource=old['sourceRevision'],
    purpose='Refresh CPython comparison for callable definitions and JSON after the admitted ASCII reuse checkpoint.')
save(quiet/'identity.json',identity)

def edit(script,replacements):
    for previous,current in replacements:
        assert script.count(previous)==1,previous
        script=script.replace(previous,current)
    return script

collect=edit((older/'collect.py').read_text(encoding='utf-8'),[
    ('len(jobs) == 10','len(jobs) == 12'),
    ("assert time.monotonic()-started<400,'Leave time for cleanup and archival'",
     "assert time.monotonic()-started<495,'Leave time for cleanup and archival'\n"
     "        assert shutil.disk_usage(root).free>=3*1024*1024,'Reserve space for saved observations and archival'"),
    ('lython-b1784-fixtures','lython-b1791-fixtures'),
])
compile(collect,'collect.py','exec')
write(quiet/'collect.py',collect)
assert b'\r' not in (quiet/'run.sh').read_bytes()
summary=edit((older/'summarize.py').read_text(encoding='utf-8'),[
    ('len(raw["jobs"])==10','len(raw["jobs"])==12'),
    ('receipt["warmJobs"]==10','receipt["warmJobs"]==12'),
])
compile(summary,'summarize.py','exec')
write(quiet/'summarize.py',summary)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
verify=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',verify],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=85)
proof=read(verify)
assert proof['state']=='Completed' and proof['caseCount']==5
assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']

payload=quiet/'stage.tar.gz'
names=('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in names:package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=remote_root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
     expandedBytes=sum((quiet/name).stat().st_size for name in names),minimumAfterStageBytes=15500000))
launch=edit((prior/'quiet.py').read_text(encoding='utf-8'),[
    ('lython-b1784-post-fixed-row-cpython-20261126','lython-b1791-post-ascii-cpython-20261126'),
    ("donor=base/'fixed-row-local-bindings-b1783-20261126'", "donor=base/'json-ascii-character-b1790-20261126-repeat'"),
    ("origin=donor/'candidate'\n assert origin.resolve()==origin",
     "origin=(donor/'candidate').resolve(strict=True)\n"
     " assert origin==base/'json-ascii-character-b1790-20261126'/'candidate'"),
    ("assert bytes>cfg['payloadBytes']+5*1024*1024,bytes",
     "assert bytes>=cfg['payloadBytes']+cfg['expandedBytes']+cfg['minimumAfterStageBytes'],bytes"),
    ("assert shutil.disk_usage(base).free>=expanded+4*1024*1024",
     "assert expanded==cfg['expandedBytes']\n  assert shutil.disk_usage(base).free>=expanded+cfg['minimumAfterStageBytes']"),
    ('RuntimeMaxSec=470','RuntimeMaxSec=555'),
    ('seconds=405','seconds=466'),
])
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
print(read(quiet/'upload.json'))
