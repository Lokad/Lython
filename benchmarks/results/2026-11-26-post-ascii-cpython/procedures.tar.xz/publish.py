from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
previous=lab.with_name('post-row-cpython-20261126')/'comparison/quiet'
root=repo/'benchmarks/results/2026-11-26-post-ascii-cpython'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
status=read(quiet/'terminal-status.json')
assert status['exitCode']=='0' and not status['live'] and not status['fixtures']
receipt=status['receipt']
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz') and receipt['warmJobs']==12
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved',
                                'archivedAndVerifiedUnderLease'))
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
old=read(previous/'identity.json')
assert identity['sourceRevision']==summary['source'] and summary['timedBatches']==336
assert identity['priorExternalSource']==old['sourceRevision']
assert identity['expectedCPythonSHA256']==old['expectedCPythonSHA256']
assert identity['cpythonWorkerSHA256']==old['cpythonWorkerSHA256']
assert identity['catalogs']['representative.json']==old['catalogs']['representative.json']
for name in ('representative.json','cpython-worker.py'):
    assert sha(quiet/name)==sha(previous/name)
for name in ('candidate-verify.json','remote-verify.json'):
    proof=read(quiet/name)
    assert proof['state']=='Completed' and proof['caseCount']==5
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==identity['coreSHA256']['candidate']
root.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(quiet/name,root/name)
with tarfile.open(root/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare.py','prepare.log','quiet.py','preserve-core.py','publish.py','launch-console.log','retrieve.log'):
        archive.add(lab/name,arcname=name)
    for name in ('candidate-verify.json','remote-verify.json','upload.json','launch.log','summarize.py',
                 'duplicate-core-preview.json','duplicate-core-reclaim.json','observe-not-before'):
        archive.add(quiet/name,arcname='quiet/'+name)

names={
    'diagnostic.shipment-routing-callbacks':('Shipment callback report','2,048 records / 27,350 B'),
    'diagnostic.generated-ordinary-definitions':('Generated ordinary definitions','96 definitions, built 16 times'),
    'scripts.rule-default-closures':('Generated rules with defaults','2,048 rule groups'),
    'diagnostic.json-service-quantity-totals':('JSON service quantity totals','2,048 records / 78,755 B'),
    'diagnostic.text-summary.nonlocal-computed-width.large':('Short Unicode word-count report with a nonlocal helper','3,072 lines / 35,840 B'),
}
phases={'warm':'Warm sync','warm-async':'Warm `RunAsync`','compile':'Compilation only','compile-run':'Compile-to-result'}
by_key={(row['case'],row['lane']):row for row in summary['rows']}
warm=[(name,phase) for name in names for phase in ('warm','warm-async') if (name,phase) in by_key]
startup=[(name,phase) for phase in ('compile','compile-run') for name in names if (name,phase) in by_key]
assert len(warm)==9 and len(startup)==3

def interval(values,digits,suffix):
    return '–'.join(f'{value:.{digits}f}' for value in values)+suffix

def cells(row):
    return ' | '.join((interval(row['lythonMs'],5,' ms'),interval(row['cpythonMs'],5,' ms'),interval(row['ratio'],3,'×')))

def qualification(row):
    low,high=row['ratio']
    values=['Inconclusive around parity.' if low <= 1 <= high else 'Diagnostic.']
    for key,engine in [('lythonControlPercent','Lython'),('cpythonControlPercent','CPython')]:
        if row[key]>5:values.append(f'{engine} worker spread is {row[key]:.2f}%.')
    return ' '.join(values)

artifact_rows=[]
warm_rows=[]
compile_rows=[]
for key in warm+startup:
    case,lane=key
    row=by_key[key]
    name,size=names[case]
    if lane=='compile':
        size=f"{row['sourceUtf8Bytes']:,} B of source"
    artifact_rows.append(f'| {name} | {size} | {phases[lane]} | {cells(row)} | {qualification(row)} |')
    if lane.startswith('warm'):
        if lane=='warm-async':name+=', Lython `RunAsync`'
        warm_rows.append(f'| {name} | {size} | {cells(row)} | {qualification(row)} [B1791]. |')
    else:
        if lane=='compile':name+=', '+size
        compile_rows.append(f'| {name} | {phases[lane]} | {cells(row)} | {qualification(row)} [B1791]. |')

root_readme=[
    '# B1791 Representative checkpoint against CPython','',
    'Lython `d370fef84` and stock CPython 3.13.16 ran on the quiet Azure F4as_v7',
    'with Ubuntu 24.04.4 and .NET 11 RC3 on November 26, 2026 UTC. Each phase',
    'uses two workers per engine, five seconds of warmup per worker and seven',
    'rotated batches targeting 460 ms. Elapsed ratios divide Lython by CPython',
    'and span all four pairings of worker medians. Above 1× means Lython takes',
    'longer. [Per-worker spreads and CPU](summary.json)','',
    '| Workload | Input or source | Phase | Lython | CPython | Elapsed ratio | Status |',
    '| --- | --- | --- | ---: | ---: | ---: | --- |',
    *artifact_rows,'',
    'Warm execution reuses compiled code in a running process. Elapsed includes',
    'applicable RAM-backed guest I/O, verified output and files, and disposal of',
    'the previous result. Lython uses the mediated comparison host with shared',
    'memory admission. CPython uses native file I/O and ordinary cyclic GC.',
    'Async rows compare Lython `RunAsync` with the same synchronous CPython script.',
    'Compile-only includes disposal of compiled code. Compile-to-result combines',
    'compilation, one synchronous run and both owner cleanups. Fixture reset,',
    'request framing and process startup sit outside elapsed. Process CPU covers',
    'the wider request. Startup has a separate historical benchmark.','',
    'The five scripts, fixture bytes and ten matching lanes reuse the',
    '[B1784 catalog](../2026-11-26-post-fixed-row-cpython/README.md). Two',
    'warm async lanes extend the catalog for defaulted rules and JSON totals.',
    'B1784 and B1791 ran separately. The paired Lython trials isolate',
    '[literal keyword defaults](../2026-11-26-literal-keyword-defaults/confirmation/README.md)',
    'and [one-byte JSON allocation](../2026-11-26-json-ascii-character/README.md).','',
    'All five independent CPython goldens, the pinned CPython executable and',
    'all 32 Lython image files verify. All 336 batches and both quiet checks',
    'pass. Workers join, guest fixtures are removed and the persistent raw',
    'archive verifies. Staging reused the B1790 worker image and retired',
    'one older VM DLL after checking its full local backup, all dependent',
    'frozen images and the matching committed observations.','',
    '[Image identity](identity.json) · [Observations](observations.tar.xz) ·',
    '[Terminal receipt](terminal-status.json) · [Procedures and custody](procedures.tar.xz)','',
]
(root/'README.md').write_text('\n'.join(root_readme),encoding='utf-8',newline='\n')

guide=repo/'docs/BENCHMARKS.md'
old_doc=guide.read_text(encoding='utf-8')
heading,tail=old_doc.split('\n\n',1)
old_warm, prose = tail.split('\n\n',1)
assert heading=='# Performance against CPython'
headers=old_warm.splitlines()[:2]
older_warm=[r for r in old_warm.splitlines()[2:] if '[B1784]' not in r]
historic, machine=prose.split('The quiet comparison machine',1)
compile_title='## Compilation and compile-to-result'
method, compile_remainder=machine.split(compile_title,1)
old_compile, next_sections=compile_remainder.lstrip('\n').split('\n\n',1)
older_compile=[r for r in old_compile.splitlines()[2:] if '[B1784]' not in r]
assert len(old_warm.splitlines()[2:])-len(older_warm)==7
assert len(old_compile.splitlines()[2:])-len(older_compile)==3
# Keep the historical revision links with their rows.
historical_revisions=historic[historic.index('B1784 measures'):].strip()
comparison=[
    'B1791 measures `d370fef84` on November 26, 2026 UTC against stock',
    'CPython 3.13.16. Ratios divide Lython elapsed time by CPython elapsed',
    'time. Above 1× means Lython takes longer. Ranges span all four pairings',
    'of process medians from two workers per engine. [B1791].',
]
warm_details=['<details>','<summary>Earlier warm measurements and revisions</summary>','',
              *headers,*older_warm,'',historical_revisions,'','</details>']
compile_head=old_compile.splitlines()[:2]
compile_details=['<details>','<summary>Earlier compilation and compile-to-result measurements</summary>','',
                 *compile_head,*older_compile,'','</details>']
new_doc='\n'.join([
    heading,'',*headers,*warm_rows,'',*comparison,'',
    'The quiet comparison machine'+method.strip('\n'),'',
    *warm_details,'',compile_title,'',*compile_head,*compile_rows,'',
    *compile_details,'',next_sections,
])
assert all(new_doc.count(row)==1 for row in older_warm+older_compile)
assert '[B1791]:' not in new_doc and new_doc.count('[B1784]:')==1
new_doc=new_doc.replace('[B1784]:','[B1791]: ../benchmarks/results/2026-11-26-post-ascii-cpython/README.md\n[B1784]:',1)
guide.write_text(new_doc,encoding='utf-8',newline='\n')
print('Published the 12 measured rows and preserved historical comparisons.')
