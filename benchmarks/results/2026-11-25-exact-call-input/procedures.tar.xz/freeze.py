from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
lab=Path(__file__).parent; repo=lab.parents[3]; worktree=lab.parents[2]/'agent-worktrees/borrowed-call-window-20261125'
reference=lab.with_name('tagged-default-ownership-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
git=lambda args,root=repo:subprocess.check_output(['git',*args],cwd=root)
revision=git(['rev-parse','c1984f96b']).decode().strip()
assert revision.startswith('c1984f96b')
assert git(['diff','--name-only',revision,'--','src'])==b''
changed=git(['diff','--name-only','--','src'],worktree).decode().splitlines()
assert len(changed)==2 and all(n.startswith('src/Lokad.Lython/') for n in changed), changed
patch=lab/'candidate.patch';patch.write_bytes(git(['diff','--binary','--','src'],worktree))
(lab/'test.patch').write_bytes(git(['diff','--binary','--','tests'],worktree))
archive=lab/'base.zip';settings=('global.json','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','NuGet.Config')
existing=set(git(['ls-tree','--name-only',revision]).decode().splitlines())
git(['archive','--format=zip',f'--output={archive}',revision,'--',*(p for p in settings if p in existing),'src/Lokad.Lython'])
frozen=lab/'frozen-candidate'
with zipfile.ZipFile(archive) as bundle:
 bundle.extractall(frozen)
 for name in changed:shutil.copyfile(worktree/name,frozen/name)
 for name in bundle.namelist():
  if name.endswith('/'):continue
  expected=(worktree/name).read_bytes() if name in changed else bundle.read(name)
  assert (frozen/name).read_bytes()==expected,name
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe';env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
with (lab/'candidate-build.log').open('wb') as log:
 subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','--artifacts-path',lab/'candidate-build'],cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
assert git(['diff','--binary','--','src'],worktree)==patch.read_bytes()
core=lab/'candidate-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
baseline=read(reference/'comparison/quiet/identity.json');assert baseline['sourceRevision'].startswith('a39d00228')
assert git(['diff','--binary',baseline['sourceRevision'],revision,'--','src'])==(reference/'candidate.patch').read_bytes()
before=baseline['imageFiles']['candidate'];assert len(before)==32 and {p.name:sha(p)for p in (reference/'candidate').iterdir()}==before
images={'reference':before,'candidate':before|{core.name:sha(core)}}
for role,files in images.items():
 output=lab/role;output.mkdir(exist_ok=True)
 for name in files:shutil.copyfile(core if role=='candidate' and name==core.name else reference/'candidate'/name,output/name)
 assert {p.name:sha(p)for p in output.iterdir()}==files
catalog=read(reference/'comparison/quiet/representative.json')
lexical=read(lab.with_name('supplied-lexical-call-20261123')/'comparison/representative.json')
new=[case for case in lexical['cases'] if case['id']=='scripts.ordinary-fully-supplied-helper.local-function']
assert len(new)==1 and 'def ' in new[0]['source'] and new[0]['id'] not in {c['id'] for c in catalog['cases']}, new
catalog['cases'].extend(new)
quiet=lab/'comparison/quiet';quiet.mkdir(parents=True,exist_ok=True);save(quiet/'representative.json',catalog)
identity=dict(sourceRevision=revision,comparisonRevision=revision,sourcePatchSHA256=sha(patch),imageFiles=images,
 coreSHA256={r+s:files[core.name]for r,files in images.items()for s in ('','-control')},
 expectedCPythonSHA256=baseline['expectedCPythonSHA256'],cpythonWorkerSHA256=baseline['cpythonWorkerSHA256'],
 catalogs={'representative.json':{'sha256':sha(quiet/'representative.json')}},
 purpose='Borrow an already evaluated exact call-update input and check live omitted binding once')
save(quiet/'identity.json',identity)
protocol=repo/'benchmarks/cpython-worker.py';assert sha(protocol)==identity['cpythonWorkerSHA256']
for role,files in images.items():
 proof=lab/'comparison'/f'{role}-verify.json'
 subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
  '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,check=True,timeout=65)
 checked=read(proof);assert checked['state']=='Completed' and checked['caseCount']==8 and checked['launched']['library']['sha256']==files[core.name]
 assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
print('Borrowed call operands and committed control match eight complete goldens')
