from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
base=Path('.git/agent-notes/review-20261031')
old=base/'csv-compiled-unpack-20261122'
new=base/'compiled-literal-defaults-keywords-20261122'
canonical='benchmarks/results/2026-11-22-csv-compiled-unpack/'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
artifact=lambda name:subprocess.check_output(['git','show','origin/master:'+canonical+name])
receipt=load(old/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
archive=artifact('observations.tgz')
assert sha(archive)==receipt['archiveSHA256']
old_root=Path(load(old/'quiet/config.json')['root']).name
image=gzip.decompress(artifact('candidate-core.dll.gz'))
assert sha(image)==load(old/'quiet/identity.json')['imageFiles']['candidate']['Lokad.Lython.dll']
catalog=(old/'quiet/representative.json').read_bytes()
assert sha(catalog)==load(old/'quiet/config.json')['catalogSHA256']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    assert any(Path(f.name).name=='representative.json' and f.isfile() and tar.extractfile(f).read()==catalog for f in tar.getmembers())
proof=[dict(paths=[old_root+'/'+name],bytes=len(data),links=1,sha256=sha(data),
            archives={old_root+'/observations.tgz':receipt['archiveSHA256']},optional=False)
       for name,data in (('candidate/Lokad.Lython.dll',image),('representative.json',catalog))]
(new/'retire-proof.json').write_text(json.dumps(dict(proof=proof,canonical=canonical),indent=2)+'\n',encoding='utf-8',newline='\n')
src=(base/'compiled-literal-defaults-20261122/prepare-quiet.py').read_text(encoding='utf-8-sig')
for a,b in (
    ('072ab6065','505a2a20a'),
    ('compiled-literal-defaults-b1324-20261122','compiled-literal-defaults-keywords-b1326-20261122'),
    ('lython-b1324-compiled-literal-defaults-20261122','lython-b1326-compiled-literal-defaults-keywords-20261122'),
    ('lython-b1324-fixtures','lython-b1326-fixtures'),
    ('Compiler-owned literal positional default tuples with independent keyword defaults','Literal default tuple load and separate keyword preparation'),
    ('Compiler-owned literal positional defaults comparison','Separate keyword preparation and literal positional defaults comparison'),
    ('"300", "385"','"300", "470"'),
    ('warmupSeconds=12','warmupSeconds=16'),
    ('min(warmed)<12','min(warmed)<16'),
    ('warmed[i]>=12','warmed[i]>=16'),
    ('accumulate 12 seconds','accumulate 16 seconds'),
    ('jobs = [(case, "warm") for case in cases] + [(cases[0], "compile-run")]','jobs = [(case, "warm") for case in reversed(cases)] + [(cases[0], "compile-run")]'),
):
    assert a in src,a
    src=src.replace(a,b)
compile(src,'prepare-quiet.py','exec')
(new/'prepare-quiet.py').write_text(src,encoding='utf-8',newline='\n')
