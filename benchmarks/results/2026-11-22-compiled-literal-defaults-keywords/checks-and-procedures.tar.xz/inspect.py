from pathlib import Path
import hashlib,json,os,shutil,subprocess
base=Path('.git/agent-notes/review-20261031').resolve()
lab=base/'compiled-literal-defaults-keywords-20261122'
p=lab/'inspect-tool'
p.mkdir(exist_ok=False)
template=base/'current-frontend-phases/inspect'
for name in ('Inspect.csproj','packages.lock.json'):
    shutil.copyfile(template/name,p/name)
program=(template/'Program.cs').read_text(encoding='utf-8-sig')
needle='            codes.Add(new { name = Read(code, "Name"), mirrors = Read(code, "RequiresLocalVariableMirroring"),'
assert needle in program
program=program.replace(needle,'''            var constants = ((IEnumerable)Read(code, "Constants")!).Cast<object?>().ToArray();
            var instructionTypes = ((IEnumerable)Read(code, "Instructions")!).Cast<object>()
                .Where(i => Read(i, "OpCode")!.ToString() is "ApplyOperation" or "LoadConst")
                .Select(i => constants[(int)Read(i, "ConstantIndex")!]?.GetType().Name ?? "null")
                .GroupBy(t => t).ToDictionary(g => g.Key, g => g.Count());
            codes.Add(new { name = Read(code, "Name"), instructionTypes, mirrors = Read(code, "RequiresLocalVariableMirroring"),''')
(p/'Program.cs').write_text(program,encoding='utf-8',newline='\n')
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,obj:path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
identity=load(lab/'identity.json')
with (lab/'inspect-build.log').open('wb') as log:
    subprocess.run([dotnet,'build',p/'Inspect.csproj','-c','Release','-f','net11.0','--no-incremental',
      '-p:InspectionCorePath='+str(lab/'frozen/reference/Lokad.Lython.dll')],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=40)
fixture=lab/'inspect-catalog.json'
write(fixture, {'cases':[{'id':c['id'],'source':c['source']} for c in load(lab/'representative.json')['cases']]})
images={}
for role,recorded in identity['imageFiles'].items():
    source=lab/'frozen'/role
    assert len(recorded)==32 and {n:sha(source/n) for n in recorded}==recorded
    target=lab/('inspect-'+role)
    target.mkdir(exist_ok=False)
    for file in (p/'bin/Release/net11.0').iterdir():
        if file.is_file():shutil.copyfile(file,target/file.name)
    shutil.copyfile(source/'Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={file.name:sha(file) for file in target.iterdir() if file.is_file()}
    assert images[role]['Lokad.Lython.dll']==recorded['Lokad.Lython.dll']
    subprocess.run([dotnet,target/'Inspect.dll',fixture,lab/(role+'-inspection.json')],cwd=lab,env=env,check=True,timeout=20)
    assert load(lab/(role+'-inspection.json'))['coreSHA256']==recorded['Lokad.Lython.dll']
a,b=[load(lab/(role+'-inspection.json'))['rows'] for role in ('reference','candidate')]
assert len(a)==len(b)==4 and a[2:]==b[2:]
rows=[]
for index in range(2):
    before=next(c['instructionTypes'] for c in a[index]['codes'] if c['name']=='compile_rule')
    after=next(c['instructionTypes'] for c in b[index]['codes'] if c['name']=='compile_rule')
    assert before['ExecutableStartFunctionDefaults']==1 and after.get('ExecutableStartFunctionDefaults',0)==0
    assert after['PyTuple']==1 and after.get('ExecutableStartKeywordDefaults',0)==1-index
    assert before['ExecutableAppendFunctionDefault']-after.get('ExecutableAppendFunctionDefault',0)==2
    rows.append(dict(id=b[index]['id'],oldDefaults=before,newDefaults=after))
write(lab/'inspection-identity.json',dict(fixtureSHA256=sha(fixture),workerImages=images,rows=rows,controlMetadataIdentical=True))
print('Both dynamic control tapes match. Each literal factory replaces two default fill operations with one compiled tuple load.')
