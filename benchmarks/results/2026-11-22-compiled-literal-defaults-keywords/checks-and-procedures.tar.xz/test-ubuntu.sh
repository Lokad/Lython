#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compiled-literal-defaults-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/compiled-literal-defaults-keywords-20261122
white='Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Default|FullyQualifiedName~Executable)'
public='Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Default|FullyQualifiedName~BindingPlan|FullyQualifiedName~Annotation|FullyQualifiedName~Closure|FullyQualifiedName~Lambda)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -30 "$logs/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -30 "$logs/public-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter 'Category=Stress&FullyQualifiedName~FunctionDefaultsAccountingScenarioTests' --verbosity quiet > "$logs/retained-defaults-stress-ubuntu.log" 2>&1 || { tail -30 "$logs/retained-defaults-stress-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log" "$logs/retained-defaults-stress-ubuntu.log"
