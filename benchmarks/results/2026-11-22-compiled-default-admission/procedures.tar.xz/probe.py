from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess

root = Path.cwd()
notes = root/".git/agent-notes/review-20261031"
lab = notes/"combined-default-storage-20261122"
recording = notes/"current-factory-admission-20261121"
source = (recording/"Program.cs").read_text(encoding="utf-8")
source = source.replace(
    "    budget.Capturing = true;",
    "    budget.Capturing = true;\n    var beforeAllocation = GC.GetTotalAllocatedBytes(precise: true);")
source = source.replace(
    "    budget.Capturing = false;",
    "    var bytesIncludingInstrumentation = GC.GetTotalAllocatedBytes(precise: true) - beforeAllocation;\n    budget.Capturing = false;")
# Counting only. Stack capture is useful for attribution and distorts allocation.
start = source.index('        var site = "unresolved";')
end = source.index('\n    }', start)
source = source[:start] + source[end:]
source = source.replace(
    "rows.Add(new { id, budget.Growths, baseline, sources = budget.Sources.Select(e => new\n        { site = e.Key.Site, bytes = e.Key.Delta, count = e.Value }).OrderByDescending(e => e.count) });",
    "rows.Add(new { id, budget.Growths, baseline, managedBytesDiagnostic = bytesIncludingInstrumentation });")
source = source.replace("bytesIncludingInstrumentation","executionAllocation")
(lab/"Program.cs").write_text(source, encoding="utf-8", newline="\n")
project = (recording/"Probe.csproj").read_text(encoding="utf-8")
project = project.replace("<Nullable>enable</Nullable>", "<Nullable>enable</Nullable><EnableDefaultCompileItems>false</EnableDefaultCompileItems>")
project = project.replace("<ItemGroup>", '<ItemGroup><Compile Include="Program.cs" />')
(lab/"Probe.csproj").write_text(project,encoding="utf-8",newline="\n")
ref = lab/"reference-core.dll"
evidence = root/"benchmarks/results/2026-11-22-regex-escape-runs"
ref.write_bytes(gzip.decompress((evidence/"candidate-core.dll.gz").read_bytes()))
assert hashlib.sha256(ref.read_bytes()).hexdigest() == json.loads((evidence/"source.json").read_text(encoding="utf-8"))["imageFiles"]["candidate"]["Lokad.Lython.dll"]
cand = lab/"windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
suite = notes/"direct-lexical-keyword-default-20261122/representative.json"
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"probe-build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"Probe.csproj","-c","Release",f"-p:InspectionCorePath={cand}"],
        cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=70)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
images = {}
for role, core in [("reference",ref),("candidate",cand)]:
    image = lab/"recording"/role
    image.mkdir(parents=True,exist_ok=True)
    for payload in (lab/"bin/Release/net11.0").iterdir():
        if payload.is_file():
            shutil.copyfile(payload,image/payload.name)
    shutil.copyfile(core,image/"Lokad.Lython.dll")
    assert sha(image/"Lokad.Lython.dll") == sha(core)
    images[role] = {p.name:sha(p) for p in image.iterdir() if p.is_file()}
    output = lab/(role+"-reservation-counts.json")
    with output.open("wb") as report:
        subprocess.run([dotnet,image/"Probe.dll",suite],cwd=root,env=env,stdout=report,check=True,timeout=30)
    print(role,json.loads(output.read_text(encoding="utf-8-sig")),flush=True)
(lab/"reservation-probe-images.json").write_text(json.dumps(dict(images=images,catalogSHA256=sha(suite)),indent=2)+"\n",
    encoding="utf-8",newline="\n")
