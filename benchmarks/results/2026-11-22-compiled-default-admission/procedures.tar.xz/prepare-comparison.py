from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
out.mkdir(exist_ok=True)
previous=lab.parent/"static-assignment-deltas-20261122"
reference=lab.parent/"regex-template-source-ranges-20261122/refined/reference"
prior=json.loads((previous/"comparison/images.json").read_text(encoding="utf-8"))
suite_path=lab.parent/"direct-lexical-keyword-default-20261122/representative.json"
suite=json.loads(suite_path.read_text(encoding="utf-8-sig"))
ids=["scripts.ordinary-fully-supplied-helper",
     "scripts.annotated-rule-closures.nested-factories",
     "scripts.annotated-rule-closures.nested-factories.postponed",
     "scripts.factory-observed-defaults"]
other=lab.parent/"single-positional-default-20261122/representative.json"
other_suite=json.loads(other.read_text(encoding="utf-8-sig"))
rows={r["id"]:r for r in other_suite["cases"]}
rows.update((r["id"],r) for r in suite["cases"])
suite["cases"]=[rows[id] for id in ids]
suite["performanceQualified"]=False
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
catalog=out/"catalog.json"
write(catalog,suite)
src=lab/"frozen-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
candidate=out/"frozen-candidate"
candidate.mkdir(exist_ok=True)
expected=prior["imageFiles"]["reference"]
assert len(expected)==32
def hashes(path):return {name:sha(path/name)for name in expected}
assert hashes(reference)==expected
core=src.name
for name in expected:shutil.copyfile(src if name==core else reference/name,candidate/name)
files={"reference":expected,"candidate":{**expected,core:sha(src)}}
assert files["reference"][core]!=files["candidate"][core]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==prior["protocolSHA256"]
for role,image in (("reference",reference),("candidate",candidate)):
    assert hashes(image)==files[role]
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify",
        "--catalog",catalog,"--dotnet",dotnet,"--python","C:/Python313/python.exe",
        "--python-worker",protocol,"--out",receipt],env=env,check=True,timeout=70)
    data=json.loads(receipt.read_text(encoding="utf-8-sig"))
    assert data["state"]=="Completed" and data["caseCount"]==len(ids) and data["catalogSha256"]==sha(catalog)
def patch(base,candidate):
    return subprocess.check_output(["git","diff","--binary",base,candidate,"--","src","tests"],cwd=repo)
measured=patch("c097d73db","fb5f9dbe7")
assert measured==patch("1d1b03e27","f81baafa9")
(out/"source.patch").write_bytes(measured)
write(out/"images.json",dict(reference="c097d73db",candidate="fb5f9dbe7",
    imageFiles=files,catalogSHA256=sha(catalog),sourcePatchSHA256=hashlib.sha256(measured).hexdigest(),
    protocolSHA256=prior["protocolSHA256"]))
