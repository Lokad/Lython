#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/combined-default-storage-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/combined-default-storage-20261122
artifact="$dir/ubuntu"
white='Category!=Stress&(FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~GeneralBoundMethodDefaultLifetime|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~Closure)'
public='Category!=Stress&(FullyQualifiedName~FunctionDefault|FullyQualifiedName~Functions|FullyQualifiedName~FunctionCall|FullyQualifiedName~Closure|FullyQualifiedName~SharedMemory|FullyQualifiedName~Cancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$artifact" --nologo > "$dir/white-exact-ubuntu.log" 2>&1 || { tail -45 "$dir/white-exact-ubuntu.log"; exit 1; }
dotnet build tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$artifact" --nologo > "$dir/public-build-ubuntu.log" 2>&1 || { tail -45 "$dir/public-build-ubuntu.log"; exit 1; }
cp Directory.Build.props "$artifact/Directory.Build.props"
public_dir="$artifact/bin/Lokad.Lython.PublicApi.Tests/release_net10.0"
mkdir -p "$artifact/Fixtures/Language/Functions"
cp -a tests/Fixtures/Language/Functions/HelperAndRecursive "$artifact/Fixtures/Language/Functions/"
dest="$artifact/tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0"
mkdir -p "$dest"
cp -a "$artifact/bin/Lokad.Lython.WorkerFixture/release_net10.0/." "$dest/"
cmp "$dest/Lokad.Lython.dll" "$public_dir/Lokad.Lython.dll"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --no-build --artifacts-path "$artifact" --nologo > "$dir/public-exact-ubuntu.log" 2>&1 || { tail -55 "$dir/public-exact-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-exact-ubuntu.log" "$dir/public-exact-ubuntu.log"
