set -eu
root=/home/lokad/lython-bench-checks/keyword-copy-path-b1092-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
