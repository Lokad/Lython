from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
notes=lab.parent
old=notes/'ready-dictreader-row-20261127'
donor=old/'comparison/quiet'
out=lab/'comparison/quiet'
out.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
previous=read(donor/'identity.json')
images=previous['imageFiles']
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
catalog=read(donor/'representative.json')
json_id='diagnostic.nested-json-document'
text_id='diagnostic.text-summary.nonlocal-computed-width.large'
text_catalog=read(notes/'post-starmap-cpython-20261126/comparison/quiet/representative.json')
json_case=next(c for c in catalog['cases'] if c['id']==json_id)
text_case=next(c for c in text_catalog['cases'] if c['id']==text_id)
assert 'csv' not in json_case['source'] and 'csv' not in text_case['source']
catalog['cases']=[json_case,text_case]
write(out/'representative.json',catalog)
write(out/'jobs.json',{'warm':[[json_id,'warm'],[text_id,'warm'],[json_id,'warm']]})
for name in ('run.sh','cpython-worker.py'):
    shutil.copyfile(donor/name,out/name)
assert b'\r' not in (out/'run.sh').read_bytes()
assert sha(out/'cpython-worker.py')==previous['cpythonWorkerSHA256']
identity=previous | dict(catalogs={n:{'sha256':sha(out/n)} for n in ('representative.json','jobs.json')},
    donorArchiveSHA256=receipt['archiveSHA256'], purpose='Recheck exact B1846 nested JSON control between early and late placements; include an unaffected Unicode text report.')
write(out/'identity.json',identity)
collector=(donor/'collect.py').read_text(encoding='utf8')
assert 'if job_index % 2 == 0: labels.reverse()' in collector
collector=collector.replace('if job_index % 2 == 0: labels.reverse()', 'if job_index == 2: labels.reverse()')
collector=collector.replace('lython-b1846-fixtures','lython-b1848-fixtures')
compile(collector,'collect.py','exec')
(out/'collect.py').write_text(collector,encoding='utf8',newline='\n')

ssh=(old/'quiet-vm.py').read_text(encoding='utf8').replace('lython-b1846-ready-dictreader-row-20261127','lython-b1848-dictreader-json-control-20261127')
start=ssh.index(" origin=(donor/'candidate').resolve(strict=True)")
end=ssh.index(' receipt=json.loads',start)
ssh=ssh[:start]+''' assert donor.resolve()==donor and donor.parent==base
 origins={role: (donor/role).resolve(strict=True) for role in cfg['donorFiles']}
 assert all(path==donor/role for role,path in origins.items())
'''+ssh[end:]
ssh=ssh.replace("assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles']", 
                "assert all({p.name:sha(p) for p in path.iterdir()}==cfg['donorFiles'][role] for role,path in origins.items())")
start=ssh.index('   if (target/name).exists():')
end=ssh.index('  assert {p.name:sha(p)',start)
ssh=ssh[:start]+'''   assert cfg['donorFiles'][role][name]==digest
   os.link(origins[role]/name,target/name)
'''+ssh[end:]
ssh=ssh.replace("proof['caseCount']==5","proof['caseCount']==2")
compile(ssh,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(ssh,encoding='utf8',newline='\n')
summary=(old/'summarize-quiet.py').read_text(encoding='utf8')
summary=summary.replace("for job in raw['jobs']:", "for index, job in enumerate(raw['jobs']):").replace("summary.append(dict(case=job['case']", "summary.append(dict(position=index+1,case=job['case']")
compile(summary,'summarize-quiet.py','exec')
(lab/'summarize-quiet.py').write_text(summary,encoding='utf8',newline='\n')

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
for role,files in images.items():
    folder=old/'local'/role
    assert len(files)==32 and {p.name:sha(p) for p in folder.iterdir()}==files
    proof=out/f'{role}-verify.json'
    subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',out/'cpython-worker.py','--out',proof],
        env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=60)
    checked=read(proof)
    assert checked['state']=='Completed' and checked['caseCount']==2
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert checked['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py']
payload=out/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(out/name,arcname=name)
staged={name:dict(length=(out/name).stat().st_size,sha256=sha(out/name)) for name in names}
write(out/'upload.json',dict(root='dictreader-json-control-b1848-20261127',donor=read(donor/'upload.json')['root'],donorFiles=images,
      donorArchive=receipt['archiveSHA256'],payloadSHA256=sha(payload),files=staged,
      expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))
