from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
local=lab/'local'
prior=lab.with_name('deferred-site-placement-20261126')/'local'
source=lab.with_name('starmap-direct-sequence-packet-20261126')/'comparison/quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,data:path.write_text(data,encoding='utf-8',newline='\n')

identity=read(local/'identity.json')
previous=read(source/'identity.json')
assert identity['imageFiles']['reference']==previous['imageFiles']['candidate']
assert identity['catalogSHA256']==sha(local/'representative.json')
jobs={'warm': [
    ['scripts.rule-default-closures','compile'],
    ['diagnostic.generated-ordinary-definitions','compile'],
    ['scripts.file-search.large','warm'],
    ['scripts.rule-default-closures','warm-async'],
]}
write(local/'jobs.json',json.dumps(jobs,indent=2)+'\n')
identity['coreSHA256']={r+s:v['Lokad.Lython.dll'] for r,v in identity['imageFiles'].items() for s in ('','-control')}
identity['catalogs']={name:{'sha256':sha(local/name)} for name in ('representative.json','jobs.json')}
identity['expectedCPythonSHA256']=previous['expectedCPythonSHA256']
identity['purpose']='Store a single compiled literal keyword initializer by reference.'
write(local/'identity.json',json.dumps(identity,indent=2)+'\n')
collector=(prior/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-deferred-site-placement-fixture-')==1
collector=collector.replace('lython-deferred-site-placement-fixture-','lython-direct-literal-keyword-metadata-fixture-')
compile(collector,'collect.py','exec')
write(local/'collect.py',collector)
shutil.copyfile(prior/'run.sh',local/'run.sh')
assert b'\r' not in (local/'run.sh').read_bytes()
shutil.copyfile(prior.parent/'summarize.py',lab/'summarize.py')
