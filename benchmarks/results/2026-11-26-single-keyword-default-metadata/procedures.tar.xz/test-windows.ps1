$env:DOTNET_ROOT=Join-Path $env:USERPROFILE '.dotnet11'
$env:DOTNET_ROOT_X64=$env:DOTNET_ROOT
$sdk=Join-Path $env:DOTNET_ROOT 'dotnet.exe'
Set-Location (Join-Path $PSScriptRoot 'source')
$filter='Category!=Stress&(FullyQualifiedName~Default|FullyQualifiedName~Callable|FullyQualifiedName~Annotation|FullyQualifiedName~Lambda|FullyQualifiedName~Closure|FullyQualifiedName~AdmissionFailureCommand)'
foreach ($suite in @('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests')) {
    & $sdk test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path ../windows --filter $filter *> "../$suite-win11.log"
    $code=$LASTEXITCODE
    Get-Content "../$suite-win11.log" -Tail 24 -Encoding utf8
    if ($code -ne 0) { exit $code }
}
