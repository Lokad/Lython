from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
old = lab.parent/'private-regex-allowance-b1938-20261128/comparison'
source = lab.parent/'staged-generator-activation-refined-b1936-20261128'
delivery = lab.parent/'current-shipment-checkpoint-b1937-20261128/comparison/quiet'
pair = lab/'comparison'
build = lab/'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def files(folder):
    return {path.name:digest(path) for path in folder.iterdir()}
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo)
def write(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')

head = git('rev-parse','HEAD').decode().strip()
old_id = read(old/'identity.json')
delivered = read(delivery/'identity.json')
assert not git('diff','--binary',delivered['sourceRevision'],head,'--','src/Lokad.Lython','Directory.Packages.props')
assert sha256(git('diff','--binary',old_id['sourceRevision'],head,'--','src/Lokad.Lython.Utf8Regex')).hexdigest()==old_id['sourcePatchSHA256']
assert not git('diff','--binary','HEAD','--','src/Lokad.Lython.Utf8Regex','Directory.Packages.props')
old_image = files(old/'candidate')
assert len(old_image)==32 and old_image==old_id['imageFiles']['candidate']
assert old_image['Lokad.Lython.dll']==delivered['imageFiles']['candidate']['Lokad.Lython.dll']
pair.mkdir()
for role in ('reference','candidate'):
    copytree(old/'candidate',pair/role)
copy2(build,pair/'candidate/Lokad.Lython.dll')
images = {role:files(pair/role) for role in ('reference','candidate')}
assert images['reference']==old_image
assert {k for k,sha in images['reference'].items() if images['candidate'][k]!=sha}=={'Lokad.Lython.dll'}
assert images['candidate']['Lokad.Lython.dll']==digest(build)

patch = git('diff','--binary','HEAD','--','src/Lokad.Lython')
(lab/'candidate.patch').write_bytes(patch)
(lab/'test.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
for name in ('representative.json','cpython-worker.py'):
    copy2(delivery/name,pair/name)
assert digest(pair/'representative.json')==delivered['catalogs']['representative.json']['sha256']
assert digest(pair/'cpython-worker.py')==delivered['cpythonWorkerSHA256']
cases = {case['id'] for case in read(pair/'representative.json')['cases']}
jobs = [
    ['diagnostic.shipment-row-generator-reduction','warm-async'],
    ['diagnostic.shipment-starmap-iterable-rows','warm-async'],
    ['diagnostic.shipment-row-generator-reduction','warm'],
    ['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.file-search-first-line','warm-async'],
]
assert {case for case,lane in jobs}==cases
write(pair/'jobs.json',{'warm':jobs})
write(pair/'identity.json',dict(sourceRevision=head,sourcePatchSHA256=sha256(patch).hexdigest(),imageFiles=images,
    coreSHA256={label:images[role]['Lokad.Lython.dll'] for role in images for label in (role,role+'-control')},
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json')},
    cpythonWorkerSHA256=delivered['cpythonWorkerSHA256'],expectedCPythonSHA256=delivered['expectedCPythonSHA256'],
    purpose='Hand an admitted generator expression frame directly to the evaluated builtin sum without a generator or cursor wrapper.'))
for name in ('run.sh','collect.py'):
    copy2(source/'comparison'/name,pair/name)
for name in ('summarize.py','measure-allocation.py'):
    copy2(source/name,lab/name)
assert b'\r' not in (pair/'run.sh').read_bytes()
print(head,len(jobs),'lanes with exact baseline and candidate images')
