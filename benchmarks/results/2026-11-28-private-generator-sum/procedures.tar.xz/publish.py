from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab/'comparison'
out = repo/'benchmarks/results/2026-11-28-private-generator-sum'
def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = read(bench/'identity.json')
for part, name in [('src/Lokad.Lython', 'candidate.patch'), ('tests', 'test.patch')]:
    source = check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', part], cwd=repo)
    assert source == (lab/name).read_bytes()
assert digest(lab/'candidate.patch')==identity['sourcePatchSHA256']
for role,manifest in identity['imageFiles'].items():
    assert len(manifest)==32 and {path.name:digest(path) for path in (bench/role).iterdir()}==manifest
assert {name for name, sha in identity['imageFiles']['reference'].items()
        if identity['imageFiles']['candidate'][name]!=sha}=={'Lokad.Lython.dll'}
summary = read(bench/'summary.json')
assert summary['verifiedTimedBatches']==140 and len(summary['rows'])==5
receipt = read(bench/'archive-receipt.json')
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(bench/'observations.tar.xz')
alloc = read(lab/'allocation/summary.json')
assert len(alloc)==8 and all(row['compiled'][0]==row['compiled'][1] and row['admittedPeak'][0]==row['admittedPeak'][1] for row in alloc)
for row in alloc:
    delta = row['clr'][0]-row['clr'][1]
    assert delta==294912 if row['case']=='diagnostic.shipment-row-generator-reduction' else abs(delta)<=56
logs = list(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs)==6
for log in logs:
    count=711 if 'PublicApi' in log.name else 159
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
out.mkdir(exist_ok=True)
artifacts = {name:bench/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json'] = lab/'allocation/summary.json'
for name,path in artifacts.items():
    copy2(path,out/name)
    assert digest(out/name)==digest(path)
procedures = {p.name:p for p in logs}
for name in ('candidate.patch','test.patch','freeze.py','test-ubuntu.sh','test-windows.ps1','ubuntu-core-build.log',
             'summarize.py','measure-allocation.py','publish.py'):
    procedures[name] = lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name]=bench/name
for p in (lab/'allocation').glob('*.json'):
    procedures[f'allocation/{p.name}']=p
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in procedures.items():
        archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Private generator sum evidence verified.')
