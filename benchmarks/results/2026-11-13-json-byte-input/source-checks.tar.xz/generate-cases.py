from pathlib import Path
import json,subprocess,sys
r=Path(__file__).parent
cases=[]
def add(name,source):
    done=subprocess.run([sys.executable,'-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8')
    assert done.returncode==0,(name,done.stderr)
    cases.append(dict(Name=name,Source=source,Output=done.stdout))
doc='{"é":"😀","n":7}'
for encoding in ['utf-8','utf-8-sig','utf-16','utf-16-le','utf-16-be','utf-32','utf-32-le','utf-32-be']:
    add(encoding,'import json\nprint(json.loads('+repr(doc.encode(encoding))+'))')
for name,b in [('utf32be-bom',b'\x00\x00\xfe\xff'+doc.encode('utf-32-be')),('utf16be-bom',b'\xfe\xff'+doc.encode('utf-16-be')),
               ('single-le',b'7\x00'),('single-be',b'\x007'),('crlf',b'{\r\n"x":"a\\r\\nb"\r\n}'),('empty',b''),
               ('empty-bom',b'\xef\xbb\xbf'),('utf8-invalid',b'"ok"\xff'),('utf8-sig-invalid',b'\xef\xbb\xbf"ok"\xff'),
               ('utf16-truncated',b'\xff\xfe7\x00\xff'),('utf16be-truncated',b'\xfe\xff\x007\xff'),
               ('utf32-truncated',b'\xff\xfe\x00\x007\x00\x00'),('utf32-range',b'\x00\x00\xfe\xff\x00\x11\x00\x00'),
               ('trailing-text','"é" x'.encode('utf-16-be'))]:
    add(name,'import json\ntry:\n print(json.loads('+repr(b)+'))\nexcept UnicodeDecodeError as e:\n print(type(e).__name__,e.encoding,e.start,e.end,e.object.hex())\nexcept json.JSONDecodeError as e:\n print(type(e).__name__,e.msg,e.pos,e.lineno,e.colno,repr(e.doc))')
add('keyword-alias-hooks','import json\nf=json.loads\nprint(f(s=b"[12,1.5,NaN]",parse_int=lambda s:"i"+s,parse_float=lambda s:"f"+s,parse_constant=str))')
add('pairs-hook','import json\nprint(json.loads(b\'{"x":1,"x":2}\',object_pairs_hook=lambda p:p))')
add('custom-decoder','import json\nclass D(json.JSONDecoder):\n def __init__(self,tag,**kw):\n  print("init",tag)\n  super().__init__(**kw)\n def decode(self,s):\n  print(type(s).__name__,repr(s))\n  return super().decode(s)\nprint(json.loads(b"7",cls=D,tag="t"))')
add('decode-before-constructor','import json\nclass D:\n def __init__(self,**kw):print("init")\n def decode(self,s):print("decode")\ntry:json.loads(b"7\\xff",cls=D)\nexcept UnicodeDecodeError:print("unicode")')
add('string-bom-before-constructor','import json\nclass D:\n def __init__(self,**kw):print("init")\n def decode(self,s):print("decode")\ntry:json.loads("\\ufeff7",cls=D)\nexcept json.JSONDecodeError as e:print(e.msg,e.pos,e.doc=="\\ufeff7")')
add('binary-stream','import json,io\nprint(json.load(io.BytesIO(b\'{"x":7}\')) )')
add('reader-protocol','import json\nclass R:\n def read(self):return b"7"\nprint(json.load(R()))')
add('decoder-str-only','import json\nfor method in [json.JSONDecoder().decode,json.JSONDecoder().raw_decode]:\n try:method(b"7")\n except TypeError:print("type")')
add('utf8-boundaries','import json\nfor n in [4094,4095,4096]:\n s=" "*n+\'"é😀"\'\n print(json.loads(s.encode("utf-8")))')
out=Path('tests/Lokad.Lython.PublicApi.Tests/Fixtures/JsonBytes/cases.json');out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'golden-origin.json').write_text(json.dumps(dict(python=sys.version,executable=sys.executable,cases=len(cases),fixture=str(out)),indent=2)+'\n',encoding='utf-8',newline='\n')
print(len(cases),'independent CPython goldens')
