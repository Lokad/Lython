from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
for target in ['net11.0','net10.0']:
 log=r/('pending-'+target+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--filter','FullyQualifiedName~JsonByteOwnershipTests.PendingHookRetainsBorrowedBytesUntilItsActualUsersFinish','--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
 print(target,done.returncode,'\n'.join(log.read_text(encoding='utf-8').splitlines()[-12:]),flush=True)
 assert done.returncode==0
