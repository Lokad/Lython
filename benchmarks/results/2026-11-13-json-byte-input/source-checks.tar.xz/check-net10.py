from pathlib import Path
import os,subprocess,time
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];sdk=env['DOTNET_ROOT']+'/dotnet.exe'
for label,project,selection in [('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','FullyQualifiedName~JsonByteInputTests|FullyQualifiedName~JsonRetainedTextTests|FullyQualifiedName~JsonSuspendingCallbackTests|FullyQualifiedName~JsonModuleCallBindingTests|FullyQualifiedName~JsonTextStreamTests'),('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','FullyQualifiedName~JsonByteOwnershipTests|FullyQualifiedName~JsonWindowOwnershipTests|FullyQualifiedName~JsonDecodeAdmissionTests')]:
 log=r/(label+'-focused-net10.log');start=time.monotonic()
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test',project,'-c','Release','-f','net10.0','--filter',selection,'--nologo'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,done.returncode,round(time.monotonic()-start,2),'\n'.join(log.read_text(encoding='utf-8').splitlines()[-4:]),flush=True)
 assert done.returncode==0
