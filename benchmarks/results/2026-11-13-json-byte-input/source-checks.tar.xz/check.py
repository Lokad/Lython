from pathlib import Path
import os,subprocess,time
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
sdk=env['DOTNET_ROOT']+'/dotnet.exe'
for name,project,selection in [
 ('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','FullyQualifiedName~JsonByteInputTests|FullyQualifiedName~JsonModuleCallBindingTests|FullyQualifiedName~JsonBoundaryContractTests|FullyQualifiedName~JsonSuspendingCallbackTests|FullyQualifiedName~JsonReadContinuationTests|FullyQualifiedName~JsonRetainedTextTests|FullyQualifiedName~JsonTextStreamTests'),
 ('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','FullyQualifiedName~JsonByteOwnershipTests|FullyQualifiedName~JsonWindowOwnershipTests|FullyQualifiedName~JsonDecodeAdmissionTests')]:
    log=r/(name+'-focused.log');start=time.monotonic()
    with log.open('w',encoding='utf-8',newline='\n')as f:
        done=subprocess.run([sdk,'test',project,'-c','Release','-f','net11.0','--filter',selection,'--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
    print(name,done.returncode,round(time.monotonic()-start,2),log,flush=True)
    print('\n'.join(log.read_text(encoding='utf-8').splitlines()[-14:]),flush=True)
    if done.returncode:raise SystemExit(done.returncode)
