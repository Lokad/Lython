set -eu
lab="$PWD/.git/agent-notes/review-20261031/map-slots-refined-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='(FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~BuiltinIteratorSequenceFunction|FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorAdapterCallback|FullyQualifiedName~NativeCallbackProtocol|FullyQualifiedName~CallInputLifetime|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~IntegerAliasOwnership)&Category!=Stress'
for target in net11.0 net10.0; do
 for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$target-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f "$target" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -48 "$log"
        exit 1
    fi
 done
done
