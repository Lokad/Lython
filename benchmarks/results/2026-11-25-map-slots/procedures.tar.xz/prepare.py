from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,tarfile,tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.with_name('zip-unpack-20261125')
prior=lab.with_name('shared-function-local-slots-20261125')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(p.read_bytes())
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
before=read(source/'comparison/quiet/identity.json')
reference=before['imageFiles']['candidate']
assert len(reference)==32 and {p.name:sha(p) for p in (source/'candidate').iterdir()}==reference
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch.read_bytes()
core=lab/'candidate-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
images={'reference':reference,'candidate':reference|{core.name:sha(core)}}
assert reference[core.name]!=images['candidate'][core.name]
for role,files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:shutil.copyfile(core if role=='candidate' and name==core.name else source/'candidate'/name,image/name)
    assert {p.name:sha(p) for p in image.iterdir()}==files

catalog=read(source/'comparison/quiet/representative.json')
source_id='diagnostic.shipment-routing-callbacks'
invoice='scripts.csv-invoice.method-policy.quoted-control'
retained_id='diagnostic.shipment-native-map-control'
cases={r['id']:r for r in catalog['cases']}
retained='''import csv

with open('shipments.csv', encoding='utf-8', newline='') as source:
    rows = list(csv.DictReader(source))
quantities = [row['quantity'] for row in rows]
print(len(quantities), sum(map(int, quantities)))
for index in (0, len(quantities) // 2, len(quantities) - 1):
    print(rows[index]['id'], quantities[index])
'''
python=Path('C:/Python313/python.exe')
parent=cases[source_id]
with tempfile.TemporaryDirectory(prefix='lython-native-map-golden-') as folder:
    for name,encoded in json.loads(parent['fixtureJson'])['inputFiles'].items():
        Path(folder,name).write_bytes(base64.b64decode(encoded))
    output=subprocess.run([python,'-I','-S','-X','utf8','-'],input=retained,cwd=folder,text=True,encoding='utf-8',capture_output=True,check=True,timeout=30)
    assert not output.stderr
cases[retained_id]=parent|dict(id=retained_id,source=retained,sourceUtf8Bytes=len(retained.encode('utf-8')),
    sourceSha256=digest(retained.encode('utf-8')),expectedOutput=output.stdout,
    expectedOutputUtf8Bytes=len(output.stdout.encode('utf-8')),expectedOutputSha256=digest(output.stdout.encode('utf-8')))
catalog['cases']=[cases[k] for k in (source_id,retained_id,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',dict(warm=[[source_id,'warm'],[retained_id,'warm'],[source_id,'warm-async'],[invoice,'warm'],[source_id,'compile-run']]))
ident=dict(sourceRevision='ac9f9211b701aeefdf61fe5edf0a92647d688b1c',comparisonRevision='ac9f9211b701aeefdf61fe5edf0a92647d688b1c',sourcePatchSHA256=sha(patch),
    purpose='Carry short map callback inputs and direct returns in native operand slots',
    imageFiles=images,coreSHA256={r+s:files[core.name] for r,files in images.items() for s in ('','-control')},
    expectedCPythonSHA256=before['expectedCPythonSHA256'],cpythonWorkerSHA256=before['cpythonWorkerSHA256'],
    catalogs={name:dict(sha256=sha(quiet/name)) for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',ident)
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==ident['cpythonWorkerSHA256']
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    verification=lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',verification],env=env,cwd=repo,check=True,timeout=65)
    result=read(verification)
    assert result['state']=='Completed' and result['caseCount']==3 and result['launched']['library']['sha256']==files[core.name]
    assert result['catalogSha256']==ident['catalogs']['representative.json']['sha256']
shutil.copyfile(source/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(source/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1665-fixtures','b1667-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='map-slots-b1667-20261125',reference='zip-unpack-b1665-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
source_receipt=read(source/'comparison/quiet/terminal-status.json')['receipt']
assert source_receipt['complete'] and sha(source/'comparison/quiet/observations.tar.xz')==source_receipt['archiveSHA256']
launcher=(source/'quiet.py').read_text(encoding='utf-8').replace('683fcdfa4dbd7f3c12ffadc461698d86584d2a4fce926626a9c7f08954bef52b',source_receipt['archiveSHA256'])
launcher=launcher.replace('lython-b1665-zip-unpack-20261125','lython-b1667-map-slots-20261125').replace('b1665','b1667')
launcher=launcher.replace("os.link(reference/'cpython-worker.py',root/'cpython-worker.py')", "os.link(reference/'cpython-worker.py',root/'cpython-worker.py')")
assert source_receipt['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
report=(source/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-zip-unpack','2026-11-25-map-slots')
report=report.replace('788be8f35','ac9f9211b')
compile(report,'archive.py','exec')
write(lab/'archive.py',report)
print('Verified both full images on the shipment report and two controls.')
