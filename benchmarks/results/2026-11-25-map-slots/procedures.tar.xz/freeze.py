from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.with_name('zip-unpack-20261125')
identity=json.loads((source/'comparison/quiet/identity.json').read_text(encoding='utf-8'))
git=lambda args:subprocess.check_output(['git',*args],cwd=repo)
revision=git(['rev-parse','HEAD']).decode().strip()
assert revision.startswith('ac9f9211b')
assert git(['diff','--binary',identity['sourceRevision'],revision,'--','src'])==(source/'candidate.patch').read_bytes()
changed=git(['diff','--name-only','--','src']).decode().splitlines()
assert len(changed)==2 and all(p.startswith('src/Lokad.Lython/Runtime/') for p in changed),changed
patch=lab/'candidate.patch'
patch.write_bytes(git(['diff','--binary','--','src']))
(lab/'test.patch').write_bytes(git(['diff','--binary','--','tests']))
archive=lab/'frozen-source.zip'
settings=['global.json','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','NuGet.Config']
existing=set(git(['ls-tree','--name-only',revision]).decode().splitlines())
git(['archive','--format=zip',f'--output={archive}',revision,'--',*(p for p in settings if p in existing),'src/Lokad.Lython'])
frozen=lab/'frozen-candidate'
with zipfile.ZipFile(archive) as bundle:
    bundle.extractall(frozen)
    for name in changed:shutil.copyfile(repo/name,frozen/name)
    for name in bundle.namelist():
        if name.endswith('/'):continue
        expected=(repo/name).read_bytes() if name in changed else bundle.read(name)
        assert (frozen/name).read_bytes()==expected,name
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
with (lab/'candidate-build.log').open('wb') as log:
    subprocess.run([sdk/'dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
        '--no-incremental','--artifacts-path',lab/'candidate-build'],cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
assert git(['diff','--binary','--','src'])==patch.read_bytes()
print('Built the candidate on the exact B1665 runtime source with the isolated map patch.')
