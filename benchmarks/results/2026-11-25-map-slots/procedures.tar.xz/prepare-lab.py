from pathlib import Path
import shutil
r=Path(__file__).parent
z=r.with_name('zip-unpack-20261125')
read=lambda path:path.read_text(encoding='utf-8')
write=lambda name,s:(r/name).write_text(s,encoding='utf-8',newline='\n')
freeze=read(z/'freeze.py').replace("source=lab.with_name('shared-locals-cpython-20261125')", "source=lab.with_name('zip-unpack-20261125')").replace("source/'external/identity.json'", "source/'comparison/quiet/identity.json'").replace("revision.startswith('0843c399e')", "revision.startswith('ac9f9211b')").replace("assert not git(['diff','--name-only',identity['sourceRevision'],revision,'--','src','Directory.Build.props','Directory.Packages.props','global.json'])", "assert git(['diff','--binary',identity['sourceRevision'],revision,'--','src'])==(source/'candidate.patch').read_bytes()").replace('len(changed)==4','len(changed)==2').replace('exact B1663 runtime source with the isolated zip patch','exact B1665 runtime source with the isolated map patch')
write('freeze.py',freeze)
prepare=read(z/'prepare.py').replace("source=lab.with_name('shared-locals-cpython-20261125')", "source=lab.with_name('zip-unpack-20261125')").replace("source/'external/", "source/'comparison/quiet/").replace("comparison/quiet/representative.json'", "comparison/quiet/representative.json'").replace('diagnostic.shipment-retained-zip','diagnostic.shipment-native-map-control').replace('lython-retained-zip-golden','lython-native-map-golden').replace("purpose='Publish fixed zip unpacks into admitted frame slots and keep the same ordered producer for escaping tuples'", "purpose='Carry short map callback inputs and direct returns in native operand slots'")
prepare=prepare.replace("ident=dict(sourceRevision=before['sourceRevision'],comparisonRevision=before['sourceRevision'],", "ident=dict(sourceRevision='ac9f9211b701aeefdf61fe5edf0a92647d688b1c',comparisonRevision='ac9f9211b701aeefdf61fe5edf0a92647d688b1c',")
begin=prepare.index("retained='''");end=prepare.index("python=Path",begin)
prepare=prepare[:begin]+'''retained=\'\'\'import csv

with open('shipments.csv', encoding='utf-8', newline='') as source:
    rows = list(csv.DictReader(source))
quantities = [row['quantity'] for row in rows]
print(len(quantities), sum(map(int, quantities)))
for index in (0, len(quantities) // 2, len(quantities) - 1):
    print(rows[index]['id'], quantities[index])
\'\'\'
'''+prepare[end:]
begin=prepare.index('shutil.copyfile(prior/');end=prepare.index('payload=quiet',begin)
prepare=prepare[:begin]+'''shutil.copyfile(source/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\\r' not in (quiet/'run.sh').read_bytes()
collector=(source/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1665-fixtures','b1667-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
'''+prepare[end:]
begin=prepare.index("save(quiet/'upload.json'");prepare=prepare[:begin]+'''save(quiet/'upload.json',dict(root='map-slots-b1667-20261125',reference='zip-unpack-b1665-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
source_receipt=read(source/'comparison/quiet/terminal-status.json')['receipt']
assert source_receipt['complete'] and sha(source/'comparison/quiet/observations.tar.xz')==source_receipt['archiveSHA256']
launcher=(source/'quiet.py').read_text(encoding='utf-8').replace('683fcdfa4dbd7f3c12ffadc461698d86584d2a4fce926626a9c7f08954bef52b',source_receipt['archiveSHA256'])
launcher=launcher.replace('lython-b1665-zip-unpack-20261125','lython-b1667-map-slots-20261125').replace('b1665','b1667')
launcher=launcher.replace("os.link(reference/'cpython-worker.py',root/'cpython-worker.py')", "os.link(reference/'cpython-worker.py',root/'cpython-worker.py')")
assert source_receipt['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
report=(source/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-zip-unpack','2026-11-25-map-slots')
report=report.replace('788be8f35','ac9f9211b')
compile(report,'archive.py','exec')
write(lab/'archive.py',report)
print('Verified both full images on the shipment report and two controls.')
'''
compile(prepare,'prepare.py','exec');write('prepare.py',prepare)
shutil.copyfile(z/'allocations.py',r/'allocations.py')
