from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output, run
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior_lab = lab.parent / 'shared-primitive-members-b1966-20261128'
prior = prior_lab / 'comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(prior / 'identity.json')
reference = git('rev-parse', 'HEAD').decode().strip()
assert reference.startswith('164bb0e36')
assert hash_file(prior_lab / 'candidate.patch') == old['sourcePatchSHA256']
git('apply', '--reverse', '--cached', '--check', '--ignore-space-change', str(prior_lab / 'candidate.patch'))
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src')
patch = git('diff', '--binary', reference, '--', 'src')
assert patch.count(b'diff --git ') == 4
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(prior / 'candidate') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}

catalog_path = prior / 'representative.json'
assert hash_file(catalog_path) == old['catalogs']['representative.json']['sha256']
catalog = read(catalog_path)
cases = {case['id']: case for case in catalog['cases']}
canonical = prior_lab / 'canonical.json'
assert hash_file(canonical) == old['canonicalCatalogSHA256']
cases.update({case['id']: case for case in read(canonical)['cases']})

count = 48
definitions = '\n'.join(f'''def normalize_{i}(value: str) -> str:
    fields = {{'label': value.strip().replace('_', '-').upper()}}
    label = fields.get('label', 'unset')
    return label.lower()
''' for i in range(count))
calls = '\n'.join(f"    normalize_{i}(' Item_{i} ')," for i in range(count))
source = definitions + '\nlabels = [\n' + calls + "\n]\nprint('|'.join(labels))\n"
expected = '|'.join(f'item-{i}' for i in range(count)) + '\n'
fixture = json.dumps(dict(size=count, text=None), separators=(',', ':'))
source_path = lab / 'generated-member-report.py'
source_path.write_text(source, encoding='utf-8', newline='\n')
python = '/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13'
source_linux = '/mnt/d/code/Lython/' + source_path.relative_to(repo).as_posix()
golden = run(['wsl', '-d', 'Ubuntu', '--', python, '-I', '-S', '-X', 'utf8', source_linux],
    cwd=repo, capture_output=True, check=True, timeout=25)
assert golden.stdout == expected.encode('utf-8') and not golden.stderr
(lab / 'generated-output.txt').write_bytes(golden.stdout)
generated = 'diagnostic.generated-member-report'
cases[generated] = dict(cases['codecs.utf16.small'], id=generated, family='scripts', category='diagnostic',
    scale='custom', size=count, source=source, fixtureJson=fixture, expectedOutput=expected,
    sourceUtf8Bytes=len(source.encode('utf-8')), expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
    fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0, sourceSha256=digest(source.encode('utf-8')),
    fixtureSha256=digest(fixture.encode('utf-8')), expectedOutputSha256=digest(golden.stdout))

jobs = [[generated, 'compile'], ['scripts.config-edit.small', 'compile-run'], ['loops.integer.small', 'compile']]
catalog['cases'] = [cases[case] for case, _ in jobs]
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': jobs})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
save(pair / 'identity.json', dict(sourceRevision=reference, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Reuse the resolved member receiver across one static return inference.'))
copy2(prior_lab / 'summarize.py', lab / 'summarize.py')
print(reference, 'frozen compiler images with independently checked output')
