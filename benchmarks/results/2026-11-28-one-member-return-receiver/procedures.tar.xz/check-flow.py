from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
donor = lab.parent / 'string-member-facts-b1965-20261128/probe'
probe = lab / 'probe'
probe.mkdir(exist_ok=True)
for name in ('ContractProbe.csproj', 'packages.lock.json'):
    copy2(donor / name, probe / name)
(probe / 'Program.cs').write_text(r'''using System.Reflection;
using System.Text.Json;

var folder = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(Path.Combine(folder, "Lokad.Lython.dll"));
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var budgetType = assembly.GetType("Lokad.Lython.LythonMemoryBudget", throwOnError: true)!;
var allowanceType = assembly.GetType("Lokad.Lython.ILythonMemoryBudget", throwOnError: true)!;
var createBudget = budgetType.GetConstructor([typeof(long?)])!;
var reserved = budgetType.GetProperty("ReservedBytes")!;
var compile = engineType.GetMethod("Compile", [typeof(string), allowanceType, typeof(CancellationToken)])!;
Assembly.LoadFrom(Path.Combine(folder, "Lokad.Utf8Regex.dll"));
Assembly.LoadFrom(Path.Combine(folder, "Lokad.Utf8Regex.PythonRe.dll"));
var adapter = Assembly.LoadFrom(Path.Combine(folder, "Lokad.Lython.Utf8Regex.dll"));
var provider = adapter.GetTypes().Single(t => t.Name == "Utf8RegexProvider").GetProperty("Instance")!.GetValue(null)!;

string[] cases =
[
    "from re import compile as pattern\np = pattern(r'(?P<word>[A-Za-z]+)(\\d+)?')\nm = p.search('apple17')\nreturn m.group('word').lower()",
    "import re\np = re.compile('(a)(b)')\nreturn p.fullmatch('ab').groups()[1].upper()",
    "import re\np = re.compile('a')\nreturn p.fullmatch('a').span()[0].bit_length()",
    "import re\np = re.compile('a')\nreturn p.fullmatch('a', invalid='x')",
    "import re\nm = re.compile('(a)').match('a')\nreturn m.group().upper()",
    "import re\np = re.compile('a')\nreturn p.split('aba')[0].upper()",
    "import re\np = re.compile('a')\nreturn p.sub('b', 'a').strip()",
    "fields = {'label': 'Item'}\nreturn fields.get('label', 'Unset').lower()",
    "fields = {'key': 'first'}\nfields.pop('key')\nreturn fields.get('key', 1).bit_length()",
    "fields = {}\na = fields.setdefault('key', 'value')\nreturn a.upper()",
    "values = [1]\nvalues.append(2)\nreturn values.pop(1).bit_length()",
    "def label(data, fallback):\n    return data.get('name', fallback).lower()\nreturn label({'name': 'KNOWN'}, '')",
    "def trim(value: str):\n    return {'label': value.strip()}.get('label', '').replace('_', '-').lower()\nreturn trim(' A_B ')",
    "values = {'first': 'text'}\nreturn values.get(*('first', None)).startswith('t')",
    "return b'alpha'.decode(*('ascii',)).strip().lower()",
];
var results = new List<object>();
foreach (var useRegex in new[] { false, true })
{
    var engine = useRegex ? Activator.CreateInstance(engineType, [provider])! : Activator.CreateInstance(engineType)!;
    foreach (var capacity in new long[] { 4096, 131072, 2097152 })
    foreach (var source in cases)
    {
        var budget = createBudget.Invoke([capacity]);
        bool valid;
        long admitted;
        JsonElement diagnostics;
        using (var script = (IDisposable)compile.Invoke(engine, [source, budget, CancellationToken.None])!)
        {
            valid = (bool)script.GetType().GetProperty("IsValid")!.GetValue(script)!;
            diagnostics = JsonSerializer.SerializeToElement(script.GetType().GetProperty("Diagnostics")!.GetValue(script));
            admitted = (long)reserved.GetValue(budget)!;
        }
        if ((long)reserved.GetValue(budget)! != 0) throw new InvalidOperationException("Compile owner did not settle.");
        results.Add(new { useRegex, capacity, source, valid, admitted, diagnostics });
    }
}
File.WriteAllText(args[1], JsonSerializer.Serialize(results));
''', encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / 'probe-build.log').open('wb') as log:
    subprocess.run([dotnet, 'build', probe / 'ContractProbe.csproj', '-c', 'Release'], env=env,
        check=True, timeout=60, stdout=log, stderr=subprocess.STDOUT)
program = probe / 'bin/Release/net11.0/ContractProbe.dll'
identity = json.loads((pair / 'identity.json').read_bytes())
outputs = []
for role, image in identity['imageFiles'].items():
    folder = pair / role
    assert {path.name: sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()} == image
    output = lab / f'{role}-flow.json'
    subprocess.run([dotnet, program, folder, output], env=env, check=True, timeout=35)
    outputs.append(output)
assert outputs[0].read_bytes() == outputs[1].read_bytes()
data = json.loads(outputs[0].read_bytes())
assert len(data) == 90 and any(row['valid'] for row in data) and any(not row['valid'] for row in data)
assert any(row['valid'] and row['useRegex'] and 'compile' in row['source'] for row in data)
print(len(data), 'matched diagnostic and admission observations with the exact two compiler images')
