def normalize_0(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_1(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_2(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_3(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_4(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_5(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_6(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_7(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_8(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_9(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_10(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_11(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_12(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_13(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_14(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_15(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_16(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_17(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_18(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_19(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_20(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_21(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_22(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_23(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_24(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_25(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_26(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_27(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_28(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_29(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_30(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_31(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_32(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_33(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_34(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_35(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_36(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_37(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_38(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_39(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_40(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_41(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_42(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_43(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_44(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_45(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_46(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

def normalize_47(value: str) -> str:
    fields = {'label': value.strip().replace('_', '-').upper()}
    label = fields.get('label', 'unset')
    return label.lower()

labels = [
    normalize_0(' Item_0 '),
    normalize_1(' Item_1 '),
    normalize_2(' Item_2 '),
    normalize_3(' Item_3 '),
    normalize_4(' Item_4 '),
    normalize_5(' Item_5 '),
    normalize_6(' Item_6 '),
    normalize_7(' Item_7 '),
    normalize_8(' Item_8 '),
    normalize_9(' Item_9 '),
    normalize_10(' Item_10 '),
    normalize_11(' Item_11 '),
    normalize_12(' Item_12 '),
    normalize_13(' Item_13 '),
    normalize_14(' Item_14 '),
    normalize_15(' Item_15 '),
    normalize_16(' Item_16 '),
    normalize_17(' Item_17 '),
    normalize_18(' Item_18 '),
    normalize_19(' Item_19 '),
    normalize_20(' Item_20 '),
    normalize_21(' Item_21 '),
    normalize_22(' Item_22 '),
    normalize_23(' Item_23 '),
    normalize_24(' Item_24 '),
    normalize_25(' Item_25 '),
    normalize_26(' Item_26 '),
    normalize_27(' Item_27 '),
    normalize_28(' Item_28 '),
    normalize_29(' Item_29 '),
    normalize_30(' Item_30 '),
    normalize_31(' Item_31 '),
    normalize_32(' Item_32 '),
    normalize_33(' Item_33 '),
    normalize_34(' Item_34 '),
    normalize_35(' Item_35 '),
    normalize_36(' Item_36 '),
    normalize_37(' Item_37 '),
    normalize_38(' Item_38 '),
    normalize_39(' Item_39 '),
    normalize_40(' Item_40 '),
    normalize_41(' Item_41 '),
    normalize_42(' Item_42 '),
    normalize_43(' Item_43 '),
    normalize_44(' Item_44 '),
    normalize_45(' Item_45 '),
    normalize_46(' Item_46 '),
    normalize_47(' Item_47 '),
]
print('|'.join(labels))
