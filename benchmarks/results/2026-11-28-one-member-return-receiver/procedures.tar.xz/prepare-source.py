from pathlib import Path

lab = Path(__file__).resolve().parent
frontend = lab.parents[3] / 'src/Lokad.Lython/Frontend'
paths = {name: frontend / f'{name}.cs' for name in (
    'StaticContractEngine', 'StaticRegexReturnResolver', 'StaticBindingEngine.Mutations', 'StaticContracts.CallableMembers')}
texts = {name: path.read_text(encoding='utf-8') for name, path in paths.items()}


def replace(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


engine = texts['StaticContractEngine']
engine = replace(engine, '''        if (StaticRegexReturnResolver.TryResolvePatternMemberCallReturn(call, bindings, out value))
        {
            return true;
        }

        if (StaticRegexReturnResolver.TryResolveMatchMemberCallReturn(call, bindings, out value))
        {
            return true;
        }

        if (TryResolveDictionaryMemberCallReturn(call, bindings, out value))
        {
            return true;
        }

        if (call.Target is MemberExpressionSyntax { Target: var memberReceiver, MemberName: var memberName } &&
            StaticAbstractValueResolver.TryResolve(memberReceiver, bindings, out var receiverValue) &&
            StaticContracts.TryGetMemberReturn(receiverValue, memberName, call.Span, bindings.AnalysisContext, out value))''',
    '''        if (call.Target is not MemberExpressionSyntax { Target: var target, MemberName: var memberName } ||
            !StaticAbstractValueResolver.TryResolve(target, bindings, out var receiver))
        {
            value = default;
            return false;
        }

        switch (receiver.Kind)
        {
            case AbstractValueKind.RegexPattern or AbstractValueKind.RegexMatch
                when StaticRegexReturnResolver.TryResolveMemberCallReturn(call, receiver, memberName, bindings, out value):
            case AbstractValueKind.Dict
                when TryResolveDictionaryMemberCallReturn(call, receiver, memberName, bindings, out value):
                return true;
        }

        if (StaticContracts.TryGetMemberReturn(receiver, memberName, call.Span, bindings.AnalysisContext, out value))''')
engine = replace(engine, 'StaticContracts.TryGetCallableContract(receiverValue, memberName, out var contract)',
    'StaticContracts.TryGetCallableContract(receiver, memberName, out var contract)')
texts['StaticContractEngine'] = replace(engine, '''    private static bool TryResolveDictionaryMemberCallReturn(CallExpressionSyntax call, AbstractState bindings, out AbstractValue value)
    {
        if (call.Target is not MemberExpressionSyntax { Target: var receiverExpression, MemberName: var memberName } ||
            memberName is not ("get" or "pop" or "setdefault") ||
            !StaticAbstractValueResolver.TryResolve(receiverExpression, bindings, out var receiver) ||
            receiver.Kind != AbstractValueKind.Dict ||''',
    '''    private static bool TryResolveDictionaryMemberCallReturn(CallExpressionSyntax call, AbstractValue receiver,
        string memberName, AbstractState bindings, out AbstractValue value)
    {
        if (memberName is not ("get" or "pop" or "setdefault") ||''')

regex = texts['StaticRegexReturnResolver']
regex = replace(regex, '''    public static bool TryResolvePatternMemberCallReturn(CallExpressionSyntax call, AbstractState bindings, out AbstractValue value)
    {
        if (call.Target is not MemberExpressionSyntax { Target: var receiverExpression, MemberName: var memberName } ||
            !StaticAbstractValueResolver.TryResolve(receiverExpression, bindings, out var receiver) ||
            receiver.Kind != AbstractValueKind.RegexPattern ||
            !StaticCallArguments.TryGetConcreteArguments(call, bindings, out var arguments) ||''',
    '''    public static bool TryResolveMemberCallReturn(CallExpressionSyntax call, AbstractValue receiver,
        string memberName, AbstractState bindings, out AbstractValue value)
    {
        if (!StaticCallArguments.TryGetConcreteArguments(call, bindings, out var arguments) ||''')
regex = replace(regex, '''        var summary = receiver.RequireRegexPatternSummary();
        if (memberName is "search" or "match" or "fullmatch")''',
    '''        if (receiver.Kind == AbstractValueKind.RegexPattern)
            return TryResolvePatternMemberCallReturn(receiver, memberName, arguments, bindings, call.Span, out value);

        value = memberName switch
        {
            "group" when arguments.PositionalCount == 0 && arguments.Keywords.Count == 0 => AbstractValue.StringType(call.Span),
            "group" => AbstractValue.Unknown(call.Span),
            "__getitem__" => AbstractValue.Unknown(call.Span),
            // Group arity is pattern-dependent: an empty-tuple shape wrongly rejects
            // literal indexes into stored groups, mirroring groupdict.
            "groups" => AbstractValue.Unknown(call.Span),
            "groupdict" => AbstractValue.Unknown(call.Span),
            "expand" => AbstractValue.StringType(call.Span),
            "start" or "end" => AbstractValue.IntegerType(call.Span),
            "span" => AbstractValue.Tuple(
                new[] { AbstractValue.IntegerType(call.Span), AbstractValue.IntegerType(call.Span) },
                call.Span),
            _ => default
        };

        return value.Kind != default;
    }

    private static bool TryResolvePatternMemberCallReturn(AbstractValue receiver, string memberName,
        ConcreteCallArguments arguments, AbstractState bindings, LythonSourceSpan span, out AbstractValue value)
    {
        var summary = receiver.RequireRegexPatternSummary();
        if (memberName is "search" or "match" or "fullmatch")''')
start = regex.index('    public static bool TryResolveMatchMemberCallReturn(')
end = regex.index('    public static bool TryResolveMatchSubscriptReturn(', start)
regex = regex[:start] + regex[end:]
start = regex.index('    private static bool TryResolvePatternMemberCallReturn(')
end = regex.index('    public static bool TryResolveMatchSubscriptReturn(', start)
assert regex[start:end].count('call.Span') == 6
texts['StaticRegexReturnResolver'] = regex[:start] + regex[start:end].replace('call.Span', 'span') + regex[end:]

texts['StaticBindingEngine.Mutations'] = replace(texts['StaticBindingEngine.Mutations'],
    '''        if (!bindings.TryGet(receiver.Name, out var value) || !StaticContracts.IsMutatingMember(value, member))''',
    '''        if (!bindings.TryGet(receiver.Name, out var value) ||
            !StaticContracts.TryGetCallableContract(value, member, out var contract) ||
            contract.Mutation != StaticMutationKind.MutatesReceiver)''')
texts['StaticBindingEngine.Mutations'] = replace(texts['StaticBindingEngine.Mutations'],
    '''        if (StaticCallArguments.TryGetConcreteArguments(call, bindings, out var arguments) &&
            StaticContracts.TryGetCallableContract(value, member, out var contract) &&
            !contract.AcceptsArgumentShape(arguments))''',
    '''        if (StaticCallArguments.TryGetConcreteArguments(call, bindings, out var arguments) &&
            !contract.AcceptsArgumentShape(arguments))''')
texts['StaticContracts.CallableMembers'] = replace(texts['StaticContracts.CallableMembers'],
    '''    public static bool IsMutatingMember(AbstractValue receiver, string memberName)
        => TryGetCallableContract(receiver, memberName, out var contract) &&
           contract.Mutation == StaticMutationKind.MutatesReceiver;

''', '')

for name, content in texts.items():
    paths[name].write_text(content, encoding='utf-8', newline='\n')
