#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/single-member-return-receiver-b1967-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Diagnostic|FullyQualifiedName~Regex|FullyQualifiedName~Dictionary|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Static|FullyQualifiedName~Binding|FullyQualifiedName~Flow|FullyQualifiedName~Lexical)' > "$lab/ubuntu-net11-whitebox.log" 2>&1
