from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-one-member-return-receiver'
pair = lab / 'comparison'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(pair / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
assert read(pair / 'summary.json')['verifiedTimedBatches'] == 84
receipt = read(pair / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(pair / 'observations.tar.xz')
assert (lab / 'reference-flow.json').read_bytes() == (lab / 'candidate-flow.json').read_bytes()
assert len(read(lab / 'reference-flow.json')) == 90
for target in ('windows-net10', 'windows-net11', 'ubuntu-net11'):
    for suite, count in (('public', 1437), ('whitebox', 178)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz'):
    copy2(pair / name, out / name)
    assert digest(out / name) == digest(pair / name)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.patch', '.sh')}
procedures.update({name: pair / name for name in ('reference-verify.json', 'candidate-verify.json',
    'exit-code.txt', 'archive-receipt.json')})
procedures.update({f'probe/{name}': lab / 'probe' / name for name in ('ContractProbe.csproj', 'Program.cs')})
procedures.update({name: lab / name for name in ('reference-flow.json', 'candidate-flow.json', 'generated-output.txt')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified complete matched worker images, 84 batches, 90 flow observations and three Release targets.')
