from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/typed-csv-text-20261124'
donor = lab.with_name('combined-csv-cpython-20261124')
previous = lab.with_name('short-dictionary-keys-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda file: json.loads(file.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda file: sha(file.read_bytes())


def write(file, source):
    file.write_text(source, encoding='utf-8', newline='\n')


def save(file, data):
    write(file, json.dumps(data,ensure_ascii=False,indent=2)+'\n')


candidate = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()
assert candidate.startswith('b3c447420')
metadata = read(donor/'comparison/quiet/identity.json')
reference = metadata['candidate']
assert set(subprocess.check_output(['git','diff','--name-only',reference,candidate,'--','src'],cwd=tree).decode().splitlines()) == {
    'src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs'}
catalog = read(donor/'comparison/quiet/representative.json')
explicit,typed,quote = catalog['cases']
observer = dict(typed)
observer['id'] = typed['id']+'.observed'
observer['source'] = typed['source'].replace('count = 0\n','count = 0\nobserved = 0\n').replace(
    '        prior = usage.get(', '        observed += len(site)\n        prior = usage.get(').replace(
    'print(count, len(usage))','print(count, len(usage), observed)')
observer['sourceUtf8Bytes'] = len(observer['source'].encode('utf-8'))
observer['sourceSha256'] = sha(observer['source'].encode('utf-8'))
observer['expectedOutput'] = '4096 3 16384\n'
observer['expectedOutputUtf8Bytes'] = len(observer['expectedOutput'].encode('utf-8'))
observer['expectedOutputSha256'] = sha(observer['expectedOutput'].encode('utf-8'))
catalog['cases'] = [typed, observer, explicit, quote]
save(comparison/'representative.json',catalog)
save(comparison/'jobs.json', {'warm': [[case['id'],'warm'] for case in catalog['cases']]})

source = (previous/'prepare.py').read_text(encoding='utf-8')
source = source[source.index('runtime = Path.home()'):].split('\nenum = ')[0]
source = source.replace("write(comparison / 'identity.json', dict(", "save(comparison / 'identity.json', dict(")
source = source.replace('B1547 borrow deferred UTF-8 keys through exact dictionary reads and existing-key updates',
    'B1550 share admitted short text publication between typed and ordinary CSV')
source = source.replace("    for helper in ('ValidatedAllocation', 'Inspect'):", "    for helper in ('ValidatedAllocation',):")
source = source.replace("    subprocess.run([dotnet, image / 'Inspect.dll', comparison / 'representative.json', lab / (role + '-tape.json')],\n        env=env, check=True, timeout=30)\n",'')
notes = lab.parent
proof = metadata
names = [case['id'] for case in catalog['cases']]
exec(source)
(lab/'allocations.py').write_bytes((previous/'allocations.py').read_bytes())

archived = 'benchmarks/results/2026-11-24-csv-unpack-bindings/'
tracked = lambda name: subprocess.check_output(['git','show','origin/master:'+archived+name],cwd=repo)
receipt = json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
old = sha(gzip.decompress(tracked('reference-core.dll.gz')))
assert old==json.loads(tracked('identity.json'))['imageFiles']['reference']['Lokad.Lython.dll']
save(lab/'verified-replicas.json',[dict(path='csv-unpack-bindings-b1544-20261124/reference/Lokad.Lython.dll',
    sha256=old, observationSHA256=receipt['archiveSHA256'], trackedArchive=archived)])

source = previous/'comparison/quiet'
worker = (source/'collect.py').read_text(encoding='utf-8').replace('b1547-', 'b1550-')
worker = worker.replace("'csv-unpack-bindings-b1544-20261124'/'reference'", "'combined-csv-cpython-b1549-20261124'/'candidate'")
worker = worker.replace('    time.sleep(3)  # Outside clocks;', '    time.sleep(12)  # Outside clocks;')
worker = worker.replace('        time.sleep(3)\n','        time.sleep(8)\n')
worker = worker.replace('warmupSeconds=12,','warmupSeconds=8,').replace('accumulate 12 seconds','accumulate 8 seconds')
compile(worker,'collect.py','exec')
write(quiet/'collect.py',worker)
(quiet/'run.sh').write_bytes((source/'run.sh').read_bytes())
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in ('identity.json','representative.json','jobs.json'):
        archive.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        archive.add(quiet/name,arcname=name)
    archive.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='typed-csv-text-b1550-20261124',reference='combined-csv-cpython-b1549-20261124',
    payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(previous/'quiet.py').read_text(encoding='utf-8').replace('b1547-short-dictionary-keys','b1550-typed-csv-text').replace('b1547-','b1550-')
launch=launch.replace("reference/'reference'", "reference/'candidate'").replace('seconds=255','seconds=207')
launch=launch.replace('RuntimeMaxSec=335','RuntimeMaxSec=270')
write(lab/'quiet.py',launch)
(lab/'summarize.py').write_bytes((previous/'summarize.py').read_bytes())
