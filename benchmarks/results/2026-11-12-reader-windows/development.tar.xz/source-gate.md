# R271 — immutable line windows, concrete source gate

Current code: reader InstallWindow borrows its private raw prefix for unchanged
UTF-8; ReleaseWindow compacts that prefix and Pull refills the same array.
CopyWindowRange allocates an independent PyString/byte array for every long line.
Those copies are real: native search allocates about182KB/command, 1025 lines.
Sharing the current mutable raw array directly would corrupt retained strings.

Prior R54/R60 general views are not replayed. They incurred global wrapper/access
costs, including eight extra bytes or hash-cache changes, and modest/adverse
whole-script results. Current inline-string storage introduces a materially
different option: on array-backed strings, its existing managed inline word is
unused and can store a window byte offset. Use a third value in the existing
storage tag, preserving ordinary wrapper size, zero-offset array reads and hash
caching. No new field, subclass, owner object, refcount, trace or storage framework.

Expected deletion: per-line byte-array allocation/copy for non-inline complete
window ranges. Preserve independent small-inline strings and accumulated reads.
All UTF-8 span/memory, rune/index/hash/format/regex operations must respect relative
window positions. A view refunds only its shell/cache; its backing remains funded.

Ownership: before allocating a first view, establish the existing execution owner
for the full raw/decoded capacity, including metadata. Reader cleanup must no
longer refund that transferred backing. Conservative retention through the bounded
command/result lifetime is explicit and may reject earlier. No arbitrary-reference
reclamation or cumulative-allocation replacement of host-driven batching.

Raw storage becomes immutable once shared. On the next refill, admit a new raw
array and replacement overlap, copy only carry, then publish it; never mutate the
shared array. Unshared raw buffers retain reuse. ReleaseWindow/close perform no
allocation: retain a carry offset until the next actual decode needs replacement.
All current users and pending reads/close complete before private owner cleanup.

Gate before promotion: actual prior-window aliases survive refills/seek/close;
first refusal/cancellation precedes new allocation and cursor mutation; old and
new buffer overlap remains charged; two executions and retained results share the
host allowance and disposal returns baseline. Reuse read/refund/encoding/gzip
regressions, add only externally useful alias/ownership cases. Check all string
consumers and independent UTF-8/UTF-16/CRLF/astral file results; no offset tricks,
unsafe APIs or host bypass.

One short complete search/text/JSON/CSV/report allocation comparison, then a
bounded quiet affected/control confirmation if justified. Preserve global controls
and original/adverse results. Allocation alone does not establish CPU benefit.
Full platform/stress/installed consumers only after coherent retention. If the
representation requires new global state or unfunded aliases, stop/revise before
implementation; no return to the old general-view patch by another name.
