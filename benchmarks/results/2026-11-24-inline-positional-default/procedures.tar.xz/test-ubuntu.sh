set -eu
lab="$PWD/.git/agent-notes/review-20261031/inline-positional-default-20261124"
export DOTNET_ROOT="$HOME/.dotnet"
framework="${1:-net11.0}"
filter='FullyQualifiedName~Function|FullyQualifiedName~Default|FullyQualifiedName~Executable|FullyQualifiedName~Closure|FullyQualifiedName~Admission|FullyQualifiedName~Cancellation|FullyQualifiedName~PyTuple|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~Generator|FullyQualifiedName~Lambda|FullyQualifiedName~NamedTuple'
if [ "$framework" = net10.0 ]; then
    filter='FullyQualifiedName~FunctionDefault|FullyQualifiedName~NativeDefinitionPair|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~FunctionBindingLifetime'
fi
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$framework-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f "$framework" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -65 "$log"
        exit 1
    fi
done
