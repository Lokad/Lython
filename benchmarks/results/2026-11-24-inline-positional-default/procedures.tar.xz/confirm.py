from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
output = lab / 'confirmation'
output.mkdir(exist_ok=True)
remote = '/home/lokad/lython-bench-checks'
unit = 'lython-b1655-inline-default-confirmation-20261124'
location = 'inline-default-confirmation-b1655-20261124'
original = 'inline-positional-default-b1655-20261124'
host = 'lokad@20.166.121.73'
common = ['-i', str(Path.home() / '.ssh/id_lython-bench.pem'), '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', *common, host, 'python3 -']
scp = ['C:/Windows/System32/OpenSSH/scp.exe', *common]
now = lambda: datetime.datetime.now(datetime.timezone.utc)
sha = lambda b: hashlib.sha256(b).hexdigest()
prefix = "from pathlib import Path\nimport json,fcntl,hashlib,os,subprocess,shutil\n"
prefix += f"base=Path({remote!r}).resolve(); root=base/{location!r}; original=base/{original!r}; unit={unit!r}\n"
prefix += "digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()\n"


def invoke(script):
    result = subprocess.run(ssh, input=prefix + script, encoding='utf-8', capture_output=True, timeout=35)
    assert result.returncode == 0, (result.stdout, result.stderr)
    return result.stdout


if sys.argv[1] == 'launch':
    previous = json.loads((quiet/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
    payload = {name:(output/name).read_text(encoding='utf-8') for name in ('collect.py','identity.json','jobs.json','representative.json','run.sh')}
    duplicates=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))
    script = f"payload={payload!r}; duplicates={duplicates!r}; checksum={previous['archiveSHA256']!r}\n" + """
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(original/'observations.tar.xz')==checksum
 assert not (original/'guest-fixtures').exists()
 block=os.statvfs(base).f_frsize
 staged=sum((len(content.encode('utf-8'))+block-1)//block*block for content in payload.values())
 minimum=staged+3840*1024
 free=shutil.disk_usage(base).free
 free_after=free; plans=[]
 for row in duplicates:
  if free_after>=minimum:break
  prior=base/row['location']
  raw=prior/'confirmation/confirmation.json'
  archive=prior/'observations.tar.xz'
  marker=prior/'archive-receipt.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(base) and raw.stat().st_nlink==1
  if (prior/'guest-fixtures').exists() or not marker.is_file():continue
  info=json.loads(marker.read_text())
  if not info.get('allWorkersJoined') or not info.get('archivedAndVerifiedUnderLease'):continue
  if raw.stat().st_size!=row['bytes'] or not archive.is_file():continue
  if digest(archive)!=row['archiveSHA256'] or digest(raw)!=row['rawSHA256']:continue
  plans.append((row,raw))
  free_after+=raw.stat().st_blocks*512
 print(json.dumps(dict(freeBefore=free,available=free_after,required=minimum,verifiedDuplicates=[row for row,_ in plans])))
 assert free_after>=minimum
 for _,raw in plans:raw.unlink()
 assert shutil.disk_usage(base).free>=minimum
 assert not root.exists()
 root.mkdir()
 for name, content in payload.items(): (root/name).write_text(content,encoding='utf-8')
 identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
 for role, files in identity['imageFiles'].items():
  image=root/role
  image.mkdir()
  assert len(files)==32
  for name, sha in files.items():
   item=original/role/name
   assert digest(item)==sha
   os.link(item,image/name)
 os.link(original/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 assert digest(root/'jobs.json')==identity['catalogs']['jobs.json']['sha256']
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 assert shutil.disk_usage(base).free>=3584*1024
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=250','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    receipt = invoke(script)
    (output / 'launch.log').write_text(receipt, encoding='utf-8')
    (output / 'observe-not-before').write_text((now()+datetime.timedelta(seconds=170)).isoformat(), encoding='utf-8')
    print(unit, receipt)
else:
    assert sys.argv[1] == 'retrieve'
    assert now() >= datetime.datetime.fromisoformat((output / 'observe-not-before').read_text(encoding='utf-8'))
    state = invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=root/'exit-code.txt'
  receipt=root/'archive-receipt.json'
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    status = json.loads(state)
    print(state)
    (output / ('status-' + now().strftime('%H%M%S') + '.json')).write_text(state, encoding='utf-8')
    if status.get('receipt') is not None:
        archive = output / 'observations.tar.xz'
        subprocess.run(scp+[host+':'+remote+'/'+location+'/'+archive.name,archive],check=True,timeout=35)
        assert sha(archive.read_bytes()) == status['receipt']['archiveSHA256']
        (output / 'terminal-status.json').write_text(state, encoding='utf-8')
