from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('terminal-backed-operand-layout-20261124')
donor_quiet = donor/'comparison/quiet'
definitions = lab.with_name('shared-function-definition-descriptor-20261124')/'comparison/quiet'
older = lab.with_name('closed-definition-construction-20261124')/'comparison/quiet'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert revision.startswith('ad893eb3b')
patch = lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo)==patch.read_bytes()
assert b'positional.HasPrivatePositionalDefault' in patch.read_bytes()
base = read(donor_quiet/'identity.json')
core = 'Lokad.Lython.dll'
original = base['imageFiles']['candidate']
assert len(original)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==original
builds = {role:lab/f'{role}-build/bin/Lokad.Lython/release_net11.0'/core for role in ('reference','candidate')}
images = {role:original | {core:sha(build)} for role,build in builds.items()}
assert images['reference'][core] != images['candidate'][core]
for role,files in images.items():
    image = lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(builds[role] if name==core else donor/'candidate'/name,image/name)
    assert {p.name:sha(p) for p in image.iterdir()}==files

catalog = read(definitions/'representative.json')
rows = {r['id']:r for r in catalog['cases']}
rows.update({r['id']:r for r in read(older/'representative.json')['cases'] if r['id'] not in rows})
rule='scripts.rule-default-closures'
eager='scripts.annotated-rule-closures'
postponed='scripts.annotated-rule-closures.nested-factories.postponed'
generated='diagnostic.generated-ordinary-definitions'
invoice='scripts.csv-invoice.method-policy.quoted-control'
catalog['cases']=[rows[k] for k in (rule,eager,postponed,generated,invoice)]
catalog['fixtureEncoding']='Canonical base64 file maps when needed. Rule and generated definitions have no file fixture.'
expected=quiet/'representative.json'
save(expected,catalog)
save(quiet/'jobs.json',{'warm':[[rule,'warm'],[eager,'warm'],[generated,'warm'],[invoice,'warm'],[postponed,'warm'],[rule,'compile-run']]})
identity=dict(sourceRevision=revision,comparisonRevision=revision,sourcePatchSHA256=sha(patch),
    purpose='Retain evaluated singleton positional defaults on the function and materialize the canonical tuple on demand',
    imageFiles=images,expectedCPythonSHA256=base['expectedCPythonSHA256'],cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',identity)
collector=(donor_quiet/'collect.py').read_text(encoding='utf-8').replace('b1653-fixtures','b1655-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(donor_quiet/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python=Path('C:/Python313/python.exe')
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role in images:
    output=lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',expected,
        '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',output],env=env,cwd=repo,check=True,timeout=75)
    checked=read(output)
    assert checked['state']=='Completed' and checked['caseCount']==5
    assert checked['catalogSha256']==sha(expected) and checked['launched']['library']['sha256']==images[role][core]

payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        package.add(quiet/name,arcname=name)
    for role,path in builds.items():
        package.add(path,arcname=f'{role}-core.dll')
save(quiet/'upload.json',dict(root='inline-positional-default-b1655-20261124',reference='terminal-backed-operand-layout-b1653-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launch=(donor/'quiet.py').read_text(encoding='utf-8')
receipt=read(donor_quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(donor_quiet/'observations.tar.xz')==receipt['archiveSHA256']
launch=launch.replace('c038cd82b5ef299cee1f5c7278b64efa6c05ef73ee8fe9cba4977259292af199',receipt['archiveSHA256'])
launch=launch.replace('terminal-backed-operand-layout-20261124','inline-positional-default-20261124').replace('b1653-','b1655-')
compile(launch,'quiet.py','exec')
(lab/'quiet.py').write_text(launch,encoding='utf-8',newline='\n')
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
print('Verified each 32-file image and five complete CPython goldens.')