from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
out = repo/'benchmarks/results/2026-11-24-inline-positional-default'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
identity = read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--','src','tests'],cwd=repo)==(lab/'candidate.patch').read_bytes()
for role,files in identity['imageFiles'].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
    for result, expected in ((lab/f'comparison/{role}-verify.json',5),(lab/f'{role}-boundary-verification.json',2)):
        verified=read(result)
        assert verified['state']=='Completed' and verified['caseCount']==expected
        assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
for header in ('windows','ubuntu'):
    for target in ('net11.0','net10.0'):
        for suite in ('Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests'):
            text=(lab/f'{header}-{target}-{suite}.log').read_text(encoding='utf-8-sig')
            assert 'Failed:     0, Passed:' in text
package_names = [
    'candidate.patch','freeze.py','prepare.py','prepare.log','allocations.py','archive.py','package-evidence.py',
    'quiet.py','recover-stage-space.py','retired-stage-custody.json','boundary-catalog.json','verify-boundaries.py','verify-boundaries.log',
    'comparison/reference-verify.json','comparison/candidate-verify.json','reference-boundary-verification.json',
    'candidate-boundary-verification.json','reference-allocation-final.json','candidate-allocation-final.json',
    'reference-build.log','candidate-build.log','windows-literal-default-failure.log','ubuntu-literal-default-failure.log',
    'initial/candidate.patch','initial/identity.json','initial/allocation-summary.json',
    'test-ubuntu.sh','windows-debug.log','prepare-confirmation.py','confirm.py','archive-confirmation.py','confirmation/launch.log','comparison/quiet/storage-custody.json','comparison/quiet/launch.log','comparison/quiet/upload.json',
    'comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/representative.json','comparison/quiet/jobs.json',
]
package_names.extend(p.name for p in sorted(lab.glob('*net1*.log')))
assert len(package_names)==len(set(package_names))
for name in ('identity.json','core-summary.json','quiet-summary.json'):
    assert not (out/name).is_symlink()
shutil.copyfile(quiet/'identity.json',out/'identity.json')
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as archive:
    for name in package_names:
        archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert set(archive.getnames())==set(package_names)
    for name in package_names:
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha(lab/name), name
print('Verified archived source, ownership, tests and procedure records.')