from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/call-operands-r470'
paths = ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Inputs.cs',
         'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']
patch = subprocess.check_output(['git', '-C', str(work), 'diff', '--', *paths])
assert patch and len(subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only'], text=True).splitlines()) == 2
(r / 'prototype.patch').write_bytes(patch)
subprocess.run(['git', '-C', str(work), 'restore', '--', *paths], check=True)
assert not subprocess.check_output(['git', '-C', str(work), 'diff'], text=True).strip()
out = repo / 'benchmarks/results/2026-11-17-subscript-entry'
out.mkdir(exist_ok=False)
decision = 'Withdraw: warm floating benefit, but run-once elapsed and wider CPU adverse with flat allocation. No permanent ban or unchanged retiming.'
summary = json.loads((r / 'summary.json').read_text(encoding='utf-8'))
summary.update(retentionDecisionPending=False, decision=decision)
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
for name in ['allocation-summary.json', 'candidate-sources.tar.xz']:
    shutil.copyfile(r / name, out / name)
shutil.copyfile(r / 'frozen/identity.json', out / 'identity.json')
for source, target in [(r / 'prototype.patch', out / 'prototype.patch.gz'),
                       (r / 'frozen/candidate/Lokad.Lython.dll', out / 'candidate-core.dll.gz')]:
    with gzip.open(target, 'wb') as stream:
        stream.write(source.read_bytes())
    with gzip.open(target, 'rb') as stream:
        assert stream.read() == source.read_bytes()
receipt = json.loads((r / 'quiet/archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r / 'quiet/observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json']:
    shutil.copyfile(r / 'quiet' / name, out / name)
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for p in list(r.glob('*.py')) + list(r.glob('*.json')) + list(r.glob('*.log')):
        archive.add(p, arcname=p.name)
    for p in (r / 'quiet').iterdir():
        if p.is_file() and p.name not in ['payload.tgz', 'observations.tgz']:
            archive.add(p, arcname='quiet/' + p.name)
(out / 'README.md').write_text('''# Single subscript entry: withdrawn

R474/B885, 2026-11-17 UTC. Qualified dc480d38/frozen5ecb2599 versus private
two-file prototype d39419ba. **Withdraw both production edits.** Receiver/key
entry duplication and an unused call output were removed, retaining native
integer, existing dictionary cache and Python protocol consumers. No new owner,
metadata, policy or public API. Allocation and numeric accounted peak stayed flat.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate control spread |
| --- | --- | ---: | ---: | ---: |
| Floating JSON numeric report | Warm | −5.30..−1.89% | −5.28..−0.71% | 3.21 / 0.38% |
| Same | Compile and execute once | **+0.47..+2.19%** | **+2.81..+3.24%** | 1.62 / 0.09% |
| Integer numeric report | Warm | −3.70..+8.26% | −3.61..+10.11% | 6.28 / 5.77% |
| Helper text control | Warm | −0.38..+0.75% | −2.16..+0.82% | 1.11 / 0.03% |
| Floating report | Compilation | −1.38..+2.72% | −2.39..+0.45% | 0.89 / 3.24% |

The warm benefit remains evidence. The run-once priority, adverse wider CPU and
flat allocation do not justify this shape. Integer results remain uncertain;
this does not resolve R471's earlier integer debt. No causal diagnosis, permanent
design ban or further unchanged-source timing. Source simplicity alone does not
establish a CPU improvement.

Five jobs took192.24s on the quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3 VM,
natural workstation GC and normal tiering. Four independent processes/job,
interleaved6s full-request warmups and five rotated approximately0.5s samples.
Ranges pair all process medians; they are not confidence intervals. Warm includes
synchronous Run, mediated RAM I/O, complete stdout/file goldens and prior-result
cleanup; excludes compile/startup/reset/protocol/final cache teardown. Fresh adds
compilation/compiled-owner disposal; external CPU is wider. No async, CPython,
RSS or embedding-tail claim.

Both actual Windows.NET11/10 passed153public/20internal focused checks, including
real suspended indexing, cancellation, retained descriptors/aliases, refusal and
cleanup. Copied32file images passed actual-worker3case goldens for each source
and13candidate goldens. Natural-GC allocation diagnostics restore every shared
budget baseline; numeric accounted peak906,718B unchanged. Source snapshot,
nonincremental freeze build and checks are preserved. No tests specific to the
discarded architecture were added. Qualified production remains dc480d38; full
unchanged platform qualification is not repeated.

All image/golden/quiet/Closed/exit/join/archive checks passed, RAM fixtures removed
and terminal cached. Fresh path/UID/hash/link/all-alias proofs retired only
committed old replicas (6,165,233B), preserving current images/toolchains and
254/252MiB staging/final floors. No staging failure in this collection.
Publication remains held; continue the larger aggregation/frame source gate.

[Summary](summary.json), [allocation](allocation-summary.json),
[raw observations](observations.tgz), [custody](archive-receipt.json),
[exact sources](candidate-sources.tar.xz), [prototype](prototype.patch.gz),
[core](candidate-core.dll.gz), [identity](identity.json),
[procedures/checks](procedures-and-checks.tar.xz).
''', encoding='utf-8', newline='\n')
with (repo / 'benchmarks/EXPERIMENTS.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
[R474/B885 single subscript entry](results/2026-11-17-subscript-entry/README.md):
withdraw both production edits. Floating warm−5.30..−1.89% with supporting CPU,
but fresh+0.47..+2.19%/widerCPU+2.81..+3.24%; runtime allocation flat. Integer
controls moving, prior debt unresolved. Exact source/core, all observations and
focused153public/20internal checks per actual target preserved; all VM users
joined and RAM removed. No new architecture tests/dormant handlers. Qualified
runtime unchanged, no repeated full qualification or publication. Assess larger
existing generator batch lifetime rather than another speculative input selector.
''')
print('R474 withdrawn; full evidence preserved; runtime unchanged.')
