from pathlib import Path
r=Path(__file__).parent;old=r.parent/'global-bindings-r473'
source=(old/'freeze.py').read_text(encoding='utf-8');a=source.index('expected=[');b=source.index('\nassert sorted(different)',a)
source=source[:a]+"expected=['Runtime/LythonRuntime.Executable.Inputs.cs','Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']"+source[b:]
source=source.replace('PrivateR473 ondc480d38, seven production files: immutable module slot facts and shared guarded resolution; no cached values','PrivateR474 onc06bc334, two production files: one subscript entry, original numeric/cache/protocol consumers and ownership; no new metadata/owner/backend')
(r/'freeze.py').write_text(source,encoding='utf-8',newline='\n')
print('Prepared existing freeze/golden/allocation procedure for two-file subscript consolidation.')
