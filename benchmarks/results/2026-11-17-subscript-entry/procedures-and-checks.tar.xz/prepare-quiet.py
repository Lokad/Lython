from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'global-bindings-r473';q=r/'quiet';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/subscript-entry-b885-20261117';f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
shutil.copyfile(old/'quiet/collect.py',q/'collect.py');shutil.copyfile(old/'quiet/archive-owned.py',q/'archive-owned.py')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/global-bindings-b883-20261117',remote),encoding='utf-8',newline='\n')
ref=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifieddc480d38/frozen5ecb2599 versus privateR474 onc06bc334/frozen'+candidate,purpose='One subscript entry replaces speculative numeric selector plus general reread; exact index/cache/protocol consumers and ownership unchanged. Complete floating warm/fresh/compile, integer affected shape, helper text control.',coreSHA256={'reference':ref,'reference-control':ref,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['diagnosticCatalogSHA256'],catalogInitialization='Same verified3case catalog, existing workers/protocol; interleaved6s full-request warmup/process, five rotated samples.',normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll')
groups=[]
canonical='benchmarks/results/2026-11-17-module-global-bindings/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
groups.append(dict(paths=['global-bindings-b883-20261117/candidate/Lokad.Lython.dll','global-binding-control-b884-20261117/candidate/Lokad.Lython.dll'],bytes=len(data),links=2,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,withdrawnPrototypeOnly=True))
canonical='benchmarks/results/2026-11-17-module-global-bindings/first-pair/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
groups.append(dict(paths=['global-bindings-b883-20261117/confirmation/confirmation.json'],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b885-subscript-entry-20261117',source='/home/lokad/lython-bench-checks/global-binding-control-b884-20261117',sourceRole='reference',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['diagnosticCatalogSHA256'],catalogSHA256=f['diagnosticCatalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("source/'catalog.json'","source/'representative.json'").replace('lython-b883-fixtures','lython-b885-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('module-binding','subscript-entry'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B883','B885'),encoding='utf-8',newline='\n')
shutil.copyfile(old/'summarize.py',r/'summarize.py')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared5jobs/same3case catalog; stage',c['unpackedBytes'],'retired only committed withdrawn core/raw',sum(g['bytes']for g in groups),'candidate',candidate)
