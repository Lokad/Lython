#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-integer-continuations-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/prepared-integer-continuations-20261122
white='Category!=Stress&(FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ExecutableJumpTarget|FullyQualifiedName~ExecutableInstruction|FullyQualifiedName~ExecutableAugmented|FullyQualifiedName~DirectOperand|FullyQualifiedName~IntegerBinaryAdmission|FullyQualifiedName~IntegerAdditionAdmission|FullyQualifiedName~CsvParserCancellation|FullyQualifiedName~ExecutableAsyncIteratorCleanup)'
public='Category!=Stress&(FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~NumericAugmented|FullyQualifiedName~OperandReadFailure|FullyQualifiedName~IntegerBinarySemantics|FullyQualifiedName~DirectGlobalOperand|FullyQualifiedName~NumericProtocolContract|FullyQualifiedName~CsvNumericReader|FullyQualifiedName~CsvDelayedHost|FullyQualifiedName~RangeSlotTransport|FullyQualifiedName~AdmissionFailureCommand)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path /tmp/lython-prepared-integer-b1359 --verbosity quiet > "$dir/white-ubuntu.log" 2>&1 || { tail -45 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path /tmp/lython-prepared-integer-b1359 --verbosity quiet > "$dir/public-ubuntu.log" 2>&1 || { tail -45 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"