from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()

def pushed(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)

copies = {}
for name, directory, archived_core in [
    ("shared-arithmetic-operand-20261122", "2026-11-22-shared-arithmetic-operand", True),
    ("direct-range-cursor-20261122", "2026-11-22-direct-range-cursors", True),
]:
    prior = lab.parent / name
    tracked = f"benchmarks/results/{directory}/"
    root = Path(read(prior / "quiet/config.json")["root"]).name
    receipt = read(prior / "quiet/archive-receipt.json")
    image = prior / "frozen/candidate"
    files = read(prior / "quiet/identity.json")["imageFiles"]["candidate"]
    assert len(files) == 32
    assert all(hash_bytes((image / file).read_bytes()) == expected for file, expected in files.items())
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
    raw = hash_bytes(pushed(tracked + "observations.tgz"))
    assert raw == receipt["archiveSHA256"]
    if archived_core:
        assert hash_bytes(gzip.decompress(pushed(tracked + "candidate-core.dll.gz"))) == files[core]
    copies[root] = dict(archive=tracked, bytes=(image / core).stat().st_size, coreSHA256=files[core],
        archiveSHA256=raw, authoritativeImageSHA256=files, authoritativeImage=str(image))

source = '''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
base=Path('/home/lokad/lython-bench-checks')
copies=OWNED_COPIES
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    proofs=[]
    for root_name,witness in copies.items():
        root=base/root_name
        core=root/'candidate/Lokad.Lython.dll'
        if not core.exists(): continue
        archive=root/'observations.tgz'
        assert core.resolve()==core and sha(core)==witness['coreSHA256']
        assert sha(archive)==witness['archiveSHA256']
        info=core.lstat()
        assert info.st_size==witness['bytes']
        paths=[]
        for folder,_,names in os.walk(base):
            for name in names:
                path=Path(folder)/name
                record=path.lstat()
                if (record.st_dev,record.st_ino)!=(info.st_dev,info.st_ino): continue
                assert path.resolve()==path and stat.S_ISREG(record.st_mode) and record.st_uid==os.getuid()
                paths.append(str(path.relative_to(base)))
        assert len(paths)==info.st_nlink
        proofs.append(dict(paths=sorted(paths),bytes=info.st_size,links=info.st_nlink,sha256=witness['coreSHA256'],
            archives={str(archive.relative_to(base)):witness['archiveSHA256']},optional=False))
    print(json.dumps(dict(free=shutil.disk_usage(base).free,proof=proofs),indent=2))
'''.replace("OWNED_COPIES", repr(copies))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
proof = json.loads(subprocess.check_output(ssh, input=source, encoding="utf-8", timeout=35))
proof["witnesses"] = copies
(lab/"retire-proof.json").write_text(json.dumps(proof, indent=2)+"\n", encoding="utf-8", newline="\n")
print(proof["free"], proof["proof"])
