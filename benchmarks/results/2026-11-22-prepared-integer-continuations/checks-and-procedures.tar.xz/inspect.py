from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(".git/agent-notes/review-20261031/prepared-integer-continuations-20261122").resolve()
template=lab.parent/"arithmetic-operand-transport-20261122/bin/Release/net11.0"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/"identity.json")
catalog=lab/"shape-catalog.json"
cases=[{"id":c["id"],"source":c["source"]} for c in read(lab/"representative.json")["cases"]]
cases.extend([
 {"id":"protected-chain","source":"def f(a,b,c):\n try: return (a*b+5)//c\n finally: print('closed')\nprint(f(7, 13, 9))\n"},
 {"id":"conditional-chain","source":"def f(a,b,c):\n return (a*b if c else a+b)+c\nprint(f(7,13,9), f(7,13,0))\n"},
 {"id":"published-chain","source":"def f(a,b,c):\n result=a*b\n alias=result\n return result+c, alias is result\nprint(f(7,13,9))\n"},
])
write(catalog,{"cases":cases})
sdk=Path.home()/".dotnet11"
environment=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
data={}
shape_worker_files={}
for role,image_files in identity["imageFiles"].items():
 assert len(image_files)==32 and {n:sha(lab/"frozen"/role/n) for n in image_files}==image_files
 image=lab/"shape-workers"/role
 image.mkdir(parents=True,exist_ok=True)
 for name in ("Inspect.dll","Inspect.deps.json","Inspect.runtimeconfig.json"):
  shutil.copyfile(template/name,image/name)
 shutil.copyfile(lab/"frozen"/role/"Lokad.Lython.dll",image/"Lokad.Lython.dll")
 shape_worker_files[role]={p.name:sha(p) for p in image.iterdir()}
 assert shape_worker_files[role]["Lokad.Lython.dll"]==image_files["Lokad.Lython.dll"]
 out=lab/f"{role}-shape.json"
 subprocess.run([sdk/"dotnet.exe",image/"Inspect.dll",catalog,out],env=environment,check=True,timeout=45)
 data[role]=read(out)
 assert data[role]["coreSHA256"]==image_files["Lokad.Lython.dll"]
 assert {p.name:sha(p) for p in image.iterdir()}==shape_worker_files[role]
enum=Path("src/Lokad.Lython/Frontend/ExecutableScript.cs").read_text(encoding="utf-8").split("internal enum ExecutableOpCode",1)[1].split("}",1)[0]
binary=[s.strip(" \n{") for s in enum.split(",") if s.strip(" \n{")].index("Binary")
cases=[]
for row in data["candidate"]["rows"]:
 marks=[]
 for code in row["codes"]:
  tape=code["tape"]
  first_temp=len(code["locals"])
  for index,current in enumerate(tape):
   if current["<OpCode>k__BackingField"]!=binary or current["_primaryOperand"]>=0:continue
   assert current["_liveExtent"]>=0 and index+1<len(tape)
   nxt=tape[index+1]
   slot=current["_resultSlot"]
   assert nxt["<OpCode>k__BackingField"]==binary and nxt["_resultSlot"]==slot
   assert (nxt["_inputStart"]==slot and nxt["_secondaryOperand"]<first_temp) or (nxt["_secondaryOperand"]==slot and nxt["_inputStart"]<first_temp)
   current["_primaryOperand"] &= 0x7fffffff
   marks.append({"code":code["name"],"index":index,"line":current["<Span>k__BackingField"]["Line"]})
 cases.append({"id":row["id"],"links":marks})
assert data["candidate"]["rows"]==data["reference"]["rows"]
assert len(cases)==len(data["reference"]["rows"])==10
count=sum(len(r["codes"]) for r in data["reference"]["rows"])
write(lab/"shape-summary.json",dict(codeObjects=count,comparison="Only existing Binary operator metadata bits differ",cases=cases,
 catalogSHA256=sha(catalog),shapeWorkerFiles=shape_worker_files))
print(f"{count} code objects retain the exact executable layout after masking {sum(len(r['links']) for r in cases)} prepared links.")
for case in cases: print(case["id"],len(case["links"]))
