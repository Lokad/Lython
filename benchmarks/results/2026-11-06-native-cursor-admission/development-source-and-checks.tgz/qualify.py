from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys
root=Path(__file__).parent;repo=Path('D:/code/Lython');old=root.parent/'adapter44';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
checks={}
def run(label,args):
    log=root/(label+'.log')
    with log.open('w',encoding='utf-8') as output:r=subprocess.run([env['DOTNET_HOST_PATH'],*args,*props],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8');print(label,r.returncode,text[-1100:],flush=True)
    if r.returncode:sys.exit(r.returncode)
    m=re.search(r'Passed:\s+(\d+)',text)
    checks[label]={'passed':int(m[1])} if m else {'exitCode':r.returncode}
run('build-internal',['build','tests/Lokad.Lython.Tests','-c','Release','--nologo','--tl:off'])
manifest=json.loads((root.parent/'adapter40/workflow-fixture-manifest.json').read_text(encoding='utf-8'))
for relative,files in manifest.items():
    source=repo/'tests/Fixtures'/relative
    for name,digest in files.items():assert sha(source/name)==digest
    for framework in ['net11.0','net10.0']:
        target=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}/Fixtures'/relative
        assert not target.exists();shutil.copytree(source,target)
link=root/'tests/Lokad.Lython.WorkerFixture/bin/Release';link.parent.mkdir(parents=True)
subprocess.run(['cmd','/c','mklink','/J',str(link),str(root/'out/Lokad.Lython.WorkerFixture/Release')],check=True,capture_output=True)
filters=json.loads((old/'filters.json').read_text(encoding='utf-8'))
for framework in ['net11.0','net10.0']:
    for suite,selection in [('internal',filters['native']),('public',filters['public']+'|FullyQualifiedName~CursorAdmissionTests')]:
        project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
        run(suite+'-'+framework,['test',project,'-c','Release','-f',framework,'--no-build','--no-restore','--filter',selection])
    folder=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}'
    checks[framework+'-loadedFiles']={name:sha(folder/(name+'.dll')) for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']}
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'));identity['providerSHA256']=sha(root/'Utf8RegexProvider.cs')
(root/'qualification.json').write_text(json.dumps({'identity':identity,'checks':checks,'limitations':'Private immutable development adapter only; normal pin/source unchanged; no final released/safety/whole-script CPU claim'},indent=2)+'\n',encoding='utf-8')
