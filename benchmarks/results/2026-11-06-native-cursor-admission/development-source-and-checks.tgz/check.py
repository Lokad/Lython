from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).parent
repo=Path('D:/code/Lython')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
def run(label,args):
    log=root/(label+'.log')
    with log.open('w',encoding='utf-8') as output:
        result=subprocess.run([env['DOTNET_HOST_PATH'],*args,*props],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    print(label,result.returncode,log.read_text(encoding='utf-8')[-1300:],flush=True)
    if result.returncode:sys.exit(result.returncode)
run('build-public',['build','tests/Lokad.Lython.PublicApi.Tests','-c','Release','--nologo','--tl:off'])
for framework in ['net11.0','net10.0']:
    run('new-'+framework,['test','tests/Lokad.Lython.PublicApi.Tests','-c','Release','-f',framework,'--no-build','--no-restore','--filter','Category!=Stress&FullyQualifiedName~CursorAdmissionTests'])
