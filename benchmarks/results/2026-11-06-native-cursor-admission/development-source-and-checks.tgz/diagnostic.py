from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
root=Path(__file__).parent;repo=Path('D:/code/Lython');old=root.parent/'adapter44';tool=root/'cursor-diagnostic';tool.mkdir()
original=root.parent/'adapter40/cursor-diagnostic'
source=(original/'Program.cs').read_text(encoding='utf-8').replace('finalBudgetBytes = budget.ReservedBytes,','finalBudgetBytes = budget.ReservedBytes, peakWorkingBytes = budget.PeakBytes - baseline,')
(tool/'Program.cs').write_text(source,encoding='utf-8')
project=(original/'CursorDiagnostic.csproj').read_text(encoding='utf-8').replace(str(root.parent/'adapter40').replace('/','\\'),str(root).replace('/','\\'))
(tool/'CursorDiagnostic.csproj').write_text(project,encoding='utf-8')
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (root/'diagnostic-build.log').open('w',encoding='utf-8') as log:r=subprocess.run([dotnet,'build',str(tool/'CursorDiagnostic.csproj'),'-c','Release','--nologo','--tl:off'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,(root/'diagnostic-build.log').read_text(encoding='utf-8')[-3000:]
for role in ['baseline','candidate']:
    shutil.copytree(tool/'bin/Release/net11.0',tool/role)
shutil.copyfile(old/'out/Lokad.Lython.PublicApi.Tests/Release/net11.0/Lokad.Lython.Utf8Regex.dll',tool/'baseline/Lokad.Lython.Utf8Regex.dll')
results=[]
for i,role in enumerate(['baseline','candidate','candidate','baseline']):
    p=subprocess.run([dotnet,str(tool/role/'CursorDiagnostic.dll'),f'{role}-{i}'],cwd=repo,env=env,capture_output=True,text=True,encoding='utf-8')
    (root/f'diagnostic-{role}-{i}.json').write_text(p.stdout,encoding='utf-8')
    (root/f'diagnostic-{role}-{i}.stderr.log').write_text(p.stderr,encoding='utf-8')
    assert p.returncode==0,p.stdout+p.stderr
    row=json.loads(p.stdout);results.append(row)
    assert row['finalBudgetBytes']==0 and row['matches']==64
    print(role,row['medianAllocatedBytes'],row['medianMilliseconds'],row['peakWorkingBytes'],flush=True)
for name in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    assert len({r['hashes'][name] for r in results})==1
allocated={role:statistics.median(r['medianAllocatedBytes'] for r in results if r['role'].startswith(role)) for role in ['baseline','candidate']}
elapsed={role:statistics.median(r['medianMilliseconds'] for r in results if r['role'].startswith(role)) for role in ['baseline','candidate']}
summary={'sameProducer':True,'sameCore':True,'privateDevelopmentOnly':True,'results':results,
    'allocationDeltaPercent':100*(allocated['candidate']/allocated['baseline']-1),'diagnosticElapsedDeltaPercent':100*(elapsed['candidate']/elapsed['baseline']-1),
    'limitation':'Direct synchronous cursor lifetime only, 192-byte UTF8 /64 matches with full capture goldens and zero cleanup, same immutable dev44 producer. Busy Windows elapsed is diagnostic, not CPU/whole-script/CPython/host-latency/RSS qualification.',
    'newCosts':'One native-allowance bridge/gate/aggregate reservation; live-byte callbacks. Removes cursor subject-size admission heuristic, keeps conservative native working high-water capacity until Close.'}
(root/'diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print({k:v for k,v in summary.items() if k!='results'},flush=True)
