from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).parent;repo=Path('D:/code/Lython');old=root.parent/'adapter44';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
checks={}
def run(label,args,custom=True):
    log=root/(label+'.log')
    with log.open('w',encoding='utf-8') as out:r=subprocess.run([env['DOTNET_HOST_PATH'],*args,*(props if custom else [])],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8');print(label,r.returncode,text[-700:],flush=True)
    if r.returncode:sys.exit(r.returncode)
    m=re.search(r'Passed:\s+(\d+)',text);checks[label]={'passed':int(m[1])} if m else {'exitCode':r.returncode}
run('corrected-build-public',['build','tests/Lokad.Lython.PublicApi.Tests','-c','Release','--nologo','--tl:off'])
filters=json.loads((old/'filters.json').read_text(encoding='utf-8'))
checks['internal-net11.0']={'passed':84,'log':'internal-net11.0.log','retainedFromBeforeTestOnlyFixtureCorrection':True}
for framework in ['net11.0','net10.0']:
    if framework=='net10.0':run('internal-'+framework,['test','tests/Lokad.Lython.Tests','-c','Release','-f',framework,'--no-build','--no-restore','--filter',filters['native']])
    run('corrected-public-'+framework,['test','tests/Lokad.Lython.PublicApi.Tests','-c','Release','-f',framework,'--no-build','--no-restore','--filter',filters['public']+'|FullyQualifiedName~CursorAdmissionTests'])
    folder=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}'
    checks[framework+'-loadedFiles']={name:sha(folder/(name+'.dll')) for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']}
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'));identity['providerSHA256']=sha(root/'Utf8RegexProvider.cs')
(root/'qualification.json').write_text(json.dumps({'identity':identity,'checks':checks,'originalFailure':'Exact unchanged working-balance fixture assumed all cursor capacity was admitted before first advance. Replace with funded working floor; retain bounded-many-matches, exhaustion/refusal, current token and zero-cleanup assertions.','limitations':'Private immutable development adapter only; normal pin/source unchanged; no final released/safety/whole-script CPU claim'},indent=2)+'\n',encoding='utf-8')
run('normal-build-public',['build','tests/Lokad.Lython.PublicApi.Tests','-c','Release','--nologo','--tl:off'],False)
for framework in ['net11.0','net10.0']:
    run('normal-lifetime-'+framework,['test','tests/Lokad.Lython.PublicApi.Tests','-c','Release','-f',framework,'--no-build','--no-restore','--filter','Category!=Stress&FullyQualifiedName~RegexAdapterLifetimeTests'],False)
(root/'normal-fixture-qualification.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
