from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-06-native-cursor-admission');out.mkdir()
contract='''# Native cursor working ownership — development contract

One existing Lython reservation in the cursor child scope funds the native live
working high-water capacity. Admission precedes covered native allocations and
replacement overlap. Native release ends the corresponding live borrow; funded
capacity remains conservatively reserved until Close/exhaustion, then all native
users finish before scope disposal. This is reusable capacity, not cumulative
allocation counting. No per-buffer ledger or new allowance/policy/collector.

The bridge's Release never calls a potentially throwing/cancelled host hook.
Refusal while growing the aggregate reservation throws LythonRegexException with
MemoryAdmission immediately: do not return false and allow producer optional
storage recovery. Native failure unwinds before refunds. Program and working
owners remain independent. Fixed conservative metadata/range-conversion overlap
is funded before native cursor creation/publication. Current-token CTS forwarding
is still required because native creation tokens remain authoritative on advances.

Intentional tradeoff: earlier denial can occur while relinquished native scratch
capacity remains reserved until cursor completion. Long match streams remain
bounded by peak live working storage, not the number of published matches.

Keep one-shot working estimates/program preflights and adapter-local name bridges:
the one-shot API cannot select Prepare's independent working owner, and UTF8 name
lookup does not enumerate all names. No core backend dependency, normal pin
promotion, released-producer safety claim or production publication.
'''
(root/'contract.md').write_text(contract,encoding='utf-8')
for name in ['identity.json','qualification.json','normal-fixture-qualification.json','diagnostic.json','contract.md']:
    shutil.copyfile(root/name,out/name)
with tarfile.open(out/'development-source-and-checks.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file():a.add(p,arcname=p.name)
    a.add(root/'cursor-diagnostic/Program.cs',arcname='cursor-diagnostic/Program.cs')
    a.add(root/'cursor-diagnostic/CursorDiagnostic.csproj',arcname='cursor-diagnostic/CursorDiagnostic.csproj')
(out/'README.md').write_text('''# Native cursor working admission — private immutable dev44

Core source `b6650f09`, exact immutable producer0.5.0-dev.44/c410be73 bytes recorded
in [qualification](qualification.json). Optional adapter only; normal0.4 pin,
locks and production source remain unchanged. Core has zero backend dependencies.

Replace cursor subject-size working estimates with native live-capacity admission
through one existing Lython reservation. Capacity stays conservatively charged
until cursor Close; native Release has no throwing host call. Fund capture/range
conversion overlap before publication. Refusal throws terminal MemoryAdmission;
no optional-storage fallback, retries, background work or per-buffer ledger.
See the [ownership contract and remaining bridges](contract.md).

Focused actual.NET11RC3/.NET10.0.8:84internal/427public each pass, including real
in-flight compilation/matching/cursor cancellation, UTF8 windows/flags/captures,
replacement/split workflows, retained caches/results and cleanup/reuse. Two new
direct checks show native refusal against an independent working owner unwinds,
and16,384matches fit within256KiB while program funding stays unchanged. Current
advance tokens remain authoritative. No CLR collection is needed for refunds.

One older fixture required the entire working charge to be constant before the
first advance. Preserve its original failure; assert funded working capacity
instead, retaining current-token, exhaustion/zero and parent-reuse checks. It also
passes against normal0.4 on both runtimes. This removes no containment guarantee.

The reused direct64-match/192-byte diagnostic has identical producer/core bits,
complete capture goldens,32warmups,7x128samples and zero final balances. Working
peak falls32,880→2,064B. Physical allocation rises22,240→22,368B/cursor(+0.58%):
one bridge/gate/reservation. Busy Windows elapsed is adverse:0.1096–0.1098ms before,
0.1152–0.1242ms after, median+9.1%. Retain that uncertainty/debt; no quiet-VM CPU,
whole-script, RSS or embedding-latency claim. The ownership improvement is distinct
from speed. No unchanged timing replay is scheduled.

Development qualification is complete for this cursor change, not final released
adapter/safety qualification. One-shot owner selection, native complete UTF8 name
enumeration and creation-token coupling remain precise outstanding producer/bridge
items; they do not stop independent core or non-regex development. Source, test,
failed condition, raw observations and commands are archived beside this record.
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');pos=s.index('\n')+1
s=s[:pos]+'''
[Native cursor working admission](results/2026-11-06-native-cursor-admission/README.md)
qualifies a private immutabledev44 adapter against b6650f09:84internal/427public
per actual11/10, real interruption/refusal/retained ownership and256KiB bounded
matching. One existing reservation replaces the cursor subject-size heuristic;
conservative live high-water capacity ends at cursor Close. Direct working peak
32,880→2,064B; physical allocation+128B/cursor, busy-host elapsed adverse/diagnostic
+9.1%. Normal0.4 pin/core dependency independence remain unchanged. The earlier
exact-working-balance fixture failure and all measurements are preserved.

The [Excel number-format correction](results/2026-11-06-openpyxl-number-formats/README.md)
preserves numeric colors/formula caches with a direct first-section classifier;
CPython/openpyxl reference plus focused actual11/10 checks pass. No timing claim.

'''+s[pos:];p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('Native cursor working admission is now a private active prototype, not yet qualified.','Native cursor working admission is now focused-qualified privately against\n  b6650f09:84internal/427public each actual11/10; no normal pin promotion.')
start=s.index('## Next independent U03: native cursor working admission');end=s.index('## Active B352',start)
s=s[:start]+'''## Independent U03: cursor migration completed privately; remaining contract work

Immutabledev44 native cursor working admission now passes84internal/427public per
actual11/10. One existing reservation replaces the subject-size heuristic; native
live high-water capacity stays charged until Close. Release cannot call a throwing
host; first refusal throws terminal MemoryAdmission. Fixed range/capture overlap
and local current-token CTS bridge remain. Independent program/working roots,
16,384matches under256KiB, actual in-flight cancellation and cleanup/reuse pass.
Normal0.4 source/pin and core dependency independence remain unchanged.

Direct same-producer/core diagnostic: working peak32,880→2,064B; allocation+128B
per cursor(+0.58%); busy-host elapsed+9.1% adverse/diagnostic. Retain the result and
explicit speed debt, without claiming CPU improvement or rejecting ownership on
an uncontrolled clock. No unchanged replay scheduled. Source/test/failure evidence:
benchmarks/results/2026-11-06-native-cursor-admission/.

Remaining precise boundaries: one-shot DetailedData cannot select Prepare's
independent working owner, so its heuristic/program preflight stays; never charge
the program owner for an independent execution or emulate fullmatch via search.
Native UTF8 lookup does not enumerate all names; adapter-local string bridge stays.
Producer creation-token coupling still requires local forwarding through actual
work. Keep these separate from Lython-owned UTF8/window/flags/ownership semantics.
Development producers/bridges remain usable; final immutable released adapter and
managed-safety qualification await only the affected producer capabilities.
Next regex implementation must remove one precise bridge with semantic/lifetime
acceptance and one bounded diagnostic; no blanket stop, framework or sibling edits.

'''+s[end:];p.write_text(s,encoding='utf-8')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','tests/Lokad.Lython.PublicApi.Tests/RegexAdapterLifetimeTests.cs','benchmarks/EXPERIMENTS.md',str(out)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Qualify native cursor ownership with the development adapter [skip ci]'],check=True)
