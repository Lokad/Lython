from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).parent;old=root.parent/'adapter44'
assert not (root/'Utf8RegexProvider.cs').exists()
for name in ('Directory.Build.props','Directory.Packages.props','NuGet.Config'):
    s=(old/name).read_text(encoding='utf-8')
    if name=='Directory.Build.props':
        s=s.replace(str(old).replace('\\','/'),str(root).replace('\\','/'))
        s=s.replace('<RestoreFallbackFolders>','<RestoreFallbackFolders>'+str(old/'packages').replace('\\','/')+';')
        s=s.replace('</Project>','''  <ItemGroup Condition="'$(MSBuildProjectName)' == 'Lokad.Lython.PublicApi.Tests'">
    <Compile Include="'''+str(root/'CursorAdmissionTests.cs').replace('\\','/')+'''" Link="CursorAdmissionTests.cs" />
  </ItemGroup>
</Project>''')
    (root/name).write_text(s,encoding='utf-8')
source=(old/'Utf8RegexProvider.cs').read_text(encoding='utf-8')
source=source.replace('            private bool _disposed;\n\n            internal Cursor',
'''            private bool _disposed;

            // Native exclusive scratch contributes its live high water, not
            // allocation traffic. Keep that conservative capacity until Close;
            // native Release must not call a possibly throwing host on cleanup.
            private sealed class WorkingAllowance : IUtf8MemoryAllowance
            {
                private readonly object _gate = new();
                private readonly ILythonMemoryReservation _storage;
                private long _liveBytes;

                internal WorkingAllowance(ILythonMemoryBudget owner) => _storage = Reserve(owner, 0);

                public bool TryReserve(ulong bytes)
                {
                    lock (_gate)
                    {
                        if (bytes > (ulong)(long.MaxValue - _liveBytes))
                            throw new LythonRegexException(LythonRegexFailure.MemoryAdmission,
                                "Shared memory budget refused regex storage.", requestedBytes: long.MaxValue);
                        var next = _liveBytes + (long)bytes;
                        // Throw at the first refused native admission. Returning
                        // false could make optional producer storage recoverable.
                        Resize(_storage, next);
                        _liveBytes = next;
                        return true;
                    }
                }

                public void Release(ulong bytes)
                {
                    lock (_gate) _liveBytes -= (long)bytes;
                }
            }

            internal Cursor''')
assert source.count('private sealed class WorkingAllowance')==1
source=source.replace('                    Reserve(_owner, subject.MatchBytes);',
'''                    // Native range publication refunds its staging; cover that
                    // array plus Lython capture conversion before either exists.
                    Reserve(_owner, checked(512L + 128L * subject.Pattern.CaptureSlotCount));
                    var working = new WorkingAllowance(_owner);''')
source=source.replace('subject._startByte, _cancellation.Token), token, patternSource:',
                      'subject._startByte, _cancellation.Token, working), token, patternSource:')
assert 'Reserve(_owner, subject.MatchBytes)' not in source
(root/'Utf8RegexProvider.cs').write_text(source,encoding='utf-8')
(root/'identity.json').write_text(json.dumps({'baseRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'baseProviderSHA256':hashlib.sha256((old/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),
    'providerSHA256':hashlib.sha256((root/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),
    'packages':json.loads((old/'identity.json').read_text(encoding='utf-8'))['packages'],
    'developmentOnly':True,'normalPin':'0.4.0 unchanged','ownership':'Native live high-water working capacity; refund at cursor Close, not cumulative allocation'},indent=2)+'\n',encoding='utf-8')
