from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'))
(q/'launch.log').rename(q/'initial-staging-failure.log')
c['retireGroups']=c['retireGroups'][:1]
for canonical,path in [('benchmarks/results/2026-11-03-call-transport-profile/observations.tgz','call-transport-b164-20261103/observations.tgz'),('benchmarks/results/2026-11-06-runtime-cost-gates/method-csv/observations.tgz','method-frame-b327-20261106/observations.tgz')]:
    blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
    c['retireGroups'].append(dict(paths=[path],bytes=len(blob),links=1,sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True,optional=True))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Fresh launcher will recheck exact optional committed replicas before any unlink; all original staging failure retained.')
