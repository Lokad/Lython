from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
base=Path(__file__).parent;repo=Path('D:/code/Lython');r=base/'confirm';q=r/'quiet';q.mkdir(parents=True,exist_ok=False)
prior=json.loads((base/'quiet/config.json').read_text(encoding='utf-8'));identity=prior['identity'].copy();identity['purpose']='R479 unchanged-image confirmation: original warm candidate moved4.88% and fresh CPU adverse. Two floating jobs, eight-second warmups; no source tuning. Original first conditions preserved.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(base/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);jobs=[['scripts.numeric-squared-error.floating.large',lane]for lane in ['warm','compile-run']];s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('warmupSeconds=6','warmupSeconds=8').replace('min(warmed)<6','min(warmed)<8').replace('warmed[i]>=6','warmed[i]>=8').replace('accumulate6seconds','accumulate8seconds')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(base/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/global-slots-confirm-b893-20261117'
(q/'run.sh').write_text((base/'quiet/run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-17-unary-result-transport/cpython/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
groups=[]
for member,data in [('confirmation/confirmation.json',data),('whole-archive',blob)]:groups.append(dict(paths=['unary-cpython-b891-20261117/'+('observations.tgz'if member=='whole-archive'else member)],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
    for n in names:archive.add(q/n,arcname=n)
c=prior|dict(root=remote,unit='lython-b893-global-slots-confirm-20261117',source=prior['root'],sourceFiles=identity['imageFiles']['candidate'],sourceCatalogSHA256=prior['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(base/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace('# Custom catalog was verified with both actual images before payload staging.',"os.link(source/'representative.json',root/'representative.json')").replace('lython-b892-fixtures','lython-b893-fixtures');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((base/'launch.py').read_text(encoding='utf-8').replace('seconds=230','seconds=125').replace('before230seconds','before125seconds').replace('Five-job','Two-job'),encoding='utf-8',newline='\n')
s=(base/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==2").replace('B892','B893');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(base/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2");s=s[:s.index("reference=json.loads")];(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+list(r.glob('*.py')):ast.parse(p.read_text(encoding='utf-8'))
print('Two unchanged-image jobs prepared; explicit originals retained; retire only committed210749B raw and50124B archive replicas.')
