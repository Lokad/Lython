from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';out=repo/'benchmarks/results/2026-11-17-instruction-global-slots';out.mkdir(exist_ok=False)
receipt=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
first=out/'first-pair';first.mkdir()
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/name,first/name)
for name in ['summary.json','allocation-summary.json','candidate-sources.tar.xz']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
core=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes();(out/'candidate-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
patch=subprocess.check_output(['git','diff','--no-ext-diff','--binary'],cwd=work);(out/'prototype.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in list(r.glob('*.py'))+list(r.glob('*.json'))+list(r.glob('*.log')):a.add(p,arcname=p.name)
    for p in (r/'quiet').rglob('*'):
        if p.is_file()and 'retrieved'not in p.parts and p.name not in ['observations.tgz','payload.tgz','Lokad.Lython.dll']:a.add(p,arcname=p.relative_to(r).as_posix())
validation=dict(eachActualWindowsTarget=dict(publicFocused=226,internalFocused=65),newArchitectureOnlyTests=0,candidatePriorCatalogGoldens=13,actualFrozenBothCatalogGoldens=3,productionFilesChanged=8,copiedWorkerImageFiles=32,sharedBudgetBaselineRestored=True,fullDelivery='Not promoted; focused prototype checks only.',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Module binding in an existing instruction operand

R479/B892, 2026-11-17 UTC. **Private prototype; decision pending.** Qualified
d8611c85/frozen0315de0a versus be7497de, eight production files. A cancellable
compiler fixup puts known module indexes in LoadGlobal's existing spare operand.
Instructions and code objects gain no fields or retained tables. A name/bounds
guard reads the live frame, retaining ordinary namespace/builtin lookup on a miss.
No value caching, alternate execution, owner or public API is introduced.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | --- | ---: | ---: | ---: |
| Floating JSON report | Warm | −0.86..+5.46% | −2.28..+7.59% | 1.43 / **4.88%** |
| Same | Compile and execute once | **+2.00..+3.12%** | **+1.81..+3.27%** | 0.19 / 0.91% |
| Integer CSV invoice | Warm | −2.46..−1.95% | −2.78..−0.83% | 0.23 / 0.30% |
| Helper text | Warm | −0.75..+0.39% | −1.85..−0.37% | 0.19 / 0.96% |
| Floating report | Compilation | +0.68..+3.57% | −0.98..+2.55% | 0.43 / 2.44% |

Natural-GC allocation and accounted peaks are unchanged in all three scripts;
all shared allowances return to baseline. Each actual Windows target passes
226 public and 65 internal focused cases: live rebinding/deletion, builtin fallback,
classes/closures, imports, pending I/O, cancellation, refusal, retained results and
cleanup. Actual copied 32-file images both pass three independent catalog goldens;
the candidate also passes all 13 previous complete-script goldens. No repeated
qualification of the unchanged delivered source.

193.34 seconds, five jobs, quiet Azure F4as_v7/Ubuntu24.04.4/.NET11 RC3; six-second
rotated full-request warmups, five sample rounds, natural GC and normal tiering.
Warm guest clocks include Run, mediated RAM I/O, output/file validation and previous
result cleanup; exclude compilation/startup/reset/protocol/final cache disposal.
Fresh adds compilation and compiled-owner disposal. External CPU has a wider
boundary. No CPython ratio or CPU gain is inferred from source simplification.

First staging failed before deletion or timing because an already removed working
raw was named. The failure is preserved; repaired staging freshly verifies exact
committed superseded core/evidence replicas, including all inode aliases. Current
images, toolchains, canonical evidence and 254/252 MiB floors remain intact. All
workers joined, machine gates passed, RAM removed, archive SHA verified; terminal
cached. Publication held.

The adverse fresh result is real evidence; the warm candidate control is unstable.
One unchanged-image warm/fresh confirmation with eight-second warmups is justified
before retain/refine/withdraw. This is uncertainty, not a permanent design ban.

[Summary](summary.json), [allocation](allocation-summary.json),
[validation](validation.json), [raw](first-pair/observations.tgz),
[identity](identity.json), [exact sources](candidate-sources.tar.xz),
[prototype](prototype.patch.gz), [core](candidate-core.dll.gz),
[procedures and original failure](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''

R479/B892: [existing instruction operand for live module bindings](results/2026-11-17-instruction-global-slots/README.md), private prototype. No new code-object fields/maps; compile-only fixup replaces per-read discovery. First 193.34s pair: floating warm −0.86..+5.46% with 4.88% candidate control movement; fresh +2.00..+3.12%, wider CPU +1.81..+3.27%. CSV −2.46..−1.95%; text near flat; allocation/peak unchanged. Focused actual11/10 and all13 candidate goldens pass. Original staging failure and every adverse observation retained. One unchanged-image floating confirmation justified; no promotion or CPU gain claim. Broader performance work/publication hold continue.
''')
print('Preserved first prototype sources/core/raw/adversity, no runtime promotion.')
