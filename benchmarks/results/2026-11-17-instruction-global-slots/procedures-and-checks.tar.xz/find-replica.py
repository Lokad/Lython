from pathlib import Path
import json
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=json.loads((r.parent/'unary-slot-results-r477/working-image-inspection.json').read_text(encoding='utf-8'))
sizes={}
for p in (repo/'benchmarks/results').rglob('observations.tgz'):sizes.setdefault(p.stat().st_size,[]).append(str(p.relative_to(repo)))
matches=[x|dict(canonicals=sizes[x['bytes']])for x in old['archives']if x['bytes']in sizes and x['bytes']>500000]
(r/'replica-candidates.json').write_text(json.dumps(matches,indent=2)+'\n',encoding='utf-8')
for x in matches[:10]:print(x)
