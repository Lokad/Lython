from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'unary-slot-results-r477';q=r/'quiet';q.mkdir(exist_ok=False)
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'cpython/quiet/config.json').read_text(encoding='utf-8'))
remote='/home/lokad/lython-bench-checks/instruction-global-slots-b892-20261117'
reference=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision=f['referenceSource']+' versus '+f['candidateSource']+'/frozen'+candidate,purpose='R479 replaces repeated module-name slot discovery with existing LoadGlobal spare operand. No code-object fields/maps. Complete floating report warm/fresh, original CSV/text controls, compilation separately; allocation and wider CPU separate.',coreSHA256={'reference':reference,'reference-control':reference,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=f['productionFiles'],catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
floating='scripts.numeric-squared-error.floating.large'
jobs=[[floating,'warm'],[floating,'compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-normalization.helper-list','warm'],[floating,'compile']]
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('bounded R473sourcepair, no preferred-sign retiming','bounded R479 source pair; usable controls or explicit uncertainty, justified confirmation allowed')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'quiet/archive-owned.py',q/'archive-owned.py')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/unary-slot-results-b889-20261117',remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
groups=[json.loads((r/'superseded-core-proof.json').read_text(encoding='utf-8'))]
for canonical,prefix in [('benchmarks/results/2026-11-17-generator-sum/observations.tgz','generator-sum-b886-20261117'),('benchmarks/results/2026-11-17-generator-sum/cpython/observations.tgz','generator-sum-cpython-b887-20261117')]:
    blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(blob))as archive:
        data=archive.extractfile('confirmation/confirmation.json').read()
    for member,data in [('confirmation/confirmation.json',data),('whole-archive',blob)]:
        path=prefix+('/observations.tgz'if member=='whole-archive'else'/'+member)
        groups.append(dict(paths=[path],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
for proof in groups:
    blob=subprocess.check_output(['git','show','HEAD:'+proof['canonical']],cwd=repo);assert hashlib.sha256(blob).hexdigest()==proof['canonicalSHA256']
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
    for n in names:archive.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b892-instruction-global-slots-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b889-fixtures','lython-b892-fixtures');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('unary-slot-results','instruction-global-slots'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B889','B892'),encoding='utf-8',newline='\n');shutil.copyfile(old/'summarize.py',r/'summarize.py')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared five jobs; staging',c['unpackedBytes'],'retire only proven superseded replicas',sum(g['bytes']for g in groups),'current0315 preserved.')
