from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,json,os
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=[]
 for name in ['generator-sum-b886-20261117','generator-sum-cpython-b887-20261117','unary-cpython-b891-20261117','current-script-costs-b888-20261117']:
  root=b/name
  rows.extend(dict(path=str(p.relative_to(b)),bytes=p.stat().st_size,links=p.stat().st_nlink)for p in root.rglob('*')if p.is_file()and not {'candidate','reference'}&set(p.relative_to(root).parts))
 print(json.dumps(rows))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stderr
rows=json.loads(p.stdout);(r/'evidence-inspection.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
for row in rows:
 if row['bytes']>100000:print(row)
