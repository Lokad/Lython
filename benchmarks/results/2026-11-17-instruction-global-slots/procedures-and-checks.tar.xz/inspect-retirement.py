from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython')
canonical='benchmarks/results/2026-11-17-generator-sum/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);sha=hashlib.sha256(data).hexdigest()
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess,shutil
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 selected=[]
 for p in b.glob('*/*/Lokad.Lython.dll'):
  if hashlib.sha256(p.read_bytes()).hexdigest()==SHA:selected.append(p)
 assert selected
 m=selected[0].lstat();key=(m.st_dev,m.st_ino);aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;v=p.lstat()
   if(v.st_dev,v.st_ino)==key:aliases.append(str(p.relative_to(b)))
 assert len(aliases)==m.st_nlink and m.st_uid==os.getuid()
 print(json.dumps(dict(paths=aliases,bytes=m.st_size,links=m.st_nlink,sha256=SHA,freeBytes=shutil.disk_usage(b).free)))
'''.replace('SHA',repr(sha))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
value=json.loads(p.stdout);assert value['bytes']==len(data)
proof=value|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededQualifiedSource='abcbd9fd replaced by qualifiedd8611c85; current0315 core preserved')
(r/'superseded-core-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8');print(json.dumps(proof))
