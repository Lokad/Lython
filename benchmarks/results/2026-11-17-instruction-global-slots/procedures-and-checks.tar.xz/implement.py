from pathlib import Path
w = Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470')
def edit(name, old, new):
    p = w / name
    s = p.read_text(encoding='utf-8-sig')
    assert old in s, (name, old)
    p.write_text(s.replace(old, new), encoding='utf-8', newline='\n')
edit('src/Lokad.Lython/Frontend/ExecutableScript.cs',
'''    public static ExecutableInstruction LoadGlobal(int nameIndex, LythonSourceSpan span)
        => new(ExecutableOpCode.LoadGlobal, span, nameIndex);''',
'''    public static ExecutableInstruction LoadGlobal(int nameIndex, LythonSourceSpan span)
        => new(ExecutableOpCode.LoadGlobal, span, nameIndex);

    // Final module binding uses the otherwise unused secondary operand. No
    // values or module-layout reference become part of immutable code metadata.
    internal int GlobalSlot => OpCode == ExecutableOpCode.LoadGlobal
        ? _secondaryOperand : throw InvalidOperand(nameof(GlobalSlot));

    internal ExecutableInstruction WithGlobalSlot(int slot)
        => OpCode == ExecutableOpCode.LoadGlobal
            ? new(OpCode, Span, _primaryOperand, slot, _inputStart, _resultSlot, _liveExtent)
            : throw InvalidOperand(nameof(GlobalSlot));''')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',
'public static ExecutableScript Compile(LoweredScript lowered)',
'public static ExecutableScript Compile(LoweredScript lowered, CancellationToken cancellationToken = default)')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',
'''        return new ExecutableScript(entryPoint.ScopeFacts.ContainsVariableAnnotations''',
'''        BindModuleGlobalSlots(entryPoint, cancellationToken);
        return new ExecutableScript(entryPoint.ScopeFacts.ContainsVariableAnnotations''')
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',
'''    private static ScopeDirectiveFacts GeneratorFacts(LoweredGeneratorExpression expression)''',
'''    // Child code is complete before a module has interned its final stores.
    // Patch only compiler-owned instruction arrays; no link table survives.
    private static void BindModuleGlobalSlots(ExecutableCodeObject module, CancellationToken cancellationToken)
    {
        PythonTokenization.CheckCancellation(cancellationToken, 0);
        var pending = new Stack<ExecutableCodeObject>();
        var visited = new HashSet<ExecutableCodeObject>();
        pending.Push(module);
        while (pending.Count != 0)
        {
            var code = pending.Pop();
            if (!visited.Add(code)) continue;
            for (var i = 0; i < code.Instructions.Length; i++)
            {
                if ((i & 63) == 0) PythonTokenization.CheckCancellation(cancellationToken, 0);
                ref var instruction = ref code.Instructions[i];
                if (instruction.OpCode == ExecutableOpCode.LoadGlobal &&
                    module.LocalNameToSlot.TryGetValue(code.Names[instruction.NameIndex], out var slot))
                    instruction = instruction.WithGlobalSlot(slot);
            }
            foreach (var function in code.Functions) pending.Push(function.CodeObject);
            foreach (var constant in code.Constants)
            {
                if (constant is ExecutableCreateLambda lambda) pending.Push(lambda.CodeObject);
                else if (constant is ExecutableCreateGeneratorExpression generator) pending.Push(generator.CodeObject);
            }
        }
    }

    private static ScopeDirectiveFacts GeneratorFacts(LoweredGeneratorExpression expression)''')
edit('src/Lokad.Lython/Public/LythonEngine.cs',
'executableScript = ExecutableScript.Compile(loweredScript);',
'executableScript = ExecutableScript.Compile(loweredScript, cancellationToken);')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Imports.cs',
'var executable = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script));',
'var executable = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script), context.State.CancellationToken);')
p = w / 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs'
s = p.read_text(encoding='utf-8-sig')
a = s.index('    private static object ResolveExecutableGlobal(')
b = s.index('    private static bool TryStoreClosure(', a)
s = s[:a] + '''    private static object ResolveExecutableGlobal(string name, int moduleSlot, LythonSourceSpan span, ExecutionContext context)
    {
        var globalContext = GetGlobalContext(context);
        if (globalContext.CurrentExecutableFrame is { } frame &&
            ((moduleSlot != int.MaxValue && frame.TryReadModuleSlot(name, moduleSlot, out var value)) ||
             frame.TryResolveLocalOrClosure(name, out value))) return value;
        if (globalContext.Variables.TryGetValue(name, out value)) return value;
        return context.TryGetBuiltin(name, out value) ? value : throw RuntimeErrors.NameNotDefined(name, span);
    }

''' + s[b:]
p.write_text(s, encoding='utf-8', newline='\n')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs',
'''        internal bool TryReadExecutableLocal(string name, [MaybeNullWhen(false)] out object value)''',
'''        // Independently compiled code may meet another live namespace. The
        // name guard proves the index still denotes this binding; values are
        // always read now, never cached across rebinding or suspension.
        internal bool TryReadModuleSlot(string name, int slot, [MaybeNullWhen(false)] out object value)
        {
            if ((uint)slot < (uint)_execution.Code.LocalNames.Count && _execution.Code.LocalNames[slot] == name)
            {
                value = ReadLocalValue(_execution.Locals, slot);
                if (value is not null) return true;
            }
            value = null;
            return false;
        }

        internal bool TryReadExecutableLocal(string name, [MaybeNullWhen(false)] out object value)''')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs',
'ResolveExecutableGlobal(execution.Code.Names[instruction.NameIndex], instruction.Span, scope)',
'ResolveExecutableGlobal(execution.Code.Names[instruction.NameIndex], instruction.GlobalSlot, instruction.Span, scope)')
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',
'ResolveExecutableGlobal(Code.Names[instruction.NameIndex], instruction.Span, _scope)',
'ResolveExecutableGlobal(Code.Names[instruction.NameIndex], instruction.GlobalSlot, instruction.Span, _scope)')
print('R479: known module slots embedded in existing32byte instructions; guarded live reads, generic namespace fallback, cancellable compile-only fixup, no new code-object fields/arrays.')
