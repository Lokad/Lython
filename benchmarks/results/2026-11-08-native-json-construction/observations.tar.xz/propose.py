from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
files=['src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs','src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs']
(r/'before').mkdir()
for p in files:shutil.copyfile(p,r/'before'/Path(p).name)
(r/'identity-before.json').write_text(json.dumps(dict(sourceRevision='15c06863',sourceSHA256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files},coreSHA256='1674a06cf69c3b6680e74c2e7b74e72d0e84c275662ff1e3dfc5bda0cfa226ca'),indent=2)+'\n',encoding='utf8')
proposal="""## R105 — native JSON encoder construction and call transport

Hypothesis: whole eager normalization (4096records, warm1.42–1.44xCPython at
15c06863) pays repeated constructor/call packaging for ordinary nondefault
options. Source shows8-key forwarding List/array, a constructor defaults dictionary
and hash lookup perargument, a six-name assignment array, method resolution/bound
wrapper and single-value argument packaging. This proves removable work, not its
CPU share or a speedup. Streamed normalization0.67x is a separate engine comparison,
not a controlled attribution to constructor cost.

Complete native constructor initialization once from already-bound module options,
sharing the same attribute initialization order, separators/default processing and
awaited callback behavior with explicit JSONEncoder construction. Parse constructor
arguments into8 ordinary locals instead of a dictionary. Keep the existing mutable
attribute object and guest-owner assignment semantics; no new settings abstraction,
cache/pool/owner or pending framework. Exact native cls/extras-empty module calls
can use that initializer directly. Native eager calls pass the value directly into
the existing encode body; public argument arity/custom-method handling remains.

Remove native forwarding/binding/method/argument transport, constructor dictionary/
lookups and six-name assignment array. General forwarding remains for guest classes
and unknown extras; it has real callers. Do not bypass a guest constructor/descriptor/
iterencode override or snapshot mutable public encoder attributes across callbacks.

Acceptance: Python option/default/key/numeric/Unicode order, keyword/arity/errors,
custom cls/init/encode/iterencode, mutable attrs, exact chunks, true suspension/
reentry/current-token/terminal-refusal, retained aliases and cleanup. Preserve
shared one-walker R102 and document its separate accepted eager debt.

Bound~30min implementation, focused existing JSON765public/171internal on11/10,
one short currentdriver allocation diagnostic and one six-job controlled pair
using R102 eager/streamed/config/CSV/decode controls. Independent full stdout/files
goldens already established. All adverse results preserved; no fixed% veto or
automatic native-attribute/storage expansion. Refine/stop if new lifetime state,
public options, duplicated initializer/walker or semantic weakening is needed.
Decide remaining allocation/CPU debt explicitly; new-source full platform/Stress/
installed qualification batched at a coherent retained boundary. R102 full CI is
independent and does not qualify this prototype. Publication/regex unchanged.
"""
(r/'proposal.md').write_text(proposal,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('2. **R104 source gate')
s=s[:a]+'2. **R105 selected: native JSON constructor/call packaging.**\n'+''.join('   '+line+'\n'for line in proposal.splitlines()[2:])+'\n'+s[a:].replace('2. **R104 source gate','3. **R104 source gate',1)
s=s.replace('3. **R103 combined representative','4. **R103 combined representative').replace('4. **Independent regex contract','5. **Independent regex contract')
s=s.replace('B462 is the only active VM collection;\nobserve after13:40:40UTC, join/unmount/archive and verify before closing.','B462 terminal/archived/locally verified; no active VM users/fixtures.')
p.write_text(s,encoding='utf8')
print('R105 exact baseline snapshots and deletion/acceptance proposal recorded before editing.')

