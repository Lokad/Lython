R105 one six-job controlled source pair17/aae; same worker/normalGC/tiering.
Native exact JSON encoder uses bound module storage/shared initialization and
direct eager value calls. Remove native keyword list/array, constructor dictionary/
hash lookups/name-array and eager bound-method/value packaging. Managed frame
and translation guard retained. Mutable native attributes/guest owner/setters,
overrides and general custom-class forwarding remain. No new owner/cache/settings
abstraction/pool/dispatcher.765public/171internal peractual11/10 pass.
Complete4096-record eager both APIs, streamed sync, config secondary affected,
CSV unchanged, decode-heavy JSONsummary controls. Independent CPython full goldens
reused byte-identically. Streamed async controlledCPU unmeasured (allocation tested).
Two processes percore,5swarmup/job,7rotated150msrounds, coarse process CPU.
210sowner+30stop+30margin. Full guest RAM I/O/output validation/prior cleanup
included; compilation/startup/staging/final cached teardown excluded.
Reuse archivedB461 immutable baseline17, uploadonlyaae.240MiBOSfloor+7MiBevidence+
actualuncompressedpayload preflight; all Ready/source/core/aux/quiet/golden/Closed/
join/fixtures/archive/local gates. No maintenance/evidence deletion unless a
separate fresh bounded exact-byte proof is necessary; do not imply old proof fresh.
Retain all diagnostic/adverse results. Architecture/allocation/CPU separate.
R102 eager debt remains a different sourcepair; do not silently repay it.
Full delivery of15c source is independent and does not qualify this prototype.
Publication/regex0.4 unchanged; no another external CPython refresh peredit.
