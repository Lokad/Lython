from pathlib import Path
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs');s=p.read_text(encoding='utf8')
a=s.index('        private async ValueTask<object> EncodeCoreAsync(');z=s.index('\n        public object IterEncode',a)
old=s[a:z];start=old.index('            context.CheckExecution(span);')
body=old[start:].replace('arguments[0]','value')
s=s[:a]+"""        private ValueTask<object> EncodeCoreAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            if (arguments.Length != 1) throw RuntimeErrors.Type("JSONEncoder.encode() takes exactly one argument", span);
            return EncodeValueAsync(arguments[0], span, context, asynchronous);
        }

        // Native module calls already own their value; public/guest method
        // invocation retains its ordinary argument and frame checks.
        internal async ValueTask<object> EncodeValueAsync(object value, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
"""+body+s[z:]
a=s.index('        internal static async ValueTask<object> ConstructAsync(');z=s.index('        public PyString RenderPython',a)
s=s[:a]+"""        internal static ValueTask<object> ConstructAsync(CallArgumentValue[] arguments, PyInstance? guest, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            context.CheckExecution(span);
            object skip = false, ascii = true, circular = true, nan = true, sort = false;
            object indent = PyNone.Instance, separators = PyNone.Instance, callback = PyNone.Instance;
            foreach (var argument in arguments)
            {
                if (argument.IsPositional) throw RuntimeErrors.Type("JSONEncoder.__init__() accepts keyword arguments only", span);
                switch (argument.KeywordName)
                {
                    case "skipkeys": skip = argument.Value; break;
                    case "ensure_ascii": ascii = argument.Value; break;
                    case "check_circular": circular = argument.Value; break;
                    case "allow_nan": nan = argument.Value; break;
                    case "sort_keys": sort = argument.Value; break;
                    case "indent": indent = argument.Value; break;
                    case "separators": separators = argument.Value; break;
                    case "default": callback = argument.Value; break;
                    default: throw RuntimeErrors.Type("JSONEncoder.__init__() got an unexpected keyword argument '" + argument.KeywordName + "'", span);
                }
            }
            return InitializeAsync(guest is null ? new JsonEncoderObject() : guest,
                skip, ascii, circular, nan, sort, indent, separators, callback, span, context, asynchronous);
        }

        // Module binding has already checked names and evaluated arguments.
        // Consume that storage directly rather than forwarding eight keywords.
        internal static ValueTask<object> ConstructBoundAsync(BoundCallArguments bound, int offset,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            context.CheckExecution(span);
            object Flag(int index, bool fallback) => bound.Assigned[offset + index] ? bound.Values[offset + index] : fallback;
            object Option(int index) => offset + index < bound.Values.Length ? bound.Values[offset + index] : PyNone.Instance;
            return InitializeAsync(new JsonEncoderObject(), Flag(1, false), Flag(2, true),
                Flag(3, true), Flag(4, true), Flag(9, false), Option(6), Option(7), Option(8),
                span, context, asynchronous);
        }

        private static async ValueTask<object> InitializeAsync(object instance, object skip, object ascii,
            object circular, object nan, object sort, object indent, object separatorValue, object callback,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            await AssignWrapperAttributeAsync(instance, "skipkeys", skip, context, span, asynchronous).ConfigureAwait(false);
            await AssignWrapperAttributeAsync(instance, "ensure_ascii", ascii, context, span, asynchronous).ConfigureAwait(false);
            await AssignWrapperAttributeAsync(instance, "check_circular", circular, context, span, asynchronous).ConfigureAwait(false);
            await AssignWrapperAttributeAsync(instance, "allow_nan", nan, context, span, asynchronous).ConfigureAwait(false);
            await AssignWrapperAttributeAsync(instance, "sort_keys", sort, context, span, asynchronous).ConfigureAwait(false);
            await AssignWrapperAttributeAsync(instance, "indent", indent, context, span, asynchronous).ConfigureAwait(false);
            if (separatorValue is not PyNone)
            {
                var separators = await JsonModule.ParseJsonSeparatorsAsync(separatorValue, span, context, asynchronous).ConfigureAwait(false);
                await AssignWrapperAttributeAsync(instance, "item_separator", separators.ItemSeparator, context, span, asynchronous).ConfigureAwait(false);
                await AssignWrapperAttributeAsync(instance, "key_separator", separators.KeySeparator, context, span, asynchronous).ConfigureAwait(false);
            }
            else if (indent is not PyNone)
                await AssignWrapperAttributeAsync(instance, "item_separator", JsonModule.PrettyItemSeparator, context, span, asynchronous).ConfigureAwait(false);
            if (callback is not PyNone)
                await AssignWrapperAttributeAsync(instance, "default", callback, context, span, asynchronous).ConfigureAwait(false);
            return instance;
        }
"""+s[z:]
p.write_text(s,encoding='utf8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs');s=p.read_text(encoding='utf8')
s=s.replace("""                var forwarded = BuildEncoderForwardArgs(bound, extras, JsonDumpCallForm.Dump).ToArray();
                var instance = await ((ICallable)cls).InvokeAsync(forwarded, span, context).ConfigureAwait(false);""","""                var instance = await ConstructEncoderClassAsync(cls, bound, extras, JsonDumpCallForm.Dump, span, context, true).ConfigureAwait(false);""")
s=s.replace('var instance = ConstructEncoderClass(cls, bound, extras, JsonDumpCallForm.Dump, span, context);','var instance = ConstructEncoderClassAsync(cls, bound, extras, JsonDumpCallForm.Dump, span, context, false).GetAwaiter().GetResult();')
s=s.replace('var instance = ConstructEncoderClass(clsValue, bound, extras, callForm, span, context);','var instance = ConstructEncoderClassAsync(clsValue, bound, extras, callForm, span, context, false).GetAwaiter().GetResult();\n            if (instance is JsonEncoderObject native)\n                return InvokeNativeEncoderAsync(native, value, span, context, false).GetAwaiter().GetResult();')
s=s.replace("""            var forwarded = BuildEncoderForwardArgs(bound, extras, callForm).ToArray();
            var instance = await ((ICallable)clsValue).InvokeAsync(forwarded, span, context).ConfigureAwait(false);""","""            var instance = await ConstructEncoderClassAsync(clsValue, bound, extras, callForm, span, context, true).ConfigureAwait(false);
            if (instance is JsonEncoderObject native)
                return await InvokeNativeEncoderAsync(native, value, span, context, true).ConfigureAwait(false);""")
a=s.index('        private static object ConstructEncoderClass(');z=s.index('        private static List<CallArgumentValue> BuildEncoderForwardArgs(',a)
s=s[:a]+"""        private static async ValueTask<object> InvokeNativeEncoderAsync(JsonEncoderObject encoder,
            object value, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            // Keep the same managed frame and exception policy as ordinary
            // callable invocation while borrowing the already-evaluated value.
            context.EnterInterpreterFrame(span);
            try { return RuntimeValue(await encoder.EncodeValueAsync(value, span, context, asynchronous).ConfigureAwait(false)); }
            catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
            finally { context.LeaveInterpreterFrame(); }
        }

        private static ValueTask<object> ConstructEncoderClassAsync(
            object clsValue,
            BoundCallArguments bound,
            IReadOnlyList<KeyValuePair<string, object>> extras,
            JsonDumpCallForm callForm,
            LythonSourceSpan span,
            ExecutionContext context,
            bool asynchronous)
        {
            if (clsValue is JsonEncoderClass && extras.Count == 0)
                return JsonEncoderClass.ConstructBoundAsync(bound,
                    callForm == JsonDumpCallForm.Dumps ? 0 : 1, span, context, asynchronous);
            var forwarded = BuildEncoderForwardArgs(bound, extras, callForm).ToArray();
            var callable = (ICallable)clsValue;
            return asynchronous ? callable.InvokeAsync(forwarded, span, context)
                : ValueTask.FromResult(callable.Invoke(forwarded, span, context));
        }

"""+s[z:]
assert 'ConstructEncoderClass('not in s
p.write_text(s,encoding='utf8',newline='\n')
print('R105 one shared initializer, native bound construction/direct value call; dictionary/name-array and native forwarding transport removed. Existing managed frame guard retained.')

