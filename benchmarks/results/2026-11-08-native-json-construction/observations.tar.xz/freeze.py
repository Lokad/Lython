from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'completed-json-r102'
prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
inventory={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in prior['productionSources']}
images=r/'images';images.mkdir()
for role in ['before','candidate']:
 shutil.copytree(old/'images/candidate',images/role,copy_function=os.link)
candidate=images/'candidate/Lokad.Lython.dll';candidate.unlink()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',candidate)
hashes={role:hashlib.sha256((images/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']}
assert hashes['before']==prior['coreSHA256']['candidate']and hashes['before']!=hashes['candidate']
identity=dict(baselineSource='Committed15c06863/core1674a06c; full CI42484943603 pending independently, Windows complete green.',candidateSource='15c06863 plus native JSON shared initialization/direct bound arguments/value calls',coreSHA256=hashes,productionSources=inventory,focusedChecks={k:v for k,v in [('public11',765),('public10',765),('internal11',171),('internal10',171)]},qualification='Focused JSON peractual11/10 pass; existing actual suspension/reentry/cancellation/refusal/retained-owner/cleanup. New source full delivery pending.',controls=prior['controls'])
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for src,name in [(old/'catalog.json','catalog.json'),(Path('PLAN.md'),'pre-measurement-plan.md')]:shutil.copyfile(src,r/name)
patch=subprocess.check_output(['git','diff','--','src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs','src/Lokad.Lython/Runtime/LythonRuntime.JsonModule.cs'])
(r/'source.patch').write_bytes(patch)
for name in ['measure.py','assess-local.py']:
 s=(old/name).read_text(encoding='utf8').replace('R102','R105')
 (r/name).write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8').replace('**R105 selected: native JSON constructor/call packaging.**','**R105 active prototype: native JSON constructor/call packaging.**\n   Shared initializer/direct bound construction/native value calls implemented;\n   dictionary/name-array/native forwarding storage removed. Same managed frame/\n   translation guard retained, existing mutable attribute owner/guest setters intact.\n   765public/171internal JSON checks peractual11/10 pass. Uncommitted/unqualified;\n   exact frozen allocation/controlled comparison next; no speedup claim yet.')
p.write_text(s,encoding='utf8')
print('R105 source frozen:',json.dumps(hashes),flush=True)

