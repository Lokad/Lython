## R105 — native JSON encoder construction and call transport

Hypothesis: whole eager normalization (4096records, warm1.42–1.44xCPython at
15c06863) pays repeated constructor/call packaging for ordinary nondefault
options. Source shows8-key forwarding List/array, a constructor defaults dictionary
and hash lookup perargument, a six-name assignment array, method resolution/bound
wrapper and single-value argument packaging. This proves removable work, not its
CPU share or a speedup. Streamed normalization0.67x is a separate engine comparison,
not a controlled attribution to constructor cost.

Complete native constructor initialization once from already-bound module options,
sharing the same attribute initialization order, separators/default processing and
awaited callback behavior with explicit JSONEncoder construction. Parse constructor
arguments into8 ordinary locals instead of a dictionary. Keep the existing mutable
attribute object and guest-owner assignment semantics; no new settings abstraction,
cache/pool/owner or pending framework. Exact native cls/extras-empty module calls
can use that initializer directly. Native eager calls pass the value directly into
the existing encode body; public argument arity/custom-method handling remains.

Remove native forwarding/binding/method/argument transport, constructor dictionary/
lookups and six-name assignment array. General forwarding remains for guest classes
and unknown extras; it has real callers. Do not bypass a guest constructor/descriptor/
iterencode override or snapshot mutable public encoder attributes across callbacks.

Acceptance: Python option/default/key/numeric/Unicode order, keyword/arity/errors,
custom cls/init/encode/iterencode, mutable attrs, exact chunks, true suspension/
reentry/current-token/terminal-refusal, retained aliases and cleanup. Preserve
shared one-walker R102 and document its separate accepted eager debt.

Bound~30min implementation, focused existing JSON765public/171internal on11/10,
one short currentdriver allocation diagnostic and one six-job controlled pair
using R102 eager/streamed/config/CSV/decode controls. Independent full stdout/files
goldens already established. All adverse results preserved; no fixed% veto or
automatic native-attribute/storage expansion. Refine/stop if new lifetime state,
public options, duplicated initializer/walker or semantic weakening is needed.
Decide remaining allocation/CPU debt explicitly; new-source full platform/Stress/
installed qualification batched at a coherent retained boundary. R102 full CI is
independent and does not qualify this prototype. Publication/regex unchanged.
