from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b463'
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and receipt['jobs']==6 and hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
vm=json.loads((b/'assessment.json').read_text(encoding='utf8'));local=json.loads((r/'assessment-local.json').read_text(encoding='utf8'))
assert vm['complete']and len(vm['jobs'])==6 and all(len(local[k])==5 for k in ['warm-sync','warm-async'])
out=Path('benchmarks/results/2026-11-08-native-json-construction');out.mkdir()
decision="""Retain R105: native JSON constructor/call packaging is a complete removable phase.
One shared initializer serves module-bound native options, explicit native encoder
construction and guest __init__ assignments. Constructor defaults dictionary/hash
lookups/six-name array removed. Native module calls skip eight-key forwarding List/
array and eager bound-method/value packaging; consume evaluated value directly.
Managed interpreter frame and exception translation preserved. Mutable attribute
storage remains; guest constructors/getters/setters/encode/iterencode dispatch and
unknown extras retain the genuine general path. No new settings record/cache/pool/
owner/framework/public options. New source two-file patch, not a second renderer.
765public/171internal JSON peractual11/10 pass, actual suspension/reentry/current
cancellation/terminal refusal/retained aliases/shared-budget reuse/awaited cleanup.
R102's private temporary traversal ownership and one walker remain.
Complete4096record eager allocation-27.22%sync/-27.68%async; streamed-24.03%sync/
-23.85%async; config-4.34/-4.30%. Desktop elapsed mixed/adverse, old baseline drift
up to17.48%; all original data retained, not CPU evidence.
B463172.758s sourcepair1674/aae, normal settings, all four median pairings:
eager sync elapsed-9.05to-9.93%, CPU-10%; eagerasync-9.06to-11.58%, CPU-11.11%;
streamedsync-6.25to-7.00%, CPU-5.88%. Baseline spreads0.73/1.50/0.007%, candidate
0.24/1.31/0.80%. Short observations/coarse ticks, not confidence intervals or
universal gains. Streamedasync controlledCPU unmeasured, allocation checked.
Config-0.83to+1.33%elapsed, coarseCPU+4.38to+5.70%: possible CPU debt/inconclusive,
accepted explicitly; no speedup claim from lower allocation. UnchangedCSV
-3.01to+0.69%/2.43%candidate spread, not a causal gain. JSONsummary-0.08to+0.97%/
CPU0to+2.5%, possible small debt/uncertainty. No broad retiming campaign or fixed%
veto. Earlier R102 eager/R95text/R96report debts remain distinct; no silent repayment.
All full stdout/files/Ready/core/aux/quiet/Closed/join/fixture/archive/local gates.
No remaining users/fixtures. No space maintenance/deletion this round; reused exact
archived baseline17, uploaded onlyaae,240MiBOSfloor+7MiBevidence+payload preflight.
Full exact new-source platform/Stress/installed qualification pending independently;
R102/15c CI42484943603 green does not qualify this candidate. Current CPython guide
stays named15c/R103; no per-edit external refresh. Regex/publication unchanged.
"""
(r/'decision.md').write_text(decision,encoding='utf8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':continue
  if p.name=='b463':
   for child in sorted(p.iterdir()):
    if child.name not in ['retrieved','baseline-core.dll','current-core.dll','payload.tgz']:a.add(child,arcname='b463/'+child.name)
  else:a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as a:assert hashlib.sha256(a.extractfile('b463/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Retained native construction/call consolidation; focused and controlled checks pass; exact new-source full delivery pending independently.',coreSHA256=i['coreSHA256'],focusedChecks=i['focusedChecks'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,referenceGuideSource='15c06863')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
readme="""# Native JSON encoder construction — 2026-11-08

Retain one shared initializer for module-bound options, explicit JSONEncoder
construction and guest attribute assignment. Delete the temporary constructor
defaults dictionary, repeated name lookups and six-name assignment array.
Exact native module calls consume already-bound values without eight-key keyword
forwarding List/array. Native eager encoding passes its value directly with the
same managed interpreter-frame/exception policy. Mutable native attributes and
guest constructors/setters/getters/encode/iterencode overrides remain. General
forwarding still serves guest classes and unknown extras; no obsolete fallback
was added. No new settings abstraction/cache/pool/owner/public option.

Baseline committed15c06863/core1674a06c, independently fully qualified at
[cached CI42484943603](../2026-11-08-unified-json-encoding/delivery-ci.json).
Candidate15c plus archived two-file patch/coreaae80cc7; exact source hashes in
identity.json. Informational binary revision predates the candidate commit.
New-source full platform/Stress/installed-core qualification remains separate/pending.
The main CPython guide accurately names15c; these source-pair results do not update
that external baseline or silently repay earlier R102/R95/R96 regression debt.

| Complete workload | Allocation sync / async | Controlled elapsed, all four median pairings |
| --- | ---: | ---: |
| Eager JSON normalization, sync | −27.22% / — | −9.05 to −9.93% |
| Eager JSON normalization, async API | — / −27.68% | −9.06 to −11.58% |
| Streamed JSON normalization, sync | −24.03% / — | −6.25 to −7.00% |

Coarse process CPU agrees:−10/−11.11/−5.88%, respectively. Baseline spreads
0.73/1.50/0.007%, candidate0.24/1.31/0.80%. Short controlled observations, not
confidence intervals/universal gains. Streamed async allocation−23.85%; its
controlled CPU/elapsed remains unmeasured.

Config allocation−4.34%sync/−4.30%async; controlled sync elapsed−0.83to+1.33%,
coarseCPU+4.38to+5.70%: possible CPU debt/inconclusive, explicitly accepted.
Unchanged CSV−3.01to+0.69%/candidate2.43%spread: no causal gain.
Decode-heavy JSONsummary−0.08to+0.97%/CPU0to+2.5%, possible small debt/uncertainty.
Original desktop eager+8.25%adverse and baseline drift up to17.48% are preserved.
Allocation savings do not establish CPU or embedding-tail improvements.

Both affected scripts read4096records/110592B, edit fields/construct nested values
and write the complete UTF-8 JSON-lines result. Eager/streamed outputs match.
Identical frozen catalog and independent CPython full stdout/file goldens from R102
are reused byte-for-byte; no new workload framework or validation campaign.

765public/171internal focused JSON Release peractual11/10 pass, including option/
key/default order, numeric/Unicode/chunks/cycles/mutation/managed nesting, real
suspension/reentry/current cancellation, terminal first refusal, retained aliases,
shared-budget reuse and awaited cleanup. Mutable attributes are read at their
original stages; no snapshot hides callback mutations. Native encoding keeps the
existing managed call guard and translated errors. Removed transient storage no
longer needs admission; surviving traversal/output storage remains funded/preflighted.

Quiet Ubuntu24.04.4/AzureF4as_v7,4EPYC9V45vCPUs/16GiB/noswap, actual.NET11RC3;
same worker7cf37ca5/optional0.4adapter, normalGC/tiering.5swarmup/process/job,
two copies/core,7rotated150msrounds; six jobs172.758s. Command-v2 includes full
execution, mediated RAM I/O, stdout/file validation and prior-result cleanup;
excludes compilation/startup/staging/final cached teardown. Completed I/O timing
does not qualify genuinely pending-I/O latency; real suspension is tested separately.

All source/core/aux/Ready/golden/quiet/Closed/exit/join/fixture/archive/local gates
pass. B463 terminal/cached; no users/fixtures, owned RAM unmounted before archive.
Exact archived17baseline reused, uploaded onlyaae.240MiBOSfloor+7MiBevidence+
actual payload preflight, no new space maintenance/evidence/core/path deletion.
Full new-source delivery is independent; broader performance work remains.

[Controlled results](controlled-comparison.json), [allocation/desktop evidence](allocation-and-local.json),
[identity](identity.json), [status](status.json), [sources/cores/logs/raw](observations.tar.xz).
"""
(out/'README.md').write_text(readme,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+"""
## Native JSON constructor and call transport (2026-11-08)

[R105/B463](results/2026-11-08-native-json-construction/README.md) shares one
initializer across bound native module options, public construction and guest
assignment. Remove constructor dictionary/name-array and native keyword/method/
value transport; keep mutable attributes, genuine custom dispatch, managed call
guard and one R102 renderer.765public/171internal peractual11/10 pass. Eager
allocation−27.22%sync/−27.68%async, streamed−24.03/−23.85%. Controlled eager
elapsed−9.05to−9.93%sync/−9.06to−11.58%async, streamed sync−6.25to−7.00%;
coarseCPU agrees. Config elapsednearbaseline/coarseCPU+4.38to+5.70% possible debt,
CSVcontrol variable and JSONsummary possible small debt retained. Original
desktop+8.25%adverse/17.48%baseline drift remain. All gates/archive/local verification
pass,172.758s; no users/fixtures. New-source full delivery pending independently;
15c source's cached green does not qualify this prototype. No per-edit CPython replay,
old-debt repayment or broader objective closure.
"""
p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');needle='| Unified JSON encoder / normalization |';a=s.index(needle)
s=s[:a]+'| Native JSON constructor/call transport / normalization | Eager allocation −27–28%, elapsed −9–12%; streamed allocation −24%, elapsed −6–7%; coarse CPU agrees | One initializer, native keyword/method/value packaging removed. Config CPU adverse/inconclusive; full new-source qualification pending. [R105](../benchmarks/results/2026-11-08-native-json-construction/README.md) |\n'+s[a:];p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8').replace('**R105 uncommitted prototype:**','**R105 retained, uncommitted:**').replace('Controlled\n  B463 running; observe after13:57:33UTC. New-source full qualification pending.','B463\n  complete172.758s, all gates/archive/local verified: eager elapsed−9–12% bothAPIs,\n  streamed sync−6–7%, coarseCPU agrees. Configelapsednearbaseline/CPU+4.38to+5.70%\n  possible debt retained, controls uncertain. Exact new-source full delivery pending.')
s=s.replace('**R105 active prototype: native JSON constructor/call packaging.**','**Commit/qualify retained R105 native JSON construction.**').replace('exact frozen allocation/controlled comparison next; no speedup claim yet.','controlled sourcepair17/aae supports eager9–12%/streamed6–7% short elapsed gains\n   with coarseCPU agreement. Retain config possible CPU debt and all adverse originals.\n   Commit coherent deletion, batch exact new-source delivery once; no old CI replay.')
s=s.replace('B463 is the only active VM collection,\nobserve after13:57:33UTC, then join/unmount/archive and verify.','B463 terminal/archived/locally verified; no active users/fixtures.')
p.write_text(s,encoding='utf8')
print('R105 retained: complete transport phase removed, controlled eager9–12%/streamed6–7%, explicit control debt. Archive',status['archiveSHA256'])

