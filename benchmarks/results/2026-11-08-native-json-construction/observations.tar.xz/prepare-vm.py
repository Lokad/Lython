from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'completed-json-r102/b461';b=r/'b463';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['scripts.json-normalize-eager.large','warm'],['scripts.json-normalize-eager.large','warm-async'],['scripts.json-normalize-streamed.large','warm'],['scripts.config-edit.small','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.json-summary-helpers.large','warm']]
identity={**prior,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before' if role.startswith('reference') else 'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('completed-json-b461-20261108','native-json-b463-20261108').replace('lython-b461-completed-json','lython-b463-native-json').replace('completed-json-b461-launch.py','native-json-b463-launch.py').replace('lython-b461-fixtures','lython-b463-fixtures')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R105 native JSON shared constructor and direct bound argument/value transport; complete eager both APIs/streamed sync, config/CSV/decode controls"+s[z:]
 if name=='launch.py':s=s.replace("reference=base/'default-rsplit-b459-20261108/candidate'","reference=base/'completed-json-b461-20261108/candidate'")
 if name=='archive-owned.py':s=s.replace(",'space-maintenance.json'","")
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json')]:shutil.copyfile(src,b/name)
contract="""R105 one six-job controlled source pair17/aae; same worker/normalGC/tiering.
Native exact JSON encoder uses bound module storage/shared initialization and
direct eager value calls. Remove native keyword list/array, constructor dictionary/
hash lookups/name-array and eager bound-method/value packaging. Managed frame
and translation guard retained. Mutable native attributes/guest owner/setters,
overrides and general custom-class forwarding remain. No new owner/cache/settings
abstraction/pool/dispatcher.765public/171internal peractual11/10 pass.
Complete4096-record eager both APIs, streamed sync, config secondary affected,
CSV unchanged, decode-heavy JSONsummary controls. Independent CPython full goldens
reused byte-identically. Streamed async controlledCPU unmeasured (allocation tested).
Two processes percore,5swarmup/job,7rotated150msrounds, coarse process CPU.
210sowner+30stop+30margin. Full guest RAM I/O/output validation/prior cleanup
included; compilation/startup/staging/final cached teardown excluded.
Reuse archivedB461 immutable baseline17, uploadonlyaae.240MiBOSfloor+7MiBevidence+
actualuncompressedpayload preflight; all Ready/source/core/aux/quiet/golden/Closed/
join/fixtures/archive/local gates. No maintenance/evidence deletion unless a
separate fresh bounded exact-byte proof is necessary; do not imply old proof fresh.
Retain all diagnostic/adverse results. Architecture/allocation/CPU separate.
R102 eager debt remains a different sourcepair; do not silently repay it.
Full delivery of15c source is independent and does not qualify this prototype.
Publication/regex0.4 unchanged; no another external CPython refresh peredit.
"""
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/n,arcname=n)
print('B463 prepared, six jobs, reuse archived baseline17; upload onlyaae.')

