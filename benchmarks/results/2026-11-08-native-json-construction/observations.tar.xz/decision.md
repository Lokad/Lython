Retain R105: native JSON constructor/call packaging is a complete removable phase.
One shared initializer serves module-bound native options, explicit native encoder
construction and guest __init__ assignments. Constructor defaults dictionary/hash
lookups/six-name array removed. Native module calls skip eight-key forwarding List/
array and eager bound-method/value packaging; consume evaluated value directly.
Managed interpreter frame and exception translation preserved. Mutable attribute
storage remains; guest constructors/getters/setters/encode/iterencode dispatch and
unknown extras retain the genuine general path. No new settings record/cache/pool/
owner/framework/public options. New source two-file patch, not a second renderer.
765public/171internal JSON peractual11/10 pass, actual suspension/reentry/current
cancellation/terminal refusal/retained aliases/shared-budget reuse/awaited cleanup.
R102's private temporary traversal ownership and one walker remain.
Complete4096record eager allocation-27.22%sync/-27.68%async; streamed-24.03%sync/
-23.85%async; config-4.34/-4.30%. Desktop elapsed mixed/adverse, old baseline drift
up to17.48%; all original data retained, not CPU evidence.
B463172.758s sourcepair1674/aae, normal settings, all four median pairings:
eager sync elapsed-9.05to-9.93%, CPU-10%; eagerasync-9.06to-11.58%, CPU-11.11%;
streamedsync-6.25to-7.00%, CPU-5.88%. Baseline spreads0.73/1.50/0.007%, candidate
0.24/1.31/0.80%. Short observations/coarse ticks, not confidence intervals or
universal gains. Streamedasync controlledCPU unmeasured, allocation checked.
Config-0.83to+1.33%elapsed, coarseCPU+4.38to+5.70%: possible CPU debt/inconclusive,
accepted explicitly; no speedup claim from lower allocation. UnchangedCSV
-3.01to+0.69%/2.43%candidate spread, not a causal gain. JSONsummary-0.08to+0.97%/
CPU0to+2.5%, possible small debt/uncertainty. No broad retiming campaign or fixed%
veto. Earlier R102 eager/R95text/R96report debts remain distinct; no silent repayment.
All full stdout/files/Ready/core/aux/quiet/Closed/join/fixture/archive/local gates.
No remaining users/fixtures. No space maintenance/deletion this round; reused exact
archived baseline17, uploaded onlyaae,240MiBOSfloor+7MiBevidence+payload preflight.
Full exact new-source platform/Stress/installed qualification pending independently;
R102/15c CI42484943603 green does not qualify this candidate. Current CPython guide
stays named15c/R103; no per-edit external refresh. Regex/publication unchanged.
