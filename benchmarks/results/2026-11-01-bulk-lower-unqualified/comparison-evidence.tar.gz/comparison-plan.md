# Lokad.Lython 0.11.0 — active deliverables

Updated **2026-11-01** (Paris). Two independent tracks: missing producer APIs
block only final optional-adapter qualification. They do not block core work,
correctness checks or independent performance development. No publication/tag.
PLAN.md intentionally remains Git-ignored; never force-add it.

## Current checkpoint

Production **d703767c** is DELIVERED (core source unchanged from9003d045;
ordinary optional-adapter error-source correction retained). Terminal green
**41343479748** proves Windows/Ubuntu ordinary Release.NET11/10, original Stress
on both targets and explicit Release installed-package consumers. Cached terminal
proof in .git/agent-notes/review-20261031/adapter06 and the A06 evidence is final;
never query again. The prior terminal41335606172 remains historical and cached.
Local focused adapter checks84 native/424 public per target pass on ordinary0.4
and isolated dev.6, with six actual dev.6 cancellation probes. Local full9003
checks3,966 native/15,607 public per target and package proof remain historical;
no unchanged local full run is repeated. Later commits contain evidence and independent regressions only.
B72 rejection/regressions committed as081a2280; B73 evidence2b8e1cfa and
B74 rejection/header-transition regression5ccdf1a8 and B75 unqualified input trial/
independent regressions46ed95e5 are pushed. No runtime prototype remains.
Canonical local unpublished0.11 packages still identify9003d045; they were not
regenerated for this adapter-only change. Published0.10/tag remain unchanged.
No publication/tag or adapter package is authorized.

B61/B63/B64/B66/B69/B72/B74/B75 prototypes are absent. B67's independent native-call packet
admission/cancellation correction and representation-independent regressions remain.
Earlier checkpoints/experiments remain in the history/evidence below; do not repeat
unchanged full platform/package or adapter qualification.

## Lasting constraints

Fully managed/memory-safe C#, managed stack admission and host-mediated effects.
Preserve current CancellationToken, first-origin terminal admission refusal,
capacity/replacement preflights, retained aliases/results/caches and awaited actual
users/cleanup. Borrow the host allowance through existing owners; scope creation
reserves nothing. Conservative retention/earlier rejection are acceptable when
explicit; no cumulative allocation substitute for bounded host-driven batches.
No unsafe/Unsafe/pointers/PInvoke/native probes, fuel/quotas/watchdogs, hidden caps
or default allowances, guest-heap tracing, forced GC or new owner infrastructure.
No guest work after refused admission; explicit guest MemoryError remains catchable.
AGENTS.md and docs/RUNTIME.md specify current public contracts.

## Track A — core corrections and final optional-adapter qualification

Core provider boundary and B59/B60 corrections are DELIVERED: Python-specific native UTF-8 contract, byte ranges/
scalar positions, original windows, shared replacement/split/expand, explicit
funding and current tokens across frontend analysis, runtime, imports and helpers.
One borrowed provider; no backend types/dependency/dialect substitution in core.
Contract tests, Python semantics and actual backend performance remain distinct.

Ordinary non-packable adapter stays on PythonRe0.4.0. Completed A04/A05 development
qualification uses exact private0.5.0-dev.1, producer
0e24cecebbb9093a18f5cb962dae3b6f6426742c, PythonRe SHA256
`e4136eddffdca5da0b9e5733cd9534053d7d99880714669b3695be5305ed7019`.
Do not requalify unchanged artifacts or poll package indices. No sibling edits.

A06 development qualification COMPLETE against exact0.5.0-dev.6, producer
825ed1f7c4b4eb54f0e092da495396d93b435a48. PythonRe SHA256
`ffbfdcd07f85b44388b2d4352e36b0de1eafe641042c04c13c00c4a37ed928c4`;
base`6ed5a8071923966e59315883d5e7cc870488c82f1422902b837cf6a5f32f30dc`.
424 public/84 native per actual runtime pass for ordinary0.4 and private dev.6.
Six actual isolated dev.6 compile/match/cursor probes prove in-flight cancellation,
original token, joined cleanup and zero allowance. Immutable API review confirms
native UTF-8 name lookup/pattern copy, but NOT name enumeration or one-shot ranges.

The new producer exposed an adapter conversion: B60 eagerly accessed Pattern on
successful calls, decoding UTF-8 solely for potential error metadata. Pass a handle
and read its text only in the pattern-error catch. No delegate/cache/new policy,
core change, ordinary pin change or publication. The compatible ordinary adapter
correction is DELIVERED atd703767c; terminal green41343479748 covers both platforms/
targets, original Stress and explicit Release consumers. Never requery it.
One fixed dev.6 eager/fixed/identical-eager allocation comparison passes: split
-5.32%, sub-8.91%, expand-72B, text unchanged. This is allocation evidence, not a
latency gain; ordinary0.4 already stores Pattern text. The separate supplied-pin
comparison records+72B per regex job for dev.6, unchanged text. No retiming.
[All source, precise gaps, tests, actual probes and both diagnostics](benchmarks/results/2026-11-01-development-producer-dev6/README.md).
Do not repeat unchanged development artifacts. Only final released pin/qualification
waits for a new immutable released package:

| Capability still missing/unqualified | Acceptance and temporary boundary |
| --- | --- |
| Native capture names | Remove adapter-only GetGroupNames encoding bridge; preserve effective/reported flags and metadata. |
| One-shot ranges | Direct match/search/fullmatch ranges and working-funding receipt. Current API lacks overloads; conservative snapshots stay outside core. |
| Reversed windows | Qualify pos>endpos zero-width semantics with original anchors/prefix/lookbehind. Core/test provider supports them; current adapter rejects explicitly. |
| Programs/cursors | Qualify funded construction/current-token moves, independent borrows, disposal after users and actual in-flight interruption. |

When supplied: existing dependency/semantic/lifetime/refusal/reuse checks, isolated
real-cancellation probes, producer managed-safety assessment and one focused backend
comparison against the new pin. Temporary development adapter/test-provider bridges
are acceptable, never core plumbing or backend-performance evidence. No new memory
framework. A newer release cannot block Track B.

## Track B — substantial non-regex performance work

B72 REJECTED and fully removed: one52.877s controlled comparison improves the
actual integer loop13.45–13.94%, but complete text regresses1.25–2.78% and fails
the required5% workload gain. All controls/goldens/ownership/cleanup pass. No
retiming, narrower acceptance or instruction-count gain claim. Fresh nonincremental
restoration and706 native/2,977 public checks pass per actual runtime. Independent
local admission and suspended operand/cancellation regressions remain.
[Complete source/results](benchmarks/results/2026-11-01-local-updates-rejected/README.md).
This closes instruction fusion as the next whole-workload answer.

B73 CLOSED: ordinary explicit named calls do use a nested body runner, but one
6.019s/20.098s capture finds only+1.77% CSV/+0.56% text guest CPU/job, below the
frozen15% selection threshold. Full Python/Lython goldens, quiet gates, final0
budgets, joined users/profilers and fixture removal pass. No runtime prototype or
qualified timing claim; no recapture. [Evidence](benchmarks/results/2026-11-01-named-call-assessment/README.md).

B74 REJECTED and removed: plain CSV-8.32/-8.33%, helpers-6.11/-7.71%, text
control+4.16/+1.28%. Both fixed helper7.5% and text3% bounds fail despite valid
controls. Single43.646s comparison, full goldens/final budgets/cleanup pass; no
retiming or speedup retained. Fresh nonincremental restoration and337 native/
1,352 public checks pass per actual target, including new retained-row/header-type
transition golden. [Evidence](benchmarks/results/2026-11-01-csv-records-rejected/README.md).
Stop further small call/casing/record/dispatch variations as the next answer.

B75 UNQUALIFIED and fully removed: fixed60s comparison times out in the fresh
configuration control. Three completed warm cases are saved; final machine gate,
fresh/phase observations and interrupted-image managed-cleanup proof are missing.
Unqualified prefix: CSV+0.78/+0.33%, text-3.21/-2.40%, JSON+0.62/+1.41%; not a
speedup claim and not near the frozen12.5% targets. Process is terminal, group
empty, lease free; three validated owned fresh-fixture trees removed after stop.
No retiming, smaller retained fragment or new pending machinery. All production
files restored, new helper deleted, original layout test restored. Fresh Release
nonincremental build and977 native/5,747 public checks pass per actual target.
Independent result-admission, suspending type/key rebind and robust span checks
remain. [All source/observations/removal proof](benchmarks/results/2026-11-01-expression-inputs-unqualified/README.md).

B76a INDEPENDENT CORRECTION COMMITTED4cae38f4: a new final-output cancellation
control fails for ALL FIVE casing methods on isolated original9fa3f535/core9003.
The native helpers check before projection but can return after the host cancels
while admitting final UTF-8 storage. Add one shared completion/refund invariant;
keep aliases, builder cleanup and first-origin refusal. Fifteen phase-based
regressions assert cancellation/refusal/cleanup/reuse. Fresh nonincremental build
and269 native/633 public checks pass per Windows.NET11RC3/.NET10.0.8. Original
allocation bounds unchanged; bulk prototype removed while isolating this fix.
[Evidence](benchmarks/results/2026-11-01-casing-final-output-cancellation/README.md).
Pushed; ONE explicit full checkpoint workflow41357098300 is in progress (Windows/
Ubuntu ordinary NET11/10, original Stress both and installed Release consumers).
Keep working on B76; poll minutes apart and cache terminal state. Never query cached prior
41343479748 again. No release/tag/publication. Freeze new performance baseline
with this correction, so all compared images share its correctness contract.

B76 IN PROGRESS — bounded SOURCE/SEMANTIC assessment: managed bulk Unicode lowercasing,
with explicit temporary ownership and bounded cancellation work. Saved B73 text
profiles retain21/26 of183 self leaves in final-Sigma property lookup, plus scalar
mapping/builder work. B75's real instruction removal does not demonstrate a large
whole-script improvement. Hypothesis: a whole ordinary string operation may use
BCL bulk decode/map/encode more efficiently than per-scalar mapping. This is NOT
another ASCII-run, property-table or deferred-Sigma-context variant; those closed
B06/B30/B36/B56 results remain unchanged. No runtime change selected yet.
Initial Windows gate PASS: pinned.NET11RC3/.NET10.0.8 each compare1,112,062 valid
scalars (excluding U+0130/U+03A3), both alone and inside A<scalar>z; zero string/
Rune invariant-lower differences. This is NOT complete Python context, Linux,
admission/cancellation or performance qualification. Probe/source-lifetime notes
are in .git/agent-notes/review-20261031/bulk-lower-b76. Next: exact bounded
eligibility and protected-context/admission contract before any runtime edit.

First gate, without performance capture: prove the pinned managed string casing
mapping agrees with current Rune casing on valid Unicode scalars for actual
.NET11/10, and review Python's expansion/context exceptions. Preserve the existing
U+0130 expansion and final-Sigma rules; no silent dialect/Unicode fallback. Current
PyString.FromString encodes fresh UTF-8 and retains no transient UTF-16 source.
Assess bounded BCL work (a small implementation chunk, not a public string cap),
with larger/context-sensitive inputs retaining effective cooperative processing.
Do not perform a noninterruptible unbounded conversion or introduce pools/caches,
new memory infrastructure, unsafe APIs, PInvoke or a configuration switch.

Any candidate must pre-admit all temporary UTF-16 buffers/metadata plus final
UTF-8 replacement overlap using existing scratch/owner hooks, then relinquish
scratch only after every actual user completes. Extra temporary representation,
higher peak allowance and earlier denial are explicit tradeoffs, not hidden caps.
Original/retained values stay funded. Refusal remains first-origin terminal,
current cancellation is checked before/after bounded work, and aliases/results
keep their owners. If semantic equivalence or bounded/funded lifetime fails,
close this source gate before runtime edits; do not expand it into a new text VM.

B76 source/semantic gate selects a bounded bulk-lower prototype BEFORE code.
Pinned Ubuntu.NET11RC3/.NET10.0.12 also pass the1,112,062-scalar/two-context gate;
its owned service finishes277ms and is terminal. All four exact runtime results
are preserved; this is not a blanket Python/performance claim.

The correctness-fixed core7b620f89/source4cae38f4 is frozen for ALL images.
The existing per-scalar allocation regression will explicitly permit two bounded
UTF-16 temporaries plus output (5N+fixed rather than3N+fixed), still rejecting
per-character CLR-string allocation; withdraw this adaptation if rejected.

Exact eligibility: nonempty lower() input <=4,096 UTF-8 bytes and no U+0130/U+03A3.
Use managed bulk UTF-8 decode, invariant string lower, then existing funded
PyString.FromString UTF-8 construction. Ordinary eligible calls bypass the whole
per-rune/builder/property pipeline. Existing native context/large-input and other
casing consumers remain real callers; no removed path is kept for compatibility.
This bound limits one BCL work unit, not accepted input size or a host option.
No cache, pool, new owner/dispatch framework, dependencies or unsafe code.

Reserve conservative two-UTF-16-string scratch128+4*inputBytes BEFORE decoding;
existing output preflight admits final UTF-8 bytes/metadata while scratch stays
funded. FromString copies and retains no CLR string, so scratch is relinquished
only after encoding completes. Higher peak temporary allowance/earlier denial is
intentional and must be documented if retained; final ownership remains unchanged.
Check current cancellation/refusal before eligibility work, after scratch admission,
before output construction and after completion. BCL calls remain <=4KiB; longer
inputs retain current per-rune checks. On late failure, refund ONLY the private
unpublished output through the existing helper; no retry or alternate storage.
Keep original inputs/escaping aliases funded and first refusal terminal.

Acceptance: short ASCII/mixed/supplementary/width-changing mappings; the4KiB byte
boundary; Python U+0130/final-Sigma/ignorable context goldens; no input mutation;
retained results and budget reuse; scratch and output overlap refusal before
allocation; cancellation signaled by admission and after final output funding.
Existing focused native/public casing/ownership/refusal/cancellation checks on
actual.NET11/10 before timing. Add only uncovered independent regressions.
Stop/revert on semantic mismatch or if correct ownership needs new infrastructure.

Before code, freeze exact eligibility/storage/cancellation bounds, source deletion,
CPython mixed/context/expansion goldens and focused refusal/cleanup validations on
both actual targets. One <=45s before/candidate/identical-before warm comparison
only IF selected: whole unchanged text plain/helper scripts and CSV helper control,
shared CoreLib/hashes/auxiliary bits, normal GC/tiering,256 interleaved warmups,
2s settling, seven rotating32-job batches; full I/O/goldens/disposal/balances.
Require >=10% elapsed gain in BOTH whole text scripts against BOTH originals,
CSV regression/drift<=3%, IQR<=10%, >100ms batches. No retiming or rescue tuning.
Compilation/startup excluded and labeled; reuse prior separate phase evidence
with its limits. No fresh-compilation campaign for a runtime-only native helper.
Full platform/original Stress/package checks only at retained delivery.

Frontend annotation and general abstract interpretation have different reachability,
refinement and directive contracts; do not drop a pass based only on pass counts.
Preserve B67 and all delivered semantic fixes. No replay of closed B51/B53/B56/
B57/B61/B63/B64/B66/B69/B72 prototypes. Missing producer APIs never stop this track.

## Completed milestones and evidence

| Milestone | Outcome |
| --- | --- |
| B75 UNQUALIFIED | Single60s timeout during fresh control; prefix retained, no qualified gain. All seven runtime files restored/new helper deleted; independent admission/rebinding/span controls remain;977/5747 focused cases per actual target pass after fresh rebuild. [Evidence](benchmarks/results/2026-11-01-expression-inputs-unqualified/README.md). |
| B74 REJECTED | Valid plain CSV gain8.32%, but helper and text-control gates fail; all28 runtime lines removed. Independent header-transition golden remains; restored337/1352 focused cases per actual target pass. [Evidence](benchmarks/results/2026-11-01-csv-records-rejected/README.md). |
| B73 CLOSED | Named-call routing differs, but fixed selection gate misses (+1.77% CSV/+0.56% text diagnostic CPU/job); no runtime candidate or retiming. Full goldens/ownership/cleanup pass. [Evidence](benchmarks/results/2026-11-01-named-call-assessment/README.md). |
| B72 REJECTED | Valid loop gain13.45–13.94% does not reach complete workloads; text regresses1.25–2.78%. All prototype code removed, independent regressions retained;706/2,977 focused cases pass per runtime after fresh restoration. [Evidence](benchmarks/results/2026-11-01-local-updates-rejected/README.md). |
| A06 DELIVERED / DEVELOPMENT | Ordinary0.4 correction delivered green41343479748 atd703767c; exact dev.6 supplied pair qualified privately. Ordinary adapter defers error-only pattern text.424 public/84 native per runtime and six actual probes pass. Split/sub allocation-5.32%/-8.91% at dev.6; no latency claim/final release qualification. [Evidence](benchmarks/results/2026-11-01-development-producer-dev6/README.md). |
| B71 COMPLETE | Actual loop/control capture6.006s in14.078s; full gates, final budgets0 and users joined. Source proves repeated local-update instruction transport; no universal scalar rewrite or latency claim. [Evidence](benchmarks/results/2026-11-01-scalar-dispatch-attribution/README.md). |
| B70 SOURCE GATE | Numeric report measures JSON/native sum rather than per-item guest arithmetic. Source unchanged since B52; no redundant capture or numeric rewrite. Native casing and rejected B37 write consolidation remain closed. |
| B69 REJECTED | Actual call-storage elimination passes1,131/3,821 focused cases per runtime, but valid affected jobs regress5.0–6.8%; JSON control inconclusive. Prototype removed; independent lifetime regression retained. [Evidence](benchmarks/results/2026-11-01-call-arena-rejected/README.md). |
| B67 DELIVERED | Native call-packet funding/cancellation, primed-capacity denial and cleanup. Full local3,966/15,607 per runtime; Windows/Ubuntu ordinary/original Stress/package consumers green41335606172 at9003d045. |
| B68 UNQUALIFIED | Phase diagnostic completes, subsequent capture exceeds6s; no retry or speedup. Current setup is small in these observed fresh jobs; saved compiler/guest samples remain diagnostic. [Evidence](benchmarks/results/2026-11-01-fresh-config-attribution/README.md). |
| B66 UNQUALIFIED | Compiler/static-layout and linear-engine candidate passes596/5,725 focused checks per target; single90s comparison times out with empty aggregate output. Entire prototype removed; independent call-packet admission fix retained. [Evidence](benchmarks/results/2026-11-01-static-operands-unqualified/README.md). |
| B65 CLOSED | One differential helper-source capture,9.153s within24s owned service; material whole-path effect, distributed attribution, no runtime candidate/speedup inferred. All output/ownership/cleanup controls pass. [Evidence](benchmarks/results/2026-11-01-helper-call-attribution/README.md). |
| B64 REJECTED | UTF-8 windows miss fixed text gain; helper timing additionally IQR73.64% inconclusive. All prototype code removed, four independent regressions retained;1,411/4,867 focused checks pass per target. [Evidence](benchmarks/results/2026-11-01-string-windows-rejected/README.md). |
| B63 UNQUALIFIED | Capacity proposal stopped at broad migration gate:100/803 initial native failures; no test changes/timing. Original restored,803 pass per target. [Evidence](benchmarks/results/2026-11-01-admission-capacity-unqualified/README.md). |
| B62 CLOSED | Source gate: native executable operators/indexing/truthiness and JSON UTF-8 paths already exist. No duplicate implementation, tests or timing. |
| B59 | Delete267-line legacy regex pass and duplicate flag checks; typed flow owns bindings, raw pattern syntax belongs to the provider.12 new controls/eight Python goldens. Modest compilation observations, no qualified speedup. [Evidence](benchmarks/results/2026-11-01-typed-regex-analysis/README.md). |
| B60 | Python PatternError constructor/mutable fields/stable args/original patterns/scalar positions; optional0.4 UTF-16 failure bridge.21 Python goldens/12 lifetime controls. CSV valid/no material regression; error timing inconclusive. Full delivery above. [Evidence](benchmarks/results/2026-11-01-pattern-error-metadata/README.md). |
| B61 REJECTED | One36s comparison: CSV+2.47%/+3.79%, text+3.61%/+2.12%, valid affected controls; JSON control IQR62.43% fails. Prototype removed/restored/tested; no replay or speedup claim. [All source, failures, gates and samples](benchmarks/results/2026-11-01-call-control-rejected/README.md). |
| B58 | Same-bits expanded helper expressions change complete CSV-16.31%/-17.88%, text-13.95%/-13.59%; valid controls. Material source effect, no runtime gain/removable fraction. [Evidence](benchmarks/results/2026-11-01-helper-cost-assessment/README.md). |

Current external guide measures830c6251, not HEAD: warm diagnostic gaps2.08x CSV/
4.93x text/1.84x JSON; fresh text is inconclusive. Keep its boundaries, compilation,
startup/I/O/cleanup limitations and historical adverse observations visible.
[Maintained guide](docs/BENCHMARKS.md); no new external ratio from internal trials.

Earlier completed work, experiments, rejected approaches and cached terminal runs
remain in .git/agent-notes/PLAN-history-through-B75.md and previous ledgers, with
immutable source/measurement evidence under benchmarks/results/. Do not reopen
B51/B53/B56/B57/B61 prototypes, poll historical CI or repeat unchanged adapter
qualification. Keep current docs concise; experimental narratives stay outside docs/.
