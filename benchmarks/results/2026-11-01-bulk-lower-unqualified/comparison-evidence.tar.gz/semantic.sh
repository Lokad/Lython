set -eu
root=/home/lokad/lython-bench-checks/bulk-lower-b76-20261101
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
for tfm in net11.0 net10.0;do "$DOTNET_ROOT/dotnet" "$root/semantic/$tfm/semantic.dll" > "$root/bcl-equivalence-ubuntu-$tfm.json";done
