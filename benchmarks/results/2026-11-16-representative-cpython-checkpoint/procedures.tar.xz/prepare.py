from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;base=r.parent/'kernel-r436/refined';old=r.parent/'line-cpython-r432/checkpoint';before=json.loads((base/'quiet/config.json').read_text(encoding='utf-8'));sha=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('312f5911')
rep=json.loads((r.parent/'subtext-storage-r435/quiet/retrieved/representative.json').read_text(encoding='utf-8'));search=json.loads((r.parent/'prepared-stores-r413/checkpoint/retrieved/representative.json').read_text(encoding='utf-8'));ids=['scripts.csv-invoice.large','scripts.text-normalization.large','scripts.json-summary-helpers.large','scripts.file-search.large.protected'];catalog=dict(rep);catalog['cases']=[next(x for x in rep['cases']+search['cases']if x['id']==id)for id in ids]
for x in catalog['cases']:
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert sha(x[field].encode())==x[key]
catalogRaw=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode();(r/'catalog.json').write_bytes(catalogRaw)
archive='benchmarks/results/2026-11-16-shared-subtext/procedure-and-image.tar.xz';raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',head+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as t:core=t.extractfile('frozen/candidate/Lokad.Lython.dll').read()
alias=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert sha(core)==alias['sha256']and len(core)==alias['bytes'];proof=dict(alias);proof.pop('freeBytes');proof['custody']=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member='frozen/candidate/Lokad.Lython.dll')
for index,pair in enumerate([ids[:2],ids[2:]]):
 q=r/('phase-'+str(index+1));q.mkdir();number=835+index;root=f'/home/lokad/lython-bench-checks/representative-b{number}-20261116';unit=f'lython-b{number}-representative-20261116';source=before['root']
 image=before['identity']['imageFiles']['candidate'];identity=dict(sourceRevision=head+'/frozen0443b5cf',runtimeCommit=head,purpose='Fixed four-case catalog, complete CSV/text/JSON/file scripts against CPython3.13.16: compile,warm,compile-run separated. No causal cross-collection gain claim.',coreSHA256={label:image['Lokad.Lython.dll']for label in ['candidate','candidate-control']},auxiliaryFiles={n:h for n,h in image.items()if n!='Lokad.Lython.dll'},imageFiles={'candidate':image},catalogSHA256=sha(catalogRaw),catalogInitialization='All four cases loaded and checked once per worker, identical catalog bytes and CPython command flags across both collections.',qualification='312f5911 full43828954661 active;607committed inputs verified; focused446internal/1992public and14internal stress eachactual11/10.',publicationHeld=True)
 (q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'representative.json').write_bytes(catalogRaw)
 jobs=[[id,lane]for id in pair for lane in ['compile','warm','compile-run']]
 s=(old/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/line-cpython-b829-20261116',root);a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n"+s[b:]
 s=s.replace("        catalog=root/('additional.json'if case_id=='scripts.report-render.format-method.large'else'representative.json')","        catalog=root/'representative.json'").replace('< 190','< 250').replace('Reserve60seconds','Reserve50seconds');ast.parse(s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
 for n in ['archive-owned.py','run.sh','retrieve.py']:
  s=(base/'quiet'/n).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B834',f'B{number}').replace('==5','==6').replace('jobs=5','jobs=6').replace("['jobs']==5","['jobs']==6").replace("elapsedSeconds']<240","elapsedSeconds']<300").replace('five-job','six-job')
  if n.endswith('.py'):ast.parse(s)
  (q/n).write_text(s,encoding='utf-8',newline='\n')
 payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']}
 with tarfile.open(q/'payload.tgz','w:gz')as t:
  for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
 c=dict(root=root,unit=unit,source=source,sourceFiles=image,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(catalogRaw),identity=identity,retireGroups=[proof]if index==0 else[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
 (q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
 s=(base/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
 s=s.replace("source/'reference'","source/'candidate'").replace("for role in ['reference','candidate']:","for role in ['candidate']:").replace(" os.link(source/'representative.json',root/'representative.json')\n",'').replace('lython-b834-fixtures',f'lython-b{number}-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=300');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
 launch=(base/'launch-quiet.py').read_text(encoding='utf-8').replace("Path(__file__).parent/'quiet'","Path(__file__).parent").replace('seconds=200','seconds=260').replace('before200seconds','before260seconds').replace('Four-job','Six-job');(q/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
 s=(old/'summarize.py').read_text(encoding='utf-8').replace('==2','==6').replace('jobs=2','jobs=6');ast.parse(s);(q/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(catalogSHA256=sha(catalogRaw),catalogBytes=len(catalogRaw),cases=ids,jobs=12,boundedCollections=2,source=head)))
