from pathlib import Path
import base64,hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-16-representative-cpython-checkpoint');out.mkdir();rows=[];times=[]
for index in [1,2]:
 q=r/f'phase-{index}';receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));summary=json.loads((q/'summary.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['archivedAndVerifiedUnderLease']and summary['complete'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 d=out/f'phase-{index}';d.mkdir();rows+=summary['timing'];times.append(receipt['elapsedSeconds'])
 for n in ['identity.json','summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,d/n)
assert len(rows)==12
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));cases={x['id']:x for x in catalog['cases']};catalogSHA=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest();assert all(json.loads((r/f'phase-{i}/identity.json').read_text(encoding='utf-8'))['catalogSHA256']==catalogSHA for i in [1,2]);ident=json.loads((r/'phase-1/identity.json').read_text(encoding='utf-8'))
summary=dict(complete=True,sourceRevision=ident['sourceRevision'],catalogSHA256=catalogSHA,catalogInitialization=ident['catalogInitialization'],externalBaseline='CPython3.13.16',elapsedSeconds=times,rows=rows,performanceQualified=False,wholeScriptPerformanceObjectiveComplete=False,causalSourceGainClaim=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname=p.name)
 t.add(r/'historical-aliases.json',arcname='historical-aliases.json')
 for i in [1,2]:
  q=r/f'phase-{i}'
  for p in q.iterdir():
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname=f'phase-{i}/'+p.name)
labels={'scripts.csv-invoice.large':'CSV invoice','scripts.text-normalization.large':'Text normalization','scripts.json-summary-helpers.large':'JSON-lines aggregation','scripts.file-search.large.protected':'File search / defensive helper'}
inputs={id:sum(len(base64.b64decode(v))for v in json.loads(x['fixtureJson'])['inputFiles'].values())for id,x in cases.items()}
inputLabels={id:f'{n:,} B'for id,n in inputs.items()};inputLabels.update({'scripts.csv-invoice.large':f'4,096 records / {inputs["scripts.csv-invoice.large"]:,} B','scripts.text-normalization.large':f'4,096 lines / {inputs["scripts.text-normalization.large"]:,} B','scripts.json-summary-helpers.large':f'4,096 records / {inputs["scripts.json-summary-helpers.large"]:,} B','scripts.file-search.large.protected':f'2,049 lines / {inputs["scripts.file-search.large.protected"]:,} B; stop at 1,025'})
span=lambda x,a,b:f'{min(x[a],x[b]):.3f}–{max(x[a],x[b]):.3f}'
ratio=lambda x:f'{min(x["ratioRange"]):.2f}–{max(x["ratioRange"]):.2f}×'
status=lambda x:f'Diagnostic; controls L/C {x["lythonControlPercent"]:.2f}/{x["cpythonControlPercent"]:.2f}%; IQR≤{x["maxIqrPercent"]:.2f}%'
warm=['| Workload / warm execution | Input | Lython | CPython | Lython / CPython | Measurement status |','| --- | --- | ---: | ---: | ---: | --- |'];phases=['| Workload | Phase | Lython | CPython | Ratio | Measurement status |','| --- | --- | ---: | ---: | ---: | --- |']
for x in rows:
 m=x['medianMilliseconds'];id=x['case'];s=f'{span(m,"candidate","candidate-control")} ms | {span(m,"CPython","CPython-control")} ms | {ratio(x)} | {status(x)} |'
 if x['lane']=='warm':warm.append(f'| {labels[id]} | {inputLabels[id]} | '+s)
 else:phases.append(f'| {labels[id]} | '+('Compilation only'if x['lane']=='compile'else'Compile and execute once')+' | '+s)
guide=Path('docs/BENCHMARKS.md');shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
text='''# Performance against CPython

'''+ '\n'.join(warm)+'''

**Ratio = Lython elapsed / CPython elapsed; above one means slower.** These are
complete scripts inside warm processes, with two independent processes per engine.
Ranges are process-median combinations, not confidence intervals. Control movement
and sample IQRs remain visible; exact magnitudes are diagnostic.

Measured **2026-11-16 UTC**, Lython **312f5911 / frozen0443b5cf** versus stock
**CPython3.13.16**. Quiet Azure F4as_v7 / Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,
16GiB/no swap; .NET11RC3 natural workstation GC/normal tiering, CPython GIL/GC.
Every worker loads the same four-case catalog, SHA43b7c6b0; initialization and
startup are outside the clocks. Two six-job collections use5s full-request warmup
and five rotated approximately0.5s rounds; all image/golden/quiet/join/archive gates
pass. [Raw results, identities and procedure](../benchmarks/results/2026-11-16-representative-cpython-checkpoint/README.md).

Warm includes synchronous Run, mediated RAM I/O, complete stdout/file goldens and
prior-result cleanup. It excludes compilation/startup, fixture reset/protocol and
final cache teardown. Lython's host performs capability/shared-budget checks;
CPython uses native buffered files without equivalent containment. These are useful
embedding comparisons, not isolated interpreter CPU or storage-device throughput.
No startup, pending-I/O, contention, heap/RSS or embedding-tail comparison is available.

## Compilation and newly generated scripts

'''+ '\n'.join(phases)+'''

Compilation includes compiled-owner disposal; compile-to-result includes compilation,
one execution and compiled-owner disposal. Independently warmed phase medians are
not additive. Wider process CPU in the artifacts also includes reset/protocol.
Compilation is not the main gap in these measured scripts; text normalization
retains a substantial execution gap. This does not establish the cause of that gap.

## Historical and unresolved measurements

The [preceding guide](../benchmarks/results/2026-11-16-representative-cpython-checkpoint/prior-BENCHMARKS.md)
preserves report, patch, configuration, captured text and async measurements with
their actual earlier revisions. They do not describe current HEAD. All original
controls and adverse cases remain linked; no source-change gain or regression
recovery is inferred across collections.

In particular, normalization CPython shifted about0.73→0.50ms in earlier same-case
collections despite identical worker/binary/flags/case bytes. Catalog initialization
differed, but its causal effect remains unisolated. This checkpoint fixes catalog
and initialization within its twelve jobs; it does not explain the earlier shift.
Moving process controls remain uncertainty, not proof of a failed design.

## Improvements within Lython

Source-pair results are separate from CPython and cannot be added together:

| Change / affected workload | Separate source-pair evidence | Limits |
| --- | --- | --- |
| Shared immutable subtext / complete normalization and JSON-lines | Allocation−19.8%/−11.3%; normalization warm1.8–4.6%lower elapsed, JSON2.9–5.6%lower, supporting CPU | Full backing stays charged for surviving views; fresh reference moves3.37%. [Evidence and full delivery](../benchmarks/results/2026-11-16-shared-subtext/README.md). |
| Shared line construction / normalization | Allocation−1.73%; warm3.8–8.5%lower elapsed, supporting CPU | Original failed idle gate and moving JSON control retained. [Evidence and full delivery](../benchmarks/results/2026-11-16-line-construction/confirmation/README.md). |
| Final-slot range transport / diagnostic module and generator drain | Allocation−97.8%/−13.7%; module24–26%lower elapsed through Run/27%through RunAsync; generator6–8%lower, supporting CPU | Native helper roughly flat; CSV inconclusive with3.58%moving controls. No broad file-script gain. [Refinement/original adversity](../benchmarks/results/2026-11-16-iteration-slot-transport/refined/README.md); full delivery pending. |

Historical native helper returns establish19–20%less allocation; original elapsed
gains remain diagnostic. Direct UTF8 formatting establishes8.67%less allocation;
[controlled confirmation](../benchmarks/results/2026-11-02-formatting-confirmation/README.md)
supports5–8%lower report elapsed/CPU, while original adverse15.125ms remains unexplained.
Other improvements, rejected call-arena/controller designs and accepted regression
debts remain in [experimental history](../benchmarks/EXPERIMENTS.md). Historical
thresholds and one-attempt rules do not govern current work.

Use the [existing comparison tooling](../benchmarks/README.md) for reproduction;
detailed qualification and exact commands stay with each immutable result. No NuGet
publication follows from measurements or qualification.
''';guide.write_text(text,encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Representative CPython checkpoint

R437/B835–B836,2026-11-16UTC. Committed312f5911,measured0443b5cf versus
CPython3.13.16. Twelve complete compile/warm/compile-run jobs, two bounded six-job
collections. [Current guide](../../../docs/BENCHMARKS.md) defines phases,inputs,
ratios and uncertainty; [summary](summary.json) preserves every process/control.

Fixed four-case catalog43b7c6b0 loaded once by every worker in both collections;
same exact source/fixture/goldens and command-v2 workers. All complete stdout/file
goldens, actual library/catalog identities, quiet-before/after, Closed/exit/join,
persisted archive/hash and RAM teardown checks pass. No users abandoned. Normal
tiering/natural GC, five-second full-request warmup/five rotated~0.5s rounds,
four process pairings per row, not confidence intervals. Full wider CPU and all
warmup responses remain; compilation/startup are not part of warm execution.

Quiet F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 natural
workstation GC and stock CPython GIL/GC. Lython uses mediated RAM files and shared
admission; CPython uses native buffered files. Warm includes goldens and prior-result
cleanup, excludes reset/protocol/final cache teardown; wider CPU includes reset/protocol.
Compilation includes compiled-owner disposal; fresh includes compilation and one run.
Independent medians are not additive; no heap/startup/pending-I/O/embedding-tail claim.

These are diagnostic external comparisons, not causal source gains. Compilation is
near CPython in CSV/text; normalization still has a substantial execution gap.
Moving controls and previous unexplained CPython shift remain explicit. Identical
catalog setup within this checkpoint does not isolate an older cross-collection cause.
Full platform/stress/package qualification43828954661 runs independently; exact607
source inputs match312f5911 and [the retained image](../2026-11-16-iteration-slot-transport/refined/README.md).

Only exact committed previous1c8e working image aliases retired after fresh owned
lease/UID/path/hash/all-alias checks; all previous image bytes remain in committed
archives. Current0443 image/toolchains and254/252MiB floors kept. No cleanup or
source-golden relaxation. Both measurement terminals cached; publication held.

[Phase one raw](phase-1/observations.tgz),[phase two raw](phase-2/observations.tgz),
[all procedures/custody](procedures.tar.xz),[preceding guide](prior-BENCHMARKS.md).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R437 fixed-catalog CPython checkpoint](results/2026-11-16-representative-cpython-checkpoint/README.md):312f5911/0443b5cf versus CPython3.13.16,twelve complete phases/two bounded collections,all gates. Four representative CSV/text/JSON/search scripts,compilation/warm/fresh separated; all processes use catalog43b7c6b0. Ratios/control movement preserved, no causal cross-collection gain or explanation of earlier CPython shift. Current guide leads with four warm rows; prior mixed-revision table preserved as historical. Broader whole-script objective remains open.\n';p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=len(rows),elapsedSeconds=times,inputBytes=inputs,catalogSHA256=catalogSHA,warmRatios={x['case']:x['ratioRange']for x in rows if x['lane']=='warm'})))
