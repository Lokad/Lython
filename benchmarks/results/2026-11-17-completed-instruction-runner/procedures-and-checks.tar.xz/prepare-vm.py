from pathlib import Path
import ast

notes = Path(__file__).parent
source = (notes.parent/'native-generators-r494/refined/prepare-quiet.py').read_text(encoding='utf-8')
source = source.replace("old=r.parent.parent/'json-scalars-r492'", "old=r.parent/'json-scalars-r492'")
a = source.index('subjects=[]')
b = source.index('assert not set', a)
source = source[:a] + '''subjects=[]
canonical='benchmarks/results/2026-11-17-native-generator-loop/refined/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-native-generator-loop/refined/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else archive.extractfile(member).read()
  subjects.append(dict(kind='completed-replica',path='native-generators-refined-b914-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-call-packet-lifetimes/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
subjects.append(dict(kind='completed-replica',path='call-packet-lifetimes-b905-20261117/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-tab-expansion/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
assert hashlib.sha256(data).hexdigest()=='6a91212d6e978ce9d055fc18a2002cd13204d9395faad05d47f1f6a50f136af7'
subjects.append(dict(kind='completed-replica',path='tab-expansion-b870-20261117/confirmation/confirmation.json',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
''' + source[b:]
source = source.replace("donor=json.loads((r.parent/'confirm/quiet/config.json').read_text(encoding='utf-8'))",
                        "donor=json.loads((r.parent/'native-generators-r494/refined/quiet/config.json').read_text(encoding='utf-8'));donor['root']='/home/lokad/lython-bench-checks/native-generators-refined-b914-20261117'")
source = source.replace("(r.parent/'launch.py').read_text(encoding='utf-8')", "(r.parent/'native-generators-r494/launch.py').read_text(encoding='utf-8')")
source = source.replace(".replace('json-cpython-b908-20261117','native-generator-confirm-b913-20261117')",
                        ".replace('json-cpython-b908-20261117','native-generators-refined-b914-20261117').replace(\"source/'candidate/Lokad.Lython.dll'\",\"source/'reference/Lokad.Lython.dll'\")")
source = source.replace("remote='/home/lokad/lython-bench-checks/native-generators-refined-b914-20261117'",
                        "remote='/home/lokad/lython-bench-checks/completed-runner-b915-20261117'")
source = source.replace('lython-b914-native-generators-refined-20261117', 'lython-b915-completed-runner-20261117')
source = source.replace('lython-b914-fixtures', 'lython-b915-fixtures').replace("'B914'", "'B915'")
source = source.replace('Fully qualified33bd7efd/5e7058a3 versus refined privateR494 on22d5a5f3; redundant frame reference removed',
                        'Fully qualified33bd7efd/5e7058a3 versus privateR495 on22d5a5f3; single completed-instruction loop and corrected call-loan cleanup bound')
source = source.replace('Reuse existing native loop for buffered executable generators; same admitted slots/PC/frame cleanup, no new dispatcher/owner.',
                        'One existing completed-instruction runner for borrowed prefixes and admitted frames; duplicate native loop/eligibility scan/call-format-publication removed. Existing binding, ownership and async lifecycles.')
# The reference image already exists under its verified immutable donor. Ship
# only the changed core; preserve the original staging and final space floors.
source = source.replace("for role in ['reference','candidate']:\n (q/role).mkdir();", "for role in ['candidate']:\n (q/role).mkdir();")
ast.parse(source)
(notes/'prepare-quiet.py').write_text(source, encoding='utf-8')
print('Prepared the existing five-job collection; staging requires completed correctness/freeze checks.')
