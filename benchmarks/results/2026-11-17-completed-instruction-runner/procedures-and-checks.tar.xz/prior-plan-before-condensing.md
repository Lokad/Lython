# Lokad.Lython 0.11.0

Updated 2026-11-17 UTC. Git-ignored; never force-add. Publication and tagging held.
Objective: coherent simplification and substantial complete-script performance,
including compilation and a single execution in an already-running host. An
isolated experiment does not complete this objective. Current contracts: docs/.
Historical evidence and decisions: [benchmarks/EXPERIMENTS.md](benchmarks/EXPERIMENTS.md).

## Delivery status

| State | Deliverable and limits |
| --- | --- |
| Fully qualified | Shared compiler-fact/callback correction `61237f58`; native helper returns `8f07764a`. Allocation reduction approximately 19–20%; elapsed gains remain diagnostic. No unchanged qualification outstanding. |
| Fully qualified | Direct UTF-8 formatting/storage: allocation reduction 8.67%; controlled report elapsed/CPU 5–8% lower supports retention. Original adverse 15.125 ms remains preserved and unexplained; new evidence can reopen the decision. |
| Completed; evidence retained | Prepared calls/direct operands, executable generators, shared builtin metadata/reused async workers, UTF-8 backing/casing, sequence construction R460, receiver pipeline `ccf20ba3`, float transport `dc480d38`, generator-sum lifetimes `abcbd9fd`, unary transport `d8611c85`, widths `dbdf8262`. Do not repeat completed work or qualification. |
| Fully qualified | R489 `add2c00a`, GREEN 44103214418: corrected ordinary scratch versus retainable bound-prefix lifetimes. Both prior failed designs remain in history; their erroneous blanket retention/clearing contracts are superseded. |
| Fully qualified | R488 `557381fe`, GREEN 44116196658: managed scoped locking in the default shared allowance. Modest confirmed JSON benefit; first adverse process unexplained, CSV/text gains unestablished. |
| Latest fully qualified runtime | R492 `33bd7efd`, GREEN 44128892209 at `22d5a5f3`; delivery evidence `3f08da40`. Both platforms and actual .NET 11/10: 4,830 internal/18,013 public ordinary, 14/406 original stress, installed Release consumers. Sixteen summaries/2,382 inputs/585 production files verified. |
| Active private foundation; not promoted | R494 refined `a5e20232` on `22d5a5f3`: reuse the existing native loop over admitted generator state; redundant frame reference removed. Correctness and text gains established at named conditions, fresh/helper regression debt prevents standalone promotion. Joint R495 gate below. |
| Active implementation; not qualified | R495 shared completed-instruction runner on the R494 private foundation. Managed span/ref gate passes actual 11/10. Duplicate native opcode loop, call/format/publication logic and whole-code opcode eligibility scan removed in the prototype; common storage/call connections are under focused validation. No elapsed or allocation result yet. |
| Independent regex | Core-owned Python/native UTF-8 contract delivered; immutable development producer 105 focused qualification complete. Normal optional, non-packable adapter remains 0.4.0. Only affected final adapter qualification waits for producer capabilities. |

[Current full delivery](benchmarks/results/2026-11-17-json-scalar-construction/delivery/README.md).
No dormant withdrawn prototypes remain in production. R494 is isolated in
`.git/agent-worktrees/native-generators-r494`; main production remains R492.

## Priority: one coherent completed-instruction runner

R490's current numerical attribution: 949 samples/81 unknown leaves; nearest
prefix 152, stack transfer 85, indexing 110; JSON inclusive 190, admission 1.
Groups overlap useful/inlined work, not removable percentages. Native generator
sum already consumes slots directly; ordinary scalars already use headroom;
ExecutableSlot already contains one reference and one long. R493 finds only two
adjacent global consumers in the floating generator, none in four other inspected
scripts. No broad global-cache/slot-format/admission redesign follows from that.

R492 removes default scalar ValueTask repackaging into iterative JSON construction.
Allocation/peaks effectively flat. Stable helper elapsed +1.3–1.5% accepted for the
simpler path; floating fresh improved diagnostically, warm remained inconclusive.
Its full qualification is complete. [Conditions/debt](benchmarks/results/2026-11-17-json-scalar-construction/README.md).

R494 proves existing native instructions can consume the generator's admitted
slots/PC/caches and shared yield/cleanup state without a third opcode loop or
new owner. Actual 11/10 each 627 internal/1,808 public focused checks pass;
eight subsequent targeted cases overlap these checks and add held cleanup,
partial-helper I/O, aliases, terminal refusal, cancellation/reuse and lambda/send/
consumer boundaries. Both API probes match CPython; five copied-worker goldens
and allocation/budget reuse checks pass. Measured source retains its seven-case
fixture; the later pure case is preserved separately. Production did not change.

First footprint B912: floating warm 4.4–6.0% lower, text 3.7–7.3% lower; fresh and
controls uncertain. B913 confirmation: fresh 2.1–4.9% lower, call control near flat;
helper still uncertain. Original adverse call process remains unexplained.
Refined B914: text 4.5–6.3% lower, floating warm inconclusive, fresh 1.5–8.8% higher
(controls 2.46/4.71%), helper 1.5–2.6% higher with close controls. Allocation
effectively flat and peaks unchanged. [All conditions and debt](benchmarks/results/2026-11-17-native-generator-loop/refined/README.md).

Do not promote R494 alone or relabel uncertainty as failure. R495 is a bounded
source/design gate toward one completed-instruction runner over the existing
admitted or borrowed values. Hypothesis: removing duplicate dispatch and PC/live-
extent handoff, rather than adding generator-specific view branches, can simplify
the implementation and improve helper-heavy reports/text and compile-to-result.
Target deletions: duplicate `NativeExecution.RunCore`, native whole-code opcode
eligibility scanning, and displaced adapters/selection helpers. Preserve final
instructions, compiler facts, the current call ABI and deferred-frame behavior.

Settle a memory-safe span/ref representation with one authoritative PC/live extent,
exact protocol/child/disposal handoff and no replay before coding. The current
array-only persistent work state and stack-borrowed native prefix are the concrete
representation issue. Ephemeral views must end before suspension; existing owned
frames/allowances continue to retain all users. No third dispatcher, binding-view
packaging layer, arena, new policy/owner, universal tagged values or public option.

Gate stopping criterion: a concrete deletion/replacement map fitting the existing
engine, or a named technical blocker. Do not silently expand into a general
compiler/storage rewrite. If that scope is required, withdraw the private R494
foundation, retain independent regressions and select the next demonstrated cost.
Joint completion requires actual semantic/cancellation/ownership checks on 11/10,
verified workers and one bounded floating warm/fresh, text/helper and call-control
pair; explicitly resolve or decide fresh/helper regression debt before promotion.
Temporary setbacks remain development debt with this completion milestone.

R495 gate passes for a bounded existing-engine migration. A disposable managed
span/ref probe compiles/runs on actual 11/10, sharing stack and class-owned PC/live
state without a view crossing await. Use one NativeExecution view over the existing
work state's metadata plus admitted/borrowed values; no third runner or owner.
Port the existing common dispatch and its approximately20 typed operation helpers
to that view; persistent work/async drivers keep their current lifecycle. Add span
forms of storage operations without changing array ownership. Stack prefixes keep
their current cursor representation, so no private iteration-position backing
needs a new transfer protocol. Delete NativeExecution.RunCore, duplicate call/
format/publication logic, R494's generator-only bridge and whole-code native opcode
eligibility scan. Preserve function binding ABI, unmanaged-free compilation,
first-refusal/cleanup, managed admission, native returns and real async protocols.
No source/CPU gain claim before focused checks and the joint affected pair.

Implementation checkpoint: complete nonincremental Release rebuild passes, and
actual 11/10 each pass 1,006 internal/4,217 public focused checks. List/tuple
construction now reads the same borrowed/admitted slots; nested helpers preserve
their existing prepared-child transfer without replay. Orphaned native integer
dispatch and its publication helper are deleted. The persistent async driver,
call binding and ownership lifecycles remain. This source state is private and
not fully qualified; old R494 measurements do not describe it. Evidence and failed port
conditions are retained under the private R495 notes until a coherent decision.
One existing cancellation regression exposed a shared compiler cleanup-bound
omission: directly consumed/forwarded call results can own private range loans.
Record those result slots in the existing bound, replacing the native final full
scan. Its refusal/alias/cleanup assertions remain. Preserve simple loop exits and
unboxed integer comparisons in the common path. Frozen worker/golden/allocation
checks precede the existing five-job comparison; no performance claim yet.

## Subsequent substantial deliverables

| Deliverable / complete scripts | Eliminated work, acceptance and bounded decision |
| --- | --- |
| Complete call/frame/operand transport: helper search/reports | After the shared-runner gate, eliminate a demonstrated remaining binding/activation stage. Preserve defaults/keywords/cells/identity, effect/error order and genuine suspension. Existing helpers already borrow/defer frames. R485 widened views still repackaged entries; R469/R470/R473/R474/R481 arenas/controllers/windows were slower or added unjustified storage. Do not rename those designs. Name displaced code, scripts/control and comparison before implementation. |
| Per-record construction: CSV/JSON aggregates/manifests | Earlier 6–8% CSV work is integrated: aggregate admission/shared keys/final rows, confirmed R482. JSON already shares layouts/options and iterative construction. A revised design must replace real construction, preserve duplicate/short/wide rows, callbacks/aliases, overlap and first refusal; no duplicate caches or lazy identity ledger. |
| Scalar/text publication: normalization/numeric reports | Widths/native return transport already improved. Mutable slots must preserve canonical aliases through withdrawal/mutation and replace direct-array adoption. Begin with actual remaining conversions/storage, not boxing alone or immutable tuple borrowing. Preserve Unicode, exact arithmetic, hooks and ownership. |
| Frontend/setup: generated config/helper scripts | Facts and prepared metadata already shared; compilation is not the dominant measured gap. Prove repeated analysis/retention before replacing passes/representations. Preserve spans/classes/cells/lazy annotations and cancellable/admitted compile-to-result. Heavyweight JIT remains lower confidence; R456 expression compilation cost about 33× and numeric warm regressed. |

Each new redesign names hypothesis, affected whole scripts/control, work/storage
and implementation removed, semantic acceptance and a bounded before/after pair.
No isolated experiment substitutes for completion of the complete-script objective.

## Measurements and decisions

CPython is the primary external baseline. R491/B908 refreshed both JSON scripts
at runtime `557381fe`/frozen `d739132f` versus stock CPython 3.13.16: helper JSON
warm 0.82–0.85×, fresh 0.86–0.87×, compile 0.98–1.02×; floating JSON warm 1.99–2.03×,
fresh 1.67–1.76×, compile 0.90–0.92×. Floating fresh controls 2.92/2.50% and compile
IQR 5.15% limit precision. Earlier text/CSV/search measurements remain named and
historical. [Authoritative guide and boundaries](docs/BENCHMARKS.md).

Refresh affected CPython comparisons at the next coherent retained/qualified
runner checkpoint, separating compilation, warm execution and compile-to-result;
include mediated I/O, goldens and result cleanup, exclude startup/reset/protocol as
documented. Do not attribute old-source measurements to HEAD or sum phase medians.

Timeouts, unstable identical controls and inconclusive observations establish
uncertainty. Allow bounded evidence-driven confirmation/refinement/measurement
repair; preserve every original failed/adverse condition. Distinguish simplicity,
allocation reduction and demonstrated CPU gain. Percentages inform decisions,
never automatically veto a coherent change. No permanent design/timing bans or
unchanged qualification replay. Original formatting, tuple-peak, scalar-publication
and async-CSV uncertainties remain in linked immutable history.

## Independent regex track

Continue core Python/native UTF-8 semantics: original-subject byte/scalar windows,
flags/names/captures/effective frontend analysis, current tokens and explicit
owners through provider/import/helper work. No backend types or dialect fallback
in core. Development producers/adapter bridges support implementation; contract
tests, semantic qualification and backend performance remain distinct.

Read-only committed sibling `a370f693` removes text FindAll/split/borrowed getters
and scalar-coordinate APIs. Still missing: UTF-8 group-name enumeration (lookup/
pattern copy exist), creation/preparation token lifetime independent of retained
cursor pulls (moves still link creation/current tokens), and separately selected
per-match staging/result allowance. Keep detached later-pull bridge; effective
flags do not replace initial Verbose parsing. No automatic normal pin change or
unchanged dev105 qualification. Qualify a changed immutable final package for
semantics/windows/errors/flags, in-flight interruption/unwind, aliases/reuse/
dependencies and one affected pair. Only that final affected qualification waits.

## Delivery and lasting constraints

Focused Release checks during development; batch Windows/Ubuntu actual 11/10,
original stress and installed explicit Release consumers at coherent retained
boundaries. Cache terminal/logs; live CI observations at least 240 seconds apart.
Never requery GREEN 44128892209, 44116196658, 44103214418, 44080812207, 44050323147,
44041981387, 44022750002, 44072440304 or failed 44067803913/44091209377/44098253722.

[AGENTS](AGENTS.md)/[RUNTIME](docs/RUNTIME.md): fully managed and memory-safe;
no unsafe/Unsafe APIs/pointers/PInvoke/native probing. Preserve managed stack,
host capabilities, cooperative cancellation, borrowed shared admission, capacity/
replacement overlap, retained aliases/caches/pending users and awaited cleanup.
First refusal terminal. No fuel/quotas/hidden caps/allowances/tracing/weak
reclamation/forced GC/abandoned work. Bounded host-driven streaming remains.
Ordinary caller scratch clears/refunds after users finish; fresh major bound
prefixes retain execution/result ownership; existing minor headroom remains.

Freeze copied complete images after nonincremental builds and verify actual
catalog workers. Join/SHA-archive RAM before unmount. Retire only exact committed
replicas with fresh lease/path/UID/hash/link/all-alias proof; preserve current
qualified images/toolchains/canonicals and 254/252 MiB floors. VM:
lokad@20.166.121.73, ~/.ssh/id_lython-bench.pem. Current VM qualified reference
5e7058a3/refined candidate a5e20232 and primary five-case catalog remain intact.
Terminal B912/B913/B914 cached; no RAM fixtures or workers remain from these runs.
Only core Release packages via pack.ps1 to artifacts/nuget; adapter non-packable.
Publication/tagging held.
