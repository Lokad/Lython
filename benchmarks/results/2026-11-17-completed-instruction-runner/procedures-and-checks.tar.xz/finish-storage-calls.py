from pathlib import Path

root = Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494/src/Lokad.Lython/Runtime')

def edit(name, old, new):
    p = root / name
    text = p.read_text(encoding='utf-8')
    assert old in text, (name, old[:100])
    p.write_text(text.replace(old, new), encoding='utf-8')

edit('LythonRuntime.Executable.Operations.cs',
     'CreateListFromStack(ref ExecutableValueStorage stack,',
     'CreateListFromStack(ref NativeExecution execution,')
edit('LythonRuntime.Executable.Operations.cs', 'items[i] = stack[start + i];', 'items[i] = execution[start + i];')
edit('LythonRuntime.Executable.Operations.cs', 'stack.RetireTo(start);', 'execution.RetireTo(start);')
edit('LythonRuntime.Executable.Operations.cs',
     'CreateTupleFromStack(ref ExecutableValueStorage stack,',
     'CreateTupleFromStack(ref NativeExecution execution,')
edit('LythonRuntime.Executable.Operations.cs',
     'CreateSlotTuple(stack.Values.AsSpan(start, count), context, span)',
     'CreateSlotTuple(execution.Values.Slice(start, count), context, span)')
edit('LythonRuntime.Executable.Interpreter.Dispatch.cs', 'CreateListFromStack(ref execution.Stack,', 'CreateListFromStack(ref execution,')
edit('LythonRuntime.Executable.Interpreter.Dispatch.cs', 'CreateTupleFromStack(ref execution.Stack,', 'CreateTupleFromStack(ref execution,')

edit('LythonRuntime.Executable.Calls.Invoke.cs',
     'function.CanStartInline && invocation is not null)',
     'function.CanStartInline\n                && (invocation is not null || scope.State.CurrentRecursionDepth < NativeCallDepth))')
edit('LythonRuntime.Executable.Calls.Invoke.cs',
     'var unpackedReturn = PrepareUnpackedCallReturn(ref execution, call, start, out var originalExtent);',
     '''var originalExtent = execution.LiveExtent;
                    var unpackedReturn = invocation is not null
                        ? PrepareUnpackedCallReturn(ref execution, call, start, out originalExtent) : default;''')
edit('LythonRuntime.Executable.Calls.Invoke.cs',
     '''if (frame is not null)
                    {
                        try''',
     '''if (frame is not null)
                    {
                        if (invocation is null)
                        {
                            // The caller first acquires its owned continuation.
                            // Preserve the child's PC and completed effects once.
                            execution.RetainPreparedChild(frame, function.DefinitionContext.MemoryGovernor);
                            started = frame;
                            callEntered = false;
                            return true;
                        }
                        try''')
edit('LythonRuntime.Executable.Calls.Invoke.cs',
     '''            if (call.HasReceiver && call.IsPositionalOnly)
''',
     '''            if (!call.HasReceiver && call.IsPositionalOnly && IsRangeBuiltin(target))
            {
                if (!TryInvokeNativeRange(execution.Values.Slice(start + call.ArgumentOffset, call.ArgumentCount),
                    call.CallSpan, scope, out var range)) return false;
                PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[execution.InstructionIndex], range);
                return true;
            }

            if (call.HasReceiver && call.IsPositionalOnly)
''')

p = root / 'LythonRuntime.Executable.Integers.cs'
text = p.read_text(encoding='utf-8')
start = text.index('    internal ref partial struct NativeExecution')
p.write_text(text[:start].rstrip() + '\n}\n', encoding='utf-8')
edit('LythonRuntime.Executable.NativePrefix.cs',
     '''        internal readonly ExecutionContext? Invocation;
''', '')
edit('LythonRuntime.Executable.NativePrefix.cs',
     '''            Invocation = invocation;
''', '')
edit('LythonRuntime.Executable.NativePrefix.cs',
     '''        private void Publish(in ExecutableInstruction instruction, ExecutableSlot value)
            => ExecutionContext.PublishInstructionResult(ref this, Invocation, instruction, value);
''', '')
edit('LythonRuntime.Executable.NativePrefix.cs',
     'ExecutionContext scope, ExecutionContext? invocation, int unpackedReturnCount = 0)',
     'ExecutionContext scope, int unpackedReturnCount = 0)')
for p in root.glob('*.cs'):
    text = p.read_text(encoding='utf-8')
    import re
    text = re.sub(r'new NativeExecution\((ref [^,]+, [^,]+, [^,]+), (?:this|scope|context|invocation)\)', r'new NativeExecution(\1)', text)
    text = text.replace('new LythonRuntime.NativeExecution(ref work, values, Closure, null, unpackedReturn.Length)',
                        'new LythonRuntime.NativeExecution(ref work, values, Closure, unpackedReturn.Length)')
    if text != p.read_text(encoding='utf-8'):
        p.write_text(text, encoding='utf-8')
