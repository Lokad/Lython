using System.Runtime.CompilerServices;

RunBorrowed();
var frame = new Frame();
await RunOwnedAsync(frame);
if (frame.Work.Pc != 2 || frame.Work.Storage.Live != 2 || frame.Work.Storage.Values[1].Number != 9)
    throw new Exception("Owned state was copied or lost across the driver boundary.");
Console.WriteLine("Managed span/ref view aliases stack and persistent state; no view crosses await.");

static void RunBorrowed()
{
    Buffer buffer = default;
    Span<Slot> values = buffer;
    var pc = 0;
    var live = 0;
    var view = new View(values, ref pc, ref live);
    view.Push(7);
    if (pc != 1 || live != 1 || buffer[0].Number != 7)
        throw new Exception("Borrowed state was copied.");
}

static View Borrow(Frame frame)
    => new(frame.Work.Storage.Values, ref frame.Work.Pc, ref frame.Work.Storage.Live);

static async Task RunOwnedAsync(Frame frame)
{
    { var view = Borrow(frame); view.Push(8); }
    await Task.Yield();
    { var view = Borrow(frame); view.Push(9); }
}

struct Slot { internal object? Value; internal long Number; }
[InlineArray(4)] struct Buffer { private Slot _first; }
struct Storage { internal Slot[] Values; internal int Live; }
struct Work { internal Storage Storage; internal int Pc; }
sealed class Frame
{
    internal Work Work = new() { Storage = new() { Values = new Slot[4] } };
}
ref struct View(Span<Slot> values, ref int pc, ref int live)
{
    private readonly Span<Slot> _values = values;
    private readonly ref int _pc = ref pc;
    private readonly ref int _live = ref live;
    internal void Push(long value)
    {
        _values[_live++] = new Slot { Value = null, Number = value };
        _pc++;
    }
}
