from pathlib import Path
import json, subprocess

notes = Path(__file__).parent
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code = '''from pathlib import Path
import fcntl,hashlib,json,os,shutil
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=[]
 for batch in b.iterdir():
  if not batch.is_dir():continue
  for p in list(batch.glob('*'))+list(batch.glob('confirmation/*')):
   if not p.is_file():continue
   if p.suffix not in ['.tgz','.json','.xz']:continue
   stat=p.stat()
   if not 100000<=stat.st_size<=4*1024*1024:continue
   rows.append(dict(path=str(p.relative_to(b)),bytes=stat.st_size,links=stat.st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,rows=rows)))
'''
result=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
assert result.returncode==0,result.stdout+result.stderr
(notes/'space-inventory.json').write_text(result.stdout,encoding='utf-8')
data=json.loads(result.stdout)
print('freeBytes',data['freeBytes'])
for row in data['rows']:
 if row['links']==1: print(row)
