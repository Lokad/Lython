from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');old=r.parent/'json-scalars-r492';q=r/'quiet'
qualification=json.loads((old/'delivery/qualification.json').read_text(encoding='utf-8'))
assert qualification['run']==44128892209 and qualification['conclusion']=='success'and qualification['allMeaningfulStepsPassed']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/'frozen'/role/n).read_bytes()).hexdigest()==h for role,files in f['imageFiles'].items()for n,h in files.items())
subjects=[]
canonical='benchmarks/results/2026-11-17-native-generator-loop/refined/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-native-generator-loop/refined/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else archive.extractfile(member).read()
  subjects.append(dict(kind='completed-replica',path='native-generators-refined-b914-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-call-packet-lifetimes/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
subjects.append(dict(kind='completed-replica',path='call-packet-lifetimes-b905-20261117/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-tab-expansion/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
assert hashlib.sha256(data).hexdigest()=='6a91212d6e978ce9d055fc18a2002cd13204d9395faad05d47f1f6a50f136af7'
subjects.append(dict(kind='completed-replica',path='tab-expansion-b870-20261117/confirmation/confirmation.json',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
assert not set(v['sha256']for v in subjects[:1])&{v['Lokad.Lython.dll']for v in f['imageFiles'].values()}
s=(old/'prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('json-cpython-b908-20261117','native-generators-refined-b914-20261117').replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'").replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout);q.mkdir(exist_ok=False);(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/completed-runner-b915-20261117'
identity=dict(sourceRevision='Fully qualified33bd7efd/5e7058a3 versus privateR495 on22d5a5f3; single completed-instruction loop and corrected call-loan cleanup bound',purpose='One existing completed-instruction runner for borrowed prefixes and admitted frames; duplicate native loop/eligibility scan/call-format-publication removed. Existing binding, ownership and async lifecycles. Floating report warm/fresh, helper/text and unchanged call controls; no predicted gain.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.text-normalization.large','warm'],['scripts.json-summary-helpers.large','warm'],['calls.positional.large','warm']]
s=(old/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+s[b:]
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
prior=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
for role in ['candidate']:
 (q/role).mkdir();shutil.copyfile(r/'frozen'/role/'Lokad.Lython.dll',q/role/'Lokad.Lython.dll');names.append(role+'/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
donor=json.loads((r.parent/'native-generators-r494/refined/quiet/config.json').read_text(encoding='utf-8'));donor['root']='/home/lokad/lython-bench-checks/native-generators-refined-b914-20261117'
c=dict(root=remote,unit='lython-b915-completed-runner-20261117',source=donor['root'],sourceRole='reference',sourceFiles=donor['identity']['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b910-fixtures','lython-b915-fixtures')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=180','seconds=230').replace('before180seconds','before230seconds').replace('Four-job scalar JSON comparison','Five-job existing-loop generator comparison');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==5").replace('B910','B915');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Five-job source pair prepared with latest qualified reference/new candidate; only superseded cores and exactly committed raw replicas eligible for fresh launch-time retirement.')
