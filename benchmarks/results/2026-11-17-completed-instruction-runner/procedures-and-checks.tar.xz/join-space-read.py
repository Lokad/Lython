from pathlib import Path
import subprocess

notes=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import json,os,signal,subprocess,time
lease='/home/lokad/lython-bench-checks/comparison-vm.lock'
locks=json.loads(subprocess.check_output(['lslocks','--json','--output','PID,COMMAND,PATH'],text=True))['locks']
owned=[v for v in locks if v.get('path')==lease]
assert len(owned)==1,owned
pid=owned[0]['pid'];proc=Path('/proc')/str(pid)
assert proc.stat().st_uid==os.getuid()
cmd=(proc/'cmdline').read_bytes().split(b'\\0')
assert cmd[:2]==[b'python3',b'-'],cmd
description=subprocess.check_output(['ps','-p',str(pid),'-o','pid,ppid,lstart,etime,args'],text=True)
print(description,flush=True)
# This is the read-only inventory launched by this task, still holding the
# exclusive lease after its SSH client timed out. No collector can hold it too.
os.kill(pid,signal.SIGTERM)
end=time.monotonic()+5
while proc.exists() and time.monotonic()<end:time.sleep(.1)
assert not proc.exists(),pid
print('Owned timed-out read-only inventory joined; no runtime/benchmark work abandoned.')
'''
result=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=15)
(notes/'join-space-read.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout+result.stderr)
assert result.returncode==0
