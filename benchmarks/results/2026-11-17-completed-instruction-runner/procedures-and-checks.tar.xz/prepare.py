from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
paths=[p for p in work.glob('src/Lokad.Lython/**/*.cs')]+[work/'tests/Lokad.Lython.PublicApi.Tests/BufferedGeneratorContinuationTests.cs']
v={p.relative_to(work).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
with tarfile.open(r/'prior-private-source.tar.xz','w:xz')as a:
 for p in paths:a.add(p,arcname=p.relative_to(work).as_posix())
(r/'prior-private-source.json').write_text(json.dumps(dict(source='PrivateR494 refined a5e20232 plus later8case regression source; production not promoted',inputs=v),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prior private foundation preserved before joint runner migration.')
