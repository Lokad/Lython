from pathlib import Path
import re
r=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494');runtime=r/'src/Lokad.Lython/Runtime'

def write(p,s): p.write_text(s,encoding='utf-8',newline='\n')
def method(s,marker):
 a=s.index(marker);b=s.index('{',a);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return a,i

# Array owners retain the same lifetime. Operations can also borrow native spans.
p=runtime/'LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8')
anchor='''        internal readonly ExecutableSlot[] Values => _items;'''
new='''        internal static ExecutableValueStorage ForBorrowedPrefix(ExecutableCodeObject code,
            ExecutionContext context, PyExecutableFunction owner)
            => new(context.State, code.FirstTemporarySlot, code.LastOwnedTemporarySlot, owner);

        private ExecutableValueStorage(ExecutionState state, int firstTemporarySlot,
            int lastOwnedTemporarySlot, PyExecutableFunction owner)
        {
            _state = state;
            _items = [];
            _firstTemporarySlot = firstTemporarySlot;
            _lastOwnedTemporarySlot = lastOwnedTemporarySlot;
            _lookupStorage = owner;
            LiveExtent = firstTemporarySlot;
        }

        internal readonly bool HasValueArray => _items.Length != 0;

'''+anchor
assert anchor in s;s=s.replace(anchor,new)
# Existing frame/async callers still use their array forms. There is one body.
specs=[('internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)','internal void PublishSlot(Span<ExecutableSlot> values, int resultSlot, int liveExtent, ExecutableSlot result)','PublishSlot(_items, resultSlot, liveExtent, result)'),('internal object TakeValue(int inputSlot, int liveExtent)','internal object TakeValue(Span<ExecutableSlot> values, int inputSlot, int liveExtent)','TakeValue(_items, inputSlot, liveExtent)'),('internal ExecutableSlot TakeSlotValue(int inputSlot, int liveExtent)','internal ExecutableSlot TakeSlotValue(Span<ExecutableSlot> values, int inputSlot, int liveExtent)','TakeSlotValue(_items, inputSlot, liveExtent)'),('internal void ForgetResultInput(int resultSlot)','internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)','ForgetResultInput(_items, resultSlot)'),('internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)','internal bool TryPrepareNativeIteration(Span<ExecutableSlot> values, object source, int slot, int liveExtent, LythonSourceSpan span)','TryPrepareNativeIteration(_items, source, slot, liveExtent, span)'),('internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)','internal bool TryAdvanceNativeIteration(Span<ExecutableSlot> values, int slot, out bool hasValue, out ExecutableSlot next)','TryAdvanceNativeIteration(_items, slot, out hasValue, out next)'),('internal bool CanRetireWithoutCleanup(int liveExtent)','internal bool CanRetireWithoutCleanup(Span<ExecutableSlot> values, int liveExtent)','CanRetireWithoutCleanup(_items, liveExtent)'),('public void RetireTo(int liveExtent)','public void RetireTo(Span<ExecutableSlot> values, int liveExtent)','RetireTo(_items, liveExtent)')]
specs=[(a.replace('internal bool CanRetireWithoutCleanup','internal readonly bool CanRetireWithoutCleanup'),b.replace('internal bool CanRetireWithoutCleanup','internal readonly bool CanRetireWithoutCleanup'),c)for a,b,c in specs]
for old,new,forward in specs:
 a,b=method(s,old);body=s[a:b].replace(old,new).replace('_items','values')
 body=body.replace('RetireTo(liveExtent)','RetireTo(values, liveExtent)').replace('PublishValue(slot, liveExtent, source)','PublishSlot(values, slot, liveExtent, ExecutableSlot.FromObject(source))')
 body=body.replace('Array.Clear(values, newCount, LiveExtent - newCount);','values.Slice(newCount, LiveExtent - newCount).Clear();')
 s=s[:a]+old+'\n            => '+forward+';\n\n        '+body+s[b:]
write(p,s)

# The existing native view becomes the common synchronous operation view. All
# authoritative mutable metadata is borrowed by managed ref, never copied.
p=runtime/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');a=s.index('        private readonly PyExecutableFunction? _function;');b=s.index('        internal bool Run(',a)
head='''        private readonly ref ExecutableWorkState _work;
        internal readonly Span<ExecutableSlot> Values;
        private readonly ExecutionContext _scope;
        internal readonly ExecutionContext? Invocation;
        private readonly int _unpackedReturnCount;
        private int _unpackedTupleStart = -1;
        private bool _transferred;
        private ExecutionContext? _preparedChild;
        private MemoryGovernor? _preparedChildOwner;
        internal LythonRuntimeException? Failure { get; private set; }
        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;
        internal ExecutableCodeObject Code => _work.Code;
        internal Span<ExecutableSlot> Locals => Values;
        internal IReadOnlyList<ExecutableCell>? ClosureCells => _work.ClosureCells;
        internal ref ExecutableValueStorage Stack => ref _work.Stack;
        internal int Index { get => _work.InstructionIndex; set => _work.InstructionIndex = value; }
        internal int InstructionIndex { get => Index; set => Index = value; }
        internal int LiveExtent { get => Stack.LiveExtent; set => Stack.RestoreNativeExtent(value); }
        internal bool ReturnConsumedByIteration => _work.ReturnConsumedByIteration;
        internal ExecutableSlot ReturnValue { get => _work.ReturnValue; set => _work.ReturnValue = value; }
        internal bool IsBorrowedPrefix => !Stack.HasValueArray;

        internal NativeExecution(ref ExecutableWorkState work, Span<ExecutableSlot> values,
            ExecutionContext scope, ExecutionContext? invocation, int unpackedReturnCount = 0)
        {
            _work = ref work;
            Values = values;
            _scope = scope;
            Invocation = invocation;
            _unpackedReturnCount = unpackedReturnCount;
        }

        internal object this[int index] { get => Values[index].Object.RequireNotNull(); set => Values[index].Object = value; }
        internal void PublishValue(int resultSlot, int liveExtent, object value)
            => PublishSlot(resultSlot, liveExtent, ExecutableSlot.FromObject(value));
        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot value)
            => Stack.PublishSlot(Values, resultSlot, liveExtent, value);
        internal object TakeValue(int inputSlot, int liveExtent) => Stack.TakeValue(Values, inputSlot, liveExtent);
        internal ExecutableSlot TakeSlotValue(int inputSlot, int liveExtent) => Stack.TakeSlotValue(Values, inputSlot, liveExtent);
        internal void RetireTo(int extent) => Stack.RetireTo(Values, extent);
        private void Trim(int extent) => RetireTo(extent);
        internal void ForgetResultInput(int slot) => Stack.ForgetResultInput(Values, slot);
        internal bool CanRetireWithoutCleanup(int extent) => Stack.CanRetireWithoutCleanup(Values, extent);

        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            if (!IsBorrowedPrefix) return Stack.TryPrepareNativeIteration(Values, source, slot, liveExtent, span);
            if (source is not (PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)) return false;
            PublishValue(slot, liveExtent, PyIteration.Cursor.Create(source, span, _scope));
            return true;
        }

        internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)
        {
            if (Stack.TryAdvanceNativeIteration(Values, slot, out hasValue, out next)) return true;
            if (Values[slot].Reference is PyIteration.Cursor { CanPullWithoutGuestCode: true } cursor)
            {
                var result = cursor.TryMoveNext();
                hasValue = result.HasValue;
                next = hasValue ? result.TakeSlotValue() : default;
                return true;
            }
            return false;
        }

        internal void RetainPreparedChild(ExecutionContext child, MemoryGovernor owner)
        {
            _preparedChild = child;
            _preparedChildOwner = owner;
        }

'''
s=s[:a]+head+s[b:]
s=s.replace('var completed = RunCore(out result);','''var pause = ExecutionContext.ExecuteInstructionPrefix(ref this, _scope, null, false, out _, out _, out _);
                var completed = pause == ExecutionContext.InstructionPause.Boundary;
                if (!completed && pause != ExecutionContext.InstructionPause.ContextRequired)
                    throw new InvalidOperationException("A borrowed prefix cannot suspend.");
                result = ReturnValue.IsUnassigned ? ExecutableSlot.FromObject(PyNone.Instance) : ReturnValue;''')
a=s.index('        private bool RunCore(');b=s.index('        private bool TryReturnUnpackedTuple(',a);s=s[:a]+s[b:]
s=s.replace('private bool TryReturnUnpackedTuple','internal bool TryReturnUnpackedTuple')
a=s.index('        private bool TryCell(');b=s.index('        internal void PrepareTransfer()',a);s=s[:a]+s[b:]
s=s.replace('finally { if (_function is not null) DisposeValues(); }','finally { DisposeValues(); Stack.ReleaseStorage(); }')
a,b=method(s,'        private void DisposeValues()');s=s[:a]+'''        private void DisposeValues() => RetireTo(Code.FirstTemporarySlot);'''+s[b:]
a=s.index('        // Reuse the existing native loop for an admitted buffered generator.');b=s.index('        internal void RestoreNativePosition(',a);s=s[:a]+s[b:]
write(p,s)

# Native call binding keeps its existing entry ABI. Only the ephemeral bookkeeping
# is initialized here; allocation remains delayed until actual materialization.
p=runtime/'PyExecutableFunction.cs';s=p.read_text(encoding='utf-8');old='''        var state = new LythonRuntime.NativeExecution(this, values, consumedByIteration, unpackedReturn.Length);'''
new='''        var work = new LythonRuntime.ExecutableWorkState
        {
            Code = _codeObject,
            ClosureCells = _closureCells,
            Stack = LythonRuntime.ExecutableValueStorage.ForBorrowedPrefix(_codeObject, Closure, this),
            InstructionIndex = _codeObject.EntryIndex,
            ReturnConsumedByIteration = consumedByIteration,
        };
        var state = new LythonRuntime.NativeExecution(ref work, values, Closure, null, unpackedReturn.Length);'''
assert old in s;s=s.replace(old,new);write(p,s)

# Switch typed operation helpers to the same view, keeping lifecycle storage.
names=['Arithmetic','Binding','Calls.Invoke','CasedSplits','Comparisons','DictionaryAccumulation','Inputs','Interpreter','Results','PreparedOperations']
for name in names:
 p=runtime/('LythonRuntime.Executable.'+name+'.cs');s=p.read_text(encoding='utf-8')
 s=s.replace('ref ExecutableWorkState execution','ref NativeExecution execution').replace('in ExecutableWorkState execution','in NativeExecution execution')
 if name=='Interpreter':s=s.replace('internal void AdoptExecutableExecution(ref NativeExecution execution','internal void AdoptExecutableExecution(ref ExecutableWorkState execution')
 s=s.replace('execution.Stack.Values.AsSpan(', 'execution.Values.Slice(').replace('execution.Stack.Values','execution.Values')
 s=re.sub(r'execution\.Stack\.Slice\(([^\n;]*?)\)\.Span',r'execution.Values.Slice(\1)',s)
 for op in ['PublishValue','PublishSlot','TakeValue','TakeSlotValue','RetireTo','ForgetResultInput','CanRetireWithoutCleanup','TryPrepareNativeIteration','TryAdvanceNativeIteration']:
  s=s.replace('execution.Stack.'+op+'(', 'execution.'+op+'(')
 s=re.sub(r'execution\.Stack\[([^\]]+)\]',r'execution[\1]',s)
 write(p,s)

# Ordinary local semantics apply equally to borrowed slots.
for name in ['LythonRuntime.Executable.Binding.cs','LythonRuntime.Executable.Interpreter.cs']:
 p=runtime/name;s=p.read_text(encoding='utf-8');s=s.replace('ExecutableSlot[] locals','Span<ExecutableSlot> locals');write(p,s)

# One wrapper for persistent frame/deferred work; one dispatch body for everyone.
p=runtime/'LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
s=s.replace('private enum InstructionPause','internal enum InstructionPause')
a=s.index('            if (invocation is not null && invocation.TryExecuteBufferedNative(');b=s.index('            var instructions =',a);s=s[:a]+s[b:]
s=s.replace('private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution','internal static InstructionPause ExecuteInstructionPrefix(ref NativeExecution execution')
for op in ['PublishValue','PublishSlot','TakeValue','TakeSlotValue','RetireTo','ForgetResultInput','CanRetireWithoutCleanup','TryPrepareNativeIteration','TryAdvanceNativeIteration']:
 s=s.replace('execution.Stack.'+op+'(', 'execution.'+op+'(')
s=s.replace('execution.Stack.Values','execution.Values');s=re.sub(r'execution\.Stack\[([^\]]+)\]',r'execution[\1]',s)
anchor='''            while (execution.InstructionIndex < instructions.Length)
            {'''
s=s.replace(anchor,anchor+'''
                if (invocation is null && execution.IsBorrowedPrefix && execution.InstructionIndex >= execution.Code.NativePrefixEnd)
                    return InstructionPause.ContextRequired;''')
s=s.replace('''                            invocation.ExecuteYield(instruction);
                            return InstructionPause.Boundary;''','''                            invocation.ExecuteYield(instruction);
                            if (invocation.TryBufferYield()) { jumped = true; break; }
                            return InstructionPause.Boundary;''')
s=s.replace('''                        case ExecutableOpCode.MakeTuple:
                            PublishInstructionResult''','''                        case ExecutableOpCode.MakeTuple:
                            if (execution.TryReturnUnpackedTuple(instruction)) return InstructionPause.Boundary;
                            PublishInstructionResult''')
s=s.replace('''                                if (started is null) break;
                                nextCall = new(started);''','''                                if (started is null) break;
                                if (invocation is null) return InstructionPause.ContextRequired;
                                nextCall = new(started);''')
anchor='''                            jumped = ExecuteControlFlow(ref execution, scope, invocation, instruction);'''
s=s.replace(anchor,'''                            if (invocation is null && execution.Code.ExceptionRegions.Count != 0
                                && instruction.OpCode is not ExecutableOpCode.Jump) return InstructionPause.ContextRequired;
'''+anchor)
marker='''        internal static InstructionPause ExecuteInstructionPrefix(ref NativeExecution execution'''
position=s.index(marker)
wrapper='''        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState work, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending,
            out LythonSourceSpan? pendingSpan, out ValueTask<ExecutionContext?> nextCall)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, scope, invocation);
            return ExecuteInstructionPrefix(ref execution, scope, invocation, asynchronous, out pending, out pendingSpan, out nextCall);
        }

'''
s=s[:position]+wrapper+s[position:];write(p,s)

# A code-wide opcode whitelist no longer selects a second execution loop.
p=r/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''            && EntryIndex < NativePrefixEnd
            && SupportsNativeInstructions();''','''            && EntryIndex < NativePrefixEnd;''')
a,b=method(s,'    private bool SupportsNativeInstructions()');s=s[:a]+s[b:]
a=s.index('    private static bool IsInlineInstruction(');b=s.index(';',a)+1;s=s[:a]+s[b:];write(p,s)

print('Single-dispatch prototype installed; duplicate native loop/format/call/publication and whole-code opcode whitelist removed. Compile follow-ups will adapt real framed callers, not add another runner.')
