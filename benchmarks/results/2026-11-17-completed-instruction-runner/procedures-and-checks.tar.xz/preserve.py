from pathlib import Path
import gzip, hashlib, json, shutil, tarfile

notes=Path(__file__).parent
root=Path('D:/code/Lython')
out=root/'benchmarks/results/2026-11-17-completed-instruction-runner'
out.mkdir(exist_ok=False)
summary=json.loads((notes/'summary.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['allUsersJoinedAndFixturesRemoved']
for name in ['summary.json','allocation-summary.json','candidate-sources.tar.xz','prototype.patch.gz',
             'checks.json','catalog.json','candidate-preflight.json','reference-preflight-reused.json']:
    shutil.copyfile(notes/name,out/name)
shutil.copyfile(notes/'frozen/identity.json',out/'identity.json')
for role in ['reference','candidate']:
    (out/(role+'-core.dll.gz')).write_bytes(gzip.compress((notes/'frozen'/role/'Lokad.Lython.dll').read_bytes(),mtime=0))
for name in ['archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(notes/'quiet'/name,out/name)
shutil.copyfile(notes/'quiet/identity.json',out/'measurement-identity.json')
receipt=json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz') as archive:
    for path in sorted(notes.rglob('*')):
        if not path.is_file():continue
        name=path.relative_to(notes)
        if {'retrieved','frozen','candidate','reference','bin','obj'} & set(name.parts):continue
        if name.name in ['payload.tgz','observations.tgz','candidate-sources.tar.xz','prior-private-source.tar.xz']:continue
        archive.add(path,arcname=name.as_posix())
table=[]
for row in summary['rows']:
    elapsed=row['elapsedChangePercent'];cpu=row['cpuChangePercent']
    table.append(f"| {row['case']} | {row['lane']} | {min(elapsed):+.2f}..{max(elapsed):+.2f}% | {min(cpu):+.2f}..{max(cpu):+.2f}% | {row['referenceSpreadPercent']:.2f}/{row['candidateSpreadPercent']:.2f}% |")
text='''# One completed-instruction runner

R495/B915, 2026-11-17 UTC. **Private prototype; decision pending.** Fully
qualified R492/33bd7efd, frozen5e7058a3, versus39c11156 on22d5a5f3.
The prior R494 foundation and all its adverse conditions remain
[separate](../2026-11-17-native-generator-loop/README.md).

One existing synchronous completed-instruction loop now serves admitted frames,
generators and stack-borrowed helper prefixes. A managed ephemeral ref/span view
shares the authoritative work PC/live extent and final slots. It ends before
suspension. Existing owned continuations retain pending users; partial helpers
transfer once without replay. Remove duplicate NativeExecution.RunCore,
call/format/publication/integer dispatch, the generator-only bridge and whole-code
native opcode eligibility scanning. Preserve the call ABI, native helper returns,
simple loop exits, scalar comparisons and existing async lifecycle. No third
dispatcher, JIT, arena, owner, resource policy or public option.

An existing cancellation/loan regression exposed an incomplete compiler cleanup
bound: directly consumed/forwarded calls can return private range loans. Include
their result slots in the existing bound; this replaces the native final full
scan while retaining the test's cancellation/refund/alias assertions. The old test
constructor required adaptation, not deletion. Failed port builds and the initial
cleanup-bound failure remain in the procedures archive.

Nonincremental Release rebuild passes. Actual Windows .NET11/10 each pass1,006
internal/4,217 public focused checks, including functions, stack admission, loops,
exceptions, closures, genuine I/O, held cleanup, terminal refusal, cancellation,
retained aliases and shared-budget reuse. Five actual copied32-file worker goldens
pass; allocations are effectivelyflat, accounted peaks unchanged and all budget
baselines restored. These are focused checks, not full delivery qualification.

| Complete script | Phase | Elapsed change | Wider CPU change | Reference/candidate process spread |
| --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+f'''

{summary['elapsedSeconds']:.2f}seconds/five jobs; quiet AzureF4as_v7,
Ubuntu24.04.4/.NET11RC3, six-second rotated full-request warmups/five rounds/four
processes, natural GC/tiering. Ranges compare all candidate/reference process
medians; negative is lower. Controls and within-process distributions are retained.
Allocation reduction, simplification and CPU improvement are separate claims.
This source pair does not refresh CPython performance ratios.

Warm clocks include complete Run, mediated RAM I/O, full stdout/file goldens and
previous-result cleanup; fresh adds compilation/compiled-owner disposal. Startup,
fixture reset/protocol and final cache teardown excluded. External CPU is wider.

Two staging attempts refused the unchanged254MiB floor before mutation or
measurement. Original configs/logs remain; add only committed, hash-verified
replicas for fresh lease/path/UID/link/all-alias retirement, preserving qualified
5e7/current catalog/toolchains. A read-only inventory timed out; its exact lease
owner was verified and joined. The bounded replacement inventory completed.
All actual-image/golden/quiet/Closed/exit/join gates pass; RAM traces are
SHA-archived persistently under lease before unmount. Terminal cached.
Publication held; broader performance objective active.

[Summary](summary.json),[allocation](allocation-summary.json),[source](candidate-sources.tar.xz),
[prototype](prototype.patch.gz),[identity](identity.json),[checks](checks.json),
[raw](observations.tgz),[procedures](procedures-and-checks.tar.xz).
'''
(out/'README.md').write_text(text,encoding='utf-8')
print('Private shared-runner source, conditions, results and original failures preserved; retention decision remains explicit.')
