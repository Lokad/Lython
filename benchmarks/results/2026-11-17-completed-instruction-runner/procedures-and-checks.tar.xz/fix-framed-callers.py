from pathlib import Path
import re
r=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494/src/Lokad.Lython/Runtime')
for p in r.glob('LythonRuntime.Executable*.cs'):
 s=p.read_text(encoding='utf-8')
 s=s.replace('_execution.Values','_execution.Stack.Values')
 for op in ['PublishValue','PublishSlot','TakeValue','TakeSlotValue','RetireTo','ForgetResultInput','CanRetireWithoutCleanup','TryPrepareNativeIteration','TryAdvanceNativeIteration']:
  s=s.replace('_execution.'+op+'(','_execution.Stack.'+op+'(')
 s=re.sub(r'_execution\[([^\]]+)\]',r'_execution.Stack[\1]',s)
 p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref _execution, this, instruction, value);''','''        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(instruction, ExecutableSlot.FromObject(value));''')
s=s.replace('''        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishInstructionResult(ref _execution, this, instruction, value);''','''        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
        {
            var execution = new NativeExecution(ref _execution, _execution.Stack.Values, this, this);
            PublishInstructionResult(ref execution, this, instruction, value);
        }''')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');anchor='''        private void Trim(int extent) => RetireTo(extent);'''
s=s.replace(anchor,anchor+'''
        private void Publish(in ExecutableInstruction instruction, ExecutableSlot value)
            => ExecutionContext.PublishInstructionResult(ref this, Invocation, instruction, value);
''')
# Same existing publication operation; helper visibility is assembly-internal only.
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8').replace('private static void PublishInstructionResult(ref NativeExecution','internal static void PublishInstructionResult(ref NativeExecution');p.write_text(s,encoding='utf-8',newline='\n')
print('Restored owned-frame operation calls and real publication wrappers; no alternate dispatcher.')
