from pathlib import Path
r=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494/src/Lokad.Lython/Runtime')
p=r/'LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8')
s=s.replace('internal int Index { get => _work.InstructionIndex; set => _work.InstructionIndex = value; }','internal ref int Index => ref _work.InstructionIndex;')
s=s.replace('internal int InstructionIndex { get => Index; set => Index = value; }','internal ref int InstructionIndex => ref _work.InstructionIndex;')
s=s.replace('internal ExecutableSlot ReturnValue { get => _work.ReturnValue; set => _work.ReturnValue = value; }','internal ref ExecutableSlot ReturnValue => ref _work.ReturnValue;')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');s=s.replace('_execution.Stack.Values.Slice(', '_execution.Stack.Values.AsSpan(')
anchor='''        private static object ReadOperand(ref NativeExecution execution'''
position=s.index(anchor)
wrappers='''        // Awaited continuations retain the existing array-backed state. Borrow
        // a view only while completing their synchronous publication/branch.
        private static object ReadOperand(ref ExecutableWorkState work, int source, ExecutionContext scope, int input)
            => ReadExecutableOperand(work.Code, work.Stack.Values, source, work.InstructionIndex, input, scope);

        private static object TakeOperand(ref ExecutableWorkState work, in ExecutableInstruction instruction, ExecutionContext scope)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, scope, scope);
            return TakeOperand(ref execution, instruction, scope);
        }

        private static void ExecuteSliceValueOperation(ref ExecutableWorkState work, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, scope, invocation);
            ExecuteSliceValueOperation(ref execution, scope, invocation, instruction);
        }

'''
s=s[:position]+wrappers+s[position:];p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8');anchor='''        private static bool CompleteComparisonBranch(ref NativeExecution''';position=s.index(anchor)
s=s[:position]+'''        private static bool CompleteComparisonBranch(ref ExecutableWorkState work, ExecutionContext context,
            in ExecutableInstruction instruction, bool truth)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, context, context);
            return CompleteComparisonBranch(ref execution, context, instruction, truth);
        }

'''+s[position:];p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
s=s.replace('CallResultConsumedByIteration(in _execution, site)', '(site.ConsumedByIteration || _execution.ReturnConsumedByIteration && site.ReturnedDirectly)')
s=s.replace('PrepareUnpackedCallReturn(ref _execution, site, start, out originalExtent)', 'PrepareUnpackedCallReturn(_execution.Stack.Values, ref _execution.Stack, site, start, out originalExtent)')
s=s.replace('CompleteUnpackedCallReturn(ref _execution, this, start, returned.Length)', 'CompleteOwnedUnpackedCallReturn(start, returned.Length)')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text(encoding='utf-8')
old='''        {
            originalExtent = execution.Stack.LiveExtent;
            // Eligibility depends'''
new='''            => PrepareUnpackedCallReturn(execution.Values, ref execution.Stack, call, start, out originalExtent);

        private static Span<ExecutableSlot> PrepareUnpackedCallReturn(Span<ExecutableSlot> values,
            ref ExecutableValueStorage storage, ExecutableCallSite call, int start, out int originalExtent)
        {
            originalExtent = storage.LiveExtent;
            // Eligibility depends'''
assert old in s;s=s.replace(old,new)
a=s.index('        private static Span<ExecutableSlot> PrepareUnpackedCallReturn(Span<ExecutableSlot> values,');b=s.index('        private static void CompleteUnpackedCallReturn',a)
body=s[a:b].replace('execution.CanRetireWithoutCleanup(start)','storage.CanRetireWithoutCleanup(values, start)').replace('execution.Values.Slice','values.Slice').replace('execution.Stack.RestoreNativeExtent','storage.RestoreNativeExtent')
s=s[:a]+body+s[b:]
anchor='''        internal static void AbortPreparedNativeCall''';position=s.index(anchor)
s=s[:position]+'''        private void CompleteOwnedUnpackedCallReturn(int start, int count)
        {
            var execution = new NativeExecution(ref _execution, _execution.Stack.Values, this, this);
            CompleteUnpackedCallReturn(ref execution, this, start, count);
        }

'''+s[position:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Connected real owned continuations; PC and return delivery are managed refs, not snapshots.')
