from pathlib import Path
import ast

notes = Path(__file__).parent
prior = notes.parent / 'native-generators-r494/refined/freeze.py'
source = prior.read_text(encoding='utf-8')
source = source.replace("prior=r.parent.parent/'json-scalars-r492'", "prior=r.parent/'json-scalars-r492'")
source = source.replace("assert len(changed)==7 and all(n.startswith('src/Lokad.Lython/')for n in changed)",
                        "assert len(changed)>20 and all(n.startswith('src/Lokad.Lython/') or n=='tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs' for n in changed)")
source = source.replace('full44128892209 pending at preparation', 'fully qualified GREEN44128892209')
source = source.replace('PrivateR494 existing-native-loop generator consumption on22d5a5f3; no promotion',
                        'PrivateR495 one completed-instruction loop on22d5a5f3; compiler call-loan cleanup bound corrected; no promotion')
source = source.replace('Seven-file existing-loop prototype frozen', 'Shared completed-instruction runner frozen')
ast.parse(source)
(notes / 'freeze.py').write_text(source, encoding='utf-8')
print('Existing frozen-worker validation procedure adapted; no freeze performed yet.')
