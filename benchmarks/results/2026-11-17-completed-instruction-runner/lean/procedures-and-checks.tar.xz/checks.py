from pathlib import Path
import json, os, subprocess, time

notes = Path(__file__).parent
work = Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
records = []

def run(label, args):
    command = [str(dotnet), *args]
    start = time.monotonic()
    with (notes / (label + '.log')).open('w', encoding='utf-8') as log:
        result = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
    records.append(dict(name=label, command=command, exitCode=result.returncode, seconds=time.monotonic()-start))
    (notes / 'checks.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    output = (notes / (label + '.log')).read_text(encoding='utf-8')
    print(label, output[-3500:] if result.returncode else output.splitlines()[-1], flush=True)
    assert result.returncode == 0

run('build', ['build', 'Lokad.Lython.slnx', '-c', 'Release', '--no-incremental'])
classes = ['Generator', 'Native', 'CursorDispatch', 'ForHelper', 'CallablePacketOwnership',
           'HelperLocalLifetime', 'RepresentativeProtocolCancellation', 'BuiltinCancellation',
           'FloatArithmeticPipeline', 'BulkConsumption', 'SequenceConstructionOwnership',
           'BufferedGeneratorContinuation', 'ProtectedHelperExecution', 'ClosedBuiltinResult',
           'CompilerCancellation', 'OrdinaryFunctionTransport', 'CasedSplit', 'Function',
           'Stack', 'Loop', 'Exception']
filt = '(' + '|'.join('FullyQualifiedName~'+name for name in classes) + ')&Category!=Stress'
for framework in ['net11.0', 'net10.0']:
    for name, project in [('internal', 'Lokad.Lython.Tests'), ('public', 'Lokad.Lython.PublicApi.Tests')]:
        run(name+'-'+framework, ['test', f'tests/{project}/{project}.csproj', '-c', 'Release',
                                 '-f', framework, '--no-build', '--filter', filt,
                                 '--logger', 'console;verbosity=minimal'])
