from pathlib import Path
import hashlib,json

notes=Path(__file__).parent
root=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
runtime=root/'src/Lokad.Lython/Runtime'
identity=json.loads((notes/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in identity['sourceInputs'].items())

def edit(name,old,new):
    path=runtime/name;text=path.read_text(encoding='utf-8')
    assert old in text,(name,old[:90])
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')

path=runtime/'LythonRuntime.Executable.NativePrefix.cs'
text=path.read_text(encoding='utf-8')
a=text.index('        private readonly ref ExecutableWorkState _work;')
b=text.index('        internal bool TryPrepareNativeIteration',a)
text=text[:a]+'''        internal readonly ExecutableCodeObject Code;
        internal readonly Span<ExecutableSlot> Values;
        internal readonly IReadOnlyList<ExecutableCell>? ClosureCells;
        internal readonly bool ReturnConsumedByIteration;
        private readonly ref ExecutableValueStorage _storage;
        private readonly ref int _index, _liveExtent;
        private readonly ref ExecutableSlot _returnValue;
        private readonly PyExecutableFunction? _prefixFunction;
        private readonly ExecutionContext _scope;
        private readonly int _unpackedReturnCount;
        private int _unpackedTupleStart = -1;
        private bool _transferred;
        private ExecutionContext? _preparedChild;
        private MemoryGovernor? _preparedChildOwner;
        internal LythonRuntimeException? Failure { get; private set; }
        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;
        internal Span<ExecutableSlot> Locals => Values;
        internal ref ExecutableValueStorage Stack
        {
            get
            {
                if (IsBorrowedPrefix) throw new InvalidOperationException("A borrowed prefix has no owned storage.");
                return ref _storage;
            }
        }
        internal ref int Index => ref _index;
        internal ref int InstructionIndex => ref _index;
        internal int LiveExtent { get => _liveExtent; set => _liveExtent = value; }
        internal ref ExecutableSlot ReturnValue => ref _returnValue;
        internal bool IsBorrowedPrefix => _prefixFunction is not null;
        internal bool HasPendingDisposals => !IsBorrowedPrefix && _storage.HasPendingDisposals;

        internal NativeExecution(ref ExecutableWorkState work, Span<ExecutableSlot> values, ExecutionContext scope)
        {
            Code = work.Code;
            Values = values;
            ClosureCells = work.ClosureCells;
            ReturnConsumedByIteration = work.ReturnConsumedByIteration;
            _storage = ref work.Stack;
            _index = ref work.InstructionIndex;
            _liveExtent = ref work.Stack.LiveExtent;
            _returnValue = ref work.ReturnValue;
            _scope = scope;
        }

        internal NativeExecution(PyExecutableFunction function, Span<ExecutableSlot> values,
            ref int index, ref int liveExtent, ref ExecutableSlot returned, bool consumedByIteration,
            int unpackedReturnCount = 0)
        {
            Code = function.CodeObject;
            Values = values;
            ClosureCells = function.ClosureCells;
            ReturnConsumedByIteration = consumedByIteration;
            _prefixFunction = function;
            _index = ref index;
            _liveExtent = ref liveExtent;
            _returnValue = ref returned;
            _scope = function.DefinitionContext;
            _unpackedReturnCount = unpackedReturnCount;
        }

        internal object this[int index] { get => Values[index].Object.RequireNotNull(); set => Values[index].Object = value; }
        internal void PublishValue(int resultSlot, int liveExtent, object value)
            => PublishSlot(resultSlot, liveExtent, ExecutableSlot.FromObject(value));
        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot value)
        {
            if (liveExtent < _liveExtent) RetireTo(liveExtent);
            ExecutableValueStorage.CompletePublication(Values, ref _liveExtent, resultSlot, liveExtent, value);
        }
        internal object TakeValue(int inputSlot, int liveExtent)
            => ExecutableValueStorage.TakeValue(Values, ref _liveExtent, inputSlot, liveExtent);
        internal ExecutableSlot TakeSlotValue(int inputSlot, int liveExtent)
            => ExecutableValueStorage.TakeSlotValue(Values, ref _liveExtent, inputSlot, liveExtent);
        internal void RetireTo(int extent)
        {
            if (IsBorrowedPrefix) ExecutableValueStorage.RetireSynchronously(Values, ref _liveExtent, Code.LastOwnedTemporarySlot, extent);
            else _storage.RetireTo(Values, extent);
        }
        private void Trim(int extent) => RetireTo(extent);
        internal void ForgetResultInput(int slot)
            => ExecutableValueStorage.ForgetResultInput(Values, ref _liveExtent, slot);
        internal bool CanRetireWithoutCleanup(int extent)
            => !HasPendingDisposals && ExecutableValueStorage.CanRetireWithoutCleanup(Values, _liveExtent, Code.LastOwnedTemporarySlot, extent);
        internal void CheckExecution(LythonSourceSpan span) => _scope.State.CheckExecution(span);
        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)
            => _prefixFunction is { } function ? function.GetLookupCaches(span) : _storage.GetLookupCaches(count, span);

''' + text[b:]
text=text.replace('if (Stack.TryAdvanceNativeIteration(Values, slot, out hasValue, out next)) return true;',
    'if (!IsBorrowedPrefix && _storage.TryAdvanceNativeIteration(Values, slot, out hasValue, out next)) return true;\n            hasValue = false;\n            next = default;')
text=text.replace('finally { DisposeValues(); Stack.ReleaseStorage(); }','finally { DisposeValues(); }')
path.write_text(text,encoding='utf-8',newline='\n')

path=runtime/'LythonRuntime.Executable.cs';text=path.read_text(encoding='utf-8')
a=text.index('        internal static ExecutableValueStorage ForBorrowedPrefix(')
b=text.index('        internal readonly ExecutableSlot[] Values',a)
text=text[:a]+text[b:]
text=text.replace('public int LiveExtent { get; private set; }','public int LiveExtent;')
text=text.replace('''            values[resultSlot] = result;
            LiveExtent = liveExtent;
''','''            CompletePublication(values, ref LiveExtent, resultSlot, liveExtent, result);
''',1)
marker='''        internal object TakeValue(int inputSlot, int liveExtent)'''
text=text.replace(marker,'''        internal static void CompletePublication(Span<ExecutableSlot> values, ref int extent,
            int resultSlot, int liveExtent, ExecutableSlot result)
        {
            values[resultSlot] = result;
            extent = liveExtent;
        }

'''+marker)
for result in ['object','ExecutableSlot']:
    method='TakeValue'if result=='object'else'TakeSlotValue'
    old=f'        internal {result} {method}(Span<ExecutableSlot> values, int inputSlot, int liveExtent)\n        {{'
    new=f'''        internal {result} {method}(Span<ExecutableSlot> values, int inputSlot, int liveExtent)
            => {method}(values, ref LiveExtent, inputSlot, liveExtent);

        internal static {result} {method}(Span<ExecutableSlot> values, ref int extent, int inputSlot, int liveExtent)
        {{'''
    assert old in text;text=text.replace(old,new)
    start=text.index(f'        internal static {result} {method}(');end=text.index('\n        }',start)
    text=text[:start]+text[start:end].replace('LiveExtent = liveExtent;','extent = liveExtent;')+text[end:]
old='''        internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)
        {
            values[resultSlot].Object = null!;
            LiveExtent = resultSlot;
        }'''
new='''        internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)
            => ForgetResultInput(values, ref LiveExtent, resultSlot);

        internal static void ForgetResultInput(Span<ExecutableSlot> values, ref int extent, int resultSlot)
        {
            values[resultSlot].Object = null!;
            extent = resultSlot;
        }'''
assert old in text;text=text.replace(old,new)
old='''            if (HasPendingDisposals) return false;
            for (var i = Math.Min(LiveExtent - 1, _lastOwnedTemporarySlot); i >= liveExtent; i--)'''
new='''            return !HasPendingDisposals && CanRetireWithoutCleanup(values, LiveExtent, _lastOwnedTemporarySlot, liveExtent);
        }

        internal static bool CanRetireWithoutCleanup(Span<ExecutableSlot> values, int extent, int lastOwned, int liveExtent)
        {
            for (var i = Math.Min(extent - 1, lastOwned); i >= liveExtent; i--)'''
assert old in text;text=text.replace(old,new)
old='''        public void RetireTo(Span<ExecutableSlot> values, int liveExtent)
        {
            if (liveExtent == LiveExtent)'''
new='''        internal static void RetireSynchronously(Span<ExecutableSlot> values, ref int extent, int lastOwned, int liveExtent)
        {
            if (liveExtent == extent) return;
            for (var i = Math.Min(extent - 1, lastOwned); i >= liveExtent; i--)
                if (values[i].Reference is ExecutableTemporaryValue temporary)
                {
                    values[i].Object = null!;
                    temporary.Dispose();
                }
            values.Slice(liveExtent, extent - liveExtent).Clear();
            extent = liveExtent;
        }

        public void RetireTo(Span<ExecutableSlot> values, int liveExtent)
        {
            if (!DeferAsyncDisposal)
            {
                RetireSynchronously(values, ref LiveExtent, _lastOwnedTemporarySlot, liveExtent);
                return;
            }
            if (liveExtent == LiveExtent)'''
assert old in text;text=text.replace(old,new)
path.write_text(text,encoding='utf-8',newline='\n')

path=runtime/'PyExecutableFunction.cs';text=path.read_text(encoding='utf-8')
a=text.index('        var work = new LythonRuntime.ExecutableWorkState')
b=text.index('        var entered = false;',a)
text=text[:a]+'''        var index = _codeObject.EntryIndex;
        var liveExtent = _codeObject.FirstTemporarySlot;
        LythonRuntime.ExecutableSlot returned = default;
        var state = new LythonRuntime.NativeExecution(this, values, ref index, ref liveExtent,
            ref returned, consumedByIteration, unpackedReturn.Length);
'''+text[b:]
path.write_text(text,encoding='utf-8',newline='\n')

for path in runtime.glob('LythonRuntime.Executable*.cs'):
    text=path.read_text(encoding='utf-8');old=text
    for name in ['HasPendingDisposals','CheckExecution','GetLookupCaches','LiveExtent']:
        text=text.replace('execution.Stack.'+name,'execution.'+name)
    # Do not alter owned fields whose identifier merely ends in execution.
    for name in ['HasPendingDisposals','CheckExecution','GetLookupCaches','LiveExtent']:
        text=text.replace('_execution.'+name,'_execution.Stack.'+name)
    text=text.replace('execution.Stack.RestoreNativeExtent(originalExtent)','execution.LiveExtent = originalExtent')
    if text!=old:path.write_text(text,encoding='utf-8',newline='\n')

path=root/'tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs';text=path.read_text(encoding='utf-8')
a=text.index('            var work = new LythonRuntime.ExecutableWorkState')
b=text.index('            context.State.CloseResources();',a)
text=text[:a]+'''            var liveExtent = source + 1;
            LythonRuntime.ExecutableSlot returned = default;
            var execution = new LythonRuntime.NativeExecution(function, values, ref index, ref liveExtent,
                ref returned, true);
'''+text[b:]
path.write_text(text,encoding='utf-8',newline='\n')
print('Borrowed prefixes use three scalar locals; owned storage construction removed. Shared refs/retirement/publication retained.')
