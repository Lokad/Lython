from pathlib import Path
import ast

notes=Path(__file__).parent
out=notes/'lean'
source=(notes/'freeze.py').read_text(encoding='utf-8')
source=source.replace("prior=r.parent/'json-scalars-r492'","prior=r.parent.parent/'json-scalars-r492'")
source=source.replace('PrivateR495 one completed-instruction loop on22d5a5f3; compiler call-loan cleanup bound corrected; no promotion',
    'PrivateR495 lean PC/live/return refs and flat common transfers on22d5a5f3; no persistent borrowed-prefix work record; no promotion')
ast.parse(source)
(out/'freeze.py').write_text(source,encoding='utf-8',newline='\n')
source=(notes/'capture-codegen.py').read_text(encoding='utf-8')
source=source.replace("repo=r.parents[3]","repo=r.parents[4]")
source=source.replace("r=Path(__file__).resolve().parent;repo=r.parents[4];old=r.parent/'activation-r403'",
                      "r=Path(__file__).resolve().parent;repo=r.parents[4]")
ast.parse(source)
(out/'capture-codegen.py').write_text(source,encoding='utf-8',newline='\n')
print('Existing frozen-image/golden/allocation and diagnostic codegen checks prepared for the lean footprint.')
