from pathlib import Path
import ast

notes=Path(__file__).parent
out=notes/'lean'
source=(notes/'prepare-quiet.py').read_text(encoding='utf-8')
source=source.replace("old=r.parent/'json-scalars-r492'","old=r.parent.parent/'json-scalars-r492'")
a=source.index('subjects=[]');b=source.index('assert not set',a)
source=source[:a]+'''subjects=[]
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else archive.extractfile(member).read()
  subjects.append(dict(kind='completed-replica',path='completed-runner-b915-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/attribution/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
subjects.append(dict(kind='completed-replica',path='completed-runner-attribution-b916-20261117/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
''' +source[b:]
source=source.replace("(r.parent/'native-generators-r494/refined/quiet/config.json')",
                      "(r.parent/'quiet/config.json')")
source=source.replace("donor['root']='/home/lokad/lython-bench-checks/native-generators-refined-b914-20261117'",
                      "donor['root']='/home/lokad/lython-bench-checks/completed-runner-b915-20261117'")
source=source.replace("(r.parent/'native-generators-r494/launch.py')",
                      "(r.parent/'launch.py')")
source=source.replace(".replace('json-cpython-b908-20261117','native-generators-refined-b914-20261117')",
                      ".replace('json-cpython-b908-20261117','completed-runner-b915-20261117')")
source=source.replace("remote='/home/lokad/lython-bench-checks/completed-runner-b915-20261117'",
                      "remote='/home/lokad/lython-bench-checks/completed-runner-lean-b917-20261117'")
source=source.replace('lython-b915-completed-runner-20261117','lython-b917-completed-runner-lean-20261117')
source=source.replace('lython-b915-fixtures','lython-b917-fixtures').replace("'B915'","'B917'")
source=source.replace('Fully qualified33bd7efd/5e7058a3 versus privateR495 on22d5a5f3; single completed-instruction loop and corrected call-loan cleanup bound',
                      'Fully qualified33bd7efd/5e7058a3 versus lean privateR495 on22d5a5f3; scalar PC/live/return refs, flat common transfer/control, no owned prefix work record')
source=source.replace('One existing completed-instruction runner for borrowed prefixes and admitted frames; duplicate native loop/eligibility scan/call-format-publication removed. Existing binding, ownership and async lifecycles.',
                      'One completed-instruction runner with direct scalar control refs and flat common transfers; persistent borrowed-prefix work record and displaced span overloads removed. Existing binding, ownership, native returns, cased iteration and async cleanup.')
source=source.replace("s=(old/'quiet/collect.py').read_text(encoding='utf-8');",
                      "s=(old/'quiet/collect.py').read_text(encoding='utf-8').replace('bounded R486 call-copy funding source pair','lean R495 shared-runner source pair');")
ast.parse(source)
(out/'prepare-quiet.py').write_text(source,encoding='utf-8',newline='\n')
print('Existing five-job source/control comparison prepared; only superseded39c aliases and committed completed raw replicas eligible for fresh retirement.')
