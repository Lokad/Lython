from pathlib import Path

runtime=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494/src/Lokad.Lython/Runtime')
p=runtime/'LythonRuntime.Executable.cs';text=p.read_text(encoding='utf-8')
text=text.replace('''        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)
            => PublishSlot(_items, resultSlot, liveExtent, result);

        internal void PublishSlot(Span<ExecutableSlot> values, int resultSlot, int liveExtent, ExecutableSlot result)
        {''','''        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)
        {
            var values = _items;''')
text=text.replace('if (liveExtent < LiveExtent) RetireTo(values, liveExtent);','if (liveExtent < LiveExtent) RetireTo(liveExtent);')
for result,name in [('object','TakeValue'),('ExecutableSlot','TakeSlotValue')]:
    old=f'''        internal {result} {name}(int inputSlot, int liveExtent)
            => {name}(_items, inputSlot, liveExtent);

        internal {result} {name}(Span<ExecutableSlot> values, int inputSlot, int liveExtent)
            => {name}(values, ref LiveExtent, inputSlot, liveExtent);'''
    new=f'''        internal {result} {name}(int inputSlot, int liveExtent)
            => {name}(_items, ref LiveExtent, inputSlot, liveExtent);'''
    assert old in text;text=text.replace(old,new)
old='''        internal void ForgetResultInput(int resultSlot)
            => ForgetResultInput(_items, resultSlot);

        internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)
            => ForgetResultInput(values, ref LiveExtent, resultSlot);'''
assert old in text;text=text.replace(old,'''        internal void ForgetResultInput(int resultSlot)
            => ForgetResultInput(_items, ref LiveExtent, resultSlot);''')
old='''        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
            => TryPrepareNativeIteration(_items, source, slot, liveExtent, span);

        internal bool TryPrepareNativeIteration(Span<ExecutableSlot> values, object source, int slot, int liveExtent, LythonSourceSpan span)
        {'''
assert old in text;text=text.replace(old,'''        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            var values = _items;''')
text=text.replace('PublishSlot(values, slot, liveExtent, ExecutableSlot.FromObject(source));',
                  'PublishSlot(slot, liveExtent, ExecutableSlot.FromObject(source));')
old='''        internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)
            => TryAdvanceNativeIteration(_items, slot, out hasValue, out next);

        internal bool TryAdvanceNativeIteration(Span<ExecutableSlot> values, int slot, out bool hasValue, out ExecutableSlot next)
        {'''
assert old in text;text=text.replace(old,'''        internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)
        {
            var values = _items;''')
old='''        internal readonly bool CanRetireWithoutCleanup(int liveExtent)
            => CanRetireWithoutCleanup(_items, liveExtent);

        internal readonly bool CanRetireWithoutCleanup(Span<ExecutableSlot> values, int liveExtent)
        {
            return !HasPendingDisposals && CanRetireWithoutCleanup(values, LiveExtent, _lastOwnedTemporarySlot, liveExtent);
        }'''
assert old in text;text=text.replace(old,'''        internal readonly bool CanRetireWithoutCleanup(int liveExtent)
            => !HasPendingDisposals && CanRetireWithoutCleanup(_items, LiveExtent, _lastOwnedTemporarySlot, liveExtent);''')
old='''        public void RetireTo(int liveExtent)
            => RetireTo(_items, liveExtent);

'''
assert old in text;text=text.replace(old,'')
text=text.replace('''        public void RetireTo(Span<ExecutableSlot> values, int liveExtent)
        {''','''        public void RetireTo(int liveExtent)
        {
            var values = _items;''')
p.write_text(text,encoding='utf-8',newline='\n')

p=runtime/'LythonRuntime.Executable.NativePrefix.cs';text=p.read_text(encoding='utf-8')
text=text.replace('_storage.RetireTo(Values, extent)','_storage.RetireTo(extent)')
text=text.replace('Stack.TryPrepareNativeIteration(Values, source, slot, liveExtent, span)',
                  'Stack.TryPrepareNativeIteration(source, slot, liveExtent, span)')
text=text.replace('_storage.TryAdvanceNativeIteration(Values, slot, out hasValue, out next)',
                  '_storage.TryAdvanceNativeIteration(slot, out hasValue, out next)')
# Keep the pre-existing closed cased-text iteration available to stack-borrowed
# helpers. Its private source owns/funds its storage, without a position array.
text=text.replace('''            if (!IsBorrowedPrefix) return Stack.TryPrepareNativeIteration''',
'''            if (source is PyStringOps.CasedWhitespaceIteration)
            {
                PublishValue(slot, liveExtent, source);
                return true;
            }
            if (!IsBorrowedPrefix) return Stack.TryPrepareNativeIteration''')
text=text.replace('''            if (Values[slot].Reference is PyIteration.Cursor''',
'''            if (Values[slot].Reference is PyStringOps.CasedWhitespaceIteration words)
            {
                var result = words.MoveNext();
                hasValue = result.HasValue;
                next = hasValue ? result.TakeSlotValue() : default;
                return true;
            }
            if (Values[slot].Reference is PyIteration.Cursor''')
p.write_text(text,encoding='utf-8',newline='\n')
print('Displaced instance-span overloads removed; one shared synchronous retirement/publication core remains.')
