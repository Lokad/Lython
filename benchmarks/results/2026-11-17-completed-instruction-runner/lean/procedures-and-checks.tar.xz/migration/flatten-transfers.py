from pathlib import Path

runtime=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494/src/Lokad.Lython/Runtime')
p=runtime/'LythonRuntime.Executable.Interpreter.cs';text=p.read_text(encoding='utf-8')
a=text.index('        private static void ExecuteStackTransfer(')
b=text.index('        private bool ExecuteStructure(',a)
old=text[a:b]
c=old.index('                    var target = ReadOperand(')
d=old.index('\n                    break;',c)
member=old[c:d]
member='\n'.join(line[8:] for line in member.split('\n'))
text=text[:a]+'''        private static void ExecuteMemberLoad(ref NativeExecution execution, ExecutionContext scope,
            ExecutionContext invocation, in ExecutableInstruction instruction)
        {
            if (instruction.OpCode == ExecutableOpCode.LoadCallMember
                && TryLoadDirectCallReceiver(ref execution, scope, invocation, instruction)) return;
'''+member+'''
        }

'''+text[b:]
old='''                case ExecutableOpCode.JumpIfFalse:
                    if (!IsTruthy(TakeOperand(ref execution, instruction, scope), scope, instruction.Span))
                    {
                        execution.InstructionIndex = instruction.TargetIndex;
                        return true;
                    }
                    return false;

                case ExecutableOpCode.Jump:
                    execution.InstructionIndex = instruction.TargetIndex;
                    return true;

'''
assert old in text;text=text.replace(old,'')
old='''                case ExecutableOpCode.Return:
                    return DeliverReturn(ref execution, invocation, TakeReturnOperand(ref execution, instruction, scope), instruction.Span);

                case ExecutableOpCode.ReturnNone:
                    return DeliverReturn(ref execution, invocation, ExecutableSlot.FromObject(PyNone.Instance), instruction.Span);

'''
assert old in text;text=text.replace(old,'')
p.write_text(text,encoding='utf-8',newline='\n')

p=runtime/'LythonRuntime.Executable.Interpreter.Dispatch.cs';text=p.read_text(encoding='utf-8')
text=text.replace('ExecuteStackTransfer(ref execution, scope, invocation, instruction)',
                  'ExecuteMemberLoad(ref execution, scope, invocation, instruction)',1)
a=text.index('                        case ExecutableOpCode.LoadConst or ExecutableOpCode.LoadGlobal or')
b=text.index('                        case ExecutableOpCode.MakeList:',a)
text=text[:a]+'''                        case ExecutableOpCode.LoadConst:
                            PublishInstructionResult(ref execution, invocation, instruction,
                                RuntimeValue(execution.Code.Constants[instruction.ConstantIndex]));
                            break;
                        case ExecutableOpCode.LoadGlobal:
                            PublishInstructionResult(ref execution, invocation, instruction,
                                ResolveExecutableGlobal(execution.Code.Names[instruction.NameIndex], instruction.Span, scope));
                            break;
                        case ExecutableOpCode.LoadName:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            PublishInstructionResult(ref execution, invocation, instruction,
                                ResolveExecutableName(execution.Code.Names[instruction.NameIndex], instruction.Span, invocation));
                            break;
                        case ExecutableOpCode.PreloadImplicitSuperArguments:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            PreloadImplicitSuperArguments(invocation, instruction.Span);
                            break;
                        case ExecutableOpCode.StoreGlobal:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            StoreName(execution.Code.Names[instruction.NameIndex],
                                execution.TakeValue(instruction.InputStart, instruction.LiveExtent), invocation, instruction.Span);
                            break;
                        case ExecutableOpCode.StoreName:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            AssignExecutableBoundName(execution.Code, execution.Locals,
                                execution.Code.Names[instruction.NameIndex],
                                execution.TakeValue(instruction.InputStart, instruction.LiveExtent), invocation, instruction.Span);
                            break;
                        case ExecutableOpCode.Dup:
                            execution.PublishValue(instruction.ResultSlot + 1, instruction.LiveExtent, execution[instruction.InputStart]);
                            break;
                        case ExecutableOpCode.PopTop:
                            _ = execution[instruction.InputStart];
                            execution.RetireTo(instruction.LiveExtent);
                            break;
''' +text[b:]
text=text.replace('''                            if (!asynchronous || condition is not PyInstance)
                                jumped = ExecuteControlFlow(ref execution, scope, invocation, instruction);
''','''                            if (!asynchronous || condition is not PyInstance)
                            {
                                if (!IsTruthy(TakeOperand(ref execution, instruction, scope), scope, instruction.Span))
                                {
                                    execution.InstructionIndex = instruction.TargetIndex;
                                    jumped = true;
                                }
                            }
''')
a=text.index('                        case ExecutableOpCode.AbruptJump or ExecutableOpCode.Jump or ExecutableOpCode.MatchException or')
b=text.index('                            jumped = ExecuteControlFlow(',a)
text=text[:a]+'''                        case ExecutableOpCode.Jump:
                            execution.InstructionIndex = instruction.TargetIndex;
                            jumped = true;
                            break;
                        case ExecutableOpCode.Return or ExecutableOpCode.ReturnNone:
                            if (invocation is null && execution.Code.ExceptionRegions.Count != 0)
                                return InstructionPause.ContextRequired;
                            jumped = DeliverReturn(ref execution, invocation,
                                instruction.OpCode == ExecutableOpCode.Return
                                    ? TakeReturnOperand(ref execution, instruction, scope)
                                    : ExecutableSlot.FromObject(PyNone.Instance), instruction.Span);
                            if (!execution.ReturnValue.IsUnassigned)
                            {
                                if (asynchronous && execution.HasPendingDisposals)
                                {
                                    pending = new(jumped);
                                    return InstructionPause.Disposal;
                                }
                                return InstructionPause.Boundary;
                            }
                            break;
                        case ExecutableOpCode.AbruptJump or ExecutableOpCode.MatchException or
                             ExecutableOpCode.BindException or ExecutableOpCode.ReraiseException or ExecutableOpCode.ClearException or
                             ExecutableOpCode.EndFinally:
                            if (invocation is null && (instruction.OpCode != ExecutableOpCode.AbruptJump
                                || execution.Code.ExceptionRegions.Count != 0)) return InstructionPause.ContextRequired;
''' +text[b:]
p.write_text(text,encoding='utf-8',newline='\n')
assert 'ExecuteStackTransfer'not in text
print('Common transfers/jumps/returns execute once in the shared opcode loop; real member/protected helpers remain.')
