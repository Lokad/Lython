using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal const int NativeValueCapacity = 16;
    // Eligibility only: deeper calls continue in the existing linear runner.
    // Use its logical depth, without a second counter or a guest recursion limit.
    private const int NativeCallDepth = 8;

    // This view cannot survive a suspension. The final executable slots and PC
    // are also the ordinary frame's representation; transfer never replays work.
    internal ref partial struct NativeExecution
    {
        private readonly ref ExecutableWorkState _work;
        internal readonly Span<ExecutableSlot> Values;
        private readonly ExecutionContext _scope;
        private readonly int _unpackedReturnCount;
        private int _unpackedTupleStart = -1;
        private bool _transferred;
        private ExecutionContext? _preparedChild;
        private MemoryGovernor? _preparedChildOwner;
        internal LythonRuntimeException? Failure { get; private set; }
        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;
        internal ExecutableCodeObject Code => _work.Code;
        internal Span<ExecutableSlot> Locals => Values;
        internal IReadOnlyList<ExecutableCell>? ClosureCells => _work.ClosureCells;
        internal ref ExecutableValueStorage Stack => ref _work.Stack;
        internal ref int Index => ref _work.InstructionIndex;
        internal ref int InstructionIndex => ref _work.InstructionIndex;
        internal int LiveExtent { get => Stack.LiveExtent; set => Stack.RestoreNativeExtent(value); }
        internal bool ReturnConsumedByIteration => _work.ReturnConsumedByIteration;
        internal ref ExecutableSlot ReturnValue => ref _work.ReturnValue;
        internal bool IsBorrowedPrefix => !Stack.HasValueArray;

        internal NativeExecution(ref ExecutableWorkState work, Span<ExecutableSlot> values,
            ExecutionContext scope, int unpackedReturnCount = 0)
        {
            _work = ref work;
            Values = values;
            _scope = scope;
            _unpackedReturnCount = unpackedReturnCount;
        }

        internal object this[int index] { get => Values[index].Object.RequireNotNull(); set => Values[index].Object = value; }
        internal void PublishValue(int resultSlot, int liveExtent, object value)
            => PublishSlot(resultSlot, liveExtent, ExecutableSlot.FromObject(value));
        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot value)
            => Stack.PublishSlot(Values, resultSlot, liveExtent, value);
        internal object TakeValue(int inputSlot, int liveExtent) => Stack.TakeValue(Values, inputSlot, liveExtent);
        internal ExecutableSlot TakeSlotValue(int inputSlot, int liveExtent) => Stack.TakeSlotValue(Values, inputSlot, liveExtent);
        internal void RetireTo(int extent) => Stack.RetireTo(Values, extent);
        private void Trim(int extent) => RetireTo(extent);

        internal void ForgetResultInput(int slot) => Stack.ForgetResultInput(Values, slot);
        internal bool CanRetireWithoutCleanup(int extent) => Stack.CanRetireWithoutCleanup(Values, extent);

        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            if (!IsBorrowedPrefix) return Stack.TryPrepareNativeIteration(Values, source, slot, liveExtent, span);
            if (source is not (PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)) return false;
            PublishValue(slot, liveExtent, PyIteration.Cursor.Create(source, span, _scope));
            return true;
        }

        internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)
        {
            if (Stack.TryAdvanceNativeIteration(Values, slot, out hasValue, out next)) return true;
            if (Values[slot].Reference is PyIteration.Cursor { CanPullWithoutGuestCode: true } cursor)
            {
                var result = cursor.TryMoveNext();
                hasValue = result.HasValue;
                next = hasValue ? result.TakeSlotValue() : default;
                return true;
            }
            return false;
        }

        internal void RetainPreparedChild(ExecutionContext child, MemoryGovernor owner)
        {
            _preparedChild = child;
            _preparedChildOwner = owner;
        }

        internal bool Run(LythonSourceSpan entrySpan, out ExecutableSlot result, Span<ExecutableSlot> unpackedReturn = default)
        {
            // The call boundary owns logical interpreter admission, and
            // StartInline owns function admission. Like an ordinary bound body,
            // validate this managed stack entry without charging nesting twice.
            ExecutionState.EnsureInterpreterStack(entrySpan);
            var previous = _scope.State.CurrentException;
            try
            {
                var pause = ExecutionContext.ExecuteInstructionPrefix(ref this, _scope, null, false, out _, out _, out _);
                var completed = pause == ExecutionContext.InstructionPause.Boundary;
                if (!completed && pause != ExecutionContext.InstructionPause.ContextRequired)
                    throw new InvalidOperationException("A borrowed prefix cannot suspend.");
                result = ReturnValue.IsUnassigned ? ExecutableSlot.FromObject(PyNone.Instance) : ReturnValue;
                if (completed && ReturnedUnpacked)
                {
                    Values.Slice(_unpackedTupleStart, _unpackedReturnCount).CopyTo(unpackedReturn);
                    Trim(Code.FirstTemporarySlot);
                    _scope.CheckExecution(Code.Instructions[Index + 1].Span);
                }
                return completed;
            }
            catch (LythonRuntimeException error)
            {
                if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous))
                    error.PythonContext ??= previous;
                if (Code.ExceptionRegions.Count == 0) throw;
                // First refusal and cancellation still fail the command. A
                // catchable guest fault transfers once, without replaying its
                // operation or building a second exception dispatcher here.
                _scope.CheckExecution(entrySpan);
                Failure = error;
                result = ExecutableSlot.FromObject(PyNone.Instance);
                return false;
            }
            finally
            {
                _scope.State.SetCurrentException(previous);
            }
        }

        internal bool TryReturnUnpackedTuple(in ExecutableInstruction instruction)
        {
            if (Code.NativePrefixEnd != Code.Instructions.Length || _unpackedReturnCount == 0 || instruction.ItemCount != _unpackedReturnCount
                || instruction.HasLocalResult || Index + 1 >= Code.Instructions.Length) return false;
            ref readonly var next = ref Code.Instructions[Index + 1];
            if (next.OpCode != ExecutableOpCode.Return || next.InputStart != instruction.ResultSlot) return false;
            var items = Values.Slice(instruction.InputStart, instruction.ItemCount);
            // Keep eager tuple admission before any caller target can change.
            // Its conservative funding survives until the execution owner ends;
            // only the unobservable tuple shell/backing allocation disappears.
            var bytes = SlotTupleBytes(items, _scope, instruction.Span);
            _scope.MemoryGovernor.Reserve(bytes, instruction.Span);
            try
            {
                _scope.CheckExecution(instruction.Span);
                _scope.MemoryGovernor.Commit(bytes);
            }
            catch { _scope.MemoryGovernor.ReleaseReserved(bytes); throw; }
            // The return wrapper copies these already-admitted operands before
            // native cleanup. The hot execution state retains no caller borrow.
            _unpackedTupleStart = instruction.InputStart;
            return true;
        }

        internal void PrepareTransfer()
        {
            // Final managed slots transfer directly; no borrowed side span remains.
            Values[LiveExtent..].Clear();
        }
        internal void TransferOwnership(ExecutionContext frame)
        {
            if (_preparedChild is { } child)
            {
                var call = Code.CallSites[Code.Instructions[Index].CallSiteIndex];
                frame.AdoptPreparedNativeChild(child, call, Code.Instructions[Index].InputStart, _preparedChildOwner!);
                _preparedChild = null;
                _preparedChildOwner = null;
            }
            _transferred = true;
        }
        internal void Dispose()
        {
            if (_transferred) return;
            try
            {
                if (_preparedChild is { } child)
                {
                    _preparedChild = null;
                    try { ExecutionContext.AbortPreparedNativeCall(child, _preparedChildOwner!); }
                    finally { _scope.LeaveInterpreterFrame(); }
                }
            }
            finally { DisposeValues(); Stack.ReleaseStorage(); }
        }

        private void DisposeValues() => RetireTo(Code.FirstTemporarySlot);
    }

    internal static ExecutionContext CreateNativeContinuation(PyExecutableFunction function,
        in BoundFunctionArguments bound, LythonSourceSpan span, int index, int liveExtent, bool consumedByIteration,
        LythonRuntimeException? failure)
    {
        var frame = function.EnterInvocationFrame(bound, span, enterFunctionCall: false);
        InitializeExecutableFrame(function.CodeObject, frame, bound, function.ClosureCells,
            argumentsAreLocals: true, lookupOwner: function, returnConsumedByIteration: consumedByIteration);
        frame.RestoreNativePosition(index, liveExtent, failure);
        return frame;
    }

    internal sealed partial class ExecutionContext
    {
        internal void RestoreNativePosition(int index, int liveExtent, LythonRuntimeException? failure)
        {
            _execution.InstructionIndex = index;
            _execution.Stack.RestoreNativeExtent(liveExtent);
            _injectedException = failure;
        }
    }
}
