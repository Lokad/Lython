using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private static InstructionPause ExecuteComparisonInstruction(ref NativeExecution execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction, bool asynchronous,
            out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)
        {
            pending = default;
            pendingSpan = null;
            // Preserve the borrowed prefix's scalar comparison without boxing
            // its machine operands. The same branch/cleanup now serves frames.
            if (IsScalarComparison(instruction.BinaryOperator)
                && TryReadMachineOperand(execution.Code, execution.Values, instruction.InputStart, out var left)
                && TryReadMachineOperand(execution.Code, execution.Values, instruction.SecondInput, out var right))
            {
                scope.CheckExecution(instruction.Span);
                pending = new(CompleteComparisonBranch(ref execution, scope, instruction,
                    CompareOrderedResult(instruction.BinaryOperator, left.CompareTo(right))));
                return InstructionPause.Continue;
            }
            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);
            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);
            try
            {
                if (TryEvaluateScalarComparison(instruction.BinaryOperator, first, second!, scope, instruction.Span, out var truth))
                    pending = new(CompleteComparisonBranch(ref execution, scope, instruction, truth));
                else if (invocation is null) return InstructionPause.ContextRequired;
                else if (!asynchronous)
                {
                    var result = EvaluateBinaryOperator(instruction.BinaryOperator, first, second!, invocation, instruction.Span);
                    execution.RetireTo(instruction.LiveExtent);
                    invocation.CheckExecution(instruction.Span);
                    pending = new(CompleteComparisonBranch(ref execution, invocation, instruction, IsTruthy(result, invocation, instruction.Span)));
                }
                else
                {
                    pending = invocation.ExecuteComparisonBranchAsync(instruction, first, second);
                    if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                }
                return InstructionPause.Continue;
            }
            catch { execution.RetireTo(instruction.LiveExtent); throw; }
        }

        private static bool CompleteComparisonBranch(ref ExecutableWorkState work, ExecutionContext context,
            in ExecutableInstruction instruction, bool truth)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, context);
            return CompleteComparisonBranch(ref execution, context, instruction, truth);
        }

        private static bool CompleteComparisonBranch(ref NativeExecution execution, ExecutionContext context,
            in ExecutableInstruction instruction, bool truth)
        {
            execution.RetireTo(instruction.LiveExtent);
            context.CheckExecution(instruction.Span);
            if (truth) return false;
            execution.InstructionIndex = instruction.TargetIndex;
            return true;
        }

        private async ValueTask<bool> ExecuteComparisonBranchAsync(ExecutableInstruction instruction, object first, object second)
        {
            try
            {
                var result = await EvaluateBinaryOperatorAsync(instruction.BinaryOperator, first, second!, this, instruction.Span).ConfigureAwait(false);
                _execution.Stack.RetireTo(instruction.LiveExtent);
                CheckExecution(instruction.Span);
                var truth = await IsTruthyAsync(result, this, instruction.Span).ConfigureAwait(false);
                return CompleteComparisonBranch(ref _execution, this, instruction, truth);
            }
            catch { _execution.Stack.RetireTo(instruction.LiveExtent); throw; }
        }

    }
}
