using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(instruction, ExecutableSlot.FromObject(value));

        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
        {
            var execution = new NativeExecution(ref _execution, _execution.Stack.Values, this);
            PublishInstructionResult(ref execution, this, instruction, value);
        }

        internal static void PublishInstructionResult(ref NativeExecution execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref execution, invocation, instruction, ExecutableSlot.FromObject(value));

        internal static void PublishInstructionResult(ref NativeExecution execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            if (!instruction.HasLocalResult)
            {
                execution.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
            }
            else CompleteLocalResult(ref execution, invocation, instruction, value);
        }

        private static void CompleteLocalResult(ref NativeExecution execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            // Preserve the original input retirement and its disposal order.
            // Pending cleanup must finish before the binding becomes visible;
            // the unchanged driver and following store already implement that.
            if (instruction.LiveExtent < execution.Stack.LiveExtent) execution.RetireTo(instruction.LiveExtent);
            if (execution.Stack.HasPendingDisposals)
            {
                execution.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
                return;
            }

            execution.ForgetResultInput(instruction.ResultSlot);
            ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            execution.Stack.CheckExecution(store.Span);
            StoreLocalValue(execution.Code, execution.Locals, invocation, store.LocalSlot, value, store.Span);
            execution.InstructionIndex++;
        }
    }
}
