from pathlib import Path
import datetime,hashlib,json,subprocess

notes=Path(__file__).parent
config=json.loads((notes/'config.json').read_text(encoding='utf-8'))
config['unit']='lython-b916b-completed-runner-attribution-20261117'
source=(notes/'run.sh').read_text(encoding='utf-8')
old=(notes/'run.sh').read_bytes()
(notes/'first-run-crlf.sh').write_bytes(old)
(notes/'run.sh').write_text(source,encoding='utf-8',newline='\n')
new=(notes/'run.sh').read_bytes();assert b'\r'not in new
code='''from pathlib import Path
import fcntl,hashlib,json,os,subprocess
c=CONFIG
root=Path(c['root']);fixture=root/'guest-fixtures'
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 prior=subprocess.check_output(['systemctl','show','lython-b916-completed-runner-attribution-20261117.service','--property=MainPID,Result,ActiveState'],text=True)
 assert 'MainPID=0'in prior and 'Result=exit-code'in prior and 'ActiveState=failed'in prior,prior
 assert root.resolve()==root and root.stat().st_uid==os.getuid()and os.path.ismount(fixture)and not list(fixture.iterdir())
 for role,files in c['identity']['imageFiles'].items():
  for name,sha in files.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==sha
 path=root/'run.sh';assert hashlib.sha256(path.read_bytes()).hexdigest()==OLD
 (root/'first-run-crlf.sh').write_bytes(path.read_bytes())
 path.write_bytes(NEW)
 assert b'\\r'not in path.read_bytes()
 subprocess.run(['/bin/sh','-n',str(path)],check=True)
 subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(path)],check=True)
 print(json.dumps(dict(restartedAfterVerifiedTerminalSetupFailure=True,unit=c['unit'],allImagesVerified=True,noPriorWorkerOrCapture=True)))
'''.replace('CONFIG',repr(config)).replace('OLD',repr(hashlib.sha256(old).hexdigest())).replace('NEW',repr(new))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=20)
(notes/'launcher-repair.log').write_text(result.stdout+result.stderr,encoding='utf-8')
assert result.returncode==0,result.stdout+result.stderr
(notes/'first-run-config.json').write_bytes((notes/'config.json').read_bytes())
(notes/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc)
(notes/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=120)).isoformat()),indent=2)+'\n',encoding='utf-8')
print(result.stdout+result.stderr)
