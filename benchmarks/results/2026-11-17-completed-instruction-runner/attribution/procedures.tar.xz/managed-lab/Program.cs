var pc = 0;
var live = 0;
var values = new object?[4];
{
    var borrowed = new View(values, ref pc, ref live);
    borrowed.Push("borrowed");
    if (pc != 1 || live != 1 || values[0] is not "borrowed") throw new Exception("Borrow copied state.");
    try { _ = borrowed.Owned.Values; throw new Exception("Missing owned storage was exposed."); }
    catch (InvalidOperationException) { }
}
var frame = new Frame();
await RunOwned(frame);
if (frame.Pc != 2 || frame.Storage.Live != 2 || frame.Storage.Values[1] is not "second")
    throw new Exception("Owned state copied or lost across suspension.");
Console.WriteLine("Managed ref/span view shares PC/live values; borrowed construction has no owned storage record.");

static async Task RunOwned(Frame frame)
{
    { var view = new View(ref frame.Storage, ref frame.Pc); view.Push("first"); }
    await Task.Yield();
    { var view = new View(ref frame.Storage, ref frame.Pc); view.Push("second"); }
}

struct Storage { internal object?[] Values; internal int Live; }
sealed class Frame { internal int Pc; internal Storage Storage = new() { Values = new object?[4] }; }
ref struct View
{
    private readonly ref Storage _ownedStorage;
    private readonly bool _owned;
    private readonly Span<object?> _values;
    private readonly ref int _pc, _live;
    internal View(Span<object?> values, ref int pc, ref int live)
    { _values=values; _pc=ref pc; _live=ref live; }
    internal View(ref Storage storage, ref int pc)
    { _ownedStorage=ref storage; _owned=true; _values=storage.Values; _pc=ref pc; _live=ref storage.Live; }
    internal ref Storage Owned
    { get { if (!_owned) throw new InvalidOperationException("This view owns no storage."); return ref _ownedStorage; } }
    internal void Push(object value) { _values[_live++]=value; _pc++; }
}
