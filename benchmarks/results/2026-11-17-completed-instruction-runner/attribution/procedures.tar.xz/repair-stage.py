from pathlib import Path
import ast, json

notes=Path(__file__).parent
config=json.loads((notes/'config.json').read_text(encoding='utf-8'))
for group in config['retireGroups']:group['optional']=True
(notes/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
source=(notes/'remote-launch.py').read_text(encoding='utf-8')
(notes/'first-stage-archive-validator.py').write_text(source,encoding='utf-8')
(notes/'first-stage-archive-validator.log').write_bytes((notes/'launch.log').read_bytes())
a=source.index('c=');b=source.index('\nb=Path(',a)
source=source[:a]+'c='+repr(config)+source[b:]
source=source.replace('and not root.exists()and source.parent==b','and source.parent==b')
source=source.replace(' root.mkdir()',' root.mkdir(exist_ok=True)')
source=source.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')", " if not(root/'cpython-worker.py').exists():os.link(source/'cpython-worker.py',root/'cpython-worker.py')")
source=source.replace(" os.link(source/'representative.json',root/'representative.json')", " if not(root/'representative.json').exists():os.link(source/'representative.json',root/'representative.json')")
source=source.replace("for n in ['collect.py','archive-owned.py']", "for n in ['collect.py','ops-profile.py']")
ast.parse(source)
(notes/'remote-launch.py').write_text(source,encoding='utf-8')
(notes/'launch.log').rename(notes/'first-stage-preserved-launch.log')
