from pathlib import Path
import ast, gzip, hashlib, io, json, shutil, subprocess, tarfile

notes=Path(__file__).parent
out=notes/'attribution';out.mkdir(exist_ok=False)
repo=Path('D:/code/Lython')
remote='/home/lokad/lython-bench-checks/completed-runner-attribution-b916-20261117'
subjects=[]
canonical='benchmarks/results/2026-11-09-borrowed-call-entry/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo)
assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
    for relative,expected in [('representative.json','e0739a8d0950cba71a12c6623451e5fe7b167315dcc616b9371fe5348e9983d2'),
                              ('confirmation/confirmation.json','84fae69e272083d44ecd86a065be3103a360f856cc6030ca9c61cd6481908d80')]:
        matches=[m for m in archive.getmembers()if m.isfile()and m.name.endswith(relative)
                 and hashlib.sha256(archive.extractfile(m).read()).hexdigest()==expected]
        assert len(matches)==1,(relative,[m.name for m in archive.getmembers()])
        member=matches[0];data=archive.extractfile(member).read()
        subjects.append(dict(kind='completed-replica',path='borrowed-call-entry-b506-20261109/'+relative,
                             bytes=len(data),sha256=expected,canonical=canonical,
                             canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member.name,committedBlobVerified=True))

old=notes.parent/'numeric-json-cost-r490'
profile=(old/'ops-profile.py').read_text(encoding='utf-8')
profile=profile.replace('/home/lokad/lython-bench-checks/numeric-json-cost-b909-20261117',remote)
profile=profile.replace('catalog = candidate / "catalog.json"','catalog = candidate / "representative.json"')
profile=profile.replace("for name, case_id, lane in [('floating-records','scripts.numeric-squared-error.floating.large','warm')]:",
    "for name, case_id, lane in [('reference-calls','calls.positional.large','warm'),('candidate-calls','calls.positional.large','warm'),('reference-floating','scripts.numeric-squared-error.floating.large','warm'),('candidate-floating','scripts.numeric-squared-error.floating.large','warm')]:\n        role=name.split('-')[0]")
profile=profile.replace('worker = tree / "candidate/Lokad.Lython.Benchmarks.dll"','worker = tree / role / "Lokad.Lython.Benchmarks.dll"')
profile=profile.replace("expected_image['coreSHA256']['candidate']","expected_image['coreSHA256'][role]")
profile=profile.replace("(candidate/'candidate'/filename)","(candidate/role/filename)")
profile=profile.replace("expected['coreSHA256']['candidate']","expected['coreSHA256'][role]")
profile=profile.replace("if total_capture_seconds > 12:","if total_capture_seconds > 32:")
(out/'ops-profile.py').write_text(profile,encoding='utf-8')

collector=(old/'collect.py').read_text(encoding='utf-8')
collector=collector.replace('/home/lokad/lython-bench-checks/numeric-json-cost-b909-20261117',remote)
collector=collector.replace("['floating-records']","['reference-calls','candidate-calls','reference-floating','candidate-floating']")
collector=collector.replace("Committed557381fe/frozend739132f; R490 floating JSON attribution",
    "R495 qualified33bd7efd/5e7058a3 versus private39c11156; four diagnostic activation/operand captures, not an elapsed comparison")
(out/'collect.py').write_text(collector,encoding='utf-8')
(out/'run.sh').write_text('set -eu\nroot='+remote+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8')
identity=json.loads((notes/'quiet/identity.json').read_text(encoding='utf-8'))
identity['purpose']='One four-capture CPU attribution of call/floating activation versus hot operand dispatch; PerfMap only, normal GC/tiering, no elapsed or speedup claim.'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')

# Reuse the existing fresh idle-lease/path/hash/UID/all-inode-alias proof gate.
source=(notes.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8')
a=source.index("code = '''")+len("code = '''");b=source.index("'''.replace",a)
code=source[a:b].replace('SUBJECTS',repr(subjects))
code=code.replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]")
code=code.replace('json-cpython-b908-20261117','completed-runner-b915-20261117')
code=code.replace("source/'candidate/Lokad.Lython.dll'","source/'reference/Lokad.Lython.dll'")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
assert result.returncode==0,result.stdout+result.stderr
groups=json.loads(result.stdout)
(out/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8')
names=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(out/'payload.tgz','w:gz')as archive:
    for name in names:archive.add(out/name,arcname=name)
config=dict(root=remote,unit='lython-b916-completed-runner-attribution-20261117',
    source='/home/lokad/lython-bench-checks/completed-runner-b915-20261117',sourceRole='reference',
    sourceFiles=identity['imageFiles']['reference'],sourceCatalogSHA256=identity['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=groups,
    payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),
    unpackedBytes=sum((out/name).stat().st_size for name in names))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
source=(notes/'quiet/remote-launch.py').read_text(encoding='utf-8');a=source.index('c=');b=source.index('\nb=Path(',a)
source=source[:a]+'c='+repr(config)+source[b:]
source=source.replace("if not p.exists():os.link(source/c['sourceRole']/n,p)",
    "if not p.exists():os.link(source/('candidate'if role=='candidate'and n=='Lokad.Lython.dll'else c['sourceRole'])/n,p)")
source=source.replace('lython-b915-fixtures','lython-b916-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=180')
(out/'remote-launch.py').write_text(source,encoding='utf-8')
source=(notes/'launch.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent/'quiet'","r=Path(__file__).parent")
source=source.replace('seconds=230','seconds=120').replace('before230seconds','before120seconds')
source=source.replace('Five-job existing-loop generator comparison source comparison','Four-capture shared-runner attribution')
(out/'launch.py').write_text(source,encoding='utf-8')
source=(old/'retrieve.py').read_text(encoding='utf-8')
source=source.replace('R490','R495').replace('B909','B916')
(out/'retrieve.py').write_text(source,encoding='utf-8')
source=(old/'analyze.py').read_text(encoding='utf-8').replace("['floating-records']","['reference-calls','candidate-calls','reference-floating','candidate-floating']")
(out/'analyze.py').write_text(source,encoding='utf-8')
for path in out.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
print('Existing perf/worker/ownership collection adapted to four fixed captures; no new benchmark framework or source mutation.')
