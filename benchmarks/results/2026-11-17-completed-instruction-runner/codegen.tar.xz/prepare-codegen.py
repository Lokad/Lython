from pathlib import Path
import ast

notes=Path(__file__).parent
source=(notes.parent/'activation-r404/capture-codegen.py').read_text(encoding='utf-8')
source=source.replace("catalog=(old/'final-storage/catalog.json').resolve()", "catalog=(r/'catalog.json').resolve()")
source=source.replace("c['id']=='scripts.csv-invoice.large'", "c['id']=='calls.positional.large'")
source=source.replace('One bounded complete-invoice JIT codegen comparison', 'One bounded positional-call activation JIT codegen comparison')
source=source.replace("[('reference',old/'final-storage/reference'),('withdrawn',old/'retirement/candidate')]",
                      "[('reference',r/'frozen/reference'),('candidate',r/'frozen/candidate')]")
source=source.replace("'*RunCore* *ExecuteInstructionPrefix*'",
                      "'*StartInline* *ExecuteInstructionPrefix* *TryExecuteNativeCall* *ForBorrowedPrefix* *NativeExecution:Run*'")
source=source.replace("response['actualFilesSha256']==case['expectedFilesSha256']",
                      "response.get('actualFilesSha256')==case.get('expectedFilesSha256')")
ast.parse(source)
(notes/'capture-codegen.py').write_text(source,encoding='utf-8')
