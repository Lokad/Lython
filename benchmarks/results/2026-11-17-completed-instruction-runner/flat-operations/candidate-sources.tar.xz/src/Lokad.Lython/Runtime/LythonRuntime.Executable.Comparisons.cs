using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private static bool CompleteComparisonBranch(ref ExecutableWorkState work, ExecutionContext context,
            in ExecutableInstruction instruction, bool truth)
        {
            var execution = new NativeExecution(ref work, work.Stack.Values, context);
            return CompleteComparisonBranch(ref execution, context, instruction, truth);
        }

        private static bool CompleteComparisonBranch(ref NativeExecution execution, ExecutionContext context,
            in ExecutableInstruction instruction, bool truth)
        {
            execution.RetireTo(instruction.LiveExtent);
            context.CheckExecution(instruction.Span);
            if (truth) return false;
            execution.InstructionIndex = instruction.TargetIndex;
            return true;
        }

        private async ValueTask<bool> ExecuteComparisonBranchAsync(ExecutableInstruction instruction, object first, object second)
        {
            try
            {
                var result = await EvaluateBinaryOperatorAsync(instruction.BinaryOperator, first, second!, this, instruction.Span).ConfigureAwait(false);
                _execution.Stack.RetireTo(instruction.LiveExtent);
                CheckExecution(instruction.Span);
                var truth = await IsTruthyAsync(result, this, instruction.Span).ConfigureAwait(false);
                return CompleteComparisonBranch(ref _execution, this, instruction, truth);
            }
            catch { _execution.Stack.RetireTo(instruction.LiveExtent); throw; }
        }

    }
}
