using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal const int NativeValueCapacity = 16;
    // Eligibility only: deeper calls continue in the existing linear runner.
    // Use its logical depth, without a second counter or a guest recursion limit.
    private const int NativeCallDepth = 8;

    // This view cannot survive a suspension. The final executable slots and PC
    // are also the ordinary frame's representation; transfer never replays work.
    internal ref partial struct NativeExecution
    {
        internal readonly ExecutableCodeObject Code;
        internal readonly Span<ExecutableSlot> Values;
        internal readonly IReadOnlyList<ExecutableCell>? ClosureCells;
        internal readonly bool ReturnConsumedByIteration;
        private readonly ref ExecutableValueStorage _storage;
        private readonly ref int _index, _liveExtent;
        private readonly ref ExecutableSlot _returnValue;
        private readonly PyExecutableFunction? _prefixFunction;
        private readonly ExecutionContext _scope;
        private readonly int _unpackedReturnCount;
        private int _unpackedTupleStart = -1;
        private bool _transferred;
        private ExecutionContext? _preparedChild;
        private MemoryGovernor? _preparedChildOwner;
        internal LythonRuntimeException? Failure { get; private set; }
        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;
        internal Span<ExecutableSlot> Locals => Values;
        internal ref ExecutableValueStorage Stack
        {
            get
            {
                if (IsBorrowedPrefix) throw new InvalidOperationException("A borrowed prefix has no owned storage.");
                return ref _storage;
            }
        }
        internal ref int Index => ref _index;
        internal ref int InstructionIndex => ref _index;
        internal int LiveExtent { get => _liveExtent; set => _liveExtent = value; }
        internal ref ExecutableSlot ReturnValue => ref _returnValue;
        internal bool IsBorrowedPrefix => _prefixFunction is not null;
        internal bool HasPendingDisposals => !IsBorrowedPrefix && _storage.HasPendingDisposals;

        internal NativeExecution(ref ExecutableWorkState work, Span<ExecutableSlot> values, ExecutionContext scope)
        {
            Code = work.Code;
            Values = values;
            ClosureCells = work.ClosureCells;
            ReturnConsumedByIteration = work.ReturnConsumedByIteration;
            _storage = ref work.Stack;
            _index = ref work.InstructionIndex;
            _liveExtent = ref work.Stack.LiveExtent;
            _returnValue = ref work.ReturnValue;
            _scope = scope;
        }

        internal NativeExecution(PyExecutableFunction function, Span<ExecutableSlot> values,
            ref int index, ref int liveExtent, ref ExecutableSlot returned, bool consumedByIteration,
            int unpackedReturnCount = 0)
        {
            Code = function.CodeObject;
            Values = values;
            ClosureCells = function.ClosureCells;
            ReturnConsumedByIteration = consumedByIteration;
            _prefixFunction = function;
            _index = ref index;
            _liveExtent = ref liveExtent;
            _returnValue = ref returned;
            _scope = function.DefinitionContext;
            _unpackedReturnCount = unpackedReturnCount;
        }

        internal object this[int index] { get => Values[index].Object.RequireNotNull(); set => Values[index].Object = value; }
        internal void PublishValue(int resultSlot, int liveExtent, object value)
            => PublishSlot(resultSlot, liveExtent, ExecutableSlot.FromObject(value));
        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot value)
        {
            if (liveExtent < _liveExtent) RetireTo(liveExtent);
            ExecutableValueStorage.CompletePublication(Values, ref _liveExtent, resultSlot, liveExtent, value);
        }
        internal object TakeValue(int inputSlot, int liveExtent)
            => ExecutableValueStorage.TakeValue(Values, ref _liveExtent, inputSlot, liveExtent);
        internal ExecutableSlot TakeSlotValue(int inputSlot, int liveExtent)
            => ExecutableValueStorage.TakeSlotValue(Values, ref _liveExtent, inputSlot, liveExtent);
        internal void RetireTo(int extent)
        {
            if (IsBorrowedPrefix) ExecutableValueStorage.RetireSynchronously(Values, ref _liveExtent, Code.LastOwnedTemporarySlot, extent);
            else _storage.RetireTo(extent);
        }
        private void Trim(int extent) => RetireTo(extent);
        internal void ForgetResultInput(int slot)
            => ExecutableValueStorage.ForgetResultInput(Values, ref _liveExtent, slot);
        internal bool CanRetireWithoutCleanup(int extent)
            => !HasPendingDisposals && ExecutableValueStorage.CanRetireWithoutCleanup(Values, _liveExtent, Code.LastOwnedTemporarySlot, extent);
        internal void CheckExecution(LythonSourceSpan span) => _scope.State.CheckExecution(span);
        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)
            => _prefixFunction is { } function ? function.GetLookupCaches(span) : _storage.GetLookupCaches(count, span);

        internal bool TryPrepareNativeIteration(object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            if (source is PyStringOps.CasedWhitespaceIteration)
            {
                PublishValue(slot, liveExtent, source);
                return true;
            }
            if (!IsBorrowedPrefix) return Stack.TryPrepareNativeIteration(source, slot, liveExtent, span);
            if (source is not (PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)) return false;
            PublishValue(slot, liveExtent, PyIteration.Cursor.Create(source, span, _scope));
            return true;
        }

        internal bool TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)
        {
            if (!IsBorrowedPrefix && _storage.TryAdvanceNativeIteration(slot, out hasValue, out next)) return true;
            hasValue = false;
            next = default;
            if (Values[slot].Reference is PyStringOps.CasedWhitespaceIteration words)
            {
                var result = words.MoveNext();
                hasValue = result.HasValue;
                next = hasValue ? result.TakeSlotValue() : default;
                return true;
            }
            if (Values[slot].Reference is PyIteration.Cursor { CanPullWithoutGuestCode: true } cursor)
            {
                var result = cursor.TryMoveNext();
                hasValue = result.HasValue;
                next = hasValue ? result.TakeSlotValue() : default;
                return true;
            }
            return false;
        }

        internal void RetainPreparedChild(ExecutionContext child, MemoryGovernor owner)
        {
            _preparedChild = child;
            _preparedChildOwner = owner;
        }

        internal bool Run(LythonSourceSpan entrySpan, out ExecutableSlot result, Span<ExecutableSlot> unpackedReturn = default)
        {
            // The call boundary owns logical interpreter admission, and
            // StartInline owns function admission. Like an ordinary bound body,
            // validate this managed stack entry without charging nesting twice.
            ExecutionState.EnsureInterpreterStack(entrySpan);
            var previous = _scope.State.CurrentException;
            try
            {
                var pause = ExecutionContext.ExecuteInstructionPrefix(ref this, _scope, null, false, out _, out _, out _);
                var completed = pause == ExecutionContext.InstructionPause.Boundary;
                if (!completed && pause != ExecutionContext.InstructionPause.ContextRequired)
                    throw new InvalidOperationException("A borrowed prefix cannot suspend.");
                result = ReturnValue.IsUnassigned ? ExecutableSlot.FromObject(PyNone.Instance) : ReturnValue;
                if (completed && ReturnedUnpacked)
                {
                    Values.Slice(_unpackedTupleStart, _unpackedReturnCount).CopyTo(unpackedReturn);
                    Trim(Code.FirstTemporarySlot);
                    _scope.CheckExecution(Code.Instructions[Index + 1].Span);
                }
                return completed;
            }
            catch (LythonRuntimeException error)
            {
                if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous))
                    error.PythonContext ??= previous;
                if (Code.ExceptionRegions.Count == 0) throw;
                // First refusal and cancellation still fail the command. A
                // catchable guest fault transfers once, without replaying its
                // operation or building a second exception dispatcher here.
                _scope.CheckExecution(entrySpan);
                Failure = error;
                result = ExecutableSlot.FromObject(PyNone.Instance);
                return false;
            }
            finally
            {
                _scope.State.SetCurrentException(previous);
            }
        }

        internal bool TryReturnUnpackedTuple(in ExecutableInstruction instruction)
        {
            if (Code.NativePrefixEnd != Code.Instructions.Length || _unpackedReturnCount == 0 || instruction.ItemCount != _unpackedReturnCount
                || instruction.HasLocalResult || Index + 1 >= Code.Instructions.Length) return false;
            ref readonly var next = ref Code.Instructions[Index + 1];
            if (next.OpCode != ExecutableOpCode.Return || next.InputStart != instruction.ResultSlot) return false;
            var items = Values.Slice(instruction.InputStart, instruction.ItemCount);
            // Keep eager tuple admission before any caller target can change.
            // Its conservative funding survives until the execution owner ends;
            // only the unobservable tuple shell/backing allocation disappears.
            var bytes = SlotTupleBytes(items, _scope, instruction.Span);
            _scope.MemoryGovernor.Reserve(bytes, instruction.Span);
            try
            {
                _scope.CheckExecution(instruction.Span);
                _scope.MemoryGovernor.Commit(bytes);
            }
            catch { _scope.MemoryGovernor.ReleaseReserved(bytes); throw; }
            // The return wrapper copies these already-admitted operands before
            // native cleanup. The hot execution state retains no caller borrow.
            _unpackedTupleStart = instruction.InputStart;
            return true;
        }

        internal void PrepareTransfer()
        {
            // Final managed slots transfer directly; no borrowed side span remains.
            Values[LiveExtent..].Clear();
        }
        internal void TransferOwnership(ExecutionContext frame)
        {
            if (_preparedChild is { } child)
            {
                var call = Code.CallSites[Code.Instructions[Index].CallSiteIndex];
                frame.AdoptPreparedNativeChild(child, call, Code.Instructions[Index].InputStart, _preparedChildOwner!);
                _preparedChild = null;
                _preparedChildOwner = null;
            }
            _transferred = true;
        }
        internal void Dispose()
        {
            if (_transferred) return;
            try
            {
                if (_preparedChild is { } child)
                {
                    _preparedChild = null;
                    try { ExecutionContext.AbortPreparedNativeCall(child, _preparedChildOwner!); }
                    finally { _scope.LeaveInterpreterFrame(); }
                }
            }
            finally { DisposeValues(); }
        }

        private void DisposeValues() => RetireTo(Code.FirstTemporarySlot);
    }

    internal static ExecutionContext CreateNativeContinuation(PyExecutableFunction function,
        in BoundFunctionArguments bound, LythonSourceSpan span, int index, int liveExtent, bool consumedByIteration,
        LythonRuntimeException? failure)
    {
        var frame = function.EnterInvocationFrame(bound, span, enterFunctionCall: false);
        InitializeExecutableFrame(function.CodeObject, frame, bound, function.ClosureCells,
            argumentsAreLocals: true, lookupOwner: function, returnConsumedByIteration: consumedByIteration);
        frame.RestoreNativePosition(index, liveExtent, failure);
        return frame;
    }

    internal sealed partial class ExecutionContext
    {
        internal void RestoreNativePosition(int index, int liveExtent, LythonRuntimeException? failure)
        {
            _execution.InstructionIndex = index;
            _execution.Stack.RestoreNativeExtent(liveExtent);
            _injectedException = failure;
        }
    }
}
