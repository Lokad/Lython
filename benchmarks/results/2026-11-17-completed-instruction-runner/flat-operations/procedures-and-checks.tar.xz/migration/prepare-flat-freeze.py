from pathlib import Path
import ast

notes=Path(__file__).parent
out=notes/'flat-operations'
source=(notes/'lean/freeze.py').read_text(encoding='utf-8')
source=source.replace('PrivateR495 lean PC/live/return refs and flat common transfers on22d5a5f3; no persistent borrowed-prefix work record; no promotion',
    'PrivateR495 flat closed arithmetic/sequence/comparison operation selection and bool comparison results on22d5a5f3; lean scalar control refs; no promotion')
ast.parse(source)
(out/'freeze.py').write_text(source,encoding='utf-8',newline='\n')
source=(notes/'lean/capture-codegen.py').read_text(encoding='utf-8')
source=source.replace("'*StartInline* *ExecuteInstructionPrefix* *TryExecuteNativeCall* *ForBorrowedPrefix* *NativeExecution:Run*'",
                      "'*StartInline* *ExecuteInstructionPrefix* *TryExecuteNativeCall* *NativeExecution:Run* *TryEvaluateIntegerInstruction* *TryEvaluateBuiltinArithmetic*'")
ast.parse(source)
(out/'capture-codegen.py').write_text(source,encoding='utf-8',newline='\n')
print('Existing frozen-image/golden/allocation and codegen procedure prepared for flat operations; no additional collection started.')
