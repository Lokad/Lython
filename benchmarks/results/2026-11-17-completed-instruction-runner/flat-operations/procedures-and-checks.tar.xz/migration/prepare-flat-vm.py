from pathlib import Path
import ast

notes=Path(__file__).parent
out=notes/'flat-operations'
source=(notes/'lean/prepare-quiet.py').read_text(encoding='utf-8')
a=source.index('subjects=[]');b=source.index('assert not set',a)
source=source[:a]+'''subjects=[]
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/lean/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-completed-instruction-runner/lean/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else archive.extractfile(member).read()
  subjects.append(dict(kind='completed-replica',path='completed-runner-lean-b917-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
''' +source[b:]
source=source.replace("donor['root']='/home/lokad/lython-bench-checks/completed-runner-b915-20261117'",
                      "donor['root']='/home/lokad/lython-bench-checks/completed-runner-lean-b917-20261117'")
source=source.replace(".replace('json-cpython-b908-20261117','completed-runner-b915-20261117')",
                      ".replace('json-cpython-b908-20261117','completed-runner-lean-b917-20261117')")
source=source.replace("remote='/home/lokad/lython-bench-checks/completed-runner-lean-b917-20261117'",
                      "remote='/home/lokad/lython-bench-checks/completed-operations-b918-20261117'")
source=source.replace('lython-b917-completed-runner-lean-20261117','lython-b918-completed-operations-20261117')
source=source.replace('lython-b917-fixtures','lython-b918-fixtures').replace("'B917'","'B918'")
source=source.replace('Fully qualified33bd7efd/5e7058a3 versus lean privateR495 on22d5a5f3; scalar PC/live/return refs, flat common transfer/control, no owned prefix work record',
                      'Fully qualified33bd7efd/5e7058a3 versus flat-operation privateR495 on22d5a5f3; closed arithmetic/sequence/comparison selectors removed, bool results, lean control refs')
source=source.replace('One completed-instruction runner with direct scalar control refs and flat common transfers; persistent borrowed-prefix work record and displaced span overloads removed. Existing binding, ownership, native returns, cased iteration and async cleanup.',
                      'One completed-instruction runner with existing closed arithmetic/index/comparison kernels selected directly; three selector frames and completed bool ValueTask transport removed. Same protocols, error/retirement order, native returns, cancellation and ownership.')
ast.parse(source)
(out/'prepare-quiet.py').write_text(source,encoding='utf-8',newline='\n')
print('Existing five-job source/control pair prepared for flat operations; no new benchmark framework or repeated source collection.')
