from pathlib import Path
import hashlib,json,subprocess

notes=Path(__file__).parent
repo=Path('D:/code/utf8regex')
head='4fdb981e8d62ae49b3393cd5861189adc556cdc8'
paths=['src/Lokad.Utf8Regex.PythonRe/Utf8PythonRegex.Metadata.cs',
       'src/Lokad.Utf8Regex.PythonRe/Utf8PythonRegex.Cursor.cs',
       'src/Lokad.Utf8Regex.PythonRe/Utf8PythonMatchCursor.cs']
rows=[]
for name in paths:
    blob=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
    old=subprocess.check_output(['git','show','a370f693:'+name],cwd=repo)
    rows.append(dict(path=name,committedSHA256=hashlib.sha256(blob).hexdigest(),unchangedSincePreviousFactCheck=blob==old))
adapter=Path('D:/code/Lython/src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs').read_text(encoding='utf-8')
removed=['Utf8PythonMatchData','Utf8PythonSubnResult','Utf8PythonMatchEvaluator','Utf8PythonUtf8MatchEvaluator']
assert not any(name in adapter for name in removed)
data=dict(head=head,readOnlyCommittedBlobs=True,producerWorktreeNotReadOrModified=True,files=rows,
    changes='PythonRe legacy structural FindAll, owned UTF16 projection and replacement callback APIs removed; current adapter uses cursors and Lython-owned replacement semantics.',
    missingCapabilities=['UTF8 group-name enumeration; UTF8 name lookup/pattern copying do not replace enumeration.',
        'Creation/preparation token independent of later retained cursor pulls; MoveNext still links original/current tokens.',
        'Separately selected per-match result/staging allowance; explicit cursor overload selects working allowance only.'],
    removedTypesUnusedByCurrentAdapter=removed,normalAdapterPin='0.4.0',development105QualificationReused=True,
    newQualification=False,packageReleaseStatusNotInferred=True,coreRuntimeWorkIndependent=True)
(notes/'producer-source-check.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
target=Path('D:/code/Lython/benchmarks/results/2026-11-17-completed-instruction-runner/attribution/producer-source-check.json')
target.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Committed producer4fdb981e read-only refresh: the three exact capability files are',
      'unchanged'if all(row['unchangedSincePreviousFactCheck']for row in rows)else'changed',
      '; final-capability gaps persist, no pin/source/package qualification change.')
