from pathlib import Path
import hashlib,json

notes=Path(__file__).parent
root=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
runtime=root/'src/Lokad.Lython/Runtime'
identity=json.loads((notes/'lean/frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in identity['sourceInputs'].items())

p=runtime/'LythonRuntime.Executable.Interpreter.Dispatch.cs';text=p.read_text(encoding='utf-8')
a=text.index('                        case ExecutableOpCode.CompareJumpIfFalse:')
b=text.index('                        case ExecutableOpCode.StoreSubscript:',a)
text=text[:a]+'''                        case ExecutableOpCode.CompareJumpIfFalse:
                        {
                            if (IsScalarComparison(instruction.BinaryOperator)
                                && TryReadMachineOperand(execution.Code, execution.Values, instruction.InputStart, out var left)
                                && TryReadMachineOperand(execution.Code, execution.Values, instruction.SecondInput, out var right))
                            {
                                scope.CheckExecution(instruction.Span);
                                jumped = CompleteComparisonBranch(ref execution, scope, instruction,
                                    CompareOrderedResult(instruction.BinaryOperator, left.CompareTo(right)));
                                break;
                            }
                            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);
                            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);
                            try
                            {
                                if (TryEvaluateScalarComparison(instruction.BinaryOperator, first, second, scope,
                                    instruction.Span, out var truth))
                                {
                                    jumped = CompleteComparisonBranch(ref execution, scope, instruction, truth);
                                    break;
                                }
                                if (invocation is null) return InstructionPause.ContextRequired;
                                if (!asynchronous)
                                {
                                    var compared = EvaluateBinaryOperator(instruction.BinaryOperator, first, second, invocation, instruction.Span);
                                    execution.RetireTo(instruction.LiveExtent);
                                    invocation.CheckExecution(instruction.Span);
                                    jumped = CompleteComparisonBranch(ref execution, invocation, instruction,
                                        IsTruthy(compared, invocation, instruction.Span));
                                    break;
                                }
                                pending = invocation.ExecuteComparisonBranchAsync(instruction, first, second);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                            }
                            catch { execution.RetireTo(instruction.LiveExtent); throw; }
                            // Async completion owns its own retirement/error path.
                            // Consume outside the selector catch as before.
                            jumped = ConsumeOperation(ref pending);
                            break;
                        }
                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary:
                        {
                            if (execution.CanRetireWithoutCleanup(instruction.ResultSlot))
                            {
                                try
                                {
                                    var end = execution.InstructionIndex;
                                    ExecutableSlot value = default;
                                    var completed = instruction.OpCode != ExecutableOpCode.Unary &&
                                        TryEvaluateIntegerInstruction(execution.Code, execution.Values, end, scope, out end, out value);
                                    if (completed || TryEvaluateBuiltinArithmetic(execution.Code, execution.Values, end, scope, out value))
                                    {
                                        execution.InstructionIndex = end;
                                        PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[end], value);
                                        break;
                                    }
                                }
                                catch { execution.RetireTo(instruction.ResultSlot); throw; }
                            }
                            goto case ExecutableOpCode.StoreSubscript;
                        }
                        case ExecutableOpCode.Subscript:
                        {
                            if (invocation?._preparedCallValue is null)
                            {
                                var receiver = ReadOperand(ref execution, instruction.InputStart, scope, 0);
                                if (TryReadMachineOperand(execution.Code, execution.Values, instruction.SecondInput, out var index))
                                {
                                    try
                                    {
                                        if (PyIndexing.TryReadSequenceIndex(receiver, index, instruction.Span, scope, out var value))
                                        {
                                            PublishInstructionResult(ref execution, invocation, instruction, value);
                                            break;
                                        }
                                    }
                                    catch { execution.RetireTo(instruction.ResultSlot); throw; }
                                }
                            }
                            goto case ExecutableOpCode.StoreSubscript;
                        }
''' +text[b:]
p.write_text(text,encoding='utf-8',newline='\n')

p=runtime/'LythonRuntime.Executable.Arithmetic.cs';text=p.read_text(encoding='utf-8')
a=text.index('    internal sealed partial class ExecutionContext')
p.write_text(text[:a].rstrip()+'\n}\n',encoding='utf-8',newline='\n')
p=runtime/'LythonRuntime.Executable.Inputs.cs';text=p.read_text(encoding='utf-8')
a=text.index('        private static bool TryExecuteSequenceIndex(')
b=text.index('        // Genuine async work',a)
p.write_text(text[:a]+text[b:],encoding='utf-8',newline='\n')
p=runtime/'LythonRuntime.Executable.Comparisons.cs';text=p.read_text(encoding='utf-8')
a=text.index('        private static InstructionPause ExecuteComparisonInstruction(')
b=text.index('        private static bool CompleteComparisonBranch(',a)
p.write_text(text[:a]+text[b:],encoding='utf-8',newline='\n')
print('Closed arithmetic/sequence/comparison selector frames removed; plain branches retain bools and pending protocols retain async helpers.')
