from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.with_name('terminal-backed-operand-layout-20261124')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
save=lambda path,value:path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=read(base/'comparison/quiet/identity.json')
changed=['src/Lokad.Lython/Frontend/'+name for name in
        ('Parser.Helpers.cs','Parser.Patterns.cs','Parser.Statements.cs','Parser.TypeParameters.cs')]
patch=subprocess.check_output(['git','diff','--binary','132d066c1','--',*changed],cwd=repo)
assert b'if (first is null || CurrentToken != Token.Pipe) return first;' in patch
(lab/'candidate.patch').write_bytes(patch)
with zipfile.ZipFile(base/'frozen-source.zip') as archive:
    for name in archive.namelist():
        if name.endswith('/'):continue
        expected=(repo/name).read_bytes() if name in changed else archive.read(name)
        assert (lab/'frozen-candidate'/name).read_bytes()==expected, name
reference=identity['imageFiles']['reference']
candidate=lab/'candidate-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
assert {p.name:sha(p) for p in (base/'reference').iterdir()}==reference
images={'reference':reference,'candidate':reference | {candidate.name:sha(candidate)}}
identity['imageFiles']=images
identity['coreSHA256']={role:files[candidate.name] for role,files in images.items()}
identity['sourcePatchSHA256']=sha(lab/'candidate.patch')
identity['purpose']='Share normalized parser spellings and allocate only the pattern nodes used'
identity['catalogs'].pop('jobs.json')
save(quiet/'identity.json',identity)
for role,files in images.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(candidate if (role=='candidate' and name==candidate.name) else base/'reference'/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==files
shutil.copyfile(base/'comparison/quiet/representative.json',quiet/'representative.json')
assert sha(quiet/'representative.json')==identity['catalogs']['representative.json']['sha256']
for name in ('compile-allocation.py','check-tape.py','verify-boundaries.py'):
    shutil.copyfile(base/name,lab/name)
(lab/'tape').mkdir(exist_ok=True)
for name in ('Program.cs','Tape.csproj'):
    shutil.copyfile(base/'tape'/name,lab/'tape'/name)

worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
python=Path('C:/Python313/python.exe')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
catalog=read(quiet/'representative.json')
source='''class K:
    def __choose(self, value):
        match value:
            case {'v': ([0, __K, z] | [1, z, __K]), 'p': [head, *__rest], **__meta} as __whole:
                return __K, z, head, __rest, __meta, len(__whole)
print(K()._K__choose({'v': [1, 2, 3], 'p': [5, 6], 'meta': 7}))
print(K._K__choose.__name__)
'''
fixture='{"size":1,"text":null}'
golden=subprocess.run([python,'-I','-S','-X','utf8','-'],input=source,encoding='utf-8',capture_output=True,check=True,timeout=15)
assert not golden.stderr and golden.stdout.startswith("(3, 2, 5, [6], {'meta': 7}, 3)")
digest=lambda value:hashlib.sha256(value.encode('utf-8')).hexdigest()
catalog['cases'].append(dict(id='diagnostic.normalized-pattern-bindings',family='scripts',category='whole-script',scale='small',size=1,
    source=source,fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode('utf-8')),
    expectedOutputUtf8Bytes=len(golden.stdout.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout)))
casefile=lab/'semantic-catalog.json'
save(casefile,catalog)
for role in images:
    output=lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',casefile,
        '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',output],env=env,cwd=repo,check=True,timeout=60)
    result=read(output)
    assert result['state']=='Completed' and result['caseCount']==4
    assert result['catalogSha256']==sha(casefile) and result['launched']['library']['sha256']==images[role][candidate.name]
