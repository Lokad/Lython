from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
out=lab.parents[3]/'benchmarks/results/2026-11-24-shared-binding-spelling'
out.mkdir(parents=True,exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
for role, files in identity['imageFiles'].items():
    assert {path.name:sha(path) for path in (lab/role).iterdir()}==files
    for file in (f'tape-{role}.json',f'{role}-compiler-owner.json'):
        result=read(lab/file)
        assert result['coreSHA256']==files['Lokad.Lython.dll']
    receipt=read(lab/'comparison'/f'{role}-verify.json')
    assert receipt['caseCount']==4 and receipt['state']=='Completed'
    assert receipt['catalogSha256']==sha(lab/'semantic-catalog.json')
assert read(lab/'tape-candidate.json')['rows']==read(lab/'tape-reference.json')['rows']
shutil.copyfile(lab/'compile-allocation-summary.json',out/'compile-allocation-summary.json')
shutil.copyfile(quiet/'identity.json',out/'identity.json')
logs=[f'{system}-{lane}.log' for system in ('windows','ubuntu') for lane in ('public','net10')]
assert all('Passed!' in (lab/log).read_text(encoding='utf-8-sig') for log in logs)
files=['archive.py','prepare.py','candidate.patch','prepare.log','candidate-build.log','tape.log','compile-allocation.log',
       'check-tape.py','compile-allocation.py','tape/Program.cs','tape/Tape.csproj','semantic-catalog.json','tape-catalog.json',
       'tape-reference.json','tape-candidate.json','comparison/reference-verify.json','comparison/candidate-verify.json',
       'reference-compiler-owner.json','candidate-compiler-owner.json','comparison/quiet/representative.json']+logs
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in files:
        bundle.add(lab/name,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==sha(lab/name) for name in files)
