from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
probe=lab/'probe/bin/Release/net11.0'
image = lab/'parity/final'
image.mkdir()
for name in ('CompilerFacts.dll','CompilerFacts.runtimeconfig.json','CompilerFacts.deps.json'):
    shutil.copyfile(probe/name,image/name)
core='Lokad.Lython.dll'
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0'/core,image/core)
limits=lab/'parity/limits.json'
subprocess.run([Path.home()/'.dotnet11/dotnet.exe', image/'CompilerFacts.dll',
                lab/'local/representative.json', image/'facts.json', limits],check=True,timeout=60)
for name in ('facts.json','cancellation.json'):
    assert (image/name).read_bytes() == (lab/'parity/candidate'/name).read_bytes()
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
(image/'source.patch').write_bytes(patch)
(image/'proof.json').write_text(json.dumps({
    'sourcePatchSHA256': sha256(patch).hexdigest(),
    'librarySHA256': sha256((image/core).read_bytes()).hexdigest(),
    'sameTapeAndBudgetFactsAsMeasuredCandidate': True,
    'sameCancellationResultAsMeasuredCandidate': True,
},indent=2)+'\n',encoding='utf-8',newline='\n')
