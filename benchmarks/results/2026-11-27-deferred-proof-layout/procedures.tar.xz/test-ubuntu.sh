set -eu
source_root=/mnt/d/code/Lython
target_root=/home/vermorel/lython-starmap-rows-8066Vm
test -d "$target_root/src/Lokad.Lython"
for file in src/Lokad.Lython/Frontend/ExecutableScript.cs src/Lokad.Lython/Frontend/ExecutableScript.DeferredDefinitions.cs src/Lokad.Lython/Frontend/ExecutableStackLayout.cs; do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
filter='Category!=Stress&(FullyQualifiedName~DeferredDefinition|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Executable)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    "$HOME/.dotnet/dotnet" test "tests/$suite/$suite.csproj" -c Release -f net10.0 --no-restore --filter "$filter"
done
