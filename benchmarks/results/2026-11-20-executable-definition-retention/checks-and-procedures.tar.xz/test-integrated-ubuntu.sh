set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$PWD/.git/agent-notes/review-20261031/executable-definition-retention
filter='(FullyQualifiedName~RegexProviderContractTests|FullyQualifiedName~PyStringPrimitiveTests|FullyQualifiedName~LoweringArchitectureSubsystemTests|FullyQualifiedName~Executable|FullyQualifiedName~Generic|FullyQualifiedName~TypeParameter|FullyQualifiedName~CompilerCancellationTests|FullyQualifiedName~FunctionDefault|FullyQualifiedName~FunctionAttribute|FullyQualifiedName~FunctionDefinition|FullyQualifiedName~Annotation|FullyQualifiedName~GeneratorDefinition|FullyQualifiedName~DeferredFunctionContext|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~AsyncMidFlightCancellation)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-integrated-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/integrated-linux" --filter "$filter" >"$log" 2>&1 || { tail -n 55 "$log"; exit 1; }
    tail -n 8 "$log"
done
