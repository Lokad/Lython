import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor = lab.parent / "lexical-binding-order-r563"
work = repo / ".git/agent-worktrees/direct-function-defaults-r575"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
python = Path("C:/Python313/python.exe")
python_worker = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(command, logfile):
    with logfile.open("w", encoding="utf-8") as output:
        subprocess.run(command, check=True, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=45)

catalog = lab / "catalog.json"
target_id = "scripts.rule-default-closures"
control_id = "calls.positional.large"
core_name = "Lokad.Lython.dll"
worker_name = "Lokad.Lython.Benchmarks.dll"

if sys.argv[1] == "prepare":
    parent=lab.parent/"borrowed-format-packet-r574"
    catalog_data=load(parent/"method-format-catalog.json")
    full=load(lab.parent/"utf8-keyword-packet-r572/full-catalog.json")
    defaults_case=next(row for row in full["cases"] if row["id"]=="calls.defaults.medium")
    base=next(row for row in full["cases"] if row["id"]=="calls.keyword.medium")
    generated="""def make_rules(index):
    def apply(base, offset=index % 7, /, *, weight=index % 5 + 1, enabled=index % 3 != 0):
        return (base + offset) * weight if enabled else base
    fallback = lambda base, offset=(index + 1) % 7, /, *, scale=2: (base - offset) * scale
    return apply, fallback

total = 0
for index in range(2048):
    apply, fallback = make_rules(index)
    total += apply(index) + fallback(index)
print(total)
"""
    expected=sum(((i+i%7)*(i%5+1) if i%3 else i)+(i-(i+1)%7)*2 for i in range(2048))
    output=f"{expected}\n"
    case=base | dict(id=target_id, family="scripts", category="whole-script", source=generated,
                     sourceUtf8Bytes=len(generated.encode()), sourceSha256=digest(generated.encode()),
                     expectedOutput=output, expectedOutputUtf8Bytes=len(output.encode()),
                     expectedOutputSha256=digest(output.encode()))
    keep={control_id, "strings.method-format-report.medium", "scripts.report-forwarding.expanded"}
    catalog_data["cases"]=[case,defaults_case]+[row for row in catalog_data["cases"] if row["id"] in keep]
    assert len(catalog_data["cases"])==5
    save(catalog,catalog_data)

    manifest = load(donor / "frozen-identity.json")["imageFiles"]["candidate"]
    base = donor / "frozen/candidate"
    assert len(manifest) == 32
    assert all(digest((base / name).read_bytes()) == value for name, value in manifest.items())
    identities = {}
    for role, src in [("reference", repo), ("candidate", work)]:
        replacement = (lab.parent / "borrowed-format-packet-r574/frozen/candidate" / core_name
                       if role == "reference" else src / "src/Lokad.Lython/bin/Release/net11.0" / core_name)
        frozen = lab / "frozen" / role
        frozen.mkdir(parents=True)
        for name in manifest:
            shutil.copyfile(replacement if name == core_name else base / name, frozen / name)
        for path in base.glob("ValidatedAllocation.*"):
            shutil.copyfile(path, frozen / path.name)
        identities[role] = {name: digest((frozen / name).read_bytes()) for name in manifest}
        assert identities[role] == manifest | {core_name: digest(replacement.read_bytes())}
    save(lab / "frozen-identity.json", dict(referenceCommit="0cf1156c8", candidateBase="0cf1156c8",
                                             casesSHA256=digest(catalog.read_bytes()), images=identities))

identities = load(lab / "frozen-identity.json")["images"]
for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
reference = lab / "frozen/reference"
candidate = lab / "frozen/candidate"
if sys.argv[1] == "prepare":
    for role, image in [("reference", reference), ("candidate", candidate)]:
        run([dotnet, image / worker_name, "--compare", "verify", "--catalog", catalog, "--dotnet", dotnet,
             "--python", python, "--python-worker", python_worker, "--out", lab / f"{role}-verify.json"],
            lab / f"{role}-verify.log")
        run([dotnet, image / "ValidatedAllocation.dll", image, catalog, lab / f"{role}-allocation.json"],
            lab / f"{role}-allocation.log")
else:
    pairs=[(target_id,"warm"),("calls.defaults.medium","warm"),(control_id,"warm"),
           (target_id,"compile-run"),(target_id,"compile")]
    for index, (case, lane) in enumerate(pairs):
        old, new = (reference, candidate) if index % 2 == 0 else (candidate, reference)
        tag = f"micro-{index}-{lane}"
        try:
            run([dotnet, new / worker_name, "--compare", "micro", "--catalog", catalog, "--dotnet", dotnet,
                 "--baseline-worker", old / worker_name, "--python", python,
                 "--python-worker", python_worker, "--out", lab / f"{tag}.json", "--case", case, "--lane", lane],
                lab / f"{tag}.log")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as failure:
            print(tag, "failed", repr(failure), flush=True)
        else:
            print(tag, load(lab / f"{tag}.json")["summaries"], flush=True)

for role, files in identities.items():
    assert all(digest((lab / "frozen" / role / name).read_bytes()) == value for name, value in files.items())
