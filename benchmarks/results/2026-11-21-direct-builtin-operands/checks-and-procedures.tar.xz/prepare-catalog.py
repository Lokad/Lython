from pathlib import Path
import hashlib,json,subprocess
lab=Path(__file__).resolve().parent
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
base=load(lab.parent/'expanded-builtin-span/representative.json')
other=load(lab.parent/'observed-regex-coordinates/representative.json')
short=next(c for c in base['cases'] if 'explicit-options' in c['id'])
old='separators=options["separators"])'
source=short['source'].replace(old,'separators=options["separators"], check_circular=True, allow_nan=True, skipkeys=False)')
assert source!=short['source']
sha=lambda data:hashlib.sha256(data).hexdigest()
def variant(case,id,source,expected):
    return dict(case,id=id,source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=sha(source.encode()),
        expectedOutput=expected,expectedOutputUtf8Bytes=len(expected.encode()),expectedOutputSha256=sha(expected.encode()))
wide=variant(short,'scripts.json-lines-shipment.explicit-wide-options.large',source,short['expectedOutput'])
math_source="""import math
accepted = 0
for row in range(4096):
    expected = (row % 37) * 0.5
    actual = expected + (row % 5) * 0.001
    if math.isclose(actual, expected, rel_tol=0.0002, abs_tol=0.0005):
        accepted += 1
print(accepted)
"""
golden=subprocess.check_output(['C:/Python313/python.exe','-X','utf8','-I','-c',math_source]).decode('utf-8').replace('\r\n','\n')
distance=variant(other['cases'][0],'scripts.measurement-tolerance.explicit-options',math_source,golden)
base['cases']=[wide,distance]+base['cases']
(lab/'representative.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(*(c['id'] for c in base['cases']),sep='\n')
