from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
refined=lab/'refined'
quiet=refined/'quiet'
out=Path('benchmarks/results/2026-11-21-direct-builtin-operands')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identities=[load(d/'identity.json') for d in (lab,refined)]
for d,identity in zip((lab,refined),identities,strict=True):
    for role,files in identity['imageFiles'].items():
        assert len(files)==32 and {name:sha(d/'frozen'/role/name) for name in files}==files
        assert load(d/f'{role}-verify.json')['state']=='Completed'
    assert identity['catalogSHA256']==sha(d/'representative.json')
    assert len(load(d/'allocation-summary.json'))==5 and all(x['budgetReturnedToBaseline'] for x in load(d/'allocation-summary.json'))
    for platform in ('windows','ubuntu'):
        assert 'Passed:   840' in (d/f'white-{platform}.log').read_text(encoding='utf-8-sig')
        assert 'Passed:  1368' in (d/f'public-{platform}.log').read_text(encoding='utf-8-sig')
    (d/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','798091df6',identity['candidate'],'--','src','tests']))
assert identities[0]['reference']==identities[1]['reference']
assert identities[0]['imageFiles']['reference']==identities[1]['imageFiles']['reference']
local=load(lab/'local-timing.json')
assert local['identity']==identities[0] and len(local['rows'])==5 and all(
    all(len(observations)==5 for observations in row['samples'].values()) for row in local['rows'])
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease','quietBeforeAndAfter'))
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
identity=load(quiet/'identity.json')
assert identity['imageFiles']==identities[1]['imageFiles'] and identity['catalogSHA256']==identities[1]['catalogSHA256']
raw=load(quiet/'retrieved/confirmation/confirmation.json')
cases={c['id']:c for c in load(lab/'representative.json')['cases']}
assert raw['complete'] and len(raw['jobs'])==receipt['jobs']==len(cases)==5
assert {job['case'] for job in raw['jobs']}==set(cases)
for job in raw['jobs']:
    case=cases[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and job['lane']=='warm' and len(job['samples'])==28
    for sample in job['samples']:
        response=sample['response']
        assert response['completedInvocations']>0 and response['status']=='Completed'
        assert response['sourceSha256']==case['sourceSha256'] and response['fixtureSha256']==case['fixtureSha256']
        assert response['actualOutputSha256']==case['expectedOutputSha256'] and response.get('actualFilesSha256')==case.get('expectedFilesSha256')
summary=load(quiet/'quiet-summary.json')
summary.update(collection='B1276', reference=identities[1]['reference'], referenceImageSource=identities[1]['referenceImageSource'],
               candidate=identities[1]['candidate'], verifiedTimedBatches=140, coreSHA256=identity['coreSHA256'],
               archiveSHA256=receipt['archiveSHA256'])
out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(refined/'allocation-summary.json',out/'allocation-summary.json')
shutil.copyfile(lab/'allocation-summary.json',out/'initial-allocation-summary.json')
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
for role in ('reference','candidate'):
    core=refined/'frozen'/role/'Lokad.Lython.dll'
    target=out/(role+'-core.dll.gz')
    assert sha(core)==identity['imageFiles'][role]['Lokad.Lython.dll']
    target.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert gzip.decompress(target.read_bytes())==core.read_bytes()
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as tar:
    for d in (lab,refined,quiet):
        for file in sorted(d.iterdir()):
            if file.is_file() and file.suffix not in {'.tgz','.stderr'}:
                tar.add(file,arcname=file.relative_to(lab).as_posix())
print('140 warm batches, every captured output digest and full-image identity verified.')
