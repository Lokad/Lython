set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-builtin-operands/refined
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Json|FullyQualifiedName~MemoryAdmission)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~ExpandedCall|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~CallBinderAccounting|FullyQualifiedName~BuiltinCallbackLifetime|FullyQualifiedName~CallableInstanceProtocol|FullyQualifiedName~Regex)&Category!=Stress' | tee "$logs/public-ubuntu.log"
