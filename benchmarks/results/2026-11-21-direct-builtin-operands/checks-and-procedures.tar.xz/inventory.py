from pathlib import Path
import json,shlex,subprocess
lab=Path(__file__).resolve().parent
prog=r'''
from pathlib import Path
import os,hashlib,json,shutil,stat
b=Path('/home/lokad/lython-bench-checks')
roles = [
 'observed-regex-coordinates-b1275-20261121/candidate/Lokad.Lython.dll',
 'sparse-abstract-invalidation-b1270-20261121/candidate/Lokad.Lython.dll',
 'skip-inert-lexical-expressions-b1263-20261121/candidate/Lokad.Lython.dll',
]
groups={}
for rel in roles:
 p=b/rel
 if not p.is_file(): continue
 m=p.lstat()
 groups[(m.st_dev,m.st_ino)]=dict(root=rel,size=m.st_size,links=m.st_nlink,paths=[],
     sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for root,dirs,files in os.walk(b):
 for name in files:
  path=Path(root)/name
  m=path.lstat()
  row=groups.get((m.st_dev,m.st_ino))
  if row is not None: row['paths'].append(str(path.relative_to(b)))
print(json.dumps(dict(free=shutil.disk_usage(b).free,groups=list(groups.values()))))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
raw=subprocess.check_output(ssh+['python3 -c '+shlex.quote(prog)],timeout=35)
(lab/'remote-reclaim-inventory.json').write_bytes(raw)
print(raw.decode())
