from pathlib import Path
import gzip,hashlib,json,subprocess
lab=Path(__file__).resolve().parent
inventory=json.loads((lab/'remote-reclaim-inventory.json').read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
def tracked(path):return subprocess.check_output(['git','show','HEAD:'+path])
bench='benchmarks/results/'
sources = [
 ('observed-regex-coordinates-b1275-20261121', '2026-11-21-observed-regex-coordinates/candidate-core.dll.gz'),
 ('sparse-abstract-invalidation-b1270-20261121', '2026-11-21-sparse-abstract-invalidation/candidate-core.dll.gz'),
 ('skip-inert-lexical-expressions-b1263-20261121', '2026-11-21-lexical-expression-traversals/measured-candidate-core.dll.gz')]
archive_paths = {
    sources[0][0]:'2026-11-21-observed-regex-coordinates', sources[1][0]:'2026-11-21-sparse-abstract-invalidation',
    sources[2][0]:'2026-11-21-lexical-expression-traversals',
    'pinned-unicode-fold-b1273-20261121':'2026-11-21-pinned-unicode-casing/fold',
    'compiler-checkpoint-cpython-b1271-20261121':'2026-11-21-cpython-compiler-checkpoint',
    'pinned-unicode-casing-b1272-20261121':'2026-11-21-pinned-unicode-casing',
    'skip-inert-lexical-expressions-b1264-20261121':'2026-11-21-lexical-expression-traversals/confirmation'}
def archive_for(path):
    root=path.split('/',1)[0]
    folder=bench+archive_paths[root]
    receipt=json.loads(tracked(folder+'/archive-receipt.json'))
    assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    digest=sha(tracked(folder+'/observations.tgz'))
    assert digest==receipt['archiveSHA256']
    return root+'/observations.tgz',digest
groups=[]
for root,artifact in sources:
    row,= (g for g in inventory['groups'] if g['root'].split('/',1)[0]==root)
    core=gzip.decompress(tracked(bench+artifact))
    assert len(core)==row['size'] and sha(core)==row['sha256'] and len(row['paths'])==row['links']
    groups.append(dict(paths=row['paths'],links=row['links'],bytes=len(core),sha256=sha(core),
                       archives=dict(archive_for(p) for p in row['paths']),verifiedCanonicalGitImage=bench+artifact))
(lab/'refined/reclaim-proof.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8')
print(sum(g['bytes'] for g in groups))
