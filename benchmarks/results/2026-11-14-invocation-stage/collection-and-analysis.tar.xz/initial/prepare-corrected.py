from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r/'b754';out.mkdir();assert json.loads((r/'retirement-receipt.json').read_text(encoding='utf-8'))['floorsUnchanged']
for name in ['identity.json','ops-profile.py','collect.py','retrieve.py','run.sh','prospective.json','launch.py','catalog.json']:
    s=(r/name).read_text(encoding='utf-8').replace('invocation-stage-b753-20261114','invocation-stage-b754-20261114').replace('lython-b753-invocation-stage-20261114','lython-b754-invocation-stage-20261114').replace('B753','B754')
    if name=='launch.py':s=s.replace("r.parent/'native-call-transport-r365", "r.parent.parent/'native-call-transport-r365")
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'));identity['stagingCorrection']='InitialB753 space preflight refused before root/worker/unit creation. Exact committed withdrawn3b/fb DLLaliases retired under fresh idle lease after allpath/UID/inode/link/fullhash verification. Currentff2/73a/catalog/toolchain/floors preserved. Same workloads/profile/settings, no timed restart.';(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for n in ['identity.json','ops-profile.py','collect.py','run.sh','prospective.json','catalog.json']:t.add(out/n,arcname=n)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
c=json.loads((r/'config.json').read_text(encoding='utf-8'));c.update(root=c['root'].replace('b753','b754'),unit=c['unit'].replace('b753','b754'),identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
s=(r/'launch-command.py').read_text(encoding='utf-8');a=s.index('config=');b=s.index('\nbase=',a);s=s[:a]+'config='+repr(c)+s[b:];s=s.replace('lython-b753-fixtures','lython-b754-fixtures').replace('noNewCoreOrCatalogUpload=True','noNewCoreUpload=True,uploadedCatalog=True');ast.parse(s);(out/'launch-command.py').write_text(s,encoding='utf-8',newline='\n');(out/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n');print('New owned collection prepared after authoritative no-root/no-worker preflight; original condition retained.',flush=True)
