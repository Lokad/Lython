from pathlib import Path
import json,subprocess
r=Path(__file__).parent;c=json.loads((r/'config.json').read_text(encoding='utf-8'));print(dict(payloadBytes=c['payloadBytes'],unpackedBytes=c['unpackedBytes']),flush=True)
code=r'''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(disk=shutil.disk_usage(base)._asdict(),rootExists=(base/'invocation-stage-b753-20261114').exists(),active=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout,mounts=[str(p)for p in base.glob('*/guest-fixtures')if p.is_mount()],unit=subprocess.check_output(['systemctl','show','lython-b753-invocation-stage-20261114.service','--property=LoadState,MainPID'],text=True))))
'''
done=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert done.returncode==0,done.stderr;(r/'space-observation.json').write_text(done.stdout,encoding='utf-8');print(done.stdout,flush=True)
