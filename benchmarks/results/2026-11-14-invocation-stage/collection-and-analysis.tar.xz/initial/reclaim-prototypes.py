from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();proof=[]
for name,member,folder,expected in [('benchmarks/results/2026-11-14-helper-activation-entry/sources-checks-and-observations.tar.xz','candidate-core.dll','helper-entry-b750-20261114','3b7487ccb670b4015cef9db6878b1868388b8d5f5a23f657edcc0686147dac76'),('benchmarks/results/2026-11-14-native-integer-workspace/completion/refinement-and-restoration.tar.xz','refined/candidate-core.dll','native-word-cleanup-b752-20261114','fb3185fba0bec6e39587ec38737673fd2c9e5315427eab2db2aefd4fbb6967b8')]:
    blob=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(blob).digest()==hashlib.sha256(Path(name).read_bytes()).digest()
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile(member).read()
    assert hashlib.sha256(body).hexdigest()==expected
    proof.append(dict(commit=head,canonicalArchive=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,bytes=len(body),sha256=expected,paths=[folder+'/candidate-core.dll',folder+'/candidate/Lokad.Lython.dll']))
(r/'retirement-proofs.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 groups=[]
 for item in proof:
  paths=[base/name for name in item['paths']];metadata=[p.lstat()for p in paths]
  assert all(p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==2 and s.st_size==item['bytes']for p,s in zip(paths,metadata))
  assert len({s.st_ino for s in metadata})==1
  assert all(hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']for p in paths)
  groups.append(paths)
 before=shutil.disk_usage(base).free;assert before+sum(p['bytes']for p in proof)>254*1024*1024+8*1024*1024+100000
 for paths in groups:
  for p in paths:p.unlink()
 d=dict(proofs=proof,freshIdleLease=True,allPathsUidsHashesLinksVerifiedBeforeMutation=True,retiredOnly=[str(p)for paths in groups for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,currentff2And73aImagesAllCatalogsAuxiliariesToolchainsPreserved=True,floorsUnchanged=True,initialB753NoRootNoWorker=True)
 (base/'b754-proved-withdrawn-prototype-retirement.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''.replace('PROOF',repr(proof))
done=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert done.returncode==0,done.stderr;(r/'retirement-receipt.json').write_text(done.stdout,encoding='utf-8');print(done.stdout,flush=True)
