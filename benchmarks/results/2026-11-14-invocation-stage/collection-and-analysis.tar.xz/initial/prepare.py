from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'representative-stage-r363/b749';src=r.parent/'native-call-transport-r365';root='invocation-stage-b753-20261114';unit='lython-b753-invocation-stage-20261114'
source=json.loads((src/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in source['sources'].items())
config_case=json.loads((r.parent/'config-phases-r336/retrieved/representative.json').read_text(encoding='utf-8'))['cases'];assert len(config_case)==1 and config_case[0]['id']=='scripts.config-edit.empty';base=json.loads((src/'catalog.json').read_text(encoding='utf-8'));search=next(c for c in base['cases']if c['id']=='scripts.file-search.large');base['cases']=[config_case[0],search];(r/'catalog.json').write_text(json.dumps(base,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
identity=dict(json.loads((src/'b751/identity.json').read_text(encoding='utf-8')));identity.update(sourceRevision='Committed1c5af539/frozenff2b5d76; full43633423371 independently active',purpose='One current configuration/search owning CPU assessment. Separate complete public invocation/setup/scheduling from useful guest instructions and wider reset/protocol/I/O. Reuse prior R275/R363; quantify one remaining stage before any prototype. No direct-caller bypass or shared mutable constructor graph.',coreSHA256={k:source['coreSHA256']['candidate']for k in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,disassemblyCollectedInTheSameProcessAsSamples=False,noSpeedupForecast=True);(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','retrieve.py']:
    s=(old/name).read_text(encoding='utf-8').replace('representative-stage-b749-20261114',root).replace('lython-b749-representative-stage-20261114',unit).replace('B749','B753')
    if name=='ops-profile.py':
        s=s.replace("[('invoice','scripts.csv-invoice.large','warm'),('search','scripts.file-search.large','warm')]", "[('config','scripts.config-edit.empty','warm'),('search','scripts.file-search.large','warm')]")
        s=s.replace('count = 64 if name == "invoice" else 512 #', 'count = 2048 if name == "config" else 512 #')
        a=s.index("                guest = [row for row in record['threadCpuSeconds']");b=s.index('            record["verificationAfter"]',a)
        s=s[:a]+'''                guest = [row for row in record['threadCpuSeconds'] if row['seconds'] > .02 and row['name'].startswith('Lython executio')]
                active = [row for row in record['threadCpuSeconds'] if row['seconds'] > .02]
                if not active:raise RuntimeError('Expected active worker/caller CPU.')
                active_tid = ','.join(row['tid'] for row in active)
                record['guestTids'] = [row['tid'] for row in guest]
                record['profiledTids'] = [row['tid'] for row in active]
                record['guestTid'] = active_tid # Historical key; all active caller/GC/guest threads here.
                record['profileBoundary'] = 'All active worker CPU; classify public-run stacks separately from fixture reset/protocol/I/O outside guest clocks. CPU samples cannot quantify blocked scheduling latency.'
'''+s[b:]
        # Validate diagnostic inventory before starting any worker.
        assert '["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm"'not in s
    elif name=='collect.py':
        s=s.replace("['invoice', 'search']", "['config', 'search']").replace('Committedfa40d674/frozen73a1b233; representative invoice/search attribution','Committed1c5af539/frozenff2b5d76; current configuration/search invocation attribution')
    ast.parse(s);(r/name).write_text(s,encoding='utf-8',newline='\n')
(r/'run.sh').write_text('set -eu\nroot=/home/lokad/lython-bench-checks/'+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(question=identity['purpose'],bound='One two-case assessment,5s199Hzcpu-clock/fp each after8guestsecondswarmup;180sowner. Existing scripts/fixtures/workers/toolchain,normalGC/tiering plusPerfMap only.2048config/512search request iterations ensure warmup completes within128requests.',sourceConstraints='Workers capture/restore CLRexecutioncontext and provide managed stack. Do not bypass them, weaken nesting admission, share mutable owner/type graphs or add scheduler/proxy/options frameworks from source presence alone.',acceptance='Fullimage/catalog/stdout/file/budget/quiet/join/persistentarchive gates. All active caller/GC/guest samples, unknowns and raw stacks retained. Identify complete removable initialization/copying/scheduling stage or explicitly reject current hypothesis; no speed forecast or CPU attribution from waiting.',stopping='One owning source gate to concrete design/oldcode deletion/semantic acceptance/bounded complete config warm+fresh/search/invoice-report controls, or supported hypothesis rejection. No new inventory or open-ended qualification campaign; publication held.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for n in ['identity.json','ops-profile.py','collect.py','run.sh','prospective.json']:t.add(r/n,arcname=n)
    t.add(r/'catalog.json',arcname='catalog.json')
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
c=dict(root='/home/lokad/lython-bench-checks/'+root,sourceRoot='/home/lokad/lython-bench-checks/native-word-loan-b751-20261114',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('config=');b=s.index('\nbase=',a);s=s[:a]+'config='+repr(c)+s[b:];s=s.replace(" assert digest(source/'representative.json')==config['identity']['catalogSHA256']\n",'').replace(" os.link(source/'representative.json',root/'catalog.json')", " assert digest(root/'catalog.json')==config['identity']['catalogSHA256']").replace('lython-b749-fixtures','lython-b753-fixtures');ast.parse(s);(r/'launch-command.py').write_text(s,encoding='utf-8',newline='\n');(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8');a=s.index(";prior=");b=s.index("\n(r/'launch-attempt.json')",a);s=s[:a]+";prior=r.parent/'native-call-transport-r365/b751/terminal-status.json';d=json.loads(prior.read_text(encoding='utf-8'));assert d['receipt']['complete'] and not d['remainingWorkers'] and not d['remainingTrace']"+s[b:];ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared bounded current config/search all-active-thread profile; no remote action.',flush=True)
