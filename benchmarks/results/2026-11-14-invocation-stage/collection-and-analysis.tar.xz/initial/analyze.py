from pathlib import Path
import ast,collections,json,re,runpy
r=Path(__file__).parent/'b754';source=r.parent.parent/'frame-primitive-transport-r360/b738/analyze-primitive.py'
for name in ['config','search']:
    s=source.read_text(encoding='utf-8').replace('profiles/csv-while','profiles/'+name).replace('R360uncommitted/frozenb9ad2490 complete CSVwhile CPU attribution','Committed1c5af539/frozenff2b5d76 current '+name+' all-active-thread CPU attribution').replace('attribution-primitive.json','attribution-'+name+'.json')
    s=s.replace("record['guestTids']", "record.get('profiledTids', record['guestTids'])").replace('guestCpuSeconds=', 'profiledCpuSeconds=').replace("summary['guestCpuSeconds']", "summary['profiledCpuSeconds']").replace('guest CPU s', 'all active CPU s')
    s=s.replace('samples=[];current=None;leafIps=[]','samples=[];sampleTids=[];current=None;leafIps=[]').replace('if current is not None:samples.append(current)', 'if current is not None:samples.append(current);sampleTids.append(header[1])')
    ast.parse(s);p=r/('analyze-'+name+'.py');p.write_text(s,encoding='utf-8',newline='\n');d=runpy.run_path(str(p));record=d['record'];groups={}
    for label,keep in [('guest',lambda tid,stack:tid in record['guestTids']),('other-active',lambda tid,stack:tid not in record['guestTids']),('invocation-ancestry',lambda tid,stack:tid in record['guestTids']or any(any(marker in frame for marker in ['LythonCompiledScript::Run','ExecutionThreads+WorkItem::Execute','ExecutionThreads::Run(','ExecutionThreads+SynchronousWorkItem::Wait'])for frame in stack))]:
        rows=[stack for tid,stack in zip(d['sampleTids'],d['samples'])if stack and keep(tid,stack)];leaves=collections.Counter(x[0]for x in rows);owners=collections.Counter(next((frame for frame in row if '[Lokad.Lython]'in frame),'[no core frame]')for row in rows);groups[label]=dict(samples=leaves.total(),topLeaves=leaves.most_common(),nearestCoreOwners=owners.most_common())
    # Assembly mentions in parameter signatures do not identify the owning
    # method. Keep the initial broad census, but add strictly owned frames.
    for label,keep in [('guest',lambda tid,stack:tid in record['guestTids']),('other-active',lambda tid,stack:tid not in record['guestTids']),('invocation-ancestry',lambda tid,stack:tid in record['guestTids']or any(any(marker in frame for marker in ['LythonCompiledScript::Run','ExecutionThreads+WorkItem::Execute','ExecutionThreads::Run(','ExecutionThreads+SynchronousWorkItem::Wait'])for frame in stack))]:
        rows=[stack for tid,stack in zip(d['sampleTids'],d['samples'])if stack and keep(tid,stack)]
        strict=collections.Counter(next((frame for frame in row if re.search(r'\[Lokad\.Lython\] Lokad\.Lython\.[^\s(\[]+::',frame)),'[no core-owned method]')for row in rows)
        groups[label]['strictNearestCoreOwners']=strict.most_common()
    result=dict(source='1c5af539/frozenff2b5d76',case=name,record=record,groups=groups,interpretation='CPU attribution, not elapsed comparison or removable shares. The initial nearestCoreOwners classifier includes assembly mentions in signatures; strictNearestCoreOwners identifies the method assembly. Other-active includes mixed protocol/reset/validation/cleanup, some outside and some inside guest clocks. Invocation ancestry is conservative and can include worker bookkeeping. CPU samples cannot quantify blocked scheduling latency; all unknowns/raw retained.')
    (r/('boundary-census-'+name+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(name,[(k,v['samples'])for k,v in groups.items()],flush=True)
    for method,count in groups['guest']['topLeaves'][:20]:print(count,method,flush=True)
