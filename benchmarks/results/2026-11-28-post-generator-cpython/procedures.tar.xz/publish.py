from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
profile = lab / 'attribution/profile'
layout = lab / 'attribution/layout'
out = repo / 'benchmarks/results/2026-11-28-post-generator-cpython'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(quiet / 'identity.json')
stage = read(quiet / 'stage-custody.json')
summary = read(quiet / 'summary.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
frozen = identity['imageFiles']['candidate']
assert identity['sourceRevision'] == summary['source']
assert len(frozen) == 32 and {p.name: digest(p) for p in (quiet / 'local-image').iterdir()} == frozen
assert summary['timedBatches'] == 196 and summary['passedQuietCheck']
assert len(summary['rows']) == 7 and summary['rows'][-1]['lane'] == 'compile-run'
assert stage['reused'] == {'donor': 31} and stage['streamed']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))

profile_identity = read(profile / 'identity.json')
profile_summary = read(profile / 'run-summary.json')
layout_summary = read(layout / 'layout.json')
assert profile_identity['sourceRevision'] == profile_summary['sourceRevision'] == identity['sourceRevision']
assert profile_identity['imageFiles'] == identity['imageFiles']
assert profile_summary['allProcessesJoined'] and not profile_summary['timingQualification']
assert profile_summary['catalogSha'] == layout_summary['catalog'] == identity['catalogs']['representative.json']['sha256']
assert layout_summary['core'] == frozen['Lokad.Lython.dll']
profile_paths = {name: profile / name for name in ('run.sh','collect.py','analyze-managed.py','capture.log','analysis.log','identity.json')}
totals = 0
for role, _, _ in profile_identity['profiles']:
    folder = profile / role
    record = read(folder / 'record.json')
    assert record['allProcessesJoined'] and record['coreSha'] == frozen['Lokad.Lython.dll']
    assert digest(folder / 'run.nettrace') == record['nettraceSha']
    totals += len(record['batches'])
    for path in folder.iterdir():
        if path.is_file(): profile_paths[f'{role}/{path.name}'] = path
assert totals == profile_summary['totalVerifiedBatches']
for name in ('InspectLayout.csproj', 'Program.cs', 'build.log'):
    profile_paths[f'layout/{name}'] = layout / name

out.mkdir()
public = {name: quiet / name for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json')}
public.update({'managed-attribution.json': profile/'managed-attribution.json',
    'layout.json':layout/'layout.json','profile-summary.json':profile/'run-summary.json'})
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)
procedures = {name: lab/name for name in ('prepare.py', 'quiet-vm.py', 'verify.sh', 'summarize.py',
    'compact-completed-images.py', 'compaction.json', 'prepare-profile.py', 'publish.py')}
procedures.update({name: quiet/name for name in ('launch.log','upload.json','stage-custody.json',
    'candidate-local-verify.json','candidate-remote-verify.json','exit-code.txt','archive-receipt.json')})
for filename, files in [('procedures.tar.xz', procedures), ('profiles.tar.xz', profile_paths)]:
    with tarfile.open(out/filename, 'w:xz') as archive:
        for name, path in files.items(): archive.add(path, arcname=name)
    with tarfile.open(out/filename) as archive:
        assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in files.items())
print('Verified archive, both profiles, full image, output and file goldens and delivery procedure.')
