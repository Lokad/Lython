from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
prior = lab.parent / 'combined-loop-cpython-b1954-20261128/attribution'
profile = lab / 'attribution/profile'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')

identity = read(quiet / 'identity.json')
verification = read(quiet / 'candidate-local-verify.json')
image = identity['imageFiles']['candidate']
assert len(image) == 32 and {p.name: digest(p) for p in (quiet / 'local-image').iterdir()} == image
assert verification['state'] == 'Completed' and verification['caseCount'] == 5
assert verification['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert verification['launched']['library']['sha256'] == image['Lokad.Lython.dll']
roles = [('generator-async', 'diagnostic.shipment-row-generator-reduction', 'warm-async'),
         ('explicit-async', 'diagnostic.shipment-row-explicit-reduction', 'warm-async')]
identity.update(inspectedHead=identity['sourceRevision'], profiles=roles)
profile.mkdir(parents=True)
save(profile / 'identity.json', json.dumps(identity, indent=2) + '\n')
for name in ('representative.json', 'cpython-worker.py'):
    copy2(quiet / name, profile.parent / name)
copy2(quiet / 'candidate-local-verify.json', profile.parent / 'candidate-verify.json')
copy2(prior / 'profile' / 'run.sh', profile / 'run.sh')
copy2(prior / 'profile' / 'collect.py', profile / 'collect.py')
assert b'\r' not in (profile / 'run.sh').read_bytes()
analysis = (prior / 'profile' / 'analyze-managed.py').read_text(encoding='utf-8')
assert analysis.count('WAIT_FRAMES =') == 1
regions = """
REGIONS.update({
    'borrowed operand preparation': ('TryPrepareBorrowedGeneratorSum',),
    'borrowed generator prefix': ('BorrowedGeneratorSum.RunPrefix',),
    'borrowed generator reduction': ('BorrowedGeneratorSum',),
    'parent callback binding': ('TryStartPositionalCallback', 'StartBorrowedInvocation', 'StartInline'),
    'executable frame construction': ('InitializeExecutableWorkState', 'InitializeExecutableFrame', 'EnterInvocationFrame'),
    'record cell reads': ('TryReadRecordValue', 'TryExecuteClosureArithmetic', 'TryExecuteSequenceIndex'),
    'CSV row construction': ('CreateRecordRow', 'BuildRecord', 'AdoptRecord', 'ReadRow'),
})

"""
analysis = analysis.replace('WAIT_FRAMES =', regions + 'WAIT_FRAMES =')
analysis = analysis.replace("REGIONS['generator construction'] + REGIONS['generator advancement']",
    "REGIONS['borrowed generator reduction'] + REGIONS['borrowed operand preparation']")
compile(analysis, 'analyze-managed.py', 'exec')
save(profile / 'analyze-managed.py', analysis)
layout = profile.parent / 'layout'
layout.mkdir()
for name in ('Program.cs', 'InspectLayout.csproj', 'packages.lock.json'):
    copy2(prior / 'layout' / name, layout / name)
print(identity['sourceRevision'], 'paired warmed captures and layout census ready')
