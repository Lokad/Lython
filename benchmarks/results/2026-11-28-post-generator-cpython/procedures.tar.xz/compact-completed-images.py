from hashlib import sha256
from pathlib import Path
import json
import shlex
import subprocess

lab = Path(__file__).resolve().parent
rows = []
for folder, remote, unit in (
    ('starmap-slot-cpython-20261127', 'starmap-slot-cpython-b1823-20261127',
        'lython-b1823-starmap-slot-cpython-20261127'),
    ('synchronous-private-cursor-cleanup-20261125', 'synchronous-private-cursor-b1701-20261125',
        'lython-b1701-synchronous-private-cursor-20261125'),
):
    local = lab.parent / folder / 'comparison/quiet'
    state = json.loads((local / 'terminal-status.json').read_bytes())
    receipt = state['receipt']
    assert not state['live'] and not state['fixtures'] and state['exitCode'] == '0'
    assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'archivedAndVerifiedUnderLease'))
    assert sha256((local / 'observations.tar.xz').read_bytes()).hexdigest() == receipt['archiveSHA256']
    identity = json.loads((local / 'identity.json').read_bytes())
    rows.append(dict(root=remote, unit=unit, archiveSHA256=receipt['archiveSHA256'],
        coreSHA256=identity['imageFiles']['candidate']['Lokad.Lython.dll']))

upload = json.loads((lab / 'comparison/quiet/upload.json').read_bytes())
minimum = upload['expandedBytes'] + upload['minimumAfterStageBytes'] + 400_000
remote = f'expected={rows!r}\nminimum={minimum}\n' + r'''
from hashlib import sha256
from pathlib import Path
import fcntl, gzip, json, os, shutil, subprocess

base = Path('/home/lokad/lython-bench-checks')
digest = lambda path: sha256(path.read_bytes()).hexdigest()
assert base.resolve() == base
with (base / 'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    initial = shutil.disk_usage(base).free
    packed = []
    assert not any(path.is_mount() for path in base.glob('*/guest-fixtures'))
    for row in expected:
        if shutil.disk_usage(base).free >= minimum: break
        root = base / row['root']
        origin = root / 'candidate/Lokad.Lython.dll'
        backup = root / 'packed-candidate-core.dll.gz'
        assert root.parent == base and root.resolve() == root and origin.resolve() == origin
        assert origin.stat().st_nlink == 1 and not backup.exists()
        assert (root / 'exit-code.txt').read_text().strip() == '0' and not (root / 'guest-fixtures').exists()
        state = subprocess.check_output(['systemctl', 'show', row['unit'] + '.service',
            '--property=ActiveState,Result'], text=True).splitlines()
        assert 'ActiveState=inactive' in state and 'Result=success' in state
        receipt = json.loads((root / 'archive-receipt.json').read_bytes())
        assert receipt['complete'] and receipt['allWorkersJoined']
        assert digest(root / 'observations.tar.xz') == receipt['archiveSHA256'] == row['archiveSHA256']
        assert digest(origin) == row['coreSHA256']
        length = origin.stat().st_size
        with origin.open('rb') as source, backup.open('xb') as target:
            with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as compressed:
                shutil.copyfileobj(source, compressed)
            target.flush()
            os.fsync(target.fileno())
        with gzip.open(backup, 'rb') as stored:
            assert sha256(stored.read()).hexdigest() == row['coreSHA256']
        assert backup.stat().st_size < length
        record = dict(row, path=backup.name, originalBytes=length,
            compressedBytes=backup.stat().st_size, compressedSHA256=digest(backup))
        with (root / 'candidate-compaction.json').open('x', encoding='utf-8') as report:
            json.dump(record, report, indent=2)
            report.write('\n')
            report.flush()
            os.fsync(report.fileno())
        directory = os.open(root, os.O_DIRECTORY)
        try: os.fsync(directory)
        finally: os.close(directory)
        origin.unlink()
        packed.append(record)
    print(json.dumps(dict(before=initial, after=shutil.disk_usage(base).free, required=minimum, packed=packed)))
'''
compile(remote, '<completed VM storage compaction>', 'exec')
result = subprocess.check_output(['ssh', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'ConnectTimeout=12',
    '-o', 'StrictHostKeyChecking=yes', 'lokad@20.166.121.73', 'python3 -c ' + shlex.quote(remote)], timeout=45)
record = json.loads(result)
(lab / 'compaction.json').write_bytes(result)
assert record['after'] >= minimum, record
print(record)
