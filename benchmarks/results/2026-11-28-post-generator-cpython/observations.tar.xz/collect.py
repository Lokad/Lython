"""Representative CPython delivery checkpoint through unchanged comparison workers/protocol."""
import contextlib, fcntl, hashlib, importlib.util, json, math, os, shutil, tarfile
import statistics, subprocess, tempfile, time, signal
from pathlib import Path

root = Path(__file__).resolve().parent
dotnet = Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
python = Path('/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13')
catalog = root / 'representative.json'
spec = importlib.util.spec_from_file_location('protocol', root / 'cpython-worker.py')
protocol = importlib.util.module_from_spec(spec); spec.loader.exec_module(protocol)
cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}
manifest_hash = hashlib.sha256(catalog.read_bytes()).hexdigest()
identity = json.loads((root / 'identity.json').read_text())
image = Path(identity['frozenImage'])
worker = image / 'Lokad.Lython.Benchmarks.dll'
assert set(identity['coreSHA256']) == {'candidate','candidate-control'}
out = root / 'confirmation'; out.mkdir(exist_ok=False)
env = os.environ.copy(); env['DOTNET_ROOT'] = str(dotnet.parent)
owned_ram=root/'guest-fixtures'
env['TMPDIR']=str(owned_ram);tempfile.tempdir=str(owned_ram)
assert not any(k.startswith(('DOTNET_', 'COMPlus_')) and k != 'DOTNET_ROOT' for k in env)

cpu_frequency = os.sysconf('SC_CLK_TCK')
def process_cpu_ticks(pid):
    text=Path(f'/proc/{pid}/stat').read_text()
    fields=text[text.rfind(')')+2:].split()
    return int(fields[11])+int(fields[12])

class Worker:
    def __init__(self, label, case, lane, stack):
        self.label, self.case, self.lane, self.sequence = label, case, lane, 0
        self.folder = Path(tempfile.mkdtemp(prefix='lython-comparison-files-'))
        self.errors = tempfile.TemporaryFile(); self.process = None
        stack.callback(self.close)
        command = ([str(python), '-I', '-S', '-X', 'utf8', str(root/'cpython-worker.py'), '--catalog', str(catalog)]
                   if self.label.startswith('CPython') else [str(dotnet), str(worker), '--compare', 'worker', '--catalog', str(catalog)])
        self.process = subprocess.Popen(command, cwd=self.folder, env=env, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=self.errors)
        self.identity = protocol.read_frame(self.process.stdout)
        if self.identity is None:
            self.errors.seek(0)
            (out / f'startup-{case["id"]}-{lane}-{label}.stderr').write_bytes(self.errors.read())
            raise RuntimeError('Worker exited before Ready; stderr preserved')
        assert self.identity['status'] == 'Ready' and self.identity['catalogSha256'] == manifest_hash
        assert self.identity['protocolVersion'] == 2 and self.identity['timingBoundary'].startswith('command-v2:')
        if not label.startswith('CPython'):
            core = next(v for v in self.identity['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')
            assert core['sha256'].lower() == identity['coreSHA256'][label].lower()
            for name, sha in identity['auxiliaryFiles'].items():
                library = next((v for v in self.identity['libraries'] if Path(v['path']).name == name), None)
                if library is not None: assert library['sha256'].lower() == sha
            assert not self.identity['serverGc'] and not any(self.identity['runtimeOverrides'].values())
        else:
            assert self.identity['gcEnabled'] and self.identity['gilEnabled']
            assert not self.identity['freeThreaded'] and not self.identity['debug']
            assert self.identity['executableSha256'] == hashlib.sha256(python.read_bytes()).hexdigest() == identity['expectedCPythonSHA256']
        self.request('verify', 2)
    def request(self, operation, count):
        request_started = time.monotonic()
        self.sequence += 1
        request = {k:self.case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
        request.update(protocolVersion=protocol.PROTOCOL_VERSION, requestId=self.sequence, operation=operation,
                       caseId=self.case['id'], lane=self.lane, iterations=count)
        before_cpu=process_cpu_ticks(self.process.pid) if operation == 'batch' else 0
        protocol.write_frame(self.process.stdin, request)
        response = protocol.read_frame(self.process.stdout)
        if operation == 'batch': self.last_cpu_ticks=process_cpu_ticks(self.process.pid)-before_cpu
        self.last_request_seconds = time.monotonic()-request_started
        assert response['requestId'] == self.sequence and response['caseId'] == self.case['id']
        assert response['status'] == ('Equivalent' if operation == 'verify' else 'Completed'), response
        assert response['completedInvocations'] == count
        for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']: assert response[k] == self.case[k]
        compile_batch = self.lane == 'compile' and operation == 'batch'
        assert response.get('actualOutputSha256') == (None if compile_batch else self.case['expectedOutputSha256'])
        assert response.get('actualFilesSha256') == (None if compile_batch else self.case.get('expectedFilesSha256'))
        return response
    def close(self):
        try:
            if self.process is not None:
                if self.process.poll() is None:
                    self.sequence += 1
                    protocol.write_frame(self.process.stdin, dict(protocolVersion=protocol.PROTOCOL_VERSION, requestId=self.sequence, operation='quit'))
                    assert protocol.read_frame(self.process.stdout)['status'] == 'Closed'
                code = self.process.wait(timeout=5)
                self.errors.seek(0); errors = self.errors.read()
                if errors: (out / f'{self.case["id"]}-{self.lane}-{self.label}.stderr').write_bytes(errors)
                assert code == 0, code
                assert not errors
        finally:
            if self.process is not None:
                if self.process.poll() is None: self.process.kill(); self.process.wait()
                self.process.stdin.close(); self.process.stdout.close()
            self.errors.close()
            assert self.folder.parent == Path(tempfile.gettempdir()) and self.folder.name.startswith('lython-comparison-files-')
            shutil.rmtree(self.folder)

def stop(*_):raise InterruptedError('Owned checkpoint stopped; join all users before cleanup.')
signal.signal(signal.SIGTERM,stop)



def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def check_image():
    assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['cpythonWorkerSHA256']
    assert hashlib.sha256(python.read_bytes()).hexdigest()==identity['expectedCPythonSHA256']
    for name, sha in identity['imageFiles']['candidate'].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==sha, name
    assert hashlib.sha256((root/'jobs.json').read_bytes()).hexdigest()==identity['catalogs']['jobs.json']['sha256']

jobs = json.loads((root/'jobs.json').read_text())
assert len(jobs) == 7 and manifest_hash == identity['catalogs']['representative.json']['sha256']

def warm():
    started=time.monotonic();record=dict(complete=False,purpose=identity['purpose'],jobs=[])
    def save():
        t=out/'confirmation.json.tmp';t.write_text(json.dumps(record,indent=2)+'\n');t.replace(out/'confirmation.json')
    save()
    for index,(case_id,lane) in enumerate(jobs):
        assert time.monotonic()-started<450,'Leave time for cleanup and archival'
        assert shutil.disk_usage(root).free>=3*1024*1024,'Reserve space for saved observations and archival'
        lanes = [lane]
        with contextlib.ExitStack()as stack:
          labels=['CPython','candidate-control','CPython-control','candidate']
          if index%2:labels.reverse()
          workers=[Worker(label,cases[case_id],'warm',stack)for label in labels]
          counts={}; warmups=[]; warmed={w.label:0.0 for w in workers}
          for w in workers:
            w.lane=lane
            counts[w.label,lane]=1
          turn=0
          while min(warmed.values())<5:
            for offset in range(len(workers)):
              w=workers[(turn+offset)%len(workers)]
              if warmed[w.label]>=5:continue
              response=w.request('batch',counts[w.label,lane])
              warmups.append(dict(engine=w.label,lane=lane,response=response))
              seconds=w.last_request_seconds
              warmed[w.label]+=seconds
              counts[w.label,lane]=max(1,min(100000,math.ceil(counts[w.label,lane]*.60/max(seconds,.000001))))
            turn+=1
          samples=[]
          for round in range(7):
            sequence=[(w,lane)for w in workers for lane in lanes]
            if round%2:sequence.reverse()
            sequence=sequence[round%len(sequence):]+sequence[:round%len(sequence)]
            for w,lane in sequence:
              w.lane=lane;response=w.request('batch',counts[w.label,lane])
              samples.append(dict(round=round,engine=w.label,lane=lane,response=response,externalProcessCpuTicks=w.last_cpu_ticks,externalCpuFrequency=cpu_frequency,requestSeconds=w.last_request_seconds))
          for w in workers:w.request('verify',2)
          result=dict(case=case_id,lanes=lanes,identities={w.label:w.identity for w in workers},warmups=warmups,samples=samples)
        result['workersJoinedAndFixturesRemoved']=True;record['jobs'].append(result);save();print(case_id,lane,'complete',flush=True)
    time.sleep(20)
    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')],env=env,check=True)
    assert json.loads((out/'machine-after.json').read_text())['gate']['quiet']
    record.update(complete=True,elapsedSeconds=time.monotonic()-started);save()
    return record

def archive(complete, warm):
    bundle=root/'observations.tar.xz'
    with tarfile.open(bundle,'w:xz') as frozen:
        for item in ('identity.json','representative.json','jobs.json','confirmation','collect.py','run.sh'):
            frozen.add(root/item,arcname=item)
    with tarfile.open(bundle) as frozen:
        assert all(hashlib.sha256(frozen.extractfile(member).read()).hexdigest()==digest(root/member.name)
            for member in frozen.getmembers() if member.isfile())
    (root/'archive-receipt.json').write_text(json.dumps(dict(
        complete=complete, warmJobs=len(warm['jobs']) if warm else None,
        allWorkersJoined=complete, guestFixturesRemoved=not owned_ram.exists(),
        quietBeforeAndAfter=complete, archivedAndVerifiedUnderLease=True, archiveSHA256=digest(bundle),
    ),indent=2)+'\n')

with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    check_image()
    owned_ram.mkdir()
    subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad',
        'lython-b1958-cpython-fixtures',owned_ram],check=True)
    complete=False
    result=None
    try:
        assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev
        time.sleep(8)
        subprocess.run([dotnet,worker,'--compare','check-machine','--out',out/'machine-before.json'],env=env,check=True)
        assert json.loads((out/'machine-before.json').read_text())['gate']['quiet']
        (out/'fixture-filesystem.txt').write_text(subprocess.check_output(
            ['findmnt','-T',str(owned_ram),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
        result=warm()
        check_image()
        assert not list(owned_ram.iterdir()), list(owned_ram.iterdir())
        complete=True
    finally:
        subprocess.run(['sudo','-n','umount',owned_ram],check=True)
        owned_ram.rmdir()
        archive(complete,result)
