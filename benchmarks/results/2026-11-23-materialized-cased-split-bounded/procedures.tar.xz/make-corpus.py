from pathlib import Path
import json
import random

lab=Path(__file__).resolve().parent
rng=random.Random(289314)
units=("A", "Ω", "a", "Σ", "σ", "İ", "ß", "ΐ", "ﬄ", "é", "K", "'", "\u0345", "\u0301", "𐐨", "😀",
       " ", "\t", "\x1c", "\u0085", "\u2003", "\u3000", "\u2028", "\xa0", "\x00")
cases=["", " \u2028\u3000\t", "AΣ'\u0301 CΣ aΣ-Σ", "İß", "A" * 126, "A" * 127, "A" * 128, "A" * 129,
       "ß" * 80 + "\tΣΣ", "A" * 1025, "Σ́ " * 301, "A " * 929, "Ω" * 622 + " \u2003ΞΣ"]
for length in (2, 7, 17, 31, 64, 100, 127, 128, 129, 256, 511):
    for _ in range(11):
        cases.append("".join(rng.choice(units) for _ in range(length)))
source="""import json

def lower_words(text):
    return text.lower().split()

def upper_words(text):
    return text.upper().rsplit()

first, second = lower_words(''), upper_words(' ')
first.append('kept')
print(first, second, first is second)

inputs = """+json.dumps(cases,ensure_ascii=False)+"""

for value in inputs:
    lower = lower_words(value)
    upper = upper_words(value)
    print(json.dumps((lower, upper), ensure_ascii=False, separators=(',', ':')))
"""
(lab/"casing-corpus.py").write_text(source,encoding="utf-8",newline="\n")
print(len(cases),"input cases")
