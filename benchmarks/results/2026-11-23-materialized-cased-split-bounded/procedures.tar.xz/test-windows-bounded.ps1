$root = Join-Path $env:USERPROFILE '.dotnet11'
$env:DOTNET_ROOT = $root
$env:DOTNET_ROOT_X64 = $root
$env:PATH = "$root;$env:Path"
$env:DOTNET_HOST_PATH = Join-Path $root 'dotnet.exe'
$lab = $PSScriptRoot
Set-Location 'D:/code/Lython/.git/agent-worktrees/materialized-cased-split-20261123'
$filter = 'Category!=Stress&(FullyQualifiedName~Split|FullyQualifiedName~Casing|FullyQualifiedName~StringWindow|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~DictionaryAccumulationLifetime|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~NativeConditionalHelper|FullyQualifiedName~CapturedScalarObservation|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~ManagedStackGuard)'
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-bounded" --filter $filter > "$lab/white-bounded-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/white-bounded-windows.log" -Encoding utf8 -Tail 38; exit $code }
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-bounded" --filter $filter > "$lab/public-bounded-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/public-bounded-windows.log" -Encoding utf8 -Tail 38; exit $code }
Get-Content "$lab/white-bounded-windows.log", "$lab/public-bounded-windows.log" -Encoding utf8 | Select-String 'Passed!'

& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.Tests -c Release -f net11.0 --no-build --artifacts-path "$lab/windows-bounded" --filter 'Category=Stress&FullyQualifiedName~NativeTextConstructionRollback' > "$lab/stress-bounded-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/stress-bounded-windows.log" -Encoding utf8 -Tail 38; exit $code }
Get-Content "$lab/stress-bounded-windows.log" -Encoding utf8 | Select-String 'Passed!'
