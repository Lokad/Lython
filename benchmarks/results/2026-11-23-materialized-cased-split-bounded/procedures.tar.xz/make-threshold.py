from pathlib import Path
import json
import random

lab=Path(__file__).resolve().parent
rng=random.Random(289314)
units=("A", "Ω", "a", "Σ", "σ", "İ", "ß", "ΐ", "ﬄ", "é", "K", "'", "\u0345", "\u0301", "𐐨", "😀",
       " ", "\t", "\x1c", "\u0085", "\u2003", "\u3000", "\u2028", "\xa0", "\x00")
cases=["", " \u2028\u3000\t", "AΣ'\u0301 CΣ aΣ-Σ", "İß", "A" * 126, "A" * 127, "A" * 128, "A" * 129,
       "ß" * 80 + "\tΣΣ", "A" * 1025, "Σ́ " * 301, "A " * 929, "Ω" * 622 + " \u2003ΞΣ"]
# UTF-8 input lengths straddle the 512-byte lower and upper stack
# thresholds and the 16 KiB lower and upper scratch thresholds.
cases = []
for size in (84, 85, 86, 126, 127, 128, 2729, 2730, 2731, 4094, 4095, 4096):
    prefix = "Σ́ ß İ ﬄ"
    cases.append(prefix + "A" * (size - len(prefix.encode("utf-8"))))
    cases.append(" " * size)
source="""import json

def lower_words(text):
    return text.lower().split()

def upper_words(text):
    return text.upper().rsplit()

first, second = lower_words(''), upper_words(' ')
first.append('kept')
print(first, second, first is second)

inputs = """+json.dumps(cases,ensure_ascii=False)+"""

for value in inputs:
    lower = lower_words(value)
    upper = upper_words(value)
    print(json.dumps((lower, upper), ensure_ascii=False, separators=(',', ':')))
"""
(lab/"casing-threshold.py").write_text(source,encoding="utf-8",newline="\n")
print(len(cases),"input cases")
