from pathlib import Path
import gzip,hashlib,json,shutil

lab=Path(__file__).resolve().parent
prior=lab.parent/'abstract-value-facts-r589'
image=prior/'frozen/reference'
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
expected=load(prior/'frozen-identity.json')['images']['reference']
assert len(expected)==32 and all(sha((image/name).read_bytes())==value for name,value in expected.items())
assert expected['Lokad.Lython.dll'].startswith('9edeede4')
core=(image/'Lokad.Lython.dll').read_bytes()
target=Path('benchmarks/results/2026-11-18-annotation-and-forwarding-cpython/lython-core.dll.gz')
blob=gzip.compress(core,6,mtime=0)
assert gzip.decompress(blob)==core
target.write_bytes(blob)
print('Preserved the verified B1016 core.')
