from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.parent / 'direct-closed-defaults-20261123'
root = lab / 'module-name-census'
image = root / 'candidate'
project = root / 'inspect'
image.mkdir(parents=True, exist_ok=True)
project.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(lab / 'comparison/quiet/identity.json')
files = identity['imageFiles']['candidate']
for name, expected in files.items():
    original = reference / 'candidate' / name
    assert digest(original) == expected
    shutil.copyfile(original, image / name)
template = lab.parent / 'closed-definition-return-20261123/inspect'
for name in ('Inspect.csproj', 'packages.lock.json'):
    shutil.copyfile(template / name, project / name)
program = (template / 'Program.cs').read_text(encoding='utf-8')
mark = '            codes.Add(new { arithmetic,'
assert program.count(mark) == 1
program = program.replace(mark, '''            var names = ((IEnumerable)Read(code, "Names")!).Cast<string>().ToArray();
            var moduleSlots = ((IEnumerable)Read(code, "ModuleGlobalSlots")!).Cast<int>().ToArray();
            codes.Add(new { names, moduleSlots, arithmetic,''')
(project / 'Program.cs').write_text(program, encoding='utf-8', newline='\n')

catalogs = [
    lab.parent / 'retained-call-cpython-20261123/representative.json',
    reference / 'comparison/representative.json',
    lab.parent / 'sparse-branch-confirmation-20261123/comparison/quiet/representative.json',
    lab.parent / 'csv-batched-markers-20261123/comparison/representative.json',
]
cases = {}
for source in catalogs:
    for row in read(source)['cases']:
        if row['id'] in cases:
            assert cases[row['id']]['source'] == row['source']
        else:
            cases[row['id']] = dict(id=row['id'], source=row['source'])
write(root / 'sources.json', dict(cases=list(cases.values())))

dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
build = project / 'build'
subprocess.run([dotnet, 'build', project / 'Inspect.csproj', '-c', 'Release', '-o', build],
    cwd=repo, env=env, timeout=75, check=True)
for name in ('Inspect.dll', 'Inspect.deps.json', 'Inspect.runtimeconfig.json'):
    shutil.copyfile(build / name, image / name)
output = root / 'tapes.json'
subprocess.run([dotnet, image / 'Inspect.dll', root / 'sources.json', output], cwd=repo, env=env, timeout=60, check=True)
tape = read(output)
assert tape['coreSHA256'] == files['Lokad.Lython.dll']
rows = []
for row in tape['rows']:
    bodies = row['codes']
    names = [name for body in bodies for name in body['names']]
    slots = [slot for body in bodies for slot in body['moduleSlots']]
    maps = [body['moduleSlots'] for body in bodies if body['moduleSlots']]
    metrics = dict(case=row['id'], bodies=len(bodies), names=len(names), uniqueNames=len(set(names)),
        mappedEntries=len(slots), boundLocations=sum(slot >= 0 for slot in slots), nonemptyMaps=len(maps),
        mapsWithNoBoundLocations=sum(all(slot < 0 for slot in group) for group in maps))
    rows.append(metrics)
    print(metrics)
write(root / 'census.json', dict(sourceRevision=identity['sourceRevision'], sha=tape['coreSHA256'], rows=rows))
