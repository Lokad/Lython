from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
old = lab.parent / 'retained-call-cpython-20261123'
donor = lab.parent / 'direct-closed-defaults-20261123'
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)


def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


def adapt(source, destination, replacements):
    script = source.read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in script, (source, before)
        script = script.replace(before, after)
    compile(script, str(destination), 'exec')
    destination.write_text(script, encoding='utf-8', newline='\n')


tracked = 'benchmarks/results/2026-11-23-direct-closed-defaults/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
proof = json.loads(pushed('identity.json'))
original = json.loads(pushed('terminal-status.json'))['receipt']
assert original['complete'] and original['allWorkersJoined'] and original['archivedAndVerifiedUnderLease']
assert sha(pushed('observations.tar.xz')) == original['archiveSHA256']
head = git('rev-parse', 'origin/master').decode().strip()
retained = proof['retainedRevision']
assert not git('diff', '--name-only', head, retained, '--', 'src')
assert not git('diff', '--name-only', retained, proof['candidate'], '--', 'src')
files = proof['imageFiles']['candidate']
image = donor / 'candidate'
assert len(files) == 32 and all(digest(image / name) == expected for name, expected in files.items())
protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == proof['cpythonWorkerSHA256']

catalog = read(old / 'representative.json')
eager = 'scripts.annotated-rule-closures.nested-factories'
postponed = eager + '.postponed'
supplied = 'scripts.ordinary-fully-supplied-helper'
quoted = 'scripts.csv-invoice.method-policy.quoted-control'
names = {eager, postponed, supplied, quoted}
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in names]
assert {row['id'] for row in catalog['cases']} == names
catalog_path = quiet / 'representative.json'
write(catalog_path, catalog)
write(quiet / 'jobs.json', [[eager, 'warm'], [postponed, 'warm'], [quoted, 'warm'], [supplied, 'warm'],
    [eager, 'compile-run'], [postponed, 'compile-run'], [postponed, 'compile']])

dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
verification = quiet / 'candidate-verify.json'
subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', catalog_path,
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', protocol, '--out', verification],
    env=env, check=True, timeout=90)
verified = read(verification)
assert verified['state'] == 'Completed' and verified['caseCount'] == 4
assert verified['launched']['library']['sha256'] == files['Lokad.Lython.dll']
assert all(digest(image / name) == expected for name, expected in files.items())

remote = '/home/lokad/lython-bench-checks'
root = 'closed-defaults-cpython-b1516-20261123'
identity = dict(sourceRevision=retained, candidate=proof['candidate'], retainedRevision=retained, deliveryRevision=head,
    frozenImage=remote + '/' + root + '/candidate', imageFiles=proof['imageFiles'],
    auxiliaryFiles={name: expected for name, expected in files.items() if name != 'Lokad.Lython.dll'},
    coreSHA256={label: files['Lokad.Lython.dll'] for label in ('candidate', 'candidate-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'], expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name: dict(sha256=digest(quiet / name)) for name in ('representative.json', 'jobs.json')})
write(quiet / 'identity.json', identity)
adapt(old / 'collect.py', quiet / 'collect.py', [('len(jobs) == 8', 'len(jobs) == 7'),
    ('<400,', '<368,'), ('lython-b1491-fixtures', 'lython-b1516-fixtures'),
    ('CPython checkpoint on retained supplied calls and factories', 'CPython checkpoint after direct owner transfer')])
adapt(old / 'summarize.py', quiet / 'summarize.py', [('len(raw["jobs"])==8', 'len(raw["jobs"])==7'),
    ('receipt["warmJobs"]==8', 'receipt["warmJobs"]==7')])
shutil.copyfile(old / 'run.sh', quiet / 'run.sh')
assert b'\r' not in (quiet / 'run.sh').read_bytes()
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as bundle:
    for name in ('identity.json', 'representative.json', 'jobs.json', 'run.sh', 'collect.py'):
        bundle.add(quiet / name, arcname=name)
write(quiet / 'upload.json', dict(root=root, reference='retained-call-cpython-b1510-20261123',
    original='direct-closed-defaults-b1515-20261123', originalArchive=original['archiveSHA256'],
    payloadBytes=payload.stat().st_size, payloadSHA256=digest(payload)))
adapt(donor / 'repeat/quiet.py', lab / 'quiet.py', [
    ('lython-b1515-direct-closed-defaults-repeat-20261123', 'lython-b1516-closed-defaults-cpython-20261123'),
    ('.+b1515-repeat-', '.+b1516-'), ('lython-b1515-repeat-stage-', 'lython-b1516-stage-'),
    ('Four bounded lanes', 'Seven bounded lanes'), ("four lanes'", "seven lanes'"),
    ('RuntimeMaxSec=275', 'RuntimeMaxSec=410'), ('seconds=225', 'seconds=370'),
])
