from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
history = lab.parent
old = history/'starmap-slot-cpython-20261127'
donor = old/'comparison/quiet'
local = history/'list-growth-transaction-20261127/local'
quiet = lab/'comparison/quiet'
image = quiet/'candidate'
quiet.mkdir(parents=True)
def sha(path): return sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def manifest(path): return {file.name:sha(file) for file in path.iterdir()}
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('4a6000316')
assert not subprocess.check_output(['git','diff','HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
local_pin = read(local/'identity.json')
assert manifest(local/'candidate') == local_pin['imageFiles']['candidate']
assert subprocess.check_output(['git','diff','--binary','c7ac5dbaf','HEAD','--','src'],cwd=repo) == (local/'candidate.patch').read_bytes()
shutil.copytree(local/'candidate',image)
core = 'Lokad.Lython.dll'
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0'/core,image/core)
files = manifest(image)
prior = read(donor/'identity.json')
old_files = prior['imageFiles']['candidate']
assert (len(files),len(old_files)) == (32,32)
overlay = sorted(name for name,digest in files.items() if old_files.get(name)!=digest)
assert overlay == ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.dll']
donor_name = Path(prior['frozenImage']).parent.name
donor_archive = read(donor/'terminal-status.json')['receipt']['archiveSHA256']
root = 'current-cpython-b1834-20261127'
campaigns = [
    history/'short-command-boundary-20261127/local/representative.json',
    history/'shared-pending-zip-20261127/local/representative.json',
    local/'representative.json',
    history/'final-default-slots-20261127/local/representative.json',
]
available = {row['id']:row for path in campaigns for row in read(path)['cases']}
jobs = [
    ['diagnostic.file-search-first-line','warm'],
    ['scripts.file-search.large','warm'],
    ['scripts.config-edit.small','warm'],
    ['diagnostic.shipment-starmap-wide-lists','warm-async'],
    ['scripts.json-summary-helpers.large','warm-async'],
    ['diagnostic.json-lines-nested-arrays','warm-async'],
    ['diagnostic.generated-ordinary-definitions','compile'],
    ['diagnostic.generated-ordinary-definitions','compile-run'],
]
catalog = read(campaigns[0])
catalog['cases'] = [available[key] for key in dict.fromkeys(key for key,_ in jobs)]
assert len(catalog['cases']) == 7
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',jobs)
shutil.copyfile(local/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py') == prior['cpythonWorkerSHA256']
defines = dict(sourceRevision=head,productionSource=head,comparisonHostRevision='05c1059de794316e509d5d0f962a0b5b4a40fb0b',
    frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate',
    auxiliaryFiles={n:h for n,h in files.items() if n not in overlay},overlay=overlay,imageFiles={'candidate':files},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=prior['expectedCPythonSHA256'],cpythonWorkerSHA256=prior['cpythonWorkerSHA256'],
    donorArchiveSHA256=donor_archive,
    purpose='Refresh current short commands, shipment, JSON Lines and ordinary definition compilation against pinned CPython.')
write(quiet/'identity.json',defines)
collector=(donor/'collect.py').read_text(encoding='utf-8').replace('len(jobs) == 6','len(jobs) == 8')
collector=collector.replace('started<263','started<325').replace('lython-b1823-fixtures','lython-b1834-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(donor/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
summary=(donor/'summarize.py').read_text(encoding='utf-8')
summary=summary.replace('len(raw["jobs"])==6','len(raw["jobs"])==8').replace('receipt["warmJobs"]==6','receipt["warmJobs"]==8')
(quiet/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
result = quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',result],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
verified = read(result)
assert verified['state']=='Completed' and verified['caseCount']==7
assert verified['catalogSha256']==defines['catalogs']['representative.json']['sha256']
assert verified['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
assert verified['launched']['library']['sha256']==files[core]
moment = ['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',
          *[f'candidate/{name}' for name in overlay]]
payload = quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as tar:
    for name in moment: tar.add(quiet/name,arcname=name)
staged = {name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in moment}
duplicates = [
    dict(expectedCore='a9ed22ffacc2407115b7b26059d0ebba91d1a04f9d5024e5d6c4f79de1992d46',
         archiveFile='observations.tar.xz',paths=[
         ['ordinary-default-operands-b1675-20261125','lython-b1675-ordinary-default-operands-20261125',
          '9a4516177ec6e3d5eb2c04cd120945547938e19cebe3fa80398c7406d1362189'],
         ['ordinary-default-operands-b1675c-20261125','lython-b1675c-ordinary-default-operands-20261125',
          'b4ca4289fd147f51ca4e2efc8b4da3dbc4f7061513603ae354dd3ccec85c66e0']]),
    dict(expectedCore='4f57ca332a6d83b36427a37934e1d2f112089d089ad0e9aee86d4cd5ce9af941',
         archiveFile='observations.tgz',paths=[
         ['json-existing-windows-b634-20261112','lython-b634-json-existing-windows-20261112',
          'eb20c371d5dbf38fb25bdfc73531a9facb9fd5404e883d2d529ea7495d207451'],
         ['json-existing-windows-b635-20261112','lython-b635-json-window-async-20261112',
          '03842ec59ed2f7c859c63703d830280c24975fd21426c75ce70191caf5302544']]),
]
write(quiet/'upload.json',dict(root=root,donor=donor_name,donorFiles=old_files,donorArchive=donor_archive,
    payloadSHA256=sha(payload),files=staged,expandedBytes=sum(item['length'] for item in staged.values()),
    minimumAfterStageBytes=4*1024*1024,duplicates=duplicates))
print('Validated overlay bytes',sum(item['length'] for item in staged.values()))
