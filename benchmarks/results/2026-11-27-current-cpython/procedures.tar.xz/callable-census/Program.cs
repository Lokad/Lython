using System.Text.Json;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var requested = new[] { "diagnostic.generated-ordinary-definitions", "scripts.rule-default-closures" };
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString();
    if (!requested.Contains(id)) continue;
    var frontend = LythonFrontend.Compile(item.GetProperty("source").GetString()!);
    var script = ExecutableScript.Compile(frontend.Script!);
    var roots = script.EntryPoint.Constants.OfType<ExecutableCreateFunction>();
    string factory = id == requested[0] ? "build" : "make_rules";
    var code = roots.Single(create => create.CodeObject.Name == factory).CodeObject;
    var deferred = (code.DeferredDefinitionSites ?? []).Select(pc =>
        (Instruction: code.Instructions[pc], Store: code.Instructions[pc + 1])).ToArray();
    Console.WriteLine(JsonSerializer.Serialize(new
    {
        id,
        factory,
        instructions = code.Instructions.Length,
        localCount = code.FirstTemporarySlot,
        code.OperandCapacity,
        code.ValueStorageCapacity,
        code.CanRunNativeInstructions,
        deferred = deferred.Length,
        separateKeywordSlots = deferred
            .Where(item => item.Instruction.DeferredKeywordSlot != item.Store.LocalSlot)
            .Select(item => item.Instruction.DeferredKeywordSlot).Distinct().Count(),
        deferredLiteralKeywords = deferred.Count(item => ((ExecutableCreateFunction)code.Constants[item.Instruction.ConstantIndex]!).LiteralKeywordDefaults is not null),
        admissions = code.Instructions.Count(op => op.OpCode == ExecutableOpCode.StartFunctionDefaults),
        stores = code.Instructions.Count(op => op.OpCode == ExecutableOpCode.StoreFunctionDefault),
        arithmeticCalls = code.Instructions.Count(op => op.OpCode == ExecutableOpCode.LoadGlobalForArithmeticCall),
    }));
}
