set -eu
root=/home/lokad/lython-bench-checks/bulk-csv-field-output-b1277-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
