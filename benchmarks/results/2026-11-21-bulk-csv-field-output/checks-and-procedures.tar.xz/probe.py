from pathlib import Path
import hashlib,json,shutil,subprocess
lab=Path(".git/agent-notes/review-20261031/bulk-csv-field-output")
tool=Path(".git/agent-worktrees/pinned-unicode-casing-20261121/tools/LythonProbe/bin/Release/net11.0")
dotnet=Path.home()/".dotnet11/dotnet.exe"
for role in ("reference","candidate"):
    target=lab/"semantic-probe"/role
    target.mkdir(parents=True)
    for p in tool.iterdir():
        if p.is_file(): shutil.copyfile(p,target/p.name)
    core=target/"Lokad.Lython.dll"
    shutil.copyfile(lab/"frozen"/role/core.name,core)
    identity=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(core.read_bytes()).hexdigest()==identity["imageFiles"][role][core.name]
    for lane in ("sync","async"):
        args=[dotnet,target/"LythonProbe.dll","--batch-json","--compare-python","--python","C:/Python313/python.exe"]
        if lane=="async":args.append("--async")
        run=subprocess.run(args,input=(lab/"probe-cases.json").read_bytes(),capture_output=True,timeout=100)
        (lab/f"probe-{role}-{lane}.jsonl").write_bytes(run.stdout)
        if run.stderr: (lab/f"probe-{role}-{lane}.stderr").write_bytes(run.stderr)
        rows=[json.loads(line) for line in run.stdout.splitlines()]
        assert len(rows)==41,(run.returncode,len(rows),run.stderr)
        print(role,lane,"exit",run.returncode,"cases",len(rows))
