from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
base = lab.parent
control = json.loads((base / "activation-r404/capture/retrieved/catalog.json").read_text(encoding="utf-8-sig"))
program = '''import csv

total = 0
written = 0
with open("inventory.csv", encoding="utf-8", newline="") as source, open("restock.csv", "w", encoding="utf-8", newline="") as target:
    reader = csv.DictReader(source)
    writer = csv.writer(target, @@options@@)
    writer.writerow(["sku", "description", "quantity"])
    for row in reader:
        count = int(row["quantity"])
        if count > 0:
            writer.writerow([row["sku"], row["description"].strip(), count])
            total += count
            written += 1
print(written, total)
'''

def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def encode(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")

def file_digest(name: str, data: bytes) -> str:
    path = name.encode("utf-8")
    return sha(struct.pack(">ii", 1, len(path)) + path + struct.pack(">i", len(data)) + data)

rows = []
for flavor, descriptions, options in (
    ("ordinary", ("  galvanised support bracket for shelf-and-panel installation  ",
        "  lower hinge and matching steel fastener pack  ", "  café location marker with pictogram 🌚  ",
        "  large-right-hand storage bin insert  "), 'lineterminator="\\n"'),
    ("escaped", ('  shelf «L» § zone λ and eclipse marker 🌚  ', '  spare · assembly part 🌙, size «S»  ',
        "  λλ🌙🌙««·§ • photo label 🌚  ", "  notes with λ and « plus · details  "),
     'delimiter="§", quotechar="«", escapechar="·", doublequote=False, lineterminator="λ🌙\\n"'),
    ("short", ("alpha", "β", "x", '"S"'), 'lineterminator="\\n"'),
):
    size = 3072
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerow(("sku", "description", "quantity"))
    for i in range(size):
        writer.writerow((f"A{i:05}", descriptions[i % len(descriptions)], i % 27))
    data = stream.getvalue().encode("utf-8")
    source = program.replace("@@options@@", options)
    with tempfile.TemporaryDirectory(prefix="lython-csv-catalog-") as directory:
        root = Path(directory)
        (root / "inventory.csv").write_bytes(data)
        proc = subprocess.run(["C:/Python313/python.exe", "-I", "-S", "-X", "utf8", "-c", source], cwd=root,
                              capture_output=True, check=True, timeout=20)
        output = proc.stdout.replace(b"\r\n", b"\n")
        result = (root / "restock.csv").read_bytes()
    fixture = json.dumps(dict(size=size, text=None, inputFiles={"inventory.csv": encode(data)},
                              outputFiles={"restock.csv": encode(result)}), separators=(",", ":"))
    rows.append(dict(id=f"scripts.csv-restock-export.{flavor}", family="scripts", category="csv-export", scale="large", size=size,
                     source=source, fixtureJson=fixture, expectedOutput=output.decode("utf-8"),
                     sourceUtf8Bytes=len(source.encode("utf-8")), expectedOutputUtf8Bytes=len(output),
                     fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
                     sourceSha256=sha(source.encode("utf-8")), fixtureSha256=sha(fixture.encode("utf-8")),
                     expectedOutputSha256=sha(output), expectedFilesSha256=file_digest("restock.csv", result)))
    print(flavor, len(data), len(result), output.decode("utf-8").strip())

control_row, = [row for row in control["cases"] if row["id"] == "scripts.csv-invoice.large"]
control["cases"] = rows + [control_row]
(lab / "representative.json").write_text(json.dumps(control, ensure_ascii=False, indent=2) + "\n",
                                        encoding="utf-8", newline="\n")
