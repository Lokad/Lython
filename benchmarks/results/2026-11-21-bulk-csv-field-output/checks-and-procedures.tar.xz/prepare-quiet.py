from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
bench=lab.parent
template=bench/"expanded-builtin-span/quiet"
donor=bench/"direct-builtin-operands/refined/quiet"
q=lab/"quiet"
read=lambda p:p.read_text(encoding="utf-8")
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix==".py": compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,v): emit(p,json.dumps(v,indent=2)+"\n")

index=load(lab/"identity.json")
assert index["reference"].startswith("54b909bb1") and index["candidate"] != index["reference"]
old=load(template/"config.json")
profile=load(donor/"config.json")
receipt=load(donor/"archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert receipt["archiveSHA256"]==sha(donor/"observations.tgz")
reference=profile["identity"]["imageFiles"]["candidate"]
images=index["imageFiles"]
core="Lokad.Lython.dll"
assert reference==images["reference"]
assert [name for name in reference if reference[name]!=images["candidate"][name]]==[core]
assert len(reference)==32 and old["protocolSHA256"]==index["pythonWorkerSHA256"]
manifest=lab/"representative.json"
for role,files in images.items():
    assert {n:sha(lab/"frozen"/role/n) for n in files}==files
    check=load(lab/f"{role}-verify.json")
    assert check["state"]=="Completed" and check["catalogSha256"]==index["catalogSHA256"]==sha(manifest)
jobs=[('scripts.csv-restock-export.ordinary', 'warm'), ('scripts.csv-restock-export.escaped', 'warm'), ('scripts.csv-restock-export.short', 'warm'), ('scripts.csv-invoice.large', 'warm')]
assert all(case in {row["id"] for row in load(manifest)["cases"]} for case,_ in jobs)
root="/home/lokad/lython-bench-checks/bulk-csv-field-output-b1277-20261121"
unit="lython-b1277-bulk-csv-field-output-20261121"
q.mkdir()
identity=dict(sourceRevision=index["reference"]+" versus "+index["candidate"],
              purpose="Use prepared CSV dialect and admitted bulk field output",
              imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=index["catalogSHA256"],
              coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")})
save(q/"identity.json",identity)
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    s=read(template/name).replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        begin=s.index("\njobs = ")
        end=s.index("\nassert len(jobs)",begin)
        s=s[:begin]+"\njobs = "+repr(jobs)+s[end:]
    s=s.replace("len(jobs)==3", "len(jobs)==4").replace("len(raw['jobs'])==3", "len(raw['jobs'])==4").replace("jobs=3,elapsedSeconds", "jobs=4,elapsedSeconds")
    if name == "collect.py": s=s.replace("accumulate 16 seconds","accumulate 8 seconds").replace("warmupSeconds=16, targetBatchSeconds=.8", "warmupSeconds=8, targetBatchSeconds=.65").replace("min(warmed)<16", "min(warmed)<8").replace("warmed[i]>=16", "warmed[i]>=8").replace("counts[i]*.8", "counts[i]*.65")
    if name == "retrieve.py": s=s.replace("status['receipt']['jobs']==3", "status['receipt']['jobs']==4")
    emit(q/name,s)
assert b"\r" not in (q/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
for role in ("candidate",):
    (q/role).mkdir()
    shutil.copyfile(lab/"frozen"/role/core,q/role/core)
shutil.copyfile(manifest,q/"representative.json")
payload=q/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in parts: out.add(q/name,arcname=name)
config=dict(root=root,unit=unit,identity=identity,source=profile["root"],sourceRole="candidate",
            sourceFiles=reference,sourceCatalogSHA256=profile["catalogSHA256"],
            donorArchiveSHA256=receipt["archiveSHA256"],catalogSHA256=identity["catalogSHA256"],retireGroups=load(lab/"reclaim-proof.json"),
            protocolSource=old["root"]+"/cpython-worker.py",protocolSHA256=index["pythonWorkerSHA256"],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((q/n).stat().st_size for n in parts))
save(q/"config.json",config)
s=read(template/"remote-launch.py")
start=s.index("\nc=")+1
end=s.index("\nb=Path(",start)
s=s[:start]+"c="+repr(config)+s[end:]
s=s.replace("lython-b1260-fixtures","lython-b1277-fixtures")
s=s.replace("c['unpackedBytes']+16*1024*1024", "c['unpackedBytes']+8*1024*1024")
emit(q/"remote-launch.py",s)
launch=read(template.parent/"launch.py").replace("Expanded builtin span comparison","CSV field output comparison").replace("305","245")
emit(lab/"launch.py",launch)
s=read(template.parent/"summarize.py").replace("len(raw['jobs'])==3", "len(raw['jobs'])==4")
emit(lab/"summarize.py",s)
