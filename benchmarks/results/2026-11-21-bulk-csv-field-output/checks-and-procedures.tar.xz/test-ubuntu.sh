set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bulk-csv-field-output
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Csv|FullyQualifiedName~Text|FullyQualifiedName~Format|FullyQualifiedName~Governor)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Csv|FullyQualifiedName~TextFile|FullyQualifiedName~PendingOutput|FullyQualifiedName~FormatOwnership|FullyQualifiedName~JsonDictionaryCallback)&Category!=Stress' | tee "$logs/public-ubuntu.log"
