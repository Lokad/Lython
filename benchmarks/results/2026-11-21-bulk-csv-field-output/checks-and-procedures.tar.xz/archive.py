from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/"quiet"
out=Path("benchmarks/results/2026-11-21-bulk-csv-field-output")
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=load(lab/"identity.json")
for role,files in identity["imageFiles"].items():
    assert len(files)==32 and {name:sha(lab/"frozen"/role/name) for name in files}==files
    verification=load(lab/f"{role}-verify.json")
    assert verification["state"]=="Completed" and verification["caseCount"]==4
    for mode in ("sync","async"):
        rows=[json.loads(line) for line in (lab/f"probe-{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(rows)==41 and all(r["Compared"] and r["Matches"] and r["Lython"]["Success"] and r["CPython"]["Success"] for r in rows), list(rows[0])
assert identity["catalogSHA256"]==sha(lab/"representative.json")
assert len(load(lab/"allocation-summary.json"))==4 and all(r["budgetReturnedToBaseline"] for r in load(lab/"allocation-summary.json"))
for platform in ("windows","ubuntu"):
    for suite,count in (("white",680),("public",438)):
        log=(lab/f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert f"Passed:   {count}, Skipped:" in log, (suite,platform)
receipt=load(quiet/"archive-receipt.json")
terminal=load(quiet/"terminal-status.json")
assert terminal["exitCode"]=="0" and terminal["receipt"]==receipt and not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease","quietBeforeAndAfter"))
assert sha(quiet/"observations.tgz")==receipt["archiveSHA256"]
staged=load(quiet/"identity.json")
assert staged["imageFiles"]==identity["imageFiles"] and staged["catalogSHA256"]==identity["catalogSHA256"]
raw=load(quiet/"retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"]==8 and raw["targetBatchSeconds"]==.65
cases={c["id"]:c for c in load(lab/"representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"])==receipt["jobs"]==len(cases)==4
assert {j["case"] for j in raw["jobs"]}==set(cases)
for job in raw["jobs"]:
    case=cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and job["lane"]=="warm" and len(job["samples"])==28
    for sample in job["samples"]:
        response=sample["response"]
        assert response["completedInvocations"]>0 and response["status"]=="Completed"
        assert response["sourceSha256"]==case["sourceSha256"] and response["fixtureSha256"]==case["fixtureSha256"]
        assert response["actualOutputSha256"]==case["expectedOutputSha256"] and response.get("actualFilesSha256")==case.get("expectedFilesSha256")
summary=load(quiet/"quiet-summary.json")
summary.update(collection="B1277",reference=identity["reference"],referenceImageSource=identity["referenceImageSource"],
               candidate=identity["candidate"],verifiedTimedBatches=112,coreSHA256=staged["coreSHA256"],archiveSHA256=receipt["archiveSHA256"])
out.mkdir(exist_ok=True)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
shutil.copyfile(lab/"allocation-summary.json",out/"allocation-summary.json")
for name in ("archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(quiet/name,out/name)
for role in ("reference","candidate"):
    core=lab/"frozen"/role/"Lokad.Lython.dll"
    target=out/(role+"-core.dll.gz")
    assert sha(core)==identity["imageFiles"][role]["Lokad.Lython.dll"]
    target.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert gzip.decompress(target.read_bytes())==core.read_bytes()
(lab/"measured-source.patch").write_bytes(subprocess.check_output(["git","diff",identity["reference"],identity["candidate"],"--","src","tests"]))
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz",preset=6) as tar:
    for folder in (lab,quiet):
        for file in sorted(folder.iterdir()):
            if file.is_file() and file.suffix not in {".tgz"}:
                tar.add(file,arcname=file.relative_to(lab).as_posix())
print("112 warm batches, every output digest and every frozen worker file verified.")
