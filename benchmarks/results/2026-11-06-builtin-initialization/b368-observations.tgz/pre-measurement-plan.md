# Lokad.Lython 0.11.0

Updated 2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
One experiment, allocation reduction or delivery checkpoint does not complete it.

## Actual status

- **Committed/pushed:** runtime4fad63c5 (R21 frame boundaries), evidence799895ea,
  private dev46 qualification6b8748e6, current CPython/preflight correctiona4a1c306.
  No active runtime prototype. New delivery CI42306860444 started22:44UTC on
  a4a1c306: Windows/Ubuntu, actual11/10, original Stress and installed consumers.
  Observe minutes apart while independent source work continues; no publication.
  R20 f2ce53db/1fdca591 delivery receipt90a00002 remains fully qualified.
- **Local qualification:** R21 focused790 internal/2,923 public and full ordinary
  Release4,274 internal/16,200 public per actual11/10, all pass. Explicit Release
  package installed consumers pass both; artifacts/nuget/ only, core zero runtime
  dependencies, optional adapter nonpackable. No unchanged local-suite rerun.
- **Previous fully qualified:** runtime f2ce53db, evidence head1fdca591; GREEN42294911136:
  Windows/Ubuntu, actual11/10, original Stress and installed consumers. Exact
  head/all eight delivery gates verified and cached in R20 evidence/delivery-ci.json;
  terminal, never query again. No unchanged qualification repeat.
- **R21 delivery partial:** terminal CI42302690579 on799895ea. Windows all four
  gates GREEN (ordinary11/10, installed consumers, original Stress); Ubuntu11
  GREEN, Ubuntu10 one discovery-test failure, downstream gates skipped. Preserve
 168736B/131072B failure/log. The assertion measured exception construction after
  refused admission. Use existing first-refusal observation, same limit/origin/
  final zero-balance checks.23focused admission/cleanup checks pass per actual11/10.
  Correction committed; updated platform/Stress/package delivery above; do not
  repeat benchmark collection or full local ordinary suite for this test-only fix.
  Terminal run cached; never query again. Runtime remains locally qualified only.
- **Previous fully qualified:** b542b601 U04, GREEN42279409059; earlier b6650f09
  GREEN42258608463. Cached delivery-ci.json in their evidence; never query again.
- **Unresolved:** possible text regression after R20, coarse adverse CSV CPU,
  warm-text gap to CPython, startup/suspended-I/O/RSS/embedding-tail costs, and
  the precise producer capabilities below. None stops core development.

Historical plans/snapshots/raw handoffs: .git/agent-notes/review-20261031/;
full pre-condensation plan in record-layout-r20/PLAN-before-delivery-condense.md.
Immutable evidence under benchmarks/results/; index benchmarks/EXPERIMENTS.md.
docs/ describes current implementation only, without experimental narratives.

## Completed milestones and measurement decisions

- Shared compiler facts, direct UTF8 formatting/storage, native helper returns,
  R13C/R14 provenance, R17 text provenance and P01 number formats are delivered.
  Preserve K01/F02–F05/Q01/Q02/R02–R14, final call/local slots, executable imports/
  lambdas, immutable builtin metadata, native functions and genuine suspension.
- Native returns: allocation−19.92/−19.31% established, elapsed diagnostic.
  Formatting: allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention.
  Original adverse15.125ms remains unexplained and preserved. Do not retime these
  completed questions or transfer their percentages to current HEAD.
- R17 retains allocation savings with measured text+1.6–2.2% debt. R18 shared
  targets withdrawn after two source pairs; mixed JSON/text/CSV results did not
  justify extra branches. B61/B69 call-arena/control slower designs remain lessons.
- U04 replaces match carriers/per-success arrays with caller spans; retained
  matches own ranges and copy groups on access, add regs. Direct cursor allocation
  −20.34% is separate from complete extraction warm−3.62–5.17%/fresh−4.58–6.40%.
  Fully qualified b542b601; no old API/stubs. Evidence2026-11-06-regex-capture-ownership.
- R19: current text/report CPU sample,14.41s guest. Prefix including inlined work
  20.64% text; ordinary calls/binding under2%; report JSON reading11.92%. These are
  leaf shares, not dispatch-only cost or predicted savings. No new capture planned.
- **R20 retained:** canonical keys/values split, shared JSON/CSV metadata, sets omit
  value storage. Delete coupled entries and separate sorted JSON hint/comparer/
  matched flags. Keep real protocol snapshots and namespace bridge. Existing owner
  funds frozen keys; rows fund independent actual values capacity. Delete/clear
  needs no metadata allocation; insert first admits private replacement. Preserve
  aliases, reentrant mutation and a real cancellation-after-admission correction.
  Conservative rejection/retained layouts/sparse scans are explicit tradeoffs.
  Complete-job allocation: CSV−12.73/−11.57%, JSON−14.99/−14.98%, report−9.43/−9.43%
  sync/async; text/scalar controls flat. Separate quiet B361: JSON warm−10.89–12.53%,
  report warm−5.36–8.80%/fresh−8.53–10.52%. CSV elapsed−1.22–2.46%, CPU adverse.
  Text B361+5.01/−0.53% with5.28% identical-build spread; B362 confirmation+0.90/
  −1.21%, then+2.73/+5.53%, CPU adverse in second block. **Possible text regression
  is accepted debt**, not parity or an all-workload speedup. Retain for coherent
  record/storage gains; prioritize text next. No more retiming scheduled for R20.
  Evidence2026-11-06-record-layout includes every failure/partial/adverse condition.
  B359–B362 terminal; never query their services again.

Primary external baseline is now B367/4fad63c5, complete312.23s/all gates:
fresh CSV1.25–1.26x,text1.77–1.79x,JSON1.08–1.11x,report1.50–1.53x,
config1.21–1.22x CPython. Warm:1.31–1.32/1.88–1.90/1.08–1.09/1.32–1.37/
1.28–1.29x. Compile44–73us separately. JSON fresh2.13%role spread/report warm
3.47%spread/3.95%IQR remain variable. Includes mediated RAM I/O, validation and
prior-result cleanup; excludes startup/staging/final teardown. No causal per-change
gain or inferred cost from subtracting medians. Earlier B352/b665 and adverse
source pairs remain linked; the primary guide does not claim HEAD qualification.
Evidence benchmarks/results/2026-11-06-current-cpython/. B367 terminal, never query.

## Priority 1 — current complete-script checkpoint, then evidenced redesign

**R21 retained/committed, updated delivery pending:** route pending child/generator errors
at driver resumption after operand cleanup, retain delegate forwarding, derive
completed returns from nonnull ReturnValue and delete HasReturn/per-instruction
signal polling. Keep current instruction spans, disposal order and every guard.
No new dispatcher/option/cache. Full ordinary actual11/10 and installed consumers
pass; combined platform/Stress checkpoint above is running. Evidence:
benchmarks/results/2026-11-06-frame-resume-boundaries/.

Controlled B366 completes108.57s/all gates: warm text−3.00–5.59%, fresh−0.79% to
+0.02%, report/CSV small; unchanged compilation also−1.47–2.23%, allocation flat.
Modest warm evidence, no general CPU gain or closure of R20 text debt. Source gate
reuses flat storage/call facts; thirteen executed word-loop instructions plus two
cleanup stores, native words helper already3nodes. All source/profile/preflight/
parser failure history is behind that evidence link. B363–B366 terminal; never
query their services again or automatically recapture the limited profile.

**B367 complete:** primary docs refreshed from the actual frozen source. All15
existing jobs/goldens, terminal balances, quiet endpoints, joined users, fixture
cleanup and under-lease archive SHA pass. No retiming scheduled without a new
question; report CPython fresh below warm is preserved as separate job evidence.

**R22 active — canonical builtin initialization.** Source gate rejects another
CSV input-copy/bulk-admission design: those are delivered. CSV writer scalar
decoding is real, but ordinary summary writes too few rows to establish dominance.
Public projection already exports only the return value/output; no globals copy.
String windows still add the same8B/object relative to the current smaller shell;
there is no materially different cost model to justify reviving them now.

Select initialization for short config/edit/helper scripts: current source still
rebuilds fixed plain callables, parameter-name arrays and interned-signature lookups
under locks on each invocation. A current reflected factory diagnostic allocates
13,064B/table and observes roughly7–10us on the desktop. This does not establish a
quiet-VM share or a speedup. Current whole config warm78us/fresh150us makes one
bounded comparison justified; larger scripts are controls, not promised winners.

Hypothesis/work eliminated: one fixed plain-function catalog; construct immutable
signatures once, including those borrowed by fresh type wrappers. Remove repeated
plain wrapper construction and signature interning/parameter-array packaging
from CreateBuiltinVariables, consolidating the existing partial sharing. Preserve
run-private object/type/exception graphs, namespaces, type caches and all mutations;
plain callables resolve __self__ from the active caller and retain no run/token.
No type-graph cache, factory framework, new policy or ownership infrastructure.

Acceptance: builtin identity/introspection/signatures/keyword errors, rebinding,
type/exception isolation; sequential/concurrent/suspended runs with shared allowance,
retained results, cancellation, first refusal and zero balances after cleanup.
Extend existing externally observable isolation coverage rather than add layout
tests. Fixed application metadata remains the existing finite runtime catalog;
guest/cache/results remain funded by their real owners. No public API change.

Complete canonical initializer migration, then focused Release actual11/10 and
existing eight complete-job allocation diagnostics. One bounded quiet source pair:
small config warm/fresh, text warm, JSON compile control; normal GC/tiering,
reference/current/identical-current, existing worker/catalog,5s warmups/seven150ms
rounds, owner150s+30sstop. Report allocation separately from elapsed/processCPU.
Retain/revise/withdraw with explicit remaining debt; bounded confirmation only
for a specific uncertainty. No fixed-percent veto. Archive all failed conditions.
Do not repeat completed R21 local/platform qualification unless changed source
requires the next coherent delivery; CI42306860444 continues independently.

R22 design/history: .git/agent-notes/review-20261031/invocation-definitions-r22/.
Source gate is complete; implement this milestone without a broader audit. Then
resume the evidence-based roadmap. Neither this local result nor delivery alone
completes the whole-script performance objective; text debt remains explicit.

## Independent regex track

Core Python-specific UTF8/byte-range/scalar-window/flags/ownership/cancellation
work does not wait for a release. U04 works with normal0.4 and private immutable
dev44 bridge. The latter qualifies native high-water working admission and256KiB
bounded matching; prior peak32,880→2,064B, allocation+128B/cursor, diagnostic
elapsed+9.1% remain separate evidence. Normal0.4 pin remains unchanged.

**Development46 refresh:** immutable0.5.0-dev.46 inputs from package source
6957b35a independently copied/hash-verified. Existing U04/native-working bridge
source is byte-identical; documented member IDs unchanged from44 on both TFMs.
Private isolated builds and85internal/482public tests pass per actual11/10,
including cursor funding/refusal/reuse and actual cancellation. Normal source,
pin0.4, core dependency graph and adapter nonpackability hashes verified unchanged.
Evidence committed6b8748e6 at
benchmarks/results/2026-11-06-regex-dev46-compatibility/. No production promotion
or Lython performance claim from producer timings. Final released-package/safety
checks remain separate.

Final adapter capabilities still missing: DetailedData cannot choose Prepare's
independent working owner; keep conservative one-shot preflight. Native UTF8
lookup cannot enumerate names; keep adapter-local name conversion. Creation-token
coupling needs per-operation forwarding through actual work. Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges are allowed;
qualify the final immutable released package and managed-safety compliance when
available. No core dependency/type edges, dialect fallback, quotas or sibling edits.

## Working/measurement contract

Unstable controls, timeouts and inconclusive data establish uncertainty, not a
failed design. Allow bounded justified confirmation/refinement/correction; retain
original conditions and adverse data. Percentages inform decisions, not automatic
vetoes/permanent closures. Distinguish simplification, allocation, elapsed and CPU.
Refresh representative CPython at coherent checkpoints, separating compile/warm/
fresh and explicit I/O/cleanup; no another framework or10min development lanes.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host CancellationToken and borrowed shared admission/capacity/replacement/
escaping aliases. First refusal fails the command, no retry/recovery. No fuel,
quotas, hidden caps/default allowance, tracing, weak reclamation or forced GC.
Await all users/cleanup. Initial streaming uses bounded host executions; XML depth
constraint remains. Never fund a still-retained alias by refunding its owner.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch platform/actual11/10/original Stress/
installed consumers at coherent boundaries; don't repeat completed qualification.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: owned lease, actual Ready
hashes, manifest IDs/quiet/goldens/funding/joins and verified persistent archives.
No SSH during capture. Disk near full: verify real headroom and retire only exact
redundant copies with independent backups, ended users and dependency checks.
Keep executing after a delivery/experiment; publication/tagging remain postponed.
