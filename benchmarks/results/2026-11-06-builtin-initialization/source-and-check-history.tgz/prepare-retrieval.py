from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).parent
assert datetime.now(timezone.utc)>=datetime(2026,11,6,23,6,27,tzinfo=timezone.utc),'Do not observe before owner plus stop bound'
s=(root.parent/'delivery-comparison-b352/retrieve.py').read_text(encoding='utf-8')
s=s.replace('root=Path(__file__).parent',"root=Path(__file__).resolve().parent/'b368'")
s=s.replace('delivery-comparison-b352','builtin-definitions-b368').replace('lython-b352-delivery-comparison','lython-b368-builtin-definitions')
s=s.replace("['jobs']==15","['jobs']==4")
(root/'retrieve-comparison.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'retrieve-comparison.py'),'exec'),{'__file__':str(root/'retrieve-comparison.py'),'__name__':'__main__'})
