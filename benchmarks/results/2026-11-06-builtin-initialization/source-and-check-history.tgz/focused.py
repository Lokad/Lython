from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
families=['Builtin','Callable','Function','TypeRecognition','TypeHierarchy','HostGrant','GovernedMemory','Cancellation','HashQueryOwnership','NativeDictionaryMutation','Constructor','ExceptionOwnership']
selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+f for f in families)+')'
checks={};commands=[('build',[env['DOTNET_HOST_PATH'],'build','Lokad.Lython.slnx','-c','Release','--no-restore','--nologo','--tl:off'])]
for tfm in ['net11.0','net10.0']:
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        commands.append((suite+'-'+tfm,[env['DOTNET_HOST_PATH'],'test',f'tests/{suite}/{suite}.csproj','-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off','--filter',selection]))
for name,cmd in commands:
    log=root/('focused-'+name+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8') as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
    content=log.read_text(encoding='utf-8');print(name,p.returncode,content[-1300:],flush=True)
    checks[name]={'exitCode':p.returncode,'summaries':re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',content)}
    (root/'focused-results.json').write_text(json.dumps({'checks':checks,'selection':selection},indent=2)+'\n',encoding='utf-8')
    if p.returncode:sys.exit(p.returncode)
result={'checks':checks,'selection':selection,'coreSHA256':{tfm:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']}}
(root/'focused-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
