from pathlib import Path
import json,statistics
root=Path(__file__).parent;rows=[]
for api in ['sync','async']:
    data=json.loads((root/'allocation'/api/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for case in data['observations']:
        med={role:statistics.median(s['allocatedBytes']/s['jobs'] for s in case['samples'] if s['image']==role) for role in ['before','candidate','before-control']}
        row=dict(api=api,case=case['caseId'],allocatedBytesPerJob=med,candidateChangePercent=100*(med['candidate']/med['before']-1),admittedPeaks=case['admittedPeaks']);rows.append(row)
        print(api,row['case'],round(row['candidateChangePercent'],3),'%',round(med['candidate']-med['before'],2),'B/job',flush=True)
setup={}
for role in ['baseline','candidate']:
    data=json.loads((root/(role+'-setup.json')).read_text(encoding='utf-8'))
    setup[role]=dict(coreSHA256=data['coreSHA256'],allocatedBytesPerTable=statistics.median(v['allocatedBytes']/v['iterations'] for v in data['rows']),desktopMicroseconds=statistics.median(v['elapsedTicks']/data['clockFrequency']*1e6/v['iterations'] for v in data['rows']))
(root/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,setup=setup,limitations='Precise complete-job process allocation under isolated images sharing CoreLib/hash seed. Desktop clocks and reflected setup diagnostic are not whole-script CPU claims. Normal GC/tiering; no forced collections.'),indent=2)+'\n',encoding='utf-8')
print('Setup diagnostic',setup,flush=True)
