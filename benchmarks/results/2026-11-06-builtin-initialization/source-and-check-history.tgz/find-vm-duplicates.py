from pathlib import Path
import subprocess
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import collections,fcntl,hashlib,json,os,re,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 groups=collections.defaultdict(list);seen=set();count=0
 for folder in base.iterdir():
  match=re.search(r'-b(\\d+)-',folder.name)
  if not match or int(match[1])<300 or folder.is_symlink() or not folder.is_dir():continue
  for p in [folder/'Lokad.Lython.dll',folder/'candidate/Lokad.Lython.dll',folder/'reference/Lokad.Lython.dll']:
   if not p.is_file() or p.resolve()!=p.absolute():continue
   stat=p.stat();inode=(stat.st_dev,stat.st_ino)
   if inode in seen:continue
   seen.add(inode);count+=1
   groups[hashlib.sha256(p.read_bytes()).hexdigest()].append(dict(path=str(p),bytes=stat.st_size,inode=stat.st_ino))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,regularCoreFiles=count,duplicates={k:v for k,v in groups.items() if len(v)>1},mounts={str(p):dict(freeBytes=shutil.disk_usage(p).free,device=p.stat().st_dev) for p in [base,Path('/mnt'),Path('/tmp')]}),indent=2))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,capture_output=True,text=True,encoding='utf-8')
(root/'duplicate-inventory.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr;print(r.stdout,flush=True)
