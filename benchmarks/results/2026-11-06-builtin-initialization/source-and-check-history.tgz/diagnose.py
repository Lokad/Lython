from pathlib import Path
import json,os,statistics,subprocess
root=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (root/'build-diagnostic.log').open('w',encoding='utf-8') as out:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(root/'SetupDiagnostic.csproj'),'-c','Release','--nologo','--tl:off'],env=env,stdout=out,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/'build-diagnostic.log').read_text(encoding='utf-8')[-2000:]
core=root.parent/'text-operands-r21/b366/Lokad.Lython.dll'
p=subprocess.run([env['DOTNET_HOST_PATH'],str(root/'bin/Release/net11.0/SetupDiagnostic.dll'),str(core),str(root/'baseline-setup.json')],env=env,capture_output=True,text=True,encoding='utf-8')
assert p.returncode==0,p.stdout+p.stderr
r=json.loads((root/'baseline-setup.json').read_text(encoding='utf-8'))
print('table median microseconds',statistics.median(v['elapsedTicks']/r['clockFrequency']*1e6/v['iterations'] for v in r['rows']),'allocated bytes/table',statistics.median(v['allocatedBytes']/v['iterations'] for v in r['rows']),flush=True)
