from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home/'b368';root.mkdir()
old=home.parent/'text-operands-r21/b366';prior='/home/lokad/lython-bench-checks/resume-boundary-b366-20261106';remote='/home/lokad/lython-bench-checks/builtin-definitions-b368-20261106'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,s):
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
baseline=json.loads((home/'baseline.json').read_text(encoding='utf-8'));priorid=json.loads((old/'identity.json').read_text(encoding='utf-8'))
assert baseline['sourceSHA256']==priorid['sourceSHA256'],'Reference binary must match all current baseline production source'
checks=json.loads((home/'focused-results.json').read_text(encoding='utf-8'));core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert sha(core)==checks['coreSHA256']['net11.0']
identity=dict(sourceRevision='a4a1c306 plus R22 canonical builtin initialization',referenceSourceRevision='4fad63c5 runtime, frozen c3e65ad3; all production source hashes match a4a1c306 baseline',purpose='R22 three-role complete config warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh',qualification=checks,coreSHA256=dict(candidate=sha(core),control=sha(core),reference=priorid['coreSHA256']['candidate']),auxiliaryFiles=priorid['auxiliaryFiles'],sourceSHA256={str(p).replace('\\','/'):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)})
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/core.name);shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
write('contract.md','R22 consolidates plain builtin definitions and immutable constructor signatures; every run retains fresh mutable type/exception graphs and namespace. Existing metadata/catalog/host/worker, normal GC/tiering, reference/current/identical current. Four complete jobs: config warm/fresh, text warm, JSON compilation control.5s warmups and seven rotated150ms rounds. Admission, all goldens, terminal balances, Closed/joins, quiet gates and under-lease archive required. Includes mediated RAM I/O, full validation and prior-result cleanup; fresh adds compilation/program disposal. Startup/staging/final teardown excluded.150sowner+30sstop; no SSH before180s. Preserve adverse/drifting/missing evidence and original failures. Separate allocation from elapsed/coarse CPU. No fixed-percentage veto or automatic retiming.\n')
write('setup-contract.json',json.dumps(dict(reference=prior+'/candidate',roles=['candidate','reference','control'],ownerSeconds=150,stopSeconds=30,observeAfterSeconds=180,unaffectedControl='scripts.json-summary-helpers.large compile'),indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh']:
    s=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    s=s.replace("jobs=[('scripts.text-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','compile-run'),('scripts.report-render.large','warm'),('scripts.csv-summary-functions.large','warm'),('scripts.json-summary-helpers.large','compile')]","jobs=[('scripts.config-edit.small','warm'),('scripts.config-edit.small','compile-run'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','compile')]")
    s=s.replace('len(jobs)==5','len(jobs)==4').replace("len(r['jobs'])==5","len(r['jobs'])==4").replace('jobs=5','jobs=4').replace(' < 130',' < 110')
    s=s.replace('R21 three-role source pair; complete text warm/fresh, report/CSV warm and JSON compile control; not a new CPython baseline',identity['purpose'])
    write(name,s)
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['Lokad.Lython.dll','identity.json','pre-measurement-plan.md','source.patch','contract.md','setup-contract.json','collect.py','archive-owned.py','run.sh']:a.add(root/name,arcname=name)
data=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');prior=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['representative.json','cpython-worker.py']:(root/name).symlink_to(prior/name)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for p in (prior/'candidate').iterdir():
  if p.suffix=='.pdb':continue
  if p.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(p,folder/p.name)
  else:(folder/p.name).symlink_to(root/p.name if p.name=='Lokad.Lython.dll' else p.resolve(),target_is_directory=p.is_dir())
 identity=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.config-edit.small','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allFourCatalogJobsValidated=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b368-builtin-definitions-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
write('launch.py',script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b368-launch.py'],capture_output=True);assert p.returncode==0,p.stderr
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b368-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8');print((p.stdout+p.stderr).decode('utf-8'),flush=True)
