from pathlib import Path
root=Path(__file__).parent
s=(root.parent/'record-layout-r20/measure-allocation.py').read_text(encoding='utf-8')
s=s.replace("['coreSHA256']['net11.0']","['net11.0']",1)
s=s.replace("checks['checks']['net11.0']['coreSHA256']","checks['coreSHA256']['net11.0']")
(root/'measure-allocation.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'measure-allocation.py'),'exec'),{'__file__':str(root/'measure-allocation.py'),'__name__':'__main__'})
