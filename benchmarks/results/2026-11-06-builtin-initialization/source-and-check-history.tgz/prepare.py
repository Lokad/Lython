from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent;repo=Path('D:/code/Lython')
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtimeSource':'4fad63c5','sourceSHA256':{}}
with tarfile.open(root/'baseline-source.tgz','w:gz') as archive:
    for p in (repo/'src/Lokad.Lython').rglob('*.cs'):
        if {'bin','obj'}.intersection(p.parts):continue
        key=str(p.relative_to(repo)).replace('\\','/');identity['sourceSHA256'][key]=hashlib.sha256(p.read_bytes()).hexdigest();archive.add(p,arcname=key)
shutil.copyfile(repo/'PLAN.md',root/'PLAN-before-R22.md')
for tfm in ['net11.0','net10.0']:
    dest=root/'baseline'/tfm;dest.mkdir(parents=True)
    core=repo/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll';shutil.copyfile(core,dest/core.name)
    identity[tfm]=hashlib.sha256(core.read_bytes()).hexdigest()
(root/'baseline.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');start=s.index('**R22 next source gate:**');end=s.index('## Independent regex track',start)
s=s[:start]+'''**R22 active — canonical builtin initialization.** Source gate rejects another
CSV input-copy/bulk-admission design: those are delivered. CSV writer scalar
decoding is real, but ordinary summary writes too few rows to establish dominance.
Public projection already exports only the return value/output; no globals copy.
String windows still add the same8B/object relative to the current smaller shell;
there is no materially different cost model to justify reviving them now.

Select initialization for short config/edit/helper scripts: current source still
rebuilds fixed plain callables, parameter-name arrays and interned-signature lookups
under locks on each invocation. A current reflected factory diagnostic allocates
13,064B/table and observes roughly7–10us on the desktop. This does not establish a
quiet-VM share or a speedup. Current whole config warm78us/fresh150us makes one
bounded comparison justified; larger scripts are controls, not promised winners.

Hypothesis/work eliminated: one fixed plain-function catalog; construct immutable
signatures once, including those borrowed by fresh type wrappers. Remove repeated
plain wrapper construction and signature interning/parameter-array packaging
from CreateBuiltinVariables, consolidating the existing partial sharing. Preserve
run-private object/type/exception graphs, namespaces, type caches and all mutations;
plain callables resolve __self__ from the active caller and retain no run/token.
No type-graph cache, factory framework, new policy or ownership infrastructure.

Acceptance: builtin identity/introspection/signatures/keyword errors, rebinding,
type/exception isolation; sequential/concurrent/suspended runs with shared allowance,
retained results, cancellation, first refusal and zero balances after cleanup.
Extend existing externally observable isolation coverage rather than add layout
tests. Fixed application metadata remains the existing finite runtime catalog;
guest/cache/results remain funded by their real owners. No public API change.

Complete canonical initializer migration, then focused Release actual11/10 and
existing eight complete-job allocation diagnostics. One bounded quiet source pair:
small config warm/fresh, text warm, JSON compile control; normal GC/tiering,
reference/current/identical-current, existing worker/catalog,5s warmups/seven150ms
rounds, owner150s+30sstop. Report allocation separately from elapsed/processCPU.
Retain/revise/withdraw with explicit remaining debt; bounded confirmation only
for a specific uncertainty. No fixed-percent veto. Archive all failed conditions.
Do not repeat completed R21 local/platform qualification unless changed source
requires the next coherent delivery; CI42306860444 continues independently.

R22 design/history: .git/agent-notes/review-20261031/invocation-definitions-r22/.
Source gate is complete; implement this milestone without a broader audit. Then
resume the evidence-based roadmap. Neither this local result nor delivery alone
completes the whole-script performance objective; text debt remains explicit.

''' +s[end:];p.write_text(s,encoding='utf-8')
print('Frozen baseline',identity['head'],identity['net11.0'],identity['net10.0'],flush=True)
