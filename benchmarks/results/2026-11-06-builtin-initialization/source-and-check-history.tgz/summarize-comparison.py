from pathlib import Path
root=Path(__file__).parent
s=(root.parent/'text-operands-r21/summarize-comparison.py').read_text(encoding='utf-8')
s=s[:s.index("a=json.loads")].replace('b366/retrieved/confirmation','b368/retrieved/confirmation')
(root/'comparison-derivation.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'comparison-derivation.py'),'exec'),{'__file__':str(root/'comparison-derivation.py'),'__name__':'__main__'})
