from pathlib import Path
import re
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.ExecutionContext.Builtins.cs');s=p.read_text(encoding='utf-8')
assert s.count('private static readonly BuiltinCallable Shared')==15
shared=dict(re.findall(r'private static readonly BuiltinCallable (Shared\w+) = (.*);',s))
lines=s[s.index('var builtins = new Dictionary'):].splitlines()
entries=[]
for line in lines:
    m=re.fullmatch(r'\s*\["([^"]+)"\] = (.*),',line)
    if m:entries.append((m.group(1),m.group(2)))
assert len(entries)==104,len(entries)
plain=set('open print input repr ascii format len sorted any all min max sum abs pow round divmod bin oct hex chr ord callable hash id isinstance issubclass getattr hasattr setattr delattr dir vars globals locals next iter'.split())
types=set('range enumerate reversed map filter slice bool int float bytes staticmethod classmethod property super list tuple set'.split())
assert plain|types <= {name for name,_ in entries}
def arguments(expr):
    result=[];start=0;level=0;quoted=False;escape=False
    for i,c in enumerate(expr):
        if quoted:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c=='"':quoted=False
        elif c=='"':quoted=True
        elif c in '([{':level+=1
        elif c in ')]}':level-=1
        elif c==',' and level==0:result.append(expr[start:i].strip());start=i+1
    result.append(expr[start:].strip());return result
type_defs=[];replacements={}
for name,expr in entries:
    if name not in types:continue
    assert expr.startswith('BuiltinCallable.Create(') and expr.endswith(')')
    args=arguments(expr[len('BuiltinCallable.Create('):-1]);first=args.pop(0)
    if first in ['IntSignature','FloatSignature']:
        first=re.search(r'private static readonly LythonCallableSignature '+first+r'\s*= (.*);',s).group(1)
    if first.startswith('LythonCallableSignature.Create('):signature=first;impl=args
    else:
        impl=[arg for arg in args if not arg.startswith('[') and ':' not in arg]
        metadata=[arg for arg in args if arg not in impl]
        signature='LythonCallableSignature.Create('+', '.join([first]+metadata)+')'
    field=name[0].upper()+name[1:];type_defs.append('            internal static readonly LythonCallableSignature '+field+' = '+signature+';')
    replacements[name]='BuiltinCallable.Create(BuiltinTypeSignatures.'+field+', '+', '.join(impl)+')'
catalog=[]
for name,expr in entries:
    if name not in plain:continue
    expr=shared.get(expr,expr) if name not in ['len','abs','sum'] else expr
    catalog.append('            ("'+name+'", '+expr+'),')
header='''        // Plain functions retain no run state. Their __self__ comes from the
        // active caller; mutable types and their caches are constructed per run.
'''
for key in ['SharedLen','SharedAbs','SharedSum']:header+='        private static readonly BuiltinCallable '+key+' = '+shared[key]+';\n'
header+='\n        private static readonly (string Name, object Value)[] SharedFunctions =\n        [\n'+'\n'.join(catalog)+'\n        ];\n\n'
header+='''        // Signature interning may lock and package parameter arrays. Do it once
        // for immutable constructor metadata, independently of each fresh type.
        private static class BuiltinTypeSignatures
        {
'''+ '\n'.join(type_defs)+'\n        }\n\n'
start=s.index('        private static readonly LythonCallableSignature IntSignature');end=s.index('        internal static bool IsLengthBuiltin',start)
s=s[:start]+header+s[end:]
for name,expr in entries:
    original='                ["'+name+'"] = '+expr+',\n'
    assert original in s,name
    if name in plain:s=s.replace(original,'',1)
    elif name in replacements:s=s.replace(original,'                ["'+name+'"] = '+replacements[name]+',\n',1)
s=s.replace('            return builtins;','            foreach (var (name, value) in SharedFunctions) builtins.Add(name, value);\n            return builtins;')
p.write_text(s,encoding='utf-8')
q=Path('tests/Lokad.Lython.PublicApi.Tests/BuiltinDefinitionIsolationTests.cs');s=q.read_text(encoding='utf-8')
old="['len', 'repr', 'ascii', 'abs', 'pow', 'round', 'divmod', 'bin', 'oct', 'hex', 'chr', 'ord', 'format', 'sorted']"
names=[name for name,_ in entries if name in plain-{'open','print','min','max'}]
assert old in s;s=s.replace(old,str(names));q.write_text(s,encoding='utf-8')
print('Moved',len(catalog),'plain definitions and',len(type_defs),'constructor signatures; expanded isolation coverage to',len(names),'functions',flush=True)
