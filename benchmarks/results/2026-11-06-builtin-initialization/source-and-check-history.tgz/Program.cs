using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// Private attribution diagnostic. No guest work, GC calls or runtime edits.
var file = Path.GetFullPath(args[0]);
var output = Path.GetFullPath(args[1]);
if (File.Exists(output)) throw new IOException("Preserve original observations.");
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(file);
var context = assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var factory = context.GetMethod("CreateBuiltinVariables", BindingFlags.NonPublic | BindingFlags.Static)!;
for (var warm = 0; warm < 512; warm++) GC.KeepAlive(factory.Invoke(null, null));
var rows = new List<object>();
for (var batch = 0; batch < 7; batch++)
{
    var allocation = GC.GetAllocatedBytesForCurrentThread();
    var start = Stopwatch.GetTimestamp();
    for (var item = 0; item < 1024; item++) GC.KeepAlive(factory.Invoke(null, null));
    rows.Add(new { batch, iterations = 1024,
        elapsedTicks = Stopwatch.GetTimestamp() - start,
        allocatedBytes = GC.GetAllocatedBytesForCurrentThread() - allocation });
}
File.WriteAllText(output, JsonSerializer.Serialize(new { source = "a4a1c306/4fad63c5 runtime",
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))),
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    clockFrequency = Stopwatch.Frequency, rows,
    boundary = "Reflected builtin-table construction only; warm desktop diagnostic, not whole-script or CPU attribution",
    forcedCollections = false }, new JsonSerializerOptions { WriteIndented = true }));
