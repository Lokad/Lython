from pathlib import Path
import subprocess
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 payloads=[dict(path=str(p),bytes=p.stat().st_size) for p in base.glob('*/payload.tgz')]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,recentPayloads=[p for p in payloads if any(x in p['path'] for x in ['b359','b360','b361','b362','b366'])]),indent=2))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,capture_output=True,text=True,encoding='utf-8')
(root/'inventory-vm.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr;print(r.stdout,flush=True)
