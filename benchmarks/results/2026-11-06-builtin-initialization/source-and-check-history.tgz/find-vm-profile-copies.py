from pathlib import Path
import subprocess
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 profiles=[]
 for pattern in ['*/perf/*/perf.data','*/profile/perf.data','*/perf.data']:
  for p in base.glob(pattern):
   if p.is_file() and p.resolve()==p.absolute():profiles.append(dict(path=str(p),bytes=p.stat().st_size))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,profiles=sorted(profiles,key=lambda p:p['bytes'],reverse=True)[:12]),indent=2))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,capture_output=True,text=True,encoding='utf-8')
(root/'profile-copy-inventory.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr;print(r.stdout,flush=True)
