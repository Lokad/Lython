from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).parent; quiet=lab/'comparison/quiet'; external=lab.with_name('tagged-default-ownership-20261125')/'comparison/quiet'; donor=lab.with_name('zip-unpack-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,indent=2)+'\n')
identity=read(quiet/'identity.json'); before=read(external/'identity.json')
assert identity['sourceRevision'].startswith('c1984f96b') and identity['imageFiles']['reference']==before['imageFiles']['candidate']
for role,files in identity['imageFiles'].items():assert {p.name:sha(p)for p in (lab/role).iterdir()}==files
terminal=read(external/'terminal-status.json'); assert terminal['exitCode']=='0' and terminal['receipt']['complete'] and sha(external/'observations.tar.xz')==terminal['receipt']['archiveSHA256']
rules='scripts.rule-default-closures'; eager='scripts.annotated-rule-closures'; post='scripts.annotated-rule-closures.nested-factories.postponed'; plain='diagnostic.generated-ordinary-definitions'; invoice='scripts.csv-invoice.method-policy.quoted-control'
save(quiet/'jobs.json',dict(warm=[[plain,'warm'],['scripts.ordinary-fully-supplied-helper.local-function','warm'],[rules,'warm'],[eager,'warm'],[rules,'compile-run'],[post,'warm'],[invoice,'warm'],['diagnostic.shipment-routing-callbacks','warm-async']]))
identity['catalogs']['jobs.json']=dict(sha256=sha(quiet/'jobs.json'));save(quiet/'identity.json',identity)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh');assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('targetBatchSeconds=.63','targetBatchSeconds=.72').replace('len(jobs) == 5','len(jobs) == 8').replace('time.sleep(12)  # Outside clocks','time.sleep(20)  # Outside clocks').replace('b1665-fixtures','b1683-fixtures')
compile(collector,'collect.py','exec');write(quiet/'collect.py',collector)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
 for n in ['identity.json','jobs.json','representative.json','run.sh','collect.py']:bundle.add(quiet/n,arcname=n)
 bundle.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='borrowed-call-window-b1683-20261125',reference='tagged-default-ownership-b1682-20261125',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launcher=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1665','b1683').replace('lython-b1682-zip-unpack','lython-b1683-borrowed-call-window')
launcher=launcher.replace('683fcdfa4dbd7f3c12ffadc461698d86584d2a4fce926626a9c7f08954bef52b',terminal['receipt']['archiveSHA256']).replace('seconds=241','seconds=380').replace('RuntimeMaxSec=305','RuntimeMaxSec=430')
compile(launcher,'quiet.py','exec');write(lab/'quiet.py',launcher)
report=(donor/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-zip-unpack','2026-11-25-borrowed-call-window')
compile(report,'archive.py','exec');assert report

