def outer():
    value = ['old']
    def replace(new):
        nonlocal value
        class Holder:
            nonlocal value
            before = value
            value = new
            def read(self):
                return value
        return value, Holder.before, Holder()
    yield replace
    yield value

generator = outer()
replace = next(generator)
new = ['new']
observed, before, holder = replace(new)
last = next(generator)
generator.close()
print(observed is new, before, last is new, holder.read() is new)
