from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-12-lexical-cell-storage-withdrawn')
out.mkdir(exist_ok=True)
summary = json.loads((r/'b641/summary.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['jobs'] == 5
assert json.loads((r/'b641/terminal-status.json').read_text(encoding='utf-8'))['exitCode'] == '0'
for framework in ['net11.0', 'net10.0']:
    for suite, count in [('internal',158),('public',61)]:
        text = (r/f'restored-{suite}-{framework}.log').read_text(encoding='utf-8')
        assert 'Failed:     0' in text and f'Passed:   {count:3}' in text, text
for name in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json','extraction.json']:
    shutil.copyfile(r/'b641'/name, out/name)
for name in ['restoration.json','candidate-identity.json','final-prototype.patch']:
    shutil.copyfile(r/name, out/name)
with tarfile.open(out/'diagnostics.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file() and p.suffix in ['.py','.md','.json','.patch','.log','.dll','.xz']:
            t.add(p,arcname=p.name)
    for folder in ['warm-sync','warm-async','compile','fresh']:
        t.add(r/folder,arcname=folder)
    for p in sorted((r/'tool').rglob('*')):
        if p.is_file() and not any(part in ['bin','obj'] for part in p.parts):
            t.add(p,arcname=str(p.relative_to(r)))
    for p in sorted((r/'b641').iterdir()):
        if p.is_file() and p.suffix in ['.py','.json','.log','.sh','.stdout','.stderr']:
            t.add(p,arcname='b641/'+p.name)
readme = '''# Lexical-cell storage prototype withdrawn — R284

2026-11-12. Qualified production **9bca1337**, frozen core **e4cc65b2**;
prototype over documentation commit632a867c, frozen core **c8bca168**. Not a
measurement of subsequent HEAD. No retained production change.

The prototype replaces each cell's value/owner/name with value-or-namespace/name,
explicitly promoting live cells when namespace mirroring starts. Cell construction
measures48→40B, but complete-script allocation is effectively flat (≤0.04%). It
adds promotion and live-storage checks, including suspended-frame handling.

**Withdraw it.** CSV Run is slower with supporting CPU; captured text supplies no
reliable whole-script benefit. The smaller cell does not justify the added
promotion machinery and measured cost. This is a source/measurement decision,
not a fixed percentage veto, proof of one CPU cause, or permanent design ban.
The broader whole-script performance objective remains open.

| B641 complete script/API | Elapsed change | Process CPU change | Reference/candidate control spread |
| --- | ---: | ---: | ---: |
| Captured text Run | −2.39..+4.19% | −2.51..+3.94% | 5.11/1.29% |
| Captured text RunAsync | −0.29..+4.15% | +0.30..+6.87% | 2.74/1.56% |
| CSV Run | +1.28..+3.46% | +1.70..+4.98% | 0.28/1.83% |
| UTF8 report Run | −1.40..+2.01% | −3.18..+0.69% | 0.92/2.51% |
| UTF8 report RunAsync | −2.62..+4.49% | −1.22..+4.43% | 3.59/3.45% |

Negative means faster than baseline. Ranges include all four candidate/reference
process-median combinations, rather than selecting one favorable pair. These are
within-Lython comparisons, not CPython ratios. Existing quiet Azure F4as_v7 VM,
Ubuntu/.NET11RC3, normal tiering/GC, fixed comparison worker and unchanged input
catalog. Five jobs finish in275.929s under a360s owner plus30s stop/30s margin.
Existing matching/validation, mediated RAM-file I/O and previous-result cleanup
remain inside the warm boundary; startup, fixture reset, protocol and final cache
cleanup are outside. Full identity/golden/balance/quiet/worker-exit/join/unmount/
archive gates pass. SHA-verified retrieval and terminal state are cached.

All original desktop data survives: favorable captured Run elapsed−7.76..−11.16%
with3.83% unchanged-control spread, adverse CSV Run+4.93..+5.02% with0.09% spread,
variable async/report and adverse compilation despite unchanged compiler source.
Those observations were diagnostic; B641 does not erase them. No unchanged retime
is required for this withdrawal. All failed setup conditions, source patches,
frozen source/core, constructor allocation observations and raw data are archived.

Candidate focused checks cover1128 internal/6030 public per actual.NET11/10
(14316 unique target checks, including separately added alias cases). Seven
complete scripts pass both APIs plus compilation/fresh execution and ownership
goldens. A new independent CPython-backed class/nonlocal/generator-close alias
regression remains:2public cases. All five production and seven fixture files
are restored;568 production sources match qualified code with explicit newline
normalization. A forced nonincremental Release solution build passes, then158
internal/61public focused checks per target pass, including the retained alias
regression. No dormant cell-promotion hooks remain. No repeated full qualification
of the unchanged production runtime is claimed or needed.

Before staging, a verified idle-lease hard-link deduplication replaces both links
to an identical e4cc65b2 core inode with the existing canonical inode. Every old
path and byte survives; all aliases, ownership, device and hashes were checked.
Free space rises274518016→280207360B without changing OS/evidence/staging floors.
Preparation and proofs survive in diagnostics. B641 ends with268345344B free,
no live owned workers and no guest RAM mount. No archive or image was deleted.

[Raw summary](summary.json), [VM observations](observations.tgz),
[source/restoration and desktop diagnostics](diagnostics.tar.xz),
[restoration proof](restoration.json), [withdrawn patch](final-prototype.patch).
The current runtime guide continues to describe qualified R281. Publication held.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.iterdir() if p.is_file() and p.name not in ['manifest.json','README.md']}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
history=Path('benchmarks/EXPERIMENTS.md')
history.write_text(history.read_text(encoding='utf-8')+'''\n## R284 — explicit lexical cell storage withdrawn\n\n+[The prototype and all original conditions](results/2026-11-12-lexical-cell-storage-withdrawn/README.md)\n+reduce each cell48→40B but leave whole-script allocation effectively flat. Explicit\n+namespace promotion adds machinery;14316focused actual-target checks and seven\n+scripts/both APIs/compile/fresh pass. B641five jobs275.929s shows CSV Run\n++1.28..+3.46% elapsed/+1.70..+4.98% CPU, while captured text remains uncertain.\n+Withdraw the source, retain the independent alias regression and all favorable/\n+adverse desktop and VM data.568sources restore to qualified production; forced\n+nonincremental build and438focused target checks pass. No dormant promotion hooks\n+or repeated full qualification. The substantial performance objective stays open.\n+''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
text=text.replace('| Active prototype | **R284**, five production files over 9bca1337, frozen c8bca168. Explicit lexical cell locations; not yet committed or fully qualified. 14316 focused checks pass across actual targets (1128 internal/6030 public each, with new cases checked separately), seven scripts/both APIs/compile/fresh pass. B641 comparison active below. |','| Withdrawn prototype | **R284** explicit cell locations: 14316 focused checks and seven complete scripts pass, but B641 CSV Run +1.28..+3.46% elapsed with supporting adverse CPU; captured benefit uncertain and allocation flat. Entire source/fixture prototype removed; independent 2-case alias regression retained. Restored build +438 focused checks pass. [Evidence](benchmarks/results/2026-11-12-lexical-cell-storage-withdrawn/README.md). |')
start=text.index('1. **Finish R284:')
end=text.index('2. **Next whole-script redesign:',start)
text=text[:start]+text[end:]
text=text.replace('2. **Next whole-script redesign:','1. **R285 whole-script redesign:').replace('3. **Other roadmap axes','2. **Other roadmap axes').replace('4. **Independent regex','3. **Independent regex')
text=text.replace('R284 is separate.','R284 was withdrawn; production remains unchanged.').replace('No extrapolation to R284.','No extrapolation to R284.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Archived withdrawal, checked restored regressions, updated ignored plan; no runtime prototype retained.')
