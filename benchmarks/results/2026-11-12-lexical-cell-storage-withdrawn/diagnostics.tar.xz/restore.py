from pathlib import Path
import hashlib,io,json,os,subprocess,sys,tarfile
r=Path(__file__).parent;workspace=Path.cwd().resolve()
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
(r/'final-prototype.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']))
paths=list(identity['changed'])+subprocess.check_output(['git','diff','--name-only','--','tests/Lokad.Lython.Tests'],text=True).splitlines()
assert len(paths)==12,paths
for name in paths:
 p=Path(name).resolve();assert p.is_relative_to(workspace)and (name.startswith('src/Lokad.Lython/')or name.startswith('tests/Lokad.Lython.Tests/'))
 p.write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))
proof=[]
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD','src/Lokad.Lython'])))as t:
 for name in identity['sources']:
  current=Path(name).read_bytes();stored=t.extractfile(name).read()
  assert current.replace(b'\r\n',b'\n')==stored.replace(b'\r\n',b'\n'),name
  proof.append(dict(path=name,currentSHA256=hashlib.sha256(current).hexdigest(),committedNormalizedSHA256=hashlib.sha256(stored.replace(b'\r\n',b'\n')).hexdigest()))
(r/'restoration.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),qualifiedProduction='9bca1337f02a9acc172c65c141ce626222b847bd',sourceCount=len(proof),allMatchWithExplicitNewlineNormalization=True,sources=proof),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
commands=[('restored-build',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
 for label,project,filter in [
 ('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','Category!=Stress&(FullyQualifiedName~NativeClosure|FullyQualifiedName~LambdaExecutable|FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~DictionaryCountingLoopAdmission|FullyQualifiedName~ExecutableAugmentedIntegerBoundary|FullyQualifiedName~ExecutableLocalImportBinding|FullyQualifiedName~ExecutableValueTransfer|FullyQualifiedName~MappingSliceKeyOwnership|FullyQualifiedName~RepresentativeLease)'),
 ('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','Category!=Stress&(FullyQualifiedName~GeneratorNamespaceMutation|FullyQualifiedName~ExecutableGenericFunction|FullyQualifiedName~NativeClosure|FullyQualifiedName~CooperativeCancellation)')]:
  commands.append(('restored-'+label+'-'+framework,[str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]))
for label,args in commands:
 with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as output:done=subprocess.run(args,env=env,stdout=output,stderr=subprocess.STDOUT)
 print(label,done.returncode,flush=True);print('\n'.join((r/(label+'.log')).read_text(encoding='utf-8').splitlines()[-10:]),flush=True)
 if done.returncode:sys.exit(done.returncode)
print('Qualified runtime and white-box convention restored/nonincrementally rebuilt; independent alias regression retained and passes.',flush=True)
