from pathlib import Path
import subprocess
r=Path(__file__).parent
(r/'base.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True),encoding='utf-8',newline='\n')
(r/'source-gate.md').write_text('''# R284: explicit lexical cell storage

Base632a867c, production9bca1337/frozene4cc65b2; R281 full delivery is independent.
R282 external captured warm1.63-1.74x/report1.30-1.33xCPython retains variable
controls. R283 counts prove frequent admissions, not duplicate funding or avoidable
CPU; no new governor balance/cache is selected.

Current cells keep both a private value and a defining context/name. Every Value
read/write rechecks two owner mode flags. Once a namespace becomes authoritative,
the private value is unused but can retain an older alias. R281 already makes the
cell authoritative in each captured slot; finish that ownership migration with one
explicit cell location: direct guest value OR namespace context, plus its name.
ExecutionContext cannot be a guest value. This is internal lexical storage, not a
general tagged-value VM. Scalars remain ordinary objects/BigInteger.

Delete the permanent owner backpointer, separate private-value shadow and repeated
mode selection. Centralize enabling namespace mirroring as an explicit monotonic
operation; seed namespaces first, then bind compiler-known cells. On static
mirroring entry bind the existing initialized namespace. New comprehension capture
cells are namespace-backed before flags/retention marks publish, as their existing
transaction already requires. Class-cell namespaces preserve their initial mode.

Do NOT cache GlobalNamespace absence. The sole production publisher is
CreateGlobalNamespace, which calls RetainLocalsForLambda before assigning it.
Namespace-backed cells therefore keep their dynamic owner/global-namespace guard;
an unmirrored owned cell has no global namespace yet. Preserve that guard and
ownerless cell eligibility. Bind only real, still-owned stack backing (which is
cleared before refund callbacks); never inspect an inactive returned workspace.
Suspended generator backing remains owned. No registration list, root inventory,
new cache, policy, opcode, backend or public option.

Affected workloads: captured helpers and namespace-backed class/generic/annotation/
generator closures. Existing profiles show recurring native guard/evaluation,
not an isolated cell-access cost; CPU savings remain a hypothesis. Cell layout and
per-command allocation must be measured, not inferred from field count. Promotion
adds work once and can affect ordinary controls. No tiny-budget identity promise.

Acceptance: live shared identity/rebinding/deletion/unbound reads, class/super,
generic/lazy annotations, comprehension transactions, globals() mutation, suspended
generators/protocols, first refusal/cancellation and funded retained users. Existing
white-box mode setup changes to explicit enable calls without dropping assertions.
Use focused actual11/10 Release checks and existing seven scripts/both APIs/compile/
fresh, then one bounded affected/general-control comparison. Refine for demonstrated
issues, or restore the entire prototype; do not retain dormant transition hooks.
Full platform/stress/consumer validation follows only a retained migration.
Publication remains postponed and final regex producer gaps stay independent.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='2. **Following redesign gates.**';pos=s.index(needle)
s=s[:pos]+'''2. **R284 — explicit lexical cell storage.** Finish R281's single-storage
   migration: a cell holds either its direct guest value or its namespace context.
   Remove permanent owner backpointers, unused shadow values and repeated owner
   mode checks. Centralize monotonic mirroring with explicit binding after namespace
   seeding; preserve dynamic global-namespace eligibility, ownerless cells and
   still-owned generator storage. No root inventory or general value VM.
   Captured helpers are affected; CPU benefit is a hypothesis, not a forecast.
   Validate live aliases, globals/class/generic/comprehension/annotation promotion,
   genuine suspension, unbound/deletion errors, terminal refusal/cancellation,
   retained users and budget reuse. Then seven existing scripts/both APIs/compile/
   fresh and a bounded affected/control pair; decide retention/debt and remove any
   withdrawn transition machinery. Full qualification only at retention.

3. **Following redesign gates.**'''+s[pos+len(needle):]
s=s.replace('4. **Independent regex','5. **Independent regex')if '4. **Independent regex'in s else s.replace('3. **Independent regex','4. **Independent regex')
s=s.replace('R282/B640 is active independently','R282/B640 completed independently')
p.write_text(s,encoding='utf-8',newline='\n')
print('Explicit cell-location migration/deletions, dynamic-guard proof and bounded acceptance recorded before edits.')
