from pathlib import Path
root=Path('src/Lokad.Lython/Runtime')
def change(path,fn):
 s=path.read_text(encoding='utf-8');n=fn(s);assert s!=n,path;path.write_text(n,encoding='utf-8',newline='\n')
def replace(s,old,new):
 assert old in s,old
 return s.replace(old,new)
def cells(s):
 start=s.index('        private object? _value;');end=s.index('        // MG11:',start)
 s=s[:start]+'''        // A context is an internal namespace location, never a guest value.
        // Direct cells need neither a permanent owner reference nor a second
        // value once their binding moves into a retained namespace.
        private object? _storage;
        private readonly string? _name;

        public ExecutableCell(object? value, ExecutionContext? owner = null, string? name = null)
            : this(owner is { MirrorsExecutableLocals: true } || owner?.MirrorLocalStores == true
                ? owner : value, owner is null ? null : name) { }

        private ExecutableCell(object? storage, string? name)
        { _storage = storage; _name = name; }

        internal static ExecutableCell ForNamespace(ExecutionContext owner, string name)
            => new((object)owner, name);

        internal void BindNamespace(ExecutionContext owner)
        {
            if (_name is not null) _storage = owner;
        }

        public object? Value
        {
            get => _storage is ExecutionContext owner ? owner.Variables.GetValueOrDefault(_name!) : _storage;
            set
            {
                if (_storage is ExecutionContext owner)
                {
                    if (value is null) owner.Variables.Remove(_name!);
                    else owner.Variables[_name!] = value;
                }
                else _storage = value;
            }
        }

        // Namespace creation is dynamic. Its publication first binds these
        // cells, so later global-map mutation retains the ordinary guard.
        internal bool CanStoreThroughOwner => _name is not null
            && (_storage is not ExecutionContext owner || owner.GlobalNamespace is null);

'''+s[end:]
 return s
change(root/'LythonRuntime.Executable.cs',cells)
def context(s):
 s=replace(s,'                MirrorLocalStores = true,\n','')
 s=replace(s,'            cellScope.ClassCell = new ExecutableCell','            cellScope.EnableLocalMirroring();\n            cellScope.ClassCell = new ExecutableCell')
 s=replace(s,'        internal bool MirrorLocalStores { get; set; }','''        internal bool MirrorLocalStores { get; private set; }

        internal void EnableLocalMirroring()
        {
            MirrorLocalStores = true;
            BindCapturedCellsToNamespace();
        }

        // Released/returned workspaces expose no backing before a refund can
        // reenter. Suspended generators retain theirs until actual cleanup.
        internal bool HasExecutableStorage => _execution.Stack.Values is { Length: > 0 };

        private void BindCapturedCellsToNamespace()
        {
            if (!HasExecutableStorage) return;
            foreach (var slot in _execution.Code.CapturedLocalSlots)
                ((ExecutableCell)_execution.Locals[slot]).BindNamespace(this);
        }''')
 s=replace(s,'            MirrorsExecutableLocals = RequiresLocalVariableMirroring;','''            MirrorsExecutableLocals = RequiresLocalVariableMirroring;
            if (MirrorsExecutableLocals || MirrorLocalStores) BindCapturedCellsToNamespace();''')
 return s
change(root/'LythonRuntime.ExecutionContext.cs',context)
def binding(s):
 s=replace(s,'new ExecutableCell(null, binding, name)','ExecutableCell.ForNamespace(binding, name)')
 s=replace(s,'binding.MirrorLocalStores = true;','binding.EnableLocalMirroring();')
 s=replace(s,'var frame = current.CurrentExecutableFrame;','var frame = current.HasExecutableStorage ? current : null;')
 s=replace(s,'current.MirrorLocalStores = true;','current.EnableLocalMirroring();')
 return s
change(root/'LythonRuntime.Executable.Binding.cs',binding)
change(root/'LythonRuntime.Generators.cs',lambda s:replace(s,'frame.MirrorLocalStores |= code.RequiresLocalVariableMirroring;','if (code.RequiresLocalVariableMirroring) frame.EnableLocalMirroring();'))
change(root/'LythonRuntime.Imports.cs',lambda s:replace(s,'moduleContext.MirrorLocalStores = true;','moduleContext.EnableLocalMirroring();'))
for p in Path('tests/Lokad.Lython.Tests').glob('*.cs'):
 s=p.read_text(encoding='utf-8')
 if 'MirrorLocalStores =' not in s:continue
 if p.name=='DictionaryCountingLoopAdmissionTests.cs':
  s=replace(s,'new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = hook })\n            { MirrorLocalStores = mirrored };','new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = hook });\n            if (mirrored) context.EnableLocalMirroring();')
 else:
  s=s.replace('context.MirrorLocalStores = true;','context.EnableLocalMirroring();').replace('root.MirrorLocalStores = true;','root.EnableLocalMirroring();')
 p.write_text(s,encoding='utf-8',newline='\n')
print('Five production files migrated; existing fixture mode setup now enables mirroring explicitly.')
