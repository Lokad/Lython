from pathlib import Path
r=Path(__file__).parent;p=Path('PLAN.md')
(r/'PLAN-before-refresh.md').write_text(p.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-12. Git-ignored; never force-add. Publication and tagging remain
postponed. Deliver coherent execution/ownership simplification and substantial
complete-script improvements, including compile-to-result. An isolated experiment
does not complete this objective.

## Actual delivery status

| State | Delivered work and limits |
| --- | --- |
| Fully qualified production | **9bca1337**, GREEN [43295336048](https://github.com/Lokad/Lython/actions/runs/43295336048). Windows/Ubuntu, actual .NET 11/10, ordinary 4590 internal/17448 public and original stress 13/406 per target, installed Release consumers. All 568 measured production sources match. [Delivery](benchmarks/results/2026-11-12-captured-slot-ownership/delivery/README.md). R284 is separate. |
| Committed evidence | 632a867c archives the current CPython checkpoint and bounded admission source gate. No production change or repeated qualification. |
| Active prototype | **R284**, five production files over 9bca1337, frozen c8bca168. Explicit lexical cell locations; not yet committed or fully qualified. 14316 focused checks pass across actual targets (1128 internal/6030 public each, with new cases checked separately), seven scripts/both APIs/compile/fresh pass. B641 comparison active below. |
| Refreshed external measurements | Qualified 9bca1337 vs CPython 3.13.16: captured text warm **1.63–1.74×**, compile **0.83–0.84×**, compile-to-result **1.44–1.54×**; UTF8 report warm **1.30–1.33×**, compile-to-result **1.23–1.29×**. Controls/IQR leave four rows variable. [Guide](docs/BENCHMARKS.md), [all five observations](benchmarks/results/2026-11-12-captured-cpython-checkpoint/README.md). Other rows retain their historical sources; no extrapolation to R284. |

## Completed milestones to preserve

| Work | Established outcome / remaining debt |
| --- | --- |
| Shared compiler facts | Shared-analysis/nonlocal correction, annotation demand and retained-lowered cleanup delivered. Compilation allocation reductions established; CPU attribution remains limited. |
| Direct UTF8 formatting/storage | Allocation **−8.67%**, controlled elapsed/CPU supports roughly **5–8%**. Original adverse 15.125 ms observation remains unexplained and preserved; it does not automatically invalidate the controlled evidence. |
| Native helper returns | Run allocation **−19.92%**, RunAsync **−19.31%**; full qualification and throwing-refund fix complete. Original elapsed improvements remain diagnostic. |
| Calls and frame storage | Direct ordinary calls, reused startup workers/workspaces, executable callable consolidation, live closures, captured helper execution and private totals delivered. R281 removes sparse local-cell arrays, backpointers and synchronization: captured Run elapsed **−4–6%**, supporting CPU; CSVAsync elapsed **+0.4–2.3%** accepted debt. Other async/report results remain uncertain. |
| CSV / record construction | Earlier bulk CSV work was selectively reassessed into current row adoption/shared keys. Preserve mutable headers/order, duplicates, protocols, retained aliases and construction overlap. No automatic promotion of old prototypes. |
| Native text/storage | Immutable reader windows, prepared word ranges, compact native metadata and transferred builders delivered. R271 report elapsed **+0.6–2.8%** remains accepted debt. These changes do not establish additive CPU gains. |
| Bulk UTF16 | Managed bounded transcoding replaces scalar emission; three dormant helpers removed. Affected elapsed improves, async CPU supports it; sync CPU uncertain. UTF8 control elapsed up to **+2.11%** and CPU up to **+1.25%** remain accepted uncertainty/debt. Initial count fusion withdrawn. |
| R279 JSON windows | Existing immutable backing reused for plain same-owner tokens. Report allocation **−4.68% UTF8 / −4.46–4.49% UTF16**; modest controlled UTF8 report benefit. Full backing can stay funded longer; UTF16/JSON/CSV CPU uncertain. Fully qualified. |
| Bounded assessments | R280 check/span deletions withdrawn with all adversity preserved. R283 observes 6229/13398/14425 allowance resizes for text/CSV/report, identical across APIs; no duplicate funding or removable CPU established, so no funding cache/allocator added. |

Detailed failed conditions, refinements, rejected designs and raw measurements stay
in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable benchmark artifacts, not
in the active checklist or current runtime guide.

## Prioritized deliverables and acceptance

1. **Finish R284: explicit lexical cell storage.** A cell holds either its direct
   guest value or its namespace context. Remove the permanent owner backpointer,
   unused shadow value and repeated owner-mode selection. Mirroring is enabled
   explicitly after namespace seeding; static mirroring binds initialized storage.
   Preserve dynamic global-namespace eligibility, ownerless cells, comprehension
   publication and still-owned suspended frames. No new root inventory or value VM.
   - Focused checks and new CPython alias golden pass, including class/generic/
     annotation/comprehension promotion, globals mutation, generator close, first
     refusal/cancellation and retained-user cleanup.
   - Cell construction measures **48 → 40 B** outside guest clocks; whole-script
     allocation is effectively flat. Desktop captured timing is favorable, CSVRun
     about **+5%** against a stable control; other adverse/variable results survive.
   - **B641**: captured Run/RunAsync, CSVRun, report Run/RunAsync; 360 s owner,
     30 s stop/30 s margin. Earliest retrieval **20:41:58 UTC**. Exact baseline e4cc65b2,
     candidate c8bca168, normal runtime and existing golden/quiet/ownership gates.
     A verified hard-link deduplication preserves all old paths/bytes and floors.
   - Decide retention and explicit regression debt from source simplification and
     controlled observations. Refine when evidence warrants, or restore the entire
     prototype and nonincrementally verify restoration. Keep independent semantic
     regressions. No dormant promotion hooks. Full platform/stress/installed-package
     qualification follows a retained coherent migration, not each iteration.

2. **Next whole-script redesign: private result/iteration transport source gate.**
   Captured-text still has a material warm gap. The existing immediate cased-split
   path constructs a private cursor for each line and transports it as an object;
   native list/tuple iteration has separate frame-owned position storage. Assess
   consolidating producer/consumer state into the existing executable lifetime and
   removing the per-line carrier, rather than another generic frame or guard VM.
   Identify the actual call/return/suspension transfer before implementation. Name
   displaced code, estimate storage from actual construction, and preserve eager
   admission before loop effects, Unicode context, aliases, last bindings and
   cleanup/refund reentry. Dynamic/exposed results keep Python behavior. Stop this
   gate with a coherent implementable contract or a documented source objection;
   do not automatically add a parallel return protocol or narrow sentinel scheme.
   Any selected migration needs representative captured/general-control scripts,
   focused semantics/ownership/cancellation and a bounded before/after comparison.
   The whole performance objective remains open after this source gate.

3. **Other roadmap axes remain evidence-driven.** Locals/operands and span binding
   already share storage. Current record adoption, formatting plans, word ranges,
   JSON windows and output batching are delivered. Do not replay slower call arenas,
   linear native proof, ordered prefixes or segment-entry forms unchanged. Config
   compilation is near CPython; no dominant duplicate frontend pass is proven.
   Scoped scalar improvements must preserve identity, exact promotion and public
   projection; boxing alone does not establish dominant cost. A materially different
   redesign stays open, with an explicit completion milestone and debt decision.

4. **Independent regex track.** Core Python/native-UTF8 contract and implementation
   are delivered; normal optional nonpackable adapter remains 0.4. Immutable
   dev73/eae880c8 semantic checks (86 internal/532 public per actual target) complete.
   Development producers/adapter-local bridges may support independent work.
   Only affected final released-adapter qualification awaits: separate one-match
   working/result owners, native UTF8 group-name enumeration, and token-independent
   cursor creation with cancellable preparation. Per-move cancellation alone does
   not prove preparation interruption. No blanket producer stop or unchanged API
   requalification; core remains decoupled and publication remains postponed.

## Measurement and lasting constraints

Architecture, allocation/allowance reduction and demonstrated CPU improvement are
separate outcomes. Percentages inform decisions; they are not automatic vetoes.
Timeouts or moving controls establish uncertainty. Permit bounded confirmation,
refinement and measurement correction when justified, retaining original/adverse
conditions. Size runs for usable observations on the quiet VM; no permanent bans
or one-attempt/no-retiming policy. Preserve all inconclusive external rows.

Use focused Release checks in development. Batch Windows/Ubuntu, actual .NET11/10,
original stress and installed Release consumers at delivery boundaries. After source
restoration, force a nonincremental build before no-build checks or worker freezing.
GC fixtures stay nonparallel. Cache terminal CI/VM states; live CI checks minutes
apart. Persistent raw/catalog/worker storage stays separate from RAM fixtures;
join, archive and verify before cleanup. Preserve OS/evidence floors. RSS, genuinely
pending-I/O latency and embedding-tail impact remain unqualified.

Fully managed and memory-safe: no unsafe code/APIs, pointers, P/Invoke or native
stack probing. Keep managed stack admission, host capabilities/paths, cancellation,
cycles/XML depth and checked representation/bounded I/O chunks. Borrowed shared
allowance funds capacity, overlap, retained results/aliases/caches and pending users
until ownership ends. First refused admission is terminal; guest-raised MemoryError
remains catchable. No fuel/quotas, hidden caps/default allowances, tracing/weak
reclamation, forced GC, retries or abandoned users. Streaming uses bounded host-led
commands. Preserve original path/Cwd requests and refused-copy destinations.
See [AGENTS](AGENTS.md) and the [current runtime contract](docs/RUNTIME.md).
''',encoding='utf-8',newline='\n')
print('Plan condensed into actual delivery, preserved completed work, bounded deliverables and explicit limitations.')
