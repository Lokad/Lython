# Lokad.Lython 0.11.0

Updated2026-11-12. Git-ignored; never force-add. Publication/tagging postponed.
Objective: simpler execution/ownership and substantial complete-script performance,
including compile-to-result. One experiment or profile does not finish this work.

## Delivery status

| State | Result / evidence |
| --- | --- |
| Fully qualified production | `b3369e3e`, GREEN43281710944: Windows/Ubuntu, actual.NET11/10, original stress, installed Release consumers. All568 frozen measured sources match. Includes R269–R279; [latest delivery](benchmarks/results/2026-11-12-json-existing-windows/delivery/README.md). Later R280 prototypes are not qualified by this run. |
| Compiler facts delivered | Shared analysis/nonlocal correction and R270 annotation demand remove repeated work; compile allocation−432..−456B, CPU/warm uncertain. Preserve corrected semantics; [history](benchmarks/EXPERIMENTS.md). |
| Direct UTF8 formatting/storage delivered | Allocation−8.67%; controlled elapsed/CPU supports5–8%. Original adverse15.125ms observation remains unexplained/preserved. [Performance guide](docs/BENCHMARKS.md). |
| Native helper returns delivered | Run allocation−19.92%/RunAsync−19.31%; qualification and throwing-refund fix complete. Original elapsed gains diagnostic. Preserve these optimizations. |
| Storage/native facts delivered | R271 immutable reader windows: allocation−18%search/−5%text/JSON; report elapsed+0.6..+2.8%accepted debt. R273nodes72→48B, whole compile−0.06..−0.18%, CPU uncertain. R274prepared ranges remove second whitespace scan; allocation flat/modest target elapsed, limited CPU attribution. [Evidence](benchmarks/EXPERIMENTS.md). |
| Bulk UTF16 delivered | Refined R276 replaces scalar emission with bounded managed transcoding and removes three dormant helpers. Allocation flat; target elapsed−1..−8%Run/−2..−5%Async, supporting AsyncCPU; sync CPU uncertain. UTF8control elapsed−.36..+2.11%/CPU0..+1.25% accepted debt/uncertainty. Initial count fusion withdrawn; adversity retained. [Both forms](benchmarks/results/2026-11-12-bulk-utf16/README.md). |
| R279 delivered | `b3369e3e` reuses existing immutable input for plain same-owner JSON tokens. Report allocation−4.68%UTF8/−4.46..4.49%UTF16; controlled UTF8 report elapsed−3..−6%Run/−2.5..−3.6%Async, supporting modest CPU. Full backing can stay charged longer; UTF16/JSON/CSV CPU uncertain. 2290focused checks, seven scripts/both APIs/compile/fresh pass. [Decision/evidence](benchmarks/results/2026-11-12-json-existing-windows/README.md). Full delivery43281710944 passes; original uncertainties remain. |
| R280 withdrawn | Both native accumulator check/span forms restored to qualified production. Initial captured-text elapsed+3..6%/CPU+2..5%; narrower confirmation remains inconclusive, allocation flat. No larger mechanism removed, so retention is not justified. 1826focused checks per form; restored-source build and126checks pass. [Original adversity and refinement](benchmarks/results/2026-11-12-native-accumulation-boundaries/README.md). No permanent design ban. |
| External checkpoint complete | Qualified41bd869b vs CPython3.13.16: captured text warm1.66–1.68×; UTF16report warm1.45–1.49×/fresh1.37–1.41×; UTF8report warm1.30–1.32×; config compile1.07–1.08×/fresh1.11–1.12×. Captured fresh1.46–1.55× remains variable (Lython5.19%spread). Other rows retain source labels. [Guide](docs/BENCHMARKS.md), [seven jobs/raw boundaries](benchmarks/results/2026-11-12-utf16-cpython-checkpoint/README.md). |
| Independent regex | Core Python/native-UTF8 architecture implemented. Immutable dev73/eae880c8 semantic checks86internal/532public per actual target complete; optional nonpackable adapter remains0.4. Only affected final released-adapter capabilities deferred below. |

Completed changes/fixes remain: direct calls, reused workers/workspaces, live cells,
captured helpers, CSV row adoption/shared keys, native UTF8/JSON, scoped integer
accumulation/private totals and final-byte output. Detailed histories/failed
conditions live in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results.

## Prioritized deliverables

1. **R281 — one authoritative captured-slot representation.** Replace duplicate
   cell values/executable caches with existing cells stored in captured local slots.
   Delete LocalCells sparse arrays/parameters, owner-slot backpointers, active-frame
   cache writes and generator cell-to-slot resume loops. Keep namespace mirroring,
   live closure identities, generator lifetimes and Python unbound diagnostics.
   Affected: captured-text, closures/helpers/generators. This removes real storage
   and synchronization; CPU benefit remains a hypothesis, with a possible type-test
   cost for ordinary local loads. No raw-long/tagged-value or new execution route.
   Validate aliases, match/import/handler/fallback writes, actual suspension,
   cancellation, first refusal, retained results and budget reuse; then seven
   unchanged complete scripts/both APIs/compile/fresh plus one bounded affected/
   ordinary-load-control comparison. Finish with mechanism deletion and an explicit
   retention/regression-debt decision; full delivery only after retention.
   Retained source: sparse arrays/backpointers/synchronization removed. Initial
   namespace handover failures corrected.7458focused checks pass; supplemental
   filters overlap, seven scripts/both APIs/compile/fresh pass. B638capturedRun
   elapsed−4..−6%/CPU−2.6..−4.5%; B639accept CSVAsync elapsed+0.4..2.3% debt,
   CPU/other async/report uncertain. No substantial allocation or new CPython
   claim. [All original conditions](benchmarks/results/2026-11-12-captured-slot-ownership/README.md).
   Committed/pushed`9bca1337`; all568 measured production files match. Full
   delivery43295336048 is active: Windows/Ubuntu, actual11/10, original stress
   and installed consumers. Observe after20:01:54UTC, then space checks5minutes.
   Continue the targeted CPython checkpoint while CI runs; no qualification claim
   from focused checks alone.
   Production remains qualified only throughb3369e3e until that delivery passes.
   R282/B640 completed independently on exact9bca1337/e4cc65b2: captured text
   compile/warm/compile-to-result and UTF8 report warm/compile-to-result against
   stockCPython3.13.16. Five targeted jobs,360sowner/30sstop/30smargin. Earliest
   retrieval20:05:36UTC. Reuses verified worker/image; no old evidence removed.
   Preserve all controls/adversity, archive/join/verify before cleanup; update only
   these source-labelled guide rows after evaluating source qualification. Existing
   historical rows stay labelled. This is a checkpoint, not a new framework or
   completion of the whole-script performance objective.


2. **R284 — explicit lexical cell storage.** Finish R281's single-storage
   migration: a cell holds either its direct guest value or its namespace context.
   Remove permanent owner backpointers, unused shadow values and repeated owner
   mode checks. Centralize monotonic mirroring with explicit binding after namespace
   seeding; preserve dynamic global-namespace eligibility, ownerless cells and
   still-owned generator storage. No root inventory or general value VM.
   Captured helpers are affected; CPU benefit is a hypothesis, not a forecast.
   Validate live aliases, globals/class/generic/comprehension/annotation promotion,
   genuine suspension, unbound/deletion errors, terminal refusal/cancellation,
   retained users and budget reuse. Then seven existing scripts/both APIs/compile/
   fresh and a bounded affected/control pair; decide retention/debt and remove any
   withdrawn transition machinery. Full qualification only at retention.

3. **Following redesign gates.** Use existing profiles and whole-script gaps to
   select an actual recurring stage to remove. Locals/operands and span binding
   already share storage; record adoption/shared keys, prepared word ranges,
   formatting plans, immutable reader/JSON windows and bulk UTF16 already ship.
   Do not replay slower call arenas, linear native proof, ordered prefixes or
   segment forms unchanged. For each selected milestone name eliminated work,
   displaced implementation, semantic/ownership acceptance and affected/control
   comparison before implementation. A materially different design remains open.
   Config compile is near CPython; no dominant duplicate frontend pass is proven.
   Keep frontend consolidation behind that evidence gate rather than expanding it.
   R283 source gate complete: one pass verifies6229captured-text/13398CSV/
   14425report shared-reservation resizes per command, identical across APIs;
   outputs/files and all ownership baselines pass. These counts and prior monitor
   samples do not establish removable CPU or duplicate funding. Existing per-record
   preflights already combine CSV fields and split words. A governor-wide capacity
   cache would add another balance, prepublication/reentry rules, headroom retention
   and changed refusal thresholds; it is not selected from counts alone. No new
   funding cache, allocator, policy or prototype. [Bounded evidence](benchmarks/results/2026-11-12-admission-frequency/README.md).


4. **Independent regex development/qualification.** Continue useful Lython-owned
   contract work independently; no blanket producer stop. Development producers
   and adapter-local bridges may support tests. Do not replay unchanged APIs.

## Remaining producer capabilities

Only affected final optional-adapter qualification awaits released support for:
independent single-match working/result owners; native UTF8 group-name enumeration
(lookup exists); token-independent cursor creation with cancellable preparation.
Per-move cancellation does not prove preparation interruption. Core stays decoupled;
no sibling edits/new published producer dependency. Distinguish contract tests,
semantic qualification and actual backend memory/performance/safety claims.

## Roadmap decisions from existing evidence

- Per-record construction: former CSV6–8%work was reassessed/revised into current
  adoption/shared keys. Reader/range and R276encoder stages delivered; preserve
  Unicode/context, mutable headers/order, aliases and overlap.
- Scalars: boxed values alone do not establish dominant cost. Existing scoped
  integer optimizations ship; no universal tagged-value redesign selected.
  R111's old05790317 integer-loop diagnostic was≈1.17×CPython, with a missing
  quiet-after gate; neither the obsolete large gap nor that ratio describes HEAD.
  Captured slots now hold authoritative cells; namespace mirroring remains.
  Deferred scalar storage must preserve identity/aliases, unbound state, generators,
  reentrant admission and exact promotion; a raw-long field alone is insufficient.
  Existing profiles do not yet prove cell boxing dominant. Next call/frame work
  must eliminate an actual recurring stage before adding more scalar special cases.
- Frontend: shared facts/annotation demand and retained-lowered cleanup ship.
  R275config costs are distributed/14%unknown; R278offline attribution preserves
  the original trace and corrects signature-based categorization. No dominant
  duplicate pass proven.
  New work must remove an actual stage, not merely count passes.
- Patch: qualified single-edit fixture is ahead of CPython; no new difflib work or
  unchanged replay. Builtin descriptors retain per-run owners; sharing the mutable
  graph is not justified by source presence.
- Call-arena/control, ordered-prefix and segment-entry forms measured slower and
  were withdrawn. Their evidence informs R278; it does not permanently ban a
  materially different coherent design. No replay of unchanged rejected forms.

## Measurement and lasting contracts

Architecture, allocation/allowance reduction and demonstrated CPU improvement are
separate outcomes. Fixed percentages inform decisions, never automatic vetoes.
Timeout/moving controls establish uncertainty, not failed design. Permit bounded
confirmation/refinement/correction with an explicit question; preserve original
conditions and adversity. No one-attempt/no-retiming/permanent-closure policy.
Use focused Release checks; batch full platforms/actual targets/stress/installed
consumers at coherent delivery boundaries. Force nonincremental builds after source
restoration before no-build checks/freezing workers. GC fixtures stay nonparallel.
Cache terminal CI/VM states; live CI observations minutes apart. Persistent workers,
catalogs/raw/logs remain separate from RAM fixtures; join/archive/verify before
cleanup. Keep OS/evidence floors. RSS, pending-I/O and embedding-tail impact remain
unqualified. Publication stays held.

Fully managed/memory-safe: no unsafe code/APIs/pointers/PInvoke/native stack probes.
Keep managed stack protection, host mediation, cancellation, cycles/XML-depth and
checked representation/bounded chunks. Borrowed shared allowance funds major
capacity/replacement overlap, results/aliases/caches/pending users until ownership
ends. First refusal is terminal; guest-raised MemoryError remains catchable.
No fuel/quotas, independent caps/default allowance, tracing/weak reclamation, forced
GC, retries or abandoned users. Preserve original path/Cwd requests and refused-copy
destination. Bounded streaming uses host-driven commands. [AGENTS](AGENTS.md),
[current runtime contract](docs/RUNTIME.md).
