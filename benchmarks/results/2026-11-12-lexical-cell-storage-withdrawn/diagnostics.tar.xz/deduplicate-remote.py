from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'idleLease': True, 'freeBytes': 274518016, 'requiredFreeBytes': 276824064, 'canonical': {'path': 'captured-slots-b638-20261112/current-core.dll', 'bytes': 5684736, 'sha256': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529', 'device': 66305, 'inode': 845257, 'links': 3, 'allocatedBytes': 5685248}, 'allDuplicateAliases': [{'path': 'captured-slots-b639-20261112/current-core.dll', 'bytes': 5684736, 'sha256': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529', 'device': 66305, 'inode': 845286, 'links': 2, 'allocatedBytes': 5689344}, {'path': 'captured-slots-b639-20261112/candidate/Lokad.Lython.dll', 'bytes': 5684736, 'sha256': 'e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529', 'device': 66305, 'inode': 845286, 'links': 2, 'allocatedBytes': 5689344}], 'reclaimableBytes': 5689344, 'bytesAndPathsCanBePreserved': True}
base=Path('/home/lokad/lython-bench-checks').resolve()
lease=(base/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
assert users.returncode in(0,1)and not [s for s in users.stdout.splitlines()if int(s.split()[0])!=os.getpid()]
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
def verify(spec):
 p=base/spec['path'];s=p.lstat()
 assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
 assert(s.st_dev,s.st_ino,s.st_size,s.st_nlink)==(spec['device'],spec['inode'],spec['bytes'],spec['links'])
 assert hashlib.sha256(p.read_bytes()).hexdigest()==spec['sha256'];return p
source=verify(proof['canonical']);targets=[verify(s)for s in proof['allDuplicateAliases']]
assert len(targets)==proof['allDuplicateAliases'][0]['links']==2
before=shutil.disk_usage(base).free;temporary=[]
try:
 for target in targets:
  link=target.parent/('.r284-canonical-'+target.name);assert link.is_relative_to(base)and not link.exists()
  os.link(source,link);temporary.append(link)
 for target,link,spec in zip(targets,temporary,proof['allDuplicateAliases']):
  q=target.lstat();assert(q.st_dev,q.st_ino,q.st_size)==(spec['device'],spec['inode'],spec['bytes'])
  os.replace(link,target)
finally:
 for link in temporary:
  if link.exists():link.unlink()
for p in [source,*targets]:
 assert p.stat().st_ino==source.stat().st_ino and hashlib.sha256(p.read_bytes()).hexdigest()==proof['canonical']['sha256']
after=shutil.disk_usage(base).free
receipt=dict(beforeFreeBytes=before,afterFreeBytes=after,source=str(source.relative_to(base)),pathsPreserved=[str(p.relative_to(base))for p in targets],allBytesUnchanged=True,allOriginalAliasesVerified=True,oldEvidenceAndImagesStillPresent=True,requiredFreeBytes=proof['requiredFreeBytes'],osFloorMiB=240,evidenceHeadroomMiB=12)
assert after>proof['requiredFreeBytes']
print(json.dumps(receipt,indent=2))
