from pathlib import Path
import json,subprocess
r=Path(__file__).parent
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
lease=(base/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
assert users.returncode in(0,1)and not [s for s in users.stdout.splitlines()if int(s.split()[0])!=os.getpid()]
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
names=['captured-slots-b638-20261112/current-core.dll','captured-slots-b639-20261112/current-core.dll','captured-slots-b639-20261112/candidate/Lokad.Lython.dll']
rows=[]
for name in names:
 p=base/name;s=p.lstat()
 assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
 h=hashlib.sha256(p.read_bytes()).hexdigest();assert h=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
 rows.append(dict(path=name,bytes=s.st_size,sha256=h,device=s.st_dev,inode=s.st_ino,links=s.st_nlink,allocatedBytes=s.st_blocks*512))
assert(rows[1]['device'],rows[1]['inode'])==(rows[2]['device'],rows[2]['inode'])and rows[1]['links']==rows[2]['links']==2
assert rows[0]['inode']!=rows[1]['inode']
print(json.dumps(dict(idleLease=True,freeBytes=shutil.disk_usage(base).free,requiredFreeBytes=264*1024*1024,canonical=rows[0],allDuplicateAliases=rows[1:],reclaimableBytes=rows[1]['allocatedBytes'],bytesAndPathsCanBePreserved=True),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'space-inventory.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
data=json.loads(done.stdout);(r/'space-inventory.json').write_text(done.stdout,encoding='utf-8',newline='\n')
print(json.dumps(data),flush=True)
