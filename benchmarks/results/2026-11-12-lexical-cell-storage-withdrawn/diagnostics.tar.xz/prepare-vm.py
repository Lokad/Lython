from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=r/'b641';out.mkdir();old=r.parent/'captured-slot-ownership-r281/b638'
oldroot='/home/lokad/lython-bench-checks/captured-slots-b638-20261112';root='/home/lokad/lython-bench-checks/lexical-cells-b641-20261112';oldunit='lython-b638-captured-slots-20261112';unit='lython-b641-lexical-cells-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit,retire=[])
config['identity'].update(sourceRevision=identity['head']+'; R284 explicit lexical storage;14316focused actual-target checks; original diagnostics retained',coreSHA256={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.report-render.large','warm'],['scripts.report-render.large','warm-async']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R281 single authoritative captured-slot representation; sparse cell array/cache synchronization removed; captured both APIs and general local-load controls; preserve all adversity.'","purpose='R284 explicit lexical cell locations; captured helpers both APIs, adverse CSVRun and report controls; same managed stack/cancellation/ownership; preserve all original diagnostics.'")
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
 text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
 if name=='remote-launch.py':text=text.replace("base/'json-existing-windows-b634-20261112/candidate'","base/'captured-slots-b638-20261112/candidate'").replace('lython-b638-fixtures','lython-b641-fixtures')
 if name=='launch.py':text=text.replace('captured-slots-b638-launch.py','lexical-cells-b641-launch.py')
 if name=='retrieve.py':text=text.replace('B638 five-job','B641 five-job')
 if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
 (out/name).write_text(text,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Five existing complete-script jobs;360s owner/30s stop/30s margin. All normal gates retained.')
