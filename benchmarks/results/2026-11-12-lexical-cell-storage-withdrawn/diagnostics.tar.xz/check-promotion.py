from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
commands=[('promotion-build',[str(sdk/'dotnet.exe'),'build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release'])]
for framework in ['net11.0','net10.0']:
 commands.append(('promotion-'+framework,[str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter','FullyQualifiedName~GeneratorNamespaceMutationTests']))
for label,args in commands:
 with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('\n'.join((r/(label+'.log')).read_text(encoding='utf-8').splitlines()[-7:]),flush=True);assert done.returncode==0
for asynchronous in [False,True]:
 args=[str(sdk/'dotnet.exe'),'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',str(r/'promotion-alias.py'),'--compare-python']+(['--async']if asynchronous else[])
 done=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/('promotion-parity-'+str(asynchronous)+'.log')).write_bytes(done.stdout)
 assert done.returncode==0 and b'Parity: match'in done.stdout
print('New alias scenario and existing mutation/deletion tests pass; independent CPython parity through both APIs.')
