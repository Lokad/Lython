from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
commands=[('build',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
 for label,project,filter in [
 ('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Lambda|FullyQualifiedName~Generator|FullyQualifiedName~Executable|FullyQualifiedName~SharedMemory|FullyQualifiedName~Admission|FullyQualifiedName~SuperDescriptor|FullyQualifiedName~RepresentativeLease|FullyQualifiedName~MappingSliceKey)'),
 ('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Lambda|FullyQualifiedName~Generator|FullyQualifiedName~Nonlocal|FullyQualifiedName~Comprehension|FullyQualifiedName~Function|FullyQualifiedName~Framed|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~Admission|FullyQualifiedName~Namespace|FullyQualifiedName~ClassScope|FullyQualifiedName~CallInput|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~NativeWord|FullyQualifiedName~Annotation|FullyQualifiedName~Match|FullyQualifiedName~Import|FullyQualifiedName~Locals|FullyQualifiedName~BoundLoopName|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~ContextManager|FullyQualifiedName~Super|FullyQualifiedName~ClassCell)')]:
  commands.append((label+'-'+framework,[str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]))
for label,args in commands:
 log=r/(label+'.log');assert not log.exists()
 with log.open('w',encoding='utf-8',newline='\n')as output:done=subprocess.run(args,env=env,stdout=output,stderr=subprocess.STDOUT)
 print(label,done.returncode,flush=True);print('\n'.join(log.read_text(encoding='utf-8').splitlines()[-12:]),flush=True)
 if done.returncode:sys.exit(done.returncode)
print('Focused actual-target Release checks pass.',flush=True)
