from pathlib import Path
import json,os,subprocess,time
r=Path('.git/agent-notes/review-20261031/text-stage-r374');sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path');sources=json.loads((r/'aliased-bindings-sources.json').read_text(encoding='utf-8'));rows=[]
for tfm in ['net11.0','net10.0']:
 for name,args in [('probe-build',['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',tfm,'-v','quiet']),('internal',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'--filter','(Category!=Stress)&(FullyQualifiedName~DictionaryCountingLoopAdmissionTests|FullyQualifiedName~CasedSplitOwnershipTests)','--logger','trx;LogFileName=r375-internal-'+tfm+'.trx'])]:
  log=r/('alias-fix-'+tfm+'-'+name+'.log');assert not log.exists()
  with log.open('w',encoding='utf-8')as f:done=subprocess.run([sdk+'/dotnet.exe']+args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  rows.append(dict(framework=tfm,name=name,exitCode=done.returncode));print(tfm,name,done.returncode,log.read_text(encoding='utf-8')[-190:],flush=True);assert done.returncode==0
 for asynchronous in [False,True]:
  done=subprocess.run([sdk+'/dotnet.exe','tools/LythonProbe/bin/Release/'+tfm+'/LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(sources),env=env,text=True,encoding='utf-8',capture_output=True,timeout=60);(r/('aliased-bindings-corrected-'+tfm+'-'+str(asynchronous)+'.jsonl')).write_text(done.stdout,encoding='utf-8',newline='\n');assert done.returncode==0,done.stdout+done.stderr;rows.append(dict(framework=tfm,asynchronous=asynchronous,cases=len(sources),matched=True));print(tfm,asynchronous,'CPython aliases/effects match',flush=True)
(r/'alias-fix-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
