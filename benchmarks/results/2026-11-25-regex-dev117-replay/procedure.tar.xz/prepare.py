from pathlib import Path, PureWindowsPath
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
from zipfile import ZipFile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=subprocess.check_output(["git","rev-parse","55c73e564"],cwd=repo,text=True).strip()
donor=lab.with_name("regex-single-group-20261125")
archive=lab/"source.zip"
files=subprocess.check_output(["git","ls-tree","--name-only",base],cwd=repo,text=True).splitlines()
selected=[f for f in ("global.json","Directory.Build.props","Directory.Build.targets","Directory.Build.rsp",
                      "Directory.Packages.props","NuGet.Config","src","tests","tools") if f in files]
subprocess.run(["git","archive","--format=zip",f"--output={archive}",base,"--",*selected],cwd=repo,check=True,timeout=70)
tree=lab/"source"
with ZipFile(archive) as package:
    package.extractall(tree)
patch=donor/"development.patch"
selection=["--include=src/Lokad.Lython.Utf8Regex/*.cs","--include=tests/*/*.cs"]
subprocess.run(["git","apply","--check",*selection,patch],cwd=tree,check=True,timeout=20)
subprocess.run(["git","apply",*selection,patch],cwd=tree,check=True,timeout=20)

version="0.5.0-dev.117"
prod=Path.home()/"code/utf8regex/artifacts/nuget"
feed=lab/"feed"
feed.mkdir(exist_ok=True)
hashes={
    "Lokad.Utf8Regex":"34f6630bf4b768781763221a94cb331f974910da48db551961c01117acc6e349",
    "Lokad.Utf8Regex.PythonRe":"2b786030c550a35a01c65b73b50cbe50b46ddea794af5413c5dce4fdea43e5d5",
}
packages={}
for package, expected in hashes.items():
    filename=f"{package}.{version}.nupkg"
    shutil.copyfile(prod/filename,feed/filename)
    assert hashlib.sha256((feed/filename).read_bytes()).hexdigest()==expected
    with ZipFile(feed/filename) as z:
        spec=ET.fromstring(z.read(package+".nuspec"))
        revision=spec.find(".//{*}repository").attrib["commit"]
        assert revision=="d657d7e61696643ceeaa6cd1a53aebf7348457d5"
        packages[package]={"packageSHA256":expected,"producerRevision":revision,
                           "assemblySHA256":{n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()
                                             if n.startswith("lib/") and n.endswith(".dll")}}
props=tree/"Directory.Packages.props"
file=props.read_text(encoding="utf-8")
before='Include="Lokad.Utf8Regex.PythonRe" Version="0.4.0"'
assert file.count(before)==1
props.write_text(file.replace(before, f'Include="Lokad.Utf8Regex.PythonRe" Version="{version}"'),encoding="utf-8",newline="\n")

for platform in ("Windows","Ubuntu"):
    config=ET.parse(donor/f"NuGet.Candidate.{platform}.Config")
    sources={v.attrib["key"]:v for v in config.findall(".//packageSources/add")}
    dst=str(feed)
    if platform=="Ubuntu":
        path=PureWindowsPath(dst)
        dst="/mnt/"+path.drive.rstrip(":").lower()+"/"+"/".join(path.parts[1:])
    sources["producer"].set("value",dst)
    config.write(lab/f"NuGet.{platform}.Config",encoding="utf-8",xml_declaration=True)
(lab/"identity.json").write_text(json.dumps(dict(source=base,bridgePatchSHA256=hashlib.sha256(patch.read_bytes()).hexdigest(),
                                                version=version,packages=packages),indent=2)+"\n",encoding="utf-8")
print("Staged exact development packages against retained 55c73e564 core.")
