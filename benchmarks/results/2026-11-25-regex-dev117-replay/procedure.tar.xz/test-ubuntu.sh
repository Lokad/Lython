set -eu
lab="$PWD/.git/agent-notes/review-20261031/regex-dev117-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export NUGET_PACKAGES="$lab/nuget-linux"
suite="$lab/linux-source/tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj"
filter='(FullyQualifiedName~RegexAdapter|FullyQualifiedName~Utf8RegexSubjectLifetime)&Category!=Stress'
if ! dotnet restore "$suite" --force-evaluate -p:RestoreLockedMode=false --artifacts-path "$lab/ubuntu" --configfile "$lab/NuGet.Ubuntu.Config" > "$lab/ubuntu-restore.log" 2>&1; then
    tail -30 "$lab/ubuntu-restore.log"; exit 1
fi
if ! dotnet restore "$suite" --locked-mode --artifacts-path "$lab/ubuntu" --configfile "$lab/NuGet.Ubuntu.Config" > "$lab/ubuntu-locked.log" 2>&1; then
    tail -30 "$lab/ubuntu-locked.log"; exit 1
fi
if ! dotnet test "$suite" --no-restore -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/ubuntu-net10.log" 2>&1; then
    tail -62 "$lab/ubuntu-net10.log"; exit 1
fi
tail -4 "$lab/ubuntu-net10.log"
