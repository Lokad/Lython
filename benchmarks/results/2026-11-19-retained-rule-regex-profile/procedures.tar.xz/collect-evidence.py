from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-19-retained-rule-regex-profile')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=load(lab/'terminal-status.json')
receipt=load(lab/'archive-receipt.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert all(receipt[field] for field in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter',
    'archivedAndVerifiedUnderLease','ramTraceArchivedAndVerifiedBeforeUnmount'))
assert receipt['archiveSHA256']==sha(lab/'observations.tgz')
identity=load(lab/'identity.json')
cases={case['id']:case for case in load(lab/'catalog.json')['cases']}
assert sha(lab/'catalog.json')==identity['catalogSHA256']
summary=load(lab/'attribution.json')
for row in summary['rows']:
    record=load(lab/'retrieved/profiles'/row['label']/'record.json')
    assert record['workload']==row['case'] and record['closed']['status']=='Closed' and record['exitCode']==0
    assert record['identity']['catalogSha256']==identity['catalogSHA256']
    files=identity['imageFiles']['candidate']
    hashed={Path(lib['path']).name:lib['sha256'].lower() for lib in record['identity']['libraries'] if Path(lib['path']).name in files}
    assert 'Lokad.Lython.dll' in hashed and all(files[name]==digest for name,digest in hashed.items())
    response=record['response']
    case=cases[row['case']]
    assert response['status']=='Completed' and response['completedInvocations']>0
    for field in ('sourceSha256','fixtureSha256','expectedOutputSha256'):
        assert response[field]==case[field]
    assert response['actualOutputSha256']==case['expectedOutputSha256']
    print(row['label'],row['guestRuntimeAncestry'],row['nearestRuntimeMethods'][:15],row['nearestReserveCallers'][:10])
out.mkdir(exist_ok=False)
for name in ('observations.tgz','attribution.json','archive-receipt.json','terminal-status.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as archive:
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix in {'.json','.py','.sh','.log'}:
            archive.add(path,arcname=path.name)
print('Verified exact retained image, seven CPython goldens and archived profile evidence.')
