from pathlib import Path
import ast,hashlib,json,os,subprocess,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'current-lexical-costs-r623'
donor=lab.parent/'prepared-capture-slots-r624'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,body):
    if name.endswith('.py'):ast.parse(body)
    (lab/name).write_text(body,encoding='utf-8',newline='\n')
def save(name,data):write(name,json.dumps(data,ensure_ascii=False,indent=2)+'\n')
old=load(prior/'config.json')
stage=load(donor/'quiet/config.json')
frozen=donor/'frozen/candidate'
files=stage['identity']['imageFiles']['candidate']
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert not subprocess.check_output(['git','diff','--name-only','8e877df62','f80035c13','--','src','tests'])
retained=load(Path('benchmarks/results/2026-11-19-prepared-capture-slots/summary.json'))
assert retained['retainedCommit']=='f80035c13' and retained['cores']['candidate']==files['Lokad.Lython.dll']
labels=['rules','annotated','captured','mutable','regex-groups','regex-spans','regex-mixed']
variants=['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures','scripts.mutable-rule-counters',
          'scripts.regex-unicode-groups','scripts.regex-unicode-spans','scripts.regex-unicode-mixed']
catalog=load(donor/'catalog.json')
all_cases=catalog['cases']+load(lab.parent/'regex-capture-projection-r626/catalog.json')['cases']
catalog['cases']=[next(c for c in all_cases if c['id']==name) for name in variants]
python=Path('C:/Python313/python.exe')
save('catalog.json',catalog)
identity=dict(sourceRevision='f80035c13',purpose='R628 retained rule construction and Unicode regex capture attribution',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']),imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/retained-rule-regex-profile-b1059-20261119'
unit='lython-b1059-retained-rule-regex-profile-20261119'
low=198*1024*1024
jobs=[(label,case,'warm') for label,case in zip(labels,variants,strict=True)]
old_labels=repr(['rules','captured','mutable'])
profile=read(prior/'ops-profile.py').replace(old['root'],root)
a,b=profile.index("[('rules',"),profile.index(")]",profile.index("[('rules',"))+2
profile=profile[:a]+repr(jobs)+profile[b:]
profile=profile.replace('count = 256','count = 64 if name.startswith("regex-") else 256').replace('total_capture_seconds > 30','total_capture_seconds > 50').replace('three-profile','diagnostic profile')
write('ops-profile.py',profile)
collect=read(prior/'collect.py').replace(old['root'],root).replace(old_labels,repr(labels))
collect=collect.replace('228589568',str(low)).replace('len(records)==3','len(records)==7').replace('R623/B1054 f80035c13 rule and capture attribution','R628/B1059 f80035c13 rule and Unicode capture attribution').replace('R623/B1054 68a7fc465 rule and capture attribution','R628/B1059 f80035c13 rule and Unicode capture attribution')
write('collect.py',collect)
write('run.sh',read(prior/'run.sh').replace(old['root'],root))
write('launch.py',read(prior/'launch.py').replace('Current lexical capture attribution','Current rule and Unicode capture attribution').replace('83','177'))
write('retrieve.py',read(prior/'retrieve.py'))
analyze=read(prior/'analyze.py').replace(old_labels,repr(labels))
a=analyze.index(' focused={')
analyze=analyze[:a]+''' focus.update({
     'core regex projection':('ProjectScalarBounds','PreparedSubject::Project','CreateMatchObject','RegexScalarPosition','SelectCloserBoundary'),
     'optional adapter':('Utf8RegexProvider','Utf8RegexMatch','PythonRe','MatchCursor'),
     'regex access and substring':('ResolveGroupBounds','GetBoundsCore','MaterializeGroup','GroupBytes'),
     'body call preparation':('BindExecutable','StartExecutable','NativeCallsPrepare','TryStartBoundInvocation','StartNativeCall','StartInline'),
 })
'''+analyze[a:]
a=analyze.index("\n(r/'attribution.json')")
analyze=analyze[:a]+'''
 if label.startswith('regex-'):
  provider = ('Lokad.Utf8Regex.', 'Lokad.Lython.Utf8Regex.', 'PythonRe')
  projection = ('ProjectScalarBounds', 'CreateMatchObject', 'PreparedSubject::Project')
  categories = collections.Counter()
  for stack in samples:
   adapted = any(any(part in frame for part in provider) for frame in stack)
   projected = any(any(part in frame for part in projection) for frame in stack)
   categories['provider'] += int(adapted)
   categories['core projection'] += int(projected)
   categories['overlap'] += int(adapted and projected)
  rows[-1]['allThreadRegexAttribution'] = dict(categories)
'''+analyze[a:]
write('analyze.py',analyze)
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as stream:
    for name in names:stream.add(lab/name,arcname=name)
size=sum((lab/name).stat().st_size for name in names)
if (lab/'quiet-space.json').exists():
    assert load(lab/'quiet-space.json')['freeBytes']>low+size+2*1024*1024
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=size)
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=(launcher[:a]+'c='+repr(config)+launcher[b:]).replace('lython-b1054-fixtures','lython-b1059-fixtures')
write('remote-launch.py',launcher.replace('228589568',str(low)).replace('+524288,','+2097152,').replace('RuntimeMaxSec=150','RuntimeMaxSec=275'))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',Path.cwd()/'benchmarks/cpython-worker.py','--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(frozen/name) for name in files}==files
print('Verified the retained 32-file image and all seven rule and Unicode regex goldens.')
