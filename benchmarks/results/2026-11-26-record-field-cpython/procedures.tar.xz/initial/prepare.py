from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
donor=lab.with_name('direct-record-helper-20261126')
prior=lab.with_name('short-path-cpython-20261126')
sealed=donor/'comparison/quiet'
template=prior/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(path,text):
    path.write_text(text,encoding='utf-8',newline='\n')
def save(path,data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('bc93d4d74') and not git('status','--porcelain','--','src')
record=read(sealed/'identity.json')
assert git('diff','--binary',record['sourceRevision'],head,'--','src')==(donor/'candidate.patch').read_bytes()
assert sha(donor/'candidate.patch')==record['sourcePatchSHA256']
receipt=read(sealed/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(sealed/'observations.tar.xz')==receipt['archiveSHA256']
files=record['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==files
shutil.copyfile(sealed/'representative.json',quiet/'representative.json')
shutil.copyfile(template/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==record['cpythonWorkerSHA256']
save(quiet/'jobs.json',[
    ['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.csv-meter-field-helper','warm'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.shipment-routing-callbacks','compile-run'],
])
identity=dict(sourceRevision=head,productionSource=head,candidate=head,imageFiles={'candidate':files},
              coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
              donorArchiveSHA256=receipt['archiveSHA256'],
              cpythonWorkerSHA256=record['cpythonWorkerSHA256'],expectedCPythonSHA256=record['expectedCPythonSHA256'],
              catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
              purpose='Compare current CSV conversion and shipment workloads against CPython.')
save(quiet/'identity.json',identity)
for name in ('collect.py','summarize.py','run.sh'):
    text=(template/name).read_text(encoding='utf-8')
    text=text.replace('lython-b1750-fixtures','lython-b1760-fixtures').replace('len(jobs) == 5','len(jobs) == 4')
    text=text.replace('len(raw["jobs"])==5','len(raw["jobs"])==4').replace('receipt["warmJobs"]==5','receipt["warmJobs"]==4')
    if name.endswith('.py'): compile(text,name,'exec')
    write(quiet/name,text)
assert b'\r' not in (quiet/'run.sh').read_bytes()

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
verify=quiet/'candidate-verify.json'
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
                '--catalog',quiet/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
                '--python-worker',worker,'--out',verify],cwd=repo,env=env,check=True,timeout=75)
proof=read(verify)
assert proof['state']=='Completed' and proof['caseCount']==3 and proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        archive.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='record-field-cpython-b1760-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
text=(prior/'quiet.py').read_text(encoding='utf-8')
text=text.replace('lython-b1750b-short-path-cpython-20261126','lython-b1760-record-field-cpython-20261126')
text=text.replace('len(frames)==7 and len(set(f.name for f in frames))==7','len(frames)==6 and len(set(f.name for f in frames))==6')
start=text.index(" donor=base/'direct-zip-starmap-b1749-20261126'")
end=text.index(' python=Path.home()',start)
text=text[:start]+''' donor=base/'direct-record-helper-b1759-20261126'
 receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert receipt['complete'] and receipt['allWorkersJoined']
 assert receipt['archiveSHA256']==image['donorArchiveSHA256']==sha(donor/'observations.tar.xz')
 origin=donor/'candidate'
 assert origin.resolve()==origin
 files=image['imageFiles']['candidate']
 assert len(files)==32 and {p.name:sha(p) for p in origin.iterdir()}==files
 (root/'candidate').symlink_to(origin,target_is_directory=True)
'''+text[end:]
text=text.replace('RuntimeMaxSec=290','RuntimeMaxSec=260').replace('seconds=225','seconds=205')
compile(text,'quiet.py','exec')
write(lab/'quiet.py',text)