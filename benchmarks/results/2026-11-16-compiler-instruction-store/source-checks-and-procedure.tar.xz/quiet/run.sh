set -eu
root=/home/lokad/lython-bench-checks/compiler-store-b820-20261116
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
