from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-16-compiler-instruction-store');out.mkdir(exist_ok=True)
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['summary.json','allocation-summary.json','focused-checks.json','equivalence.json','diagnostic-image-hashes.json']:
    shutil.copyfile(r/n,out/n)
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
p=out/'summary.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,
    decision='Remove both block wrappers and normalized/shortened instruction arrays; one single-use list reaches final tape. Compilation allocation3.35–4.74%lower; generated compilation modest lower elapsed/CPU. Manifest/fresh inconclusive with adverse timings retained; unchanged runtime control improvement is not attributed to source. Broader objective remains active.')
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz') as a:
    for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
    for p in r.iterdir():
        if p.is_file():a.add(p,arcname='procedure/'+p.name)
    a.add(r/'original',arcname='original-source')
    a.add(r/'checks',arcname='checks')
    for n in ['allocation','inspect']:
        for p in (r/n).iterdir():
            if p.is_file():a.add(p,arcname=n+'/'+p.name)
    for p in (r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):a.add(p,arcname='allocation-driver/'+p.name)
    for p in (r/'inspect/bin/Release/net11.0').glob('Inspect.*'):a.add(p,arcname='facts-driver/'+p.name)
    for p in q.iterdir():
        if p.is_file() and p.name not in {'observations.tgz','payload.tgz','representative.json'}:a.add(p,arcname='quiet/'+p.name)
print('Retained R424 source, copied cores, raw/adverse measurements, full checks and original conditions archived.')
