from pathlib import Path
import json
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('R424source design selected below; no other active runtime prototype.',
'''R424active prototype9d26d408 below; no other active runtime prototype.''')
needle='Full R423qualification proceeds independently. Finish this coherent decision before'
assert needle in s
v=json.loads((Path(__file__).parent/'quiet/observe-not-before.json').read_text(encoding='utf-8'))
s=s.replace(needle,'''Implemented prototype9d26d408,590inputs frozen. Nonincremental Release build and
151internal/1,011public focused checks eachactual11/10 pass. Compared final instruction
backing fields/spans, target/region/slot/read/call metadata agree with baseline for
all four complete sources; independent golden/budget cleanup gates pass. Allocation:
compile3.35–4.74%lower; generated-normalizer fresh3.88%lower. No CPU claim yet.
B820active (four jobs: manifest/generated compile, generated fresh, invoice warm);
observe only after '''+v['doNotObserveBeforeUTC']+'''. Same owner/quiet/floors/
archive gates; two archived8faliases retired with fresh proof, currenteee/9dremain.
Full R423qualification proceeds independently. Finish this coherent decision before''')
p.write_text(s,encoding='utf-8',newline='\n')
print('PLAN records active R424 source, checks/allocation and pending timing separately.')
