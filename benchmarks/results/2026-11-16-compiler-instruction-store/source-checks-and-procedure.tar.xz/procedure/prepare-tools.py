from pathlib import Path
import json, shutil

r=Path(__file__).parent
old=r.parent/'frontend-regions-r412'
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
controls=json.loads((r.parent/'finally-prefix-r423/catalog.json').read_text(encoding='utf-8'))
catalog['cases'] += [c for c in controls['cases'] if c['id'] in ['scripts.csv-invoice.large','scripts.json-summary-helpers.large']]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'inspect';d.mkdir(exist_ok=True)
shutil.copyfile(r.parent/'finally-prefix-r423/inspect/Inspect.csproj',d/'Inspect.csproj')
s=(r.parent/'finally-prefix-r423/inspect/Program.cs').read_text(encoding='utf-8')
s=s.replace('opcodeCounts = counts, calls', '''opcodeCounts = counts, calls,
                entry = Read(code, "EntryIndex"), regions = Read(code, "ExceptionRegions"),
                operandReads = code.GetType().GetField("_operandReadSpans", flags)!.GetValue(code),
                tape = ((IEnumerable)Read(code, "Instructions")!).Cast<object>().Select(i =>
                    i.GetType().GetFields(flags).OrderBy(f => f.Name).ToDictionary(f => f.Name, f => f.GetValue(i))).ToArray()''')
(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
d=r/'allocation';d.mkdir(exist_ok=True)
shutil.copyfile(r.parent/'regex-boundaries-r422/allocation-short/Allocation.csproj',d/'Allocation.csproj')
s=(r.parent/'regex-boundaries-r422/allocation-short/Program.cs').read_text(encoding='utf-8')
a=s.index('        using var script =');b=s.index('\n    }\n    finally',a)
s=s[:a]+'''        void Validate(LythonCompiledScript script)
        {
            if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        }
        void Compile()
        {
            using (var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget)) Validate(script);
            if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation retained allowance.");
        }
        void Fresh()
        {
            reset.Invoke(host, null);
            using (var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget))
            {
                Validate(script);
                using var result = script.Run(host);
                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                    throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
                if ((string)digest.Invoke(null, [check.Invoke(host, null)])! != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("File golden mismatch.");
            }
            if (budget.ReservedBytes != 0) throw new InvalidOperationException("Fresh invocation retained allowance.");
        }
        Fresh(); // Complete independent catalog goldens, outside compile-only counters.
        foreach (var phase in new[] { "compilation", "compile-run" })
        {
            Action invoke = phase == "compilation" ? Compile : Fresh;
            var warm = Stopwatch.StartNew();
            for (var i = 0; i < 4 || warm.Elapsed < TimeSpan.FromSeconds(0.5); i++) invoke();
            var batches = new List<double>();
            for (var block = 0; block < 3; block++)
            {
                var before = GC.GetTotalAllocatedBytes(precise: true);
                for (var i = 0; i < 4; i++) invoke();
                batches.Add((GC.GetTotalAllocatedBytes(precise: true) - before) / 4.0);
            }
            rows.Add(new { id = item.GetProperty("id").GetString(), phase, allocatedBytesPerInvocation = batches, sharedBudgetBaselineRestored = true });
        }''' +s[b:]
s=s.replace('Complete warm runs including mediated I/O/reset, all output/file checks and result cleanup; compilation/startup/final cache teardown excluded. Process-wide CLR allocation counters, no forced GC; no timing comparison.',
'''Compilation includes public compile/compiled-owner disposal, no I/O; independent complete goldens checked first. Compile-run includes compile/one execution/mediated I/O/reset/full goldens/result and compiled-owner cleanup. No startup or forced GC, process-wide natural allocation counters; no timing comparison.''')
(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
print('Existing catalog/inspector/allocation diagnostic adapted to compile/fresh; no new runtime instrumentation.')
