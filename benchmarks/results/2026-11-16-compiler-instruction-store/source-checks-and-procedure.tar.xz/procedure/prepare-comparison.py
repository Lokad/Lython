from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'finally-prefix-r423/launch-vm.py').read_text(encoding='utf-8')
s=s.replace("r.parent/'regex-boundaries-r422/delivery/", "r.parent/'finally-prefix-r423/delivery/")
s=s.replace("'7d522f1f'", "'e6500781'").replace("==592", "==591")
s=s.replace("old=r.parent/'regex-boundaries-r422/refinement/quiet'", "old=r.parent/'finally-prefix-r423/quiet'")
s=s.replace('regex-boundaries-b818-20261116','finally-prefix-b819-20261116')
s=s.replace('lython-b818-regex-boundaries-20261116','lython-b819-finally-prefix-20261116')
s=s.replace('finally-prefix-b819-20261116','compiler-store-b820-20261116',1)
s=s.replace("unit='lython-b819-finally-prefix-20261116'", "unit='lython-b820-compiler-store-20261116'")
s=s.replace("sourceRevision='R423 uncommitted'", "sourceRevision='R424 uncommitted'")
s=s.replace(' versus committed7d522f1f/frozen8f468f0a; full43783452636active at staging',
            ' versus committede6500781/frozeneee74a10; full43787325151active at staging')
s=s.replace('Conservative native prefix before earliest finally suite replaces whole-function exclusion; complete invoice with observable per-row cleanup warm/fresh and unchanged invoice/JSON controls. No new controller/arena/dispatch or policy.',
            'One compiler block instruction store replaces duplicate normalized/forwarded arrays and wrappers. Complete manifest/generated normalizer compile, generated fresh, unchanged invoice warm control; no runtime ABI, unsafe API or policy change.')
s=s.replace("referenceQualificationRun='43783452636'", "referenceQualificationRun='43787325151'")
a=s.index('jobs=');b=s.index('\nfor n in',a)
s=s[:a]+"jobs=[['scripts.config-manifest.small','compile'],['scripts.config-generated-guards.medium','compile'],['scripts.config-generated-guards.medium','compile-run'],['scripts.csv-invoice.large','warm']]"+s[b:]
s=s.replace(".replace('finally-prefix-b819-20261116','finally-prefix-b819-20261116')", ".replace('finally-prefix-b819-20261116','compiler-store-b820-20261116')")
s=s.replace(".replace('B818','B819')", ".replace('B819','B820')")
s=s.replace(".replace('lython-b819-fixtures','lython-b819-fixtures')", ".replace('lython-b819-fixtures','lython-b820-fixtures')")
assert "source='/home/lokad/lython-bench-checks/finally-prefix-b819-20261116'" in s
assert "root='/home/lokad/lython-bench-checks/compiler-store-b820-20261116'" in s
ast.parse(s);(r/'launch-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('B820 planned: two compile, one fresh, one unchanged warm control, current frozen sources and inherited ownership/quiet gates.')
