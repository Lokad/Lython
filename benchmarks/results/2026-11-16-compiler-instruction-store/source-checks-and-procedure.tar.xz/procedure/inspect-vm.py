from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive='benchmarks/results/2026-11-16-finally-prefix/source-checks-and-procedure.tar.xz'
raw=Path(archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
member='frozen/reference/Lokad.Lython.dll'
with tarfile.open(fileobj=io.BytesIO(raw)) as a:core=a.extractfile(member).read()
sha=hashlib.sha256(core).hexdigest();assert sha=='8f468f0a5cde74127abf48e9f7a929272e0906a523cef4a006cd494f969f3632'
s=(r.parent/'finally-prefix-r423/inspect-vm-generated.py').read_text(encoding='utf-8')
s=s.replace('format-operation-b814-20261115/candidate','regex-boundaries-b818-20261116/candidate')
s=s.replace('0393331afcdd9bffcb3dc1b2e1764316df152a20749ec08cec0c51f6e9a1b12f',sha)
(r/'inspect-vm-generated.py').write_text(s,encoding='utf-8',newline='\n')
p=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'inspect-vm-generated.py')],capture_output=True,timeout=45);assert p.returncode==0,p.stderr
v=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert v['sha256']==sha and v['bytes']==len(core)
v['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member)
(r/'historical-aliases.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(v))
