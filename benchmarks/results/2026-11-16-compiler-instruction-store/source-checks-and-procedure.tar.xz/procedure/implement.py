from pathlib import Path
import json, shutil, subprocess

r=Path(__file__).parent
files=['ExecutableScript.Builder.cs','ExecutableScript.Infrastructure.cs',
       'ExecutableScript.SuspendingExpressions.cs','ExecutableScript.Expressions.cs',
       'ExecutableScript.cs','ExecutableStackLayout.cs','ExecutableScript.CasedSplits.cs']
root=Path('src/Lokad.Lython/Frontend')
assert not (r/'original').exists()
(r/'original').mkdir()
for n in files: shutil.copyfile(root/n,r/'original'/n)
(r/'baseline.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    coreSHA256='eee74a1030fc154f3de9e35843fac8b178834ea339ea2f45b282935da0fb55f4',
    fullQualificationPending=True,sourceGate='Single-use block lists already own all instructions. No external callers retain them; final code keeps only linear tape. Remove two block wrappers, normalized/forwarded arrays and duplicate copying; no runtime ABI or semantic analysis change.'),indent=2)+'\n',encoding='utf-8',newline='\n')
for n in files:
    p=root/n;s=p.read_text(encoding='utf-8')
    s=s.replace('List<BasicBlockBuilder>', 'List<List<ExecutableInstruction>>')
    s=s.replace('IReadOnlyList<ExecutableBasicBlock>', 'IReadOnlyList<List<ExecutableInstruction>>')
    s=s.replace('List<ExecutableBasicBlock>', 'List<List<ExecutableInstruction>>')
    s=s.replace('_blocks[blockIndex].Instructions','_blocks[blockIndex]')
    s=s.replace('_blocks[originalIndex].Instructions','_blocks[originalIndex]')
    s=s.replace('_blocks[startBlock].Instructions','_blocks[startBlock]')
    s=s.replace('_blocks[block].Instructions','_blocks[block]')
    s=s.replace('_blocks[i].Instructions','_blocks[i]')
    if n=='ExecutableScript.Infrastructure.cs':
        s=s.replace('_blocks.Add(new BasicBlockBuilder(index));','_blocks.Add([]);')
        old='''                var rewritten = new ExecutableInstruction[instructions.Count];
                for (var i = 0; i < rewritten.Length; i++)
                    rewritten[i] = RewriteInstructionTargets(instructions[i], indexMap, jumpTargets);
                normalized.Add(new ExecutableBasicBlock(NormalizedBlock(indexMap, originalIndex), rewritten));'''
        new='''                // This single-use builder owns the lists throughout preparation.
                // Normalize targets in place; only the final tape needs an array.
                for (var i = 0; i < instructions.Count; i++)
                    instructions[i] = RewriteInstructionTargets(instructions[i], indexMap, jumpTargets);
                normalized.Add(instructions);'''
        assert old in s;s=s.replace(old,new)
        s=s.replace('block.Instructions','block')
        a=s.index('        private sealed class BasicBlockBuilder\n');b=s.index('        // A for-loop',a)
        s=s[:a]+s[b:]
    if n=='ExecutableScript.cs':
        a=s.index('internal sealed record ExecutableBasicBlock(');b=s.index('internal sealed record ExecutableExceptionRegion(',a)
        s=s[:a]+s[b:]
    if n=='ExecutableStackLayout.cs':
        s=s.replace('blocks[i].InstructionArray','blocks[i]').replace('blocks[blockIndex].InstructionArray','blocks[blockIndex]').replace('blocks[block].InstructionArray','blocks[block]')
        s=s.replace('source.Length','source.Count').replace('instructions.Length','instructions.Count')
        s=s.replace('static bool Completes(ExecutableBasicBlock block) => block.InstructionArray.Length == 0 ||\n            block.InstructionArray[^1].OpCode',
                    'static bool Completes(List<ExecutableInstruction> block) => block.Count == 0 ||\n            block[^1].OpCode')
        s=s.replace('blocks[i].Length','blocks[i].Count')
        s=s.replace('blocks[block] = blocks[block] with { InstructionArray = instructions[..kept] };',
                    'instructions.RemoveRange(kept, instructions.Count - kept);')
    if n=='ExecutableScript.CasedSplits.cs':
        s=s.replace('block.InstructionArray','block').replace('instructions.Length','instructions.Count')
        s=s.replace('PrepareCasedSplit(ExecutableInstruction[] instructions,','PrepareCasedSplit(IReadOnlyList<ExecutableInstruction> instructions,')
    p.write_text(s,encoding='utf-8',newline='\n')
print('Removed block wrappers and normalized/forwarded instruction arrays; single-use lists reach final tape.')
