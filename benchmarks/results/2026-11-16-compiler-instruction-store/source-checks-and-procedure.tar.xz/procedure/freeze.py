from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;f=r/'frozen';f.mkdir();images={}
base=r.parent/'finally-prefix-r423/frozen/candidate'
for role in ['reference','candidate']:
    target=f/role;shutil.copytree(base,target)
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir() if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='eee74a1030fc154f3de9e35843fac8b178834ea339ea2f45b282935da0fb55f4'
assert all(images['candidate'][n]==h for n,h in images['reference'].items() if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
paths+=['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json']
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz') as a:
    for p in paths:a.add(p,arcname=p)
    a.add(r/'checks',arcname='checks')
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,
    contracts='One single-use list per block throughout compiler preparation replaces two wrappers and duplicate normalized/forwarded instruction arrays. Final linear tape, scopes, semantics, runtime ABI and policies unchanged; no unsafe APIs.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib) for p in (r/'checks').glob('*.trx')]
assert sorted(int(x['passed']) for x in checks)==[151,151,1011,1011] and all(x['failed']=='0' for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,frameworks=['net11.0','net10.0'],fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll'] for role,v in images.items()},sourceInputs=len(paths),checks=[(x['file'],x['passed']) for x in checks]))
