from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tempfile,time
r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ,DOTNET_ROOT=sdk)
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
data={};images={};start=time.monotonic()
for role in ['reference','candidate']:
    d=r/('facts-'+role);d.mkdir()
    for p in (r/'inspect/bin/Release/net11.0').glob('Inspect.*'):shutil.copyfile(p,d/p.name)
    shutil.copyfile(r/'frozen'/role/'Lokad.Lython.dll',d/'Lokad.Lython.dll')
    output=r/('compiler-facts-'+role+'.json')
    p=subprocess.run([sdk+'/dotnet.exe',str(d/'Inspect.dll'),str(r/'catalog.json'),str(output)],env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)
    assert p.returncode==0,p.stderr
    v=json.loads(output.read_text(encoding='utf-8'));assert v['coreSHA256']==identity['images'][role]['Lokad.Lython.dll']
    data[role]=v
    images['facts-'+role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
assert data['reference']['rows']==data['candidate']['rows'],'Final instructions/slots/regions/calls differ; investigate before timing.'
(r/'equivalence.json').write_text(json.dumps(dict(equal=True,cases=[v['id'] for v in data['reference']['rows']],
    compared='Every final instruction backing field including original span; exception regions, entry, cold operand-read spans, slots, locals/closures, call sites and eligibility, recursively defined functions. Known compiled metadata, no guest tracing. Independent semantic/lifetime/cancellation tests remain necessary.'),indent=2)+'\n',encoding='utf-8',newline='\n')
data={}
with tempfile.TemporaryDirectory(prefix='lython-compile-allocation-') as directory:
    env['TEMP']=directory;env['TMP']=directory
    for role in ['reference','candidate']:
        d=r/'allocation'/role;shutil.copytree(r/'frozen'/role,d)
        assert all(hashlib.sha256((d/n).read_bytes()).hexdigest()==h for n,h in identity['images'][role].items())
        for p in (r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):shutil.copyfile(p,d/p.name)
        images['allocation-'+role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
        output=r/'allocation'/(role+'.json');assert not output.exists()
        with (r/'allocation'/(role+'.log')).open('w',encoding='utf-8') as log:
            p=subprocess.run([sdk+'/dotnet.exe',str(d/'ValidatedAllocation.dll'),str(d),str(r/'catalog.json'),str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
        assert p.returncode==0,(r/'allocation'/(role+'.log')).read_text(encoding='utf-8')[-1500:]
        data[role]=json.loads(output.read_text(encoding='utf-8'));print(role,'complete',flush=True)
    assert not list(Path(directory).iterdir())
rows=[]
for x in data['reference']['rows']:
    a=statistics.median(x['allocatedBytesPerInvocation'])
    b=statistics.median(next(v for v in data['candidate']['rows'] if (v['id'],v['phase'])==(x['id'],x['phase']))['allocatedBytesPerInvocation'])
    rows.append(dict(case=x['id'],phase=x['phase'],referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1)))
(r/'diagnostic-image-hashes.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,complete=True,elapsedSeconds=time.monotonic()-start,
    allOutputAndFileGoldensPassed=True,budgetBaselineAndCleanupPassed=True,CPUorElapsedClaim=False,
    boundary=data['candidate']['boundary']),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows),flush=True)
