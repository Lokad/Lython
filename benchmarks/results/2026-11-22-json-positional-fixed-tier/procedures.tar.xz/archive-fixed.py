from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
q=lab/"fixed-tier"
out=lab.parents[3]/"benchmarks/results/2026-11-22-json-positional-fixed-tier"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

receipt=load(q/"archive-receipt.json")
assert receipt["complete"] and receipt["jobs"]==2 and receipt["archivedAndVerifiedUnderLease"]
assert hashlib.sha256((q/"observations.tgz").read_bytes()).hexdigest()==receipt["archiveSHA256"]
raw=load(q/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and len(raw["jobs"])==2 and all(j["workersJoinedAndFixturesRemoved"] for j in raw["jobs"])
for job in raw["jobs"]:
    for worker in job["identities"].values():
        assert {k:v for k,v in worker["runtimeOverrides"].items() if v is not None}=={"DOTNET_TieredCompilation":"0"}
summary=load(q/"quiet-summary.json")
summary["retentionDecisionPending"]=False
summary["policy"]="diagnostic fixed tier"
out.mkdir(exist_ok=True)
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(q/name,out/name)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
files=("prepare-fixed.py","launch-fixed.py","summarize-fixed.py","archive-fixed.py","fixed-tier/observe-not-before.json")
with tarfile.open(out/"procedures.tar.xz","w:xz") as a:
    for name in files:a.add(lab/name,arcname=name)
with tarfile.open(out/"procedures.tar.xz") as a:assert set(a.getnames())==set(files)
