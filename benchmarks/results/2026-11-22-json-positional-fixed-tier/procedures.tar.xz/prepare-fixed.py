from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
previous=lab/"confirmation"
out=lab/"fixed-tier"
out.mkdir()
old=json.loads((previous/"config.json").read_text(encoding="utf-8"))
receipt=json.loads((previous/"archive-receipt.json").read_text(encoding="utf-8"))
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert hashlib.sha256((previous/"observations.tgz").read_bytes()).hexdigest()==receipt["archiveSHA256"]
replica="post-capture-first-use-profile-b1357-20261122/observations.tgz"
storage=json.loads((lab/"cpython-inventory.json").read_text(encoding="utf-8"))
proof=next(row for row in storage["found"] if row["path"]==replica)
artifact="origin/master:benchmarks/results/2026-11-22-post-capture-first-use-profile/"
canonical=subprocess.check_output(["git","show",artifact+"observations.tgz"],cwd=lab.parents[3])
archive_receipt=json.loads(subprocess.check_output(["git","show",artifact+"archive-receipt.json"],cwd=lab.parents[3]))
assert archive_receipt["complete"] and archive_receipt["allWorkersJoined"] and archive_receipt["archivedAndVerifiedUnderLease"]
assert proof["links"]==1 and len(canonical)==proof["bytes"]
assert hashlib.sha256(canonical).hexdigest()==proof["sha256"]==archive_receipt["archiveSHA256"]
root="/home/lokad/lython-bench-checks/json-positional-fixed-tier-b1379-20261122"
unit="lython-b1379-json-positional-fixed-tier-20261122"
identity=old["identity"]
identity["purpose"]="Repeat the B1377 controls with tiering disabled as a diagnostic"
identity["diagnosticRuntimeOverride"]={"DOTNET_TieredCompilation":"0"}

def write(path, text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")

write(out/"identity.json",json.dumps(identity,indent=2)+"\n")
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    text=(previous/name).read_text(encoding="utf-8").replace(old["unit"],unit).replace(old["root"],root).replace("B1377","B1379")
    if name=="collect.py":
        at=text.index("\ncpu_frequency = ")
        text=text[:at]+"\nenv['DOTNET_TieredCompilation']='0'\n"+text[at:]
        assertion="assert not self.identity['serverGc'] and not any(self.identity['runtimeOverrides'].values())"
        assert text.count(assertion)==1
        text=text.replace(assertion,"assert not self.identity['serverGc']\n"
            "            assert {k:v for k,v in self.identity['runtimeOverrides'].items() if v is not None}=={'DOTNET_TieredCompilation':'0'}")
        text=text.replace("no forced GC or runtime overrides",
            "no forced GC and only the declared DOTNET_TieredCompilation=0 diagnostic override")
    write(out/name,text)
assert b"\r" not in (out/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh")
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as tar:
    for name in parts:tar.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
stage=dict(old,root=root,unit=unit,identity=identity,
           retireGroups=[dict(paths=[replica],links=1,bytes=proof["bytes"],sha256=proof["sha256"],archives={})],
           payloadBytes=payload.stat().st_size,payloadSHA256=hashlib.sha256(payload.read_bytes()).hexdigest(),
           unpackedBytes=unpacked)
write(out/"config.json",json.dumps(stage,indent=2)+"\n")
remote=(previous/"remote-launch.py").read_text(encoding="utf-8")
a,b=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:a]+"c="+repr(stage)+remote[b:]
write(out/"remote-launch.py",remote.replace("lython-b1377-fixtures","lython-b1379-fixtures"))
write(lab/"launch-fixed.py",(lab/"launch-confirmation.py").read_text(encoding="utf-8")
      .replace("parent/'confirmation'","parent/'fixed-tier'").replace("Reversed-order positional control","Fixed-tier positional diagnosis"))
write(lab/"summarize-fixed.py",(lab/"summarize-confirmation.py").read_text(encoding="utf-8").replace("/'confirmation","/'fixed-tier"))
