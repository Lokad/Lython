from pathlib import Path
import subprocess
r=Path(__file__).parent
s=(r/'measure.py').read_text(encoding='utf8').replace("[('warm','sync'),('warm','async')]","[('compile','sync')]").replace("(phase+'-'+api)","(phase+'-qualified-'+api)").replace("r/'images/before/","r/'images/qualified/")
(r/'measure-compile-qualified.py').write_text(s,encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-compile-qualified.py')],check=True)
s=(r/'compile-diagnostic.py').read_text(encoding='utf8');a=s.index("s=(r/'measure.py')");z=s.index('d=json.loads',a)
s=s[:a]+s[z:];s=s.replace('compile-sync/measurements.json','compile-qualified-sync/measurements.json').replace('compile-assessment.json','compile-qualified-assessment.json').replace('Compilation only through existing diagnostic driver','Qualified1310 versus final93e9, compilation only through existing diagnostic driver')
exec(compile(s,str(r/'compile-qualified.py'),'exec'))
