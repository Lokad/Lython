from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'primitive-helpers-r113/qualify.py').read_text(encoding='utf8')
exec(compile(s,str(r/'qualify.py'),'exec'))
