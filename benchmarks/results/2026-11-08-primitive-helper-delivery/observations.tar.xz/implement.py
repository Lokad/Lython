from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;old=r.parent/'independent-proof-r114';i=json.loads((old/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
(r/'baseline.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8');shutil.copyfile('PLAN.md',r/'prior-plan.md')
paths=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs']
for p in paths:
    q=r/'original'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for role,origin in [('before',old/'images/candidate'),('candidate',old/'images/candidate'),('qualified',old/'images/qualified')]:shutil.copytree(origin,r/'images'/role,copy_function=os.link)
(r/'proposal.md').write_text('''R115 bounded coherent correction after preserved R114 adverse async-float+4.14–6.29%: share one pure native binary result-shape fact between compiler and runtime for exact BigInteger/double/bool plus existing string addition. Numeric operators still invoke the same canonical evaluator; no new arithmetic implementation, value representation, owner, cache, flags, call-control carrier or repeated-probe policy. Integer/float/bool are CLR primitives with no guest protocols. Stable arithmetic/comparison/bitwise result shapes only; unsupported power/matrix/identity/membership proofs rejected during preparation instead of retaining permanently unusable Binary metadata. General guest operations remain supported by ordinary executable dispatch. Preserve native-descriptor independence and operand forwarding, managed depth, exact promotion/errors/context/evaluation order, cancellation/refusal and alias funding. Mixed/custom/suspending protocols remain ordinary; measure a genuine Quantity.__mul__ guard-miss accounting variation explicitly rather than rename a passing float case as a miss.
Source-visible repeated rejected proof attempts may contribute to float cost, not proven to explain all CPU. Scope correction lets common primitive shapes share the existing route; do not revive slower R71 control/arena carriers. Source gate~15min then focused actual11/10 semantic/cancellation/ownership checks, normal warm/compile allocation diagnostics and one bounded combined qualified1310/current whole-script comparison. Final retain/refine/reject with explicit custom/control debt; full platform/Stress/installed-core at coherent retained boundary. This is not the entire performance objective; next bounded text/report CPU attribution follows while delivery runs. Native dictionary scalar-update admission hypothesis is disproven: capacity already funds scalar slots and StoreNativeValue only assigns an array element; no new subsystem there. Regex/publication independent.
''',encoding='utf8')
p=Path(paths[0]);s=p.read_text(encoding='utf8').replace('    private enum NativeReturnShape','    internal enum NativeReturnShape')
a=s.index('                var op = code.Instructions[value.SourceInstruction]') if 'code.Instructions[value.SourceInstruction]' in s else s.index('                var op = value.Instruction.BinaryOperator;')
z=s.index('            case NativeReturnOperation.Subscript:',a)
s=s[:a]+'''                return TryGetNativeBinaryShape(value.Instruction.BinaryOperator, first, right, out shape);
'''+s[z:]
at=s.index('    private static bool GuardNativeReturn(')
fact='''    // One pure fact serves frontend eligibility and the runtime type proof.
    // It authorizes canonical operations, never evaluates values or protocols.
    internal static bool TryGetNativeBinaryShape(BinaryOperatorSyntax op, NativeReturnShape left,
        NativeReturnShape right, out NativeReturnShape result)
    {
        result = NativeReturnShape.Other;
        if (op == BinaryOperatorSyntax.Add && left == NativeReturnShape.String && right == left)
        {
            result = left;
            return true;
        }
        if (left is not (NativeReturnShape.Integer or NativeReturnShape.Float or NativeReturnShape.Boolean)
            || right is not (NativeReturnShape.Integer or NativeReturnShape.Float or NativeReturnShape.Boolean)) return false;
        var integral = left != NativeReturnShape.Float && right != NativeReturnShape.Float;
        result = op switch
        {
            BinaryOperatorSyntax.Add or BinaryOperatorSyntax.Subtract or BinaryOperatorSyntax.Multiply
                or BinaryOperatorSyntax.FloorDivide or BinaryOperatorSyntax.Modulo
                => integral ? NativeReturnShape.Integer : NativeReturnShape.Float,
            BinaryOperatorSyntax.Divide => NativeReturnShape.Float,
            BinaryOperatorSyntax.BitwiseOr or BinaryOperatorSyntax.BitwiseXor or BinaryOperatorSyntax.BitwiseAnd when integral
                => left == NativeReturnShape.Boolean && right == left ? NativeReturnShape.Boolean : NativeReturnShape.Integer,
            BinaryOperatorSyntax.LeftShift or BinaryOperatorSyntax.RightShift when integral => NativeReturnShape.Integer,
            BinaryOperatorSyntax.Equal or BinaryOperatorSyntax.NotEqual or BinaryOperatorSyntax.Less
                or BinaryOperatorSyntax.LessEqual or BinaryOperatorSyntax.Greater or BinaryOperatorSyntax.GreaterEqual
                => NativeReturnShape.Boolean,
            _ => NativeReturnShape.Other,
        };
        return result != NativeReturnShape.Other;
    }

'''
s=s[:at]+fact+s[at:];p.write_text(s,encoding='utf8')
p=Path(paths[1]);s=p.read_text(encoding='utf8');needle='                    case ExecutableOpCode.Binary:\n';assert s.count(needle)==1
s=s.replace(needle,'''                    case ExecutableOpCode.Binary when LythonRuntime.TryGetNativeBinaryShape(instruction.BinaryOperator,
                        LythonRuntime.NativeReturnShape.Integer, LythonRuntime.NativeReturnShape.Integer, out _):
''');p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');s+='''
R114/B474 intermediate corea383d084 archived/all output/ownership/quiet/cleanup gates,
223.498s. Integer gains persist; async floatCSV+4.14–6.29%adverse, no final promotion.
R115 priority bounded correction: one shared compiler/runtime primitive numeric
shape fact (BigInteger/double/bool), canonical operations, retain independent proof
descriptors/ordinary forwarding; remove permanently unsupported Binary metadata.
Measure actual custom Quantity.__mul__ guard miss, not pretend float still misses.
No call-control flags/carriers or universal scalar design. Focused checks, warm/
compile diagnostics, one combined controlled source pair, explicit debt decision
then full coherent delivery. Dictionary-update admission hypothesis disproven:
scalar capacity is already funded, StoreNativeValue only assigns; no work selected.
Applied B474 launch command270s, metadata210 error/terminal infinity preserved;
earlier live limit unverified, no abandoned users or retrospective claim. B474
terminal cached/archived/localverified; never query again. Publication postponed.
''';p.write_text(s,encoding='utf8');shutil.copyfile(p,r/'pre-implementation-plan.md')
print('R115 shared primitive proof implemented; unsupported binary metadata excluded, canonical operations unchanged.')
