from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'independent-proof-r114/b474';b=r/'b475';b.mkdir()
i=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['scripts.csv-integer-accounting.large','warm'],['scripts.json-integer-accounting.large','warm'],*[ [case,lane] for case in ['scripts.csv-float-accounting.large','scripts.csv-protocol-accounting.large'] for lane in ['warm','warm-async']],['scripts.text-summary-helpers.large','warm'],['scripts.report-render.large','warm']]
identity={**prior,'sourceRevision':i['candidateSource'],'baselineSource':i['controlledReference'],'coreSHA256':{role:i['coreSHA256']['qualified' if role.startswith('reference') else 'candidate'] for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':i['productionSources'],'qualification':i['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
    s=(old/name).read_text(encoding='utf8').replace('independent-proof-b474-20261108','primitive-proof-b475-20261108').replace('lython-b474-independent-proof','lython-b475-primitive-proof').replace('independent-proof-b474-launch.py','primitive-proof-b475-launch.py').replace('lython-b474-fixtures','lython-b475-fixtures').replace('ownerSeconds=210','ownerSeconds=270')
    if name=='collect.py':
        a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
        a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R115 coherent shared primitive binary fact and independent native proof descriptors, ordinary forwarding; qualified1310 baseline, integer/float/custom accounting and text/report controls"+s[z:]
    if name=='run.sh':
        marker='date -u +%FT%TZ > "$root/started.utc"\n';assert marker in s
        s=s.replace(marker,marker+'systemctl show lython-b475-primitive-proof-20261108.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"\n')
    if name=='archive-owned.py':
        s=s.replace("'started.utc','run.sh'","'started.utc','live-unit.txt','run.sh'")
        marker="with tarfile.open(root/'observations.tgz','w:gz')as a:\n";assert marker in s
        s=s.replace(marker,"live=(root/'live-unit.txt').read_text();assert 'LoadState=loaded' in live and 'RuntimeMaxUSec=infinity' not in live\n"+marker)
    (b/name).write_text(s,encoding='utf8',newline='\n')
    if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'representative.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
shutil.copyfile(old/'baseline-source.json',b/'baseline-source.json')
dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved/confirmation').rglob('*') if p.is_file());estimate=(dynamic+(old/'observations.tgz').stat().st_size+(r/'representative.json').stat().st_size)*1.5;assert estimate<12*1024*1024
(b/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorFullArchiveBytes=(old/'observations.tgz').stat().st_size,newCatalogBytes=(r/'representative.json').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,baselineArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=270,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('''R115 one bounded refinement of preserved R114 adverse async-float result. Existing canonical integer/double/bool arithmetic uses one pure compiler/runtime result-shape fact; no new arithmetic, frame, control carrier, owner, value representation, flags or repeated-probe policy. Independent immutable proof descriptors/ordinary forwarding retained. Unsupported binary proofs excluded during preparation, Python behavior stays ordinary.1526public/104internal focused peractual11/10; full retained-source delivery pending. Earlier metadata/control/adverse source pairs preserved, not silently repaid.
Eight jobs: integerCSV/JSONsync, floatCSVbothAPIs now intended native, actual custom Quantity guard-missCSVbothAPIs, unchanged text/report. Complete4096records/report/stdout independently validated with CPython. Same frozen7cf/host/optional0.4/normalGC/tiering, two roles/core,5swarmup,7rotated150msrounds.270sowner+30stop+30margin, final job admission<240. Live systemd finite limit captured by owned script at startup, descriptive owner fields corrected before run; previous terminal infinity/metadata210 preserved separately. Warm includes invocation/mediated RAM I/O/fullvalidation/prior-resultcleanup, excludes compile/startup/staging/finalcacheteardown. Local incremental a383/current allocation/compile separate; controlled reference qualified1310. No new CPython timing campaign/framework or ratio inference.
All Ready/core/aux/quiet/golden/baseline/Closed/exit/join/unmount/archive/local gates. Persistent evidence, owned128MiB RAMfixtures. Unchanged OS240MiB/evidence12MiB/actualpayload preflight, completed prior dynamic+archive+catalog+50% fitsheadroom. Baseline archive reused, all old paths/bytes/archives retained. Decide complete milestone with explicit custom/control debt, full platform/Stress/installed-core once retained; performance roadmap continues, regex/publication independent.
''',encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for name in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','baseline-source.json','sizing.json']:t.add(b/name,arcname=name)
print('B475 eight-job final coherent comparison prepared, actual custom guard miss and live limit evidence explicit.')
