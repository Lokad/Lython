from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
a=json.loads((r/'b475/archive-receipt.json').read_text(encoding='utf8'))
assert a['complete'] and a['jobs']==8 and a['allWorkersJoined'] and a['quietBeforeAndAfter'] and not a['guestFixtureDirectories']
assert hashlib.sha256((r/'b475/observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
live=(r/'b475/retrieved/live-unit.txt').read_text(encoding='utf8');assert 'RuntimeMaxUSec=4min 30s' in live and 'LoadState=loaded' in live and 'ActiveState=active' in live
status=dict(status='Retained coherent R113/R114/R115 source, commit/full delivery qualification pending. No public API change; publication postponed.',decision='Retain one primitive result-shape fact and independent immutable proof descriptors with ordinary forwarding; canonical arithmetic/semantics, no new engine/representation/arena/cache/owner/control carrier. Explicitly accept measured custom-operator async debt and compiled metadata cost; next current-source CPU attribution includes this debt and complete text.',validation=i['focusedChecks'],measurement='B475224.458s/all output/ownership/quiet/lifecycle/archive gates. IntegerCSVelapsed−3.80to−5.17%,CPU−3.45%; JSON−3.47to−4.93%,CPU−3.57to−9.24%; floatCSV−1.76to−3.45%sync/−2.23to−6.16%async,CPU supports. CustomCSVsync−0.87to+2.57%with3.19%oldspread,async+1.28to+3.36%/CPU+6.67%debt. Text−2.69to+1.69%oldspread3.54%inconclusive; report−0.74to+0.54%/CPU0to+6.25%possible debt. Original adverse R114+4.14–6.29%float source pair preserved, not erased by refinement.',allocation='Incremental warm diagnostics neutral; final qualified1310/current compile allocation+1.40–1.48%accounting/+0.59%text/report unchanged, desktop elapsed uncertain. Native nodes32to72B, instructions32B unchanged, ordinary forwarded loads removed. Coarse compilation allowance intentionally approximate.',limits='New complete4096-record accounting variations, not refreshed CPython performance cases. Warm includes invocation/mediated RAM I/O/full stdout/file validation/prior-result cleanup; excludes compile/startup/staging/final cache teardown. No pending-I/O/embedding-tail/RSS claim. Custom protocol slowdown retained; no universal speedup or CPU attribution from source alone.',lifecycle='Live finite270s owner captured atstartup; terminal transient unit resets toinfinity, original terminal data retained. Users joined/ownedRAMunmounted/archive locallyverified; no repeated terminal query. Earlier B474metadata errors and all adverse intermediate sources remain independent.')
(r/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
out=Path('benchmarks/results/2026-11-08-primitive-helper-delivery');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name=='images':
            for role in ['before','candidate','qualified']:t.add(p/role/'Lokad.Lython.dll',arcname='images/'+role+'/Lokad.Lython.dll')
        elif p.name=='b475':
            for q in sorted(p.iterdir()):
                if q.name not in ['retrieved','payload.tgz']:t.add(q,arcname='b475/'+q.name)
        else:t.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as t:assert hashlib.sha256(t.extractfile('b475/observations.tgz').read()).hexdigest()==a['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'status.json','status.json'),(r/'b475/assessment.json','assessment.json'),(r/'assessment-local.json','incremental-allocation.json'),(r/'compile-qualified-assessment.json','compilation.json'),(r/'b475/archive-receipt.json','archive-receipt.json'),(r/'b475/retrieved/live-unit.txt','live-unit.txt')]:shutil.copyfile(src,out/name)
(out/'README.md').write_text('''# Primitive helper proof and ordinary forwarding

2026-11-08. Retained combined R113/R114/R115 source over9b61264b, frozen core
93e926fe; reference fully qualified05790317/core13107e6b. Focused1526public/104
internal Release pass peractual.NET11/.NET10. Full delivery qualification pending.
Public API/Python behavior unchanged; publication postponed.

One pure compiler/runtime fact proves stable BigInteger/double/bool arithmetic,
comparisons/bitwise operations and existing string addition; execution uses the
canonical operators. Permanently unsupported native binary proofs are rejected
during preparation; their supported Python behavior stays ordinary. Existing
native proof nodes own immutable opcode descriptors and member/return spans,
removing runtime source/return/member offsets and the native/operand-forwarding
mutual exclusion. Ordinary code forwards loads even when a dynamic guard fails.
No new evaluator/backend/value representation/owner/cache/arena/call-control flag.

Independent CPython goldens cover mixed primitives, negative floor/modulo,
promotion, defaults/order, zero division/error context, Decimal/complex and custom
protocols. Actual suspended multiply/reflected protocols cancel and release funded
owners. Integer result refusal/after-admission cancellation preserve origin/cleanup.
Intermediate assertion/build-identity/measurement corrections remain linked below.

Same quiet F4as_v7/Ubuntu24.04.4/four EPYC9V45vCPUs/16GiB/no swap, .NET11RC3,
frozen worker7cf/optional0.4, normal GC/tiering. Two isolated roles/core,5swarmup,
7rotated150msrounds,8jobs224.458s. Warm includes invocation, mediated RAM-file I/O,
complete stdout/file validation and prior-result cleanup; excludes compilation,
startup/protocol/staging/final cache teardown. New accounting variations have4096
records and full CSV reports, independently checked with CPython3.13. They are
not a refreshed external performance comparison or proof of the historical gap.

| Script / API | Elapsed change across all pairings | Process CPU |
| --- | ---: | ---: |
| Integer CSV / sync |−5.17% to−3.80%|−3.45%|
| Integer JSON / sync |−4.93% to−3.47%|−9.24% to−3.57%|
| Float CSV / sync |−3.45% to−1.76%|−6.25% to−3.85%|
| Float CSV / async |−6.16% to−2.23%|−8% to0%|
| Custom operator CSV / sync |−0.87% to+2.57%|0% to+0.39%|
| Custom operator CSV / async |+1.28% to+3.36%|+6.67%|
| Unchanged text / sync |−2.69% to+1.69%|−2.41% to+2.44%|
| Unchanged report / sync |−0.74% to+0.54%|0% to+6.25%|

Negative is faster. Text old-role spread3.54% and custom-sync3.19% are inconclusive.
Report elapsed is nearbaseline but coarse CPU remains possible debt. Integer and
float gains are supported; custom async has measured regression debt. Rejected
proof attempts are source-visible, not isolated attribution of all CPU. Retain
the coherent simplification with that debt explicit; current whole-script CPU
assessment must include custom operators and text, without reviving slower
call-control/arena carriers. No universal CPU/speedup claim.

Incremental warm allocations are neutral. Direct qualified-reference compilation
allocation rises1.40–1.48%accounting/0.59%text, report unchanged; desktop elapsed is
uncertain. Proof nodes grow32→72B, ordinary instructions remain32B and forwarded
loads disappear. The admitted source-based compilation estimate remains coarse;
no claim of exact tiny-budget thresholds or free retained metadata.

All Ready/core/aux/golden/baseline/quiet/Closed/join/fixture/archive/local gates pass.
Live owner captured270s at startup; transient terminal unit reports infinity after
completion. No users or owned RAM remain. Exact-byte hardlinks under fresh idle
lease recovered11.17MB, every path/alias/content/archive retained, guards unchanged.

Preserved stages: [integer-only R113](../2026-11-08-integer-helper-prototype/README.md),
[independent proof R114](../2026-11-08-independent-native-proof/README.md), including
its adverse async-float+4.14–6.29% and limit metadata errors. These are different
source pairs; percentages are not additive and original debts are not erased.

[Status](status.json), [all roles](assessment.json), [identity](identity.json),
[incremental allocation](incremental-allocation.json), [direct compilation](compilation.json),
[receipt](archive-receipt.json), [live unit](live-unit.txt),
[all source/binaries/corrections/raw](observations.tar.xz).
''',encoding='utf8')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf8');needle='Prepared values refer to original\ninstructions and call inputs; evaluation requires no operand or argument arrays.'
assert needle in s;s=s.replace(needle,'''Prepared values own immutable original opcode metadata and member/return source
spans independently of physical bytecode positions. Ordinary operand forwarding
still applies when native guards fail. One shared compiler/runtime result-shape
fact covers primitive integer, float and boolean binary operations and string
addition; execution uses the canonical operators. Custom protocols keep ordinary
dispatch. Evaluation requires no operand or argument arrays.''');p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');needle='| Shared closed-method preparation / text helpers |';at=s.index(needle)
s=s[:at]+'| Primitive helper proof / complete accounting | Integer CSV/JSON elapsed −3.5–5.2%; float CSV −1.8–6.2% across APIs, supporting CPU; incremental warm allocation neutral | Metadata/ordinary forwarding consolidated; compiler allocation +1.4–1.5%accounting. Custom async +1.3–3.4%elapsed/+6.7%CPU debt, text/report uncertain. Frozen93e926fe; full qualification pending. [R113–R115](../benchmarks/results/2026-11-08-primitive-helper-delivery/README.md) |\n'+s[at:];p.write_text(s,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf8')+'''
## Coherent primitive helper delivery (2026-11-08)

[R115/B475](results/2026-11-08-primitive-helper-delivery/README.md) retains the
combined shared primitive proof and independent descriptor/ordinary-forwarding
design.1526public/104internal peractual11/10,8jobs224.458s/allgates/archive/local.
IntegerCSV/JSON−3.5–5.2%, floatCSV−1.8–6.2%across APIs/supportingCPU; prior adverse
float pair preserved. Warm allocations neutral in incremental diagnostics, direct
compile+1.40–1.48%accounting/+0.59%text. Native nodes32to72B/instructions32B.
Custom async+1.28–3.36%/CPU+6.67%explicit debt; text controls variable, reportCPU
possible debt. Retain coherent simplification with those limits, full delivery
pending. Live270slimit captured; all historical conditions/intermediates remain.
Continue current complete text/custom CPU attribution and primary checkpoint,
not claim the performance objective complete or revive slower call carriers.
''',encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('   **Completion:**');z=s.index('\n2. **Coherent delivery',a)
s=s[:a]+'''   **Retained decision:** B4758jobs224.458s/allgates/archive/localverified; no users/
   RAM remain. IntegerCSV/JSONelapsed−3.5–5.2%, float−1.8–6.2%across APIs, CPU
   supports. Customasync+1.28–3.36%elapsed/+6.67%CPU is accepted explicit debt;
   customsync/text variable, report elapsed flat/CPUpossible debt. No universal
   speed claim. Live270sowner verified atstartup; earlier metadata errors/terminal
   infinity preserved. Commit/qualify combined source next; previous adverse pairs
   remain, this milestone does not complete the performance objective.
''' + s[z:]
s=s.replace('current complete text/report costs','current complete text/custom-operator costs').replace('complete text/report\n   scripts','complete text/custom-operator\n   scripts').replace('B450–B474 terminal/cached; B475 active.','B450–B475 terminal/cached/archived/locallyverified; no VM users/fixtures.')
p.write_text(s,encoding='utf8')
print('R115 coherent milestone retained with custom async/metadata debts explicit; evidence/docs/plan ready, full delivery pending.')
