from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent
ops=['+','-','*','//','%','|','^','&','<<','>>','/','==','!=','<','<=','>','>=']
source=''.join(f'def numeric{i}(a,b):return a {op} b\n' for i,op in enumerate(ops))
for a,b,integral in [('1.5','2',False),('-7.5','2.5',False),('0.0','-3.0',False),('True','True',True),('False','True',True),('True','3',True),('2**70+7','1.25',False)]:
    indexes=[i for i,op in enumerate(ops) if integral or op not in ['|','^','&','<<','>>']]
    source+='print('+','.join(f'numeric{i}({a},{b})' for i in indexes)+')\n'
source+='''def bits(a,b):return (a&b)^(a|b)
for a,b in [(True,True),(False,True),(True,3)]:
 value=bits(a,b)
 print(value,type(value).__name__)
def amount(quantity,cents,discount=10):return quantity*cents*(100-discount)//100
print(amount(1.5,199),amount(True,199),amount(-3.5,199,15))
'''
cases=[('primitive-numeric-mixed-return-shapes',source),('primitive-binary-protocols-and-declined-operators','''from decimal import Decimal
def multiply(value):return value*3
class Left:
 def __mul__(self,other):
  print('left once')
  return other+7
class Right:
 def __rmul__(self,other):
  print('right once')
  return other+8
def reflected(value):return 3*value
print(multiply(Left()),reflected(Right()))
print(multiply(1+2j),multiply(Decimal('1.25')))
def power(a,b):return a**b
def identity(a,b):return a is b
def contains(a,b):return a in b
items=[]
print(power(2,-3),identity(items,items),contains(2,[1,2]))
''')]
entries=[];receipts=[]
for name,source in cases:
    p=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',source],capture_output=True,check=True)
    expected=p.stdout.decode().replace('\r\n','\n')
    receipts.append(dict(name=name,source=source,expected=expected,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),reference='isolated CPython3.13'))
    entries.append('        { '+', '.join(json.dumps(x,ensure_ascii=False) for x in [name,source,expected])+' },\n')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs');s=p.read_text(encoding='utf8');needle='    public static TheoryData<string, string, string> Cases => new()\n    {\n';assert needle in s and 'primitive-numeric-mixed-return-shapes' not in s
p.write_text(s.replace(needle,needle+''.join(entries)),encoding='utf8')
(r/'semantic-goldens.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Two independent mixed-primitive/protocol/deferred-operator goldens recorded.')
