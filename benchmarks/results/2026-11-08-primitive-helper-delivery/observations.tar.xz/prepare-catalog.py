from pathlib import Path
import base64,copy,hashlib,json,struct,subprocess,tempfile
r=Path(__file__).parent;prior=json.loads((r.parent/'independent-proof-r114/catalog.json').read_text(encoding='utf8'))
c=copy.deepcopy(prior['cases'][0]);assert c['id']=='scripts.csv-integer-accounting.large'
c['id']='scripts.csv-protocol-accounting.large';c['source']='''class Quantity:
    def __init__(self,value):self.value=value
    def __mul__(self,other):return self.value*other
'''+c['source'].replace("quantity=int(record['quantity'])","quantity=Quantity(int(record['quantity']))")
f=json.loads(c['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-r115-cpython-') as folder:
    folder=Path(folder)
    for name,value in f['inputFiles'].items():(folder/name).write_bytes(base64.b64decode(value))
    p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,capture_output=True,check=True);assert not p.stderr
    output=(folder/'report.csv').read_bytes();stdout=p.stdout.replace(b'\r\n',b'\n')
f['outputFiles']['report.csv']=base64.b64encode(output).decode();digest=hashlib.sha256();key=b'report.csv'
for part in [struct.pack('>I',1),struct.pack('>I',len(key)),key,struct.pack('>I',len(output)),output]:digest.update(part)
c.update(fixtureJson=json.dumps(f,separators=(',',':')),sourceUtf8Bytes=len(c['source'].encode()),sourceSha256=hashlib.sha256(c['source'].encode()).hexdigest(),expectedOutput=stdout.decode(),expectedOutputUtf8Bytes=len(stdout),expectedOutputSha256=hashlib.sha256(stdout).hexdigest(),expectedFilesSha256=digest.hexdigest())
c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
allcases=[*prior['cases'],c]
(r/'representative.json').write_text(json.dumps({**prior,'cases':allcases},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
ids=['scripts.csv-integer-accounting.large','scripts.csv-float-accounting.large','scripts.csv-protocol-accounting.large','scripts.text-summary-helpers.large','scripts.report-render.large']
(r/'catalog.json').write_text(json.dumps({**prior,'cases':[next(c for c in allcases if c['id']==id) for id in ids]},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'protocol-accounting.py').write_text(c['source'],encoding='utf8')
(r/'workload-contract.md').write_text('''Local existing-driver five cases: integer CSV, float CSV (now intended native), custom Quantity CSV (actual guard miss/ordinary __mul__), unchanged text/report. Complete4096-row input/output, independent isolated CPython stdout/report goldens and original file digest. Final controlled eight jobs: integerCSV/JSON sync, floatCSV both APIs, customCSV both APIs, text/report sync. Qualified1310 baseline versus combined R113/R114/R115; local incremental baselinea383d084 preserved separately. No subtraction across runs, new framework or external CPython timing campaign.\n''',encoding='utf8')
print('Custom-protocol accounting full golden',stdout.decode().strip(),flush=True)
