from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).parent;b=json.loads((r/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in b['productionSources']}
assert {p for p,h in sources.items() if h!=b['productionSources'][p]}=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs'}
counts={}
for n in ['publicnet11.0','internalnet11.0','publicnet10.0','internalnet10.0']:
    s=(r/(n+'.log')).read_text(encoding='utf8');m=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert m,n;counts[n]=int(m[1])
for framework in ['net11.0','net10.0']:
    ps=[Path(p)/'bin/Release'/framework/'Lokad.Lython.dll' for p in ['src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests','tests/Lokad.Lython.Tests']]
    assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in ps})==1
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
i=dict(baselineSource='Intermediate R114 over9b61264b/corea383d084, adverse float case preserved; not fully qualified',controlledReference='Fully qualified05790317/core13107e6b, cached CI42502610937',candidateSource='9b61264b plus coherent R113/R114/R115 primitive binary native proof, immutable descriptors and ordinary forwarding',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate','qualified']},productionSources=sources,focusedChecks=counts,qualification='1526public/104internal focused Release peractual11/10 pass, including primitive int/float/bool/Decimal/complex/custom semantics, actual protocol suspension/cancellation and result admission/refusal cleanup. Full coherent retained-source delivery pending.',controls='Incremental local a383/current; final controlled qualified1310/current. Same frozenworker7cf/host/optional0.4, normalGC/tiering. Integer/float/customCSV complete4096records, unchanged text/report, JSONinteger additional controlled case. Distinguish new native float from actual Quantity guard miss. No external CPython timing refresh.')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']));shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for n in ['measure.py','assess-local.py','compile-diagnostic.py']:
    s=(r.parent/'independent-proof-r114'/n).read_text(encoding='utf8')
    if n=='assess-local.py':
        a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a);s=s[:a]+"out['limitations']='R115 incremental same-process ALC diagnostic from archived a383 to shared primitive proof; normalGC/tiering, bothAPIs. IntegerCSV, newly passing floatCSV, actual custom Quantity guard miss, unchanged text/report. Warm Run clocks, allocation includes full validation/fixture reset/prior-result cleanup. Desktop elapsed diagnostic; final controlled baseline is qualified1310, no subtracting different pairs or CPython timing claim.'"+s[z:]
    (r/n).write_text(s,encoding='utf8')
print('R115 frozen',i['coreSHA256'],counts,flush=True)
