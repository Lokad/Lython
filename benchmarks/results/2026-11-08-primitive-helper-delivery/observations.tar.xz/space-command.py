from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'380b78d49359b22ba73fe337ef400f4d1949485f6ef6e9945bfae49d86a9d108': ['/home/lokad/lython-bench-checks/native-key-construction-b139-20261103/legacy/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/json-key-storage-b138-refined-20261103/candidate/Lokad.Lython.dll'], '81deb3be4bf45f73a4a6372f1223014edc3bf09e8439f8da1eeffa018d1b4cfa': ['/home/lokad/lython-bench-checks/native-preparation-b246-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/format-construction-b249-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/prepared-text-report-cpu-b248-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/native-confirm-b247-20261105/candidate/Lokad.Lython.dll'], 'ad3eb74a8440b88fc7aa3bb4f5c9c9e9bd9ea9c5a5aebae0b8e63393e6f2d9a6': ['/home/lokad/lython-bench-checks/proc-stat-exit-20261011/original-bin/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/proc-stat-exit-20261011/corrected-bin/Lokad.Lython.dll'], '4c3f8fa9ad3fe49add25842dc62aabd047900f90fb55399a1a852b491aa41e58': ['/home/lokad/lython-bench-checks/csv-owned-record-b110-20261102/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/owned-output-b109-20261102/candidate/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free;inventory={};aliases={}
 for digest,names in groups.items():
  rows=[]
  for name in names:
   p=Path(name).resolve();assert base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   aliases[name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p) for row in rows):continue
   st=p.stat();rows.append(dict(path=str(p),inode=st.st_ino,bytes=st.st_size,links=st.st_nlink))
  inventory[digest]=rows
 selected=[];saved=0
 for digest,rows in inventory.items():
  canonical=rows[0];byinode={row['inode']:[x for x in rows if x['inode']==row['inode']] for row in rows}
  for inode,paths in byinode.items():
   if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
   selected.append(dict(sha256=digest,canonical=canonical,paths=paths));saved+=paths[0]['bytes']
   break
  if saved>=9*1024*1024:break
 assert 9*1024*1024<=saved<=14*1024*1024,(saved,inventory)
 proof=base/'r115-core-dedup-proof.json';assert not proof.exists()
 for group in selected:
  for row in [group['canonical'],*group['paths']]:
   p=Path(row['path']);st=p.stat();assert st.st_ino==row['inode'] and st.st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in selected:
  canonical=Path(group['canonical']['path'])
  for row in group['paths']:
   p=Path(row['path']);temporary=p.with_name(p.name+'.r115-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=selected,freshInventory=inventory,aliases=aliases,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
