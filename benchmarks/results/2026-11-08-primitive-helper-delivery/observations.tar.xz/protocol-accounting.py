class Quantity:
    def __init__(self,value):self.value=value
    def __mul__(self,other):return self.value*other
def charge(quantity,cents,discount):
    return quantity*cents*(100-discount)//100
import csv

totals={}
accepted=0
with open('input.csv',newline='') as source:
    for record in csv.DictReader(source):
        quantity=Quantity(int(record['quantity']))
        cents=int(record['cents'])
        discount=int(record['discount'])
        amount=charge(quantity,cents,discount)
        category=record['kind']
        totals[category]=totals.get(category,0)+amount
        accepted+=1
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\n')
    writer.writerow(['kind','total'])
    for category in sorted(totals):
        writer.writerow([category,totals[category]])
print(accepted,sum(totals.values()))
