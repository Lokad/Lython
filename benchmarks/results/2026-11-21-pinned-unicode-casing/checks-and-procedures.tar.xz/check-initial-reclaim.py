from pathlib import Path
import gzip,hashlib,json,shlex,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
committed=Path('benchmarks/results/2026-11-21-instruction-scratch/refined')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda bytes_:hashlib.sha256(bytes_).hexdigest()
receipt=load(committed/'archive-receipt.json')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert sha((committed/'observations.tgz').read_bytes())==receipt['archiveSHA256']
image=gzip.decompress(subprocess.check_output(['git','show','HEAD:'+str((committed/'candidate-core.dll.gz').as_posix())],cwd=repo))
root='instruction-scratch-refined-b1267-20261121'
program=f'''from pathlib import Path
import hashlib,json,shutil
p=Path('/home/lokad/lython-bench-checks')
core=p/'{root}/candidate/Lokad.Lython.dll'
archive=p/'{root}/observations.tgz'
print(json.dumps(dict(free=shutil.disk_usage(p).free, core=hashlib.sha256(core.read_bytes()).hexdigest() if core.is_file() else None,links=core.stat().st_nlink if core.is_file() else None, size=core.stat().st_size if core.is_file() else None,archive=hashlib.sha256(archive.read_bytes()).hexdigest() if archive.is_file() else None)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
raw=subprocess.check_output(ssh+['python3 -c '+shlex.quote(program)],timeout=30)
(lab/'reclaim-inventory.json').write_bytes(raw)
info=json.loads(raw);print(info)
assert info['core']==sha(image) and info['links']==1 and info['size']==len(image) and info['archive']==receipt['archiveSHA256']
proof=[dict(archives={f'{root}/observations.tgz':receipt['archiveSHA256']},paths=[f'{root}/candidate/Lokad.Lython.dll'],bytes=len(image),links=1,sha256=sha(image),verifiedCanonicalGitImage=(committed/'candidate-core.dll.gz').as_posix())]
(lab/'reclaim-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
