import base64
import hashlib
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
python = Path('C:/Python313/python.exe')
protocol_path = repo/'benchmarks/cpython-worker.py'
spec = importlib.util.spec_from_file_location('protocol', protocol_path)
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
catalog = load(lab.parent/'native-callback-entry/representative.json')
base = next(row for row in catalog['cases'] if row['id']=='scripts.text-summary-helpers.map-callback.large')
original = base64.b64decode(json.loads(base['fixtureJson'])['inputFiles']['input.txt'])
assert len(original)==35840 and len(original.splitlines())==3072
assert set(original.decode().splitlines())=={'Alpha café 😀','alpha BETA café',''}

def variant(label, text):
    fixture = json.loads(base['fixtureJson'])
    encoded = text.encode('utf-8')
    fixture['inputFiles']['input.txt'] = base64.b64encode(encoded).decode('ascii')
    with TemporaryDirectory(prefix='lython-comparison-files-') as folder:
        folder = Path(folder)
        (folder/'input.txt').write_bytes(encoded)
        stdout = subprocess.check_output([python,'-X','utf8','-I','-c',base['source']],cwd=folder,timeout=20)
        files = {'report.txt':(folder/'report.txt').read_bytes()}
    fixture['outputFiles'] = {name:base64.b64encode(data).decode('ascii') for name,data in files.items()}
    encoding = json.dumps(fixture,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    return dict(base,id=base['id']+'.'+label,fixtureJson=encoding.decode('utf-8'),fixtureSha256=sha(encoding),
                expectedOutput=stdout.decode('utf-8').replace('\r\n','\n'),expectedOutputUtf8Bytes=len(stdout.replace(b'\r\n',b'\n')),
                expectedOutputSha256=sha(stdout.replace(b'\r\n',b'\n')),expectedFilesSha256=protocol.file_digest(files))

catalog['cases']=[base,variant('mixed-unicode','ОТЧЁТ CAFÉ ÉLAN ΣΟΣ Αθήνα 汉字 😀\nİSTANBUL ᲐႠ ЖЪ ΚΌΣΜΟΣ 𐐀𐐐 上海\n\n'*1024),
                  variant('ascii','Alpha CAFEA BASE\nalpha BETA cafea\n\n'*1024)]
(lab/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for row in catalog['cases']:
    data=base64.b64decode(json.loads(row['fixtureJson'])['inputFiles']['input.txt'])
    print(row['id'],len(data),len(data.splitlines()))
