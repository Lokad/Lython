from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/'sparse-abstract-invalidation'
prev=lab.parent/'native-callback-entry'
trial=repo/'.git/agent-worktrees/pinned-unicode-casing-20261121'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def git(*args,cwd=repo):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
core='Lokad.Lython.dll'
reference=load(donor/'identity.json')['candidate']; candidate=git('rev-parse','HEAD',cwd=trial)
assert reference.startswith('406388271') and candidate.startswith('8f6c22584')
assert not git('diff','--name-only',reference,'6e972677e','--','src')
assert not git('status','--porcelain',cwd=trial)
manifest=lab/'representative.json'; protocol=repo/'benchmarks/cpython-worker.py'
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
base=donor/'frozen/candidate';files=load(donor/'identity.json')['imageFiles']['candidate']
assert len(files)==32 and {n:sha(base/n) for n in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for n in files:
        origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/core if n==core and role=='candidate' else base/n
        shutil.copyfile(origin,image/n)
    hashes={n:sha(image/n) for n in files}
    ready=lab/f'{role}-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',protocol,'--out',ready],check=True,env=env,timeout=100)
    assert load(ready)['state']=='Completed' and load(ready)['catalogSha256']==sha(manifest)
    probes=list((prev/'frozen/candidate').glob('ValidatedAllocation.*'))
    assert any(p.suffix=='.dll' for p in probes)
    for p in probes:shutil.copyfile(p,image/p.name)
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,lab/f'{role}-allocation.json'],check=True,env=env,timeout=100)
    assert {n:sha(image/n) for n in files}==hashes
    assert all(row['sharedBudgetBaselineRestored'] for row in load(lab/f'{role}-allocation.json')['rows'])
    images[role]=hashes
assert [n for n in files if images['candidate'][n]!=images['reference'][n]]==[core]
save(lab/'identity.json',dict(reference=reference,candidate=candidate,catalogSHA256=sha(manifest),
                              pythonWorkerSHA256=sha(protocol),imageFiles=images))
baseline,change=(load(lab/f'{role}-allocation.json')['rows'] for role in ('reference','candidate'))
rows=[]
for ref, cand in zip(baseline,change,strict=True):
    assert ref['id']==cand['id']
    a,b=(statistics.median(row['allocatedBytesPerInvocation']) for row in (ref,cand))
    p,q=(row['peakExecutionMemoryBytes'] for row in (ref,cand))
    rows.append(dict(case=ref['id'],previousAllocatedBytes=a,candidateAllocatedBytes=b,allocationChangePercent=100*(b/a-1),
        previousAccountedPeak=p,candidateAccountedPeak=q,budgetReturnedToBaseline=True))
save(lab/'allocation-summary.json',rows)
print(rows)
