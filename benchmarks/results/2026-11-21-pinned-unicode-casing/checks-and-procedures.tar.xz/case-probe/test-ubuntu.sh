set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/current-text-report-attribution/case-probe
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~CasedSplit|FullyQualifiedName~FullCaseExpansion|FullyQualifiedName~StringMethodOwnership|FullyQualifiedName~DirectStringLower|FullyQualifiedName~NativeOperationAllocation' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~Casing|FullyQualifiedName~CaseExpansion|FullyQualifiedName~Cased|FullyQualifiedName~NativeOperationAdmission|FullyQualifiedName~DictionaryCountingLoop' | tee "$logs/public-ubuntu.log"
