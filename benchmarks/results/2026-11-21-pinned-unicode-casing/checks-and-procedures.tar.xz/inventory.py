from pathlib import Path
import hashlib,json,shlex,subprocess
lab=Path(__file__).resolve().parent
program='''from pathlib import Path
import json,shutil
p=Path('/home/lokad/lython-bench-checks')
rows=[]
for d in sorted(p.glob('*-20261121')):
 for role in ('candidate','reference'):
  core=d/role/'Lokad.Lython.dll'
  if core.is_file():
   s=core.stat(); rows.append([str(core.relative_to(p)),s.st_size,s.st_nlink])
print(json.dumps(dict(free=shutil.disk_usage(p).free,images=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
raw=subprocess.check_output(ssh+['python3 -c '+shlex.quote(program)],timeout=30)
(lab/'candidate-inventory.json').write_bytes(raw)
for row in json.loads(raw)['images']:
 if row[-1]==1: print(row)
