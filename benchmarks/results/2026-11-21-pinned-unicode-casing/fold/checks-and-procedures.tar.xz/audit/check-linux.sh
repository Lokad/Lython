set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/pinned-unicode-casing/fold/audit
dotnet build CaseProbe.Linux.csproj -c Release --nologo > build-linux.log
dotnet bin/Release/net10.0/Lokad.Lython.WhiteBox.Tests.dll > linux-candidate.txt
