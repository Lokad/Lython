from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
audit=lab/'audit'
out=Path('benchmarks/results/2026-11-21-pinned-unicode-casing/fold')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease','quietBeforeAndAfter'))
assert sha((quiet/'observations.tgz').read_bytes())==receipt['archiveSHA256']
identity=load(lab/'identity.json')
for role,files in identity['imageFiles'].items():
 assert len(files)==32 and all(sha((lab/'frozen'/role/name).read_bytes())==digest for name,digest in files.items())
 assert load(lab/f'{role}-verify.json')['state']=='Completed'
raw=load(quiet/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs'])==receipt['jobs']==4 and all(len(j['samples'])==28 for j in raw['jobs'])
catalog=load(lab/'representative.json')
cases={case['id']:case for case in catalog['cases']}
assert {job['case'] for job in raw['jobs']}==set(cases)
for job in raw['jobs']:
 case=cases[job['case']]
 assert job['workersJoinedAndFixturesRemoved'] and job['lane']=='warm'
 for row in job['samples']:
  response=row['response']
  assert response['completedInvocations']>0 and response['status']=='Completed'
  assert response['sourceSha256']==case['sourceSha256'] and response['fixtureSha256']==case['fixtureSha256']
  assert response['actualOutputSha256']==case['expectedOutputSha256'] and response['actualFilesSha256']==case['expectedFilesSha256']
assert (audit/'linux-candidate.txt').read_text(encoding='utf-8-sig')==(audit/'windows-candidate.txt').read_text(encoding='utf-8-sig')
for platform in ('windows','linux'):
 assert (audit / f'{platform}-audit.txt').read_text(encoding='utf-8-sig').strip()=='{}'
for log,count in (('white-windows.log',254),('white-ubuntu.log',254),('public-windows.log',313),('public-ubuntu.log',313)):
 assert f'Passed:   {count}' in (lab/log).read_text(encoding='utf-8-sig')
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
 shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
for platform in ('windows','linux'):
 shutil.copyfile(audit/f'{platform}-audit.txt',out/f'{platform}-audit.txt')
core=(lab/'frozen/candidate/Lokad.Lython.dll').read_bytes()
(out/'candidate-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
assert gzip.decompress((out/'candidate-core.dll.gz').read_bytes())==core
(lab/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff',identity['reference'],identity['candidate'],'--','src','tests','docs','tools','THIRD_PARTY_NOTICES.md']))
summary=load(quiet/'quiet-summary.json')
summary.update(collection='B1273', reference=identity['reference'],candidate=identity['candidate'], verifiedBatches=112,
    coreSHA256=sha(core),archiveSHA256=receipt['archiveSHA256'],
    candidateDllBytes=len(core),referenceDllBytes=(lab/'frozen/reference/Lokad.Lython.dll').stat().st_size)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as tar:
 for p in sorted(lab.iterdir()):
  if p.is_file():tar.add(p,arcname=p.name)
 for p in sorted(quiet.iterdir()):
  if p.suffix in {'.json','.py','.sh','.log'}:tar.add(p,arcname='quiet/'+p.name)
 for p in sorted(audit.iterdir()):
  if p.is_file():tar.add(p,arcname='audit/'+p.name)
print(sha(core),receipt['archiveSHA256'])
