set -eu
root=/home/lokad/lython-bench-checks/pinned-unicode-fold-b1273-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
