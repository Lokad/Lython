from pathlib import Path
import itertools, json, os, random, subprocess
repo=Path.cwd()
lab=repo/'.git/agent-notes/review-20261031/split-line-count-r557'
work=repo/'.git/agent-worktrees/split-line-count-r557'
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
separators=['\n','\r','\r\n','\v','\f','\x1c','\x1d','\x1e','\x85','\u2028','\u2029']
source=[]
for sep,leading,trailing in itertools.product(separators, ('','x'*4095,'café'*817+'中'*3), ('','😀')):
    value=leading+sep+'line'+sep+trailing
    source.append('def count(text):return len(text.splitlines())\n'+f'x={value!r}\nprint(count(x),len(x.splitlines()),len(x.splitlines(True)))')
rng=random.Random(72581)
for _ in range(18):
    value=''.join(rng.choices(separators+['⛄','x','\u180e','𐐷','\x00','\t',' ','\x1f'],k=rng.randrange(60,100)))
    source.append(f'x={value!r}\nprint(len(x.splitlines()))')
input_data=json.dumps(source,ensure_ascii=False)
(lab/'probe-input.json').write_text(input_data,encoding='utf-8')
for framework in ('net11.0','net10.0'):
    image=work/'tools/LythonProbe/bin/Release'/framework
    for mode in ('sync','async'):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if mode=='async': args.append('--async')
        done=subprocess.run(args,input=input_data,text=True,encoding='utf-8',capture_output=True,env=env,timeout=90)
        (lab/f'probe-{framework}-{mode}.jsonl').write_text(done.stdout,encoding='utf-8')
        rows=[json.loads(line) for line in done.stdout.splitlines()]
        assert len(rows)==len(source),done.stderr
        failed=[x for x in rows if not x['Matches'] or not x['Lython']['Success']]
        assert not failed,(framework,mode,failed[:1])
        assert done.returncode==0,done.stderr
        print(framework,mode,len(rows),'matching CPython probes',flush=True)
