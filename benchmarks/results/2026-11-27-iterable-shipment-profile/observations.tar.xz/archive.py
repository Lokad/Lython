from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import tarfile


root = Path(__file__).resolve().parent
repo = root.parents[4]
out = repo / 'benchmarks/results/2026-11-27-iterable-shipment-profile'
out.mkdir(exist_ok=True)
roles = ('iterable-sync', 'iterable-async', 'wide-async')
summary = json.loads((root / 'run-summary.json').read_bytes())
assert summary['totalVerifiedBatches'] == 68 and summary['allProcessesJoined']
for name in ('attribution.json', 'identity.json', 'run-summary.json'):
    copyfile(root / name, out / name)
files = [root / name for name in ('analyze.py', 'archive.py', 'collect.py', 'collection.log', 'run.sh')]
for role in roles:
    files.extend(root / role / name for name in
                 ('capture.log', 'record.json', 'run.nettrace', 'run.speedscope.json', 'worker.stderr'))
files.extend(path for path in (root / 'initial-fixture-check').rglob('*') if path.is_file())
archive = out / 'observations.tar.xz'
with tarfile.open(archive, 'w:xz') as bundle:
    for path in files:
        bundle.add(path, arcname=path.relative_to(root))
with tarfile.open(archive) as bundle:
    assert all(bundle.extractfile(path.relative_to(root).as_posix()).read() == path.read_bytes() for path in files)
(out / 'archive-receipt.json').write_text(json.dumps(dict(
    archiveSHA256=sha256(archive.read_bytes()).hexdigest(),
    archivedAndVerified=True, fileCount=len(files)), indent=2) + '\n', encoding='utf-8', newline='\n')
