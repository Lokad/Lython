from pathlib import Path
import base64
import csv
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.with_name("async-map-prefix-20261125")
catalog = json.loads((prior / "input-catalog.json").read_text(encoding="utf-8"))
selected = {
    "scripts.csv-invoice.method-policy.quoted-control",
    "diagnostic.shipment-routing-callbacks",
    "diagnostic.shipment-file-fed-map",
}
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in selected]
assert len(catalog["cases"]) == 3
invoice = next(case for case in catalog["cases"] if "invoice" in case["id"])
source = invoice["source"]
header = "    for row in csv.DictReader(source):"
assert source.count(header) == 1
exposed = source.replace(header, "    reader = csv.DictReader(source)\n    reader.fieldnames\n    for row in reader:")
fixture = json.loads(invoice["fixtureJson"])
first_line = base64.b64decode(fixture["inputFiles"]["input.csv"]).decode("utf-8").splitlines()[0]
names = next(csv.reader([first_line]))
plain = source.replace(header, "    reader = csv.reader(source)\n    next(reader)\n    for row in reader:")
for name in ("quantity", "unit_cents", "discount_bps", "tax_bps", "category"):
    access = "row[" + repr(name) + "]"
    assert plain.count(access) == 1
    plain = plain.replace(access, f"row[{names.index(name)}]")
for id_suffix, script in (("exposed-header", exposed), ("plain-reader", plain)):
    encoded = script.encode("utf-8")
    catalog["cases"].append(invoice | dict(
        id="diagnostic.invoice-" + id_suffix, source=script, sourceUtf8Bytes=len(encoded),
        sourceSha256=hashlib.sha256(encoded).hexdigest(),
    ))
(lab / "input-catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                                        encoding="utf-8", newline="\n")
