from base64 import b64decode
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
previous=notes/'comprehension-assignments-20261127'
local_base=previous/'local'
donor=previous/'comparison/quiet'
local=lab/'local'
quiet=lab/'comparison/quiet'
local.mkdir()
(quiet/'candidate').mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=lambda p:{f.name:sha(f) for f in p.iterdir()}
core='Lokad.Lython.dll'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('c665a179e')
assert subprocess.check_output(['git','diff','--binary','807d6e745',head,'--','src'],cwd=repo)==(local_base/'candidate.patch').read_bytes()
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
(local/'candidate.patch').write_bytes(patch)
assert patch.count(b'diff --git ')==5 and b'FitsIterationOperandStorage' in patch
(local/'regression.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','tests'],cwd=repo))
pin=read(donor/'identity.json')
assert sha(local_base/'candidate.patch')==pin['sourcePatchSHA256']
assert pin['imageFiles']['reference']['Lokad.Lython.Benchmarks.dll']==pin['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
files=pin['imageFiles']['candidate']
assert len(files)==32 and manifest(local_base/'candidate')==files
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
for role in ('reference','candidate'):
    shutil.copytree(local_base/'candidate',local/role)
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(new)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
shutil.copyfile(new,local/'candidate'/core)
shutil.copyfile(new,quiet/'candidate'/core)
images={role:manifest(local/role) for role in ('reference','candidate')}
assert images['reference']==files
assert [k for k,h in files.items() if h!=images['candidate'][k]]==[core]

catalog=read(notes/'private-compiler-slots-20261127'/'representative.json')
control=next(row for row in catalog['cases'] if row['id']=='diagnostic.generated-ordinary-definitions')

def case(case_id, source, size):
    output=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-S','-'],input=source,
        check=True,capture_output=True,encoding='utf8',timeout=15).stdout
    fixture=read(notes/'private-compiler-slots-20261127'/'representative.json')['cases'][-2]
    settings=json.loads(fixture['fixtureJson']); settings['size']=size
    assert not settings.get('inputFiles') and not settings.get('outputFiles')
    serialized=json.dumps(settings,ensure_ascii=False,separators=(',',':'))
    digest=lambda text:sha256(text.encode('utf8')).hexdigest()
    return control | dict(id=case_id,source=source,size=size,fixtureJson=serialized,
        sourceUtf8Bytes=len(source.encode('utf8')),sourceSha256=digest(source),fixtureSha256=digest(serialized),
        expectedOutput=output,expectedOutputUtf8Bytes=len(output.encode('utf8')),expectedOutputSha256=digest(output))

source="""from itertools import starmap
convert = int

def quantity(row):
    return convert(row['quantity'])

row = {'quantity':'17'}
rows = (row,)
starred = ((row,),)
total = 0
for _ in range(2048):
    ordinary = map(quantity, rows)
    expanded = starmap(quantity, starred)
    total += next(ordinary) + next(expanded)
print(total)
"""
construction=case('diagnostic.repeated-iterator-construction',source,2048)
report=next(row for row in read(local_base/'representative.json')['cases'] if row['id']=='diagnostic.generated-comprehension-report')
external={row['id']:row for row in read(notes/'post-ready-insertion-cpython-20261127'/'comparison/quiet/representative.json')['cases']}
file_fed=external['diagnostic.shipment-file-fed-map']
json_control=external['diagnostic.nested-json-document']
catalog['cases']=[construction,file_fed,report,json_control]
write(local/'representative.json',catalog)
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',{'warm':[[construction['id'],'warm'],[file_fed['id'],'warm-async'],[report['id'],'compile'],[json_control['id'],'warm']]})
write(local/'fixture-census.json',dict(mapConstructions=2048,starmapConstructions=2048,
    sourceBytes=construction['sourceUtf8Bytes'],stdout=construction['expectedOutput']))
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(donor/name,quiet/name)
assert sha(quiet/'cpython-worker.py')==pin['cpythonWorkerSHA256'] and b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(local/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:items[core] for role,items in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    comparisonHostRevision=pin['comparisonHostRevision'],cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
    expectedCPythonSHA256=pin['expectedCPythonSHA256'],donorArchiveSHA256=receipt['archiveSHA256'],
    purpose='Use the already emitted instruction layout to prove small iterator callback storage once.')
write(quiet/'identity.json',identity)
collector=(donor/'collect.py').read_text(encoding='utf8').replace('len(jobs) == 3','len(jobs) == 4').replace('lython-b1856-fixtures','lython-b1857-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf8',newline='\n')
ssh=(previous/'quiet-vm.py').read_text(encoding='utf8').replace('lython-b1856-comprehension-assignments-20261127','lython-b1857-iteration-operand-footprint-20261127')
ssh=ssh.replace('--property=RuntimeMaxSec=180','--property=RuntimeMaxSec=215').replace("proof['caseCount']==3","proof['caseCount']==4")
compile(ssh,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(ssh,encoding='utf8',newline='\n')
summary=(previous/'summarize-quiet.py').read_text(encoding='utf8').replace("receipt['warmJobs'] == 3","receipt['warmJobs'] == 4")
summary=summary.replace("len(raw['jobs']) == 3","len(raw['jobs']) == 4").replace('timedBatches=84','timedBatches=112')
(lab/'summarize-quiet.py').write_text(summary,encoding='utf8',newline='\n')

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,fileset in images.items():
    folder=local/role
    report=local/f'{role}-verify.json'
    subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',report],env=env,check=True,timeout=65)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==4 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==fileset['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['library']['sha256']==fileset[core]
    allocated=local/f'{role}-allocated'
    shutil.copytree(folder,allocated)
    for p in (local_base/'candidate-allocated').glob('ValidatedAllocation*'): shutil.copyfile(p,allocated/p.name)
    assert all(sha(allocated/name)==h for name,h in fileset.items())

names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',f'candidate/{core}']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root='iteration-operand-footprint-b1857-20261127',donor=read(donor/'upload.json')['root'],donorFiles=images['reference'],
    donorArchive=identity['donorArchiveSHA256'],payloadSHA256=sha(payload),files=staged,
    expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selection=local/f'{mode}-allocation-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=local/f'{role}-allocated'
        report=local/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=75)
        pair.append(read(report)['rows'])
    for before,after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        change=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                    peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
                    compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(change)
        print(change,flush=True)
write(local/'allocation-summary.json',rows)
