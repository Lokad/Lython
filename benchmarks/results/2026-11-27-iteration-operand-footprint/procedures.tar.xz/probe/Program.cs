using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Numerics;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var limits = args.Length == 3 ? JsonSerializer.Deserialize<Dictionary<string, long[]>>(File.ReadAllText(args[2]))! : null;
var sources = catalog.RootElement.GetProperty("cases").EnumerateArray().ToDictionary(
    item => item.GetProperty("id").GetString()!, item => item.GetProperty("source").GetString()!);
sources.Add("capture-after-literal", """
    def create(seed):
        mark = 17
        def read():
            return seed
        return mark, read
    result, read = create(23)
    print(result, read())
    """);
sources.Add("capture-snapshot-overlap", """
    def create():
        first, second = 17, 23
        def read():
            return first + second
        return read
    print(create()())
    """);
sources.Add("signed-constant-boundaries", """
    def boundary(value):
        if value:
            return value + 9223372036854775807
        return value + 9223372036854775808
    def negatives(value):
        return value - 9223372036854775809
    print(boundary(1), boundary(0), negatives(1))
    """);

sources.Add("declaration-in-default", """
    def launch(seed):
        def adjusted(value=(lambda: seed + 1)(), *, extra=3):
            return value + extra + seed
        return adjusted()
    print(launch(5))
    """);
sources.Add("declaration-kinds", """
    def records(data):
        type Scalar = int
        class Label:
            def __init__(self, value):
                self.value = value
        make = lambda number: Label(number)
        yield from (make(number) for number in data)
    print([item.value for item in records([3, 5])])
    """);
var fillers = string.Join("\n", Enumerable.Range(0, 20).Select(i => $"    reserve_{i} = {i}"));
foreach (var (tag, continuation) in new (string, string)[]
{
    ("deferral-through-layout", "    return locals(), live()"),
    ("return-forwarded-local", "    result = lambda a=shift(seed), *, b=shift(seed): a + b\n    return result"),
    ("rebound-definition", "    saved = 5\n    return saved, live()"),
    ("explicit-read-before-forwarding", "    chosen = saved\n    return chosen(), live()"),
    ("scope-not-eligible", "    del saved\n    return live()"),
})
{
    sources.Add(tag, "def shift(n): return n + 1\ndef factory(seed):\n" + fillers +
        "\n    saved = lambda a=shift(seed), *, b=shift(seed): a + b\n" +
        "    def live(a=shift(seed), *, b=shift(seed)): return a + b\n" + continuation);
}
sources.Add("deferred-before-returned-pair", "def factory(seed):\n" + fillers +
    "\n    def unused(a=seed + 1, *, b=seed + 2): return a + b\n" +
    "    def first(a=seed + 4, *, b=3): return a + b\n" +
    "    def second(a=seed + 5, *, b=6): return a + b\n" +
    "    return first, second\n");
sources.Add("namespace-protected-temporaries", """
    class Manager:
        def __enter__(self): return 7
        def __exit__(self, *args): return False
    def factory(manager, first):
        with manager as value:
            result = 0 < first < value
            def read():
                return value, result
            return read, locals()
    print(factory(Manager(), 2)[0]())
    """);
sources.Add("nested-protected-match-and-comprehension", """
    def records(values):
        for number in values:
            match number:
                case int() if 0 < number < 4:
                    yield number
    print(list(records([0, 1, 3, 4])))
    """);
var results = sources.Select(pair =>
{
    var budget = new TracingBudget(null);
    var engine = new LythonEngine();
    WithBudget(engine, pair.Value, budget, script =>
    {
        if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
        return 0;
    });
    var stablePeak = budget.Peak;
    var growth = budget.Granted.Where(item => item.New > item.Old).ToArray();
    var testLimits = limits is not null && limits.TryGetValue(pair.Key, out var overridden) ? overridden
        : growth.Select(item => item.Total - 1).TakeLast(8).Append(stablePeak - 1).Append(stablePeak).Where(n => n >= 0).Distinct().ToArray();
    var full = new TracingBudget(null);
    var tape = WithBudget(engine, pair.Value, full, script =>
    {
        var code = Read(script, "_executable")!;
        var output = new List<object>();
        ReadCode(Read(code, "EntryPoint")!, output);
        return output;
    });
    var refusals = testLimits.Select(limit =>
    {
        var limited = new TracingBudget(limit);
        return WithBudget(engine, pair.Value, limited, script => new
        {
            limit, script.IsValid, limited.Refused,
            diagnostics = script.Diagnostics.Select(item => new { item.Code, item.Span }).ToArray()
        });
    }).ToArray();
    for (var i = 0; i < 8; i++)
        using (var warm = engine.Compile(pair.Value))
            if (!warm.IsValid) throw new InvalidOperationException("Compilation warmup failed.");
    var allocated = new long[17];
    for (var i = 0; i < allocated.Length; i++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        using (var script = engine.Compile(pair.Value))
            if (!script.IsValid) throw new InvalidOperationException("Compilation diagnostic changed during measurement.");
        allocated[i] = GC.GetAllocatedBytesForCurrentThread() - before;
    }
    return new { id = pair.Key, peak = stablePeak, growth, testLimits, tape, refusals, allocated };
}).ToArray();
var options = new JsonSerializerOptions { WriteIndented = true, IncludeFields = true };
options.Converters.Add(new JsonStringEnumConverter());
File.WriteAllText(args[1], JsonSerializer.Serialize(results, options));
using (var cancellation = new CancellationTokenSource())
{
    const string source = "return 17";
    var engine = new LythonEngine();
    var successful = new TracingBudget(null);
    WithBudget(engine, source, successful, script => script.IsValid ? 0 : throw new InvalidOperationException("Expected a compiled integer."));
    var table = successful.Granted.Last(item => item.New > item.Old);
    if (table.New - table.Old != 48) throw new InvalidOperationException("Expected the one-slot table's admission to be last.");
    var interrupted = new TracingBudget(null)
    {
        Cancel = cancellation,
        CancelAt = table.Total,
    };
    var atReturn = WithBudget(engine, source, interrupted, script =>
    {
        if (script.IsValid || script.Diagnostics.Single().Code != "LA2011")
            throw new InvalidOperationException("Compilation did not report cancellation at the granted table.");
        return interrupted.Root.ReservedBytes;
    });
    if (!cancellation.IsCancellationRequested || atReturn != table.Total - 48)
        throw new InvalidOperationException("The cancelled table's temporary admission was retained.");
    File.WriteAllText(Path.Combine(Path.GetDirectoryName(args[1])!, "cancellation.json"),
        JsonSerializer.Serialize(new { granted = table.Total, afterCancellation = atReturn, afterDispose = interrupted.Root.ReservedBytes }));
}

static T WithBudget<T>(LythonEngine engine, string source, TracingBudget budget, Func<LythonCompiledScript, T> observe)
{
    T result;
    using (var script = engine.Compile(source, budget, budget.Cancel?.Token ?? default))
        result = observe(script);
    if (budget.Root.ReservedBytes != 0) throw new InvalidOperationException("Compilation scope did not restore allowance.");
    return result;
}

static object? Read(object value, string name)
{
    const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    var type = value.GetType();
    return type.GetProperty(name, Flags)?.GetValue(value) ?? type.GetField(name, Flags)?.GetValue(value);
}

static void ReadCode(object code, List<object> output)
{
    var constants = (object?[])Read(code, "Constants")!;
    var machine = (long?[]?)Read(code, "_machineConstants");
    var instructions = (IEnumerable)Read(code, "Instructions")!;
    var expected = constants.Select(value => value is BigInteger integer &&
        integer >= long.MinValue && integer <= long.MaxValue ? (long?)integer : null).ToArray();
    if (expected.Any(item => item.HasValue) ? machine is null || !machine.SequenceEqual(expected) : machine is not null)
        throw new InvalidOperationException("Machine integer table differs from the original literals.");
    var expectedBorrow = PriorIterationFootprint(code, instructions.Cast<object>().ToArray());
    if (Read(code, "FitsIterationOperandStorage") is bool prepared && prepared != expectedBorrow)
        throw new InvalidOperationException($"Iteration footprint disagrees for {Read(code, "Name")}.");
    output.Add(new
    {
        canBorrowIterationOperands = expectedBorrow,
        name = Read(code, "Name"), machine,
        native = Read(code, "CanRunNativeInstructions"),
        entry = Read(code, "EntryIndex"),
        nativePrefixEnd = Read(code, "NativePrefixEnd"),
        capacity = Read(code, "ValueStorageCapacity"),
        deferred = Read(code, "DeferredDefinitionSites"),
        directReturn = Read(code, "HasDirectOperandReturn"),
        directDefinitionReturn = Read(code, "DirectDefinitionReturn") is { } direct ? Read(Read(direct, "CodeObject")!, "Name") : null,
        directCased = Read(code, "DirectCasedReturnIndex"),
        firstPairCreation = Read(code, "FirstPairedDefaultCreationIndex"),
        captures = Read(code, "CaptureSources") is { } capture ? Read(capture, "Slots") : null,
        byValue = Read(code, "CaptureSources") is { } owner ? Read(owner, "CanCaptureByValue") : null,
        locals = Read(code, "LocalNames"), closureNames = Read(code, "ClosureNames"),
        bindingSlots = Read(code, "LocalNameToSlot"),
        sharesPreparedMap = ReferenceEquals(Read(code, "LocalNameToSlot"),
            Read(Read(code, "ScopeFacts")!, "PreparedLocalSlots")),
        capturedLocals = Read(code, "CapturedLocalSlots"),
        mirrors = Read(code, "RequiresLocalVariableMirroring"), lexical = Read(code, "UsesOnlyLexicalSlots"),
        constants = constants.Select(value => value is BigInteger integer
            ? integer.ToString(CultureInfo.InvariantCulture) : value?.GetType().Name).ToArray(),
        steps = instructions.Cast<object>().Select(instruction => new
        {
            op = Read(instruction, "OpCode"), span = Read(instruction, "Span"),
            primary = Read(instruction, "_primaryOperand"), secondary = Read(instruction, "_secondaryOperand"),
            input = Read(instruction, "_inputStart"), result = Read(instruction, "_resultSlot"), extent = Read(instruction, "_liveExtent"),
        }).ToArray(),
    });
    foreach (var constant in constants)
    {
        if (constant is null) continue;
        var child = constant.GetType().Name switch
        {
            "ExecutableCreateFunction" or "ExecutableCreateGeneratorExpression" => Read(constant, "CodeObject"),
            "ExecutableCreateClass" => Read(constant, "Body"),
            _ => null,
        };
        if (child is not null) ReadCode(child, output);
    }
}

static bool PriorIterationFootprint(object code, object[] instructions)
{
    const int capacity = 3;
    if (instructions.Length == 0 || Read(code, "CanRunNativeInstructions") is not true ||
        (int)Read(code, "EntryIndex")! != 0 || (int)Read(code, "NativePrefixEnd")! != instructions.Length ||
        ((IEnumerable)Read(code, "ExceptionRegions")!).Cast<object>().Any() ||
        ((IEnumerable)Read(code, "CapturedLocalSlots")!).Cast<object>().Any() ||
        (int)Read(code, "FirstTemporarySlot")! > capacity || Op(instructions[^1]) != "Return" ||
        Read(code, "HasDirectOperandReturn") is true && Op(instructions[0]) != "LoadGlobal") return false;

    var sites = (Array)Read(code, "CallSites")!;
    foreach (var step in instructions)
    {
        if (Read(step, "HasResultConsumer") is true || (int)Read(step, "LiveExtent")! > capacity) return false;
        var slot = (int)Read(step, "ResultSlot")!;
        switch (Op(step))
        {
            case "LoadConst" or "LoadGlobal":
                if ((uint)slot >= capacity) return false;
                break;
            case "LoadLocal":
                if ((uint)(int)Read(step, "LocalSlot")! >= capacity || (uint)slot >= capacity) return false;
                break;
            case "Subscript":
                if ((int)Read(step, "InputStart")! >= capacity || (int)Read(step, "SecondInput")! >= capacity ||
                    (uint)slot >= capacity) return false;
                break;
            case "Call":
                var site = sites.GetValue((int)Read(step, "CallSiteIndex")!)!;
                if (Read(step, "HasForwardedCallOperands") is true || (uint)slot >= capacity ||
                    Read(site, "IsPositionalOnly") is not true || Read(site, "HasReceiver") is true ||
                    Read(site, "UnpackedReturnCount") is not 0 || Read(site, "SplitPrefix") is not null ||
                    (int)Read(site, "ArgumentCount")! > capacity - slot - (int)Read(site, "ArgumentOffset")!) return false;
                break;
            case "Return":
                if ((int)Read(step, "InputStart")! >= capacity) return false;
                break;
            default: return false;
        }
    }
    return true;

    static string Op(object instruction) => Read(instruction, "OpCode")!.ToString()!;
}

internal sealed class TracingBudget(long? limit) : ILythonMemoryBudget
{
    public LythonMemoryBudget Root { get; } = limit is { } ceiling ? new(ceiling) : new();
    public long Peak { get; private set; }
    public CancellationTokenSource? Cancel { get; init; }
    public long CancelAt { get; init; }
    public List<(long Old, long New, long Total)> Granted { get; } = [];
    public (long Old, long New)? Refused { get; private set; }

    public ILythonMemoryScope CreateScope() => new Owner(this, Root.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Reserve(Root, bytes, out reservation);

    private bool Reserve(ILythonMemoryBudget owner, long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!owner.TryReserve(bytes, out var actual))
        {
            Refused ??= (0, bytes);
            reservation = null;
            return false;
        }
        Track(0, bytes);
        reservation = new Reservation(this, actual);
        return true;
    }

    private void Track(long old, long next)
    {
        Peak = Math.Max(Peak, Root.ReservedBytes);
        if (old != next) Granted.Add((old, next, Root.ReservedBytes));
        if (next > old && Root.ReservedBytes == CancelAt) Cancel?.Cancel();
        if (Refused is not null && next > old) throw new InvalidOperationException("Admission retried after refusal.");
    }

    private sealed class Owner(TracingBudget root, ILythonMemoryScope owner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Owner(root, owner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => root.Reserve(owner, bytes, out reservation);
        public void Dispose() => owner.Dispose();
    }

    private sealed class Reservation(TracingBudget root, ILythonMemoryReservation reservation) : ILythonMemoryReservation
    {
        public long Bytes => reservation.Bytes;
        public bool TryResize(long bytes)
        {
            var previous = Bytes;
            if (!reservation.TryResize(bytes))
            {
                root.Refused ??= (previous, bytes);
                return false;
            }
            root.Track(previous, bytes);
            return true;
        }
        public void Dispose() => reservation.Dispose();
    }
}