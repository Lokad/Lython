from pathlib import Path
from hashlib import sha256
from statistics import median
import base64
import copy
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('compiled-prefix-search-20261126')
image_base=lab.with_name('shared-pending-zip-20261127')/'local'
callback=lab.with_name('direct-map-result-handoff-20261126')
repeat=lab.with_name('map-repeat-operands-20261126')
run=lab/'local'
run.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(path):return sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def manifest(directory):return {p.name:sha(p) for p in directory.iterdir()}
core='Lokad.Lython.dll'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('a768ff8d7')
for area, name in (('src','candidate.patch'),('tests','regression.patch')):
    (run/name).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',area],cwd=repo))
pin=read(image_base/'identity.json')
reference_files=pin['imageFiles']['candidate']
assert len(reference_files)==32 and manifest(image_base/'candidate')==reference_files
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core
assert sha(new)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
images={}
for role in ('reference','candidate'):
    target=run/role
    shutil.copytree(image_base/'candidate',target)
    if role=='candidate':shutil.copyfile(new,target/core)
    images[role]=manifest(target)
assert images['reference']==reference_files
assert [p for p,x in reference_files.items() if x!=images['candidate'][p]]==[core]
catalog=read(lab.with_name('json-empty-record-layout-20261127')/'local/representative.json')
flat='scripts.json-summary-helpers.large'
base,=[case for case in catalog['cases'] if case['id']==flat]
nested='diagnostic.json-lines-nested-arrays'
case=copy.deepcopy(base)
case['id']=nested
assert case['source'].count("    return record['amount']")==1
case['source']=case['source'].replace("    return record['amount']",
    "    interval = record['amount']\r\n    return interval[0] - interval[1]")
case['sourceUtf8Bytes']=len(case['source'].encode())
case['sourceSha256']=sha256(case['source'].encode()).hexdigest()
fixture=json.loads(case['fixtureJson'])
original=base64.b64decode(fixture['inputFiles']['input.jsonl']).decode()
rows=[]
count=0
for line in original.splitlines():
    if not line.strip():
        rows.append(line)
        continue
    row=json.loads(line)
    lower=count%31
    row['amount']=[row['amount']+lower,lower]
    rows.append(json.dumps(row,separators=(',',':'),ensure_ascii=False))
    count+=1
payload=('\n'.join(rows)+'\n').encode()
fixture['inputFiles']['input.jsonl']=base64.b64encode(payload).decode()
case['fixtureJson']=json.dumps(fixture,separators=(',',':'))
case['fixtureSha256']=sha256(case['fixtureJson'].encode()).hexdigest()
catalog['cases']=[case,base]
write(run/'field-census.json',dict(records=count,nestedBytes=len(payload),flatBytes=len(original.encode())))
write(run/'representative.json',catalog)
collector=(lab.with_name('file-metadata-observation-20261127')/'local/collect.py').read_text(encoding='utf-8')
collector=collector.replace('lython-file-metadata-fixture-','lython-fixed-initial-list-fixture-')
compile(collector,'collect.py','exec')
(run/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(previous/'local/run.sh',run/'run.sh')
assert b'\r' not in (run/'run.sh').read_bytes()
shutil.copyfile(image_base/'cpython-worker.py',run/'cpython-worker.py')
assert sha(run/'cpython-worker.py')==pin['cpythonWorkerSHA256']
write(run/'jobs.json',{'warm':[[nested,'warm'],[flat,'warm-async'],[nested,'warm-async']]})
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(run/'candidate.patch'),imageFiles=images,cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
              coreSHA256={role+suffix:im[core] for role,im in images.items() for suffix in ('','-control')},
              catalogs={name:{'sha256':sha(run/name)} for name in ('representative.json','jobs.json')},
              purpose='Remove the per-list initial backing lease, with a flat JSON Lines control.')
write(run/'identity.json',identity)

sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role, im in images.items():
    report=run/f'{role}-verify.json'
    subprocess.run([dotnet,run/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',run/'representative.json','--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',run/'cpython-worker.py','--out',report],cwd=repo,env=env,check=True,timeout=60)
    checked=read(report)
    assert checked['caseCount']==2 and checked['state']=='Completed'
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==im[core]
    diagnostic=run/f'{role}-allocated'
    shutil.copytree(run/role,diagnostic)
    for path in (previous/'candidate-allocated').glob('ValidatedAllocation*'):
        shutil.copyfile(path,diagnostic/path.name)
    assert all(sha(diagnostic/p)==h for p,h in im.items())
rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selected=run/f'{mode}-allocation-catalog.json'
    write(selected,catalog)
    values=[]
    for role in ('reference','candidate'):
        diagnostic=run/f'{role}-allocated'
        report=run/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,diagnostic/'ValidatedAllocation.dll',diagnostic,selected,report],env=env,check=True,timeout=75)
        values.append(read(report)['rows'])
    for before,after in zip(*values,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],peak=[r['peakExecutionMemoryBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(run/'allocation-summary.json',rows)
