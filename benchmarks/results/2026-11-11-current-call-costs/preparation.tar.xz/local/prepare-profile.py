from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b582';q.mkdir(parents=True,exist_ok=False)
old=r.parent/'native-word-boundary-r238/b578';prior=r.parent/'mirrored-call-storage-r241'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((prior/'diagnostic-identity.json').read_text(encoding='utf-8'))
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Retained5f9059fa executable code, frozenR241 f702 core with precommit30b03 metadata and documented comment-only delta. Full43042632656 still in progress. Current captured and ordinary text CPU source-selection profiles; no elapsed source pair/CPython ratio/allocation attribution.',
 coreSHA256={'candidate':meta['images']['candidate']['Lokad.Lython.dll']},catalogSHA256=sha(prior/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(prior/'catalog.json',q/'catalog.json')
text=(old/'ops-profile.py').read_text(encoding='utf-8').replace('native-word-profile-b578','call-preparation-profile-b582')
text=text.replace('[("text-warm", "scripts.text-summary-helpers.nonlocal-counter.large", "warm")]', '[("text-warm", "scripts.text-summary-helpers.nonlocal-counter.large", "warm"), ("text-ordinary", "scripts.text-summary-helpers.large", "warm")]')
text=text.replace('total_capture_seconds > 10','total_capture_seconds > 16')
(q/'ops-profile.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py']:
 text=(old/name).read_text(encoding='utf-8').replace('native-word-profile-b578','call-preparation-profile-b582').replace('lython-b578-native-word-profile','lython-b582-call-preparation-profile')
 text=text.replace('for case in text-warm;', 'for case in text-warm text-ordinary;').replace("['text-warm']","['text-warm','text-ordinary']")
 text=text.replace('elapsed<10','elapsed<10').replace('seconds<10','seconds<16').replace("['capturedSeconds']<10","['capturedSeconds']<16")
 text=text.replace('ownerSeconds=90','ownerSeconds=120').replace('seconds=150','seconds=180')
 (q/name).write_text(text,encoding='utf-8',newline='\n')
for p in q.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
files=['catalog.json','identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in files:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/call-preparation-profile-b582-20261111',unit='lython-b582-call-preparation-profile-20261111',payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8').replace("source=base/'native-counter-loops-b576-20261111/candidate'","source=base/'mirrored-storage-b581-20261111/candidate'")
text=text.replace('lython-b578-fixtures','lython-b582-fixtures').replace('sampledSeconds=10,ownerSeconds=90','sampledSeconds=16,ownerSeconds=120').replace('RuntimeMaxSec=90','RuntimeMaxSec=120')
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared two6sCPU captures on existing retained core,120sowner; no new runtime, new framework or remote deletion. Fresh lease/disk proof required.')
