# Next complete phase after R241

Read-only assessment on retained5f9059fa; no new runtime prototype.

The current native histogram consumes compiler-private cased-word iteration.
MoveNext materializes a PyString, then the native table hashes/probes it. Native
PyDict already owns its hash table and PyString.HashUtf8 accepts spans/current
cancellation. A universal comparer framework is unnecessary. A raw UTF-8
consumer could remove transient word objects only if all retained insertion keys,
last-loop-word identity, fallback/handler observation and source spans survive.

The actual two maintained text fixtures have3072lines/6144words/four distinct
words,35840input bytes/28672word UTF-8 bytes, maximumword5bytes. Every word already
fits inline; there is no per-word payload array. Final word binding must still be
materialized per nonempty native segment. A per-cursor scratch array would add
3072allocations to avoid at most3072other transient word shells, plus an encoding
and publication protocol. Do not assume dense prose or count every6144word as
removable, and do not change fixtures merely to make the design look useful.

Conclusion: no raw-word prototype selected for these existing workloads. This is
a current workload/storage gate, not a timing rejection or permanent design veto.
A genuinely representative dense-word workload could justify reconsideration.
Existing preflight counts every eventual fragment before effects; replacing it
with a worst-case O(1)estimate still overcharges other inputs and is not proposed.
No range vector, wrapper, deferred-binding framework, pool/cache or producer change.

The stronger next construction boundary remains whole compiled-call preparation:
BindPositionalFunctionArguments -> BoundCallArguments -> BeginBoundCall ->
CreateExecutableWorkState -> shared synchronous prefix. Normal captured helpers
already avoid lexical-context creation and reuse final arrays. Their remaining
transport is completed binding/presence/owner state followed by work/stack/code
state, with separate transfer/cleanup paths. Investigate consolidation into the
existing executable work state, not another carrier/arena/controller/span ABI.
Argument presence is genuinely needed by builtin omissions and async protocol
defaults; do not delete it globally or change live default/missing-value semantics.

R238fe leaves include binding21/1151, BeginPendingCall24, BeginBoundCall17,
CreateExecutableWorkState18; these samples are not current source allocation
attribution or additive removable percentages. R240 changes the intervening loop;
profile current retained code only where the existing evidence cannot choose the
complete phase. Preserve compile/warm/host-I/O/cleanup boundaries and adverse data.

Source/lifetime gate must prove one owner through binding/default suspension,
body, pending host work and throwing cleanup; frame/namespace/cells and first
refusal remain intact. Name the exact duplicated state/code that disappears.
If consolidation needs another parallel dispatch/ownership model, record that
obstacle before implementation. Follow with one bounded whole-script pair:
captured text/CSV helpers and unchanged ordinary/report/JSON controls, both APIs
and compilation separate. A useful simplification/allocation reduction need not
meet an arbitrary speed%threshold; a temporary regression needs a completion/debt
decision. Slower earlier arenas/controllers remain lessons, not mechanisms to
reintroduce. One experiment does not complete the objective.
