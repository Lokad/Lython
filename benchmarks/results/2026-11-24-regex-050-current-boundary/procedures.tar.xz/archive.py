from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / "benchmarks/results/2026-11-24-regex-050-current-boundary"
proof = json.loads((lab / "verification.json").read_text(encoding="utf-8"))
assert proof["producerVersion"] == "0.5.0" and [row["passed"] for row in proof["checks"]] == [157, 157]
sha = lambda data: hashlib.sha256(data).hexdigest().upper()
assert sha((lab / "adapter-bridge.patch").read_bytes()) == proof["bridgePatchSHA256"]
shutil.copyfile(lab / "verification.json", out / "verification.json")
names = ("adapter-bridge.patch", "verify.py", "archive.py", "windows-restore.log", "windows-net11.log",
         "ubuntu-restore.log", "ubuntu-net10.log", "test-ubuntu.sh")
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert {member.name: sha(archive.extractfile(member).read()) for member in archive} == {
        name: sha((lab / name).read_bytes()) for name in names}
