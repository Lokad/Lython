from pathlib import Path
import hashlib, json, re, subprocess, zipfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
worktree = root / ".git/agent-worktrees/regex-050-current-boundary-20261124"
old = lab.with_name("regex-050-frozen-boundary")
manifest = json.loads((old / "producer-candidate.json").read_text(encoding="utf-8-sig"))
feed = lab.with_name("regex-050-range-adapter-20261122") / "feed"
sha = lambda payload: hashlib.sha256(payload).hexdigest().upper()
source = subprocess.check_output(["git", "-C", worktree, "rev-parse", "HEAD"], text=True).strip()
assert source.startswith("9d50a1b1f") and manifest["SourceRevision"].startswith("61228b20f")
patch = subprocess.check_output(["git", "-C", worktree, "diff", "--binary", "HEAD"])
(lab / "adapter-bridge.patch").write_bytes(patch)
rows = []
for platform, target in (("windows", "net11.0"), ("ubuntu", "net10.0")):
    transcript = (lab / (platform + "-" + target[:-2] + ".log")).read_text(encoding="utf-8-sig")
    passed = re.search(r"Failed:\s*0, Passed:\s*(\d+), Skipped:\s*0, Total:\s*\1\b", transcript)
    assert passed, transcript[-1200:]
    output = lab / platform / "bin/Lokad.Lython.PublicApi.Tests" / ("release_" + target)
    packages = []
    for row in manifest["Packages"]:
        if row["Id"] not in ("Lokad.Utf8Regex", "Lokad.Utf8Regex.PythonRe") or row["TargetFramework"] != target:
            continue
        package = feed / Path(row["RelativePath"]).name
        assert sha(package.read_bytes()) == row["PackageSha256"]
        library = row["Id"] + ".dll"
        with zipfile.ZipFile(package) as asset:
            expected = asset.read(f"lib/{target}/{library}")
        assert sha(expected) == row["AssemblySha256"]
        assert (output / library).read_bytes() == expected
        packages.append(dict(package=package.name, sha256=row["PackageSha256"], assemblySHA256=row["AssemblySha256"]))
    assert len(packages) == 2
    rows.append(dict(platform=platform, target=target, passed=int(passed[1]), packages=packages))
proof = dict(lythonSource=source, bridgePatchSHA256=sha(patch), producerSource=manifest["SourceRevision"],
             producerVersion=manifest["PackageVersion"], checks=rows)
(lab / "verification.json").write_text(json.dumps(proof, indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(proof))
