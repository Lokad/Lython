#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/body-signature-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/body-signature-20261123
filter='Category!=Stress&(FullyQualifiedName~Default|FullyQualifiedName~Binding|FullyQualifiedName~Dataclass|FullyQualifiedName~Generator|FullyQualifiedName~ExecutableFunction|FullyQualifiedName~NativeCall|FullyQualifiedName~NativeUnpack|FullyQualifiedName~IntegerReturn|FullyQualifiedName~FunctionTransport|FullyQualifiedName~BoundBox|FullyQualifiedName~BoundMethod|FullyQualifiedName~Recursion|FullyQualifiedName~ManagedStack|FullyQualifiedName~Annotation|FullyQualifiedName~TypeParam|FullyQualifiedName~ScopeDirective|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~CasedSplitOwnership|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~FormattedStringExecutable)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/white-refined-ubuntu.log" 2>&1 || { tail -38 "$lab/white-refined-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/public-refined-ubuntu.log" 2>&1 || { tail -38 "$lab/public-refined-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-refined-ubuntu.log" "$lab/public-refined-ubuntu.log"
