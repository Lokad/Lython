$root = Join-Path $env:USERPROFILE '.dotnet11'
$env:DOTNET_ROOT = $root
$env:DOTNET_ROOT_X64 = $root
$env:PATH = "$root;$env:Path"
$env:DOTNET_HOST_PATH = Join-Path $root 'dotnet.exe'
$lab = $PSScriptRoot
Set-Location 'D:/code/Lython/.git/agent-worktrees/body-signature-20261123'
$filter = 'Category!=Stress&(FullyQualifiedName~Default|FullyQualifiedName~Binding|FullyQualifiedName~Dataclass|FullyQualifiedName~Generator|FullyQualifiedName~ExecutableFunction|FullyQualifiedName~NativeCall|FullyQualifiedName~NativeUnpack|FullyQualifiedName~IntegerReturn|FullyQualifiedName~FunctionTransport|FullyQualifiedName~BoundBox|FullyQualifiedName~BoundMethod|FullyQualifiedName~Recursion|FullyQualifiedName~ManagedStack|FullyQualifiedName~Annotation|FullyQualifiedName~TypeParam|FullyQualifiedName~ScopeDirective|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~CasedSplitOwnership|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~FormattedStringExecutable)'
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-refined" --filter $filter > "$lab/white-refined-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/white-refined-windows.log" -Encoding utf8 -Tail 38; exit $code }
& $env:DOTNET_HOST_PATH test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/windows-refined" --filter $filter > "$lab/public-refined-windows.log" 2>&1
$code = $LASTEXITCODE
if ($code) { Get-Content "$lab/public-refined-windows.log" -Encoding utf8 -Tail 38; exit $code }
Get-Content "$lab/white-refined-windows.log", "$lab/public-refined-windows.log" -Encoding utf8 | Select-String 'Passed!'
