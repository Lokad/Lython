from pathlib import Path
import hashlib,json,os,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"prepared-histogram-20261122/comparison/catalog.json"
known=json.loads(prior.read_text(encoding="utf-8"))
original=known["cases"][0]
assert original["id"]=="diagnostic.text-summary.nonlocal-computed-width.large"
needle="            for word in words_from_line(line):"
assert original["source"].count(needle)==1
source=original["source"].replace(needle,"            words = words_from_line(line)\n            for word in words:")
digest=lambda value: hashlib.sha256(value).hexdigest()
materialized={**original,"source":source,"id":"diagnostic.text-summary.materialized-line.large",
    "sourceUtf8Bytes":len(source.encode("utf-8")),"sourceSha256":digest(source.encode("utf-8"))}
catalog=lab/"text-route-catalog.json"
catalog.write_text(json.dumps({**known,"cases":[original,materialized]},ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")

identity=json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))
image=lab/"comparison/frozen-reference"
expected=identity["imageFiles"]["reference"]
assert {name:digest((image/name).read_bytes()) for name in expected}==expected
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert digest(protocol.read_bytes())==identity["protocolSHA256"]
proof=lab/"text-route-verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
    env=env,cwd=repo,check=True,timeout=45)
receipt=json.loads(proof.read_text(encoding="utf-8"))
assert receipt["state"]=="Completed" and receipt["caseCount"]==2 and receipt["catalogSha256"]==digest(catalog.read_bytes())
allocation=lab/"text-route-allocation.json"
subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,allocation],env=env,cwd=repo,check=True,timeout=60)
rows=json.loads(allocation.read_text(encoding="utf8"))["rows"]
assert len(rows)==2 and all(r["sharedBudgetBaselineRestored"]for r in rows)
for row in rows:
    print(row["id"], "allocation",statistics.median(row["allocatedBytesPerInvocation"]),
        "peak",row["peakExecutionMemoryBytes"])
