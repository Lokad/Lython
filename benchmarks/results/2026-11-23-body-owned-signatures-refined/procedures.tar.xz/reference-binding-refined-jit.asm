; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 24 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 504
       lea      rbp, [rsp+0x230]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG23:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG23
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, gword ptr [rbp+0x38]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x005E
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x006E
       mov      rdx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdx+0xE0], 0
       je       G_M000_IG09
       cmp      byte  ptr [rbp+0x48], 0
       je       SHORT G_M000_IG05
       cmp      r12d, dword ptr [rdx+0xC4]
       jne      G_M000_IG09
       mov      bword ptr [rbp-0x1A0], r13
       mov      dword ptr [rbp-0x198], r12d
       lea      rdx, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00BE
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      rax, rax
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], rax
       jmp      G_M000_IG12
 
G_M000_IG05:                ;; offset=0x00D3
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG07
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG07
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x1D8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG06:                ;; offset=0x013E
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      ecx, eax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x016D
       xor      ecx, ecx
 
G_M000_IG08:                ;; offset=0x016F
       test     ecx, ecx
       jne      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0177
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      r10d, dword ptr [rcx+0xD4]
       mov      dword ptr [rbp-0x18C], r10d
       cmp      r10d, 16
       ja       G_M000_IG18
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG14
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r10d
       ja       G_M000_IG18
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      dword ptr [rbp-0x1A8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG10:                ;; offset=0x020C
       mov      dword ptr [rbp-0x1B8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r13
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x1B0]
       lea      rdx, [rbp-0x1C0]
       lea      r9, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG11:                ;; offset=0x025F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1A8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r15
       mov      rdi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG12:                ;; offset=0x02D3
       nop      
 
G_M000_IG13:                ;; offset=0x02D4
       add      rsp, 504
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x02E8
       xor      eax, eax
       test     rsi, rsi
       je       SHORT G_M000_IG15
       mov      eax, 1
       test     r10d, r10d
       je       G_M000_IG22
       mov      gword ptr [rbp-0x138], rsi
       xor      ecx, ecx
       mov      qword ptr [rbp-0x130], rcx
 
G_M000_IG15:                ;; offset=0x030D
       cmp      eax, r10d
       ja       SHORT G_M000_IG18
       lea      rcx, bword ptr [rbp-0x138]
       mov      edx, eax
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r10d
       sub      edx, eax
       cmp      r12d, edx
       ja       SHORT G_M000_IG21
 
G_M000_IG16:                ;; offset=0x032C
       mov      r8d, r12d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       SHORT G_M000_IG20
 
G_M000_IG17:                ;; offset=0x033C
       mov      rdx, r13
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa37082aa8)], 0
       je       G_M000_IG11
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0353
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG19:                ;; offset=0x035A
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG11
 
G_M000_IG20:                ;; offset=0x0364
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG11
 
G_M000_IG21:                ;; offset=0x0372
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG22:                ;; offset=0x0379
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 895

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 36 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rsi, rdx
       mov      rdi, r8
       mov      rbx, r9
       mov      r8, gword ptr [rbp+0x30]
       mov      r14, gword ptr [rbp+0x40]
       mov      r15, gword ptr [rbp+0x48]
       mov      rdx, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0058
       mov      r13, bword ptr [rdx]
       mov      r12d, dword ptr [rdx+0x08]
       mov      rax, bword ptr [rcx]
       mov      bword ptr [rbp-0x118], rax
       mov      r10d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x8C], r10d
 
G_M000_IG03:                ;; offset=0x0074
       xor      r11d, r11d
       mov      r9, gword ptr [rbx+0x08]
       cmp      dword ptr [r9+0x4C], 0
       jge      G_M000_IG07
       test     r15, r15
       je       G_M000_IG06
       movzx    rcx, byte  ptr [r15+0x34]
       test     ecx, ecx
       je       SHORT G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0098
       mov      ecx, dword ptr [r9+0x3C]
       test     r14, r14
       setne    dl
       movzx    rdx, dl
       sub      ecx, edx
       cmp      ecx, r12d
       jl       G_M000_IG38
       test     r14, r14
       je       SHORT G_M000_IG05
       mov      dword ptr [rbp-0x5C], 1
       test     r10d, r10d
       je       G_M000_IG41
       mov      rcx, rax
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      rax, bword ptr [rbp-0x118]
       mov      qword ptr [rax+0x08], rdx
       mov      rax, bword ptr [rbp-0x118]
       mov      r8, gword ptr [rbp+0x30]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
 
G_M000_IG05:                ;; offset=0x00F3
       test     r12d, r12d
       je       G_M000_IG18
       xor      r9d, r9d
       mov      dword ptr [rbp-0xD4], r12d
       jmp      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x010B
       cmp      dword ptr [rsi+0x08], 0
       je       SHORT G_M000_IG04
 
G_M000_IG07:                ;; offset=0x0111
       mov      bword ptr [rbp-0xA0], rax
       mov      dword ptr [rbp-0x98], r10d
 
G_M000_IG08:                ;; offset=0x011F
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG09:                ;; offset=0x012B
       mov      gword ptr [rsp+0x20], r8
       mov      gword ptr [rsp+0x28], r14
       mov      gword ptr [rsp+0x30], r15
       mov      bword ptr [rbp-0xC0], r13
       mov      dword ptr [rbp-0xB8], r12d
       lea      rcx, [rbp-0x40]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xA0]
       lea      rdx, [rbp-0xB0]
       lea      r9, [rbp-0xC0]
       mov      qword ptr [rsp+0x38], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):int]
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG10:                ;; offset=0x0195
       mov      r8d, dword ptr [rbp-0x5C]
       mov      eax, r8d
       mov      r8, gword ptr [rbx+0x08]
       cmp      eax, dword ptr [r8+0x3C]
       jge      G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01AA
       cmp      eax, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      r9, rax
       shl      r9, 4
       mov      qword ptr [rbp-0xC8], r9
       mov      r11, bword ptr [rbp-0x118]
       cmp      gword ptr [r11+r9], 0
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01D2
       lea      r8, [rbp-0x80]
       mov      rcx, rbx
       mov      qword ptr [rbp-0xE0], rax
       mov      edx, eax
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      r8, qword ptr [rbp-0xC8]
       add      r8, bword ptr [rbp-0x118]
       mov      rcx, r8
       mov      bword ptr [rbp-0x120], rcx
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x78]
       mov      rcx, bword ptr [rbp-0x120]
       mov      qword ptr [rcx+0x08], rdx
       mov      rax, qword ptr [rbp-0xE0]
 
G_M000_IG13:                ;; offset=0x0227
       inc      eax
       mov      rdx, gword ptr [rbx+0x08]
       cmp      eax, dword ptr [rdx+0x3C]
       jl       G_M000_IG11
 
G_M000_IG14:                ;; offset=0x0236
       mov      dword ptr [rbp-0x60], -1
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x40], 0
       je       SHORT G_M000_IG15
       mov      r11, bword ptr [rbp-0x118]
       mov      bword ptr [rbp-0xA0], r11
       mov      r10d, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0x98], r10d
       lea      rdx, [rbp-0xA0]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryFillPreparedKeywordDefaults(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rax, bword ptr [rbp-0x118]
       mov      bword ptr [rbp-0xA0], rax
       mov      r10d, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0x98], r10d
       movzx    rcx, byte  ptr [rbp+0x38]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0xA0]
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:CompleteLiveKeywordDefaults(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):int]
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG15:                ;; offset=0x02BC
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x50], 0
       jl       G_M000_IG17
       cmp      gword ptr [rbp-0x50], 0
       jne      G_M000_IG16
       mov      r9, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x100], rdx
       mov      rcx, 0x7FF9D78310B8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xF0], rax
       mov      rdx, gword ptr [rbp-0x100]
       mov      r8, gword ptr [rdx+0x88]
       mov      rdx, r8
       mov      gword ptr [rbp-0x108], rdx
       lea      rcx, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xF0]
       lea      rcx, bword ptr [rax+0x18]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xF0]
       mov      byte  ptr [rax+0x54], 0
       mov      rcx, rax
       mov      r9, rdi
       mov      r8, gword ptr [rbp-0x108]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.PyDict:InitializeNativeStorage(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0xF0]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0xF0]
       mov      gword ptr [rbp-0x50], rcx
 
G_M000_IG16:                ;; offset=0x036F
       mov      r9, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x110], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rcx, gword ptr [rbp-0x110]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG17:                ;; offset=0x03A0
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0x4C]
       test     edx, edx
       jl       G_M000_IG35
       cmp      edx, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      r9d, edx
       shl      r9, 4
       add      r9, bword ptr [rbp-0x118]
       mov      bword ptr [rbp-0xE8], r9
       cmp      dword ptr [rbp-0x48], 0
       je       G_M000_IG33
       mov      bword ptr [rbp-0xC0], r13
       mov      dword ptr [rbp-0xB8], r12d
       mov      edx, dword ptr [rbp-0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      edx, dword ptr [rbp-0x48]
       mov      dword ptr [rsp+0x28], edx
       mov      r8, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x30], r8
       mov      gword ptr [rsp+0x38], rdi
       lea      rdx, [rbp-0xC0]
       mov      rcx, rsi
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateVariadicPositionalTuple(System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Frontend.ExecutableCallSite,System.Object,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       jmp      G_M000_IG34
 
G_M000_IG18:                ;; offset=0x0422
       mov      dword ptr [rbp-0x5C], r11d
       jmp      G_M000_IG10
 
G_M000_IG19:                ;; offset=0x042B
       mov      rdx, gword ptr [rbp-0x70]
       mov      r8, 0x201E2C03970
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG26
       cmp      qword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG20
       mov      r8, gword ptr [rbp-0x70]
       mov      dword ptr [rbp-0x5C], r11d
       jmp      G_M000_IG32
 
G_M000_IG20:                ;; offset=0x0456
       cmp      qword ptr [rbp-0x68], 0
       jle      G_M000_IG25
       mov      dword ptr [rbp-0x5C], r11d
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, 0x7FF9D7934238
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xF8], rax
       test     rax, rax
       jne      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0484
       mov      rax, bword ptr [rbp-0x118]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
       jmp      G_M000_IG25
 
G_M000_IG22:                ;; offset=0x049B
       mov      r8d, dword ptr [rbp-0x68]
       dec      r8d
       mov      dword ptr [rbp-0x88], r8d
       mov      rdx, gword ptr [rax+0x08]
       mov      rcx, 0x7FF9D7142560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG23
       mov      r8d, dword ptr [rbp-0x88]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG41
       mov      ecx, r8d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x04DC
       mov      r8d, dword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0xF8]
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG24:                ;; offset=0x04FC
       mov      gword ptr [rbp-0x70], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x68], rcx
       mov      rax, bword ptr [rbp-0x118]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
 
G_M000_IG25:                ;; offset=0x0518
       mov      r8, gword ptr [rbp-0x70]
       mov      dword ptr [rbp-0x5C], r11d
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x0525
       mov      dword ptr [rbp-0x5C], r11d
       mov      rcx, 0x7FF9D7176488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rbp-0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      gword ptr [rbp-0x70], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x68], rcx
       mov      rax, bword ptr [rbp-0x118]
       mov      r9, qword ptr [rbp-0xD0]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
 
G_M000_IG27:                ;; offset=0x0565
       lea      edx, [r11+0x01]
       mov      dword ptr [rbp-0x5C], edx
       cmp      r11d, r10d
       jae      G_M000_IG41
       mov      r11d, r11d
       shl      r11, 4
       add      r11, rax
       mov      bword ptr [rbp-0x128], r11
       mov      qword ptr [rbp-0xD0], r9
       lea      r8, bword ptr [r9+r13]
       mov      bword ptr [rbp-0x130], r8
       mov      rdx, gword ptr [r8]
       mov      rcx, r11
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp-0x130]
       mov      r8, qword ptr [r8+0x08]
       mov      rcx, bword ptr [rbp-0x128]
       mov      qword ptr [rcx+0x08], r8
       mov      r9, qword ptr [rbp-0xD0]
       add      r9, 16
       mov      ecx, dword ptr [rbp-0xD4]
       dec      ecx
       mov      dword ptr [rbp-0xD4], ecx
       je       G_M000_IG10
 
G_M000_IG28:                ;; offset=0x05D8
       mov      rax, bword ptr [rbp-0x118]
       mov      r8, gword ptr [rbp+0x30]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
 
G_M000_IG29:                ;; offset=0x05EE
       cmp      gword ptr [r9+r13], 0
       jne      G_M000_IG27
 
G_M000_IG30:                ;; offset=0x05F9
       mov      qword ptr [rbp-0xD0], r9
       vmovdqu  xmm0, xmmword ptr [r9+r13]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG31:                ;; offset=0x060B
       mov      rdx, gword ptr [rbp-0x70]
       mov      r8, 0x201E2C03968
       cmp      rdx, gword ptr [r8]
       jne      G_M000_IG19
       mov      dword ptr [rbp-0x5C], r11d
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG32:                ;; offset=0x0633
       test     r8, r8
       mov      rax, bword ptr [rbp-0x118]
       mov      r9, qword ptr [rbp-0xD0]
       mov      r10d, dword ptr [rbp-0x8C]
       mov      r11d, dword ptr [rbp-0x5C]
       jne      G_M000_IG27
       jmp      G_M000_IG39
 
G_M000_IG33:                ;; offset=0x065A
       mov      rdx, 0x201E2C01C18
       mov      rdx, gword ptr [rdx]
 
G_M000_IG34:                ;; offset=0x0667
       mov      rcx, bword ptr [rbp-0xE8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0xE8]
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG35:                ;; offset=0x0680
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG37
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0x50]
       cmp      ecx, dword ptr [rbp-0x8C]
       jae      G_M000_IG41
       mov      ebx, ecx
       shl      rbx, 4
       add      rbx, bword ptr [rbp-0x118]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
 
G_M000_IG36:                ;; offset=0x06B9
       mov      gword ptr [rbp-0x50], rcx
 
G_M000_IG37:                ;; offset=0x06BD
       mov      ebx, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0x84], ebx
       jmp      G_M000_IG42
 
G_M000_IG38:                ;; offset=0x06CB
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this
       mov      esi, eax
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this
       mov      rdx, rax
       mov      ecx, esi
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:                ;; offset=0x06FE
       mov      rcx, 0x7FF9D72A94A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x201CA050228
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG40:                ;; offset=0x072C
       mov      rax, qword ptr [rbp-0xE0]
       mov      esi, eax
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableKind():int:this
       mov      r14d, eax
       mov      rcx, rbx
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.FunctionBindingPlan:get_CallableName():System.String:this
       mov      r15, rax
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:NameAt(int):System.String:this]
       mov      r8, rax
       mov      ecx, r14d
       mov      rdx, r15
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG41:                ;; offset=0x077B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG42:                ;; offset=0x0781
       call     G_M000_IG48
       nop      
 
G_M000_IG43:                ;; offset=0x0787
       mov      eax, dword ptr [rbp-0x84]
 
G_M000_IG44:                ;; offset=0x078D
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x07A1
       sub      rsp, 104
 
G_M000_IG46:                ;; offset=0x07A5
       mov      r8, gword ptr [rbp+0x30]
       mov      rcx, gword ptr [r8+0x98]
       mov      rcx, gword ptr [rcx+0x88]
       mov      rdx, qword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       nop      
 
G_M000_IG47:                ;; offset=0x07C4
       add      rsp, 104
       ret      
 
G_M000_IG48:                ;; offset=0x07C9
       sub      rsp, 104
 
G_M000_IG49:                ;; offset=0x07CD
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG54
 
G_M000_IG50:                ;; offset=0x07D4
       mov      rbx, gword ptr [rbp-0x50]
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyDict:RefundAbortedConstruction():this]
       xor      rcx, rcx
       mov      gword ptr [rbx+0x08], rcx
 
G_M000_IG51:                ;; offset=0x07E9
       mov      gword ptr [rbx+0x28], rcx
 
G_M000_IG52:                ;; offset=0x07ED
       mov      gword ptr [rbx+0x30], rcx
 
G_M000_IG53:                ;; offset=0x07F1
       call     G_M000_IG45
       nop      
 
G_M000_IG54:                ;; offset=0x07F7
       add      rsp, 104
       ret      
 
; Total bytes of code 2044

