from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/body-signature-20261123"
previous = lab.parent / "direct-bound-integer-refined-20261123" / "comparison"
out = lab / "comparison-refined"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)

core = "Lokad.Lython.dll"
published = read(repo / "benchmarks/results/2026-11-23-direct-bound-integer-refined/source.json")
known = published["imageFiles"]["candidate"]
reference = previous / "frozen-candidate"
assert len(known) == 32 and {n: digest(reference / n) for n in known} == known
base = git("rev-parse", "47cdc8c80", cwd=tree).decode().strip()
assert not git("diff", "--name-only", published["candidate"], base, "--", "src", "tests")
patch = git("diff", "--binary", base, "--", "src", "tests", cwd=tree)
assert patch.count(b"diff --git ") == 34
(out / "source.patch").write_bytes(patch)
python = Path("C:/Python313/python.exe")

catalog = out / "representative.json"
prior_wide = lab.parent/"native-call-selection-single-proof-20261122/comparison/quiet/representative.json"
wide_identity = read(repo/"benchmarks/results/2026-11-22-native-call-selection-single-proof/source.json")
assert digest(prior_wide) == wide_identity["catalogs"]["representative.json"]["sha256"]
ordinary = read(previous / "representative.json")
assert len(ordinary["cases"]) == 5 and digest(previous / "representative.json") == published["catalogs"]["representative.json"]["sha256"]
wide = next(c for c in read(prior_wide)["cases"] if c["id"] == "calls.positional.large")
save(catalog, {**ordinary, "cases": [*ordinary["cases"], wide]})

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == published["protocolSHA256"]

images, allocation = {}, {}
candidate = lab / "windows-refined/bin/Lokad.Lython/release_net11.0" / core
for role, built in (("reference", reference / core), ("candidate", candidate)):
    image = out / f"frozen-{role}"
    image.mkdir()
    files = {**known, core: digest(built)}
    for name in files:
        shutil.copyfile(built if name == core else reference / name, image / name)
    assert {n: digest(image / n) for n in files} == files
    images[role] = files
    for suffix in (".dll", ".deps.json", ".runtimeconfig.json"):
        name = "ValidatedAllocation" + suffix
        shutil.copyfile(reference / name, image / name)
    proof = out / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", proof],
        env=env, cwd=repo, check=True, timeout=90)
    state = read(proof)
    assert state["state"] == "Completed" and state["catalogSha256"] == digest(catalog) and state["caseCount"] == 6
    report = out / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, report],
        env=env, cwd=repo, check=True, timeout=85)
    rows = read(report)["rows"]
    assert len(rows) == 6 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    allocation[role] = rows
    assert {n: digest(image / n) for n in files} == files

save(out / "identity.json", dict(reference=base, verifiedReferenceSource=published["candidate"], patchBase=base,
    sourcePatchSHA256=sha(patch), imageFiles=images, protocolSHA256=digest(protocol), catalogSHA256=digest(catalog)))
for before, after in zip(allocation["reference"], allocation["candidate"], strict=True):
    assert before["id"] == after["id"]
    a, b = (statistics.median(x["allocatedBytesPerInvocation"]) for x in (before, after))
    print(before["id"], a, b, b - a, round(100 * (b / a - 1), 3),
        before["peakExecutionMemoryBytes"], after["peakExecutionMemoryBytes"], flush=True)
