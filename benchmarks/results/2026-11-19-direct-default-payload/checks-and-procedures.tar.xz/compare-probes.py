from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source = ["events = []\ndef note(name, value):\n    events.append(name)\n    return value\ndef dec():\n    events.append('decorator')\n    return lambda f: f\n@dec()\ndef f(a:note('annotation', int)=note('positional', 7), *, b=note('keyword', 8)):\n    return a,b\nprint(events, f())\n", "def outer():\n    def inner(a=(yield 'first'), /, b=(yield 'second'), *, c=(yield 'third')):\n        return a,b,c\n    yield inner\ng=outer()\nprint(next(g),g.send(1),g.send(2),g.send(3)())\n", "def outer():\n    yield lambda x=(yield 'lambda first'),*,y=(yield 'lambda last'):x+y\ng=outer()\nprint(next(g),g.send(13),g.send(4)())\n", "values=[]\ndef stamp(n):\n    values.append(n)\n    if n == 2: raise ValueError('stop')\n    return values\ntry:\n    f=lambda a=stamp(1), b=stamp(2), *, c=stamp(3):a\nexcept ValueError:\n    print(values)\n", "survivors=[]\ndef capture(f):\n    survivors.append(f)\n    raise ValueError('expected')\ndef run(x):\n    try:\n        @capture\n        def f(a=x+10000,b=x/2,*,c=x):\n            return a,b,c\n    except ValueError:\n        return None\nrun(5)\nf=survivors[0]\nprint(f(), f()[0] is f.__defaults__[0], f()[1] is f.__defaults__[1])\n", 'class C:\n    payload=[]\n    def method(self, x=payload, *, y=1):\n        return x,y\n    make = staticmethod(lambda x=payload,*,y=2:(x,y))\nprint(C().method()[0] is C.payload,C.make()[0] is C.payload,C.make()[1])\n', 'def build(n):\n    def f(value=n+10000, real=n/3, big=10**80):\n        return value,real,big\n    return f, lambda copied=f.__defaults__[0]:copied\nf, copy = build(3)\nactual=f()\nprint(actual[0],actual[1],actual[2]==10**80)\nprint(copy() is actual[0], tuple(x is y for x,y in zip(f.__defaults__,actual)))\n', 'def build(n):\n    return lambda a=n,b=n+1,c=n+2,d=n+3,e=n+4,f=n+5,g=n+6,h=n+7,i=n+8,j=n+9,k=n+10,l=n+11,m=n+12,p=n+13,q=n+14,r=n+15,s=n+16: (a,h,r,s)\nprint(build(45)())\n']
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs = (lab/'probes.json').read_bytes()
driver = Path('tools/LythonProbe/bin/Release/net11.0')
identity = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))['images']
work = lab/'probe'
work.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def all_hashes(path):
    return {entry.name:digest(entry) for entry in path.iterdir() if entry.is_file()}
stock = [subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',program],capture_output=True,text=True,encoding='utf-8',check=True,timeout=20).stdout for program in source]
matches=[]
for role in ('reference','candidate'):
    image = work/role
    image.mkdir(exist_ok=True)
    for entry in driver.iterdir():
        if entry.is_file() and entry.suffix != '.pdb': shutil.copyfile(entry,image/entry.name)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(lab/'frozen'/role/name, image/name)
        assert digest(image/name)==identity[role][name]
common=all_hashes(work/'reference')
assert common | {'Lokad.Lython.dll':identity['candidate']['Lokad.Lython.dll']} == all_hashes(work/'candidate')
for mode in ('sync','async'):
    results=[]
    for role in ('reference','candidate'):
        args=[sdk/'dotnet.exe',work/role/'LythonProbe.dll','--batch-json']+(['--async'] if mode=='async' else [])
        completed=subprocess.run(args,env=env,input=inputs,capture_output=True,timeout=60)
        (lab/f'probe-{role}-{mode}.jsonl').write_bytes(completed.stdout)
        (lab/f'probe-{role}-{mode}.stderr').write_bytes(completed.stderr)
        records=[json.loads(line) for line in completed.stdout.decode('utf-8-sig').splitlines()]
        assert len(records)==len(source), (role, mode, completed.returncode, completed.stderr)
        semantics=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
        results.append([{key:record['Lython'][key] for key in semantics} for record in records])
    assert results[0]==results[1], [i for i,pair in enumerate(zip(*results)) if pair[0]!=pair[1]]
    assert all(value['Success'] and value['StandardOutput'] == expect for value, expect in zip(results[1], stock, strict=True)), results[1]
    matches.append(dict(mode=mode, matching=len(source)))
(lab/'probe-summary.json').write_text(json.dumps(dict(results=matches, referenceImage=common),indent=2)+'\n',encoding='utf-8',newline='\n')
print(matches)
