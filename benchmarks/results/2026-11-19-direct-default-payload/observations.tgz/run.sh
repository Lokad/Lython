set -eu
root=/home/lokad/lython-bench-checks/direct-default-payload-b1111-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
