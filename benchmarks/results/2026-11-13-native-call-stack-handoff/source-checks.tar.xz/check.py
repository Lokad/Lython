from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
phase,label=sys.argv[1:]
if phase=='build':jobs=[('public-'+tfm,[str(sdk/'dotnet.exe'),'build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--disable-build-servers','-m:1'])for tfm in ['net11.0','net10.0']]
else:
 filt='Category!=Stress&(FullyQualifiedName~StackGuardScenario|FullyQualifiedName~FailureAttributionTests|FullyQualifiedName~RecursionDepthScenario|FullyQualifiedName~ComposedHelper)'
 jobs=[('public-'+tfm,[str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-build','--disable-build-servers','--filter',filt,'--logger','console;verbosity=normal','--blame-crash','--blame-crash-dump-type','mini','--results-directory',str(r/(label+'-'+tfm))])for tfm in ['net11.0','net10.0']]
for name,args in jobs:
 p=r/(phase+'-'+name+'-'+label+'.log');assert not p.exists()
 with p.open('w',encoding='utf-8',newline='\n')as log:
  child=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  print(p.name,'owned pid',child.pid,flush=True);code=child.wait()
 output=p.read_text(encoding='utf-8');print(p.name,'exit',code,output[-2500:],flush=True)
 if code or 'No test matches'in output:raise SystemExit(code or 1)
