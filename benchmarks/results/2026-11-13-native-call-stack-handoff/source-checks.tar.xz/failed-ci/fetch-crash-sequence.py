from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
r=Path(__file__).parent;p=r/'ci-windows-crash.zip';assert not p.exists()
with p.open('wb')as output:done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','api','repos/Lokad/Lython/actions/artifacts/14012899596/zip','--allow-escape-sequences'],stdout=output,stderr=subprocess.PIPE)
assert done.returncode==0,done.stderr.decode('utf-8')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='952dec4ed9cb26e487ff6e8d53bafa8cd82040b94792d9efc77a502dd1f943b1'
with zipfile.ZipFile(p)as archive:
 print('Crash artifact entries:',[(i.filename,i.file_size)for i in archive.infolist()],flush=True)
 names=[n for n in archive.namelist()if n.endswith('.xml')];assert len(names)==1
 blob=archive.read(names[0]);(r/'ci-windows-sequence.xml').write_bytes(blob)
 document=ET.fromstring(blob);tests=list(document)
 for test in tests:
  if test.attrib.get('Completed','').lower()=='false':print('UNFINISHED:',test.attrib,flush=True)
 print('Last recorded tests:',[t.attrib for t in tests[-8:]],flush=True)
