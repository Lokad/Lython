from pathlib import Path
import json,re,subprocess
r=Path(__file__).parent;p=sorted(r.glob('ci-2*.json'))[-1];state=json.loads(p.read_text(encoding='utf-8'))
job=next(j for j in state['jobs']if j['name']=='tests (windows-latest)');assert job['status']=='completed'and job['conclusion']=='failure'
print('Failed steps:',[(s['name'],s['conclusion'])for s in job['steps']if s['conclusion']not in ['success','skipped']],flush=True)
out=r/'ci-windows-failure-raw.log';assert not out.exists()
with out.open('wb')as log:done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','api','repos/Lokad/Lython/actions/jobs/'+str(job['databaseId'])+'/logs','--allow-escape-sequences'],stdout=log,stderr=subprocess.PIPE)
assert done.returncode==0,done.stderr.decode('utf-8')
lines=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',out.read_text(encoding='utf-8',errors='replace')).splitlines();indices=[i for i,line in enumerate(lines)if any(w in line for w in ['[FAIL]','Failed ','error ','Error Message:','Assert.','Exception:','Test Run Failed'])]
shown=set()
for i in indices:
 for n in range(max(0,i-2),min(len(lines),i+11)):
  if n not in shown:print(f'{n+1}: {lines[n]}');shown.add(n)
