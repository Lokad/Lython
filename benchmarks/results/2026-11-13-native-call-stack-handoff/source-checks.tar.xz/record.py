from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent;out=Path('benchmarks/results/2026-11-13-native-call-stack-handoff');out.mkdir()
state=json.loads((old/'ci-terminal.json').read_text(encoding='utf-8'));assert state['status']=='completed'and state['conclusion']=='failure'
assert {j['name']:j['conclusion']for j in state['jobs']}=={'tests (ubuntu-latest)':'success','tests (windows-latest)':'failure'}
with(old/'ci-failed-full-logs.zip').open('wb')as log:done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','api','repos/Lokad/Lython/actions/runs/43373824703/logs','--allow-escape-sequences'],stdout=log,stderr=subprocess.PIPE)
assert done.returncode==0,done.stderr.decode('utf-8')
identity=json.loads((r/'corrected-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for tfm in ['net11.0','net10.0']:
 text=(r/('focused-public-'+tfm+'-corrected.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and 'Total tests: 66'in text
before=json.loads((r/'candidate-256k-barrier-terminal.json').read_text(encoding='utf-8'));reference=json.loads((r/'reference-256k-barrier-terminal.json').read_text(encoding='utf-8'))
after=json.loads((r/'corrected-256k-barrier-terminal.json').read_text(encoding='utf-8'));finite=json.loads((r/'corrected-256k-finite-terminal.json').read_text(encoding='utf-8'))
assert before['exitCode']==0xc00000fd and reference['exitCode']==after['exitCode']==finite['exitCode']==0
files=[p for p in r.iterdir()if p.is_file()]
files +=[r/'probe/Program.cs',r/'probe/probe.csproj']
files +=[old/name for name in ['ci-terminal.json','ci-windows-failure.log','ci-windows-failure-raw.log','ci-windows-crash.zip','ci-windows-sequence.xml','ci-failed-full-logs.zip','fetch-crash-sequence.py','inspect-failed-job.py']]
with tarfile.open(out/'source-checks.tar.xz','w:xz')as archive:
 for p in files:archive.add(p,arcname=('probe/'if p.parent.name=='probe'else'failed-ci/'if p.parent==old else'')+p.name)
validation=dict(status='Corrected source pending full platform/package qualification',identity=identity,failedRun='43373824703',failedPlatforms={j['name']:j['conclusion']for j in state['jobs']},reference=reference,before=before,after=after,finite=finite,focusedRelease={'net11.0':66,'net10.0':66},contract='Eight logical levels is native-call optimization eligibility, not a new guest limit. Deeper calls transfer before child entry to existing linear runner; existing recursion/512managed admission and first memory refusal remain authoritative.',originalConditions=['An isolated ordinary attribution case passed and did not reproduce the CI crash.','The first small-stack attempts resumed on the large startup worker; they are inconclusive and preserved.','One-worker completed-command barrier then proves actual continuation on requested256KiB managed thread. Qualified6b returns structured error,2f crashes0xC00000FD, corrected2e returns structured error and succeeds at finite depth100.','Initial correction fixture build hit a C# new() overload ambiguity, corrected before checks.','Initial job-log download was rejected for ANSI content; the empty file and corrected raw download are preserved.'],performanceClaim=False,archiveSHA256=hashlib.sha256((out/'source-checks.tar.xz').read_bytes()).hexdigest())
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
print('R304 correction/failed CI/exact controlled fatal witness preserved;132focused checks pass; no speedup claim.',flush=True)
