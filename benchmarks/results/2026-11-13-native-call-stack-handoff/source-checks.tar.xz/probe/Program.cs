using System.Reflection;
using System.Security.Cryptography;
using Lokad.Lython;

var source = "import time\ntime.sleep(1)\ntime.monotonic_ns()\ndef f(n):\n return 7 if n<=0 else f(n-1)\nreturn f(" + args[1] + ")\n";
Console.WriteLine("core=" + Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))));
using var budget = new OwnedBudget(new LythonMemoryBudget(4 * 1024 * 1024));
using var script = new LythonEngine().Compile(source, budget.Value);
if (!script.IsValid) throw new InvalidOperationException(string.Join(";", script.Diagnostics));
var timing = new Timing();
using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));
var run = script.RunAsync(new Host(timing), new LythonRunOptions { MemoryBudget = budget.Value, MaxRecursionDepth = 1024 }, cancellation.Token);
await timing.Entered.Task.WaitAsync(TimeSpan.FromSeconds(5));
if (run.IsCompleted) throw new InvalidOperationException("Expected outstanding host work.");
// With one execution worker, a completed second command proves that the first
// synchronous prefix returned and registered its whole await chain. No sleep race.
if (Environment.ProcessorCount != 1) throw new InvalidOperationException("Require the diagnostic one-worker profile.");
using (var barrier = new LythonEngine().Run("return 1", new Host(new Timing())))
    if (!barrier.Success) throw new InvalidOperationException("Prefix-release barrier failed.");
Console.WriteLine("prefixReleased");
var worker = new Thread(() => { Console.WriteLine("releaseThread=" + Environment.CurrentManagedThreadId); timing.Release.SetResult(); }, int.Parse(args[0]));
worker.Start();
if (!worker.Join(TimeSpan.FromSeconds(15))) throw new TimeoutException("Owned continuation did not join.");
using (var result = await run.WaitAsync(TimeSpan.FromSeconds(5)))
    Console.WriteLine($"success={result.Success}; return={result.ReturnValue}; failure={result.Failure?.Message}; reason={result.FailureAttribution?.Reason}; continuation={timing.ResumeThread}; owned={worker.ManagedThreadId}");
script.Dispose();
if (budget.Value.ReservedBytes != 0) throw new InvalidOperationException("Funding did not return to baseline.");

sealed class OwnedBudget(LythonMemoryBudget value) : IDisposable
{
    public LythonMemoryBudget Value => value;
    public void Dispose() { if (value.ReservedBytes != 0) throw new InvalidOperationException("Unretired funding."); }
}
sealed class Timing : ILythonTiming
{
    public readonly TaskCompletionSource Entered = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public readonly TaskCompletionSource Release = new();
    public int ResumeThread;
    public long MonotonicNanoseconds { get { ResumeThread = Environment.CurrentManagedThreadId; Console.WriteLine("resumeThread=" + ResumeThread); return 0; } }
    public ValueTask DelayAsync(TimeSpan duration, CancellationToken token) { Entered.SetResult(); return new(Release.Task); }
}
sealed class Host(Timing timing) : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ILythonTiming? Timing => timing;
    public ValueTask<bool> ExistsAsync(LythonPathRequest p, CancellationToken t) => new(false);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest p, CancellationToken t) => new(Array.Empty<string>());
    public ValueTask MkDirAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("mkdir");
    public ValueTask RemoveAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("remove");
    public ValueTask CopyAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("copy");
    public ValueTask MoveAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("move");
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("stat");
}
