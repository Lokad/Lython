from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
r=Path(__file__).parent;names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in names};assert len(sources)==571
old=json.loads((r.parent/'refined/candidate-identity.json').read_text(encoding='utf-8'))
assert[p for p,h in sources.items()if h!=old['sources'][p]]==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'corrected-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R304 conservative native-call eligibility hands deep calls to existing linear runner using existing logical depth; no new guest limit/counter',sources=sources,coreSHA256=hashlib.sha256((r/'corrected-core.dll').read_bytes()).hexdigest(),previousSHA256=old['coreSHA256'])
(r/'corrected-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'corrected-sources.tar.xz','w:xz')as archive:
 for name in sources:archive.add(name,arcname=name)
print('Corrected source matched core frozen',identity['coreSHA256'],flush=True)
