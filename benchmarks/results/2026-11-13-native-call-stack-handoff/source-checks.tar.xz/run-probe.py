from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
r=Path(__file__).parent;label,role,stack,depth=sys.argv[1:];base=r.parent
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')if role=='corrected'else base/('reference/Lokad.Lython.dll'if role=='reference'else'refined/candidate/Lokad.Lython.dll')
out=r/'probe/bin/Release/net11.0';target=out/'Lokad.Lython.dll'
assert target.resolve().is_relative_to(out.resolve())and not target.is_symlink()
target.unlink();shutil.copyfile(core,target)
sha=hashlib.sha256(core.read_bytes()).hexdigest();assert hashlib.sha256(target.read_bytes()).hexdigest()==sha
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
env['DOTNET_PROCESSOR_COUNT']='1' # Diagnostic scheduling barrier only; no performance comparison.
args=[str(sdk/'dotnet.exe'),str(out/'probe.dll'),stack,depth]
p=r/(label+'.log');assert not p.exists()
with p.open('w',encoding='utf-8',newline='\n')as log:
 child=subprocess.Popen(args,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 owner=dict(startedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=child.pid,args=args,role=role,coreSHA256=sha)
 (r/(label+'-owner.json')).write_text(json.dumps(owner,indent=2)+'\n',encoding='utf-8')
 try:child.wait(timeout=30)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/pid',str(child.pid),'/t','/f'],stdout=log,stderr=subprocess.STDOUT,check=True);child.wait();owner['observationTimeout']=True
owner.update(exitCode=child.returncode,stoppedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(r/(label+'-terminal.json')).write_text(json.dumps(owner,indent=2)+'\n',encoding='utf-8')
text=p.read_text(encoding='utf-8');print(label,'exit',child.returncode,'bytes',p.stat().st_size,flush=True);print(text[:1200],flush=True)
if len(text)>1200:print(text[-3500:],flush=True)
