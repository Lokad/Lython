from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'build-probe.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'probe/probe.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print((r/'build-probe.log').read_text(encoding='utf-8')[-5000:],flush=True);assert done.returncode==0
