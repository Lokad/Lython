from pathlib import Path
import hashlib,json,os,statistics,subprocess
lab=Path('.git/agent-notes/review-20261031/single-positional-default-20261122')
catalog=json.loads((lab/'representative.json').read_text(encoding='utf-8'))
case=next(x for x in catalog['cases'] if x['id']=='scripts.factory-observed-defaults').copy()
marker="    total += latest(index)"
assert case['source'].count(marker)==1
case['source']=case['source'].replace(marker,"    assert latest.__defaults__[0] is latest.__defaults__[0]\n"+marker)
case['id']='scripts.factory-observed-default-value-identity'
case['sourceUtf8Bytes']=len(case['source'].encode('utf-8'))
case['sourceSha256']=hashlib.sha256(case['source'].encode('utf-8')).hexdigest()
catalog['cases']=[case]
manifest=(lab/'observed-value-catalog.json').resolve()
manifest.write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
python=Path('C:/Python313/python.exe')
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
expected=json.loads((lab/'identity.json').read_text(encoding='utf-8'))['imageFiles']
rows=[]
for role in ['reference','candidate']:
 image=(lab/'frozen'/role).resolve()
 def check():assert {n:hashlib.sha256((image/n).read_bytes()).hexdigest() for n in expected[role]}==expected[role]
 check()
 receipt=lab/(role+'-value-verify.json')
 subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
     '--dotnet',dotnet,'--python',python,'--python-worker','benchmarks/cpython-worker.py','--out',receipt],env=env,check=True,timeout=90)
 assert json.loads(receipt.read_text(encoding='utf-8-sig'))['state']=='Completed'
 report=lab/(role+'-value-allocation.json')
 subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,report],env=env,check=True,timeout=90)
 check()
 row,=json.loads(report.read_text(encoding='utf-8-sig'))['rows']
 assert row['id']==case['id'] and row['sharedBudgetBaselineRestored']
 rows.append(dict(role=role,allocatedBytes=statistics.median(row['allocatedBytesPerInvocation']),
                  peak=row['peakExecutionMemoryBytes']))
print(rows)
(lab/'observed-value-allocation.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')

