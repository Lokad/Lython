from pathlib import Path
import ast,hashlib,json
r=Path(__file__).parent;q=r/'profile';q.mkdir();old=r.parent/'frontend-regions-r412/profile';base=r.parent/'prepared-stores-r413/checkpoint';remote='/home/lokad/lython-bench-checks/matched-calls-b808-20261115';unit='lython-b808-matched-calls-20261115'
catalog=json.loads((r.parent/'helper-boundaries-r410/catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']in ['scripts.helper-boundary.inline','scripts.helper-boundary.helper']];assert len(catalog['cases'])==2 and len({c['fixtureSha256']for c in catalog['cases']})==1 and len({c['expectedOutputSha256']for c in catalog['cases']})==1
(q/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
reference=json.loads((base/'identity.json').read_text(encoding='utf-8'));identity=dict(sourceRevision=reference['sourceRevision'],runtimeCommit=reference['runtimeCommit'],purpose='R414 bounded matched no-counter helper/inline attribution; locate whole call/transport/preparation work to displace. No timing or removable-share claim.',coreSHA256=dict(candidate=reference['coreSHA256']['candidate']),auxiliaryFiles=reference['auxiliaryFiles'],catalogSHA256=hashlib.sha256((q/'catalog.json').read_bytes()).hexdigest(),publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('frontend-regions-b804-20261115','matched-calls-b808-20261115').replace('lython-b804-frontend-regions-20261115',unit).replace('B804','B808')
 s=s.replace("[('manifest','scripts.config-manifest.small','compile'),('validator','scripts.config-generated-guards.medium','compile')]","[('inline','scripts.helper-boundary.inline','warm'),('helper','scripts.helper-boundary.helper','warm')]").replace("['manifest','validator']","['inline','helper']").replace('Unchanged qualified1b82/frozen0ed; R412 public compilation attribution','Committed2865f619/frozen55ba4c8a; R414 matched helper/inline attribution')
 s=s.replace('count = 4096 if name == "manifest" else 512 # Same public compile boundary; enough warmup without oversized batches.','count = 512 # Existing complete matched scripts; bounded warmed CPU attribution.')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
print('Prepared exact matched inputs and reused profile collector; not launched, VM remains owned by B807.')
