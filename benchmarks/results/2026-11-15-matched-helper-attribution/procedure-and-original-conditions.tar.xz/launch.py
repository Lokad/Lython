from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'profile';old=r.parent/'prepared-stores-r413';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:size=sum(m.size for m in t if m.isfile())
retire=[]
for name,canonical,member in [('stores-cpython-b807-20261115/observations.tgz','benchmarks/results/2026-11-15-store-cpython-checkpoint/observations.tgz',None),('stores-cpython-b807-20261115/confirmation/confirmation.json','benchmarks/results/2026-11-15-store-cpython-checkpoint/observations.tgz','confirmation/confirmation.json'),('frontend-regions-b804-20261115/observations.tgz','benchmarks/results/2026-11-15-frontend-phase-attribution/observations.tgz',None),('text-loop-b793-20261115/observations.tgz','benchmarks/results/2026-11-15-text-loop-interior/observations.tgz',None)]:
 raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw))as t:raw=t.extractfile(member).read()
 retire.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=member))
canonical='benchmarks/results/2026-11-15-helper-boundary-decomposition/observations.tgz';raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
with tarfile.open(fileobj=io.BytesIO(raw))as t:
 assert 'root=/home/lokad/lython-bench-checks/helper-boundaries-b801-20261115' in t.extractfile('run.sh').read().decode('utf-8')
 raw=t.extractfile('confirmation/confirmation.json').read()
retire.append(dict(path='helper-boundaries-b801-20261115/confirmation/confirmation.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member='confirmation/confirmation.json'))
c=dict(root='/home/lokad/lython-bench-checks/matched-calls-b808-20261115',unit='lython-b808-matched-calls-20261115',source='/home/lokad/lython-bench-checks/stores-cpython-b807-20261115',identity=identity,retire=retire,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
tree=ast.parse((old/'prepare-checkpoint.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='code'for t in n.targets));code=node.value.func.value.value
code=code.replace(" assert sha(Path(c['catalog']))==c['identity']['catalogSHA256']and sha(Path(c['additional']))==c['identity']['additionalCatalogSHA256']\n",'')
code=code.replace(' inodes={};paths=[]',' inodes={};paths=[];present=[];alreadyAbsent=[]').replace("  p=b/v['path'];m=p.lstat();", "  p=b/v['path']\n  if not p.exists():alreadyAbsent.append(v);continue\n  present.append(v);m=p.lstat();")
code=code.replace("sorted(v['path']for v in c['retire'])","sorted(v['path']for v in present)").replace("sum(v['bytes']for v in c['retire'])>254*1024*1024+c['unpackedBytes']+65536","sum(v['bytes']for v in present)>max(254*1024*1024,252*1024*1024+2621440)+c['unpackedBytes']+65536")
code=code.replace(" os.link(c['catalog'],root/'representative.json');os.link(c['additional'],root/'additional.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')", " assert sha(root/'catalog.json')==c['identity']['catalogSHA256']")
code=code.replace("['collect.py','archive-owned.py']","['collect.py','ops-profile.py']").replace("retiredOnly=c['retire']","retiredOnly=present,alreadyAbsent=alreadyAbsent").replace('size=32m','size=128m').replace('lython-b807-fixtures','lython-b808-fixtures').replace('RuntimeMaxSec=390','RuntimeMaxSec=120')
code=code.replace("fixture.mkdir();assert shutil.disk_usage(b).free>254*1024*1024","fixture.mkdir();assert shutil.disk_usage(b).free>max(254*1024*1024,252*1024*1024+2621440)")
code=code.replace('CONFIG',repr(c));ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
