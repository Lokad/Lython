from pathlib import Path
import json,shutil,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'profile';out=repo/'benchmarks/results/2026-11-15-matched-helper-attribution';out.mkdir()
for src,n in [(r/'attribution.json','attribution.json'),(r/'compiler-facts.json','compiler-facts.json'),(q/'identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(src,out/n)
with tarfile.open(out/'procedure-and-original-conditions.tar.xz','w:xz')as t:
 for p in r.iterdir():
  if p.is_file():t.add(p,arcname=p.name)
 for p in q.iterdir():
  if p.is_file()and p.name!='observations.tgz':t.add(p,arcname='profile/'+p.name)
 for n in ['Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json']:t.add(r/'local-facts'/n,arcname='facts-driver/'+n)
 for n in ['Program.cs','Inspect.csproj']:t.add(r.parent/'helper-boundaries-r410'/n,arcname='facts-driver/'+n)
decision=dict(source='2865f619/frozen55ba4c8a',sourceChange=False,measuredHypothesis='R410 matched helper gap: distinguish complete entry/body/return from useful string/dictionary work.',conclusion='Appreciable helper entry/body work, no isolated removable binding/array share. Both scopes unmirrored, five-slot native helper. Do not repeat a workspace/arena or weaken managed stack checks. Ordinary ExecuteInstructionPrefix already loops completed instructions; do not re-propose it as missing async architecture.',remainingQuestion='Can one complete call/operand representation displace both native/ordinary body-control duplication while preserving fast final slots, distinct logical admissions and real suspension, without the extra controller/clear/copy costs measured in R403/R411?',nextCriterion='Require a complete displacement/invariant design before a prototype, not additional unchanged sampling or per-opcode tweaks. No fixed percentage veto or permanent ban.',allGatesAndCleanupPassed=True,performanceClaim=False)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n');print('Saved matched CPU attribution, facts, original failed conditions and precise remaining call/operand question.')
