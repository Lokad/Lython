from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;q=r/'profile';s=(q/'launch-command.py').read_text(encoding='utf-8');a=s.index(' before=shutil.disk_usage(b).free;assert');s=s[:a]+" print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,present=present,alreadyAbsent=alreadyAbsent,unpackedBytes=c['unpackedBytes'],requiredBytes=max(254*1024*1024,252*1024*1024+2621440)+c['unpackedBytes']+65536)))\n"
(r/'headroom-remote.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);assert p.returncode==0,p.stderr
(r/'headroom.json').write_bytes(p.stdout);print(p.stdout.decode('utf-8'))
