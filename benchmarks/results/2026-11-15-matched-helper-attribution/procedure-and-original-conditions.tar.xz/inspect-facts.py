from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;d=r/'local-facts'
if not d.exists():shutil.copytree(r.parent/'helper-boundaries-r410/bin/Release/net11.0',d)
core=r.parent/'prepared-stores-r413/frozen/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='55ba4c8a24f3ae110a937f6b9b2b11179c90720a991a8f119cba1dab035fa2b2';shutil.copyfile(core,d/'Lokad.Lython.dll')
images={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()};env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';dll=next(p for p in d.glob('*.dll')if p.name=='Inspect.dll')
p=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(dll),str(r/'profile/catalog.json'),str(r/'compiler-facts.json')],capture_output=True,text=True,encoding='utf-8',env=env,timeout=30);(r/'compiler-facts.stderr').write_text(p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stderr
data=json.loads((r/'compiler-facts.json').read_text(encoding='utf-8'));assert data['coreSHA256']=='55ba4c8a24f3ae110a937f6b9b2b11179c90720a991a8f119cba1dab035fa2b2';(r/'facts-image.json').write_text(json.dumps(images,indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout)
