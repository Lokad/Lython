from pathlib import Path
import hashlib,json,shutil,zipfile

root=Path('.git/agent-worktrees/regex-050-range-adapter-20261122')
lab=Path('.git/agent-notes/review-20261031/regex-050-range-adapter-20261122')
old=lab.parent/'regex-050-frozen-boundary'
manifest=json.loads((old/'producer-candidate.json').read_text(encoding='utf-8-sig'))
assert manifest['SourceRevision'].startswith('61228b20f') and manifest['PackageVersion']=='0.5.0'
feed=lab/'feed'
feed.mkdir(exist_ok=True)
origin=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0')
for package in {p['RelativePath']:p for p in manifest['Packages']
                if p['Id'] in ('Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe')}.values():
    asset=origin/package['RelativePath']
    assert hashlib.sha256(asset.read_bytes()).hexdigest().upper()==package['PackageSha256']
    copied=shutil.copyfile(asset,feed/asset.name)
    with zipfile.ZipFile(copied) as z:
        for row in manifest['Packages']:
            if row['Id']!=package['Id']:continue
            data=z.read(f"lib/{row['TargetFramework']}/{row['Id']}.dll")
            assert hashlib.sha256(data).hexdigest().upper()==row['AssemblySha256']
            assert data==(old/'probes'/row['TargetFramework']/(row['Id']+'.dll')).read_bytes()
props=root/'Directory.Packages.props'
s=props.read_text(encoding='utf-8')
assert s.count('Include="Lokad.Utf8Regex.PythonRe" Version="0.4.0"')==1
props.write_text(s.replace('Include="Lokad.Utf8Regex.PythonRe" Version="0.4.0"',
                           'Include="Lokad.Utf8Regex.PythonRe" Version="0.5.0"'),encoding='utf-8',newline='\n')
path=root/'src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs'
s=path.read_text(encoding='utf-8')
def replace(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new,1)
replace('using System.Text;', 'using System.Buffers;\nusing System.Text;')
replace('    private const int LocaleFlag = 4;','''    private static readonly Utf8RegexPolicy CancellationOnly = new()
    {
        MatchTimeout = Timeout.InfiniteTimeSpan,
        ConstructionTimeout = Timeout.InfiniteTimeSpan,
    };

    private const int LocaleFlag = 4;''')
replace('''            var regex = Backend((Pattern: pattern, Options: backendOptions), static (state, token) =>
                Utf8PythonRegex.Compile(state.Pattern.Span, state.Options,
                Timeout.InfiniteTimeSpan, Utf8ResourcePolicy.Unlimited, Utf8ConstructionPolicy.Default,
                Timeout.InfiniteTimeSpan, token), cancellationToken, utf8Pattern: pattern);
            cancellationToken.ThrowIfCancellationRequested();
            return new Pattern(regex, EffectiveFlags(pattern.Span, options, cancellationToken), pattern.Length, owner, cancellationToken);''','''            var regex = Backend((Pattern: pattern, Options: backendOptions), static (state, token) =>
                Utf8PythonRegex.Compile(state.Pattern.Span, state.Options, CancellationOnly, token),
                cancellationToken, utf8Pattern: pattern);
            try
            {
                cancellationToken.ThrowIfCancellationRequested();
                return new Pattern(regex, EffectiveFlags(pattern.Span, options, cancellationToken), pattern.Length, owner, cancellationToken);
            }
            catch { regex.Dispose(); throw; }''')
replace('''            var names = regex.GetGroupNames();
            CaptureSlotCount = names.Length;
            var named = new List<LythonRegexNamedGroup>();
            for (var i = 0; i < names.Length; i++)
            {
                token.ThrowIfCancellationRequested();
                if (!int.TryParse(names[i], out _)) named.Add(new(Encoding.UTF8.GetBytes(names[i]), i));
            }''','''            CaptureSlotCount = checked(regex.CaptureGroupCount + 1);
            var named = new List<LythonRegexNamedGroup>();
            Span<byte> scratch = stackalloc byte[64];
            for (var i = 1; i < CaptureSlotCount; i++)
            {
                var status = regex.TryCopyGroupNameUtf8(i, scratch, out var length, token);
                if (status == OperationStatus.Done)
                {
                    // Unnamed slots use ASCII decimal indices.
                    if (scratch[0] is < (byte)'0' or > (byte)'9')
                        named.Add(new(scratch[..length].ToArray(), i));
                }
                else if (status == OperationStatus.DestinationTooSmall)
                {
                    var name = new byte[length];
                    if (regex.TryCopyGroupNameUtf8(i, name, out _, token) != OperationStatus.Done)
                        throw new InvalidOperationException("Regex group name changed during publication.");
                    named.Add(new(name, i));
                }
                else throw new InvalidOperationException("Regex group name is not valid UTF-8.");
            }''')
replace('''            // PythonRe 0.4 owns only managed objects, with no program Dispose API.
            // Drop those references and retire their existing funded scope.
            if (Interlocked.Exchange(ref _regex, null) is null) return;
            _namedGroups = null;
            _owner.Dispose();''','''            if (Interlocked.Exchange(ref _regex, null) is not { } regex) return;
            try { regex.Dispose(); }
            finally { _namedGroups = null; _owner.Dispose(); }''')
replace('        private ReadOnlyMemory<byte> BoundedInput => _input[.._window.EndByte];\n','')
replace('PythonRe 0.4 does not support Python match with pos greater than endpos.',
        'PythonRe 0.5 does not support Python match with pos greater than endpos.')
start=s.index('            var data = Backend((Regex: regex, Input: BoundedInput, _window.StartByte, Mode: mode)')
end=s.index('            if (!data.Success)',start)
s=s[:start]+'''            var backendMode = mode switch
            {
                LythonRegexMatchMode.Match => Utf8PythonMatchMode.Match,
                LythonRegexMatchMode.FullMatch => Utf8PythonMatchMode.FullMatch,
                _ => Utf8PythonMatchMode.Search,
            };
            // The one-shot range writer lacks last-close metadata.
            // Dispose this snapshot cursor before returning borrowed results.
            using var cursor = Backend((Regex: regex, Input: _input, Window: _window, Mode: backendMode),
                static (state, token) => state.Regex.CreateMatchCursor(state.Input, state.Window.StartByte,
                    token, mode: state.Mode, endOffsetInBytes: state.Window.EndByte),
                cancellationToken, patternSource: regex);
            var data = Backend(cursor, static (current, token) => current.MoveNext(out var match, token) ? match : default,
                cancellationToken, patternSource: regex);
'''+s[end:]
replace('private static void CopyCaptures(Utf8PythonDetailedMatchData data,','private static void CopyCaptures(Utf8PythonRangeMatch data,')
replace('''                        _cursor = Backend((Regex: regex, Input: subject.BoundedInput, subject._window.StartByte, Token: _cancellation.Token),
                            static (state, _) => state.Regex.CreateMatchCursor(state.Input, state.StartByte, state.Token),''','''                        _cursor = Backend((Regex: regex, Input: subject._input, Window: subject._window, Token: _cancellation.Token),
                            static (state, _) => state.Regex.CreateMatchCursor(state.Input, state.Window.StartByte,
                                state.Token, endOffsetInBytes: state.Window.EndByte),''')
replace('''                        if (Backend(cursor, static (current, _) => current.MoveNext(), token, patternSource: _subject.Pattern.Regex))
                        {
                            var data = cursor.Current;
                            CopyCaptures(data, captures, token);''','''                        var data = Backend(cursor, static (current, _) => current.MoveNext(out var match) ? match : default,
                            token, patternSource: _subject.Pattern.Regex);
                        if (data.Success)
                        {
                            CopyCaptures(data, captures, token);''')
path.write_text(s,encoding='utf-8',newline='\n')
