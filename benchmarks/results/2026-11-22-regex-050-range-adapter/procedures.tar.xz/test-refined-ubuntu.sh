#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-050-range-adapter-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-050-range-adapter-20261122
export NUGET_PACKAGES="$lab/nuget-linux"
cat > "$lab/NuGet.Ubuntu.Config" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <clear />
    <add key="producer" value="$lab/feed" />
    <add key="cached" value="$HOME/.nuget/packages" />
  </packageSources>
  <packageSourceMapping>
    <packageSource key="producer"><package pattern="Lokad.Utf8Regex*" /></packageSource>
    <packageSource key="cached"><package pattern="*" /></packageSource>
  </packageSourceMapping>
</configuration>
EOF
dotnet restore tests/Lokad.Lython.PublicApi.Tests --configfile "$lab/NuGet.Ubuntu.Config" --artifacts-path "$lab/ubuntu" > "$lab/restore-ubuntu.log" 2>&1 || { tail -30 "$lab/restore-ubuntu.log"; exit 1; }
filter='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Glob|FullyQualifiedName~Fnmatch)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-restore --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-refined-ubuntu.log" 2>&1 || { tail -45 "$lab/public-refined-ubuntu.log"; exit 1; }
tail -7 "$lab/public-refined-ubuntu.log"
