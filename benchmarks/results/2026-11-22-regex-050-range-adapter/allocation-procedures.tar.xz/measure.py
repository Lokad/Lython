from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"current-cpython-refresh-20261122"
out=lab/"allocation"
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
reference=read(prior/"identity.json")
base=prior/"frozen"
assert len(reference["imageFiles"])==32 and {n:sha(base/n) for n in reference["imageFiles"]}==reference["imageFiles"]
candidate=lab/"benchmark-windows/bin/Lokad.Lython.Benchmarks/release_net11.0"
version=read(lab/"tested-producer.json")
for backend,v in version["images"]["windows"].items():
    assert sha(candidate/(backend+".dll")).upper()==v["assemblySHA256"]
tree=repo/".git/agent-worktrees/regex-050-range-adapter-20261122"
rev=subprocess.check_output(["git","rev-parse","HEAD"],cwd=tree,text=True).strip()
assert rev.startswith("ef44cbeec") and not subprocess.check_output(
    ["git","diff",reference["sourceRevision"],rev,"--","src/Lokad.Lython","benchmarks"],cwd=repo)
catalog=lab.parent/"regex-provider-state-20261122/comparison/catalog.json"
archive=repo/"benchmarks/results/2026-11-22-regex-provider-state"
assert sha(catalog)==read(archive/"source.json")["catalogSHA256"]
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==reference["protocolSHA256"]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
core="Lokad.Lython.dll"
worker="Lokad.Lython.Benchmarks.dll"
images={}
results={}
for role,src in (("reference",base),("candidate",candidate)):
    image=out/("image-"+role)
    image.mkdir(exist_ok=True)
    for name in reference["imageFiles"]:
        shutil.copyfile((base if name==core else src)/name,image/name)
    manifest={name:sha(image/name) for name in reference["imageFiles"]}
    assert manifest[core]==reference["imageFiles"][core]
    if role=="reference":assert manifest==reference["imageFiles"]
    images[role]=manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/name,image/name)
    verify=out/(role+"-verify.json")
    subprocess.run([dotnet,image/worker,"--compare","verify","--catalog",catalog,"--dotnet",dotnet,
        "--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verify],env=env,cwd=repo,
        check=True,timeout=90)
    proof=read(verify)
    assert proof["state"]=="Completed" and proof["caseCount"]==5 and proof["catalogSha256"]==sha(catalog)
    report=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],
                   env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==5 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    assert {name:sha(image/name) for name in manifest}==manifest
    results[role]=rows
changed=[n for n in images["reference"] if images["reference"][n]!=images["candidate"][n]]
assert set(changed)=={worker,"Lokad.Lython.Benchmarks.deps.json","Lokad.Lython.Utf8Regex.dll",
                     "Lokad.Utf8Regex.dll","Lokad.Utf8Regex.PythonRe.dll"}
save(out/"identity.json",dict(referenceSource=reference["sourceRevision"],candidateSource=rev,
    imageFiles=images,catalogSHA256=sha(catalog),protocolSHA256=sha(protocol),changedFiles=changed))
for a,b in zip(results["reference"],results["candidate"],strict=True):
    assert a["id"]==b["id"]
    x,y=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    print(a["id"],x,y,round(100*(y/x-1),3),a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
