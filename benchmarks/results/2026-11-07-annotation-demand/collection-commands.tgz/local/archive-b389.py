from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');o=repo/'benchmarks/results/2026-11-07-annotation-demand';b=r/'b389'
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs']==5 and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','contract.md']:shutil.copyfile(b/name,o/name)
shutil.copyfile(r/'comparison-summary.json',o/'comparison-summary.json')
with tarfile.open(o/'collection-commands.tgz','w:gz') as t:
 for root in [r,b]:
  for p in sorted(root.iterdir()):
   if p.is_file() and p.suffix in ['.py','.sh','.json','.md']:
    t.add(p,arcname=('local/' if root==r else 'collection/')+p.name)
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
p=o/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('Quiet B389/source-pair elapsed qualification is pending at this source commit;\nfull Windows/Ubuntu/Stress/installed consumers remain separate.', '''Quiet B389 completes140.29s/all5jobs/gates on the same frozen source now committed
asb0889a46. SourceLink remains79fddd4a from the precommit build; production source
matches. Report compile elapsed−6.51–8.02%, text compile−8.25–9.13%, config
compile-to-result−0.54–2.42%. Warm text−5.46 to+1.74% has4.94%baseline role spread;
it establishes neither a warm gain nor parity. Full-flow regex compile+0.014–1.66%,
current1.23%spread, is accepted possible overhead alongside304B allocation growth.
No CPU attribution or compound source-pair debt repayment. Retain the bounded
frontend change; no unchanged retiming selected. Full delivery42351006316 on
exactb0889a46 batches R36/R38 Windows/Ubuntu/actual11/10/original Stress/installed
consumers; pending at this evidence commit.''')
s+='''

## Quiet comparison provenance

Unchanged b94fa98c worker/host and normal optional0.4; dedicated AzureF4as_v7/
Ubuntu24.04.4/.NET11RC3, normal GC/tiering. Two baseline/two current processes,
5s warmup per role/job and seven rotated150ms rounds. Compile includes program
disposal; config fresh/text warm include mediated RAM I/O, complete output/file
goldens and prior-result cleanup. Fresh adds compile/program disposal; startup,
staging/reset and final cached teardown excluded. CPU tick observations stay
separate. No CPython refresh, startup/RSS/pending-I/O or embedding-tail claim.

All Ready hashes/auxiliaries, goldens, terminal funding, quiet endpoints, Closed/
exit/joins, fixture removal and archive verification under lease pass. Independent
retrieval verifiesa347ac58. Observation07:24:24UTC follows07:24:01.727783bound
(210s owner+30s stop+40s margin). Terminal inactive/exit0/no users or fixtures;
never query the service again. A local retrieval-template assertion failed after
valid payload/launcher generation; the shell then ran that launcher. Independent
remote setup verifies all inputs before work. Correct only retrieval path selection;
do not restart the collection. Original source/condition retained.

[Controlled summary](comparison-summary.json), [all raw gates](observations.tgz),
[commands and original plan](collection-commands.tgz), [receipt](archive-receipt.json).
''';write(p,s)
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');mark='| Direct formatted instructions / dynamic-width report |';row='''| Demand-bound annotation analysis / compilation | Report compile elapsed −6.51–8.02%; text compile −8.25–9.13%; config compile-to-result −0.54–2.42% versus79fddd4a | Separate compile allocation −4.38–8.94% across five scripts. Regex control +304B/+0.117%, elapsed up to+1.66%; warm text variable. Full delivery pending; no warm CPU claim. [R38](../benchmarks/results/2026-11-07-annotation-demand/README.md) |
''';s=s.replace(mark,row+mark,1);s=s.replace('Later changes, including R36, and private development','Later changes, including R36/R38, and private development');write(p,s)
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='''

R38/B389 completes140.29s/all5gates: report compile−6.51–8.02%, text compile
−8.25–9.13%, config fresh−0.54–2.42%. Warm text−5.46 to+1.74% with4.94%
baseline spread remains inconclusive; regex compile+0.014–1.66% is accepted possible
overhead. Retain compilation simplification/allocation gain, no warm CPU/parity/
compound claim or unchanged retiming. Terminal capture archived/verified, all users
joined. Full R36/R38 delivery42351006316 onb0889a46 remains independent/pending.
''';write(p,s)
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('Quiet elapsed and full delivery remain pending.','B389 completes140.29s/all5gates: report compile−6.51–8.02%, text compile−8.25–9.13%,\n  config fresh−0.54–2.42%. Warm text inconclusive; regex up to+1.66% accepted\n  possible overhead. Retained; full delivery42351006316 onb0889a46 pending.')
s=s.replace('B389 is owned and\nactive until observed after its recorded bound. B385–B388 terminal/archived; no\nservice queries of those completed collections.','B385–B389 terminal/archived; no owned collection running or service queries of\nthose completed collections.')
s=s.replace('Quiet B389 owns its recorded210+30+40s bound until07:24:01.727783UTC;\nno early observation/restart.','B389 observed terminal after07:24:01.727783UTC, all users joined/archive verified;\nnever query it again.')
write(p,s)
print('B389 archived; retain R38 with explicit warm uncertainty and regex overhead.')
