# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completion of one experiment/checkpoint does not complete that objective.

## Actual delivery status

- **Fully qualified:** R35 exact42101cd5, terminal GREEN42347124351: Windows/
  Ubuntu Release, ordinary actual.NET11/10, original Stress both targets and
  installed-package consumers. Includes R30 class facts, R31 shared parameter
  layouts, R32 canonical parameter prefix, R33 current-token native hashing and
  the corrected5000-definition shared-layout stress contract. No repeat queries.
  R35 removes the generic formatting detour/four wrapper records; dynamic native
  specs avoid contexts, real protocols promote/await, transient values retain the
  helper lifetime fence. Focused203internal/1,141public per target plus independent
  Python/ownership checks. Full receipt and representative B388 committed dab4774b.
- **Committed/focused-qualified:** R36 root identity79fddd4a. User classes named
  object/type now retain normal attributes/instances; original builtin aliases
  stay immutable. Delete display-name root heuristics using existing graph facts,
  no new cache/flag/owner.986internal/2,765public per actual target, eight isolated
  Python goldens/both APIs, balance/reuse pass. Full platform qualification is a
  later batch; R35 receipt excludes R36. No performance claim.
- **Active frontend prototype R38:** demand-bound annotation dataflow, baseline
  79fddd4a/images preserved. No retained performance result or full qualification
  yet. R37 call transport is not selected: native slices already borrow storage;
  removing adjacent loads alone adds snapshot/span metadata without deleting it.
- **Independent regex:** immutabledev48/sourcef6b2175e passed85internal/488public
  per actual target on R30 consumer. Normal adapter remains nonpackable/pinned0.4;
  core decoupled. This is neither current-HEAD nor final producer certification.
- **History separate:** benchmarks/EXPERIMENTS.md and immutable results retain
  original failed/withdrawn sources, controls and adverse observations. R28 windows/
  mask withdrawn; slower call-arena/control lessons remain. R36 unsupported fixture
  and masked probe preserved; supported type-subclass fixture corrects the test.

## Established measurements and uncertainty

| Milestone | Established outcome | Limit / decision |
| --- | --- | --- |
| Shared compiler-fact correction | Shared inferred-value traversal fixes exponential work; qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Full qualification; allocation−19.92/−19.31% | Earlier elapsed improvements diagnostic, not current-HEAD gains. |
| Direct UTF8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retain | Original adverse15.125ms remains unexplained/preserved. |
| R20/R25 record construction | Shared keys/independent values; completed CSV arrays transferred. R25 allocation−7.31/−6.55%, native warm−7.72–8.04% | Selectively revisits old6–8% bulk rejection with coherent transfer. Coarse CPU/text controls mixed. |
| R29 completed calls | Synthetic pause/completion deleted; text warm−4.25–7.61%sync/−7.63–8.64%async vsR26 | Allocation flat; report/CSV uncertainty and prior debt remain. |
| R30–R32 shared facts/layouts | Repeated class/parameter analysis/storage removed; qualified | Class allocation/time improve; compilation storage grows. Prior moving text/CSV controls and adverse pairings remain debt. |
| R33 hashing | Current token reaches4096-byte str/bytes scans, caches do not retain callers | Short primitive allocation flat, no CPU claim. |
| R35 direct formatting | Dynamic-width complete report warm allocation~−15.35%both APIs; quiet elapsed−10.09–13.19% | Static warm favorable, fresh/text variable; CSV+0.13–2.36% accepted possible debt. Original B386/refinement retained; no broad CPU/compound claim. |

**Current representative CPython checkpoint:** B388/exact42101cd5/frozen6ab7367f,
before R36. All15jobs311.96s/all gates, source/full delivery verified. Primary
docs/BENCHMARKS.md refreshed; previous B380/source81036f25 remains immutable.
Warm CSV1.20x,text1.67–1.75x,JSON1.02–1.04x,report1.40–1.42x,config1.26x CPython.
Compile45–75us separate; fresh CSV1.23–1.30x,text1.70x,report1.34–1.41x. Most
cases variable: text4.87% warm role spread, report6.18%IQR, CSV5.20%fresh spread.
Includes mediated RAM I/O, complete checks and prior-result cleanup; fresh adds
compile/program disposal. Excludes startup/staging/reset/final cached teardown.
No median subtraction, per-change causal attribution or algebraic debt repayment.
Startup, genuinely pending I/O, heap/RSS and embedding tails remain unmeasured.

## Priority 1 — substantial execution/storage milestone

Use complete text/CSV/JSON/report/config/file scripts, including new compile-once/
run-once scripts inside a warm host. Preserve compile/warm/fresh clock boundaries;
keep mediated I/O/check/cleanup inclusion explicit. Existing profiles before new
captures; source-select actual removable work/storage, not stale review claims.

**Current evidence/source gate:** R34 report916guest samples/4.62CPU seconds,
63unknown. Formatting241inclusive/37self partly addressed by R35; JSON220inclusive/
25self and ReadJsonString50self remain. BeginPendingCall441inclusive/10self includes
useful helper execution, not demonstrated binding dominance. Earlier text-prefix
21% includes inlined work; addition~3% and calls~2% alone do not justify universal
value/frame rewrites. Existing source already has direct native calls/receiver
dispatch, final local/operand backing, lazy contexts, result forwarding, bulk casing/
split, synchronous completed JSON, direct small-number parsing and native key reuse.
R36 setup gate finds fixed functions/signatures already shared; broader type-graph
sharing needs descriptor/isolation/owner proof and current cost evidence.

| Selected design boundary | Hypothesis / displaced work to establish | Affected scripts / acceptance |
| --- | --- | --- |
| Text/operand transport, first | Resolve the remaining text-prefix cost before changing representation. Select a whole transport/publication phase if material; do not revive general windows solely from allocation shares. | Text/helpers and report; Unicode width/expansion, identity/aliases, exception/effect order, managed stack, actual suspension, current cancellation, funded input/results. |
| Per-record JSON construction | Check whether another capacity/copy/publication phase remains after shared keys and completed CSV values. Existing SetRecordItem already fills matching prefixes directly; ordinary completed parsing is synchronous. Delete a demonstrated intermediate rather than add another key cache. | JSON/report/CSV controls; duplicates/order, escaped names, nested hooks, reentry, independent values, aliases, retained capacity/replacement admission. |
| Complete calls/frames | Reuse direct operands/native returns/deferred contexts. Require evidence for a remaining binding/context/continuation phase, then replace it coherently and remove its old driver/transport. No new caller arena. | Small helpers, constructors, comprehensions, genuinely pending hooks; defaults/keywords/closures, spans, stack admission, borrows and cleanup. |
| Scoped scalar transport | Assess boxed counters with reads/publication/retirement; select a bounded representation change only after hot-work proof. No universal tagged slots from allocation shares alone. | Aggregation/indexes; exact promotion, Python identity/aliases/hash/projection, checked arithmetic and substantial-storage funding. |
| Frontend/setup | Remove an actual repeated analysis or retained representation after shared lexical/class/parameter facts. Compile cost distinct from warm; caching identical scripts is not the answer. | Config/new helper/comprehension scripts; diagnostics, shared-graph correctness, binding, cancellation/admission and isolated per-run state. |

**R37 source gate completed:** current JSON already uses synchronous completed
container loops, direct UTF8 small-number parsing and key reuse; escaped strings
use UTF8 CopyString. Shared record prefixes already fill directly. No new JSON
intermediate selected. Existing R29 same-process code/address mapping identifies
118/1,095 samples in fetch/reload/check/switch blocks, within233prefix samples;
required checks are mixed in, and this is historical, not removable CPU today.
No aggregate recapture or runtime prototype selected from these facts.

**Next concrete gate:** inspect contiguous call-operand staging with compiler
forwarding. Establish actual removable leaf instructions/copies on complete text/
helper and report scripts, distinguishing existing borrowed slices from arrays and
native expression metadata from a general argument convention. Preserve read/
callback/admission order, original dynamic binding and genuine suspension. Name the
old transport/storage to disappear before mutation; no new selector/caller arena.
If no meaningful phase survives, record that and move boundary. One bounded current
address/code capture is permitted only for a specific missing cost fact, not another
aggregate ranking. Preserve R29 mapping and all unknown/adverse observations.
Source notes: .git/agent-notes/review-20261031/operand-source-gate-r37.md.

**Selected R38 — remove irrelevant annotation dataflow:** AnnotationDiagnostics
currently constructs a second AbstractState and updates bindings through every
module/function/control-flow body even when no remaining LA1080/81/82 check can
use them. Its conservative flow differs deliberately from the main interpreter
(including dead branches), so merging the two flows would change diagnostics.
Prepare one temporary structural demand map, then retain the existing annotation
flow only through each isolated scope's last relevant check; control-flow bodies
export complete exit facts. No stored syntax flags, shared
binding state, alternate engine or public option. Delete unconditional suffix
UpdateBindings, unused state clones and completely irrelevant annotation walks.

Hypothesis: reduce compile allocation/time for all five complete scripts, especially
unannotated report/config and modules whose only checked helper precedes main work.
Warm execution is unchanged source/control, not an expected CPU gain. Accept exactly
the existing annotation diagnostics/order/spans, conservative branch joins and dead
branch checks; preserve nested defaults/returns/classes, previous shared-fact fix,
current compile cancellation/first refusal and retained regex-program ownership.
Check real-provider diagnostics as well: removed binding work must not silently
drop required constant-pattern validation. Baseline snapshots precede mutation.
Initial focused.NET11:919internal/2,012public pass, three existing missing-provider
regressions fail. The annotation pass also supplies constant-regex metadata in dead/
deferred scopes. Preserve source/images/logs and initial522/524 differential result.
Refinement: scripts importing re retain the exact full conservative flow, including
last-statement binding updates and aliases. This is semantic dependency detection,
not a regex dialect/backend switch; no independent validation pass is introduced.
Non-regex isolated scopes alone prune suffix work. Quantify regex compile overhead
as an unchanged-work control, and require all diagnostic differentials to agree.
Focused differential diagnostics + Release annotation/frontend/regex/ownership/
cancellation checks on both targets; existing complete-job compile/allocation and
one bounded quiet compile/fresh comparison with warm control. Retain original
adverse results. Finish by deleting the unconditional dataflow, evaluating debt and
batching full delivery only at a coherent boundary; no fixed percentage veto.

**Completion for a retained redesign:** old displaced route/storage removed;
focused Python/cancellation/first-refusal/alias/cleanup checks; short exact-allocation
and quiet controlled before/after observations sized to be usable. Separate
architectural deletion, allocation reduction and demonstrated CPU improvement.
Temporary regressions require a finish milestone and explicit debt disposition.
Batch full platform/Stress/package checks at a coherent retained checkpoint, then
refresh external comparison only if materially affected. Continue the roadmap.

## Experimental policy

Timeouts, unstable unchanged controls and inconclusive measurements establish
uncertainty, not permanent design rejection. Bounded confirmation, source-justified
refinement or measurement correction is permitted; never repeat until favorable.
Size runs for the existing quiet VM. Preserve all adverse observations/original
failed conditions and independently verify source/image provenance. Percentages
inform retention, not automatic vetoes of useful simplification. No compound gains
or parity claims from variable data. Completed qualification is recorded once.

## Priority 2 — independent regex architecture

Continue Lython-owned Python/nativeUTF8 semantics: byte ranges/scalar positions,
original-subject windows, captures/replacements/errors/cache ownership, current
cancellation through real work. Build on U04 caller-owned captures/R23 validated-
program reuse; no repeated unchanged qualification. Development producers and
adapter-local conversions/bridges support implementation and contract/semantic
tests. Producer publication defers only affected final adapter qualification.

Missing producer capabilities: DetailedData has no independent Prepare working
owner; native names lack enumeration; cursors mix creation/current token authority.
Exactdev48 adds no documented API removing these limits. Keep conservative
preflight/local conversion/qualified CTS bridge where needed. Qualify final released
immutable package and managed safety separately; no silent promotion, sibling
edits, dialect fallback, regex quota or abandoned background matching.

## Delivery constraints / current resources

AGENTS.md is authoritative. Fully managed/memory-safe; no unsafe/Unsafe/pointers/
PInvoke/native probing. Preserve managed stack/recursion, current cancellation,
host-mediated contained paths, cycles, coarse shared admission/preflights/overlap,
retained aliases and awaited actual-user cleanup. First memory refusal is terminal.
No tracing/weak reclamation/forced GC/fuel/quotas/caps/hidden default allowance.
Bounded host-driven streaming; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Preserve original
Stress scales/timeouts and GC nonparallel groups. Full Windows/Ubuntu/actual11/10/
original Stress/installed consumers batched at meaningful boundaries. Never query
terminal CI42347124351 or earlier terminal runs again; receipts are committed.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. No owned collection
running. B385–B388 terminal/archived; no service queries. Persistent inputs/evidence,
archive/verify RAM traces under lease before removal; record owner+stop+margin
before observation and never restart on observation timeout. Disk nearly full:
retire only exact redundant expanded files with independent committed backup,
matching hashes, ended users and checked file/directory link dependencies.
No active prototype, local tests or remote qualification. Publication postponed.
