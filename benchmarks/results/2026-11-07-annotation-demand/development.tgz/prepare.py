from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;repo=Path('D:/code/Lython');baseline=r/'baseline';baseline.mkdir(exist_ok=True)
sources=['src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs']
for name in sources:
 p=baseline/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,p)
images={}
for tfm,expected in [('net11.0','8b40e46eac9a9432b09f9435e1fd698845fc118c19ff580d85e453d8d05a361d'),('net10.0','4572bcff0f9258fb4ac196993d44c63c65b9ef766ce5e007666dee91f006ac00')]:
 p=repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll';actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected
 dest=baseline/tfm;dest.mkdir(exist_ok=True);shutil.copyfile(p,dest/p.name);images[tfm]=actual
(r/'identity-before.json').write_text(json.dumps({'source':'79fddd4a','coreSHA256':images,'sourceSHA256':{str(p.relative_to(repo)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts and 'bin' not in p.parts}},indent=2)+'\n',encoding='utf-8',newline='\n')
plan=repo/'PLAN.md';s=plan.read_text(encoding='utf-8');s=s.replace('- **No active runtime prototype.** Next: source-select one substantial milestone\n  below, preserving current source/images before mutation. No unchanged retiming.','- **Active frontend prototype R38:** demand-bound annotation dataflow, baseline\n  79fddd4a/images preserved. No retained performance result or full qualification\n  yet. R37 call transport is not selected: native slices already borrow storage;\n  removing adjacent loads alone adds snapshot/span metadata without deleting it.')
mark='**Completion for a retained redesign:**'
item='''**Selected R38 — remove irrelevant annotation dataflow:** AnnotationDiagnostics
currently constructs a second AbstractState and updates bindings through every
module/function/control-flow body even when no remaining LA1080/81/82 check can
use them. Its conservative flow differs deliberately from the main interpreter
(including dead branches), so merging the two flows would change diagnostics.
Prepare one temporary structural demand map, then retain the existing annotation
flow only through each body's last relevant check. No stored syntax flags, shared
binding state, alternate engine or public option. Delete unconditional suffix
UpdateBindings, unused state clones and completely irrelevant annotation walks.

Hypothesis: reduce compile allocation/time for all five complete scripts, especially
unannotated report/config and modules whose only checked helper precedes main work.
Warm execution is unchanged source/control, not an expected CPU gain. Accept exactly
the existing annotation diagnostics/order/spans, conservative branch joins and dead
branch checks; preserve nested defaults/returns/classes, previous shared-fact fix,
current compile cancellation/first refusal and retained regex-program ownership.
Check real-provider diagnostics as well: removed binding work must not silently
drop required constant-pattern validation. Baseline snapshots precede mutation.
Focused differential diagnostics + Release annotation/frontend/regex/ownership/
cancellation checks on both targets; existing complete-job compile/allocation and
one bounded quiet compile/fresh comparison with warm control. Retain original
adverse results. Finish by deleting the unconditional dataflow, evaluating debt and
batching full delivery only at a coherent boundary; no fixed percentage veto.

'''
s=s.replace(mark,item+mark,1);plan.write_text(s,encoding='utf-8',newline='\n')
print('R38 design recorded, baseline source/images verified and preserved.')
