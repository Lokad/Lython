using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var sources=JsonSerializer.Deserialize<string[]>(File.ReadAllText(args[2]))!;
var records=new List<object>();
using var before=new Image(args[0]);
using var candidate=new Image(args[1]);
foreach(var provider in new[]{false,true})
for(var i=0;i<sources.Length;i++)
{
    var a=before.Compile(sources[i],provider);
    var b=candidate.Compile(sources[i],provider);
    records.Add(new {source=i,provider,before=a,candidate=b,identical=a==b});
}
var output=new {purpose="Current/baseline diagnostic differential; no guest execution or performance claim",before=before.Hash,candidate=candidate.Hash,sources=sources.Length,records};
File.WriteAllText(args[3],JsonSerializer.Serialize(output,new JsonSerializerOptions{WriteIndented=true}));
var failures=records.Cast<object>().Count(x=>!(bool)x.GetType().GetProperty("identical")!.GetValue(x)!);
Console.WriteLine($"{sources.Length*2-failures}/{sources.Length*2} identical diagnostics/validity; {failures} differences");
return failures==0?0:1;

sealed class Image:IDisposable
{
    private readonly AssemblyLoadContext _context=new(Guid.NewGuid().ToString(),isCollectible:true);
    private readonly Type _engine,_budget;
    private readonly object _provider;
    private readonly MethodInfo _compile;
    public string Hash{get;}
    public Image(string directory)
    {
        directory=Path.GetFullPath(directory);
        _context.Resolving+=(context,name)=>File.Exists(Path.Combine(directory,name.Name+".dll"))?context.LoadFromAssemblyPath(Path.Combine(directory,name.Name+".dll")):null;
        var core=_context.LoadFromAssemblyPath(Path.Combine(directory,"Lokad.Lython.dll"));
        Hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core.Location)));
        _engine=core.GetType("Lokad.Lython.LythonEngine",true)!;
        _budget=core.GetType("Lokad.Lython.LythonMemoryBudget",true)!;
        _compile=_engine.GetMethod("Compile",[typeof(string),core.GetType("Lokad.Lython.ILythonMemoryBudget",true)!])!;
        var adapter=_context.LoadFromAssemblyPath(Path.Combine(directory,"Lokad.Lython.Utf8Regex.dll"));
        _provider=adapter.GetType("Lokad.Lython.Utf8Regex.Utf8RegexProvider",true)!.GetProperty("Instance")!.GetValue(null)!;
    }
    public string Compile(string source,bool provider)
    {
        var budget=Activator.CreateInstance(_budget,[ (long?)(64L*1024*1024) ])!;
        var engine=provider?Activator.CreateInstance(_engine,[_provider])!:Activator.CreateInstance(_engine)!;
        string output;
        using(var script=(IDisposable)_compile.Invoke(engine,[source,budget])!)
        {
            var valid=script.GetType().GetProperty("IsValid")!.GetValue(script);
            var diagnostics=((IEnumerable)script.GetType().GetProperty("Diagnostics")!.GetValue(script)!).Cast<object>().Select(d=>JsonSerializer.Serialize(d,d.GetType())).ToArray();
            output=JsonSerializer.Serialize(new{valid,diagnostics});
        }
        if((long)_budget.GetProperty("ReservedBytes")!.GetValue(budget)! !=0)throw new InvalidDataException("Compilation ownership leaked.");
        return output;
    }
    public void Dispose()=>_context.Unload();
}
