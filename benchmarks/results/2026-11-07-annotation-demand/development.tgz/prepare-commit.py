from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).parent;o=repo/'benchmarks/results/2026-11-07-annotation-demand';o.mkdir(exist_ok=True)
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
checks=json.loads((r/'focused-initial.json').read_text(encoding='utf-8'))
for tfm,digest in checks['coreSHA256'].items():
 p=repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll';assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
shutil.copyfile(repo/'src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs',r/'final-AnnotationDiagnostics.cs')
shutil.copyfile(repo/'tests/Lokad.Lython.PublicApi.Tests/AnnotationFlowBoundaryTests.cs',r/'final-AnnotationFlowBoundaryTests.cs')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests/Lokad.Lython.PublicApi.Tests/AnnotationFlowBoundaryTests.cs']))
with tarfile.open(o/'development.tgz','w:gz') as t:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if not p.is_file() or any(x in rel.parts for x in ['bin','obj','out','images','initial-images','baseline','b389']):continue
  if p.suffix in ['.py','.cs','.csproj','.props','.json','.log','.txt','.md','.patch']:t.add(p,arcname=str(rel))
 for tfm in ['net11.0','net10.0']:
  t.add(r/f'baseline/{tfm}/Lokad.Lython.dll',arcname=f'baseline/{tfm}/Lokad.Lython.dll')
  t.add(repo/f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll',arcname=f'candidate/{tfm}/Lokad.Lython.dll')
 t.add(r/'initial-images/candidate/Lokad.Lython.dll',arcname='initial-prototype/net11.0/Lokad.Lython.dll')
 for name in ['census.json','identity.json','catalog.json','prepare-census.py','census/Program.cs','census/census.csproj']:
  t.add(r.parent/'call-operands-r37'/name,arcname='r37/'+name)
 t.add(r.parent/'operand-source-gate-r37.md',arcname='r37/source-gate.md')
for name in ['focused-initial.json','diagnostics-final.json','summary.json']:shutil.copyfile(r/name,o/name)
write(o/'README.md','''# Annotation demand — R38

Baseline79fddd4a/core8b40e46e; candidatec21c0c4b/actual.NET11, deb66c94/.NET10,
built from that source plus the recorded frontend change. Frozen images/source
are in development.tgz. This milestone changes compilation, not runtime dispatch.

AnnotationDiagnostics formerly constructed a second binding state through every
module/function/class suffix even when no later annotation check consumed it.
One temporary structural demand map removes those unused updates/state clones and
entire irrelevant annotation walks. Control-flow bodies still export all exit facts.
Scripts importing re retain full conservative flow, including the final update:
constant-pattern analysis also needs it in dead/deferred scopes. No new public API,
policy, engine, shared binding state or retained syntax metadata. The original
conservative annotation branch/return/default/class semantics remain separate from
the main analyzer's refined/reachable flow.

Focused Release919internal/2,015public pass on each actual framework.524/524
baseline/candidate diagnostic/validity cases agree, with normal optional0.4 and no
provider roles; every compilation owner returns to zero. Six existing complete
scripts pass output/file goldens, peak/final funding, retained script cleanup,
isolated images and fixture removal across compile/warm/fresh diagnostics.

Compile allocation falls4.38–8.94% on five representative scripts. Regex full-flow
control grows304B/+0.117%; warm allocation essentially flat and admitted peaks
unchanged. These precise per-process allocation observations use shared ALCs/
CoreLib/GC; desktop clocks are diagnostic, including all adverse values. A separate
diagnostic process briefly overlaps part of fresh capture. An early summary read
finds the still-incomplete JSON; the same measurement continues to successful
terminal gates. No measurement restart or CPU claim.

Initial prototype omitted regex's conservative-analysis dependency:3 existing
missing-provider tests fail after919internal/2,012public pass;522/524 differential
cases agree. Preserve initial source/image/logs and refine the semantic demand;
do not weaken the tests or silently drop frontend validation. Private diagnostic
tool's initial nullable-unboxing compile error is corrected before observations.

R37's source/census gate finds native calls already borrow contiguous slices;
dropping adjacent loads alone retains storage and needs snapshot/span metadata.
No additional call transport or general value/frame representation is selected.
Static instruction counts are not dynamic frequencies or CPU savings.

Quiet B389/source-pair elapsed qualification is pending at this source commit;
full Windows/Ubuntu/Stress/installed consumers remain separate. R35's receipt
does not qualify this source. Publication postponed; whole-script objective active.

[Focused checks](focused-initial.json), [diagnostics](diagnostics-final.json),
[allocation/diagnostic clocks](summary.json), [source/images/all conditions](development.tgz).
''')
attr=repo/'.gitattributes';s=attr.read_text(encoding='utf-8');s+='\n# Preserve the annotation-demand source pair and diagnostic observations.\nbenchmarks/results/2026-11-07-annotation-demand/** -text whitespace=cr-at-eol\n';write(attr,s)
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','''## 0.11.0 - Unreleased

- Omit unused annotation binding analysis after the final relevant check in
  non-regex module/function/class scopes. Preserve conservative branch facts,
  nested checks and constant regex analysis in unreachable/deferred scopes.
''',1);write(p,s)
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');mark='Compilation tokenizes/parses source, validates the subset, computes scope facts,\n';insert='''Annotation diagnostics retain conservative branch facts, including unreachable
checks, independently of the main analyzer's refined flow. Non-regex lexical
scopes omit binding analysis after their final relevant annotation check. Constant
regex analysis retains its full conservative bindings across dead/deferred scopes.

''';s=s.replace(mark,insert+mark,1);write(p,s)
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='''

## R37 call-operand gate / R38 annotation demand

[R38](results/2026-11-07-annotation-demand/README.md) removes irrelevant annotation
binding suffix work while preserving full regex conservative analysis and control
exit facts.919internal/2,015public per actual target and524exact differential cases
pass; compile allocation−4.38–8.94%, regex+304B/+0.117%, warm essentially flat.
Initial3semantic failures, source/images and diagnostic desktop adverse conditions
remain explicit. Quiet elapsed and full delivery are separate/pending. R37 static
census finds native call slices already borrowed; no further transport selected.
''';write(p,s)
print('R38 source/evidence ready for a focused-qualified commit; quiet/full delivery pending.')
