from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;aux=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0');images=r/'initial-images';images.mkdir(exist_ok=True)
for role,core in [('before',r/'baseline/net11.0/Lokad.Lython.dll'),('candidate',Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'))]:
 target=images/role;target.mkdir(exist_ok=True)
 for p in aux.iterdir():
  if p.is_dir():shutil.copytree(p,target/p.name,dirs_exist_ok=True)
  elif p.suffix!='.pdb':shutil.copy2(core if p.name=='Lokad.Lython.dll' else p,target/p.name)
 assert hashlib.sha256((target/'Lokad.Lython.dll').read_bytes()).digest()==hashlib.sha256(core.read_bytes()).digest()
for name in ['focused-initial.json','focused-initial-Lokad.Lython.PublicApi.Tests-net11.0.log','build-initial.log']:
 shutil.copyfile(r/name,r/('initial-'+name))
shutil.copyfile('src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs',r/'initial-AnnotationDiagnostics.cs')
print('Initial adverse source/images and checks preserved.')
