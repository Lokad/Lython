from pathlib import Path
import json,shutil
r=Path(__file__).parent;prior=r.parent/'canonical-formatted-instructions-r35';tool=r/'tool';tool.mkdir(exist_ok=True)
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copyfile(prior/'tool'/name,tool/name)
s=(prior/'tool/Program.cs').read_text(encoding='utf-8-sig').replace('cases.Length != 4','cases.Length != 6').replace('Require static/dynamic report, text and CSV cases.','Require the existing five scripts and regex compile control.').replace('R35 canonical formatted-instruction diagnostic','R38 annotation demand diagnostic')
s=s.replace('var engine = Activator.CreateInstance(EngineType)!;','''var adapter=context.LoadFromAssemblyPath(Path.Combine(directory,"Lokad.Lython.Utf8Regex.dll"));
        var provider=adapter.GetType("Lokad.Lython.Utf8Regex.Utf8RegexProvider",true)!.GetProperty("Instance")!.GetValue(null)!;
        var engine = Activator.CreateInstance(EngineType,[provider])!;''')
(tool/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((r.parent/'call-operands-r37/catalog.json').read_text(encoding='utf-8'))
regex=json.loads((r.parent/'regex-program-artifacts-r23/comparison-catalog.json').read_text(encoding='utf-8'))
matches=[x for x in regex['cases'] if 'regex' in x['id'] or 'extract' in x['id']]
assert len(matches)==1,[x['id'] for x in regex['cases']]
catalog['cases'].append(matches[0])
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'measure.py').read_text(encoding='utf-8-sig')
s=s.replace("root/'baseline/Lokad.Lython.dll'","root/'baseline/net11.0/Lokad.Lython.dll'")
s=s.replace("root/'before.json'","root/'identity-before.json'").replace("['images']['net11.0']","['coreSHA256']['net11.0']")
s=s.replace('static/dynamic reports with unchanged text/CSV controls','five representative scripts and existing regex control')
(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8-sig')
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print('Reused six existing cases, same auxiliary images, compile/warm/fresh diagnostics.')
