from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home/'b389';root.mkdir(exist_ok=False)
old=home.parent/'canonical-formatted-instructions-r35/b386'
old_remote='/home/lokad/lython-bench-checks/canonical-format-instructions-b386-20261107'
remote='/home/lokad/lython-bench-checks/annotation-demand-b389-20261107'
checks=json.loads((home/'focused-initial.json').read_text(encoding='utf-8'))
before=json.loads((home/'identity-before.json').read_text(encoding='utf-8'))
candidate=home/'images/candidate/Lokad.Lython.dll';reference=home/'baseline/net11.0/Lokad.Lython.dll'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(candidate)==checks['coreSHA256']['net11.0']
assert sha(reference)==before['coreSHA256']['net11.0']
aux=json.loads((home.parent/'report-cost-r34/identity.json').read_text(encoding='utf-8-sig'))['auxiliaryFiles']
identity=dict(sourceRevision='79fddd4a plus R38 annotation demand; frozen'+sha(candidate),
 referenceSourceRevision='committed/focused79fddd4a; frozen'+sha(reference),
 purpose='R38 demand-bound conservative annotation flow; report/text compile, config fresh, unchanged text warm and full-flow regex compile controls; two baseline/two current',
 qualification=checks,diagnosticDifferential=dict(cases=524,identical=524,providerRoles=['normal optional0.4','missing']),
 coreSHA256=dict(candidate=sha(candidate),control=sha(candidate),reference=sha(reference),**{'reference-control':sha(reference)}),
 auxiliaryFiles=aux,modifiedSourceSHA256={'src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs':sha(Path('src/Lokad.Lython/Frontend/AnnotationDiagnostics.cs'))})
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(home/'catalog.json',root/'representative.json');shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
jobs=[('scripts.report-render.large','compile'),('scripts.text-summary-helpers.large','compile'),('scripts.config-edit.small','compile-run'),('scripts.text-summary-helpers.large','warm'),('scripts.regex-capture-summary.large','compile')]
collect=(old/'collect.py').read_text(encoding='utf-8-sig').replace(old_remote,remote)
a=collect.index('jobs=');b=collect.index('\nenv =',a)
collect=collect[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+collect[b:]
(root/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh']:(root/name).write_text((old/name).read_text(encoding='utf-8-sig').replace(old_remote,remote),encoding='utf-8',newline='\n')
contract='''R38 removes binding-state construction/updates after the final relevant annotation check in isolated non-regex module/function/class scopes. Control bodies export complete exit facts. Scripts importing re retain original full conservative flow/last updates, preserving required dead/deferred constant-pattern metadata and missing-provider diagnostics. No shared-flow rewrite, backend, public option or policy. Initial source/3 existing failures and522/524 differential retained; refined524/524 exact diagnostics/validity and919internal/2015public per actual target pass. Compile allocation-4.38..-8.94% across five maintained scripts, regex+304B/+0.117%; warm essentially flat and admitted peaks unchanged. Desktop clocks/adverse conditions remain diagnostic, including the brief separate differential process during fresh observations. Five jobs/two baseline/two current; normal .NET11RC3 GC/tiering/normal optional0.4 with frozen b94 worker/host.5s warmup per role, seven rotated150ms rounds. Compile/program disposal separate; config fresh/text warm include mediated RAM I/O/full checks/prior-result cleanup, fresh adds compile/program disposal. Startup/staging/reset/final teardown excluded. No CPU forecast, median subtraction, fixed improvement veto or whole-goal completion. All Ready/source/aux/golden/funding/quiet/Closed/joins/fixture/archive gates required.210s owner+30s stop+40s margin; observe after280s, no early query/restart. Preserve all adverse/original failed conditions. Publication deferred.'''
(root/'contract.md').write_text(contract+'\n',encoding='utf-8',newline='\n')
(root/'setup-contract.json').write_text(json.dumps(dict(referenceTemplate='/home/lokad/lython-bench-checks/delivery-comparison-b388-20261107/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=210,stopSeconds=30,observeAfterSeconds=280,jobs=jobs),indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests/Lokad.Lython.PublicApi.Tests/AnnotationFlowBoundaryTests.cs']))
for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text(encoding='utf-8'))
with tarfile.open(root/'payload.tgz','w:gz') as t:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','contract.md','pre-measurement-plan.md','setup-contract.json','source.patch']:t.add(root/name,arcname=name)
 t.add(candidate,arcname='current-core.dll');t.add(reference,arcname='baseline-core.dll')
launch=(old/'launch.py').read_text(encoding='utf-8-sig').replace('canonical-format-instructions-b386-20261107','annotation-demand-b389-20261107').replace('report-cost-b385-20261107/candidate','delivery-comparison-b388-20261107/candidate').replace('lython-b386-canonical-format-20261107','lython-b389-annotation-demand-20261107').replace('canonical-format-b386-launch.py','annotation-demand-b389-launch.py')
launch=launch.replace(" (root/'reference').symlink_to(reference,target_is_directory=True)"," shutil.copytree(reference,root/'reference',symlinks=True,copy_function=os.link)\n (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')")
assert 'symlink_to(reference' not in launch
ast.parse(launch);(root/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
retrieve=(home.parent/'canonical-formatted-instructions-r35/retrieve-b387.py').read_text(encoding='utf-8-sig')
retrieve=retrieve.replace("root=Path(__file__).parent/'b387'","root=Path(__file__).parent/'b389'").replace('canonical-format-instructions-b387-20261107','annotation-demand-b389-20261107').replace('lython-b387-canonical-format-20261107','lython-b389-annotation-demand-20261107')
assert "root=Path(__file__).parent/'b389'" in retrieve
(home/'retrieve-b389.py').write_text(retrieve,encoding='utf-8',newline='\n')
print('Prepared five existing jobs, two verified source images; no collection started.')
