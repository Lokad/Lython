# R37 source gate: no prototype selected yet

Source79fddd4a, 2026-11-07. R35 full delivery/B388 comparison closed; R36 focused
only. No new performance measurement or runtime change in this gate.

Read current JSON parsing, PyDict record construction, shared slot publication,
ForwardValues, native-call selection and ordinary argument preparation alongside
existing R29/R34 captures. Findings:

- JSON completed containers use an ordinary loop; continuations materialize only
  for actual pending hooks. Default small numbers parse UTF8 directly. Plain keys
  reuse RecordKeys; escaped strings use CopyString UTF8 before an exact final copy.
  The GetString fallback is not an ordinary per-token conversion on current input.
- SetRecordItem fills matching shared-key prefixes directly. CSV already adopts
  completed funded row storage. No new copy/capacity phase selected from that source.
- Final local/operand backing, direct result stores, safe adjacent constant/local
  forwarding, lazy frames and completed native helper calls already exist. Ordinary
  argument packets remain for dynamic calls, but selected native calls borrow the
  actual contiguous operand slice. Do not count that existing slice as a new array.
- Existing R29 same-process code/address mapping already resolves 118/1,095 guest
  samples to fetch/reload/check/switch blocks, within 233 prefix samples. Required
  cancellation/refusal checks are mixed with dispatch; these numbers are historical
  and not wholly removable CPU. Repeating aggregate ranking alone adds no fact.

Next concrete design gate: inspect contiguous call-operand staging and compiler
forwarding together. Quantify which leaf loads/copies can disappear in the complete
text/helper and report scripts without moving failable reads, callbacks, namespace
resolution or admission. NativeArgumentIndex is native-body expression metadata,
not an existing general direct-argument reference convention. Any design must retain
the original dynamic binder and genuine suspension while removing a demonstrated
transport phase, not add another native selector or caller arena. Before a prototype,
name the old instructions/storage/methods to disappear and the semantic checks.

If no meaningful removable phase survives this source test, record it and move to
the next boundary. A current address/code capture is justified only for a specific
missing cost fact; preserve existing mapping and all unknown/adverse observations.
No global type cache, universal tagged values, policy, owner or new backend selected.
