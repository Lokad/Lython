from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).parent; project=r/'census';project.mkdir(parents=True,exist_ok=True)
prior=r.parent/'compiled-operand-layout-b132/census'
shutil.copyfile(prior/'census.csproj',project/'census.csproj')
s=(prior/'Program.cs').read_text(encoding='utf-8-sig')
s=s.replace('Get(code, "NativeReturn")','Get(code, "NativeBody")')
s=s.replace('nativeNodes = (Get(code, "NativeBody") as Array)?.Length,','')
s=s.replace('operations.Add(new { op, line = Get(span, "Line") });','''
            var sites = Items(code, "CallSites");
            object? call = op == "Call" ? sites[(int)Get(instruction, "CallSiteIndex")!] : null;
            operations.Add(new { op, line = Get(span, "Line"),
                inputStart=Get(instruction,"InputStart"), resultSlot=Get(instruction,"ResultSlot"),
                secondInput=Get(instruction,"SecondInput"), liveExtent=Get(instruction,"LiveExtent"),
                localSlot=op=="LoadLocal"?Get(instruction,"LocalSlot"):null,
                constantIndex=op=="LoadConst"?Get(instruction,"ConstantIndex"):null,
                call=call is null?null:new {count=Get(call,"ArgumentCount"),
                    receiver=Get(call,"HasReceiver"),positional=Get(call,"IsPositionalOnly")}
            });''')
(project/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
catalog=r.parent/'delivery-comparison-b388/representative.json'
shutil.copyfile(catalog,r/'catalog.json')
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert hashlib.sha256(core.read_bytes()).hexdigest()=='8b40e46eac9a9432b09f9435e1fd698845fc118c19ff580d85e453d8d05a361d'
(r/'identity.json').write_text(json.dumps({'source':'79fddd4a','coreSHA256':hashlib.sha256(core.read_bytes()).hexdigest(), 'purpose':'compile-only static call operand census; not dynamic frequencies, allocation or CPU', 'catalogSHA256':hashlib.sha256(catalog.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared existing census for five current complete scripts.')
