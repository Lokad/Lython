from pathlib import Path
import json,shutil
r=Path(__file__).parent;tool=r/'diagnostics';tool.mkdir(exist_ok=True)
shutil.copyfile(r.parent/'compiled-operand-layout-b132/census/census.csproj',tool/'diagnostics.csproj')
sources=[]
for value in ["1","'bad'","None","[1,2]","{'a':1}"]:
 for annotation in ['int','str','list','dict','object']:
  sources += [f'value={value}\nresult:{annotation}=value',f'def helper()->{annotation}:\n value={value}\n return value\nx=helper()',f'def helper(value:{annotation}={value}):pass\nx=1']
  for wrapper in ["if False:\n{}", "if True:\n{}\nelse:\n pass", "for unused in []:\n{}", "while False:\n{}", "class Outer:\n{}", "try:\n{}\nfinally:\n pass", "match 1:\n case _:\n{}"]:
   body=f'value={value}\nresult:{annotation}=value';width=2 if wrapper.startswith('match') else 1
   sources.append(wrapper.format('\n'.join('    '*width+l for l in body.splitlines())))
sources += [
 "value=0\nif True:\n marker:int=1\n value='bad'\nelse:value='bad'\nresult:int=value",
 "def outer()->str:\n class Inner:\n  def number()->int:return 1\n return 'ok'\nresult=outer()",
 "def outer():\n def inner()->int:\n  value='bad'\n  return value\n return inner",
 "def outer():\n def inner(value:int='bad'):pass\n return inner",
 "import re\nvalue=re.compile('[')",
 "import re\nif False:\n value=re.compile('[')",
 "import re\nif False:\n value=re.compile('(?P<é>a)')",
 "import re\nvalue=re.compile('(?i)(?P<é>a)')\nresult:dict=value.groupindex",
 "import re\nvalue=re.compile('(?i)(?P<é>a)')\nresult:str=1",
 "from __future__ import annotations\nvalue:int='bad'",
 "def helper():pass\n"+"\n".join(f'value{i}={i}' for i in range(256)),
 "value:int=1\n"+"\n".join(f'value{i}={i}' for i in range(256)),
]
(r/'diagnostic-sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(len(sources),'deterministic diagnostic cases; provider and missing-provider roles')
