from pathlib import Path
import hashlib,json,subprocess
lab=Path(__file__).resolve().parent
old=lab.parent/'shared-bound-entry'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
put=lambda name,value:(lab/name).write_text(value,encoding='utf-8',newline='\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
catalog=load(old/'catalog.json')
cases={row['id']:row for row in catalog['cases']}
inherit=next(row for row in load(lab.parent/'ordered-class-headers/catalog.json')['cases']
    if row['id']=='scripts.dataclass-inherited-configuration.generated')
catalog['cases']=[inherit,cases['scripts.annotated-rule-closures'],cases['scripts.csv-invoice.large']]
source="""registered = []
class Component:
    def __init_subclass__(cls, source, **options):
        cls.source = source
        cls.weight = options["weight"]
def register(cls):
    registered.append((cls.source, cls.weight))
    return cls
for index in range(256):
    options = {"source": "part-" + str(index), "weight": index % 7 + 1}
    @register
    class Section(*[Component], **options):
        pass
print(len(registered), next(iter(registered))[0], next(reversed(registered))[0], sum(row[1] for row in registered))
"""
data=source.encode('utf-8')
expected=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-'],
    input=data,stdout=subprocess.PIPE,check=True).stdout.replace(b'\r\n',b'\n')
assert expected==b'256 part-0 part-255 1018\n', expected
fixture='{"size":256,"text":null}'
catalog['cases'].insert(1,dict(id='scripts.generated-component-registry',family='scripts',category='class',scale='medium',
    size=256,source=source,fixtureJson=fixture,expectedOutput=expected.decode('utf-8'),sourceUtf8Bytes=len(data),
    expectedOutputUtf8Bytes=len(expected),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=sha(data),fixtureSha256=sha(fixture.encode('utf-8')),expectedOutputSha256=sha(expected)))
assert len(catalog['cases'])==4
put('catalog.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')

s=(old/'freeze-and-verify.py').read_text(encoding='utf-8')
s=s.replace("previous=lab.parent/'ordered-class-headers'","previous=lab.parent/'shared-bound-entry'")
s=s.replace("trial=repo/'.git/agent-worktrees/shared-bound-entry'","trial=repo/'.git/agent-worktrees/direct-class-header'")
s=s.replace("ref=git('rev-parse','9bdd10a70').decode().strip()","ref=git('rev-parse','0bb3783a2').decode().strip()\nassert git('rev-parse','HEAD').decode().strip()==ref\nassert not git('status','--porcelain','--','src','tests')")
a=s.index("assert not git('diff','--name-only',prior_source,ref")
b=s.index("assert git('merge-base'",a)
s=s[:a]+"""assert set(git('diff','--name-only',prior_source,ref,'--','src','tests','Directory.Build.props','Directory.Packages.props','global.json',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','src/Lokad.Lython.Utf8Regex').decode().splitlines()) == {
    'src/Lokad.Lython/Host/ILythonRegexProvider.cs','src/Lokad.Lython/Runtime/LythonRuntime.RegexCompiler.cs',
    'tests/Lokad.Lython.PublicApi.Tests/RegexProviderContractTests.cs'}
"""+s[b:]
s=s.replace("== 5","== 4").replace('all five cases','all four cases')
s=s.replace("""        if name==core and role=='candidate':
            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
            expected[name]=sha(origin.read_bytes())""",
"""        if name==core:
            build=trial if role=='candidate' else repo
            origin=build/'src/Lokad.Lython/bin/Release/net11.0'/name
            expected[name]=sha(origin.read_bytes())
            assert expected[name]!=files[core]""")
put('freeze-and-verify.py',s)

