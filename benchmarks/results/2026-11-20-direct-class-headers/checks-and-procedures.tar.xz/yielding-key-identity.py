key = ''.join(('trace', '_label'))
class Base:
    def __init_subclass__(cls, **options):
        cls.first_label = next(iter(options))
def definition():
    class Item(Base, **(yield 'header')):
        pass
    yield Item.first_label
build = definition()
print(next(build), build.send({key: 7}) is key)
