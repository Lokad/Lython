from pathlib import Path
import hashlib, json, os, shutil, subprocess
lab=Path('.git/agent-notes/review-20261031/direct-class-header')
bin=Path('.git/agent-worktrees/direct-class-header/tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0')
ref=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
out=lab/'yielding-key-baseline-test'
assert not out.exists()
shutil.copytree(bin,out)
assets=lambda p:{f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
expected=assets(bin)
shutil.copyfile(ref,out/'Lokad.Lython.dll')
digest=hashlib.sha256(ref.read_bytes()).hexdigest()
assert expected['Lokad.Lython.dll']!=digest
assert assets(out)==expected|{'Lokad.Lython.dll':digest}
(lab/'yielding-key-baseline-test-image.json').write_text(json.dumps(assets(out),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'yielding-key-baseline.log').open('wb') as report:
    status=subprocess.run([sdk/'dotnet.exe','vstest',str(out/'Lokad.Lython.PublicApi.Tests.dll'),
        '/TestCaseFilter:FullyQualifiedName~YieldingHeaderKeepsTheOriginalExpandedKeyword'],
        env=env,stdout=report,stderr=subprocess.STDOUT,timeout=120).returncode
assert status==1
text=(lab/'yielding-key-baseline.log').read_text(encoding='utf-8-sig')
assert 'Expected: "header True' in text and 'Actual:   "header False' in text,text
print('The revised public regression observes the original keyword identity only in the candidate.')

