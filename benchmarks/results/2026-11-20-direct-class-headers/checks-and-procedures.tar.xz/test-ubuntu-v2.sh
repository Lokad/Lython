set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-class-header
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/direct-class-header
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Class|FullyQualifiedName~Dataclass|FullyQualifiedName~TypeParameter|FullyQualifiedName~Annotation|FullyQualifiedName~CompileCancellation|FullyQualifiedName~CompilationAccounting|FullyQualifiedName~Import|FullyQualifiedName~GeneratorDefinition|FullyQualifiedName~Interruption|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-v2-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Class|FullyQualifiedName~StaticFact|FullyQualifiedName~Lowering|FullyQualifiedName~StatementSyntaxTraversal|FullyQualifiedName~StackLayout|FullyQualifiedName~ManagedStackGuard)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-v2-whitebox.log"
