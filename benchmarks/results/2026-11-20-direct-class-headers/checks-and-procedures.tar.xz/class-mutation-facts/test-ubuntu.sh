set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/class-mutation-facts
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/class-mutation-facts
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Class|FullyQualifiedName~Static|FullyQualifiedName~Annotation|FullyQualifiedName~Dataclass|FullyQualifiedName~RegexProviderContract)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Static|FullyQualifiedName~Binding|FullyQualifiedName~Class)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
