using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var image = Path.GetFullPath(args[0]);
var hostType = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"))
    .GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonHost", true)!;
var host = (ILythonHost)Activator.CreateInstance(hostType, nonPublic: true)!;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[1]));
var source = catalog.RootElement.GetProperty("cases").EnumerateArray()
    .First(c => c.GetProperty("id").GetString()!.EndsWith("nested-factories.postponed"));
var budget = new LythonMemoryBudget(256L * 1024 * 1024);
var tracing = new RecordingBudget(budget);
var engine = new LythonEngine();
var rows = new List<object>();
using (var script = engine.Compile(source.GetProperty("source").GetString()!, budget))
{
    var baseline = budget.ReservedBytes;
    var expected = source.GetProperty("expectedOutput").GetString();
    var options = new LythonRunOptions { MemoryBudget = tracing };
    for (var i = 0; i < 96; i++)
    {
        using var warm = script.Run(host, new LythonRunOptions { MemoryBudget = budget });
        if (!warm.Success || warm.StandardOutput != expected) throw new InvalidDataException(warm.Failure?.Message);
    }
    if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Warm budget state differs.");
    for (var i = 0; i < 2; i++)
    {
        tracing.Counts.Clear();
        long peak;
        using (var result = script.Run(host, options))
        {
            if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                throw new InvalidDataException(result.Failure?.Message);
            peak = result.PeakExecutionMemoryBytes;
        }
        if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Budget did not return to baseline.");
        rows.Add(new { peak, growths = tracing.Counts.Values.Sum(), requests = tracing.Counts.OrderByDescending(p => p.Value).ToArray() });
    }
}
if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compile owner did not refund.");
Console.WriteLine(JsonSerializer.Serialize(new
{
    core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    rows
}));

sealed class RecordingBudget(ILythonMemoryBudget inner, Dictionary<string,int>? counts = null) : ILythonMemoryScope
{
    public Dictionary<string,int> Counts { get; } = counts ?? new();
    public ILythonMemoryScope CreateScope() => new RecordingBudget(inner.CreateScope(), Counts);

    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!inner.TryReserve(bytes, out var value))
        {
            reservation = null;
            return false;
        }
        if (bytes != 0) Track(bytes);
        reservation = new RecordingReservation(value, this);
        return true;
    }

    public void Dispose() => (inner as ILythonMemoryScope)?.Dispose();

    private void Track(long growth)
    {
        var frames = new StackTrace().GetFrames().Select(f => f.GetMethod())
            .Where(m => m?.DeclaringType?.Assembly == typeof(LythonEngine).Assembly)
            .Take(6)
            .Select(m => m!.DeclaringType!.Name + "." + m.Name);
        var key = growth + " " + string.Join(" > ", frames);
        Counts[key] = Counts.GetValueOrDefault(key) + 1;
    }

    sealed class RecordingReservation(ILythonMemoryReservation inner, RecordingBudget owner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var previous = inner.Bytes;
            if (!inner.TryResize(bytes)) return false;
            if (bytes > previous) owner.Track(bytes - previous);
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}
