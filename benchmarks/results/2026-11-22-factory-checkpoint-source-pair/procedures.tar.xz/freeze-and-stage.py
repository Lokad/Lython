from pathlib import Path
import concurrent.futures
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = lab/"comparison"
quiet = out/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
old = lab.parent/"histogram-total-slots-20261122"/"comparison"
donor = lab.parent/"retained-current-cpython-b1406"/"comparison"
core = "Lokad.Lython.dll"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def h(path): return sha(path.read_bytes())
def write(path,text):
    if path.suffix==".py": compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,value): write(path,json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def archived(dir,name):
    return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+dir+"/"+name],cwd=repo)
def original(name):
    b=lambda leaf:archived(name,leaf)
    info=json.loads(b("source.json"))
    receipt=json.loads(b("archive-receipt.json"))
    assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease"))
    assert sha(b("observations.tgz"))==receipt["archiveSHA256"]
    compiled=gzip.decompress(b("candidate-core.dll.gz"))
    manifest=info["imageFiles"]["candidate"]
    assert len(manifest)==32 and sha(compiled)==manifest[core]
    return info,manifest,compiled,receipt

before,before_files,before_core,before_receipt=original("2026-11-22-retained-source-cpython")
after,after_files,after_core,after_receipt=original("2026-11-22-current-source-cpython")
unused,retired_files,retired_core,retired_receipt=original("2026-11-22-histogram-total-slots")
assert {name for name in before_files if before_files[name]!=after_files[name]}=={core}
assert before["catalogSHA256"]==after["catalogSHA256"] and before["protocolSHA256"]==after["protocolSHA256"]
prior=donor/"quiet/representative.json"
assert h(prior)==after["catalogSHA256"]
catalog=read(prior)
cases={c["id"]:c for c in catalog["cases"]}
factory="scripts.annotated-rule-closures.nested-factories.postponed"
word="diagnostic.text-summary.nonlocal-computed-width.large"
invoice="scripts.csv-invoice.method-policy.quoted-control"
jobs=[(factory,"warm"),(factory,"compile-run"),(word,"warm"),(invoice,"warm")]
catalog["cases"]=[cases[case] for case in (factory,word,invoice)]
case_path=quiet/"representative.json"
save(case_path,catalog)
save(out/"jobs.json",jobs)
expected={"reference":before_files,"candidate":after_files}
frozen_base=old/"frozen-reference"
assert {n:h(frozen_base/n) for n in after_files}==after_files
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==after["protocolSHA256"]

def verify(role):
    files=expected[role]
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    for name in files:
        if name==core and role=="reference":(image/name).write_bytes(before_core)
        else:shutil.copyfile(frozen_base/name,image/name)
    assert {p.name:h(p) for p in image.iterdir()}==files
    proof=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",case_path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=100)
    verified=read(proof)
    assert verified["state"]=="Completed" and verified["caseCount"]==len(catalog["cases"]) and verified["catalogSha256"]==h(case_path)
    assert {p.name:h(p) for p in image.iterdir()}==files
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(verify,expected))

config=read(old/"quiet/config.json")
old_root,old_unit=config["root"],config["unit"]
root=old_root.replace("histogram-total-slots-b1411","factory-source-pair-b1412")
unit=old_unit.replace("b1411-histogram-total-slots","b1412-factory-source-pair")
identity=dict(sourceRevision=before["revision"]+" versus "+after["revision"],reference=before["revision"],
    candidate=after["revision"],imageFiles=expected,purpose="Pair the exact Lython images from B1397 and B1406",
    normalAdapterPin="0.4.0",protocolSHA256=h(protocol),coreSHA256={role+suffix:files[core]
    for role,files in expected.items() for suffix in ("","-control")},catalogs={case_path.name:{"sha256":h(case_path)}})
save(quiet/"identity.json",identity)
(quiet/"reference").mkdir(exist_ok=True)
(quiet/"reference"/core).write_bytes(before_core)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    program=(old/"quiet"/name).read_text(encoding="utf-8").replace(old_root,root).replace(old_unit,unit)
    program=program.replace("len(jobs)==6","len(jobs)==4").replace("len(raw['jobs'])==6","len(raw['jobs'])==4")
    program=program.replace("jobs=6,","jobs=4,").replace("['jobs']==6","['jobs']==4")
    if name=="collect.py":
        start,end=program.index("\njob_catalog = "),program.index("\nassert len(jobs)")
        program=program[:start]+"\njob_catalog = "+repr({c:case_path.name for c,_ in jobs})+"\njobs = "+repr(jobs)+program[end:]
        program=program.replace("started < 350","started < 245")
    write(quiet/name,program)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json",case_path.name,"collect.py","run.sh","archive-owned.py","reference/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:bundle.add(quiet/name,arcname=name)
unpacked=sum((quiet/n).stat().st_size for n in parts)
retire=[dict(paths=[str(Path(old_root).name)+"/candidate/"+core],bytes=len(retired_core),links=1,
             sha256=retired_files[core],
             archives={str(Path(old_root).name)+"/observations.tgz":retired_receipt["archiveSHA256"]})]
assert config["sourceFiles"]==after_files and config["donorArchiveSHA256"]==after_receipt["archiveSHA256"]
config.update(root=root,unit=unit,identity=identity,retireGroups=retire,
              payloadBytes=payload.stat().st_size,payloadSHA256=h(payload),unpackedBytes=unpacked)
save(quiet/"config.json",config)
launch=(old/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=launch.index("\nc=")+1,launch.index("\nb=Path(")
launch=(launch[:start]+"c="+repr(config)+launch[end:]).replace("b1411-fixtures","b1412-fixtures").replace("RuntimeMaxSec=415","RuntimeMaxSec=290")
write(quiet/"remote-launch.py",launch)
for name in ("launch.py","summarize.py"):
    program=(old/name).read_text(encoding="utf-8").replace("seconds=366","seconds=255").replace("before 366 seconds","before 255 seconds")
    program=program.replace("Histogram total slots","Factory source pair").replace("len(raw['jobs'])==6","len(raw['jobs'])==4")
    write(out/name,program)
