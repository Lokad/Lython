from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
out=lab/"comparison"
probe=lab/"reservation-probe"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
files=read(out/"quiet/identity.json")["imageFiles"]
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for role,manifest in files.items():
    source=out/("frozen-"+role)
    image=probe/role
    image.mkdir(exist_ok=True)
    assert {p:sha(source/p) for p in manifest}==manifest
    for p in manifest:shutil.copyfile(source/p,image/p)
    for name in ("Reservations.dll","Reservations.deps.json","Reservations.runtimeconfig.json"):
        shutil.copyfile(probe/"bin/Release/net11.0"/name,image/name)
    trace=out/(role+"-reservations.json")
    with trace.open("wb") as stream:
        subprocess.run([sdk/"dotnet.exe",image/"Reservations.dll",image,out/"quiet/representative.json"],
                       env=env,stdout=stream,check=True,timeout=35)
    actual=read(trace)
    assert actual["core"]==manifest["Lokad.Lython.dll"] and len(actual["rows"])==2
    assert {p:sha(image/p) for p in manifest}==manifest
    for row in actual["rows"]:
        print(role,row["peak"],row["growths"],[(r["Value"],r["Key"].split(" > ")[:4]) for r in row["requests"][:5]],flush=True)
