using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class ExecutionState
{
    // Names are immutable and already execution/result-owned. Sharing their
    // storage also shares the lazy Python hash; mutable records stay separate.
    private Dictionary<ReadOnlyMemory<byte>, PyString>? _jsonPropertyNames;

    internal PyString GetJsonPropertyName(ReadOnlyMemory<byte> bytes, LythonSourceSpan span, PyString? decoded = null)
    {
        if (_jsonPropertyNames is not null && _jsonPropertyNames.TryGetValue(bytes, out var existing))
        {
            // The decoder alone can supply an unpublished duplicate. Never
            // refund the stored key, its aliases, or borrowed input storage.
            if (decoded is not null && !ReferenceEquals(decoded, existing))
                MemoryGovernor.RefundUnpublishedValue(decoded);
            return existing;
        }

        // Coarse capacity funding includes sparse buckets/entries and old/new
        // table overlap on growth. Unique names retain this headroom until the
        // execution/result owner ends; there is no hidden cache limit or eviction.
        var charge = _jsonPropertyNames is null ? 384L : 256L;
        MemoryGovernor.Reserve(charge, span);
        try
        {
            var owned = decoded ?? PyString.CopyFromUtf8(bytes.Span, MemoryGovernor, span);
            _jsonPropertyNames ??= new(Utf8PropertyNameComparer.Instance);
            // Only independent owned bytes enter the table. The original
            // document/window is used for lookup, never retained as a table key.
            _jsonPropertyNames.Add(owned.Utf8Bytes, owned);
            MemoryGovernor.Commit(charge);
            return owned;
        }
        catch
        {
            MemoryGovernor.ReleaseReserved(charge);
            throw;
        }
    }

    private sealed class Utf8PropertyNameComparer : IEqualityComparer<ReadOnlyMemory<byte>>
    {
        internal static readonly Utf8PropertyNameComparer Instance = new();

        public bool Equals(ReadOnlyMemory<byte> left, ReadOnlyMemory<byte> right)
            => left.Span.SequenceEqual(right.Span);

        public int GetHashCode(ReadOnlyMemory<byte> value)
        {
            var hash = new HashCode();
            hash.AddBytes(value.Span);
            return hash.ToHashCode();
        }
    }
}
