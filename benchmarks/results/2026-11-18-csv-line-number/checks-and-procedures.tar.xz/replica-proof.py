from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
proofs = [{'kind': 'exact superseded compiled replica', 'canonical': 'benchmarks/results/2026-11-18-shared-trim-ownership/candidate-core.dll.gz', 'canonicalSHA256': 'a02596c0f4ab9933df77ba93f4e586e13ca7bc3260121f9e2ef71fc79e62bef7', 'member': None, 'sha256': '27cb473eae15bb8c002801a75ec48c83cb9c4304d7adaaeef49948eaeb52dc18', 'bytes': 5759488, 'anchor': 'strip-owner-b970-20261118/candidate/Lokad.Lython.dll', 'committedBlobVerified': True}]
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.run(['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode == 1
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    inodes = {}
    for proof in proofs:
        anchor = root / proof.pop('anchor')
        info = anchor.lstat()
        assert anchor.resolve() == anchor and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == proof['bytes'] and hashlib.sha256(anchor.read_bytes()).hexdigest() == proof['sha256']
        proof.update(links=info.st_nlink, paths=[])
        inodes[info.st_dev, info.st_ino] = proof
    for base, _, names in os.walk(root):
        for name in names:
            path = Path(base) / name
            info = path.lstat()
            if (proof := inodes.get((info.st_dev, info.st_ino))) is not None:
                assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                assert info.st_nlink == proof['links'] and info.st_size == proof['bytes']
                assert name == 'Lokad.Lython.dll'
                proof['paths'].append(str(path.relative_to(root)))
    for proof in proofs:
        assert len(proof['paths']) == proof['links']
        proof['paths'].sort()
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=proofs)))
