from pathlib import Path

base=Path(".git/agent-worktrees/dispatch-known-call-semantics-20261123/src/Lokad.Lython/Frontend")
def read(name):return (base/name).read_text(encoding="utf-8")
def write(name,s):(base/name).write_text(s,encoding="utf-8",newline="\n")
def once(s,old,new):
    assert s.count(old)==1, old
    return s.replace(old,new,1)

s=read("StaticContracts.KnownCalls.cs")
s=once(s,"""        // Qualified aliases enter here with their canonical target. Select its
        // owning module without allocating another string.
        var separator = targetName.IndexOf('.');
        var index = separator > 0 ? targetName.AsSpan(0, separator) switch
""","""        var index = KnownCallModule(targetName) switch
""")
s=once(s,"""        } : null;

        if (index""","""        };

        if (index""")
s=once(s,"""    public static bool TryGetKnownCallReturn(string targetName, LythonSourceSpan span, out AbstractValue value)
    {
        if (TryGetKnownCallContract(targetName, out var contract) &&
            contract.ReturnShape != StaticReturnShape.Unknown)""","""    internal static ReadOnlySpan<char> KnownCallModule(string targetName)
    {
        // Aliases use their canonical target, including nested modules such as os.path.
        var separator = targetName.IndexOf('.');
        return separator > 0 ? targetName.AsSpan(0, separator) : default;
    }

    public static bool TryGetKnownCallReturn(StaticKnownCallContract contract, LythonSourceSpan span, out AbstractValue value)
    {
        if (contract.ReturnShape != StaticReturnShape.Unknown)""")
write("StaticContracts.KnownCalls.cs",s)

s=read("StaticContractEngine.cs")
start=s.index("        if (StaticDataclassContractFamily.TryResolveKnownCallReturn")
end=s.index("    public static bool TryResolveKnownCallableTarget",start)
s=s[:start]+"""        switch (StaticContracts.KnownCallModule(targetName))
        {
            case "dataclasses" when StaticDataclassContractFamily.TryResolveKnownCallReturn(targetName, arguments, bindings, call.Span, out value):
            case "re" when StaticRegexReturnResolver.TryResolveKnownCallReturn(targetName, arguments, bindings, call.Span, out value):
            case "typing" when StaticTypingContractFamily.TryResolveKnownCallReturn(targetName, arguments, bindings, call.Span, out value):
                return true;
            default:
                return StaticContracts.TryGetKnownCallReturn(contract, call.Span, out value);
        }
    }

"""+s[end:]
start=s.index("        var emitted = false;",s.index("    private static bool AnalyzeKnownCallSemanticContract("))
end=s.index("    private static bool TryResolveDictionaryMemberCallReturn",start)
s=s[:start]+s[end:]
s=once(s,"""        AbstractState bindings)
    {
    private static bool TryResolveDictionaryMemberCallReturn""","""        AbstractState bindings)
        => StaticContracts.KnownCallModule(targetName) switch
        {
            "dataclasses" => StaticDataclassContractFamily.AnalyzeKnownCallSemanticContract(targetName, call, arguments, diagnostics, bindings),
            "json" => StaticDataModuleContractFamily.AnalyzeJsonKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "csv" => StaticDataModuleContractFamily.AnalyzeCsvKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "copy" => StaticDataModuleContractFamily.AnalyzeCopyKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "random" => StaticDataModuleContractFamily.AnalyzeRandomKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "difflib" => StaticDataModuleContractFamily.AnalyzeDifflibKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "pkgutil" => StaticDataModuleContractFamily.AnalyzePkgutilKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "re" => StaticRegexArgumentContracts.AnalyzeKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "argparse" => StaticArgparseContractFamily.AnalyzeKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "subprocess" => StaticProcessContractFamily.AnalyzeKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "pathlib" => StaticFilesystemContractFamily.AnalyzePathlibKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "os" => StaticFilesystemContractFamily.AnalyzeOsKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "shutil" => StaticFilesystemContractFamily.AnalyzeShutilKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "glob" => StaticFilesystemContractFamily.AnalyzeGlobKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "fnmatch" => StaticFilesystemContractFamily.AnalyzeFnmatchKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "math" => StaticMathContractFamily.AnalyzeKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            "statistics" => StaticStatisticsContractFamily.AnalyzeKnownCallArgumentTypes(targetName, arguments, diagnostics, bindings),
            _ => false,
        };

    private static bool TryResolveDictionaryMemberCallReturn""")
write("StaticContractEngine.cs",s)

name="StaticDataModuleContractFamily.cs"
s=read(name)
start=s.index("    public static bool AnalyzeKnownCallArgumentTypes")
signature=s[start:s.index("        if (string.Equals(targetName, LythonKnownCallableSignatures.Json.Load.Name",start)]
s=once(s,signature,signature.replace("AnalyzeKnownCallArgumentTypes","AnalyzeJsonKnownCallArgumentTypes"))
start=s.index("        if (string.Equals(targetName, LythonKnownCallableSignatures.Json.Dumps.Name")
end=s.index("        if (string.Equals(targetName, LythonKnownCallableSignatures.Csv.Reader.Name",start)
s=s[:start]+"""        return false;
    }

"""+signature.replace("AnalyzeKnownCallArgumentTypes","AnalyzeCsvKnownCallArgumentTypes")+s[end:]
start=s.index("        if (AnalyzeDifflibKnownCallArgumentTypes")
end=s.index("    public static bool TryAnalyze",start)
s=s[:start]+"""        return false;
    }

"""+s[end:]
write(name,s)
for name, parts in (("StaticDataModuleContractFamily.CopyRandom.cs",["Copy","Random"]),
                    ("StaticDataModuleContractFamily.DifflibPkgutil.cs",["Difflib","Pkgutil"])):
    s=read(name)
    for part in parts:
        s=once(s,f"private static bool Analyze{part}KnownCallArgumentTypes",f"internal static bool Analyze{part}KnownCallArgumentTypes")
    write(name,s)

name="StaticFilesystemContractFamily.cs"
s=read(name)
s=once(s,"public static bool AnalyzeKnownCallArgumentTypes","internal static bool AnalyzePathlibKnownCallArgumentTypes")
start=s.index("        var emitted = false;")
end=s.index("    private static bool IsPathlibPathConstructor",start)
s=s[:start]+"""        if (!IsPathlibPathConstructor(targetName))
        {
            return false;
        }

        var emitted = false;
        for (var i = 0; i < arguments.Positional.Count; i++)
        {
            emitted |= AnalyzePathLikeArgument(arguments, i, string.Empty, $"{targetName}([path][, ...]) expects string or Path path segments.", diagnostics, bindings);
        }

        return emitted;
    }

"""+s[end:]
for part in ("Os","Shutil","Glob","Fnmatch"):
    s=once(s,f"private static bool Analyze{part}KnownCallArgumentTypes",f"internal static bool Analyze{part}KnownCallArgumentTypes")
write(name,s)
