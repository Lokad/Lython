using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

const BindingFlags Lookup = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var engineType = assembly.GetType("Lokad.Lython.LythonEngine", throwOnError: true)!;
var compile = engineType.GetMethod("Compile", new[] { typeof(string) })!;
var engine = Activator.CreateInstance(engineType);
using var corpus = JsonDocument.Parse(File.ReadAllBytes(args[1]));

object? Property(object instance, string name) => instance.GetType().GetProperty(name, Lookup)!.GetValue(instance);
var records = new List<object>();
foreach (var probe in corpus.RootElement.EnumerateArray())
{
    var source = probe.GetProperty("source").GetString();
    using var script = (IDisposable)compile.Invoke(engine,new object?[] { source })!;
    var diagnostics = new List<object>();
    foreach (var diagnostic in (IEnumerable)Property(script,"Diagnostics")!)
    {
        var span = Property(diagnostic,"Span");
        diagnostics.Add(new
        {
            code = Property(diagnostic,"Code"),
            message = Property(diagnostic,"Message"),
            severity = Property(diagnostic,"Severity")?.ToString(),
            span = span is null ? null : new
            {
                start = Property(span,"Start"),
                length = Property(span,"Length"),
                line = Property(span,"Line"),
                column = Property(span,"Column"),
            },
        });
    }
    records.Add(new { valid = Property(script,"IsValid"), diagnostics });
}
Console.WriteLine(JsonSerializer.Serialize(records));
