from pathlib import Path
from collections import Counter
import hashlib
import json
import keyword
import os
import re
import subprocess

lab=Path(__file__).resolve().parent
previous=lab.parent/"module-known-calls-20261123"
comparison=lab/"comparison"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
write=lambda p,value:p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
snapshot=read(previous/"reference-contracts.json")
source=read(comparison/"identity.json")
repo=lab.parents[3]
source_file=repo/"src/Lokad.Lython/Frontend/StaticContracts.Modules.cs"
module_names=set(re.findall(r'^        \["([^"]+)"\] = ',source_file.read_text(encoding="utf-8"),re.M))
corpus=[]
def add(target,source):
    assert target and source
    corpus.append(dict(target=target,source=source))

for row in snapshot["signatures"]:
    if not row["visible"]:
        continue
    target=row["target"]
    parts=target.split(".")
    length=max(i for i in range(1,len(parts)) if ".".join(parts[:i]) in module_names)
    module, *attribute = (".".join(parts[:length]), *parts[length:])
    path=".".join(["_module",*attribute])
    prefix=f"import {module} as _module\n"
    positions = row["minimumArguments"]
    positional = row["maxPositional"] or row["maxArguments"]
    wrong=", ".join("None" if index%2==0 else "[]" for index in range(positions))
    add(target,prefix + path + "()\n")
    add(target,prefix + path + "(" + wrong + ")\n")
    with_value=max(1,positions)
    path=".".join(["_call", *attribute[1:]])
    prefix=f"from {module} import {attribute[0]} as _call\n"
    args = ["1" if i%2 else "{'a': 1}" for i in range(with_value)]
    if row["names"] and row["positionalOnly"]==0 and positions:
        for index, parameter in enumerate(row["names"][:positions]):
            if parameter.isidentifier() and not keyword.iskeyword(parameter):
                args[index]=parameter+"=None"
            else:
                args=["None"]*with_value
                break
    add(target,prefix + path + "(" + ", ".join(args) + ")\n")

for alias, target in snapshot["aliases"].items():
    module, member = alias.rsplit(".", 1)
    add(target,f"from {module} import {member} as _call\n_call(1, invalid_keyword=True)\n")

manual=[
("json.loads","import json as data\ndata.loads([])\n"),
("csv.reader","from csv import reader as read\nread(7)\n"),
("copy.deepcopy","from copy import deepcopy\ndeepcopy([], memo=5)\n"),
("random.randrange","import random\nrandom.randrange(1.5)\n"),
("difflib.ndiff","import difflib\ndifflib.ndiff(32, 7)\n"),
("pkgutil.get_data","import pkgutil\npkgutil.get_data([], 7)\n"),
("argparse.ArgumentParser","from argparse import ArgumentParser as Parser\nParser(add_help=7)\n"),
("subprocess.run","import subprocess\nsubprocess.run(7, check=[])\n"),
("pathlib.Path","from pathlib import Path\nPath(7)\n"),
("os.path.join","from os import path as op\nop.join(7, 8)\n"),
("shutil.copy","from shutil import copy\ncopy(7, [])\n"),
("glob.glob","from glob import glob\nglob([])\n"),
("fnmatch.fnmatch","from fnmatch import fnmatch\nfnmatch(0, [])\n"),
("math.sqrt","import math\nmath.sqrt([])\n"),
("statistics.fmean","from statistics import fmean\nfmean(7)\n"),
("dataclasses.replace","from dataclasses import dataclass, replace\n@dataclass\nclass A:\n    x: int\na=A(1)\nreplace(a,y=2)\n"),
("typing.cast","from typing import cast\nx=cast(int, 1)\nx.missing()\n"),
]
for target,text in manual:
    add(target,text)

payload=lab/"diagnostic-corpus.json"
write(payload, corpus)
assert len(corpus)==487*3+23+len(manual)
dotnet=Path.home()/".dotnet11/dotnet.exe"
driver=lab/"diagnostic-driver/bin/Release/net11.0/Diagnostics.dll"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
prior=lab.parent/"frontend-contract-sections-20261123/comparison/frozen-candidate"
assemblies={"reference":prior/"Lokad.Lython.dll","candidate":comparison/"frozen-candidate/Lokad.Lython.dll"}
records={}
for role,image in assemblies.items():
    assert hashlib.sha256(image.read_bytes()).hexdigest()==source["coreSHA256"][role]
    obtained=subprocess.run([dotnet,driver,image,payload],env=env,capture_output=True,check=True,timeout=70)
    (lab/(role+"-diagnostics.json")).write_bytes(obtained.stdout)
    records[role]=json.loads(obtained.stdout)
    assert len(records[role])==len(corpus)

mismatches=[dict(probe=probe,reference=ref,candidate=new)
    for probe,ref,new in zip(corpus,records["reference"],records["candidate"],strict=True) if ref!=new]
write(lab/"diagnostics-differences.json", mismatches)
assert not mismatches, mismatches[:3]
shapes=Counter(d["code"] for row in records["reference"] for d in row["diagnostics"])
assert len(shapes)>5 and sum(shapes.values())>500
write(lab/"diagnostic-summary.json",dict(cases=len(corpus),valid=sum(row["valid"] for row in records["reference"]),
    diagnostics=dict(sorted(shapes.items())), mismatches=0))
print((lab/"diagnostic-summary.json").read_text(encoding="utf-8"))
