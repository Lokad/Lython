from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
notes=lab.parent
manifest=json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))
driver=notes/"factory-checkpoint-source-pair-20261122/reservation-probe/bin/Release/net11.0"
catalog=json.loads((lab/"comparison/representative.json").read_text(encoding="utf-8"))
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
same=lambda image,expected:{name:hashlib.sha256((image/name).read_bytes()).hexdigest() for name in expected}==expected
results={}
for suffix, key in ((".postponed","postponed"),("","eager")):
    case=next(c.copy() for c in catalog["cases"] if c["id"]=="scripts.annotated-rule-closures.nested-factories"+suffix)
    case_id=case["id"]
    case["id"]=f"diagnostic.{key}.nested-factories.postponed"
    path=lab/(key+"-admission-catalog.json")
    path.write_text(json.dumps(dict(catalog,cases=[case]),indent=2)+"\n",encoding="utf-8",newline="\n")
    results[case_id]={}
    for role, expected in manifest["imageFiles"].items():
        image=lab/role
        assert same(image,expected)
        for name in ("Reservations.dll","Reservations.deps.json","Reservations.runtimeconfig.json"):
            shutil.copyfile(driver/name,image/name)
        result=subprocess.run([dotnet,image/"Reservations.dll",image,path],env=env,
            capture_output=True,encoding="utf-8",check=True,timeout=55)
        data=json.loads(result.stdout)
        assert not result.stderr and data["core"]==expected["Lokad.Lython.dll"] and len(data["rows"])==2
        results[case_id][role]=data
        for row in data["rows"]:
            print(key,role,row["growths"],row["peak"],[(r["Value"],r["Key"].split(" > ")[0]) for r in row["requests"][:4]])
        assert same(image,expected)
(lab/"admission.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8",newline="\n")
