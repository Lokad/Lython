set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/callable-standard-overrides
filter='Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Decorator|FullyQualifiedName~Wrap|FullyQualifiedName~Subclass|FullyQualifiedName~Dataclass)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" | tee "$logs/focused-ubuntu.log"
