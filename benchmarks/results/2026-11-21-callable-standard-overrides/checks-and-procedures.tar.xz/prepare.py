from pathlib import Path
import hashlib
import json
import subprocess


lab = Path(__file__).resolve().parent
prior = lab.parent / "factory-call-stages"
catalog = json.loads((prior / "representative.json").read_text(encoding="utf-8"))
keep = {"scripts.annotated-rule-closures", "scripts.annotated-rule-closures.nested-factories",
        "scripts.annotated-rule-closures.nested-factories.postponed", "scripts.csv-invoice.large",
        "scripts.dataclass-keyword-configuration.generated"}
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in keep]

source = """from functools import wraps

def transform(record):
    \"""Convert a record.\"""
    return record * 2

def make(offset):
    @wraps(transform)
    def invoke(record):
        return transform(record) + offset
    return invoke

total = 0
for index in range(2048):
    latest = make(index % 13)
    total += latest(index)
print(total, latest.__name__, latest.__doc__, latest.__wrapped__ is transform)
"""
result = subprocess.run(["C:/Python313/python.exe", "-I", "-X", "utf8", "-c", source],
                        check=True, capture_output=True, encoding="utf-8")
assert not result.stderr
wrapper = dict(catalog["cases"][0], id="scripts.factory-wrapper-metadata",
               source=source, expectedOutput=result.stdout)
for field in ("source", "expectedOutput"):
    data = wrapper[field].encode("utf-8")
    wrapper[field + "Utf8Bytes"] = len(data)
    wrapper[field + "Sha256"] = hashlib.sha256(data).hexdigest()
catalog["cases"].append(wrapper)
assert len(catalog["cases"]) == 6
(lab / "representative.json").write_text(json.dumps(catalog, indent=2) + "\n", encoding="utf-8", newline="\n")

script = (prior / "freeze-shared.py").read_text(encoding="utf-8")
script = script.replace('donor = lab.parent / "compiler-literal-newlines"',
                        'donor = lab.parent / "regex-program-equality"')
script = script.replace('git(repo, "rev-parse", "7e5cdd6e8")', 'git(repo, "rev-parse", "a3d0bfc34")')
script = script.replace('result["caseCount"] == 7', 'result["caseCount"] == 6')
compile(script, str(lab / "freeze.py"), "exec")
(lab / "freeze.py").write_text(script, encoding="utf-8", newline="\n")
