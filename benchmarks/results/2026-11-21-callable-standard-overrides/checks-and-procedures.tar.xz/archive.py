from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-21-callable-standard-overrides")


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


identity = load(lab / "identity.json")
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 6
    assert verification["catalogSha256"] == identity["catalogSHA256"] == sha(lab / "representative.json")
allocation = load(lab / "allocation-summary.json")
assert len(allocation) == 6 and all(row["budgetReturnedToBaseline"] for row in allocation)
for platform in ("win", "ubuntu"):
    log = (lab / f"focused-{platform}.log").read_text(encoding="utf-8-sig")
    assert any(line.strip().startswith("Passed!") and "Passed:  2006, Skipped:" in line for line in log.splitlines())

receipt = load(quiet / "archive-receipt.json")
terminal = load(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                   "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
staged = load(quiet / "identity.json")
assert staged["imageFiles"] == identity["imageFiles"] and staged["catalogSHA256"] == identity["catalogSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(lab / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 7 and len(cases) == 6
assert {(job["case"], job["lane"]) for job in raw["jobs"]} == (
    {(case, "warm") for case in cases} |
    {("scripts.annotated-rule-closures.nested-factories.postponed", "compile-run")})
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        assert response.get("actualOutputSha256") == case["expectedOutputSha256"]
        assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")

decision = load(lab / "decision.json")
summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1282", reference=identity["reference"], referenceImageSource=identity["referenceImageSource"],
               candidate=identity["candidate"], verifiedTimedBatches=196, coreSHA256=staged["coreSHA256"],
               archiveSHA256=receipt["archiveSHA256"], retentionDecision=decision["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
follow_up = lab.parent / "callable-standard-overrides-direct"
shutil.copyfile(follow_up / "allocation-summary.json", out / "direct-admission-allocation-summary.json")
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
for role in ("reference", "candidate"):
    binary = (lab / "frozen" / role / "Lokad.Lython.dll").read_bytes()
    target = out / (role + "-core.dll.gz")
    target.write_bytes(gzip.compress(binary, mtime=0))
    assert gzip.decompress(target.read_bytes()) == binary
(lab / "measured-source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", identity["reference"], identity["candidate"], "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet):
        for path in sorted(folder.iterdir()):
            if (path.is_file() and path.suffix not in {".dll", ".tgz"}
                    and path.name not in {"launch.py", "retrieve.py"}):
                archive.add(path, arcname=path.relative_to(lab).as_posix())
    for name in ("identity.json", "focused-win.log", "focused-ubuntu.log", "reference-verify.json",
                 "candidate-verify.json"):
        archive.add(follow_up / name, arcname="direct-admission/" + name)
print("196 timed batches and both complete frozen worker images verified.")
