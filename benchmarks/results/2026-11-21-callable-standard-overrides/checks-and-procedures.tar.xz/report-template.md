# B1282 standard function attribute storage

Ordinary functions read names and docstrings from their executable code
object. This prototype replaces four inline override fields with one
optional record. The first standard metadata mutation admits the record.
Later mutations reuse it. Guest-visible `__dict__` storage and the
representation of positional and keyword defaults are unchanged.

Measured November 21, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu
24.04.4 and .NET 11 RC3. The reference `a3d0bfc34` uses the exact
production-equivalent `da805131a` image. Candidate `11680b9a0` was measured.
Two independent processes per source warmed for at least eight seconds,
then contributed seven rotated batches each. Changes range over all
process-median pairings. Warm elapsed includes mediated RAM-backed I/O,
goldens and prior-result disposal. Time to result adds compilation and
code-owner disposal. CPU covers the full request. Startup and final
cleanup are outside those guest clocks.

{{results}}

Six CPython goldens pass in both complete frozen 32-file images. Windows
.NET 11 and Ubuntu .NET 10 each pass 2,006 focused Release checks. Every
local execution returns its allowance to baseline. Accounted peaks match
except on the wrapper workload, where 2,048 metadata records add 131,072
bytes. All 196 timed batches pass. Workers join, leases close and the
archive verifies with both quiet gates and fixtures removed.

{{decision}}

[Timing](summary.json) · [Allocation](allocation-summary.json)
· [Raw observations](observations.tgz)
· [Source, checks and procedures](checks-and-procedures.tar.xz).
