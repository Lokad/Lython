from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
prior = lab.parent / "factory-call-stages"
older = lab.parent / "compiler-literal-newlines"
template = prior / "quiet"
quiet = lab / "quiet"
repo = lab.parents[3]
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


index = load(lab / "identity.json")
previous = load(template / "config.json")
previous_receipt = load(template / "archive-receipt.json")
older_config = load(older / "quiet/config.json")
older_receipt = load(older / "quiet/archive-receipt.json")
for folder, receipt in ((template, previous_receipt), (older / "quiet", older_receipt)):
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert receipt["archiveSHA256"] == sha(folder / "observations.tgz")
images = index["imageFiles"]
source_files = previous["identity"]["imageFiles"]["candidate"]
assert index["reference"].startswith("a3d0bfc34") and len(source_files) == 32
assert previous["protocolSHA256"] == index["pythonWorkerSHA256"]
manifest = lab / "representative.json"
cases = load(manifest)["cases"]
postponed = next(case["id"] for case in cases if "nested-factories.postponed" in case["id"])
jobs = [(case["id"], "warm") for case in cases] + [(postponed, "compile-run")]
assert len(jobs) == 7
for role, files in images.items():
    assert [name for name in source_files if source_files[name] != files[name]] == [core]
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 6
    assert verification["catalogSha256"] == index["catalogSHA256"] == sha(manifest)

prior_name = Path(previous["root"]).name
older_name = Path(older_config["root"]).name
older_archive = older_name + "/observations.tgz"
prior_archive = prior_name + "/observations.tgz"
old_reference = previous["identity"]["imageFiles"]["reference"][core]
assert old_reference == older_config["identity"]["imageFiles"]["candidate"][core]


def retirement(paths, canonical, digest, archives):
    binary = gzip.decompress(subprocess.check_output(["git", "show", "HEAD:" + canonical], cwd=repo))
    assert hashlib.sha256(binary).hexdigest() == digest
    return dict(paths=paths, links=len(paths), bytes=len(binary), sha256=digest,
                archives=archives, verifiedCanonicalGitImage=canonical)


retire = [
    retirement([older_name + "/candidate/" + core, prior_name + "/reference/" + core],
               "benchmarks/results/2026-11-21-compiler-literal-newlines/candidate-core.dll.gz", old_reference,
               {older_archive: older_receipt["archiveSHA256"], prior_archive: previous_receipt["archiveSHA256"]}),
    retirement([prior_name + "/candidate/" + core],
               "benchmarks/results/2026-11-21-compound-function-defaults/candidate-core.dll.gz", source_files[core],
               {prior_archive: previous_receipt["archiveSHA256"]}),
]
root = "/home/lokad/lython-bench-checks/callable-standard-overrides-b1282-20261121"
unit = "lython-b1282-callable-standard-overrides-20261121"
quiet.mkdir(exist_ok=False)
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Allocate function standard attribute overrides on first mutation",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=index["catalogSHA256"],
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(template / name).replace(previous["root"], root).replace(previous["unit"], unit)
    if name == "collect.py":
        begin = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", begin)
        source = source[:begin] + "\njobs = " + repr(jobs) + source[end:]
    source = source.replace("len(jobs)==8", "len(jobs)==7").replace("len(raw['jobs'])==8", "len(raw['jobs'])==7")
    source = source.replace("jobs=8,elapsedSeconds", "jobs=7,elapsedSeconds").replace("status['receipt']['jobs']==8", "status['receipt']['jobs']==7")
    emit(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core, "reference/" + core)
for role in ("candidate", "reference"):
    (quiet / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, quiet / role / core)
shutil.copyfile(manifest, quiet / "representative.json")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=previous["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=previous["catalogSHA256"],
              donorArchiveSHA256=previous_receipt["archiveSHA256"], catalogSHA256=index["catalogSHA256"],
              retireGroups=retire, protocolSource=previous["root"] + "/cpython-worker.py",
              protocolSHA256=index["pythonWorkerSHA256"], payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload), unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
source = read(template / "remote-launch.py")
begin = source.index("\nc=") + 1
end = source.index("\nb=Path(", begin)
source = source[:begin] + "c=" + repr(config) + source[end:]
emit(quiet / "remote-launch.py", source.replace("lython-b1281-fixtures", "lython-b1282-fixtures"))
emit(lab / "launch.py", read(prior / "launch-shared.py").replace("458", "410")
     .replace("Compound defaults comparison", "Function attribute storage comparison"))
emit(lab / "summarize.py", read(prior / "summarize-shared.py").replace("len(raw['jobs'])==8", "len(raw['jobs'])==7"))
