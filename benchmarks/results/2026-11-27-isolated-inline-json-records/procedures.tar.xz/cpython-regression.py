def guest():
    import json
    first, row, other = json.loads('[{"a":1,"b":2},{"a":3,"b":4},{"a":5,"b":6}]')
    assert type(row) is dict and isinstance(row, dict) and list(dict.items(row)) == [('a', 3), ('b', 4)]
    def collect(**fields):
        return fields
    forwarded = collect(**row)
    copied = row.copy()
    assert row.pop('a') == 3
    assert list(reversed(row)) == ['b']
    row['a'] = 7
    row[8] = 'extra'
    assert list(row) == ['b', 'a', 8]
    other.clear()
    assert not other
    other['a'] = 9
    return json.dumps([first, forwarded, copied, row, other], separators=(',', ':'))
assert guest() == '[{"a":1,"b":2},{"a":3,"b":4},{"a":3,"b":4},{"b":4,"a":7,"8":"extra"},{"a":9}]'
print(guest())
