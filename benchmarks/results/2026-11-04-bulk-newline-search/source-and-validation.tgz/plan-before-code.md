# Lokad.Lython 0.11.0

Updated2026-11-04. Git-ignored; never force-add. Publication/tagging postponed.
Objective: substantial whole-script and compile-to-result improvements through
coherent simplification. Another completed experiment is not objective completion.
Main1f441cb6 (docs); runtimea00fe76d. Last fully qualified runtime97bc43b2; D6/D7 committed, focused and
measurement-qualified, with full41874093956 running. No active source prototype.

## Delivery status

| Deliverable | Actual status / evidence |
| --- | --- |
| Shared compiler facts / class-method correction | Committed/qualified61237f58/ca4822f4. Preserve class cells and global/nonlocal invalidation. |
| Native helper returns | Fully qualified; original allocation−19.92%/−19.31%, original elapsed diagnostic. Later source pairs separate, never additive. |
| Direct UTF8 formatting/storage | Qualified6e1ca104/df548ddf; allocation−8.67%, controlledB102 elapsed/CPU−5..8%. Supports retention; original adverse15.125ms remains unexplained/preserved. |
| Bulk CSV/native construction | Qualified; B150 variable-width CSV about10% faster, peak+63,648B. Original6–8%, rigid-threshold misses/adverse control preserved. |
| Native inputs/fixed UTF8/ordered bindings | QualifiedB192/B194/B197; no repeat of unchanged qualification. |
| JSON grammar/native formatting; direct list backing | Qualified48d4bf14/ffc01134 and ae9b82b7; cached41788586642/41793317194 green. Report allocation−26.12%, warm−7..12%/fresh−8..10%; list366 net lines deleted, sync-text+1.2..2.9% debt. |
| String accounting | Qualifiedbf0d38f3/frozen454cd98c; cached41807227386 green. Allocation−1.5..4.1%; sync-text+3.5..5.8% accepted debt. Window prototypes withdrawn. |
| D1 executable storage / copy correctness | Qualifiedc6ac2ae5, corrected41838965356 all eight gates green. Original41831306188 failed; retain fixes/evidence. |
| D2 call/frame / D3 storage source gates | Complete7535e07a. No substantial new general-frame/storage redesign selected; assessed mechanisms already exist. |
| D4 binding-state identity cache | Qualified123f9ff1/frozen159744bd, cached41853526333 all eight gates green. Older454 compile-debt decision complete. |
| D5 shared module facts / lexical preparation | Qualified97bc43b2/frozen0d452f95, cached41863346055 all eight gates green.57 net production lines removed; metadata exact27scripts/71code objects. |
| D6 native string truth/text EOF | Committed65e0871d/frozen7cf2623c.49 internal/241 public per actual11/10 pass. Complete1MiB scans−49..53%, line filtering−32..34%; allocation unchanged. Full delivery pending. |
| D7 shared UTF8 search windows | Committeda00fe76d/frozen1dcca6f2.59 net production lines removed; two Python bugs corrected. Focused50 internal/350 public per target plus cache/search selections pass. Full41874093956 pending. |
| Regex | Core decoupled; normal non-packable adapter0.4.0. Immutabledev.26 independently qualified; only affected final released-adapter capabilities deferred. |

All eight gates: Windows/Ubuntu actual.NET11/10 ordinary, original Stress and
installed Release consumers. Cache terminal receipts; never query/replay unchanged
qualification. History belongs in benchmarks/EXPERIMENTS.md/results and private
.git/agent-notes/review-20261031/, not docs/. Preserve original adverse/failure data.

## Active delivery checkpoint

1. Observe exact41874093956 on a00fe76d at spaced intervals; cache terminal status.
   D4/D5 are already green. Full qualification covers D6/D7 together; focused
   acceptance or an older green revision does not qualify new source.
2. B214 current CPython refresh COMPLETE328.59s: existing12-job complete-script worker,
   five representative scripts warm/fresh plus CSV/report compilation. Current
   frozen1dcca6f2 and identical control, qualifiedD5/frozen0d452f95 reference,
   CPython3.13.16. Original420sec owned bound,5sec warmups/seven rotated150ms samples.
   Preserve source/control drift, CPU/elapsed distinction, joins and quiet gates.
   Reuse tooling/catalogs; no new framework or open-ended qualification campaign.
3. docs/BENCHMARKS.md refreshed from exact validB214 bits. Separate compilation,
   warm execution, startup and included I/O/cleanup. Retain prior external table
   behind its immutable evidence link. Do not combine source-pair percentages.
4. Resolve delivery failures before additional runtime changes. Keep working on
   independent assessment while CI runs; no blocking CI waits or quota polling.
5. Resume the broader redesign roadmap below; do not call this objective complete.

## Retained design decisions and regression debt

D1 removes Push/Pop/Peek/shape transport, NativeReturnNode/type/arrays, separate
ordinary locals/temporary arrays, global compaction map/full instruction copy/
duplicate remap. Compiler facts prepare physical positions. Native provenance
uses existing16B call metadata; readonly borrowing avoids40B instruction copies.
Stride24→40B/conservative frame capacity are accepted costs. c6 preserves active
caller copy provenance after awaited hooks, stored hashes and aliases. Custom
hash/write-key equality still requires synchronous completion, including RunAsync.
Original async-report+7.84..7.89% and corrected near-baseline readonly results remain.
Evidence: benchmarks/results/2026-11-04-executable-storage/.

D4 removes structural syntax hashing, versions/wrapper from the existing state-
owned cache; mutations still clear it. D5 removes duplicate module-super traversal,
lowered-to-syntax reconstruction/nullable builder facts. Preserve module exclusion
from closure cells, later/global super shadowing and all scope boundaries.
Controlled text/report compilation improves; CSV is control-limited. Direct
qualified454 comparison: CSV near unchanged, text−5.5..5.8%, report−1.2..1.8%;
net compiler allocation+3.3..5.0% accepted for D1 storage. Original adverse results
remain, not overwritten. Evidence: results/2026-11-04-resolution-cache/ and
results/2026-11-04-module-lexical-facts/ under benchmarks/.

D6 uses logical UTF8 byte extent for truth/EOF; readlines counts only positive
hints. Scalar length/index behavior and owners unchanged.213s controlled six-case
run passes all goldens/owner/cleanup/quiet gates. Existing small text helpers
+0.9..1.4% near1.38%IQR retained as accepted uncertain debt; no broad CPU claim.
Three pre-timing newline/launch failures and untimed source correction preserved.
Evidence: benchmarks/results/2026-11-04-utf8-existence/.

D7 carries one validated byte window/validity through all search/affix methods;
scalar coordinates only when bounds/results need them. Tuple affixes reuse the
window. Remove repeated conversions/empty branches, no new dispatcher/arity/cache
family/owner. Existing cooperative checkpoint covers repeated count matches.
Correct beyond-length empty searches and invalid-start-before-end-hook effects.
Both public regressions RED on saved7cf2623c, GREEN on current.13,608 independent
CPython result/error combinations exact per API/actual11/10.207s original and119s
reversed-role confirmation both pass all semantic/identity/owner/quiet gates.
Long-line scripts−22..23%; allocation unchanged. PossibleCSVwarm+0.6..3.6% debt
accepted with control-limited magnitude. Config adverse direction reverses;
compile regression unconfirmed. Text remains variable. Stop retiming this pair;
keep every original adverse observation. B214 supplies independent current
external context, not an attempt to erase debt. Evidence:
benchmarks/results/2026-11-04-utf8-search-window/.

## Substantial redesign roadmap after delivery

Complete call/frame construction: prior source/CPU gate confirms inline argument
presence, shared bound-local/frame array, one inherited context/frame object,
lazy slot namespaces and shared empty nonlocal table already exist. Native~96B
vs conditional ordinary~640B includes branch work. Complete text profiles show
construction/binding inclusive4.5%/3.5%, prefix leaf19.9%, monitor9.1%; overlapping
samples do not prove all of this removable. No naive context merge/arena/reset
or new arity-series selected. Reopen with concrete whole-storage/transport deletion,
lifetime proof and affected complete scripts. Preserve slower arena/control/
reusable-dispatcher lessons without permanent architectural bans. Evidence:
benchmarks/results/2026-11-04-call-construction-gate/.

Operand transport: D1 is delivered. Revisit only a concrete representation deleting
more work than compiler-prepared positions already removed; avoid a second engine,
universal tagged values or a heavyweight JIT without whole-script evidence.

Per-record collections/text: direct list backing, CSV bulk fields, split-range/
batch admission, native casing, JSON plain-tokenUTF8/name reuse, small-number
parse/int64 render and destination formatting already ship. D6/D7 address actual
scalar-count cliffs. Remaining Python float/large-integer behavior is real work.
No resurrection of window/compact-payload prototypes. B196 integer trials withdrawn;
B198 owner-capacity needs a changed lifetime proof addressing229/71 failures.
Native scopes already share one gate. No broad ownership audit or collector work.

Frontend: D4/D5 delivered actual repeated-work deletions. Annotation analysis has
real effects even without annotations; do not replay B187's invalid pass skip or
merge distinct flow semantics. Assess representation/fact consumers before a new
pass/graph redesign; identical-script caching is not the main answer.

Selection gate for the next coherent redesign: use current checkpoint/profile
and one bounded affected-script source pass, not another open-ended campaign.
State eliminated work/storage, displaced code to delete, complete affected scripts,
semantic acceptance, cancellation/admission invariants and a bounded source pair
with unchanged controls. If a mechanism is already removed, update the hypothesis
and choose another justified direction. Do not manufacture dominant costs from
allocation totals. Temporary regressions require an explicit completion decision.

## D8 source gate complete; cleanup-stack redesign unselected

Four private helper families share operand storage; RetireTo scans only dropped
slots and preserves real async-disposal/failure ordering. An intrusive owner or
parallel resource array would add linkage/storage and new transfer invariants.
The aggregate prefix19.9% is not measured cleanup-scan cost. No coherent deletion
or dominant cost demonstrated; do not add a resource framework on that hypothesis.
Reopen with changed evidence, not a permanent ban. Source findings preserved in
.git/agent-notes/review-20261031/operand-cleanup-source-gate-b215/.

## D9 source/CPU gate complete; builtin redesign not selected

Assess receiver-independent method definitions using existing call/member machinery.
Actual source: five string provider instances/interface and per-receiver bound
closures coexist with direct string/list/dictionary sentinels and no-argument
delegates. Count/search callbacks also prepare error-signature text on valid calls.
Do not mistake the existing specialized paths for missing optimizations or use
ordinary-function frame4.5% as attribution for builtin construction.

Hypothesis: share immutable operation/signature definitions, carry evaluated
receiver/arguments through existing calls, and materialize bound method values only
when exposed. Target deletion: per-receiver closure/signature packaging and duplicate
provider/arity dispatch, preserving already-fast native operations. No extra arena,
new public option, universal dispatch framework or new caching/memory policy.

Current bounded gate complete:810 search/2,000CSV guest samples on exact1dcca6f2,
all loaded identities/goldens/joins/quiet gates pass. ReadLine29.51% of search
leaves; native binding1.60% is visible, not a dominant generic-method proof.
CSV prefix11.60%, parserFeed7.30%, readerNextAsync6.15%. Inlining/unknowns limit
attribution. Do not introduce a descriptor framework or arity series now; retain
source lessons for a coherent later redesign. Evidence:
benchmarks/results/2026-11-04-builtin-method-source-gate/.

## D10 active: shared managed bulk newline search

Measured hypothesis: ReadLine contains29.5% of long-line guest leaf samples; source
shows its shared TextLineScanning helper branches on each byte/mode. That is not
proof that all29.5% is removable. Replace the existing scan with managed Span
IndexOf/IndexOfAny/sequence search, selecting newline mode once. Delete per-byte
mode branches; no new owner, cache, counter, opcode or representation.

Target complete long-line file filter plus existing short-line CSV/text controls;
shared text/gzip/ZIP consumers retain the same byte-offset contract. Preserve LF,
CR, CRLF, universal modes, trailing CR/window-edge joins, size-limited scalar
reads, empty/NUL/Unicode, actual suspension, cancellation checks, refusal and
retained file/result funding. Existing caller checks/chunk bounds stay intact.
Before timing: focused native/public newline/text/gzip/ZIP boundary/lifetime tests
on actual11/10; add a semantic case only for a demonstrated coverage gap. One short
controlled whole-script source pair on exact bits, unchanged controls and CPython
goldens; compile separate. Decide adverse results explicitly. No broad CPU claim
or automatic credit for the full inlined ReadLine sample share.

## Independent regex track

Continue Lython-owned Python-specific nativeUTF8 semantics across frontend/runtime/
imports: byte ranges/scalar positions, original-subject windows, effective flags,
captures/names/errors, explicit ownership/current tokens. Core has no backend edge.
No universal framework, silent dialect fallback, prior cached token or abandoned work.

Immutabledev.26/producer e731a452 independently qualified on123f9ff1:84 internal/
421 public per actual11/10, including6 lifetime and3 actual compile/match/cursor
cancellation subprocess cases per target. Exact package/DLL/core identities verified.
Main-class143 reflected members unchanged vsdev20 is not whole-producer API/safety/
performance certification. Normal0.4.0 pin unchanged; do not repeat unchanged checks.
Evidence: benchmarks/results/2026-11-04-adapter-dev26/.

Precisely remaining producer capabilities: nativeUTF8 name enumeration; one-shot
byte ranges with working-funding receipts; reversed match windows. Development
producers/adapter-local bridges may support independent implementation and semantic
contract tests. Missing published APIs defer only affected final released-adapter
qualification. Contract correctness and actual backend performance are distinct.

## Measurement policy / lasting constraints

Current external table describesa00fe76d/frozen1dcca6f2 on2026-11-04:
CPython3.13.16/.NET11RC3, quiet AzureF4as_v7/Ubuntu24.04.4. FreshCSV/JSON/text/
report/config1.46/1.25/2.45/1.70/1.09; warm1.49/1.28/2.52/1.70/1.05.
SeparateCSV/report compile1.48×. Report remains variable; text/report gaps remain.
All12jobs328.59s, exact loaded cores/goldens/quiet gates/joins pass. Initial old-
core identity failure from executable symlinks caught BEFORE timing, preserved;
corrected application directories verified before capture. D6/D7 explicitALC
identity-qualified data unaffected. Net D6/D7 vs qualifiedD5 does not erase isolated
adverse debt. Evidence: benchmarks/results/2026-11-04-utf8-runtime-cpython-checkpoint/.
Includes invocation, mediatedRAMI/O, fullchecks/prior-result cleanup; fresh adds
compilation/disposal. Excludes startup/staging/reset/hash/final cached teardown.
All users joined. No CPU/RSS/embedding-latency guarantee. CPython primary baseline.

Timeout/unstable unchanged control/inconclusive data means uncertainty, not failed
design. Allow bounded justified confirmation/refinement/correction; preserve original
adverse/failed conditions. No fixed-percent veto or permanent one-attempt closure.
Distinguish simplification, allocation, elapsed observations and demonstrated CPU.
Size usable runs on existing VM; persistent evidence separate from RAM fixtures.
VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem. Check available disk first.

Focused Release during iteration; actual11/10 affected checks and full Windows/
Ubuntu/original Stress/installed consumers batched at delivery. Nonincremental
rebuild after timestamp-preserved restore; exact source/binary identity. UTF8 text/
JSON explicitly, LF for remote scripts/fixtures. Cache terminal CI, live polls minutes
apart. No new benchmark framework, publication, tag or adapter package.

Fully managed/memory-safe/host-mediated: no unsafe compilation/C#/Unsafe APIs,
pointers/PInvoke/native probing. Preserve managed stack admission/cycle checks.
CancellationToken sole time authority; no fuel/quotas/watchdogs. Shared allowance
funds coarse capacity/replacement overlap/retained aliases/results/caches/pending
users through awaited cleanup. No independent caps/hidden allowances, tracing,
weak reclamation/forcedGC. First refused admission terminates guest work even
through suppression/finally; native cleanup/refunds remain available and awaited.
