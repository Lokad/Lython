from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.parent/"retained-current-cpython-b1406/comparison"
comp=lab/"comparison"
quiet=comp/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(p):return sha(p.read_bytes())
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,value):write(p,json.dumps(value,indent=2)+"\n")
def committed(folder,leaf):
    return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+folder+"/"+leaf],cwd=repo)
def verified_archive(folder):
    raw=committed(folder,"observations.tgz")
    receipt=json.loads(committed(folder,"archive-receipt.json"))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(raw)==receipt["archiveSHA256"]
    return raw,receipt["archiveSHA256"]

info=read(lab/"identity.json")
assert info["sourceRevision"].startswith("6ac96ea93") and h(lab/"verify.json")==info["verificationSHA256"]
assert read(lab/"verify.json")["caseCount"]==6 and len(info["imageFiles"])==32
assert {p.name:h(p) for p in (lab/"frozen").iterdir()}==info["imageFiles"]
old=read(base/"quiet/config.json")
role="candidate"
old_image=old["identity"]["imageFiles"][role]
new=info["imageFiles"]
assert old_image.keys()==new.keys()
differences=[n for n,d in new.items() if old_image[n]!=d]
assert set(differences)=={core,"Lokad.Lython.Benchmarks.dll","Lokad.Lython.Utf8Regex.dll"}
print("Updated frozen files",differences,flush=True)
root=old["root"].replace("b1406","b1419")
unit=old["unit"].replace("b1406","b1419")
identity=dict(sourceRevision=info["sourceRevision"],candidate=info["sourceRevision"],
    purpose="Refresh six full scripts on current Lython against CPython 3.13.16",
    normalAdapterPin="0.4.0",imageFiles={role:new},coreSHA256={e:new[core] for e in (role,"candidate-control")},
    cpythonWorkerSHA256=info["protocolSHA256"],protocolSHA256=info["protocolSHA256"],
    auxiliaryFiles={n:d for n,d in new.items() if n!=core},
    catalogs={"representative.json":{"sha256":info["catalogSHA256"]}})
save(quiet/"identity.json",identity)
shutil.copyfile(lab/"representative.json",quiet/"representative.json")
assert h(quiet/"representative.json")==info["catalogSHA256"]
(quiet/role).mkdir(exist_ok=True)
for leaf in differences:shutil.copyfile(lab/"frozen"/leaf,quiet/role/leaf)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(base/"quiet"/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1406","B1419")
    write(quiet/name,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py",*[role+"/"+n for n in differences])
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for n in parts:t.add(quiet/n,arcname=n)

old_raw,old_archive_sha=verified_archive("2026-11-22-current-source-cpython")
with tarfile.open(fileobj=io.BytesIO(old_raw)) as t:
    assert t.extractfile("representative.json").read()==(lab/"representative.json").read_bytes()
previous_raw,_=verified_archive("2026-11-20-native-dict-item-cursor")
with tarfile.open(fileobj=io.BytesIO(previous_raw)) as t:
    custody=json.load(t.extractfile("identity.json"))["imageFiles"]["reference"]
original=lab.parent/"native-dict-item-cursor/frozen/reference"
assert len(custody)==32 and {n:h(original/n) for n in custody}==custody
retire=[dict(paths=["native-dict-item-cursor-b1251-20261120/reference/"+core],bytes=(original/core).stat().st_size,
             links=1,sha256=custody[core],archives={})]
for folder,remote in [
    ("2026-11-22-factory-worker-spread","factory-worker-spread-b1414-20261122"),
    ("2026-11-22-function-diagnostic-identity/confirmation","function-diagnostic-identity-b1418-20261122")]:
    raw,digest=verified_archive(folder)
    retire.append(dict(paths=[remote+"/observations.tgz"],bytes=len(raw),links=1,sha256=digest,
                       archives={},optional=True))
cfg={**old,"root":root,"unit":unit,"identity":identity,"source":old["root"],"sourceRole":role,"sourceFiles":old_image,
     "sourceCatalogSHA256":info["catalogSHA256"],"donorArchiveSHA256":old_archive_sha,
     "retireGroups":retire,"payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),
     "unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(base/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
write(quiet/"remote-launch.py",(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1406-fixtures","b1419-fixtures"))
write(comp/"launch.py",(base/"launch.py").read_text(encoding="utf-8").replace("B1406","B1419"))
print(root,cfg["unpackedBytes"],flush=True)
