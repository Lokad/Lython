from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=repo/"benchmarks/results/2026-11-22-current-source-cpython"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
revision=(lab/"revision.txt").read_text(encoding="utf-8-sig").strip()
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert revision==head and revision.startswith("6ac96ea93")
config=read(previous/"source.json")
receipt=read(previous/"archive-receipt.json")
archive=previous/"observations.tgz"
assert receipt["complete"] and sha(archive)==receipt["archiveSHA256"]
with tarfile.open(archive) as bundle:
    names=bundle.getnames()
    assert "representative.json" in names
    catalog=bundle.extractfile("representative.json").read()
cases=json.loads(catalog)
assert len(cases["cases"])==6
published=lab/"representative.json"
published.write_bytes(catalog)
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==config["protocolSHA256"]
old=next(iter(config["imageFiles"].values()))
assert len(old)==32
worker="Lokad.Lython.Benchmarks.dll"
build=lab/"build/bin/Lokad.Lython.Benchmarks/release_net11.0"
image=lab/"frozen"
image.mkdir(exist_ok=True)
manifest={}
for name in old:
    shutil.copyfile(build/name,image/name)
    manifest[name]=sha(image/name)
    assert manifest[name]==sha(build/name)
assert {p.name:sha(p) for p in image.iterdir()}==manifest
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
out=lab/"verify.json"
subprocess.run([dotnet,image/worker,"--compare","verify","--catalog",published,"--dotnet",dotnet,
    "--python","C:/Python313/python.exe","--python-worker",protocol,"--out",out],cwd=repo,env=env,check=True,timeout=105)
verified=read(out)
assert verified["state"]=="Completed" and verified["caseCount"]==6 and verified["catalogSha256"]==sha(published)
assert {p.name:sha(p) for p in image.iterdir()}==manifest
(lab/"identity.json").write_text(json.dumps(dict(sourceRevision=revision,
    inheritedCatalogFrom="55424591f", catalogSHA256=sha(published), protocolSHA256=sha(protocol),
    imageFiles=manifest, verificationSHA256=sha(out)),indent=2)+"\n",encoding="utf-8",newline="\n")
print("Current image",revision,"verified",verified["caseCount"],"goldens",flush=True)
