from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from statistics import median, quantiles
import json
import tarfile

root = Path(__file__).resolve().parent
pair = root / 'comparison/quiet'
repo = root.parents[3]
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2)+'\n',encoding='utf-8',newline='\n')
assert (pair/'exit-code.txt').read_text().strip()=='0'
identity=read(pair/'identity.json')
cases={case['id']:case for case in read(pair/'representative.json')['cases']}
receipt=read(pair/'archive-receipt.json')
archive=pair/'observations.tar.xz'
assert digest(archive)==receipt['archiveSHA256']
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==4
assert not read(pair/'terminal-status.json')['fixtures']
stage=read(pair/'stage-custody.json')
assert stage['reused']=={'donor':60,'paired':1} and stage['streamed']
for role, files in identity['imageFiles'].items():
    for platform in ('remote','local'):
        proof=read(pair/f'{role}-{platform}-verify.json')
        assert proof['state']=='Completed' and proof['caseCount']==4
        assert proof['launched']['library']['sha256']==identity['coreSHA256'][role]
        assert proof['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
        if platform=='remote':
            assert proof['launched']['python']['sha256']==identity['expectedCPythonSHA256']
        assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile('confirmation/confirmation.json'))
    before=json.load(bundle.extractfile('confirmation/machine-before.json'))
    after=json.load(bundle.extractfile('confirmation/machine-after.json'))
    assert before['gate']['quiet'] and after['gate']['quiet'] and raw['complete']
    assert json.load(bundle.extractfile('identity.json'))==identity
    jobs=json.load(bundle.extractfile('jobs.json'))['warm']
    for name, expected in identity['catalogs'].items():
        assert sha256(bundle.extractfile(name).read()).hexdigest()==expected['sha256']

summary=dict(sourceRevision=identity['sourceRevision'],candidateRevision=identity['checkedCandidate'],
    measurementQualified=True, collectionSeconds=raw['elapsedSeconds'], rows=[])
for job,(case_id,lane) in zip(raw['jobs'],jobs,strict=True):
    assert job['case']==case_id and job['lane']==lane and job['workersJoinedAndFixturesRemoved']
    case=cases[case_id]
    elapsed={}
    cpu={}
    iqr=[]
    for label,worker in job['identities'].items():
        role='candidate' if label.startswith('candidate') else 'reference'
        libraries={Path(entry['path']).name:entry['sha256'].lower() for entry in worker['libraries']}
        assert libraries['Lokad.Lython.dll']==identity['coreSHA256'][label]
        assert libraries['Lokad.Lython.Benchmarks.dll']==identity['imageFiles'][role]['Lokad.Lython.Benchmarks.dll']
        samples=[entry for entry in job['samples'] if entry['engine']==label]
        assert len(samples)==7 and {entry['round'] for entry in samples}==set(range(7))
        times=[]
        active=[]
        for entry in samples:
            result=entry['response']
            count=result['completedInvocations']
            assert result['status']=='Completed' and count>0
            assert all(result[key]==case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'))
            assert result['actualOutputSha256']==case['expectedOutputSha256']
            assert result['actualFilesSha256']==case['expectedFilesSha256']
            times.append(1000*result['elapsedTicks']/result['clockFrequency']/count)
            active.append(1000*entry['externalProcessCpuTicks']/entry['externalCpuFrequency']/count)
        elapsed[label]=median(times)
        cpu[label]=median(active)
        q=quantiles(times,n=4,method='inclusive')
        iqr.append((q[2]-q[0])*100/elapsed[label])
    def change(data):
        pairs=[100*(data[new]/data[old]-1) for new in ('candidate','candidate-control')
               for old in ('reference','reference-control')]
        return [min(pairs),max(pairs)]
    def spread(data,role):
        a,b=sorted([data[role],data[role+'-control']])
        return 100*(b/a-1)
    row=dict(case=case_id,lane=lane,elapsedMilliseconds=elapsed,cpuMilliseconds=cpu,
        elapsedChangePercent=change(elapsed),cpuChangePercent=change(cpu),
        elapsedSpreadsPercent={r:spread(elapsed,r) for r in ('reference','candidate')},
        cpuSpreadsPercent={r:spread(cpu,r) for r in ('reference','candidate')},
        maximumElapsedIqrPercent=max(iqr))
    summary['rows'].append(row)
    print(case_id,lane,'elapsed',*[f'{v:.2f}' for v in row['elapsedChangePercent']],
        'CPU',*[f'{v:.2f}' for v in row['cpuChangePercent']],
        'elapsed spreads',row['elapsedSpreadsPercent'],'CPU spreads',row['cpuSpreadsPercent'])
summary['verifiedTimedBatches']=sum(len(job['samples']) for job in raw['jobs'])
assert summary['verifiedTimedBatches']==112
out=repo/'benchmarks/results/2026-11-27-generator-outer-quiet'
out.mkdir(exist_ok=True)
write(out/'summary.json',summary)
for name in ('identity.json','archive-receipt.json','observations.tar.xz','stage-custody.json','terminal-status.json'):
    copyfile(pair/name,out/name)
files=[root/name for name in ('prepare.py','quiet-vm.py','archive.py','prepare.log')]
files.extend(pair/name for name in ('upload.json','exit-code.txt','launch.log',
    'reference-local-verify.json','candidate-local-verify.json','reference-remote-verify.json','candidate-remote-verify.json'))
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for file in files: bundle.add(file,arcname=file.relative_to(root))
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(bundle.extractfile(file.relative_to(root).as_posix()).read()==file.read_bytes() for file in files)
