from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
baseline = notes/'direct-generator-outer-20261127/comparison'
donor = notes/'regex-released-050-20261127/comparison/quiet'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')

identity = read(baseline/'identity.json')
base = identity['productionReference']
candidate = subprocess.check_output(['git','rev-parse','af9558316'],cwd=repo,text=True).strip()
patch = subprocess.check_output(['git','diff','--binary',base,candidate,'--','src'],cwd=repo)
assert sha256(patch).hexdigest() == identity['sourcePatchSHA256']
identity.update(checkedCandidate=candidate,
    purpose='Quiet confirmation of B1893 generator-expression ownership and sync CPU debt on its exact images.')
images = identity['imageFiles']
for role, files in images.items():
    assert len(files) == 32 and {p.name:digest(p) for p in (baseline/role).iterdir()} == files
assert [name for name,d in images['candidate'].items() if d != images['reference'][name]] == ['Lokad.Lython.dll']
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile((donor if name == 'run.sh' else baseline)/name,quiet/name)
assert digest(quiet/'representative.json') == identity['catalogs']['representative.json']['sha256']
assert digest(quiet/'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet/'run.sh').read_bytes()
target='diagnostic.shipment-row-generator-reduction'
control='diagnostic.shipment-file-fed-map'
write(quiet/'jobs.json',{'warm': [[target,'warm'],[control,'warm'],[target,'warm-async'],[control,'warm-async']]})
identity['catalogs']['jobs.json']['sha256'] = digest(quiet/'jobs.json')
receipt = read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['allWorkersJoined']
assert receipt['archiveSHA256'] == digest(donor/'observations.tar.xz')
identity['donorArchiveSHA256'] = receipt['archiveSHA256']
donor_files = read(donor/'identity.json')['imageFiles']['candidate']
assert len(donor_files) == 32
write(quiet/'identity.json',identity)

collector = (donor/'collect.py').read_text(encoding='utf-8')
collector = collector.replace('lython-regex-release-20261127-fixtures','lython-b1895-generator-outer-fixtures')
collector = collector.replace('targetBatchSeconds=.44', 'targetBatchSeconds=.63')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')

payload_paths = {name: quiet/name for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py')}
for role, files in images.items():
    for name, checksum in files.items():
        if donor_files[name] == checksum:
            continue
        if role == 'reference' and images['candidate'][name] == checksum:
            continue
        payload_paths[f'{role}/{name}'] = baseline/role/name
assert {name for name in payload_paths if '/' in name} == {
    'reference/Lokad.Lython.dll', 'candidate/Lokad.Lython.dll', 'candidate/Lokad.Lython.Utf8Regex.dll'}
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name, source in payload_paths.items():
        archive.add(source,arcname=name)
staged={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in payload_paths.items()}
write(quiet/'upload.json',dict(root='generator-outer-quiet-b1895-20261127',
    donor=read(donor/'upload.json')['root'],donorFiles=donor_files,donorArchive=receipt['archiveSHA256'],
    payloadSHA256=digest(payload),files=staged,expandedBytes=sum(item['length'] for item in staged.values()),
    minimumAfterStageBytes=12*1024*1024))

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,fileset in images.items():
    report=quiet/f'{role}-local-verify.json'
    subprocess.run([dotnet,baseline/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',
        '--catalog',quiet/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',quiet/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==fileset['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['library']['sha256']==fileset['Lokad.Lython.dll']
