from pathlib import Path
import hashlib
import importlib.util
import json
import os
import queue
import subprocess
import tempfile
import threading
import time

lab=Path(__file__).resolve().parent
proof=json.loads((lab/'identity.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def checked_image():
    for role, files in proof['imageFiles'].items():
        assert len(files)==32 and {p.name:sha(p.read_bytes()) for p in (lab.parent/role).iterdir()}==files
def save(path,value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
checked_image()
sdk=Path.home()/".dotnet"
dotnet=sdk/"dotnet"
trace=Path.home()/".dotnet/tools/dotnet-trace"
env=dict(os.environ,DOTNET_ROOT=str(sdk),TMPDIR="/dev/shm",PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol_path=lab.parent/'cpython-worker.py'
assert sha(protocol_path.read_bytes())==proof["cpythonWorkerSHA256"]
spec=importlib.util.spec_from_file_location("bench_protocol",protocol_path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
catalog=lab.parent/'representative.json'
cases={case['id']:case for case in json.loads(catalog.read_bytes())['cases']}
digest=sha(catalog.read_bytes())
assert digest==proof['catalogs']['representative.json']['sha256']
diagnostic=[]
for role,case_id,lane,flavor in proof['profiles']:
    image=lab.parent/flavor
    expected=proof['imageFiles'][flavor]
    worker=image/'Lokad.Lython.Benchmarks.dll'
    verification=json.loads((lab.parent/f'verification-{flavor}.json').read_bytes())
    assert verification["state"]=="Completed" and verification["caseCount"]==4 and verification["catalogSha256"]==digest
    assert verification["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
    assert verification["launched"]["adapter"]["sha256"]==expected["Lokad.Lython.Benchmarks.dll"]
    assert verification["launched"]["python"]["sha256"]==proof["expectedCPythonSHA256"]
    case=cases[case_id]
    observations=lab/role
    observations.mkdir()
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-",dir="/dev/shm")as fixture, (observations/"worker.stderr").open("wb")as errors:
        command=[dotnet,worker,"--compare","worker","--catalog",catalog]
        child=subprocess.Popen(command,cwd=fixture,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
        seq=0
        def read_frame():
            result=queue.Queue()
            def receive():
                try:result.put(protocol.read_frame(child.stdout))
                except BaseException as error:result.put(error)
            thread=threading.Thread(target=receive)
            thread.start()
            try:response=result.get(timeout=18)
            except queue.Empty:
                child.kill()
                child.wait(timeout=8)
                raise
            finally:thread.join()
            if isinstance(response,BaseException):raise response
            assert response is not None
            return response
        def request(action,count):
            global seq
            seq+=1
            payload=dict(protocolVersion=2,requestId=seq,operation=action)
            if action!="quit":
                payload.update(caseId=case["id"],lane=lane,iterations=count,
                               **{key:case[key] for key in ("sourceSha256","fixtureSha256","expectedOutputSha256")})
            protocol.write_frame(child.stdin,payload)
            response=read_frame()
            assert response["requestId"]==seq and response["status"]=={"verify":"Equivalent","batch":"Completed","quit":"Closed"}[action]
            if action!="quit":assert response["completedInvocations"]==count
            if action=="batch" and lane=="compile":
                assert response.get("actualOutputSha256") is None and response.get("actualFilesSha256") is None
            elif action!="quit":
                assert response.get("actualOutputSha256")==case["expectedOutputSha256"]
                assert response.get("actualFilesSha256")==case.get("expectedFilesSha256")
            return response
        attached=None
        try:
            identity=read_frame()
            assert identity["status"]=="Ready" and identity["catalogSha256"]==digest
            assert any(n["sha256"].lower()==expected["Lokad.Lython.dll"] for n in identity["libraries"])
            before=request("verify",2)
            count=64
            end=time.monotonic()+4
            while time.monotonic()<end:request("batch",count)
            recording=observations/"run.nettrace"
            with (observations/"capture.log").open("wb")as trace_log:
                attached=subprocess.Popen([trace,"collect","--process-id",str(child.pid),
                           "--profile","dotnet-sampled-thread-time","--buffersize","32",
                           "--duration","00:00:06","--format","Speedscope","--output",recording],
                           env=env,stdin=subprocess.DEVNULL,stdout=trace_log,stderr=subprocess.STDOUT)
                sample=[]
                started=time.monotonic()
                while attached.poll() is None and time.monotonic()-started < 18:sample.append(request("batch",count))
                assert attached.wait(timeout=5)==0 and sample
            after=request("verify",2)
            closed=request("quit",0)
            assert child.wait(timeout=6)==0
        finally:
            if attached is not None and attached.poll() is None:attached.kill();attached.wait(timeout=5)
            if child.poll() is None:child.kill();child.wait(timeout=5)
            child.stdin.close()
            child.stdout.close()
        slot=dict(role=role,lane=lane,workload=case["id"],batches=sample,identity=identity,before=before,after=after,
                  closed=closed,allProcessesJoined=True,coreSha=expected["Lokad.Lython.dll"],nettraceSha=sha(recording.read_bytes()),
                  profile="Ubuntu WSL EventPipe managed sampled thread time")
        diagnostic.append(slot)
        save(observations/"record.json",slot)
        for mode in ("exclusive","inclusive"):
            cmd=[trace,"report",recording,"topN","-n","65"]
            if mode=="inclusive":cmd.append("--inclusive")
            text=subprocess.check_output(cmd,env=env,timeout=35)
            (observations/(mode+".txt")).write_bytes(text)
        print(role,len(sample),sum(b["completedInvocations"]for b in sample),slot["nettraceSha"],flush=True)
checked_image()
save(lab/"run-summary.json",dict(sourceRevision=proof["sourceRevision"],inspectedHead=proof["inspectedHead"],
                                runtime=diagnostic[0]["identity"]["runtime"],catalogSha=digest,
                                allProcessesJoined=True,totalVerifiedBatches=sum(len(item["batches"])for item in diagnostic),
                                timingQualification=False))
