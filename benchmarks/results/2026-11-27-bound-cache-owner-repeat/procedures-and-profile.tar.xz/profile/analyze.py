from collections import Counter
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
ROLES = ('reference-bound', 'candidate-bound', 'candidate-wide')
REGIONS = {
    'iterator callbacks': ('StartIterationCallback', 'TryStartIterationRow', 'TryStartPositionalCallback'),
    'direct operand return': ('TryStartSuppliedOperandReturn', 'TryStartDirectOperandReturn', 'TryEvaluateDirectOperandReturn'),
    'lookup backing access': ('ExistingLookupCaches', 'GetLookupCaches', 'ClearLookupCache'),
    'record field reads': ('TryReadRecordValue', 'TryReadDirectField'),
    'ordinary input operations': ('ExecuteInputInstruction',),
    'zip pulls': ('PyZipIterator',),
    'map pulls': ('PyMapIterator',),
    'starmap pulls': ('PyStarmapIterator',),
    'CSV record construction': ('CsvRecordParser',),
    'owned memory admission': ('MemoryGovernor.Reserve',),
    'async host relay': ('AsynchronousWorkItem.Relay',),
}
WAIT_FRAMES = ('WaitSubsystem+ThreadWaitInfo.Wait', 'LowLevelThreadBlocker.TimedWait', 'PollGCWorker')


def analyze(role):
    capture = json.loads((ROOT / role / 'run.speedscope.json').read_bytes())
    frames = [frame['name'].split('(', 1)[0].split('!', 1)[-1] for frame in capture['shared']['frames']]
    nearest = Counter()
    row_nearest = Counter()
    region = Counter()
    runtime = 0
    for profile in capture['profiles']:
        assert profile['unit'] == 'milliseconds' and profile['type'] == 'evented'
        stack = []
        previous = profile['startValue']
        for event in profile['events']:
            elapsed = event['at'] - previous
            active = [frame for frame in stack if frame.startswith(('Lokad.Lython.Runtime.', 'Lokad.Lython.Frontend.', 'Lokad.Lython.LythonEngine'))]
            if elapsed > 0 and active and not any(mark in frame for frame in stack for mark in WAIT_FRAMES):
                runtime += elapsed
                nearest[active[-1]] += elapsed
                if any('StartIterationCallback' in frame for frame in active):
                    row_nearest[active[-1]] += elapsed
                for label, marks in REGIONS.items():
                    if any(mark in frame for frame in active for mark in marks):
                        region[label] += elapsed
            if event['type'] == 'O':
                stack.append(frames[event['frame']])
            else:
                assert stack.pop() == frames[event['frame']]
            previous = event['at']
        assert not stack
    return dict(role=role, runtimeThreadMilliseconds=runtime, inclusiveRegionsMilliseconds=region,
                nearestLythonMethods=nearest.most_common(35), nearestIterableMethods=row_nearest.most_common(35))


rows = [analyze(role) for role in ROLES]
(ROOT / 'attribution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
for row in rows:
    runtime = row['runtimeThreadMilliseconds']
    print(row['role'], round(runtime, 1))
    for name, elapsed in row['inclusiveRegionsMilliseconds'].most_common():
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
    for name, elapsed in row['nearestIterableMethods'][:8]:
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
