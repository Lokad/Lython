from pathlib import Path
from hashlib import sha256
from shutil import copytree, copyfile
import json

lab = Path(__file__).resolve().parent
old = lab.parent / "current-quiet-script-checkpoint-20261127"
origin = lab.parent / "generator-definition-cache-20261127/comparison"
new = lab / "profile"
new.mkdir()
identity = json.loads((origin / "identity.json").read_bytes())
for name, files in identity["imageFiles"].items():
    copytree(origin / name, lab / name)
    assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (lab / name).iterdir()} == files
for name in ("representative.json", "cpython-worker.py"):
    copyfile(origin / name, lab / name)
identity.update(inspectedHead="5cb61871abd7c09ee45c32984087d061b90154ac",
                profiles=[["reference-bound", "diagnostic.shipment-bound-starmap", "warm-async", "reference"],
                          ["candidate-bound", "diagnostic.shipment-bound-starmap", "warm-async", "candidate"],
                          ["candidate-wide", "diagnostic.shipment-starmap-wide-lists", "warm-async", "candidate"]])
(new / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8", newline="\n")
collect = (old / "profile/collect.py").read_text(encoding="utf-8")
collect = collect.replace("image=lab.parent/'candidate'\nexpected=proof['imageFiles']['candidate']\n", "")
collect = collect.replace("def checked_image():assert len(expected)==32 and {n:sha((image/n).read_bytes()) for n in expected}==expected",
                          "def checked_image():\n    for role, files in proof['imageFiles'].items():\n        assert len(files)==32 and {p.name:sha(p.read_bytes()) for p in (lab.parent/role).iterdir()}==files")
lo = collect.index('worker=image/')
hi = collect.index('    case=cases[case_id]', lo)
collect = collect[:lo] + """diagnostic=[]
for role,case_id,lane,flavor in proof['profiles']:
    image=lab.parent/flavor
    expected=proof['imageFiles'][flavor]
    worker=image/'Lokad.Lython.Benchmarks.dll'
    verification=json.loads((lab.parent/f'verification-{flavor}.json').read_bytes())
    assert verification["state"]=="Completed" and verification["caseCount"]==4 and verification["catalogSha256"]==digest
    assert verification["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
    assert verification["launched"]["adapter"]["sha256"]==expected["Lokad.Lython.Benchmarks.dll"]
    assert verification["launched"]["python"]["sha256"]==proof["expectedCPythonSHA256"]
""" + collect[hi:]
compile(collect, "collect.py", "exec")
(new / "collect.py").write_text(collect, encoding="utf-8", newline="\n")
analyze = (old / "profile/analyze.py").read_text(encoding="utf-8")
lo = analyze.index("ROLES =")
hi = analyze.index("WAIT_FRAMES", lo)
analyze = analyze[:lo] + """ROLES = ('reference-bound', 'candidate-bound', 'candidate-wide')
REGIONS = {
    'iterator callbacks': ('StartIterationCallback', 'TryStartIterationRow', 'TryStartPositionalCallback'),
    'direct operand return': ('TryStartSuppliedOperandReturn', 'TryStartDirectOperandReturn', 'TryEvaluateDirectOperandReturn'),
    'lookup backing access': ('ExistingLookupCaches', 'GetLookupCaches', 'ClearLookupCache'),
    'record field reads': ('TryReadRecordValue', 'TryReadDirectField'),
    'ordinary input operations': ('ExecuteInputInstruction',),
    'zip pulls': ('PyZipIterator',),
    'map pulls': ('PyMapIterator',),
    'starmap pulls': ('PyStarmapIterator',),
    'CSV record construction': ('CsvRecordParser',),
    'owned memory admission': ('MemoryGovernor.Reserve',),
    'async host relay': ('AsynchronousWorkItem.Relay',),
}
""" + analyze[hi:]
analyze = analyze.replace("if any('InvokeIterableRowAsync' in frame for frame in active):",
                          "if any('StartIterationCallback' in frame for frame in active):")
compile(analyze, "analyze.py", "exec")
(new / "analyze.py").write_text(analyze, encoding="utf-8", newline="\n")
entry = (old / "profile-entry.sh").read_text(encoding="utf-8")
lo = entry.index('"$DOTNET_ROOT/dotnet"')
hi = entry.index('bash "$root/profile/run.sh"', lo)
entry = entry[:lo] + """for role in reference candidate; do
  "$DOTNET_ROOT/dotnet" "$root/$role/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" --out "$root/verification-$role.json"
done
""" + entry[hi:]
(lab / "profile.sh").write_text(entry, encoding="utf-8", newline="\n")
copyfile(old / "profile/run.sh", new / "run.sh")
assert all(b"\r" not in file.read_bytes() for file in (lab / "profile.sh", new / "run.sh"))
