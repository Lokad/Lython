#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export DOTNET_ROOT="$HOME/.dotnet"
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
for role in reference candidate; do
  "$DOTNET_ROOT/dotnet" "$root/$role/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" --out "$root/verification-$role.json"
done
bash "$root/profile/run.sh"
python3 "$root/profile/analyze.py"
