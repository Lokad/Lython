from pathlib import Path
from hashlib import sha256
import json
import tarfile
from shutil import copyfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
profile = lab / "profile"
out = repo / "benchmarks/results/2026-11-27-bound-cache-owner-repeat"
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
proof = read(quiet / "identity.json")
assert read(quiet / "summary.json")["verifiedTimedBatches"] == 56
assert read(quiet / "archive-receipt.json")["archiveSHA256"] == digest(quiet / "observations.tar.xz")
assert read(profile / "identity.json")["imageFiles"] == proof["imageFiles"]
cases = {case["id"]: case for case in read(lab / "representative.json")["cases"]}
sources = [lab / name for name in ("prepare.py", "prepare-profile.py", "archive.py", "quiet-vm.py", "summarize.py", "profile.sh",
                                  "verification-reference.json", "verification-candidate.json")]
sources += [quiet / name for name in ("launch.log", "exit-code.txt", "upload.json", "reference-remote-verify.json", "candidate-remote-verify.json")]
sources += [profile / name for name in ("identity.json", "collect.py", "analyze.py", "run.sh", "run-summary.json", "collection.log", "attribution.json")]
captured = 0
roles = {}
for record in profile.glob("*/record.json"):
    data = read(record)
    case = cases[data["workload"]]
    role = data["role"].split("-")[0]
    roles[data["role"]] = len(data["batches"])
    fileset = proof["imageFiles"][role]
    assert data["lane"] == "warm-async" and data["allProcessesJoined"]
    assert data["coreSha"] == fileset["Lokad.Lython.dll"]
    assert data["closed"]["status"] == "Closed"
    assert data["identity"]["catalogSha256"] == proof["catalogs"]["representative.json"]["sha256"]
    loaded = {Path(entry["path"]).name: entry["sha256"] for entry in data["identity"]["libraries"]}
    assert all(loaded[name] == fileset[name] for name in ("Lokad.Lython.dll", "Lokad.Lython.Benchmarks.dll"))
    for batch in [data["before"], data["after"], *data["batches"]]:
        assert batch["status"] == ("Equivalent" if batch is data["before"] or batch is data["after"] else "Completed")
        assert all(batch[k] == case[k] for k in ("sourceSha256", "fixtureSha256", "expectedOutputSha256"))
        assert batch["actualOutputSha256"] == case["expectedOutputSha256"] and batch["actualFilesSha256"] == case["expectedFilesSha256"]
    nettrace = record.with_name("run.nettrace")
    assert data["nettraceSha"] == digest(nettrace)
    sources.extend([record, nettrace, record.with_name("capture.log"), record.with_name("worker.stderr")])
    captured += len(data["batches"])
assert roles == {"reference-bound": 28, "candidate-bound": 35, "candidate-wide": 25}
assert captured == read(profile / "run-summary.json")["totalVerifiedBatches"] == 88

out.mkdir(exist_ok=True)
for name in ("identity.json", "summary.json", "archive-receipt.json", "observations.tar.xz", "terminal-status.json", "stage-custody.json"):
    copyfile(quiet / name, out / name)
copyfile(profile / "attribution.json", out / "profile-attribution.json")
archive = out / "procedures-and-profile.tar.xz"
with tarfile.open(archive, "w:xz", preset=3) as bundle:
    for item in sources:
        bundle.add(item, arcname=item.relative_to(lab))
with tarfile.open(archive) as bundle:
    assert all(bundle.extractfile(p.relative_to(lab).as_posix()).read() == p.read_bytes() for p in sources)
(out / "profile-receipt.json").write_text(json.dumps(dict(verifiedBatches=captured, files=len(sources), sha256=digest(archive)), indent=2) + "\n",
                                         encoding="utf-8", newline="\n")
print(captured, "verified profile batches")
