from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
parent = lab.parent / "generator-definition-cache-20261127"
donor = parent / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

identity = read(donor / "identity.json")
receipt = read(donor / "archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["quietBeforeAndAfter"]
assert receipt["archiveSHA256"] == digest(donor / "observations.tar.xz")
candidate = subprocess.check_output(["git", "rev-parse", "5cb61871a"], cwd=repo, text=True).strip()
patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], candidate, "--", "src"], cwd=repo)
assert sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    assert {p.name: digest(p) for p in (parent / "comparison" / role).iterdir()} == files
    proof = read(donor / f"{role}-remote-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert proof["launched"]["adapter"]["sha256"] == files["Lokad.Lython.Benchmarks.dll"]
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    copyfile(donor / name, quiet / name)
assert digest(quiet / "representative.json") == identity["catalogs"]["representative.json"]["sha256"]
assert digest(quiet / "cpython-worker.py") == identity["cpythonWorkerSHA256"]
assert b"\r" not in (quiet / "run.sh").read_bytes()
jobs = {"warm": [["diagnostic.shipment-starmap-wide-lists", "warm-async"], ["diagnostic.shipment-bound-starmap", "warm-async"]]}
write(quiet / "jobs.json", jobs)
identity.update(candidateRevision=candidate, donorArchiveSHA256=receipt["archiveSHA256"],
                purpose="Reverse initial worker placement for B1897 bound async timing with a wide-list control.")
identity["catalogs"]["jobs.json"]["sha256"] = digest(quiet / "jobs.json")
write(quiet / "identity.json", identity)
collector = (donor / "collect.py").read_text(encoding="utf-8")
collector = collector.replace("len(jobs) == 4", "len(jobs) == 2").replace(
    "lython-b1897-generator-cache-fixtures", "lython-b1898-bound-cache-fixtures")
collector = collector.replace("if job_index % 2 == 0: labels.reverse()", "if job_index % 2 == 1: labels.reverse()")
assert "len(jobs) == 2" in collector and "if job_index % 2 == 1: labels.reverse()" in collector
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
payload_paths = {name: quiet / name for name in ("identity.json", "representative.json", "jobs.json", "cpython-worker.py", "run.sh", "collect.py")}
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as archive:
    for name, source in payload_paths.items():
        archive.add(source, arcname=name)
files = {name: dict(length=file.stat().st_size, sha256=digest(file)) for name, file in payload_paths.items()}
write(quiet / "upload.json", dict(root="bound-cache-repeat-b1898-20261127", donor=read(donor / "upload.json")["root"],
    donorFiles=identity["imageFiles"], donorArchive=receipt["archiveSHA256"], payloadSHA256=digest(payload), files=files,
    expandedBytes=sum(file["length"] for file in files.values()), minimumAfterStageBytes=12 * 1024 * 1024))

vm = (parent / "quiet-vm.py").read_text(encoding="utf-8")
vm = vm.replace("lython-b1897-generator-cache-quiet", "lython-b1898-bound-cache-repeat")
vm = vm.replace(" origin=(donor/'candidate').resolve(strict=True)\n assert origin==donor/'candidate' and donor.resolve()==donor and donor.parent==base",
                " assert donor.resolve()==donor and donor.parent==base")
vm = vm.replace(" assert {p.name:sha(p) for p in origin.iterdir()}==cfg['donorFiles']",
                " for role, entries in cfg['donorFiles'].items():\n  origin=(donor/role).resolve(strict=True)\n  assert origin==donor/role and {p.name:sha(p) for p in origin.iterdir()}==entries")
lo = vm.index("   if cfg['donorFiles'][name]==digest:")
hi = vm.index("  assert {p.name", lo)
vm = vm[:lo] + """   assert cfg['donorFiles'][role][name]==digest
   os.link(donor/role/name,target/name)
   reused['donor']+=1
""" + vm[hi:]
vm = vm.replace("RuntimeMaxSec=250", "RuntimeMaxSec=145")
compile(vm, "quiet-vm.py", "exec")
(lab / "quiet-vm.py").write_text(vm, encoding="utf-8", newline="\n")
print("Verified both original images and reversed the bound lane worker order.")
