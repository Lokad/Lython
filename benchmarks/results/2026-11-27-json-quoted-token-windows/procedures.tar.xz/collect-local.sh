#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/json-quoted-token-windows-20261127
case "${1:-first}" in
    first) cd "$lab/comparison/local" ;;
    repeat) cd "$lab/comparison/repeat" ;;
    *) exit 2 ;;
esac
lease="$lab/comparison/collection.lock"
flock -n "$lease" timeout --signal=TERM 275s taskset -c 27 bash ./run.sh
