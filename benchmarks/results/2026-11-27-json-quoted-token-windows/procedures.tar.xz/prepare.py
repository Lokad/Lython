from base64 import b64decode, b64encode
from hashlib import sha256
from pathlib import Path
from statistics import median
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
prior = notes / 'csv-dictwriter-direct-fields-20261127'
profile = notes / 'current-json-read-export-profile-20261127/comparison/quiet'
workers = lab / 'comparison/local'
allocation = lab / 'allocation'
workers.mkdir(parents=True)
allocation.mkdir()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda p: sha256(p.read_bytes()).hexdigest()
image = lambda p: {f.name: sha(f) for f in p.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
pinned = read(repo/'benchmarks/results/2026-11-27-csv-dictwriter-direct-fields/identity.json')
base = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert base.startswith('43ef47bba')
assert sha256(subprocess.check_output(['git','diff','--binary',pinned['sourceRevision'],base,'--','src'],cwd=repo)).hexdigest()==pinned['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'CreateJsonStringSpecialBytes' in patch and patch.count(b'diff --git ')==1
(lab/'candidate.patch').write_bytes(patch)
original=prior/'comparison/local'
assert image(original/'candidate')==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(original/'candidate',workers/role)
fresh=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert sha(fresh)==sha(repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'/core)
shutil.copyfile(fresh,workers/'candidate'/core)
images={role:image(workers/role) for role in ('reference','candidate')}
assert [name for name, digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(original/name,workers/name)
assert b'\r' not in (workers/'run.sh').read_bytes()
spec=importlib.util.spec_from_file_location('protocol',workers/'cpython-worker.py')
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
catalog=read(profile/'catalog.json')
profile_id=read(profile/'identity.json')
assert sha(profile/'catalog.json')==profile_id['profileCatalogSHA256']
read_case,default=catalog['cases']
input_bytes=b64decode(json.loads(default['fixtureJson'])['inputFiles']['records.json'])
source_catalog=read(notes/'json-traversal-20261124/comparison/representative.json')
escaped=dict(next(c for c in source_catalog['cases'] if c['id']=='scripts.json-lines-shipment.escaped-options.large'))
fixture=json.loads(escaped['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-b1872-goldens-') as location:
    root=Path(location)
    (root/'records.json').write_bytes(input_bytes)
    (root/'export.py').write_bytes(escaped['source'].encode('utf-8'))
    output=subprocess.check_output([python,'-I','-X','utf8',root/'export.py'],cwd=root,timeout=15).decode('utf-8').replace('\r\n','\n')
    file=(root/'shipments.jsonl').read_bytes()
    assert (root/'records.json').read_bytes()==input_bytes
    assert sorted(p.name for p in root.iterdir())==['export.py','records.json','shipments.jsonl']
assert len(file.splitlines())==768 and output==default['expectedOutput']
fixture.update(size=768,inputFiles={'records.json':b64encode(input_bytes).decode('ascii')},outputFiles={'shipments.jsonl':b64encode(file).decode('ascii')})
fixture_text=json.dumps(fixture,separators=(',',':'))
escaped.update(id='diagnostic.json-lines-shipment.escaped-export-768',size=768,fixtureJson=fixture_text,
    fixtureSha256=sha256(fixture_text.encode()).hexdigest(),expectedOutput=output,expectedOutputUtf8Bytes=len(output.encode()),
    expectedOutputSha256=sha256(output.encode()).hexdigest(),expectedFilesSha256=protocol.file_digest({'shipments.jsonl':file}))
catalog['cases'].append(escaped)
print(escaped['id'],len(input_bytes),len(file),repr(output),flush=True)
write(workers/'representative.json',catalog)
write(workers/'jobs.json',{'warm':[[default['id'],'warm'],[read_case['id'],'warm'],[escaped['id'],'warm-async'],[default['id'],'warm-async']]})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),productionReference=base,imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(workers/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),verificationPythonSHA256=sha(python),
    purpose='Compare bounded JSON string scans and plain-token writes with the scalar writer.')
identity['catalogs']={name:{'sha256':sha(workers/name)} for name in ('representative.json','jobs.json')}
write(workers/'identity.json',identity)
collector=(original/'collect.py').read_text(encoding='utf-8').replace('lython-b1870-direct-field-fixture-','lython-b1872-quoted-token-fixture-')
compile(collector,'collect.py','exec')
(workers/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for role, files in images.items():
    report=workers/f'{role}-verify.json'
    subprocess.run([dotnet,workers/role/worker,'--compare','verify','--catalog',workers/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',workers/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==3
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
    folder=allocation/role
    shutil.copytree(workers/role,folder)
    for path in (prior/'allocation/candidate').glob('ValidatedAllocation*'):
        shutil.copyfile(path,folder/path.name)
    assert all(sha(folder/name)==digest for name,digest in files.items())

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:
        case['runAsync']=mode=='async'
    selection=allocation/f'{mode}-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=allocation/role
        report=allocation/f'{role}-{mode}.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=90)
        pair.append(read(report)['rows'])
    for before, after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(allocation/'summary.json',rows)
