The first preparation compared the descriptive fixtureEncoding strings when
merging the file-backed controls. The catalogs share the versioned encoding
but use different prose descriptions. Preparation halted before staging.
The verified catalog now keeps the original cases and describes their file
maps separately from the embedded binary table.
The first Ubuntu filter found the comparison CLI but WSL exposed only
python3 on PATH. The local recovery builds the matching Release probe and
uses the existing CPython 3.13.2 through an alias isolated to this test.
