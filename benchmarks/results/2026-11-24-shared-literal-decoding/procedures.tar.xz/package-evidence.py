from pathlib import Path
import hashlib, json, shutil, statistics, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-24-shared-literal-decoding"
refine=lab/"refinement"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(data): return hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo)
assert patch==(refine/"candidate.patch").read_bytes()
for run, target in ((lab,out),(refine,out/"refinement")):
    quiet=run/"comparison/quiet"
    identity=read(quiet/"identity.json")
    status=read(quiet/"terminal-status.json")
    assert status["receipt"]["complete"] and status["receipt"]["allWorkersJoined"] and not status["fixtures"]
    assert digest((target/"quiet-observations.tar.xz").read_bytes())==status["receipt"]["archiveSHA256"]
    assert digest((run/"candidate.patch").read_bytes())==identity["sourcePatchSHA256"]
    for role, files in identity["imageFiles"].items():
        assert {file.name:digest(file.read_bytes()) for file in (run/role).iterdir()}==files
        verified=read(run/"comparison"/(role+"-verify.json"))
        assert verified["state"]=="Completed" and verified["caseCount"]==3
    assert all(counts["validMatch"]==7 and counts["cpythonRejected"]==3 for counts in read(run/"oracle-summary.json").values())
    shutil.copyfile(quiet/"identity.json",target/"identity.json")
rows=[]
for ref, initial, latest in zip(*(read(file)["rows"] for file in
    (lab/"reference-compiler-owner.json",lab/"candidate-compiler-owner.json",refine/"candidate-compiler-owner.json")),strict=True):
    observations=(ref,initial,latest)
    assert len({row["id"] for row in observations})==len({row["retainedAdmission"] for row in observations})==1
    rows.append(dict(case=ref["id"],compileAllocatedBytes=[statistics.median(row["allocatedBytes"]) for row in observations],
        retainedAdmittedBytes=[row["retainedAdmission"] for row in observations]))
(out/"compiler-ownership.json").write_text(json.dumps(dict(order=["reference","initial","refinement"],rows=rows),indent=2)+"\n",encoding="utf-8")
files=["package-evidence.py","rewrite-decoder.py","local-recovery.md","test-ubuntu-public.sh",
    "candidate.patch","prepare.py","quiet.py","archive.py","prepare.log","launch.log","retrieve.log",
    "reference-compiler-owner.json","candidate-compiler-owner.json","oracle.py","oracle-input.json","oracle-summary.json",
    "oracle-reference-sync.jsonl","oracle-reference-async.jsonl","oracle-candidate-sync.jsonl","oracle-candidate-async.jsonl",
    "comparison/reference-verify.json","comparison/candidate-verify.json","windows-public.log","windows-white.log",
    "ubuntu-public.log","ubuntu-public-corrected.log","windows-net10.log","ubuntu-net10.log"]
files += ["refinement/"+name for name in ["candidate.patch","prepare.py","quiet.py","archive.py","prepare.log","launch.log",
    "retrieve.log","candidate-compiler-owner.json","oracle.py","oracle-input.json","oracle-summary.json",
    "oracle-candidate-sync.jsonl","oracle-candidate-async.jsonl","comparison/reference-verify.json","comparison/candidate-verify.json",
    "windows-public.log","ubuntu-public.log","windows-net10.log","ubuntu-net10.log"]]
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in files: archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert {entry.name:digest(archive.extractfile(entry).read()) for entry in archive}=={name:digest((lab/name).read_bytes()) for name in files}
print("Verified exact source and both complete timing archives.")
