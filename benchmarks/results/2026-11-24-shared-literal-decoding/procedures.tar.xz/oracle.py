from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
sdk = Path.home()/".dotnet11"
valid = {
    "text numeric escapes": r"""print(repr('\x00\101\u00E9\U0001F642'))""",
    "bytes octal and hex": r"""print(list(b'\xff\377\xFf\x00\07\077'))""",
    "raw escapes and adjacent bytes": r"""print(len(br'\x41' B'\x41' b'\101'), repr(R'\x 4'))""",
    "bytes spanning physical lines": "print(b'one\\\ntwo' b'''three\nfour''')",
    "literal and mapping patterns": """match {b'@A': 42}:
        case {b'\\x40' B'\\101': value}:
            print(value)""",
    "formatted text": r'''print(f"\x41\u03bb{'Z'}\U0001F600")''',
    "postponed bytes annotation": r"""
        from __future__ import annotations
        def factory(value: b'\x40' b'A' = b'\x41'):
            return value
        print(factory.__annotations__, factory())
    """,
}
invalid = {
    "text space before hex digit": r"""print('\x 4')""",
    "bytes space after hex digit": r"""print(b'\x4 ')""",
    "formatted space before hex digit": r"""print(f'\x 4{1}')""",
}
sources = {name:textwrap.dedent(source).strip()+"\n" for name,source in (valid|invalid).items()}
(lab/"oracle-input.json").write_text(json.dumps(sources,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
donor=lab.with_name("shared-prepared-definitions-20261124")/"probe-candidate"
manifest=json.loads((lab/"comparison/quiet/identity.json").read_text(encoding="utf-8"))["imageFiles"]
counts={}
for role in ("reference","candidate"):
    image=lab/("probe-"+role)
    shutil.copytree(donor,image,dirs_exist_ok=True)
    shutil.copyfile(lab/role/"Lokad.Lython.dll",image/"Lokad.Lython.dll")
    assert hashlib.sha256((image/"Lokad.Lython.dll").read_bytes()).hexdigest()==manifest[role]["Lokad.Lython.dll"]
    for mode in ("sync","async"):
        cmd=[sdk/"dotnet.exe",image/"LythonProbe.dll","--batch-json","--compare-python","--python","C:/Python313/python.exe"]
        if mode=="async": cmd.append("--async")
        observation=subprocess.run(cmd,env=env,input=json.dumps(list(sources.values()),ensure_ascii=False),
            encoding="utf-8",capture_output=True,timeout=30)
        assert not observation.stderr and observation.returncode in (0,1)
        (lab/f"oracle-{role}-{mode}.jsonl").write_text(observation.stdout,encoding="utf-8")
        for name,row in zip(sources,observation.stdout.splitlines(),strict=True):
            report=json.loads(row)
            if name in valid:
                assert report["Matches"] and report["Lython"]["Success"], (name,report)
            else:
                assert not report["CPython"]["Success"] and report["CPython"]["Failure"]["ExceptionType"]=="SyntaxError"
                if role=="candidate":
                    assert not report["Lython"]["Success"] and not report["Lython"]["StandardOutput"]
                else:
                    assert report["Lython"]["Success"]
        counts[f"{role}-{mode}"]={"validMatch":len(valid),"cpythonRejected":len(invalid),"lythonRejected":len(invalid) if role=="candidate" else 0}
(lab/"oracle-summary.json").write_text(json.dumps(counts,indent=2)+"\n",encoding="utf-8")
print(json.dumps(counts))
