set -eu
root=/home/lokad/lython-bench-checks/borrowed-call-entry-b506-20261109
date -u +%FT%TZ > "$root/started.utc"
systemctl show lython-b506-borrowed-call-entry-20261109.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
python3 "$root/collect.py"
