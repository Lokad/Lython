# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script performance. Completing
an isolated experiment does not complete it. Current contracts live in docs; original
failures, prototypes and qualification live in [history](benchmarks/EXPERIMENTS.md).

## Actual delivery status

| Work | Delivery | Qualification / limits |
| --- | --- | --- |
| Shared compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed foundations | Qualified. Keep allocation and elapsed claims separate; no unchanged replay. |
| R119–R135 record/lookup facts, storage lifetimes, declaration/literal/static-call facts, native inputs/Boolean identity | Committed | Qualified Windows/Ubuntu actual .NET 11/10, original Stress and installed consumers at later checkpoints. |
| R138/R139 closed helpers and incoming lexical reads | Committed, class/global proof corrections preserved | Qualified. Source-pair CPU benefits and control uncertainty remain in history. |
| R141 owned hash stress canceller | Committed `7aa637bf` | Full CI42573178034 cached success; original failed conditions/mutation proof retained. Never requery. |
| R142 shared generator compilation/state | Committed `081052fa`, test correction `27353cfb` | Fully qualified CI42579357509; prototype timings remain distinct from delivery binary. Never requery. |
| R140/R143 CPU attribution | Committed | One usable text/search capture each, exact sources/raw retained. Inclusive VM-prefix shares include useful work. |
| R144 helper proof gate | Completed assessment | Guards precede admission/effects; execution rereads live data. No safe phase deletion selected, no second guard VM/cache. Not a permanent design ban. |
| R145 one executable callable engine | Committed `65ed6cf7`, correctness/fixture correction `58d3ec0f` | Fully qualified: corrected CI42588611410 cached terminal success, Windows/Ubuntu actual11/10, original Stress both and installed consumers. Original failure/correction and measured65ed source retained. Never requery. |
| R146 CPython refresh | Committed `115dda5f`; measured `65ed6cf7`/core082a | Twelve jobs250.847s, all quiet/output/ownership/cleanup/archive gates pass. Do not relabel timings as the correction. |
| R147 general operand transport gate | Committed `c301812f` | Existing input/result forwarding already removes the presumed ordinary round trip. Store continuation retains cleanup/check/span semantics. Static census, no timing claim. |
| R148 filename-filter suspension | Committed `46e3746e` | Fully qualified with R149 at42598266368. Original pending-I/O failure and focused goldens retained. |
| R149 native callback transport | Committed `afb11d97`, measured core6417B97A | Fully qualified CI42598266368 cached success: bothOS actual11/10, original Stress both and installed consumers. Never requery. |
| R150 JSON-report attribution | Committed `2640437c`; boundary clarification `c89d6914` | One current-source usable capture, source gate finds no ordinary instruction copy or duplicate plain-string parse. No speedup claim; no unchanged second capture. |
| Prepared maps, call arenas/control, shared string windows | Held/restored prototypes | Slower or complex variants and useful independent semantic fixes remain in history; no permanent bans. |

## Evidence and uncertainty

[BENCHMARKS.md](docs/BENCHMARKS.md) separates compilation, warm and compile-to-result.
Measured65ed / CPython3.13.16 complete CSV/text/JSON-report/search ratios:
1.13–1.17× /1.49–1.51× /1.35× /1.34–1.35×. Warm:1.15–1.17× /1.56–1.60× /
1.37–1.38× /1.61–1.63×. Compile roughly1.05–1.09×, search0.95×. Variable controls
remain visible; older rows retain their own sources. Includes mediated RAM-file I/O,
full output checks and prior-result cleanup; excludes startup/reset/protocol/final
cache teardown. Pending I/O, embedding tails and large-tree/file throughput unknown.
Search input has2,049 physical lines and exits at1,025; both engines run the same work.

Native helper returns: allocation−19.92/19.31%, distinct from diagnostic elapsed.
Formatting: allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention,
while original adverse15.125ms remains unexplained and retained. No unchanged campaign.

R142: text allocation−15.1%; quiet affected pipelines improve, supporting CPU.
Compile allocation+1.3–1.6% and report control+1.17–4.54%elapsed/+0.39–4.44%CPU
remain accepted/unresolved debt. Original desktop JSON adversity survives. No final-
binary timing claim or attempt to settle this by comparing unrelated checkpoints.

R145: remove PyFunction, its mode/177-line duplicate dispatcher, runtime lambda
lowering/compilation and unused bodies; preserve actual executable capture facts
and real lowered consumers. Complete class-callable CSV/text/JSON warm allocation
−23–26%/−74–76%/−56–57%; quiet elapsed−9–12%/−38–39%/−13–15%, supporting CPU.
Compile allocation+3.2–5.2% accepted; report control+0.05–1.12%elapsed/0–4.44%coarseCPU
uncertain. Source pairs are not CPython/shape ratios. Measured source65ed remains
explicit after58d3's scope correction. [Evidence](benchmarks/results/2026-11-09-callable-consolidation/README.md).

## Prioritized non-regex deliverables

1. **R151 one borrowed entry on the existing callable contract.** Selected continuation,
   not a new interface/framework: add short-span consumption to existing ICallable,
   with an owned-array default for real retainers. Let functions, bound methods,
   builtin binders and JSON consume before returning pending work. Replace R149's
   repeated callable-type switches with this entry; retire the separate executable
   three-arity packet pool/rent/clear/return lifecycle and completed general-call
   async forwarding. Reuse the existing short managed storage. Constructors and
   wider calls retain admitted owned arrays through actual cleanup; no new pool,
   cache, option or guest limit. Hypothesis: remove packet lifecycle and repeated
   dispatch in ordinary JSON/native calls; static CPU shares are not promised gains.
   Affects maintained JSON/report/CSV/text scripts; include a constructor-heavy
   control to expose owned-fallback cost. Preserve keyword/default/variadic binding,
   receiver/evaluation order, invalid-callable diagnostics, constructor protocols,
   reentrancy, generators, current cancellation/refusal and funded pending users.
   Focused actual11/10 checks, independent Python goldens, short before/after warm
   allocation/elapsed with compile/control costs separate. Quiet bounded comparison
   only if material. Completion deletes displaced pools/switches, decides fallback
   regression debt explicitly, then batches delivery. Stop/refine within20min of
   an unworkable contract, preserving any failed prototype; no broader compiler rewrite.

   **R148/R149 delivery complete:** Windows/Ubuntu actual11/10, original Stress both
   and installed Release consumers all pass42598266368; terminal cached, never requery.
   Preserve current cancellation/refusal,
   awaited cleanup and owned values before default lookup/body suspension. R149
   deletes three thread-local pools/six rent-clear-return helpers, async forwarders,
   duplicate binding bodies and ordinary map per-record arrays/reservations. Wide
   map/dynamic callable arrays remain owned; no new pool/framework/public policy.
   Same-source map-based CSV/text/JSON allocation−6.8/−14.1/−4.7% across both APIs;
   compile allocation unchanged. Desktop elapsed inconclusive, controls up to16.5%.
   Quiet B504 five jobs142.204s: CSVelapsed−2.8–3.2%, text−3.0–6.6% with supporting
   CPU; JSON−1.5–+2.7% mixed. Report/search controls also move. Retain simplification
   and allocation benefits; dynamic-fallback allocation and elapsed attribution are
   explicit limitations, no universal gain claim/repeated unchanged campaign.
   [R149 evidence](benchmarks/results/2026-11-09-callback-arguments/README.md).

2. **Select the next coherent execution redesign from current evidence.** Remaining
   warm text/search gaps are real; current profiles do not isolate one removable cause.
   **R150 complete:** maintained JSON/currentafb11d97 capture gives1201guest samples,
   5.66%unknown; observed prefix40.47%,JSON19.90%,dictionary7.83%,admission6.91%,
   nativecall6.74%,text6.41%,managed cancellation/stack4.33%. Prefix includes useful
   inlined work; source already reads immutable instructions by readonly reference,
   skips backend reparsing of plain strings and shares record keys/completed loops.
   Default JSON calls skip general binding. No duplicate phase selected; no second
   capture/new framework from these counts. [Evidence](benchmarks/results/2026-11-09-json-runtime-attribution/README.md).
   Module facts are retained at lexical preparation's end; early binding-only facts
   precede final class-cell demand. Do not cache partial class facts as final facts.
   General executable calls still use a separate three-arity packet pool. Replacing
   it with R149 alone would allocate owned packets for dynamic callees; do not
   present that as a free deletion. A future common borrowed-argument convention
   must consume inputs into owned storage before real suspension and remove the
   displaced packet/binding phase across workloads, preserving constructors and
   evaluation order. No new pool/interface/dispatch framework to hide that cost.
   Start with general instruction/operand/call representation across complete scripts,
   then remaining text/record work. State the current duplicated work or storage and
   displaced code before implementation. R147 confirms direct input/result forwarding
   and nonmirrored maintained modules/helpers already exist; do not reimplement them.
   Retained store continuations protect pending disposal and publication ordering.
   No new arena, dispatch framework, guard VM, per-call cache or syntax-specific trick.

   Source/design gate at most20min per actual hypothesis. Static counts and inclusive
   samples are not savings. If no coherent deletion is found, record that and move to
   the independent next family without another capture/unchanged timing campaign.
   A selected milestone names affected CSV/text/JSON/report/file scripts and controls,
   preserves Python order/errors/scopes/protocols, current cancellation, terminal
   refusal, stack safety and explicit owners, then compares compile/allocation/warm
   separately. Use a short diagnostic and bounded quiet confirmation where material.
   Finish by deleting displaced implementation and deciding remaining regression debt.

3. **Remaining text/frontend and per-record gates.** Direct final UTF-8/managed bulk
   ASCII casing, one Unicode mapping pass, fused final-word splitting, flat callable
   facts and commit without root resizing already exist. Ordinary counters skip
   separate magnitude admission. SumState already accumulates machine integers
   with guarded promotion; local imports already compile/execute the common engine
   with explicit export mirroring. Do not repeat those migrations or infer scalar
   CPU dominance from boxing.
   Inspect remaining conversions/repeated analysis only where a current phase is
   demonstrated; preserve Unicode expansion/scalar offsets, aliases and diagnostics.
   No heavyweight JIT/tagged-value or class/import compiler rewrite from inclusive
   counts. Each new gate has the same20min stopping rule and coherent deletion target.

   CSV already stages a record, admits field/row capacity once and adopts storage;
   JSON shares layouts. Historical bulk-CSV6–8% benefits remain promising evidence,
   but the copying premise has been displaced. Reopen for a current duplicate phase
   or measured control issue; no automatic promotion or percentage veto. Slower
   call-arena/control lessons remain explicit. Refresh CPython after another substantial
   coherent checkpoint, not per tweak; R146 is complete and needs no unchanged replay.

## Independent regex deliverable

Core owns Python semantics, native UTF-8 names, byte ranges/scalar positions, original
windows, effective flags, errors/replacements, current tokens, explicit owners and one
frontend/runtime/import provider. Continue independent contract/implementation/semantic
work; missing published producer APIs defer only affected final adapter qualification.
Adapter-local bridges, test providers and pinned development producers are acceptable.
Keep forwarding/unwind, semantic validation and actual backend performance distinct.

Optional nonpackable adapter pin0.4.0; official index checked2026-11-09. Dev55/d6067925
already86 internal/514 public eachactual11/10 pass; no unchanged replay/sibling edits.
Missing released capabilities: DetailedData with distinct preparation/working owners,
native-name enumeration and cursor creation without an earlier caller token. Current
Lython-owned byte-range/capture-buffer contract is independent of those bridges.

## Iteration and lasting constraints

Timeouts, unstable controls and inconclusive observations establish uncertainty, not
failed designs. Allow bounded confirmation/refinement/measurement correction when
evidence justifies it. Retain original adverse/failed conditions. Percentages inform
decisions, not automatic vetoes; distinguish simplification, allocation and CPU benefit.

AGENTS.md is authoritative: fully managed memory safety and managed stack admission;
host mediation/current cancellation; coarse borrowed shared budget/preflights/capacity/
replacement overlap; escaping results/caches/aliases/pending users funded through
awaited cleanup. First refusal terminal. No unsafe/native probing, fuel/quotas/caps/
hidden allowance, tracing/weak reclaim/forced GC or abandoned work. Focused Release
checks during iteration; batch full platform/Stress/installed consumers at delivery.
No overlapping local builds/tests/timing; force nonincremental after source restores.
Release packages only via tools/pack.ps1 into artifacts/nuget; no publication.

VM lokad@20.166.121.73/key ~/.ssh/id_lython-bench.pem. ThroughB505 terminal/cached/local
SHA verified, no users/fixtures; never requery. Finite service/lease, persistent workers/
catalog/raw separate from RAM, joined users/unmount/archive under lease. Space recovery
requires fresh idle exact bytes/all aliases/SHA/owner/group/mode/parents and persisted
pre-mutation plan; preserve every path/byte/floor. CI observations at least5min apart
using recorded UTC clocks; cache terminal once. Through42588611410 terminal/cached.
Delivery42598266368/sourceafb11d97 terminal cached success; never requery.
Currentc89d6914 differs only by evidence/docs, not production code. No live VM work.
