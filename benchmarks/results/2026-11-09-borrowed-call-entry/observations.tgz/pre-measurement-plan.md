# R151 bounded confirmation

Five same-source jobs: maintained JSON sync and existing warm-async lane, maintained
text control, map-heavy text dispatch control, CSV constructor-owned-packet control.
The maintained ordinary CSV also has desktop allocation/elapsed observations but no
extra quiet job. Four independent roles, five-second warmup, seven rotated150ms rounds.
Common existing worker/adapter, normal GC/tiering. Warm clock includes mediated RAM-file
I/O, full output checks and prior-result cleanup; excludes startup, compilation, reset/
protocol/final teardown. External process CPU separate. No CPython comparison here.
Allocation unchanged on ordinary scripts; constructor plus2.5percent is expected debt.
Desktop JSONsync about minus3.8percent, async plus2.6to4.4percent; controls spread7.4percent.
Retain all original adversity; deletion/simplification does not prove CPU improvement.
Decide remaining constructor/dynamic fallback and CPU regression debt explicitly.
No full lanes, new worker/framework or producer replay. Finite owner210s+30stop+30margin;
expected155s, persistent raw apart from RAM fixtures, join/unmount/archive under lease
and verify localSHA. Floors/headroom unchanged; no space recovery in this collection.
