from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b506';out=Path('benchmarks/results/2026-11-09-borrowed-call-entry');out.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
assert hashlib.sha256((v/'observations.tgz').read_bytes()).hexdigest()==json.loads((v/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
proof=dict(productionSourceMatchesMeasuredFreeze=True,baselineRevision=identity['baselineRevision'],baselineProduction='afb11d97 fully qualified42598266368',measuredCoreSHA256=identity['candidateCoreSHA256'],actualFrameworks=['net11.0','net10.0'],focusedPerFramework=dict(internal=706,public=1614),newFrameworkOrPublicApi=False,independentWholeScriptPythonGoldens=5,removed='Three executable-call thread-local packet pools and rent/return/clear lifecycle, two callback callable-type switches, completed general/JSON async forwarding; private builtin hierarchy no longer exposed to callback selection. Six pool-sentinel fixture regions removed, independent semantic/lifetime assertions preserved.',preserved='Existing array entry for genuine owned callers, dynamic/constructor/wide packets through completion, owned binding before actual suspension, current cancellation and first terminal refusal, managed nesting, retained aliases and awaited cleanup. Original five packet-release failures fixed in code with original release assertions unchanged.',limitations='Constructor control allocation plus2.5percent, ordinary script allocation unchanged. Desktop controls vary up to7.4percent and async JSON adversity retained. No universal/startup/pending-I/O/CPython speedup claim. Full platform/package/Stress batch after retention decision.',space='Initial setup refused before any service/root/fixture creation. Fresh idle lease/single-alias hashes/ownership/parents/pre-mutation plan verified two redundant remote archives, both still immutable Git-tracked locally with raw trees/receipts retained. Removed those copies only; same floor/headroom/staged source/payload, no timed work restarted.')
(r/'delivery-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests']))
for target,source in [('observations.tgz',v/'observations.tgz'),('summary.json',v/'assessment.json'),('terminal.json',v/'terminal-status.json'),('identity.json',r/'identity.json'),('local-summary.json',r/'assessment-local.json'),('delivery-source.json',r/'delivery-source.json'),('script-goldens.json',r/'script-goldens.json'),('space-recovery.json',r/'space-recovery.json')]:
    assert not (out/target).exists();shutil.copyfile(source,out/target)
with tarfile.open(out/'preparation.tar.xz','w:xz') as archive:
    for p in r.iterdir():
        if p.is_file():archive.add(p,arcname=p.name)
    for name in ['warm-sync','warm-async','compile-sync']:archive.add(r/name,arcname=name)
    for p in v.iterdir():
        if p.is_file() and p.name not in ['payload.tgz','observations.tgz','baseline-core.dll','current-core.dll','common-worker.dll','common-adapter.dll']:archive.add(p,arcname='b506/'+p.name)
    archive.add('tests/Lokad.Lython.Tests/ExecutableCallTransferTests.cs',arcname='ExecutableCallTransferTests.cs')
print('Measured source verified; original lifetime/source-assumption/headroom failures, recovery, all raw/control evidence and focused logs archived.')
