from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b506';v.mkdir()
old=r.parent/'callback-transport-r149/b504'
old_name='callback-transport-b504-20261109';new_name='borrowed-call-entry-b506-20261109'
jobs=[['scripts.json-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','warm-async'],['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.map-callback.large','warm'],['scripts.csv-validated-records.constructor-control.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
    data=(old/name).read_text(encoding='utf-8').replace(old_name,new_name).replace('lython-b504-callback-transport-20261109','lython-b506-borrowed-call-entry-20261109').replace('callback-transport-b504-launch.py','borrowed-call-entry-b506-launch.py').replace('lython-b504-fixtures','lython-b506-fixtures')
    if name=='collect.py':
        start=data.index('jobs=[');end=data.index('\nenv =',start)
        data=data[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+data[end:]
        start=data.index("purpose='R149");end=data.index('\n                  warmupSeconds=',start)
        data=data[:start]+"purpose='R151 one borrowed entry on existing callable contract; remove executable packet pool and callback type switches. Maintained JSON sync/async, ordinary text, map-dispatch and constructor-owned-packet controls. No allocation speedup claim; constructor allocation plus2.5percent and original desktop control drift retained.',"+data[end:]
    if name.endswith('.py'):compile(data,name,'exec')
    (v/name).write_text(data,encoding='utf-8',newline='\n')
for target,source in [('representative.json',r/'catalog.json'),('baseline-core.dll',r/'images/before/Lokad.Lython.dll'),('current-core.dll',r/'images/candidate/Lokad.Lython.dll'),('source.patch',r/'source.patch'),('baseline-source.json',r/'baseline-proof.json')]:shutil.copyfile(source,v/target)
shutil.copyfile('PLAN.md',v/'contract.md')
for target,name in [('common-worker.dll','Lokad.Lython.Benchmarks.dll'),('common-adapter.dll','Lokad.Lython.Utf8Regex.dll'),('common-worker.deps.json','Lokad.Lython.Benchmarks.deps.json'),('common-worker.runtimeconfig.json','Lokad.Lython.Benchmarks.runtimeconfig.json')]:shutil.copyfile(r/'images/before'/name,v/target)
identity=dict(sourceRevision='Qualified afb11d97 production / doc-only c89d6914 versus R151 prototype; verified nonincremental freezes, no restore; common frozen worker/adapter',coreSHA256={role:hashlib.sha256((v/name).read_bytes()).hexdigest() for role,name in [('reference','baseline-core.dll'),('reference-control','baseline-core.dll'),('candidate','current-core.dll'),('candidate-control','current-core.dll')]},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'images/before').glob('*.dll') if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(status='Actual11 focused706internal/1614public pass; actual10 checks running independently. Five independent whole-script Python goldens. Original packet-lifetime failures fixed without weakening assertions.'),indent=2)+'\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,jobs=5,unchangedWorkerAndProtocol=True),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=5,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=155,ownerSeconds=210),indent=2)+'\n',encoding='utf-8')
(v/'pre-measurement-plan.md').write_text('''# R151 bounded confirmation

Five same-source jobs: maintained JSON sync and existing warm-async lane, maintained
text control, map-heavy text dispatch control, CSV constructor-owned-packet control.
The maintained ordinary CSV also has desktop allocation/elapsed observations but no
extra quiet job. Four independent roles, five-second warmup, seven rotated150ms rounds.
Common existing worker/adapter, normal GC/tiering. Warm clock includes mediated RAM-file
I/O, full output checks and prior-result cleanup; excludes startup, compilation, reset/
protocol/final teardown. External process CPU separate. No CPython comparison here.
Allocation unchanged on ordinary scripts; constructor plus2.5percent is expected debt.
Desktop JSONsync about minus3.8percent, async plus2.6to4.4percent; controls spread7.4percent.
Retain all original adversity; deletion/simplification does not prove CPU improvement.
Decide remaining constructor/dynamic fallback and CPU regression debt explicitly.
No full lanes, new worker/framework or producer replay. Finite owner210s+30stop+30margin;
expected155s, persistent raw apart from RAM fixtures, join/unmount/archive under lease
and verify localSHA. Floors/headroom unchanged; no space recovery in this collection.
''',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz') as archive:
    for p in v.iterdir():
        if p.name!='payload.tgz':archive.add(p,arcname=p.name)
print('Five jobs, JSON sync/async and explicit controls; expected155s/owner210s; payload',(v/'payload.tgz').stat().st_size)
