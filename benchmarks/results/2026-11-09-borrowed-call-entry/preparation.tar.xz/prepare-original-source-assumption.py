from pathlib import Path
import base64,copy,hashlib,json,subprocess,tempfile
r=Path(__file__).parent
catalog=json.loads((r.parent/'lexical-operands-r139/catalog.json').read_text(encoding='utf-8'))
original={item['id'].split('.')[1]:copy.deepcopy(item) for item in catalog['cases']}
mapped=json.loads((r.parent/'callback-transport-r149/catalog.json').read_text(encoding='utf-8'))
map_text=next(c for c in mapped['cases'] if '.text-summary-helpers.' in c['id'])
csv=Path('benchmarks/scripts/csv-validated-records.py').read_text(encoding='utf-8')
constructor=csv.replace('def validated_record',"class RecordAmount:\n    def __init__(self, record):\n        self.amount = int(record['amount'])\n\n\ndef validated_record",1).replace("amount = int(record['amount'])","amount = RecordAmount(record).amount",1)
# Replace only the original function expression, not the newly inserted constructor.
constructor=constructor.replace("self.amount = RecordAmount(record).amount","self.amount = int(record['amount'])").replace("    amount = int(record['amount'])","    amount = RecordAmount(record).amount")
selected=[]
for name in ['json-summary-helpers','text-summary-helpers','csv-validated-records']:
    item=original[name];assert item['source']==Path('benchmarks/scripts',name+'.py').read_text(encoding='utf-8');selected.append(item)
selected.append(copy.deepcopy(map_text))
item=copy.deepcopy(original['csv-validated-records']);item['source']=constructor;item['id']='scripts.csv-validated-records.constructor-control.large';item['sourceUtf8Bytes']=len(constructor.encode());item['sourceSha256']=hashlib.sha256(constructor.encode()).hexdigest();selected.append(item)
assert len(selected)==5
goldens=[]
for item in selected:
    fixture=json.loads(item['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r151-golden-') as folder:
        folder=Path(folder)
        for path,encoded in fixture['inputFiles'].items():
            dest=folder/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(base64.b64decode(encoded,validate=True))
        done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',item['source']],cwd=folder,encoding='utf-8',capture_output=True,timeout=15)
        assert done.returncode==0 and done.stdout==item['expectedOutput'] and not done.stderr,(item['id'],done)
        for path,encoded in fixture['outputFiles'].items():assert (folder/path).read_bytes()==base64.b64decode(encoded,validate=True),(item['id'],path)
        goldens.append(dict(case=item['id'],source=item['source'],sourceSHA256=item['sourceSha256'],stdout=done.stdout,allOutputFilesEqual=True))
catalog['cases']=selected
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'script-goldens.json').write_text(json.dumps(goldens,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
previous=json.loads((r.parent/'callback-transport-r149/identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()==previous['candidateCoreSHA256']
(r/'baseline-proof.json').write_text(json.dumps(dict(revision=(r/'baseline-revision.txt').read_text(encoding='utf-8-sig').strip(),productionRevision='afb11d97',coreSHA256=previous['candidateCoreSHA256'],build='Reuse R149 fresh nonincremental freeze, no source restore; production unchanged through baseline doc-only commits.',productionSources=previous['productionSources']),indent=2)+'\n',encoding='utf-8')
print('Three maintained scripts and map/constructor controls: five independent Python goldens pass.')
