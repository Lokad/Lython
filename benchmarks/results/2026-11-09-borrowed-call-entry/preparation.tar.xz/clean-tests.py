from pathlib import Path
import re
names=['DirectAppendExecutionTests','DirectDictionarySetDefaultTests','DirectDictionaryGetTests','DirectStringStartsWithTests','PositionalCallTransportTests']
for name in names:
    p=Path('tests/Lokad.Lython.Tests',name+'.cs');s=p.read_text(encoding='utf-8');removed=0
    pattern=r'        var (pool|field) = typeof\(LythonRuntime\)\.GetField\(.*?\n        try\n        \{\n(.*?)\n        \}\n        finally \{ \1\.SetValue\(null, previous\); \}'
    def clean(m):
        global removed
        removed+=1
        body=[line[4:] if line.startswith('    ') else line for line in m[2].splitlines() if 'sentinel' not in line and 'pool.GetValue' not in line and 'field.GetValue' not in line]
        return '\n'.join(body)
    s=re.sub(pattern,clean,s,flags=re.S)
    assert removed==(2 if name=='PositionalCallTransportTests' else 1),(name,removed)
    if 'BindingFlags' not in s:s=s.replace('using System.Reflection;\n','')
    for a,b in [('DifferentReceiversDoNotPackageArgumentsOrConstructBoundMethods','DifferentReceiversPreserveArgumentsAndCleanup'),('DistinctReceiversUseOperandsWithoutArgumentPackaging','DistinctReceiversPreserveDefaultsAndCleanup'),('DistinctReceiversAvoidMethodAndArgumentPackaging','DistinctReceiversPreserveValuesAndCleanup'),('OrdinaryCallsLeaveTheArgumentPoolUntouched','OrdinaryCallsPreserveValuesAndCleanup'),('CompiledPositionalCallsDoNotBorrowThePackagedArgumentPool','CompiledPositionalCallsPreserveArgumentsAndCleanup'),('ClassDefinedMethodsPreserveValuesWithoutArgumentPackaging','ClassDefinedMethodsPreserveArgumentsAndCleanup')]:s=s.replace(a,b)
    p.write_text(s,encoding='utf-8')
    print(name,removed,'pool-only sentinel checks removed; semantic/ownership assertions retained')
