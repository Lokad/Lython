from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/callback-transport-b504-20261109/observations.tgz', 'sha256': '46ce2b5dcbe1b0f881094358bc325535cf7f486e6ae5e79d845441d79b687ba2', 'size': 3983632, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-callback-arguments/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/json-runtime-b505-20261109/observations.tgz', 'sha256': '59c4a92971759a700cdcbd26abe673ddd90579747045b222876879a7730e4004', 'size': 2138069, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-json-runtime-attribution/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'borrowed-call-entry-b506-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b505').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 rows=[]
 for entry in spec:
  p=Path(entry['path']);assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
 plan=dict(freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'borrowed-call-entry-b506-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'borrowed-call-entry-b506-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
