from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path(__file__).parent/'b506'
assert not (r/'observe-not-before.json').exists() and not (r/'terminal-status.json').exists()
code=(r/'launch-command.py').read_bytes();payload=(r/'payload.tgz').read_bytes()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/borrowed-call-entry-b506-launch.py'
check="from pathlib import Path;import hashlib;print(hashlib.sha256(Path("+repr(stage)+").read_bytes()).hexdigest())"
verified=subprocess.run(ssh+['python3 -'],input=check,text=True,encoding='utf-8',capture_output=True)
assert verified.returncode==0 and verified.stdout.strip()==hashlib.sha256(code).hexdigest(),verified
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(r/'launch-retry.log').write_bytes(done.stdout+b'\n'+done.stderr)
print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=270)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=30,initialSetupRefusal='Before root/service/fixture creation; disk-headroom gate. No timed work restarted.',stagedSourceSHA256=hashlib.sha256(code).hexdigest()),indent=2)+'\n',encoding='utf-8')
print('Observe after '+(now+datetime.timedelta(seconds=270)).isoformat())
