from pathlib import Path
import ast,base64,copy,hashlib,json,os,shutil,subprocess,tempfile,textwrap
r=Path(__file__).resolve().parent;prior=r.parent/'activation-r79';d=json.loads((prior/'source-pair/catalog.json').read_text(encoding='utf-8'));byid={c['id']:c for c in d['cases']}
pairs=[];goldens=[]
for name in ['scripts.text-summary-helpers.large','scripts.csv-summary-functions.large']:
 original=byid[name];source=original['source'];tree=ast.parse(source);prefix=0
 for node in tree.body:
  if not isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef)):break
  prefix=node.end_lineno
 assert prefix and 'agent_main'not in source
 lines=source.splitlines(keepends=True);variant=copy.deepcopy(original)
 variant['source']=''.join(lines[:prefix])+'\n\ndef agent_main():\n'+textwrap.indent(''.join(lines[prefix:]),'    ')+'\nagent_main()\n'
 variant['id']=name.replace('.large','-function-locals.large');variant['sourceUtf8Bytes']=len(variant['source'].encode('utf-8'));variant['sourceSha256']=hashlib.sha256(variant['source'].encode('utf-8')).hexdigest()
 with tempfile.TemporaryDirectory(prefix='lython-module-locals-golden-')as folder:
  fixture=json.loads(variant['fixtureJson'])
  for label,case in [('module',original),('function',variant)]:
   for f,v in fixture['inputFiles'].items():(Path(folder)/f).write_bytes(base64.b64decode(v))
   result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True)
   assert result.returncode==0 and not result.stderr and result.stdout.replace(b'\r\n',b'\n')==case['expectedOutput'].encode('utf-8'),result.stderr
   assert all((Path(folder)/f).read_bytes()==base64.b64decode(v)for f,v in fixture['outputFiles'].items())
   goldens.append(dict(case=case['id'],form=label,sourceSHA256=case['sourceSha256'],allStdoutAndFilesMatch=True))
 assert not Path(folder).exists();pairs.extend([original,variant])
d['cases']=[*pairs,byid['scripts.report-render.large']];assert len(d['cases'])==5
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(r/'independent-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'source-pair/images/candidate',r/'images'/role,copy_function=os.link)
(r/'measure.py').write_text((prior/'measure.py').read_text(encoding='utf-8'),encoding='utf-8')
identity=json.loads((prior/'source-pair/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity['productionSources'].items())
(r/'identity.json').write_text(json.dumps(dict(sourceRevision='913ea550',coreSHA256=identity['coreSHA256']['candidate'],runtimeVaries=False,productionSources=identity['productionSources'],intent='Same-core module/function workload contrast; not a runtime improvement or valid arbitrary-script rewrite.'),indent=2)+'\n',encoding='utf-8')
(r/'selected-plan.md').write_text('''R81 bounded namespace-binding gate after R80current profile: module workload versus function-local main body, same current core/all ALC roles. Helper definitions/imports stay at module level; stdout/all files independently equal CPython. Public namespace/stack/introspection semantics differ deliberately, so this cannot be shipped as a source rewrite. One existing five-case diagnostic/both APIs: text pair, CSV pair, unchanged report. Test whether repeated module binding/mirroring is materially different from actual local slots before selecting a coherent single-authority namespace design. Source currently StoreLocalValue may write locals and frame Variables; mirrored slot reads also consult the context. Globals/locals aliases, deletion/insertion order, dynamic protocol keys, closures/imports/class/annotation rules, host globals, diagnostics and funded escaping namespaces must survive any actual redesign; no new memory ledger/tracing, per-name kernels or configuration switch. Allocation/workload contrast and desktop elapsed do not identify exact CPU saving. Stop at a justified complete removable binding phase or insufficient evidence; no automatic namespace rewrite, broad scalar/tagged-value redesign or profile sweep.''',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='   b444-20261108. No second capture/restart on an observation timeout.\n';assert needle in s
s=s.replace(needle,'''   b444-20261108. B444 is now terminal, archived and locally verified:1083guest
   samples/5.45CPU-s,49unknown, no malformed maps. Self samples:dispatch21.0%,
   input handlers5.6%, token-range scan4.6%, structural hash4.4%, local-result
   completion3.5%, native-call selector3.4%, integer add2.0%; inclusive overlaps.
   Existing split already batches admission; no speculative per-token reservation
   redesign or universal numeric representation. All source/golden/quiet/join/
   archive gates pass. Diagnostic overrides preclude normal timing claims.
   R81 bounded next source contrast selected: same-runtime complete text/CSV main
   bodies as module versus function locals; helpers/imports stay at module level,
   all CPython output/files match. This is not a valid arbitrary-source rewrite:
   namespace/stack semantics deliberately differ. Use it to test the significance
   of module binding/mirroring before any single-authority namespace redesign.
   Preserve globals/locals aliases/order/dynamic keys/closures/imports/annotations,
   diagnostics, current cancellation and funded escaping namespaces. One existing
   five-case diagnostic, then justified phase or insufficient evidence; no new
   switch/cache/ledger or open-ended campaign.
''')
p.write_text(s,encoding='utf-8',newline='\n');print('Text/CSV module/function full goldens independently match; bounded source gate recorded, one same-core diagnostic prepared.')
