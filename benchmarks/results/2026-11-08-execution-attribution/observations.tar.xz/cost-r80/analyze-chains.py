from pathlib import Path
r=Path(__file__).resolve().parent;s=(r.parent/'text-cost-r63/analyze-chains.py').read_text(encoding='utf-8').replace("'perf/text-warm/'","'profiles/text-warm/'")
exec(compile(s,str(r/'analyze-chains.py'),'exec'),{'__file__':str(r/'analyze-chains.py')})
