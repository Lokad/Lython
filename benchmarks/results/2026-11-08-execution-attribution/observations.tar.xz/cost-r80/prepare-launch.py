from pathlib import Path
import ast
r=Path(__file__).resolve().parent;old=r.parent/'text-cost-r63'
s=(old/'launch.py').read_text(encoding='utf-8')
s='\n'.join(line for line in s.splitlines()if not line.startswith('previous='))+'\n'
s=s.replace('text-cost-b419-20261107','native-cost-b444-20261108').replace('lython-b419-text-cost-20261107','lython-b444-native-cost-20261108').replace('text-cost-b419-launch.py','native-cost-b444-launch.py')
s=s.replace("source=(base/'syntax-validation-b418-20261107/candidate').resolve()","source=(base/'native-workstate-b443-20261108/candidate').resolve()")
s=s.replace("Path('/dev/shm/lython-text-cost-b419')","Path('/dev/shm/lython-b444')").replace("fixture=root/'guest-fixtures';fixture.mkdir()","fixture=Path('/dev/shm/lython-b444');fixture.mkdir()")
s=s.replace("'lython-b419-fixtures'","'lython-b444-fixtures'")
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');needle='   next boundary. No open-ended audit or universal rewrite by assumption.\n';assert needle in text
text=text.replace(needle,needle+'''   Selected R80 capture: one maintained synchronous text-summary/helpers job,
   current913ea550/core18b563e9, existing R63worker/perf199Hz protocol:6guest-second
   warmup,2s settle,6s wall profile. PerfMap3/JIT listings diagnostic only; keep
   all-thread raw stacks/maps/unknowns and actual guest CPU denominator. Source/
   core/allaux/Ready/pre-post goldens/Closed/join/quiet/archive gates required.
   Short owned RAM fixture path, persistent trace/catalog/core, join/unmount/
   archive underlease and verify locally.120s owner+30s stop+30s margin. Stop
   at a demonstrably removable phase or explicit insufficient evidence; no
   normal-settings timing/speedup claim or automatic scalar/value rewrite.
''')
p.write_text(text,encoding='utf-8',newline='\n');print('R80 one-profile selection and exact stopped/ownership criteria recorded; current worker donor validated by launch.')
