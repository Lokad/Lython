from pathlib import Path
import json
r=Path(__file__).resolve().parent;bound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'));ci=json.loads((r.parent/'activation-r79/ci-request.json').read_text(encoding='utf-8'))
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('First status>=04:36:58UTC; run ID pending the initial spaced query.','CI42447193207 active; observe at/after the cached next-check bound.')
needle='   normal-settings timing/speedup claim or automatic scalar/value rewrite.\n';assert needle in s
s=s.replace(needle,needle+'''   B444 launched04:43:09UTC; observe after04:46:09.852431UTC. Short owned RAM
   fixtures /dev/shm/lython-b444, persistent source/trace/worker under native-cost-
   b444-20261108. No second capture/restart on an observation timeout.
''')
s=s.replace('per-move tokens. Existing bridges remain justified.', 'per-move tokens. Both dev55 package SHAs rechecked bit-identical04:45UTC; no\nnew supplied version or repeat qualification. Existing bridges remain justified.')
p.write_text(s,encoding='utf-8',newline='\n');(r/'producer-recheck.json').write_text(json.dumps(dict(version='0.5.0-dev.55',bothPackageSHAsMatchQualifiedR68=True,newPackageSupplied=False,repeatQualification=False,scope='Read-only filename/SHA comparison; no sibling source edits/builds, normal pin unchanged.'),indent=2)+'\n',encoding='utf-8')
print('PLAN records live B444 bounds, actual R79 CI handle, and unchanged immutable producer; no duplicate qualification.')
