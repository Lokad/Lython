from pathlib import Path
import hashlib,json,statistics,tarfile
r=Path(__file__).resolve().parent
n=r.parent/'namespace-r81'
summary={}
for api in ['warm-sync','warm-async']:
 d=json.loads((n/api/'measurements.json').read_text(encoding='utf-8'))
 assert all(d[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 summary[api]=[dict(case=o['caseId'],allocationPerJobMedian=statistics.median(s['allocatedBytes']/s['jobs'] for s in o['samples']),executionMillisecondsPerJobMedian=statistics.median(s['executionMilliseconds']/s['jobs'] for s in o['samples']),executionMillisecondsPerJobRange=[min(s['executionMilliseconds']/s['jobs'] for s in o['samples']),max(s['executionMilliseconds']/s['jobs'] for s in o['samples'])]) for o in d['observations']]
summary['conclusion']='No material allocation benefit from function locals; elapsed unstable and altered namespace semantics. Insufficient evidence for module-namespace redesign; no runtime change or CPU benefit claimed.'
(n/'assessment.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
out=Path('benchmarks/results/2026-11-08-execution-attribution');out.mkdir(exist_ok=True)
with tarfile.open(out/'observations.tar.xz','w:xz') as archive:
 for root,label in [(r,'cost-r80'),(n,'namespace-r81')]:
  for p in sorted(root.rglob('*')):
   if p.is_file() and not any(part in ['images','retrieved','__pycache__'] for part in p.relative_to(root).parts) and p.name!='payload.tgz':
    archive.add(p,arcname=f'{label}/{p.relative_to(root).as_posix()}')
with tarfile.open(out/'observations.tar.xz') as a:
 for member in a.getmembers():
  assert member.isfile()
  name=member.name.split('/',1);p=({'cost-r80':r,'namespace-r81':n}[name[0]]/name[1])
  assert hashlib.sha256(a.extractfile(member).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
print('Preserved/verified current profile, raw VM archive, same-core contrasts and failed/adverse observations:',(out/'observations.tar.xz').stat().st_size)
p=Path('benchmarks/results/2026-11-08-native-workstate/README.md')
s=p.read_text(encoding='utf-8');s+='\nFinal committed913ea550 delivery is fully green: [cached CI42447193207](delivery-ci.json),\nWindows/Ubuntu Release actual .NET11/.NET10, original Stress and installed core\npackage consumers. This qualifies that source, not later runtime work.\n';p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('R79 /913ea550 committed/pushed, delivery dispatched','R79 /913ea550 fully qualified CI42447193207').replace('Full final delivery dispatched; first status>=04:36:58UTC.','Full Windows/Ubuntu actual11/10, original Stress and installed consumers pass; cached terminal receipt.').replace('Latest fully qualified runtime5b9d569a','Latest fully qualified runtime913ea550').replace('Never requery/re-dispatch terminal runs or imply that this qualifies later R79.','Never requery/re-dispatch terminal runs or imply that this qualifies later changes.')
start=s.index('1. R79 committed/pushed');end=s.index('3. Continue independent',start)
s=s[:start]+'''1. R79 delivery complete/cached:913ea550, CI42447193207, both platforms actual
   .NET11/10, original Stress and installed core consumers. Accepted small CSV
   debt remains explicit; no duplicate qualification or further R79 retiming.
2. R80/R81 current attribution gate complete, evidence preserved separately.
   B444:1083guest CPU samples/5.45CPU-s,49unknown; diagnostic perf/JIT overrides,
   not normal timing. Dispatch21.0%, inputs5.6%, scan4.6%, hash4.4%, local-result
   publication3.5%, native selector3.4%, integer add2.0% self. Split already batches
   admission; no universal scalar or speculative reservation redesign selected.
   Same-core text/CSV module/function contrast has <0.05% extra allocation in
   function form and unstable elapsed; different namespace semantics preclude a
   compiler wrapping trick. Insufficient evidence for namespace redesign.
   Next select a complete removable dispatch/construction phase from current
   source; record hypothesis, displaced work, affected scripts, semantic/current
   cancellation/shared-admission criteria and bounded source pair with controls.
   Preserve adverse observations, exact sources and architectural/CPU distinction.
''' +s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
