from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent/'text-cost-r63';current=r.parent/'activation-r79';root='native-cost-b444-20261108';fixtures='/dev/shm/lython-b444'
identity=json.loads((current/'source-pair/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity['productionSources'].items())
shutil.copyfile(current/'source-pair/catalog.json',r/'catalog.json');shutil.copyfile(current/'source-pair/source.patch',r/'source.patch')
aux=json.loads((current/'b443/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
d=dict(sourceRevision='913ea550',files={'Lokad.Lython.dll':identity['coreSHA256']['candidate']},auxiliaryFiles=aux,productionSources=identity['productionSources'],qualification='140internal/326public per actual11/10; full CI42447193207 running. Actual original source18b563e9; source inventory matches committed913ea550.',purpose='One bounded current whole-text CPU attribution; no source-pair timing/performance claim.')
(r/'identity.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for n in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('text-cost-b419-20261107',root).replace('lython-b419-text-cost-20261107','lython-b444-native-cost-20261108')
 if n=='ops-profile.py':s=s.replace('str(candidate/"guest-fixtures")',repr(fixtures))
 if n=='retrieve.py':s=s.replace("(root/'guest-fixtures').exists()", "Path('"+fixtures+"').exists()")
 (r/n).write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
s=(old/'run.sh').read_text(encoding='utf-8').replace('text-cost-b419-20261107',root).replace('export TMPDIR="$root/guest-fixtures"','export TMPDIR='+fixtures)
s=s.replace('python3 "$root/archive.py"\n','').replace("Path('/home/lokad/lython-bench-checks/"+root+"/guest-fixtures')","Path('"+fixtures+"')")
s=s.replace('python3 "$root/ops-profile.py"', 'findmnt -T "'+fixtures+'" -o TARGET,SOURCE,FSTYPE,OPTIONS > "$root/fixture-filesystem.txt"\npython3 "$root/ops-profile.py"')
s+='python3 "$root/archive.py"\n';(r/'run.sh').write_text(s,encoding='utf-8',newline='\n')
archive=r'''from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/native-cost-b444-20261108')
assert all(json.loads((root/n).read_text())['gate']['quiet']for n in ['machine-before.json','machine-after.json'])
assert not Path('/dev/shm/lython-b444').exists()
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
record=json.loads((root/'profiles/text-warm/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
assert record['verificationBefore']['status']=='Equivalent'and record['verificationAfter']['status']=='Equivalent'
assert (root/'profiles/text-warm/worker.stderr').stat().st_size==0
seconds=record['response']['elapsedTicks']/record['response']['clockFrequency'];assert seconds<8
with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as a:
 for p in sorted(root.rglob('*')):
  if p.is_file()and p.name!='observations.tgz'and 'candidate'not in p.relative_to(root).parts:a.add(p,arcname=p.relative_to(root).as_posix())
 a.add(root/'candidate/Lokad.Lython.dll',arcname='current-core.dll')
with tarfile.open(root/'observations.tgz')as a:assert json.loads(a.extractfile('profiles/text-warm/record.json').read())['exitCode']==0
result=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,capturedSeconds=seconds,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
(r/'archive.py').write_text(archive,encoding='utf-8',newline='\n');ast.parse(archive)
contract='''R80 current whole-script attribution gate. One maintained synchronous text-summary/helpers job, source913ea550/core18b563e9. Reuse R63checked worker/perf199Hz CPU-clock/FP protocol:6guest-second warmup(max64x1024),2s settle,6s wall capture, named guest tids by CPU delta, all-thread raw stacks/maps/unknowns retained. PerfMap3 and five existing JIT listings are diagnostic overrides; no normal-settings timing/CPU speedup or adding inclusive shares. Separate useful tokenization/hash/numeric/update work from removable dispatch/transport/collection phases. Preserve actualReady/core/allaux/source/pre/post fullgoldens/Closed/exit/join/quiet/archive gates. Persistent logs/catalog/cores/perf; separate short owned128MiB RAM fixture path avoids diagnostic socket-length assumptions. Await workers/maps/perf reads, copy/verify temporary maps, remove RAM mount, archive underlease and independently locally.120s owner+30s stop+30s margin. Source/compiled package qualification separate; R79fullCI runs independently, publication postponed. Stop at one justified substantial phase or explicit insufficient attribution; no open-ended profile sweep, no universal tagged-value/arena or per-name kernel by assumption. Preserve cancellation/shared allowance/aliases and managed safety in any selected redesign.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','pre-measurement-plan.md']:a.add(r/n,arcname=n)
print('One six-second current CPU gate prepared with existing tools; short owned RAM fixtures, persistent evidence, explicit diagnostic-only overrides.')
