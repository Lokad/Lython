from pathlib import Path
import re,collections,json,bisect
r=Path(__file__).parent;p=r/'retrieved/profiles/text-warm'
maps=[]
for line in (p/'perf.map').read_text(encoding='utf-8').splitlines():
 a,size,name=line.split(' ',2)
 if '::ExecuteInstructionPrefix(' in name and '[OptimizedTier1]' in name:maps.append((int(a,16),int(size,16),name))
assert len(maps)==1,maps
start,size,_=maps[0];offsets=collections.Counter()
for line in (p/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
 m=re.match(r'\s*\d+/(\d+)\s+([0-9a-f]+)',line)
 if m and m[1]=='3389089' and start<=int(m[2],16)<start+size:offsets[int(m[2],16)-start]+=1
jit=(p/'call-jit.txt').read_text(encoding='utf-8');sections=jit.split('; Assembly listing for method ')
section=next(s for s in sections if s.startswith('Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(') and s.splitlines()[0].endswith('(Tier1)'))
blocks=[]
for m in re.finditer(r'(G_M\d+_IG\d+):\s*;; offset=0x([0-9A-Fa-f]+)',section):blocks.append((int(m[2],16),m[1],m.start()))
grouped=collections.Counter();starts=[b[0] for b in blocks]
for offset,n in offsets.items():grouped[bisect.bisect_right(starts,offset)-1]+=n
out=[]
for i,n in grouped.most_common(14):
 b=blocks[i];text=section[b[2]:blocks[i+1][2] if i+1<len(blocks) else len(section)]
 out.append(dict(samples=n,offset=hex(b[0]),block=b[1],instructions=text))
(r/'prefix-offsets.json').write_text(json.dumps(dict(samples=sum(offsets.values()),size=size,blocks=out),indent=2)+'\n',encoding='utf-8')
for row in out[:8]:print(row['samples'],row['offset'],row['instructions'][:1200])
