import json,subprocess,os,fcntl,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
s=Path('/home/lokad/lython-bench-checks/json-default-dumps-22648c5a');revision='22648c5a364877801ff9c11ba6bdc6fb75d631c7'
dotnet='/home/lokad/lython-bench-toolchains/dotnet/10.0.401/dotnet'
env=dict(os.environ,DOTNET_ROOT=str(Path(dotnet).parent),DOTNET_NOLOGO='1',DOTNET_CLI_TELEMETRY_OPTOUT='1',MSBUILDDISABLENODEREUSE='1',DOTNET_CLI_USE_MSBUILD_SERVER='0',GIT_TERMINAL_PROMPT='0')
r={'state':'Starting','baseRevision':revision,'candidateKind':'four frozen runtime files on immutable base; working snapshot','startedUtc':datetime.now(timezone.utc).isoformat()}
def save():(s/'preparation.json').write_text(json.dumps(r,indent=2)+'\n')
def run(args,cwd=None,log=None):
    x=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    if log:(s/log).write_text(x.stdout+x.stderr)
    if x.returncode:raise RuntimeError(str(args[:2])+':'+(x.stderr or x.stdout)[-1800:])
    return x.stdout.strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save()
try:
    with Path('/home/lokad/lython-bench-checks/comparison-vm.lock').open('a+') as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        root=s/'source';root.mkdir();run(['git','init','-q',str(root)])
        run(['git','-C',str(root),'remote','add','origin','https://github.com/Lokad/Lython.git'])
        run(['git','-C',str(root),'fetch','--depth=1','--filter=blob:none','origin',revision],log='fetch.log')
        run(['git','-C',str(root),'config','core.sparseCheckout','true'])
        (root/'.git/info/sparse-checkout').write_text('/*\n!/*/\n/src/\n/benchmarks/Lokad.Lython.Benchmarks/\n/benchmarks/scripts/\n/benchmarks/cpython-worker.py\n/third_party/\n')
        run(['git','-C',str(root),'checkout','--detach',revision],log='checkout.log');assert not run(['git','-C',str(root),'status','--porcelain'])
        launch=s/'build-launch';launch.mkdir();(launch/'global.json').write_text(json.dumps({'sdk':{'version':'10.0.401','rollForward':'disable'}}))
        project=root/'benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj'
        r['state']='BuildingBaseline';save()
        run([dotnet,'build',str(project),'-c','Release','-v','minimal','-nodeReuse:false'],cwd=launch,log='build-baseline.log')
        assert not run(['git','-C',str(root),'status','--porcelain'])
        output=project.parent/'bin/Release/net10.0';baseline=s/'baseline-worker';shutil.copytree(output,baseline)
        r.update(baselineBuildClean=True,baselineWorker=str(baseline/'Lokad.Lython.Benchmarks.dll'),baselineFiles={p.relative_to(baseline).as_posix():sha(p) for p in baseline.rglob('*') if p.is_file()});save()
        frozen=json.loads((s/'frozen-source.json').read_text())
        for item in frozen['files']:
            data=(s/item['payloadFile']).read_bytes();assert sha(s/item['payloadFile'])==item['canonicalSha256']
            (root/item['sourceFile']).write_bytes(data)
        assert sorted(run(['git','-C',str(root),'diff','--name-only']).splitlines())==sorted(item['sourceFile'] for item in frozen['files'])
        r.update(state='BuildingCandidate',root=str(root),frozenSource=frozen);save()
        run([dotnet,'build',str(project),'-c','Release','--no-restore','-v','minimal','-nodeReuse:false'],cwd=launch,log='build-candidate.log')
        worker=output/'Lokad.Lython.Benchmarks.dll'
        (s/'candidate.patch').write_text(run(['git','-C',str(root),'diff'])+'\n')
        assert all(sha(baseline/filename)==value for filename,value in r['baselineFiles'].items())
        r.update(state='Completed',completedUtc=datetime.now(timezone.utc).isoformat(),worker=str(worker),workerSha256=sha(worker),librarySha256=sha(output/'Lokad.Lython.dll'),sourceStatus=run(['git','-C',str(root),'status','--porcelain']),catalog='/home/lokad/lython-bench-checks/json-default-dumps-22648c5a/catalog.json');save()
except BaseException as error:r.update(state='Failed',error=repr(error),completedUtc=datetime.now(timezone.utc).isoformat());save();raise
