using System.Globalization;
using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Ordinary JSONEncoder instances (N38): reusable and independent, each
    // carrying authoritative mutable option values. Each operation captures
    // its effective options; subclasses read their ordinary instance state.
    internal sealed record JsonEncoderOptions(
        object SkipKeys,
        object EnsureAscii,
        object CheckCircular,
        object AllowNan,
        object SortKeys,
        object Indent);

    internal sealed class JsonEncoderObject : IPyTruthyValue, IPyRenderableValue, IPyMutableDynamicAttributes
    {
        internal JsonEncoderObject(JsonEncoderOptions options, PyString itemSeparator, PyString keySeparator, ICallable? defaultHook)
        {
            Options = options;
            ItemSeparator = itemSeparator;
            KeySeparator = keySeparator;
            DefaultHook = defaultHook;
        }

        internal JsonEncoderOptions Options { get; private set; }

        internal PyInstance? GuestOwner { get; set; }

        internal object ItemSeparator { get; private set; }

        internal object KeySeparator { get; private set; }

        internal object? DefaultHook { get; private set; }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value) => JsonEncoderMembers.TryGetMember(this, name, out value);

        public bool TrySetMember(string name, object value)
        {
            switch (name)
            {
                case "skipkeys": Options = Options with { SkipKeys = value }; break;
                case "ensure_ascii": Options = Options with { EnsureAscii = value }; break;
                case "check_circular": Options = Options with { CheckCircular = value }; break;
                case "allow_nan": Options = Options with { AllowNan = value }; break;
                case "sort_keys": Options = Options with { SortKeys = value }; break;
                case "indent": Options = Options with { Indent = value }; break;
                case "item_separator": ItemSeparator = value; break;
                case "key_separator": KeySeparator = value; break;
                case "default": DefaultHook = value; break;
                default: return false;
            }
            return true;
        }

        internal JsonDumpOptions GetDumpOptions(ExecutionContext context, LythonSourceSpan span)
        {
            object Read(string name, object fallback)
            {
                if (GuestOwner is null) return fallback;
                if (GuestOwner.TryGetAttribute(name, context, span, out var value)) return value;
                throw PyMemberAccess.CreateMissingMemberError(GuestOwner, name, span, context);
            }
            string Separator(string name, object fallback)
            {
                var value = Read(name, fallback);
                if (PyStringOps.TryAsString(value, out var text)) return text.ToString();
                throw new LythonRuntimeException("TypeError", "JSON separator must be a string", span);
            }
            object defaultMethod;
            if (GuestOwner is not null)
            {
                if (!GuestOwner.TryGetAttribute("default", context, span, out defaultMethod!))
                    throw PyMemberAccess.CreateMissingMemberError(GuestOwner, "default", span, context);
            }
            else
            {
                JsonEncoderMembers.TryGetMember(this, "default", out defaultMethod!);
            }
            return new JsonDumpOptions(
                LythonRuntime.IsTruthy(Read("skipkeys", Options.SkipKeys)),
                LythonRuntime.IsTruthy(Read("ensure_ascii", Options.EnsureAscii)),
                LythonRuntime.IsTruthy(Read("check_circular", Options.CheckCircular)),
                LythonRuntime.IsTruthy(Read("allow_nan", Options.AllowNan)),
                JsonModule.ParseJsonIndent(Read("indent", Options.Indent), span),
                Separator("item_separator", ItemSeparator),
                Separator("key_separator", KeySeparator),
                defaultMethod as ICallable ?? new JsonInvalidDefaultCallable(defaultMethod),
                LythonRuntime.IsTruthy(Read("sort_keys", Options.SortKeys)));
        }

        private sealed class JsonInvalidDefaultCallable(object value) : ICallable
        {
            public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
                => throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(value, context) + "' object is not callable", span);
        }

        public bool IsTruthy() => true;

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<json.encoder.JSONEncoder object>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public object Encode(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "JSONEncoder.encode() takes exactly one argument (" + arguments.Length + " given).", span);
            }

            context.CheckExecution(span);
            return JsonModule.SerializeJsonText(arguments[0], GetDumpOptions(context, span), context, span);
        }

        public async ValueTask<object> EncodeAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
                throw new LythonRuntimeException("TypeError", "JSONEncoder.encode() takes exactly one argument (" + arguments.Length + " given).", span);
            context.CheckExecution(span);
            return await JsonModule.SerializeJsonTextAsync(arguments[0], GetDumpOptions(context, span), context, span).ConfigureAwait(false);
        }

        public object IterEncode(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "JSONEncoder.iterencode() takes exactly one argument (" + arguments.Length + " given).", span);
            }

            context.CheckExecution(span);
            var iterator = new JsonEncodeIterator(arguments[0], GetDumpOptions(context, span), context, span);
            return iterator;
        }

        // The base default() is not a fallback call to encode(): even an
        // otherwise encodable value fails here unless a default= hook (or an
        // N39 override) supplies the behavior.
        public static object Default(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "JSONEncoder.default() takes exactly one argument (" + arguments.Length + " given).", span);
            }

            throw new LythonRuntimeException("TypeError", "Object of type " + JsonDefaultTypeName(arguments[0], context) + " is not JSON serializable", span);
        }

        internal static string JsonDefaultTypeName(object value, ExecutionContext context)
            => value switch
            {
                PyString => "str",
                PyBytes => "bytes",
                PyList => "list",
                PyDict => "dict",
                PyTuple => "tuple",
                PySet => "set",
                bool => "bool",
                _ when Numbers.PyNumberOps.IsInteger(value) => "int",
                double => "float",
                PyDecimal => "Decimal",
                PyNone or null => "NoneType",
                PyInstance instance => instance.Type.Name,
                _ => UnboundTypeMethod.PythonTypeName(value, context),
            };
    }

    // The stable json.JSONEncoder class identity: construction binds the
    // keyword-only dump options while module-function layouts stay
    // positional-first on their own signatures. Cached by the module, so
    // identity and isinstance agree across direct, imported and aliased
    // references.
    internal sealed class JsonEncoderClass : ICallable, INamedRuntimeCallable, IPyRenderableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        public static readonly JsonEncoderClass Instance = new();

        private JsonEncoderClass()
        {
        }

        public string Name => "json.JSONEncoder";

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__" || name == "__qualname__")
            {
                value = PyString.FromString("JSONEncoder");
                return true;
            }

            if (name == "__module__")
            {
                value = PyString.FromString("json.encoder");
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public bool TryGetMember(string memberName, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            _ = context;
            _ = span;
            return TryGetMember(memberName, out value);
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return BindEncoderOptions(arguments, span, context);
        }

        internal static JsonEncoderObject BindEncoderOptions(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            object skipKeys = false;
            object ensureAscii = true;
            object checkCircular = true;
            object allowNan = true;
            object sortKeys = false;
            object indent = PyNone.Instance;
            object separators = PyNone.Instance;
            var hasSeparators = false;
            ICallable? defaultHook = null;
            var positional = 0;
            foreach (var argument in arguments)
            {
                if (argument.IsPositional)
                {
                    positional++;
                    continue;
                }

                switch (argument.KeywordName)
                {
                    case "skipkeys":
                        skipKeys = argument.Value;
                        break;
                    case "ensure_ascii":
                        ensureAscii = argument.Value;
                        break;
                    case "check_circular":
                        checkCircular = argument.Value;
                        break;
                    case "allow_nan":
                        allowNan = argument.Value;
                        break;
                    case "sort_keys":
                        sortKeys = argument.Value;
                        break;
                    case "indent":
                        indent = argument.Value;
                        break;
                    case "separators":
                        separators = argument.Value;
                        hasSeparators = true;
                        break;
                    case "default":
                        defaultHook = JsonModule.OptionalJsonCallable(argument.Value, "default", span);
                        break;
                    default:
                        throw new LythonRuntimeException("TypeError", "JSONEncoder.__init__() got an unexpected keyword argument '" + argument.KeywordName + "'", span);
                }
            }

            if (positional > 0)
            {
                throw new LythonRuntimeException("TypeError", "JSONEncoder.__init__() takes 1 positional argument but " + (positional + 1) + " were given.", span);
            }

            _ = JsonModule.ParseJsonIndent(indent, span);
            var parsedSeparators = JsonModule.ParseJsonSeparators(hasSeparators ? separators : PyNone.Instance, !ReferenceEquals(indent, PyNone.Instance), span, context);
            return new JsonEncoderObject(
                new JsonEncoderOptions(skipKeys, ensureAscii, checkCircular, allowNan, sortKeys, indent),
                PyString.FromString(parsedSeparators.ItemSeparator),
                PyString.FromString(parsedSeparators.KeySeparator),
                defaultHook);
        }

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<class 'json.JSONEncoder'>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
    }

    internal static class JsonEncoderMembers
    {
        public static bool TryGetMember(JsonEncoderObject encoder, string name, [MaybeNullWhen(false)] out object value)
        {
            switch (name)
            {
                case "encode":
                    value = BoundCallable.Create((arguments, span, context) => encoder.Encode(arguments, span, context), LythonKnownCallableSignatures.JsonEncoderEncode, (arguments, span, context) => encoder.EncodeAsync(arguments, span, context));
                    return true;
                case "iterencode":
                    value = BoundCallable.Create((arguments, span, context) => encoder.IterEncode(arguments, span, context), LythonKnownCallableSignatures.JsonEncoderIterencode);
                    return true;
                case "default":
                    value = encoder.GuestOwner is null && encoder.DefaultHook is not null
                        ? encoder.DefaultHook
                        : BoundCallable.Create(JsonEncoderObject.Default, LythonKnownCallableSignatures.JsonEncoderDefault);
                    return true;
                case "skipkeys":
                    value = encoder.Options.SkipKeys;
                    return true;
                case "ensure_ascii":
                    value = encoder.Options.EnsureAscii;
                    return true;
                case "check_circular":
                    value = encoder.Options.CheckCircular;
                    return true;
                case "allow_nan":
                    value = encoder.Options.AllowNan;
                    return true;
                case "sort_keys":
                    value = encoder.Options.SortKeys;
                    return true;
                case "indent":
                    value = encoder.Options.Indent;
                    return true;
                case "item_separator":
                    value = encoder.ItemSeparator;
                    return true;
                case "key_separator":
                    value = encoder.KeySeparator;
                    return true;
                default:
                    value = MissingMemberValue.Instance;
                    return false;
            }
        }
    }

    // Genuinely incremental encoder traversal: an explicit-stack machine over
    // the same rendering helpers as encode(), so joined chunks equal encode()
    // output exactly while each advance visits only what its chunk needs. A
    // container opener is consumable before later elements (and their default
    // hooks) are visited. Per-advance scratch is scope-bound; sort scratch
    // spanning yields is pool-tracked for drop safety (see GrowScratch).
    internal sealed class JsonEncodeIterator : PyIteratorBase
    {
        private sealed class EmitFrame
        {
            public bool IsList;
            public object Container = null!;
            public IEnumerator<object>? ListItems;
            public IEnumerator<KeyValuePair<object, object>>? DictPairs;
            public List<(object OriginalKey, object Value)>? SortedEntries;
            public int SortedIndex;
            public int Index;
            public int Depth;
            public long ScratchBytes;
            public bool Opened;
        }

        private readonly JsonDumpOptions _options;
        private readonly ExecutionContext _context;
        private readonly LythonSourceSpan _span;
        private readonly Stack<EmitFrame> _stack = new();
        private readonly HashSet<object>? _markers;
        private object? _rootValue;
        private bool _hasRoot;
        private long _scratchBytes;
        private bool _finished;

        public JsonEncodeIterator(object value, JsonDumpOptions options, ExecutionContext context, LythonSourceSpan span)
        {
            _rootValue = value;
            _hasRoot = true;
            _options = options;
            _context = context;
            _span = span;
            _markers = options.CheckCircular ? new HashSet<object>(ReferenceEqualityComparer.Instance) : null;
            PyIteratorBase.ChargeIteratorValue(context.MemoryGovernor, span);
        }

        public override PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<json.encoder._iterencode object>");
        }

        public override bool TryMoveNext([MaybeNullWhen(false)] out object value)
        {
            var result = TryMoveNextCoreAsync(false).GetAwaiter().GetResult();
            value = result.HasValue ? result.Value : PyNone.Instance;
            return result.HasValue;
        }

        public override ValueTask<PyIterationResult> TryMoveNextAsync() => TryMoveNextCoreAsync(true);

        private async ValueTask<PyIterationResult> TryMoveNextCoreAsync(bool asynchronous)
        {
            _context.CheckExecution(_span);
            if (_finished)
            {
                return PyIterationResult.End;
            }

            try
            {
                using var charge = new JsonModule.JsonGrowthCharge(_context.MemoryGovernor, _span);
                var builder = new StringBuilder();
                while (true)
                {
                    _context.CheckExecution(_span);
                    var (advanced, chunkReady) = await AdvanceAsync(builder, charge, asynchronous).ConfigureAwait(false);
                    if (!advanced)
                    {
                        DiscardScratch();
                        _finished = true;
                        return PyIterationResult.End;
                    }

                    if (!chunkReady || builder.Length == 0)
                    {
                        continue;
                    }

                    // Fund the UTF-16 copy below like the eager path, then
                    // transfer ownership to the retained chunk itself.
                    charge.Grow(builder.Length);
                    var chunk = LythonRuntime.CreateString(builder.ToString(), _context, _span);
                    return PyIterationResult.Yield(chunk);
                }
            }
            catch (InvalidOperationException ex)
            {
                DiscardScratch();
                _finished = true;
                throw new LythonRuntimeException("TypeError", ex.Message, _span);
            }
            catch
            {
                DiscardScratch();
                _finished = true;
                throw;
            }
        }

        private void GrowScratch(long bytes)
        {
            if (bytes <= 0)
            {
                return;
            }

            var pool = _context.Services.State.MemoryGovernor;
            _context.MemoryGovernor.Reserve(bytes, _span);

            _context.MemoryGovernor.Commit(bytes);
            _scratchBytes += bytes;
        }

        private void ReleaseScratch(long bytes)
        {
            if (bytes <= 0)
            {
                return;
            }

            _context.MemoryGovernor.Release(bytes);
            _scratchBytes -= bytes;
            if (_scratchBytes < 0)
            {
                _scratchBytes = 0;
            }
        }

        private void DiscardScratch()
        {
            if (_scratchBytes > 0)
            {
                _context.MemoryGovernor.Release(_scratchBytes);
                _scratchBytes = 0;
            }
        }

        // Advances the machine; true means more work remains (with a complete
        // chunk when chunkReady). Structural order mirrors the eager renderer
        // exactly: separators, indent prefixes, keys and values concatenate to
        // the same text encode() produces.
        private async ValueTask<(bool Advanced, bool ChunkReady)> AdvanceAsync(StringBuilder builder, JsonModule.JsonGrowthCharge charge, bool asynchronous)
        {
            var chunkReady = false;
            if (_hasRoot)
            {
                _hasRoot = false;
                return await AdvanceValueAsync(_rootValue!, 0, builder, charge, asynchronous).ConfigureAwait(false);
            }

            while (_stack.Count > 0)
            {
                var frame = _stack.Peek();
                if (!frame.Opened)
                {
                    frame.Opened = true;
                    if (_markers is not null && !_markers.Add(frame.Container))
                    {
                        throw new LythonRuntimeException("ValueError", "Circular reference detected.", _span);
                    }

                    builder.Append(frame.IsList ? '[' : '{');
                    chunkReady = true;
                    return (true, chunkReady);
                }

                if (frame.IsList)
                {
                    if (frame.ListItems is null || !frame.ListItems.MoveNext())
                    {
                        CloseFrame(frame);
                        if (frame.Index > 0)
                        {
                            JsonModule.AppendJsonContainerSuffix(builder, _options, frame.Depth, charge, _context, _span);
                        }

                        builder.Append(']');
                        chunkReady = true;
                        return (true, chunkReady);
                    }

                    var element = frame.ListItems.Current;
                    if (frame.Index > 0)
                    {
                        JsonModule.AppendSeparator(builder, _options.ItemSeparator, charge);
                    }

                    AppendPrettyPrefix(builder, frame.Depth + 1, charge);
                    frame.Index++;
                    return await AdvanceValueAsync(element, frame.Depth + 1, builder, charge, asynchronous).ConfigureAwait(false);
                }

                if (!TryTakePair(frame, out var key, out var pairValue))
                {
                    CloseFrame(frame);
                    if (frame.Index > 0)
                    {
                        JsonModule.AppendJsonContainerSuffix(builder, _options, frame.Depth, charge, _context, _span);
                    }

                    builder.Append('}');
                    chunkReady = true;
                    return (true, chunkReady);
                }

                if (frame.Index > 0)
                {
                    JsonModule.AppendSeparator(builder, _options.ItemSeparator, charge);
                }

                AppendPrettyPrefix(builder, frame.Depth + 1, charge);
                if (!JsonModule.TryConvertJsonObjectKey(key, skipKeys: false, out var keyText))
                {
                    throw new InvalidOperationException("json.dumps() requires dictionary keys to be strings, numbers, booleans, or None.");
                }

                JsonModule.AppendJsonString(builder, keyText, _options.EnsureAscii, charge, _context, _span);
                JsonModule.AppendSeparator(builder, _options.KeySeparator, charge);
                frame.Index++;
                return await AdvanceValueAsync(pairValue, frame.Depth + 1, builder, charge, asynchronous).ConfigureAwait(false);
            }

            return (false, false);
        }

        private async ValueTask<(bool Advanced, bool ChunkReady)> AdvanceValueAsync(object value, int depth, StringBuilder builder, JsonModule.JsonGrowthCharge charge, bool asynchronous, int defaultDepth = 0)
        {
            var chunkReady = false;
            _context.CheckExecution(_span);
            if (depth >= ExecutionLimits.MaxInterpreterDepth || defaultDepth >= ExecutionLimits.MaxInterpreterDepth)
            {
                throw RuntimeErrors.Attributed(
                    "RecursionError",
                    "maximum recursion depth exceeded while encoding a JSON object",
                    _span, LythonFailureReason.InterpreterStackLimit, ExecutionLimits.MaxInterpreterDepth,
                    Math.Max(depth, defaultDepth));
            }

            switch (value)
            {
                case PyNone:
                    builder.Append("null");
                    chunkReady = true;
                    return (true, chunkReady);
                case PyString text:
                    JsonModule.AppendJsonString(builder, text.AsString(), _options.EnsureAscii, charge, _context, _span);
                    chunkReady = true;
                    return (true, chunkReady);
                case bool boolean:
                    builder.Append(boolean ? "true" : "false");
                    chunkReady = true;
                    return (true, chunkReady);
                case BigInteger integer:
                    _context.CheckExecution(_span);
                    JsonModule.AppendJsonNumber(builder, integer.ToString(CultureInfo.InvariantCulture), charge, _context, _span);
                    chunkReady = true;
                    return (true, chunkReady);
                case int integer:
                    JsonModule.AppendJsonNumber(builder, integer.ToString(CultureInfo.InvariantCulture), charge, _context, _span);
                    chunkReady = true;
                    return (true, chunkReady);
                case double floating:
                    JsonModule.AppendJsonDouble(builder, floating, _options, charge, _context, _span);
                    chunkReady = true;
                    return (true, chunkReady);
                case PyDecimal decimalValue:
                    JsonModule.AppendJsonNumber(builder, PyDecimalOps.Format(decimalValue), charge, _context, _span);
                    chunkReady = true;
                    return (true, chunkReady);
                case PyList list:
                    PushListFrame(list, list.GetEnumerator(), depth);
                    return (true, chunkReady);
                case PyTuple tuple:
                    PushListFrame(tuple, tuple.GetEnumerator(), depth);
                    return (true, chunkReady);
                case PyDict dict:
                    PushDictFrame(dict, depth);
                    return (true, chunkReady);
                case PyCounter counter:
                    PushDictFrame(counter.InnerDict, depth);
                    return (true, chunkReady);
                case PyDefaultDict defaultDict:
                    PushDictFrame(defaultDict.InnerDict, depth);
                    return (true, chunkReady);
                default:
                    if (_options.DefaultCallable is null)
                    {
                        throw new InvalidOperationException($"Unsupported json.dumps value type: {JsonModule.JsonValueTypeName(value)}");
                    }

                    var replacement = await JsonModule.InvokeJsonCallbackCoreAsync(_options.DefaultCallable, value, _context, _span, asynchronous).ConfigureAwait(false);
                    if (ReferenceEquals(replacement, value))
                    {
                        throw new LythonRuntimeException("ValueError", "json.dumps default returned the original unsupported object.", _span);
                    }

                    // Replacements that keep producing fresh unsupported
                    // objects carry their own depth budget like the eager
                    // path instead of recursing past the container guard.
                    return await AdvanceValueAsync(replacement, depth, builder, charge, asynchronous, defaultDepth + 1).ConfigureAwait(false);
            }
        }

        private void AppendPrettyPrefix(StringBuilder builder, int depth, JsonModule.JsonGrowthCharge charge)
        {
            if (_options.IndentUnit is null)
            {
                return;
            }

            JsonModule.AppendJsonValuePrefix(builder, _options, depth, 0, charge, _context, _span);
        }

        private void PushListFrame(object container, IEnumerator<object> items, int depth)
        {
            _stack.Push(new EmitFrame
            {
                IsList = true,
                Container = container,
                ListItems = items,
                Depth = depth,
            });
        }

        private void PushDictFrame(PyDict dict, int depth)
        {
            var frame = new EmitFrame
            {
                IsList = false,
                Container = dict,
                Depth = depth,
            };

            if (!_options.SortKeys)
            {
                frame.DictPairs = dict.GetEnumerator();
                _stack.Push(frame);
                return;
            }

            // Sorting retains one reference pair per entry beside the live
            // dict; fund that scratch before building it like the eager path.
            var estimate = checked(32L * dict.Count);
            GrowScratch(estimate);
            try
            {
                var entries = JsonModule.CollectSortedJsonEntries(dict, _context, _span);
                frame.SortedEntries = entries;
                frame.ScratchBytes = estimate;
                _stack.Push(frame);
            }
            catch
            {
                ReleaseScratch(estimate);
                throw;
            }
        }

        private bool TryTakePair(EmitFrame frame, out object key, out object value)
        {
            while (true)
            {
                if (frame.SortedEntries is not null)
                {
                    if (frame.SortedIndex >= frame.SortedEntries.Count)
                    {
                        key = PyNone.Instance;
                        value = PyNone.Instance;
                        return false;
                    }

                    var entry = frame.SortedEntries[frame.SortedIndex++];
                    if (!JsonModule.IsSupportedJsonObjectKey(entry.OriginalKey))
                    {
                        if (_options.SkipKeys) continue;
                        throw new InvalidOperationException("json.dumps() requires dictionary keys to be strings, numbers, booleans, or None.");
                    }
                    key = entry.OriginalKey;
                    value = entry.Value;
                    return true;
                }

                if (frame.DictPairs is null || !frame.DictPairs.MoveNext())
                {
                    key = PyNone.Instance;
                    value = PyNone.Instance;
                    return false;
                }

                var pair = frame.DictPairs.Current;
                if (!JsonModule.IsSupportedJsonObjectKey(pair.Key))
                {
                    if (_options.SkipKeys)
                    {
                        continue;
                    }

                    throw new InvalidOperationException("json.dumps() requires dictionary keys to be strings, numbers, booleans, or None.");
                }

                key = pair.Key;
                value = pair.Value;
                return true;
            }
        }

        private void CloseFrame(EmitFrame frame)
        {
            _ = _stack.Pop();
            if (_markers is not null)
            {
                _ = _markers.Remove(frame.Container);
            }

            if (frame.ScratchBytes > 0)
            {
                ReleaseScratch(frame.ScratchBytes);
                frame.ScratchBytes = 0;
            }

            frame.ListItems?.Dispose();
            frame.DictPairs?.Dispose();
        }
    }
}
