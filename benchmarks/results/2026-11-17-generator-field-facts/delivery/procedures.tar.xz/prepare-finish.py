from pathlib import Path
import json
r=Path(__file__).resolve().parent;dispatch=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'constant-record-r499/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44192474928',str(dispatch['run'])).replace('ea8e9f911fe39aa4133b2d362d8a11754469a2b1',dispatch['head']).replace('18035','18039').replace('2385','2386')
s=s.replace('all585ProductionInputsMatchMeasuredCf847936','all585ProductionInputsMatchMeasured5ae019db').replace('benchmarks/results/2026-11-17-constant-record-keys/delivery','benchmarks/results/2026-11-17-generator-field-facts/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared exact627/16summary/2386input verifier against measured5ae source.')
