from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-generator-field-facts';out.mkdir(exist_ok=False)
for n in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','reference-reuse.json','checks.json','decision.json']:
 shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
with gzip.open(out/'candidate-core.dll.gz','wb')as a:a.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or any(n in p.relative_to(r).parts for n in ['frozen','retrieved']):continue
  if p.suffix in ['.dll','.xz','.tgz','.gz']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
v=json.loads((out/'summary.json').read_text(encoding='utf-8'));v['retentionDecisionPending']=False;v['decision']=json.loads((out/'decision.json').read_text(encoding='utf-8'));(out/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Generator field facts

Private R503 on7584bcaf/core5ae019db versus qualifiedea8production/corecf847936.
Remove one compiler exclusion: function-like code, including generator expressions,
uses existing field-cache sites. No new runtime cache, owner, token, policy or
execution path. PyGenerator already creates a work state with no function lookup
owner, funds its private cache through owned workspace and detaches after awaited
cleanup. Entries retain layout/key/index, never row values; hits read live slots.
The existing conservative frame estimate includes lookup metadata; actual cache
backing is separately admitted. New sites may reject tighter allowances earlier.

B928,2026-11-17 quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/tiering,
fourjobs155.24s/six-second warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Process CPU change | Reference/candidate spread |
| --- | --- | --- | --- |
| Floating numeric report warm | −10.03..−9.16% | −9.61..−8.61% |0.15/0.82%|
| Floating compile-to-result | −13.56..−11.93% | −12.61..−11.75% |0.60/1.28%|
| Text normalization warm | −0.08..+4.00% |0..+1.63%|0.78/3.28%|
| Positional calls warm | −4.96..−0.19% |−6.67..+0.79%|4.67/0.33%|

Retain the ownership-consistent correction and named floating benefit. Preserve
text's possible adverse CPU/elapsed movement and candidate spread; call reference
maxIQR5.10%limits precision. No universal gain or recovery claim, no new CPython
ratio inferred. Allocation/peaks effectively flat; floating+0.12%/same906,686Bpeak,
all six budget baselines restore. Both actual11/10 each407internal/570public
focused checks and six exact-worker goldens pass. Four added public cases preserve
mutation/rebinding, interleaved generators, actual delayed host I/O, protocol-key
fallback, errors/close, first terminal refusal/no guest continuation and reuse.

Full Windows/Ubuntu/originalstress/installed Release package qualification is
independent/pending at this writing. Frozen images copy and verify all32recorded
files; auxiliary worker/optional adapter remain reference files. Exact cfreference
diagnostics are reused only after full hashes/catalog comparison. The unchanged
six-case catalog was verified with actual images before staging. Sources and
test snapshots identify2386inputs/585production. Rebuilt-binary equality is not
inferred. This consistency fix does not close the larger activation/operand goal.

Warm includes Run, mediated RAM I/O, goldens and prior-result cleanup; fresh adds
compile/compiled-owner disposal. Startup/reset/protocol/final cache teardown
excluded; processCPU wider. Quiet gates, joined users, persistent archive/localSHA
and fixture teardown pass. Only exact committed raw/archive replicas and the old
five-case catalog retire; currentcf/six-case catalog/toolchains preserved.254/252MiB
guards unchanged. A reused preparation kept six-job validators; the local guard
caught that before staging. Actual four-job files/caps were generated directly
from verified templates, originals retained; no failed collection or retiming.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[identity](identity.json),[source](candidate-sources.tar.xz),
[procedures/checks](procedures-and-checks.tar.xz).
Publication remains postponed; the broader runtime roadmap continues.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as h:h.write('\nR503 [generator field facts](results/2026-11-17-generator-field-facts/README.md), private5ae019db on7584 versusqualifiedcf: remove generator exclusion/use existing frame-owned caches. Fourjobs155.24s: floating warm9–10%lower/fresh12–14%lower elapsed/supportingCPU/stablecontrols; allocation/peaksflat. Textpossible0..4%elapsed/0..1.63%CPUdebt/candidate3.28%spread, callreference4.67%spread/maxIQR5.10%retain uncertainty. Both targets407internal/570public/sixgoldens/reuse pass including4new real-I/O/mutation/protocol/refusal cases. No new owner/cache/policy; retain consistent correction, full delivery independent. Original local count-validator failure caught before stage; no collection retimed. No CPython ratio inference/publication; larger objective active.\n')
guide=repo/'docs/BENCHMARKS.md';s=guide.read_text(encoding='utf-8');needle='| Reuse constant record keys |';assert needle in s
s=s.replace(needle,'| Generator field facts | Floating report warm9–10% lower/fresh12–14% lower elapsed with supporting CPU; allocation/peaks flat | Separate5ae019db versuscf847936 pair; text/call controls remain uncertain. [Evidence](../benchmarks/results/2026-11-17-generator-field-facts/README.md). Full delivery pending. |\n'+needle,1);guide.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('Active R503:');b=s.index('\n1. Bounded',a)
s=s[:a]+'''Retained R503 pending full delivery: exact measured5ae019db source integrated.
One compiler exclusion removed; existing generator workspace/cache lifetime stays.
Both targets407internal/570public/sixgoldens/reuse pass. B928155.24s: floatingwarm
9–10%lower/fresh12–14%lower elapsed/supportingCPU/stablecontrols, allocation/peaks
flat. Textpossible0..4%elapsed/0..1.63%CPUdebt with3.28%candidate spread remains;
callreference4.67%spread/maxIQR5.10%limits precision. No universal gain/CPython-ratio
claim. Earlier supplied-budget denial for new cache capacity intentional.
[Sources/decision](benchmarks/results/2026-11-17-generator-field-facts/README.md).
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Retained generator fact correction archived; full delivery pending, control debt explicit.')
