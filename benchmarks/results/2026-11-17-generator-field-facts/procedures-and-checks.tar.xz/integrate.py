from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/generator-facts-r503';f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
names=f['changedProductionFiles']+['tests/Lokad.Lython.PublicApi.Tests/GeneratorRecordLookupTests.cs'];assert len(f['changedProductionFiles'])==1
for n in names:
 assert hashlib.sha256((work/n).read_bytes()).hexdigest()==f['sourceInputs'][n],n
 shutil.copyfile(work/n,repo/n)
decision=dict(retain=True,reference='Qualifiedea8production/cf847936',candidate='PrivateR503 on7584/5ae019db',productionSourceUnchangedSinceMeasurement=True,reason='Remove inconsistent generator exclusion, reuse existing private frame/cache ownership, stable floating warm/fresh elapsed and CPU benefit with independent semantic tests.',warmElapsedImprovementPercent='9.16-10.03',freshElapsedImprovementPercent='11.93-13.56',allocation='Essentially flat,+0.12percent floating; peaks flat.',remainingDebt='Text elapsed-0.08..+4.00percent/CPU0..+1.63percent with3.28percent candidate spread; positional reference4.67percent spread/maxIQR5.10percent. No universal gain or recovery claimed.',fullQualification='Pending coherent delivery; no inherited ea8 qualification',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n');print('Integrated exact measured production and four public regressions; full delivery remains pending.')
