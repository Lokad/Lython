from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'transfer-dispatch-r501/check.py').read_text(encoding='utf-8').replace('transfer-dispatch-r501','generator-facts-r503')
s=s.replace("'ContainerDisplayPipeline'", "'ContainerDisplayPipeline','GeneratorRecordLookup'")
(r/'check.py').write_text(s,encoding='utf-8',newline='\n')
