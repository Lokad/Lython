from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent/'transfer-dispatch-r501/quiet';q=r/'quiet'
assert not(q/'launch.log').exists()
before=r/'first-prepared-count-validation'
assert q.resolve().is_relative_to(r.resolve())and before.resolve().is_relative_to(r.resolve())and not before.exists()
q.rename(before);q.mkdir()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert len(f['imageFiles']['candidate'])==32
assert all(hashlib.sha256((r/'frozen'/role/n).read_bytes()).hexdigest()==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=dict(sourceRevision='Qualifiedea8production/cf847936 versus privateR503/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Remove generator field-fact exclusion; existing private frame/cache owns key/layout facts, records supply live values. Floating warm/fresh and text/call controls, no predicted gain or new ownership layer.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:];s=re.sub(r'time.monotonic\(\)-started < \d+','time.monotonic()-started < 210',s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==4",s);s=re.sub(r'jobs=\d+','jobs=4',s);assert "len(raw['jobs'])==4"in s;(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/generator-facts-b928-20261117';unit='lython-b928-generator-facts-20261117';prior=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/record-cpython-b927-20261117',sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=re.sub(r'RuntimeMaxSec=\d+','RuntimeMaxSec=270',s).replace('lython-b926-fixtures','lython-b928-fixtures');assert 'RuntimeMaxSec=270'in s;(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'transfer-dispatch-r501/launch.py').read_text(encoding='utf-8');s=re.sub(r'seconds=\d+','seconds=230',s).replace('before280seconds','before230seconds').replace('Six-job constant-record source pair','Four-job generator-fact source pair');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8');s=re.sub(r"\['jobs'\]==\d+","['jobs']==4",s).replace('B926','B928');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'transfer-dispatch-r501/summarize.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==4",s);(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert "['jobs']==4"in(q/'retrieve.py').read_text(encoding='utf-8')and "len(raw['jobs'])==4"in(r/'summarize.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=4,collectorCapSeconds=210,serviceCapSeconds=270,sourceRole=c['sourceRole'],unpackedBytes=c['unpackedBytes'],currentSixCaseCatalogPreserved=True)))
