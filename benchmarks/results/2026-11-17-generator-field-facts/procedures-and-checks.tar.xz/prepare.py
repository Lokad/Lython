from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'constant-record-r499';old=prior/'quiet'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/'frozen'/role/n).read_bytes()).hexdigest()==h for role,files in f['imageFiles'].items()for n,h in files.items())
groups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs']
q=r/'quiet';q.mkdir(exist_ok=False)
identity=dict(sourceRevision='Committedea8e9f91/cf847936 versus privateR503/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Remove generator field-fact exclusion; existing private frame/cache owns lookup storage and live records supply values. Complete floating report warm/fresh plus text/call controls, no predicted gain or new owner.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=f['sourceInputsArchiveSHA256'],productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large', 'warm'], ['scripts.numeric-squared-error.floating.large', 'compile-run'], ['scripts.text-normalization.large', 'warm'], ['calls.positional.large', 'warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4\n'+s[b:]
s=re.sub(r'time.monotonic\(\)-started < \d+','time.monotonic()-started < 210',s)
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==4").replace('jobs=4','jobs=4');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/generator-facts-b928-20261117';unit='lython-b928-generator-facts-20261117'
config=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(config['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll')
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=config['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace('lython-b923-fixtures','lython-b928-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=270')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8').replace('seconds=200','seconds=230').replace('before200seconds','before230seconds').replace('Four-job corrected integration source pair','Six-job primary-transfer source pair');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==4").replace('B924','B928');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==4");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert "len(raw['jobs'])==4"in(q/'archive-owned.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=len(jobs),reference=f['imageFiles']['reference']['Lokad.Lython.dll'][:8],candidate=f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],unpackedBytes=c['unpackedBytes'])))
