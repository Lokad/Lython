from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
for suffix,remote in [('2026-11-17-owned-transfer-dispatch','transfer-dispatch-b926-20261117'),('2026-11-17-record-cpython-baseline','record-cpython-b927-20261117')]:
 canonical='benchmarks/results/'+suffix+'/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as a:
  for member in ['confirmation/confirmation.json','whole-archive']:
   data=blob if member=='whole-archive'else a.extractfile(member).read()
   subjects.append(dict(kind='completed-replica',path=remote+'/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-current-cpython-checkpoint/catalog.json';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();assert hashlib.sha256(blob).hexdigest()!=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['catalogSHA256']
subjects.append(dict(kind='completed-replica',path='representative-cpython-b919-20261117/representative.json',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]").replace('json-cpython-b908-20261117','record-cpython-b927-20261117')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;proofs=json.loads(p.stdout)
assert all('record-cpython-b927-20261117/representative.json'not in proof['paths']for proof in proofs)
(r/'retirement-candidates.json').write_text(json.dumps(dict(proofs=proofs,eligibleBytes=sum(p['bytes']for p in proofs),currentImageAndSixCaseCatalogPreserved=True,exactCommittedReplicasOnly=True),indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(groups=len(proofs),eligibleBytes=sum(p['bytes']for p in proofs))))
