from pathlib import Path
import ast
r=Path(__file__).resolve().parent
s=(r.parent/'transfer-dispatch-r501/prepare.py').read_text(encoding='utf-8')
s=s.replace('transfer-dispatch-b926-20261117','generator-facts-b928-20261117').replace('lython-b926-transfer-dispatch-20261117','lython-b928-generator-facts-20261117').replace('lython-b926-fixtures','lython-b928-fixtures')
s=s.replace('privateR501/','privateR503/')
s=s.replace('Collapse owned-runner secondary transfer dispatch into its existing primary loop; no new frame or transport view, native helpers unchanged. Complete text/floating warm/fresh plus record/call controls, no predicted gain.', 'Remove generator field-fact exclusion; existing private frame/cache owns lookup storage and live records supply values. Complete floating report warm/fresh plus text/call controls, no predicted gain or new owner.')
a=s.index('jobs=');b=s.index('\ns=',a);jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace('len(jobs)==6','len(jobs)==4').replace('len(raw[\'jobs\'])==6','len(raw[\'jobs\'])==4').replace("['jobs']==6","['jobs']==4").replace('jobs=6','jobs=4')
s=s.replace('time.monotonic()-started < 270','time.monotonic()-started < 210').replace('RuntimeMaxSec=330','RuntimeMaxSec=270')
s=s.replace('seconds=280','seconds=230').replace('before280seconds','before230seconds').replace('Six-job constant-record source pair','Four-job generator-fact source pair')
s=s.replace("'B924','B926'","'B924','B928'")
ast.parse(s);(r/'prepare.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared four-job changed-source gate,210s collector/270s service before staging.')
