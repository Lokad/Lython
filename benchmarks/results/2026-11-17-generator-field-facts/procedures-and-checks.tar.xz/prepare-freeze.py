from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'transfer-dispatch-r501/freeze.py').read_text(encoding='utf-8').replace('transfer-dispatch-r501','generator-facts-r503')
s=s.replace("names=list(inputs['inputs']);assert len(names)==2385", "names=list(inputs['inputs'])+['tests/Lokad.Lython.PublicApi.Tests/GeneratorRecordLookupTests.cs'];assert len(names)==2386")
s=s.replace("['git','diff','--name-only']", "['git','diff','HEAD','--name-only']").replace("['git','diff','--']", "['git','diff','HEAD','--']")
s=s.replace('len(production)==2','len(production)==1')
s=s.replace('Private R501 one two-file change onea8: collapse owned-runner secondary transfer switch into primary dispatch; direct cold member helper. Native borrowed initialization and all ownership/cancellation unchanged. Auxiliary worker/adapter remain reference copies.', 'Private R503 on7584: function-like field facts include generators; remove generator exclusion, use existing per-frame cache ownership/cleanup. One production condition and four externally observable mutation/IO/identity/refusal/reuse tests. Auxiliary worker/adapter remain reference copies.')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
