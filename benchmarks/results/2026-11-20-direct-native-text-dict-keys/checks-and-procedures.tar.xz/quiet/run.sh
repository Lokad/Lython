set -eu
root=/home/lokad/lython-bench-checks/direct-native-text-dict-keys-b1246-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
