#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/direct-native-text-dict-keys"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/direct-native-text-dict-keys"
dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --filter '(FullyQualifiedName~Dict|FullyQualifiedName~Json|FullyQualifiedName~Csv|FullyQualifiedName~Record|FullyQualifiedName~Forwarding|FullyQualifiedName~Hash)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --filter '(FullyQualifiedName~Dict|FullyQualifiedName~Json|FullyQualifiedName~Csv|FullyQualifiedName~Hash|FullyQualifiedName~CallExpansion|FullyQualifiedName~FormatMap|FullyQualifiedName~Keyword)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
