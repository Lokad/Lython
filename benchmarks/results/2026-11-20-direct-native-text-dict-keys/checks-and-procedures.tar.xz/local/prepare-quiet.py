import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "private-callsite-preparation/rebased/quiet"
donor = lab.parent / "validator-manifest-current-profile"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def sha(content):
    return hashlib.sha256(content).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def committed(path):
    return subprocess.check_output(["git", "cat-file", "blob", "bd94edeec:" + path], cwd=repo)


def retire(canonical, expected_sha, cases):
    image = gzip.decompress(committed(canonical))
    assert sha(image) == expected_sha
    archives = {}
    paths = []
    for remote, role, result in cases:
        results = f"benchmarks/results/{result}"
        receipt = json.loads(committed(f"{results}/archive-receipt.json"))
        content = committed(f"{results}/observations.tgz")
        assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
        assert receipt["archiveSHA256"] == sha(content)
        archives[f"{remote}/observations.tgz"] = receipt["archiveSHA256"]
        paths.append(f"{remote}/{role}/{core}")
    return dict(archives=archives, paths=paths, bytes=len(image), links=len(paths),
                sha256=expected_sha, verifiedCanonicalGitImage=canonical)


index = load(lab / "identity.json")
assert index["reference"].startswith("bd94edeec") and index["candidate"].startswith("c62457d49")
old = load(template / "config.json")
donor_config = load(donor / "config.json")
donor_receipt = load(donor / "archive-receipt.json")
assert donor_receipt["complete"] and donor_receipt["archivedAndVerifiedUnderLease"]
assert donor_receipt["archiveSHA256"] == file_sha(donor / "observations.tgz")
source_files = donor_config["identity"]["imageFiles"]["candidate"]
protocol_root = lab.parent / "private-stable-parameter-captures/quiet"
protocol_config = load(protocol_root / "config.json")
protocol = protocol_config["protocolSHA256"]
assert index["pythonWorkerSHA256"] == protocol
manifest = lab / "representative.json"
assert file_sha(manifest) == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(source_files) == 32
    assert set(files) == set(source_files)
    assert [n for n in files if files[n] != source_files[n]] == ([core] if role == "candidate" else [])
    assert {n: file_sha(lab / "frozen" / role / n) for n in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed"
    assert verification["catalogSha256"] == index["catalogSHA256"]

previous = load(protocol_root / "identity.json")
proposals = [
    retire(f"benchmarks/results/2026-11-20-stable-parameter-captures/measured-{role}-core.dll.gz",
           previous["coreSHA256"][role], [
               ("stable-parameter-captures-b1243-20261120", role, "2026-11-20-stable-parameter-captures"),
               ("stable-parameter-captures-confirm-b1244-20261120", role, "2026-11-20-stable-parameter-captures/confirmation"),
           ]) for role in ("reference", "candidate")
]
root = "/home/lokad/lython-bench-checks/direct-native-text-dict-keys-b1246-20261120"
unit = "lython-b1246-direct-native-text-dict-keys-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Skip protocol dispatch for exact string dictionary keys",
                catalogSHA256=index["catalogSHA256"], imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: names[core] for role, names in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
jobs = [(row["id"], "warm") for row in load(manifest)["cases"]]
assert len(jobs) == 4 and jobs[-1][0] == "scripts.config-manifest.helper-guards"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()

parts = ["identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh"]
shutil.copyfile(manifest, q / "representative.json")
for role in ("candidate",):
    (q / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, q / role / core)
    parts.append(f"{role}/{core}")
with tarfile.open(q / "payload.tgz", "w:gz") as payload:
    for part in parts:
        payload.add(q / part, arcname=part)
config = dict(root=root, unit=unit, source=donor_config["root"], sourceRole="candidate", sourceFiles=source_files,
              sourceCatalogSHA256=donor_config["catalogSHA256"], protocolSHA256=protocol, protocolSource=protocol_config["root"] + "/cpython-worker.py", catalogSHA256=index["catalogSHA256"],
              identity=identity, retireGroups=proposals, donorArchiveSHA256=donor_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / part).stat().st_size for part in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1241-fixtures", "lython-b1246-fixtures")
assert "proof['archives']" in content and "176160768+c['unpackedBytes']+64*1024*1024" in content
content = content.replace("assert sha(source/'representative.json')", "assert sha(source/'catalog.json')")
content = content.replace("source/'cpython-worker.py'", "Path(c['protocolSource'])")
assert "protocolSource" in content and "assert sha(source/'catalog.json')" in content
assert not (q / "reference").exists()
emit(q / "remote-launch.py", content)
launch = read(template.parent / "launch.py").replace("Call-site preparation comparison", "Native string dictionary comparison")
emit(lab / "launch.py", launch)
