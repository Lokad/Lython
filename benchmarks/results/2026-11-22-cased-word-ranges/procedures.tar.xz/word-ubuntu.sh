#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/cased-word-ranges-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/record-and-text-profile-20261122
white='Category!=Stress&(FullyQualifiedName~Cased|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~Whitespace|FullyQualifiedName~NativeTextConstruction)'
public='Category!=Stress&(FullyQualifiedName~Cased|FullyQualifiedName~NativeWordBinding|FullyQualifiedName~ReturnedIteration|FullyQualifiedName~Whitespace)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$dir/word-range-ubuntu" --nologo > "$dir/word-white-ubuntu.log" 2>&1 || { tail -75 "$dir/word-white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path "$dir/word-range-ubuntu" --nologo > "$dir/word-public-ubuntu.log" 2>&1 || { tail -75 "$dir/word-public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/word-white-ubuntu.log" "$dir/word-public-ubuntu.log"
