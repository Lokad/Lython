from pathlib import Path
import hashlib, json, shutil, tarfile, xml.etree.ElementTree as E

r = Path(__file__).parent
q = r / 'quiet'
out = Path('benchmarks/results/2026-11-16-finally-prefix')
out.mkdir(exist_ok=True)
receipt = json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks = [dict(file=p.name, **E.parse(p).find('t:ResultSummary/t:Counters', ns).attrib)
          for p in (r/'checks').glob('*.trx')]
assert sorted(int(x['passed']) for x in checks if x['file']!='r423-new11.trx') == [105,105,223,223]
assert all(x['failed']=='0' for x in checks)
for n in ['summary.json','allocation-summary.json','focused-checks.json','cpython-semantics.json',
          'invoice-cpython.json','facts-image-hashes.json','staging-decision.json']:
    shutil.copyfile(r/n, out/n)
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(q/n, out/n)
shutil.copyfile(r/'frozen/identity.json', out/'identity.json')
p = out/'allocation-summary.json'
v = json.loads(p.read_text(encoding='utf-8'))
v['boundary'] = ('Local complete warm jobs with reset/mediated I/O/full stdout and file goldens/'
                 'result cleanup; compilation/startup excluded. >=4/.5s warmup,3x4 observations, '
                 'natural-GC whole-process allocation counters; no elapsed/CPU claim.')
p.write_text(json.dumps(v,indent=2)+'\n', encoding='utf-8', newline='\n')
p = out/'summary.json'
v = json.loads(p.read_text(encoding='utf-8'))
v.update(retentionDecisionPending=False, retained=True, fullQualificationPending=True,
         decision=('Remove blanket finally-helper rejection using the existing exact-PC transfer. '
                   'Protected invoice warm lower with CPU support and 2.91% allocation reduction. '
                   'Fresh inconclusive; ordinary/JSON controls adverse/moving, retained as debt. '
                   'No universal improvement or broader objective completion.'))
p.write_text(json.dumps(v,indent=2)+'\n', encoding='utf-8', newline='\n')
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz') as a:
    for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:
        a.add(r/'frozen'/n, arcname='frozen/'+n)
    for p in r.iterdir():
        if p.is_file(): a.add(p,arcname='procedure/'+p.name)
    a.add(r/'checks',arcname='checks')
    for p in q.iterdir():
        if p.is_file() and p.name not in {'observations.tgz','payload.tgz','representative.json'}:
            a.add(p,arcname='quiet/'+p.name)
    for p in (r/'allocation-short').iterdir():
        if p.is_file(): a.add(p,arcname='allocation/'+p.name)
    for p in (r/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):
        a.add(p,arcname='allocation-driver/'+p.name)
    a.add(r/'inspect/Program.cs',arcname='inspector/Program.cs')
    a.add(r/'inspect/Inspect.csproj',arcname='inspector/Inspect.csproj')
print('R423 retained evidence, source images, focused checks and original conditions archived.')
