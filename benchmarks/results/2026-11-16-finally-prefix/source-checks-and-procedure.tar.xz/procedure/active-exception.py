import sys
def compute(n):
 try: return n*3
 finally: print(sys.exc_info()[1] is original)
try:
 1//0
except ZeroDivisionError as original:
 print(compute(2))
print(sys.exc_info()[1])
