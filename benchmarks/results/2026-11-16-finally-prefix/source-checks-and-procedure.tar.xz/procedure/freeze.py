from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E

r=Path(__file__).parent;f=r/'frozen';f.mkdir();images={}
base=r.parent/'regex-boundaries-r422/refinement/frozen/candidate'
for role in ['reference','candidate']:
    target=f/role;shutil.copytree(base,target)
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='8f468f0a5cde74127abf48e9f7a929272e0906a523cef4a006cd494f969f3632'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
paths+=['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.PublicApi.Tests/FinallyHelperExecutionTests.cs']
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
    for p in paths:a.add(p,arcname=p)
    for p in(r/'checks').iterdir():
        if p.is_file():a.add(p,arcname='checks/'+p.name)
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,contracts='Conservative earliest-finally native frontier replaces global finally veto. All returns/abrupt exits/direct tuple completion transfer exact PC/values to existing funded cleanup frame. No new runner, owner, dispatch, cache or policy; admission timing changes explicitly.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-short';d.mkdir();shutil.copyfile(r/'catalog.json',d/'catalog.json')
for p in(r.parent/'regex-boundaries-r422/allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):
    dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
s=(r.parent/'regex-boundaries-r422/measure-allocation.py').read_text(encoding='utf-8');(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')]
assert all(c['failed']=='0'for c in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,productionNonincrementalReleaseBuild=True,finalPublicTestBuildNoDependencies=True,frameworks=['net11.0','net10.0'],fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll']for role,v in images.items()},sourceInputs=len(paths),checks=[(c['file'],c['passed'])for c in checks]))
