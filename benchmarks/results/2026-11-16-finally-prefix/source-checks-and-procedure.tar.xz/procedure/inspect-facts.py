from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11'
for role in ['reference','candidate']:
    d=r/('facts-'+role);d.mkdir()
    for p in(r/'inspect/bin/Release/net11.0').glob('Inspect.*'):shutil.copyfile(p,d/p.name)
    core=r/'frozen'/role/'Lokad.Lython.dll';shutil.copyfile(core,d/'Lokad.Lython.dll')
    output=r/('compiler-facts-'+role+'.json')
    p=subprocess.run([sdk+'/dotnet.exe',str(d/'Inspect.dll'),str(r/'facts-catalog.json'),str(output)],env=dict(os.environ,DOTNET_ROOT=sdk),capture_output=True,text=True,encoding='utf-8',timeout=30)
    assert p.returncode==0,p.stderr
    v=json.loads(output.read_text(encoding='utf-8'));assert v['coreSHA256']==hashlib.sha256(core.read_bytes()).hexdigest()
    invoice=next(x for x in v['rows']if x['id']=='scripts.csv-invoice.finally.large')
    body=next(c for c in invoice['codes']if c['name']=='price_line')
    assert body['native']==(role=='candidate'),body
    print(role,body['native'],body['nativeEnd'],body['instructions'],body['capacity'])
(r/'facts-image-hashes.json').write_text(json.dumps({role:{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/('facts-'+role)).iterdir()if p.is_file()}for role in ['reference','candidate']},indent=2)+'\n',encoding='utf-8',newline='\n')
