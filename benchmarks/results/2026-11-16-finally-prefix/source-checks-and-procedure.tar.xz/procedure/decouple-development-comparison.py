from pathlib import Path
import json,shutil
r=Path(__file__).parent;p=r/'launch-vm.py'
shutil.copyfile(p,r/'original-require-green-launch.py')
s=p.read_text(encoding='utf-8')
a=s.index('qualified=json.loads');b=s.index("q=r/'quiet'",a)
s=s[:a]+"""delivery=json.loads((r.parent/'regex-boundaries-r422/delivery/delivery-candidate.json').read_text(encoding='utf-8'))
proof=json.loads((r.parent/'regex-boundaries-r422/delivery/source-proof.json').read_text(encoding='utf-8'))
assert delivery['head'].startswith('7d522f1f') and proof['allInputsMatchAfterExplicitUTF8NewlineNormalization'] and proof['inputCount']==592
""" +s[b:]
s=s.replace('versus qualified7d522f1f/frozen8f468f0a','versus committed7d522f1f/frozen8f468f0a; full43783452636active at staging')
s=s.replace("referenceQualificationRun='43783452636',","referenceQualificationRun='43783452636',referenceFullQualificationPendingAtStaging=True,")
p.write_text(s,encoding='utf-8',newline='\n')
(r/'staging-decision.json').write_text(json.dumps(dict(noPriorLaunchAttempt=True,removedUnnecessaryFinalCIDependency=True,reason='Focused development source pair may use committed source with recorded pending full qualification. Current8f and prototypeeee images remain; older039 exact replicas have committed full source/binary custody. No weakening of fresh UID/path/hash/all-alias, lease, quiet, ownership,254/252MiB floors or source/golden gates.',referenceRuntime='7d522f1f/8f468f0a',pendingRun='43783452636'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('No CI wait gate for focused comparison; qualification status explicit, current images and all archival/staging safeguards preserved.')
