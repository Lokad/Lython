from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent
qualified=json.loads((r.parent/'regex-boundaries-r422/delivery/ci-terminal.json').read_text(encoding='utf-8'))
assert qualified['conclusion']=='success' and qualified['headSha'].startswith('7d522f1f') and all(j['conclusion']=='success'for j in qualified['jobs'])
assert Path('benchmarks/results/2026-11-16-regex-known-boundaries/delivery/test-counts.json').exists()
q=r/'quiet';q.mkdir();old=r.parent/'regex-boundaries-r422/refinement/quiet'
root='/home/lokad/lython-bench-checks/finally-prefix-b819-20261116';unit='lython-b819-finally-prefix-20261116'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'])
images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
identity=dict(sourceRevision='R423 uncommitted'+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified7d522f1f/frozen8f468f0a',purpose='Conservative native prefix before earliest finally suite replaces whole-function exclusion; complete invoice with observable per-row cleanup warm/fresh and unchanged invoice/JSON controls. No new controller/arena/dispatch or policy.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualificationRun='43783452636',candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.finally.large','warm'],['scripts.csv-invoice.finally.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.json-summary-helpers.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=(old/n).read_text(encoding='utf-8').replace('regex-boundaries-b818-20261116','finally-prefix-b819-20261116').replace('lython-b818-regex-boundaries-20261116',unit).replace('B818','B819')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']:a.add(q/n,arcname=n)
    a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git','show',proof['custody']['commit']+':'+proof['custody']['archive']])==Path(proof['custody']['archive']).read_bytes()
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/regex-boundaries-b818-20261116',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((old/'representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
oldcode=(old/'remote-launch.py').read_text(encoding='utf-8');code=oldcode[:oldcode.index('c=')]+ 'c='+repr(c)+'\n'+oldcode[oldcode.index("b=Path("):]
code=code.replace('lython-b818-fixtures','lython-b819-fixtures')
ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8'),flush=True)
