from pathlib import Path
import json,re,subprocess,textwrap
r=Path(__file__).parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/FinallyHelperExecutionTests.cs').read_text(encoding='utf-8')
pattern=r'yield return \["([^"]+)", """\n(.*?)\n            """, ("(?:[^"\\]|\\.)*")\];'
rows=[]
for name,body,expected in re.findall(pattern,text,re.S):
    source=textwrap.dedent(body)+'\n';expected=json.loads(expected)
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],text=True,encoding='utf-8',capture_output=True,timeout=10)
    assert done.returncode==0 and done.stdout==expected,(name,done.stdout,expected,done.stderr)
    rows.append(dict(name=name,source=source,expected=expected))
assert len(rows)==11,len(rows)
(r/'cpython-semantics.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Eleven complete protected-helper programs agree with isolated CPython.')

