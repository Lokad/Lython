from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

r=Path(__file__).parent
s=(r.parent/'regex-boundaries-r422/inspect-vm.py').read_text(encoding='utf-8')
s=s.replace('2026-11-15-runtime-format-operation/source-checks-and-procedure.tar.xz','2026-11-16-regex-known-boundaries/source-checks-and-procedure.tar.xz').replace('9d071eba52291e91d609b6887195485c3e92d7e84538f8513cbe2dbd548cdbd2','0393331afcdd9bffcb3dc1b2e1764316df152a20749ec08cec0c51f6e9a1b12f').replace('format-operation-b814-20261115/reference','format-operation-b814-20261115/candidate')
(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'inspect/Program.cs').read_text(encoding='utf-8').replace('GetProperty(name, flags)!.GetValue(item)','GetProperty(name, flags)?.GetValue(item)')
(r/'inspect/Program.cs').write_text(s,encoding='utf-8',newline='\n')
print('Prepared read-only obsolete-image custody proof; retirement requires terminal green R422. Facts reader handles absent old metadata without changing runtime.')
