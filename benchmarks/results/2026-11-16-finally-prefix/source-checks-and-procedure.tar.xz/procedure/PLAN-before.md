# Lokad.Lython 0.11.0

Updated 2026-11-16 UTC. Git-ignored; never force-add. Publication and tagging remain
postponed. Deliver coherent simplification and substantial complete-script gains,
including newly generated scripts compiled and executed once. An isolated experiment
does not complete that objective. Current contracts belong in `docs/`; historical
conditions, rejected designs and raw evidence belong in [EXPERIMENTS](benchmarks/EXPERIMENTS.md).

## Delivery status

| State | Actual revision and evidence |
| --- | --- |
| Committed and fully qualified | **c023042d / measured 0393331a**, runtime method-format consolidation. [Full delivery](benchmarks/results/2026-11-15-runtime-format-operation/delivery/README.md): 43774159426 GREEN at 0e978c0b; Windows/Ubuntu, actual .NET 11/10, each 4,777 internal and 17,894 public ordinary tests, original 13/406 stress tests and installed Release consumers. All 16 summaries, 595 inputs and deleted paths verified. Receipt committed/pushed in 09bf8cbb. Terminal cached; do not repeat. |
| Retained source awaiting full qualification | **R422 / committed7d522f1f / frozen8f468f0a**, nearest known Unicode scalar boundaries.64internal/363public each actual11/10 pass; B818four jobs153.252s/all gates. Full 43783452636 active;592 committed inputs verified. No other prototype. |
| Latest completed comparison | **R421/B816**, current 0393331a versus CPython 3.13.16: existing complete patch generation, warm/compilation/compile-to-result, CSV warm control. Four jobs complete in 137.167s, all image/golden/quiet/budget/join/archive gates; [results](benchmarks/results/2026-11-16-patch-cpython-checkpoint/README.md). Reused checked workers/goldens; no source speedup or arbitrary-diff claim. Terminal cached. |
| Latest report comparison | [B813](benchmarks/results/2026-11-15-layout-cpython-checkpoint/README.md), 58eeea6f/9d071eba: method report warm 1.66–1.68× CPython, compile 1.02–1.03×, fresh 1.60–1.64×; f-string warm 1.17–1.18×. These are the measured earlier revision, not today's HEAD. |
| Other representative measurements | [B807](benchmarks/results/2026-11-15-store-cpython-checkpoint/README.md), 2865f619/55ba: invoice 1.08–1.11×, captured text 1.34–1.42×, JSON 0.84–0.87×, search 1.76–1.80× warm; manifest compile 1.25–1.29× / fresh 1.06–1.08×. Text control moves 4.14%; preserve that uncertainty and actual revision labels. |
| Independent adapter prototype | [R409](benchmarks/results/2026-11-15-regex-range-prototype/README.md), immutable development 0.5 assets: baseline/native each 361 public regex checks on actual 11/10; normal released 0.4 passes the same checks. Allocation reductions and backend timings remain separate from core contract acceptance. Normal pin unchanged. |

[BENCHMARKS](docs/BENCHMARKS.md) defines all boundaries. Warm includes mediated RAM
I/O, goldens and prior-result cleanup; excludes compilation, startup, reset/protocol
and final cache teardown. Fresh includes compiled-owner disposal. Wider process CPU
includes reset/protocol. Startup, pending I/O, contention, heap/RSS and embedding-tail
costs remain unmeasured; no claim is inferred from fewer allocations or full tests.

## Immediate deliverable: finish the current workload decision

R420's [current call/frame capture](benchmarks/results/2026-11-16-current-call-attribution/README.md)
is complete: 1,016 active samples, 146 unknown leaves and all other-thread CPU retained.
568 overlapping call/packet samples include useful formatting; 97 entry/frame samples
do not establish dominant removable activation cost. No ABI/controller/view prototype
is selected. Ordinary format promotion is a source fact; frequency remains unmeasured.

The different-workload source gate confirms that imports already execute code objects,
ordinary protected helpers and lazy namespaces are delivered, and default JSON storage
is native UTF-8. Annotation and ordinary abstract flows intentionally differ in dead/
deferred scope handling; counting their passes does not justify merging them.

**R421 completed:** B816 archived/joined; all controls and failed conditions retained.
Patch warm 0.817–0.825× and fresh 0.797–0.820× CPython confirm no demonstrated gap
for this single-edit fixture. CSV warm 1.107–1.149× has 2.95% unchanged Lython control
movement; no causal regression is inferred. Current patch/CSV guide rows identify all
phases/costs and source. No matcher redesign selected. R229's original evidence stays.

**R422 retained:** [known scalar boundaries](benchmarks/results/2026-11-16-regex-known-boundaries/README.md).
Eliminates repeated Unicode suffix walks using already-known subject/window endpoints,
without a map/cache/provider API or new memory machinery. Released0.4 unchanged.
Initial+refined sources/adverse controls retained. Refined complete diagnostics:
Unicode suffix elapsed5–10%/about5%lower at1,024/4,096scalars, CPU support; allocation
effectively flat(+16B), small-input control moves4.88%, ASCII CPU mixed. Both actual
frameworks pass64internal/363public and independent CPython programs.592inputs frozen.
Committed/pushed7d522f1f;592 committed inputs verified. Full 43783452636 active;
no query before 2026-11-16T01:01:59.777844+00:00. No repeated timing.

**Next R423 — protected-prefix source gate.** A1 source evidence finds the remaining
blanket rejection of all finally-containing functions (ExecutableScript.cs, native
eligibility), independently of whether the body needs a context before cleanup.
Assess a conservative instruction frontier at the earliest compiled finally suite:
reuse native final slots only before that frontier, then transfer exact PC/values to
the existing funded ordinary frame. This removes whole-function rejection; no new
controller/arena/dispatch framework. Normal unprotected native calls remain untouched.

Before implementation prove all early exits: Return/ReturnNone, direct unpacked tuple
completion and AbruptJump must transfer before bypassing cleanup. Normal jumps and
fallthrough cannot execute a finally suite natively. Faults keep existing original-PC
handler/finally routing; actual async work starts only after durable funding. Nested
cleanup order, overridden returns, retained return aliases, active exception identity,
cursor disposal, cancellation/refusal and joined cleanup are semantic gates. Prefix
values may survive until later frame admission; document admission timing rather
than promising identical thresholds or transactional command rollback.

Stop this source gate with that complete frontier/transfer invariant or a precise
deferral. If selected, use complete invoice/helper scripts with real try/finally,
plus unchanged ordinary/JSON/text controls, one short allocation and warm/fresh pair.
Do not infer a speedup merely from native eligibility or expand to with execution.
R403 controller/R411 tail-borrow debt stays relevant. The broader objective remains.

## Substantial redesign roadmap

Select from demonstrated work, not broad inclusive sample percentages. Each selected
milestone must name the complete work/storage removed, displaced implementation to
delete, affected complete scripts, semantic acceptance and bounded before/after controls.

| Area / hypothesis | Removal target and workloads | Acceptance / decision gate |
| --- | --- | --- |
| **A1. Complete calls, frames and operands.** Remaining transition/transport might explain helper cost. | Eliminate an entire argument, activation or retirement representation in captured-text, protected search, invoice and report helpers. Start from existing final slots, direct binding, deferred contexts and shared completed-operation kernels. | Preserve zero-allocation native entry where applicable, identity/closures, caller scope, evaluation/error order, true suspension, generators, admitted ownership and managed stack. Native spans cannot escape; establish durable funding before starting callbacks. R403 controller and R411 tail borrowing measured slower and were removed. Another wrapper or relocated state is insufficient. R414/R415/R420 have not isolated a dominant binder cost; no new implementation selected yet. |
| **A2. Record/collection construction and scalar transport.** Intermediate row/value construction may remain material in numerical aggregation. | Remove whole intermediates in CSV/JSON/invoice/fulfillment, rather than append a side cache or ledger. Shared headers and final CSV payloads are already delivered. | Preserve short/wide/duplicate rows, partial mutation, alias identity, exact overflow promotion and replacement peaks. Universal scalar slots widen reference-only rows; require a complete replacement and demonstrated relevant workload, not "boxing exists". Historical bulk CSV 6–8% proposal was reassessed; final payload metadata saves 5.56% allocation with ordinary timing flat/mixed, not a duplicate CPU gain. |
| **A3. Bulk text and formats.** Remaining conversions might justify replacing a complete pipeline. | Casing, final-output sinks, reusable format layouts and the runtime method-format executor are delivered. Further work must displace a real remaining representation across useful scripts. | Preserve Unicode expansion/context, formats, hooks, actual async suspension, current tokens and escaped aliases. No continuing series of format-only special cases. Require affected-script allocation plus warm/fresh timing and controls. |
| **A4. Frontend construction.** Repeated facts or representations may matter for new compile-heavy scripts. | Remove a complete redundant pass or representation in configuration/report compilation. R413 already deletes repeated store lowering, read maps and augmented shapes. | Preserve all diagnostics/spans, lexical/nonlocal/class-cell facts, lazy scopes and callback inspection. R412 finds mixed parsing/analysis/executable costs; no dominant region scan. Need a concrete compile-heavy workload and actual displaced pass before a rewrite, not an index/traversal framework. |

Stop an investigation with a coherent replacement design or a precise uncertainty and
move to another useful workload. Do not repeat unchanged attribution merely to keep a
task active. Baseline comparisons may close material workload gaps before a redesign;
they are distinct from testing a source hypothesis. Temporary performance setbacks can
serve a justified redesign, but require a completion milestone and an explicit retain,
refine or remove decision on remaining regression debt. Completion removes displaced
machinery and obsolete mechanism-only tests; independent semantics/cleanup checks stay.

## Independent regex deliverable

The core owns its Python-specific contract: native UTF-8 subjects/names, byte captures,
scalar positions, original-subject windows, effective flags, explicit owners and current
tokens consistently through frontend/runtime/imports. Native fnmatch/glob and cooperating
provider in-flight cancellation/joined cleanup are delivered. No core Utf8Regex dependency.
Missing published producer APIs defer **only affected final adapter qualification**.

- Build on R409's development producer and adapter-local bridges. It removes detailed
  text projection, per-advance registration/closure transport and disposes programs.
  Preserve four inline/effective-flag controls from 717f0747; parse Verbose and reported
  effective flags are distinct. No silent dialect fallback or semantic weakening.
- Normal adapter remains at 0.4.0 until a released immutable replacement is verified.
  Checked 2026-11-16: NuGet still lists 0.4; local 0.5 hashes match R409 and PythonRe
  source changes only README. No unchanged requalification.
  Recorded 0.5 candidate: dcfe880a, acceptance c5e02a27. Precisely missing: native UTF-8
  group-name enumeration, preparation with the current token, and per-match result-stage
  allowance. Range/cursor advancement tokens, working allowance, receipts and disposal
  exist. Assess no-reentry/nonthrowing-refund assumptions against supported Lython hosts;
  keep bridges rather than impose hidden host restrictions or add memory infrastructure.
- Verify actual package/source/assets before adoption; do not rerun unchanged backend
  tests merely because unrelated producer projects advance. Final checks: semantic/error/
  flag/window parity, real in-flight cancellation, refusal/unwind, retained users/budget
  reuse and one focused affected performance pair. Core contract tests, adapter semantics
  and real backend performance remain separately reported. Publication remains held.

## Completed milestones and retained uncertainty

Shared compiler facts/callback correction 61237f58 and native helper returns 8f07764a
are fully qualified. Returns establish approximately 19–20% less allocation; original
elapsed changes remain diagnostic. Direct UTF-8 formatting/storage establishes 8.67%
less allocation; [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md)
supports 5–8% lower report elapsed/CPU. The original adverse 15.125 ms remains unexplained.
No repeated unchanged qualification is pending for these changes.

R395–398 tuples, R405 arithmetic, R408 casing and R413 prepared stores are delivered;
their allocation/CPU distinctions, moving controls and earlier-denial tradeoffs remain
in history. R413 has small allocation savings, no demonstrated CPU gain and possible
manifest compile debt. R416 removes field intermediates (17.31% allocation reduction),
R418 reuses layouts (18.47%), R419 consolidates the executor (9.41%); these separate source
pairs cannot be added. Their full qualifications are complete. R419's warm/fresh gains
are modest (roughly 2–4% / 1–4%), with moving/adverse controls retained. Native promotion
and argument copies remain. Historical debts are accepted explicitly in the
[roadmap review](benchmarks/results/2026-11-15-runtime-roadmap-review/README.md), not declared recovered.

## Iteration and lasting contracts

Timeouts, unstable unchanged controls and inconclusive measurements establish uncertainty,
not a failed design or permanent ban. Allow bounded confirmation, refinement and correction
when evidence justifies it; preserve every adverse result and original failed condition.
Size runs for usable observations on the existing quiet VM. Percentages inform decisions;
they are not automatic vetoes. Separate simplification, allocation reduction and proven CPU.
Use focused Release semantics/cancellation/ownership tests; batch Windows/Ubuntu actual
11/10, original stress and installed Release consumers only at coherent retained boundaries.

[AGENTS](AGENTS.md) binds: fully managed memory safety and supported stack admission;
host-mediated capabilities and paths/Cwd; checked representation bounds and bounded I/O.
The host token governs time: no fuel, quotas or hidden watchdog. Shared admission funds
capacity/replacement overlap, results, aliases, caches and all pending users. First refusal
is terminal and cleanup awaited; no hidden allowance, retry, tracing, weak reclamation,
forced GC or abandoned work. Long streaming uses bounded host-driven commands.

Freeze copies/full hashes and force builds after preserved-timestamp restoration. UTF-8
text. Persist and verify VM evidence under lease before RAM teardown; join users before
refund. Retire only exact committed archived replicas with fresh ownership/path/hash/all-
alias proof; keep current images/toolchains and 254/252 MiB stage/archive floors. Cache
terminal CI/VM results forever. Only core is packaged; adapter remains non-packable.
