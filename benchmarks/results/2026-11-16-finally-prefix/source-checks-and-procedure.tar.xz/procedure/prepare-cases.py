from pathlib import Path
import copy,hashlib,json,subprocess
r=Path(__file__).parent
base=json.loads((r.parent/'format-operation-r419/quiet/retrieved/representative.json').read_text(encoding='utf-8'))
byid={c['id']:c for c in base['cases']}
invoice=copy.deepcopy(byid['scripts.csv-invoice.large']);source=invoice['source']
start=source.index('def price_line(row):\n');end=source.index('\n\ntotals =',start)
body=source[start+len('def price_line(row):\n'):end]
wrapped='processed = 0\n\n\ndef price_line(row):\n    global processed\n    try:\n'+''.join('    '+line+'\n'for line in body.splitlines())+'    finally:\n        processed += 1'
source=source[:start]+wrapped+source[end:]+'\nprint(processed)\n'
count=int(invoice['expectedOutput'].split()[0]);expected=invoice['expectedOutput']+str(count)+'\n'
invoice.update(id='scripts.csv-invoice.finally.large',source=source,expectedOutput=expected,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode()),sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),expectedOutputSha256=hashlib.sha256(expected.encode()).hexdigest())
base['cases']=[invoice,byid['scripts.csv-invoice.large'],byid['scripts.json-summary-helpers.large']]
base['performanceQualified']=False
(r/'catalog.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'invoice-finally.py').write_text(source,encoding='utf-8',newline='\n')
facts=json.loads((r/'cpython-semantics.json').read_text(encoding='utf-8'));cases=[dict(id=x['name'],source=x['source'])for x in facts['rows']]+base['cases']
(r/'facts-catalog.json').write_text(json.dumps(dict(cases=cases),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'inspect';d.mkdir()
project=(r.parent/'helper-boundaries-r410/Inspect.csproj').read_text(encoding='utf-8').replace('../cased-preparation-r408/refined/candidate/Lokad.Lython.dll','../../../../../src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
# Explicit absolute reference avoids guessing another relative traversal.
project=project.replace('../../../../../src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',str(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').resolve()).replace('\\','/'))
(d/'Inspect.csproj').write_text(project,encoding='utf-8',newline='\n')
program=(r.parent/'helper-boundaries-r410/Program.cs').read_text(encoding='utf-8')
program=program.replace('native = Read(code, "CanRunNativeInstructions"), capacity', 'native = Read(code, "CanRunNativeInstructions"), nativeEnd = Read(code, "NativePrefixEnd"), instructions = ((IEnumerable)Read(code, "Instructions")!).Cast<object>().Count(), capacity')
(d/'Program.cs').write_text(program,encoding='utf-8',newline='\n')
print('Prepared complete invoice with observable per-row finally bookkeeping, unchanged invoice/JSON controls and compiler-fact inspection.')
