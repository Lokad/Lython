from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent
out=repo/'benchmarks/results/2026-11-11-prepared-split-ranges-withdrawn';out.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','4aa2d46d','--','src/Lokad.Lython'])
for name in ['focused-checks.json','restored-checks.json']:
    checks=load(r/name);assert len(checks)==4 and all(x['exitCode']==0 and x['counts']['failed']=='0' for x in checks.values())
    shutil.copyfile(r/name,out/name)
for name in ['before.json','diagnostic-identity.json','source.patch','restoration.json']:shutil.copyfile(r/name,out/name)
for phase in ['warm-sync','warm-async','compile']:
    folder=out/'desktop'/phase;folder.mkdir(parents=True)
    raw=load(r/phase/'measurements.json');assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for name in ['measurements.json','summary.json','hash-witness.json','stderr.log']:shutil.copyfile(r/phase/name,folder/name)
restored={f:hashlib.sha256((repo/'src/Lokad.Lython/bin/Release'/f/'Lokad.Lython.dll').read_bytes()).hexdigest()for f in ['net11.0','net10.0']}
decision=dict(status='Withdraw whole one-file prepared-range prototype; restore exact fully qualified4aa production source. No new runtime mechanism or architecture test remains.',
    hypothesis='Reuse the first private casing/whitespace sizing pass to retain immutable ranges instead of rescanning during immediate iteration. Existing collector, reservation, final fragment writer and eager all-word admission reused.',
    architecturalOutcome='A second scan disappears, but a per-input range-array allocation/copy and additional scratch/final replacement overlap appear. Twenty net source lines added; the complete construction/lifetime pipeline is not simplified.',
    allocationOutcome='Complete captured-helper text allocation +8.48–8.49%, ordinary text +9.11% through both APIs; text estimated execution-allowance peaks +163840B (about9.85%), not CLR/RSS. This gives back more allocation than R225 saved while retaining list avoidance.',
    elapsedOutcome='Desktop complete-script clocks mixed/adverse and unchanged controls moving. Captured text sync envelope +5.98..+7.17% with1.11% control spread; async +1.19..+4.75% with3.41% spread. Ordinary text sync -2.56..+.64%, async -.14..+2.75%. No CPU regression, equivalence or gain attribution.',
    decisionReason='The measured added storage plus array/copy construction has no demonstrated compensating whole-script benefit. Withdraw before adding inline tiers, pools, caches or more special cases. No fixed percentage acceptance rule or permanent ban on a different coherent bulk-text design.',
    qualification='Candidate and restored45internal/263public focused checks per actual.NET11/.NET10; fresh nonincremental builds20.76s/20.05s withzero warnings/errors. Cached full runtime4aa qualification unchanged; no repeated platform/package cycle or new VM collection.',
    restoredCoreSHA256=restored,
    limitations='Local source-pair allocation is precise; elapsed diagnostic only. Compilation source unchanged/allocation flat, variable clocks retained. No quiet confirmation or CPU gain claimed. First driver start omitted a required hash-witness input and failed before image creation/warmup/timing; original condition and corrected unchanged input survive.',
    broaderObjective='Complete-script performance objective remains active; reassess complete call/frame/operand construction from the existing current-source profile rather than adding another narrow scan fast path.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
    for p in sorted(r.rglob('*')):
        if p.is_file() and p.relative_to(r).parts[0]!='images' and '__pycache__'not in p.parts:t.add(p,arcname=p.relative_to(r).as_posix())
    for role in ['before','candidate']:t.add(r/'images'/role/'Lokad.Lython.dll',arcname='cores/'+role+'/Lokad.Lython.dll')
p=out/'preparation.tar.xz'
with tarfile.open(p)as t:
    for m in t.getmembers():
        if m.isfile():t.extractfile(m).read()
(out/'archive-identity.json').write_text(json.dumps(dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
sync=load(r/'warm-sync/summary.json')['rows'];asyncRows={x['case']:x for x in load(r/'warm-async/summary.json')['rows']}
rows=[]
for x in sync:
    values=[]
    for row in [x,asyncRows[x['case']]]:
        changes=[v['elapsedMilliseconds']for v in row['candidateChangePercent'].values()]
        values.append(f'{min(changes):+.2f}..{max(changes):+.2f}%')
    rows.append('| '+x['case'].replace('scripts.','').replace('.large','')+' | '+' | '.join(values)+' |')
(out/'README.md').write_text('''# R230 — prepared split ranges withdrawn

2026-11-11. Qualified4aa/frozen9ee7 baseline, evidence HEAD2f6fa99e; candidate
identities in [source pair](diagnostic-identity.json). One production file/+20 net
lines; **whole prototype withdrawn**, exact qualified production bytes restored.
No retained runtime change, new option, pool, cache or architecture-specific test.

The current R227 profile attributes72 leaves to private split preparation and
additional useful scanning inside iteration/dispatch. These samples motivated a
bounded tradeoff, not a speed forecast: reuse the existing range collector to
retain immutable boundaries after sizing rather than scan the line again. The
existing cursor writes independently owned words from prepared ranges; every word
is still prepaid before the first guest loop effect. Scratch and final range-array
overlap are admitted before allocation. Existing Unicode writer/collector, current
cancellation, terminal refusal and ownership mechanisms remain unchanged.

**The second scan disappears, but a range-array allocation/copy and its lifetime
appear.** Text CLR allocation rises8.48–8.49% for the captured-helper shape and9.11%
for ordinary text through both APIs. Estimated execution-allowance peaks increase
163,840B/about9.85%, not RSS. That gives back more allocation than R225 saved. No
compensating whole-script benefit is demonstrated; adding inline tiers or a cache
would move away from simplification. Withdraw the complete design without a quiet
campaign. This is a construction/storage tradeoff, not a fixed-percentage veto or
permanent closure of a different coherent text pipeline. [Decision](decision.json).

## Bounded observations

Existing six complete scripts, fixedfec79 worker/optional0.4/auxiliary images,
only core differs. Same Windows/.NET11RC3 process, ordinary GC/tiering,256warmups
per image,5rotated16-invocation rounds and two identical baseline ALCs. All goldens,
stable/final-zero shared-budget balances, image isolation and fixture cleanup pass.
Envelope includes mediated file I/O, fixture reset, full checks and result disposal;
excludes compilation/startup/final cache disposal. Run-only clocks exclude reset,
post-return validation/disposal and survive separately. Compilation includes
construction/disposal. Shared JIT/GC and moving controls prevent CPU conclusions.

These are diagnostic **envelope** ranges against both identical baseline roles:

| Complete script | Sync change | Async change |
| --- | ---: | ---: |
'''+ '\n'.join(rows)+'''

Captured text's sync control spread is1.11%, async3.41%; ordinary text3.18%/2.81%.
Other unchanged controls vary up to9.23%. All adverse samples and wider coarse CPU
remain in [raw sync](desktop/warm-sync/measurements.json),
[async](desktop/warm-async/measurements.json) and [compile](desktop/compile/measurements.json).
Compilation source is unchanged, allocation flat, elapsed variable/adverse up to
+9.68%. No elapsed improvement/equivalence/causal CPU regression is claimed.

Candidate **45internal/263public checks per actual.NET11/.NET10** pass, preserving
Unicode/order/aliases/defaults/keywords/dynamic targets, terminal all-word refusal
before body effects, cancellation, genuine suspended protocols, retained values,
awaited cleanup and budget reuse. No test added to enforce this private design.
Guarded restoration verifies the owned candidate before writing original physical
bytes. Forced nonincremental solution rebuild20.05s/zero warnings/errors and the
same focused checks pass for restored source. Rebuilt binary identities are
separate, not timed. [Restoration](restoration.json), [checks](restored-checks.json).
Full platform/stress/installed-consumer4aa qualification is already cached GREEN;
unchanged source does not require replay. Broader whole-script work remains active.

The first private-driver launch omitted its unchanged hash-witness input and
failed before image construction, warmup or timing. The corrected run supplies
that same R228 input, changing no source, images or settings. Original empty output,
error and explanation survive with all source/cores/builds/tests/commands in
[preparation](preparation.tar.xz), verified by [archive identity](archive-identity.json).
No VM collection, producer change or publication occurred.
''',encoding='utf-8',newline='\n')
print('R230 withdrawn evidence frozen; source restored, checks and all raw observations retained.')
