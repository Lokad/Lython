from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent; meta=json.loads((r/'before.json').read_text(encoding='utf-8'))
p=Path(meta['path']);candidate=(r/'candidate.cs').read_bytes();before=(r/'before.cs').read_bytes()
assert p.read_bytes()==candidate
assert hashlib.sha256(before).hexdigest()==meta['sha256']
p.write_bytes(before)
assert not subprocess.check_output(['git','diff','4aa2d46d','--','src/Lokad.Lython'])
(r/'restoration.json').write_text(json.dumps(dict(exactPhysicalSourceRestored=True,allProductionSourcesEqualQualified4aa=True,guardedCandidateSHA256=hashlib.sha256(candidate).hexdigest(),restoredSHA256=hashlib.sha256(before).hexdigest(),forcedNonincrementalBuildRequiredBeforeNoBuildChecks=True),indent=2)+'\n',encoding='utf-8')
focus=(r/'focus.py').read_text(encoding='utf-8').replace("r/'tests'","r/'restored-tests'").replace("r/'tests'/trx","r/'restored-tests'/trx").replace("r/'focused-checks.json'","r/'restored-checks.json'").replace("r/(name+'.log')","r/('restored-'+name+'.log')")
(r/'focus-restored.py').write_text(focus,encoding='utf-8')
print('Exact qualified4aa production bytes restored; no candidate runtime mechanism remains.')
