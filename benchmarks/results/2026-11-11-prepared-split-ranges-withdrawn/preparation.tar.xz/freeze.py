from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();r=Path(__file__).parent
prod=repo/'src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'
assert prod.read_bytes()!=(r/'before.cs').read_bytes()
assert subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True).strip()=='src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'
(r/'candidate.cs').write_bytes(prod.read_bytes())
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
ids=dict(before=hash(r/'before.cs'),candidate=hash(prod),images={role:{p.name:hash(p)for p in (r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},sourceRevision='R230 one-file private split-range prototype versus fully qualified4aa/frozen9ee7. Existing fec79 worker/optional0.4 and six complete scripts. Desktop diagnostics; no elapsed claim.',net10SHA256=hash(r/'candidate-net10.dll'))
assert ids['images']['before']['Lokad.Lython.dll']=='9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'
assert ids['images']['candidate']['Lokad.Lython.dll']!=ids['images']['before']['Lokad.Lython.dll']
for name,h in ids['images']['before'].items():
 if name!='Lokad.Lython.dll':assert ids['images']['candidate'][name]==h
(r/'diagnostic-identity.json').write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
print('Fresh candidate/core/source identities frozen; only core differs between diagnostic roles.')
