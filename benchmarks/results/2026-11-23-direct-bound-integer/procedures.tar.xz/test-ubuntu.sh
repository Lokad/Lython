#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-bound-integer-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-bound-integer-20261123
filter='Category!=Stress&(FullyQualifiedName~DefaultMetadata|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~DefaultConstruction|FullyQualifiedName~NativeCall|FullyQualifiedName~IntegerReturn|FullyQualifiedName~IntegerChain|FullyQualifiedName~CallBinding|FullyQualifiedName~Recursion|FullyQualifiedName~NativeUnpack|FullyQualifiedName~ExecutableCall|FullyQualifiedName~FunctionCancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/white-ubuntu.log" 2>&1 || { tail -45 "$lab/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -45 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"

