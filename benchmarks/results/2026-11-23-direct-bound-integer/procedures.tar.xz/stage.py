
from pathlib import Path
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
previous=lab.parent/"direct-single-def-default-20261123"/"comparison"
donor=lab.parent/"cpython-checkpoint-20261123"/"comparison"/"quiet"
profile=lab.parent/"function-optional-attributes-20261122"/"profile"/"quiet"
quiet=out/"quiet"
quiet.mkdir()
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
def committed(folder,leaf):return git("show",f"origin/master:benchmarks/results/{folder}/{leaf}")
def verified_archive(folder):
    receipt=json.loads(committed(folder,"archive-receipt.json"))
    data=committed(folder,"observations.tgz")
    assert all(receipt[k]for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(data)==receipt["archiveSHA256"]
    return data,receipt["archiveSHA256"]

template=read(previous/"quiet/config.json")
donor_config=read(donor/"config.json")
_,archive_digest=verified_archive("2026-11-23-retained-cpython-checkpoint")
past=json.loads(committed("2026-11-23-retained-cpython-checkpoint","source.json"))
assert past["imageFiles"]==donor_config["identity"]["imageFiles"]
trace,digest=verified_archive("2026-11-23-function-storage-attribution")
assert digest==h(profile/"observations.tgz")
profile_base=read(profile/"config.json")["root"].split("/")[-1]
retire=[]
with tarfile.open(fileobj=io.BytesIO(trace)) as bundle:
    for m in bundle.getmembers():
        if not m.isfile() or not m.name.startswith("confirmation/job-") or m.size<25_000:continue
        assert ".." not in Path(m.name).parts
        data=bundle.extractfile(m).read()
        assert len(data)==m.size
        retire.append(dict(paths=[profile_base+"/"+m.name],bytes=m.size,sha256=sha(data),links=1,archives={}))
assert len(retire)>=18 and sum(row["bytes"]for row in retire)>2_600_000

tree=repo/".git/agent-worktrees/direct-bound-integer-20261123"
candidate=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert not git("status","--porcelain",cwd=tree)
before=read(out/"identity.json")
patch=git("diff","--binary",before["patchBase"],candidate,"--","src","tests")
assert patch.count(b"diff --git ")==4
assert sha(patch)==before["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
files=before["imageFiles"]
assert past["imageFiles"]["candidate"]==files["reference"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
catalog=out/"representative.json"
ids=[row["id"] for row in read(catalog)["cases"]]
jobs=[(ids[0],"warm"),(ids[0],"compile-run")]+[(name,"warm")for name in ids[1:]]
assert len(jobs)==6
save(out/"jobs.json",jobs)
shutil.copyfile(catalog,quiet/"representative.json")
for role in files:
    image=out/f"frozen-{role}"
    proof=read(out/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["catalogSha256"]==h(catalog) and proof["caseCount"]==len(ids)
    assert len(files[role])==32 and {n:h(image/n)for n in files[role]}==files[role]
(quiet/"candidate").mkdir()
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
identity={**before,"sourceRevision":before["reference"]+" versus "+candidate,"candidate":candidate,
    "purpose":"Replace the omitted-argument binder and both scalar and reference staging with direct prepared integer operand reads.",
    "normalAdapterPin":"0.4.0","coreSHA256":{r+s:m[core]for r,m in files.items()for s in ("","-control")},
    "catalogs":{"representative.json":{"sha256":h(catalog)}}}
save(quiet/"identity.json",identity)
root="/home/lokad/lython-bench-checks/direct-bound-integer-b1430-20261123"
unit="lython-b1430-direct-bound-integer-20261123"
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(previous/"quiet"/leaf).read_text(encoding="utf-8").replace(template["root"],root).replace(template["unit"],unit)
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json" for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
    write(quiet/leaf,code.replace("Singleton positional defaults","Direct bound integers"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as t:
    for n in parts:t.add(quiet/n,arcname=n)
cfg={**template,"root":root,"unit":unit,"identity":identity,"source":donor_config["root"],"sourceRole":"candidate",
     "sourceFiles":files["reference"],"sourceCatalogSHA256":past["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":archive_digest,"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(previous/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1428-fixtures","b1430-fixtures"))
write(out/"launch.py",(previous/"launch.py").read_text(encoding="utf-8").replace("Singleton positional defaults","Direct bound integers"))
write(out/"summarize.py",(previous/"summarize.py").read_text(encoding="utf-8"))
print(candidate,root,cfg["unpackedBytes"],sum(r["bytes"]for r in retire),flush=True)

