; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryEvaluateDirectIntegerReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 17 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 120
       lea      rbp, [rsp+0xB0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdi, r8
       mov      r14, r9
 
G_M000_IG02:                ;; offset=0x0037
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       mov      r15, gword ptr [rsi+0x88]
       cmp      dword ptr [r15+0x08], 0
       jbe      G_M000_IG17
       add      r15, 16
       mov      r13, gword ptr [r15]
       mov      r12, gword ptr [rdi+0x98]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0071
       mov      rcx, r12
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG04:                ;; offset=0x007D
       mov      rcx, bword ptr [rbx]
       mov      r13d, dword ptr [rbx+0x08]
       mov      r12d, dword ptr [r15+0x10]
       test     r12d, r12d
       jge      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x008D
       mov      edx, r12d
       not      edx
       mov      r13, gword ptr [rsi+0x30]
       cmp      dword ptr [r13+0x08], edx
       jg       SHORT G_M000_IG06
       sub      edx, dword ptr [r13+0x08]
       lea      r9, [rbp-0x60]
       mov      rcx, rsi
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x00C0
       cmp      edx, dword ptr [r13+0x08]
       jae      G_M000_IG17
       mov      ecx, edx
       mov      rcx, gword ptr [r13+8*rcx+0x10]
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00DD
       cmp      r12d, r13d
       jae      G_M000_IG17
       mov      edx, r12d
       shl      rdx, 4
       add      rcx, rdx
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG08:                ;; offset=0x00FA
       xor      rdx, rdx
       mov      gword ptr [rbp-0x60], rdx
       test     eax, eax
       je       G_M000_IG15
 
G_M000_IG09:                ;; offset=0x0108
       mov      rcx, bword ptr [rbx]
       mov      r13d, dword ptr [rbx+0x08]
       mov      r15d, dword ptr [r15+0x0C]
       test     r15d, r15d
       jge      SHORT G_M000_IG11
       mov      edx, r15d
       not      edx
       mov      r15, gword ptr [rsi+0x30]
       cmp      dword ptr [r15+0x08], edx
       jg       SHORT G_M000_IG10
       sub      edx, dword ptr [r15+0x08]
       lea      r9, [rbp-0x68]
       mov      rcx, rsi
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x014B
       cmp      edx, dword ptr [r15+0x08]
       jae      G_M000_IG17
       mov      ecx, edx
       mov      rcx, gword ptr [r15+8*rcx+0x10]
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0168
       cmp      r15d, r13d
       jae      G_M000_IG17
       mov      edx, r15d
       shl      rdx, 4
       add      rcx, rdx
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG12:                ;; offset=0x0185
       xor      rcx, rcx
       mov      gword ptr [rbp-0x68], rcx
       test     eax, eax
       je       G_M000_IG15
       mov      rcx, qword ptr [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       mov      gword ptr [rsp+0x28], rdi
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x38], rcx
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r9, qword ptr [rbp-0x40]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rsi+0x88]
       mov      eax, dword ptr [rbp-0x50]
       inc      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG17
       shl      rax, 5
       mov      rbx, gword ptr [rcx+rax+0x10]
       mov      rsi, gword ptr [rdi+0x98]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG13:                ;; offset=0x0207
       mov      rbx, qword ptr [rbp-0x58]
       mov      rcx, 0x210E3003968
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r14+0x08], rbx
       mov      eax, 1
 
G_M000_IG14:                ;; offset=0x0229
       add      rsp, 120
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG15:                ;; offset=0x023A
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x023C
       add      rsp, 120
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x024D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 595

