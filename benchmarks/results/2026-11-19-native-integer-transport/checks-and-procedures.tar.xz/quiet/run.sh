set -eu
root=/home/lokad/lython-bench-checks/native-integer-transport-b1135-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
