import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'validator-errors-r704'
stage = (previous / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('native-conversion-failure-b1134', 'native-integer-transport-b1135')
stage = stage.replace('lython-b1134-native-conversion-failure', 'lython-b1135-native-integer-transport')
stage = stage.replace('lython-b1134-fixtures', 'lython-b1135-fixtures')
stage = stage.replace('R704 route malformed integer conversion without CLR unwinding',
                      'R706 direct short integer result and failure transport')
stage = stage.replace('Native conversion failure source pair', 'Native integer transport source pair')
stage = stage.replace('"Native conversion failure").replace', '"Native integer transport").replace')
proof = (previous / 'prove-quiet-space.py').read_text(encoding='utf-8')
proof = proof.replace('opened-file-acquisition-r702/quiet', 'validator-errors-r704/quiet')
proof = proof.replace('2026-11-19-opened-file-acquisition', '2026-11-19-native-conversion-failure')
for name, contents in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
