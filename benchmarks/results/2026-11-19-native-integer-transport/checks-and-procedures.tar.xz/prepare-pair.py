import shutil
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'validator-errors-r704'
shutil.copyfile(previous / 'catalog.json', lab / 'catalog.json')
source = (previous / 'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace("git('rev-parse','7d120c9ea')", "git('rev-parse','365335ea8')")
source = source.replace("git('rev-parse',can+'^')", "git('merge-base',ref,can)")
assert "git('merge-base',ref,can)" in source and '365335ea8' in source
(lab / 'freeze-and-verify.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
