values = ['', 'abc', 'é😀é', 'a\0b']
needles = ['', 'a', 'é', '😀', '\0', 'xyz']
bounds = [None, -10**40, -4, -1, 0, 1, 2, 4, 10**40]
for value in values:
    for needle in needles:
        for start in bounds:
            for end in bounds:
                for name in ['find', 'rfind', 'count', 'index', 'rindex', 'startswith', 'endswith']:
                    try: print(getattr(value,name)(needle,start,end))
                    except ValueError: print('ValueError')
