from pathlib import Path
import fcntl,json,os,subprocess,time,tarfile,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/captured-cpu-b662-20261113')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll';dotnet=env['DOTNET_ROOT']+'/dotnet'
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 subprocess.run(['python3',str(root/'ops-profile.py'),str(root/'guest-fixtures/profiles')],check=True)
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 assert [p.name for p in (root/'guest-fixtures').iterdir()]==['profiles']
 record=json.loads((root/'guest-fixtures/profiles/captured/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 trace=root/'guest-fixtures/profiles'
 raw={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
  for p in sorted(root.iterdir()):
   if p.is_file()and p.name not in {'observations.tgz','current-core.dll'}:archive.add(p,arcname=p.name)
  archive.add(trace,arcname='profiles')
 with tarfile.open(root/'observations.tgz')as archive:
  assert json.loads(archive.extractfile('profiles/captured/record.json').read())['exitCode']==0
  for name,sha in raw.items():assert hashlib.sha256(archive.extractfile('profiles/'+name).read()).hexdigest()==sha
 # Every RAM byte is now preserved and verified persistently, while lease is held.
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=True,allWorkersJoined=True,quietBeforeAndAfter=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,ramTraceArchivedAndVerifiedBeforeUnmount=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),source='c5d05cff/3a2c1cf6 captured source gate; delivery running',performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
