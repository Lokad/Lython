using System.Text;
using System.Text.Json;
using Lokad.Lython.Frontend;

var frontend = LythonFrontend.Compile(File.ReadAllText(args[0], Encoding.UTF8));
if (frontend.Diagnostics.Any(d => d.Severity == Lokad.Lython.LythonDiagnosticSeverity.Error))
    throw new InvalidOperationException(string.Join(';', frontend.Diagnostics));
var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
var facts = new List<object>();
Visit("module", code);
Console.WriteLine(JsonSerializer.Serialize(facts, new JsonSerializerOptions { WriteIndented = true }));
void Visit(string name, ExecutableCodeObject body)
{
    facts.Add(new { name, body.ValueStorageCapacity, body.CanInlineInstructions,
        body.RequiresLocalVariableMirroring, capturedSlots = body.CapturedLocalSlots.Count,
        calls = body.CallSites.Count(), instructions = body.Instructions.Count() });
    foreach (var function in body.Functions) Visit(name + "." + function.Name, function.CodeObject);
}
