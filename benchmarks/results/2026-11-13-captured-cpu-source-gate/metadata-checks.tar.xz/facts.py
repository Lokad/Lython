from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
for name in ['facts-build.log','facts-stderr.log','captured-facts.json']:
 p=r/name
 if p.exists(): p.rename(r/(p.stem+'-previous-'+str(len(list(r.glob(p.stem+'-previous-*'))))+p.suffix))
with(r/'facts-build.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'facts/facts.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'facts-build.log').read_text(encoding='utf-8')
done=subprocess.run([str(sdk/'dotnet.exe'),str(r/'facts/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),str(r/'captured.py')],env=env,capture_output=True,text=True,encoding='utf-8');(r/'captured-facts.json').write_text(done.stdout,encoding='utf-8');(r/'facts-stderr.log').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
print(done.stdout,flush=True)
