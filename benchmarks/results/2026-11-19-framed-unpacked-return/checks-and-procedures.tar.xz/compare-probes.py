from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source = ["shared=[]\ndef decorate(value):\n    return lambda: value\ndef factory(value):\n    def capture(): return value\n    return capture,decorate(value),value\nget, again, alias = factory(shared)\nsaved = factory(shared)\na = 'untouched'\ntry: a,b = factory(shared)\nexcept ValueError: print(a)\nprint(get() is shared,again() is alias,type(saved).__name__,saved[2] is alias)\n", 'def f(seed):\n    def get(): return seed\n    for i in range(1):\n        return seed+i, get, seed/2\na,b,c = f(101)\nprint(a,b(),c)\n', "events=[]\ndef nested(value):\n    events.append('nested')\n    return value\ndef outer(value):\n    def f(): return value\n    def g(): return nested(value),f()\n    x,y=g()\n    return f,x,y\na,b,c=outer(events)\nprint(a() is events,b is c,events)\n", "events=[]\ndef factory():\n    try:\n        return (1,2)\n    finally:\n        events.append('finally')\n        return (3,4)\na,b = factory()\nprint(a,b,events)\n", 'events=[]\nclass Pipe:\n    def __setattr__(self,name,value):\n        events.append((name,value))\ndef factory(n):\n    def keep(): return n\n    return keep(),n+1,n+2\npipe=Pipe()\npipe.first, *pipe.rest = factory(6)\nprint(events)\n', 'def factory(x):\n    def capture(): return x\n    def twice(): return capture(),capture()\n    return twice(), capture\nvalue=[]\n(left,right),capture=factory(value)\nprint(left is right is capture() is value)\n', 'def factory(a):\n    b=a+10000\n    def closure(): return b\n    return b,closure,b\nx,reader,y=factory(2)\nprint(x is y, reader() is x, x)\n', "events=[]\ndef factory(limit):\n    def saved(): return limit\n    events.append('rhs')\n    return saved, 2\nclass Target:\n    def __setattr__(self,name,value):\n        events.append(name)\n        raise ValueError('stop')\nobj=Target()\nunchanged=0\ntry: obj.a,unchanged=factory(1)\nexcept ValueError: print(events,unchanged)\n"]
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs = (lab/'probes.json').read_bytes()
driver = Path('tools/LythonProbe/bin/Release/net11.0')
identity = json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))['images']
work = lab/'probe'
work.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def all_hashes(path):
    return {entry.name:digest(entry) for entry in path.iterdir() if entry.is_file()}
stock = [subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',program],capture_output=True,text=True,encoding='utf-8',check=True,timeout=20).stdout for program in source]
matches=[]
for role in ('reference','candidate'):
    image = work/role
    image.mkdir(exist_ok=True)
    for entry in driver.iterdir():
        if entry.is_file() and entry.suffix != '.pdb': shutil.copyfile(entry,image/entry.name)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(lab/'frozen'/role/name, image/name)
        assert digest(image/name)==identity[role][name]
common=all_hashes(work/'reference')
assert common | {'Lokad.Lython.dll':identity['candidate']['Lokad.Lython.dll']} == all_hashes(work/'candidate')
for mode in ('sync','async'):
    results=[]
    for role in ('reference','candidate'):
        args=[sdk/'dotnet.exe',work/role/'LythonProbe.dll','--batch-json']+(['--async'] if mode=='async' else [])
        completed=subprocess.run(args,env=env,input=inputs,capture_output=True,timeout=60)
        (lab/f'probe-{role}-{mode}.jsonl').write_bytes(completed.stdout)
        (lab/f'probe-{role}-{mode}.stderr').write_bytes(completed.stderr)
        records=[json.loads(line) for line in completed.stdout.decode('utf-8-sig').splitlines()]
        assert len(records)==len(source), (role, mode, completed.returncode, completed.stderr)
        semantics=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
        results.append([{key:record['Lython'][key] for key in semantics} for record in records])
    assert results[0]==results[1], [i for i,pair in enumerate(zip(*results)) if pair[0]!=pair[1]]
    assert all(value['Success'] and value['StandardOutput'] == expect for value, expect in zip(results[1], stock, strict=True)), results[1]
    matches.append(dict(mode=mode, matching=len(source)))
(lab/'probe-summary.json').write_text(json.dumps(dict(results=matches, referenceImage=common),indent=2)+'\n',encoding='utf-8',newline='\n')
print(matches)
