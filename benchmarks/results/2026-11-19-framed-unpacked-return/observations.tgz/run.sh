set -eu
root=/home/lokad/lython-bench-checks/framed-unpacked-return-b1113-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
