from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pair=load(lab/'frozen-identity.json')
remote=load(quiet/'config.json')
manifest=lab/'comparison-catalog.json'
archive=quiet/'observations.tgz'
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
timing=load(lab/'quiet-summary.json')
assert terminal['exitCode']=='0' and receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['quietBeforeAndAfter'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert sha(archive)==receipt['archiveSHA256']
assert sha(manifest)==remote['catalogSHA256']
assert len(timing['rows'])==receipt['jobs']==4
for role,files in pair['images'].items():
    assert len(files)==32 and files==remote['identity']['imageFiles'][role]
    assert all(sha(lab/'frozen'/role/name)==digest for name,digest in files.items())
    checked=load(lab/f'{role}-comparison-verify.json')
    assert checked['state']=='Completed' and checked['catalogSha256']==sha(manifest)
    assert all(row['sharedBudgetBaselineRestored'] for row in load(lab/f'{role}-comparison-allocation.json')['rows'])
out=Path('benchmarks/results/2026-11-20-inline-lexical-definitions/initial')
out.mkdir(parents=True,exist_ok=False)
timing.update(source=pair['candidateCommit'],reference=pair['referenceCommit'],archiveSHA256=receipt['archiveSHA256'],
              coreSHA256=remote['identity']['coreSHA256'],comparedTo='Lython',performanceQualified=False,retained=False)
(out/'summary.json').write_text(json.dumps(timing,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
patch=subprocess.check_output(['git','diff','--binary',pair['referenceCommit'],pair['candidateCommit'],'--','src','tests'])
(lab/'measured-source.patch').write_bytes(patch)
files=('stage-quiet.py','launch-quiet.py','summarize-quiet.py','archive.py','diagnose-allocation.py','frozen-identity.json',
       'comparison-catalog.json','catalog.json','reference-comparison-verify.json','candidate-comparison-verify.json',
       'reference-comparison-allocation.json','candidate-comparison-allocation.json','focused-win.log','test-ubuntu.sh',
       'focused-filter.txt','probe-ubuntu.log','Lokad.Lython.Tests-ubuntu.log','Lokad.Lython.PublicApi.Tests-ubuntu.log',
       'diagnostic.log','measured-source.patch','stage.log','retrieval.log')
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in files:bundle.add(lab/name,arcname=name)
    for name in ('collect.py','archive-owned.py','retrieve.py','remote-launch.py','identity.json','config.json','run.sh',
                 'launch.log','observe-not-before.json'):
        bundle.add(quiet/name,arcname='quiet/'+name)
print('Preserved the source pair, both complete image identities, 80 timed batches and existing checks.')
