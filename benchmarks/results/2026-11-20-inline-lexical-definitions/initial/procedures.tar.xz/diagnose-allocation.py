from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
baseline = lab.parent/'single-lexical-class-cells'
trial = Path('.git/agent-worktrees/inline-lexical-definitions')
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git',*map(str,args)],encoding='utf-8').strip()
lineage = read(baseline/'frozen-identity.json')
reference = git('rev-parse','HEAD')
candidate = git('-C',trial,'rev-parse','HEAD')
assert reference.startswith('f65be4da5') and candidate.startswith('75e11995f')
assert not git('-C',trial,'status','--porcelain')
assert not git('diff','--name-only',lineage['candidateCommit'],reference,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
files = lineage['images']['candidate']
origin = baseline/'frozen/candidate'
assert len(files)==32 and {name:sha(origin/name) for name in files}==files
catalog = read(baseline/'catalog.json')
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in ('scripts.annotated-rule-closures','scripts.csv-invoice.large')]
catalog['cases'] += [c for c in read(lab.parent/'factory-dispatch-after-direct-emission/catalog.json')['cases'] if c['id'].endswith('.nested-factories')]
assert len(catalog['cases'])==3
manifest = lab/'catalog.json'
manifest.write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
results = {}
imageFiles = {}
for role in ('reference','candidate'):
    image = lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=False)
    for name in files: shutil.copyfile(origin/name,image/name)
    for helper in origin.glob('ValidatedAllocation.*'): shutil.copyfile(helper,image/helper.name)
    expected=files.copy()
    if role=='candidate':
        binary=trial/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
        shutil.copyfile(binary,image/binary.name)
        expected[binary.name]=sha(binary)
    assert {name:sha(image/name) for name in expected}==expected
    verify=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
                    '--python','C:/Python313/python.exe','--python-worker',Path('benchmarks/cpython-worker.py').resolve(),'--out',verify],
                   env=env,check=True,timeout=90)
    checked=read(verify)
    assert checked['state']=='Completed' and checked['catalogSha256']==sha(manifest)
    result=lab/(role+'-allocation.json')
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,result],env=env,check=True,timeout=90)
    assert {name:sha(image/name) for name in expected}==expected
    results[role]=read(result)['rows']
    assert all(row['sharedBudgetBaselineRestored'] for row in results[role])
    imageFiles[role]=expected
for a,b in zip(results['reference'],results['candidate'],strict=True):
    assert a['id']==b['id']
    metrics=('allocatedBytesPerInvocation','peakExecutionMemoryBytes')
    print(a['id'],*(f'{label} {a[label]} to {b[label]}' for label in metrics))
(lab/'frozen-identity.json').write_text(json.dumps(dict(referenceCommit=reference,candidateCommit=candidate,casesSHA256=sha(manifest),images=imageFiles),indent=2)+'\n',encoding='utf-8')
