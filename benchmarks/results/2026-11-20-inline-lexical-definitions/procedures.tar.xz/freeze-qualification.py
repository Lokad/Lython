from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
initial=lab.parent/'inline-lexical-definitions'
trial=Path('.git/agent-worktrees/shared-lexical-definitions')
read=lambda p:p.read_text(encoding='utf-8-sig')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pair=json.loads(read(initial/'frozen-identity.json'))
candidate=subprocess.check_output(['git','-C',trial,'rev-parse','HEAD'],encoding='utf-8').strip()
assert candidate.startswith('32c5f2ef7')
assert subprocess.check_output(['git','-C',trial,'status','--porcelain'],encoding='utf-8')==''
assert subprocess.check_output(['git','diff','--name-only','HEAD',pair['referenceCommit'],'--','src','tests',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],encoding='utf-8')==''
pair['candidateCommit']=candidate
shutil.copyfile(initial/'catalog.json',lab/'catalog.json')
for role,files in pair['images'].items():
    source=initial/'frozen'/role
    target=lab/'frozen'/role
    assert len(files)==32 and all(sha(source/name)==digest for name,digest in files.items())
    target.mkdir(parents=True,exist_ok=False)
    for name in files:
        shutil.copyfile(source/name,target/name)
    for helper in source.glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,target/helper.name)
    if role=='candidate':
        core=trial/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
        shutil.copyfile(core,target/core.name)
        files[core.name]=sha(core)
    assert all(sha(target/name)==digest for name,digest in files.items())
(lab/'frozen-identity.json').write_text(json.dumps(pair,indent=2)+'\n',encoding='utf-8',newline='\n')
text=read(initial/'stage-quiet.py').replace('b1201','b1202').replace('inline-lexical-definitions','shared-lexical-definitions')
text=text.replace('Complete eligible lexical definitions using inline operand slots','Complete lexical definitions with a shared operand kernel')
compile(text,'stage-quiet.py','exec')
(lab/'stage-quiet.py').write_text(text,encoding='utf-8',newline='\n')
