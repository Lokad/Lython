from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
trial=lab.parent/'dynamic-record-layout'
template=lab.parent/'report-cpython-checkpoint'
quiet=trial/'quiet'
root='/home/lokad/lython-bench-checks/dynamic-record-cpython-b1180-20261120-confirmed'
unit='lython-b1180-dynamic-record-cpython-20261120-confirmed'
read=lambda f:f.read_text(encoding='utf-8-sig')
load=lambda f:json.loads(read(f))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value):
    write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args]).decode().strip()

pair=load(trial/'frozen-identity.json')
retained=git('rev-parse','HEAD')
assert not git('status','--porcelain')
measured=pair['candidateCommit']
assert not git('diff','--name-only',measured,retained,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
files=pair['images']['candidate']
donor=load(quiet/'config.json')
receipt=load(quiet/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
assert len(files)==32 and donor['identity']['imageFiles']['candidate']==files
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=True)
for name,digest in files.items():
    source=trial/'frozen/candidate'/name
    assert sha(source)==digest
    shutil.copyfile(source,image/name)
assert {name:sha(image/name) for name in files}==files

catalog=load(trial/'catalog.json')
cases={case['id']:case for case in catalog['cases']}
ids=['scripts.report-forwarding.expanded','scripts.csv-invoice.large']
catalog['cases']=[cases[key] for key in ids]
save('representative.json',catalog)
catalog_sha=sha(lab/'representative.json')
worker=lab/'cpython-worker.py'
shutil.copyfile('benchmarks/cpython-worker.py',worker)
worker_sha=sha(worker)
assert worker_sha==donor['protocolSHA256']
core=files['Lokad.Lython.dll']
identity=dict(sourceRevision=retained,imageSource=measured,purpose='Expanded forwarding against stock CPython',
    imageFiles={'candidate':files},auxiliaryFiles={n:h for n,h in files.items() if n!='Lokad.Lython.dll'},coreSHA256={'candidate':core,'candidate-control':core},
    catalogSHA256=catalog_sha,cpythonWorkerSHA256=worker_sha)
save('identity.json',identity)
save('build-revision.json',dict(sourceRevision=retained,imageSource=measured,coreSHA256=core))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_sha
assert {name:sha(image/name) for name in files}==files

old=load(template/'config.json')
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    text=read(template/name).replace(old['root'],root).replace(old['unit'],unit).replace('B1173','B1180')
    if name=='collect.py':
        a=text.index('    for case_id,diagnostic in ')
        b=text.index('\n',a)
        text=text[:a]+f'    for case_id,diagnostic in {[(key,False) for key in ids]!r}:'+text[b:]
    text=text.replace("['jobs'])==4","['jobs'])==2").replace("['jobs']==4","['jobs']==2").replace('jobs=4,','jobs=2,')
    text=text.replace('seconds=275','seconds=145').replace('before 275','before 145').replace(
        'reports and validator comparison','expanded forwarding comparison')
    write(name,text)
assert b'\r' not in (lab/'run.sh').read_bytes()
names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
with tarfile.open(lab/'payload.tgz','w:gz') as archive:
    for name in names:archive.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
assert receipt['freeBytesAfterArchive']>168*1024*1024+expanded+1835008+131072
config=dict(root=root,unit=unit,source=donor['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=donor['catalogSHA256'],catalogSHA256=catalog_sha,identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=(lab/'payload.tgz').stat().st_size,
    payloadSHA256=sha(lab/'payload.tgz'),unpackedBytes=expanded,cpythonWorkerSHA256=worker_sha)
save('config.json',config)
launcher=read(template/'remote-launch.py')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
write('remote-launch.py',launcher.replace('lython-b1173-fixtures','lython-b1180-confirmed-fixtures'))
print('Verified source-identical 32-file image and two CPython goldens.')
