from pathlib import Path
import base64
import hashlib
import json
import shutil
import statistics
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-20-cpython-expanded-forwarding")
read = lambda path: path.read_text(encoding="utf-8-sig")
load = lambda path: json.loads(read(path))
sha = lambda value: hashlib.sha256(value).hexdigest()
terminal = load(lab / "terminal-status.json")
receipt = load(lab / "archive-recovery.json")
identity = load(lab / "identity.json")
built = load(lab / "build-revision.json")
files = identity["imageFiles"]["candidate"]
assert len(files) == 32
assert {name: sha((lab / "frozen/candidate" / name).read_bytes()) for name in files} == files
assert built["sourceRevision"] == identity["sourceRevision"] and built["coreSHA256"] == files["Lokad.Lython.dll"]
assert terminal["exitCode"] == "1" and terminal["receipt"] is None and receipt["jobs"] == 2
assert receipt["verifiedAfterCollectionUnderIdleLease"]
assert sha((lab / "observations.tgz").read_bytes()) == receipt["archiveSHA256"]
assert not terminal.get("remainingTrace",False) and not terminal.get("remainingWorkers","")
assert all(receipt[name] for name in ("complete","allWorkersJoined","guestFixturesRemoved",
                                      "quietBeforeAndAfter","verifiedAfterCollectionUnderIdleLease"))
raw = load(lab / "retrieved/confirmation/confirmation.json")
cases = load(lab / "representative.json")["cases"]
assert sha((lab / "representative.json").read_bytes()) == load(lab / "identity.json")["catalogSHA256"]
assert raw["complete"] and len(raw["jobs"]) == len(cases) == 2
previous = load(lab.parent / "report-cpython-checkpoint/retrieved/confirmation/confirmation.json")
stock_python = previous["jobs"][0]["identities"]["CPython"]
labels = ["candidate","candidate-control","CPython","CPython-control"]
rows = []
for case, job in zip(cases, raw["jobs"], strict=True):
    assert job["case"] == case["id"] and job["workersJoinedAndFixturesRemoved"] and not job["diagnostic"]
    assert set(labels) == set(job["identities"])
    for role in labels[2:]:
        python = job["identities"][role]
        assert python["version"] == stock_python["version"] and python["version"].startswith("3.13.16 ")
        assert python["executableSha256"] == stock_python["executableSha256"]
        assert python["adapterSha256"] == identity["cpythonWorkerSHA256"]
    for role in labels[:2]:
        worker_image = identity["imageFiles"]["candidate"]
        supplied = {
            Path(lib["path"]).name: lib["sha256"].lower()
            for lib in job["identities"][role]["libraries"]
            if Path(lib["path"]).name in worker_image
        }
        assert supplied.get("Lokad.Lython.dll") == worker_image["Lokad.Lython.dll"]
        assert all(worker_image[name] == value for name, value in supplied.items())
    lanes = job["lanes"]
    expected_lanes = ("warm",) if case["id"] == "scripts.csv-invoice.large" else ("warm", "compile-run", "compile")
    assert tuple(lanes) == expected_lanes
    assert len(job["samples"]) == len(labels)*len(lanes)*5
    fixture = json.loads(case["fixtureJson"])
    byte_counts = {name:len(base64.b64decode(data)) for name,data in fixture.get("inputFiles",{}).items()}
    line_counts = {name:len(base64.b64decode(data).splitlines()) for name,data in fixture.get("inputFiles",{}).items()}
    for lane in lanes:
        engines = {}
        for label in labels:
            samples = [s for s in job["samples"] if s["engine"] == label and s["lane"] == lane]
            assert [s["round"] for s in samples] == list(range(5))
            values, cpu = [], []
            for row in samples:
                value = row["response"]
                assert value["completedInvocations"] > 0 and value["status"] == "Completed"
                assert value["sourceSha256"] == case["sourceSha256"] and value["fixtureSha256"] == case["fixtureSha256"]
                assert value.get("actualOutputSha256") == (None if lane == "compile" else case["expectedOutputSha256"])
                assert value.get("actualFilesSha256") == (None if lane == "compile" else case.get("expectedFilesSha256"))
                values.append(1000*value["elapsedTicks"]/value["clockFrequency"]/value["completedInvocations"])
                cpu.append(1000*row["externalProcessCpuTicks"]/row["externalCpuFrequency"]/value["completedInvocations"])
            median = statistics.median(values)
            low, _, high = statistics.quantiles(values, n=4, method="inclusive")
            engines[label] = dict(elapsedMs=median, cpuMs=statistics.median(cpu), elapsedIQRPercent=100*(high-low)/median)
        left = [engines[x]["elapsedMs"] for x in labels[:2]]
        right = [engines[x]["elapsedMs"] for x in labels[2:]]
        ratio = [l/r for l in left for r in right]
        lc, rc = [100*(max(x)/min(x)-1) for x in (left,right)]
        rows.append(dict(case=case["id"],lane=lane,inputFileBytes=byte_counts,inputFileLines=line_counts,
                         lythonMs=[min(left),max(left)],cpythonMs=[min(right),max(right)],
                         ratio=[min(ratio),max(ratio)],lythonControlPercent=lc,cpythonControlPercent=rc,
                         maxIQRPercent=max(e["elapsedIQRPercent"] for e in engines.values()),engines=engines))
        print(case["id"], lane, "L", left, "C", right, "ratio", min(ratio), max(ratio),
              "spread", lc, rc, "IQR max", rows[-1]["maxIQRPercent"])
assert len(rows) == 4
out.mkdir(exist_ok=False)
core_bytes=(lab/'frozen/candidate/Lokad.Lython.dll').read_bytes()
assert sha(core_bytes)==files['Lokad.Lython.dll']
summary = dict(source=load(lab/'identity.json')['sourceRevision'],coreSHA256=load(lab/"identity.json")["coreSHA256"]["candidate"],
               collection="B1180",rows=rows,elapsedSeconds=raw["elapsedSeconds"],
               archiveSHA256=receipt["archiveSHA256"],originalArchiveFloorFailure=True,measuredColdStartup=False,
               measuredCore="../2026-11-20-dynamic-record-layout/measured-core.dll.gz",
               memoryMeasurementIncluded=False, builtImageSource=built["imageSource"], verifiedBatches=80)
(out / "summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
for name in ["terminal-status.json","archive-recovery.json","observations.tgz"]:
    shutil.copyfile(lab / name, out / name)
with tarfile.open(out / "procedures.tar.xz", "w:xz", preset=6) as tar:
    tar.add(lab / "failed-stage.tar.xz", arcname="failed-stage.tar.xz")
    for file in sorted(lab.iterdir()):
        if file.suffix in {".json",".py",".sh",".log"} :
            tar.add(file,arcname=file.name)
print("Verified and archived B1180, all measured lanes and original control observations.")
