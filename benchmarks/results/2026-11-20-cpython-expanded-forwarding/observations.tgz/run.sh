set -eu
root=/home/lokad/lython-bench-checks/dynamic-record-cpython-b1180-20261120-confirmed
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
