#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/comprehension-assignments-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
filter='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~ComprehensionSuperCompatibility|FullyQualifiedName~CompileMemory|FullyQualifiedName~GeneratorExpressionAdmission)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    project="tests/$suite/$suite.csproj"
    dotnet restore "$project" --locked-mode --artifacts-path "$lab/ubuntu" 2>&1 | tee "$lab/$suite-ubuntu-restore.log"
    dotnet test "$project" -c Release -f net10.0 --no-restore --artifacts-path "$lab/ubuntu" --filter "$filter" 2>&1 | tee "$lab/$suite-ubuntu-net10.0.log"
done
