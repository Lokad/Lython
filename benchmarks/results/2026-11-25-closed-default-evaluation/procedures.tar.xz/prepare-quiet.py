from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
base = lab.with_name("async-map-prefix-20261125")
parser = lab.with_name("boolean-linear-20261125")
quiet = lab / "comparison/quiet"
donor = base / "comparison/quiet"
template = parser / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, indent=2) + "\n")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet / "identity.json")
assert identity["imageFiles"]["reference"] == read(donor / "identity.json")["imageFiles"]["candidate"]
receipt = read(donor / "terminal-status.json")["receipt"]
assert receipt["archivedAndVerifiedUnderLease"] and sha(donor / "observations.tar.xz") == receipt["archiveSHA256"]
for label, files in identity["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / label).iterdir()} == files
    assert read(lab / "comparison" / (label + "-verify.json"))["caseCount"] == 7
jobs = [
    ["diagnostic.generated-ordinary-definitions", "warm"],
    ["diagnostic.generated-live-definitions", "warm"],
    ["scripts.rule-default-closures", "warm"],
    ["scripts.annotated-rule-closures", "warm"],
    ["scripts.annotated-rule-closures.nested-factories.postponed", "warm"],
    ["scripts.rule-default-closures", "compile-run"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"],
    ["diagnostic.shipment-routing-callbacks", "warm-async"],
]
save(quiet / "jobs.json", {"warm": jobs})
identity["catalogs"]["jobs.json"] = dict(sha256=sha(quiet / "jobs.json"))
save(quiet / "identity.json", identity)
shutil.copyfile(template / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collect = (template / "collect.py").read_text(encoding="utf-8")
collect = collect.replace("b1693-fixtures", "b1699-fixtures").replace("len(jobs) == 8", "len(jobs) == 8")
assert "len(jobs) == 8" in collect
compile(collect, "collect.py", "exec")
write(quiet / "collect.py", collect)
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as bundle:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        bundle.add(quiet / name, arcname=name)
    bundle.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="closed-default-evaluation-b1699-20261125", reference="async-map-prefix-b1692-20261125",
                                 payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
launcher = (parser / "quiet.py").read_text(encoding="utf-8").replace("b1693", "b1699")
launcher = launcher.replace("lython-b1699-boolean-linear", "lython-b1699-closed-default-evaluation")
parser_donor = lab.with_name("compiled-entry-20261125") / "comparison/focused-compile/terminal-status.json"
launcher = launcher.replace(read(parser_donor)["receipt"]["archiveSHA256"], receipt["archiveSHA256"])
launcher = launcher.replace("seconds=352", "seconds=354").replace("RuntimeMaxSec=415", "RuntimeMaxSec=425")
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
duplicates = []
for location, directory in (
    ("boolean-linear-b1693-20261125", template),
    ("retained-async-cpython-b1694-20261125", lab.with_name("retained-async-cpython-20261125") / "external"),
    ("compiled-entry-b1689-20261125", parser_donor.parent),
):
    archived = directory / "observations.tar.xz"
    terminal = read(directory / "terminal-status.json")
    assert terminal["receipt"]["archivedAndVerifiedUnderLease"] and not terminal["fixtures"]
    assert sha(archived) == terminal["receipt"]["archiveSHA256"]
    with tarfile.open(archived) as bundle:
        raw = bundle.extractfile("confirmation/confirmation.json").read()
    duplicates.append(dict(location=location, bytes=len(raw), rawSHA256=hashlib.sha256(raw).hexdigest(),
                           archiveSHA256=sha(archived)))
save(lab / "verified-raw-replicas.json", duplicates)
print("Staged eight controlled definition and control lanes.")
