from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/closed-default-evaluation-20261125"
out = repo / "benchmarks/results/2026-11-25-closed-default-evaluation"
quiet = lab / "comparison/quiet"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = json.loads((quiet / "identity.json").read_text(encoding="utf-8"))
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab / "candidate.patch").read_bytes() == subprocess.check_output(
    ["git", "-C", tree, "diff", "--binary", "--", "src"])
(lab / "test.patch").write_bytes(subprocess.check_output(
    ["git", "-C", tree, "diff", "--binary", "--", "tests"]))
for role, files in identity["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == files
for folder, name in ((quiet, "identity.json"), (lab, "allocation-summary.json")):
    shutil.copyfile(folder / name, out / name)
files = [
    "candidate.patch", "test.patch", "catalog.py", "freeze.py", "allocations.py",
    "candidate-build.log", "test-ubuntu.sh", "ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
    "ubuntu-net10-Lokad.Lython.Tests.log", "comparison/reference-verify.json",
    "comparison/candidate-verify.json", "candidate-allocation-final.json",
    "reference-allocation-final.json", "prepare-quiet.py", "quiet.py", "archive.py", "package.py",
    "comparison/quiet/upload.json", "comparison/quiet/launch.log", "comparison/quiet/storage-custody.json",
    "verified-raw-replicas.json",
    "retire-native-iterator-routing.py",
    "retired-core/native-iterator-routing-20261125/local-custody.json",
    "retired-core/native-iterator-routing-20261125/vm-custody.json",
]
with tarfile.open(out / "procedures.tar.xz", "w:xz") as bundle:
    for name in files:
        bundle.add(lab / name, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as bundle:
    assert bundle.getnames() == files
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == sha(lab / name)
               for name in files)
print("Archived the exact source, test patch and custody history.")
