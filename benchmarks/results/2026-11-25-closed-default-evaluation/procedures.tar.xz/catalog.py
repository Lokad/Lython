from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
donor = lab.with_name("shared-default-write-20261125") / "comparison/quiet/representative.json"
catalog = json.loads(donor.read_text(encoding="utf-8-sig"))
selected = {
    "diagnostic.generated-ordinary-definitions",
    "scripts.rule-default-closures",
    "scripts.annotated-rule-closures",
    "scripts.annotated-rule-closures.nested-factories.postponed",
    "scripts.csv-invoice.method-policy.quoted-control",
    "diagnostic.shipment-routing-callbacks",
}
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in selected]
assert {entry["id"] for entry in catalog["cases"]} == selected
ordinary = next(case for case in catalog["cases"] if case["id"] == "diagnostic.generated-ordinary-definitions")
source = ordinary["source"]
handoff = "    return rule_0, rule_48, rule_95"
assert source.count(handoff) == 1 and source.count("first, middle, last = build(offset)") == 1
live_rules = ", ".join(f"rule_{index}" for index in range(96))
source = source.replace(handoff, f"{handoff}, [{live_rules}]")
source = source.replace("first, middle, last = build(offset)", "first, middle, last, live = build(offset)")
source = source.replace("    total += first() + middle() + last()", "    assert len(live) == 96 and live[48] is middle\n    total += first() + middle() + last()")
payload = source.encode("utf-8")
catalog["cases"].append(ordinary | dict(id="diagnostic.generated-live-definitions", source=source,
    sourceUtf8Bytes=len(payload), sourceSha256=hashlib.sha256(payload).hexdigest()))
(lab / "input-catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                                        encoding="utf-8", newline="\n")
