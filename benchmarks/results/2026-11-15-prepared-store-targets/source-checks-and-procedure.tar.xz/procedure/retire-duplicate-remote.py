from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
c={'path': 'caller-workspace-b803-20261115/observations.tgz', 'sha256': 'f74fc3c883977246bc9721f6aeede284b17f15a7b7dacfb3d39a220a33c949cb', 'bytes': 53950, 'custody': {'commit': 'bbc820273b7206d5465724c1ba8444744d18b8bc', 'archive': 'benchmarks/results/2026-11-15-caller-workspace-prototype/observations.tgz'}};b=Path('/home/lokad/lython-bench-checks').resolve();p=b/c['path']
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(q)for q in b.glob('*/guest-fixtures'))
 m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==c['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==c['sha256']and m.st_nlink==1
 aliases=[]
 for base,dirs,files in os.walk(b):
  for n in files:
   q=Path(base)/n;s=q.lstat()
   if(s.st_dev,s.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(q.relative_to(b)))
 assert aliases==[c['path']]
 before=shutil.disk_usage(b).free;p.unlink()
 print(json.dumps(dict(retiredOnly=c,allHashesPathsOwnershipLinksAndAliasesVerified=True,freshIdleLease=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free)))
