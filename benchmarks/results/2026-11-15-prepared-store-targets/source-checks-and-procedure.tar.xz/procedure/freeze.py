from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
repo=Path.cwd();r=Path(__file__).parent;f=r/'frozen';f.mkdir()
base=r.parent/'cased-preparation-r408/refined/candidate';images={}
for role in ['reference','candidate']:
 d=f/role;d.mkdir()
 for p in base.iterdir():
  if p.is_file():shutil.copyfile(p,d/p.name)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='0edc0c1c5a43852a61d3588a2f61973a0dd9b0b173d78b82e63ece5082383133'
assert all(images['reference'][n]==images['candidate'][n] for n in images['reference'] if n!='Lokad.Lython.dll')
sources={};checks={};ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 paths=[p for p in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()if(repo/p).is_file()]+['Directory.Build.props','Directory.Packages.props','global.json','NuGet.Config','tests/Lokad.Lython.Tests/LoweringArchitectureSubsystemTests.cs','tests/Lokad.Lython.PublicApi.Tests/PreparedStoreTargetTests.cs']
 for n in paths:
  p=repo/n;sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=n)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in (repo/'tests'/suite/'TestResults').glob('r413-*.trx'):
   checks[suite+'/'+p.name]=E.parse(p).find('.//t:Counters',ns).attrib;t.add(p,arcname='checks/'+suite+'/'+p.name)
 t.add(r/'baseline-source.tar',arcname='baseline-source.tar')
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,checks=checks,scope='One prepared store tree for ordinary/header/augmented assignments; no syntax-keyed read dictionary or duplicate executable expression lowering. Original nested-loop diagnostic failure and corrected checks retained. No public API change intended.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen copied images/source/checks', {k:v['Lokad.Lython.dll']for k,v in images.items()})
