from pathlib import Path
import shlex,subprocess
r=Path(__file__).parent
s=(r.parent/'caller-workspace-r411/inspect-vm.py').read_text(encoding='utf-8')
s=s.replace("r=Path(__file__).parent", "r=Path(__file__).parent")
s=s.replace('native-owned-slots-b709-20261114/candidate/Lokad.Lython.dll','caller-workspace-b803-20261115/candidate/Lokad.Lython.dll').replace('38c0562fdd20b4df2ba0f37806cfdfa1b20a31f9fbabcd522e28c611ea3e8567','6b6cfe6f9ae2558342fe5ae8ef2a1e3791bb2e61526d5d1aedb4b0816613db67')
exec(compile(s,str(__file__),'exec'))
