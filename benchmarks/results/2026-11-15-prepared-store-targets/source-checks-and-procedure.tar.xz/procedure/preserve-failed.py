from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';remote='/home/lokad/lython-bench-checks/prepared-stores-b805-20261115'
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/prepared-stores-b805-20261115')
with(r.parent/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 fixture=r/'guest-fixtures';assert os.path.ismount(fixture)and not list(fixture.iterdir())
 identity=json.loads((r/'identity.json').read_text())
 for role,files in identity['imageFiles'].items():
  for n,h in files.items():assert hashlib.sha256((r/role/n).read_bytes()).hexdigest()==h,n
 raw=json.loads((r/'confirmation/confirmation.json').read_text());assert not raw['complete']and len(raw['jobs'])==1 and raw['jobs'][0]['workersJoinedAndFixturesRemoved']
 (r/'failure-journal.txt').write_text(subprocess.check_output(['journalctl','--no-pager','-u','lython-b805-prepared-stores-20261115.service'],text=True))
 with tarfile.open(r/'failed-observations.tgz','w:gz',dereference=True)as t:
  for p in sorted(r.rglob('*')):
   if p.is_file()and p.name!='failed-observations.tgz'and not{'candidate','reference'}&set(p.relative_to(r).parts):t.add(p,arcname=p.relative_to(r).as_posix())
 with tarfile.open(r/'failed-observations.tgz')as t:assert len(json.loads(t.extractfile('confirmation/confirmation.json').read())['jobs'])==1
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 receipt=dict(terminal=True,success=False,reason='Collector used unsupported fresh protocol lane; actual worker accepts compile-run. First compilation partial retained, no runtime conclusion.',workersJoined=True,emptyRAMArchivedAndVerifiedBeforeUnmount=True,fullImagesVerified=True,archiveSHA256=hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(r).free)
 (r/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
(q/'preserve-failed-remote.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(q/'terminal-failure.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['failed-observations.tgz','failure-receipt.json']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+remote+'/'+n,str(q/n)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
receipt=json.loads((q/'failure-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((q/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
