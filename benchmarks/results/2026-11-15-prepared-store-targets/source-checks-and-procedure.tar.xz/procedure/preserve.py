from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
repo=Path.cwd();r=Path(__file__).parent;out=repo/'benchmarks/results/2026-11-15-prepared-store-targets';out.mkdir();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for src,n in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'frozen/identity.json','identity.json'),(r/'corrected/observations.tgz','observations.tgz'),(r/'corrected/archive-receipt.json','archive-receipt.json'),(r/'corrected/terminal-status.json','terminal-status.json'),(r/'quiet/failed-observations.tgz','failed-B805-observations.tgz'),(r/'quiet/failure-receipt.json','failed-B805-receipt.json')]:shutil.copyfile(src,out/n)
checks={}
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz')as t:
 for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for directory in ['original-stage-refusal','quiet','corrected']:
  for p in(r/directory).iterdir():
   if p.is_file()and p.name not in ['observations.tgz','failed-observations.tgz']:t.add(p,arcname=directory+'/'+p.name)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in(repo/'tests'/suite/'TestResults').glob('r413-*.trx'):
   checks[suite+'/'+p.name]=E.parse(p).find('.//t:Counters',ns).attrib;t.add(p,arcname='checks/'+suite+'/'+p.name)
 for p in(r/'allocation').iterdir():
  if p.is_file():t.add(p,arcname='allocation/'+p.name)
 for p in(r/'allocation/bin/Release/net11.0').glob('Allocation.*'):t.add(p,arcname='allocation/driver/'+p.name)
 for n in ['historical-aliases.json','duplicate-retirement.json','confirmation-retirement.json']:t.add(r/n,arcname=n)
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'));summary.update(retained=True,retentionDecisionPending=False,reason='Removes duplicate target families, syntax-keyed dictionaries and repeated lowering. Modest allocation reduction; no CPU improvement claimed. Possible manifest compile regression/contrary original partial retained as uncertainty.',fullQualificationPending=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'checks.json').write_text(json.dumps(dict(checks=checks,cleanNonincrementalReleaseSolutionBuild='Passed, zero warnings/errors; source image55ba4c8a frozen after build.',originalFailures='Nested-loop source column2 became28; loop-origin propagation fixed with original assertion unchanged. Ordinary11 initial child environment omitted pinned SDK PATH; all33 failed cases covered by corrected69case passing selection. Original full TRX retained.',publicApiChanges=False,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Preserved source, complete image identities, binaries, checks, original failed conditions and controls.',flush=True)
