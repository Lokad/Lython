from pathlib import Path
repo=Path.cwd()
files=['src/Lokad.Lython/Frontend/ExecutableScript.Statements.cs','src/Lokad.Lython/Runtime/LythonRuntime.Lowered.cs','src/Lokad.Lython/Runtime/LythonRuntime.LoweredAsync.cs','tests/Lokad.Lython.Tests/LoweringArchitectureSubsystemTests.cs']
renames={'LoweredNameAugmentedAssignmentTarget':'LoweredNameStoreTarget','LoweredSubscriptAugmentedAssignmentTarget':'LoweredSubscriptStoreTarget','LoweredSliceAugmentedAssignmentTarget':'LoweredSliceStoreTarget','LoweredMemberAugmentedAssignmentTarget':'LoweredMemberStoreTarget','LoweredAugmentedAssignmentTarget':'LoweredStoreTarget'}
for n in files:
 p=repo/n;s=p.read_text(encoding='utf-8')
 for old,new in renames.items():s=s.replace(old,new)
 s=s.replace('augmentedMember.Target.MemberName','augmentedMember.MemberName').replace('augmentedName.Target.Name','augmentedName.Name').replace('member.Target.MemberName','member.MemberName')
 if n.endswith('LythonRuntime.Lowered.cs'):
  s=s.replace('return ResolveAugmentedAssignmentTarget(name.Target, context);','return new AugmentedAssignmentTargetReference(ResolveName(name.Name, name.Span, context),\n                    value => StoreName(name.Name, value, context, name.Span));')
 if n.endswith('LythonRuntime.LoweredAsync.cs'):
  s=s.replace('return ResolveAugmentedAssignmentTarget(name.Target, context);','return ResolveLoweredAugmentedAssignmentTarget(name, context);')
 s=s.replace('ResolveLoweredStoreTarget','ResolveLoweredAugmentedAssignmentTarget')
 p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'src/Lokad.Lython/Runtime/LythonRuntime.Evaluation.Assignments.cs';s=p.read_text(encoding='utf-8');a=s.index('    private static AugmentedAssignmentTargetReference ResolveAugmentedAssignmentTarget(');b=s.index('    internal static object ReadSubscriptValue(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('Existing\naugmented read-modify-write targets remain unless sharing them simplifies this\nmigration.','Augmented read-modify-write now shares the same prepared shapes; its duplicate\nrecord family/factory and old raw-syntax augmented resolver are removed.');p.write_text(s,encoding='utf-8',newline='\n')
