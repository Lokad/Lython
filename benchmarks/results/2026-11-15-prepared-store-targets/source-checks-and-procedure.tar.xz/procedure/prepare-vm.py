from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet';q.mkdir();old=r.parent/'caller-workspace-r411/quiet';remote='/home/lokad/lython-bench-checks/prepared-stores-b805-20261115';unit='lython-b805-prepared-stores-20261115'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((old/'identity.json').read_text(encoding='utf-8'));keys=set(prior['imageFiles']['reference'])
images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
identity=dict(sourceRevision='R413 uncommitted55ba4c8a versus fully qualified1b82/frozen0edc0c1c',purpose='Single prepared store tree removes duplicate expression lowering, syntax-keyed reads and separate augmented shapes; compilation/fresh commands plus warm CSV control.',coreSHA256={k:images['candidate'if k.startswith('candidate')else'reference']['Lokad.Lython.dll']for k in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=json.loads((r.parent/'frontend-regions-r412/catalog.json').read_text(encoding='utf-8'));extra=json.loads((old/'representative.json').read_text(encoding='utf-8'));catalog['cases'].append(next(c for c in extra['cases']if c['id']=='scripts.csv-invoice.large'))
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('caller-workspace-b803-20261115','prepared-stores-b805-20261115').replace('lython-b803-caller-workspace-20261115',unit).replace('B803','B805')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+"jobs=[['scripts.config-manifest.small','compile'],['scripts.config-manifest.small','fresh'],['scripts.config-generated-guards.medium','compile'],['scripts.config-generated-guards.medium','fresh'],['scripts.csv-invoice.large','warm']]\n"+s[b:]
  a=s.index('count=1; end=');b=s.index('; rows=[]',a);s=s[:a]+"count=1; end=time.monotonic()+(8 if lane=='compile'else 5)"+s[b:]
  s=s.replace(' < 200,',' < 280,').replace('capturedWarmupSeconds=12, compilationWarmupSeconds=5','compilationWarmupSeconds=8')
 s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace("['jobs']==4","['jobs']==5").replace('jobs=4,','jobs=5,').replace("elapsedSeconds']<240","elapsedSeconds']<330")
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
archive='benchmarks/results/2026-11-15-caller-workspace-prototype/source-checks-and-procedure.tar.xz';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();raw=(repo/archive).read_bytes();assert subprocess.check_output(['git','show',head+':'+archive])==raw
with tarfile.open(repo/archive)as t:core=t.extractfile('frozen/candidate/Lokad.Lython.dll').read()
proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'));assert hashlib.sha256(core).hexdigest()==proof['sha256']and len(core)==proof['bytes']and proof['links']==len(proof['paths'])==1
proof['custody']=dict(commit=head,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member='frozen/candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
 t.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:unpacked=sum(m.size for m in t if m.isfile())
config=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115',sourceFiles=images['reference'],identity=identity,retire=proof,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
tree=ast.parse((r.parent/'regex-producer-050-r409/launch-vm.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='code'for t in n.targets));code=node.value.func.value.value
code=code.replace(" for role in ['reference','candidate']:\n"," for role in ['reference','candidate']:\n  (root/role).mkdir(exist_ok=True)\n").replace("os.link(root/'backend'/n if n in ['Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']else source/'candidate'/n,p)","os.link(source/'candidate'/n,p)").replace('lython-b798-fixtures','lython-b805-fixtures').replace('RuntimeMaxSec=150','RuntimeMaxSec=330').replace('CONFIG',repr(config))
ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
print('Preflight expected free',proof['freeBytes']+proof['bytes']-unpacked,'floor',254*1024*1024,'unpacked',unpacked,flush=True)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=260)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
