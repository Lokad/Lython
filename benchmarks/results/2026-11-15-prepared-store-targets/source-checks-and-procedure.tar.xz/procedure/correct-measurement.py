from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent;q=r/'corrected';q.mkdir();old=r/'quiet';root='/home/lokad/lython-bench-checks/prepared-stores-b806-20261115';unit='lython-b806-prepared-stores-20261115'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('prepared-stores-b805-20261115','prepared-stores-b806-20261115').replace('lython-b805-prepared-stores-20261115',unit).replace('B805','B806')
 if n=='collect.py':s=s.replace(",'fresh']",",'compile-run']")
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:size=sum(m.size for m in t if m.isfile())
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/prepared-stores-b805-20261115',payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size,identity=json.loads((old/'identity.json').read_text(encoding='utf-8')))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
c=CONFIG;b=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==source.parent==b and root.resolve()==root and source.resolve()==source and not root.exists()
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert json.loads((source/'failure-receipt.json').read_text())['workersJoined']
 for role,files in c['identity']['imageFiles'].items():
  for n,h in files.items():assert sha(source/role/n)==h,n
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 assert shutil.disk_usage(b).free>254*1024*1024+c['unpackedBytes']+65536
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 for role,files in c['identity']['imageFiles'].items():
  (root/role).mkdir()
  for n,h in files.items():os.link(source/role/n,root/role/n);assert sha(root/role/n)==h
 for n in ['identity.json','representative.json','cpython-worker.py']:os.link(source/n,root/n)
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(b).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b806-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=330','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],root=str(root),fullImagesVerified=True,originalB805Preserved=True,freeBytes=shutil.disk_usage(b).free)))
'''.replace('CONFIG',repr(c))
ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=260)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
