from pathlib import Path
import hashlib,json,shlex,subprocess,sys,tarfile
repo=Path.cwd();r=Path(__file__).parent
archive='benchmarks/results/2026-11-15-caller-workspace-prototype/observations.tgz';raw=(repo/archive).read_bytes();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','show',head+':'+archive])==raw
proof=dict(path='caller-workspace-b803-20261115/observations.tgz',sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),custody=dict(commit=head,archive=archive))
member = len(sys.argv)>1 and sys.argv[1]=='confirmation'
if member:
 with tarfile.open(repo/archive)as t:raw=t.extractfile('confirmation/confirmation.json').read()
 proof=dict(path='caller-workspace-b803-20261115/confirmation/confirmation.json',sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),custody=dict(commit=head,archive=archive,member='confirmation/confirmation.json'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
c=PROOF;b=Path('/home/lokad/lython-bench-checks').resolve();p=b/c['path']
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(q)for q in b.glob('*/guest-fixtures'))
 m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==c['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==c['sha256']and m.st_nlink==1
 aliases=[]
 for base,dirs,files in os.walk(b):
  for n in files:
   q=Path(base)/n;s=q.lstat()
   if(s.st_dev,s.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(q.relative_to(b)))
 assert aliases==[c['path']]
 before=shutil.disk_usage(b).free;p.unlink()
 print(json.dumps(dict(retiredOnly=c,allHashesPathsOwnershipLinksAndAliasesVerified=True,freshIdleLease=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free)))
'''.replace('PROOF',repr(proof))
(r/('retire-confirmation-remote.py'if member else'retire-duplicate-remote.py')).write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/('confirmation-retirement.json'if member else'duplicate-retirement.json')).write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
