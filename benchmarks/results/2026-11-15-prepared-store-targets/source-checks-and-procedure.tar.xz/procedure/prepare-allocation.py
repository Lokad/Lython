from pathlib import Path
import json,shutil
r=Path(__file__).parent;d=r/'allocation';d.mkdir()
s=(r.parent/'csv-final-payload-r379/allocation-driver-source.cs').read_text(encoding='utf-8')
s=s.replace('var rows = new List<object>();',"var mode = args[3];\nvar rows = new List<object>();")
s=s.replace('void Run()\n        {\n            reset.Invoke', '''void Run()
        {
            if (mode == "compile")
            {
                using var next = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
                if (!next.IsValid) throw new InvalidDataException("Compile failed.");
                return;
            }
            using var fresh = mode == "fresh" ? new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget) : null;
            reset.Invoke''')
s=s.replace('using (var result = script.Run(host))','using (var result = (fresh ?? script).Run(host))')
s=s.replace('if (budget.ReservedBytes != baseline) throw', 'fresh?.Dispose();\n            if (budget.ReservedBytes != baseline) throw')
s=s.replace('var warm = Stopwatch.StartNew();','reset.Invoke(host,null);\n        using(var golden=script.Run(host)) if(!golden.Success || golden.StandardOutput != expected) throw new InvalidDataException("Golden failed.");\n        var warm = Stopwatch.StartNew();')
s=s.replace('id = item.GetProperty("id").GetString(), allocatedBytesPerInvocation','id = item.GetProperty("id").GetString(), mode, allocatedBytesPerInvocation')
s=s.replace('boundary = "Complete warm runs', 'boundary = "Local allocation diagnostic: chosen compile/fresh/warm operation; complete fresh/warm runs')
(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
project=(r.parent/'word-buffer-loan-r324/allocation/Allocation.csproj').read_text(encoding='utf-8').replace('../reference/','../frozen/reference/')
(d/'Allocation.csproj').write_text(project,encoding='utf-8',newline='\n')
shutil.copyfile(r/'quiet/representative.json',d/'catalog.json')
