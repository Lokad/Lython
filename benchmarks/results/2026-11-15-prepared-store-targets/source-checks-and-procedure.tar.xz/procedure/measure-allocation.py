from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tempfile,time
r=Path(__file__).parent;d=r/'allocation';identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));catalog=json.loads((d/'catalog.json').read_text(encoding='utf-8'));sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;records={};start=time.monotonic();copies={}
with tempfile.TemporaryDirectory(prefix='lython-store-allocation-')as fixture:
 env['TEMP']=fixture;env['TMP']=fixture
 for role in ['reference','candidate']:
  image=d/role;shutil.copytree(r/'frozen'/role,image)
  for n,h in identity['images'][role].items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h,n
  for p in(d/'bin/Release/net11.0').iterdir():
   if p.name.startswith('Allocation.'):shutil.copyfile(p,image/p.name)
  copies[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in image.iterdir()if p.is_file()}
  for mode in ['compile','fresh','warm']:
   c=dict(catalog);c['cases']=[x for x in catalog['cases']if(x['id']=='scripts.csv-invoice.large')==(mode=='warm')];cat=d/(mode+'-catalog.json');cat.write_text(json.dumps(c,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
   output=d/(role+'-'+mode+'.json');assert not output.exists()
   with(d/(role+'-'+mode+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run([sdk+'/dotnet.exe',str(image/'Allocation.dll'),str(image),str(cat),str(output),mode],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=45)
   assert p.returncode==0,(role,mode,(d/(role+'-'+mode+'.log')).read_text(encoding='utf-8')[-2000:]);records[role,mode]=json.loads(output.read_text(encoding='utf-8'));print(role,mode,'complete',flush=True)
 assert not list(Path(fixture).iterdir())
rows=[]
for mode in ['compile','fresh','warm']:
 for v in records['reference',mode]['rows']:
  a=statistics.median(v['allocatedBytesPerInvocation']);b=statistics.median(next(x for x in records['candidate',mode]['rows']if x['id']==v['id'])['allocatedBytesPerInvocation']);rows.append(dict(case=v['id'],lane=mode,referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1)))
(d/'image-hashes.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,complete=True,elapsedSeconds=time.monotonic()-start,allGoldensAndBalancesPassed=True,allUsersJoinedAndFixturesRemoved=True,performanceQualified=False,CPUorElapsedClaim=False,boundary='Local process-wide natural-GC allocations. Compile/dispose or complete fresh/warm with reset/I/O/goldens/result cleanup. One additional compiled control remains held outside counted operations. Not identical to quiet command-v2 timing boundary.'),indent=2)+'\n',encoding='utf-8',newline='\n');print(rows,flush=True)
