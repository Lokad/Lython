from pathlib import Path
import fcntl,hashlib,json,os,shutil,signal,subprocess,tarfile,time

r=Path('/home/lokad/lython-bench-checks/shared-hash-b779-20261115')
source=r.parent/'invocation-lifetime-b777-20261115'
dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
env=dict(os.environ);env['DOTNET_ROOT']=str(Path(dotnet).parent);env['TMPDIR']=str(r/'guest-fixtures')
assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
def stop(*_):raise InterruptedError('Owned collection stopped; join users before cleanup.')
signal.signal(signal.SIGTERM,stop)
with(r.parent/'comparison-vm.lock').open('a')as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert os.path.ismount(r/'guest-fixtures')
    time.sleep(3)
    subprocess.run([dotnet,str(source/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(r/'machine-before.json')],env=env,check=True)
    assert json.loads((r/'machine-before.json').read_text())['gate']['quiet']
    started=time.monotonic();rows=[]
    for index in (1,2):
        folder=r/f'process-{index}';folder.mkdir();shutil.copyfile(r/'witness.json',folder/'witness.json')
        command=[dotnet,str(r/'tool/complete-jobs.dll'),str(source/'reference/Lokad.Lython.Benchmarks.dll'),str(source/'candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(folder/'witness.json'),'reverse'if index==2 else'normal','warm','async']
        with(folder/'stdout.json').open('w')as output,(folder/'stderr.txt').open('w')as errors:
            result=subprocess.run(command,env=env,cwd=folder,stdout=output,stderr=errors,timeout=65)
        assert result.returncode==0, f'Process{index} failed; all original stdout/stderr retained.'
        assert not(folder/'stderr.txt').read_text()
        data=json.loads((folder/'stdout.json').read_text())
        assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']and data['imageIsolationVerified']
        assert len(data['observations'])==1 and data['asynchronous']and not data['serverGc']and not any(data['runtimeOverrides'].values())
        assert not list((r/'guest-fixtures').iterdir())
        rows.append(dict(process=index,joined=True,allGoldensAndBalancesPassed=True,hashWitness=data['observations'][0]['hashWitness']))
        (r/'progress.json').write_text(json.dumps(dict(complete=False,processes=rows,elapsedSeconds=time.monotonic()-started),indent=2)+'\n')
    time.sleep(3)
    subprocess.run([dotnet,str(source/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(r/'machine-after.json')],env=env,check=True)
    assert json.loads((r/'machine-after.json').read_text())['gate']['quiet']
    assert not list((r/'guest-fixtures').iterdir())
    subprocess.run(['sudo','-n','umount',str(r/'guest-fixtures')],check=True);(r/'guest-fixtures').rmdir()
    (r/'progress.json').write_text(json.dumps(dict(complete=True,processes=rows,elapsedSeconds=time.monotonic()-started),indent=2)+'\n')
    with tarfile.open(r/'observations.tgz','w:gz')as archive:
        for file in sorted(r.rglob('*')):
            if file.is_file()and file.name!='observations.tgz':archive.add(file,arcname=file.relative_to(r).as_posix())
    with tarfile.open(r/'observations.tgz')as archive:
        assert json.loads(archive.extractfile('progress.json').read())['complete']
        for index in (1,2):assert json.loads(archive.extractfile(f'process-{index}/stdout.json').read())['allBalancesZero']
    assert shutil.disk_usage(r).free>252*1024*1024
    receipt=dict(complete=True,processes=2,allUsersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(r).free,elapsedSeconds=time.monotonic()-started,performanceQualified=False)
    (r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
