from pathlib import Path
import hashlib,json,shutil,tarfile

notes=Path(__file__).parent;r=notes/'shared-hash-r391';out=Path('benchmarks/results/2026-11-15-shared-hash-control');out.mkdir(exist_ok=False)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allUsersJoined']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['summary.json','identity.json','prospective.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'local-procedures.tar.xz','w:xz')as archive:
    for name in ['prepare-shared-hash-r391.py','launch-shared-hash-r391.py','correct-shared-hash-preparation-r391.py','save-shared-hash-r391.py']:archive.add(notes/name,arcname=name)
    for name in ['build.log','config.json','launch-command.py','launch-attempt.json','launch.log','preparation-correction-command.py','preparation-correction-attempt.json','preparation-correction.log','observe-not-before.json','retrieve.py','summarize.py']:archive.add(r/name,arcname='local/'+name)
decision=dict(status='retain-pending-delivery',candidate='f304b3db8f03e9e9310cabf4b6daf458e22be4fb3df0bcf4d18809cabfd97df8',reference='810379be/8fbfa3f0',
              reason='Coherent complete-invocation ownership lifetime removes outer cleanup continuation without a replacement dispatcher. Focused semantics/ownership/cancellation/stack pass. File wider CPU improves. Text remains uncertain rather than proving consistent regression.',
              newControl='Same CoreLib/hash witnesses still give7.82%unchanged-reference invocation spread in process1. Candidate -.2.43..+5.20%invocation there; process2 -5.35..-3.74%invocation/-8.28..-7.28%widerCPU with1.68%reference spread. Hashing alone cannot explain variability.',
              retainedDebt=['All B777/B778 adverse/moving text observations remain unresolved','Initial unchanged sync-text elapsed +.05..+1.44% and local short-sync +.96..+4.12% diagnostics remain','No general speedup, allocation reduction, pending-I/O latency or portable CPU claim'],
              completionMilestone='Full Windows/Ubuntu actual.NET11/10, originalstress and installed Release consumers. Preserve no-public-thread-affinity, public cancellation status/token, scope-creation failure cleanup, retained aliases/results and first refusal.',
              nextRoadmap='Continue substantial common text/operand work from current dominant samples. No further unchanged R390 timing campaign; different justified designs remain eligible.',publicationHeld=True)
decision['newControl']=decision['newControl'].replace('-.2.43','-2.43')
(notes/'invocation-lifetime-r390/retention-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
(Path('benchmarks/results/2026-11-15-invocation-lifetime')/'retention-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(saved=str(out),status=decision['status'],archiveSHA256=receipt['archiveSHA256'])))
