from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;c=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert not(r/'terminal-status.json').exists()
bound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'));assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
code=r'''from pathlib import Path
import fcntl,json,subprocess
c=CONFIG
root=Path(c['root']);s=subprocess.run(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID,SubState,Result,ExecMainStatus'],capture_output=True,text=True)
if'ActiveState=active'in s.stdout:print(json.dumps(dict(live=True,service=s.stdout)));raise SystemExit(0)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(live=False,service=s.stdout,exitCode=(root/'exit-code.txt').read_text().strip()if(root/'exit-code.txt').exists()else None,receipt=json.loads((root/'archive-receipt.json').read_text())if(root/'archive-receipt.json').exists()else None,remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.*complete-jobs.dll|[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,remainingFixtures=(root/'guest-fixtures').exists(),journal=subprocess.run(['journalctl','-u',c['unit']+'.service','-n','8','--no-pager'],capture_output=True,text=True).stdout)))
'''.replace('CONFIG',repr(c))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=60);assert done.returncode==0,done.stderr
status=json.loads(done.stdout);(r/'observed-status.json').write_text(done.stdout,encoding='utf-8');print(done.stdout,flush=True)
if status['live']:raise SystemExit(0)
assert status['exitCode']=='0'and status['receipt']['complete']and status['receipt']['allUsersJoined']and not status['remainingWorkers']and not status['remainingFixtures']
(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['archive-receipt.json','observations.tgz']:
    done=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/'+name,str(r/name)],capture_output=True);assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as archive:archive.extractall(out,filter='data')
print('B779 both shared-hash process controls complete, terminal cached and raw archive verified.',flush=True)
