from pathlib import Path
import json,statistics

r=Path(__file__).parent;rows=[]
for index in (1,2):
    data=json.loads((r/f'retrieved/process-{index}/stdout.json').read_text(encoding='utf-8'))
    assert data['imageIsolationVerified']and data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']
    observation=data['observations'][0];samples=observation['samples'];values={}
    for label in ['before','candidate','before-control']:
        selected=[s for s in samples if s['image']==label];assert len(selected)==5
        values[label]={metric:[s[field]/s['jobs']for s in selected]for metric,field in [('invocationMilliseconds','executionMilliseconds'),('fullRequestMilliseconds','elapsedMilliseconds'),('fullRequestCpuMilliseconds','cpuMilliseconds'),('fullRequestAllocatedBytes','allocatedBytes')]}
    med={label:{metric:statistics.median(v)for metric,v in metrics.items()}for label,metrics in values.items()}
    changes={metric:[100*(med['candidate'][metric]/med[label][metric]-1)for label in ['before','before-control']]for metric in med['candidate']}
    controls={metric:100*(med['before-control'][metric]/med['before'][metric]-1)for metric in med['candidate']}
    iqr={label:{metric:100*(statistics.quantiles(v,n=4)[2]-statistics.quantiles(v,n=4)[0])/statistics.median(v)for metric,v in metrics.items()}for label,metrics in values.items()}
    row=dict(process=index,hashWitness=observation['hashWitness'],coreLibSHA256=data['sharedCoreLibSHA256'],medians=med,candidateChangePercent=changes,unchangedReferenceControlPercent=controls,iqrPercent=iqr,identities=observation['identities'])
    rows.append(row);print(json.dumps(row),flush=True)
summary=dict(complete=True,processes=rows,allGoldensAndBalancesPassed=True,allImagesAndWitnessesValidated=True,performanceQualified=False,boundary='Same CoreLib/hash witnesses inside each process, distinct noncollectible images share process GC. Invocation clock includes RunAsync and its native cleanup, excludes result disposal/full goldens/reset; full-request clocks include those. No portable CPU claim or inferred explanation of all B777/B778 variability.')
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
