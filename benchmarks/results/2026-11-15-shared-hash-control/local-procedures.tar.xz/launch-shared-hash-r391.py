from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile

notes=Path(__file__).parent;r=notes/'shared-hash-r391';assert not(r/'launch-attempt.json').exists()
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
frozen=json.loads((notes/'invocation-lifetime-r390/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in frozen['sources'].items())
remote='/home/lokad/lython-bench-checks/shared-hash-b779-20261115';unit='lython-b779-shared-hash-20261115'
(r/'run.sh').write_text('set -eu\nroot='+remote+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
ast.parse((r/'collect.py').read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for name in ['identity.json','prospective.json','catalog.json','witness.json','collect.py','run.sh']:archive.add(r/name,arcname=name)
    archive.add(r/'tool/Program.cs',arcname='tool/Program.cs')
    for name in identity['toolFiles']:archive.add(r/'tool/bin/Release/net11.0'/name,arcname='tool/'+name)
with tarfile.open(r/'payload.tgz')as archive:unpacked=sum(m.size for m in archive.getmembers())
config=dict(root=remote,unit=unit,sourceRoot='/home/lokad/lython-bench-checks/invocation-lifetime-b777-20261115',identity=identity,auxiliaryFiles=frozen['auxiliaryFiles'],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py|[d]otnet.*complete-jobs.dll'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 assert(source/'exit-code.txt').read_text().strip()=='0'and json.loads((source/'archive-receipt.json').read_text())['complete']
 for role in ['candidate','reference']:
  assert sha(source/role/'Lokad.Lython.dll')==config['identity']['cores'][role]
  for name,h in config['auxiliaryFiles'].items():assert sha(source/role/name)==h
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']+32768
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for name,h in config['identity']['toolFiles'].items():assert sha(root/'tool'/name)==h
 assert sha(root/'catalog.json')==config['identity']['catalogSHA256']and sha(root/'witness.json')==config['identity']['witnessSHA256']
 ast.parse((root/'collect.py').read_text());subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noRuntimeImageUpload=True,noRetirement=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b779-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
now=datetime.datetime.now(datetime.timezone.utc);(r/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60)
(r/'launch.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,(result.stdout+result.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat(),ownerSeconds=150),indent=2)+'\n',encoding='utf-8',newline='\n')
print(result.stdout.decode('utf-8'));print('Earliest observation',(now+datetime.timedelta(seconds=90)).isoformat(),flush=True)
