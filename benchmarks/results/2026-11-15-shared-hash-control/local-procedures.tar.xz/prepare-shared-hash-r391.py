from pathlib import Path
import hashlib,json,subprocess

notes=Path(__file__).parent;out=notes/'shared-hash-r391';out.mkdir(exist_ok=False)
tool=out/'tool';tool.mkdir();old=notes/'call-lifecycle-r301/tool'
source=(old/'Program.cs').read_text(encoding='utf-8')
source=source.replace('cases.Length != 7','cases.Length != 1').replace('Require existing seven complete search/CSV/text/JSON/UTF8-report/UTF16-report fixtures.','Require the existing captured-text fixture.')
source=source.replace('var warmups = 16;','var warmups = 8;').replace('var batch = 8;','var batch = 256;')
source=source.replace('for (var i = 0; i < warmups; i++) foreach (var image in images) image.Measure(phase);',
'''foreach (var image in images)
    {
        var warmup = Stopwatch.StartNew();
        do { image.Measure(phase); } while (warmup.Elapsed.TotalSeconds < warmups);
    }''')
source=source.replace('warmupsPerImage = warmups','warmupFullRequestSecondsPerImage = warmups')
start=source.index('purpose = "R289');end=source.index('\n    runtime =',start)
source=source[:start]+'purpose = "R391 bounded captured-text method control; existing complete-job driver, same CoreLib/hash witnesses, distinct frozen images and unchanged control; no portable CPU claim",'+source[end:]
source=source.replace('        nativeNodeStorage = images.ToDictionary(i => i.Label, i => i.NativeNodeStorage),\n','').replace('    public object NativeNodeStorage { get; }\n','')
start=source.index('        // Host-only allocation observation');end=source.index('        var adapter=',start);source=source[:start]+source[end:]
start=source.index('    private static object MeasureCells');end=source.index('    private long Balance',start);source=source[:start]+source[end:]
(tool/'Program.cs').write_text(source,encoding='utf-8',newline='\n')
(tool/'complete-jobs.csproj').write_text((old/'complete-jobs.csproj').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
catalog=json.loads((notes/'invocation-lifetime-r390/catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large'];assert len(catalog['cases'])==1
(out/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'witness.json').write_text(json.dumps(dict(source="return [hash('alpha'), hash('beta'), hash('éclair'), hash('零')]\n"),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
prospective=dict(purpose='Source-supported hash-variation method control after unresolved independent-process text comparisons. Hash variation is plausible, not proved causal.',
    reference='810379be/frozen8fbfa3f0',candidate='R390/frozenf304b3db',tool='Existing R301 complete-job driver, one fixture, warmup corrected from iteration count to eight full-request seconds,256jobs/batch; removed discarded node-storage inspection.',
    processes=2,imagesPerProcess=['before','candidate','before-control'],sharedCoreLib=True,hashWitnessesMustAgree=True,rounds=5,warmupSecondsPerImage=8,
    boundary='Separate RunAsync clocks from wider fixture reset/goldens/disposal; shared process GC remains a limitation. No forced GC or runtime overrides.',
    stoppingCriterion='Finish both process controls, interpret alongside all B777/B778 adversity and file/sync controls, then retain/refine/withdraw. Do not infer a general gain or erase prior regressions.',
    ownerSeconds=150,noNewRuntimeOrFramework=True,publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
with(out/'build.log').open('w',encoding='utf-8',newline='\n')as log:
    result=subprocess.run(['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','build',str(tool/'complete-jobs.csproj'),'-c','Release','-f','net11.0','-v','quiet'],stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(out/'build.log').read_text(encoding='utf-8')
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(tool/'bin/Release/net11.0').iterdir()if p.is_file()and p.suffix in ['.dll','.json']}
identity=dict(toolFiles=files,programSHA256=hashlib.sha256((tool/'Program.cs').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((out/'catalog.json').read_bytes()).hexdigest(),witnessSHA256=hashlib.sha256((out/'witness.json').read_bytes()).hexdigest(),cores=json.loads((notes/'invocation-lifetime-r390/candidate-identity.json').read_text(encoding='utf-8'))['coreSHA256'])
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,toolFiles=files,cores=identity['cores'])))
