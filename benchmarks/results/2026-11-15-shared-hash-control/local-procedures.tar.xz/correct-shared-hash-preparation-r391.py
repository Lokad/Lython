from pathlib import Path
import ast

script=Path(__file__).with_name('launch-shared-hash-r391.py').read_text(encoding='utf-8')
script=script.replace("assert not(r/'launch-attempt.json').exists()", "assert not(r/'preparation-correction-attempt.json').exists(); assert 'Allocation.deps.json' in (r/'launch.log').read_text(encoding='utf-8') and 'FileNotFoundError' in (r/'launch.log').read_text(encoding='utf-8')")
script=script.replace("auxiliaryFiles=frozen['auxiliaryFiles']", "auxiliaryFiles=json.loads((notes/'invocation-lifetime-r390/quiet/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']")
script=script.replace("(r/'launch-command.py')", "(r/'preparation-correction-command.py')").replace("(r/'launch-attempt.json').write_text", "(r/'preparation-correction-attempt.json').write_text").replace("(r/'launch.log').write_bytes", "(r/'preparation-correction.log').write_bytes")
script=script.replace(" assert(source/'exit-code.txt')", " state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)\n assert 'LoadState=not-found'in state and 'MainPID=0'in state\n assert(source/'exit-code.txt')")
ast.parse(script)
exec(compile(script,str(__file__),'exec'))
