from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
read = lambda path: json.loads(path.read_bytes())
digest = lambda source: sha256(source).hexdigest()
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and terminal['exitCode'] == '0' and not terminal['fixtures']
assert receipt['freshPairs'] == 14
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined',
    'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
archive = quiet / 'observations.tar.xz'
assert digest(archive.read_bytes()) == receipt['archiveSHA256']

identity = read(quiet / 'identity.json')
assert identity['sourceRevision'].startswith('83042273c')
assert len(identity['imageFiles']['candidate']) == 32
assert {p.name: digest(p.read_bytes()) for p in (quiet / 'local-image').iterdir()} == identity['imageFiles']['candidate']
assert read(quiet / 'stage-custody.json')['reused'] == {'donor': 32}
catalog = {case['id']: case for case in read(quiet / 'representative.json')['cases']}
observations = {case: [] for case in catalog}
with tarfile.open(archive) as bundle:
    assert json.load(bundle.extractfile('identity.json')) == identity
    for name, spec in identity['catalogs'].items():
        assert digest(bundle.extractfile(name).read()) == spec['sha256']
    for phase in ('before', 'after'):
        assert json.load(bundle.extractfile(f'confirmation/machine-{phase}.json'))['gate']['quiet']
    for attempt in range(7):
        run = json.load(bundle.extractfile(f'confirmation/fresh-{attempt:02d}.json'))
        assert run['state'] == 'Completed' and run['caseCount'] == 2
        assert run['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
        assert run['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
        assert run['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
        assert run['launched']['adapter']['sha256'] == identity['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
        assert len(run['rows']) == 4 and len(run['validation']) == 2
        assert [row['engine'] for row in run['rows']] == ['Lython','CPython'] * 2
        pair = {case: {} for case in catalog}
        for row in run['rows']:
            child = row['observation']
            reply = child['response']
            case = catalog[reply['caseId']]
            for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'):
                assert reply[key] == case[key]
            assert reply['actualOutputSha256'] == case['expectedOutputSha256']
            assert reply.get('actualFilesSha256') == case.get('expectedFilesSha256')
            assert reply['completedInvocations'] == 1
            payload = 'confirmation/' + row['path'].split('/confirmation/',1)[1]
            assert digest(bundle.extractfile(payload).read()) == row['payloadSha256']
            pair[reply['caseId']][row['engine']] = child['elapsedTicks'] * 1000 / child['clockFrequency']
        for case, pair_clocks in pair.items():
            assert set(pair_clocks) == {'Lython','CPython'}
            observations[case].append(pair_clocks)

result = []
for case, pairs in observations.items():
    medians = {engine: median(item[engine] for item in pairs) for engine in ('Lython','CPython')}
    ratios = [pair['Lython'] / pair['CPython'] for pair in pairs]
    result.append(dict(case=case, elapsedMilliseconds=medians,
        medianRatio=medians['Lython']/medians['CPython'], pairedRatioRange=[min(ratios),max(ratios)], pairs=pairs))
    print(case, medians, 'median ratio', result[-1]['medianRatio'], 'paired range', result[-1]['pairedRatioRange'])
summary = dict(sourceRevision=identity['sourceRevision'], launches=28, pairs=14,
    cpythonVersion='3.13.16', budgetBoundary='process launch through exit and pipe drain', rows=result)
(quiet / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
