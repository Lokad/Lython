from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / 'short-frontend-cpython-b1968-20261128'
donor = prior / 'comparison/quiet'
quiet = lab / 'comparison/quiet'
stage = 'script-cpython-fresh-b1970-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')


def save(path, data):
    write(path, json.dumps(data, indent=2) + '\n')


old = read(donor / 'identity.json')
terminal = read(donor / 'terminal-status.json')
archive = terminal['receipt']
assert old['sourceRevision'].startswith('83042273c') and not terminal['live'] and not terminal['fixtures']
assert archive['complete'] and archive['quietBeforeAndAfter'] and archive['allWorkersJoined']
assert archive['archiveSHA256'] == digest(donor / 'observations.tar.xz')
files = old['imageFiles']['candidate']
assert len(files) == 32 and {path.name: digest(path) for path in (donor / 'local-image').iterdir()} == files

quiet.mkdir(parents=True)
copytree(donor / 'local-image', quiet / 'local-image')
assert {path.name: digest(path) for path in (quiet / 'local-image').iterdir()} == files
assert digest(donor / 'representative.json') == old['catalogs']['representative.json']['sha256']
catalog = read(donor / 'representative.json')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in
    ('diagnostic.file-search-first-line', 'scripts.config-edit.small')]
assert len(catalog['cases']) == 2
save(quiet / 'representative.json', catalog)
save(quiet / 'jobs.json', dict(rounds=7, cases=[case['id'] for case in catalog['cases']]))
for name in ('cpython-worker.py', 'run.sh'):
    copy2(donor / name, quiet / name)
assert digest(quiet / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
image = dict(old, purpose='Measure first process launch on the exact B1968 image.',
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json','jobs.json')},
    donorArchiveSHA256=archive['archiveSHA256'])
save(quiet / 'identity.json', image)

collector = (donor / 'collect.py').read_text(encoding='utf-8')
start = collector.index('cpu_frequency = ')
finish = collector.index('def stop(*_)', start)
collector = collector[:start] + collector[finish:]
start = collector.index('assert len(jobs) == 4')
finish = collector.index('    time.sleep(20)', start)
collector = collector[:start] + '''assert jobs['rounds'] == 7 and set(jobs['cases']) == set(cases)
assert manifest_hash == identity['catalogs'][catalog.name]['sha256']

def fresh():
    started = time.monotonic()
    for attempt in range(jobs['rounds']):
        receipt = out / f'fresh-{attempt:02d}.json'
        subprocess.run([dotnet, worker, '--compare', 'smoke-fresh', '--catalog', catalog,
            '--dotnet', dotnet, '--python', python, '--python-worker', root/'cpython-worker.py',
            '--out', receipt], env=env, check=True, timeout=30)
        observed = json.loads(receipt.read_text())
        assert observed['state'] == 'Completed' and observed['caseCount'] == len(cases)
        assert observed['catalogSha256'] == identity['catalogs'][catalog.name]['sha256']
        assert observed['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
        assert observed['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
        assert observed['launched']['adapter']['sha256'] == identity['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
''' + collector[finish:]
collector = collector.replace('    record.update(complete=True,elapsedSeconds=time.monotonic()-started);save()\n    return record',
    "    return dict(pairs=jobs['rounds'] * len(cases), elapsedSeconds=time.monotonic()-started)")
collector = collector.replace("warmJobs=len(warm['jobs']) if warm else None", "freshPairs=warm['pairs'] if warm else None")
collector = collector.replace('result=warm()', 'result=fresh()').replace('lython-b1968-cpython-fixtures', 'lython-b1970-cpython-fixtures')
compile(collector, 'collect.py', 'exec')
write(quiet / 'collect.py', collector)

paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json',
    'cpython-worker.py', 'run.sh', 'collect.py')}
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as bundle:
    for name, path in paths.items():
        bundle.add(path, arcname=name)
with tarfile.open(payload) as bundle:
    assert all(sha256(bundle.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
save(quiet / 'upload.json', dict(root=stage, donor=read(donor/'upload.json')['root'], donorFiles=files,
    donorArchive=archive['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(p.stat().st_size for p in paths.values()), minimumAfterStageBytes=16*1024*1024, caseCount=2))

launch = (prior / 'quiet-vm.py').read_text(encoding='utf-8')
write(lab / 'quiet-vm.py', launch.replace('lython-b1968-short-frontend-cpython',
    'lython-b1970-fresh-command-cpython').replace('RuntimeMaxSec=370', 'RuntimeMaxSec=180'))
write(lab / 'verify.sh', (prior / 'verify.sh').read_text(encoding='utf-8').replace(prior.name, lab.name))
print(old['sourceRevision'], 'two goldens and fourteen fresh pairs on the existing image')
