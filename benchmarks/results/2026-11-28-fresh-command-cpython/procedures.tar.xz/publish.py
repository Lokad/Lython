from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
out = lab.parents[3] / 'benchmarks/results/2026-11-28-fresh-command-cpython'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
terminal = read(quiet / 'terminal-status.json')
summary = read(quiet / 'summary.json')
assert summary['sourceRevision'] == identity['sourceRevision'] and summary['launches'] == 28
assert terminal['receipt']['freshPairs'] == 14 and terminal['exitCode'] == '0'
assert terminal['receipt']['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
for role in ('local','remote'):
    verify = read(quiet / f'candidate-{role}-verify.json')
    assert verify['state'] == 'Completed' and verify['caseCount'] == 2
    assert verify['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert verify['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
    assert verify['launched']['python']['sha256'] == identity['expectedCPythonSHA256']

out.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    copy2(quiet / name, out / name)
    assert digest(out / name) == digest(quiet / name)
procedures = {name: lab / name for name in ('prepare.py', 'quiet-vm.py', 'verify.sh', 'summarize.py', 'publish.py')}
procedures.update({name: quiet / name for name in ('launch.log','upload.json','stage-custody.json',
    'candidate-local-verify.json','candidate-remote-verify.json','exit-code.txt','archive-receipt.json')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified 14 launch pairs and both procedure and observation archives.')
