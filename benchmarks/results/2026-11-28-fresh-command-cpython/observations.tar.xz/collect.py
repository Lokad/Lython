"""Representative CPython delivery checkpoint through unchanged comparison workers/protocol."""
import contextlib, fcntl, hashlib, importlib.util, json, math, os, shutil, tarfile
import statistics, subprocess, tempfile, time, signal
from pathlib import Path

root = Path(__file__).resolve().parent
dotnet = Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
python = Path('/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13')
catalog = root / 'representative.json'
spec = importlib.util.spec_from_file_location('protocol', root / 'cpython-worker.py')
protocol = importlib.util.module_from_spec(spec); spec.loader.exec_module(protocol)
cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}
manifest_hash = hashlib.sha256(catalog.read_bytes()).hexdigest()
identity = json.loads((root / 'identity.json').read_text())
image = Path(identity['frozenImage'])
worker = image / 'Lokad.Lython.Benchmarks.dll'
assert set(identity['coreSHA256']) == {'candidate','candidate-control'}
out = root / 'confirmation'; out.mkdir(exist_ok=False)
env = os.environ.copy(); env['DOTNET_ROOT'] = str(dotnet.parent)
owned_ram=root/'guest-fixtures'
env['TMPDIR']=str(owned_ram);tempfile.tempdir=str(owned_ram)
assert not any(k.startswith(('DOTNET_', 'COMPlus_')) and k != 'DOTNET_ROOT' for k in env)

def stop(*_):raise InterruptedError('Owned checkpoint stopped; join all users before cleanup.')
signal.signal(signal.SIGTERM,stop)



def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def check_image():
    assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['cpythonWorkerSHA256']
    assert hashlib.sha256(python.read_bytes()).hexdigest()==identity['expectedCPythonSHA256']
    for name, sha in identity['imageFiles']['candidate'].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==sha, name
    assert hashlib.sha256((root/'jobs.json').read_bytes()).hexdigest()==identity['catalogs']['jobs.json']['sha256']

jobs = json.loads((root/'jobs.json').read_text())
assert jobs['rounds'] == 7 and set(jobs['cases']) == set(cases)
assert manifest_hash == identity['catalogs'][catalog.name]['sha256']

def fresh():
    started = time.monotonic()
    for attempt in range(jobs['rounds']):
        receipt = out / f'fresh-{attempt:02d}.json'
        subprocess.run([dotnet, worker, '--compare', 'smoke-fresh', '--catalog', catalog,
            '--dotnet', dotnet, '--python', python, '--python-worker', root/'cpython-worker.py',
            '--out', receipt], env=env, check=True, timeout=30)
        observed = json.loads(receipt.read_text())
        assert observed['state'] == 'Completed' and observed['caseCount'] == len(cases)
        assert observed['catalogSha256'] == identity['catalogs'][catalog.name]['sha256']
        assert observed['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
        assert observed['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
        assert observed['launched']['adapter']['sha256'] == identity['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
    time.sleep(20)
    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')],env=env,check=True)
    assert json.loads((out/'machine-after.json').read_text())['gate']['quiet']
    return dict(pairs=jobs['rounds'] * len(cases), elapsedSeconds=time.monotonic()-started)

def archive(complete, warm):
    bundle=root/'observations.tar.xz'
    with tarfile.open(bundle,'w:xz') as frozen:
        for item in ('identity.json','representative.json','jobs.json','confirmation','collect.py','run.sh'):
            frozen.add(root/item,arcname=item)
    with tarfile.open(bundle) as frozen:
        assert all(hashlib.sha256(frozen.extractfile(member).read()).hexdigest()==digest(root/member.name)
            for member in frozen.getmembers() if member.isfile())
    (root/'archive-receipt.json').write_text(json.dumps(dict(
        complete=complete, freshPairs=warm['pairs'] if warm else None,
        allWorkersJoined=complete, guestFixturesRemoved=not owned_ram.exists(),
        quietBeforeAndAfter=complete, archivedAndVerifiedUnderLease=True, archiveSHA256=digest(bundle),
    ),indent=2)+'\n')

with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    check_image()
    owned_ram.mkdir()
    subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad',
        'lython-b1970-cpython-fixtures',owned_ram],check=True)
    complete=False
    result=None
    try:
        assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev
        time.sleep(8)
        subprocess.run([dotnet,worker,'--compare','check-machine','--out',out/'machine-before.json'],env=env,check=True)
        assert json.loads((out/'machine-before.json').read_text())['gate']['quiet']
        (out/'fixture-filesystem.txt').write_text(subprocess.check_output(
            ['findmnt','-T',str(owned_ram),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
        result=fresh()
        check_image()
        assert not list(owned_ram.iterdir()), list(owned_ram.iterdir())
        complete=True
    finally:
        subprocess.run(['sudo','-n','umount',owned_ram],check=True)
        owned_ram.rmdir()
        archive(complete,result)
