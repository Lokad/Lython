# Lokad.Lython 0.11.0

Updated 2026-11-04. Git-ignored; never force-add. Publication/tagging postponed.
Objective: substantial whole-script and compile-to-result improvement through
coherent design simplification. Completing an isolated experiment is not completion.
Main97bc43b2. Runtime123f9ff1 is fully qualified; module-fact97bc43b2 is committed,
focused/measurement-qualified, with full41863346055 still running. No active prototype.

## Delivery status and remaining uncertainty

| Deliverable | Actual status / evidence |
| --- | --- |
| Shared compiler facts/class-method correction | Committed/qualified61237f58/ca4822f4; retain cells and global/nonlocal invalidation. |
| Native helper returns | Fully qualified; original allocation−19.92%/−19.31%, original elapsed diagnostic. Later source pairs remain separate. |
| Direct UTF8 formatting/storage | Qualified6e1ca104/df548ddf; allocation−8.67%, controlledB102 elapsed/CPU−5..8%. Original adverse15.125ms remains unexplained and preserved. |
| Bulk CSV/native construction | Qualified; B150 variable-width CSV about10% faster, peak+63,648B. Original6–8% results, threshold misses and adverse control preserved. |
| Borrowed native inputs/fixed UTF8/ordered bindings | QualifiedB192/B194/B197; do not repeat unchanged checks. |
| JSON grammar/native formatting | Qualified48d4bf14/ffc01134; cached41788586642 green. Report allocation−26.12%, warm−7..12%/fresh−8..10%; compile+2% accepted. |
| Direct list backing | Qualifiedae9b82b7, cached41793317194 green;366 net runtime lines removed. Allocation lower; sync-text+1.2..2.9% accepted debt. |
| String accounting | Qualifiedbf0d38f3/frozen454cd98c, cached41807227386 green. Allocation−1.5..4.1%; sync-text+3.5..5.8% accepted debt, async−2.9..5.9%. Windows withdrawn. |
| D1 executable storage/copy correctness | Qualifiedc6ac2ae5, corrected41838965356 all eight gates green. Original41831306188 failed, retained with fixes. |
| D2 call construction / D3 storage source gates | Complete7535e07a. No new substantial general-frame/storage redesign selected; evidence below. |
| D4 binding-state cache | Qualified123f9ff1/frozen159744bd, cached41853526333 all eight gates green. Direct older-reference compilation debt decision complete. |
| D5 shared module facts/lexical preparation | Committed97bc43b2/frozen0d452f95;240 internal/1,889 public per actual11/10 pass,27 scripts/71 code objects exactly preserved. Full41863346055 pending Windows Stress; ordinary/package both OS and Ubuntu Stress successful. |
| Regex | Core decoupled; non-packable adapter normal pin0.4.0. Immutabledev.26 independently qualified; only affected final released-adapter capabilities deferred. |

All eight gates: Windows/Ubuntu actual.NET11/10 ordinary, original Stress and
installed Release consumers. Cache terminal receipts, never re-query/replay
unchanged qualification. History/evidence: benchmarks/EXPERIMENTS.md and results/;
private working notes .git/agent-notes/review-20261031/. Do not move history to docs/.

## Current priorities / completion criteria

1. Close D5 delivery by observing exact41863346055 at spaced intervals; investigate
   any real failure without replaying already-green D4 qualification.
2. D6 bounded text-streaming correction below: remove a demonstrated avoidable
   scalar-count traversal, validate whole affected scripts, and decide retention.
3. Continue substantial performance work from demonstrated costs. Do not stack
   arity fast paths, new pools/flags or micro-optimizations to manufacture progress.
   A new coherent redesign needs concrete eliminated work/storage, representative
   scripts, semantic acceptance and a completion decision on regression debt.
4. Regex progresses independently; missing released producer features defer only
   the affected final adapter checks. Publication remains postponed.

## D1 complete: existing engine storage and ownership

Removed dynamic Push/Pop/Peek/shape transport, NativeReturnNode/type/array/list,
separate ordinary local/temporary arrays, global compaction map, intermediate
instruction copy and duplicate branch/region remapping. Existing compiler facts
prepare physical positions; provenance uses existing16B call metadata. Readonly
borrowing avoids40B instruction copies. Actual stride24→40B and conservative
frame capacity are explicit costs. Retain stable cells/snapshots and funding
through callee, borrowed inputs and awaited cleanup. No second engine or policy.

c6 fixes caller copy provenance after awaited hooks, using explicit memo lookups
and short synchronous mutation scopes. Five deterministic regressions reproduce
then pass; shallow constructors preserve hashes/aliases. Independent CPython
goldens cover rehash after real I/O and hash reuse. Custom hash/write-key equality
still requires synchronous completion, including RunAsync; this limitation is documented.

Warm allocation flat. Original async-report+7.84..7.89% retained; confirmation
unchanged prototype+4.07..5.53%. Readonly refinement−5.75% against that prototype,
near baseline−0.54..+1.91% with1.38% control spread. No broad CPU gain claimed.
Original compilation debt retained; D4 direct comparison below closes net decision.
Evidence: benchmarks/results/2026-11-04-executable-storage/.

## D2/D3 complete: call/frame and bulk-storage assessment

Source already has inline argument-presence word, shared bound-local/frame array,
one inherited ExecutionContext/ExecutionFrame object, lazy slot namespaces and
shared empty nonlocal tables. Native~96B/call vs conditional ordinary~640B includes
branch work. Complete text profile1,231/1,456 samples: ordinary construction/binding
inclusive4.5%/3.5%, prefix leaf19.9%, monitor leaves9.1%; overlap limits attribution.
No demonstrated dominant removable general-frame mechanism. Evidence:
benchmarks/results/2026-11-04-call-construction-gate/.

Reopen with concrete whole-storage/transport deletion and lifetime proof. Preserve
slower arena/control/reusable-dispatcher lessons; no permanent architectural ban.
Preserve binding/defaults/evaluation order, protocols/reentry, closures/global/
nonlocal, traceback, real suspension, generators, token/stack checks and retained
aliases. Allocation reduction alone does not justify another general rewrite.

Bulk source pass confirms existing split ranges/batch admission, native casing,
direct list backing, CSV bulk fields, JSON plain-tokenUTF8/name reuse, native
small-number parsing/int64 rendering and destination writes. Remaining Python
float/large-integer behavior is real work. Lower/split inclusive18–23% is not all
waste. No new window/compact-payload redesign selected. B196 integer prototypes
withdrawn; B198 owner-capacity needs changed lifetime design addressing229/71
failures, not another broad audit. Native scopes already share one root gate.

## D4 complete: binding-state identity cache and debt decision

123f9ff1 removes recursive structural node hashing/equality, _version,
CachedAbstractValue and version checks: one exact-node-identity cache per mutable
AbstractState, storing existing resolution; mutations already clear it.14 net
frontend lines removed. No pass skip, new cache layer or eligibility flag.
Focused109 internal/807 public per actual11/10 pass, full41853526333 green/cached.

Six-case163s controlled run: compileCSV−3.9..6.5%, text−8.4%, report−3.1%; fresh
config−1.1..1.8%, fresh text within dispersion, warm text straddles controls.
Compilation allocation−0.25..0.46%; no broad CPU claim. Direct81s comparison
against qualified454: CSV+0.07..−1.45% within2.5–2.7%IQR, text−5.5..5.8%,
report−1.2..1.8%. D1 elapsed compile debt not reproduced net; CSV near unchanged.
Compilation allocation remains+3.3..5.0% versus454, explicitly accepted for D1.
Never add independent source-pair percentages. Preserve B87 original3.84..7.35%
and15.23% control drift. Evidence: benchmarks/results/2026-11-04-resolution-cache/.

## D5 committed: shared module facts and one lexical preparation walk

97bc43b2 caches module facts on existing ScriptSyntax and reuses them through
lowering/executable construction. Require actual facts at every builder entry;
remove ForLoweredStatements/GetSyntax switch, optional constructors, duplicate
nullable declared-facts field. Fold ModuleUsesSuper into existing renamed
LexicalScopePreparation; defer eligible tags until later/global declarations
known. Module class-read facts finish after child preparation, reusing bindings.
57 net production lines deleted; no new pass/framework/backend/option/public API.

Preserve module __class__ exclusion from closure cells using actual function
scope, module/delayed-global super shadowing, class/header/type-parameter
boundaries, lambdas/comprehensions/generators and postponed reads. Both targets'
27 scripts/71 code objects preserve all active facts/instructions/spans/regions/
closures/native provenance.240 internal/1,889 public per actual11/10 pass unchanged.
Frozen0d452f95 matches isolated source; cherry-picked main differs only CRLF text,
verified by canonical-LF comparison, not a false raw-byte identity claim.

163s controlled six-case collection: compiletext−6.58..7.42%, report−4.19..5.32%,
CSV−3.22..7.28% with4.39% shifted identical controls (magnitude control-limited).
Compilation allocation−4.25..4.83%. Fresh config/text near unchanged; modest warm
observations do not establish frontend-caused CPU gain. All identities/goldens/
ownership/cleanup/quiet gates pass. Retain deletion and compile benefits; no CSV
retiming needed. Initial valid early-finalization variant preserved, never timed.
Evidence: benchmarks/results/2026-11-04-module-lexical-facts/.

## D6 source gate: constant-time native string truth

Confirmed: PyString.IsTruthy currently calls scalar Length, lazily traversing
all UTF8 on a fresh string. Native synchronous/asynchronous truth dispatch both
reach this method. Strict valid UTF8 makes emptiness exactly byteLength==0.
Proposal: use existing logical byte extent for truth; retain scalar Length for
len/index/offset semantics. Delete the unnecessary full scalar traversal from
existence checks; no cached flag, special opcode or new execution route.

Affected scripts: complete chunked file/text scans with fresh strings and EOF
checks, and line-filter helpers that test a string before other character work.
First inspect existing workload/tool support. Focused existing empty/nonempty,
Unicode/NUL, bool/not/and/or, sync/async, text-I/O/cancellation/refusal/ownership
coverage; add only an independently missing semantic regression. One short
controlled complete-workload source pair plus unchanged control with CPython
goldens and exact images. Include I/O/result cleanup; compilation separate.
No predicted broad speedup, no repeated cached-string microbenchmark. Decide
retention and any adverse control uncertainty at the bounded completion point.
This correction does not close the broader performance objective.

## Independent regex track

Core owns Python-specific UTF8 contract: byte ranges/scalar positions, original
subject windows, effective flags, names/captures/errors, explicit ownership and
current tokens across frontend/runtime/imports. No core backend edge, universal
framework, silent dialect fallback, cached prior token or abandoned matching.

Immutabledev.26/producer e731a452 independently qualified on123f9ff1:84 internal/
421 public per actual11/10 pass, including6 lifetime and3 actual compile/match/
cursor cancellation subprocesses per target. Exact package/DLL/core identities
verified. Main-class143 reflected public members unchanged vsdev20, not complete
API/safety/performance certification. Normal0.4.0 pin unchanged. Evidence:
benchmarks/results/2026-11-04-adapter-dev26/. Do not repeat unchangeddev20/26.
NativeUTF8 names, one-shot byte ranges with working-funding receipts and reversed
match windows remain precisely tracked affected capabilities. Development
producers/adapter-local bridges support progress; missing released features defer
only their final adapter qualification, never independent Lython development.

## Measurement policy and lasting constraints

Primary external table docs/BENCHMARKS.md measures0ffc9ac6/frozen0ee77cd0,
CPython3.13.16/.NET11RC3, quiet AzureF4as_v7/Ubuntu24.04.4,2026-11-04.
FreshCSV/JSON/text/report/config ratios1.49/1.30/2.46/1.85/1.13; warm1.51/1.27/
2.53/1.92/1.05. CSVfresh control-limited; text/report variable. SeparateCSV/report
compile1.65/1.63. Later copy/cache/D5 changes excluded. No additive source pairs.
Includes invocation, mediated RAM I/O, checks and prior-result cleanup; fresh
adds compilation/disposal. Excludes startup/staging/reset/hash/final cache teardown;
all users joined. No CPU/RSS/embedding-latency guarantee. Refresh external comparison
at a coherent runtime checkpoint, not after every frontend deletion.

Timeouts, unstable unchanged controls and inconclusive results establish
uncertainty, not failed designs. Bounded confirmation/refinement/correction is
allowed when evidence justifies it; preserve original adverse/failed conditions.
No permanent one-attempt closure or fixed-percentage veto. Distinguish coherent
simplification, allocation reduction, elapsed observations and proven CPU gains.

Use existing tools/quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem.
Persistent evidence separate from RAM fixtures; check disk first. Focused Release
in iteration; actual11/10 affected checks, full platform/Stress/installed consumers
batched at delivery. Nonincremental rebuild after timestamp-preserved restoration;
verify source/binary identities. Cache terminal CI, poll live runs minutes apart.
No new benchmark framework. All text/JSON reads and writes explicitly UTF8.

Fully managed/memory-safe/host-mediated; no unsafe compilation/C#/Unsafe APIs,
pointers/PInvoke/native probing. Retain managed stack admission/cycle checks.
CancellationToken sole time authority; no fuel/quotas/watchdogs. Shared allowance
funds coarse capacity, replacement overlap, retained aliases/results/caches and
pending users through awaited cleanup. No independent caps/hidden allowances,
tracing/weak reclamation/forcedGC. First admission refusal ends guest work even
through suppression/finally; native cleanup/refunds remain available and awaited.
