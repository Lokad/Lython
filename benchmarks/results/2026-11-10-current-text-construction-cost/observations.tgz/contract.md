# R211 — current complete-text cost gate

One existing complete script, qualified e543/0e source, unchanged workers/fixtures/
goldens/CPU collector. Six-second warmed capture; ordinary GC/tiering plus perf-map
logging. No elapsed comparison, CPython, compilation or backend qualification.
R199 predates material split/loop/tuple work, so current attribution is justified.
Retain unknowns, all thread CPU/raw maps/stacks and full wider reset/protocol/check
boundary; actual CPU-active execution thread is selected. Useful/inlined work is
not a removable tax. One capture plus source gate selects a coherent phase removal
or explicit uncertainty; no automatic local optimization. 90s owner/30stop/30margin.
All verification, join/Closed, map-copy/SHA, archive-under-lease/cleanup gates remain.
