from pathlib import Path
import bisect,collections,datetime,hashlib,json,re,shutil,tarfile
root=Path(__file__).parent; p=root/'b562'; repo=Path('D:/code/Lython')
r=p/'retrieved/profiles/text-warm'
receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
record=json.loads((r/'record.json').read_text(encoding='utf-8'));original=json.loads((r/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
ranges=[]
for line in(r/'perf.map').read_text(encoding='utf-8').splitlines():
    start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))
ranges.sort();starts=[a for a,n,name in ranges];counts=collections.Counter();tids=set(record['guestTids'])
for line in(r/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
    m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
    if not m or m[2]not in tids:continue
    address=int(m[3],16);i=bisect.bisect_right(starts,address)-1;symbol=m[4]
    if i>=0 and address<ranges[i][0]+ranges[i][1]:symbol=ranges[i][2]
    counts[symbol]+=1
assert counts.total()==original['samples']==1151 and counts['[unknown]']==68
rules=[('VM instruction prefix',['::ExecuteInstructionPrefix']),('Operand/result transport',['::CompleteLocalResult','::ExecuteStackTransfer','ExecutableValueStorage']),('Native dictionary/hash',['::TryExecuteDictionaryAccumulation','::TryAccumulateWithoutAdmission','::ComputeStructuralHashCode','::FindNativeIndex']),('Whitespace/casing',['PyStringOps::']),('Native call selection',['::TryExecuteNativeCall','::TryLoadDirectCallReceiver','::EvaluateNativeReturn']),('Scalar arithmetic',['::AddExactIntegers','PyNumberOps::']),('Monitor locking; caller not attributed',['System.Threading.Monitor::']),('Unmapped',['[unknown]'])]
groups=collections.Counter()
for name,count in counts.items():groups[next((label for label,needles in rules if any(n in name for n in needles)),'Other mapped leaves')]+=count
wall=(datetime.datetime.fromisoformat(record['stoppedUtc'])-datetime.datetime.fromisoformat(record['startedUtc'])).total_seconds()
result=dict(sourceRevision='Fully qualified committed e543bf15, fresh postcommit0e2bc55b; evidence HEAD6ca794be.',samples=counts.total(),unknown=68,
    wallCaptureSeconds=wall,workerExecutionSeconds=receipt['capturedSeconds'],selectedThreadCPUSeconds=original['cpuSeconds'],allThreadCPU=record['threadCpuSeconds'],
    classification='Same disjoint innermost rules as R199; groups include useful/inlined work and wider reset/protocol/output checks. Not removable-tax percentages or a performance comparison.',
    groups=[dict(name=k,samples=v,percent=100*v/counts.total())for k,v in groups.most_common()],allLeaves=counts.most_common())
dest=repo/'benchmarks/results/2026-11-10-current-text-construction-cost';dest.mkdir(exist_ok=False)
def write(path,text):path.write_text(text,encoding='utf-8',newline='\n')
write(dest/'attribution.json',json.dumps(result,indent=2)+'\n')
write(root/'early-retrieval-condition.json',json.dumps(dict(localAttemptUTC='2026-11-10T21:27:54.7921767Z',notBeforeUTC='2026-11-10T21:27:57.643413+00:00',result='Local deadline assertion refused before any SSH/status request; waited five seconds and resumed the same acknowledged owner. No restart or repeated capture.'),indent=2)+'\n')
gate=dict(decision='No complete runtime redesign selected from this capture; advance the bounded frontend source gate rather than promoting a narrow guess.',
    established=['Calls use existing native helper entry for this script, not a complete per-word frame.',
        'Cased split admits every eventual fragment before the first loop effect; the sizing scan is semantically required by current ownership/admission ordering.',
        'The consumption scan avoids eager PyList/object-array/range-array storage. Restoring it would reverse measured R203 and must not be treated as an unimplemented improvement.',
        'String payloads up to eight bytes already live inline; a shared backing per line would add slice ownership/representation changes with little evidence of benefit here.',
        'Instructions already overlay operand fields and forward pure local inputs; a new map/packet/sidecar is not demonstrated duplicate removal.',
        'Native dictionary accumulation already shares one probe, and PyString hashes are cached. Useful hashing/casing are not redundant conversion overhead.'],
    uncertainties=['Instruction-prefix samples include inlined useful work; no specific removable dispatch phase has been attributed.',
        'Monitor caller attribution and unmapped frames remain unresolved; do not assign all locking to memory admission.',
        'This script does not establish call/frame costs for all helper shapes or compilation bottlenecks.'],
    next='P2: inspect actual remaining repeated analysis/representations and their consumers; reuse existing frontend attribution. Preserve independent regex development. No new timed source pair without a selected coherent migration.')
write(dest/'source-gate.json',json.dumps(gate,indent=2)+'\n')
for name in ['observations.tgz','archive-receipt.json','identity.json','source-proof.json','terminal-status.json','extraction.json']:
    shutil.copyfile(p/name,dest/name)
with tarfile.open(dest/'preparation.tar.xz','w:xz')as output:
    for f in root.rglob('*'):
        if f.is_file() and 'retrieved'not in f.relative_to(root).parts and f.name not in ['observations.tgz','payload.tgz']:
            output.add(f,arcname=f.relative_to(root).as_posix())
    for name in ['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/Text/PyString.cs',
                 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',
                 'src/Lokad.Lython/Runtime/PyDict.Accumulation.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs']:
        output.add(repo/name,arcname='source-gate/'+name)
rows='\n'.join(f"| {g['name']} | {g['samples']} | {g['percent']:.2f}% |"for g in result['groups'])
write(dest/'README.md','''# R211 — complete-text construction cost gate

2026-11-10, fully qualified e543bf15 production source, exact fresh postcommit core
0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492, all 568 source
hashes unchanged. Existing text-summary/helper script, fixtures, full goldens,
worker and CPU collector. Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary GC/tiering
plus diagnostic perf-map logging. R199 predates material split/loop/tuple changes;
this is one current attribution, not an unchanged elapsed retiming.

One warmed six-second wall capture: **1,151 execution-thread samples**, 68 unmapped
(5.91%), 5.79 execution-thread CPU seconds and 5.888 summed worker execution seconds.
Actual CPU-active thread selected, not assumed to be process main. No malformed
map lines. [All leaves/threads](attribution.json), [raw core/maps/stacks/records](observations.tgz),
[identity](identity.json), [source proof](source-proof.json), [receipt](archive-receipt.json),
[preparation/original conditions/source](preparation.tar.xz).

| Innermost observed group | Samples | Share |
| --- | ---: | ---: |
'''+rows+'''

Groups use the same disjoint rules as R199. They contain useful/inlined work and
the wider reset/protocol/full-output-check boundary. Unknowns are retained. These
are neither removable taxes nor speedup forecasts. Monitor callers are unproved;
do not assign every lock sample to memory admission. This does not compare normal
elapsed performance, CPython, compilation, startup or embedding latency.

Split preparation has 105 leaf samples (9.12%). Source confirms its first scan
computes exact conservative aggregate admission for every eventual word before
any guest loop effect. Consumption then avoids the eager list/value/range arrays.
Replacing the first scan with worst-case per-byte word overhead would greatly
overcharge long tokens; restoring eager storage would reverse delivered R203.
Neither is promoted as a simplification. Short string bytes are already inline.
Calls use the existing native helper entry; complete frame construction is not a
demonstrated dominant cost here. Instructions already overlay operands and forward
locals; dictionary accumulation already shares one probe and string hashes cache.

The [source gate](source-gate.json) finds no justified complete migration from
these shares. Continue the frontend source gate using existing evidence, and the
independent regex track. Do not manufacture a local optimization or expand this
into a profile campaign. A genuinely different design can receive a bounded
confirmation when its eliminated work and semantic acceptance are concrete.

All source/fixture/output identities, verification before/after, quiet gates,
Closed/zero-exit/join, map copy/SHA, RAM removal, archive-under-lease and local SHA
pass. Terminal status is cached; no remaining workers or RAM traces. Staging retired
only two exact committed compressed duplicates (B558/B561), with fresh idle lease,
path/UID/single-link/hash proof and fixed 240 MiB floor / 12 MiB headroom intact.
An attempted retrieval 2.85 seconds early failed locally before SSH; after five
seconds the same owner was retrieved, with no restart or repeated capture.
No production change, redundant platform qualification, adapter promotion or publication.
''')
print(json.dumps({'samples':result['samples'],'groups':result['groups'],'decision':gate['decision']},indent=2))
