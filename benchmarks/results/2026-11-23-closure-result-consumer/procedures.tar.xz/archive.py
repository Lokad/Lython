from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
checks=lab.parent.parent/'closure-result-b1497'
quiet=lab/'comparison/quiet'
output=repo/'benchmarks/results/2026-11-23-closure-result-consumer'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=read(lab/'comparison/identity.json')
terminal=read(quiet/'terminal-status.json')
assert not terminal['live'] and terminal['exitCode']=='0' and not terminal['fixtures']
assert all(terminal['receipt'][k] for k in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((quiet/'observations.tar.xz').read_bytes())==terminal['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==168
assert all(row['peakAdmission'][0]==row['peakAdmission'][1] for row in read(lab/'allocation-summary-six.json'))
assert sum(len(row['consumers']) for row in read(lab/'tape-summary.json'))==2
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf-8').strip()
identity['retainedRevision']=head if not subprocess.check_output(['git','diff','--name-only',head,identity['candidate'],'--','src'],cwd=repo) else None
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src'],cwd=repo)
(lab/'production.patch').write_bytes(patch)
identity['productionPatchSHA256']=sha(patch)
output.mkdir(exist_ok=True)
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
    core=(lab/role/'Lokad.Lython.dll').read_bytes()
    if role=='reference':
        artifact=output.parent/'2026-11-23-imported-regex-programs/candidate-core.dll.gz'
    else:
        artifact=output/'candidate-core.dll.gz'
        artifact.write_bytes(gzip.compress(core,mtime=0))
    assert sha(gzip.decompress(artifact.read_bytes()))==files['Lokad.Lython.dll']
(output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ('observations.tar.xz','terminal-status.json','summary.json'):
    shutil.copyfile(quiet/name,output/name)
for name in ('allocation-summary-six.json','tape-summary.json'):
    shutil.copyfile(lab/name,output/name)
with tarfile.open(output/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','freeze.py','stage.py','quiet.py','summarize.py','allocations.py','compare-tapes.py',
                 'reference-tape.json','candidate-tape.json','reference-allocation-six.json','candidate-allocation-six.json',
                 'verify.log','launch.log','retrieval.log','production.patch','comparison/reference-verify.json',
                 'comparison/candidate-verify.json','comparison/quiet/observe-not-before'):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ('prepare-campaign.py','windows-frozen.log','windows-Lokad.Lython.Tests.log',
                 'ubuntu-Lokad.Lython.Tests.log','windows-Lokad.Lython.PublicApi.Tests.log',
                 'ubuntu-Lokad.Lython.PublicApi.Tests.log','win-suspending-operator.log','ubuntu-suspending-operator.log',
                 'suspending-operator.patch','windows-retained-suspending.log','ubuntu-retained-suspending.log'):
        archive.add(checks/name,arcname=name,recursive=False)
    archive.add(lab/'prepare-confirmation.py',arcname='prepare-confirmation.py',recursive=False)
confirm=lab.parent/'closure-result-confirmation-20261123'
repeat=confirm/'comparison/quiet'
repeat_result=read(repeat/'terminal-status.json')
assert not repeat_result['live'] and repeat_result['exitCode']=='0' and not repeat_result['fixtures']
assert all(repeat_result['receipt'][k] for k in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((repeat/'observations.tar.xz').read_bytes())==repeat_result['receipt']['archiveSHA256']
assert read(repeat/'summary.json')['timedBatches']==84
assert read(confirm/'comparison/identity.json')['imageFiles']==identity['imageFiles']
confirmed=output/'confirmation'
confirmed.mkdir(exist_ok=True)
for name in ('observations.tar.xz','terminal-status.json','summary.json'):
    shutil.copyfile(repeat/name,confirmed/name)
with tarfile.open(confirmed/'procedures.tar.xz','w:xz') as archive:
    for name in ('quiet.py','summarize.py','launch.log','retrieval.log','comparison/quiet/observe-not-before'):
        archive.add(confirm/name,arcname=name,recursive=False)
print(output,identity['retainedRevision'] or 'private')
