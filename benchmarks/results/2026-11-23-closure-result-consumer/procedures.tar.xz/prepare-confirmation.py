from pathlib import Path
import hashlib
import json
import tarfile

source=Path(__file__).resolve().parent
lab=source.parent/'closure-result-confirmation-20261123'
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(parents=True,exist_ok=True)
previous=source/'comparison'
write=lambda path,text:path.write_text(text,encoding='utf-8',newline='\n')
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=json.loads((previous/'identity.json').read_text(encoding='utf-8'))
catalog=(previous/'representative.json').read_bytes()
jobs=dict(warm=[['scripts.ordinary-fully-supplied-helper','warm'],
    ['diagnostic.text-summary.nonlocal-computed-width.large','compile-run'],
    ['diagnostic.text-summary.nonlocal-computed-width.large','warm']])
(comparison/'representative.json').write_bytes(catalog)
write(comparison/'jobs.json',json.dumps(jobs,indent=2)+'\n')
assert digest(comparison/'representative.json')==identity['catalogs']['representative.json']['sha256']
identity['catalogs']['jobs.json']['sha256']=digest(comparison/'jobs.json')
identity['purpose']='B1498 reverse worker order for the unchanged B1497 pair'
write(comparison/'identity.json',json.dumps(identity,indent=2)+'\n')

def change(value,old,new):
    assert old in value, old
    return value.replace(old,new)

collector=(previous/'quiet/collect.py').read_text(encoding='utf-8')
collector=change(collector,'assert len(jobs) == 6','assert len(jobs) == 3')
collector=change(collector,"labels=['reference-control','candidate-control','reference','candidate']",
    "labels=['candidate','reference','candidate-control','reference-control']")
collector=change(collector,'< 307,','< 167,').replace('b1497','b1498')
write(quiet/'collect.py',collector)
compile(collector,'collect.py','exec')
(quiet/'run.sh').write_bytes((previous/'quiet/run.sh').read_bytes())
assert b'\r' not in (quiet/'run.sh').read_bytes()
launcher=(source/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('b1497','b1498').replace('closure-result-consumer-20261123','closure-result-confirmation-20261123')
launcher=change(launcher,"'candidate-core.dll','reference-core.dll'", "")
launcher=change(launcher, '''   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(target)
   else:
    src=reference/'candidate'/name
    assert digest(src)==sha, (role,name)
    os.link(src,target)
   assert digest(target)==sha, (role,name)''','''   src=reference/role/name
   assert digest(src)==sha, (role,name)
   os.link(src,target)
   assert digest(target)==sha, (role,name)''')
launcher=change(launcher,"'--property=RuntimeMaxSec=350'","'--property=RuntimeMaxSec=215'")
launcher=change(launcher,'seconds=298','seconds=169')
write(lab/'quiet.py',launcher)
compile(launcher,'quiet.py','exec')
summary=(source/'summarize.py').read_text(encoding='utf-8')
summary=change(summary,'["warmJobs"] == 6','["warmJobs"] == 3')
summary=change(summary,'len(warm["jobs"])==6','len(warm["jobs"])==3')
summary=change(summary,'timedBatches=168','timedBatches=84')
write(lab/'summarize.py',summary)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for dir_,name in ((comparison,'identity.json'),(comparison,'jobs.json'),(comparison,'representative.json'),
                    (quiet,'run.sh'),(quiet,'collect.py')):
        bundle.add(dir_/name,arcname=name)
info=dict(root='closure-result-confirmation-b1498-20261123',reference='closure-result-consumer-b1497-20261123',
          payloadBytes=payload.stat().st_size,payloadSHA256=digest(payload))
write(quiet/'upload.json',json.dumps(info,indent=2)+'\n')
print(info)
