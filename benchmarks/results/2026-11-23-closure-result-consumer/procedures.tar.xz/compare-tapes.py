from pathlib import Path
import json

lab=Path(__file__).resolve().parent
read=lambda name:json.loads((lab/name).read_text(encoding='utf-8'))
identity=read('comparison/identity.json')
before=read('reference-tape.json')
after=read('candidate-tape.json')
assert before['coreSHA256']==identity['coreSHA256']['reference']
assert after['coreSHA256']==identity['coreSHA256']['candidate']
binary=46
store_closure=26
rows=[]
for a,b in zip(before['rows'],after['rows'],strict=True):
    assert a['id']==b['id']
    consumers=[]
    for old,new in zip(a['codes'],b['codes'],strict=True):
        assert {k:v for k,v in old.items() if k!='tape'}=={k:v for k,v in new.items() if k!='tape'}
        for index,(prior,current) in enumerate(zip(old['tape'],new['tape'],strict=True)):
            if prior==current: continue
            assert {k:v for k,v in prior.items() if k!='_liveExtent'}=={k:v for k,v in current.items() if k!='_liveExtent'}
            assert prior['_liveExtent']>=0 and current['_liveExtent']==~prior['_liveExtent']
            assert prior['<OpCode>k__BackingField']==binary
            successor=new['tape'][index+1]
            assert successor['<OpCode>k__BackingField']==store_closure
            assert successor['_inputStart']==current['_resultSlot']
            consumers.append(dict(function=new['name'],instruction=index,store=index+1,workspace=new['capacity']))
    rows.append(dict(case=a['id'],consumers=consumers))
assert [len(row['consumers']) for row in rows]==[1,0,1,0,0],rows
(lab/'tape-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))
