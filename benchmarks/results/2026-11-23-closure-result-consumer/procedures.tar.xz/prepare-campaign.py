from pathlib import Path
import json
import shutil

checks=Path(__file__).resolve().parent
repo=checks.parents[2]
archive=checks.parent/'review-20261031'
template=archive/'csv-deferred-number-20261123'
donor=archive/'forwarded-global-call-20261123'
lab=archive/'closure-result-consumer-20261123'
lab.mkdir(exist_ok=True)

def copy_script(name,replacements):
    source=(template/name).read_text(encoding='utf-8')
    for old,new in replacements:
        assert old in source,(name,old)
        source=source.replace(old,new)
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

for name in ('representative.json','jobs.json'):
    shutil.copyfile(donor/'comparison'/name,lab/name)

copy_script('freeze.py',[
    ('csv-combined-scan-20261123','closure-result-consumer-20261123'),
    ('138e91373','ee42dc80a'),
    ("assert not subprocess.check_output(['git','diff','--name-only',base,identity['candidate'],'--','src','tests'],cwd=repo)",
     '''artifact = lab.parent.parent / 'regex-import-b1496'
proof = json.loads((artifact/'identity.json').read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','--name-only',base,proof['candidateSource'],'--','src'],cwd=repo)
assert all(checksum==proof['images']['candidate'][name] for name,checksum in identity['imageFiles']['candidate'].items() if name != 'Lokad.Lython.dll')'''),
    ('''        if name==core and role=='candidate':
            original=lab/'windows/bin/Lokad.Lython/release_net11.0'/core''',
     '''        if name==core:
            original=artifact/'candidate'/core if role=='reference' else lab.parent.parent/'closure-result-b1497/windows/bin/Lokad.Lython/release_net11.0'/core
            if role=='reference': assert sha(original)==proof['images']['candidate'][core]'''),
    ('sourceImageRevision=identity["candidate"]','sourceImageRevision=proof["candidateSource"]'),
    ('B1495 defer non-short numbers through the buffered CSV line commit','B1497 consume binary results in the existing closure cell'),
    ('five CPython goldens on both CSV images','five CPython goldens on both closure-store images'),
])
copy_script('stage.py',[
    ('csv-deferred-number-b1495-20261123','closure-result-consumer-b1497-20261123'),
    ('b1495','b1497'),
    ("'reference':root.parent/'{reference}'/'candidate'","'reference':root/'reference'"),
    ('    bundle.add(lab/"candidate/Lokad.Lython.dll",arcname="candidate-core.dll")',
     '''    for role in ('reference','candidate'):
        bundle.add(lab/role/'Lokad.Lython.dll',arcname=role+'-core.dll')'''),
])
copy_script('quiet.py',[
    ('csv-deferred-number-20261123','closure-result-consumer-20261123'),('b1495','b1497'),
    ("'candidate-core.dll'}", "'candidate-core.dll','reference-core.dll'}"),
    (''' image=root/'candidate';image.mkdir()
 for name,sha in identity['imageFiles']['reference'].items():
  src=reference/'candidate'/name
  assert digest(src)==sha, name
  if name!='Lokad.Lython.dll':
   assert sha==identity['imageFiles']['candidate'][name]
   os.link(src,image/name)
 core=image/'Lokad.Lython.dll'
 (root/'candidate-core.dll').rename(core)
 assert identity['imageFiles']['candidate'][core.name]==digest(core)''',
     ''' for role,files in identity['imageFiles'].items():
  image=root/role;image.mkdir()
  for name,sha in files.items():
   target=image/name
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(target)
   else:
    src=reference/'candidate'/name
    assert digest(src)==sha, (role,name)
    os.link(src,target)
   assert digest(target)==sha, (role,name)'''),
])
shutil.copyfile(template/'summarize.py',lab/'summarize.py')
print(lab)
