# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent design simplification and substantial whole-script performance.
An isolated experiment does not complete the objective. Current contracts live in
docs; original failed conditions, prototypes and qualification remain in
[experimental history](benchmarks/EXPERIMENTS.md) and linked immutable results.

## Actual delivery status

| Deliverable | Status and qualification |
| --- | --- |
| Shared compiler facts; direct UTF-8 formatting/storage; native helper returns | Committed, qualified. Native-return allocation −19.92/19.31%, distinct from diagnostic elapsed. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention; original adverse15.125ms remains unexplained and preserved. No unchanged replay. |
| R119–R139 record/storage/declaration/literal/static-call/lexical facts | Committed and qualified; class/global proof corrections preserved. Source-pair CPU claims and uncertain controls stay distinct. |
| R141 hash stress canceller; R142 generator state; R145 common executable callable engine | Committed and fully qualified through CI42588611410. R142 compile allocation +1.3–1.6% and uncertain report controls; R145 compile allocation +3.2–5.2% accepted debt. Original failures and correction retained. |
| R148 suspended filename filtering; R149 callback arguments; R151 borrowed callable entry | Committed, fully qualified through CI42605184549. Removed packet pools/duplicate call entry; pending users and constructors remain funded. Constructor allocation debt explicit in history. |
| R154 workspace capacity `200d195b`; R155 valid DEFLATE `78fd7bb4` | Fully qualified CI42615908221, Windows/Ubuntu actual11/10, original Stress both and installed consumers. Original prefix-clearing failure/fix retained; no CPU gain established for capacity reuse. |
| R157 managed ASCII split search `7c10322c` | Fully qualified CI42627090614/source038f7fb4: both OS actual11/10, original Stress both, installed consumers. Focused178internal/219public per framework and6Python boundary scripts pass. Allocation flat; elapsed overlaps controls, CPU mixed. Retain simplification without a CPU-gain claim. |
| R140/R143/R150/R156 runtime attribution; R144/R147/R158 source gates | Completed and committed, sources explicit. No presumed operand round trip, duplicate plain-JSON parse or justified name/abstract visitor merger remains. Inclusive prefix samples include useful work, not savings. |
| R146 representative CPython refresh `115dda5f` | Measured65ed6cf7, not later HEAD. Twelve jobs250.847s; all gates pass. No unchanged qualification replay. |
| R159 current config comparison `ddfa849e` | Complete and committed. Current7c-equivalent/corecfeb reused freeze, not a fresh postcommit binary. Three jobs88.416s, two independent processes per engine, all identity/quiet/output/ownership/join/archive gates pass. |
| R161 default argparse inputs `b59c2be3` | Committed/pushed;201focused per actual11/10, independent Python, ordinary CI42634762709 green. Fully qualified by cached CI42640859228/sourcef6861aa5. |
| R162 CSV attribution `7a5048c9` | Committed; one usable1210sample capture with original failure/owned cleanup/sizing correction retained. No speed claim. |
| R163 scalar comparison `f6861aa5` | Committed/pushed; fully qualified42640859228/sourcef6861aa5, cached success. Final65internal/306public per actual11/10 pass; quiet4jobs115.042s supports asyncCSV improvement, syncCPU/report uncertain. |
| R160 config CPU attribution `d37336a5` | Complete. Same R159 source,545guest samples/2.90CPU seconds, host51.74%/JSON9.91%/builtin initialization2.20%. No justified singleton/frame redesign; original pre-work metadata failure/correction preserved. |
| Call-arena/control, prepared maps, shared string windows | Held/restored prototypes. Slower measurements and semantic lessons retained; no automatic promotion or permanent veto. |

## Evidence and decision policy

[BENCHMARKS](docs/BENCHMARKS.md) separates compilation, warm execution and complete
compile-to-result. Current config: compile36.5–36.7µs/CPython34.4 (1.06–1.07×);
warm78.7–79.0/61.6–62.1 (1.27–1.28×); complete138.7–139.6/124.9–125.1
(1.11–1.12×). Stock CPython3.13.16, quiet F4as_v7 Ubuntu24.04.4/.NET11RC3.
Earlier measured65ed complete CSV/text/report/search ratios1.13–1.17/1.49–1.51/
1.35/1.34–1.35×; warm1.15–1.17/1.56–1.60/1.37–1.38/1.61–1.63×.
These include mediated RAM-file guest I/O, full output validation and prior-result
cleanup; exclude startup/reset/protocol/final cache teardown. Compilation separate;
independent medians need not add. External process CPU includes reset/protocol.
Pending I/O, embedding tails and large-tree throughput remain unqualified.

Timeouts, unstable unchanged controls and inconclusive results establish uncertainty,
not design failure. Permit bounded confirmation/refinement/correction when justified;
retain every adverse result and original failed condition. Size quiet-VM runs for
usable observations. Percentages inform decisions, not automatic vetoes. Distinguish
code removed, allocation reduced and demonstrated CPU improvement. Do not relabel
historical sources or infer an individual gain from unrelated checkpoints.

## Prioritized execution

1. **R164 — committed260b2acf; delivery/debt pending.** Source
   assessment complete; implementation selected below. R163's exact operators now use
   bounded checks, but PyString.Equals/CompareOrdinal retain whole-span primitives
   for structural/direct-method/sorting paths. Consolidate in the existing PyString
   methods, preserving context-free internal interfaces; accept explicit current
   context where available, using existing structural context only where already
   established. No token captured in cached strings/methods or new ambient policy.
   Delete R163's private byte loop and displaced whole-span guest routes. Direct
   StringMembers eq/ne/lt/le/gt/ge receive current invocation context. Structural
   PyEquality/PyComparison and JSON/difflib/rendering sort callers need current
   context carried through actual recursion. The rendering-only static
   PyStringOrdinalComparer has one caller and can disappear with that migration.
   Preserve null/reference/length shortcuts, UTF-8 scalar ordering, raw protocols,
   cycle handling, first refusal and aliases. Do not expand into generic comparison
   infrastructure or alter custom dispatch merely to supply cancellation.
   Bounded source decision: native JSON key sorting currently has no ambient
   context. Reuse existing PushAmbient plus SuppressGuestDispatch together only
   around its synchronous sort; native recursion then checks the current token
   without enabling guest callbacks where the old native path had none. Normal structural
   operators already establish context. No new ambient storage/policy or await
   across that scope. Other sort callers pass their actual context directly.
   This avoids adding a second cancellation context through every equality helper.

   Finish one coherent migration with focused direct/structural/Unicode/protocol,
   current-token/refusal/ownership checks; reuse the long Stress observation with
   joined users, no checkpoint counters or broad new stress campaign. State remaining
   context-free/byte/backend limitations precisely. No CPU claim from source or
   unchanged VM campaign. Significant new performance claims need a bounded source
   pair, not relabeling R163. Full delivery qualifies its recorded source only.

2. **R165 — JSON sorted item-pair semantics.** Independent Python probe exposes
   an existing difference: sorted nested tuple keys call guest __eq__ twice under
   CPython item-pair ordering but once under Lython's key-only comparator. Preserve
   event availability in R164 without asserting the incorrect count. Then replace
   key-only ordering with Python-shaped item-pair equality/order, using existing
   comparison/sort machinery; preserve raw hooks, first failure, genuine async
   protocols, funding and cleanup. Start with the exact small reproducer in
   string-comparison-r164/json-item-comparison-gap.json; no broad campaign. If
   current synchronous CLR comparator cannot support required suspension, state
   the contract tradeoff and use an existing supported sort path, not a new framework.

3. **Continue the whole-script redesign roadmap.** Current config initialization
   is not dominant (builtin12/545samples); no blanket singleton/type cache. R162
   finds parser16.03%, scalar7.11%, binding4.21%, setup3.97%; prefix44.55% includes
   useful work and is not a savings estimate. Binding already targets final local
   slots, presence is inline, workspace reused and contexts deferred. Record arrays
   already transfer into dictionaries; the header proof around admission protects
   reentrancy. Native integer parsing already consumes UTF-8. Do not recreate or
   delete these invariants based on presumed duplication.

   Assess complete call/frame/operand transport, actual remaining text conversion,
   per-record construction and frontend work from current evidence. Name the work/
   storage eliminated, affected CSV/text/JSON/config/report/file scripts, semantic
   criteria and displaced code before prototyping. Bound each source hypothesis
   to20min; if no coherent deletion is justified, record uncertainty and move family.
   A material attribution gap can justify a short usable capture/correction; no
   broad campaign or new framework. Larger value/frame representations remain
   possible only with demonstrated costs, completion scope and regression-debt
   decision. Prefer coherent simplification over accumulating narrow special cases.

   Previous bulk-CSV6–8% results remain selectively promising, but current adoption
   displaces the old copying premise. No automatic promotion/percentage veto.
   Preserve slower call-arena/control lessons. Frontend name/abstract passes compute
   distinct facts; small name-pass share does not justify merger. Shared compiler
   facts and final UTF-8 formatting/storage stay intact. Compare compile, allocation,
   warm execution, included I/O and cleanup separately with independent controls.
   Temporary regressions require an explicit completion milestone and final debt
   decision. Refresh representative CPython at a substantial coherent checkpoint,
   keeping every historical source/adverse/uncertain case visible.

4. **Independent regex development.** Core owns Python semantics, native UTF-8
   names, byte ranges/scalar positions, original windows, effective flags, errors/
   replacements, current cancellation and explicit ownership; one provider across
   frontend/runtime/imports. Contract/semantic development continues independently.
   Optional nonpackable adapter0.4.0; dev55/d606 already86internal/514public per11/10
   pass. Missing released APIs: DetailedData with separate preparation/working
   owners, native-name enumeration and cursor creation without an earlier token.
   Adapter-local bridges/test providers/pinned development producers may support
   work; only affected final released-adapter qualification waits. Distinguish
   contract tests, Python semantics and backend performance. No sibling edits,
   repeated unchanged qualification, new memory subsystem or publication.

## Delivery and lasting constraints

R163 committed/pushed f6861aa5; original and refined images/evidence kept distinct.
Final65internal/306public per actual11/10 pass, including new active-comparisonStress.
Quiet4jobs115.042s supports asyncCSV−4.53to6.08%elapsed/coarseCPU−6.90%; syncCPU
mixed, report controls inconclusive. No universal gain/final allocation claim.
Full delivery42640859228/sourcef6861aa5 covers Windows/Ubuntu actual11/10, original
Stress both and installed consumers. Cached terminal success; never requery. R164
is independent source, not covered by this receipt.
All earlier terminal runs, including ordinary42634762709, cached; never requery.
Focused Release during iteration; no overlapping local build/test/timing. Force
nonincremental after restored timestamps; batch full qualification at milestones.

AGENTS.md governs: fully managed safety/stack admission; host mediation/current
CancellationToken only, no fuel/quotas/caps/hidden allowance. Coarse borrowed shared
budget preflights/capacity/replacement overlap; results/caches/aliases/pending users
funded through awaited cleanup. First refusal terminal. No tracing/weak reclamation/
forced GC/retries/abandoned work. Preserve supported Python behavior and diagnostics.
Only core packs via tools/pack.ps1 into artifacts/nuget; adapter nonpackable.
Publication and tagging postponed. Completing R163 does not complete performance.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. ThroughB513 terminal/cached/
archive+localSHA verified, no users/fixtures; no local job. Finite services/leases,
persistent raw apart from RAM, join/unmount/archive under lease. Floors unchanged.
B509/B510 redundant remote compressed copies removed with tracked exact proofs;
raw/receipts/images/canonical Git bytes survive. Future space recovery requires a
fresh deficit and exact aliases/SHA/owner/group/mode/parents/pre-mutation plan;
fresh sufficient space skips mutation. Original failures/restoration stay in history.

CI42640859228 terminal success cached2026-11-09T15:30UTC; both OS actual11/10,
originalStress and installed consumers verified. No active CI/VM/local timing.
R164 implemented;108internal/150public per actual11/10 pass; never requery earlier terminal runs.

R164 final diagnostic preserves original prototype/controls: text−0.75to+1.08%,
CSV+2.41to5.45%elapsed with2.97%baseline spread; report/search/config controls mixed.
No CPU gain claim. Accept possible localCSV regression debt provisionally for
cooperative kernel consolidation; resolve/decide it at the coherent R165 delivery
checkpoint before another performance redesign. Original text+4.21to6.25% and
configcontrol10.38%spread retained; no demonstrated causal inlining explanation.
Context-free native interfaces deliberately retain short whole-span primitives;
only callers with an active context receive bounded checks. JSON bridge preserves
previous guest-hook availability. Frozen mutation validates this invariant.

R164 evidence: benchmarks/results/2026-11-09-shared-string-comparisons/README.md.
Next: R165 semantic correction and coherent qualification/debt decision; then resume
whole-script redesign. No local/VM job remains. No permanent experimental veto.

R165 bounded implementation: replace key-only comparator with native item-pair
identity/equality prefix and value tie-break using existing PyEquality/PyComparison.
No new sort framework, allocation owner or dispatch policy. Original nested-hook
case and second-equality failure must match independently executed Python; existing
JSON sorting-before-skip, refusal/cancellation, async ambient and cleanup stay green.
This fixes the demonstrated native subset, not arbitrary async guest-key ordering.
Current native CLR sort still has that prior limitation and three-way/stability
behavior; do not claim full custom-key equivalence. Larger sorting migration needs
its own justified scope. R164 possible CSV debt remains for this delivery boundary.
