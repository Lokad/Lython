from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
def run(args,name,expect=0):
 with (r/name).open('w',encoding='utf-8')as f:x=subprocess.run([env['DOTNET_HOST_PATH']]+args,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert (x.returncode==expect if expect==0 else x.returncode!=0),(r/name).read_text(encoding='utf-8')[-3500:]
 print(name,(r/name).read_text(encoding='utf-8').splitlines()[-1],flush=True)
copy=r/'baseline-regression';shutil.copytree('tests/Lokad.Lython.Tests/bin/Release/net11.0',copy)
baseline=r.parent/'string-comparison-r164/final/images/candidate/Lokad.Lython.dll';shutil.copyfile(baseline,copy/'Lokad.Lython.dll')
run(['vstest',str(copy/'Lokad.Lython.WhiteBox.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~JsonSortedComparisonTests','--logger:console;verbosity=minimal'],'baseline-regression.log',1)
assert 'Failed:     3' in (r/'baseline-regression.log').read_text(encoding='utf-8')
(r/'regression-proof.json').write_text(json.dumps(dict(baselineCoreSHA256=hashlib.sha256(baseline.read_bytes()).hexdigest(),sourceRestored=False,failedBefore=3,passedCurrent=3,testAssemblySHA256=hashlib.sha256((copy/'Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
for suite,filter in [('internal','(FullyQualifiedName~Json|FullyQualifiedName~ScalarComparison|FullyQualifiedName~AsyncStructuralAmbient|FullyQualifiedName~ExecutionSort)&Category!=Stress'),('public','(FullyQualifiedName~Json|FullyQualifiedName~Comparison|FullyQualifiedName~ListSort|FullyQualifiedName~SortedLifetime)&Category!=Stress')]:
 project='Lokad.Lython.Tests'if suite=='internal'else'Lokad.Lython.PublicApi.Tests'
 run(['test',f'tests/{project}/{project}.csproj','-c','Release','-f','net10.0','--no-restore','--filter',filter],f'final-{suite}10.log')
run(['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental'],'final-build.log')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'current-core.dll')
(r/'source.json').write_text(json.dumps(dict(baselineRevision='260b2acf',candidateSource='R165 working change',candidateCoreSHA256=hashlib.sha256((r/'current-core.dll').read_bytes()).hexdigest(),productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}),indent=2)+'\n',encoding='utf-8')
print('R165 checks and nonincremental final freeze complete.',flush=True)
