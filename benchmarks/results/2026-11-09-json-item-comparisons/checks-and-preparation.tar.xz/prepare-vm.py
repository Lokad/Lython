from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b514';v.mkdir(exist_ok=False);old=r.parent/'scalar-comparison-r163/b513'
proof=json.loads((r/'source.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in proof['productionSources'].items())
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
 s=(old/n).read_text(encoding='utf-8').replace('scalar-comparison-b513','shared-comparison-b514').replace('lython-b513-scalar-comparison','lython-b514-shared-comparison').replace('lython-b513-fixtures','lython-b514-fixtures')
 if n=='collect.py':
  a=s.index('jobs=[');z=s.index('\nenv =',a);s=s[:a]+"jobs=[['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],['scripts.config-edit.small','warm']]\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n"+s[z:]
  a=s.index("purpose='");z=s.index('\n                  warmupSeconds=',a);s=s[:a]+"purpose='R164/R165 contextual UTF-8 comparisons and native JSON item equality; resolve desktop CSV debt against committed f6861aa5, JSON configuration control.',"+s[z:];s=s.replace('started < 150','started < 120')
 if n=='launch.py':
  s=s.replace("'assert len(jobs)==4 '","'assert len(jobs)==3 '").replace('RuntimeMaxSec=180','RuntimeMaxSec=150').replace('ownerSeconds=180','ownerSeconds=150').replace('seconds=240','seconds=210')
  s=s.replace("root.mkdir();a.extractall(root,filter='data')", "root.mkdir();a.extractall(root,filter='data')\n previous=base/'scalar-comparison-b513-20261109'\n for n in ['common-worker.dll','common-adapter.dll','common-worker.deps.json','common-worker.runtimeconfig.json']:os.link(previous/n,root/n)\n os.link(previous/'current-core.dll',root/'baseline-core.dll')")
 if n in ['archive-owned.py','retrieve.py','assess-vm.py']:s=s.replace('==4','==3').replace('== 4','== 3').replace('jobs=4','jobs=3').replace('<150','<120').replace('Four-job','Three-job')
 if n.endswith('.py'):compile(s,n,'exec')
 (v/n).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(r/'current-core.dll',v/'current-core.dll')
shutil.copyfile(old/'representative.json',v/'representative.json')
shutil.copyfile(r.parent/'string-comparison-r164/baseline-proof.json',v/'baseline-source.json')
shutil.copyfile(r/'source.json',v/'final-source.json')
shutil.copyfile('src/Lokad.Lython/Runtime/LythonRuntime.ScalarComparison.cs',v/'ScalarComparison.cs')
(v/'source.patch').write_bytes(subprocess.check_output(['git','diff','f6861aa5','--','src/Lokad.Lython']))
base=r.parent/'string-comparison-r164/images/before'
fresh=json.loads((r.parent/'string-comparison-r164/baseline-proof.json').read_text(encoding='utf-8'))
prior=json.loads((old.parent/'final-source.json').read_text(encoding='utf-8'))
assert fresh['productionSources']==prior['productionSources']
bh=hashlib.sha256((old/'current-core.dll').read_bytes()).hexdigest();assert bh==prior['candidateCoreSHA256']
(v/'baseline-equivalence.json').write_text(json.dumps(dict(identicalProductionSources=True,reusedCoreSHA256=bh,freshPostcommitCoreSHA256=fresh['coreSHA256'],reason='Initial local preparation rejected binary identity before any VM mutation. R163 final precommit and f6861aa5 production sources are identical; reuse the explicitly identified prior freeze, not a postcommit binary.'),indent=2)+'\n',encoding='utf-8')
i=dict(sourceRevision='R163 final precommit freeze, production-source equivalent to f6861aa5, versus final R164/R165 working source freshly nonincremental. Common unchanged worker; no postcommit/CPython claim.',coreSHA256={x:bh if x.startswith('reference')else proof['candidateCoreSHA256']for x in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in base.glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(internal11=198,public11=1378,baselineRegressionsFailed=3,checks='Final .NET10 log counts retained separately; no full platform claim.'),indent=2)+'\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(jobs=3,roles=4,ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=3,warmupSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=88,ownerSeconds=150),indent=2)+'\n',encoding='utf-8')
for n in ['contract.md','pre-measurement-plan.md']:(v/n).write_text('Three bounded jobs using existing driver: CSV warm sync/async plus JSON configuration warm. Four independent roles; 5s warmup,7 rotated150ms rounds. Retain all adverse controls. Decide known desktop CSV debt before another redesign. Includes I/O, validation, prior-result cleanup; excludes compile/startup/reset/protocol/final cache teardown. Coarse process CPU diagnostic. No speed target veto or new framework.\n',encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz')as t:
 for p in v.iterdir():
  if p.name!='payload.tgz':t.add(p,arcname=p.name)
with tarfile.open(v/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+252*1024*1024
(v/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(v/'payload.tgz').stat().st_size,floorsUnchanged=True),indent=2)+'\n',encoding='utf-8')
# Reuse exact-copy recovery. A fresh sufficient-space check bypasses all mutation.
s=(old/'recover-space.py').read_text(encoding='utf-8')
s=s.replace("[('config-runtime-b510-20261109','2026-11-09-config-runtime-attribution'),('config-boundary-b509-20261109','2026-11-09-config-boundary')]","[('csv-runtime-b512-20261109','2026-11-09-csv-runtime-attribution'),('scalar-comparison-b513-20261109','2026-11-09-scalar-comparisons'),('bulk-whitespace-b508-20261109','2026-11-09-managed-whitespace-search')]")
s=s.replace('scalar-comparison-b513-space','shared-comparison-b514-space').replace("base/'scalar-comparison-b513-20261109'","base/'shared-comparison-b514-20261109'").replace('276938752',str(required))
s=s.replace("  rows.append(dict(**entry", "  rows.append(dict(**entry")
s=s.replace("allAliases=[str(p)]))", "allAliases=[str(p)]))\n  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>"+str(required)+":break")
compile(s,'recover-space','exec');(v/'recover-space.py').write_text(s,encoding='utf-8')
print('Three-job payload prepared; only new core/data shipped, prior baseline/auxiliaries verified and linked. Required free bytes',required,flush=True)
