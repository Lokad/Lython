from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
proofs = [{'kind': 'exact superseded compiled replica', 'canonical': 'benchmarks/results/2026-11-18-frontend-dispatch/candidate-core.dll.gz', 'canonicalSHA256': '192297e0a558958a11fed8a80b8fd51872dc28cc5723b27c42e3b596fbcc523a', 'member': None, 'sha256': '2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226', 'bytes': 5752832, 'anchor': 'frontend-dispatch-b957-20261118/candidate/Lokad.Lython.dll', 'committedBlobVerified': True}, {'kind': 'exact superseded compiled replica', 'canonical': 'benchmarks/results/2026-11-18-numeric-compiler-facts/comparison/candidate-core.dll.gz', 'canonicalSHA256': 'e92bbfc1733b23344bc7720f1e491dbaaa820b8d7a96962655d84d4d0827f79e', 'member': None, 'sha256': '29192b95b8d0ab729d55afa380e9ac0056e2f97f15bc70b485b15236319e948e', 'bytes': 5758464, 'anchor': 'numeric-compiler-b962-20261118/candidate/Lokad.Lython.dll', 'committedBlobVerified': True}]
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.run(['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode == 1
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    inodes = {}
    for proof in proofs:
        anchor = root / proof.pop('anchor')
        info = anchor.lstat()
        assert anchor.resolve() == anchor and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == proof['bytes'] and hashlib.sha256(anchor.read_bytes()).hexdigest() == proof['sha256']
        proof.update(links=info.st_nlink, paths=[])
        inodes[info.st_dev, info.st_ino] = proof
    for base, _, names in os.walk(root):
        for name in names:
            path = Path(base) / name
            info = path.lstat()
            if (proof := inodes.get((info.st_dev, info.st_ino))) is not None:
                assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                assert info.st_nlink == proof['links'] and info.st_size == proof['bytes']
                assert name == 'Lokad.Lython.dll'
                proof['paths'].append(str(path.relative_to(root)))
    for proof in proofs:
        assert len(proof['paths']) == proof['links']
        proof['paths'].sort()
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=proofs)))
