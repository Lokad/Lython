from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
donor=lab/"quiet"
template=notes/"direct-integer-return-cpython-20261122"/"quiet"
evidence=lab/"cpython"
base="/home/lokad/lython-bench-checks"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, contents):
    if path.suffix==".py":
        compile(contents,str(path),"exec")
    path.write_text(contents,encoding="utf-8",newline="\n")

def pushed(path):
    return subprocess.check_output(["git","show","origin/master:"+path],cwd=repo)

config=load(donor/"config.json")
receipt=load(donor/"archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert sha((donor/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
source=load(lab/"images.json")
image=source["imageFiles"]["candidate"]
frozen=lab/"frozen/candidate"
assert len(image)==32 and {name:sha((frozen/name).read_bytes()) for name in image}==image

evidence.mkdir(exist_ok=True)
existing=notes/"native-json-encoding-options-r540/quiet/representative.json"
catalog=load(existing)
config_case=next(x for x in catalog["cases"] if x["id"]=="scripts.config-edit.small")
catalog["cases"]=[config_case]
small=evidence/"configuration.json"
write(small,json.dumps(catalog,indent=2)+"\n")
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
         PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==source["protocolSHA256"]==config["protocolSHA256"]
proof_path=lab/"candidate-configuration-exact-verification.json"
subprocess.run([dotnet,frozen/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",small,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof_path],
    check=True,env=env,timeout=85)
proof=load(proof_path)
assert proof["state"]=="Completed" and proof["caseCount"]==1 and proof["catalogSha256"]==sha(small.read_bytes())

# Find one already committed diagnostic archive with sufficient verified space.
# Only an exact unused staging replica can be retired, and only under the lease.
archive_candidates=[
    ("2026-11-22-post-default-first-use-profile","post-default-first-use-profile-b1333-20261122"),
    ("2026-11-22-post-capture-first-use-profile","post-capture-first-use-profile-b1355-20261122"),
    ("2026-11-20-retained-dispatch-profile","retained-dispatch-profile-b1170-20261120"),
]
for name, folder in list(archive_candidates):
    manifest=json.loads(pushed(f"benchmarks/results/{name}/archive-receipt.json"))
    canonical=pushed(f"benchmarks/results/{name}/observations.tgz")
    assert sha(canonical)==manifest["archiveSHA256"]
    assert manifest["complete"] and manifest["allWorkersJoined"] and manifest["archivedAndVerifiedUnderLease"]
    archive_candidates[archive_candidates.index((name,folder))]=(name,folder,sha(canonical),len(canonical))
witness={digest:(name,count) for name,folder,digest,count in archive_candidates}
preferred=[folder+"/observations.tgz" for name,folder,digest,count in archive_candidates]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
inventory="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(REMOTE_BASE);witness=WITNESS;preferred=PREFERRED
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 found=[]
 candidates=list(b.glob('*/observations.tgz'))
 candidates.sort(key=lambda p:(str(p.relative_to(b)) not in preferred,-p.stat().st_size))
 for p in candidates:
  m=p.lstat()
  if not stat.S_ISREG(m.st_mode) or m.st_nlink!=1 or m.st_uid!=os.getuid() or p.resolve()!=p:continue
  if m.st_size not in {row[1] for row in witness.values()}:continue
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  if h in witness:found.append(dict(path=str(p.relative_to(b)),bytes=m.st_size,links=m.st_nlink,sha256=h))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,found=found)))
""".replace("REMOTE_BASE",repr(base)).replace("WITNESS",repr(witness)).replace("PREFERRED",repr(preferred))
checked=subprocess.run(ssh+["python3 -c "+shlex.quote(inventory)],capture_output=True,timeout=42)
assert checked.returncode==0,checked.stderr.decode()
(lab/"cpython-inventory.json").write_bytes(checked.stdout)
free=json.loads(checked.stdout)

root=base+"/json-delivery-cpython-b1378-20261122"
unit="lython-b1378-json-delivery-cpython-20261122"
core="Lokad.Lython.dll"
expanded=load(donor/"identity.json")["catalogs"]["expansion.json"]
local_expansion=notes/"expanded-builtin-span/quiet/representative.json"
assert sha(local_expansion.read_bytes())==expanded["sha256"]
archived_verification=load(lab/"candidate-expansion.json")
assert archived_verification["state"]=="Completed" and archived_verification["catalogSha256"]==expanded["sha256"]
catalogs={"expansion.json":dict(path=config["root"]+"/expansion.json",sha256=expanded["sha256"]),
          "configuration.json":dict(sha256=sha(small.read_bytes()))}
ids=[x["id"] for x in load(local_expansion)["cases"]]
assert ids[0]=="scripts.json-lines-shipment.expanded-options.large"
assert ids[1]=="scripts.json-lines-shipment.explicit-options.large"
jobs=[(ids[0],"warm"),(ids[1],"warm"),(config_case["id"],"warm"),
      (ids[0],"compile"),(config_case["id"],"compile"),(ids[0],"compile-run"),(config_case["id"],"compile-run")]
identity=dict(sourceRevision=source["candidate"], deliveryRevision="e4df38816",
              purpose="Compare the combined JSON checkpoint with stock CPython",
              imageFiles={"candidate":image}, coreSHA256={"candidate":image[core],"candidate-control":image[core]},
              auxiliaryFiles={n:h for n,h in image.items() if n!=core},
              catalogs=catalogs,cpythonWorkerSHA256=source["protocolSHA256"],
              cpythonExecutableSHA256="673525f3e1ac992831891979187e259c06bbd5e331ab50c0bb697f274ecb0f2a")
write(evidence/"identity.json",json.dumps(identity,indent=2)+"\n")
old=load(template/"config.json")
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    script=(template/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        script=script.replace("catalog = root / 'representative.json'","catalog = root / 'expansion.json'")
        script=script.replace("== hashlib.sha256(python.read_bytes()).hexdigest()",
            "== identity['cpythonExecutableSHA256'] == hashlib.sha256(python.read_bytes()).hexdigest()")
        start,end=script.index("    for case_id,lane in ["),script.index("        diagnostic = False")
        script=script[:start]+"    for case_id,lane in "+repr(jobs)+""":
        assert time.monotonic()-started<410,'Leave time for cleanup and archival'
        catalog=root/('configuration.json' if case_id=='scripts.config-edit.small' else 'expansion.json')
        manifest_hash=hashlib.sha256(catalog.read_bytes()).hexdigest()
        assert manifest_hash==identity['catalogs'][catalog.name]['sha256']
        cases={c['id']:c for c in json.loads(catalog.read_text())['cases']}
"""+script[end:]
    elif name in ("archive-owned.py","retrieve.py"):
        script=script.replace("jobs=4,","jobs=7,").replace("['jobs']==4","['jobs']==7").replace("len(raw['jobs'])==4","len(raw['jobs'])==7")
    write(evidence/name,script.replace("B1373","B1378"))
assert b"\r" not in (evidence/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh","configuration.json")
payload=evidence/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:archive.add(evidence/name,arcname=name)
unpacked=sum((evidence/name).stat().st_size for name in parts)
retire=[]
available=free["free"]
target=176160768+unpacked+640*1024
for match in free["found"]:
    if available>target:break
    assert witness[match["sha256"]][1]==match["bytes"]
    retire.append(dict(paths=[match["path"]],links=1,bytes=match["bytes"],sha256=match["sha256"],archives={}))
    available+=match["bytes"]
assert available>target,(available,target,free)
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],donorArchiveSHA256=receipt["archiveSHA256"],
           protocolSource=config["protocolSource"],protocolSHA256=config["protocolSHA256"],
           payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
           retireGroups=retire,catalogs=catalogs,unpackedBytes=unpacked)
write(evidence/"config.json",json.dumps(stage,indent=2)+"\n")
remote=(lab/"confirmation/remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
remote=remote.replace(" for role in ['reference','candidate']:"," for role in ['candidate']:")
remote=remote.replace("  source_catalog=Path(witness['path'])","  if 'path' not in witness:\n"
    "   assert sha(root/leaf)==witness['sha256'];continue\n  source_catalog=Path(witness['path'])")
remote=remote.replace("RuntimeMaxSec=180","RuntimeMaxSec=485").replace("lython-b1377-fixtures","lython-b1378-fixtures")
write(evidence/"remote-launch.py",remote)
write(lab/"launch-cpython.py",(lab/"launch.py").read_text(encoding="utf-8").replace("parent/'quiet'","parent/'cpython'")
      .replace("Direct JSON keyword mapping comparison","Combined JSON CPython checkpoint").replace("255","402"))
print("Verified the existing JSON Lines inputs and the bounded configuration catalog for seven independent phases.")
