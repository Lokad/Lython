from pathlib import Path
import base64
import hashlib
import json
import shutil
import statistics
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
evidence=lab/"cpython"
result=repo/"benchmarks/results/2026-11-22-json-delivery-cpython"
ref="[B1378]"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, text):
    path.write_text(text,encoding="utf-8",newline="\n")

def save_data(path, data):
    save(path,json.dumps(data,indent=2)+"\n")

def extent(values, digits, unit):
    lo,hi=(f"{v:.{digits}f}" for v in values)
    return lo+unit if lo==hi else f"{lo}–{hi}{unit}"

receipt=load(evidence/"archive-receipt.json")
raw=load(evidence/"retrieved/confirmation/confirmation.json")
identity=load(evidence/"identity.json")
assert receipt["complete"] and receipt["jobs"]==7 and receipt["archivedAndVerifiedUnderLease"]
assert hashlib.sha256((evidence/"observations.tgz").read_bytes()).hexdigest()==receipt["archiveSHA256"]
assert raw["complete"] and len(raw["jobs"])==7
labels=("candidate","candidate-control","CPython","CPython-control")
rows=[]
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"]
    assert set(job["identities"])==set(labels)
    lane,=job["lanes"]
    medians={}
    cpu_medians={}
    variation={}
    for label in labels:
        batch=[s for s in job["samples"] if s["engine"]==label]
        assert len(batch)==7
        elapsed=[1000*s["response"]["elapsedTicks"]/s["response"]["clockFrequency"]/s["response"]["completedInvocations"] for s in batch]
        medians[label]=statistics.median(elapsed)
        q=statistics.quantiles(elapsed,n=4,method="inclusive")
        variation[label]=100*(q[2]-q[0])/medians[label]
        cpu_medians[label]=statistics.median([1000*s["externalProcessCpuTicks"]/s["externalCpuFrequency"]/s["response"]["completedInvocations"] for s in batch])
    left=sorted(medians[n] for n in labels[:2])
    right=sorted(medians[n] for n in labels[2:])
    ratio=[left[0]/right[1],left[1]/right[0]]
    rows.append(dict(case=job["case"],lane=lane,lythonMs=left,cpythonMs=right,ratio=ratio,
                     lythonSpread=100*(left[1]/left[0]-1),cpythonSpread=100*(right[1]/right[0]-1),
                     iqrPercent=variation,processCpuMilliseconds=cpu_medians))
summary=dict(source=identity["sourceRevision"],relatedProduction=identity["deliveryRevision"],
    elapsedSeconds=raw["elapsedSeconds"],image=identity["imageFiles"],cpythonExecutableSHA256=identity["cpythonExecutableSHA256"],
    complete=True,timedBatches=28*len(rows),rows=rows)
result.mkdir(exist_ok=True)
save_data(result/"summary.json",summary)
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(evidence/name,result/name)
names={
    "scripts.json-lines-shipment.expanded-options.large":"JSON Lines export with expanded options",
    "scripts.json-lines-shipment.explicit-options.large":"JSON Lines export with explicit options",
    "scripts.config-edit.small":"Configuration edit",
}
boundaries={"warm":"Warm","compile":"Compilation only","compile-run":"Compile-to-result"}
inputs={
    "scripts.json-lines-shipment.expanded-options.large":"3,072 records / 189,441 B",
    "scripts.json-lines-shipment.explicit-options.large":"3,072 records / 189,441 B",
    "scripts.config-edit.small":"",
}
case,=load(evidence/"configuration.json")["cases"]
input_files=json.loads(case["fixtureJson"])["inputFiles"]
assert len(input_files)==1
inputs[case["id"]]=f"One JSON file / {len(base64.b64decode(next(iter(input_files.values())),validate=True)):,} B"
table = [
    "| Complete script | Phase | Lython | CPython | Lython / CPython | Lython / CPython worker spread |",
    "| --- | --- | ---: | ---: | ---: | ---: |",
]
def measurement(row):
    digits=5 if row["lane"]=="compile" else 3
    return [extent(row["lythonMs"],digits," ms"),extent(row["cpythonMs"],digits," ms"),extent(row["ratio"],3,"×")]
for row in rows:
    fields=[names[row["case"]],boundaries[row["lane"]],*measurement(row),f"{row['lythonSpread']:.2f} / {row['cpythonSpread']:.2f}%"]
    table.append("| "+" | ".join(fields)+" |")
report=f"""# B1378 JSON delivery against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with
Ubuntu 24.04.4 and .NET 11 RC3. The frozen Lython core is
`{summary['source'][:9]}`, the B1376 candidate. The measured encoder
and binding patches are present in production `{summary['relatedProduction']}`,
which also includes the separately qualified regex correction.
The external engine is stock CPython 3.13.16. The two JSON Lines
exports read the same 3,072 records in 189,441 bytes and produce the
same output files. The configuration script reads one small file,
edits its fields and writes a verified replacement.

"""
report+="\n".join(table)+f"""

Ratios divide Lython elapsed by CPython elapsed. Above 1× means
Lython takes longer. Each range spans all pairings of two process
medians per engine. Each phase uses independent processes, normal
GC and tiering, eight seconds of warmup per worker and seven timed
batches per worker.

Warm execution includes mediated RAM-backed I/O for Lython, native
file I/O for CPython, output checks and prior-result disposal.
Compilation-only includes compiled-owner disposal. Time to result
includes compilation, one execution and their cleanup. Startup and
final teardown use separate boundaries. Process CPU in the raw
results includes worker reset and request handling.

All {summary['timedBatches']} timed batches verified in
{summary['elapsedSeconds']:.0f} seconds. The complete Lython image and the
CPython executable matched their recorded hashes. Both quiet gates
passed, all workers joined and the persistent archive verified under
the lease. The source-pair positional regression remains open.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Verified inputs and procedures](procedures.tar.xz) ·
[JSON source pair](../2026-11-22-json-direct-mapping/README.md) ·
[Positional control](../2026-11-22-json-positional-control/README.md).
"""
save(result/"README.md",report)
files=("prepare-cpython.py","launch-cpython.py","report-cpython.py","cpython-inventory.json",
       "candidate-configuration-exact-verification.json","candidate-expansion.json","cpython/observe-not-before.json")
with tarfile.open(result/"procedures.tar.xz","w:xz") as a:
    for n in files:a.add(lab/n,arcname=n)
with tarfile.open(result/"procedures.tar.xz") as a:assert set(a.getnames())==set(files)

def format_public(row):
    peak=max(row["lythonSpread"],row["cpythonSpread"])
    engine="Lython" if row["lythonSpread"]>=row["cpythonSpread"] else "CPython"
    status="Diagnostic."
    if row["ratio"][0]<=1<=row["ratio"][1]:status="Inconclusive. Spans parity."
    elif peak>=5:status="Uncertain magnitude."
    middle=inputs[row["case"]] if row["lane"]=="warm" else boundaries[row["lane"]]
    fields=[names[row["case"]],middle,*measurement(row),f"{status} {engine} worker spread {peak:.2f}%. {ref}."]
    return "| "+" | ".join(fields)+" |"
guide_path=repo/"docs/BENCHMARKS.md"
guide=guide_path.read_text(encoding="utf-8")
assert ref not in guide
marker=next(line for line in guide.splitlines() if line.startswith("| JSON Lines export with expanded options |"))
guide=guide.replace(marker,"\n".join(format_public(r) for r in rows if r["lane"]=="warm"))
marker=next(line for line in guide.splitlines() if line.startswith("| JSON normalization | Compilation only |"))
guide=guide.replace(marker,"\n".join(format_public(r) for r in rows if r["lane"]!="warm")+"\n"+marker)
marker="| [B1373] |"
offset=guide.index(marker)
guide=guide[:offset]+f"| {ref} | `{summary['source'][:9]}` | 2026-11-22 UTC |\n"+guide[offset:]
offset=guide.index("[B1373]:")
guide=guide[:offset]+f"{ref}: ../benchmarks/results/2026-11-22-json-delivery-cpython/README.md\n"+guide[offset:]
save(guide_path,guide)
for line in table: print(line)
