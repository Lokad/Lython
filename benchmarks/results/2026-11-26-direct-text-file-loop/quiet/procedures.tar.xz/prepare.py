from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("json-ready-construction-20261126")
local = lab / "local"
local.mkdir()
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
write = lambda path, value: path.write_text(value, encoding="utf-8", newline="\n")
save = lambda path, value: write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = lambda path: {p.name: sha(p) for p in path.iterdir()}

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
subprocess.run(["git", "diff", "--exit-code", "e222c5221", head, "--", "src"], cwd=repo, check=True)
prior_quiet = prior / "comparison/quiet"
previous = read(prior_quiet / "identity.json")
previous_patch = subprocess.check_output(
    ["git", "diff", "--binary", previous["sourceRevision"], head, "--", "src"], cwd=repo
)
assert hashlib.sha256(previous_patch).hexdigest() == previous["sourcePatchSHA256"]
receipt = read(prior_quiet / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["archiveSHA256"] == sha(prior_quiet / "observations.tar.xz")
donor = prior / "frozen/candidate"
assert len(previous["imageFiles"]["candidate"]) == 32
assert manifest(donor) == previous["imageFiles"]["candidate"]
patch = subprocess.check_output(["git", "diff", "--binary", "--", "src"], cwd=repo)
assert patch.count(b"diff --git ") == 3 and b"LythonRuntime.Executable.Interpreter.Async.cs" in patch
(lab / "candidate.patch").write_bytes(patch)

core = "Lokad.Lython.dll"
images = {}
for role in ("reference", "candidate"):
    image = local / role
    shutil.copytree(donor, image)
    assert manifest(image) == previous["imageFiles"]["candidate"]
    if role == "candidate":
        shutil.copyfile(repo / "src/Lokad.Lython/bin/Release/net11.0" / core, image / core)
    images[role] = manifest(image)
assert {name for name in images["reference"] if images["reference"][name] != images["candidate"][name]} == {core}

catalog = read(prior_quiet / "representative.json")
search = "scripts.file-search.large"
lines = "scripts.json-summary-helpers.large"
mapped = "diagnostic.shipment-file-fed-map"
affix = read(lab.with_name("direct-affix-return-20261126") / "comparison/quiet/representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] == lines]
catalog["cases"].extend(case for case in affix["cases"] if case["id"] in (search, mapped))
assert {case["id"] for case in catalog["cases"]} == {search, lines, mapped}
save(local / "representative.json", catalog)
save(local / "jobs.json", {"warm": [[mapped, "warm-async"], [search, "warm"], [lines, "warm"],
                                   [search, "warm-async"], [lines, "warm-async"]]})
shutil.copyfile(prior_quiet / "cpython-worker.py", local / "cpython-worker.py")
assert sha(local / "cpython-worker.py") == previous["cpythonWorkerSHA256"]
identity = dict(
    sourceRevision=head, sourcePatchSHA256=sha(lab / "candidate.patch"), imageFiles=images,
    coreSHA256={r+s:v[core] for r,v in images.items() for s in ("", "-control")},
    cpythonWorkerSHA256=previous["cpythonWorkerSHA256"], expectedCPythonSHA256=previous["expectedCPythonSHA256"],
    catalogs={name:{"sha256":sha(local / name)} for name in ("representative.json", "jobs.json")},
    purpose="Remove the executable loop cursor and result handoff for exact borrowed text files.",
)
save(local / "identity.json", identity)

old = lab.with_name("ready-json-decoder-entry-20261126") / "local"
collector = (old / "collect.py").read_text(encoding="utf-8")
assert collector.count("len(jobs) == 4") == 1
collector = collector.replace("len(jobs) == 4", "len(jobs) == 5")
collector = collector.replace("lython-json-ready-fixture-", "lython-json-default-decoder-fixture-")
write(local / "collect.py", collector)
write(local / "run.sh", (old / "run.sh").read_text(encoding="utf-8"))
assert b"\r" not in (local / "run.sh").read_bytes()

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
allocation_tool = lab.with_name("json-traversal-20261124") / "reference"
allocation = {}
for role, files in images.items():
    image = local / role
    verify = lab / (role + "-verify.json")
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
                    local / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", local / "cpython-worker.py", "--out", verify],
                   cwd=repo, env=env, check=True, timeout=85)
    proof = read(verify)
    assert proof["state"] == "Completed" and proof["caseCount"] == 3
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
    assert proof["launched"]["library"]["sha256"].lower() == files[core]
    path = lab / (role + "-allocated")
    shutil.copytree(image, path)
    assert manifest(path) == files
    for executable in allocation_tool.glob("ValidatedAllocation*"):
        shutil.copyfile(executable, path / executable.name)
    output = lab / (role + "-allocation.json")
    subprocess.run([dotnet, path / "ValidatedAllocation.dll", path, local / "representative.json", output],
                   cwd=repo, env=env, check=True, timeout=65)
    allocation[role] = read(output)["rows"]
summary = []
for before, after in zip(allocation["reference"], allocation["candidate"], strict=True):
    assert before["id"] == after["id"] and before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    summary.append(dict(case=before["id"],
        bytes=[median(row["allocatedBytesPerInvocation"]) for row in (before, after)],
        peak=[row["peakExecutionMemoryBytes"] for row in (before, after)]))
save(lab / "allocation-summary.json", summary)
print(json.dumps(summary))
