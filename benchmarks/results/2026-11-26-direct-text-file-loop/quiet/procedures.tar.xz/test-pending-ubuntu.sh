set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/direct-text-file-loop-20261126"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj \
    -c Release -f net10.0 --no-restore --artifacts-path "$lab/delivery-ubuntu" \
    --filter 'Category!=Stress&FullyQualifiedName~CancellationWaitsForActualReadAndUncancelledCloseBeforeRefund' \
    > "$lab/pending-loop-ubuntu10.log" 2>&1
tail -7 "$lab/pending-loop-ubuntu10.log"
