from pathlib import Path
from statistics import median
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
local = lab / "local"
target = lab.parents[3] / "benchmarks/results/2026-11-26-direct-text-file-loop"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(local / "identity.json")
receipt = read(local / "archive-receipt.json")
assert (local / "exit-code.txt").read_text(encoding="utf-8").strip() == "0"
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
    "archivedAndVerifiedUnderLease"))
assert receipt["warmJobs"] == 5 and receipt["quietBeforeAndAfter"] is None
assert receipt["archiveSHA256"] == sha(local / "observations.tar.xz")
assert identity["sourcePatchSHA256"] == sha(lab / "candidate.patch")
with tarfile.open(local / "observations.tar.xz") as archive:
    raw = json.load(archive.extractfile("confirmation/confirmation.json"))
    assert json.load(archive.extractfile("identity.json")) == identity
    for name, expected in identity["catalogs"].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected["sha256"]

assert raw["complete"] and len(raw["jobs"]) == 5
rows = []
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    measures = {}
    for role, worker in job["identities"].items():
        core = next(v for v in worker["libraries"] if Path(v["path"]).name == "Lokad.Lython.dll")
        assert core["sha256"].lower() == identity["coreSHA256"][role].lower()
        samples = [x for x in job["samples"] if x["engine"] == role]
        assert len(samples) == 7
        elapsed, cpu = [], []
        for sample in samples:
            response = sample["response"]
            assert response["status"] == "Completed"
            count = response["completedInvocations"]
            elapsed.append(1e6 * response["elapsedTicks"] / response["clockFrequency"] / count)
            cpu.append(1e6 * sample["externalProcessCpuTicks"] / sample["externalCpuFrequency"] / count)
        measures[role] = dict(elapsed=median(elapsed), cpu=median(cpu))
    differences, spreads = {}, {}
    for metric in ("elapsed", "cpu"):
        before, after = ([measures[role][metric], measures[role + "-control"][metric]]
                         for role in ("reference", "candidate"))
        pairs = [100 * (new / old - 1) for new in after for old in before]
        differences[metric] = [min(pairs), max(pairs)]
        spreads[metric] = [100 * (max(row) / min(row) - 1) for row in (before, after)]
    rows.append(dict(case=job["case"], lane=job["lane"], processMedianUs=measures,
                     percentChange=differences, sameSourceSpreadPercent=spreads))
    print(job["case"], job["lane"], differences, spreads)

target.mkdir(parents=True, exist_ok=True)
for name in ("identity.json", "archive-receipt.json", "observations.tar.xz"):
    shutil.copyfile(local / name, target / name)
for name in ("candidate.patch", "allocation-summary.json"):
    shutil.copyfile(lab / name, target / name)
shutil.copyfile(lab / "routes/counts.json", target / "routes.json")
summary = dict(sourceRevision=identity["sourceRevision"], sourcePatchSHA256=identity["sourcePatchSHA256"],
               timedBatches=140, environment="WSL diagnostic", rows=rows)
(target / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
paths = [(lab, name) for name in ("archive-local.py", "prepare.py", "prepare.log", "routes.py", "routes-console.log",
    "test-ubuntu.sh", "tests.patch", "run-local.sh", "reference-verify.json", "candidate-verify.json",
    "reference-allocation.json", "candidate-allocation.json", "alias-recheck-win11.log",
    "Lokad.Lython.Tests-win11.log", "Lokad.Lython.PublicApi.Tests-win11.log",
    "Lokad.Lython.Tests-delivery-ubuntu10.log", "Lokad.Lython.PublicApi.Tests-delivery-ubuntu10.log")]
paths.extend((lab, "routes/" + name) for name in ("diagnostic.patch", "cases.json", "build-core.log",
    "build-probe.log", "run.log"))
paths.extend((lab, "local/" + name) for name in ("collect-console.log", "exit-code.txt"))
with tarfile.open(target / "procedures.tar.xz", "w:xz") as archive:
    for parent, name in paths:
        archive.add(parent / name, arcname=name, recursive=False)
