set -eu
lab="$PWD/.git/agent-notes/review-20261031/direct-text-file-loop-20261126"
cpu=$(python3 -c 'import os; print(max(os.sched_getaffinity(0)))')
echo "Pinned CPU $cpu"
exec timeout 245s taskset -c "$cpu" sh "$lab/local/run.sh"
