from pathlib import Path
import ast,hashlib,json,tarfile

lab=Path(__file__).resolve().parent
donor=lab/'quiet'
out=lab/'invoice-confirmation'
out.mkdir(exist_ok=True)
read=lambda f:f.read_text(encoding='utf-8-sig')
load=lambda f:json.loads(read(f))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(path,source):
    if path.suffix=='.py': ast.parse(source)
    path.write_text(source,encoding='utf-8',newline='\n')

old=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
pair=load(lab/'frozen-identity.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
assert pair['images']==old['identity']['imageFiles']
assert all(len(files)==32 and {n:sha(lab/'frozen'/role/n) for n in files}==files for role,files in pair['images'].items())
assert all(load(lab/f'{role}-verify.json')['catalogSha256']==old['catalogSHA256'] for role in pair['images'])
root=old['root']+'-invoice-control'
unit=old['unit']+'-invoice-control'
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    source=read(donor/name).replace(old['root'],root).replace(old['unit'],unit)
    source=source.replace('len(jobs)==3','len(jobs)==1').replace("['jobs'])==3","['jobs'])==1").replace(
        "['jobs']==3","['jobs']==1").replace('jobs=3,','jobs=1,')
    if name=='collect.py':
        a=source.index('\njobs = ')
        b=source.index('\nassert len(jobs)',a)
        source=source[:a]+"\njobs = [('scripts.csv-invoice.large', 'warm')]"+source[b:]
    write(out/name,source)
assert b'\r' not in (out/'run.sh').read_bytes()
for name in ('identity.json','representative.json','cpython-worker.py'):
    (out/name).write_bytes((donor/name).read_bytes())
parts=['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh']
payload=out/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts:archive.add(out/name,arcname=name)
expanded=sum((out/name).stat().st_size for name in parts)
assert receipt['freeBytesAfterArchive']>168*1024*1024+expanded+1310720
config={**old,'root':root,'unit':unit,'source':old['root'],'sourceFiles':pair['images'],'retireGroups':[],
    'sourceCatalogSHA256':old['catalogSHA256'],'donorArchiveSHA256':receipt['archiveSHA256'],
    'payloadBytes':payload.stat().st_size,'payloadSHA256':sha(payload),'unpackedBytes':expanded}
write(out/'config.json',json.dumps(config,indent=2)+'\n')
source=read(donor/'remote-launch.py')
a=source.index('\nc=')+1
b=source.index('\nb=Path(',a)
source=source[:a]+'c='+repr(config)+source[b:]
source=source.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    " for role,files in c['sourceFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
source=source.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace(
    'lython-b1179-fixtures','lython-b1179-invoice-control-fixtures')
write(out/'remote-launch.py',source)
launch=read(lab/'launch-quiet.py').replace("r=Path(__file__).parent/'quiet'",'r=Path(__file__).parent')
write(out/'launch.py',launch.replace('seconds=215','seconds=91').replace('before 215','before 91').replace(
    'Funded annotation values source pair','Warm invoice control confirmation'))
summary=read(lab/'summarize-quiet.py').replace("'quiet/retrieved/confirmation/confirmation.json'","'retrieved/confirmation/confirmation.json'").replace(
    "'quiet/retrieved/retirement-receipt.json'","'retrieved/retirement-receipt.json'").replace("len(raw['jobs'])==3","len(raw['jobs'])==1")
write(out/'summarize.py',summary)
