set -eu
root=/home/lokad/lython-bench-checks/dynamic-record-layout-b1179-20261120-invoice-control
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
