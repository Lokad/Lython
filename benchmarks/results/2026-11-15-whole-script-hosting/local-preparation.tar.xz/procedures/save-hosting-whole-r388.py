from pathlib import Path
import hashlib
import json
import shutil
import tarfile

notes = Path(__file__).parent
source = notes / 'hosting-whole-r388'
target = Path('benchmarks/results/2026-11-15-whole-script-hosting')
target.mkdir(exist_ok=False)
receipt = json.loads((source / 'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((source / 'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
for name in ['summary.json', 'identity.json', 'prospective.json', 'archive-receipt.json', 'terminal-status.json', 'observations.tgz']:
    shutil.copyfile(source / name, target / name)
with tarfile.open(target / 'local-preparation.tar.xz', 'w:xz') as archive:
    for name in ['config.json', 'launch.py', 'launch-command.py', 'launch-attempt.json', 'launch.log',
                 'preparation-correction-attempt.json', 'preparation-correction-command.py', 'preparation-correction.log',
                 'observe-not-before.json', 'retrieve.py', 'summarize.py']:
        archive.add(source / name, arcname=name)
    for name in ['prepare-hosting-whole-r388.py', 'correct-hosting-preparation-r388.py', 'save-hosting-whole-r388.py']:
        archive.add(notes / name, arcname='procedures/' + name)
decision = {'source': '810379be / frozen 8fbfa3f0', 'runtimeChanged': False,
            'observation': 'Completed-I/O RunAsync is modestly slower on all three scripts. Captured text has the clearest controls and supporting wider CPU.',
            'next': 'Attribute async captured-text work to actual file/iteration/builtin completion versus common dispatch and scheduling before choosing a redesign.',
            'hypotheses': ['Per-line completed async file/iteration machinery', 'Completed builtin/protocol setup and disposal', 'Invocation/result scheduling'],
            'existingArchitecture': ['Both APIs use ExecuteInstructionPrefix and prepared executable functions', 'Native helper prefixes are shared', 'ExecutionThreads reuses startup workers and releases them at actual suspension'],
            'notJustified': ['Duplicate dispatch framework', 'Removing effective cancellation or ownership admission', 'Calling wider process CPU guest interpreter time', 'Claiming pending-I/O latency or portable speedup'],
            'limits': ['Two independent processes per API, five rotating rounds; diagnostic rather than confidence intervals', 'Wider CPU includes fixture reset and protocol', 'CSV async control spread 3.06%; file sync spread 3.09%', 'No heap/RSS, startup or actual I/O suspension measurement'],
            'publicationHeld': True}
(target/'decision.json').write_text(json.dumps(decision, indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'saved': str(target), 'archiveSHA256': receipt['archiveSHA256'], 'elapsedSeconds': receipt['elapsedSeconds']}))
