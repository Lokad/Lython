from pathlib import Path
import ast
import hashlib
import json
import tarfile

notes = Path(__file__).parent
old = notes / 'fresh-config-r386'
out = notes / 'hosting-whole-r388'
out.mkdir(exist_ok=False)
remote_old = 'fresh-config-b774-20261115'
remote_new = 'hosting-whole-b775-20261115'
unit_old = 'lython-b774-fresh-config-20261115'
unit_new = 'lython-b775-hosting-whole-20261115'
catalog = notes / 'function-slot-binding-r384/catalog.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = json.loads((old / 'config.json').read_text(encoding='utf-8'))
config['root'] = config['root'].replace(remote_old, remote_new)
config['unit'] = unit_new
identity = config['identity']
identity['purpose'] = 'Unchanged complete scripts: public Run versus awaited RunAsync with completed host I/O, two independent processes per API. Attribute before redesign; no CPU/CPython gain claim.'
identity['catalogSHA256'] = sha(catalog)
identity['roleMeaning'] = {'reference': 'Run', 'reference-control': 'Run', 'candidate': 'RunAsync', 'candidate-control': 'RunAsync'}
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
prospective = dict(cases=['scripts.csv-fulfillment.large', 'scripts.text-summary-helpers.nonlocal-counter.large', 'scripts.file-search.large.protected'],
                   question='Does the plausible local identity-call API gap matter to complete scripts on the quiet VM?',
                   acceptance='Existing command-v2 identity/full goldens/quiet/shared-balance/Closed/join/archive gates; no runtime change.',
                   warmupSeconds=5, capturedWarmupSeconds=12, requestBatchSeconds=.5, rounds=5,
                   ownerSeconds=240, stoppingCriterion='Finish three matched API jobs. If a material consistent gap survives controls and wider CPU, attribute before redesign; otherwise record uncertainty and continue common operand/iteration assessment.',
                   storage='Reuse immutable B773 8fbf image/catalog and B772 protocol module. No image/catalog upload, retirement or floor changes.', publicationHeld=True)
(out / 'prospective.json').write_text(json.dumps(prospective, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py']:
    text = (old / name).read_text(encoding='utf-8').replace(remote_old, remote_new).replace(unit_old, unit_new).replace('B774', 'B775')
    if name == 'collect.py':
        start = text.index('\njobs=') + 1
        end = text.index('\nenv =', start)
        text = text[:start] + 'jobs=' + repr([[c, 'warm-vs-warm-async'] for c in prospective['cases']]) + '\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n' + text[end:]
        text = text.replace('"""Representative CPython delivery checkpoint through unchanged comparison workers/protocol."""', '"""Complete-script hosting parity through unchanged comparison workers/protocol."""')
        text = text.replace('self.label, self.case, self.lane, self.sequence = label, case, lane, 0', "self.label, self.case, self.lane, self.sequence = label, case, ('warm-async' if label.startswith('candidate') else 'warm'), 0")
        start = text.index('        command = (')
        end = text.index('\n        self.process =', start)
        text = text[:start] + "        command = [str(dotnet), str(root/'candidate/Lokad.Lython.Benchmarks.dll'), '--compare', 'worker', '--catalog', str(catalog)]" + text[end:]
        text = text.replace("labels=['candidate','CPython','candidate-control','CPython-control']", "labels=['candidate','reference','candidate-control','reference-control']")
        text = text.replace("< 120, 'Reserve60seconds", "< 180, 'Reserve60seconds")
        text = text.replace('identities={w.label:w.identity for w in workers},', 'identities={w.label:w.identity for w in workers}, executionLanes={w.label:w.lane for w in workers},')
    elif name == 'retrieve.py':
        text = text.replace('<180', '<240')
    if name.endswith('.py'): ast.parse(text)
    (out / name).write_text(text, encoding='utf-8', newline='\n')
with tarfile.open(out / 'payload.tgz', 'w:gz') as archive:
    for name in ['identity.json', 'prospective.json', 'collect.py', 'archive-owned.py', 'run.sh']:
        archive.add(out / name, arcname=name)
with tarfile.open(out / 'payload.tgz') as archive: unpacked = sum(m.size for m in archive.getmembers())
config.update(payloadBytes=(out/'payload.tgz').stat().st_size, payloadSHA256=sha(out/'payload.tgz'), unpackedBytes=unpacked)
(out / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
text = (old / 'launch-command.py').read_text(encoding='utf-8')
start = text.index('config='); end = text.index('\nbase=', start)
text = text[:start] + 'config=' + repr(config) + text[end:]
text = text.replace(" assert digest(root/'representative.json')==config['identity']['catalogSHA256']", " assert digest(catalog/'representative.json')==config['identity']['catalogSHA256']\n os.link(catalog/'representative.json',root/'representative.json')")
text = text.replace('lython-b774-fixtures', 'lython-b775-fixtures').replace('--property=RuntimeMaxSec=180', '--property=RuntimeMaxSec=240').replace('newSmallCatalog=True', 'noNewCatalogUpload=True')
ast.parse(text)
(out / 'launch-command.py').write_text(text, encoding='utf-8', newline='\n')
text = (old / 'launch.py').read_text(encoding='utf-8').replace("r.parent/'entry-stage-r385/terminal-status.json'", "r.parent/'fresh-config-r386/terminal-status.json'")
text = text.replace('seconds=120', 'seconds=155').replace('ownerSeconds=180', 'ownerSeconds=240')
ast.parse(text)
(out / 'launch.py').write_text(text, encoding='utf-8', newline='\n')
print(json.dumps(dict(prepared=True, payloadBytes=config['payloadBytes'], unpackedBytes=unpacked, jobs=3, catalogSHA256=identity['catalogSHA256'])))
