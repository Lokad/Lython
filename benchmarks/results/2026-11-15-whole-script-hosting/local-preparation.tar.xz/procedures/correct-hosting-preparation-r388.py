from pathlib import Path
import base64
import datetime
import hashlib
import json
import subprocess

out = Path(__file__).parent / 'hosting-whole-r388'
assert not (out / 'preparation-correction-attempt.json').exists()
failure = (out / 'launch.log').read_text(encoding='utf-8')
assert 'FileNotFoundError' in failure and 'entry-stage-b773-20261115/representative.json' in failure
config = json.loads((out / 'config.json').read_text(encoding='utf-8'))
payload = {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in
           ['identity.json', 'prospective.json', 'collect.py', 'archive-owned.py', 'run.sh']}
code = '''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess
CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and root.resolve()==root and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'exit-code.txt').exists()and not(root/'confirmation').exists()and not(root/'guest-fixtures').exists()
 service=subprocess.run(['systemctl','show',config['unit']+'.service','--property=LoadState,ActiveState,MainPID'],text=True,capture_output=True)
 assert 'LoadState=not-found' in service.stdout and 'MainPID=0' in service.stdout,service.stdout
 for name,h in payload.items():assert sha(root/name)==h
 assert sha(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(root/'candidate'/name)==h
 assert sha(source/'catalog.json')==config['identity']['catalogSHA256']
 assert not(root/'representative.json').exists()and not(root/'cpython-worker.py').exists()
 python_source=Path(config['pythonRoot']);assert python_source.parent==base and python_source.resolve()==python_source
 assert sha(python_source/'cpython-worker.py')==config['pythonWorkerSHA256']
 before=shutil.disk_usage(root).free;assert before>254*1024*1024
 os.link(source/'catalog.json',root/'representative.json')
 os.link(python_source/'cpython-worker.py',root/'cpython-worker.py')
 (root/'preparation-failure.json').write_text(json.dumps(dict(originalFailure=failure,collectionHadNotStarted=True,sourceCatalog='catalog.json',noAutomaticCollectionRestart=True))+'\\n')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noNewImageUpload=True,noNewCatalogUpload=True,floorsUnchanged=True,noRetirementOrDeduplication=True))+'\\n')
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b775-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''
code = code.replace('CONFIG', 'config='+repr(config)+'\npayload='+repr(payload)+'\nfailure='+repr(failure))
import ast
ast.parse(code)
(out / 'preparation-correction-command.py').write_text(code, encoding='utf-8', newline='\n')
now = datetime.datetime.now(datetime.timezone.utc)
(out / 'preparation-correction-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),collectionHadNotStarted=True))+'\n',encoding='utf-8')
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result = subprocess.run(ssh+['python3 -'], input=code, capture_output=True, text=True, encoding='utf-8', timeout=60)
(out / 'preparation-correction.log').write_text(result.stdout+result.stderr,encoding='utf-8')
assert result.returncode==0, result.stdout+result.stderr
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=155)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8')
print(result.stdout,flush=True)
print('Earliest observation', (now+datetime.timedelta(seconds=155)).isoformat(),flush=True)
