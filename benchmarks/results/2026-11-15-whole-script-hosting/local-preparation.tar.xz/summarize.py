from pathlib import Path
import json
import statistics

root = Path(__file__).parent
raw = json.loads((root / 'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert raw['complete'] and len(raw['jobs']) == 3
rows = []
for job in raw['jobs']:
    assert job['workersJoinedAndFixturesRemoved']
    assert job['executionLanes'] == {'reference': 'warm', 'reference-control': 'warm', 'candidate': 'warm-async', 'candidate-control': 'warm-async'}
    labels = list(job['identities'])
    values = {label: [1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']
                      for s in job['samples'] if s['engine'] == label] for label in labels}
    medians = {label: statistics.median(v) for label, v in values.items()}
    cpu = {label: statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']
                                   for s in job['samples'] if s['engine'] == label) for label in labels}
    iqr = {label: 100*(statistics.quantiles(v, n=4)[2]-statistics.quantiles(v, n=4)[0])/medians[label]
           for label, v in values.items()}
    row = dict(case=job['case'], medianMilliseconds=medians, widerCpuMedianMilliseconds=cpu,
               elapsedAsyncOverSyncPercent=sorted(100*(medians[a]/medians[b]-1) for a in ['candidate','candidate-control'] for b in ['reference','reference-control']),
               widerCpuAsyncOverSyncPercent=sorted(100*(cpu[a]/cpu[b]-1) for a in ['candidate','candidate-control'] for b in ['reference','reference-control']),
               iqrPercent=iqr, syncControlPercent=100*abs(medians['reference-control']/medians['reference']-1),
               asyncControlPercent=100*abs(medians['candidate-control']/medians['candidate']-1))
    rows.append(row)
summary = dict(complete=True, jobs=3, elapsedSeconds=raw['elapsedSeconds'],
               identity=json.loads((root/'identity.json').read_text(encoding='utf-8')),
               timing=rows, runtimeChanged=False, performanceQualified=False,
               boundary='Public Run versus awaited RunAsync with completed host I/O, prior-result disposal and full goldens. Compile/startup/reset/protocol/final cache cleanup excluded from elapsed; wider CPU includes reset/protocol. No pending-I/O latency or source-pair gain claim.')
(root/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(summary, indent=2))
