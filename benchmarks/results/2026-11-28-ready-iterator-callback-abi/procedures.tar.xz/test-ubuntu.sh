#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/ready-callback-abi-b1935-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
filter='Category!=Stress&(FullyQualifiedName~NativeCallback|FullyQualifiedName~Iteration|FullyQualifiedName~Generator|FullyQualifiedName~Map|FullyQualifiedName~Itertools|FullyQualifiedName~AdmissionFailureCommandTests)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
  log="$lab/ubuntu-$suite-net11.0.log"
  ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -50 "$log"; exit 1; }
  tail -5 "$log"
done
