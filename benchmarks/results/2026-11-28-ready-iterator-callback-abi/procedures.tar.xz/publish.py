from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab / 'comparison'
output = repo / 'benchmarks/results/2026-11-28-ready-iterator-callback-abi'

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = read(bench / 'identity.json')
for part, name in [('src/Lokad.Lython', 'candidate.patch'), ('tests', 'test.patch')]:
    source = check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', part], cwd=repo)
    assert source == (lab / name).read_bytes()
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, manifest in identity['imageFiles'].items():
    assert len(manifest) == 32
    assert {path.name: digest(path) for path in (bench / role).iterdir()} == manifest
summary = read(bench / 'summary.json')
assert summary['verifiedTimedBatches'] == 112 and len(summary['rows']) == 4
receipt = read(bench / 'archive-receipt.json')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == digest(bench / 'observations.tar.xz')
alloc = read(lab / 'allocation/summary.json')
assert len(alloc) == 8 and all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in alloc)
assert max(abs(row['clr'][0] - row['clr'][1]) for row in alloc) <= 230
logs = list(lab.glob('windows-*net*.log')) + list(lab.glob('ubuntu-*net*.log'))
assert len(logs) == 6
for log in logs:
    count = 1238 if 'PublicApi' in log.name else 334
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
output.mkdir(exist_ok=True)
artifacts = {name: bench / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'archive-receipt.json')}
artifacts['allocation.json'] = lab / 'allocation/summary.json'
for name, source in artifacts.items():
    copy2(source, output / name)
    assert digest(output / name) == digest(source)
procedures = {p.name: p for p in logs}
for name in ('candidate.patch', 'test.patch', 'test-ubuntu.sh', 'freeze.py', 'summarize.py', 'measure-allocation.py', 'publish.py'):
    procedures[name] = lab / name
for name in ('collection.log', 'reference-verify.json', 'candidate-verify.json', 'exit-code.txt'):
    procedures[name] = bench / name
for path in (lab / 'allocation').glob('*.json'):
    procedures[f'allocation/{path.name}'] = path
with tarfile.open(output / 'procedures.tar.xz', 'w:xz') as archive:
    for name, source in procedures.items():
        archive.add(source, arcname=name)
with tarfile.open(output / 'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name, path in procedures.items())
print('Verified direct-ready ABI prototype evidence.')
