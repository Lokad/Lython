#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/short-borrowed-text-probe-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/short-borrowed-text-probe-20261122
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~CompleteCsvAssertionsPublishIndependentReport|FullyQualifiedName~TypedModuleCsvJobPublishesCompleteReport' > "$lab/fixture-rerun-ubuntu.log" 2>&1 || { tail -35 "$lab/fixture-rerun-ubuntu.log"; exit 1; }
tail -7 "$lab/fixture-rerun-ubuntu.log"
