from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"function-diagnostic-identity-20261122/comparison"
baseline=lab.parent/"current-cpython-refresh-20261122/comparison/quiet"
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(exist_ok=False)
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(path):return sha(path.read_bytes())
def write(path,text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,value):write(path,json.dumps(value,indent=2)+"\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def committed(folder,leaf):return git("show","origin/master:benchmarks/results/"+folder+"/"+leaf)
def verified_archive(folder):
    receipt=json.loads(committed(folder,"archive-receipt.json"))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    assert sha(committed(folder,"observations.tgz"))==receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

ident=read(out/"identity.json")
candidate=git("-C",str(repo/".git/agent-worktrees/short-borrowed-text-probe-20261122"),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("a0382d044")
patch=git("diff","--binary",ident["patchBase"],candidate,"--","src")
assert sha(patch)==ident["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
for role,manifest in ident["imageFiles"].items():
    assert len(manifest)==32 and all(h(out/("frozen-"+role)/n)==digest for n,digest in manifest.items())
    proof=read(out/(role+"-verify.json"))
    assert proof["caseCount"]==7 and proof["catalogSha256"]==ident["catalogSHA256"] and proof["state"]=="Completed"
catalog=out/"representative.json"
shutil.copyfile(catalog,quiet/"representative.json")
assert h(quiet/"representative.json")==ident["catalogSHA256"]
jobs=[tuple(row) for row in read(out/"jobs.json")]
assert len(jobs)==8 and len({id for id,_ in jobs})==7
old=read(prior/"quiet/config.json")
cfg_base=read(baseline/"config.json")
root="/home/lokad/lython-bench-checks/short-borrowed-text-probe-b1420-20261122"
unit="lython-b1420-short-borrowed-text-probe-20261122"
ident.update(sourceRevision=ident["reference"]+" versus "+candidate,candidate=candidate,testedRevision=candidate,
    purpose="Replace query hashes with bounded dense probes for short UTF-8 histogram and record keys",
    normalAdapterPin="0.4.0",
    coreSHA256={role+suffix:m[core] for role,m in ident["imageFiles"].items() for suffix in ("","-control")},
    catalogs={"representative.json":{"sha256":h(catalog)}})
assert cfg_base["identity"]["imageFiles"]["candidate"]==ident["imageFiles"]["reference"]
save(quiet/"identity.json",ident)
(quiet/"candidate").mkdir()
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(prior/"quiet"/leaf).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    code=code.replace("len(jobs)==7","len(jobs)==8").replace("len(raw['jobs'])==7","len(raw['jobs'])==8")
    code=code.replace("jobs=7,","jobs=8,").replace("['jobs']==7","['jobs']==8")
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json" for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
        code=code.replace("started < 410","started < 450")
    if leaf=="retrieve.py":code=code.replace("Function diagnostic identity","Short UTF-8 probe")
    write(quiet/leaf,code)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for leaf in parts:t.add(quiet/leaf,arcname=leaf)
folder="2026-11-22-function-diagnostic-identity"
initial_sha=verified_archive(folder)
verified_archive(folder+"/confirmation")
earlier=json.loads(committed(folder,"source.json"))
later=json.loads(committed(folder+"/confirmation","source.json"))
assert earlier["imageFiles"]==later["imageFiles"]
retire=[]
first="function-diagnostic-identity-b1417-20261122"
second="function-diagnostic-identity-b1418-20261122"
for role in ("reference","candidate"):
    data=gzip.decompress(committed(folder,role+"-core.dll.gz"))
    assert sha(data)==earlier["imageFiles"][role][core] and sha(data)!=ident["imageFiles"]["reference"][core]
    retire.append(dict(paths=[first+"/"+role+"/"+core,second+"/"+role+"/"+core],bytes=len(data),links=2,
        sha256=sha(data),archives={first+"/observations.tgz": initial_sha}))
donor=verified_archive("2026-11-22-callable-checkpoint-cpython")
cfg={**old,"root":root,"unit":unit,"identity":ident,"source":cfg_base["root"],"sourceRole":"candidate",
     "sourceFiles":ident["imageFiles"]["reference"],"sourceCatalogSHA256":cfg_base["identity"]["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":donor,"retireGroups":retire,"payloadBytes":payload.stat().st_size,
     "payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(prior/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1417-fixtures","b1420-fixtures").replace("RuntimeMaxSec=475","RuntimeMaxSec=525"))
code=(prior/"launch.py").read_text(encoding="utf-8").replace("Function diagnostic identity","Short UTF-8 probe")
write(out/"launch.py",code.replace("seconds=422","seconds=485").replace("before 422 seconds","before 485 seconds"))
code=(prior/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==7","len(raw['jobs'])==8")
write(out/"summarize.py",code)
print(candidate,root,cfg["unpackedBytes"],flush=True)
