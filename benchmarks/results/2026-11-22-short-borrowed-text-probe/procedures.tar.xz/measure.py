from pathlib import Path
import base64,collections,hashlib,importlib.util,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
up=lab.parent/"current-cpython-refresh-20261122"
old=lab.parent/"histogram-total-slots-20261122/comparison/quiet"
out=lab/"comparison"
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode("utf-8")).hexdigest()
def save(p,value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
catalog=read(up/"representative.json")
source={r["id"]:r for r in catalog["cases"]}
word="diagnostic.text-summary.nonlocal-computed-width.large"
ordinary="diagnostic.text-summary.ordinary-histogram.large"
dense="diagnostic.text-summary.dense-line"
wide="diagnostic.text-summary.nonlocal-computed-width.wide-vocabulary"
helper="scripts.ordinary-fully-supplied-helper"
invoice="scripts.csv-invoice.method-policy.quoted-control"
json_export="scripts.json-lines-shipment.expanded-options.large"
prior=read(old/"identity.json")
assert sha(old/"representative.json")==prior["catalogs"]["representative.json"]["sha256"]
more={r["id"]:r for r in read(old/"representative.json")["cases"]}
assert source[word]==more[word] and source[invoice]==more[invoice]
source.update({id:more[id] for id in (ordinary,dense,helper)})
payload="".join(f"key{i%512:04x} Alpha café\n" for i in range(3071))+"\n"
counts=collections.Counter(item for line in payload.splitlines() for item in line.lower().split())
assert len(counts)==514 and sum(counts.values())==9213
output="".join(f"{key}={counts[key]}\n" for key in sorted(counts)).encode("utf-8")
fixture=read(up/"representative.json")["cases"]
case={**source[word],"id":wide}
def b64(value):return base64.b64encode(value).decode("ascii")
files=json.loads(case["fixtureJson"])
files["inputFiles"]["input.txt"]=b64(payload.encode("utf-8"))
files["outputFiles"]["report.txt"]=b64(output)
fixture_json=json.dumps(files,ensure_ascii=False,separators=(",",":"))
protocol=repo/"benchmarks/cpython-worker.py"
mod=importlib.util.spec_from_file_location("protocol",protocol)
worker=importlib.util.module_from_spec(mod);mod.loader.exec_module(worker)
expected=f"{sum(counts.values())}\n"
case.update(fixtureJson=fixture_json,fixtureSha256=digest(fixture_json),
    expectedOutput=expected,expectedOutputSha256=digest(expected),expectedOutputUtf8Bytes=len(expected.encode("utf-8")),
    expectedFilesSha256=worker.file_digest({"report.txt":output}))
source[wide]=case
ids=[word,ordinary,dense,wide,json_export,invoice,helper]
catalog["cases"]=[source[id] for id in ids]
catalog["performanceQualified"]=False
manifest=out/"representative.json"
save(manifest,catalog)
jobs=[(word,"warm"),(word,"compile-run"),*[(id,"warm") for id in ids[1:]]]
save(out/"jobs.json",jobs)
reference=read(up/"identity.json")
image_before=up/"frozen"
assert sha(protocol)==reference["protocolSHA256"]
expected_files=reference["imageFiles"]
assert len(expected_files)==32 and {n:sha(image_before/n) for n in expected_files}==expected_files
core="Lokad.Lython.dll"
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
assert sha(candidate)!=expected_files[core]
tree=repo/".git/agent-worktrees/short-borrowed-text-probe-20261122"
current=subprocess.check_output(["git","rev-parse","HEAD"],cwd=tree,text=True).strip()
assert current.startswith("f3d8fac1e")
assert not subprocess.check_output(["git","diff",reference["sourceRevision"],current,"--","src","tests","benchmarks/Lokad.Lython.Benchmarks"],cwd=repo)
patch=subprocess.check_output(["git","diff","--binary","HEAD","--","src"],cwd=tree)
assert patch.count(b"diff --git ")==3
(out/"source.patch").write_bytes(patch)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
hashes={}
results={}
for role in ("reference","candidate"):
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    paths={name:candidate if name==core and role=="candidate" else image_before/name for name in expected_files}
    for name,path in paths.items():shutil.copyfile(path,image/name)
    files={name:sha(image/name) for name in expected_files}
    assert all(files[name]==sha(paths[name]) for name in files)
    hashes[role]=files
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/name,image/name)
    proof=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=95)
    verify=read(proof)
    assert verify["caseCount"]==len(ids) and verify["state"]=="Completed" and verify["catalogSha256"]==sha(manifest)
    report=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,manifest,report],
        env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==len(ids) and all(r["sharedBudgetBaselineRestored"] for r in rows)
    results[role]=rows
    assert {name:sha(image/name) for name in files}==files
assert [name for name in expected_files if hashes["reference"][name]!=hashes["candidate"][name]]==[core]
save(out/"identity.json",dict(reference=reference["sourceRevision"],patchBase=current,imageFiles=hashes,
    catalogSHA256=sha(manifest),protocolSHA256=sha(protocol),sourcePatchSHA256=sha(out/"source.patch")))
for a,b in zip(results["reference"],results["candidate"],strict=True):
    assert a["id"]==b["id"]
    x,y=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    print(a["id"],x,y,a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
