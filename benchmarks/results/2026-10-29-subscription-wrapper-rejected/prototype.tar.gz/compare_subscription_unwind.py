import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

base=Path('/home/lokad/lython-bench-checks')
store=base/'foundation-bed371f6'
control=base/'delivery-da0ff811'
candidate=base/'type-subscription-completed-prototype-3eb6c3b8'
patch=base/'type-subscription-completed-prototype.patch'
dotnet=Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
output=base/'type-subscription-unwind-20261029'
env=os.environ.copy()
env['DOTNET_ROOT']=str(dotnet.parent)
env['PATH']=str(dotnet.parent)+':'+env['PATH']
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    output.mkdir(exist_ok=False)
    subprocess.run(['git','worktree','add','--detach',str(candidate),'delivery-docs-3eb6c3b8'],cwd=store,check=True)
    subprocess.run(['git','apply',str(patch)],cwd=candidate,check=True)
    with (output/'build.log').open('w') as log:
        result=subprocess.run([str(dotnet),'build','Lokad.Lython.slnx','-c','Release','--tl:off','--nologo','-v','minimal'],
            cwd=candidate,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    print('candidate build',result.returncode,flush=True)
    if result.returncode: raise RuntimeError((output/'build.log').read_text())
    observations=[]
    for name,tree in [('control',control),('candidate',candidate)]:
        fixture=tree/'tests/Lokad.Lython.WorkerFixture/bin/Release/net11.0/Lokad.Lython.WorkerFixture.dll'
        library=fixture.parent/'Lokad.Lython.dll'
        for scenario in ['class-getitem','class-getitem-descriptor']:
            stem=name+'-'+scenario
            command=['sudo','-n','systemd-run','--quiet','--wait','--pipe','--collect',
                '--unit=lython-type-unwind-'+stem+'-'+str(os.getpid()),'--uid=lokad',
                '--working-directory='+str(tree),'-p','RuntimeMaxSec=25','-p','TimeoutStopSec=0',
                '-p','KillMode=control-group','--setenv=DOTNET_ROOT='+str(dotnet.parent),
                str(dotnet),str(fixture),'stack-guard',str(library),scenario]
            started=time.monotonic()
            result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=30)
            (output/(stem+'.stdout')).write_text(result.stdout)
            (output/(stem+'.stderr')).write_text(result.stderr)
            row=dict(variant=name,scenario=scenario,elapsedSeconds=time.monotonic()-started,
                exitCode=result.returncode,librarySha256=hashlib.sha256(library.read_bytes()).hexdigest())
            if result.returncode==0:
                row['result']=json.loads(result.stdout)
                assert row['result']['Success'] and row['result']['value']=='3' and row['result']['completedAsynchronously']>0
            observations.append(row)
            (output/'comparison.json').write_text(json.dumps(dict(performanceQualified=False,
                baseRevision='3eb6c3b897f5f45710475ac01e74ae536904600a',
                patchSha256=hashlib.sha256(patch.read_bytes()).hexdigest(),observations=observations),indent=2)+'\n')
            print(stem,row['exitCode'],round(row['elapsedSeconds'],3),flush=True)
    print('One unchanged-fixture comparison complete; lease released.',flush=True)
