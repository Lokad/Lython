from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
image = lab / 'reference'
image.mkdir(exist_ok=False)
probe = repo / 'tools/LythonProbe/bin/Release/net11.0'
core = lab.parent / 'frontend-dispatch-r527/frozen/candidate/Lokad.Lython.dll'
expected = '2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226'
assert hashlib.sha256(core.read_bytes()).hexdigest() == expected
for source in probe.glob('*'):
    if source.is_file():
        shutil.copyfile(core if source.name == core.name else source, image / source.name)
manifest = {item.name: hashlib.sha256(item.read_bytes()).hexdigest() for item in sorted(image.iterdir())}
(lab / 'reference-image.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')

cases = {
    'decimal-separators': 'print(1_000_000, 0_0, .25, 2_0.5, 1e+02, 1_2j)',
    'radix-literals': 'print(0x_FF, 0o_17, 0b_101, 0X0, 0O0, 0B0)',
    'big-integer': 'print(18_446_744_073_709_551_616, 0x10000000000000000)',
    'overflow-underflow': 'print(1e999, 1e-999, -0.0, -0j, 1e999j)',
    'matches': 'for val in (0, 7, 1.5, 2j):\n    match val:\n        case 0x00: print("zero")\n        case 0b111: print("seven")\n        case 1.50: print("one and a half")\n        case 2.0j: print("imaginary")',
    'postponed-annotations': 'from __future__ import annotations\ndef f(x: tuple[0x10, 1_000, 1e+2, 1.0j]):\n    return x\nprint(f.__annotations__)',
    'class-and-defaults': 'class Values:\n    real = 1.25\n    imag = 2.5j\n    integer = 0x10000000000000000\n    def decimal(self, value=2_5.5):\n        return value\nprint(Values.real, Values.imag, Values.integer, Values().decimal())',
    'mixed-key-equality': 'data = {1: "first", 1.0: "second", True: "final"}\nprint(len(data), data[0x1], data[1e0])',
    'decimal-key': 'd = {1_0: "present"}\nprint(d[10])',
    'radix-key': 'd = {0xA: "present"}\nprint(d[10])',
    'mixed-numeric-join': 'def choose(flag):\n    if flag:\n        x = 0xA\n    else:\n        x = 10\n    return x\nprint(choose(True), choose(False))',
    'known-empty-range': 'for i in range(0_0):\n    print(i)\nprint("done")',
    'flags-folding': 'import re\nprint(re.search("a", "A", re.I | 0_0).group())',
    'flags-radix': 'import re\nprint(re.search("a", "A", 0x2).group())',
    'unpacked-byte-facts': 'print([*b"ab"][1])',
    'duplicate-index-fact': 'a = [1, 2]\nprint(a[1_0])',
    'hex-index-fact': 'a = [1, 2]\nprint(a[0xA])',
    'wrong-numeric-argument': 'import math\nprint(math.isclose(1, 2, rel_tol="bad"))',
    'separator-invalid': 'print(1__0)',
    'trailing-separator': 'print(1_)',
    'leading-zero': 'print(01)',
    'empty-radix': 'print(0x)',
    'radix-digit': 'print(0b102)',
    'ambiguous-imaginary': 'print(1jx)',
    'incomplete-exponent': 'print(1e+)',
    'syntax-before-literal': 'if :\n    print(0x10000000000000000)',
}
(lab / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n', encoding='utf-8')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
for mode in ('sync', 'async'):
    command = [str(dotnet), str(image / 'LythonProbe.dll'), '--batch-json']
    if mode == 'async':
        command.append('--async')
    proc = subprocess.run(command, input=json.dumps(list(cases.values())), encoding='utf-8',
                          capture_output=True, env=env, timeout=60)
    (lab / (mode + '-reference.jsonl')).write_text(proc.stdout, encoding='utf-8')
    assert proc.returncode == 1 and not proc.stderr, proc.stderr
    rows = [json.loads(line) for line in proc.stdout.splitlines()]
    assert len(rows) == len(cases) and all(isinstance(row, dict) for row in rows)
    print(mode, len(rows), 'public probe outcomes recorded with qualified core')
