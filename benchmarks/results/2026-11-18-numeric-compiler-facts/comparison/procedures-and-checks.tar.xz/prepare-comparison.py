from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/prepared-names-r525'
previous = lab.parent / 'frontend-dispatch-r527'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

checks = read(lab / 'focused-checks.json')
assert len(checks) == 4 and all(row['exitCode'] == 0 for row in checks)
candidate_expected = read(lab / 'comparison.json')[0]['imageFiles']['Lokad.Lython.dll']
candidate = work / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(candidate) == candidate_expected
assert sha(work / 'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll') == candidate_expected
images = {}
source_hashes = read(previous / 'frozen/identity.json')['imageFiles']['candidate']
assert len(source_hashes) == 32 and source_hashes[candidate.name].startswith('2c6b304b')
for role, core in [('reference', previous / 'frozen/candidate/Lokad.Lython.dll'), ('candidate', candidate)]:
    folder = lab / 'frozen' / role
    folder.mkdir(parents=True, exist_ok=False)
    for name, digest in source_hashes.items():
        source = previous / 'frozen/candidate' / name
        assert sha(source) == digest, name
        shutil.copyfile(core if name == core.name else source, folder / name)
    images[role] = {name: sha(folder / name) for name in source_hashes}
    for tool in (previous / 'frozen/candidate').glob('ValidatedAllocation.*'):
        shutil.copyfile(tool, folder / tool.name)
assert images['reference'] == source_hashes
assert images['candidate'] == source_hashes | {candidate.name: candidate_expected}

all_cases = read(previous / 'catalog.json')
config = read(repo / 'benchmarks/results/2026-11-01-fresh-config-attribution/catalog.json')
case_ids = {'scripts.csv-invoice.large', 'scripts.report-render.large', 'scripts.config-edit.small', 'scripts.text-normalization.helper-list'}
cases = [case for case in all_cases['cases'] + config['cases'] if case['id'] in case_ids]
assert {case['id'] for case in cases} == case_ids
catalog = lab / 'representative.json'
write(catalog, all_cases | {'cases': cases})
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']

def run(label, *args):
    with (lab / (label + '.log')).open('w', encoding='utf-8') as log:
        subprocess.run([str(dotnet), *map(str, args)], cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
    print(label, 'passed', flush=True)

# Reuse the previous current-thread Compile-and-dispose allocation driver.
# The catalog selects the cases here instead of a fixed list embedded in it.
project = lab / 'compile-allocation'
project.mkdir()
for name in ('Program.cs', 'compile-allocation.csproj'):
    shutil.copyfile(previous / 'compile-allocation' / name, project / name)
program = project / 'Program.cs'
source = program.read_text(encoding='utf-8')
start = source.index('    if (id is not ')
end = source.index('    var source = ', start)
program.write_text(source[:start] + source[end:], encoding='utf-8')
run('compile-allocation-build', 'build', project / 'compile-allocation.csproj', '-c', 'Release',
    '-p:InspectionCorePath=' + str(lab / 'frozen/reference/Lokad.Lython.dll'))

for role, hashes in images.items():
    folder = lab / 'frozen' / role
    for label, path in [('goldens', previous / 'catalog.json'), ('measurement', catalog)]:
        run(role + '-' + label, folder / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', path,
            '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', repo / 'benchmarks/cpython-worker.py',
            '--out', lab / (role + '-' + label + '.json'))
    run(role + '-allocation', folder / 'ValidatedAllocation.dll', folder, previous / 'catalog.json', lab / (role + '-allocation.json'))
    driver = lab / ('compile-' + role)
    shutil.copytree(project / 'bin/Release/net11.0', driver)
    shutil.copyfile(folder / 'Lokad.Lython.dll', driver / 'Lokad.Lython.dll')
    report = lab / (role + '-compile-allocation.json')
    run(role + '-compile-allocation', driver / 'compile-allocation.dll', catalog, report)
    values = read(report)
    assert values['coreSha256'] == hashes[candidate.name]
    assert len(values['rows']) == 4 and all(row['allowanceBaselineRestored'] for row in values['rows'])
    assert all(sha(folder / name) == digest for name, digest in hashes.items())
write(lab / 'frozen-identity.json', dict(
    sourceRevision='Qualified 925397f65 / 2c6b304b and private shared numeric compiler facts',
    purpose='Compare compile and compile-to-result for config edit, CSV invoice and report workloads with warm text control.',
    imageFiles=images, catalogSHA256=sha(catalog),
    coreSHA256={name: images[role][candidate.name] for role in images for name in (role, role + '-control')},
    normalAdapterPin='0.4.0', publicationHeld=True))
