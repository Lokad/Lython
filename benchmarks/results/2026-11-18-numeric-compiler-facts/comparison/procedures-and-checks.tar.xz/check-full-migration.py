from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
work = Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
checks = {
    'Lokad.Lython.Tests': ['Static', 'Abstract', 'ParserCancellation', 'PostponedAnnotation', 'CallBindingSubsystem', 'ExecutableLocalImportBinding'],
    'Lokad.Lython.PublicApi.Tests': [
        'StaticErrorDiagnostics', 'StaticRuntimeArityAgreement', 'Diagnostic', 'ScopeDirective',
        'ShortCircuit', 'ComprehensionEffect', 'SharedCompilerFact', 'CompilerCancellation',
        'GovernedMemoryContract', 'MemoryDenialAttribution', 'ClassAnnotationExecution',
        'RegexAnalysisBinding', 'AnnotationCompatibility', 'ParserCompatibility', 'FloatArithmeticPipeline',
        'Complex', 'PostponedAnnotation', 'ClassMethod', 'PatternMatching', 'LocalImport',
    ],
}
rows = []
for target in ('net11.0', 'net10.0'):
    for project, classes in checks.items():
        filter_expression = '(' + '|'.join('FullyQualifiedName~' + name for name in classes) + ')&Category!=Stress'
        command = [str(dotnet), 'test', f'tests/{project}/{project}.csproj', '-c', 'Release', '-f', target,
                   '--filter', filter_expression, '--nologo']
        if project == 'Lokad.Lython.Tests':
            command.append('--no-build')
        result = subprocess.run(command, cwd=work, text=True, encoding='utf-8', errors='replace',
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, timeout=180)
        log = lab / f'{project}-{target}.log'
        log.write_text(result.stdout, encoding='utf-8')
        print(target, project, result.stdout.splitlines()[-1], flush=True)
        rows.append(dict(framework=target, project=project, filter=filter_expression, exitCode=result.returncode,
                         summary=result.stdout.splitlines()[-1], log=log.name))
        (lab / 'focused-checks.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
        assert result.returncode == 0, result.stdout[-7000:]
