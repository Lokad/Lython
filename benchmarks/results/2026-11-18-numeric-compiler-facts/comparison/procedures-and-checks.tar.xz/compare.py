from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
work = Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
cases = json.loads((lab / 'cases.json').read_text(encoding='utf-8'))
records = []
for framework in ('net11.0', 'net10.0'):
    image = work / 'tools/LythonProbe/bin/Release' / framework
    hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in image.iterdir() if path.is_file()}
    for mode in ('sync', 'async'):
        reference = [json.loads(line) for line in (lab / (mode + '-reference.jsonl')).read_text(encoding='utf-8').splitlines()]
        command = [str(dotnet), str(image / 'LythonProbe.dll'), '--batch-json']
        if mode == 'async':
            command.append('--async')
        proc = subprocess.run(command, input=json.dumps(list(cases.values())), encoding='utf-8', capture_output=True, env=env, timeout=60)
        (lab / f'{framework}-{mode}-candidate.jsonl').write_text(proc.stdout, encoding='utf-8')
        assert proc.returncode == 1 and not proc.stderr, proc.stderr
        candidate = [json.loads(line) for line in proc.stdout.splitlines()]
        assert len(candidate) == len(reference) == len(cases)
        different = [name for name, left, right in zip(cases, reference, candidate) if left != right]
        records.append(dict(framework=framework, mode=mode, cases=len(cases), different=different, imageFiles=hashes))
        print(framework, mode, 'differences', different, flush=True)
(lab / 'comparison.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
assert not any(row['different'] for row in records)
