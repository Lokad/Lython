from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
prior = lab.parent / 'result-transport-r531'
results = repo / 'benchmarks/results'
source = results / '2026-11-18-result-transport/comparison'
remote_root = 'result-transport-b961-20261118'
choices = []
for archive_path, path, member in (
    (source / 'candidate-core.dll.gz', remote_root + '/candidate/Lokad.Lython.dll', 'gzip-payload'),
    (source / 'observations.tgz', remote_root + '/confirmation/confirmation.json', 'confirmation/confirmation.json'),
    (results / '2026-11-18-native-call-body/corrected/observations.tgz',
     'call-body-b960-20261118/observations.tgz', 'whole-file'),
):
    canonical = archive_path.relative_to(repo).as_posix()
    archive_bytes = (repo / canonical).read_bytes()
    assert archive_bytes == subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    if member == 'gzip-payload':
        value = gzip.decompress(archive_bytes)
        assert hashlib.sha256(value).hexdigest().startswith('76555c49')
    elif member == 'whole-file':
        value = archive_bytes
    else:
        with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
            value = archive.extractfile(member).read()
    choices.append(dict(kind='archived withdrawn-prototype working replica', canonical=canonical,
                        canonicalSHA256=hashlib.sha256(archive_bytes).hexdigest(), member=member,
                        sha256=hashlib.sha256(value).hexdigest(), bytes=len(value), paths=[path],
                        links=1, committedBlobVerified=True))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
read_state = '''from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
root = Path('/home/lokad/lython-bench-checks').resolve()
choices = CHOICES
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for group in choices:
        path = root / group['paths'][0]
        st = path.lstat()
        assert path.resolve() == path and stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid()
        assert st.st_size == group['bytes'] and st.st_nlink == group['links']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == group['sha256']
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=choices)))
'''.replace('CHOICES', repr(choices))
state = subprocess.run(ssh + ['python3 -'], input=read_state, text=True, encoding='utf-8',
                       capture_output=True, timeout=30, check=True).stdout
(lab / 'space.json').write_text(state, encoding='utf-8')

# Adapt the existing timed source-pair launcher and retain its custody gates.
stage = (prior / 'stage.py').read_text(encoding='utf-8')
start, end = stage.index("jobs = [('scripts.text-"), stage.index('collect =')
jobs = [
    ('scripts.config-edit.small', 'compile'),
    ('scripts.config-edit.small', 'compile-run'),
    ('scripts.csv-invoice.large', 'compile'),
    ('scripts.csv-invoice.large', 'compile-run'),
    ('scripts.report-render.large', 'compile'),
    ('scripts.text-normalization.helper-list', 'warm'),
]
stage = stage[:start] + 'jobs = ' + repr(jobs) + '\n' + stage[end:]
stage = stage.replace('result-transport-b961-20261118', 'numeric-compiler-b962-20261118').replace('lython-b961', 'lython-b962')
stage = stage.replace("'len(jobs)==5'", "'len(jobs)==6'").replace('"len(raw[\'jobs\'])==5"', '"len(raw[\'jobs\'])==6"')
stage = stage.replace("'jobs=5,elapsedSeconds'", "'jobs=6,elapsedSeconds'").replace('"[\'jobs\']==5"', '"[\'jobs\']==6"')
stage = stage.replace("'RuntimeMaxSec=330'", "'RuntimeMaxSec=400'").replace('seconds=255', 'seconds=315').replace('before255seconds', 'before315seconds')
stage = stage.replace('Result transport', 'Shared numeric facts').replace('result transport source pair', 'shared numeric facts source pair')
ast.parse(stage)
(lab / 'stage.py').write_text(stage, encoding='utf-8', newline='\n')
staged = lab / 'quiet'
if staged.is_dir() and not (staged / 'config.json').exists():
    assert staged.resolve() == lab / 'quiet'
    staged.rename(lab / 'staging-floor-refusal')
exec(compile(stage, str(lab / 'stage.py'), 'exec'), {'__file__': str(lab / 'stage.py')})
