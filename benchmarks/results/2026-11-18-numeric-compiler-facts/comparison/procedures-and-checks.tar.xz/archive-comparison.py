from pathlib import Path
import gzip
import hashlib
import json
import shutil
import statistics
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/prepared-names-r525'
out = repo / 'benchmarks/results/2026-11-18-numeric-compiler-facts/comparison'
out.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
quiet = lab / 'quiet'
receipt = read(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['jobs'] == 6 and not (out / 'observations.tgz').exists()
assert sha(quiet / 'observations.tgz') == receipt['archiveSHA256']
for name in ('archive-receipt.json', 'observations.tgz', 'terminal-status.json'):
    shutil.copyfile(quiet / name, out / name)
for name in ('summary.json', 'allocation-summary.json', 'frozen-identity.json', 'focused-checks.json'):
    shutil.copyfile(lab / name, out / name)
subprocess.run(['git', 'add', '-N', '--', 'src/Lokad.Lython/Frontend/Parser.NumericLiterals.cs'], cwd=work, check=True)
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=work)
(out / 'candidate.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
candidate = lab / 'frozen/candidate/Lokad.Lython.dll'
assert sha(candidate) == read(lab / 'frozen-identity.json')['coreSHA256']['candidate']
(out / 'candidate-core.dll.gz').write_bytes(gzip.compress(candidate.read_bytes(), mtime=0))

reference, trial = [read(lab / (name + '-compile-allocation.json'))['rows'] for name in ('reference', 'candidate')]
assert len(reference) == len(trial) == 4
rows = []
for left, right in zip(reference, trial):
    assert left['id'] == right['id'] and left['allowanceBaselineRestored'] and right['allowanceBaselineRestored']
    a = statistics.median(left['allocatedBytesPerCompilation'])
    b = statistics.median(right['allocatedBytesPerCompilation'])
    rows.append(dict(case=left['id'], referenceBytes=a, candidateBytes=b, changeBytes=b-a))
(out / 'compile-allocation-summary.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')

names = ['prepare-comparison.py', 'stage-comparison.py', 'stage.py', 'launch.py', 'summarize.py', 'archive-comparison.py',
         'comparison.json', 'cases.json', 'compare.py', 'check-full-migration.py', 'focused-checks.json',
         'compile-allocation/Program.cs', 'compile-allocation/compile-allocation.csproj',
         'quiet/config.json', 'quiet/collect.py', 'quiet/archive-owned.py', 'quiet/run.sh',
         'quiet/remote-launch.py', 'quiet/retrieve.py', 'quiet/launch.log', 'representative.json']
names.extend(path.name for path in lab.glob('Lokad.Lython.*.log'))
names.extend(path.name for path in lab.glob('*-candidate.jsonl'))
for role in ('reference', 'candidate'):
    names.extend(f'{role}-{suffix}.json' for suffix in ('goldens', 'measurement', 'allocation', 'compile-allocation'))
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for name in names:
        archive.add(lab / name, arcname=name)
print('Verified comparison archive', receipt['archiveSHA256'])
