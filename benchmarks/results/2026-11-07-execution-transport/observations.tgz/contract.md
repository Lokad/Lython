# B377 current-source execution attribution

One existing complete text/helper script, frozen R269e1dbc38/current production
source. Same b94fa98c worker/host/optional0.4 provider, ordinary GC/tiering.
DOTNET_PerfMapEnabled3 and selected JIT disassembly only. Six-second warmup,
two-second settling, one6s complete-checked-job capture,199Hz cpu-clock/fp.
No throughput, CPython or causal speedup claim. Retain all threads/unknowns.
The same process emits generated code; match unique Tier1 map size/address range.
Classify basic blocks manually with raw code/sample offsets retained; necessary
inlined work is not removable dispatch. Stop this bounded attribution if mapping
cannot be proved; no broad campaign. Preserve source/quiet/goldens/funding/Closed,
joined workers, fixtures and verified persistent archive under the exclusive lease.
RuntimeMax120s+stop30s+margin30s: no observation before180s from acknowledged launch.
No source/build or policy change, new allowance, runtime counters or new harness.
