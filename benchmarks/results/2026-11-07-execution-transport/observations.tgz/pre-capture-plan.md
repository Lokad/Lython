# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent design simplification and substantial complete-script
performance. An isolated experiment/checkpoint does not finish it.

## Actual delivery

- Fully qualifiedc4729a9f R26: GREEN42324522730/all eight Windows/Ubuntu ordinary
  actual.NET11/10, original Stress and installed-package gates.01aedc3b R25,
  ec134e8c R23 and41c25958 R22 likewise fully qualified. Terminal receipts cached
  under their benchmark evidence; never query them or repeat unchanged checks.
- Committed/pushed14366ac7: B373 representative CPython refresh on exact01aedc3b
  source/frozen0933d540, all15jobs/312s/goldens/quiet/funding/joins/archive pass.
  Primary docs/BENCHMARKS.md measures this source, before R26. Compile44–72us is
  separate; warm text1.81–1.83x, CSV1.20–1.22x, JSON1.08x CPython. Fresh JSON/
  report/config vary. Includes mediated RAM I/O/checks/prior-result cleanup;
  excludes startup/staging/reset/final teardown. No subtraction of medians.
- Committed/pushed R27 source/JIT/allocation gates; they repeat no R26 qualification.
  R28 owned split-result payloads are withdrawn after two controlled captures.
  Allocation−6.94% is established; text elapsed inconclusive, report consistently
  adverse. Both runtime variants are removed; useful Unicode regressions remain.
  Restored source passes a nonincremental Release build and16internal/1public
  affected checks per actual target. Full R26 delivery stays valid; prototype
  focused951/2557 and package successes are not production qualification.
- Open: whole-script text gap/possible R20/R26 debt, mixed CSV coarse CPU,
  startup, genuinely suspended-I/O latency, heap/RSS/embedding tails and affected
  final adapter capabilities. R26 allocation flat; adverse timing is not parity.

Current guides belong in docs/. History/raw evidence stays under benchmarks/results/
and benchmarks/EXPERIMENTS.md; detailed plans/source gates also survive under
.git/agent-notes/review-20261031/. Do not repeat qualification to refresh its date.

## Completed milestones / evidence decisions

Preserve shared compiler-fact correction, direct UTF8 formatting/storage, final
call/local slots, executable imports/lambdas, genuine suspension, fixed builtin
metadata and reusable sync/async startup workers. Worker release on actual I/O
already exists. Keep K01/F02–F05/Q01/Q02/R02–R14 and delivered ownership/protection
simplifications; do not propose them as missing.

| Milestone | Established outcome | Remaining limits / evidence |
| --- | --- | --- |
| Native helper returns | Allocation−19.92/−19.31%; delivered | Elapsed diagnostic. Do not transfer percentages to HEAD. |
| UTF8 formatting | Allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms unexplained/preserved; completed question, no unchanged retiming scheduled without new evidence. |
| R20 record layout | Canonical shared keys/independent values, no coupled entries/sorted JSON hint/set values. JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8% | CSV modest/mixed CPU. Text confirmation−1.21% to+5.53%: possible regression accepted debt, not parity. Fully delivered; record-layout evidence retains every failure/adverse condition. |
| R21 frame resume | Delete per-instruction pending-error/return polling; preserve guards/spans/cleanup | Allocation flat, modest warm text; unchanged compile also moves. Fully delivered; no general CPU gain or closure of R20 debt. |
| R22 builtin setup | Fixed functions/signatures prepared once; per-run mutable type/exception/namespace isolation. Factory−2,688B | Whole scripts mostly<0.2%allocation, config~1.17%. Config warm−1.13–2.44%, fresh−1.43% to+0.13%. Fully delivered; text controls variable. |
| U04 capture ownership | Caller spans/retained ranges replace carriers/arrays. Direct cursor allocation−20.34%; complete extraction warm−3.62–5.17%/fresh−4.58–6.40% | Fully delivered; distinct from R23, no backend CPU attribution. |
| R23 validated programs | Eliminate duplicate frontend/runtime provider compilation; native UTF8 request keys, per-run wrappers/names/purge/current tokens | B36989s extraction warm−8.34–9.64%, fresh−6.47–6.53%. Probe compiled funding39,397→105,481B until script disposal: explicit retention/earlier-denial tradeoff. Fully delivered; moving controls limit CPU attribution. |
| R25 CSV values | Transfer final funded arrays for exact header identities; no second values allocation/per-field publication on that path | Allocation−7.31/−6.55%sync/async. B372109s native warm−7.72–8.04%, ordinary warm−4.13–4.78%; text spread2.52%, coarse CPU mixed. Fully delivered. |

R25 revisits earlier6–8% bulk CSV rejection through a different completed-array
transfer model enabled by shared keys, not automatic promotion of the old design.
Header revalidation, original headroom, retained Clear capacity and corrected
test assumptions remain documented. R26 fixes demonstrated InvalidCastException
after admission changes a later receiver, deletes full native formatted proof/
evaluation and keeps real async cleanup funded. Primitive native returns remain.
Its retained possible ~3% async/text debt needs a decision at the next coherent
execution delivery. Both milestones' original failed/adverse conditions survive.

## Priority 1 — R29 canonical execution transport

Hypothesis: redundant operand publication, frame transitions and instruction
transport account for a material part of the remaining complete-script text gap.
R24's21% prefix share includes useful inlined work; calls/binding~2% and integer
addition~3% alone do not justify an arena or universal scalar rewrite. Current
source already forwards safe leaf reads and result stores, borrows final argument
storage, defers contexts and has real frameless native helper execution. Preserve
these delivered mechanisms; do not propose them as missing.

First resolve the concrete attribution gap: one current-source Linux text capture
with the existing checked worker/perf protocol and matching generated Tier1 prefix
code from that same process. Map samples to cancellation/refusal checks, reads,
publication/retirement, call transitions, control dispatch and useful inlined work.
No runtime counters, new harness, changed guest source or normal-clock speedup
claim. Preserve all threads/unknowns/tiering/profiling effects and raw addresses.
Bound one short window plus controlled warmup/cleanup under the existing lease;
do not expand into a general profiling campaign. If exact mapping is unavailable,
state which claims remain unsupported and choose the next source-backed deletion.

Then select one canonical representation milestone, not another peephole series:
eliminate a proved redundant operand/frame phase across the affected consumers,
and remove its old transport/forwarding/continuation implementation. Before code,
write the producer/use/retirement invariant and list displaced methods. Evaluate
complete text, CSV, JSON and report scripts. Keep contiguous dynamic argument and
aggregate packets where semantics require actual snapshots; do not reread mutable
receivers after admission or callbacks. No second dispatcher, hint table, dormant
backend or new execution option. A wider compiler rewrite needs evidence and an
explicit completion boundary, not automatic expansion from an aggregate sample.

Acceptance: original read/error/effect order and spans, dynamic overflow without
replay, closures/cells, exception cleanup, actual async suspension and original
evaluation order. Cancellation remains effective during nonallocating loops;
first admission refusal remains terminal. Keep retained operands and pending
borrows funded through awaited cleanup. Focused actual-target checks first, then
existing exact allocation diagnostics and a bounded quiet-VM source pair with
unchanged controls. At delivery decide every remaining regression debt, including
R26's possible~3% text/async debt; do not label uncertainty as parity. Batch full
platform/original Stress/installed consumers only at that runtime boundary.

## R28 decision and retained evidence

Newly owned multiword payloads fit the existing56B string layout after removing
the hash-cache flag. Both actual runtimes pass focused951internal/2557public
checks; exact text allocation−6.94%/bothAPIs, same admitted peaks after correcting
the initial+65,536B header overcharge. General slices/file-input windows never
share refundable storage. No owner ledger/tracing/refcounts were introduced.

B375129s/all gates: text sync−0.32–0.17%, async+1.08–7.59%/6.05%identical-role
spread; report/JSON adverse. B376168s/all gates uses two baseline/two mask-refined
processes. Text straddles baseline; report sync+1.63–4.97%, async+0.91–2.53%.
Withdraw both representations: allocation benefit does not justify universal byte
access work/ownership complexity and this regression debt. No permanent design
ban or CPU claim. Independent Unicode tests remain. History/raw/gates/source and
exact withdrawn images: benchmarks/results/2026-11-07-owned-split-storage/.

No duplicate qualification of the restored R26 runtime. R28's initial assertion
failures, overcharge, adverse elapsed, disk-preflight refusal and correction remain
visible. Retired expanded B205 VM images have independent committed/pushed backup
52a16c83 plus fresh hash/user/link checks; binary bits/raw evidence are retained.

## R27 completed source gate / broader roadmap

Current mixed-prefix21% leaf share includes necessary inlined work. Calls~2% and
integer addition~3% do not establish dominant removable costs. Windows Tier1
inspection10,091B/3,000 checked text jobs is not Linux perf attribution. Reused
D36 allocation collector:1024 checked text/report jobs each,15,873/26,720ticks,
zero lost; all goldens/Closed/joins/fixtures pass. Includes request reset/I/O/
validation/cleanup. Sampling is neither exact per-type allocation nor CPU cost.
Report54.8%Byte[] includes host/reset/output capacity; do not call it all avoidable.

| Area | Existing evidence / hypothesis | Selected work and displaced implementation | Acceptance / decision |
| --- | --- | --- | --- |
| Complete call/frame construction | R24 ordinary binding/calls~2%; native proofs/evaluation~16% report before R26, only~3.5% text | R26 closes duplicated formatted-body execution. Assess remaining whole-call ownership/argument/frame transitions before any replacement. Do not revive slower B61/B69 arenas/control. | Same defaults/keywords/receivers/locals/closures, evaluation order, error frames, actual suspension, cancellation and funded aliases. Proceed only for demonstrated remaining work. |
| Operand transport | Prefix~21% text includes inlined useful work; pure-dispatch fraction unproven | Inspect current fixed-slot instructions and read/publication/retirement together. A coherent representation may eliminate redundant transport and its old paths; no narrow fusion/hint series or new dispatcher alongside old. | Original read/error/effect order, dynamic promotion without replay, source spans, local cells, temporary disposal and admission. Stop before a runtime prototype if safe producer/use ownership needs a wider compiler rewrite unsupported by evidence. |
| Per-record construction | R20/R25 eliminate shared-key duplication and final CSV values copy | Delivered. Remaining report JSON~10% samples includes needed parsing; select another construction change only with concrete intermediate storage to delete. | Mutation/order/protocols, short/rest records, retained results and replacement peaks; no parser-specific second dictionary. |
| Remaining text conversion/storage | Text split/casing/lookup costs visible; casing and split final UTF8 output already direct | Inspect current final representation, not revive slower shared windows (+8B/string) or per-character CLR conversion already removed. No speculative pooling/cache layer. | Python Unicode expansion/context, identity/captured operands, all public formats, cancellation and capacity admission. |
| Repeated frontend analysis | Compile44–72us vs CPython35–60us; lexical facts already shared | Consolidate only a demonstrated duplicate walk/retained representation; use comprehension/helper compile-to-result controls. Main text warm gap remains independent. | Existing shared-fact correction, scoping/class cells/annotations and Python diagnostics; eliminate displaced collector/walk, not another cache. |

R28 is withdrawn; select R29's measured representation work next. Preserve slower B61/B69 arena/
call-control lessons and R24 unknowns/export/prelaunch/observer-delay deviation.
No broad dispatcher/scalar rewrite or native-wrapper prototype follows merely
from aggregate prefix samples. Evidence2026-11-07-execution-source-gate retains
all raw/source/failed staging conditions; no duplicate qualification scheduled.

## Independent regex track

Core Python semantics/native UTF8/byte ranges/scalar original windows, captures/
replacements/errors, ownership and current cancellation keep advancing without a
producer release. U04/R23 delivered. Normal adapter pin0.4/nonpackable; core has
zero backend dependency/type edges. Dev46 immutable source6957b35a compatibility
passed85internal/482public per actual target, same U04 bridge as44; evidence
2026-11-06-regex-dev46-compatibility. No production promotion/requalification replay.

Only affected final adapter qualification waits for missing producer capabilities:
DetailedData lacks independent Prepare working owner (conservative preflight);
native names cannot be enumerated (adapter-local conversion); native cursors mix
creation/per-operation tokens (qualified CTS bridge already provides current-token
semantics; removal is simplification, not a core blocker). Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges support
testing; qualify final released immutable package/managed safety separately.
No sibling edits, silent dialect fallback or work/time quotas.

## Working contract

Timeouts/unstable controls/inconclusive results establish uncertainty, not failed
design. Bounded confirmation/refinement/measurement correction is allowed when
justified; preserve original failed conditions/adverse data. Percentages inform
decisions, not automatic vetoes or permanent closures. Separate architecture,
allocation, elapsed and demonstrated CPU. Temporary debt needs a completion
milestone and decision on remaining regression, not indefinite acceptance.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/
native probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host cancellation, shared allowance/capacity/replacement/escaping aliases
and awaited cleanup. First admission refusal fails the command; never retry.
No fuel/quotas/hidden caps/default allowance/tracing/weak reclamation/forced GC.
Initial streaming uses bounded host executions; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch actual11/10/Windows/Ubuntu/original
Stress/installed consumers at coherent boundaries; no repeated terminal CI probes.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: exclusive owned lease,
Ready hashes, controls/quiet/goldens/funding/joins and verified persistent archives.
Observe only after owner+stop+margin; record conservative UTC bound after launch.
Disk near full: retire only exact redundant expanded files after independent
committed backup and all user/dependency checks. Keep raw evidence. Continue
after individual experiments/checkpoints; publication and tagging stay postponed.
