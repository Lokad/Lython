from pathlib import Path
home=Path(__file__).parent
source=(home.parent/'native-single-pass-r26/package-check.py').read_text(encoding='utf-8')
exec(compile(source,str(home/'package-check.py'),'exec'),{'__file__':str(home/'package-check.py')})
