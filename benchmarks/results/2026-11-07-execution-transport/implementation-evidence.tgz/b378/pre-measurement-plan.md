# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvement.
Finishing an experiment does not finish that objective.

## Delivery status

- **Fully qualified:** R26 `c4729a9f`, terminal GREEN42324522730/all eight Windows/
  Ubuntu, actual .NET11/10, original Stress and installed-package gates. R25
  `01aedc3b`, R23 `ec134e8c` and R22 `41c25958` likewise fully qualified. Cached
  receipts live with their evidence; never query terminal runs or repeat unchanged
  qualification. Preserve the shared compiler-fact correction, direct UTF-8
  formatting/storage and native helper returns, including their correctness fixes.
- **Committed/pushed:** `14366ac7` records B373's representative CPython refresh
  on exact R25 source/frozen0933d540. All15 jobs/goldens/funding/quiet/joins/archive
  pass in312s. docs/BENCHMARKS.md accurately identifies that source, before R26.
  `58441811` records R26 delivery/R27 source gates. `3b7512d8` records R28 withdrawal
  and retained Unicode regressions. These are not new runtime qualifications.
- **Withdrawn:** R28 owned split-result windows and its mask refinement. Text
  allocation−6.94%/both APIs is established; text elapsed inconclusive, report
  consistently adverse. Both runtime variants are removed. Restored R26 source
  passes a nonincremental Release build and16 internal/one public affected checks
  per actual target. Prototype951/2557 focused/package successes are not delivery.
- **Active:** R29 completed-helper call dispatch. B377 attribution passes all
  gates:1,095 guest samples/233 prefix samples map uniquely to current Tier1 code.
  It makes no speedup claim; raw evidence is retained. No producer/API blocker.

## Established results / unresolved measurements

| Milestone | Established | Remaining qualification or uncertainty |
| --- | --- | --- |
| Shared compiler facts | Eliminates exponential traversal of shared inferred values; mutable aliases/diagnostics/cancellation preserved | Not a warm-execution result; keep corrected callback traversal too. |
| Native helper returns | Allocation−19.92/−19.31%; qualified | Historical elapsed improvements are diagnostic, not established CPU gains or percentages transferable to HEAD. |
| Direct UTF-8 formatting | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms remains unexplained/preserved; reopen only for justified correction/refinement, not unchanged date-refresh retiming. |
| R20 shared record layout | JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8%; qualified | CSV coarse CPU mixed. Text−1.21 to+5.53% is accepted possible debt, not parity. |
| R21/R22 execution/setup | Shared resume path removes per-instruction pending return/error polling; immutable builtin metadata; factory−2,688B; qualified | Whole-script R22 allocation mostly<0.2%, config~1.17%; clocks/control movement prevent broad CPU attribution. |
| U04/R23 regex ownership/programs | Capture carriers removed; duplicate frontend/runtime compilation removed; qualified | U04 direct allocation−20.34%; R23 extraction warm−8.34–9.64%, fresh−6.47–6.53%. Earlier denial: compiled funding39,397→105,481B until script disposal. |
| R25 CSV values | Final funded row-array transfer removes second values array/per-field publication for exact unchanged native headers; qualified | Allocation−7.31/−6.55%; B372 ordinary warm−4.13–4.78%, native−7.72–8.04%; controls/coarse CPU limit attribution. |
| R26 canonical formatting | Corrects stale native proof/InvalidCastException after admission changes a receiver; removes duplicate formatted-body execution; qualified | Allocation flat; possible~3% async/text elapsed debt remains for the next coherent execution delivery. |

B373 separates compile-only44–72µs from warm execution: text1.81–1.83×, CSV
1.20–1.22×, JSON~1.08× CPython. Fresh JSON/report/config vary. Boundary includes
mediated RAM I/O, complete checks and prior-result cleanup; excludes startup,
staging/reset and final teardown. No subtraction of medians. Refresh this primary
comparison at the next meaningful runtime delivery, not after each local edit.
Startup, genuinely suspended-I/O latency, heap/RSS and embedding tails remain open.

## Priority 1 — R29 canonical execution transport

**Hypothesis:** redundant operand publication, frame transitions or dispatch work
materially contributes to the remaining text gap. R24's21% prefix sample share
includes useful inlined work; calls/binding~2% and integer addition~3% alone do not
justify arenas or a universal scalar rewrite. R27 allocation shares likewise are
not CPU evidence. Current safe forwarding, direct result stores, final argument
storage, deferred contexts and frameless native helpers are already delivered.

**Bounded gate, complete:** one current-source Linux text capture reuses the
checked worker/perf protocol, emitting exact Tier1 code in that same process.
Map samples to checks, reads, publication/retirement, call transitions, dispatch
and useful operations. Preserve all threads/unknowns/tiering effects/raw addresses.
No runtime counters, new harness, changed guest source or normal-clock speedup
claim. Stop after this bounded attribution; if mapping fails, identify unsupported
claims and the next source-backed alternative rather than expanding a campaign.

**Selected implementation:** ordinary, exact-positional, unbound closed native
helpers currently manufacture a pending call, exit the prefix, run the same
frameless body in BeginPendingCall, publish completed state and reenter through
ResumePendingCall. Move that existing borrow/native attempt into the existing
TryExecuteNativeCall selection and delete the displaced branch in BeginPendingCall.
No new native evaluator, input plan, caller packet or public option. These helpers
cannot suspend; all bound/default/dynamic/protocol/general calls retain the real
frame runner. Exact operands remain borrowed until completion/retirement; the
original call stack/recursion checks and callable exception translation remain.
A failed read-only proof performs no work/admission; no operation retries.

This removes a proved synthetic pause/completion phase, not the whole21% prefix.
BeginPendingCall/ResumePendingCall account for14 samples each; reentry and useful
work limit attribution. No predicted speedup. Keep the larger destination rewrite
conditional: it must replace following-store/HasLocalResult and pending cleanup
together, not add a success-only route. Preserve actual value snapshots; do not
reread receivers after callbacks or revive measured-slower B61/B69 arenas/control.

**Acceptance:** text/CSV/JSON/report complete scripts; original read/error/effect
order/spans; defaults/keywords/receivers; closures/cells; exact numeric promotion
without replay; actual suspension; exception/cursor cleanup. Keep cancellation in
nonallocating loops, terminal first refusal, retained operands and awaited cleanup
funding. Focused actual-target Release checks, existing exact allocation diagnostic
and a bounded quiet-VM source pair with unchanged controls. At delivery decide all
remaining regression debt, including R26; uncertainty is not parity. Batch full
platform/original Stress/installed consumers at that runtime boundary.

## Following redesign roadmap

| Area / evidence | Work to eliminate / displaced implementation | Scripts and acceptance / decision |
| --- | --- | --- |
| Complete call/frame construction | R29 attribution first. Target one complete argument/binding/context/continuation phase, preserving existing borrowed/native paths; remove its old driver/transport. | Helper-heavy text/CSV/report, constructors and genuine I/O. Defaults, dynamic keywords, protocol selection, frames, evaluation order, stack admission, cancellation and funded borrows. No arena merely because boxing exists. |
| Boxed values / operand transport | Assess integer object traffic together with reads, publication and retirement. Select a canonical representation only with a proved hot removable phase; delete displaced object/transport paths. | Counters/indexes/aggregation; Python identity/aliases/hash/projection, exact promotion and public storage funding. Small add's~3% CPU is insufficient by itself; do not start a universal migration speculatively. |
| Per-record construction | R20/R25 delivered. Earlier6–8% CSV bulk rejection was reconsidered through completed-array transfer, not automatically promoted. Select another phase only when an actual intermediate can disappear. | CSV/JSON/report; header reentry/admission mutation, short/rest/duplicate/custom keys, independent mutable rows, Clear capacity and overlap. Keep old adverse control results. |
| Remaining text conversions | Casing/split and unchanged UTF-8 file windows already direct. R28−6.94% allocation fails to justify universal window overhead/report debt; seek a different final-storage/conversion boundary. | Unicode expansion/context, indexing/hash/repr, regex scalar/byte offsets, retained aliases and cancellation. No new pool/owner ledger; allocations and CPU are distinct. |
| Repeated frontend analysis | Lexical/shared facts already reused. Consolidate a demonstrated duplicate walk or retained representation; remove it rather than add another cache. | Helper/comprehension compile-to-result controls, separate from warm text. Preserve corrected shared-graph analysis, scoping/class cells/annotations, diagnostics and compile cancellation/admission. |

## Independent regex track

Core Python semantics/native UTF-8, byte ranges, scalar original-subject windows,
captures/replacements/errors, ownership and current cancellation keep advancing.
U04/R23 delivered; core has zero backend dependency/type edges. Normal adapter
pin0.4 is nonpackable. Dev46 immutable source6957b35a passes85 internal/482 public
per actual target using the U04 bridge; evidence2026-11-06-regex-dev46-compatibility.
Do not repeat unchanged qualification or promote private producer bits silently.

Only affected final adapter qualification waits: DetailedData lacks independent
Prepare working ownership; native names cannot be enumerated; native cursors mix
creation/current tokens. Existing conservative preflight, adapter-local conversion
and qualified CTS bridge support development/current semantics. Normal0.4 reversed
windows fail explicitly. Development producers/bridges are acceptable; qualify the
released immutable package/managed safety separately. No sibling edits, silent
dialect fallback, work/time quotas or abandoned matching. This dependency never
blocks independent core implementation/correctness/performance work.

## Evidence, iteration and project constraints

Timeouts, unstable controls and inconclusive timings establish uncertainty. Allow
bounded confirmation/refinement/measurement correction when justified; preserve
original failed conditions and adverse results. Percentages inform decisions,
not automatic vetoes or permanent closures. Distinguish simplification, allocation,
elapsed and demonstrated CPU. Temporary regression debt needs an explicit
completion milestone/decision. Keep active plan concise; historical narratives/raw
sources/observations belong in benchmarks/results and benchmarks/EXPERIMENTS.md.
R28 all variants, failed conditions and exact images are preserved in committed
2026-11-07-owned-split-storage; original B205 binaries likewise have committed
backup before redundant expanded VM copies are retired after user/link/hash checks.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
probing. Preserve managed stack/recursion, host capabilities/contained paths, cycles,
cooperative cancellation and borrowed shared allowance for capacity/replacement/
escaping aliases. First admission refusal fails the command; never retry. Await
all users/cleanup. No fuel/quotas, hidden caps/default allowance, heap tracing,
weak reclamation or forced GC. Long streaming uses bounded host executions;
XML depth constraint remains. Do not alter supported semantics to simplify proof.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Quiet VM lokad@20.166.121.73,
key~/.ssh/id_lython-bench.pem: owned lease, Ready identities, controls/quiet/goldens/
funding/Closed/joins and verified persistent archives. Observe only after recorded
owner+stop+margin bound. Disk nearly full: retire exact redundant expanded files
only after independent committed backup and current user/dependency checks. Keep
all raw evidence. Continue the roadmap; publication/tagging remain postponed.
