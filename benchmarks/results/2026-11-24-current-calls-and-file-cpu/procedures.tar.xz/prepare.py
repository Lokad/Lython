from pathlib import Path
import hashlib, json, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.with_name("forwarded-rule-cpu-20261124")
external = lab.with_name("frontend-cpython-20261124") / "external"
donor = lab.with_name("shared-comprehension-facts-20261124")
quiet = donor / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, data: path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n",encoding="utf-8",newline="\n")
ident = read(external / "identity.json")
sealed = read(quiet / "identity.json")
receipt = read(quiet / "terminal-status.json")["receipt"]
assert ident["sourceRevision"].startswith("b9b20aa98") and ident["sourceImageArchiveSHA256"] == receipt["archiveSHA256"]
assert sha(quiet / "observations.tar.xz") == receipt["archiveSHA256"] and receipt["complete"]
assert ident["imageFiles"]["candidate"] == sealed["imageFiles"]["candidate"]
assert {path.name: sha(path) for path in (donor / "candidate").iterdir()} == ident["imageFiles"]["candidate"]
assert not subprocess.check_output(["git","diff",ident["sourceRevision"],"--","src","tests"],cwd=repo)
ident.update(profiles=[
    ("defaulted-warm", "scripts.rule-default-closures", "candidate"),
    ("defaulted-through", "scripts.rule-default-closures", "candidate"),
    ("manifest-warm", "scripts.config-manifest.small", "candidate"),
], purpose="Locate current rule construction and host/runtime manifest costs on the CPython comparison source",
    donorArchiveSHA256=receipt["archiveSHA256"], profileCatalogSHA256=sha(external / "representative.json"))
save(lab / "identity.json", ident)
save(lab / "verified-raw-replicas.json", [])
shutil.copyfile(external / "representative.json", lab / "catalog.json")
shutil.copyfile(external / "candidate-verify.json", lab / "candidate-verification.json")
shutil.copyfile(template / "run.sh", lab / "run.sh")
assert b"\r" not in (lab / "run.sh").read_bytes()
launcher = (template / "quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("forwarded-rule-cpu-b1634", "current-calls-and-file-cpu-b1644").replace("b1634-forwarded-rule-cpu", "b1644-current-calls-and-file-cpu")
launcher = launcher.replace("borrow-forwarded-integers-20261124", "shared-comprehension-facts-20261124").replace('checked["caseCount"]==3', 'checked["caseCount"]==5')
collector = (template / "collect.py").read_text(encoding="utf-8").replace("borrow-forwarded-integers-b1631", "shared-comprehension-facts-b1642").replace("b1634-fixtures", "b1644-fixtures")
analyzer = (template / "analyze.py").read_text(encoding="utf-8")
statement = ''' rows[-1]['insideGuestComparisonHost'] = sum(any('ComparisonFileHost' in frame for frame in stack) for stack in guest)
 rows[-1]['insideGuestMetadataOrFileStream'] = sum(any('System.IO.' in frame for frame in stack) for stack in guest)
 rows[-1]['unmappedGuestLeaf'] = sum('[unknown]' in stack[0] for stack in guest if stack)
'''
offset = analyzer.index("\n(r/'attribution.json')")
analyzer = analyzer[:offset] + "\n" + statement + analyzer[offset:]
archive = (template / "archive.py").read_text(encoding="utf-8").replace("2026-11-24-forwarded-rule-cpu","2026-11-24-current-calls-and-file-cpu").replace('startswith("d6a168491")','startswith("b9b20aa98")')
ops = (template / "ops-profile.py").read_text(encoding="utf-8")
for name, contents in (("quiet.py", launcher), ("collect.py", collector), ("analyze.py", analyzer), ("archive.py", archive), ("ops-profile.py", ops)):
    compile(contents, name, "exec")
    (lab / name).write_text(contents,encoding="utf-8",newline="\n")
