#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/native-dict-item-cursor"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/native-dict-item-cursor"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~NativeDictionary|FullyQualifiedName~NamespaceView|FullyQualifiedName~RegexProviderContractTests)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~NativeDictionary|FullyQualifiedName~NamespaceView)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"