from pathlib import Path
import hashlib
import json
import os
import subprocess
import shutil
import statistics

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
trial = repo / ".git/agent-worktrees/native-dict-item-cursor"
donor = notes / "direct-native-text-dict-keys"
core = "Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])


def load(p):
    return json.loads(p.read_text(encoding="utf-8"))


def save(p, v):
    p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def revision(directory):
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=directory, text=True).strip()


reference, candidate = revision(repo), revision(trial)
assert reference.startswith("cb84980ca") and candidate != reference
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=trial)
assert not subprocess.check_output(["git", "diff", "--name-only", reference, "--", "src"], cwd=repo)
manifest = lab / "representative.json"
manifest_hash = sha(manifest)
protocol = repo / "benchmarks/cpython-worker.py"
previous = load(donor / "identity.json")["imageFiles"]["candidate"]
assert len(previous) == 32
previous_image = donor / "frozen/candidate"
assert {n: sha(previous_image / n) for n in previous} == previous
frozen = {}
for role, checkout in (("reference", repo), ("candidate", trial)):
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in previous:
        origin = checkout / "src/Lokad.Lython/bin/Release/net11.0" / core if name == core else previous_image / name
        shutil.copyfile(origin, image / name)
    image_hashes = {name: sha(image / name) for name in previous}
    for probe in previous_image.glob("ValidatedAllocation.*"):
        shutil.copyfile(probe, image / probe.name)
    compile_probe = notes / "borrow-lexical-builder-r625/compile-allocation/bin/Release/net11.0"
    for probe in compile_probe.glob("CompileAllocation.*"):
        shutil.copyfile(probe, image / probe.name)
    compile_result = subprocess.check_output([dotnet,image/"CompileAllocation.dll",manifest],env=env,timeout=100)
    (lab/f"{role}-compile-allocation.json").write_bytes(compile_result)
    assert json.loads(compile_result)["coreSha256"]==image_hashes[core]
    verified = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
        "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol, "--out", verified],
        check=True, env=env, timeout=100)
    assert load(verified)["state"] == "Completed" and load(verified)["catalogSha256"] == manifest_hash
    allocation = lab / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, allocation], check=True, env=env, timeout=100)
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha(image / name) for name in previous} == image_hashes
    frozen[role] = image_hashes
assert [name for name in previous if frozen["reference"][name] != frozen["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=reference, candidate=candidate, catalogSHA256=manifest_hash,
                                 pythonWorkerSHA256=sha(protocol), imageFiles=frozen))
left, right = [load(lab / f"{r}-allocation.json")["rows"] for r in ("reference", "candidate")]
rows = []
for before, after in zip(left, right, strict=True):
    assert before["id"] == after["id"]
    a, b = (statistics.median(row["allocatedBytesPerInvocation"]) for row in (before, after))
    p, q = (row["peakExecutionMemoryBytes"] for row in (before, after))
    rows.append(dict(case=before["id"], previousAllocatedBytes=a, candidateAllocatedBytes=b, allocationChangePercent=100*(b/a-1),
                     previousAccountedPeak=p, candidateAccountedPeak=q, budgetReturnedToBaseline=True))
save(lab / "allocation-summary.json", rows)
for row in rows:
    print(row["case"], f"{row['allocationChangePercent']:+.3f}% allocation",
          f"accounted peak {row['previousAccountedPeak']} -> {row['candidateAccountedPeak']}")
