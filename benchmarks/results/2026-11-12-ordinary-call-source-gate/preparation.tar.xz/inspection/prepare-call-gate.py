from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent.parent/'call-boundary-r264';r.mkdir(exist_ok=False)
old=r.parent/'namespace-ownership-r261'
t=(old/'Program.cs').read_text(encoding='utf-8')
t=t.replace('instructions=((Array)Get(code,"Instructions")!).Length,','instructions=((Array)Get(code,"Instructions")!).Length,opcodes=((IEnumerable)Get(code,"Instructions")!).Cast<object>().Select(i=>Get(i,"OpCode")!.ToString()).ToArray(),exceptionRegions=((IEnumerable)Get(code,"ExceptionRegions")!).Cast<object>().Count(),')
(r/'Program.cs').write_text(t,encoding='utf-8')
t=(old/'inspect.csproj').read_text(encoding='utf-8').replace('cell-write-authority-r260/candidate','text-output-batches-r263/refined/candidate')
(r/'inspect.csproj').write_text(t,encoding='utf-8')
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
more=json.loads((r.parent/'receiver-operations-r256/catalog.json').read_text(encoding='utf-8'))
cases={c['id']:c for c in catalog['cases']+more['cases']}
catalog['cases']=[cases[k]for k in ['scripts.file-search.large','scripts.file-search.guarded-helper.large','scripts.csv-validated-records.large','scripts.text-summary-helpers.nonlocal-counter.large','scripts.report-render.large']]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
print(r)
