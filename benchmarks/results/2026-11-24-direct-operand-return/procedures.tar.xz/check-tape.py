from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
quiet=lab/'comparison/quiet'
identity=read(quiet/'identity.json')
short='''def identity(value):
    return value

def literal():
    return None

def select(first, second, enabled):
    return first if enabled else second

print(identity('retained'), literal(), select([], (), False))
'''
cases=read(quiet/'representative.json')['cases']+[dict(id='short-return-shapes',source=short)]
source=lab/'tape-catalog.json'
source.write_text(json.dumps(dict(cases=[{k:r[k] for k in ('id','source')} for r in cases]),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
subprocess.run([dotnet,'build',lab/'tape/Tape.csproj','-c','Release','-f','net11.0','-o',lab/'tape-output'],env=env,cwd=repo,check=True,timeout=45)
rows={}
for role,property in [('reference','HasDirectIntegerReturn'),('candidate','HasDirectOperandReturn')]:
    image=lab/role
    assert {p.name:sha(p) for p in image.iterdir()}==identity['imageFiles'][role]
    output=lab/f'tape-{role}'
    output.mkdir(exist_ok=True)
    for p in (lab/'tape-output').glob('Tape.*'):shutil.copyfile(p,output/p.name)
    core=image/'Lokad.Lython.dll'
    shutil.copyfile(core,output/core.name)
    result=lab/f'tape-{role}.json'
    subprocess.run([dotnet,output/'Tape.dll',source,result,property],env=env,check=True,timeout=45)
    tape=read(result)
    assert tape['coreSHA256']==sha(core)
    rows[role]=tape['rows']
summary=[]
n_objects=n_instructions=0
for old,new in zip(rows['reference'],rows['candidate'],strict=True):
    assert old['id']==new['id'] and old['retainedAdmission']==new['retainedAdmission']
    for before,after in zip(old['objects'],new['objects'],strict=True):
        a,b=(item.pop('DirectOperandReturn') for item in (before,after))
        assert before==after,(old['id'],before['Name'])
        n_objects+=1
        n_instructions+=len(before['Instructions'])
        if a or b:
            summary.append(dict(case=old['id'],name=before['Name'],referenceDirect=a,candidateDirect=b))
            assert b or not a
picked={(r['case'],r['name']):(r['referenceDirect'],r['candidateDirect']) for r in summary}
for name in ('choose','choose_policy'):
    assert picked['diagnostic.shipment-routing-report',name]==(True,True)
for name in ('identity','literal'):
    assert picked['short-return-shapes',name]==(False,True)
report=dict(verifiedSources=len(cases),codeObjects=n_objects,instructions=n_instructions,matchedTapeAndRetainedAdmission=True,direct=summary)
(lab/'tape-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report))