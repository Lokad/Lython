from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-24-direct-operand-return'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert identity['sourcePatchSHA256']==sha(lab/'candidate.patch')
assert subprocess.check_output(['git','diff','--binary',identity['validationSourceRevision'],'--','src'],cwd=repo)==(lab/'candidate.patch').read_bytes()
changes=subprocess.check_output(['git','diff','--binary',identity['validationSourceRevision'],'--','tests'],cwd=repo)
assert b'conditional-operand-aliases' in changes
(lab/'test.patch').write_bytes(changes)
for role,files in identity['imageFiles'].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
    verification=read(lab/f'comparison/{role}-verify.json')
    assert verification['state']=='Completed' and verification['caseCount']==4
    assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert read(lab/f'tape-{role}.json')['coreSHA256']==files['Lokad.Lython.dll']
assert read(lab/'tape-summary.json')['matchedTapeAndRetainedAdmission']
for platform in ('windows','ubuntu'):
    for target in ('net11.0','net10.0'):
        for suite,count in (('Lokad.Lython.Tests',109),('Lokad.Lython.PublicApi.Tests',413)):
            log=(lab/f'{platform}-{target}-{suite}.log').read_text(encoding='utf-8-sig')
            assert 'Failed:     0, Passed:' in log and f'Total:   {count:3d},' in log,(platform,target,suite)
for name,p in [('identity.json',quiet/'identity.json'),('allocation-summary.json',lab/'allocation-summary.json'),('tape-summary.json',lab/'tape-summary.json')]:
    shutil.copyfile(p,out/name)
items=['candidate.patch','test.patch','freeze.py','freeze.log','candidate-build.log','prepare.py','prepare.log','initial-file-map.log',
    'test-ubuntu.sh','allocations.py','reference-allocation-final.json','candidate-allocation-final.json','verified-space.py',
    'retired-stage-custody.json','quiet.py','archive.py','package-evidence.py','check-tape.py','tape/Program.cs','tape/Tape.csproj',
    'tape.log','tape-catalog.json','tape-reference.json','tape-candidate.json','comparison/quiet/representative.json',
    'comparison/quiet/jobs.json','comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/storage-custody.json',
    'comparison/quiet/launch.log','comparison/quiet/upload.json','comparison/reference-verify.json','comparison/candidate-verify.json','retrieve.log','prepare-confirmation.py','confirm.py','archive-confirmation.py','confirmation/launch.log','confirmation/retrieve.log','verified-raw-replicas.json']
items.extend(p.name for p in sorted(lab.glob('*net1*.log')))
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in items:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha(lab/name) for name in items)
print('Verified archived patch, tapes, image identities, tests and procedures.')