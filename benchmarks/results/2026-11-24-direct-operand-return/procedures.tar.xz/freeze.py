from pathlib import Path
import subprocess
import shutil
import zipfile
import os

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = subprocess.check_output(['git', 'rev-parse', '694c1645b'], cwd=repo, text=True).strip()
assert reference.startswith('694c1645b'), reference
changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'src'], cwd=repo, text=True).splitlines()
assert len(changed) == 8 and all(path.startswith('src/Lokad.Lython/') for path in changed), changed
assert not subprocess.check_output(['git','diff',reference,'HEAD','--',*changed],cwd=repo)
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'src'], cwd=repo)
(lab/'candidate.patch').write_bytes(patch)
archive = lab/'frozen-source.zip'
paths = ['global.json','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','NuGet.Config','src/Lokad.Lython']
existing = subprocess.check_output(['git','ls-tree','--name-only',reference], cwd=repo,text=True).splitlines()
paths = [path for path in paths if '/' in path or path in existing]
subprocess.run(['git','archive','--format=zip',f'--output={archive}',reference,'--',*paths],cwd=repo,check=True)
sdk = Path.home()/'.dotnet11'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
with zipfile.ZipFile(archive) as bundle:
    for role in ('candidate',):
        root = lab/f'frozen-{role}'
        bundle.extractall(root)
        if role=='candidate':
            for name in changed:
                shutil.copyfile(repo/name, root/name)
        for name in bundle.namelist():
            if name.endswith('/'): continue
            expected=(repo/name).read_bytes() if role=='candidate' and name in changed else bundle.read(name)
            assert (root/name).read_bytes()==expected, name
        with (lab/f'{role}-build.log').open('wb') as log:
            subprocess.run([sdk/'dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
                '--no-incremental','--artifacts-path',lab/f'{role}-build'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch
print('Built reference and candidate from verified source snapshots.')