from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'direct-split-r513';old=prior/'quiet';q=r/'quiet';q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=dict(sourceRevision='Qualified10ee56c7/2ede09fc versus privateR515/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Known-size private working-drain construction removes initial geometric growth/copy/admission while retaining live iteration, bounded consumers, reentrant mutations, first refusal and awaited cleanup. Original/helper text warm plus floating/call controls; no predicted speedup.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.helper-list','warm'],['scripts.numeric-squared-error.floating.large','warm'],['calls.positional.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('lean R495 shared-runner source pair','known-size working-drain source pair');(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'archive-owned.py',q/'archive-owned.py')
remote='/home/lokad/lython-bench-checks/known-drain-b942-20261118';unit='lython-b942-known-drain-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=previous['catalogSHA256'],catalogSource='/home/lokad/lython-bench-checks/generator-sum-b886-20261117/representative.json',catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(" assert sha(source/'representative.json')==c['sourceCatalogSHA256']"," assert sha(source/'representative.json')==c['sourceCatalogSHA256']\n catalogSource=Path(c['catalogSource']);assert catalogSource.resolve()==catalogSource and catalogSource.is_relative_to(b)and sha(catalogSource)==c['catalogSHA256']")
s=s.replace("os.link(source/'representative.json',root/'representative.json')","os.link(catalogSource,root/'representative.json')").replace('Six-case catalog','Thirteen-case catalog').replace('lython-b939-fixtures','lython-b942-fixtures')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((prior/'launch.py').read_text(encoding='utf-8').replace('Four-job refined direct-split','Four-job known-size drain'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace('B934','B942'),encoding='utf-8',newline='\n')
shutil.copyfile(prior/'summarize.py',r/'summarize.py')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Four-job pair prepared; current32-file images13catalog goldens verified; byte/path/alias retirement revalidated on staging. No new timings yet.')
