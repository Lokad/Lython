from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
def committed(name):
 blob=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert blob==(repo/name).read_bytes();return blob
name='benchmarks/results/2026-11-18-buffered-yield-transport/candidate-core.dll.gz';blob=committed(name);data=gzip.decompress(blob);assert hashlib.sha256(data).hexdigest()=='1bce52adf7b88038092efdced148939a2b8716c5fe88b9b73ec380fa7864da98'
subjects.append(dict(kind='superseded-qualified-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
for name,folder in [('benchmarks/results/2026-11-18-direct-split-construction/refined/observations.tgz','direct-split-refined-b939-20261118'),('benchmarks/results/2026-11-18-direct-global-operands/initial/observations.tgz','direct-globals-b933-20261118')]:
 blob=committed(name);member='confirmation/confirmation.json'
 with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath=folder+'/'+member))
name='benchmarks/results/2026-11-18-call-entry-gate/corrected/observations.tgz';blob=committed(name)
subjects.append(dict(kind='archived-observation-file-replica',sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True,knownPath='call-entry-b941-20261118/observations.tgz'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 proofs=[];keys={}
 for item in subjects:
  candidates=[b/item['knownPath']]if'knownPath'in item else list(b.glob('*/*/Lokad.Lython.dll'));ps=[]
  for p in candidates:
   if not p.exists():continue
   m=p.lstat()
   if m.st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']:ps.append(p)
  assert ps,item
  m=ps[0].lstat();key=(m.st_dev,m.st_ino);assert key not in keys
  for p in ps:
   v=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and(v.st_dev,v.st_ino)==key and v.st_nlink==m.st_nlink
  proof=item|dict(paths=sorted(str(p.relative_to(b))for p in ps),links=m.st_nlink);proofs.append(proof);keys[key]=proof
 aliases={key:[]for key in keys}
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;m=p.lstat();key=(m.st_dev,m.st_ino)
   if key in keys:aliases[key].append(str(p.relative_to(b)))
 for key,proof in keys.items():assert sorted(aliases[key])==proof['paths']and len(aliases[key])==proof['links']
 print(json.dumps(dict(readOnly=True,freshIdleLease=True,proofs=proofs,current2edeImagesCatalogsToolchainsAndUnmatchedEvidencePreserved=True)))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'retirement-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8');v=json.loads(p.stdout);print('Read-only fresh exact committed replica proof:',[(p['kind'],p['bytes'],p['links'])for p in v['proofs']])
