from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-known-drain-construction/initial';out.mkdir(parents=True,exist_ok=False)
receipt=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved'];assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
decision=dict(retain=False,state='Private; one bounded unchanged confirmation selected',reference='Qualified10ee56c7/2ede09fc',candidate='PrivateR515/a71abfed',hypothesis='Existing known counts can remove initial working-list geometric growth/copy/repeated admission, without a new buffer or owner. Size is a hint, not a live iteration bound.',established='Both targets74internal/73public focused pass;13goldens/allocation/budgetreuse and actual4casecatalog both-image goldens pass. Helper-list text allocation7.110percent lower, helperreport1.542percent lower; original text/nontext effectively flat, accounted peaksflat. Initial major allocation and lease wrapper now inside rollback boundary.',uncertainty='FirstB942original elapsed+1.30..+4.84percent/CPU+1.09..+3.67 with1.20/2.26spreads; helper-5.20..-1.07elapsed/CPU-4.83..-0.73 with3.70/.63spreads. Floating+.24..+6.78elapsed/supportingCPU, candidate4.21spread. Callsnearflat/CPUuncertain. No universal CPU claim.',tradeoffs=['Conservative known-size admission can refuse sooner than incremental enumeration. Tiny-budget threshold equality is not a contract.','Live list changes after admission and underestimated/overestimated hints preserve actual iteration; growth still admits replacement overlap.','Generic/protocol drains still consume before item validation and await user cleanup.'],next='One unchanged original/helper/floating confirmation;8second rotated warmup/opposite preparation roles. Preserve original adverse results; decide retention/refinement/debt, no fixed-percent veto.',publicationHeld=True)
(r/'initial-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for n in ['summary.json','allocation-summary.json','checks.json','candidate-sources.tar.xz','prototype.patch.gz','initial-decision.json','reference-allocation.json','candidate-allocation.json','reference-preflight.json','candidate-preflight.json','reference-measurement-preflight.json','candidate-measurement-preflight.json']:shutil.copyfile(r/n,out/n)
for n in ['archive-receipt.json','observations.tgz','terminal-status.json','identity.json']:shutil.copyfile(r/'quiet'/n,out/n)
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not {'frozen','retrieved','bin','obj'}&set(p.relative_to(r).parts)and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Known-size working-drain construction: first source pair

R515/B942,2026-11-18UTC, private **a71abfed** onf9aeaf0b versus fully qualified
**10ee56c7/2ede09fc**. Not promoted; one bounded unchanged confirmation selected.
Existing Cursor/collection count hints fund initial working capacity once, avoiding
its geometric growth/copy/repeated admission. Actual iteration remains live; growth
after host reentry or underestimates still funds replacement overlap. Initial
backing/lease-wrapper construction move inside rollback protection. No new
framework/cache/owner/policy. Earlier conservative denial is a documented tradeoff.

Both actual11/10 each74internal/73public focused tests pass. New cases preserve
aliases, cleanup/reuse, hints, bounded consumers, refusal before enumeration and
host admission mutating a live list. Four old join-fixture failures assumed a
four-slot minimum; the one-byte-short setup now uses actual exact capacity and
keeps refusal/first attribution/alias/cleanup assertions. Original failures retained.
13case actual-worker goldens/allocation/reuse pass. An older VM catalog mismatch
was caught before mutation/launch; exact timed4case catalogs pass both frozen
32-file images and CPython goldens. Initial allocation catalog stays separate.

Helper-list normalization1,385,840→1,287,304B(−7.110%); helperreport−1.542%.
Original normalization/nontext effectively flat; accounted peaksflat. Allocation
is distinct from CPU. Four quietVM jobs155.71s,6s rotated warmups/five rounds:

| Warm complete script | Elapsed change | Wider process CPU | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Original text |+1.30..+4.84%|+1.09..+3.67%|1.20/2.26%|
| Helper-list text |−5.20..−1.07%|−4.83..−0.73%|3.70/0.63%|
| Floating |+0.24..+6.78%|+0.80..+6.26%|2.22/4.21%|
| Positional calls |+0.03..+1.67%|−0.80..+2.81%|0.63/1.01%|

Keep original adversity/helper reference and floating candidate instability.
One unchanged original/helper/floating confirmation uses8s warmup/opposite roles.
No universal gain, causal source-condition subtraction, currentHEAD/CPython ratio
or qualification inheritance. Default GC/tiering, AzureF4as_v7/Ubuntu24.04.4/
.NET11RC3. Warm clocks include mediated RAM I/O/goldens/prior-result cleanup;
startup/reset/protocol/finalcache cleanup excluded. ProcessCPU is wider.

All quiet/image/golden/join/SHAarchive/cleanup gates pass.254/252MiBfloors preserved;
only exact committed replica bytes retired under fresh path/UID/hash/link/all-alias
proof. Current2ede/images/catalogs/toolchains/unmatched evidence stay. Normal
adapter0.4 unchanged, publication postponed; broader roadmap continues.

[Decision](initial-decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[checks/procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

R515/B942 [known-drain first source pair](results/2026-11-18-known-drain-construction/initial/README.md), privatea71abfed versus qualified2ede09fc: existing count hints admit working capacity once; live mutations/underestimates/maxItems/first refusal/cleanup preserved, initial backing/lease-wrapper rollback protected. Both targets74internal/73public/13goldens+reuse/actual4case goldens pass. Helperallocation−7.110%/helperreport−1.542%, other diagnostics~flat/peaksflat. Original+1.30..+4.84%elapsed/supportingadverseCPU; helper−5.20..−1.07%/supportingCPU with3.70%reference spread; floatingadverse/4.21%candidate spread. One unchanged8s original/helper/floating confirmation selected; no promotion/universal claim. Old four-slot fixture assumption corrected without weakening refusal/alias/cleanup. Catalog mismatch caught before mutation, original condition retained. All quiet/join/SHA/guards pass, publicationheld.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('\n\n| Fully qualified | R513','\n| Fully qualified | R513')
s=s.replace('**R514 source gate complete; R515 construction next.**','**R514 complete; R515 private confirmation next.**')
s=s.replace('   decides retention/refinement/regression debt. Then resume wider roadmap.','''   decides retention/refinement/regression debt. Both targets74internal/73public
   pass;13goldens/reuse plus actual4case checks pass. Helperallocation7.110%lower,
   original/nontext~flat/peaksflat. B942original+1.30..+4.84%elapsed/adverseCPU;
   helper−5.20..−1.07%/supportingCPU but3.70%reference spread; floating4.21%candidate
   spread/adverse. Keep private; one unchanged8s warmup/opposite-role original/
   helper/floating confirmation. Original adversity/catalog mismatch retained.
   R516 current IR confirms append_cleaned6instructions/2calls/onePopTop. Assess
   discarded call-result transport as next coherent operand milestone: remove
   unused publication/PopTop dispatch, preserve eager operations/preflights,
   exceptions, real suspension and awaited temporary cleanup. No prototype/CPU
   claim yet. Then resume wider roadmap.''')
p.write_text(s,encoding='utf-8',newline='\n');print('Original adverse source pair preserved; unchanged bounded confirmation selected, next operand gate recorded.')
