from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'quiet';repo=Path('D:/code/Lython')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# The failed stage checked an old nine-case catalog against this later13-case
# catalog before any root creation, retirement, mount or launch. Preserve it.
failed=r/'prestage-catalog-mismatch';failed.mkdir(exist_ok=False)
for n in ['launch.log','remote-launch.py','config.json']:shutil.copyfile(q/n,failed/n)
(q/'launch.log').unlink()
v=json.loads((r/'catalog.json').read_text(encoding='utf-8'));wanted=['scripts.text-normalization.large','scripts.text-normalization.helper-list','scripts.numeric-squared-error.floating.large','calls.positional.large'];v['cases']=[next(c for c in v['cases']if c['id']==n)for n in wanted]
catalog=r/'measurement-catalog.json';catalog.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 cmd=[str(d),str(r/'frozen'/role/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(catalog),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-measurement-preflight.json'))]
 with(r/(role+'-measurement-preflight.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert p.returncode==0,(r/(role+'-measurement-preflight.log')).read_text(encoding='utf-8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'prove-space.py')],check=True)
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'));identity['catalogSHA256']=sha(catalog);identity['allocationCatalogSHA256']=sha(r/'catalog.json');(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(catalog,q/'representative.json');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll','representative.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c.pop('catalogSource');c.update(identity=identity,catalogSHA256=sha(catalog),retireGroups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s='\n'.join(line for line in s.splitlines()if'catalogSource='not in line and'os.link(catalogSource,'not in line)+'\n'
s=s.replace(" present=[];absent=[];paths=[];inodes={}"," with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:assert hashlib.sha256(t.extractfile('representative.json').read()).hexdigest()==c['catalogSHA256']\n present=[];absent=[];paths=[];inodes={}")
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Four-case actual frozen-worker catalog/goldens verified; old catalog mismatch preserved before any mutation. Initial13-case allocation results remain separate; timed catalog bytes:',catalog.stat().st_size)
