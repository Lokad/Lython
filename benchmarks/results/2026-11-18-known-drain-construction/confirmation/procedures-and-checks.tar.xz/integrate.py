from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/known-drain-r515';q=r/'confirmation';out=repo/'benchmarks/results/2026-11-18-known-drain-construction/confirmation';out.mkdir(parents=True,exist_ok=False)
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==3 and receipt['allWorkersJoined'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));prod=[n for n in identity['sourceInputs']if n.startswith('src/Lokad.Lython/')];assert len(prod)==587
same=lambda a,b:a==b or a.decode('utf-8-sig').replace('\r\n','\n')==b.decode('utf-8-sig').replace('\r\n','\n')
different=[]
for n in prod:
 frozen=(work/n).read_bytes();assert hashlib.sha256(frozen).hexdigest()==identity['sourceInputs'][n]
 if not same((repo/n).read_bytes(),frozen):different.append(n)
assert different==['src/Lokad.Lython/Runtime/PyIteration.cs'],different
for n in different+['tests/Lokad.Lython.Tests/KnownDrainOwnershipTests.cs','tests/Lokad.Lython.Tests/StringJoinCleanupTests.cs']:shutil.copyfile(work/n,repo/n)
assert all(same((repo/n).read_bytes(),(work/n).read_bytes())for n in prod)
decision=dict(retain=True,state='Integrated, focused-qualified; full delivery batched with next runtime milestone',candidate='a71abfed',reference='Qualified2ede09fc',reasons=['One capacity-level preflight removes initial geometric growth/copy/admission for known-size private drains; no new buffer/owner/cache/policy.','Helper-list normalization allocation7.110percent lower; helperreport1.542percent lower; other diagnostics effectivelyflat/peaksflat.','Both actual targets74internal/73public focused,13goldens/reuse/actual4case32filechecks pass; live source mutation/hints/boundedconsumers/refusal/cleanup preserved.'],CPUDecision='No consistent CPU gain established. Original firstB942adversity retained; B943 original-1.24..+1.38elapsed/CPU-0.89..+1.19 with.017/2.63spreads. Helper-2.00..+2.11elapsed/CPU+.03..+1.75 with.51/3.67spreads. Floating-.83..+3.88elapsed/CPU-.79..+5.06 with.55/4.18spreads. Accept unresolved process variability/possible modest CPU debt for established allocation/capacity benefit. Revisit controls at next representative helper milestone, no further unchanged campaign now.',tradeoff='Conservative known-size admission may reject earlier, including overestimated hints. Allocation before mutation remains admitted; live iteration/growth still funds replacement overlap. No tiny-budget threshold promise.',all587ProductionInputsMatchMeasuredSource=True,binaryEqualityInferred=False,fullDelivery='Pending coherent R515/R516 boundary, not inherited from reference',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for source,target in [(r/'confirmation-summary.json','summary.json'),(r/'decision.json','decision.json'),(r/'checks.json','checks.json')]:shutil.copyfile(source,out/target)
for n in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:shutil.copyfile(q/n,out/n)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not {'frozen','retrieved','bin','obj'}&set(p.relative_to(r).parts)and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Known-size working drains: confirmation and retention

R515/B943,2026-11-18UTC, unchanged **a71abfed versus2ede09fc**. Retained for
capacity-level construction/established allocation benefit, with CPU uncertainty;
not a demonstrated CPU gain or universal performance improvement. Full platform/
stress/installed-package delivery will be batched at the next runtime boundary.
All587production inputs match the measured source; no binary equality inferred.

Three jobs142.33s;8s rotated warmups/opposite preparation roles, five rounds,
two processes per source; defaultGC/tiering and unchanged quietVM/toolchains.
Exact32-file images/timed4case catalog reused, no repeated unchanged correctness
or allocation qualification. [Original adverse conditions](../initial/README.md)
and13case allocation diagnostic remain separate.

| Warm complete script | Elapsed change | Wider process CPU | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Original text |−1.24..+1.38%|−0.89..+1.19%|0.02/2.63%|
| Helper-list text |−2.00..+2.11%|+0.03..+1.75%|0.51/3.67%|
| Floating |−0.83..+3.88%|−0.79..+5.06%|0.55/4.18%|

No consistent CPU improvement follows. Retain the helper allocation7.110% and
helperreport1.542% reduction independently. Accounted peaksflat; unknown/protocol
drains retain live iteration/growth and cleanup. Conservative hints can refuse
earlier. Initial backing/lease allocation rollback stays protected. No hidden
allowance, new policy, per-object ledger, disabled check or skipped user effect.

Accept process variability/possible modest CPU debt for this storage benefit;
revisit representative controls at the next helper/operand checkpoint. No third
unchanged campaign or causal subtraction across collections. All workers joined,
quiet/golden/exit/SHAarchive/fixture teardown pass;254/252MiBfloors intact. Only an
exact committed raw observation replica retired under fresh path/UID/hash/link/
all-alias proof; current images/catalogs/toolchains/unmatched evidence retained.
Normal optional adapter0.4unchanged; publication postponed; wider roadmap active.

[Decision](decision.json),[confirmation](summary.json),[raw](observations.tgz),
[custody](archive-receipt.json),[checks/procedures](procedures-and-checks.tar.xz),
[original sources/allocation/failed conditions](../initial/README.md).
''',encoding='utf-8',newline='\n')
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');old='private drain stays funded through output admission and completion. Join retains';assert old in s
s=s.replace(old,'private drain stays funded through output admission and completion. Known sequence\nsizes admit initial working capacity once; iteration still observes mutations\nduring host admission and funds replacement overlap on growth. Conservative size\nhints can refuse before enumeration. Join retains');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');needle='| Direct split construction |';assert needle in s
s=s.replace(needle,'| Known-size working drains | Helper-list text allocation7.11% lower; original/nontext effectively flat | Separatea71abfed versus2ede09fc pair; elapsed/CPU gains inconclusive, adverse first collection retained. Focused checks pass; full delivery pending. [Evidence](../benchmarks/results/2026-11-18-known-drain-construction/confirmation/README.md). |\n'+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');s=s.replace('# Testing Lython\n','# Testing Lython\n\n[Known-size drains](Lokad.Lython.Tests/KnownDrainOwnershipTests.cs) preserve live\nsource changes during admission, aliases, underestimated hints, bounded consumers\nand refusal before enumeration. Scratch stays funded until cleanup; the shared\nallowance is reusable afterward. Existing asynchronous drain cleanup checks apply.\n',1);p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','## 0.11.0 - Unreleased\n\n- Admit known-size iterator working capacity once, preserving live iteration,\n  replacement overlap, cancellation and cleanup. Conservative hints can reject\n  earlier; initial backing and lease construction share rollback protection.\n',1);p.write_text(s,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

R515/B943 [unchanged confirmation and retention](results/2026-11-18-known-drain-construction/confirmation/README.md), threejobs142.33s/8s warmup/opposite roles: original−1.24..+1.38%elapsed/CPUstraddleszero, helper−2.00..+2.11%elapsed/CPU+.03..+1.75, floating−.83..+3.88%elapsed/CPUstraddleszero; candidate spreads2.63/3.67/4.18%. No consistent CPU gain. Retain capacity-level lifecycle reduction/helperallocation7.110%/helperreport1.542% independently, accept unresolved CPU variability/debt for next helper checkpoint; originaladversity kept, no thirdunchangedcampaign. All587production inputs match measureda71;74internal/73public both targets/13goldens/reuse plus actual4case32filechecks pass. Full delivery batched at next runtime boundary, not inherited. Core remainsmanaged/admission/cancellation/cleanup intact; normaladapter0.4/publicationheld.
''')
print('R515 integrated with exact587 production source proof; allocation benefit retained, CPU uncertainty explicit, full qualification batched.')
