from pathlib import Path
import ast,hashlib,io,json,tarfile,subprocess
r=Path(__file__).resolve().parent;old=r/'quiet';q=r/'confirmation';q.mkdir(exist_ok=False);repo=Path('D:/code/Lython')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
canonical='benchmarks/results/2026-11-18-known-drain-construction/initial/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='confirmation/confirmation.json'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
proof=dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,paths=['known-drain-b942-20261118/'+member],links=1)
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['purpose']='One unchanged original/helper/floating confirmation afterB942original adverseCPU/helper3.70reference spread/floating4.21candidate spread.8second rotated warmups/opposite preparation roles; allocation7.110percent helper benefit separate. Preserve original adversity, no causal subtraction or CPU forecast.';(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.helper-list','warm'],['scripts.numeric-squared-error.floating.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('accumulate6seconds','accumulate8seconds').replace('warmupSeconds=6','warmupSeconds=8').replace('while min(warmed)<6:','while min(warmed)<8:').replace('if warmed[i]>=6:continue','if warmed[i]>=8:continue').replace("labels=['candidate','reference','candidate-control','reference-control']","labels=['reference','candidate','reference-control','candidate-control']").replace('if job_index >= 2: labels.reverse()','if job_index % 2 == 1: labels.reverse()')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace('jobs=4','jobs=3');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/known-drain-confirm-b943-20261118';unit='lython-b943-known-drain-confirm-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n');names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['candidate'],sourceCatalogSHA256=previous['catalogSHA256'],catalogSHA256=previous['catalogSHA256'],identity=identity,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s='\n'.join(line for line in s.splitlines()if"t.extractfile('representative.json')"not in line)+'\n'
s=s.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')"," os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n os.link(source/'representative.json',root/'representative.json')").replace('lython-b942-fixtures','lython-b943-fixtures')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'confirmation'").replace('Four-job known-size drain source pair','Three-job unchanged known-drain confirmation');(r/'launch-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==3").replace('B942','B943');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'confirmation/retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace("r/'summary.json'","r/'confirmation-summary.json'").replace("r/'allocation-summary.json'","r/'confirmation-allocation-summary.json'");(r/'summarize-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
for p in q.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Three jobs,8second warmups/opposite preparation roles; exact same32-file images/catalog, no repeated correctness or allocation qualification. Exact committed raw replica retirement freshly revalidated on staging.')
