set -eu
root=/home/lokad/lython-bench-checks/prepared-format-keywords-b1189-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
