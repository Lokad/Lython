set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$PWD/.git/agent-notes/review-20261031/prepared-format-keywords
cd .git/agent-worktrees/prepared-format-keywords
filter='(FullyQualifiedName~Format|FullyQualifiedName~CompilerCancellationTests|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/linux" --filter "$filter" >"$log" 2>&1 || { tail -n 55 "$log"; exit 1; }
    tail -n 8 "$log"
done
