from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
helper=lab.parent/'executable-lambda-binding/managed-retention/bin/Release/net11.0'
if not (helper/'ManagedRetention.dll').is_file():
    candidates=list((lab.parent/'executable-lambda-binding/managed-retention/bin').rglob('ManagedRetention.dll'))
    assert len(candidates)==1
    helper=candidates[0].parent
load=lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
identity=load(lab/'frozen-identity.json')
manifest=lab/'catalog.json'
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'],DOTNET_TieredCompilation='0')
for role, expected in identity['images'].items():
    image=lab/'frozen'/role
    assert {name:sha(image/name) for name in expected}==expected
    for name in ('ManagedRetention.dll','ManagedRetention.deps.json','ManagedRetention.runtimeconfig.json'):
        shutil.copyfile(helper/name,image/name)
    for rep in (1,2):
        path=lab/f'{role}-retention-{rep}.json'
        with path.open('xb') as logfile:
            subprocess.run([sdk/'dotnet.exe',image/'ManagedRetention.dll',manifest],env=env,stdout=logfile,check=True,timeout=130)
        result=load(path)
        assert result['coreSha256']==expected['Lokad.Lython.dll']
        assert all(row['sharedBudgetBaselineRestored'] for row in result['rows'])
    assert {name:sha(image/name) for name in expected}==expected
rows=[]
for rep in (1,2):
    ref, cand=[load(lab/f'{role}-retention-{rep}.json')['rows'] for role in ('reference','candidate')]
    for before, after in zip(ref,cand,strict=True):
        assert before['id']==after['id']
        for metric in ('liveBytes','allocatedBytes'):
            a,b=[statistics.median(row[metric]) for row in (before,after)]
            row=dict(repetition=rep,case=before['id'],metric=metric,referenceBytes=a,candidateBytes=b,
                     changePercent=100*(b/a-1))
            rows.append(row)
            print(rep, before['id'], metric, a,b,f'{row["changePercent"]:+.2f}%',flush=True)
(lab/'retention-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
