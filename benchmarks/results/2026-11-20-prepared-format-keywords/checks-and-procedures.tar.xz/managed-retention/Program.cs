using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;

using var input = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
var rows = new List<object>();
foreach (var item in input.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    for (var warmup = 0; warmup < 8; warmup++) Compile().Dispose();
    var liveBytes = new double[5];
    var allocatedBytes = new double[liveBytes.Length];
    for (var round = 0; round < liveBytes.Length; round++)
    {
        const int count = 64;
        var live = new LythonCompiledScript[count];
        var before = GC.GetTotalMemory(forceFullCollection: true);
        var beforeAllocation = GC.GetAllocatedBytesForCurrentThread();
        try
        {
            for (var i = 0; i < count; i++) live[i] = Compile();
            allocatedBytes[round] = (GC.GetAllocatedBytesForCurrentThread() - beforeAllocation) / (double)count;
            var after = GC.GetTotalMemory(forceFullCollection: true);
            liveBytes[round] = (after - before) / (double)count;
        }
        finally
        {
            foreach (var compiled in live) compiled?.Dispose();
            Array.Clear(live);
        }
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation allowance was not restored.");
    }
    rows.Add(new { id, liveBytes, allocatedBytes, sharedBudgetBaselineRestored = budget.ReservedBytes == 0 });

    LythonCompiledScript Compile()
    {
        var script = engine.Compile(source, budget);
        if (script.IsValid) return script;
        script.Dispose();
        throw new InvalidOperationException(string.Join('\n', script.Diagnostics));
    }
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(),
    sdk = Environment.Version.ToString(),
    boundary = "Standalone process. 8 warmups and 5 groups of 64 live compiled scripts using the same source. Full collection before and after for a diagnostic managed live-byte estimate. No execution or timing.",
    rows
}));
