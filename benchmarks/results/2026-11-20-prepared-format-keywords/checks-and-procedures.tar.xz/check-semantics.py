from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'mixed-position-and-order': "print('{1}:{name!r}:{0}:{word}'.format('first','second',word='γ',name='β'))", 'nested-width-and-unicode-key': "print('{Début:🟩>{width}d}|{last:λ^{width}d}'.format(last=4,width=6,Début=9))", 'format-bound-alias-and-expanded-keywords': "t='{name}:{count}'\nf=t.format\nfields={'name':'é','count':7}\nprint(f(count=8,name='β'), t.format(**fields), f(**fields))\n", 'guest-method-named-format': "class Message:\n    def format(self, *, name, value):\n        return name,value\nprint(Message().format(value=5,name='field'))\n", 'fields-after-callback-and-error-order': "events=[]\nclass Value:\n    def __format__(self,spec):\n        events.append(spec)\n        return 'value'\ntry:\n    '{x:tag}:{missing}'.format(x=Value())\nexcept KeyError as error:\n    print(error.args, events)\nprint('{x:more}:{y[name]}'.format(y={'name':'done'},x=Value()),events)\n"}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'lexical-annotation-boundary/probe-build/bin/LythonProbe/release_net11.0'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
