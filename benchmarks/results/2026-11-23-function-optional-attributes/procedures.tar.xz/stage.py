
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prev=lab.parent/"csv-literal-field-scan-20261122"/"comparison"
out=lab/"refined-comparison"
quiet=out/"quiet"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,value):write(p,json.dumps(value,indent=2)+"\n")
def committed(name):return git("show","origin/master:benchmarks/results/2026-11-22-csv-literal-field-scan/"+name)

p=read(prev/"quiet/config.json")
receipt=json.loads(committed("archive-receipt.json"))
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(committed("observations.tgz"))==receipt["archiveSHA256"]
prior=json.loads(committed("source.json"))
assert p["identity"]["imageFiles"]==prior["imageFiles"]
before=read(out/"identity.json")
assert before["imageFiles"]["reference"]==prior["imageFiles"]["reference"]
tree=repo/".git/agent-worktrees/function-optional-attributes-20261122"
candidate=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert candidate.startswith("1a8aefaff") and not git("status","--porcelain",cwd=tree)
patch=git("diff","--binary",before["patchBase"],candidate,"--","src","tests",cwd=tree)
assert sha(patch)==before["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
files=before["imageFiles"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
catalog=out/"representative.json"
ids=[r["id"]for r in read(catalog)["cases"]]
jobs=[(ids[0],"warm"),(ids[0],"compile-run")]+[(case,"warm")for case in ids[1:6]]
assert len(jobs)==len(ids)==7
save(out/"jobs.json",jobs)
for role in files:
    assert len(files[role])==32 and {n:h(out/f"frozen-{role}"/n)for n in files[role]}==files[role]
    proof=read(out/f"{role}-verify.json")
    assert proof["catalogSha256"]==h(catalog) and proof["state"]=="Completed" and proof["caseCount"]==len(ids)
old=gzip.decompress(committed("candidate-core.dll.gz"))
assert sha(old)==prior["imageFiles"]["candidate"][core]
assert sha(old) not in {m[core]for m in files.values()}
old_name=Path(p["root"]).name
retire=[dict(paths=[old_name+"/candidate/"+core],bytes=len(old),sha256=sha(old),links=1,
             archives={old_name+"/observations.tgz":receipt["archiveSHA256"]})]
before.update(sourceRevision=before["reference"]+" versus "+candidate,candidate=candidate,testedRevision=candidate,
    purpose="Move optional attributes off ordinary function objects. Keep a single dictionary or type-parameter tuple in its existing owner.",
    normalAdapterPin="0.4.0",coreSHA256={role+suffix:m[core]for role,m in files.items()for suffix in ("","-control")},
    catalogs={"representative.json":{"sha256":h(catalog)}})
root="/home/lokad/lython-bench-checks/function-optional-attributes-b1425-20261123"
unit="lython-b1425-function-optional-attributes-20261123"
quiet.mkdir()
save(quiet/"identity.json",before)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir()
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(prev/"quiet"/leaf).read_text(encoding="utf-8").replace(p["root"],root).replace(p["unit"],unit)
    if leaf=="collect.py":
        a,b=code.index("\njob_catalog ="),code.index("\nassert len(jobs)")
        code=code[:a]+"\njob_catalog = "+repr({id:"representative.json"for id,_ in jobs})+"\njobs = "+repr(jobs)+code[b:]
    write(quiet/leaf,code.replace("Literal CSV field scan","Function optional metadata"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for n in parts:bundle.add(quiet/n,arcname=n)
cfg={**p,"root":root,"unit":unit,"identity":before,"source":p["root"],"sourceRole":"reference",
     "sourceFiles":prior["imageFiles"]["reference"],"sourceCatalogSHA256":prior["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":receipt["archiveSHA256"],"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
code=(prev/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=code.index("\nc=")+1,code.index("\nb=Path(")
write(quiet/"remote-launch.py",(code[:a]+"c="+repr(cfg)+code[b:]).replace("b1424-fixtures","b1425-fixtures"))
write(out/"launch.py",(prev/"launch.py").read_text(encoding="utf-8").replace("Literal CSV field scan","Function optional metadata"))
write(out/"summarize.py",(prev/"summarize.py").read_text(encoding="utf-8"))
print(candidate,root,cfg["unpackedBytes"],flush=True)

