from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"immediate-definition-depth-20261122"/"comparison"
base=lab.parent/"csv-literal-field-scan-20261122"/"comparison"
out=lab/"comparison"
out.mkdir()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(path):return sha(path.read_bytes())
def digest(s):return sha(s.encode("utf-8"))
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args,cwd=repo):return subprocess.check_output(["git",*args],cwd=cwd)
def catalog_archive(dirname):
    folder=f"benchmarks/results/{dirname}/"
    receipt=json.loads(git("show","origin/master:"+folder+"archive-receipt.json"))
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
    archive=repo/(folder+"observations.tgz")
    assert h(archive)==receipt["archiveSHA256"]
    with tarfile.open(archive) as tar:
        return json.load(tar.extractfile("representative.json"))

original=read(prior/"representative.json")
controls=catalog_archive("2026-11-21-direct-function-override-admission")
sources={row["id"]:row for row in original["cases"]+controls["cases"]}
postponed="scripts.annotated-rule-closures.nested-factories.postponed"
eager="scripts.annotated-rule-closures.nested-factories"
wrapper="scripts.factory-wrapper-metadata"
dict_only="scripts.factory.custom-dictionary"
generics="scripts.factory.generic-metadata"
helper="scripts.ordinary-fully-supplied-helper"
invoice="scripts.csv-invoice.method-policy.quoted-control"
def make_case(id,source,expected):
    fixture='{"size":2048,"text":null}'
    return dict(id=id,family="scripts",category="whole-script",scale="medium",size=2048,
        source=source,fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(source.encode("utf-8")),
        expectedOutputUtf8Bytes=len(expected.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
        sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(expected))
sources[dict_only]=make_case(dict_only,"""def factory(tag):
    def f(value):
        return value
    f.tag = tag
    assert f.__dict__ is f.__dict__
    return f

total = 0
for i in range(2048):
    f = factory(i)
    total += f.tag
print(total, f(197))
""","2096128 197\n")
sources[generics]=make_case(generics,"""def factory():
    def f[T](value: T) -> T:
        return value
    return f

total = 0
for i in range(2048):
    f = factory()
    total += f(i)
assert len(f.__type_params__) == 1
print(total, f.__type_params__[0].__name__)
""","2096128 T\n")
ids=[postponed,eager,wrapper,dict_only,generics,helper,invoice]
catalog=out/"representative.json"
save(catalog,{**original,"performanceQualified":False,"cases":[sources[id]for id in ids]})
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
identity=read(base/"identity.json")
files=identity["imageFiles"]["reference"]
core="Lokad.Lython.dll"
ref=base/"frozen-reference"
assert len(files)==32 and {n:h(ref/n)for n in files}==files and h(protocol)==identity["protocolSHA256"]
cand=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
tree=repo/".git/agent-worktrees/function-optional-attributes-20261122"
head=git("rev-parse","HEAD",cwd=tree).decode().strip()
assert head==identity["reference"]
patch=git("diff","--binary","HEAD","--","src","tests",cwd=tree)
assert patch.count(b"diff --git ")==2
(out/"source.patch").write_bytes(patch)
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
images={}
results={}
for role in ("reference","candidate"):
    image=out/f"frozen-{role}"
    image.mkdir()
    manifest={**files,core:h(cand)} if role=="candidate" else files
    for n in manifest:shutil.copyfile(cand if n==core and role=="candidate" else ref/n,image/n)
    assert manifest=={n:h(image/n)for n in manifest}
    images[role]=manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/n,image/n)
    receipt=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,cwd=repo,check=True,timeout=85)
    check=read(receipt)
    assert check["state"]=="Completed" and check["caseCount"]==len(ids) and check["catalogSha256"]==h(catalog)
    report=out/f"{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==len(ids) and all(row["sharedBudgetBaselineRestored"] for row in rows)
    results[role]=rows
    assert manifest=={n:h(image/n)for n in manifest}
save(out/"identity.json",dict(reference=head,patchBase=head,imageFiles=images,
    protocolSHA256=h(protocol),catalogSHA256=h(catalog),sourcePatchSHA256=h(out/"source.patch")))
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"],a,b,b-a,round(100*(b/a-1),3),before["peakExecutionMemoryBytes"],after["peakExecutionMemoryBytes"],flush=True)
