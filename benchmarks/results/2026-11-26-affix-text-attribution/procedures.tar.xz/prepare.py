from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
trial=lab.parent/'direct-affix-return-20261126'
original=trial/'comparison/quiet'
template=lab.parent/'file-processing-profile-20261126'
quiet=lab/'comparison/quiet';quiet.mkdir(parents=True,exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,doc):write(p,json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(); assert source.startswith('264a1176f')
snapshot=read(original/'identity.json')
delta=subprocess.check_output(['git','diff','--binary',snapshot['sourceRevision'],source,'--','src'],cwd=repo)
assert delta==(trial/'candidate.patch').read_bytes() and hashlib.sha256(delta).hexdigest()==snapshot['sourcePatchSHA256']
for role,files in snapshot['imageFiles'].items(): assert len(files)==32 and {p.name:sha(p)for p in (trial/role).iterdir()}==files
receipt=read(original/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(original/'observations.tar.xz')==receipt['archiveSHA256']
# Failed staging kept a separately uploaded copy of the exact candidate core.
# The valid immutable VM image and locally frozen image preserve its content.
failed=trial/'first-launch'
failed_receipt=read(failed/'terminal-status.json')['receipt']
assert not failed_receipt['complete'] and sha(failed/'observations.tar.xz')==failed_receipt['archiveSHA256']
catalog=read(original/'representative.json')
report='diagnostic.text-summary.nonlocal-computed-width.large'
catalog['cases']=[case for case in catalog['cases'] if case['id']==report]
assert len(catalog['cases'])==1
save(quiet/'catalog.json',catalog)
identity=dict(sourceRevision=source,comparisonRevision=snapshot['sourceRevision'],imageFiles=snapshot['imageFiles'],
    coreSHA256={role:files['Lokad.Lython.dll']for role,files in snapshot['imageFiles'].items()},
    profileCatalogSHA256=sha(quiet/'catalog.json'), profiles=[['unicode-reference',report,'reference'],
      ['unicode-candidate',report,'candidate']],donorArchiveSHA256=receipt['archiveSHA256'],
    purpose='Assess text CPU difference after exact string affix return using a bounded paired attribution.')
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
 s=(template/'comparison/quiet'/name).read_text(encoding='utf-8-sig')
 s=s.replace('native-cursor-stack-b1743-20261126','direct-affix-return-b1746b-20261126').replace('b1745-fixtures','b1748-fixtures')
 if name=='collect.py':s=s.replace('assert digest(image.parent/\'observations.tar.xz\')', 'assert digest(root.parent/"direct-affix-return-b1746b-20261126"/\'observations.tar.xz\')')
 if name=='analyze.py':s=s.replace("label=='unicode-report'", "label.startswith('unicode-')")
 if name.endswith('.py'):compile(s,name,'exec')
 write(quiet/name,s)
assert b'\r' not in (quiet/'run.sh').read_bytes()
s=(template/'quiet.py').read_text(encoding='utf-8-sig').replace('lython-b1745-file-processing-profile-20261126','lython-b1748-affix-text-profile-20261126')
s=s.replace(" donor=base/'native-cursor-stack-b1743-20261126'", " donor=base/'direct-affix-return-b1746b-20261126'")
a=" assert {p.name:sha(p) for p in frozen.iterdir()}==image['imageFiles']['candidate'] and len(image['imageFiles']['candidate'])==32"
assert a in s
s=s.replace(a,""" for role,files in image['imageFiles'].items():
  assert len(files)==32 and {p.name:sha(p) for p in (donor/role).iterdir()}==files
 failed=base/'direct-affix-return-b1746-20261126'
 retired=failed/'candidate'/'Lokad.Lython.dll'
 if retired.is_file():
  assert retired.resolve()==retired and retired.is_relative_to(base) and retired.stat().st_nlink==1
  prior=json.loads((failed/'archive-receipt.json').read_text())
  assert not prior['complete'] and not (failed/'guest-fixtures').exists()
  assert prior['archiveSHA256']==cfg['failedArchiveSHA256'] and sha(failed/'observations.tar.xz')==prior['archiveSHA256']
  assert sha(retired)==image['coreSHA256']['candidate']
  first=shutil.disk_usage(base).free
  retired.unlink()
  print(json.dumps(dict(retiredVerifiedDuplicate=retired.name,freeBefore=first,freeAfter=shutil.disk_usage(base).free)),flush=True)
""".rstrip())
s=s.replace('RuntimeMaxSec=155','RuntimeMaxSec=130').replace('seconds=110','seconds=85')
compile(s,'quiet.py','exec');write(lab/'quiet.py',s)
worker=repo/'benchmarks/cpython-worker.py'
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in identity['imageFiles'].items():
 verified=quiet/f'{role}-verification.json'; image=trial/role
 subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
  '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',verified],cwd=repo,env=env,check=True,timeout=60)
 v=read(verified); assert v['state']=='Completed' and v['caseCount']==1 and v['catalogSha256']==identity['profileCatalogSHA256']
 assert v['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
 for name in ('collect.py','ops-profile.py','run.sh','catalog.json','identity.json'):
  archive.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='affix-text-profile-b1748-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expectedDonorArchiveSHA256=receipt['archiveSHA256'],failedArchiveSHA256=failed_receipt['archiveSHA256']))
