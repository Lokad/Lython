from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
dest=Path('benchmarks/results/2026-11-07-regex-dev54');dest.mkdir(exist_ok=True)
q=json.loads((r/'qualification.json').read_text(encoding='utf-8'))
for name in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
    for target in ['net11.0','net10.0']:
        assert q['checks'][name+'-'+target]['passed']==(86 if name=='Lokad.Lython.Tests' else 514)
for name,entry in q['identity']['packages'].items():assert hashlib.sha256((r/'feed'/name).read_bytes()).hexdigest()==entry['sha256']
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()=='aa133dcbb1c70bddc3339d09085a53785f789582cf39ff83c883d26f8ef4f20e'
for name in ['qualification.json','identity.json','Utf8RegexProvider.cs','CursorAdmissionTests.cs','Directory.Build.props','Directory.Packages.props','NuGet.Config','qualify.py']:
    shutil.copyfile(r/name,dest/name)
with tarfile.open(dest/'observations.tgz','w:gz') as t:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.log','.json','.xml','.cs','.props','.Config','.py']:t.add(p,arcname=p.name)
    t.add(r/'locks',arcname='locks')
receipt=dict(archiveSHA256=hashlib.sha256((dest/'observations.tgz').read_bytes()).hexdigest(),
    normalCoreUnchanged=True,productionPinUnchanged='0.4.0',developmentOnly=True,finalReleasedAdapterQualified=False,performanceMeasured=False,
    producerPackages=q['identity']['packages'])
(dest/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(dest/'README.md').write_text('''# Immutable development adapter snapshot — R59

2026-11-07. Current Lython sourcee66b8f72, producer0.5.0-dev.54 at
553acbdfc895d993416e3bad3af47c468a181148. The immutable Core/PythonRe packages
were copied and checked by SHA256 and nuspec repository commit; PythonRe pins
exact Core0.5.0-dev.54. The dirty sibling worktree was neither built nor consumed.
Private isolated outputs, assets, locks/feed/package cache reuse the existing
dev.48 Lython adapter and native cursor allowance bridge **byte for byte**.
No new framework, production API, normal package pin or lockfile change.

**86internal and514public focused Release checks pass per actual.NET11/10.**
Regex, fnmatch/glob, flags/constant analysis, captures/offsets/replacements/errors,
cache ownership/current tokens and cleanup remain. Cursor-specific checks refuse
actual native growth, preserve program funding, reuse the working allowance,
exercise many matches within bounded live capacity and switch caller tokens.
Loaded core/adapter/producer hashes and build/test logs are retained. Normal
production coreaa133dcb and optional0.4 pin remain unchanged.

| Required boundary | dev.54 capability / remaining bridge |
| --- | --- |
| Native UTF-8 patterns, windows and byte-range captures | Available; current Lython contract unchanged |
| Native cursor working owner | Available; existing IUtf8MemoryAllowance bridge remains outside core; refusal throws terminally rather than making storage optional |
| Separate single-match preparation/working owner | DetailedData overloads still accept no distinct working owner; conservative adapter funding remains |
| Enumerate native capture names | UTF-8 lookup exists; enumeration still uses GetGroupNames and adapter-local encoding |
| Creation versus each move's cancellation | Current-token MoveNext overloads exist, but creation retains its invocation token; stable adapter token/forwarding bridge remains necessary for independent callers |

No producer API difference requires new Lython plumbing or a source/performance
redesign here. **This is development contract/semantic compatibility, not final
released-adapter or managed-safety certification.** No backend performance
comparison or speedup is claimed, and producer timings are not Lython timings.
An adapter promotion remains tied to an immutable supported released input and
its separate final qualification. Missing producer APIs/publication block neither
core architecture nor independent performance development. Core has no Utf8Regex
runtime dependency; the optional adapter remains nonpackable.

[Identity](identity.json), [qualified loaded files/counts](qualification.json),
[exact bridge source](Utf8RegexProvider.cs), [native ownership checks](CursorAdmissionTests.cs),
[isolated build recipe](qualify.py), [raw logs/XML/locks](observations.tgz),
[receipt/package hashes](archive-receipt.json). No producer packages are republished.
''',encoding='utf-8')
history=Path('benchmarks/EXPERIMENTS.md')
history.write_text(history.read_text(encoding='utf-8')+'''
## Immutable development regex snapshot (2026-11-07)

[R59](results/2026-11-07-regex-dev54/README.md): exact0.5.0-dev.54/553acbdf,
unchanged existing development cursor bridge, isolated outputs/feed/locks;
86internal/514public per actual11/10 pass. Native working-owner cursor remains
usable; DetailedData owner, native name enumeration and creation/current-token
separation still need bridges. Normal0.4pin/core unchanged; no final released
qualification, backend performance or safety certification inferred. Producer
publication does not block core work. No sibling source edits/builds.
''',encoding='utf-8')
plan=Path('PLAN.md');text=plan.read_text(encoding='utf-8')
a=text.index('## Following R59');b=text.index('## Following redesign roadmap',a)
text=text[:a]+'''## R59 — immutable development adapter compatibility complete

Exact unpublished0.5.0-dev.54/553acbdf, copied packages and nuspec/SHA verification;
existing dev.48 bridge reused unchanged in isolated outputs/feed/assets/locks.
86internal/514public per actual11/10 pass; native refusal/current tokens/bounded
working capacity/retained program ownership/reuse remain. Normal0.4pin/core unchanged.
DetailedData still lacks separate working-owner preparation, UTF-8 name lookup
lacks enumeration, creation retains its token despite per-move token overloads.
Keep adapter-local bridges; no new source/performance redesign justified here.
Development contract/semantic compatibility is separate from final released
adapter, managed-safety and backend performance qualification. No speedup claim.
[Evidence](benchmarks/results/2026-11-07-regex-dev54/README.md). Return to runtime roadmap.

'''+text[b:]
text=text.replace('Supplied\nproducer6032b928/dev51 still requires adapter-local bridges/conservative funding.', 'Exact development producer553acbdf/dev54 passes the current bridge tests but\nstill requires adapter-local bridges/conservative funding; final released input\nand backend performance remain separately unqualified.')
text=text.replace('First status no earlier than 2026-11-07T19:14:33.472770+00:00; no tight polling.', 'CI42404834827 in progress at19:15:09Z; next status≥19:20:09Z, no tight polling.')
plan.write_text(text,encoding='utf-8')
print(json.dumps(receipt))
