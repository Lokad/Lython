#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython/.git/agent-notes/review-20261031/current-regex-cpython-b1985-20261128/comparison/quiet
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
export DOTNET_ROOT="$HOME/.dotnet"
"$DOTNET_ROOT/dotnet" "$root/local-image/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" --out "$root/candidate-local-verify.json"