from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / 'ownership-cpython-b1963-20261128'
old = previous / 'comparison/quiet'
matched = lab.parent / 'deferred-starmap-row-b1980-20261128/comparison'
donor = matched / 'quiet'
quiet = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
stage = 'script-regex-cpython-b1985-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
hash_image = lambda path: {p.name: digest(p) for p in path.iterdir()}


def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()


def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')


def git(*args):
    return check_output(['git', *args], cwd=repo)


head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('a1a9ee4a4') and not git('status', '--porcelain')
identity = read(donor / 'identity.json')
patch = git('diff', '--binary', identity['referenceRevision'], 'HEAD', '--', 'src', 'tests')
snapshot = (matched.parent / 'candidate.patch').read_bytes()
assert sha256(snapshot).hexdigest() == identity['sourcePatchSHA256']
tracked = git('diff','--binary',identity['referenceRevision'],'HEAD','--','src')
assert tracked == snapshot[:snapshot.index(b'diff --git a/tests/')]
terminal = read(donor / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor / 'observations.tar.xz') == receipt['archiveSHA256']
image = identity['imageFiles']['candidate']
assert len(image) == 32 and hash_image(matched / 'candidate') == image

quiet.mkdir(parents=True)
frozen = quiet / 'local-image'
copytree(matched / 'candidate', frozen)
assert hash_image(frozen) == image
assert all(not p.samefile(matched / 'candidate' / p.name) for p in frozen.iterdir())
assert digest(donor / 'representative.json') == identity['catalogs']['representative.json']['sha256']
catalog = read(lab.parent/'current-regex-attribution-b1984-20261128/comparison/quiet/representative.json')
jobs = [
    ['scripts.regex-log-search.compiled', 'warm'],
    ['scripts.regex-log-search.module', 'warm'],
]
case_by_id = {row['id']: row for row in catalog['cases']}
catalog['cases'] = [case_by_id[case_id] for case_id, _ in jobs]
assert len(catalog['cases']) == 2
write(quiet / 'representative.json', catalog)
copy2(donor / 'cpython-worker.py', quiet / 'cpython-worker.py')
copy2(old / 'run.sh', quiet / 'run.sh')
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
write(quiet / 'jobs.json', jobs)
write(quiet / 'identity.json', dict(sourceRevision=head, productionHead=head,
    purpose='Refresh compiled and module-level regex log scans with the signed PythonRe producer.',
    imageFiles={'candidate': image}, coreSHA256={role: image[core] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: checksum for name, checksum in image.items() if name != core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=identity['expectedCPythonSHA256'], cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'], measuredCorePatchSHA256=identity['sourcePatchSHA256']))
collector = (old / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 7') == collector.count('lython-b1963-cpython-fixtures') == 1
save(quiet / 'collect.py', collector.replace('len(jobs) == 7', 'len(jobs) == 2')
     .replace('lython-b1963-cpython-fixtures', 'lython-b1985-regex-fixtures'))
paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json',
    'cpython-worker.py', 'run.sh', 'collect.py')}
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'upload.json')['root'], donorFiles=image,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()), minimumAfterStageBytes=5*1024*1024, caseCount=2))
launch = (previous / 'quiet-vm.py').read_text(encoding='utf-8')
save(lab / 'quiet-vm.py', launch.replace('lython-b1963-ownership-cpython', 'lython-b1985-regex-cpython')
     .replace('RuntimeMaxSec=535', 'RuntimeMaxSec=230'))
verify = (previous / 'verify.sh').read_text(encoding='utf-8')
save(lab / 'verify.sh', verify.replace(previous.name, lab.name))
summary = (previous / 'summarize.py').read_text(encoding='utf-8')
save(lab / 'summarize.py', summary.replace('0b50e6fda5f9ac8fa994ee08ca67da306b813a40', head)
     .replace('len(raw["jobs"])==7','len(raw["jobs"])==2').replace('receipt["warmJobs"]==7','receipt["warmJobs"]==2').replace('==196', '==56').replace('["caseCount"]==5', '["caseCount"]==2')
     .replace('{"donor":31}', '{"donor":32}').replace('16*1024*1024', '5*1024*1024'))
print(head, len(jobs), 'quiet lanes with two expected output and file goldens')