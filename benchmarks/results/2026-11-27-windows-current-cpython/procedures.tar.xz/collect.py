from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_bytes())
hash_file=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,data):p.write_text(json.dumps(data, indent=2)+'\n',encoding='utf-8',newline='\n')
new=notes/'ordinary-static-call-prefix-20261127/comparison/local'
old=notes/'csv-dictwriter-native-validation-20261127/comparison/quiet-cpython'
json_lab=notes/'json-eager-traversal-20261127/comparison/local'
original=notes/'post-ready-insertion-cpython-20261127/comparison/quiet'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('18c82c45f') and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
new_id=read(new/'identity.json')
old_id=read(old/'identity.json')
patch=subprocess.check_output(['git','diff','--binary',new_id['productionReference'],head,'--','src'],cwd=repo)
assert sha256(patch).hexdigest()==new_id['sourcePatchSHA256']
old_head=subprocess.check_output(['git','rev-parse','6e59cd41e'],cwd=repo,text=True).strip()
prior_patch=subprocess.check_output(['git','diff','--binary',old_id['sourceRevision'],old_head,'--','src'],cwd=repo)
assert sha256(prior_patch).hexdigest()==old_id['sourcePatchSHA256']
def snapshot(folder):
    return {p.name:hash_file(p) for p in folder.iterdir()}
for label,base,identity in [('reference',old.parent/'local',old_id),('candidate',new,new_id)]:
    assert snapshot(base/'candidate')==identity['imageFiles']['candidate'] and len(identity['imageFiles']['candidate'])==32
    shutil.copytree(base/'candidate',lab/label)
    assert snapshot(lab/label)==identity['imageFiles']['candidate']

folders=(old,json_lab,original)
manifests=[]
for base in folders:
    identity=read(base/'identity.json')
    catalog=base/'representative.json'
    assert hash_file(catalog)==identity['catalogs']['representative.json']['sha256']
    manifests.append(read(catalog))
catalog=manifests[0]
cases={c['id']:c for manifest in manifests for c in manifest['cases']}
csv='diagnostic.shipment-dictwriter-report'
export='diagnostic.json-lines-shipment.default-export-768'
ordinary='diagnostic.generated-ordinary-definitions'
text='diagnostic.text-summary.nonlocal-computed-width.large'
catalog['cases']=[cases[name] for name in (csv,export,ordinary,text)]
path=lab/'representative.json'
write(path,catalog)
sdk=Path.home()/'.dotnet11'
python=Path('C:/Python313/python.exe')
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
protocol=new/'cpython-worker.py'
assert hash_file(protocol)==new_id['cpythonWorkerSHA256']==old_id['cpythonWorkerSHA256']
image=lab/'candidate/Lokad.Lython.Benchmarks.dll'
reference=lab/'reference/Lokad.Lython.Benchmarks.dll'
base=[dotnet,image,'--compare']
options=['--catalog',path,'--dotnet',dotnet,'--python',python,'--python-worker',protocol]
write(lab/'identity.json',dict(candidate=head,reference=old_head,catalogSHA256=hash_file(path),
    imageFiles={r:snapshot(lab/r) for r in ('reference','candidate')},cpythonWorkerSHA256=hash_file(protocol),
    cpythonSHA256=hash_file(python),cpythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),
    dotnetSHA256=hash_file(dotnet),performanceQualified=False))
with tempfile.TemporaryDirectory(prefix='lython-b1878-',dir=lab) as scratch:
    staging=dict(env,TEMP=scratch,TMP=scratch,TMPDIR=scratch)
    for label,worker in [('candidate',image),('reference',reference)]:
        report=lab/f'{label}-verify.json'
        subprocess.run([dotnet,worker,'--compare','verify',*options,'--out',report],cwd=scratch,env=staging,timeout=60,check=True)
        proof=read(report)
        assert proof['state']=='Completed' and proof['caseCount']==4 and proof['catalogSha256']==hash_file(path)
        assert proof['launched']['library']['sha256']==hash_file(worker.parent/'Lokad.Lython.dll')
    jobs=[(csv,'warm'),(export,'warm-async'),(ordinary,'compile'),(text,'warm'),(export,'warm'),(ordinary,'compile-run')]
    write(lab/'jobs.json',jobs)
    for case,lane in jobs:
        report=lab/(case+'.'+lane+'.json')
        subprocess.run([*base,'micro',*options,'--baseline-worker',reference,'--case',case,'--lane',lane,'--out',report],
                       cwd=scratch,env=staging,timeout=30,check=True)
        receipt=read(report)
        assert receipt['state']=='Completed' and receipt['catalogSha256']==hash_file(path) and not receipt['performanceQualified']
        assert receipt['lane']==lane
        print(case,lane,receipt['summaries'],flush=True)
assert snapshot(lab/'candidate')==new_id['imageFiles']['candidate']
assert snapshot(lab/'reference')==old_id['imageFiles']['candidate']
print('All comparisons complete and worker images reverified.',flush=True)
