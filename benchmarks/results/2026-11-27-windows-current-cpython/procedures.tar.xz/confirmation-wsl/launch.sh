#!/bin/bash
set -euo pipefail
cd "$(dirname -- "$0")"
flock -n ./collection.lock timeout --signal=TERM 275s taskset -c 27 bash ./run.sh
