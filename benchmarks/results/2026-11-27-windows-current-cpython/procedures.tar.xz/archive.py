from collections import Counter
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
confirmation=lab/'confirmation-wsl'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,data):p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=read(lab/'identity.json')
assert all({p.name:digest(p) for p in (lab/role).iterdir()}==files
           for role,files in identity['imageFiles'].items())
assert not list(lab.glob('lython-b1878-*'))
jobs=read(lab/'jobs.json')
windows=[]
receipts={}
for case,lane in jobs:
    name=case+'.'+lane+'.json'
    receipts[name]=lab/name
    r=read(lab/name)
    workload=r['workload']
    assert r['state']=='Completed' and r['lane']==lane and not r['performanceQualified']
    assert r['catalogSha256']==identity['catalogSHA256']
    assert r['identities']['CPython']['executableSha256']==identity['cpythonSHA256']
    for label,role in [('baseline','reference'),('candidate','candidate')]:
        files={Path(v['path']).name:v['sha256'].lower() for v in r['identities'][label]['libraries']}
        assert files['Lokad.Lython.dll']==identity['imageFiles'][role]['Lokad.Lython.dll']
    counts=Counter()
    for a in r['attempts']:
        if a['phase'] not in ('measure','verify'):continue
        b=a['response']
        assert b['status']==('Equivalent' if a['phase']=='verify' else 'Completed')
        assert b['completedInvocations']==a['requestedIterations']
        compile_only=a['phase']=='measure' and lane=='compile'
        assert b.get('actualOutputSha256')==(None if compile_only else workload.get('expectedOutputSha256'))
        assert b.get('actualFilesSha256')==(None if compile_only else workload.get('expectedFilesSha256'))
        counts[(a['engine'],a['phase'])]+=1
    assert all(counts[(engine,'measure')]==7 and counts[(engine,'verify')]==2 for engine in ['baseline','candidate','CPython'])
    windows.append(dict(case=case,lane=lane,engines=r['summaries']))
write(lab/'windows-summary.json',dict(timedBatches=126,rows=windows))

receipt=read(confirmation/'archive-receipt.json')
assert receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved'] and receipt['allWorkersJoined'] and receipt['complete']
assert receipt['archiveSHA256']==digest(confirmation/'observations.tar.xz')
assert (confirmation/'exit-code.txt').read_text().strip()=='0'
cn=read(confirmation/'identity.json')
assert cn['imageFiles']==identity['imageFiles'] and cn['catalogSHA256']==identity['catalogSHA256']
with tarfile.open(confirmation/'observations.tar.xz') as tar:
    assert json.load(tar.extractfile('identity.json'))==cn
    raw=json.load(tar.extractfile('confirmation/confirmation.json'))
    machine=json.load(tar.extractfile('confirmation/machine-local.json'))
    assert machine['affinity']==[27]
assert raw['complete'] and len(raw['jobs'])==4
wsl=[]
for j in raw['jobs']:
    assert j['workersJoinedAndFixturesRemoved'] and len(j['samples'])==28
    engines={}
    for role,worker in j['identities'].items():
        files={Path(v['path']).name:v['sha256'].lower() for v in worker['libraries']}
        assert files['Lokad.Lython.dll']==cn['coreSHA256'][role]
        batches=[item for item in j['samples'] if item['engine']==role]
        assert len(batches)==7
        values=[]
        for item in batches:
            response=item['response']
            assert response['status']=='Completed'
            n=response['completedInvocations']
            values.append([1e6*response['elapsedTicks']/response['clockFrequency']/n,
                           1e6*item['externalProcessCpuTicks']/item['externalCpuFrequency']/n])
        engines[role]=list(map(median,zip(*values)))
    intervals={}
    for i,key in enumerate(('elapsed','cpu')):
        values=[100*(engines[a][i]/engines[b][i]-1) for a in ('candidate','candidate-control')
                     for b in ('reference','reference-control')]
        intervals[key]=[min(values),max(values)]
    wsl.append(dict(case=j['case'],lane=j['lane'],intervals=intervals,engineMedianUs=engines))
    print(j['case'],j['lane'],intervals,flush=True)
out=repo/'benchmarks/results/2026-11-27-windows-current-cpython'
out.mkdir(exist_ok=True)
for name in ('identity.json','windows-summary.json'):
    shutil.copyfile(lab/name,out/name)
write(out/'wsl-summary.json',dict(timedBatches=112,rows=wsl))
shutil.copyfile(confirmation/'observations.tar.xz',out/'wsl-observations.tar.xz')
for name in ('collect.py','archive.py','collector.log','initial-prepare.log','confirmation.log','candidate-verify.json','reference-verify.json',
             'representative.json','jobs.json','initial-confirmation.log','windows-machine.json'):
    receipts[name]=lab/name
for name in ('archive-receipt.json','collect.py','identity.json','run.sh','launch.sh','jobs.json','exit-code.txt'):
    receipts['confirmation-wsl/'+name]=confirmation/name
with tarfile.open(out/'procedures.tar.xz','w:xz') as tar:
    for name,source in receipts.items():tar.add(source,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as tar:
    assert all(tar.extractfile(name).read()==p.read_bytes() for name,p in receipts.items())
