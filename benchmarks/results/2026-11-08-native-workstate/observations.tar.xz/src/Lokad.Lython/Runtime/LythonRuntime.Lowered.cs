using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Calls;
using Lokad.Lython.Runtime.Text;
using System.Text.RegularExpressions;
using System.Runtime.ExceptionServices;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static LoweredBlockFlow ExecuteStatements(IReadOnlyList<LoweredStatement> statements, ExecutionContext context)
    {
        LythonRuntimeException failure;
        try
        {
            foreach (var statement in statements)
            {
                var flow = context.UseSynchronousLoweredFunctionDispatch
                    ? DispatchLoweredStatement(statement, context)
                    : DispatchLoweredStatementAsync(statement, context, SynchronousLoweredStatementExecution.Instance).GetAwaiter().GetResult();
                if (flow.Return is not null)
                {
                    return flow;
                }
            }

            return default;
        }
        catch (LythonRuntimeException ex)
        {
            ex.SetSourcePathIfMissing(context.SourcePath);
            failure = ex;
        }
        catch (ControlSignal signal)
        {
            return new LoweredBlockFlow(signal, null);
        }

        // Leave the catch before propagating. On Unix, recursively rethrowing
        // from active catch handlers can exhaust the native exception stack
        // even while the guest's managed frames have ample stack headroom.
        ExceptionDispatchInfo.Throw(failure);
        return default;
    }

    private static void ExecuteLoweredImport(LoweredImportStatement statement, ExecutionContext context)
    {
        ExecuteImport(statement.Syntax, context);
    }

    private static void ExecuteLoweredFunctionDefinition(LoweredFunctionDefinitionStatement functionDefinition, ExecutionContext context)
    {
        context.EnterInterpreterFrame(functionDefinition.Span);
        try
        {
            using var decoratorStorage = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(functionDefinition.Decorators.Count), functionDefinition.Span);
            var decorators = EvaluateDecorators(functionDefinition.Decorators, context);
            var syntax = functionDefinition.Syntax;
            var defaultCount = functionDefinition.Parameters.Count(static p => p.DefaultValue is not null);
            using var defaultStorage = ReserveDefaultArgumentsWorkingStorage(defaultCount, context.MemoryGovernor, functionDefinition.Span);
            var defaults = EvaluateFunctionDefaults(functionDefinition.Parameters, defaultCount, context, false).GetAwaiter().GetResult();
            var typeScope = CreateTypeScope(functionDefinition.TypeParameters, context, functionDefinition.Span);
            var function = CreateLoweredFunction(functionDefinition, typeScope.Closure, defaults);
            AttachTypeMetadataAsync(function, functionDefinition.Parameters, functionDefinition.ReturnAnnotation,
                functionDefinition.TypeParameters is not null, functionDefinition.Span, typeScope, context, false).GetAwaiter().GetResult();
            StoreName(syntax.Name, ApplyDecorators(function, decorators, functionDefinition.Span, context), context, functionDefinition.Span);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredClassDefinition(LoweredClassDefinitionStatement classDefinition, ExecutionContext context)
    {
        context.EnterInterpreterFrame(classDefinition.Span);
        try
        {
            using var decoratorStorage = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(classDefinition.Decorators.Count), classDefinition.Span);
            var decorators = EvaluateDecorators(classDefinition.Decorators, context);
            var typeScope = CreateTypeScope(classDefinition.TypeParameters, context, classDefinition.Span);
            var header = EvaluateClassHeaderArgumentsAsync(classDefinition, typeScope.Annotations, decoratorStorage, false).GetAwaiter().GetResult();
            var baseTypes = header.Bases;
            var classKeywordArguments = header.Keywords;

            var resolvedBases = AddGenericClassBase(classDefinition, ResolveClassBases(baseTypes, classDefinition.Span, context), context);
            ValidateClassKeywordArguments(classKeywordArguments, classDefinition.Span);

            var classContext = ExecutionContext.CreateClassBody(typeScope.Closure, classDefinition.Syntax);
            var classFlow = ExecuteStatements(classDefinition.Body, classContext);
            if (classFlow.Control is not null)
            {
                throw new LythonRuntimeException("RuntimeError", "Loop control cannot escape a class body.", classDefinition.Span);
            }

            if (classFlow.Return is not null)
            {
                throw classFlow.Return;
            }

            AttachGenericClassMetadataAsync(classDefinition, typeScope, classContext, false, baseTypes).GetAwaiter().GetResult();
            var type = CreateLoweredClassType(classDefinition, resolvedBases, baseTypes, classKeywordArguments, classContext, context,false).GetAwaiter().GetResult();
            if (classContext.ClassCell is { } classCell) classCell.Value = type;
            if (type is PyType defined)
            {
                InvokeInitSubclass(defined, classKeywordArguments, classDefinition.Span, context);
            }
            StoreName(classDefinition.Syntax.Name, ApplyDecorators(type, decorators, classDefinition.Span, context), context, classDefinition.Span);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static object[] EvaluateDecorators(IReadOnlyList<LoweredExpression> expressions, ExecutionContext context)
    {
        var values = new object[expressions.Count];
        for (var i = 0; i < expressions.Count; i++)
        {
            values[i] = EvaluateLoweredExpression(expressions[i], context);
        }
        return values;
    }

    private static object ApplyDecorators(object value, IReadOnlyList<object> decorators, LythonSourceSpan span, ExecutionContext context)
    {
        object current = value;
        for (var i = decorators.Count - 1; i >= 0; i--)
        {
            var decorator = decorators[i];
            if (decorator is not LythonRuntime.ICallable callable)
            {
                throw new LythonRuntimeException("TypeError", "Decorator expression must evaluate to a callable.", span);
            }

            current = CallableInvocation.InvokeUnary(callable, current, span, context);
        }

        return current;
    }

    private static void ExecuteLoweredIfStatement(LoweredIfStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var branch = IsTruthy(EvaluateLoweredExpression(statement.Condition, context), context, statement.Condition.Span)
                ? statement.ThenStatements
                : statement.ElseStatements;

            if (branch is not null)
            {
                var branchFlow = ExecuteStatements(branch, context);
                if (branchFlow.Control is not null)
                {
                    throw branchFlow.Control;
                }

                if (branchFlow.Return is not null)
                {
                    throw branchFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredForStatement(LoweredForStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var syntax = statement.Syntax;
            var iterable = EvaluateLoweredExpression(statement.Iterable, context);
            var broke = false;
            foreach (var item in ToSequence(iterable, statement.Iterable.Span, context))
            {
                // A pass-only body and a builtin range iterator may otherwise
                // perform no expression, call or allocation checkpoints.
                context.CheckExecution(statement.Span);
                AssignLoopTarget(syntax.Target, item, statement.Iterable.Span, context);
                var bodyFlow = ExecuteStatements(statement.Body, context);
                if (bodyFlow.Control is ContinueSignal)
                {
                    continue;
                }

                if (bodyFlow.Control is BreakSignal)
                {
                    broke = true;
                    break;
                }
                if (bodyFlow.Return is not null)
                {
                    throw bodyFlow.Return;
                }
            }

            if (!broke && statement.ElseStatements is not null)
            {
                var elseFlow = ExecuteStatements(statement.ElseStatements, context);
                if (elseFlow.Control is not null)
                {
                    throw elseFlow.Control;
                }

                if (elseFlow.Return is not null)
                {
                    throw elseFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredWhileStatement(LoweredWhileStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var broke = false;
            while (IsTruthy(EvaluateLoweredExpression(statement.Condition, context), context, statement.Condition.Span))
            {
                var bodyFlow = ExecuteStatements(statement.Body, context);
                if (bodyFlow.Control is ContinueSignal)
                {
                    continue;
                }

                if (bodyFlow.Control is BreakSignal)
                {
                    broke = true;
                    break;
                }
                if (bodyFlow.Return is not null)
                {
                    throw bodyFlow.Return;
                }
            }

            if (!broke && statement.ElseStatements is not null)
            {
                var elseFlow = ExecuteStatements(statement.ElseStatements, context);
                if (elseFlow.Control is not null)
                {
                    throw elseFlow.Control;
                }

                if (elseFlow.Return is not null)
                {
                    throw elseFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredMatchStatement(LoweredMatchStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var subject = EvaluateLoweredExpression(statement.Subject, context);
            foreach (var matchCase in statement.Cases)
            {
                if (!TryExecuteLoweredPattern(matchCase.Pattern, subject, context))
                    continue;

                if (matchCase.Guard is { } guard &&
                    !IsTruthy(EvaluateLoweredExpression(guard, context), context, guard.Span))
                    continue;

                var flow = ExecuteStatements(matchCase.Body, context);
                if (flow.Return is not null) throw flow.Return;
                if (flow.Control is not null) throw flow.Control;
                return;
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredWithStatement(LoweredWithStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            ExecuteWithStatement(statement.Syntax, statement.ContextExpression, statement.Body, context);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static void ExecuteLoweredTryStatement(LoweredTryStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            static ValueTask<LoweredBlockFlow> ExecuteSynchronously(
                IReadOnlyList<LoweredStatement> statements, ExecutionContext executionContext)
                => new(ExecuteStatements(statements, executionContext));

            var flow = ExecuteTryStatementCoreAsync(statement, context, ExecuteSynchronously,
                expression => new ValueTask<object>(EvaluateLoweredExpression(expression, context))).GetAwaiter().GetResult();
            if (flow.Control is not null) throw flow.Control;
            if (flow.Return is not null) throw flow.Return;
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    // Assignments do not track interpreter depth (MG25): depth is tracked
    // once per Python nesting level (calls, bodies, compound statements), and
    // assignment targets nest shallowly enough for the frontend bound plus the
    // stack probe. Cancellation checks remain on every statement.
    private static void ExecuteLoweredAssignment(LoweredAssignmentStatement assignment, ExecutionContext context)
    {
        context.CheckExecution(assignment.Span);
        switch (assignment)
            {
                case LoweredNameAssignmentStatement simple:
                    StoreName(simple.Assignment.Name, EvaluateLoweredExpression(simple.Expression, context), context, simple.Span);
                    return;
                case LoweredChainedAssignmentStatement chained:
                    var chainedValue = EvaluateLoweredExpression(chained.Expression, context);
                    foreach (var assignmentTarget in chained.Assignment.Targets)
                    {
                        AssignTarget(assignmentTarget, chainedValue, context);
                    }
                    return;
                case LoweredAnnotatedAssignmentStatement annotated:
                    if (annotated.Expression is not null)
                    {
                        AssignTarget(annotated.Assignment.Target, EvaluateLoweredExpression(annotated.Expression, context), context);
                    }
                    else EvaluateAnnotationTargetReadsAsync(annotated, context, false).GetAwaiter().GetResult();
                    StoreVariableAnnotationAsync(annotated, context, false).GetAwaiter().GetResult();
                    return;
                case LoweredAugmentedAssignmentStatement augmented:
                    var augmentedTarget = ResolveLoweredAugmentedAssignmentTarget(augmented.Target, context);
                    augmentedTarget.Store(EvaluateAugmentedAssignment(
                        augmentedTarget.CurrentValue,
                        EvaluateLoweredExpression(augmented.Expression, context),
                        augmented.Assignment.Operator,
                        context,
                        augmented.Span));
                    return;
                case LoweredUnpackingAssignmentStatement unpacking:
                    AssignTargets(
                        unpacking.Assignment.Targets,
                        EvaluateLoweredExpression(unpacking.Expression, context),
                        unpacking.Expression.Span,
                        context);
                    return;
                case LoweredSubscriptAssignmentStatement subscript:
                    ExecuteLoweredSubscriptAssignment(
                        subscript.Assignment,
                        subscript.Receiver,
                        subscript.Index,
                        EvaluateLoweredExpression(subscript.Expression, context),
                        context);
                    return;
                case LoweredSliceAssignmentStatement slice:
                    ExecuteLoweredSliceAssignment(
                        slice.Assignment,
                        slice.Receiver,
                        slice.Start,
                        slice.End,
                        slice.Step,
                        EvaluateLoweredExpression(slice.Expression, context),
                        context);
                    return;
                case LoweredMemberAssignmentStatement member:
                    var value = EvaluateLoweredExpression(member.Expression, context);
                    var target = EvaluateLoweredExpression(member.Receiver, context);
                    if (!PyMemberAccess.TryAssign(target, member.Assignment.MemberName, value, context, member.Span))
                    {
                        throw new LythonRuntimeException("TypeError", "Object does not support attribute assignment.", member.Span);
                    }
                    return;
                default:
                    throw new InvalidOperationException($"Unsupported lowered assignment: {assignment.GetType().Name}");
            }
    }

    private static void ExecuteLoweredSliceAssignment(
        SliceAssignmentStatementSyntax statement,
        LoweredExpression targetExpression,
        LoweredExpression? startExpression,
        LoweredExpression? endExpression,
        LoweredExpression? stepExpression,
        object value,
        ExecutionContext context)
    {
        ExecuteSliceAssignment(
            EvaluateLoweredExpression(targetExpression, context),
            startExpression is null ? null : EvaluateLoweredExpression(startExpression, context),
            endExpression is null ? null : EvaluateLoweredExpression(endExpression, context),
            stepExpression is null ? null : EvaluateLoweredExpression(stepExpression, context),
            value,
            statement.Span,
            context);
    }

    private static AugmentedAssignmentTargetReference ResolveLoweredAugmentedAssignmentTarget(
        LoweredAugmentedAssignmentTarget target,
        ExecutionContext context)
    {
        switch (target)
        {
            case LoweredNameAugmentedAssignmentTarget name:
                return ResolveAugmentedAssignmentTarget(name.Target, context);

            case LoweredSubscriptAugmentedAssignmentTarget subscript:
                var subscriptTarget = EvaluateLoweredExpression(subscript.Receiver, context);
                var index = EvaluateLoweredExpression(subscript.Index, context);
                var subscriptValue = ReadSubscriptValue(subscriptTarget, index, subscript.Span, context);
                return new AugmentedAssignmentTargetReference(
                    subscriptValue,
                    value => SetSubscriptValue(subscriptTarget, index, value, subscript.Span, context));

            case LoweredSliceAugmentedAssignmentTarget slice:
                var sliceTarget = EvaluateLoweredExpression(slice.Receiver, context);
                var start = slice.Start is null ? null : EvaluateLoweredExpression(slice.Start, context);
                var end = slice.End is null ? null : EvaluateLoweredExpression(slice.End, context);
                var step = slice.Step is null ? null : EvaluateLoweredExpression(slice.Step, context);
                if (sliceTarget is PyInstance instance)
                {
                    var sliceIndex = CreateSliceValue(start, end, step, slice.Span, context);
                    var current = GetUserItem(instance, sliceIndex, context, slice.Span);
                    return new AugmentedAssignmentTargetReference(current,
                        value => SetSubscriptValue(instance, sliceIndex, value, slice.Span, context));
                }
                var sliceValue = PyIndexing.ReadSlice(sliceTarget, start, end, step, slice.Span, context);
                return new AugmentedAssignmentTargetReference(
                    sliceValue,
                    value => ExecuteSliceAssignment(sliceTarget, start, end, step, value, slice.Span, context));

            case LoweredMemberAugmentedAssignmentTarget member:
                var memberTarget = EvaluateLoweredExpression(member.Receiver, context);
                if (!TryResolveRuntimeMember(memberTarget, member.Target.MemberName, context, member.Span, out var memberValue))
                {
                    throw PyMemberAccess.CreateMissingMemberError(memberTarget, member.Target.MemberName, member.Span, context);
                }

                return new AugmentedAssignmentTargetReference(
                    memberValue,
                    value => SetMemberValue(memberTarget, member.Target.MemberName, value, member.Span, context));

            default:
                throw new InvalidOperationException($"Unsupported lowered augmented target: {target.GetType().Name}");
        }
    }

    private static void ExecuteLoweredSubscriptAssignment(
        SubscriptAssignmentStatementSyntax statement,
        LoweredExpression targetExpression,
        LoweredExpression indexExpression,
        object value,
        ExecutionContext context)
    {
        var target = EvaluateLoweredExpression(targetExpression, context);
        var index = EvaluateLoweredExpression(indexExpression, context);
        SetSubscriptValue(target, index, value, statement.Span, context);
    }
}
