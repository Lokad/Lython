from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');canonical=base/'method-binding-b441-20261108/candidate/Microsoft.CodeAnalysis.CSharp.dll';note=base/'activation-b442-shared-worker-library.json'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not note.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 assert canonical.is_file()and not canonical.is_symlink()and hashlib.sha256(canonical.read_bytes()).hexdigest()=='1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f'
 reference=canonical.stat();before=shutil.disk_usage(base).free;changed=[];scanned=0
 for folder,dirs,files in os.walk(base,followlinks=False):
  if 'Microsoft.CodeAnalysis.CSharp.dll'not in files:continue
  path=Path(folder)/'Microsoft.CodeAnalysis.CSharp.dll';scanned+=1
  assert scanned<=256,'Bound this cleanup to one worker-library name.'
  if path.is_symlink()or not path.resolve().is_relative_to(base.resolve()):continue
  state=path.stat()
  if state.st_ino==reference.st_ino and state.st_dev==reference.st_dev:continue
  if state.st_size!=reference.st_size or stat.S_IMODE(state.st_mode)!=stat.S_IMODE(reference.st_mode):continue
  if hashlib.sha256(path.read_bytes()).hexdigest()!='1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f':continue
  temporary=path.with_name(path.name+'.b442-dedup.tmp');assert not temporary.exists()
  try:
   os.link(canonical,temporary);os.replace(temporary,path)
  finally:
   if temporary.exists():temporary.unlink()
  assert hashlib.sha256(path.read_bytes()).hexdigest()=='1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f'
  changed.append(dict(path=str(path),previousInode=state.st_ino,previousMtimeNs=state.st_mtime_ns,newInode=path.stat().st_ino))
  if shutil.disk_usage(base).free-before>=48*1024*1024:break
 assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f'
 result=dict(library=canonical.name,sha256='1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f',canonical=str(canonical),beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,scannedPaths=scanned,changed=changed,allOriginalPathsAndBytesRetained=True,independentLocalBytesVerified=True,ownedLease=True,noActiveWorkersOrCollectors=True,scope='Deduplicate one byte-identical managed worker library using atomic hardlink replacement; no source/core/archive/data deletion. Existing measurements continue to identify identical bytes.')
 note.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
