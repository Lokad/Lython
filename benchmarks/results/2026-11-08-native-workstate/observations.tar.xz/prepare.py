from pathlib import Path
import base64,copy,hashlib,json,os,shutil,subprocess,tempfile
r=Path(__file__).resolve().parent;prior=r.parent/'method-binding-r78'
data=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));cases=data['cases'];original=cases[0];right=cases[1];assert original['id']=='scripts.text-summary-helpers.large'and right['id']=='scripts.text-summary-rsplit-helpers.large'
inline=[]
for case in [original,right]:
 c=copy.deepcopy(case);body=c['source'].split('\n\n',1);assert body[0].startswith('def words_from_line(line:str)->list:\n    return line.lower().')
 expression=body[0].split('return ',1)[1];c['source']=body[1].replace('words_from_line(line)',expression);c['id']=c['id'].replace('-helpers.','-inline.')
 c['sourceUtf8Bytes']=len(c['source'].encode('utf-8'));c['sourceSha256']=hashlib.sha256(c['source'].encode('utf-8')).hexdigest();inline.append(c)
data['cases']=[original,right,*inline,cases[2]];assert len(data['cases'])==5
goldens=[]
with tempfile.TemporaryDirectory(prefix='lython-activation-golden-')as folder:
 for case in data['cases'][:4]:
  fixture=json.loads(case['fixtureJson'])
  for name,value in fixture['inputFiles'].items():(Path(folder)/name).write_bytes(base64.b64decode(value))
  p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True)
  assert p.returncode==0 and not p.stderr and p.stdout.replace(b'\r\n',b'\n')==case['expectedOutput'].encode('utf-8'),p.stderr
  assert all((Path(folder)/name).read_bytes()==base64.b64decode(value)for name,value in fixture['outputFiles'].items())
  goldens.append(dict(case=case['id'],sourceSHA256=case['sourceSha256'],allFilesAndStdoutMatch=True))
assert not Path(folder).exists();(r/'independent-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8')
(r/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
frozen=json.loads(Path('benchmarks/results/2026-11-08-string-receivers/positional-correction.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in frozen['productionSources'].items())
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');assert hashlib.sha256(core.read_bytes()).hexdigest()==frozen['focused']['coreSHA256']['net11.0']
for role in ['before','candidate']:
 shutil.copytree(prior/'images'/role,r/'images'/role,copy_function=os.link);target=r/'images'/role/'Lokad.Lython.dll';target.unlink();shutil.copyfile(core,target)
(r/'identity.json').write_text(json.dumps(dict(sourceRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeVaries=False,coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),productionSources=frozen['productionSources'],measurement='Same-core workload diagnostic, allocation and desktop elapsed only; no runtime source pair or CPU claim.'),indent=2)+'\n',encoding='utf-8')
(r/'measure.py').write_text((prior/'measure.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(r/'selected-plan.md').write_text('''R79 bounded activation gate: complete text report helper/inline pairs independently match all CPython stdout/files. Same final5b9d569a production core in all ALC roles, common CoreLib/hash seed; existing five-case driver/both APIs. rsplit uses identical unfused casing/splitting in helper and inline forms, helping separate invocation from the native split helper's fused casing/storage. Not exact per-frame attribution: module/function lookup and definition costs also differ. Source shows full ExecutionContext promotion before ordinary native receiver calls, even though existing no-argument string operations and workstate already suffice for native data operations. Consider centralizing the existing native receiver convention in TryExecuteNativeCall and removing duplicate ordinary-call branches; no new per-name native-return tags or dispatch framework. Require actual type/arity/shape proof and preserve user protocols, callbacks/reentry, lexical locals/closures, exception annotations, real suspension, managed stack and shared-budget ownership. Never infer no callbacks from ReceiverMethod.CanSuspend alone. Stop after this bounded comparison at a removable phase or insufficient evidence; no new VM campaign merely for source selection.''',encoding='utf-8')
print('Four helper/inline complete goldens verified independently; same frozen current core in all diagnostic roles, no runtime change.')
