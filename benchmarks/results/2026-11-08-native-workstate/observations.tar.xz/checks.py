from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'inline-text-r76/checks.py').read_text(encoding='utf-8');a=s.index('internal=');b=s.index('results={}',a)
internal=['DirectString','DirectDictionary','BoundMethodInvocationBoundaryTests','GeneralBoundMethodTransportTests','GeneralBoundMethodDefaultLifetimeTests','AsyncExecutableFunctionTests','ExecutionContextArchitectureSubsystemTests','IterationIndexingSubsystemTests','IterationCancellationTests','NativeSequenceAdmissionTests','StringMethodOwnershipTests','TerminalStringStorageTests']
public=['NativeWorkStateDispatchTests','StringReceiverBindingTests','StringPositionalBindingTests','ReceiverMethodSemanticsTests','AsyncFunctionHostingTests','PreparedFunctionDefaultsTests','PreparedFunctionHostLifetimeTests','ClosureContextAccountingScenarioTests','ClosureRetentionAccountingScenarioTests','TransitiveClosureCompatibilityTests','TracebackScenarioTests','StarredLoopTargetTests','ProtectedLoopControlTests','BoundLoopNameStorageTests','BoundedLoopTemporaryScenarioTests','GeneralBoundMethod','CooperativeCancellationTests','BuiltinIterationCancellationTests','DictView','StringOwnershipAdmissionTests','StringMethodAccountingScenarioTests']
s=s[:a]+'internal='+repr(internal)+'\npublic='+repr(public)+'\n'+s[b:]
exec(compile(s,str(r/'checks.py'),'exec'),{'__file__':str(r/'checks.py')})
