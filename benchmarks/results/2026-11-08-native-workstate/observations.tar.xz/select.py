from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;rows=[]
for api in ['sync','async']:
 d=json.loads((r/('warm-'+api)/'measurements.json').read_text(encoding='utf-8'));assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 for j in d['observations']:
  roles={role:dict(allocatedBytes=statistics.median(s['allocatedBytes']/s['jobs']for s in j['samples']if s['image']==role),elapsedMilliseconds=statistics.median(s['elapsedMilliseconds']/s['jobs']for s in j['samples']if s['image']==role))for role in ['before','candidate','before-control']};rows.append(dict(api=api,case=j['caseId'],roles=roles,elapsedDiagnosticOnly=True))
(r/'source-gate.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('1. R78 committed');b=s.index('3. Keep the regex',a)
s=s[:a]+'''1. R78 committed/pushed af481194; positional correction5b9d569a committed/pushed.
   Combined CI42443700988 running: Windows/Ubuntu actual11/10, original Stress
   and installed consumers. Last check03:48:21UTC; next>=03:53:21. Cache terminal
   receipt once, never requery/duplicate-dispatch. Continue R79 while CI runs.
2. R79 native workstate dispatch SELECTED/IMPLEMENTING. Same-current-core complete
   reports verify identical CPython stdout/files: rsplit helper~3.09MB versus
   inline~1.79MB; optimized fused split helper~1.50MB. The~1.30MB invocation
   difference is distinct from~0.29MB fused-text storage, not precise CPU attribution.
   Centralize existing native receiver conventions in TryExecuteNativeCall, remove
   the two duplicate ordinary native-call branches. Exact PyString/zero-argument
   methods have no guest argument coercion; native dictionary views only retain
   their receiver. Do not infer this from CanSuspend or add per-name proof markers.
   Move existing admitted exact list/tuple iteration before ContextRequired; its
   positions live in owned WorkState and transfer once on later promotion. Avoid
   full ExecutionContext allocation for these native function bodies, retaining
   the ordinary frame before other shapes, guest protocols or real suspension.
   No new backend/dispatcher/arena/pool/configuration or tagged-value redesign.
   Affected: ordinary/guarded text helpers and native collection-loop helpers;
   controls: existing fused text, CSV and report scripts. Preserve locals/closures,
   exception diagnostics/handlers, receiver/argument order, actual callbacks and
   reentry, stack safety, current cancellation and first refusal/owned aliases.
   Focused semantics and native-loop-to-async adoption/cleanup, then one bounded
   complete-workload source pair with controls. Retain/refine/reject explicitly;
   whole-script objective remains active after this milestone.
'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n');print('R79 native-first dispatch milestone and source-gate evidence recorded; no CPU claim or per-name proof expansion.')
