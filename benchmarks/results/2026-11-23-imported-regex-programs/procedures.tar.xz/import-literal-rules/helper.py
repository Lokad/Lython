import re
rules = (
    re.compile(r"^00: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^01: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^02: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^03: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^04: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^05: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^06: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^07: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^08: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^09: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^10: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^11: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^12: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^13: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^14: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
    re.compile(r"^15: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\n]+)$", re.I),
)
def normalize(line):
    m = rules[int(line[:2])].match(line)
    return m['label'].lower() + ',' + m['city'] + ',' + m['icon'] + '\n'
