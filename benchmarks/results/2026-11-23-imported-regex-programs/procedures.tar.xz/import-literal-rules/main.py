from helper import normalize
rows = []
with open('input.txt', encoding='utf-8') as source:
    for line in source:
        rows.append(normalize(line))
with open('out.txt', 'w', encoding='utf-8', newline='') as sink:
    sink.write(''.join(rows))
