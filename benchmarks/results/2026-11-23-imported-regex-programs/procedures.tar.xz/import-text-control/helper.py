def normalize(line):
    label, rest = line[4:].strip().split(' ', 1)
    city, icon = rest.split('-', 1)
    return label.lower() + ',' + city + ',' + icon + '\n'
