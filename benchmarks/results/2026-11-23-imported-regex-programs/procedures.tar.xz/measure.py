from pathlib import Path
from statistics import median
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[2]
donor = lab.parent / 'review-20261031/forwarded-global-call-20261123'
prior = json.loads((donor / 'comparison/identity.json').read_text(encoding='utf-8'))
files = prior['imageFiles']['candidate']
assert len(files) == 32
dotnet = Path.home() / '.dotnet11/dotnet.exe'
python = Path('C:/Python313/python.exe')
environment = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_HOST_PATH=str(dotnet))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path,text: path.write_text(text,encoding='utf-8',newline='\n')
core='Lokad.Lython.dll'
adapter='Lokad.Lython.Utf8Regex.dll'
case_names=('import-literal-rules','import-text-control')
paths = {role: lab/role for role in ('reference','candidate')}

if sys.argv[1] == 'prepare':
    for fixture in case_names:
        path = lab/fixture
        path.mkdir(exist_ok=True)
        write(path/'main.py', '''from helper import normalize
rows = []
with open('input.txt', encoding='utf-8') as source:
    for line in source:
        rows.append(normalize(line))
with open('out.txt', 'w', encoding='utf-8', newline='') as sink:
    sink.write(''.join(rows))
''')
        write(path/'input.txt',''.join(f'{i%16:02d}: CAFÉ_{i:04d} 東京-😀\n' for i in range(96)))
        if fixture=='import-literal-rules':
            rules=',\n'.join(f'    re.compile(r"^{i:02d}: (?P<label>[A-ZÉ]+_[0-9]+) (?P<city>[^-]+)-(?P<icon>[^\\n]+)$", re.I)' for i in range(16))
            body=f'''import re
rules = (
{rules},
)
def normalize(line):
    m = rules[int(line[:2])].match(line)
    return m['label'].lower() + ',' + m['city'] + ',' + m['icon'] + '\n'
'''.replace("+ '\n'", "+ '\\n'")
        else:
            body=r'''def normalize(line):
    label, rest = line[4:].strip().split(' ', 1)
    city, icon = rest.split('-', 1)
    return label.lower() + ',' + city + ',' + icon + '\n'
'''
        write(path/'helper.py',body)
        subprocess.run([python,'-I','-S','-X','utf8','-B','-c',
            "import sys;sys.path.insert(0,'.');exec(compile(open('main.py',encoding='utf-8').read(),'main.py','exec'),{'__name__':'__main__'})"],cwd=path,check=True,timeout=20)
        (path/'out.txt').replace(path/'expected.txt')
    subprocess.run([dotnet,'build',lab/'ImportDiagnostic.csproj','-c','Release','-o',lab/'driver',
        f'-p:FrozenDonor={donor/"candidate"}'],cwd=repo,env=environment,check=True,timeout=65)
    images={}
    for role,path in paths.items():
        path.mkdir(exist_ok=True)
        for name,sha in files.items():
            original=donor/'candidate'/name
            assert digest(original)==sha,(name,'donor hash')
            if role=='candidate' and name==core:
                original=lab/'windows/bin/Lokad.Lython/release_net11.0'/core
            shutil.copyfile(original,path/name)
        for extension in ('dll','deps.json','runtimeconfig.json'):
            name='ImportDiagnostic.'+extension
            shutil.copyfile(lab/'driver'/name,path/name)
        images[role]={name:digest(path/name) for name in [*files,'ImportDiagnostic.dll','ImportDiagnostic.deps.json','ImportDiagnostic.runtimeconfig.json']}
    assert [name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]]==[core]
    base=subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo,encoding='utf-8').strip()
    candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf-8').strip()
    assert not subprocess.check_output(['git','diff','--name-only',base,prior['candidate'],'--','src'],cwd=repo)
    identity=dict(referenceSource=base,donorSource=prior['candidate'],candidateSource=candidate,
        images=images,fixtures={name:{n:digest(lab/name/n) for n in ('main.py','helper.py','input.txt','expected.txt')} for name in case_names})
    write(lab/'identity.json',json.dumps(identity,indent=2)+'\n')
else:
    assert sys.argv[1]=='measure'
    identity=json.loads((lab/'identity.json').read_text(encoding='utf-8'))
    all_rows=[]
    summaries=[]
    for case,lane in [(case_names[0],'warm'),(case_names[0],'first-use'),(case_names[1],'warm')]:
        rows=[]
        for role in ('reference','candidate','candidate','reference'):
            path=paths[role]
            assert all(digest(path/n)==sha for n,sha in identity['images'][role].items())
            assert all(digest(lab/case/n)==sha for n,sha in identity['fixtures'][case].items())
            run=subprocess.run([dotnet,path/'ImportDiagnostic.dll',lab/case,lane],cwd=repo,env=environment,encoding='utf-8',capture_output=True,timeout=35)
            if run.returncode:
                print(run.stderr,flush=True)
                run.check_returncode()
            data=json.loads(run.stdout)
            assert data['core']==identity['images'][role][core] and data['adapter']==identity['images'][role][adapter]
            assert data['golden']==identity['fixtures'][case]['expected.txt']
            row=dict(role=role,case=case,lane=lane,**data)
            all_rows.append(row)
            rows.append(row)
            write(lab/'observations.json',json.dumps(dict(host=platform.platform(),rows=all_rows),indent=2)+'\n')
        get=lambda row,k: median(batch[k] for batch in row['batches'])/row['iterations']
        elapsed=lambda row: get(row,'ticks')/row['frequency']*1000
        def change(metric):
            p=[(metric(a)/metric(b)-1)*100 for a in rows if a['role']=='candidate' for b in rows if b['role']=='reference']
            return [min(p),max(p)]
        summary=dict(case=case,lane=lane,elapsedChangePercent=change(elapsed),cpuChangePercent=change(lambda x:get(x,'cpuTicks')),
            allocations=[get(r,'bytes') for r in rows],admitted=[r['peak'] for r in rows],elapsedMs=[elapsed(r) for r in rows])
        print(json.dumps(summary),flush=True)
        summaries.append(summary)
        write(lab/'summary.json',json.dumps(summaries,indent=2)+'\n')
