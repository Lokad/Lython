using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Benchmarks;
using Lokad.Lython.Utf8Regex;

var fixture = args[0];
var fresh = args[1] == "first-use";
var host = new BenchmarkHost();
host.SeedBytes("/input.txt", File.ReadAllBytes(Path.Combine(fixture, "input.txt")));
host.SeedBytes("/helper.py", File.ReadAllBytes(Path.Combine(fixture, "helper.py")));
var expected = File.ReadAllBytes(Path.Combine(fixture, "expected.txt"));
var source = File.ReadAllText(Path.Combine(fixture, "main.py"));
var allowance = new LythonMemoryBudget(8 * 1024 * 1024);
var options = new LythonRunOptions { AllowedLocalModules = new HashSet<string> { "helper" }, MemoryBudget = allowance };
var engine = new LythonEngine(Utf8RegexProvider.Instance);
using var compiled = fresh ? null : engine.Compile(source, allowance);
var baseline = allowance.ReservedBytes;
long peak = 0;

void Run()
{
    using (var owned = fresh ? engine.Compile(source, allowance) : null)
    using (var result = (compiled ?? owned!).Run(host, options))
    {
        if (!result.Success) throw new Exception(result.Failure?.Message ?? string.Join("\n", result.Diagnostics));
        if (!host.ReadBytes("/out.txt").AsSpan().SequenceEqual(expected)) throw new Exception("Result differs from CPython");
        peak = Math.Max(peak, result.PeakExecutionMemoryBytes);
    }
    if (allowance.ReservedBytes != baseline) throw new Exception($"Expected {baseline} allowance, found {allowance.ReservedBytes}");
}

var warmup = Stopwatch.StartNew();
do { Run(); } while (warmup.Elapsed < TimeSpan.FromSeconds(2));
using var process = Process.GetCurrentProcess();
const int iterations = 96;
var batches = new List<object>();
for (var batch = 0; batch < 7; batch++)
{
    var cpu = process.TotalProcessorTime.Ticks;
    var allocated = GC.GetTotalAllocatedBytes(precise: true);
    var start = Stopwatch.GetTimestamp();
    for (var i = 0; i < iterations; i++) Run();
    var ticks = Stopwatch.GetTimestamp() - start;
    var bytes = GC.GetTotalAllocatedBytes(precise: true) - allocated;
    process.Refresh();
    batches.Add(new { ticks, bytes, cpuTicks = process.TotalProcessorTime.Ticks - cpu });
}
compiled?.Dispose();
if (allowance.ReservedBytes != 0) throw new Exception("Compilation owner did not refund");
string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
Console.WriteLine(JsonSerializer.Serialize(new { fresh, iterations, processId = Environment.ProcessId,
    runtime = Environment.Version.ToString(), frequency = Stopwatch.Frequency, batches, peak, peakShared = allowance.PeakBytes,
    core = Hash(typeof(LythonEngine).Assembly.Location), adapter = Hash(typeof(Utf8RegexProvider).Assembly.Location),
    golden = Hash(Path.Combine(fixture, "expected.txt")) }));
