from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[2]
result=repo/'benchmarks/results/2026-11-23-imported-regex-programs'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
identity=read(lab/'identity.json')
observations=read(lab/'observations.json')
assert len(observations['rows'])==12 and all(len(row['batches'])==7 for row in observations['rows'])
assert all(len(files)==35 for files in identity['images'].values())
for role,files in identity['images'].items():
    assert all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
for role in ('windows','ubuntu'):
    assert 'Passed:   847' in (lab/f'{role}-public-final.log').read_text(encoding='utf-8-sig')
    assert 'Passed:   108' in (lab/f'{role}-white.log').read_text(encoding='utf-8-sig')
result.mkdir(exist_ok=True)
for name in ('identity.json','observations.json','summary.json'):
    shutil.copyfile(lab/name,result/name)
core=(lab/'candidate/Lokad.Lython.dll').read_bytes()
assert sha(core)==identity['images']['candidate']['Lokad.Lython.dll']
(result/'candidate-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
patch=subprocess.check_output(['git','diff','--binary',identity['referenceSource'],identity['candidateSource'],'--','src'],cwd=repo)
(lab/'production.patch').write_bytes(patch)
with tarfile.open(result/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','measure.py','Program.cs','ImportDiagnostic.csproj','production.patch','measurement.log',
                 'first-failed.log','first-failed.deps.json','preparation.log','windows-frozen.log',
                 'windows-public-final.log','ubuntu-public-final.log','windows-white.log','ubuntu-white.log'):
        archive.add(lab/name,arcname=name,recursive=False)
    for fixture,files in identity['fixtures'].items():
        for name,digest in files.items():
            path=lab/fixture/name
            assert sha(path.read_bytes())==digest
            archive.add(path,arcname=f'{fixture}/{name}',recursive=False)
    for suffix in ('dll','deps.json','runtimeconfig.json'):
        name=f'ImportDiagnostic.{suffix}'
        archive.add(lab/'driver'/name,arcname=name,recursive=False)
print(result)
