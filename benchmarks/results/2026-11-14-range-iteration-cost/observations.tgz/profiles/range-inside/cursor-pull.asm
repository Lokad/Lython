; Assembly listing for method Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu32 zmmword ptr [rbp-0x50], zmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x10], rsi
 
G_M000_IG02:                ;; offset=0x002E
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x58]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x08], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0045
       mov      rax, 0x7641C5801640
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG17
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG05
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, bword ptr [rbp-0x10]
       mov      r11, 0x7649A3A61AF8
       call     [r11]Lokad.Lython.Runtime.IPyIteratorValue:TryMoveNext(byref):bool:this
       mov      dword ptr [rbp-0x84], eax
       jmp      G_M000_IG19
 
G_M000_IG05:                ;; offset=0x0093
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x30], 0
       jne      G_M000_IG12
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x20], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7649A62DB958
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG06
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7649A61E3C00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG12
 
G_M000_IG06:                ;; offset=0x00E4
       mov      rax, gword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp-0x08]
       lea      rsi, bword ptr [rax+0x54]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG07:                ;; offset=0x0108
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG08:                ;; offset=0x0112
       mov      rax, bword ptr [rbp-0x10]
       mov      bword ptr [rbp-0x70], rax
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
       mov      rax, bword ptr [rbp-0x70]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, 0x7641C5801640
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x80], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0143
       mov      rax, bword ptr [rbp-0x70]
       mov      bword ptr [rbp-0x78], rax
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rdi, bword ptr [rbp-0x78]
       mov      rsi, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rax, gword ptr [rbp-0x08]
       mov      byte  ptr [rax+0x58], 1
 
G_M000_IG11:                ;; offset=0x017C
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       mov      dword ptr [rbp-0x84], eax
       jmp      G_M000_IG19
 
G_M000_IG12:                ;; offset=0x0191
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x30], 0
       jne      G_M000_IG14
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x40], rax
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x48], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG13
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyIteration:GetSyncEnumerable(System.Object,Lokad.Lython.LythonSourceSpan):System.Collections.Generic.IEnumerable`1[System.Object]]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x28]
       mov      rsi, gword ptr [rbp-0x58]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG13:                ;; offset=0x01FE
       mov      rdi, gword ptr [rbp-0x50]
       mov      r11, 0x7649A3A61AF0
       call     [r11]System.Collections.Generic.IEnumerable`1[System.__Canon]:GetEnumerator():System.Collections.Generic.IEnumerator`1[System.__Canon]:this
       mov      rsi, rax
       mov      rax, gword ptr [rbp-0x48]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG14:                ;; offset=0x021F
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x30]
       mov      r11, 0x7649A3A61AE0
       call     [r11]System.Collections.IEnumerator:MoveNext():bool:this
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x30]
       mov      r11, 0x7649A3A61AE8
       call     [r11]System.Collections.Generic.IEnumerator`1[System.__Canon]:get_Current():System.__Canon:this
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, 1
 
G_M000_IG15:                ;; offset=0x025E
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x0267
       mov      rax, 0x7641C5801640
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG17:                ;; offset=0x027D
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x027F
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x0288
       movzx    rax, byte  ptr [rbp-0x84]
 
G_M000_IG20:                ;; offset=0x028F
       add      rsp, 144
       pop      rbp
       ret      
 
; Total bytes of code 664

; Assembly listing for method Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 208
       lea      rbp, [rsp+0xD0]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu32 zmmword ptr [rbp-0x50], zmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x10], rsi
 
G_M000_IG02:                ;; offset=0x003E
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x58]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x08], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0055
       mov      rdi, 0x7649A6377AB8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0064
       mov      rdi, 0x7649A6377ABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7641C5801640
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG20
 
G_M000_IG05:                ;; offset=0x008E
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x18], 0
       je       SHORT G_M000_IG06
       mov      rdi, 0x7649A6377AC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x88], rax
       mov      rdi, gword ptr [rbp-0x88]
       mov      rsi, 0x7649A6377AC8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, bword ptr [rbp-0x10]
       mov      r11, 0x7649A3A61C98
       call     [r11]Lokad.Lython.Runtime.IPyIteratorValue:TryMoveNext(byref):bool:this
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG22
 
G_M000_IG06:                ;; offset=0x0102
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x30], 0
       jne      G_M000_IG15
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x20], rax
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7649A62DB958
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG08
       mov      rsi, gword ptr [rbp-0x20]
       mov      rdi, 0x7649A61E3C00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG07:                ;; offset=0x014F
       mov      rdi, 0x7649A6377BD0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x015E
       mov      rax, gword ptr [rbp-0x08]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp-0x08]
       lea      rsi, bword ptr [rax+0x54]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG09:                ;; offset=0x0182
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG10:                ;; offset=0x018C
       mov      rax, bword ptr [rbp-0x10]
       mov      bword ptr [rbp-0x70], rax
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG12
       mov      rax, bword ptr [rbp-0x70]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, 0x7641C5801640
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x80], rax
       jmp      SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x01BD
       mov      rdi, 0x7649A6377BD4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x01CE
       mov      rdi, 0x7649A6377BD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x70]
       mov      bword ptr [rbp-0x78], rax
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG13:                ;; offset=0x01F3
       mov      rdi, bword ptr [rbp-0x78]
       mov      rsi, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7649A6377BDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      byte  ptr [rax+0x58], 1
 
G_M000_IG14:                ;; offset=0x0225
       mov      rdi, 0x7649A6377BE0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG22
 
G_M000_IG15:                ;; offset=0x0249
       mov      rax, gword ptr [rbp-0x08]
       cmp      gword ptr [rax+0x30], 0
       jne      G_M000_IG17
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x40], rax
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x48], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG16
       mov      rdi, 0x7649A6377BE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyIteration:GetSyncEnumerable(System.Object,Lokad.Lython.LythonSourceSpan):System.Collections.Generic.IEnumerable`1[System.Object]]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x08]
       lea      rdi, bword ptr [rax+0x28]
       mov      rsi, gword ptr [rbp-0x58]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG16:                ;; offset=0x02C5
       mov      rdi, 0x7649A6377BE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x90], rax
       mov      rdi, gword ptr [rbp-0x90]
       mov      rsi, 0x7649A6377BF0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      r11, 0x7649A3A61C90
       call     [r11]System.Collections.Generic.IEnumerable`1[System.__Canon]:GetEnumerator():System.Collections.Generic.IEnumerator`1[System.__Canon]:this
       mov      rsi, rax
       mov      rax, gword ptr [rbp-0x48]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG17:                ;; offset=0x0327
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x98], rax
       mov      rdi, gword ptr [rbp-0x98]
       mov      rsi, 0x7649A6377CF8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7649A3A61C80
       call     [r11]System.Collections.IEnumerator:MoveNext():bool:this
       test     eax, eax
       je       SHORT G_M000_IG19
       mov      rdi, 0x7649A6377E00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, 0x7649A6377E08
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      r11, 0x7649A3A61C88
       call     [r11]System.Collections.Generic.IEnumerator`1[System.__Canon]:get_Current():System.__Canon:this
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, 1
 
G_M000_IG18:                ;; offset=0x03D9
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x03E2
       mov      rdi, 0x7649A6377F10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x7641C5801640
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG20:                ;; offset=0x0407
       xor      eax, eax
 
G_M000_IG21:                ;; offset=0x0409
       add      rsp, 208
       pop      rbp
       ret      
 
G_M000_IG22:                ;; offset=0x0412
       movzx    rax, byte  ptr [rbp-0xA4]
 
G_M000_IG23:                ;; offset=0x0419
       add      rsp, 208
       pop      rbp
       ret      
 
; Total bytes of code 1058

; Assembly listing for method Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 75360
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       sub      rsp, 24
       lea      rbp, [rsp+0x30]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       mov      qword ptr [rbp-0x20], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x001F
       cmp      byte  ptr [rbx+0x58], 0
       jne      G_M000_IG17
       cmp      gword ptr [rbx+0x08], 0
       je       G_M000_IG17
       mov      rdi, gword ptr [rbx+0x18]
       test     rdi, rdi
       jne      SHORT G_M000_IG07
       mov      rsi, gword ptr [rbx+0x30]
       test     rsi, rsi
       je       SHORT G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0046
       mov      rdi, gword ptr [rbx+0x30]
       mov      r14, 0x7649A6322E58
       cmp      qword ptr [rdi], r14
       jne      G_M000_IG15
       call     [Lokad.Lython.Runtime.PyRange+<Iterate>d__21:MoveNext():bool:this]
 
G_M000_IG04:                ;; offset=0x0063
       test     eax, eax
       je       G_M000_IG17
       mov      rdi, gword ptr [rbx+0x30]
       cmp      qword ptr [rdi], r14
       jne      G_M000_IG16
       mov      rsi, gword ptr [rdi+0x08]
 
G_M000_IG05:                ;; offset=0x007C
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x0089
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0094
       mov      rsi, r15
       mov      r11, 0x7649A3A61CD0
       call     [r11]Lokad.Lython.Runtime.IPyIteratorValue:TryMoveNext(byref):bool:this
       mov      ebx, eax
       jmp      G_M000_IG19
 
G_M000_IG08:                ;; offset=0x00AB
       mov      r14, gword ptr [rbx+0x08]
       mov      rsi, r14
       mov      rdi, 0x7649A62DB958
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG09
       mov      rsi, r14
       mov      rdi, 0x7649A61E3C00
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x00DD
       mov      rdi, gword ptr [rbx+0x08]
       lea      rsi, bword ptr [rbx+0x54]
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x28], rax
       mov      qword ptr [rbp-0x20], rdx
       cmp      byte  ptr [rbp-0x20], 0
       jne      SHORT G_M000_IG10
       mov      rdi, 0x7641C5801640
       mov      rsi, gword ptr [rdi]
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0108
       lea      rdi, [rbp-0x28]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rsi, rax
 
G_M000_IG11:                ;; offset=0x0115
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       cmp      byte  ptr [rbp-0x20], 0
       jne      SHORT G_M000_IG12
       mov      byte  ptr [rbx+0x58], 1
 
G_M000_IG12:                ;; offset=0x0127
       movzx    rbx, byte  ptr [rbp-0x20]
       jmp      G_M000_IG19
 
G_M000_IG13:                ;; offset=0x0130
       mov      rdi, gword ptr [rbx+0x28]
       test     rdi, rdi
       jne      SHORT G_M000_IG14
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.PyIteration:GetSyncEnumerable(System.Object,Lokad.Lython.LythonSourceSpan):System.Collections.Generic.IEnumerable`1[System.Object]]
       mov      r14, rax
       lea      rdi, bword ptr [rbx+0x28]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, r14
 
G_M000_IG14:                ;; offset=0x0159
       mov      r11, 0x7649A3A61CC8
       call     [r11]System.Collections.Generic.IEnumerable`1[System.__Canon]:GetEnumerator():System.Collections.Generic.IEnumerator`1[System.__Canon]:this
       mov      rsi, rax
       lea      rdi, bword ptr [rbx+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG03
 
G_M000_IG15:                ;; offset=0x0177
       mov      r11, 0x7649A3A61CB8
       call     [r11]System.Collections.IEnumerator:MoveNext():bool:this
       jmp      G_M000_IG04
 
G_M000_IG16:                ;; offset=0x0189
       mov      r11, 0x7649A3A61CC0
       call     [r11]System.Collections.Generic.IEnumerator`1[System.__Canon]:get_Current():System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG05
 
G_M000_IG17:                ;; offset=0x019E
       mov      rdi, 0x7641C5801640
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x01B5
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x01C0
       movzx    rax, bl
 
G_M000_IG20:                ;; offset=0x01C3
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 462

