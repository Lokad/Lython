from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;stage=r/'b743';out=Path('benchmarks/results/2026-11-14-range-iteration-cost');out.mkdir()
status=json.loads((stage/'terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace']
assert hashlib.sha256((stage/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
gate=dict(source='Committed3bc513b8/frozenca1e2331; full43618009133 still in progress when captured',demonstrated='995 guest leaves/5.0 guest CPU s;38unknown/0ambiguous. Range generated MoveNext326 leaves, Cursor.TryMoveNextCore66; owning/inlined useful work, not removable shares. Final R361counterallocation~3.2MB/100kpulls supports boxed-yield volume; no allocation stack or CPU speedup inferred.',hypothesis='Replace range iteration/boxed native transport as one stage, retaining existing cursor and integer working storage; not another ordinary-frame representation.',expectedProductionInputs=['Runtime/PyCoreIterators.cs:replace compiler-generated PyRange.Iterate state machine with one shared explicit range enumerator, preserving existing Python/CLR interfaces','Runtime/PyIteration.cs:acquire that enumerator once for exact ranges and expose a primitive pull beside existing object pulls; share position/EOF/disposal across sync/async','Runtime/LythonRuntime.Executable.NativePrefix.cs:publish primitive range pulls through existing private integer storage only when already prepared; materialize before existing observation/transfer boundaries'],displaced='Generated range MoveNext/object-current pipeline and per-yield boxes in eligible native numeric loops. Generic object iteration uses the same range state; no dormant alternate range engine. No new compiler fact pass or unconditional storage for unrelated for loops.',ownership='Reuse range owner/current cursor lifetime, current BigInteger major-value funding and stable publication. No root tracing/ledger/pool/new memory scope or allowance. Small primitive fields remain private iterator metadata; no borrowed native span escapes. Keep per-execution constructor metadata.',tradeoffs='Preserve PyRange CLR interfaces to avoid changing generic projection/serialization/type routing. A simple enumerable adapter plus independent enumerator may add small legacy acquisition overhead; measure materializing/short controls. Checked int64 bounds/progression can avoid per-pull BigInteger transport; exact wider path and large-yield preflight must remain shared. Do not add all-for-loop working arrays: reuse only already prepared native integer storage.',acceptance=['Exact signed/int64-boundary/wider starts/stops/strides,empty/negative/huge lengths and sticky exhaustion','Independent/repeated enumerators,stable Current/aliases,iter(range) identity and Python-shaped errors','Range aliases through native-to-owned-frame transfer,real I/O,early exit/generators/closures and cancellation','First refusal before body effects,large yield allocation origin,retained results/shared-budget reuse and awaited cleanup','Existing unsupported JSON/projection behavior and generic object iteration preserved'],bound='One coherent three-file prototype or concrete source rejection; focused actual11/10 controls and Python goldens before bounded same-work counter warm/fresh+CSV/materializing/short/observed controls. Allocation separate; explicit retention/debt. One current profile is enough for selection; no further attribution inventory without a specific new question.',notMeasured='No CPU delta, predicted speedup,current CPython ratio,contention,heap peak or embedding tail-latency claim.',publicationHeld=True)
(out/'source-gate.json').write_text(json.dumps(gate,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['identity.json','prospective.json','attribution-range.json','leaf-census.json','terminal-status.json','archive-receipt.json']:shutil.copyfile(stage/n,out/n)
shutil.copyfile(stage/'observations.tgz',out/'observations.tgz')
with tarfile.open(out/'collection-and-analysis.tar.xz','w:xz')as t:
    for p in sorted(stage.iterdir()):
        if p.is_file()and p.name!='observations.tgz':t.add(p,arcname=p.name)
    for n in ['profile.py','analyze.py','save-gate.py']:t.add(r/n,arcname=n)
(out/'README.md').write_text('''# Remaining range-iteration stage: source selection

R362/B743, 2026-11-14 UTC, committed `3bc513b8` / frozen `ca1e2331`.
Full 43618009133 is still in progress at capture time. Same quiet F4as_v7 /
Ubuntu 24.04.4 / four EPYC 9V45 / .NET 11 RC3, fixed worker and optional 0.4
adapter. Original complete inside-range 100,000-add script, exact stdout/budget.
One 5-second 199 Hz cpu-clock/fp capture after eight guest seconds warmup;
same-process cursor-pull JIT map/disassembly. PerfMap/JIT overrides are diagnostic,
not normal timing. No source-pair, allocation-stack or CPython comparison.

995 guest leaves /5.0 guest CPU seconds, 38 unknown, zero ambiguous.

| Leaf owner, including inlined useful work | Samples |
| --- | ---: |
| Generated PyRange.Iterate.MoveNext | 326 |
| Native RunCore | 221 |
| Native TryIntegerOperation | 179 |
| Cursor.TryMoveNextCore | 66 |
| TryMachineBinary | 52 |
| AugmentedBinaryOperator | 38 |

These are attribution counts, not removable shares. Range iteration is now a
demonstrated substantial component after the shared arithmetic/native-storage
deliveries. R361's approximately 3.2 MB/100,000 pulls independently supports the
boxing-volume hypothesis; it does not assign CPU time to allocation.

Select one iteration-stage prototype: replace range's generated enumerator with
shared explicit state, expose a primitive pull through the existing cursor and
publish through native integer storage only where already prepared. Generic
object iteration shares that state. Preserve range's CLR/Python interfaces,
independent enumerators, Current/EOF, exact large bounds, stable aliases and large
yield funding. Avoid adding CLR collection interfaces that might change generic
serialization/projection. A small iterable adapter may add legacy acquisition
overhead; materialization/short controls must expose it. No ordinary-frame scalar
state, new compiler pass, universal values, controller, pool or ownership layer.

This is a source selection, **not an implemented or measured redesign**. Concrete
deletions, ownership limits, focused acceptance and the bounded counter/fresh/
CSV/materialization/short/observed comparison are in the source gate. No speedup
forecast. Whole-script and independent regex work remain active; publication held.

All image/golden/budget/quiet/join/archive checks pass. The trace was SHA-verified
persistently under the lease before RAM unmount; no users/fixtures remain.
Only exact committed raw-result duplicate files were retired for staging; current
images, catalogs, auxiliaries, toolchains and 254/252 MiB floors remain unchanged.
Raw SHA256 `1d60785ff7088274d48e9637422d420df3faf4e9b21001fc2c57f608ea3bc3a6`.

[Source/ownership design](source-gate.json), [attribution](attribution-range.json),
[all leaves](leaf-census.json), [raw trace/maps/conditions](observations.tgz),
[collector/analysis](collection-and-analysis.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## R362 — current range iteration source selection

[B743 at committed3bc/frozenca1](results/2026-11-14-range-iteration-cost/README.md)
keeps995guest leaves/38unknown/0ambiguous after R361: generatedrangeMoveNext326,
cursorpull66, nativeRunCore221. Counts include useful/inlined work and predict no
speedup. All gates/joins/persistent archive pass. Select one shared range-iterator/
native-pull stage using existing cursor and already prepared primitive storage;
preserve Python/CLR interfaces, independent enumeration, exact bounds/aliases,
large-yield funding, cancellation and actual transfer cleanup. No new frame value
system, fact pass, pool or owner. Legacy acquisition overhead is a control/tradeoff.
Source selection only, no prototype/CPUdelta; full43618009133 remains independent.
''',encoding='utf-8',newline='\n');print('One current owning profile/source decision archived; no runtime prototype or speedup claim.',flush=True)
