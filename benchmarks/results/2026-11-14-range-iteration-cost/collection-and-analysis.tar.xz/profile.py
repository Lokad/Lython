from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b743';out.mkdir();prior=r.parent/'frame-primitive-transport-r360/b738';source=r.parent/'native-range-r361/native-only/b742';identity=json.loads((source/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Committed3bc513b8/frozenca1e2331; full43618009133 active, not yet qualified',purpose='One current inside-range counter CPU profile: assess remaining range enumerator/boxed-yield transport versus useful arithmetic/native dispatch. 3.2MB/100kpulls is source/allocation evidence, not CPU attribution.',diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,disassemblyCollectedInTheSameProcessAsSamples=True,noSpeedupForecast=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldroot='frame-profile-b738-20261114';newroot='range-iteration-b743-20261114';unit='lython-b743-range-iteration-20261114'
for n in ['ops-profile.py','collect.py']:
    s=(prior/n).read_text(encoding='utf-8').replace(oldroot,newroot).replace("'csv-while'","'range-inside'").replace("'diagnostic.csv-check-digits.while.large'","'diagnostic.loop-range.inside.large'").replace('*TryMachineInstruction*','*TryMoveNextCore*').replace('primitive-instruction.asm','cursor-pull.asm').replace('R360uncommitted/frozenb9ad2490; one owning CSVtransport profile','Committed3bc513b8/frozenca1e2331; current counter iteration attribution')
    ast.parse(s);(out/n).write_text(s,encoding='utf-8',newline='\n')
(out/'run.sh').write_text("set -eu\nroot=/home/lokad/lython-bench-checks/"+newroot+"\ntrap 'result=$?; printf \"%s\\n\" \"$result\" > \"$root/exit-code.txt\"' EXIT\npython3 \"$root/collect.py\"\n",encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(question=identity['purpose'],bound='One5s199Hzcpu-clock/fp after8guestsecondwarmup,64invocationrequests,120sowner. Currentfrozenimage/catalog/normalGC/tiering, PerfMap/JITdisasm diagnostic overrides only.',hypothesis='PyRange generated object enumerator boxes each yielded value before native publication; assess one shared range-iteration state/observation boundary, preserving existing cursor ownership. No universal value/frame/controller/pool rewrite.',acceptance='Exact signed/hugebounds/overflow,Pythonaliases/identity,Current/stickyEOF,earlyexit,activecursortransfer/realIO,cancel/refusalbeforeeffects,retainedfunding/cleanup. Delete displaced iterator/storage if a coherent prototype is selected.',stopping='One owning capture/sourcegate selects a concrete coherent design or supported rejection. No speedup forecast from samples or allocation; retain unknowns/raw and all adverseR361controls. Not another open-ended inventory.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for n in ['identity.json','ops-profile.py','collect.py','run.sh','prospective.json']:t.add(out/n,arcname=n)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();duplicates=[];archives={}
for folder,run,remote_root in [('native-only','b742','native-range-complete-b742-20261114'),('initial','b740','native-range-b740-20261114'),('owned-constructor','b741','owned-range-b741-20261114')]:
    name='benchmarks/results/2026-11-14-closed-range-construction/'+folder+'/sources-checks-and-observations.tar.xz'
    blob=subprocess.check_output(['git','show',head+':'+name]);assert hashlib.sha256(blob).hexdigest()==hashlib.sha256(Path(name).read_bytes()).hexdigest()
    names=['confirmation/machine-before.json','confirmation/machine-after.json']
    if folder=='native-only':names+=['confirmation/confirmation.json','observations.tgz']
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:
        for relative in names:
            member=run+('/'+relative if relative=='observations.tgz'else'/retrieved/'+relative);body=t.extractfile(member).read()
            duplicates.append(dict(commit=head,canonicalArchive=name,archiveSHA256=hashlib.sha256(blob).hexdigest(),member=member,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),remote=remote_root+'/'+relative))
c=dict(root='/home/lokad/lython-bench-checks/'+newroot,sourceRoot='/home/lokad/lython-bench-checks/native-range-complete-b742-20261114',unit=unit,identity=identity,duplicates=duplicates,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
code=(prior/'launch-command.py').read_text(encoding='utf-8');start=code.index('config=');end=code.index('\nbase=',start);code=code[:start]+'config='+repr(c)+code[end:];code=code.replace('lython-b738-fixtures','lython-b743-fixtures')
old=" before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']+32768"
new=""" paths=[]
 for item in config['duplicates']:
  p=base/item['remote'];info=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and p.is_file()and not p.is_symlink()and info.st_uid==os.getuid()and info.st_nlink==1
  assert info.st_size==item['bytes']and digest(p)==item['sha256'];paths.append(p)
 before=shutil.disk_usage(base).free
 assert before+sum(p['bytes']for p in config['duplicates'])>254*1024*1024+config['unpackedBytes']+32768
 for p in paths:p.unlink()
 (base/'b743-proved-committed-result-duplicates-retirement.json').write_text(json.dumps(dict(proofs=config['duplicates'],retiredOnly=[str(p)for p in paths],freshIdleLease=True,currentImagesCatalogsAuxiliariesToolchainPreserved=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free))+chr(10))
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+32768"""
assert old in code;code=code.replace(old,new).replace('noRetirement=True','retiredOnlyByteProvenCommittedResultDuplicates=True');ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');(out/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'retrieve.py').read_text(encoding='utf-8').replace(oldroot,newroot).replace('lython-b738-frame-profile-20261114',unit).replace('B738','B743');ast.parse(s);(out/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
(out/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'";done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=60)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=60)).isoformat(),flush=True)
