from pathlib import Path
import ast,json,runpy
r=Path(__file__).parent;out=r/'b743';old=r.parent/'frame-primitive-transport-r360/b738/analyze-primitive.py'
s=old.read_text(encoding='utf-8').replace('profiles/csv-while','profiles/range-inside').replace('R360uncommitted/frozenb9ad2490 complete CSVwhile CPU attribution','Committed3bc513b8/frozenca1e2331 current numeric-loop CPU attribution').replace('attribution-primitive.json','attribution-range.json');ast.parse(s);p=out/'analyze-range.py';p.write_text(s,encoding='utf-8',newline='\n');a=runpy.run_path(str(p))
for name,count in a['leaves'].most_common(20):print(count,name,flush=True)
print('Nearest owning frames:',flush=True)
for name,count in a['guest'].most_common(14):print(count,name,flush=True)
(out/'leaf-census.json').write_text(json.dumps(dict(leaves=a['leaves'].most_common(),nearest=a['guest'].most_common(),sampleCount=a['leaves'].total(),interpretation='Owning CPU samples include useful/inlined work, not removable CPU shares or a speed forecast.'),indent=2)+'\n',encoding='utf-8',newline='\n')
