from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'));bound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'))
assert not(r/'terminal-status.json').exists()
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
code=r'''from pathlib import Path
import fcntl,json,subprocess
config=CONFIG
root=Path(config['root'])
service=subprocess.run(['systemctl','show',config['unit']+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True)
if'ActiveState=active'in service.stdout:print(json.dumps(dict(live=True,service=service.stdout)));raise SystemExit(0)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(live=False,service=service.stdout,exitCode=(root/'exit-code.txt').read_text().strip()if(root/'exit-code.txt').exists()else None,receipt=json.loads((root/'archive-receipt.json').read_text())if(root/'archive-receipt.json').exists()else None,remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,remainingTrace=(root/'guest-fixtures').exists(),journal=subprocess.run(['journalctl','-u',config['unit']+'.service','-n','20','--no-pager'],capture_output=True,text=True).stdout)))
'''.replace('CONFIG',repr(config))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
status=json.loads(done.stdout);(r/('observation-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(done.stdout,encoding='utf-8',newline='\n');print(done.stdout,flush=True)
if status['live']:raise SystemExit(0)
assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingTrace']
assert status['receipt']['ramTraceArchivedAndVerifiedBeforeUnmount']and status['receipt']['quietBeforeAndAfter']
(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['archive-receipt.json','observations.tgz']:
 done=subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+name,str(r/name)],capture_output=True);assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as a:
 members=a.getmembers();regular=[m for m in members if m.isfile()or m.isdir()];assert all(m.isfifo()and m.size==0 for m in members if m not in regular)
 a.extractall(out,members=regular,filter='data')
print('One CPU profile preserved and SHA-verified; terminal cached, all users joined and RAM traces archived before unmount.',flush=True)
