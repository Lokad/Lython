from pathlib import Path
import hashlib,os,shutil,subprocess
r=Path(__file__).parent;target=r/'tests-before'
shutil.copytree('tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0',target,copy_function=os.link)
(target/'Lokad.Lython.dll').unlink();shutil.copyfile(r/'baseline-core.dll',target/'Lokad.Lython.dll')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
args=[env['DOTNET_ROOT']+'/dotnet.exe','vstest',str(target/'Lokad.Lython.PublicApi.Tests.dll'),
    '--TestCaseFilter:FullyQualifiedName~PartialLinesKeepStorageThroughPendingRefillAndClose',
    '--logger:trx;LogFileName=baseline-pending-lines-net11.trx','--ResultsDirectory:'+str(r.resolve())]
done=subprocess.run(args,env=env,capture_output=True,text=True,encoding='utf-8')
(r/'baseline-pending-lines-net11.log').write_text(done.stdout+done.stderr,encoding='utf-8')
print(done.stdout[-1300:]+done.stderr)
assert done.returncode==0
