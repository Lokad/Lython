from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'syntax-validation-b418-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'buffered-lines-b420-20261107').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 archive=root/'observations.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='b531480cb20b9e43e93a6856bc83ceb84a38d723bcee77cde5fcfebba76228b7'
 with tarfile.open(archive) as t:expected=t.extractfile('baseline-core.dll').read()
 targets=[root/'baseline-core.dll',root/'reference/Lokad.Lython.dll']
 for p in targets:
  assert p.resolve()==p and p.is_file() and p.read_bytes()==expected and p.stat().st_nlink==2
 rows=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(expected).hexdigest(),archiveMemberVerified=True) for p in targets]
 for p in targets:p.unlink()
 print(json.dumps(dict(removedOnlyRedundantExtractedCopies=rows,archiveRetainedAndVerifiedLocallyAndRemotely=True,selectedB418CandidateUnchanged=True)))
