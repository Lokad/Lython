from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path(__file__).parent;old=r.parent/'syntax-validation-r62'
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'syntax-validation-b418-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'buffered-lines-b420-20261107').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 archive=root/'observations.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='DIGEST'
 with tarfile.open(archive) as t:expected=t.extractfile('baseline-core.dll').read()
 targets=[root/'baseline-core.dll',root/'reference/Lokad.Lython.dll']
 for p in targets:
  assert p.resolve()==p and p.is_file() and p.read_bytes()==expected and p.stat().st_nlink==2
 rows=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(expected).hexdigest(),archiveMemberVerified=True) for p in targets]
 for p in targets:p.unlink()
 print(json.dumps(dict(removedOnlyRedundantExtractedCopies=rows,archiveRetainedAndVerifiedLocallyAndRemotely=True,selectedB418CandidateUnchanged=True)))
'''.replace('DIGEST',receipt['archiveSHA256'])
compile(code,'reclaim','exec');(r/'reclaim-command.py').write_text(code,encoding='utf-8')
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True)
(r/'reclaim.log').write_text(done.stdout+done.stderr,encoding='utf-8');print(done.stdout+done.stderr,flush=True);assert done.returncode==0
payload=(r/'payload.tgz').read_bytes()
done=subprocess.run(ssh+['python3 /home/lokad/lython-bench-checks/buffered-lines-b420-launch.py'],input=payload,capture_output=True)
(r/'corrected-launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode('utf-8'),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=240,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observe after '+(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
