from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'buffered-lines-b420-20261107'
reference=base/'syntax-validation-b418-20261107/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1922615+1)
 assert len(payload)==1922615 and hashlib.sha256(payload).hexdigest()=='81b8c4cf38d06392e62da944119cdd4590324d2cace72fd36d2246f6c129743f'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role in ['reference','candidate']:
  target=root/role;shutil.copytree(reference,target,copy_function=os.link)
  if role=='candidate':
   (target/'Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',target/'Lokad.Lython.dll')
 os.link(root/'reference/Lokad.Lython.dll',root/'baseline-core.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 owned_ram=root/'guest-fixtures';assert not owned_ram.exists();owned_ram.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b420-fixtures',str(owned_ram)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==6 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==6" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allSixJobsValidated=True,ownerSeconds=240,stopSeconds=30,marginSeconds=30)
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b420-buffered-lines-20261107','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
