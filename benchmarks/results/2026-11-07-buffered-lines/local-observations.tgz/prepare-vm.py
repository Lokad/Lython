from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;old=r.parent/'syntax-validation-r62';base=r.parent/'compiler-graph-r58'
previous='syntax-validation-b418-20261107';name='buffered-lines-b420-20261107'
def adapt(s):
    return s.replace(previous,name).replace('lython-b418-syntax-validation-20261107','lython-b420-buffered-lines-20261107').replace('syntax-validation-b418-launch.py','buffered-lines-b420-launch.py').replace('lython-b418-fixtures','lython-b420-fixtures')
def save(n,s):
    if n.endswith('.py'):ast.parse(s)
    (r/n).write_text(s,encoding='utf-8',newline='\n')
local=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in local['productionSources'].items())
checks={}
for n in ['initial-internal-net11','initial-public-net11','pending-lines-net11','baseline-pending-lines-net11']:
    a=dict(ET.parse(r/(n+'.trx')).find('.//{*}Counters').attrib);assert a['failed']=='0';checks[n]=a
(r/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
catalog=json.loads((r.parent/'wildcard-utf8-r51/b409/representative.json').read_text(encoding='utf-8'))
ids=['scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']
catalog['cases']=[c for c in catalog['cases'] if c['id'] in ids];assert len(catalog['cases'])==4
(r/'representative.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
jobs=[(ids[0],'warm-async'),(ids[1],'warm-async'),(ids[2],'warm-async'),(ids[1],'warm'),(ids[0],'warm'),(ids[3],'warm')]
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
baseline=identity['coreSHA256']['candidate']
identity.update(sourceRevision=local['sourceRevision'],sourcePairBaseline='70267889 fully qualified CI42412531882 / frozen74c88248; controlled source pair includes R65 and R66. Local diagnostic isolates R66 on R65.',
    coreSHA256={'reference':baseline,'reference-control':baseline,'candidate':local['coreSHA256']['candidate'],'candidate-control':local['coreSHA256']['candidate']},
    productionSources=local['productionSources'],jobs=jobs,referenceVersion='Four independent Lython workers; no CPython in this source pair',
    included='Warm and warm-async public execution, mediated RAM I/O, full validation and prior-result cleanup. Compilation/startup/staging/reset/transport/final teardown excluded.')
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=adapt((old/'collect.py').read_text(encoding='utf-8'))
a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n"+s[b:]
s=s.replace("labels=['reference','reference-control','candidate']","labels=['reference','candidate','reference-control','candidate-control']")
s=s.replace('R62 demand-driven validation source-pair confirmation','R66 buffered-line sync/async source-pair confirmation; R65 included')
s=s.replace('started < 150','started < 210')
save('collect.py',s)
s=adapt((old/'archive-owned.py').read_text(encoding='utf-8')).replace("len(r['jobs'])==5","len(r['jobs'])==6").replace('jobs=5','jobs=6')
save('archive-owned.py',s)
save('run.sh',adapt((old/'run.sh').read_text(encoding='utf-8')))
s=adapt((old/'retrieve.py').read_text(encoding='utf-8')).replace("['jobs']==5","['jobs']==6")
save('retrieve.py',s)
s=adapt((old/'launch.py').read_text(encoding='utf-8'))
# Reuse the fully qualified baseline core already on the VM; only one new core
# is staged. Own complete hard-linked images, never symlink a worker DLL.
s=s.replace("reference=base/'compiler-graph-b415-20261107/candidate'","reference=base/'syntax-validation-b418-20261107/candidate'")
a=s.index(" for role,core in [");b=s.index(" (root/'cpython-worker.py')",a)
s=s[:a]+''' for role in ['reference','candidate']:
  target=root/role;shutil.copytree(reference,target,copy_function=os.link)
  if role=='candidate':
   (target/'Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',target/'Lokad.Lython.dll')
 os.link(root/'reference/Lokad.Lython.dll',root/'baseline-core.dll')
'''+s[b:]
s=s.replace('len(jobs)==5','len(jobs)==6').replace("len(r['jobs'])==5","len(r['jobs'])==6").replace('allFiveJobsValidated','allSixJobsValidated')
s=s.replace('ownerSeconds=180','ownerSeconds=240').replace('RuntimeMaxSec=180','RuntimeMaxSec=240').replace('seconds=240','seconds=300')
save('launch.py',s)
contract='''R66/B420 source confirmation:6jobs, async CSV/text/JSON-lines, synchronous text/CSV and synchronous report control. Four independent baseline/current/baseline-control/current-control processes,5s warmup per role/job,11rotated200ms rounds. Baseline qualified70267889/frozen74c88248; current includes R65+R66, local diagnostic separately isolates R66 on5dd131bf. No CPU prediction; retain allocation-neutral/adverse/noisy desktop results. NormalGC/tiering, source/actualReady/auxiliary/goldens/quiet/Closed/join/funding/emptyfixtures. Persistent records/workers; owned separate128MiB tmpfs guest fixtures; archive/verify under lease and locally, join all users/unmount. Only one new core transferred, own hard-linked complete worker images; baseline hard-linked from immutable B418 image.256MiB staging headroom.240sowner+30sstop+30smargin; observe300s. Stop at source/debt decision; bounded refinement/measurement correction if controls or specific adverse phase justify it, retaining original conditions. No new framework, CPython rerun, fixed threshold veto or publication.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=6,roles=4,ownerSeconds=240,stopSeconds=30,marginSeconds=30,observeAfterSeconds=300),indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s+='\nR66/B420 declared:6warm/warm-async jobs, four independent old/current/control\nroles;5s warmup/role,11rotated200ms rounds.240sowner+30sstop+30smargin; observe300s.\nCombined source baseline70267889/frozen74c88248 fully qualified; local diagnostic\nisolates R66 onR65. Allocation neutral, desktop CSV adverse/controls unstable;\nno predicted gain or threshold veto. One new core, complete hard-linked images,\n256MiB staging headroom and all Ready/golden/funding/quiet/join/fixture/archive\ngates. Preserve original variant before any refinement.\n'
p.write_text(s,encoding='utf-8');shutil.copyfile(p,r/'pre-measurement-plan.md')
(r/'vm-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','70267889','--','src','tests']))
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for n in ['collect.py','archive-owned.py','run.sh','representative.json','current-core.dll','focused.json','contract.md','setup-contract.json','pre-measurement-plan.md']:
        t.add(r/n,arcname=n)
    t.add(r/'vm-identity.json',arcname='identity.json');t.add(r/'vm-source.patch',arcname='source.patch')
print(json.dumps(dict(payloadBytes=(r/'payload.tgz').stat().st_size,jobs=jobs,cores=identity['coreSHA256'])))
