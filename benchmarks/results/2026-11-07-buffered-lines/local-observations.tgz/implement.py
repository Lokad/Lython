from pathlib import Path
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs')
s=p.read_text(encoding='utf-8');a=s.index('            public PyString ReadLine(int size)');b=s.index('            public void Release()',a)
assert s[a:b].count('FindLineEndByte')==3 and s[a:b].count('ReadLineIntoAsync')==1
s=s[:a]+'''            public PyString ReadLine(int size)
                => ReadLineCore(size, asynchronous: false).GetAwaiter().GetResult();

            public ValueTask<PyString> ReadLineAsync(int size)
                => ReadLineCore(size, asynchronous: true);

            // Native consumers own their destination through the complete line.
            // The same scanner appends directly; no intermediate string escapes.
            internal bool ReadLineInto(GovernedByteBuilder destination)
            {
                var before = destination.Length;
                _ = ReadLineCore(-1, asynchronous: false, destination).GetAwaiter().GetResult();
                return destination.Length != before;
            }

            internal ValueTask<bool> ReadLineIntoAsync(GovernedByteBuilder destination)
            {
                var before = destination.Length;
                var line = ReadLineCore(-1, asynchronous: true, destination);
                if (!line.IsCompletedSuccessfully) return AwaitLineIntoAsync(line, destination, before);
                _ = line.GetAwaiter().GetResult();
                return new(destination.Length != before);
            }

            private static async ValueTask<bool> AwaitLineIntoAsync(ValueTask<PyString> pending,
                GovernedByteBuilder destination, int before)
            {
                _ = await pending.ConfigureAwait(false);
                return destination.Length != before;
            }

            private ValueTask<PyString> ReadLineCore(int size, bool asynchronous,
                GovernedByteBuilder? destination = null)
            {
                if (size == 0) return new(PyString.Empty);
                var ownsBuilder = destination is null;
                var builder = destination;
                var remaining = size;
                var transferred = false;
                try
                {
                    while (true)
                    {
                        _services.CheckExecution(null);
                        if (_windowConsumed >= _window.Length)
                        {
                            if (asynchronous)
                            {
                                var refill = RefillAsync();
                                if (!refill.IsCompleted)
                                {
                                    var result = ReadLineAfterRefillAsync(refill, remaining, builder, ownsBuilder);
                                    transferred = true;
                                    return result;
                                }
                                refill.GetAwaiter().GetResult();
                            }
                            else Refill();
                        }
                        if (TryReadLineWindow(ref remaining, ref builder, ownsBuilder, out var line))
                            return new(line);
                    }
                }
                finally { if (ownsBuilder && !transferred) builder?.Release(); }
            }

            // A pending refill transfers the private builder to this one iterative
            // continuation. Caller-owned destinations remain with their caller.
            private async ValueTask<PyString> ReadLineAfterRefillAsync(ValueTask refill, int remaining,
                GovernedByteBuilder? builder, bool ownsBuilder)
            {
                try
                {
                    await refill.ConfigureAwait(false);
                    while (true)
                    {
                        _services.CheckExecution(null);
                        if (TryReadLineWindow(ref remaining, ref builder, ownsBuilder, out var line)) return line;
                        await RefillAsync().ConfigureAwait(false);
                    }
                }
                finally { if (ownsBuilder) builder?.Release(); }
            }

            private bool TryReadLineWindow(ref int remaining, ref GovernedByteBuilder? builder,
                bool ownsBuilder, out PyString line)
            {
                if (Drained())
                {
                    line = ownsBuilder ? EmitAccumulated(builder) : PyString.Empty;
                    return true;
                }

                var bytes = _window.Span;
                var end = TextLineScanning.FindLineEndByte(bytes, _windowConsumed, _newline);
                if (remaining >= 0)
                {
                    end = WindowEndAfterRunes(end, remaining, out var taken);
                    remaining -= taken;
                }

                // The decoder's CR holdback makes a terminator at the window
                // edge complete. An unterminated edge needs another refill.
                if (end < bytes.Length || EndsWithTerminator() || remaining == 0)
                {
                    if (builder is null)
                    {
                        line = CopyWindowRange(_windowConsumed, end);
                        Advance(end);
                    }
                    else
                    {
                        AppendRange(builder, _windowConsumed, end);
                        line = ownsBuilder ? EmitAccumulated(builder) : PyString.Empty;
                    }
                    _services.CheckExecution(null);
                    return true;
                }

                builder ??= new GovernedByteBuilder(_services.MemoryGovernor, null);
                AppendRange(builder, _windowConsumed, bytes.Length);
                line = PyString.Empty;
                return false;
            }

'''+s[b:]
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.cs');s=p.read_text(encoding='utf-8')
a=s.index('            public async ValueTask<PyIterationResult> TryMoveNextAsync()');b=s.index('            public async ValueTask<PyList> ReadLinesAsync',a)
assert s[a:b].count('EnsureOpen();')==2
s=s[:a]+'''            public ValueTask<PyIterationResult> TryMoveNextAsync()
            {
                var line = ReadLineAsync(-1);
                return line.IsCompletedSuccessfully ? new(LineResult(line.GetAwaiter().GetResult())) : AwaitNextLineAsync(line);
            }

            private static async ValueTask<PyIterationResult> AwaitNextLineAsync(ValueTask<PyString> line)
                => LineResult(await line.ConfigureAwait(false));

            private static PyIterationResult LineResult(PyString line)
                => line.IsTruthy() ? PyIterationResult.Yield(line) : PyIterationResult.End;

            public ValueTask<PyString> ReadAsync(int size)
            {
                EnsureOpen();
                return RequireReader().ReadAsync(size);
            }

            public ValueTask<PyString> ReadLineAsync(int size)
            {
                EnsureOpen();
                return RequireReader().ReadLineAsync(size);
            }

'''+s[b:]
p.write_text(s,encoding='utf-8')
print('Shared buffered-line scanner and pending-refill continuation implemented; forwarding async wrappers removed.')
