from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-buffered-lines');out.mkdir()
for n in ['observations.tgz','archive-receipt.json','assessment.json','local-assessment.json','final-focused.json','pre-code-plan.md','vm-identity.json']:
    shutil.copyfile(r/n,out/n)
with tarfile.open(out/'local-observations.tgz','w:gz') as t:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.py','.cs','.json','.log','.txt','.md','.trx','.patch','.sh','.dll']:
            t.add(p,arcname=p.name)
    for n in ['warm-sync','warm-async']:t.add(r/n,arcname=n)
with tarfile.open(out/'local-observations.tgz') as t:
    assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==json.loads((r/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
d=json.loads((r/'assessment.json').read_text(encoding='utf-8'));table=[]
for j in d['jobs']:
    values=[x for a in j['elapsedPercent'].values() for x in a]
    cpu=[x for a in j['cpuPercent'].values() for x in a]
    table.append('|'+j['lane']+' / '+j['case'].removeprefix('scripts.')+'|'+f'{min(values):+.2f} to {max(values):+.2f}%'+'|'+f'{min(cpu):+.2f} to {max(cpu):+.2f}%'+'|'+f"{j['baselineSpreadPercent']:+.2f}% / {j['candidateSpreadPercent']:+.2f}%"+'|')
(out/'README.md').write_text('''# Shared buffered-line execution — R66/B420

2026-11-07. Retain the shared line scanner and synchronous buffered prefix.
Current core `15c04e2a` / `5dd131bf` plus frozen R66 patch; local baseline
`77993f5c` isolates R66 on R65. The VM baseline is fully qualified `70267889` /
`74c88248`, so its source pair includes R65 and R66. Normal 0.4 optional adapter
and comparison worker remain unchanged. Exact source/Ready/auxiliary identities
are archived; no speedup is inferred merely from eliminating async source.

Readline and native destination reads use one window scanner/emission routine.
Buffered reads return directly; only a pending refill creates the iterative
continuation. It owns the private builder through actual read completion and
unwind. Caller-owned CSV destinations are never released here. Async file iteration
and simple forwarding wrappers also complete directly. Duplicated sync/async line
algorithms and per-line forwarding state machines disappear: 14 net production
lines are deleted. Existing decoder, CR holdback, newline/scalar bounds, allocation
preflights, alias funding, cancellation, first refusal and awaited close remain.
No new public option, owner, backend, result framework or memory mechanism.
Cooperative cancellation can be observed earlier on buffered reads; exact private
checkpoint locations are not a contract. Public APIs and supported syntax remain.

**637 internal / 3,584 public focused Release checks per actual .NET 11 and 10
PASS.** Matching probes contain corresponding core bytes. Twelve new public cases
use a two-byte decoded window, then a genuinely pending refill and close, covering
readline, iteration, CSV and JSON-lines under completion/cancellation/refusal.
Storage remains funded until real users finish; suppression/finally return and a
secondary close error cannot mask the first refused estimate. Those same twelve
cases pass on the previous R65 core, confirming independent contract coverage.
The initial test fixture compile failure (underscore parameter/discard collision)
and its correction are preserved. No timeout or containment assertion was weakened.

## Controlled complete-script comparison

Quiet F4as_v7/Ubuntu 24.04.4/.NET 11 RC3; four independent baseline/current/
baseline-control/current-control processes, normal GC/tiering, five-second warmup
per role/job, eleven rotated 200 ms rounds. Six jobs complete in 197.560 seconds.
Full stdout/file goldens, source/core/Ready/auxiliary, quiet endpoints, Closed/exit
zero/join/funding/emptyfixtures pass. Persistent evidence is separate from the owned
128 MiB fixture tmpfs, archived/verified under lease and locally; mount removed.
240-second owner + 30-second stop + 30-second margin; observe after 300 seconds.
Terminal/cached; never query B420 again.

Warm clocks include public Run or awaited RunAsync, mediated RAM I/O, full output
validation and prior-result cleanup. Compilation, startup, fixture staging/reset,
transport and final cached teardown are excluded. CPython was not rerun here;
the primary comparison table still describes its recorded `55e510ff` revision.

Positive percentages mean current slower. Ranges compare both current processes
with both baseline processes; CPU is whole-worker CPU, quantized to 10 ms and
including work outside the internal elapsed boundary.

| API / complete script | Elapsed changes | Worker CPU changes | Old / current process spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

Async text and JSON elapsed improve across both candidate processes. Their CPU
observations differ: text improves, JSON is approximately unchanged. Baseline and
current process spreads reach several percent, and synchronous/report observations
include adverse elapsed/CPU points. Within-role precision does not remove between-
process variation. Hashing/JIT/scheduling may contribute; none is established as
the cause. **No general CPU or synchronous-execution speedup is established.**
Preserve the +0.99% synchronous CSV, +2.39% report elapsed and +6.94% report CPU
points and treat remaining magnitude/impact as uncertainty. Retain the coherent
deletion and bounded async elapsed evidence; do not declare the whole-script
objective complete or use a fixed percentage veto. A future bounded confirmation
can control shared hashing/GC or increase process replication if it changes a
decision; no unchanged retiming campaign was run here.

The existing five-script desktop diagnostic independently passes all goldens,
isolation, shared funding and fixture cleanup through both APIs. Allocation is
essentially unchanged. Original async CSV +7.45/+13.94% and large identical-role
drift remain; they are not evidence of a controlled CSV regression or CPU benefit.
Do not combine absolute desktop and VM clocks: their fixture/reset boundaries differ.

Initial staging stopped before measurement at the 256 MiB reserve. Only the two
redundant extracted B418 baseline copies were removed after exact member bytes and
the local/remote immutable archive hashes were verified; archived evidence remains.
The chosen B418 candidate baseline was unchanged. Setup then passed with
271,523,840 free bytes. Original failure, guarded reclaim and launch records remain.

Full combined R65/R66 Windows/Ubuntu, both targets, original Stress and installed
core-consumer qualification is pending at this delivery checkpoint. Publication
remains postponed. R62's cached green receipt does not qualify newer source.

[Controlled assessment](assessment.json), [desktop assessment](local-assessment.json),
[focused checks](final-focused.json), [exact VM source/core inventory](vm-identity.json),
[pre-code plan](pre-code-plan.md), [VM receipt](archive-receipt.json),
[VM raw/source/cores](observations.tgz),
[local source/cores/tests/failures/raw observations](local-observations.tgz).
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8')
s+='''
## Buffered-line execution consolidated (2026-11-07)

[R66/B420](results/2026-11-07-buffered-lines/README.md) replaces duplicated line
algorithms with one scanner and buffered synchronous prefixes; a sole iterative
continuation retains private storage only for pending refills. Native destinations
remain caller-owned; forwarding async state machines disappear (14 net production
lines deleted). 637 internal / 3,584 public per actual11/10 pass, including twelve
two-byte-window pending-read/close cases also green on baseline. Controlled six-job,
four-process pair completes in 197.560s with every semantic/ownership/archive gate.
Async text elapsed −2.32–8.26%, JSON −1.46–3.96%; synchronous and worker CPU results
remain mixed with between-process spreads. Preserve adverse report CPU +6.94%,
sync CSV elapsed +0.99% and original noisy desktop CSV +7.45/+13.94%. Allocation
unchanged; no general CPU/sync gain or objective completion claimed. Retain coherent
deletion and bounded async elapsed evidence; combined delivery qualification pending.
'''
p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s+='''
R66 RETAINED after B420: 637 internal / 3,584 public per actual11/10, new12pending
cases also baseline-green; all source/golden/funding/quiet/archive gates. Async
text elapsed −2.32–8.26%, JSON −1.46–3.96%; allocation neutral. Between-process
variation/quantized CPU and adverse sync CSV/report remain uncertainty, not proved
general CPU/sync improvement. [Evidence](benchmarks/results/2026-11-07-buffered-lines/README.md).
No unchanged retiming now; bounded confirmation remains available when it changes
a decision. B420 terminal/archived/locally verified; no workers/mounts.
Next commit retained R66 and batch full R65/R66 platform/Stress/package delivery.
Then refresh representative CPython comparisons at this coherent runtime checkpoint,
keeping compile/warm/fresh and I/O/cleanup boundaries explicit. Continue independent
roadmap while CI runs; never query cached R62 CI42412531882 again.
'''
p.write_text(s,encoding='utf-8')
print('R66 retained decision and all adverse observations preserved; delivery/primary refresh next.')
