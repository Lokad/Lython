# R275 bounded source gate

Current frozen source43541e78, full qualification active; no production edits.
Reuse immutable config-edit.small16-path fixture, UTF8/UTF16 report3,072-record
fixtures, fixedfec79 worker and adapter0.4. Existing patch fixture is already ahead
of CPython and source presence alone does not warrant another difflib experiment.

Four six-second profiles: config compilation, config compile-plus-one-run, report
UTF8 warm and report UTF16 warm. Existing profiler/protocol/host; normal GC/tiering
plus perf maps only. Keep all active caller/execution/GC CPU and raw stacks:
compilation does not run on the guest execution worker. Profile wider boundaries
include reset/protocol/validation; no timings or CPU speedup claims from sampling.
Full output/files/shared ownership and joined cleanup gate each case. Persistent
catalog/maps/raw/logs separate from bounded RAM fixtures; archive before cleanup.

Stop after this cost/source proof identifies one dominant removable construction,
conversion or analysis stage, or an explicit decision to redirect. No permanent
bans/percentage veto, no unchanged profile replay or broad ownership audit.
Selected redesign must state exact displaced implementation, Python/evaluation
order/cancellation/admission acceptance and one bounded before/after comparison.

Source inspection: object.__new__ and other builtin descriptors retain _owner,
bound during per-run type construction (PyType.BindOwner). Shared fixed functions
and constructor signatures already exist. Do not promote the whole mutable type
graph or describe all repeated builtin metadata as still unshared.
