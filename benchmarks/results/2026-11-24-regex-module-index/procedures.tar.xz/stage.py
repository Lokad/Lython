from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('regex-index-resumption-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
reference='regex-index-resumption-b1569-20261124'
root='regex-module-index-b1570-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path,value):
    write(path,json.dumps(value,indent=2)+'\n')


replicas=[]
for archive, remote in [
    ('benchmarks/results/2026-11-23-closed-native-workspace/','closed-native-workspace-b1486-20261123'),
    ('benchmarks/results/2026-11-23-dictreader-ready-header/','dictreader-ready-header-b1485-20261123'),
    ('benchmarks/results/2026-11-23-dictreader-activation/','dictreader-activation-b1484-20261123'),
]:
    def tracked(file):
        return subprocess.check_output(['git','show','origin/master:'+archive+file],cwd=repo)
    receipt=json.loads(tracked('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
    binary=sha(gzip.decompress(tracked('candidate-core.dll.gz')))
    assert json.loads(tracked('identity.json'))['imageFiles']['candidate'][core]==binary
    replicas.append(dict(path=remote+'/candidate/'+core,sha256=binary,
        observationSHA256=receipt['archiveSHA256'],trackedArchive=archive))
save(lab/'verified-replicas.json',replicas)

original=donor/'comparison/quiet'
collector=(original/'collect.py').read_text(encoding='utf-8')
old="root.parent/'fixed-return-ownership-b1566-20261124'/'candidate'"
assert collector.count(old)==1
collector=collector.replace(old,"root/'reference'").replace('b1569-','b1570-')
assert 'assert len(jobs) == 4' in collector
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    for role in ('reference','candidate'):
        bundle.add(lab/role/core,arcname=role+'-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1569-regex-index-resumption','b1570-regex-module-index').replace('b1569-','b1570-')
assert launch.count("'candidate-core.dll'}")==1
launch=launch.replace("'candidate-core.dll'}","'candidate-core.dll','reference-core.dll'}")
start=launch.index("  image=root/role if role=='candidate'")
end=launch.index(" os.link(reference/'cpython-worker.py'",start)
launch=launch[:start]+'''  image=root/role
  image.mkdir()
  for name,sha in files.items():
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
'''+launch[end:]
import ast
remote_stage, = (n.value for n in ast.walk(ast.parse(launch)) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith('digest=lambda path:'))
compile(remote_stage,'remote-stage','exec')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
shutil.copyfile(donor/'summarize.py',lab/'summarize.py')
