
class Receiver:
    def f(self, name, /, *, ζ='last', café='default', a='first', **kw):
        print(name, a, café, ζ, list(kw.values()), next(iter(kw)) is unmatched)

unmatched = ''.join(['cafe', '\u0301'])
values = {'café': 'matched', unmatched: 42, 'name': 5, 'a': 'start', 'ζ': 'end'}
Receiver().f('bound', **values)
Receiver().f('bound', **{unmatched: 1})

