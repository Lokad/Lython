from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/"quiet"
out=Path("benchmarks/results/2026-11-18-compact-keyword-layout")
read=lambda file:json.loads(file.read_text(encoding="utf-8-sig"))
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
status=read(quiet/"terminal-status.json")
receipt=read(quiet/"archive-receipt.json")
assert status["receipt"]==receipt and status["exitCode"]=="0"
assert not status["live"] and not status["remainingWorkers"] and not status["remainingTrace"]
assert receipt["jobs"]==7 and all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved",
         "quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
archive=quiet/"observations.tgz"
assert sha(archive)==receipt["archiveSHA256"]
identity=read(lab/"frozen-identity.json")
for role,mapping in identity["images"].items():
    assert len(mapping)==32 and read(lab/f"{role}-verify.json")["state"]=="Completed"
    assert {name:sha(lab/"frozen"/role/name) for name in mapping}==mapping
for framework in ("net11.0","net10.0"):
    for prefix,count in (("final-win",734),("final-wsl-public",104),("final-wsl-white",318)):
        assert f"Passed: {count:5d}" in (lab/f"{prefix}-{framework}.log").read_text(encoding="utf-8-sig")
summary=read(lab/"quiet-summary.json")
summary.pop("retentionDecisionPending",None)
summary["retained"]=True
summary["images"]=identity
summary["sourcePatchSHA256"]=sha(lab/"source.patch")
summary["focusedChecksPerFramework"]=dict(windowsPublic=734,ubuntuPublic=104,ubuntuWhiteBox=318)
(out/"summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False)+"\n", encoding="utf-8")
shutil.copyfile(archive,out/archive.name)
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz") as procedure:
    for path,prefix in ((lab,"local"),(quiet,"quiet")):
        for p in sorted(path.iterdir()):
            if p.is_file() and p.suffix in (".sh",".py",".json",".log",".patch"):
                procedure.add(p,arcname=f"{prefix}/{p.name}")
assert sha(out/archive.name)==receipt["archiveSHA256"]
print("Verified seven jobs, both worker images, focused Release results and source patch.")
