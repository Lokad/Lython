from pathlib import Path
import ast, hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
donor=lab.parent/"utf8-keyword-packet-r572"
previous=donor/"quiet"
quiet=lab/"quiet"
quiet.mkdir(exist_ok=False)
load=lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,source):
    if path.suffix==".py": ast.parse(source)
    path.write_text(source,encoding="utf-8",newline="\n")
def save(path,data): write(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")

prior=load(previous/"config.json")
screen=load(lab/"frozen-identity.json")
space=load(lab/"quiet-space.json")
catalog=lab/"catalog.json"
images=screen["images"]
source_files=prior["identity"]["imageFiles"]["reference"]
core="Lokad.Lython.dll"
assert screen["casesSHA256"]==sha(catalog)
for role,files in images.items():
    assert len(files)==32 and files==source_files|{core:files[core]}
    assert {name:sha(lab/"frozen"/role/name) for name in files}==files
    verified=load(lab/f"{role}-verify.json")
    assert verified["state"]=="Completed" and verified["catalogSha256"]==sha(catalog)
    (quiet/role).mkdir()
    if role=="candidate": shutil.copyfile(lab/"frozen"/role/core,quiet/role/core)

target="scripts.report-forwarding.expanded"
jobs=[(target,"warm"),("calls.keyword.medium","warm"),("strings.formatted-report.medium","warm"),
      ("calls.positional.large","warm"),(target,"compile"),("calls.keyword.medium","compile"),(target,"compile-run")]
count=len(jobs)
identity=dict(sourceRevision="0f48fcbbf versus compact UTF-8 keyword layout candidate",
              purpose="R573 compact UTF-8 keyword layout confirmation",
              imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin="0.4.0",
              coreSHA256={label:images[role][core] for role in images for label in (role,role+"-control")})
root="/home/lokad/lython-bench-checks/compact-keyword-layout-b998-20261118"
unit="lython-b998-compact-keyword-layout-20261118"
read=lambda path:path.read_text(encoding="utf-8")
def rename(source):
    return source.replace("Fixed-list unpack source pair","Compact UTF-8 keyword source pair").replace("Native guest keyword source pair","Compact UTF-8 keyword source pair")

runner=rename(read(previous/"collect.py"))
a=runner.index("\njobs = ")
b=runner.index("\nassert len(jobs)",a)
runner=runner[:a]+"\njobs = "+repr(jobs)+runner[b:]
write(quiet/"collect.py",runner.replace("assert len(jobs)==2",f"assert len(jobs)=={count}"))
archive=read(previous/"archive-owned.py").replace("len(raw['jobs'])==2",f"len(raw['jobs'])=={count}").replace("jobs=2,",f"jobs={count},")
write(quiet/"archive-owned.py",archive)
write(quiet/"run.sh",read(previous/"run.sh").replace(prior["root"],root))
assert b"\r" not in (quiet/"run.sh").read_bytes()
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
names=["collect.py","archive-owned.py","run.sh","identity.json","representative.json","candidate/"+core]
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in names: out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
need=254*1024*1024+expanded+512*1024
available=space["freeBytes"]
selected=[]
for proof in sorted(space["replicas"],key=lambda p:-p["bytes"]):
    if available>=need: break
    available+=proof["bytes"]
    selected.append(proof)
save(quiet/"preflight.json",dict(available=available,need=need,withoutRetirement=space["freeBytes"],selected=selected))
assert available>=need,(available,need)
config=dict(root=root,unit=unit,source=prior["root"],sourceRole="reference",sourceFiles=source_files,
            sourceCatalogSHA256=prior["catalogSHA256"],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/"config.json",config)
launcher=read(previous/"remote-launch.py")
a=launcher.index("\nc=")+1
b=launcher.index("\nb=Path(")
launcher=launcher[:a]+"c="+repr(config)+launcher[b:]
write(quiet/"remote-launch.py",launcher.replace("lython-b997-fixtures","lython-b998-fixtures").replace("RuntimeMaxSec=330","RuntimeMaxSec=540"))
retrieve=rename(read(previous/"retrieve.py")).replace("['jobs']==2",f"['jobs']=={count}")
write(quiet/"retrieve.py",retrieve)
launch=rename(read(donor/"launch-quiet.py")).replace("seconds=125","seconds=340").replace("before 125 seconds","before 340 seconds")
write(lab/"launch-quiet.py",launch)
write(lab/"summarize-quiet.py",read(donor/"summarize-quiet.py"))
print("Verified both complete images and",count,"jobs, with",available-need,"bytes above the staging requirement")
