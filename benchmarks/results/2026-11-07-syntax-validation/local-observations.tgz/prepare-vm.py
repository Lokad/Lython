from pathlib import Path
import ast, hashlib, json, shutil, tarfile
import xml.etree.ElementTree as ET

r=Path(__file__).parent
prior=r.parent/'compiler-graph-r58'
old='compiler-graph-b415-20261107'; name='syntax-validation-b418-20261107'
def adapt(s):
    return s.replace(old,name).replace('lython-b415-compiler-graph-20261107','lython-b418-syntax-validation-20261107').replace('compiler-graph-b415-launch.py','syntax-validation-b418-launch.py').replace('lython-b415-fixtures','lython-b418-fixtures')
def save(n,s):
    if n.endswith('.py'): ast.parse(s)
    (r/n).write_text(s,encoding='utf-8',newline='\n')
checks={}
for n in ['initial-internal-net11','initial-public-net11']:
    a=ET.parse(r/(n+'.trx')).find('.//{*}Counters').attrib
    assert int(a['failed'])==0
    checks[n]=a
(r/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
local=json.loads((r/'local-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in local['productionSources'].items())
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=local['sourceRevision'],sourcePairBaseline=local['baseline']['revision'],productionSources=local['productionSources'],
    coreSHA256={'reference':local['coreSHA256']['before'],'reference-control':local['coreSHA256']['before'],'candidate':local['coreSHA256']['candidate']})
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(prior/'representative.json',r/'representative.json')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=adapt((prior/n).read_text(encoding='utf-8'))
    s=s.replace('R58 compiler graph source-pair confirmation','R62 demand-driven validation source-pair confirmation')
    save(n,s)
s=adapt((prior/'launch.py').read_text(encoding='utf-8'))
s=s.replace("reference=base/'invocation-setup-b414-20261107/candidate'", "reference=base/'compiler-graph-b415-20261107/candidate'")
save('launch.py',s)
contract='''R62/B418 demand-driven syntax validation: five existing complete-script jobs, compile CSV/text/report, fresh config, warm text control. Three independent baseline/baseline-control/current workers;5s warmup per role/job,11rotated200ms rounds. No warm speedup predicted. Original diagnostic/allocation/adverse clocks retained. Normal GC/tiering, actual Ready/source/auxiliary/goldens/quiet/Closed/join/emptyfixtures; persistent records and owned128MiB tmpfs guest fixtures; archive/verify under lease and independently locally.256MiB staging headroom.180s owner+30s stop+30s margin, observe only after240s. No CPython refresh for this compiler-only experiment; no CPU claim from allocation. Stop at a source/debt decision, permit bounded measurement correction only when justified.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=5,ownerSeconds=180,stopSeconds=30,marginSeconds=30,observeAfterSeconds=240),indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s += '\nR62/B418 selected after559internal/1492public actual11 checks and716exact\ndiagnostic/validity comparisons. Five compile/fresh/warm control jobs, three\nindependent roles,5s warmup/role,11rotated200ms rounds.180sowner+30sstop+30smargin;\nobserve after240s.256MiB staging headroom; all source/Ready/golden/funding/quiet/\njoin/fixture/archive gates. No warm gain predicted; no fixed threshold veto.\n'
p.write_text(s,encoding='utf-8');shutil.copyfile(p,r/'pre-measurement-plan.md')
members=['collect.py','archive-owned.py','run.sh','representative.json','identity.json','current-core.dll','baseline-core.dll','focused.json','source.patch','contract.md','setup-contract.json','pre-measurement-plan.md']
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for n in members:t.add(r/n,arcname=n)
print(json.dumps(dict(payloadBytes=(r/'payload.tgz').stat().st_size,checks=checks,cores=identity['coreSHA256'])))
