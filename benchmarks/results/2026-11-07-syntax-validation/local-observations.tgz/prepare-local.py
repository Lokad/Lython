from pathlib import Path
import hashlib, json, os, re, shutil, subprocess

r = Path(__file__).parent
for role, filename in [('before', 'baseline-core.dll'), ('candidate', 'current-core.dll')]:
    if role == 'candidate':
        shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', r/filename)
    target = r/'images'/role
    shutil.copytree(r.parent/'compiler-graph-r58/images/candidate', target, copy_function=os.link)
    (target/'Lokad.Lython.dll').unlink()
    shutil.copyfile(r/filename, target/'Lokad.Lython.dll')

identity = dict(sourceRevision='f519e54b plus archived R62 demand-driven validation',
    baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8')),
    coreSHA256={role: hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before', 'candidate']},
    productionSources={str(p).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in Path('src/Lokad.Lython').rglob('*.cs') if not any(x in ['bin', 'obj'] for x in p.parts)})
(r/'local-identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src']))
shutil.copyfile(r.parent/'module-bindings-r49/catalog.json', r/'catalog.json')
s=(r.parent/'admission-reentry-r53/measure.py').read_text(encoding='utf-8')
s=s.replace("[('warm','sync'),('warm','async')]", "[('compile','sync'),('fresh','sync'),('warm','sync')]")
(r/'measure.py').write_text(s, encoding='utf-8')

sources=json.loads((r.parent/'annotation-demand-r38/diagnostic-sources.json').read_text(encoding='utf-8'))
text=Path('tests/Lokad.Lython.PublicApi.Tests/SyntaxValidityTests.cs').read_text(encoding='utf-8')
sources += [json.loads(x) for x in re.findall(r'\[InlineData\(("(?:[^"\\]|\\.)*")\)\]', text)]
for body in [
    'yield 1', 'x = (yield 1)', 'x = lambda: (yield 1)',
    'x = [(yield 1) for i in range(2)]', 'x = [i for i in (yield 1)]',
    'def inner(x=(yield 1)):\n pass', 'def inner(x:(yield 1)):\n pass',
    'x:(yield 1)', 'class Inner:\n x=(yield 1)',
]:
    sources += [body, 'def outer():\n'+'\n'.join(' '+x for x in body.splitlines())]
    sources += ['from __future__ import annotations\n'+s for s in sources[-2:]]
for body in [
    'from __future__ import annotations',
    'x:(y:=1)', 'def f(x:(y:=1)):pass',
    'type Alias = (x:=1)', 'type Alias[T] = (yield 1)',
    'def f[T](x:(y:=1)):pass', 'class C[T]((x:=1)):pass',
    'def f[T]():\n def g():\n  nonlocal T',
    'def f[T]():pass\ndef g():\n nonlocal T',
    'def f[T]():\n class C:\n  def g():\n   nonlocal T',
    'break\ntype Alias = (x:=1)\ndef f[T](x:(y:=1)):pass',
    'x = [(lambda: (i:=1)) for i in range(2)]',
]:
    sources += [body, 'if False:\n'+'\n'.join(' '+x for x in body.splitlines()),
        'x=1\n'+body, 'from __future__ import annotations\n'+body]
sources=list(dict.fromkeys(sources))
(r/'diagnostic-sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(cores=identity['coreSHA256'],diagnosticSources=len(sources))))
