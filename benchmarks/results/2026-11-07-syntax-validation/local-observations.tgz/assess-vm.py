from pathlib import Path
import json, statistics
r=Path(__file__).parent
d=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert d['complete'] and len(d['jobs'])==5
out=dict(complete=True,ownedSeconds=d['elapsedSeconds'],jobs=[])
for job in d['jobs']:
    roles={}
    for role in ['reference','reference-control','candidate']:
        samples=[s for s in job['samples'] if s['engine']==role]
        elapsed=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in samples]
        cpu=[s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in samples]
        q=statistics.quantiles(elapsed,n=4,method='inclusive');median=statistics.median(elapsed)
        roles[role]=dict(seconds=median,cpuSeconds=statistics.median(cpu),iqrPercent=100*(q[2]-q[0])/median)
    c=roles['candidate']
    row=dict(case=job['case'],lane=job['lane'],roles=roles,
        elapsedPercent=[100*(c['seconds']/roles[k]['seconds']-1) for k in ['reference','reference-control']],
        cpuPercent=[100*(c['cpuSeconds']/roles[k]['cpuSeconds']-1) for k in ['reference','reference-control']],
        controlSpreadPercent=100*(roles['reference-control']['seconds']/roles['reference']['seconds']-1))
    out['jobs'].append(row)
    print(row['lane'],row['case'],'current_us',round(c['seconds']*1e6,3),'elapsed%',*[round(x,3) for x in row['elapsedPercent']],'CPU%',*[round(x,3) for x in row['cpuPercent']],'control%',round(row['controlSpreadPercent'],3),'currentIQR',round(c['iqrPercent'],3))
(r/'assessment.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
