from pathlib import Path
import json, statistics
r=Path(__file__).parent
records=[]
for phase in ['compile','fresh','warm']:
    d=json.loads((r/(phase+'-sync')/'measurements.json').read_text(encoding='utf-8'))
    assert all(d[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for o in d['observations']:
        roles={}
        for role in ['before','before-control','candidate']:
            ss=[s for s in o['samples'] if s['image']==role]
            roles[role]={k:statistics.median(s[k]/s['jobs'] for s in ss) for k in ['elapsedMilliseconds','allocatedBytes']}
        current=roles['candidate']
        row=dict(phase=phase,case=o['caseId'],roles=roles,
            allocationPercent=[100*(current['allocatedBytes']/roles[k]['allocatedBytes']-1) for k in ['before','before-control']],
            elapsedPercent=[100*(current['elapsedMilliseconds']/roles[k]['elapsedMilliseconds']-1) for k in ['before','before-control']],
            oldSpreadPercent=100*(roles['before-control']['elapsedMilliseconds']/roles['before']['elapsedMilliseconds']-1))
        records.append(row)
        print(phase,o['caseId'],'allocation',*[round(x,3) for x in row['allocationPercent']],'elapsed',*[round(x,2) for x in row['elapsedPercent']],'control',round(row['oldSpreadPercent'],2))
(r/'local-assessment.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
