from pathlib import Path
import datetime, json, shlex, subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'syntax-validation-b418-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (root/'started.utc').exists() and not (root/'confirmation').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 freeBefore=shutil.disk_usage(base).free
 identity=json.loads((root/'identity.json').read_text())
 for role,filename in [('reference','baseline-core.dll'),('candidate','current-core.dll')]:
  core=root/role/'Lokad.Lython.dll';owned=root/filename
  assert hashlib.sha256(core.read_bytes()).hexdigest()==identity['coreSHA256'][role]
  assert core.read_bytes()==owned.read_bytes()
  core.unlink();os.link(owned,core)
  assert core.stat().st_ino==owned.stat().st_ino
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 assert subprocess.check_output(['findmnt','-T',str(root/'guest-fixtures'),'-n','-o','FSTYPE'],text=True).strip()=='tmpfs'
 assert not list((root/'guest-fixtures').iterdir())
 setup=dict(freeBytesBeforeCorrection=freeBefore,freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,allFiveJobsValidated=True,ownerSeconds=180,stopSeconds=30,marginSeconds=30,originalFailure='Duplicate owned core copies crossed256MiB staging floor before any measurement; replace copies with identical owned hard links. Original failure retained.')
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b418-syntax-validation-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
compile(script,'correct-staging','exec')
(r/'staging-correction-command.py').write_text(script,encoding='utf-8')
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'staging-correction.log').write_text(done.stdout+done.stderr,encoding='utf-8')
print(done.stdout+done.stderr,flush=True)
assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observe after '+(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
