from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks/current-script-cpu-b269-20261105')
base=Path('/home/lokad/lython-bench-checks/current-script-cpu-b268-20261105/candidate')
(root/'candidate').symlink_to(base,target_is_directory=True)
for name,sha in json.loads((root/'identity.json').read_text())['files'].items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==sha
assert shutil.disk_usage(root).free>32*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free)))
