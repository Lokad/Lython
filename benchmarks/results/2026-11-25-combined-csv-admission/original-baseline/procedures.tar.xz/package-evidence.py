from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).resolve().parent
root=lab.parents[3]
quiet=lab/'comparison/quiet'
out=root/'benchmarks/results/2026-11-25-combined-csv-admission/original-baseline'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
summary=read(out/'quiet-summary.json')
assert identity['comparisonRevision'].startswith('4e8e60923')
assert identity['candidateBase'].startswith('0374493f9')
assert summary['reference']==identity['comparisonRevision'] and summary['timedBatches']==28
assert len(summary['rows'])==1 and summary['rows'][0]['case']=='diagnostic.shipment-file-fed-map'
assert sha(lab/'aggregate.patch')==identity['aggregatePatchSHA256']
for role in ('reference','candidate'):
    checked=read(lab/(role+'-verify.json'))
    assert checked['state']=='Completed' and checked['caseCount']==5
    assert checked['catalogSha256']==identity['inputCatalogSHA256']
    assert checked['launched']['library']['sha256']==identity['coreSHA256'][role]
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('prepare.py','quiet.py','archive.py','package-evidence.py','aggregate.patch',
        'reference-verify.json','candidate-verify.json','prepare.log','launch-console.log','retrieve.log'):
        bundle.add(lab/name,arcname=name,recursive=False)
print('Verified all 28 original-baseline batches and both exact image goldens.')
