from pathlib import Path
import hashlib,json,shutil,sys,tarfile,subprocess,os

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
ref=lab.with_name('deferred-callable-locals-refined-20261125')
cand=lab.with_name('csv-combined-record-admission-20261125')
confirmation=lab.with_name('csv-combined-record-confirmation-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
before=cand/'comparison/quiet'; quiet=lab/'comparison/quiet'; refq=ref/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
old_source=subprocess.check_output(['git','rev-parse','4e8e60923'],cwd=repo).decode().strip()
refid=read(refq/'identity.json')
assert subprocess.check_output(['git','diff','--binary',refid['sourceRevision'],old_source,'--','src'],cwd=repo)==(ref/'candidate.patch').read_bytes()
identity=read(before/'identity.json')
original_source=identity['comparisonRevision']
identity['imageFiles']['reference']=refid['imageFiles']['candidate']
for suffix in ('','-control'):
    identity['coreSHA256']['reference'+suffix]=identity['imageFiles']['reference']['Lokad.Lython.dll']
assert identity['imageFiles']['reference'].keys()==identity['imageFiles']['candidate'].keys()
identity['comparisonRevision']=old_source
identity['candidateBase']=original_source
identity['sourcePatchSHA256']=sha(cand/'candidate.patch')
current_patch=lab/'aggregate.patch'
with current_patch.open('wb') as f:
    subprocess.run(['git','diff','--binary',old_source,'--','src'],stdout=f,cwd=repo,check=True)
identity['aggregatePatchSHA256']=sha(current_patch)
identity['purpose']='File-fed CSV map against the pre-comprehension baseline'
shutil.copyfile(before/'representative.json',quiet/'representative.json')
case=next(c for c in read(before/'representative.json')['cases'] if c['id']=='diagnostic.shipment-file-fed-map')
save(quiet/'jobs.json',{'warm':[[case['id'],'warm-async']]})
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
save(quiet/'identity.json',identity)
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,donor in [('reference',ref),('candidate',cand)]:
    image=donor/'candidate'
    files=identity['imageFiles'][role]
    assert len(files)==32 and {p.name:sha(p)for p in image.iterdir()}==files
    evidence=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',evidence],
        cwd=repo,env=env,check=True,timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==5
    assert checked['catalogSha256']==identity['inputCatalogSHA256']
    assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
for name in ('collect.py','run.sh'):
    s=(before/name).read_text(encoding='utf-8').replace('b1738-fixtures','b1739-fixtures')
    s=s.replace('len(jobs) == 5','len(jobs) == 1')
    write(quiet/name,s)
assert b'\r' not in (quiet/'run.sh').read_bytes()
for donor in (before,refq):
    term=read(donor/'terminal-status.json')['receipt']
    assert term['complete'] and sha(donor/'observations.tar.xz')==term['archiveSHA256']
refroot=read(refq/'upload.json')['root']
refarchive=read(refq/'terminal-status.json')['receipt']['archiveSHA256']
s=(confirmation/'quiet.py').read_text(encoding='utf-8').replace('b1738c','b1739')
s=s.replace('seconds=270','seconds=74').replace('RuntimeMaxSec=320','RuntimeMaxSec=123')
s=s.replace("os.link(reference/role/name,image/name)",
            """donor_image=reference/role if role=='candidate' else base/configuration['preComprehension']/'candidate'
   os.link(donor_image/name,image/name)""")
a=s.index("with (base/'comparison-vm.lock').open('a') as lease:",s.index("assert donor['archiveSHA256']=='"))
s=s[:a]+f"""previous=base/configuration['preComprehension']
previous_receipt=json.loads((previous/'archive-receipt.json').read_text())
assert previous_receipt['complete'] and digest(previous/'observations.tar.xz')=={refarchive!r}
"""+s[a:]
compile(s,'quiet.py','exec')
write(lab/'quiet.py',s)
s=(cand/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-combined-csv-admission"',
    '2026-11-25-combined-csv-admission/original-baseline"')
s=s.replace('receipt["warmJobs"]==5','receipt["warmJobs"]==1').replace('timedBatches=140,lanes=5','timedBatches=28,lanes=1')
write(lab/'archive.py',s)
save(lab/'verified-raw-replicas.json',[])
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as tar:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        tar.add(quiet/name,arcname=name)
save(quiet/'upload.json',dict(root='combined-csv-admission-b1739-original-baseline-20261125',
    reference=read(before/'upload.json')['root'],preComprehension=refroot,
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
