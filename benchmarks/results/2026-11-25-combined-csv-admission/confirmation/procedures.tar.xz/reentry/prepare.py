from pathlib import Path
import subprocess,zipfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/'source'
source.mkdir(exist_ok=False)
archive=lab/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',str(archive),'0374493f9','--','src','tests',
 'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config'],
 cwd=repo,check=True)
with zipfile.ZipFile(archive) as z:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
    z.extractall(source)
base=source/'tests/Lokad.Lython.Tests'
shared='''
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ReentrantRawPullCannotDiscardTheActiveNativeRecord(bool asynchronous)
    {
        var host = new MockLythonHost();
        host.SeedFile("/csv", "10,20\\n30,40\\n50,60\\n");
        var budget = new LythonMemoryBudget(65536);
        using var owner = budget.CreateScope();
        var hook = new AdmissionHookMemoryBudget(owner);
        var context = new LythonRuntime.ExecutionContext(host, new() { MemoryBudget = hook });
        var file = await LythonRuntime.ExecutionContext.TextFileHandle.ForReadAsync("/csv", context,
            LythonRuntime.TextEncodingMode.Utf8, LythonRuntime.TextErrorMode.Strict, LythonRuntime.TextNewlineMode.TranslateUniversal);
        var source = new LythonRuntime.CsvRecordSource(file, Options(), Span, context);
        var reader = new LythonRuntime.CsvReaderObject(source);
        async ValueTask<PyList> Next()
            => Assert.IsType<PyList>((asynchronous ? await reader.TryMoveNextAsync() : reader.TryMoveNext()).Value);
        string[] Values(PyList row) => row.Cast<PyString>().Select(value => value.AsString()).ToArray();
        try
        {
            var first = await Next();
            var nestedRefused = false;
            hook.AfterGrowth = _ =>
            {
                hook.AfterGrowth = null;
                var failure = Assert.Throws<LythonRuntimeException>(() => reader.TryMoveNext());
                Assert.Equal("reentrant text read", failure.Message);
                nestedRefused = true;
            };
            Assert.Equal(["30", "40"], Values(await Next()));
            Assert.True(nestedRefused);
            Assert.Equal(["10", "20"], Values(first));
            Assert.Equal(["50", "60"], Values(await Next()));
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
        finally
        {
            hook.AfterGrowth = null;
            context.State.CloseResources();
        }
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }
'''
(lab/'test-method.cs').write_text(shared,encoding='utf-8',newline='\n')
p=base/'CsvPrivateRecordOwnershipTests.cs'
original=p.read_text(encoding='utf-8')
marker='    [Fact]\n    public void PublicRowAdoptsItsFundedArrayWithoutCopyOrNewAdmission()'
assert original.count(marker)==1
p.write_text(original.replace(marker,shared+'\n'+marker),encoding='utf-8',newline='\n')
