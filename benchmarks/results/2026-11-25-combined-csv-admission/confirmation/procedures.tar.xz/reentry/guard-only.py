from pathlib import Path
import sys
from difflib import unified_diff
base=Path(sys.argv[1]); source=base/'source'
changes=[]
def edit(relative, transform):
    file=source/relative
    before=file.read_text(encoding='utf-8')
    after=transform(before)
    assert before!=after
    changes.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+relative,'b/'+relative))
    file.write_text(after,encoding='utf-8',newline='\n')

app='src/Lokad.Lython/Runtime/'
def module(s):
    for line in ('        internal int UnpackNext(Memory<ExecutableSlot> destination)\n        {\n',
                 '        internal async ValueTask<int> UnpackNextAsync(Memory<ExecutableSlot> destination)\n        {\n',
                 '            pendingLine = null;\n'):
        assert s.count(line)==1
        check='            _nativeFile?.CheckCsvReadReentry();\n'
        if line.startswith('            pendingLine'):
            check=('            // A denied nested pull must not reset the parser still in use\n'
                   '            // by the outer file read and its admission callback.\n'+check)
            s=s.replace(line,check+line)
        else: s=s.replace(line,line+check)
    return s
def file(s):
    line='            internal ValueTask<int> ReadCsvLine'
    assert s.count(line)==1
    return s.replace(line,'''            internal void CheckCsvReadReentry()
            {
                if (_state is ChunkedTextFileReadState reader) reader.ThrowIfReading();
            }

'''+line)
def reader(s):
    line='''                if (_reading) throw RuntimeErrors.Runtime("reentrant text read", null);
                _reading = true;
            }
'''
    assert s.count(line)==1
    return s.replace(line,'''                ThrowIfReading();
                _reading = true;
            }

            internal void ThrowIfReading()
            {
                if (!_reading) return;
                _services.CheckExecution(null);
                throw RuntimeErrors.Runtime("reentrant text read", null);
            }
''')
edit(app+'LythonRuntime.CsvModule.cs',module)
edit(app+'LythonRuntime.TextFileHandle.cs',file)
edit(app+'LythonRuntime.TextFileHandle.Read.cs',reader)
(base/'guard-only.patch').write_text(''.join(changes),encoding='utf-8',newline='\n')
