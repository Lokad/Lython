from pathlib import Path
import hashlib,json,shutil,sys,tarfile
old,lab=map(Path,sys.argv[1:])
old=old.resolve(); lab=lab.resolve()
before=old/'comparison/quiet'; quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
identity=read(before/'identity.json')
term=read(before/'terminal-status.json')['receipt']
assert term['complete'] and sha(before/'observations.tar.xz')==term['archiveSHA256']
assert sha(before/'representative.json')==identity['catalogs']['representative.json']['sha256']
for role,files in identity['imageFiles'].items():
    check=read(old/(role+'-verify.json'))
    assert check['state']=='Completed' and check['caseCount']==5
    assert check['catalogSha256']==identity['inputCatalogSHA256']
    assert {p.name:sha(p)for p in (old/role).iterdir()}==files
    assert check['launched']['library']['sha256']==files['Lokad.Lython.dll']
shutil.copyfile(before/'representative.json',quiet/'representative.json')
first=read(before/'jobs.json')['warm']
save(quiet/'jobs.json',{'warm':[first[i] for i in (4,3,2,0,1)]})
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
identity['purpose']='Reordered confirmation of combined CSV row and dictionary admission'
save(quiet/'identity.json',identity)
for name in ('collect.py','run.sh'):
    write(quiet/name,(before/name).read_text(encoding='utf-8').replace('b1738-fixtures','b1738c-fixtures'))
assert b'\r' not in (quiet/'run.sh').read_bytes()
s=(old/'quiet.py').read_text(encoding='utf-8').replace('b1738','b1738c')
start=s.index("assert donor['archiveSHA256']=='"); end=s.index('\n',start)
s=s[:start]+f"assert donor['archiveSHA256']=={term['archiveSHA256']!r}"+s[end:]
s=s.replace(",'candidate-core.dll'","")
s=s.replace("""   if name=='Lokad.Lython.dll' and role=='candidate':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
""","""   os.link(reference/role/name,image/name)
""")
assert "os.link(reference/role/name,image/name)" in s
compile(s,'quiet.py','exec')
write(lab/'quiet.py',s)
write(lab/'archive.py',(old/'archive.py').read_text(encoding='utf-8').replace(
    '2026-11-25-combined-csv-admission"','2026-11-25-combined-csv-admission/confirmation"'))
save(lab/'verified-raw-replicas.json',[])
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as tar:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        tar.add(quiet/name,arcname=name)
save(quiet/'upload.json',dict(root='combined-csv-admission-b1738c-20261125',
    reference=read(before/'upload.json')['root'],payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
print('Verified the exact original 32-file images and catalog for the reordered confirmation.')
