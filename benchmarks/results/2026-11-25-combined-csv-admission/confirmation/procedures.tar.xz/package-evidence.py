from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
initial=lab.with_name('csv-combined-record-admission-20261125')
guard=lab.with_name('csv-native-reentry-control-20261125')
quiet=lab/'comparison/quiet'
results=root/'benchmarks/results/2026-11-25-combined-csv-admission'
out=results/'confirmation'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
source=initial/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=root)==source.read_bytes()
assert sha(source)==identity['sourcePatchSHA256']==read(out/'quiet-summary.json')['sourcePatch']
assert identity['imageFiles']==read(results/'identity.json')['imageFiles']
assert read(out/'quiet-summary.json')['timedBatches']==140
for suite,n in [('Lokad.Lython.PublicApi.Tests',639),('Lokad.Lython.Tests',180)]:
    for platform in ('win11','ubuntu10'):
        assert re.search(rf'Failed:\s+0, Passed:\s+{n},',(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig'))
baseline=(guard/'baseline.log').read_text(encoding='utf-8-sig')
assert baseline.count('Actual:   []')==2 and re.search(r'Failed:\s+2, Passed:\s+0,',baseline)
assert re.search(r'Failed:\s+0, Passed:\s+148,',(guard/'guard-win11.log').read_text(encoding='utf-8-sig'))
test_patch=lab/'final-tests.patch'
test_patch.write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','tests'],cwd=root))
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in ('prepare.py','quiet.py','archive.py','package-evidence.py',
        'launch-console.log','retrieve.log','final-tests.patch','test-ubuntu.sh',
        'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
        'Lokad.Lython.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log'):
        bundle.add(lab/name,arcname=name,recursive=False)
    for name in ('prepare.py','guard-only.py','guard-only.patch','test-method.cs','baseline.log','guard-win11.log'):
        bundle.add(guard/name,arcname='reentry/'+name,recursive=False)
print('Verified the repeated 140 batches, the final 819-check platform logs and the standalone reentry proof.')
