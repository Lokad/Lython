from pathlib import Path
from statistics import median
import hashlib,json,tarfile,shutil

lab=Path(__file__).resolve().parent
root=lab.parents[3]
quiet=lab/"comparison/quiet"
out=root/"benchmarks/results/2026-11-25-combined-csv-admission/confirmation"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
before=read(quiet/"terminal-status.json")
receipt=before["receipt"]
assert before["exitCode"]=="0" and not before["live"] and not before["fixtures"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
raw=quiet/"observations.tar.xz"
assert hashlib.sha256(raw.read_bytes()).hexdigest()==receipt["archiveSHA256"]
with tarfile.open(raw) as bundle:
    data=json.load(bundle.extractfile("confirmation/confirmation.json"))
    staged=json.load(bundle.extractfile("identity.json"))
    jobs=json.load(bundle.extractfile("jobs.json"))["warm"]
    machines=[json.load(bundle.extractfile("confirmation/machine-"+which+".json"))for which in ("before","after")]
assert staged==read(quiet/"identity.json") and all(machine["gate"]["quiet"] for machine in machines)
assert data["complete"] and [(job["case"],job["lane"])for job in data["jobs"]]==list(map(tuple,jobs))
assert len(data["jobs"])==receipt["warmJobs"]==5
cases={r["id"]:r for r in read(quiet/"representative.json")["cases"]}
rows=[]
for job in data["jobs"]:
    elapsed,cpu={},{}
    job_case=cases[job["case"]]
    assert len(job["samples"])==28 and job["workersJoinedAndFixturesRemoved"]
    for role,ready in job["identities"].items():
        own=next(v["sha256"] for v in ready["libraries"] if Path(v["path"]).name=="Lokad.Lython.dll")
        assert own==staged["coreSHA256"][role]
        assert ready["catalogSha256"]==staged["catalogs"]["representative.json"]["sha256"]
        assert ready["runtimeVersion"]=="11.0.0" and not ready["serverGc"]
        responses=[a for a in job["samples"] if a["engine"]==role]
        assert len(responses)==7
        for sample in responses:
            result=sample["response"]
            assert result["status"]=="Completed"
            assert result.get("actualOutputSha256")== (None if job["lane"]=="compile" else job_case["expectedOutputSha256"])
            assert result.get("actualFilesSha256")== (None if job["lane"]=="compile" else job_case.get("expectedFilesSha256"))
        elapsed[role]=median(s["response"]["elapsedTicks"]*1000/s["response"]["clockFrequency"]/s["response"]["completedInvocations"] for s in responses)
        cpu[role]=median(s["externalProcessCpuTicks"]*1000/s["externalCpuFrequency"]/s["response"]["completedInvocations"] for s in responses)
    def spans(values):
        seq=[(values[c]/values[r]-1)*100 for c in ("candidate","candidate-control")for r in ("reference","reference-control")]
        return [min(seq),max(seq)]
    spread=lambda x:(max(elapsed[x],elapsed[x+"-control"])/min(elapsed[x],elapsed[x+"-control"])-1)*100
    row=dict(case=job["case"],lane=job["lane"],elapsedPercent=spans(elapsed),cpuPercent=spans(cpu),
             sameSourceElapsedSpreadPercent=[spread("reference"),spread("candidate")],elapsedMediansMs=elapsed,widerCpuMediansMs=cpu)
    rows.append(row)
    print(row["case"],row["lane"],*([f"{v:+.2f}%"for v in row[key]]for key in ("elapsedPercent","cpuPercent","sameSourceElapsedSpreadPercent")),flush=True)
summary=dict(sourcePatch=staged["sourcePatchSHA256"],reference=staged["comparisonRevision"],timedBatches=140,lanes=5,elapsedSeconds=data["elapsedSeconds"],rows=rows)
out.mkdir(exist_ok=True)
(out/"quiet-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
shutil.copyfile(raw,out/"quiet-observations.tar.xz")
shutil.copyfile(quiet/"terminal-status.json",out/"quiet-terminal-status.json")
assert hashlib.sha256((out/"quiet-observations.tar.xz").read_bytes()).hexdigest()==receipt["archiveSHA256"]







