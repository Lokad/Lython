from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
routes=lab.with_name('csv-combined-record-routes-20261125')
out=repo/'benchmarks/results/2026-11-25-combined-csv-admission'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
for folder,key in [('src','candidate.patch'),('tests','tests.patch')]:
    patch=lab/key
    assert subprocess.check_output(['git','diff','--binary','HEAD','--',folder],cwd=repo)==patch.read_bytes()
summary=read(out/'quiet-summary.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']==summary['sourcePatch']
assert summary['timedBatches']==140 and len(summary['rows'])==5
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['caseCount']==5
    assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
for suite,n in [('Lokad.Lython.PublicApi.Tests',639),('Lokad.Lython.Tests',178)]:
    for platform in ('win11','ubuntu10'):
        assert re.search(rf'Failed:\s+0, Passed:\s+{n},',(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig'))
trace=read(routes/'identity.json')
assert trace['productionPatchSHA256']==identity['sourcePatchSHA256']
assert trace['diagnosticPatchSHA256']==sha(routes/'diagnostic.patch')
assert trace['measuredImage']==identity['imageFiles']['candidate']
rows=read(routes/'routes.json')['rows']
assert len(rows)==10 and all(r['allowanceReturned'] for r in rows)
expected={
    'scripts.csv-invoice.method-policy.quoted-control':(3064,1033,0),
    'diagnostic.shipment-routing-callbacks':(2046,3,0),
    'diagnostic.shipment-file-fed-map':(2046,3,0),
    'diagnostic.invoice-plain-reader':(0,4097,0),
    'diagnostic.text-summary.nonlocal-computed-width.large':(0,0,0)
}
for r in rows: assert tuple(r['routes'].values())==expected[r['id']]
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
for name in ('allocation-summary.json','compile-allocation-summary.json'):
    shutil.copyfile(lab/name,out/name)
shutil.copyfile(routes/'routes.json',out/'routes.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for p in ('prepare.py','archive.py','quiet.py','package-evidence.py','candidate.patch','tests.patch',
        'probe-build.log','first-build-win11.log','tight-win11.log','prepare.log',
        'reference-verify.json','candidate-verify.json','test-ubuntu.sh',
        'reference-allocation-final.json','candidate-allocation-final.json','reference-compiler-owner.json',
        'candidate-compiler-owner.json','allocations.py','compile-allocation.py',
        'verified-raw-replicas.json','launch-console.log','retrieve.log',
        'Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
        'Lokad.Lython.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log'):
        bundle.add(lab/p,arcname=p,recursive=False)
    for p in ('prepare.py','Program.cs','RouteProbe.csproj','cases.json','identity.json','diagnostic.patch','core-build.log','probe-build.log'):
        bundle.add(routes/p,arcname='routes/'+p,recursive=False)
print('Verified exact prototype, 140 batches, five goldens per image, 817 checks per platform and route counts.')
