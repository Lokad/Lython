from pathlib import Path
import hashlib,json,shutil,subprocess,os,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
reference=lab.with_name('lexical-comprehension-isolation-20261125')
reference_quiet=reference/'comparison/quiet'
template=lab.with_name('csv-direct-record-admission-20261125')/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,s): p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('0374493f9')
anchor=read(reference_quiet/'identity.json')
assert git('diff','--binary',anchor['sourceRevision'],head,'--','src')==(reference/'candidate.patch').read_bytes()
base=anchor['imageFiles']['candidate']
assert len(base)==32 and {f.name:sha(f)for f in (reference/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==5
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    path=lab/role
    path.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else reference/'candidate'/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==files

catalog=read(template/'representative.json')
assert len(catalog['cases'])==5
save(quiet/'representative.json',catalog)
run=[
 ('diagnostic.shipment-file-fed-map','warm-async'),
 ('diagnostic.shipment-routing-callbacks','warm-async'),
 ('scripts.csv-invoice.method-policy.quoted-control','warm'),
 ('diagnostic.invoice-plain-reader','warm'),
 ('diagnostic.text-summary.nonlocal-computed-width.large','warm'),
]
save(quiet/'jobs.json',{'warm':run})
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    inputCatalogSHA256=sha(quiet/'representative.json'),imageFiles=images,
    coreSHA256={role+suffix:files[core.name]for role,files in images.items()for suffix in ('','-control')},
    cpythonWorkerSHA256=anchor['cpythonWorkerSHA256'],expectedCPythonSHA256=anchor['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=sha(quiet/name))for name in ('representative.json','jobs.json')},
    purpose='Combined CSV row and dictionary admission on buffered lines with inferred private headers')
save(quiet/'identity.json',identity)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python_worker=repo/'benchmarks/cpython-worker.py'
assert sha(python_worker)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    image=lab/role
    evidence=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',python_worker,'--out',evidence],
        cwd=repo, env=env, check=True, timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==5
    assert checked['catalogSha256']==identity['inputCatalogSHA256']
    assert checked['launched']['library']['sha256']==files[core.name]

old_receipt=read(reference_quiet/'terminal-status.json')['receipt']
assert old_receipt['complete'] and sha(reference_quiet/'observations.tar.xz')==old_receipt['archiveSHA256']
for name in ('collect.py','run.sh'):
    write(quiet/name,(reference_quiet/name).read_text(encoding='utf-8').replace('b1737i-fixtures','b1738-fixtures'))
assert b'\r' not in (quiet/'run.sh').read_bytes()
s=(reference/'quiet.py').read_text(encoding='utf-8')
s=s.replace('lython-b1737i-forwarded-comprehension','lython-b1738-combined-csv-admission').replace('b1737i','b1738')
start=s.index("assert donor['archiveSHA256']=='")
end=s.index('\n',start)
s=s[:start]+f"assert donor['archiveSHA256']=={old_receipt['archiveSHA256']!r}"+s[end:]
compile(s,'quiet.py','exec')
write(lab/'quiet.py',s)
write(lab/'archive.py',(reference/'archive.py').read_text(encoding='utf-8').replace(
    '2026-11-25-forwarded-comprehension-binding/isolation','2026-11-25-combined-csv-admission'))
replicas=[]
for prior in (reference,lab.with_name('dictreader-inline-headers-20261125'),lab.with_name('pair-only-rollback-20261125')):
    archive=prior/'comparison/quiet'
    receipt=read(archive/'terminal-status.json')['receipt']
    assert receipt['complete'] and sha(archive/'observations.tar.xz')==receipt['archiveSHA256']
    location=read(archive/'upload.json')['root']
    with tarfile.open(archive/'observations.tar.xz') as bundle:
        raw=bundle.extractfile('confirmation/confirmation.json').read()
    replicas.append(dict(location=location,member='confirmation/confirmation.json',bytes=len(raw),
        rawSHA256=digest(raw),archiveSHA256=receipt['archiveSHA256']))
    if prior==reference: continue
    candidate=prior/'candidate'
    earlier_image=read(archive/'identity.json')['imageFiles']['candidate']
    assert len(earlier_image)==32 and {p.name:sha(p)for p in candidate.iterdir()}==earlier_image
    f=candidate/core.name
    replicas.append(dict(location=location,member='candidate/Lokad.Lython.dll',bytes=f.stat().st_size,
        rawSHA256=sha(f),archiveSHA256=receipt['archiveSHA256'],localFrozenImage=str(candidate),localImageFileCount=32))
save(lab/'verified-raw-replicas.json',replicas)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as tar:
    for name in ('identity.json','jobs.json','representative.json','run.sh','collect.py'):
        tar.add(quiet/name,arcname=name)
    tar.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='combined-csv-admission-b1738-20261125',
    reference=read(reference_quiet/'upload.json')['root'],payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
print('Five independent goldens per frozen image and staging identities verified.')
