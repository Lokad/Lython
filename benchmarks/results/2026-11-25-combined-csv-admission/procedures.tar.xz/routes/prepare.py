from pathlib import Path
from difflib import unified_diff
import hashlib,json,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
trial=lab.with_name('csv-combined-record-admission-20261125')
template=lab.with_name('shipment-comprehension-routes-20261125')
source=lab/'source'
source.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
identity=read(trial/'comparison/quiet/identity.json')
base=git('rev-parse','HEAD').decode().strip()
assert identity['sourceRevision']==base
assert git('diff','--binary','HEAD','--','src')==(trial/'candidate.patch').read_bytes()
archive=lab/'source.zip'
git('archive','--format=zip','--output',str(archive),base,'--','src','Directory.Build.props','Directory.Build.targets',
    'Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config')
with zipfile.ZipFile(archive) as z:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
    z.extractall(source)
for name in git('diff','--name-only','HEAD','--','src').decode().splitlines():
    shutil.copyfile(repo/name,source/name)
files={}
def patch(name,left,right):
    p=source/'src/Lokad.Lython/Runtime'/name
    s=p.read_text(encoding='utf-8-sig')
    files.setdefault(name,s)
    assert s.count(left)==1
    write(p,s.replace(left,right))
name='LythonRuntime.CsvModule.cs'
patch(name,'        private object? _readyRecord;', '''        private object? _readyRecord;
        internal static int DiagnosticCombined;
        internal static int DiagnosticPrivateArray;
        internal static int DiagnosticUnpacked;''')
patch(name,'                _readyRecord = result;', '''                if (result is PyDict) Interlocked.Increment(ref DiagnosticCombined);
                else Interlocked.Increment(ref DiagnosticPrivateArray);
                _readyRecord = result;''')
patch(name,'            // The caller diagnoses arity at the unpack instruction, after',
    '            Interlocked.Increment(ref DiagnosticUnpacked);\n            // The caller diagnoses arity at the unpack instruction, after')
changes=[]
for file,before in files.items():
    relative='src/Lokad.Lython/Runtime/'+file
    after=(source/relative).read_text(encoding='utf-8')
    changes.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+relative,'b/'+relative))
write(lab/'diagnostic.patch',''.join(changes))
frozen=identity['imageFiles']['candidate']
assert len(frozen)==32 and {p.name:sha(p)for p in (trial/'candidate').iterdir()}==frozen
image=lab/'image'
image.mkdir(exist_ok=False)
for name in frozen: shutil.copyfile(trial/'candidate'/name,image/name)
shutil.copyfile(template/'RouteProbe.csproj',lab/'RouteProbe.csproj')
s=(template/'Program.cs').read_text(encoding='utf-8')
a=s.index('string[] names')
b=s.index('foreach (var item',a)
s=s[:a]+'''string[] names = ["Combined", "PrivateArray", "Unpacked"];
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
'''+s[b:]
s=s.replace('        transfers.Clear();\n','')
s=s.replace('            transfers = transfers.OrderBy(pair => pair.Key).ToDictionary(), peakExecutionMemoryBytes','            peakExecutionMemoryBytes')
write(lab/'Program.cs',s)
catalog=read(trial/'comparison/quiet/representative.json')
catalog['cases']=[case|{'runAsync':mode} for case in catalog['cases'] for mode in (False,True)]
write(lab/'cases.json',json.dumps(catalog,ensure_ascii=False))
write(lab/'identity.json',json.dumps(dict(source=base,measuredImage=frozen,productionPatchSHA256=sha(trial/'candidate.patch'),
    diagnosticPatchSHA256=sha(lab/'diagnostic.patch'),catalogSHA256=sha(lab/'cases.json')),indent=2)+'\n')
