data=b'abc'*4097
text='é😀'*4097
marker=[]
values=(marker,)*4097
marker.append(7)
assert len(data)==12291 and data[-7:]==b'cabcabc'
assert len(text)==8194 and text[-3:]=='😀é😀'
assert values[0] is marker and values[-1] is marker
assert values[-1]==[7]
assert b'abc'*-1==b'' and 'é😀'*0=='' and (marker,)*-1==()
assert (2**40)*b''==b'' and (2**40)*()==()
events=[]
class Count:
    def __index__(self):
        events.append('index')
        return 2
assert b'ab'*Count()==b'abab'
assert Count()*'é😀'=='é😀é😀'
assert (marker,)*Count()==(marker,marker)
assert events==['index','index','index']
class LargeCount:
    def __index__(self):return 2**40
assert ''*LargeCount()==''
class HugeCount:
    def __index__(self):return 2**100
for operation in [lambda:b''*HugeCount(),lambda:''*HugeCount(),
                  lambda:()*HugeCount(),lambda:b''*-(2**100)]:
    try:operation()
    except OverflowError:pass
    else:assert False
print('ok')
