from pathlib import Path
import subprocess,sys
r=Path(__file__).parent
for phase in ['warm-sync','warm-async']:
 subprocess.run([sys.executable,'-X','utf8',str(r/'diagnostic.py'),phase],check=True)
subprocess.run([sys.executable,'-X','utf8',str(r/'summarize.py')],check=True)
