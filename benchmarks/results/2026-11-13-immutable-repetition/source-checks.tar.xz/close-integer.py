from pathlib import Path
import json,subprocess
p=Path('benchmarks/results/2026-11-13-integer-admission/validation.json');d=json.loads(p.read_text(encoding='utf-8'));d['fullPlatformStressInstalledPackageQualification']='GREEN43384587266; exact c5d05cff/frozen3a2c1cf6 source qualified; cached delivery proof';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=Path('benchmarks/results/2026-11-13-integer-admission/README.md');s=p.read_text(encoding='utf-8').replace('actual.NET11/10, original stress and installed Release package qualification is next.', 'actual.NET11/10, original stress and installed Release package qualification is\nGREEN43384587266 for exactc5d05cff/3a2c1cf6. [Cached delivery](delivery/README.md).')
p.write_text(s,encoding='utf-8')
subprocess.run(['git','add','benchmarks/results/2026-11-13-integer-admission/delivery','benchmarks/results/2026-11-13-integer-admission/validation.json','benchmarks/results/2026-11-13-integer-admission/README.md'],check=True)
subprocess.run(['git','commit','-m','Record qualified integer arithmetic delivery [skip ci]'],check=True)
