using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

var rows = new List<object>();
foreach (var owned in new[] { false, true })
{
    var budget = new LythonMemoryBudget(4 * 1024 * 1024);
    using (var owner = budget.CreateScope())
    {
        var gate = new Gate(owner);
        var context = new LythonRuntime.ExecutionContext(new Host(), new LythonRunOptions { MemoryBudget = gate });
        var span = new LythonSourceSpan(7, 12, 1, 8);
        var input = owned ? new PyBytes([97], context.MemoryGovernor, span) : new PyBytes([97]);
        var baseline = budget.ReservedBytes;
        gate.Before = GC.GetAllocatedBytesForCurrentThread(); gate.Armed = true;
        string? failure = null; object? result = null;
        try { result = LythonRuntime.EvaluateBinaryOperator(BinaryOperatorSyntax.Multiply, input, new BigInteger(1048576), context, span); }
        catch (LythonRuntimeException error) { failure = error.Attribution?.Reason.ToString(); }
        rows.Add(new { owned, failure, allocatedBeforeRefusal = gate.AllocatedAtRefusal, requestedBytes = gate.Requested,
            resultLength = (result as PyBytes)?.Length, retainedFundingDelta = budget.ReservedBytes - baseline,
            resultHasOwner = result is PyBytes bytes && bytes.OwnerMemoryGovernor is not null });
        gate.Armed = false; context.State.CloseResources();
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Cleanup did not return the allowance.");
}
Console.WriteLine(JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))), rows }));

sealed class Gate(ILythonMemoryBudget parent) : ILythonMemoryBudget
{
    internal bool Armed;
    internal long Before;
    internal long? AllocatedAtRefusal;
    internal long? Requested;
    private bool Refuse(long bytes)
    {
        if (!Armed) return false;
        AllocatedAtRefusal ??= GC.GetAllocatedBytesForCurrentThread() - Before;
        Requested ??= bytes;
        return true;
    }
    public ILythonMemoryScope CreateScope() => parent.CreateScope();
    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (bytes > 0 && Refuse(bytes)) { reservation = null; return false; }
        if (!parent.TryReserve(bytes, out var inner)) { reservation = null; return false; }
        reservation = new Reservation(this, inner!); return true;
    }
    private sealed class Reservation(Gate gate, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes) => bytes > inner.Bytes && gate.Refuse(bytes - inner.Bytes) ? false : inner.TryResize(bytes);
        public void Dispose() => inner.Dispose();
    }
}
sealed class Host : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest p, CancellationToken t) => new(false);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest p, CancellationToken t) => new(Array.Empty<string>());
    public ValueTask MkDirAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("mkdir");
    public ValueTask RemoveAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("remove");
    public ValueTask CopyAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("copy");
    public ValueTask MoveAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("move");
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("stat");
}
