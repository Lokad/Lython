from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;out=r/'after-index-probe';out.mkdir()
(out/'after.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><AssemblyName>Lokad.Lython.WhiteBox.Tests</AssemblyName><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="../probe/Program.cs"/><Reference Include="Lokad.Lython"><HintPath>../index-corrected/Lokad.Lython.dll</HintPath></Reference></ItemGroup></Project>''',encoding='utf-8')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'after-index-build.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(out/'after.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'after-index-build.log').read_text(encoding='utf-8')
done=subprocess.run([str(sdk/'dotnet.exe'),str(out/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll')],env=env,capture_output=True,text=True,encoding='utf-8');(r/'after-index.json').write_text(done.stdout,encoding='utf-8');(r/'after-index-stderr.log').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);identity=json.loads((r/'index-corrected/candidate-identity.json').read_text(encoding='utf-8'));assert d['coreSHA256'].lower()==identity['coreSHA256']
assert all(row['failure']=='SharedMemoryAllowance'and row['allocatedBeforeRefusal']<32768 for row in d['rows']);print(json.dumps(d,indent=2),flush=True)
