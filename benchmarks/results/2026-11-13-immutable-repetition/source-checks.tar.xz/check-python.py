from pathlib import Path
import hashlib,json,subprocess,tempfile
r=Path(__file__).parent
with tempfile.TemporaryDirectory(prefix='lython-repeat-golden-')as folder:
 source=(r/'artifact-repetition.py').read_text(encoding='utf-8');done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,text=True,capture_output=True,encoding='utf-8');assert done.returncode==0,done.stderr
 golden=json.loads((r/'artifact-golden.json').read_text(encoding='utf-8'));assert done.stdout==golden['expectedOutput']
 for name,size in golden['expectedFileBytes'].items():assert (Path(folder)/name).stat().st_size==size
 version=subprocess.check_output(['C:/Python313/python.exe','-V'],text=True).strip()
 (r/'python-golden.json').write_text(json.dumps(dict(version=version,stdout=done.stdout,files={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in Path(folder).iterdir()}),indent=2)+'\n',encoding='utf-8');print(version,'complete artifact goldens pass',flush=True)
