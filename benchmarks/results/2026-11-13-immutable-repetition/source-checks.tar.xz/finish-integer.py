from pathlib import Path
import ast,subprocess,sys
r=Path(__file__).parent.parent/'arithmetic-source-r305';p=r/'save-delivery.py';lines=p.read_text(encoding='utf-8').splitlines()
indent=next(line[:len(line)-len(line.lstrip())]for line in lines if line.lstrip().startswith('data=frozen.extractfile'))
lines=[indent+'count+=1'if line.strip()=='count+=1'else line for line in lines];code='\n'.join(lines)+'\n';ast.parse(code);p.write_text(code,encoding='utf-8')
subprocess.run([sys.executable,'-X','utf8',str(p)],check=True)
