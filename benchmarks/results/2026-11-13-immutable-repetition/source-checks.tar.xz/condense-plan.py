from pathlib import Path
r=Path(__file__).parent;p=Path('PLAN.md');(r/'plan-before-condensation.md').write_text(p.read_text(encoding='utf-8'),encoding='utf-8')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-13. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-to-result. A successful experiment/CI run is not completion.

## Delivery status

| State | Exact outcome and limit |
| --- | --- |
| Fully qualified current committed runtime | **c5d05cff/3a2c1cf6**, GREEN43384587266: Windows/Ubuntu actual.NET11/10, original stress and installed Release consumers.572frozen production inputs match the CI head. [Cached delivery](benchmarks/results/2026-11-13-integer-admission/delivery/README.md). |
| Current uncommitted prototype | R307 immutable repetition; initial **6f3ed1d3** passes192internal/339public Release checks, seven unchanged scripts plus complete artifact generation through both APIs. Final empty-text/large-index refinement is being checked. No full R307 qualification or controlled CPU claim yet. |
| Current external measurements | Qualified **63389c9d/2e74ef4f**, B660 six jobs/250.895s. Invoice warm1.45–1.46×CPython3.13.16, compile1.10–1.11×, fresh1.41–1.44×; captured warm1.65–1.66×, variable search1.59–1.67×, JSON0.82–0.83×. [Sources, controls, boundaries](benchmarks/results/2026-11-13-invoice-cpython-checkpoint/README.md). Do not infer3a ratios by multiplying source-pair gains. |
| Source-pair outcome | Qualified R3053a versus2e: invoice warm7.2–8.2%, fresh7.2–9.3% faster, supporting widerCPU; allocation flat. Text/JSON cross zero. [All adverse/original evidence](benchmarks/results/2026-11-13-integer-admission/README.md). |
| Historical failed qualification | Original composed calls **47e0a7be/2f34a48f** crash Windows on a small managed continuation. Corrected633/2e is fully qualified; all fatal/inconclusive probes survive. Do not call2f qualified/current. |

Source qualification does not imply byte-identical CI binaries: generated Git
metadata changes hashes. Freeze exact sources/bits for observations, compare with
the recorded commit, and force nonincremental builds after timestamp-preserved restores.

## Completed milestones—reuse, do not replay unchanged

- Shared compiler facts: nonlocal correction, annotation demand and lowered-tree
  retention cleanup. Fewer analyses/allocations do not establish compile dominance.
- Direct UTF8 formatting/storage: **−8.67%allocation** established; later controlled
  roughly5–8%elapsed/CPU supports retention. Original adverse15.125ms remains unexplained.
  R296 shares ordinary/native formatting, report warm5.8–9.1% and fresh4.9–8.3%,
  supportingCPU, allocation flat; full deliveryGREEN43350708328.
- Native helper returns: historical **−19.92%Run/−19.31%Async allocation**, fully
  qualified with deterministic refunds/correctness fixes. R289 removes graph/proof/
  duplicate evaluation using final slots/PC; CSV fresh9–11% faster. Search+1–6% debt
  accepted; guarded debt uncertain. Slower call arenas/control remain withdrawn.
- Composed native calls keep shallow helpers in final slots; deep calls hand off
  to the existing linear runner using logical depth. No new guest limit/counter or
  native telemetry. Controlled256KiB direct/mutual recursion and finite100-depth
  calls recover; full deliveryGREEN43378817838. Corrected2e invoice improves8.4–10.7%
  versus qualified6b with supportingCPU; old2f−19.51%allocation keeps its own label.
- Bulk CSV adoption/shared keys, private unboxed dictionary values, live closure
  cells, UTF8 casing and JSON windows. R293 range loans remove scratch copying;
  captured fresh3.6–9.1%elapsed/4.4–7.7%CPU improves, warm remains uncertain.
- R295 builder transactions and R301 temporary-owner reentry preserve published
  survivors/funding through refund callbacks. R298builtin slot owners preserve
  defining-class aliases; reproduced public bugs fixed and fully qualified.
- R305 shared integer kernel removes four generic methods, modulo quotient/product
  intermediates, duplicate prod preflight and late result funding. Eight pre-fix
  failures reproduce; corrected refusal occurs after32diagnostic bytes instead of
 64–128KiB allocation. Retained aliases/cancellation/cleanup and full delivery pass.

Historical experiments, rejected forms, receipts and raw measurements stay in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results, outside current docs.

## Prioritized deliverables

1. **Finish R307 immutable repetition.** Frozen3a probe demonstrates unowned bytes
   input creates an unfunded1MiB result; owned input allocates1MiB before refusal.
   Source also shows unbounded per-repeat byte/text copying and tuple late admission.
   Replace these with one managed, bounded doubling-copy routine. Admit final
   capacity/scalar headroom before construction, charge the active execution,
   transfer retained funding from the same grant. Delete the three displaced loops
   and tuple's redundant admission; no new policy/ledger/cache/backend/options.

   Preserve Unicode, Python index protocols/evaluation order, negative/empty/large
   counts, shared tuple element identities, funded inputs/results and terminal first
   refusal. Empty text with a very large custom index returns empty. Refusing
   formerly unfunded bytes earlier is intentional. Cancellation during admission
   refunds private capacity; copying checks current cancellation between bounded
   chunks. Individual managed allocations remain atomic; no hard-deadline claim.

   Finish final focused Release semantic/ownership/cancellation/refusal checks.
   Reuse initial seven-script+artifact diagnostics (both APIs): goldens/balances/
   cleanup pass, allocation flat, desktop clocks adverse/moving; no CPU claim.
   Freeze/refine sources accurately, update current docs, commit the coherent fix.
   Batch full Windows/Ubuntu actual11/10, original stress and installed consumers
   at delivery; never relabel the earlier3a qualification as R307's.

2. **Next substantial redesign: existing bulk execution/construction boundary.**
   R306 current captured source gate closes without a new runtime prototype:
  1502guest samples/7.58CPU seconds,9.72%unmapped, no ambiguous leaves. Dictionary
   loop274, preparation151, instruction prefix113, native core82, casing writer66
   include useful/inlined work, not removable shares. Full identity/output/ownership/
   quiet/join/verified-RAM-archive gates pass. [Exact boundary/evidence](benchmarks/results/2026-11-13-captured-cpu-source-gate/README.md).

   Assess complete call/frame and operand transport, per-record collections and
   remaining text conversion together with this evidence. Before another prototype,
   identify actual work/storage eliminated across captured/ordinary text, invoice,
   CSV/JSON aggregation and reports; name displaced implementation to delete.
   Specify Python protocols/aliasing/effect order, cancellation and admission
   acceptance, a bounded complete-script before/after with unchanged controls and
   an explicit retain/refine/withdraw/regression-debt decision. Temporary regression
   can be carried only to a named completion milestone.

   Stopping criterion for each source gate: select a coherent migration with that
   deletion list, or record the precise unresolved useful/overhead boundary and move
   to the next candidate. No new profiler campaign merely because the last one was
   inconclusive. Current facts rule out mirrored locals/per-line ordinary frames in
   captured text, repeated Unicode sizing/mapping and nested allowance locks.
   Range loans, private totals, direct return slots, shared parameter layouts and
   immutable signatures already exist. Ordinary inline tuple storage was tested:
  −2.42%CSV allocation, no reliable targetedCPU gain, larger headers/branches; do not
   replay it, whole-line casing, call arenas or call-control unchanged.

3. **Frontend consolidation, below demonstrated execution gaps.** Reuse shared
   lexical/binding/annotation facts and remove an actual retained intermediate or
   repeated analysis. Compilation is part of compile-to-result; near-CPython rows
   do not prove it free or dominant. Keep config/helper/report controls and Python
   diagnostics/scoping. Do not add a heavyweight compiler or blanket script cache
   as the answer for newly generated scripts.

4. **Independent regex/provider work.** Core owns the Python/nativeUTF8 contract,
   dependency-free across frontend/runtime/imports; optional nonpackable adapter0.4.
   Immutable dev78/dev79 bridges passed88internal/534public per actual target.
   Sibling read-only HEADb8a851bf is unchanged at the latest observation; no replay.
   Final precise producer gaps: separate one-match working/result owners, native
   UTF8 group names, token-independent cursor construction/cancellable preparation.
   Funded Compile did not visibly forward AssumeValid; adapter-local working
   overload bridge conservatively admits storage. Keep exact dev-package evidence
   separate from released-adapter qualification/backend performance.
   Missing published APIs defer only affected final adapter checks. Continue core
   Python flags/captures, byte/scalar ranges, original windows, current-token work
   and cache ownership independently; no dialect fallback/core dependency edge.

## Iteration and lasting constraints

Distinguish simplification, allocation and demonstrated CPU improvement. Percentages
inform decisions, never automatically veto them. Timeouts, moving unchanged controls
and inconclusive observations establish uncertainty. Allow bounded confirmation,
refinement or measurement correction for a stated reason; retain adverse originals.
No one-attempt/no-retiming/permanent-closure rules. Size observations for the quiet VM;
microbench during iteration, long lanes only at meaningful milestones.

Use focused Release checks; batch platform, original stress and installed consumers.
Cache terminal CI, space queries at least4min apart. GC tests share nonparallel
collections. Never weaken deadlines/assertions. Workers/catalog/evidence stay
persistent, RAM fixtures separate; join users, SHA-archive before unmount. Reuse valid
measurements/source labels. Current guides live in docs, experiments/receipts outside.

Fully managed/memory-safe: no unsafe compilation/C#/APIs, pointers, P/Invoke or native
probing. Preserve managed stack admission, host-mediated capabilities/original paths
and Cwd, cooperative cancellation, cycle/XML/checked representation protections and
bounded I/O. No fuel/host quotas, regex work/time policies, hidden caps/allowances,
heap tracing, weak reclamation or forced GC. Borrowed shared allowance funds major
capacity, overlap, retained aliases/results/caches and pending users. Scopes add no
allowance; initial streaming uses bounded host executions. First refused admission
fails the command through suppression/finally; preserve its structured origin,
await cleanup, never retry or abandon work. Publication/tagging need separate approval.
''',encoding='utf-8')
print('Condensed active deliverables; preserved completed milestones and linked source-labelled history.',flush=True)
