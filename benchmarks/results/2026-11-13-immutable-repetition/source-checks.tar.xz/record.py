from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;identity=json.loads((r/'index-corrected/candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for name,count in [('index-corrected-test.log',192),('index-corrected-public-test.log',339)]:
 text=(r/name).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and 'Total tests: '+str(count)in text
after=json.loads((r/'after-index.json').read_text(encoding='utf-8'));assert after['coreSHA256'].lower()==identity['coreSHA256']
assert all(row['failure']=='SharedMemoryAllowance'and row['allocatedBeforeRefusal']<32768 for row in after['rows'])
out=Path('benchmarks/results/2026-11-13-immutable-repetition');out.mkdir()
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if not p.is_file()or set(relative.parts)&{'bin','obj','candidate','reference'}:continue
  if p.suffix in {'.py','.json','.log','.cs','.csproj','.txt','.dll','.xz','.md'}:a.add(p,arcname=relative.as_posix())
validation=dict(decision='Retain containment correction and shared bounded copy; no controlled CPU claim',final=identity,focusedReleaseNet11=dict(internal=192,public=339),before=json.loads((r/'before.json').read_text(encoding='utf-8')),after=after,initialDiagnosticCore='6f3ed1d38bb423ea6ec00ec6fbefabf58592d91cebd1e0f61775fb37e9dbe501',independentCpython='3.13.2 semantic/artifact goldens only; no external timing',fullPlatformStressInstalledPackageQualification='Pending; do not reuse earlier3a source qualification',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Shared immutable repetition

R307 retains final frozen **93a6d134** against qualified **c5d05cff/3a2c1cf6**.
All572production inputs and measured sources/binaries are preserved. Publication
remains postponed. Full platform/stress/installed-package qualification is next;
the earlier3a GREEN does not qualify this source.

A direct frozen3a probe repeats one byte1048576times. Unowned input returns a1MiB
result with no reservation or owner; owned input allocates1048680bytes before
refusal. Corrected output admits final storage in the active execution first;
both probe routes now refuse after at most a few hundred diagnostic bytes, without
allocation of the large result or a changed retained balance. Exact values remain
in [validation](validation.json). Native cleanup returns shared funding to baseline.

One managed doubling-copy kernel replaces three byte/text/tuple fill loops and
checks current cancellation between bounded chunks. Bytes transfer the initial
reservation into their result; tuple scalar/backing capacity is admitted together,
removing its duplicate late admission. Text construction refunds private capacity
on failure. Compiled/unowned inputs do not select an unowned output. No new policy,
quota, allowance, pool, collector, unsafe code or execution backend.

Final actual.NET11 Release checks:192internal/339public pass. Tests cover both APIs,
refusal before major allocation, owned/unowned inputs, admission cancellation,
retained funding, tuple aliases, Unicode, non-power-of-two/chunk boundaries,
custom indices and terminal refusal through suppression/finally returns. Source
checks cancellation during bounded copying; no timed mid-copy latency guarantee
or preemption of an individual CLR allocation is claimed.

The independent CPython3.13.2 gate catches an incorrect initial expectation:
unrepresentable repetition counts raise OverflowError even for empty values.
Final code validates managed native-index representation before the empty shortcut;
representable large indices can repeat empty values without allocating. The
incorrect expectation/script/failed Python result and superseded test snapshots
survive in source evidence. Only final index-corrected checks establish semantics.

One complete artifact-generation diagnostic writes262146binary bytes and49152UTF8
bytes, constructs4097tuple aliases and checks full stdout/files. It and seven
unchanged representative scripts pass both APIs, independent image/CoreLib/hash
controls, shared balances and fixture cleanup. Existing driver/host/catalog APIs
are reused; no benchmark framework or producer change. Initial frozen6f3ed1d3
precedes the count-semantic correction and keeps its own source label.

Allocation is effectively flat. Windows desktop artifact warm sync−7.65..−7.63%
with0.02%reference-control movement; async−1.62..−0.21% with1.43%movement. Other
desktop controls move and include adverse UTF16/report/text observations. These
are diagnostic elapsed observations, not demonstrated CPU or CPython gains. No
quiet-VM retiming is required to retain the admission/cleanup correction; all
original/adverse rows remain. Do not relabel6f clocks as final93a6 measurements.

Contract changes: previously uncharged bytes can now be refused before allocation;
tuple storage may be refused before filling instead of during late ownership.
Native-index overflow follows Python. Shared inputs/element identities remain
funded; explicit guest MemoryError remains catchable, refused admission terminal.
Broader bulk execution/collection and independent regex priorities remain open.

[Sources, exact binaries, raw diagnostics, failed conditions and final checks](source-checks.tar.xz),
[final validation/source identity](validation.json).
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');at=s.index('[Captured-text CPU');s=s[:at]+'''[Shared immutable repetition](results/2026-11-13-immutable-repetition/README.md)
fixes reproduced unfunded/late-admitted bytes output, shares bounded copying and
removes tuple's duplicate late admission. Final93a6d134 passes192internal/339public
focused Release checks and CPython count semantics. Initial6f artifact/seven-script
diagnostics pass both APIs with flat allocation; moving/adverse desktop clocks
remain diagnostic. Incorrect initial oversized-count expectations survive; full
delivery is pending and the broader performance objective remains open.

'''+s[at:]
s=s.replace('All original failed/adverse conditions survive; full delivery is pending.', 'All original failed/adverse conditions survive; integer delivery is\nGREEN43384587266 with cached source-matched platform/stress/package evidence.')
p.write_text(s,encoding='utf-8')
print('R307 final source, corrected semantics, original failures and diagnostic limits recorded.',flush=True)
