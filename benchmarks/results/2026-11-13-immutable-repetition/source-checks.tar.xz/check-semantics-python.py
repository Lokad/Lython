from pathlib import Path
import subprocess
r=Path(__file__).parent;s=Path('tests/Lokad.Lython.PublicApi.Tests/ImmutableRepetitionTests.cs').read_text(encoding='utf-8');s=s.split('const string source = """\n',1)[1].split('            """;',1)[0];s='\n'.join(line[12:]for line in s.splitlines()).replace('return data,text,len(values)',"print('ok')")
(r/'semantics.py').write_text(s+'\n',encoding='utf-8')
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(r/'semantics.py')],capture_output=True,text=True,encoding='utf-8');(r/'python-semantics.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr;assert done.stdout=='ok\n';print('Independent CPython3.13.2 semantics pass.',flush=True)
