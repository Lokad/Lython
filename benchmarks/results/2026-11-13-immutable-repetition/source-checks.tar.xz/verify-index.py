from pathlib import Path
import ast,subprocess,sys
r=Path(__file__).parent
for name in ['semantics.py','python-semantics.log']:
 p=r/name
 if p.exists():p.rename(r/('incorrect-index-'+name))
subprocess.run([sys.executable,'-X','utf8',str(r/'check-semantics-python.py')],check=True)
subprocess.run([sys.executable,'-X','utf8',str(r/'check.py'),'index-corrected'],check=True)
code=(r/'public.py').read_text(encoding='utf-8').replace("'public-'+phase+'.log'","'index-corrected-public-'+phase+'.log'");ast.parse(code);(r/'index-corrected-public.py').write_text(code,encoding='utf-8')
subprocess.run([sys.executable,'-X','utf8',str(r/'index-corrected-public.py')],check=True)
