from pathlib import Path
import ast,base64,hashlib,json,shutil,struct
r=Path(__file__).parent;old=r.parent/'arithmetic-source-r305'
shutil.copy2(r/'catalog.json',r/'catalog-existing.json')
data=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
source="""data=b'abc'*87382
text='é😀'*8192
values=(b'x',)*4097
with open('artifact.bin','wb') as target:
    target.write(data)
with open('report.txt','w',newline='') as target:
    target.write(text)
print(len(data),len(text),len(values))
"""
outputs={'artifact.bin':b'abc'*87382,'report.txt':('é😀'*8192).encode('utf-8')}
digest=hashlib.sha256();digest.update(struct.pack('>I',len(outputs)))
for name,content in sorted(outputs.items()):
 b=name.encode('utf-8');digest.update(struct.pack('>I',len(b)));digest.update(b);digest.update(struct.pack('>I',len(content)));digest.update(content)
fixture=json.dumps(dict(size=87382,text=None,inputFiles={},outputFiles={n:base64.b64encode(v).decode('ascii')for n,v in outputs.items()}),ensure_ascii=False,separators=(',',':'))
stdout='262146 16384 4097\n';sha=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
case=dict(id='scripts.artifact-repetition.large',family='scripts',category='whole-script',scale='large',size=87382,source=source,fixtureJson=fixture,expectedOutput=stdout,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(stdout.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source),fixtureSha256=sha(fixture),expectedOutputSha256=sha(stdout),expectedFilesSha256=digest.hexdigest())
data['cases']=[c for c in data['cases']if c['id']!='scripts.file-search.guarded-helper.large']+[case];assert len(data['cases'])==8
(r/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'artifact-repetition.py').write_text(source,encoding='utf-8')
(r/'artifact-golden.json').write_text(json.dumps(dict(sourceSHA256=case['sourceSha256'],expectedOutput=stdout,expectedFilesSHA256=case['expectedFilesSha256'],expectedFileBytes={k:len(v)for k,v in outputs.items()},usesExistingDriver=True,newFramework=False,profile='Windows desktop; no controlled CPU claim'),indent=2)+'\n',encoding='utf-8')
code=(old/'diagnostic.py').read_text(encoding='utf-8');ast.parse(code);(r/'diagnostic.py').write_text(code,encoding='utf-8')
code=(old/'summarize.py').read_text(encoding='utf-8');ast.parse(code);(r/'summarize.py').write_text(code,encoding='utf-8')
print('Seven unchanged scripts plus complete binary/text/tuple artifact generation; existing driver/tooling.',flush=True)
