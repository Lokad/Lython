from pathlib import Path
import json
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'previous-plan.md').write_text(s,encoding='utf-8')
at=s.index('   Next source deliverable:');end=s.index('\n   Remaining roadmap:',at)
s=s[:at]+'''   **R307 next: shared immutable repetition admission and bounded copying.** A
   frozen3a probe confirms bytes repetition from an unowned/compiled input creates
   a1MiB unowned result with no admission; owned input allocates1MiB before refusal.
   This is demonstrated containment debt. Bytes/text repeat with one copy per
   repetition and lack in-fill cancellation; tuple repetition preflights backing
   then separately admits retained storage after filling it.

   Small coherent migration: one managed, bounded doubling-copy helper shared by
   bytes/text/tuple immutable repetition; admit final capacity/scalar headroom before
   allocation, fund outputs with active execution owner, transfer retained storage
   from the same grant. Delete three old fill loops and tuple's redundant late
   admission. No new policy, ledger, cache, backend or configuration. Keep custom
   index protocols/evaluation order, empty/negative/large-count errors, Unicode,
   shared element identities and funded inputs/escaping results. Cancellation after
   admission and during bounded fill must unwind private capacity. Earlier denial
   for formerly unfunded output is intentional; no hidden replacement allowance.

   Focused Release refusal-before-allocation, retained aliases, cancellation and
   repeat semantic/protocol tests; use a short complete binary/text generation
   diagnostic with output goldens and existing scripts, not another measurement
   framework/campaign. No CPU claim from source shape alone. Finish with the old
   loops/late-admission code gone and explicit docs, then continue broader roadmap.
   R305's independently frozen source qualification must retain its own label.
'''+s[end:];p.write_text(s,encoding='utf-8')
print(json.dumps(json.loads((r/'before.json').read_text(encoding='utf-8')),indent=2))
