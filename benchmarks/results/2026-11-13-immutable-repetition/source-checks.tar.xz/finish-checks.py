from pathlib import Path
import ast,os,subprocess,sys
r=Path(__file__).parent
code=(r/'public.py').read_text(encoding='utf-8').replace("'public-'+phase+'.log'","'final-public-'+phase+'.log'")
ast.parse(code);(r/'final-public.py').write_text(code,encoding='utf-8')
subprocess.run([sys.executable,'-X','utf8',str(r/'check.py'),'final'],check=True)
subprocess.run([sys.executable,'-X','utf8',str(r/'final-public.py')],check=True)
