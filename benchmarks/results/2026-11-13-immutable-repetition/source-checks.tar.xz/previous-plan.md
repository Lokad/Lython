# Lokad.Lython 0.11.0

Updated2026-11-13. Git-ignored; never force-add. Publication/tagging remain postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-to-result. Another experiment or CI checkpoint is not completion.

## Actual delivery status

| State | Evidence and limit |
| --- | --- |
| Fully qualified baseline | **fc2531b8/6b468bf1**, GREEN43364639355: Windows/Ubuntu actual.NET11/10, original stress and installed Release consumers. Reuse [cached qualification](benchmarks/results/2026-11-13-temporary-owner-reentry/delivery/README.md). |
| Committed, qualification failed | **47e0a7be/2f34a48f**, composed native calls: invoice warm−8..−10%, supporting CPU and−19.51%allocation. These remain source-labelled historical observations. CI43373824703 passes Ubuntu but Windows crashes after real suspension; controlled continuation reproduces the bug. Do not describe2f as fully qualified or today’s performance. [Complete history](benchmarks/results/2026-11-13-composed-native-calls/README.md). |
| Latest fully qualified runtime | **63389c9d/2e74ef4f**, pushed: conservative native-call handoff using existing logical depth. All571frozen production inputs match the commit with explicit checkout normalization.66focused checks pass per actual target; controlled deep/direct/mutual recovery, finite100-depth calls and shared-budget cleanup pass. Full delivery [43378817838](https://github.com/Lokad/Lython/actions/runs/43378817838) is GREEN: both platforms, actual.NET11/10, original stress and installed Release consumers. Terminal logs,16step counts and571source proof are cached in the correction delivery directory. [Correction/evidence](benchmarks/results/2026-11-13-native-call-stack-handoff/README.md). |
| Current committed delivery candidate | **c5d05cff/3a2c1cf6**, R305 integer admission/kernel;572frozen production inputs match the commit.115internal/1049public focused Release checks and eight scripts/both APIs pass. Full Windows/Ubuntu actual.NET11/10, stress and installed consumers [43384587266](https://github.com/Lokad/Lython/actions/runs/43384587266) dispatched07:16:38UTC. Reuse source-labelled evidence; no active runtime prototype. |
| Evidence commits | d8e66a3e closes final2f local checks;681b6e8f invoice CPU gate;b649cbd8 independent complete invoice workload;031b92fa R301 delivery. Original adverse/failed conditions are preserved. Committed R304/R305 and external-checkpoint evidence are preserved separately. |
| Remaining measurement uncertainty | Historical formatting adverse15.125ms stays unexplained; later controlled5–8%CPU supports the retained implementation. Old native-return allocation savings are established; initial elapsed gains remain diagnostic. Captured2f+0.1..+3.3% with3.1%reference-control movement remains unresolved. B660 supplies corrected2e external/source-pair rows; R3053a invoice source-pair improves7–9%, supporting widerCPU, allocation flat. Captured/JSON3a controls cross zero. No current3a external ratio is inferred. |

## Completed milestones to preserve

- Shared compiler facts: nonlocal correction, annotation demand and lowered-retention
  cleanup delivered. Allocation reduction does not establish compilation dominance.
- Direct UTF8 formatting/storage: **−8.67% allocation**, controlled roughly5–8%
  elapsed/CPU. Preserve original adverse elapsed evidence separately.
- Native helper returns: historical **−19.92% Run/−19.31% Async allocation**;
  qualification, deterministic refund and correctness fixes complete. R289 replaces
  graph/proof/evaluation duplication with final slots/PC and exact once-only handoff.
  CSV fresh improves9–11%; native-search+1–6% debt accepted, guarded debt uncertain.
- Bulk CSV adoption/shared keys, private unboxed dictionary accumulators, live
  closure cells, bulk casing, JSON UTF8 windows and deterministic ownership delivered.
  R293 direct range loans remove scratch transactions/copying: captured fresh
  elapsed3.6–9.1%/CPU4.4–7.7% better; warm/control uncertainty remains.
- R295 builder transactions fix four reproduced refund/ownership failures: publish
  survivors before callbacks, roll back only unpublished replacement storage.
  No CPU claim. R29816builtin slot wrappers preserve their first defining owner;
  two public failures reproduce before correction, full qualification GREEN.
- R296 shares one formatter between ordinary workstate and native final slots.
  Report warm improves5.8–9.1%UTF8/6.5–8.0%UTF16, fresh4.9–8.3%, supporting CPU;
  allocation flat. Seven scripts/four boundaries and full delivery GREEN43350708328.
  [Controlled/source/delivery evidence](benchmarks/results/2026-11-13-formatted-helper-slots/README.md).
- Current external report/captured rows at qualified31d65e01/e34cacaf separate
  compile/warm/fresh. Captured warm remains1.61–1.64×CPython, fresh1.50–1.51×;
  compilation0.81–0.82×. Reports warm1.23–1.28×. These exclude laterR298.
  [Current and historical external guide](docs/BENCHMARKS.md). Reuse valid comparisons.

Experimental narratives, source identities, original/adverse conditions and rejected
designs stay in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results.

## Prioritized deliverables

1. **Close R304 managed native-call handoff delivery.** Unbounded CLR nesting from
   composed native prefixes has been replaced by an eight-level optimization
   eligibility check using existing logical depth. Deeper calls transfer before
   child entry to the existing linear runner. There is no new guest limit, counter,
   worker policy, stack telemetry or public switch. Existing512managed admission,
   recursion diagnostics, cancellation, first refusal and funded cleanup remain.
   Tradeoff: deeper calls can need ordinary admitted storage earlier; shallow
   composition remains native. The controlled256KiB host continuation proves
   qualified6b returns a structured error,2f crashes0xC00000FD and corrected2e
   recovers and supports finite depth100. Initial probes that resumed on the large
   startup worker were inconclusive, not evidence against the defect.

   CLOSED: focused66cases/actualtarget and full delivery are GREEN. The source
   proof matches all571frozen production inputs; generated metadata does not prove
   CI byte identity. Reuse cached logs; no further unchanged stack qualification or
   separate stack redesign is required.

2. **Current external checkpoint CLOSED.** B660 completes six jobs in250.895s on
   qualified63389c9d/2e74ef4f; all identity/output/ownership/quiet/join/archive gates
   pass, no users or RAM fixtures remain. Invoice warm1.45–1.46×CPython, compilation
   1.10–1.11×, fresh1.41–1.44×. Corrected-source invoice gain8.4–10.7% versus6b,
   supporting wider CPU. Captured warm1.65–1.66× and variable search1.59–1.67× still
   need work; JSON0.82–0.83×. Keep older phases/source-pair adversity explicit.
   Reuse [complete evidence](benchmarks/results/2026-11-13-invoice-cpython-checkpoint/README.md)
   and current docs tables; do not repeat this checkpoint unchanged.

3. **R305: consolidate pre-admitted integer arithmetic (retained, delivery next).** Current633/2e
   source/probe confirms subtract/multiply allocate~64KiB before first refusal,
   floor division/modulo~128KiB; addition refuses after32diagnostic bytes. Inputs
   remain unchanged and cleanup returns baseline. This is a demonstrated admission
   defect, separately from the CPU hypothesis. Modulo currently constructs a full
   quotient, product and difference. B656 also names arithmetic/classification;
   invoice still has a1.45–1.46×warm external gap.

   Migration: one integer kernel for subtract/multiply/floor-divide/modulo, shared
   from exact guest dispatch and bool/ingress numeric fallback. Pre-admit major
   result/workspace overlap, commit the surviving magnitude from that reservation;
   retain the tiny-scalar fast tier. Replace modulo's quotient/product with signed
   remainder correction. Reuse the kernel in math.prod/sumprod and Counter subtraction
   to remove duplicate multiplication preflight and post-allocation ownership.
   Remove displaced generic integer branches/helpers rather than add a parallel
   evaluator. Addition's measured fast path and existing power/shift guards remain.

   Acceptance: exact signed floor/mod and overflow promotion; mixed float/bool,
   reflected/subclass protocols and augmented evaluation order unchanged. Denial
   before major allocation/mutation preserves first structured origin; retained
   input/result aliases funded, reservations refunded, cancellation during admission
   aborts publication and cleanup returns shared allowance. BCL arithmetic itself
   cannot be interrupted mid-operation; do not claim new in-flight support there.
   Conservative scratch can reject earlier; no tiny-threshold contract.

   Development: focused Release numeric/protocol/admission/ownership/cancellation
   tests, regression demonstrated before correction, short exact source-pair invoice
   warm/fresh plus captured/JSON controls on the quiet VM. Compare allocation
   separately from elapsed/widerCPU. Preserve adverse observations; refine/retain/
   withdraw using semantic and complete-script evidence. End this milestone with
   displaced code removed, docs/contract limits current, then batch platform/stress/
   installed consumers at the coherent boundary. No extra external refresh needed.

   Outcomes: all eight pre-fix regressions fail; corrected3a2c1cf6 refuses after32
   diagnostic bytes,115internal/1049public Release checks pass. Eight complete scripts
   pass both APIs with effectively flat allocation. Quiet B661 completes four jobs
   in179.626s with full gates: invoice warm7.2–8.2%, fresh7.2–9.3% faster, supporting
   widerCPU. Text/JSON cross zero, no gain inferred. Retain without another retime;
   batch full platform/stress/package delivery now. [Immutable evidence](benchmarks/results/2026-11-13-integer-admission/README.md).

   R306 captured source gate CLOSED without a new runtime prototype. One capture
   has1502guest samples/7.58CPU seconds,9.72%unmapped, no ambiguous leaves; full
   identity/output/ownership/quiet/join/verified-RAM-archive gates pass. Top leaves:
   existing dictionary loop274, casing preparation151, instruction prefix113,
   native core82, casing writer66; useful/inlined work is not removable share.
   Metadata proves no mirrored locals, helper already native/five slots; main's
  21slots/one captured cell create one frame per script. Source disproves repeated
   Unicode count/mapping passes and nested allowance locks. Preserve these negative
   findings, avoiding another local tweak or unchanged rejected design.
   [Evidence and exact unresolved boundary](benchmarks/results/2026-11-13-captured-cpu-source-gate/README.md).

   Next source deliverable: assess the complete existing bulk dictionary/preparation
   boundary or per-record collection transport. Identify one major repeated proof,
   intermediate or ownership transaction actually removable across representative
   scripts before prototyping. If cost remains mixed useful work, record that
   uncertainty rather than infer a gain or start another profiler campaign. Keep
   eager denial-before-effects, last-word/total publication and refund reentry.

   Remaining roadmap: source-gate per-record construction/operand transport and
   repeated frontend analysis after R305. Existing bulk CSV/shared keys, final slots,
   live cells, direct UTF8 casing/formatting and JSON windows are already delivered;
   select an actual remaining copy/retained intermediate with representative cost.
   Preserve source identities and existing slower call-arena/control lessons.

4. **Independent regex/provider development.** Core Python/nativeUTF8 contract is
   delivered and dependency-free; normal optional nonpackable adapter remains0.4.
   Immutable dev.78/dev.79 bridges passed88internal/534public per actual target.
   [Exact dev.79 evidence](benchmarks/results/2026-11-13-regex-dev79-bridge/README.md)
   is development validation, not backend performance/final release qualification.
   At that checkpoint funded Compile did not visibly forward AssumeValid; the
   adapter-local bridge uses the working overload with conservative admission.
   Precise final gaps: separate one-match working/result owners, nativeUTF8 group
   names, token-independent cursor construction with cancellable preparation.
   Review current producer capabilities before adoption, without editing the sibling
   or replaying unchanged bridge qualification. Missing released APIs defer only
   affected final adapter qualification. Continue independent core semantics,
   byte/scalar ranges, original windows, flags, current-token forwarding and cache
   ownership; no blanket development stop or core dependency edge.

## Iteration and lasting constraints

Distinguish architectural simplification, allocation reduction and demonstrated CPU
improvement. Percentages inform decisions, never automatically veto them. Timeouts,
moving controls and inconclusive observations establish uncertainty. Allow bounded
confirmation, refinement or measurement correction when evidence justifies it;
retain originals. No blanket one-attempt/no-retiming/permanent-closure rules.

Use focused Release checks during iteration; batch platform, original stress and
installed Release package consumers at coherent boundaries. Force nonincremental
builds after source restores. Keep GC cases nonparallel. Cache terminal CI and
space observations at least4min apart. VM workers/catalog/evidence stay persistent;
RAM fixtures are separate. Join users, archive/SHA-verify before unmount. Reuse valid
measurements; repeat only for a stated material uncertainty or changed condition.

Fully managed/memory-safe: no unsafe C#/APIs, pointers, P/Invoke or native probing.
Keep managed stack admission, host mediation/original path+Cwd, cancellation, cycle/
XML/checked representation protection and bounded I/O chunks. No fuel/host quotas,
regex work/time policies, hidden resource caps/default allowances, guest-heap
tracing, weak reclamation or forced GC. Borrowed allowance funds major capacity,
replacement peaks, retained aliases/results/caches and pending users. Scopes add no
independent allowance. Initial streaming uses bounded host executions. First refused
admission fails the command through suppression/finally; await cleanup, never retry
or abandon work. Keep regex core-decoupled and Python-shaped semantics. Current
guides stay in docs; plans/receipts/experiments stay outside it. Publication/tagging
require separate authorization.
