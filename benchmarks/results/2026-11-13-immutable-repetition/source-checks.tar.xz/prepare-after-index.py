from pathlib import Path
import ast
r=Path(__file__).parent;code=(r/'after-probe.py').read_text(encoding='utf-8').replace("out=r/'after-probe'","out=r/'after-index-probe'").replace('../final/Lokad.Lython.dll','../index-corrected/Lokad.Lython.dll').replace("r/'final/candidate-identity.json'","r/'index-corrected/candidate-identity.json'")
for name in ['after-build.log','after.json','after-stderr.log']:code=code.replace(name,name.replace('after','after-index',1))
ast.parse(code);(r/'after-index.py').write_text(code,encoding='utf-8')
