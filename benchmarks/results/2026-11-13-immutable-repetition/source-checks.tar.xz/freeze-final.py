from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'index-corrected';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();sources={p:sha(p)for p in names};assert len(sources)==572
initial=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));changed=[p for p,h in sources.items()if h!=initial['sources'][p]];assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Operations.cs'],changed
shutil.copy2('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='Final R307; CPython-correct native-index validation follows initial6f diagnostic; incorrect oversized-count assumption preserved separately',sources=sources,changedFromInitial=changed,changed=initial['changed'],coreSHA256=sha(out/'Lokad.Lython.dll'),referenceSHA256=initial['referenceSHA256'],initialDiagnosticCore=initial['coreSHA256'])
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
print(identity['coreSHA256'],flush=True)
