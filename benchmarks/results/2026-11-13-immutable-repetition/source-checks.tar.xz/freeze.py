from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'arithmetic-source-r305';reference=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();assert len(names)==572
sources={p:sha(p)for p in names};changed=[p for p in names if sources[p]!=reference['sources'][p]];assert len(changed)==5,changed
for role in ['reference','candidate']:
 shutil.copytree(old/'candidate',r/role,copy_function=os.link)
 if role=='candidate':
  (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copy2(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R307 shared bounded immutable repetition and pre-admitted retained storage',sources=sources,changed=changed,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=reference['coreSHA256'])
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
shutil.copy2(old/'catalog.json',r/'catalog.json')
print(identity['coreSHA256'],changed,flush=True)
