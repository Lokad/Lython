data=b'abc'*87382
text='é😀'*8192
values=(b'x',)*4097
with open('artifact.bin','wb') as target:
    target.write(data)
with open('report.txt','w',newline='') as target:
    target.write(text)
print(len(data),len(text),len(values))
