from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
dest=repo/"benchmarks/results/2026-11-23-numeric-capture-cpython"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(lab/"identity.json")
terminal=read(lab/"terminal-status.json")
assert terminal["exitCode"]=="0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha(lab/"observations.tar.xz")==terminal["receipt"]["archiveSHA256"]
assert read(lab/"summary.json")["timedBatches"]==196
assert not subprocess.check_output(["git","diff","--name-only",identity["sourceRevision"],"HEAD","--","src","tests"],cwd=repo)
image=lab.parent/"strict-short-float-20261123/candidate"
assert {name:sha(image/name) for name in identity["imageFiles"]["candidate"]}==identity["imageFiles"]["candidate"]
dest.mkdir(exist_ok=True)
for name in ("identity.json","terminal-status.json","observations.tar.xz","summary.json"):
    shutil.copyfile(lab/name,dest/name)
with tarfile.open(dest/"procedures.tar.xz","w:xz") as archive:
    for name in ("archive.py","quiet.py","summarize.py","candidate-verify.json","launch.log","launch-first.log","observe-not-before"):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ("terminal-status.json","observations.tar.xz","launch.log","retrieval.log"):
        archive.add(lab/"failed-attempt"/name,arcname="failed-attempt/"+name,recursive=False)
print(dest)
