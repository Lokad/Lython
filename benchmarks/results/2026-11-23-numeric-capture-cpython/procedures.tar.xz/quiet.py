from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
host="lokad@20.166.121.73"
root="/home/lokad/lython-bench-checks/numeric-capture-cpython-b1467-retry-20261123"
unit="lython-b1467-numeric-capture-cpython-retry-20261123"

source=lab.parent/"strict-short-float-20261123"
previous=source/"comparison/quiet"
confirmation=json.loads((source/"exponent-control/terminal-status.json").read_text(encoding="utf-8"))
assert confirmation["exitCode"]=="0" and confirmation["receipt"]["complete"]

state=json.loads((previous/"terminal-status.json").read_text(encoding="utf-8"))
previous_archive=state["receipt"]["archiveSHA256"]
assert state["exitCode"]=="0" and state["receipt"]["complete"]
key=Path.home()/".ssh/id_lython-bench.pem"
options=["-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=14"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*options,host]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*options]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc)

if sys.argv[1]=="launch":
    staged=json.loads((source/"comparison/identity.json").read_text(encoding="utf-8"))
    production=subprocess.check_output(["git","rev-parse","d969c134f"],cwd=repo,encoding="utf-8").strip()
    assert not subprocess.check_output(["git","diff","--name-only",production,staged["candidate"],"--","src","tests"],cwd=repo)
    assert not subprocess.check_output(["git","diff","--name-only",production,"HEAD","--","src","tests"],cwd=repo)
    assert sha(previous/"observations.tar.xz")==previous_archive
    assert sha(lab/"run.sh")==sha(previous/"run.sh") and b"\r" not in (lab/"run.sh").read_bytes()
    files=staged["imageFiles"]["candidate"]
    local=source/"candidate"
    assert len(files)==32 and {name:sha(local/name) for name in files}==files
    catalog=lab/"representative.json"
    protocol=repo/"benchmarks/cpython-worker.py"
    assert sha(protocol)==staged["cpythonWorkerSHA256"]
    dotnet=Path.home()/".dotnet11/dotnet.exe"
    verification=lab/"candidate-verify.json"
    subprocess.run([dotnet,local/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verification],
        env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=90)
    proof=json.loads(verification.read_text(encoding="utf-8"))
    assert proof["state"]=="Completed" and proof["caseCount"]==6 and proof["catalogSha256"]==sha(catalog)
    core=files["Lokad.Lython.dll"]
    assert proof["launched"]["library"]["sha256"]==core
    assert {name:sha(local/name) for name in files}==files
    identity=dict(sourceRevision=production,candidate=staged["candidate"],retainedRevision=production,
        frozenImage=root.rsplit("/",1)[0]+"/strict-short-float-b1465-20261123/candidate",
        imageFiles={"candidate":files},
        auxiliaryFiles={name:digest for name,digest in files.items() if name!="Lokad.Lython.dll"},
        coreSHA256={role:core for role in ("candidate","candidate-control")},
        cpythonWorkerSHA256=staged["cpythonWorkerSHA256"],expectedCPythonSHA256=staged["expectedCPythonSHA256"],
        catalogs={name:dict(sha256=sha(lab/name)) for name in ("representative.json","jobs.json")})
    used_keys={"auxiliaryFiles","catalogs","coreSHA256","cpythonWorkerSHA256",
               "expectedCPythonSHA256","frozenImage","imageFiles"}
    assert used_keys <= identity.keys()
    (lab/"identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
    files=("representative.json","identity.json","collect.py","run.sh","jobs.json")
    archive=io.BytesIO()
    with tarfile.open(fileobj=archive,mode="w:gz") as package:
        for name in files:
            package.add(lab/name,arcname=name,recursive=False)
    data=archive.getvalue()
    (lab/"payload.tgz").write_bytes(data)
    code=f"""
from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
root=Path({root!r})
prior=root.parent/'strict-short-float-b1465-20261123'
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert digest(prior/'observations.tar.xz')=={previous_archive!r}
data=sys.stdin.buffer.read()
assert hashlib.sha256(data).hexdigest()=={hashlib.sha256(data).hexdigest()!r}
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert shutil.disk_usage(root.parent).free>=128*1024*1024
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data)) as package:
  assert set(package.getnames())=={{'representative.json','identity.json','collect.py','run.sh','jobs.json'}}
  package.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 image=prior/'candidate'
 assert image==Path(identity['frozenImage'])
 assert all(digest(image/f)==expected for f,expected in identity['imageFiles']['candidate'].items())
 assert digest(prior/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 os.link(prior/'cpython-worker.py',root/'cpython-worker.py')
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=395','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    compile(code,"remote-stage","exec")
    result=subprocess.run(ssh+["python3 -c "+shlex.quote(code)],input=data,capture_output=True,timeout=25)
    (lab/"launch.log").write_bytes(result.stdout+result.stderr)
    print((result.stdout+result.stderr).decode(),end="")
    result.check_returncode()
    (lab/"observe-not-before").write_text((now()+datetime.timedelta(seconds=353)).isoformat(),encoding="utf-8")
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((lab/"observe-not-before").read_text(encoding="utf-8"))
    code=f"""
from pathlib import Path
import fcntl,json,subprocess
root=Path({root!r})
service=subprocess.run(['systemctl','show','{unit}.service','--property=ActiveState,Result,ExecMainStatus,MainPID'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service: print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  read=lambda n: (root/n).read_text().strip() if (root/n).exists() else None
  print(json.dumps(dict(live=False,service=service,exitCode=read('exit-code.txt'),receipt=json.loads(read('archive-receipt.json') or 'null'),
        fixtures=(root/'guest-fixtures').exists(),
        journal=subprocess.run(['journalctl','-u','{unit}.service','-n','25','--no-pager'],capture_output=True,text=True).stdout)))
"""
    output=subprocess.check_output(ssh+["python3 -c "+shlex.quote(code)],encoding="utf-8",timeout=25)
    report=json.loads(output)
    (lab/("status-"+now().strftime("%H%M%S")+".json")).write_text(output,encoding="utf-8")
    print(output,end="")
    if not report["live"] and report["receipt"] is not None:
        target=lab/"observations.tar.xz"
        subprocess.run(scp+[host+":"+root+"/observations.tar.xz",target],check=True,timeout=35)
        assert sha(target)==report["receipt"]["archiveSHA256"]
        (lab/"terminal-status.json").write_text(output,encoding="utf-8")
        assert report["exitCode"]=="0" and report["receipt"]["complete"] and not report["fixtures"]
