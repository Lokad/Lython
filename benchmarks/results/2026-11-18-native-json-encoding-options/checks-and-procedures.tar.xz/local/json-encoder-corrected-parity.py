import subprocess
from pathlib import Path
import os
import json

lab = Path(__file__).resolve().parent
folder = lab.parent.parent.parent / "agent-worktrees"
root = Path.cwd()
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
source = """
import io
import json

events=[]
class Flag:
    def __init__(self,name,value):
        self.name=name
        self.value=value
    def __bool__(self):
        events.append(self.name)
        return self.value
class Unknown:
    pass
def default(value):
    events.append('default')
    return ['🚚',None]
def separators():
    events.append('first')
    yield ','
    events.append('second')
    yield ':'
def bad_separators():
    events.append('first')
    yield 42
    events.append('second')
    yield ':'
class Writer:
    def __init__(self,fail=False):
        self.pieces=[]
        self.fail=fail
    def write(self,chunk):
        self.pieces.append(chunk)
        if self.fail and len(self.pieces)==3:
            raise ValueError('write refused')
class Encoder(json.JSONEncoder):
    def __init__(self,**kwargs):
        events.append('init')
        super().__init__(**kwargs)
    def iterencode(self,value,_one_shot=False):
        events.append('iterencode')
        return super().iterencode(value,_one_shot)
"""
cases = {
    "compact": """print(json.dumps({'café':'🚚','q':'x\\ny'},ensure_ascii=False,separators=(',',':'),sort_keys=True))""",
    "eager_flags": """print(json.dumps({'z':1,'a':2},cls=json.JSONEncoder,skipkeys=Flag('skip',False),ensure_ascii=Flag('ascii',False),check_circular=Flag('circle',True),allow_nan=Flag('nan',True),sort_keys=Flag('sort',True),separators=separators()))""",
    "dump_flags": """target=Writer()
json.dump({'a':'é','z':float('nan')},target,cls=json.JSONEncoder,ensure_ascii=Flag('ascii',False),check_circular=Flag('circle',True),allow_nan=Flag('nan',True),sort_keys=Flag('sort',True),skipkeys=Flag('skip',False),separators=separators())
print(target.pieces)""",
    "string_ignores_other_options": """print(json.dumps('🚚',ensure_ascii=Flag('ascii',False),check_circular=Flag('circle',True),indent=Unknown(),separators=bad_separators()))""",
    "separator_type": """try: json.dumps(['a','b'],separators=bad_separators())
except Exception as error: print(type(error).__name__)""",
    "writer_failure": """target=Writer(True)
try: json.dump([2,3,4],target,ensure_ascii=False,indent=2)
except Exception as error: print(type(error).__name__)
print(target.pieces)""",
    "custom_default": """print(json.dumps({'a':Unknown()},default=default,ensure_ascii=False,indent=2))
target=io.StringIO()
json.dump({'a':Unknown()},target,default=default,ensure_ascii=False,indent=2)
print(target.getvalue())""",
    "subclass": """target=Writer()
json.dump([Unknown()],target,cls=Encoder,default=default,ensure_ascii=False)
print(target.pieces)
print(json.dumps([Unknown()],cls=Encoder,default=default,ensure_ascii=False))""",
    "extra": """for fn in [lambda:json.dumps([],unknown=True),lambda:json.dump([],Writer(),unknown=True)]:
    try: fn()
    except Exception as error: print(type(error).__name__)""",
    "cycle": """value=[]
value.append(value)
for fn in [lambda:json.dumps(value,ensure_ascii=False),lambda:json.dump(value,Writer(),ensure_ascii=False)]:
    try: fn()
    except Exception as error: print(type(error).__name__)""",
}
def run(args, data):
    result = subprocess.run(args, input=data, capture_output=True, env=env, timeout=45)
    return (result.returncode, result.stdout.replace(b"\r\n",b"\n"), result.stderr)

programs = [(name,source+"\n"+body+"\nprint(events)\n") for name,body in cases.items()]
standards = [run(["C:/Python313/python.exe","-X","utf8","-I","-S","-"],program.encode()) for _,program in programs]
payload = json.dumps([program for _,program in programs]).encode()

for framework in ("net11.0","net10.0"):
    for asynchronous in (False,True):
        solutions = []
        for tree in ("shared-strip-entry","native-json-encoding-options"):
            probe = root/".git/agent-worktrees"/tree/"tools/LythonProbe/bin/Release"/framework/"LythonProbe.dll"
            code,stdout,stderr = run([sdk/"dotnet.exe",probe,"--batch-json"]+(["--async"] if asynchronous else []),payload)
            assert code==0 and not stderr,(code,stderr,stdout)
            solutions.append([json.loads(line)["Lython"] for line in stdout.splitlines()])
        assert solutions[0]==solutions[1] and len(solutions[1])==len(programs)
        lines = []
        for (name,_),std,actual in zip(programs,standards,solutions[1]):
            assert actual["Success"]
            same = std==(0,actual["StandardOutput"].encode(),actual["StandardError"].encode())
            lines.append(f"{name} matches previous Lython; CPython parity {same}")
            if not same:
                lines.append("CPython "+repr(std))
                lines.append("Lython "+repr(actual["StandardOutput"]))
        tag=f"{framework}-{'async' if asynchronous else 'sync'}"
        (lab/f"encoder-corrected-parity-{tag}.log").write_text("\n".join(lines)+"\n",encoding="utf-8")
        print(tag,len(programs),"match prior Lython;",sum(x.endswith("True") for x in lines),"match CPython",flush=True)
