import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
home = root.parent
out = home/"native-json-encoding-options-r540"
out.mkdir(exist_ok=True)
repo = Path.cwd()
candidate = repo/".git/agent-worktrees/native-json-encoding-options"
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
def write(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
core = "Lokad.Lython.dll"
reference = root/"frozen/candidate"
release = candidate/"src/Lokad.Lython/bin/Release/net11.0"/core
assert sha(release)==sha(candidate/"benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0"/core)
assert "Build succeeded." in (root/"json-encoder-build.log").read_text(encoding="utf-8-sig")
donor_id = read(root/"frozen-identity.json")
donor = donor_id["imageFiles"]["candidate"]
assert len(donor)==32 and all(sha(reference/n)==h for n,h in donor.items())
diff = subprocess.check_output(["git","-C",candidate,"diff","--binary","227d80b47","--","src"])
(out/"source.patch").write_bytes(diff)
catalog = read(home/"numeric-compiler-facts-r532/representative.json")
edit = next(c for c in catalog["cases"] if c["id"]=="scripts.config-edit.small")
prepared = read(home/"compiler-checkpoint-r425/checkpoint/representative.json")
manifest = next(c for c in prepared["cases"] if c["id"]=="scripts.config-manifest.small")
control = next(c for c in read(root/"representative.json")["cases"] if c["id"]=="calls.positional.large")
catalog["cases"] = [edit,manifest,control]
catalog["performanceQualified"] = False
workload = out/"representative.json"
write(workload,catalog)
images = {}
for role, dll in [("reference", reference/core), ("candidate", release)]:
    image = out/"frozen"/role
    image.mkdir(parents=True,exist_ok=True)
    for n in donor:
        shutil.copyfile(dll if n==core else reference/n,image/n)
    for p in reference.glob("ValidatedAllocation.*"):
        shutil.copyfile(p,image/p.name)
    images[role] = {n:sha(image/n) for n in donor}
    assert images[role] == donor | {core:sha(dll)}
    verification = [dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",workload,"--dotnet",dotnet,
                    "--python","C:/Python313/python.exe","--python-worker",repo/"benchmarks/cpython-worker.py",
                    "--out",out/f"{role}-verification.json"]
    with (out/f"{role}-verification.log").open("w",encoding="utf-8") as log:
        subprocess.run(verification,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,workload,out/f"{role}-allocation.json"],cwd=repo,env=env,timeout=120,check=True)
    assert all(sha(image/n)==h for n,h in images[role].items())
    print(role,images[role][core],"goldens and allowance reuse passed",flush=True)
write(out/"frozen-identity.json", {
    "sourceRevision":"227d80b47 / f2824fea0 versus private bound JSON serialization prototype",
    "imageFiles":images,"catalogSHA256":sha(workload),
    "coreSHA256":{label:images[role][core] for role in images for label in (role,role+"-control")},
    "normalAdapterPin":"0.4.0",
    "purpose":"Remove transient exact-builtin JSON encoder attribute and method packaging"
})
