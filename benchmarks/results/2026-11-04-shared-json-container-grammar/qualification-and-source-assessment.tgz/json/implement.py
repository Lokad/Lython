from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs')
s=p.read_text(encoding='utf-8')
old='''                return first == (byte)'{'
                    ? ReadJsonObjectAsync(input, options, context, span, depth + 1, position, asynchronous)
                    : ReadJsonArrayAsync(input, options, context, span, depth + 1, position, asynchronous);'''
assert old in s
s=s.replace(old,"                return ReadJsonContainerAsync(input, options, context, span, depth + 1, position, first == (byte)'{', asynchronous);")
start=s.index('        private async ValueTask<(object Value, int End)> ReadJsonObjectAsync(')
end=s.index('        // Matches a JSON constant literal',start)
s=s[:start]+'''        private async ValueTask<(object Value, int End)> ReadJsonContainerAsync(
            PyString input, JsonLoadOptions options, ExecutionContext context, LythonSourceSpan span,
            int depth, int opening, bool isObject, bool asynchronous)
        {
            var bytes = input.Utf8Bytes;
            var expected = isObject ? context.State.JsonRecordKeys : Array.Empty<PyString>();
            var matched = true;
            var dictionary = isObject && options.ObjectPairsHook is null ? new PyDict(context.MemoryGovernor, span) : null;
            var values = dictionary is null ? new PyList([], context.MemoryGovernor, span) : null;
            var closer = isObject ? (byte)'}' : (byte)']';
            var valueEnd = -1;
            while (true)
            {
                // A closer here follows an empty container or a completed value.
                var peek = SkipJsonWhitespace(bytes.Span, valueEnd < 0 ? opening + 1 : valueEnd, context, span);
                if (peek < bytes.Length && bytes.Span[peek] == closer)
                {
                    if (isObject)
                    {
                        var count = dictionary?.Count ?? values!.Count;
                        if (matched && count == expected.Length) context.State.JsonRecordKeys = expected;
                        else context.State.RememberJsonRecordKeys(dictionary is not null ? dictionary.Keys : JsonPairKeys(values!), count, span);
                    }
                    object result = dictionary is not null ? dictionary : values!;
                    var hook = isObject ? options.ObjectPairsHook ?? options.ObjectHook : null;
                    return hook is null ? (result, peek + 1)
                        : (await InvokeJsonCallbackCoreAsync(hook, result, context, span, asynchronous).ConfigureAwait(false), peek + 1);
                }

                var start = peek;
                if (valueEnd >= 0)
                {
                    var comma = EnsureJsonComma(bytes.Span, valueEnd, input, span, context);
                    start = SkipJsonWhitespace(bytes.Span, comma + 1, context, span);
                    if (start < bytes.Length && bytes.Span[start] == closer)
                    {
                        throw NewJsonDecodeFailure(input, isObject
                            ? "Illegal trailing comma before end of object" : "Illegal trailing comma before end of array",
                            comma, innerException: null, span, context);
                    }
                }

                if (start >= bytes.Length || (isObject && bytes.Span[start] != (byte)'"'))
                {
                    throw CreateJsonExpectingError(input, start >= bytes.Length ? bytes.Length : start,
                        isObject ? JsonIncompleteExpectation.PropertyName : JsonIncompleteExpectation.Value, span, context);
                }

                context.CheckExecution(span);
                PyString? key = null;
                if (isObject)
                {
                    var property = ReadJsonObjectKey(input, options, start, context, span, expected);
                    key = property.Value;
                    matched &= property.Reused;
                    start = EnsureJsonColon(bytes.Span, property.End, input, span, context) + 1;
                }

                var (value, end) = await ReadJsonValueAsync(input, options, context, span, depth, start, asynchronous).ConfigureAwait(false);
                if (dictionary is not null) dictionary.SetItem(key!, value);
                else values!.Add(isObject ? PyTuple.FromOwnedArray([key!, value], context.MemoryGovernor, span) : value);
                context.CheckExecution(span);
                valueEnd = end;
            }
        }

        private static IEnumerable<object> JsonPairKeys(PyList pairs)
        {
            foreach (var pair in pairs) yield return ((PyTuple)pair)[0];
        }

''' + s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
