# B199 operand/dispatch gate — current source32a42cec

B198 is shelved with all sources/observations/229 and71 failures preserved;
production source restored to qualified B197. This advances the continuing
whole-script objective, not completion. No new CPU or full qualification claim.

Actual source corrections before choosing a redesign:
- ExecutableInstruction already is a compact readonly struct with two int operand
  slots and a span. Do not propose removing hypothetical15-field instructions.
- ExecuteInstructionPrefix contains the instruction WHILE loop shared by both
  APIs. InstructionPause returns at boundaries; no driver roundtrip per opcode.
  Instructions are read by reference.
- ExecutableValueStack is a mutable struct with one admitted object array,
  ordinary pushes/pops and explicit retirement. No heap carrier per push exists.
- Parameter bindings already are pooled locals; native helpers and borrowed
  arguments already bypass substantial general construction.
- Remaining work includes local->operand object transport, slot clearing,
  operation-helper dispatch and boxing. The mixed17.5–19.2% instruction bucket
  does not attribute all of this to one mechanism.

Next bounded design gate: use existing representative text/report and CSV/JSON
code objects/profiles to identify a COMPLETE operand-transport deletion. Assess
an expression/register representation, not a list of fused-opcode exceptions.
Count eliminated loads/stores/copies/dispatch/storage and metadata added; include
compilation and native-helper bypasses in the cost/lifetime model. No new framework
or broad campaign. End in one concrete pre-code proposal or precise deferral;
no arena, reset framework or general tagged-value replacement without this model.

If justified, retain one executable engine and supported syntax. Snapshot values
before callbacks/rebinding; preserve identity/aliases/exact overflow, closures,
class cells, order/short-circuit, exceptions/finally, generators and real suspension.
Preflights/terminal refusal, awaited cleanup, current-token cancellation, managed
stack admission and retained owners remain effective. Name displaced stack
operations/dispatch to remove at completion; leave no dormant backend.

One short complete-script pair with independent old roles and affected controls,
both APIs, compilation separate; warm IO/checks/previous-result cleanup included.
Keep binary/source identity, adverse samples and warmup/tiering sensitivity.
Intermediate regression is debt with a completion milestone and explicit decision.

## Current source decision

Compiled inventory10d37309 records five scripts and the integer control. Text's
inner loop26..42 has17 instructions,9 local/constant loads/stores. Report render
has19 instructions:6 loads,3 subscripts,9 prepared formatting operations,return.
Three other helpers already use native-return bodies. These are static work counts,
not CPU shares. Crucial prior evidence: B147 folded all operator inputs/destinations
and B185 used the spare arithmetic operand for sources; both added metadata/input
dispatch, had essentially flat allocation and measured actual script regressions.
Do not repeat them. A full register model must eliminate their per-operator plan
lookup and reuse/replace native-return metadata; preserve callback snapshots and
direct/native argument borrows. No such complete cost model is established now.

Precisely defer register code at this gate. Next selected bounded design is B200,
one recursive JSON container grammar eliminating3 duplicate loops and one async
state-machine type without B137/B176's explicit continuation workspace. This is
not a permanent operand ban; the inventory and concrete displacement criteria stay.
