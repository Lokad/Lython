import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
trial = repo / '.git/agent-worktrees/branch-state-ownership'
prior = lab.parent / 'utf8-expanded-format'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args])

pair = read(prior/'frozen-identity.json')
reference = git('rev-parse', 'bbbf360cd').decode().strip()
assert git('rev-parse','HEAD').decode().strip()==reference
candidate = git('-C', trial, 'rev-parse', 'HEAD').decode().strip()
assert reference.startswith('bbbf360cd') and reference!=candidate
assert git('merge-base', reference, candidate).decode().strip() == reference
assert not git('-C', trial, 'status', '--porcelain')
assert not git('diff','--name-only',reference,candidate,'--','global.json','Directory.Build.props','Directory.Packages.props',
               'src/Lokad.Lython.Utf8Regex','benchmarks')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',reference,candidate))

catalog=read(lab.parent/'lowered-default-values/catalog.json')
catalog['cases']=[row for row in catalog['cases'] if row['id'] in {
    'scripts.config-generated-guards.medium','scripts.config-manifest.small',
    'scripts.annotated-rule-closures','scripts.csv-invoice.large'}]
assert len(catalog['cases'])==4
manifest = lab/'catalog.json'
write(manifest,catalog)

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
files = pair['images']['candidate']
origin = prior/'frozen/candidate'
core = 'Lokad.Lython.dll'
assert len(files)==32 and {name:sha(origin/name) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for name in files:
        shutil.copyfile(origin/name,image/name)
    expected=files.copy()
    build=lab/'build-win' if role=='candidate' else lab.parent/'lazy-positional-defaults/reference-build'
    built=build/'bin/Lokad.Lython/release_net11.0'/core
    shutil.copyfile(built,image/core)
    expected[core]=sha(built)
    for helper in (lab.parent/'method-format-frame/frozen/reference').glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    for helper in (lab.parent/'direct-class-header/compile-allocation/reference').glob('CompileAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    def run(kind, arguments, environment=env):
        with (lab/(role+'-'+kind+'.log')).open('wb') as log:
            subprocess.run([dotnet,*arguments],env=environment,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=140)
    assert {name:sha(image/name) for name in expected}==expected
    verify=lab/(role+'-verify.json')
    run('verify',[image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
                  '--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py','--out',verify])
    verified=read(verify)
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    run('compile-allocation',[image/'CompileAllocation.dll',manifest],dict(env,DOTNET_TieredCompilation='0'))
    alloc=read(lab/(role+'-compile-allocation.log'))
    assert alloc['coreSha256']==expected[core]
    run('allocation',[image/'ValidatedAllocation.dll',image,manifest,lab/(role+'-allocation.json')])
    assert {name:sha(image/name) for name in expected}==expected
    images[role]=expected
assert images['reference'][core]!=images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
rows=[]
for boundary,metric,baseline in [('compile-allocation','bytes',None),('allocation','allocatedBytesPerInvocation','sharedBudgetBaselineRestored')]:
    extension='.json' if baseline else '.log'
    for a,b in zip(*(read(lab/(role+'-'+boundary+extension))['rows'] for role in images),strict=True):
        assert a['id']==b['id']
        if baseline:
            assert a[baseline] and b[baseline]
        before,after=[statistics.median(row[metric]) for row in (a,b)]
        row=dict(boundary=boundary,id=a['id'],referenceBytes=before,candidateBytes=after,changePct=100*(after/before-1))
        if 'peakExecutionMemoryBytes' in a:
            row.update(referencePeak=a['peakExecutionMemoryBytes'],candidatePeak=b['peakExecutionMemoryBytes'])
        rows.append(row)
        print(boundary,a['id'],f'{before:,} to {after:,} {row["changePct"]:+.2f}%')
write(lab/'summary.json',dict(reference=reference,candidate=candidate,verification='Four CPython goldens per full 32-file image.',rows=rows))
