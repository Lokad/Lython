from pathlib import Path
import gzip
import io
import tarfile
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
pairs = [('lazy-positional-defaults/quiet', '2026-11-20-lazy-positional-defaults', 'candidate', 'measured-core.dll.gz'), ('utf8-expanded-format/quiet', '2026-11-20-utf8-format-specifiers', 'candidate', 'measured-core.dll.gz')]
records=[]
base='/home/lokad/lython-bench-checks'
for folder, evidence, role, image in pairs:
    local=f'benchmarks/results/{evidence}'
    where=read(lab.parent/folder/'config.json')['root']
    assert where.startswith(base+'/')
    commit=subprocess.check_output(['git','log','-1','--format=%H','--',local+'/'+image]).decode().strip()
    def recorded(name):
        return subprocess.check_output(['git','show',f'{commit}:{local}/{name}'])
    core=gzip.decompress(recorded(image))
    digest=hashlib.sha256(core).hexdigest()
    summary=json.loads(recorded('summary.json'))
    assert digest==(summary.get('coreSHA256') or summary['cores'][role])
    receipt = json.loads(recorded('archive-recovery.json' if folder == 'borrow-lexical-builder-r625' else 'archive-receipt.json'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt.get('archivedAndVerifiedUnderLease') or receipt.get('verifiedAfterCollectionUnderIdleLease')
    assert hashlib.sha256(recorded('observations.tgz')).hexdigest() == receipt['archiveSHA256']
    records.append(dict(bytes=len(core),links=1,paths=[where.removeprefix(base+'/')+'/'+role+'/Lokad.Lython.dll'],
        sha256=digest,committedBlobVerified=True,canonicalCommit=commit,canonicalPath=local+'/'+image))
remote = '''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
root=Path('/home/lokad/lython-bench-checks')
records=CONTENTS
present=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    eligible={}
    rejected=[]
    for record in records:
        path=root/record['paths'][0]
        if not path.exists(): continue
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid(): continue
        if info.st_size!=record['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=record['sha256']:
            rejected.append(str(path))
            continue
        key=info.st_dev,info.st_ino
        if key in eligible: continue
        eligible[key]=(record,info.st_nlink,[])
    for directory,_,files in os.walk(root):
        for name in files:
            candidate=Path(directory)/name
            candidate_info=candidate.lstat()
            key=candidate_info.st_dev,candidate_info.st_ino
            if key not in eligible: continue
            assert candidate.resolve()==candidate and candidate.is_relative_to(root)
            eligible[key][2].append(str(candidate.relative_to(root)))
    for record,links,aliases in eligible.values():
        if len(aliases)!=links: continue
        assert record['paths'][0] in aliases
        present.append(dict(record,links=links,paths=sorted(aliases)))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=present,rejectedReplicas=rejected),indent=2))
'''.replace('CONTENTS',repr(records))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
     '-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=50)
if result.returncode:
    raise RuntimeError(result.stderr.decode('utf-8','replace'))
data=json.loads(result.stdout)
(lab/'quiet-space.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print(data['freeBytes'], [item['paths'][0] for item in data['replicas']])

