from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('.git/agent-notes/review-20261031/cold-string-hash-r33');out=Path('benchmarks/results/2026-11-07-native-hash-cancellation');out.mkdir()
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
for name in ['focused-initial.json','hash-diagnostic-summary.json','probe-after.json','baseline.json','contract.md']:shutil.copyfile(root/name,out/name)
(root/'runtime.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src','tests/Lokad.Lython.Tests']))
with tarfile.open(out/'development-evidence.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.is_file() and p.suffix!='.tgz':a.add(p,arcname=p.name)
    a.add(root/'baseline-source-and-images.tgz',arcname='baseline-source-and-images.tgz')
    a.add('tests/Lokad.Lython.Tests/NativeHashCancellationTests.cs',arcname='NativeHashCancellationTests.cs')
    for framework in ['net11.0','net10.0']:
        p=Path(f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll');assert hashlib.sha256(p.read_bytes()).hexdigest()==checks['coreSHA256'][framework]
        a.add(p,arcname=f'checked-images/{framework}/Lokad.Lython.dll')
archive=out/'development-evidence.tgz';(out/'sha256.json').write_text(json.dumps({archive.name:hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Current-token native hashing — R33

2026-11-07. Runtime structural/builtin hash requests now require the active context.
Cold strings and bytes pass its token through the actual byte scan; bytes replaces
one whole-buffer HashCode.AddBytes call with the existing4096-byte streaming hash.
Native hash methods receive their caller rather than discarding it. Native
already-funded dictionary writes and native-format proof reads also carry that
context, retaining their sealed-key/no-protocol eligibility. Context-free CLR
comparers keep their separate, guest-free behavior. No new policy, counter,
watchdog, background matching, owner or hash framework.

Source8c4059b6 plus the preserved twelve-file runtime patch/new regression file.
Final checked net11 07a6530e / net10 6c5dcc32. Existing standalone forwarding probe
changes from sync success under a cancelled token to refusal on both APIs; explicit
token overload still refuses, allowance returns to zero. Baseline source/images,
all implementation stages and original raw probe remain retained.

## Validation

Release solution builds without warnings/errors. Initial broad native-hash/text/
bytes/ownership coverage passes667internal/2,640public per actual target. After
native shortcut correction, broad676internal/2,680public pass per target. Final
native-only shortcut refinement passes127internal/660public per target, including
native helper/formatting and deferred contexts. No result from an earlier variant
is silently presented as full qualification of the final image.

New regressions cover cold native requests without ambient state, separate caller
tokens on cached values, cancellation before native dictionary reads/writes,
unchanged destination/funding, and first admission refusal taking priority over
cancellation. Native str.__hash__/bytes.__hash__ run on a dedicated test worker
with admitted64MiB immutable inputs. Both tests observe the active call, cancel,
receive cancellation without a VM exit, and verify the scan did not publish its
completed cache. A fresh caller can finish/cache the same value. All users join
before cleanup; balances/depths recover and input funding lasts through the retry.
Chunk-boundary cases preserve the old whole-buffer hash values on both runtimes.

The substantial in-flight fixtures are isolated in the existing AllocationSensitive
collection, using existing10s watchdogs. No timeout or assertion is relaxed; no
checkpoint-count hooks are added. Compilation and other CLR/BCL operations retain
their documented cooperative/non-preemptible boundaries.

## Short affected-workload diagnostic

The existing isolated forwarding probe adds a direct native-hash diagnostic mode:
4MiB+3 immutable bytes, fresh str/bytes wrappers, active uncancelled caller token,
one-second warmup per kind, five32-call batches. Before/current/identical-before
processes use normal GC/tiering. Normalized hashes, unchanged input funding and
final zero balances pass. No input allocation, compile/startup or I/O is timed.
This is a native primitive diagnostic, not a whole-script/CPython comparison.

Observed allocation including minor process instrumentation is unchanged:75.25B
per string hash and67.25B per bytes hash in all three images. Windows elapsed
string0.387ms current vs0.402ms controls; bytes~0.389ms in all images. Coarse CPU
is0.488ms per hash throughout. Retain all raw observations; these desktop clocks
do not establish a CPU gain or quiet-machine performance parity.

Full platform/original Stress/installed-package qualification is batched with the
corrected R30–R32 default-storage fixture. Previous delivery42339537256 failed
that obsolete policy assertion after all ordinary/package gates passed; it does
not qualify R33. Publication remains postponed. Continue the representative
execution redesign roadmap after this bounded cancellation correction.
''',encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');old='Explicit dictionary queries carry their execution context into hashing and probing.';assert old in s;s=s.replace(old,old+'''
Native string/bytes hashing carries the current token through4096-byte scan chunks,
including public hash calls, native hash methods and dictionary fast paths. Only a
completed scan publishes its cached value; caches retain no caller token. Raw CLR
comparers remain context-free and do not dispatch guest callbacks.''');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/README.md');s=p.read_text(encoding='utf-8');old='The same checks refuse set-entry metadata before publication.';assert old in s;s=s.replace(old,'''[Native hash cancellation](Lokad.Lython.Tests/NativeHashCancellationTests.cs) interrupts
actual string/bytes scans before cache publication, keeps current caller tokens
independent, preserves refusal priority and awaits users before returning funding.
The same checks refuse set-entry metadata before publication.''');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','''## 0.11.0 - Unreleased

- Carry current cancellation through native string/bytes hashing, explicit hash
  methods and dictionary shortcuts. Reuse bounded byte-hash chunks, publish caches
  only after completion and preserve caller independence and first memory refusal.
''',1);p.write_text(s,encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''
## Current-token native hashing (2026-11-07)

[R33 correction](results/2026-11-07-native-hash-cancellation/README.md) removes
context-dropping native hash routing and reuses4096-byte scans for bytes. Actual
native-call interruption/cache/budget tests pass on both runtimes. Broad676internal/
2,680public precedes final shortcut refinement127internal/660public; exact sources
and images retained. One short native primitive comparison preserves allocations,
hashes and cleanup; desktop clocks establish no CPU gain. Full qualification batches
with the canonical-parameter stress-fixture correction; broader roadmap stays open.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('## Priority 1 — R33');b=s.index('## Priority 2 —',a)
s=s[:a]+'''## Priority 1 — close corrected R30–R33 delivery

R33 current-token native hashing implemented: contextual hash requests require the
active context; strings/bytes scan4096-byte chunks; native methods and dictionary
shortcuts forward current authority. Raw CLR comparers remain guest-free. No token
is retained by a cache, new policy/owner/counter/background work or new hash framework.

Focused actual11/10: broad676internal/2,680public, then final native-only refinement
127internal/660public. Two64MiB admitted native-call cancellation fixtures interrupt
without VM exit and preserve cache/ownership/retry behavior. First memory refusal,
protocol order, normalization and current-caller cache behavior pass. Native4MiB
hash diagnostic allocation flat; all values/funding/cleanup pass, no CPU claim.
Evidence2026-11-07-native-hash-cancellation; final images07a6530e/6c5dcc32.

Corrected original5000-definition default scenarios pass8cases per actual target:
20MiB success,6MiB denial, same-root compilation/result cleanup and reuse. Preserve
the terminal failed42339537256 history. Commit R33 and the fixture correction,
then run one corrected full platform/original Stress/installed-package delivery.
Keep all prior qualification separate; publication remains postponed. Once launched,
continue Priority2 source/design work while CI runs, with spaced status queries.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('R33 correction, exact stages and validation recorded.',flush=True)
