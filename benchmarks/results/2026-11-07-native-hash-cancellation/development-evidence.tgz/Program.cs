using Lokad.Lython;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using System.Text.Json;
using System.Security.Cryptography;
using System.Diagnostics;

if (args.Length != 0 && args[0] == "measure") { Measure(); return; }

using var cancellation = new CancellationTokenSource();
var budget = new LythonMemoryBudget(1024 * 1024);
using var scope = budget.CreateScope();
var context = new LythonRuntime.ExecutionContext(new EmptyHost(),
    new LythonRunOptions { CancellationToken = cancellation.Token, MemoryBudget = scope });
var span = new LythonSourceSpan(1, 1, 1, 5);
var first = PyString.FromString("first", context.MemoryGovernor, span);
var second = PyString.FromString("second", context.MemoryGovernor, span);
var explicitToken = PyString.FromString("third", context.MemoryGovernor, span);
cancellation.Cancel();
bool syncReturned = false, asyncReturned = false, explicitTokenRefused = false;
try { _ = PyHashProtocols.PrepareKeyHash(first, context, span); syncReturned = true; }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { }
try { _ = await PyHashProtocols.PrepareKeyHashAsync(second, context, span); asyncReturned = true; }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { }
try { _ = explicitToken.GetHashCode(cancellation.Token, span); }
catch (LythonRuntimeException error) when (error.Attribution?.Reason == LythonFailureReason.Cancelled) { explicitTokenRefused = true; }
context.State.CloseResources();
scope.Dispose();
Console.WriteLine(JsonSerializer.Serialize(new { syncReturned, asyncReturned, explicitTokenRefused,
    tokenCancelled = cancellation.IsCancellationRequested, finalBudgetBytes = budget.ReservedBytes,
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))) }));

static void Measure()
{
    const int length = 4 * 1024 * 1024 + 3;
    const int jobs = 32;
    var budget = new LythonMemoryBudget(16 * 1024 * 1024);
    using var owner = budget.CreateScope();
    using var token = new CancellationTokenSource();
    var context = new LythonRuntime.ExecutionContext(new EmptyHost(),
        new LythonRunOptions { MemoryBudget = owner, CancellationToken = token.Token });
    var span = new LythonSourceSpan(1, 1, 1, 5);
    // One immutable diagnostic input and headroom for short-lived wrapper values.
    // No value or borrower survives disposal; no payload is allocated in the clock.
    using var storage = context.MemoryGovernor.ReserveTemporary(length + 65536L, span);
    var input = new byte[length];
    for (var i = 0; i < input.Length; i++) input[i] = (byte)('a' + i % 26);
    var expected = new HashCode(); expected.AddBytes(input);
    var normalized = expected.ToHashCode(); if (normalized == -1) normalized = -2;
    var baseline = budget.ReservedBytes;
    var rows = new List<object>();
    foreach (var binary in new[] { false, true })
    {
        var warm = Stopwatch.StartNew();
        do { Once(); } while (warm.Elapsed < TimeSpan.FromSeconds(1));
        for (var round = 0; round < 5; round++)
        {
            var allocated = GC.GetTotalAllocatedBytes(true);
            var cpu = Process.GetCurrentProcess().TotalProcessorTime;
            var clock = Stopwatch.StartNew();
            for (var i = 0; i < jobs; i++) Once();
            clock.Stop();
            var cpuMilliseconds = (Process.GetCurrentProcess().TotalProcessorTime - cpu).TotalMilliseconds;
            rows.Add(new { kind = binary ? "bytes" : "str", round, jobs,
                elapsedMilliseconds = clock.Elapsed.TotalMilliseconds, cpuMilliseconds,
                allocatedBytes = GC.GetTotalAllocatedBytes(true) - allocated });
        }
        void Once()
        {
            object value = binary ? new PyBytes(input) : PyString.FromOwnedUtf8(input);
            var hash = PyHashProtocols.GetProtocolHash(value, context, span);
            if (hash != normalized) throw new InvalidDataException("Native hash changed its normalized value.");
        }
    }
    if (budget.ReservedBytes != baseline || context.MemoryGovernor.CurrentReservedBytes != length + 65536L)
        throw new InvalidDataException("Hash operation changed the borrowed input funding.");
    context.State.CloseResources(); storage.Dispose(); owner.Dispose();
    if (budget.ReservedBytes != 0) throw new InvalidDataException("Owner cleanup did not return the allowance.");
    Console.WriteLine(JsonSerializer.Serialize(new { length, rows, finalBudgetBytes = budget.ReservedBytes,
        coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
        runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
        purpose = "Native cold str/bytes hash diagnostic only. Existing caller token active; 4MiB shared immutable input, fresh wrappers; no compile/startup/I/O. Desktop clocks diagnostic; no CPU/performance qualification." }));
}

sealed class EmptyHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
