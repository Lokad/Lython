from pathlib import Path
root=Path('.git/agent-notes/review-20261031/cold-string-hash-r33')
s=(root.parent/'canonical-parameter-prefix-r32/focused.py').read_text(encoding='utf-8');a=s.index('families=[');b=s.index('\nselection=',a)
s=s[:a]+"families=['Hash','NativeByteCancellation','NativeHashCancellation','String','Bytes','Dictionary','SharedMemory','GovernedMemory','Cancellation']"+s[b:]
s=s.replace("'build-corrected.log'","'build-initial.log'")
(root/'focused.py').write_text(s,encoding='utf-8',newline='\n')
