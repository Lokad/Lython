from pathlib import Path
root=Path('.git/agent-notes/review-20261031/cold-string-hash-r33')
for p in list(root.glob('focused-initial-*.log'))+[root/'focused-initial.json',root/'build-initial.log']:
 if p.exists():p.rename(p.with_name(p.stem+'-generic-native-queries'+p.suffix))
p=root/'focused.py';s=p.read_text(encoding='utf-8');a=s.index('families=[');b=s.index('\nselection=',a)
s=s[:a]+"families=['NativeHashCancellation','HashQuery','NativeReturn','NativeHelper','CompletedHelper','CanonicalFormatted','NestedHash','NumericHash','BuiltinByteHash','ManagedHash','Dictionary','ContextualHash','Deferred']"+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
