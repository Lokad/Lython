from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,tarfile
root=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (root/'build-diagnostic.log').open('w',encoding='utf-8') as output:
 p=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(root/'probe.csproj'),'-c','Release','--nologo','--tl:off'],env=env,stdout=output,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/'build-diagnostic.log').read_text(encoding='utf-8')[-3000:]
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'));candidate=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');assert sha(candidate)==checks['coreSHA256']['net11.0']
base=root/'diagnostic-images';base.mkdir()
with tarfile.open(root/'baseline-source-and-images.tgz') as a:before=a.extractfile('checked-images/net11.0/Lokad.Lython.dll').read()
oldsha=json.loads((root/'baseline.json').read_text(encoding='utf-8'))['coreSHA256']['net11.0'];assert hashlib.sha256(before).hexdigest()==oldsha
identity=dict(before=oldsha,candidate=sha(candidate));results={}
for role in ['before','candidate','before-control']:
 folder=base/role;folder.mkdir()
 for source in (root/'bin/Release/net11.0').iterdir():
  if source.is_file() and source.suffix!='.pdb':shutil.copyfile(source,folder/source.name)
 (folder/'Lokad.Lython.dll').write_bytes(candidate.read_bytes() if role=='candidate' else before)
 expected=identity['candidate' if role=='candidate' else 'before'];assert sha(folder/'Lokad.Lython.dll')==expected
 p=subprocess.run([env['DOTNET_HOST_PATH'],str(folder/'Lokad.Lython.WhiteBox.Tests.dll'),'measure'],env=env,text=True,encoding='utf-8',capture_output=True)
 (root/('measure-'+role+'.json')).write_text(p.stdout,encoding='utf-8',newline='\n');(root/('measure-'+role+'.stderr')).write_text(p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stderr
 results[role]=json.loads(p.stdout);assert results[role]['coreSHA256'].lower()==expected and results[role]['finalBudgetBytes']==0
 print(role,'hash values/funding/cleanup pass',flush=True)
summary=[]
for kind in ['str','bytes']:
 row=dict(kind=kind)
 for role,result in results.items():
  samples=[r for r in result['rows'] if r['kind']==kind]
  row[role]=dict(allocatedBytesPerHash=statistics.median(r['allocatedBytes']/r['jobs'] for r in samples),desktopMillisecondsPerHash=statistics.median(r['elapsedMilliseconds']/r['jobs'] for r in samples),desktopCpuMillisecondsPerHash=statistics.median(r['cpuMilliseconds']/r['jobs'] for r in samples))
 summary.append(row);print(row,flush=True)
(root/'hash-diagnostic-summary.json').write_text(json.dumps(dict(identity=identity,rows=summary,performanceQualified=False,limitations='Sequential Windows processes with normal GC/tiering and one-second native warmup per type. Allocations include minor process instrumentation; clocks are diagnostic, not quiet-machine CPU or complete-script proof.'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=subprocess.run([env['DOTNET_HOST_PATH'],str(base/'candidate/Lokad.Lython.WhiteBox.Tests.dll')],env=env,text=True,encoding='utf-8',capture_output=True);assert p.returncode==0,p.stderr
(root/'probe-after.json').write_text(p.stdout,encoding='utf-8',newline='\n');proof=json.loads(p.stdout);assert not proof['syncReturned'] and not proof['asyncReturned'] and proof['explicitTokenRefused'] and proof['finalBudgetBytes']==0
print('Original forwarding probe now refuses both preparation paths and returns budget0.',flush=True)
