from pathlib import Path
import re
root=Path('src/Lokad.Lython/Runtime')
p=root/'LythonRuntime.Builtins.cs';s=p.read_text(encoding='utf-8')
s=s.replace('ComputeBuiltinHash(object value, LythonSourceSpan span)','ComputeBuiltinHash(object value, LythonSourceSpan span, ExecutionContext context)').replace('ComputeStructuralHashCode(value, span));','ComputeStructuralHashCode(value, span, context));')
s=s.replace('ComputeStructuralHashCode(object value, LythonSourceSpan? span)','ComputeStructuralHashCode(object value, LythonSourceSpan? span, ExecutionContext context)')
s=s.replace('        try { return PyValueComparer.Instance.GetHashCode(value); }','''        context.CheckExecution(span);
        try
        {
            // Native buffers need the current caller through the actual scan.
            // The CLR comparer stays context-free and never dispatches guests.
            if (value is PyString text)
                return PyValueComparer.NormalizeHash(text.GetHashCode(context.State.CancellationToken, span));
            if (value is PyBytes bytes)
                return PyValueComparer.NormalizeHash(bytes.GetHashCode(context.State.CancellationToken, span));
            return PyValueComparer.Instance.GetHashCode(value);
        }''');p.write_text(s,encoding='utf-8',newline='\n')
for name in ['PyHashProtocols.cs','PyHashProtocols.Async.cs']:
 p=root/name;s=p.read_text(encoding='utf-8').replace('ComputeStructuralHashCode(key, span)','ComputeStructuralHashCode(key, span, context)').replace('ComputeStructuralHashCode(instance, span)','ComputeStructuralHashCode(instance, span, context)');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'PyBytes.cs';s=p.read_text(encoding='utf-8');a=s.index('    public int GetPyHashCode()\n');b=s.index('\n    public PyString RenderInterpolated',a)
s=s[:a]+'''    public int GetPyHashCode() => GetHashCode(default, null);

    internal int GetHashCode(CancellationToken token, LythonSourceSpan? span)
    {
        if (Volatile.Read(ref _hashCodeComputed)) return _hashCode;
        // HashCode's streaming state preserves the whole-buffer result. Only
        // completed scans publish a cache; caller cancellation is never retained.
        var computed = PyString.HashUtf8(_bytes, span: span, cancellationToken: token);
        _hashCode = computed;
        Volatile.Write(ref _hashCodeComputed, true);
        return computed;
    }
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
for name in ['LythonRuntime.StringMembers.cs','LythonRuntime.BytesMembers.cs','LythonRuntime.Members.cs','LythonRuntime.PathMembers.cs']:
 p=root/name;s=p.read_text(encoding='utf-8');matches=list(re.finditer(r'ComputeBuiltinHash\(([^,]+), span\)',s))
 for m in reversed(matches):
  marker='BoundCallable.Create((arguments, span, _)';a=s.rfind(marker,0,m.start());assert a>=0 and s.count('BoundCallable.Create',a,m.start())==1,(name,m.group())
  s=s[:m.start()]+f'ComputeBuiltinHash({m[1]}, span, context)'+s[m.end():]
  s=s[:a]+s[a:].replace(marker,'BoundCallable.Create((arguments, span, context)',1)
 p.write_text(s,encoding='utf-8',newline='\n')
p=root/'LythonRuntime.UrllibParseModule.Cache.cs';s=p.read_text(encoding='utf-8').replace('ComputeBuiltinHash(value, span)','ComputeBuiltinHash(value, span, context)');p.write_text(s,encoding='utf-8',newline='\n')
print('Active context reaches native hash scans; bytes reuses existing chunked hash.',flush=True)
