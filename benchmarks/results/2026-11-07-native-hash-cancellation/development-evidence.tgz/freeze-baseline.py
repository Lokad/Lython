from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('.git/agent-notes/review-20261031/cold-string-hash-r33');
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[Path('src/Lokad.Lython/Runtime')/n for n in ['LythonRuntime.Builtins.cs','PyBytes.cs','PyHashProtocols.cs','PyHashProtocols.Async.cs','LythonRuntime.StringMembers.cs','LythonRuntime.BytesMembers.cs','LythonRuntime.Members.cs','LythonRuntime.PathMembers.cs','LythonRuntime.UrllibParseModule.Cache.cs']]
(root/'baseline.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={str(p).replace('\\','/'):sha(p) for p in files},coreSHA256={f:sha(Path(f'src/Lokad.Lython/bin/Release/{f}/Lokad.Lython.dll')) for f in ['net11.0','net10.0']}),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(root/'baseline-source-and-images.tgz','w:gz') as a:
 for p in files:a.add(p,arcname=p)
 for framework in ['net11.0','net10.0']:a.add(Path(f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll'),arcname=f'checked-images/{framework}/Lokad.Lython.dll')
shutil.copyfile('PLAN.md',root/'pre-implementation-plan.md')
(root/'contract.md').write_text('''R33 bounded correction. Require the active context through runtime structural/
builtin hashes and native hash members, preserving context-free CLR comparers.
Native str/bytes scans use the existing current-token/chunked UTF8 byte hash;
bytes replaces its whole-buffer AddBytes call with the identical streaming hash
at4096-byte boundaries. Preserve normalized equality/bucket hashes, protocol/
compound ordering, cache caller independence, first memory refusal and cleanup.
No token captured by cached values. No new owner, public option, hash framework,
watchdog, work counter or background abandonment. Tests need native in-flight
interruption rather than VM exit checks, cancelled cold retries/cache behavior,
current caller priority and eventual shared funding reuse. A short affected hash
comparison separates correctness/allocations/diagnostic clocks; no CPU forecast.
Full R30–R32 CI remains independent; batch full correction qualification later.
''',encoding='utf-8',newline='\n')
print('Frozen R33 baseline/contract before implementation.',flush=True)
