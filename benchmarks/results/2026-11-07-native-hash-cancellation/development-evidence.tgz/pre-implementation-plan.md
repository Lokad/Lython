# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
Completing a local experiment does not complete that objective.

## Delivery status

- **Fully qualified:** R29 `81036f25`, terminal GREEN42333421800/all eight Windows/
  Ubuntu, actual.NET11/10, original Stress and installed-package gates. Includes
  R26's correctness fix; earlier R25/R23/R22 qualification remains recorded. Cached
  terminal receipts are authoritative: no unchanged reruns or status queries.
- **Committed; focused-qualified, full delivery pending:** R30 `49d40b00` removes
  runtime class-cell syntax analysis; R31 `bf279768` shares prepared parameter
  tables across executable/lowered/lambda/generator function objects. Current
  frozen R31 images33384376/9a043078 pass1,080internal/4,616public per actual target,
  plus independent Python probes and complete allocation/ownership diagnostics.
- **Independent regex compatibility complete:** exact immutabledev48/sourcef6b2175e
  passes85internal/488public per actual target in isolation. Normal adapter remains
  nonpackable/pinned0.4. Core has no backend dependency. Not producer CPU/safety/
  release certification. Evidence2026-11-07-regex-dev48-compatibility.
- **Committed, focused-qualified; full delivery pending:** R32 `42643b1b` canonical parameter prefix
  removes Builder's duplicate ordering, images77bb12cc/0f9553f9.406internal/1,962public
  per actual target and independent generator probes pass; compile−32B/ordinary
  definition, empty generator+152B; warm flat. No measured R32 CPU claim.
- **Active:** R30–R32 delivery42339537256 requested for42643b1b, full original
  platform/Stress/installed-package qualification; identity/conclusion not fetched,
  R33 current-token hash correction/representative execution design continue. No objective closure.
- **Withdrawn:** R28 owned split-result windows and mask variant; both runtime
  implementations removed, independent Unicode regressions retained. Allocation
  −6.94% did not establish text CPU benefit; report remained adverse. All evidence
  and initial overcharge/assertion failures survive in immutable history.

## Measurement decisions

| Work | Established / decision | Remaining uncertainty |
| --- | --- | --- |
| Shared compiler facts | Correct shared inferred-value traversal, avoiding exponential work; qualified | Not a warm-execution claim; preserve callback correction too. |
| Native helper returns | Qualified; allocation−19.92/−19.31% | Earlier elapsed gains remain diagnostic, not CPU claims transferable to HEAD. |
| Direct UTF-8 formatting/storage | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms remains unexplained and preserved. No further correction currently justified. |
| R20/R25 records | Shared keys/final CSV row transfer delivered and qualified | Earlier6–8% bulk CSV rejection was reconsidered through a coherent storage transfer; old controls/adverse data remain. |
| R29 completed calls | Pending-call/completion phase removed; qualified; text warm−4.25–7.61%sync/−7.63–8.64%async vs R26 | Report/CSV uncertainty remains; no broad CPU or compounded debt-repayment claim. |
| R30 prepared class facts | Warm class allocation−7.75%; quiet warm−5.83–6.31%, fresh−3.65–5.33%; retain | Compile+1,048B/+0.70–1.30% elapsed. Desktop text adverse not reproduced; cause unresolved. |
| R31 shared parameter layout | Class allocation−10.65%warm/−7.35%fresh; quiet warm−4.33–7.01%, fresh−3.52–4.38%; retain | Compile+1,728B/+0.26–1.40% elapsed. Text/CSV current roles differ4.41/5.02%, adverse pairings up4.18/4.60% remain possible debt, not parity or demonstrated regression. |

R30/R31 affected class factory is synthetic, not a representative CPython refresh.
Their desktop adverse results, B381 fixture mismatch and B383 collector-count
failure survive; setup failures collected no timings. Corrected B382/B384 pass all
identity/golden/funding/quiet/Closed/join/fixture/archive gates. Both are terminal;
no live VM users and no more queries. Full history is in benchmarks/EXPERIMENTS.md
and results/2026-11-07-prepared-class-facts / prepared-call-layout.

B380 primary CPython checkpoint measures exact81036f25/frozen32dcf141, excluding
R30/R31. All15jobs/312s/gates pass. Compile-only44–72µs separate; warm text
1.71–1.75×, CSV1.22×, JSON1.05–1.06×, report1.38–1.42×. Text/report and most fresh
cases remain variable. Boundary includes mediated RAM I/O, complete checks and
prior-result cleanup; excludes startup/staging/reset/final teardown. No subtraction
of medians. docs/BENCHMARKS.md labels the measured source, not today's HEAD.
Refresh after a meaningful whole-script runtime milestone, not merely a new date.
Startup, genuinely suspended I/O latency, heap/RSS and embedding tails remain open.

## Delivery gate — canonical parameter metadata (R30–R32)

Implementation complete: R31's immutable tables are shared across created functions;
R32 also deletes Builder's two-pass kind ordering/raw-list field. Per-function mutable
default/name/closure storage and native generated admission/rollback remain private.
One canonical order, no new binder/cache/owner. Focused numbers above; full original
Windows/Ubuntu, actual11/10 ordinary/Stress/package gates run once as42339537256.
Actual head42643b1b verified04:48:18Z; both builds pass, ordinary.NET11 tests running,
later gates pending. Local installed Release consumers pass both targets, source/
logs in2026-11-07-canonical-parameter-prefix. Next CI query after04:53:18Z; do not
repeat earlier terminal green runs. Keep code qualification separate from new work.

## Priority 1 — R33 current-token native hashing

**Demonstrated/source:** a cold native-string synchronous PrepareKeyHash returns
under an already cancelled active token; explicit token overload refuses. Async
entry refuses, but source still reaches a default-token scan. This probe does not
prove public in-flight behavior. HashUtf8 already has4096-byte chunks; actual
forwarding is missing. Bytes uses a whole BCL hash call; explicit native hash members
discard context. Evidence2026-11-07-native-hash-cancellation-gate.

**Correction/removal:** carry current authority through actual native hash work,
reusing token-aware strings/chunking; assess bytes within this same bounded path.
Remove context-dropping routing; keep context-free CLR comparers safe. No new hash
framework, policy, counter, background work or ownership infrastructure.

**Acceptance/tradeoffs:** public hash, dictionary/set and compound keys, explicit
native hash methods; normalization/equality, cached values with independent callers,
protocol order, cycles/depth, terminal refusal and cleanup/budget reuse. Establish
cancellation during real scanning, not just entry/exit. Focused Release checks and
one short affected-workload diagnostic; no CPU forecast or broad memory audit.
Finish when current tokens reach scans and regression coverage demonstrates it;
retain BCL/non-preemptible limitations honestly. Batch full qualification later.

## Priority 2 — substantial complete-script execution redesign

Use representative text/CSV/JSON/report/config/file scripts, including compile-once,
run-once inside a warm host. R31's synthetic result does not establish progress on
all of these. Reassess accepted text/CSV/report debt at this next coherent boundary.

| Area | Source/cost gate and work to eliminate | Semantic acceptance / affected scripts |
| --- | --- | --- |
| Complete call/frame construction | Build on direct operands/native calls/deferred contexts. Select a demonstrated removable binding/context/continuation phase and delete its old driver/transport; no new caller arena. | Helpers, constructors, true host suspension; defaults/keywords, closures, call order, spans, stack admission, cancellation and funded borrows. |
| Operand/scalar transport | Assess boxed counters together with reads/publication/retirement; require a hot removable phase before a representation change. Existing single local/operand backing already delivered. | CSV/text counters; exact promotion, identity/aliases/hash/projection and major storage funding. Small-add~3% CPU alone does not justify universal tagged values. |
| Per-record construction | R20/R25 already remove intermediates; select another actual capacity/copy phase, not an added cache. | CSV/JSON/report; mutable/duplicate/custom headers, short/rest rows, independent values, admission reentry, Clear capacity/overlap. |
| Text/storage boundaries | Bulk casing/split/file windows already direct. Find a final-representation conversion to remove rather than revive universal windows. | Unicode expansion/context, scalar/byte offsets, hash/index/repr, aliases and cancellation. Split already admits aggregate output; fragment Commit is local, not a host lock per word. |
| Frontend/setup | R30–R32 consolidate genuine repeated facts; target another proved redundant pass/retained representation. | Fresh helpers/comprehensions/config; diagnostics, shared-graph correctness, scoping, cancellation/admission; compilation separate from warm. |

**Selection/stop:** reuse existing B377/current allocation evidence first. One bounded
current representative cost gate may resolve a specific missing fact; enough warmup/
samples for usable observations, retaining unknowns. Select one coherent deletion,
state removed work/storage, affected scripts and completion milestone before coding.
If no phase is justified, record the missing evidence and move to another boundary;
no speculative broad rewrite or permanent rejection from an inconclusive profile.

Each retained redesign gets focused semantics/cancellation/ownership and a bounded
before/after complete-script comparison with unchanged controls. Keep source/image,
I/O/cleanup boundary and adverse results. Decide simplification, allocation and CPU
separately. Allow bounded confirmation/refinement or measurement correction when
controls/timeouts justify it; do not automatically repeat until favorable. Fixed
percentages inform, not veto. Temporary regression debt needs an explicit decision
at completion. Preserve slower call-control/call-arena lessons, not their machinery.

Source check: captured-header cloning serves yielding definition headers, not
ordinary helper construction. Do not target it as representative overhead without
an affected workload. Sync/async annotation effect-order probes match Python.
Destination publication already skips its adjacent store; deleting metadata alone
removes no normal dispatch and must preserve awaited disposal/GC-lifetime fences.

## Independent regex track

Continue core Python semantics/native UTF-8, byte ranges, scalar original-subject
windows, captures/replacements/errors/cache ownership and current cancellation.
U04/R23 completed; do not repeat unchanged qualification. Development producers
and adapter-local bridges support correctness and independent development.

Only affected final adapter qualification waits: DetailedData lacks independent
Prepare working ownership; native names lack enumeration; cursors mix creation/
current token authority. Exactdev48 adds no documented API removing those limits.
Keep conservative preflight, local conversion and qualified CTS bridge where needed.
Qualify released immutable inputs/managed safety separately; no silent promotion,
sibling edits, dialect fallback, private regex quota or abandoned matching.

## Delivery and constraints

Follow AGENTS.md: fully managed/memory-safe, no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, cancellation, host-mediated contained
paths, cycles, coarse shared admission/preflights, retained aliases and actual-user
cleanup. First memory refusal is terminal. No tracing, weak reclamation, forced GC,
fuel/quotas, hidden caps/default allowance. Bounded host-driven streaming; XML depth
constraint remains. Keep current guides concise; historical work belongs outside docs.

Focused Release iteration; no overlapping local builds/tests. Full platform/Stress/
package checks at coherent delivery boundaries, not each local change. Preserve
timeouts, original stress scales and GC-test nonparallel collection. No repeated
queries of terminal green CI. No publication/tagging.

Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: existing owned lease,
Ready/goldens/funding/quiet/Closed/joins and verified persistent archives. Record
owner+stop+margin before observation; never restart on an observation timeout.
Disk nearly full: retire only exact redundant expanded copies after independent
committed backup and current hash/user/link checks; keep all original evidence.

Delivery dispatch recorded 2026-11-07T04:41:55.927494+00:00; next CI observation after 2026-11-07T04:46:55.927494+00:00.
Do not repeat old terminal receipts. Publication/tagging remain postponed.

Next safe checkpoint: tracked runtime clean at42643b1b; R33 source gate only, not
implemented or qualified. Continue correction, then substantial Priority2 roadmap.
CI last checked04:48:18Z; next after04:53:18Z. No live VM work.
