from pathlib import Path
root=Path('.git/agent-notes/review-20261031/cold-string-hash-r33');p=root/'Program.cs';s=p.read_text(encoding='utf-8');(root/'Program.baseline.txt').write_text(s,encoding='utf-8',newline='\n')
s=s.replace('using System.Security.Cryptography;','using System.Security.Cryptography;\nusing System.Diagnostics;')
s=s.replace('using var cancellation = new CancellationTokenSource();','if (args.Length != 0 && args[0] == "measure") { Measure(); return; }\n\nusing var cancellation = new CancellationTokenSource();',1)
a=s.index('\nsealed class EmptyHost')
method='''
static void Measure()
{
    const int length = 4 * 1024 * 1024 + 3;
    const int jobs = 32;
    var budget = new LythonMemoryBudget(16 * 1024 * 1024);
    using var owner = budget.CreateScope();
    using var token = new CancellationTokenSource();
    var context = new LythonRuntime.ExecutionContext(new EmptyHost(),
        new LythonRunOptions { MemoryBudget = owner, CancellationToken = token.Token });
    var span = new LythonSourceSpan(1, 1, 1, 5);
    // One immutable diagnostic input and headroom for short-lived wrapper values.
    // No value or borrower survives disposal; no payload is allocated in the clock.
    using var storage = context.MemoryGovernor.ReserveTemporary(length + 65536L, span);
    var input = new byte[length];
    for (var i = 0; i < input.Length; i++) input[i] = (byte)('a' + i % 26);
    var expected = new HashCode(); expected.AddBytes(input);
    var normalized = expected.ToHashCode(); if (normalized == -1) normalized = -2;
    var baseline = budget.ReservedBytes;
    var rows = new List<object>();
    foreach (var binary in new[] { false, true })
    {
        var warm = Stopwatch.StartNew();
        do { Once(); } while (warm.Elapsed < TimeSpan.FromSeconds(1));
        for (var round = 0; round < 5; round++)
        {
            var allocated = GC.GetTotalAllocatedBytes(true);
            var cpu = Process.GetCurrentProcess().TotalProcessorTime;
            var clock = Stopwatch.StartNew();
            for (var i = 0; i < jobs; i++) Once();
            clock.Stop();
            var cpuMilliseconds = (Process.GetCurrentProcess().TotalProcessorTime - cpu).TotalMilliseconds;
            rows.Add(new { kind = binary ? "bytes" : "str", round, jobs,
                elapsedMilliseconds = clock.Elapsed.TotalMilliseconds, cpuMilliseconds,
                allocatedBytes = GC.GetTotalAllocatedBytes(true) - allocated });
        }
        void Once()
        {
            object value = binary ? new PyBytes(input) : PyString.FromOwnedUtf8(input);
            var hash = PyHashProtocols.GetProtocolHash(value, context, span);
            if (hash != normalized) throw new InvalidDataException("Native hash changed its normalized value.");
        }
    }
    if (budget.ReservedBytes != baseline || context.MemoryGovernor.CurrentReservedBytes != length + 65536L)
        throw new InvalidDataException("Hash operation changed the borrowed input funding.");
    context.State.CloseResources(); storage.Dispose(); owner.Dispose();
    if (budget.ReservedBytes != 0) throw new InvalidDataException("Owner cleanup did not return the allowance.");
    Console.WriteLine(JsonSerializer.Serialize(new { length, rows, finalBudgetBytes = budget.ReservedBytes,
        coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
        runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
        purpose = "Native cold str/bytes hash diagnostic only. Existing caller token active; 4MiB shared immutable input, fresh wrappers; no compile/startup/I/O. Desktop clocks diagnostic; no CPU/performance qualification." }));
}
'''
p.write_text(s[:a]+method+s[a:],encoding='utf-8',newline='\n')
print('Extended existing forwarding probe with one short native-hash diagnostic mode.',flush=True)
