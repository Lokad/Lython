from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
template=lab.with_name('current-default-call-cpu-20261124')
source=lab.with_name('shared-locals-cpython-20261125')
external=source/'external'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
ident=read(external/'identity.json')
receipt=read(external/'terminal-status.json')['receipt']
assert ident['sourceRevision'].startswith('788be8f35') and {p.name:sha(p) for p in (source/'candidate').iterdir()}==ident['imageFiles']['candidate']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(external/'observations.tar.xz')==receipt['archiveSHA256']
ident.update(profiles=[('shipment-warm','diagnostic.shipment-routing-callbacks','candidate'),
    ('defaulted-through','scripts.rule-default-closures','candidate')],
    purpose='Attribute CPU on the two largest measured warm gaps using the production CPython checkpoint image',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(external/'representative.json'))
save(lab/'identity.json',ident)
for src,dst in ((external/'representative.json','catalog.json'),(external/'candidate-verify.json','candidate-verification.json'),
                (template/'run.sh','run.sh')):
    shutil.copyfile(src,lab/dst)
assert b'\r' not in (lab/'run.sh').read_bytes()
records=[]
for stage,path in (('shared-locals-cpython-b1663-20261125',external),
    ('inline-default-confirmation-b1655-20261124',lab.with_name('inline-positional-default-20261124')/'confirmation'),
    ('single-pass-operand-layout-b1651-20261124',lab.with_name('single-pass-operand-layout-20261124')/'comparison/quiet'),
    ('single-pass-operand-layout-refined-b1652-20261124',lab.with_name('single-pass-operand-layout-20261124')/'refinement/comparison/quiet'),
    ('shared-match-bindings-b1648-20261124',lab.with_name('shared-match-bindings-20261124')/'comparison/quiet'),
    ('shared-function-definition-descriptor-b1647-20261124',lab.with_name('shared-function-definition-descriptor-20261124')/'comparison/quiet'),
    ('raw-expression-retirement-b1640-20261124',lab.with_name('raw-expression-retirement-20261124')/'comparison/quiet')):
    if not (path/'terminal-status.json').is_file():continue
    r=read(path/'terminal-status.json')['receipt']
    assert r['allWorkersJoined'] and r['archivedAndVerifiedUnderLease'] and sha(path/'observations.tar.xz')==r['archiveSHA256']
    with tarfile.open(path/'observations.tar.xz') as full:
        raw=full.extractfile('confirmation/confirmation.json').read()
    records.append(dict(location=stage,bytes=len(raw),archiveSHA256=r['archiveSHA256'],rawSHA256=hashlib.sha256(raw).hexdigest()))
save(lab/'verified-raw-replicas.json',records)
launcher=(template/'quiet.py').read_text(encoding='utf-8').replace('current-default-call-cpu-b1657-20261124','shipment-and-defaulted-cpu-b1664-20261125')
launcher=launcher.replace('lython-b1657-current-default-call-cpu-20261124','lython-b1664-shipment-and-defaulted-cpu-20261125')
launcher=launcher.replace('inline-positional-default-20261124','shared-locals-cpython-20261125').replace('checked["caseCount"]==5','checked["caseCount"]==4')
launcher=launcher.replace('Staged three profiles','Staged two profiles')
collector=(template/'collect.py').read_text(encoding='utf-8').replace('inline-positional-default-b1655-20261124','shared-locals-cpython-b1663-20261125').replace('b1657-fixtures','b1664-fixtures')
archive=(template/'archive.py').read_text(encoding='utf-8').replace('2026-11-24-current-default-call-cpu','2026-11-25-shipment-and-defaulted-cpu').replace('6b41db7b3','788be8f35')
for name,s in (('quiet.py',launcher),('collect.py',collector),('archive.py',archive),
    ('analyze.py',(template/'analyze.py').read_text(encoding='utf-8')),('ops-profile.py',(template/'ops-profile.py').read_text(encoding='utf-8'))):
    compile(s,name,'exec')
    write(lab/name,s)
