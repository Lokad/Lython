from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib,json,os,subprocess,sys

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
remote='/home/lokad/lython-bench-checks'
unit='lython-b1780-json-default-decoder-20261126'
vm=os.environ['LYTHON_BENCH_HOST']
common=['-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12']
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
configuration.update(base=remote,unit=unit)
prefix='cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,tarfile,json,os,shutil,subprocess
base=Path(cfg['base'])
root=base/cfg['root']
unit=cfg['unit']
assert root.resolve()==root and root.parent==base and base.resolve()==base
archive=base/(cfg['root']+'.tar.gz')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
'''
invoke=lambda code:subprocess.check_output(['ssh',*common,vm,'python3 -'],input=prefix+code,encoding='utf-8',timeout=63)
scp=['scp',*common]
if sys.argv[1]=='launch':
    payload=quiet/'stage.tar.gz'
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration['payloadSHA256']
    before=json.loads(invoke('''
assert not root.exists() and not archive.exists()
bytes=shutil.disk_usage(base).free
assert bytes>cfg['payloadBytes']+cfg['expandedBytes']+5*1024*1024,bytes
print(json.dumps(dict(freeBeforeUploadBytes=bytes)))
'''))
    subprocess.run(scp+[payload,vm+':'+remote+'/'+configuration['root']+'.tar.gz'],check=True,timeout=90)
    staged=invoke('''
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and archive.resolve()==archive and sha(archive)==cfg['payloadSHA256']
 with tarfile.open(archive) as package:
  frames=package.getmembers()
  assert len(frames)==7 and len(set(f.name for f in frames))==7 and all(f.isfile() for f in frames)
  expanded=sum(f.size for f in frames)
  assert shutil.disk_usage(base).free>=expanded+4*1024*1024
  root.mkdir()
  package.extractall(root,filter='data')
 image=json.loads((root/'identity.json').read_text())
 donor=base/'ready-json-construction-b1776-20261126'/'candidate'
 assert donor.resolve()==donor and {p.name:sha(p) for p in donor.iterdir()}==image['imageFiles']['reference']
 donor_receipt=json.loads((donor.parent/'archive-receipt.json').read_text())
 assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')
 (root/'candidate').mkdir()
 for p in donor.iterdir():
  if p.name=='Lokad.Lython.dll': continue
  if p.name.startswith('Lokad.Lython.Benchmarks.'):
   shutil.copyfile(p,root/'candidate'/p.name)
  else:
   (root/'candidate'/p.name).symlink_to(p)
 (root/'new-core.dll').rename(root/'candidate'/'Lokad.Lython.dll')
 (root/'reference').symlink_to(donor,target_is_directory=True)
 for role,files in image['imageFiles'].items():
  assert len(files)==32 and {p.name:sha(p) for p in (root/role).iterdir()}==files
 for name,metadata in image['catalogs'].items(): assert sha(root/name)==metadata['sha256']
 assert sha(root/'cpython-worker.py')==image['cpythonWorkerSHA256']
 archive.unlink()
 sdk=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==image['expectedCPythonSHA256']
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll'
 verifier=root/'remote-verify.json'
 verification=subprocess.run([sdk/'dotnet',worker,'--compare','verify','--catalog',root/'representative.json',
  '--dotnet',sdk/'dotnet','--python',python,'--python-worker',root/'cpython-worker.py','--out',verifier],
  cwd=root,env=dict(os.environ,DOTNET_ROOT=str(sdk)),capture_output=True,text=True,timeout=36)
 print(verification.stdout,verification.stderr,flush=True)
 verification.check_returncode()
 verified=json.loads(verifier.read_text())
 assert verified['state']=='Completed' and verified['caseCount']==4
 assert verified['catalogSha256']==image['catalogs']['representative.json']['sha256']
 assert verified['launched']['library']['sha256'].lower()==image['coreSHA256']['candidate'].lower()
 print(json.dumps(dict(freeBeforeLaunchBytes=shutil.disk_usage(base).free,expandedBytes=expanded)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=285','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
''')
    (quiet/'launch.log').write_text(json.dumps(before)+'\n'+staged,encoding='utf-8')
    (quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=205)).isoformat(),encoding='utf-8')
    print(staged)
else:
    assert sys.argv[1]=='retrieve' and datetime.now(timezone.utc)>=datetime.fromisoformat((quiet/'observe-not-before').read_text(encoding='utf-8'))
    status=invoke('''
state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in state:
 print(json.dumps(dict(live=True,service=state)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps(dict(live=False,service=state,exitCode=code.read_text().strip() if code.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','38','--no-pager'],capture_output=True,text=True).stdout)))
''')
    result=json.loads(status)
    (quiet/f'status-{datetime.now(timezone.utc):%H%M%S}.json').write_text(status,encoding='utf-8')
    if not result['live']:
        (quiet/'terminal-status.json').write_text(status,encoding='utf-8')
        if result['receipt']:
            archive=quiet/'observations.tar.xz'
            subprocess.run(scp+[vm+':'+remote+'/'+configuration['root']+'/'+archive.name,archive],check=True,timeout=45)
            assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['receipt']['archiveSHA256']
    print(status)
