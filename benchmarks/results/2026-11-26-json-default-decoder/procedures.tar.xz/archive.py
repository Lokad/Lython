from pathlib import Path
from shutil import copyfile
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
target = lab.parents[3] / "benchmarks/results/2026-11-26-json-default-decoder"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(quiet / "terminal-status.json")
receipt = state["receipt"]
assert state["exitCode"] == "0" and not state["live"] and not state["fixtures"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter",
                                   "archivedAndVerifiedUnderLease"))
assert receipt["archiveSHA256"] == sha(quiet / "observations.tar.xz") and read(quiet / "summary.json")["timedBatches"] == 140
assert read(quiet / "identity.json")["sourcePatchSHA256"] == sha(lab / "candidate.patch")
with tarfile.open(quiet / "observations.tar.xz") as observations:
    for name in ("representative.json", "jobs.json", "identity.json"):
        assert hashlib.sha256(observations.extractfile(name).read()).hexdigest() == sha(quiet / name)
verification = read(quiet / "remote-verify.json")
identity = read(quiet / "identity.json")
assert verification["caseCount"] == 4 and verification["state"] == "Completed"
assert verification["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
assert verification["launched"]["library"]["sha256"].lower() == identity["coreSHA256"]["candidate"].lower()
target.mkdir(parents=True, exist_ok=True)
for name in ("identity.json", "terminal-status.json", "observations.tar.xz", "summary.json"):
    copyfile(quiet / name, target / name)
for name in ("candidate.patch", "allocation-summary.json"):
    copyfile(lab / name, target / name)
copyfile(lab / "routes/counts.json", target / "routes.json")
paths = [(lab, name) for name in (
    "archive.py", "prepare.py", "prepare.log", "prepare-quiet.py", "quiet.py", "compact-for-quiet.py",
    "summarize-quiet.py", "launch-console.log", "retrieve.log", "routes.py", "routes-console.log",
    "reference-verify.json", "candidate-verify.json", "reference-allocation.json", "candidate-allocation.json",
    "test-ubuntu.sh", "Lokad.Lython.Tests-win11.log", "Lokad.Lython.PublicApi.Tests-win11.log",
    "Lokad.Lython.Tests-delivery-ubuntu10.log", "Lokad.Lython.PublicApi.Tests-delivery-ubuntu10.log")]
paths.extend((lab, "routes/" + name) for name in ("diagnostic.patch", "build-core.log", "build-probe.log", "run.log"))
paths.extend((quiet, name) for name in ("launch.log", "upload.json", "storage-primary-only-preview.log",
                                       "storage-preview.log", "storage-compact.log", "remote-verify.json"))
with tarfile.open(target / "procedures.tar.xz", "w:xz") as archive:
    for folder, name in paths:
        archive.add(folder / name, arcname=name, recursive=False)
