from pathlib import Path
import base64
import csv
from io import StringIO
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = "d51891009"
candidate = "bf011b805"
worktree = repo / ".git/agent-worktrees/direct-positional-methods-20261121"
donor = lab.parent / "packed-annotations-in-creation"
prior = lab.parent / "direct-regex-group-copy"
source_owner = lab.parent / "observed-regex-coordinates/frozen/reference"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree, text=True).startswith(candidate)
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=worktree)
catalog = load(lab.parent / "native-only-method-lookup-20261121/representative.json")
by_id = {case["id"]:case for case in catalog["cases"]}
policy = by_id["scripts.csv-invoice.method-policy"]
ordinary = by_id["scripts.csv-invoice.large"]
fixture = json.loads(policy["fixtureJson"])
original = base64.b64decode(fixture["inputFiles"]["input.csv"], validate=True)
fields = list(csv.reader(StringIO(original.decode("utf-8"), newline="")))
quoted = StringIO(newline="")
csv.writer(quoted,quoting=csv.QUOTE_ALL,lineterminator="\n").writerows(fields)
new_file = quoted.getvalue().encode("utf-8")
assert list(csv.reader(StringIO(new_file.decode("utf-8"), newline=""))) == fields
assert len(fields) == 4097 and len(original) == 127031
fixture["inputFiles"]["input.csv"] = base64.b64encode(new_file).decode("ascii")
fixture_json=json.dumps(fixture,separators=(",",":"))
quote_control=dict(policy,id="scripts.csv-invoice.method-policy.quoted-control",fixtureJson=fixture_json,
    fixtureSha256=sha(fixture_json.encode("utf-8")))
catalog["cases"]=[policy,ordinary,quote_control]
save(lab/"fixture-shape.json",dict(dataRecords=len(fields)-1,originalBytes=len(original),quoteAllBytes=len(new_file)))
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "quiet/identity.json")["imageFiles"]["reference"]
reference = donor / "quiet-workers/reference"
assert len(identity) == 32 and {name: sha((reference / name).read_bytes()) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role, root in (("reference", repo), ("candidate", worktree)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = reference / name
        if name == core:
            origin = (lab.parent / "native-only-method-lookup-20261121/frozen/candidate" / name if role == "reference"
                      else root / "src/Lokad.Lython/bin/Release/net11.0" / name)
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha((image / name).read_bytes()) for name in identity}
    for path in source_owner.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 3 and proof["catalogSha256"] == sha(manifest.read_bytes())
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha((image / name).read_bytes()) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=baseline, candidate=candidate,
     catalogSHA256=sha(manifest.read_bytes()), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1])
save(lab / "allocation-summary.json", result)
