set -eu
lab="$1"
local_run="$lab/local"
target=$(mktemp -d "$HOME/lython-nested-json-layouts-XXXXXX")
for item in reference candidate representative.json identity.json jobs.json cpython-worker.py run.sh collect.py; do
    cp -r "$local_run/$item" "$target/$item"
done
python3 - "$target" <<'PY'
from hashlib import sha256
import json, sys
from pathlib import Path
root = Path(sys.argv[1])
identity = json.loads((root/'identity.json').read_text(encoding='utf-8'))
for role, manifest in identity['imageFiles'].items():
    observed = {path.name: sha256(path.read_bytes()).hexdigest() for path in (root/role).iterdir()}
    assert observed == manifest, role
assert b'\r' not in (root/'run.sh').read_bytes()
PY
printf '%s\n' "$target"
cpu=$(python3 -c 'import os; print(max(os.sched_getaffinity(0)))')
printf '%s\n' "$cpu" > "$target/affinity.txt"
taskset --cpu-list "$cpu" sh "$target/run.sh"
