from pathlib import Path
from hashlib import sha256
from base64 import b64decode, b64encode
import json,sys
lab=Path(sys.argv[1])
pinned=lab.with_name('converted-entry-20261127')/'local'
earlier=lab.with_name('fixed-initial-list-20261127')/'local'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(name,value):
    (lab/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def digest(s):return sha256(s.encode('utf-8')).hexdigest()
def compact(o):return json.dumps(o,ensure_ascii=False,separators=(',',':'))
orig=read(pinned/'representative.json')
document=next(row for row in orig['cases'] if row['id']=='diagnostic.json-service-quantity-totals')
csv=next(row for row in orig['cases'] if row['id']=='diagnostic.shipment-file-fed-map')
flat=next(row for row in read(earlier/'representative.json')['cases'] if row['id']=='scripts.json-summary-helpers.large')
def variant(row,label,name,values,script):
    fixture=read_fixture(row)
    assert set(fixture['inputFiles'])=={name}
    fixture['inputFiles'][name]=b64encode(values.encode('utf-8')).decode('ascii')
    packed=compact(fixture)
    return row|dict(id=label,source=script,fixtureJson=packed,sourceSha256=digest(script),
                    sourceUtf8Bytes=len(script.encode('utf-8')),fixtureSha256=digest(packed))
def read_fixture(row):return json.loads(row['fixtureJson'])
def content(row,name):return b64decode(read_fixture(row)['inputFiles'][name]).decode('utf-8')
source_doc=content(document,'shipments.json')
rows=json.loads(source_doc)
nested_doc=compact([{'service':item['service'],'details':{'quantity':item['quantity']}} for item in rows])
needle="        totals[service] = totals.get(service, 0) + int(row['quantity'])"
assert document['source'].count(needle)==1
doc_script=document['source'].replace(needle,"        details = row['details']\n        totals[service] = totals.get(service, 0) + int(details['quantity'])")
source_lines=content(flat,'input.jsonl')
count=0
built=[]
for raw in source_lines.splitlines(keepends=True):
    if not raw.strip():
        built.append(raw)
        continue
    record=json.loads(raw)
    assert set(record)=={'amount','kind'}
    end='\n' if raw.endswith('\n') else ''
    built.append(compact({'kind':record['kind'],'details':{'amount':record['amount']}})+end)
    count+=1
nested_lines=''.join(built)
line_reader="return record['amount']"
assert flat['source'].count(line_reader)==1
lines_script=flat['source'].replace(line_reader,"return record['details']['amount']")
cases=[variant(document,'diagnostic.nested-json-document','shipments.json',nested_doc,doc_script),
       variant(flat,'diagnostic.nested-json-lines','input.jsonl',nested_lines,lines_script),flat,csv]
write('representative.json',orig|{'cases':cases})
write('fixture-census.json',dict(document=dict(records=len(rows),bytes=len(nested_doc.encode('utf-8'))),
                                     lines=dict(records=count,bytes=len(nested_lines.encode('utf-8')))))
old=(pinned.parent/'prepare.py').read_text(encoding='utf-8')
replacements={
    "image_base=lab.with_name('ready-starmap-async-20261127')/'local'":"image_base=lab.with_name('converted-entry-20261127')/'local'",
    "assert head.startswith('7bc13cd06')\nassert not subprocess.check_output(['git','diff','42b3a04d9',head,'--','src'],cwd=repo)":"assert head.startswith('f48ab7583')",
    "assert pin['sourceRevision'].startswith('6c459bbd8')":"assert pin['sourceRevision'].startswith('7bc13cd06')",
    "json_totals='diagnostic.json-service-quantity-totals'\nwide='diagnostic.shipment-starmap-wide-lists'\nbound='diagnostic.shipment-bound-starmap'":"document='diagnostic.nested-json-document'\nlines='diagnostic.nested-json-lines'\nflat='scripts.json-summary-helpers.large'",
    "{file_fed,json_totals,wide,bound}":"{file_fed,document,lines,flat}",
    "'lython-converted-entry-fixture-'":"'lython-nested-json-layouts-fixture-'",
    "[[file_fed,'warm-async'],[wide,'warm-async'],[json_totals,'warm'],[bound,'warm-async']]":"[[flat,'warm-async'],[document,'warm'],[file_fed,'warm-async'],[lines,'warm-async']]",
    "['git','rev-parse','42b3a04d9']":"['git','rev-parse','f48ab7583']",
    "Reuse the converted dictionary kernel without staging get operands. File-fed map is the unchanged control.":"Keep previous JSON key layouts by container depth. Flat Lines and file-fed map are controls.",
}
for before,after in replacements.items():
    assert old.count(before)==1,before
    old=old.replace(before,after)
compile(old,'prepare.py','exec')
def write_script(name,s):(lab/name).write_text(s,encoding='utf-8',newline='\n')
write_script('prepare.py',old)
write_script('stage.sh',(pinned.parent/'stage.sh').read_text(encoding='utf-8').replace('lython-converted-entry-','lython-nested-json-layouts-'))
write_script('summarize.py',(pinned.parent/'summarize.py').read_text(encoding='utf-8'))