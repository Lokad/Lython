set -eu
root=/home/lokad/lython-bench-checks/csv-runtime-b512-20261109
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm/lython-b512
date -u +%FT%TZ > "$root/started.utc"
systemctl show lython-b512-csv-runtime-20261109.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-before.json"
findmnt -T "/dev/shm/lython-b512" -o TARGET,SOURCE,FSTYPE,OPTIONS > "$root/fixture-filesystem.txt"
python3 "$root/ops-profile.py" "$root/profiles"
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-after.json"
for case in csv-warm; do
 python3 "$root/analyze-cpu-guest.py" "$root/profiles/$case"
done
# All sudo perf reads have ended before transferring these owned files.
for case in csv-warm; do
 sudo -n chown lokad:lokad "$root/profiles/$case/perf.data"
done
python3 - <<'PY'
from pathlib import Path
import subprocess
p=Path('/dev/shm/lython-b512')
assert p.is_mount() and not list(p.iterdir())
subprocess.run(['sudo','-n','umount',str(p)],check=True);p.rmdir()
PY
python3 "$root/archive.py"
