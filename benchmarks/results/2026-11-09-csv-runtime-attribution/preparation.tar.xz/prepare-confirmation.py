from pathlib import Path
import hashlib,json,shutil,tarfile
old=Path(__file__).parent;r=old/'confirmation';r.mkdir(exist_ok=False)
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','attribute.py','run.sh','retrieve.py','launch.py']:
    s=(old/n).read_text(encoding='utf-8').replace('csv-runtime-b511-20261109','csv-runtime-b512-20261109').replace('lython-b511-csv-runtime-20261109','lython-b512-csv-runtime-20261109').replace('/dev/shm/lython-b511','/dev/shm/lython-b512').replace('lython-b511-fixtures','lython-b512-fixtures').replace('csv-runtime-b511-launch.py','csv-runtime-b512-launch.py')
    if n=='ops-profile.py':
        assert 'request("batch", 4096)' in s and 'count = 256' in s
        s=s.replace('request("batch", 4096)','request("batch", 128)').replace('count = 256','count = 64')
    if n=='launch.py':
        s=s.replace(' proof=json.loads', " os.link(source/'Lokad.Lython.dll',root/'current-core.dll')\n proof=json.loads")
    if n.endswith('.py'):compile(s,n,'exec')
    (r/n).write_text(s,encoding='utf-8',newline='\n')
for n in ['catalog.json','core-source.json','current-source-delta.json','sizing.json']:shutil.copyfile(old/n,r/n)
i=json.loads((old/'identity.json').read_text(encoding='utf-8'));original=i['catalogSHA256'];i['catalogSHA256']=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
selection=(old/'selection.md').read_text(encoding='utf-8')+'''

Bounded sizing correction: B511 original4096-job warmup exceeded the unchanged20s
frame guard before CPU capture. Killed worker joined; all raw/map/RAM evidence
archived under owned cleanup and localSHA verified. No timed observation or design
failure. B512 uses128warmup jobs and64capture jobs per request, same6s targets,
normal runtime settings and unchanged guards/lease. Original stale unused config
catalogSHA field is preserved in B511 metadata; Ready/verify identify actual CSV.
B512 identity now contains its exact catalog SHA. Existing frozen core linked,
not re-uploaded/copied. No storage deletion or reduced headroom.
'''
(r/'selection.md').write_text(selection,encoding='utf-8')
(r/'sizing-correction.json').write_text(json.dumps(dict(originalWarmupBatch=4096,correctedWarmupBatch=128,originalCaptureBatch=256,correctedCaptureBatch=64,frameGuardSeconds=20,guardUnchanged=True,originalUnusedCatalogSHA=original,actualCatalogSHA=i['catalogSHA256'],originalFailedEvidence='../failed-attempt.tgz'),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','core-source.json','identity.json','selection.md','sizing.json','current-source-delta.json','sizing-correction.json']:t.add(r/n,arcname=n)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('R161 complete, awaiting commit:','R161 committed b59c2be3:')
s=s.replace('R162/B511 active;\nobserve after14:27:44UTC.','R162/B511 warmup mis-sized and failed before sampling; worker joined, all raw/map/\nRAM evidence archived/localSHA verified, no users/fixtures. One bounded B512 sizing\ncorrection uses128/64jobs, unchanged20s guard/6s targets; no design-failure inference.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Bounded confirmation prepared: smaller requests, unchanged guards, exact catalog identity.')
