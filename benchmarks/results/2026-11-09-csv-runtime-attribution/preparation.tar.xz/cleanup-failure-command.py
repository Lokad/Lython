from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');r=base/'csv-runtime-b511-20261109';ram=Path('/dev/shm/lython-b511')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 row=json.loads((r/'profiles/csv-warm/record.json').read_text());pid=row['identity']['processId'];assert row['exitCode']==-9 and not Path('/proc/'+str(pid)).exists()
 (r/'failure-journal.txt').write_text(subprocess.run(['journalctl','-u','lython-b511-csv-runtime-20261109.service','--no-pager'],capture_output=True,text=True,check=True).stdout)
 maps=[]
 for prefix in ['perf','perfinfo']:
  p=Path('/tmp')/(prefix+'-'+str(pid)+'.map')
  if p.exists():
   st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid() and st.st_nlink==1
   maps.append((p,hashlib.sha256(p.read_bytes()).hexdigest()))
 assert ram.is_mount()
 entries=[dict(path=str(p.relative_to(ram)),mode=p.lstat().st_mode,size=p.lstat().st_size) for p in ram.rglob('*')]
 assert not any(stat.S_ISLNK(x['mode']) for x in entries)
 (r/'failed-ram-inventory.json').write_text(json.dumps(entries,indent=2)+'\n')
 archive=r/'failed-attempt.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True) as t:
  for p in sorted(r.rglob('*')):
   if p.is_file() and p.name not in ['failed-attempt.tgz','current-core.dll'] and 'candidate' not in p.relative_to(r).parts:t.add(p,arcname=p.relative_to(r).as_posix())
  for p,h in maps:t.add(p,arcname='joined-worker-maps/'+p.name)
  for p in ram.rglob('*'):
   if p.is_file():t.add(p,arcname='failed-ram/'+p.relative_to(ram).as_posix())
 with tarfile.open(archive)as t:
  assert json.loads(t.extractfile('profiles/csv-warm/record.json').read())['exitCode']==-9
  for p,h in maps:assert hashlib.sha256(t.extractfile('joined-worker-maps/'+p.name).read()).hexdigest()==h
  for p in ram.rglob('*'):
   if p.is_file():assert hashlib.sha256(t.extractfile('failed-ram/'+p.relative_to(ram).as_posix()).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
 for p,h in maps:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==h;p.unlink()
 subprocess.run(['sudo','-n','umount',str(ram)],check=True);ram.rmdir()
 proof=dict(complete=True,allWorkersJoined=True,failedWorkerExitCode=-9,warmupTimedOutBeforeCapture=True,originalFailedConditionPreserved=True,allRamRegularBytesAndTemporaryMapsArchivedBeforeRetirement=True,guestFixturesRemoved=True,archiveVerifiedUnderLease=True,temporaryMaps=[dict(path=str(p),sha256=h)for p,h in maps],archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest())
 (r/'failure-cleanup.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
