from pathlib import Path
import json,subprocess
r=Path(__file__).parent
remote="""from pathlib import Path
import json,subprocess
r=Path('/home/lokad/lython-bench-checks/csv-runtime-b511-20261109')
j=subprocess.run(['journalctl','-u','lython-b511-csv-runtime-20261109.service','-n','45','--no-pager'],capture_output=True,text=True)
data=dict(journal=j.stdout+j.stderr,files=[str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and 'candidate' not in p.relative_to(r).parts],record=(r/'profiles/csv-warm/record.json').read_text() if (r/'profiles/csv-warm/record.json').exists() else None)
print(json.dumps(data))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=remote,text=True,encoding='utf-8',capture_output=True);assert p.returncode==0,p.stderr
(r/'failure-inspection.json').write_text(p.stdout,encoding='utf-8');d=json.loads(p.stdout);print(d['journal']);print('Record available:',d['record'] is not None)
if d['record']:
    row=json.loads(d['record']);print(json.dumps({k:v for k,v in row.items() if k not in ['batches','identity']},indent=2))
