from pathlib import Path
import shutil
r=Path(__file__).parent;p=r/'attribute.py';shutil.copyfile(p,r/'attribute-original.py');shutil.copyfile(r/'attribution.json',r/'attribution-original.json')
s=p.read_text(encoding='utf-8')
s=s.replace('leafs=collections.defaultdict(collections.Counter);frames=[];', 'leafs=collections.defaultdict(collections.Counter);phase_leafs=collections.defaultdict(lambda:collections.defaultdict(collections.Counter));frames=[];')
s=s.replace("counts[g][min(hits)[1]if hits else'unassigned']+=1", "phase=min(hits)[1]if hits else'unassigned';counts[g][phase]+=1;phase_leafs[g][phase][frames[0]]+=1")
s=s.replace("topLeaf=leafs[g].most_common(16)", "topLeaf=leafs[g].most_common(16),phaseLeaf={phase:leaves.most_common(20)for phase,leaves in phase_leafs[g].items()}")
compile(s,'attribute.py','exec');p.write_text(s,encoding='utf-8')
