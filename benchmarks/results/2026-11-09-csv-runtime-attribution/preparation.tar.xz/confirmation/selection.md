# R162 maintained validated-CSV attribution

Existing config/text/JSON profiles do not isolate validated-record keyword binding,
record construction and parser work. One short existing-tool CPU capture of the
unchanged csv-validated-records.py and R146 exact fixture/golden,5,120records/68,625B.
Reuse fully qualified7c-equivalent/corecfeb freeze/common worker. Not subsequent
argparse source: only2production files differ, unrelated here; exact delta retained.
Normal GC/tiering, only perf maps;6s warmup and6s whole-batch CPU window. Retain guest,
caller/reset/protocol, tiering and unknowns; no elapsed/source-pair speed claim.
Then <=20min source assessment identifies a current displaced phase before prototype.
Known row capacity is already adopted, namespaces lazy and frames deferred; do not
reimplement them or infer removable VM work from inclusive samples. Preserve Python
keyword/default/protocol/alias semantics, cancellation, terminal refusal and cleanup.
Finite120s owner+30stop+30margin; persistent raw, joined users, RAM unmounted,
archive-under-lease/localSHA. No storage deletion without a fresh proven need.


Bounded sizing correction: B511 original4096-job warmup exceeded the unchanged20s
frame guard before CPU capture. Killed worker joined; all raw/map/RAM evidence
archived under owned cleanup and localSHA verified. No timed observation or design
failure. B512 uses128warmup jobs and64capture jobs per request, same6s targets,
normal runtime settings and unchanged guards/lease. Original stale unused config
catalogSHA field is preserved in B511 metadata; Ready/verify identify actual CSV.
B512 identity now contains its exact catalog SHA. Existing frozen core linked,
not re-uploaded/copied. No storage deletion or reduced headroom.
