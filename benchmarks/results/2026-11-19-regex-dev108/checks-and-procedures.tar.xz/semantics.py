import re
cases = [
    (r"(?P<head>[A-Z]+)(?P<end>:)", "é A :ABC ABC: def Z:", 2, 18),
    (r"\b([0-9]+)\b(?![.])", "é77 9.12 03 abc44 6.", 1, 19),
    (r"(?P<word>\w{2,5})(\s{0,2}):$", "😀Éé  :bad xa: 🐣", 1, 7),
    (r"(?P<word>[α-ω]+)([A-Z]{0,3}):", "🌾αβ ABC:αβDD:γ :γΔz", 1, 16),
    (r"(?<=(é))(?P<body>[^;]+);", "no éX;éXY; ê Z;", 4, 13),
    (r"(?P<digit>\d+)\s*[:;](?P<suffix>\w+)", "文٢ : A ٢:b no 02;z", 0, 17),
    (r"(?P<finish>\w{1,4})END$", "xxEND and ÉÉENDmore", 10, 15),
    (r"(?P<word>.*?)", "é😀 α!", 1, 4),
    (r"(?P<part>α|βα)+(?P<tail>!)", "é βαα! αβα! β!", 2, 14),
]
def detail(m):
    return None if m is None else (m.regs, m.groups(), m.lastindex, m.lastgroup, m.pos, m.endpos)
for expression, text, pos, end in cases:
    p = re.compile(expression)
    print(expression, p.flags, p.groups, p.groupindex)
    print([detail(method(text, pos, end)) for method in (p.match, p.search, p.fullmatch)])
    survivors = list(p.finditer(text, pos, end))
    re.purge()
    print([detail(m) for m in survivors], p.split(text), p.sub(lambda m: '<' + m[0] + '>', text, 2))
