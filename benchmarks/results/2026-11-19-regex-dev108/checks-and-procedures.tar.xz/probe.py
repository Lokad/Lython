from pathlib import Path
import hashlib, json, os, shutil, subprocess, xml.etree.ElementTree as ET, zipfile

lab=Path(__file__).resolve().parent
base=lab.parent
repo=Path.cwd()
source=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.108')
host=Path('D:/code/utf8regex/artifacts/package-acceptance/0.5.0-dev.108/windows')
previous=base/'regex-dev107-r585'
load=lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data: hashlib.sha256(data).hexdigest()
def save(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

core_name='Lokad.Lython.dll'
core_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert core_revision.startswith('0d16f8307')
assert not subprocess.check_output(['git','diff','--name-only','7a0bc456b',core_revision,'--','src/Lokad.Lython/Host/ILythonRegexProvider.cs','src/Lokad.Lython/Public/ILythonMemoryBudget.cs'])
receipt=load(source/'candidate.json')
host_receipt=load(host/'host-acceptance.json')
assert receipt['PackageVersion']=='0.5.0-dev.108' and receipt['CleanSource'] and not receipt['Published']
assert receipt['SourceRevision']==host_receipt['SourceRevision']=='e0097a3fa7b839f56cc11c35e0b50c3d3960b34c'
shutil.copyfile(source/'candidate.json',lab/'producer-candidate.json')
shutil.copyfile(host/'host-acceptance.json',lab/'producer-host-acceptance.json')
proof=load(previous/'result.json')
text=(previous/'semantics.py').read_text(encoding='utf-8')
before='\n]\ndef detail'
assert text.count(before)==1
text=text.replace(before,'''
    (r"(?P<word>.*?)", "é😀 α!", 1, 4),
    (r"(?P<part>α|βα)+(?P<tail>!)", "é βαα! αβα! β!", 2, 14),
]
def detail''')
(lab/'semantics.py').write_text(text,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
report=dict(packageVersion=receipt['PackageVersion'],producer=receipt['SourceRevision'],coreSource=core_revision,
            files={},probes=[],producerHostChecks=[])
for target in ('net10.0','net11.0'):
    original=previous/'probes'/target
    hashes=proof['files'][target]['imageHashes']
    assert {p.relative_to(original).as_posix():sha(p.read_bytes()) for p in original.rglob('*') if p.is_file()}==hashes
    image=lab/'probes'/target
    shutil.copytree(original,image,copy_function=shutil.copyfile)
    core=(lab/'reference/bin/Lokad.Lython/release_net10.0'/core_name if target=='net10.0'
        else base/'inline-function-binding-r690/frozen/reference'/core_name)
    shutil.copyfile(core,image/core_name)
    producer={}
    for row in receipt['Packages']:
        name=row['Id']
        if name not in ('Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe') or row['TargetFramework']!=target: continue
        package=source/row['RelativePath']
        assert sha(package.read_bytes())==row['PackageSha256'].lower()
        with zipfile.ZipFile(package) as archive:
            data=archive.read(f'lib/{target}/{name}.dll')
        assert sha(data)==row['AssemblySha256'].lower()
        (image/(name+'.dll')).write_bytes(data)
        producer[name]=dict(packageSha256=row['PackageSha256'].lower(), assemblySha256=row['AssemblySha256'].lower())
    assert len(producer)==2
    record=next(r for r in host_receipt['Records'] if r['Host']=='lython' and r['Framework']==target)
    assert producer=={r['Id']:dict(packageSha256=r['PackageSha256'],assemblySha256=r['AssemblySha256']) for r in record['Packages']}
    trx=host/f'lython-{target}/accepted.trx'
    assert sha(trx.read_bytes())==record['TrxSha256']
    results=ET.parse(trx).findall('.//{*}UnitTestResult')
    assert len(results)==record['Passed']==405 and all(r.attrib['outcome']=='Passed' for r in results)
    actual=[r.attrib['testName'] for r in results if 'ActualBackendWorkObservesInFlightCancellationAndUnwinds' in r.attrib['testName']]
    assert len(actual)==3 and all(any(stage in name for name in actual) for stage in ['match','compile','cursor'])
    report['producerHostChecks'].append(dict(framework=target,passed=405, trxSHA256=record['TrxSha256'],
              inFlightCases=actual, exactPackageBytesVerified=True))
    shutil.copyfile(trx,lab/f'producer-host-{target}.trx')
    def image_hashes():
        return {p.relative_to(image).as_posix():sha(p.read_bytes()) for p in image.rglob('*') if p.is_file()}
    identity=image_hashes()
    assert len(identity)==len(hashes)==11
    report['files'][target]=dict(imageHashes=identity, producerHashes=producer)
    for api in ('sync','async'):
        assert image_hashes()==identity
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll',lab/'semantics.py','--json','--compare-python',
              '--python','C:/Python313/python.exe','--max-memory-bytes','4194304']
        if api=='async': args.append('--async')
        run=subprocess.run(args,env=env,capture_output=True,timeout=35)
        (lab/f'{target}-{api}.json').write_bytes(run.stdout)
        (lab/f'{target}-{api}.stderr').write_bytes(run.stderr)
        data=json.loads(run.stdout.decode('utf-8'))
        report['probes'].append(dict(framework=target,api=api,exitCode=run.returncode,match=data['Matches']))
        save(lab/'result.json',report)
        print(target,api,run.returncode,data['Matches'],flush=True)
        assert run.returncode==0 and data['Matches']
    assert image_hashes()==identity