set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/fixed-row-local-bindings-20261126"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj \
    -c Release -f net10.0 --no-restore --artifacts-path "$lab/delivery-ubuntu" \
    --filter 'Category!=Stress&FullyQualifiedName~DelayedAsyncStrictZipReportsLongerTail' \
    > "$lab/strict-zip-ubuntu10.log" 2>&1
tail -7 "$lab/strict-zip-ubuntu10.log"
