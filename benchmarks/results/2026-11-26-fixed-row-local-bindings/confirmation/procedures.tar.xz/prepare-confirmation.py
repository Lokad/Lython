from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
first=lab/'comparison/quiet'
repeat=lab.with_name(lab.name+'-confirmation')
quiet=repeat/'comparison/quiet'
quiet.mkdir(parents=True)
template=lab.with_name('json-ready-construction-20261126-confirmation')/'quiet.py'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
terminal=read(first/'terminal-status.json')
receipt=terminal['receipt']
assert terminal['exitCode']=='0' and not terminal['live'] and not terminal['fixtures']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(first/'observations.tar.xz')
identity=read(first/'identity.json')
identity['donorArchiveSHA256']=receipt['archiveSHA256']
identity['purpose']='Confirm fixed row local bindings with reordered target and control lanes.'
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(first/name,quiet/name)
assert sha(quiet/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
shipment='diagnostic.shipment-routing-callbacks'
meter='scripts.csv-meter-report.explicit-float'
search='scripts.file-search.large'
save(quiet/'jobs.json',dict(warm=[[search,'warm'],[shipment,'warm'],[meter,'warm'],[shipment,'warm-async']]))
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
save(quiet/'identity.json',identity)
collector=(first/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1783-fixtures')==1 and collector.count('len(jobs) == 5')==1
collector=collector.replace('lython-b1783-fixtures','lython-b1783c-fixtures').replace('len(jobs) == 5','len(jobs) == 4')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
root='fixed-row-local-bindings-b1783c-20261126'
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
launcher=template.read_text(encoding='utf-8')
for before,after in [
    ('lython-b1776c-ready-json-construction-20261126','lython-b1783c-fixed-row-local-bindings-20261126'),
    ('ready-json-construction-b1776-20261126','fixed-row-local-bindings-b1783-20261126'),
    ('RuntimeMaxSec=285','RuntimeMaxSec=248'),('seconds=205','seconds=172')]:
    assert launcher.count(before)==1,before
    launcher=launcher.replace(before,after)
compile(launcher,'quiet.py','exec')
write(repeat/'quiet.py',launcher)
summary=(lab/'summarize-quiet.py').read_text(encoding='utf-8')
summary=summary.replace("receipt['warmJobs'] == 5","receipt['warmJobs'] == 4")
summary=summary.replace("len(raw['jobs']) == 5","len(raw['jobs']) == 4")
summary=summary.replace('timedBatches=140','timedBatches=112')
compile(summary,'summarize-quiet.py','exec')
write(repeat/'summarize-quiet.py',summary)
