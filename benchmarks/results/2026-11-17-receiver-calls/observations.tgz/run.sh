set -eu
root=/home/lokad/lython-bench-checks/receiver-calls-b871-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
