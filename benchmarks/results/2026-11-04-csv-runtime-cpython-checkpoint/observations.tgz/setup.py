from pathlib import Path
import json,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/csv-runtime-cpython-b219-20261104');base=Path('/home/lokad/lython-bench-checks/runtime-cpython-b214-20261104/candidate')
for f in base.iterdir():
 if f.name=='Lokad.Lython.dll':continue
 if f.name in ('Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json'):shutil.copyfile(f,root/'candidate'/f.name)
 else:(root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
(root/'reference').symlink_to(base,target_is_directory=True)
i=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for label in ('candidate','control','reference'):
 folder=root/('candidate' if label=='control' else label)
 assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
assert shutil.disk_usage(root).free>64*1024*1024
