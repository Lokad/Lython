from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from collections import Counter

lab=Path(__file__).resolve().parent
earlier=lab.parent/"cpython-runtime-checkpoint-20261123/startup"
comparison=lab/"comparison"
out=lab/"follow-up"
out.mkdir()
instrumented=out/"profile"
instrumented.mkdir()
reading=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
reference=reading(comparison/"reference-verify.json")
identity=reading(comparison/"identity.json")
dotnet=Path(reference["launched"]["dotnet"]["path"])
tracer=Path.home()/".dotnet/tools/dotnet-trace.exe"
environment=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
adapter="Lokad.Lython.Benchmarks.dll"
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,expected in identity["imageFiles"]["candidate"].items():
    frozen=comparison/"frozen-candidate"/n
    assert digest(frozen)==expected
    original=earlier/"frozen-traced"/n if n==adapter else frozen
    shutil.copyfile(original,instrumented/n)
source=reading(comparison/"representative.json")
scenarios={case["id"]:case for case in source["cases"]}
ordered=["control.empty.control","scripts.config-edit.small","scripts.csv-meter-report.typed-ascii"]
observations=[]
for index,name in enumerate(ordered):
    case=scenarios[name]
    payload=out/(str(index)+".json")
    payload.write_text(json.dumps(dict(source,cases=[case]),ensure_ascii=False),encoding="utf-8")
    worker=[dotnet,instrumented/adapter,"--compare","once","--catalog",payload]
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as folder:
        tested=subprocess.run(worker,cwd=folder,env=environment,capture_output=True,check=True,timeout=25)
        result=json.loads(tested.stdout[4:])["response"]
        assert result["status"]=="Equivalent" and result["actualOutputSha256"]==case["expectedOutputSha256"]
        assert result.get("actualFilesSha256")==case.get("expectedFilesSha256")
        phases=dict((name,float(time))for name,time in(line.split() for line in tested.stderr.decode("utf-8").splitlines()))
    for repeat in range(1 if index==0 else 3):
        stamp=out/f"trace-{index}-{repeat}.nettrace"
        with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as folder:
            process=subprocess.run([tracer,"collect","--providers","Microsoft-Windows-DotNETRuntime:0x10:5,Microsoft-DotNETCore-SampleProfiler",
                "--format","Speedscope","--output",stamp,"--",*worker],cwd=folder,env=environment,capture_output=True,check=True,timeout=35)
            stamp.with_suffix(".log").write_bytes(process.stdout+process.stderr)
        scan=reading(stamp.with_suffix(".speedscope.json"))
        frames=[frame["name"] for frame in scan["shared"]["frames"]]
        included=Counter()
        patterns={"frontend":"LythonFrontend.Compile(", "abstract":"StaticAbstractInterpreter.Analyze(",
            "signatureInitialization":"LythonKnownCallableSignatures..cctor", "createSignatures":"LythonCallableSignature.Create(",
            "knownCallCatalog":"StaticContracts+KnownCallCatalog..cctor", "callableMemberCatalog":"StaticContracts+CallableMemberCatalog..cctor",
            "moduleCatalog":"StaticModuleCatalog..cctor", "emission":"ExecutableScript.Compile(", "parser":"Parser.Parse("}
        for profile in scan["profiles"]:
            assert profile["type"]=="evented" and profile["unit"]=="milliseconds"
            active=[]
            previous=profile["startValue"]
            for event in profile["events"]:
                at=event["at"]
                for label,pattern in patterns.items():
                    if any(pattern in frame for frame in active):
                        included[label]+=at-previous
                if event["type"]=="O":active.append(frames[event["frame"]])
                else: assert active.pop()==frames[event["frame"]]
                previous=at
        result=dict(case=name,repeat=repeat,workerPhaseSnapshot=phases,inclusiveStackMilliseconds=included,traceSHA256=digest(stamp))
        observations.append(result)
        print(result,flush=True)
(out/"summary.json").write_text(json.dumps(dict(candidate=identity["candidate"],observations=observations,
    coreSHA256=digest(instrumented/"Lokad.Lython.dll"),workerSHA256=digest(instrumented/adapter)),indent=2)+"\n",encoding="utf-8")
