from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name("dictreader-completed-rows-20261125")
jobs = [
    ("diagnostic.text-summary.nonlocal-computed-width.large", "warm"),
    ("diagnostic.shipment-file-fed-map", "warm-async"),
    ("scripts.csv-invoice.method-policy.quoted-control", "warm"),
    ("diagnostic.invoice-plain-reader", "warm"),
    ("diagnostic.shipment-file-fed-map", "warm"),
]

def edit(name, changes):
    text = (prior / name).read_text(encoding="utf-8")
    for before, after in changes:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

source = (prior / "freeze.py").read_text(encoding="utf-8")
a = source.index('for role in ("reference", "candidate"):')
b = source.index('assert candidate_diff("--binary") == patch.read_bytes()', a)
construction = source[a:b]
edit("freeze.py", [
    ('".git/agent-worktrees/dictreader-completed-rows-20261125"', '".git/agent-worktrees/dictreader-inline-headers-20261125"'),
    ('"pair-only-rollback-20261125"', '"dictreader-completed-rows-20261125"'),
    ('assert git("rev-parse", "HEAD").decode().strip() == base', 'assert git("diff", "--binary", base, "HEAD", "--", "src") == b""'),
    ('patch.write_bytes(candidate_diff("--binary"))',
     'assert patch.read_bytes() == candidate_diff("--binary")\n'
     'assert sha(patch) == read(lab / "identity-source.json")["sourcePatchSHA256"]'),
    ('old_identity["imageFiles"]["candidate"]','old_identity["imageFiles"]["reference"]'),
    ('(donor / "candidate").iterdir()', '(donor / "reference").iterdir()'),
    (construction, '''assert old_identity["sourceRevision"] == base
reference = lab / "reference"
reference.mkdir(exist_ok=True)
for name, expected in old_files.items():
    shutil.copyfile(donor / "reference" / name, reference / name)
    assert sha(reference / name) == expected
images["reference"] = old_files
''' + construction.replace('("reference", "candidate")', '("candidate",)').replace('donor / "candidate" / name', 'donor / "reference" / name')),
    (next(line for line in source.splitlines() if line.startswith("jobs =")), "jobs = " + repr(jobs)),
    ('== 5', '== 4'),
    ('Complete buffered DictReader rows without unconditional asynchronous state machines',
     'Isolate completion of known DictReader field names without changing data-row transport'),
])
edit("prepare.py", [
    ('"pair-only-rollback-20261125"', '"dictreader-completed-rows-20261125"'),
    ('verified["caseCount"] == 5', 'verified["caseCount"] == 4'),
    ('collector.replace("b1711-fixtures", "b1718-fixtures")',
     'collector.replace("b1711-fixtures", "b1718c-fixtures").replace("len(jobs) == 8", "len(jobs) == 5")'),
    ('"started < 360"', '"started < 242"'),
    ('"lython-b1717c-pair-only-rollback", "lython-b1718-dictreader-completed-rows"',
     '"lython-b1718-dictreader-completed-rows", "lython-b1718c-dictreader-inline-headers"'),
    ('launcher.replace("b1717c", "b1718").replace("if name==\'Lokad.Lython.dll\' and role==\'candidate\':", "if name==\'Lokad.Lython.dll\':")',
     'launcher.replace("b1718", "b1718c").replace("if name==\'Lokad.Lython.dll\':", "if name==\'Lokad.Lython.dll\' and role==\'candidate\':")'
     '.replace("reference/\'candidate\'/name", "reference/\'reference\'/name")'),
    ('''launcher.replace("'candidate-core.dll'}", "'candidate-core.dll','reference-core.dll'}")''',
     '''launcher.replace("'candidate-core.dll','reference-core.dll'}", "'candidate-core.dll'}")'''),
    ('"RuntimeMaxSec=270", "RuntimeMaxSec=390"', '"RuntimeMaxSec=390", "RuntimeMaxSec=275"'),
    ('"seconds=216", "seconds=305"', '"seconds=305", "seconds=207"'),
    ('    for role in identity["imageFiles"]:\n        out.add(lab / role / "Lokad.Lython.dll", arcname=role + "-core.dll")',
     '    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")'),
    ('root="dictreader-completed-rows-b1718-20261125"', 'root="dictreader-inline-headers-b1718c-20261125"'),
    ('reference="pair-only-rollback-b1717c-20261125"', 'reference="dictreader-completed-rows-b1718-20261125"'),
])
