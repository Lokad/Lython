set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/dictreader-inline-headers-20261125"
worktree="$PWD/.git/agent-worktrees/dictreader-inline-headers-20261125"
log="$lab/headers-ubuntu10.log"
if dotnet test "$worktree/tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~CsvSuspendedProtocolTests|FullyQualifiedName~CsvBlankRecordTests|FullyQualifiedName~CsvHeaderOwnershipTests' > "$log" 2>&1; then
  tail -4 "$log"
else
  tail -45 "$log"
  exit 1
fi
