set -eu
root=/home/lokad/lython-bench-checks/inline-trim-membership-b1063-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
