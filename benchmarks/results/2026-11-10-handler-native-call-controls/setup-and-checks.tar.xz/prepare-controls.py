from pathlib import Path
import hashlib,json,shutil,tarfile
home=Path(__file__).parent;old=home/'b522';dest=home/'b523';dest.mkdir()
def adapt(s):return s.replace('handler-native-entry-b522-20261110','ordinary-controls-b523-20261110').replace('lython-b522-handler-native-entry-20261110','lython-b523-ordinary-controls-20261110').replace('lython-b522-fixtures','lython-b523-fixtures').replace('handler-native-entry-b522-launch','ordinary-controls-b523-launch').replace('B521','B523').replace('B522','B523')
for name in ['identity.json','representative.json','baseline-source.json','final-source.json','source.patch','FramedFunctionExecutionTests.cs','LythonRuntime.Json.Serialize.cs','LythonRuntime.Json.Options.cs','PyExecutableFunction.cs','focused.json','setup-contract.json','sizing.json']:
    shutil.copyfile(old/name,dest/name)
text=adapt((old/'collect.py').read_text())
start=text.index('jobs=');end=text.index('\n\n',start)
text=text[:start]+"jobs=[['scripts.report-render.large','warm'],['scripts.unicode-index-report.control','warm']]\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)"+text[end:]
(dest/'collect.py').write_text(text)
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=adapt((old/name).read_text()).replace("len(r['jobs'])==5","len(r['jobs'])==2").replace("['jobs']==5","['jobs']==2").replace('jobs=5','jobs=2').replace('five-job','two-job')
    (dest/name).write_text(text)
contract='''Bounded confirmation of B522 adverse report/Unicode controls. Same source,
frozen cores, toolchain, four processes,5s warmups,7rotated150msrounds and original
conditions. Two existing jobs only. Preserve B522 adversity; no change to GC/tiering,
input/goldens, included I/O/validation/prior-result cleanup or wider CPU boundary.
Owner120s/stop30s/margin30s. Reuse cores by verified hardlinks, no new binaries.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract)
with tarfile.open(dest/'payload.tgz','w:gz')as t:
    for p in sorted(dest.iterdir()):
        if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
payload=(dest/'payload.tgz').read_bytes()
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+65536+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),frozenCoresReused=True),indent=2)+'\n')
p=Path('benchmarks/results/2026-11-10-framed-native-entry/quiet/observations.tgz')
spec=[dict(path='/home/lokad/lython-bench-checks/bound-native-entry-b521-20261110/observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=p.resolve().as_posix(),tracked=True)]
script=adapt((old/'space-recovery-command.py').read_text()).replace('handler-native-entry-b522','ordinary-controls-b523')
oldrequired=json.loads((old/'payload-sizing.json').read_text())['requiredFreeBytes'];script=script.replace(str(oldrequired),str(required))
script='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in script.splitlines())+'\n'
(dest/'space-recovery-command.py').write_text(script)
(dest/'recover-space.py').write_text(adapt((old/'recover-space.py').read_text()))
script=adapt((old/'launch-command.py').read_text()).replace('RuntimeMaxSec=210','RuntimeMaxSec=120').replace('ownerSeconds=210','ownerSeconds=120').replace("assert 'assert len(jobs)==5 '","assert 'assert len(jobs)==2 '")
script='\n'.join(' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest()) if line.startswith(' payload=')else line for line in script.splitlines())+'\n'
script=script.replace(" previous=base/", " os.link(base/'handler-native-entry-b522-20261110/current-core.dll',root/'current-core.dll')\n previous=base/")
(dest/'launch-command.py').write_text(script)
launch=adapt((old/'launch.py').read_text()).replace('seconds=270','seconds=180').replace('ownerSeconds=210','ownerSeconds=120')
(dest/'launch.py').write_text(launch)
print('Existing two-control confirmation prepared; required free bytes',required)
