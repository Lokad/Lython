from pathlib import Path
import ast
import gzip
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('json-traversal-20261124')
prior = lab.with_name('rule-activation-cpython-20261124')
output = lab/'external'
output.mkdir(exist_ok=True)

read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())

def emit(path, source):
    if path.suffix == '.py': compile(source, str(path), 'exec')
    path.write_text(source, encoding='utf-8', newline='\n')

def save(path, value):
    emit(path, json.dumps(value, indent=2, ensure_ascii=False)+'\n')

metadata = read(donor/'comparison/identity.json')
receipt = read(donor/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(donor/'comparison/quiet/observations.tar.xz') == receipt['archiveSHA256']
source = subprocess.check_output(['git','rev-parse','2cf721f73'],cwd=repo,text=True).strip()
subprocess.run(['git','diff','--exit-code',metadata['candidate'],source,'--','src'],cwd=repo,check=True)
subprocess.run(['git','diff','--exit-code',source,'HEAD','--','src','tests'],cwd=repo,check=True)
files = metadata['imageFiles']['candidate']
assert len(files) == 32 and all(digest(donor/'candidate'/name) == digest_value for name,digest_value in files.items())
root = 'shared-traversal-cpython-b1587-20261124'
origin = 'json-traversal-b1586-20261124'
identity = dict(sourceRevision=metadata['candidate'], candidate=metadata['candidate'], productionSource=source,
    imageFiles={'candidate':files}, frozenImage='/home/lokad/lython-bench-checks/'+root+'/candidate',
    auxiliaryFiles={name:sha for name,sha in files.items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:metadata['coreSHA256'][role] for role in ('candidate','candidate-control')},
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'], cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'])

catalog = read(prior/'external/representative.json')
json_catalog = read(donor/'comparison/representative.json')
json_case = 'scripts.json-lines-shipment.expanded-options.large'
assert {k:v for k,v in catalog.items() if k!='cases'} == {k:v for k,v in json_catalog.items() if k!='cases'}
catalog['cases'].extend(case for case in json_catalog['cases'] if case['id']==json_case)
captured, defaulted, short, invoice, json_case = [case['id'] for case in catalog['cases']]
jobs = [[case,'warm'] for case in (captured,defaulted,short,invoice,json_case)]
jobs += [[case,'compile-run'] for case in (defaulted,short,json_case)]
jobs += [[case,'compile'] for case in (defaulted,short)]
save(output/'representative.json',catalog)
save(output/'jobs.json',jobs)
identity['catalogs'] = {name:dict(sha256=digest(output/name)) for name in ('representative.json','jobs.json')}
save(output/'identity.json',identity)

dotnet = Path.home()/'.dotnet11/dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
protocol = repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
    '--catalog',output/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
    '--python-worker',protocol,'--out',output/'candidate-verify.json'],env=env,check=True,timeout=90)
verification = read(output/'candidate-verify.json')
assert verification['state']=='Completed' and verification['caseCount']==5
assert verification['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verification['launched']['library']['sha256']==identity['coreSHA256']['candidate']

collector = (prior/'external/collect.py').read_text(encoding='utf-8').replace('b1575-','b1587-')
collector = collector.replace('len(jobs) == 9','len(jobs) == 10')
collector = collector.replace('CPython checkpoint for captured and defaulted scalar helper returns',
    'CPython checkpoint for current JSON traversal and generated rule scripts')
emit(output/'collect.py',collector)
summary = (prior/'external/summarize.py').read_text(encoding='utf-8')
summary = summary.replace('len(raw["jobs"])==9 and receipt["warmJobs"]==9',
    'len(raw["jobs"])==10 and receipt["warmJobs"]==10')
emit(output/'summarize.py',summary)

def versioned(path):
    return subprocess.check_output(['git','show',f'origin/master:benchmarks/results/{path}'],cwd=repo)

prior_record = '2026-11-24-json-ascii-runs'
core = 'Lokad.Lython.dll'
reference_digest = sha(gzip.decompress(versioned(f'{prior_record}/reference-core.dll.gz')))
replicas = []
for record, folder in ((prior_record,'json-ascii-runs-b1585-20261124'),('2026-11-24-json-traversal',origin)):
    assert json.loads(versioned(f'{record}/identity.json'))['imageFiles']['reference'][core] == reference_digest
    previous = json.loads(versioned(f'{record}/terminal-status.json'))['receipt']
    assert previous['complete'] and previous['archivedAndVerifiedUnderLease']
    assert sha(versioned(f'{record}/observations.tar.xz')) == previous['archiveSHA256']
    replicas.append(dict(folder=folder, archive=previous['archiveSHA256']))
save(output/'verified-replicas.json',dict(core=core,coreSHA256=reference_digest,replicas=replicas))

launch = (prior/'external.py').read_text(encoding='utf-8')
launch = launch.replace("lab.parent / 'external-arithmetic-operands-20261124/comparison/quiet'", "lab.parent / 'json-traversal-20261124/comparison/quiet'")
launch = launch.replace('lython-b1575-rule-activation-','lython-b1587-shared-traversal-')
launch = launch.replace('rule-activation-cpython-b1575-20261124',root)
launch = launch.replace('external-arithmetic-operands-b1574-20261124',origin)
launch = launch.replace('seconds=444','seconds=504')
launch = launch.replace('    script = f"payload={payload!r}; checksum={previous[\'archiveSHA256\']!r}\\n"',
    '    retired = json.loads((output/\'verified-replicas.json\').read_text(encoding=\'utf-8\'))\n'
    '    script = f"payload={payload!r}; checksum={previous[\'archiveSHA256\']!r}; retired={retired!r}\\n"')
launch = launch.replace(' assert shutil.disk_usage(base).free>=10*1024*1024',""" block=os.statvfs(base).f_frsize
 staged=sum((len(content.encode('utf-8'))+block-1)//block*block for content in payload.values())
 minimum=staged+3840*1024
 free=shutil.disk_usage(base).free
 if free<minimum:
  candidates=[]
  for saved in retired['replicas']:
   old=base/saved['folder']
   replica=old/'reference'/retired['core']
   assert replica.resolve()==replica and replica.is_relative_to(base)
   assert digest(old/'observations.tar.xz')==saved['archive'] and not (old/'guest-fixtures').exists()
   assert digest(replica)==retired['coreSHA256'] and replica.stat().st_nlink==len(retired['replicas'])
   candidates.append(replica)
  assert len(set(candidates))==len(candidates) and all(os.path.samefile(candidates[0],item) for item in candidates)
  assert free+candidates[0].stat().st_blocks*512>=minimum
  for item in candidates: item.unlink()
  print(json.dumps(dict(verifiedArchivedCopiesRetired=[str(item) for item in candidates])),flush=True)
 assert shutil.disk_usage(base).free>=minimum
 assert not root.exists()""")
launch = launch.replace(' assert bytes([13]) not in (root/\'run.sh\').read_bytes()',
    " assert bytes([13]) not in (root/'run.sh').read_bytes()\n assert shutil.disk_usage(base).free>=3584*1024")
assert 'staged=sum' in launch and 'retired={retired!r}' in launch
remote_code, = (node.value for node in ast.walk(ast.parse(launch)) if isinstance(node,ast.Constant) and isinstance(node.value,str) and 'staged=sum' in node.value)
compile(remote_code,'remote-stage','exec')
emit(lab/'external.py',launch)
