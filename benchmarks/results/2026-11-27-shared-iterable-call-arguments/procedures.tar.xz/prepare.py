from base64 import b64decode
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
prior=notes/'iterable-starmap-arguments-20261127'
comparison=lab/'comparison/local'
allocation=lab/'allocation'
comparison.mkdir(parents=True)
allocation.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
image=lambda path:{p.name:sha(p) for p in path.iterdir()}
core='Lokad.Lython.dll'
worker='Lokad.Lython.Benchmarks.dll'
pinned=read(repo/'benchmarks/results/2026-11-27-iterable-starmap-arguments/quiet/identity.json')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','aae8992e0','HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
delivered=subprocess.check_output(['git','diff','--binary',pinned['sourceRevision'],'aae8992e0','--','src'],cwd=repo)
assert sha256(delivered).hexdigest()==pinned['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'AppendPositionalIterableAsync' in patch and patch.count(b'diff --git ')==2
(lab/'candidate.patch').write_bytes(patch)
orig=prior/'comparison/local/candidate'
assert image(orig)==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(orig,comparison/role)
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
assert sha(new/core)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
shutil.copyfile(new/core,comparison/'candidate'/core)
images={role:image(comparison/role) for role in ('reference','candidate')}
assert [name for name,digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

catalog=read(prior/'comparison/local/representative.json')
starmap='diagnostic.shipment-starmap-iterable-rows'
map_case='diagnostic.shipment-file-fed-map'
target='diagnostic.shipment-starred-generated-rows'
cases={case['id']:case for case in catalog['cases']}
row_case=cases[starmap].copy()
row_case['id']=target
suffix="    print(sum(starmap(cost, (arguments(record) for record in csv.DictReader(source)))))\n"
assert row_case['source'].endswith(suffix)
row_case['source']=row_case['source'][:-len(suffix)].replace('from itertools import starmap\n','')+'''    total = 0
    for record in csv.DictReader(source):
        total += cost(*arguments(record))
    print(total)
'''
source_bytes=row_case['source'].encode('utf-8')
fixture=json.loads(row_case['fixtureJson'])
assert fixture['size']==2048 and fixture['text'] is None and len(fixture['inputFiles'])==1
python=Path('C:/Python313/python.exe')
with tempfile.TemporaryDirectory(prefix='lython-b1866-goldens-') as location:
    folder=Path(location)
    (folder/'shipment.py').write_bytes(source_bytes)
    for name,content in fixture['inputFiles'].items():
        assert name=='shipments.csv'
        (folder/name).write_bytes(b64decode(content))
    expected=subprocess.check_output([python,'-I','-X','utf8',folder/'shipment.py'],cwd=folder,timeout=15)
    assert len(list(folder.iterdir()))==2
    assert all((folder/name).read_bytes()==b64decode(content) for name,content in fixture['inputFiles'].items())
row_case.update(sourceUtf8Bytes=len(source_bytes),sourceSha256=sha256(source_bytes).hexdigest(),
                expectedOutput=expected.decode('utf-8').replace('\r\n','\n'))
golden=row_case['expectedOutput'].encode('utf-8')
row_case.update(expectedOutputUtf8Bytes=len(golden),expectedOutputSha256=sha256(golden).hexdigest())
print('CPython output',repr(row_case['expectedOutput']),flush=True)
catalog['cases']=[row_case,cases[starmap],cases[map_case]]
write(comparison/'representative.json',catalog)
write(comparison/'jobs.json',{'warm':[[target,'warm'],[starmap,'warm-async'],[target,'warm-async'],[map_case,'warm-async']]})
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(prior/'comparison/quiet'/name,comparison/name)
assert b'\r' not in (comparison/'run.sh').read_bytes()
collector=(notes/'converted-entry-20261127/confirm/local/collect.py').read_text(encoding='utf-8')
collector=collector.replace('len(jobs) == 3','len(jobs) == 4').replace('lython-converted-entry-fixture-','lython-b1866-starred-fixture-')
compile(collector,'collect.py','exec')
(comparison/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),
    productionReference='aae8992e0',imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(comparison/name)} for name in ('representative.json','jobs.json')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(comparison/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),
    verificationPythonSHA256=sha(python),
    purpose='Compare one shared reader for starred generated rows with starmap and file-fed controls.')
write(comparison/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    report=comparison/f'{role}-verify.json'
    subprocess.run([dotnet,comparison/role/worker,'--compare','verify','--catalog',comparison/'representative.json',
       '--dotnet',dotnet,'--python',python,'--python-worker',comparison/'cpython-worker.py','--out',report],env=env,check=True,timeout=65)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==3
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
    folder=allocation/role
    shutil.copytree(comparison/role,folder)
    for path in (prior/'allocation/candidate').glob('ValidatedAllocation*'):
        shutil.copyfile(path,folder/path.name)
    assert all(sha(folder/name)==digest for name,digest in files.items())

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selection=allocation/f'{mode}-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=allocation/role
        report=allocation/f'{role}-{mode}.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=75)
        pair.append(read(report)['rows'])
    for before,after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                 peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
                 compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(allocation/'summary.json',rows)

