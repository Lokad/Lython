from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-19-validator-warm-profile')
read=lambda path:json.loads(path.read_text(encoding='utf8'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
receipt=read(lab/'archive-receipt.json')
terminal=read(lab/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved',
    'archivedAndVerifiedUnderLease','ramTraceArchivedAndVerifiedBeforeUnmount'))
assert receipt['archiveSHA256']==digest(lab/'observations.tgz')
identity=read(lab/'identity.json')
assert identity['sourceRevision'].startswith('a472eb2a4') and identity['catalogSHA256']==digest(lab/'catalog.json')
built=read(lab.parent/'postfix-cpython-b1130/identity.json')
assert built['sourceRevision']==identity['sourceRevision'] and built['imageFiles']['candidate']['Lokad.Lython.dll']==identity['coreSHA256']['candidate']
files=identity['imageFiles']['candidate']
frozen=lab.parent/'postfix-cpython-b1130/frozen/candidate'
assert len(files)==32 and {name:digest(frozen/name) for name in files}==files
cases={case['id']:case for case in read(lab/'catalog.json')['cases']}
rows=read(lab/'attribution.json')['rows']
assert len(rows)==len(cases)==2
for row in rows:
    record=read(lab/'retrieved/profiles'/row['label']/'record.json')
    case=cases[row['case']]
    assert record['workload']==row['case'] and record['lane']=='warm'
    assert record['warmupSeconds']>=8 and record['exitCode']==0 and record['closed']['status']=='Closed'
    assert record['verificationBefore']['status']==record['verificationAfter']['status']=='Equivalent'
    observed={Path(lib['path']).name:lib['sha256'].lower() for lib in record['identity']['libraries']}
    assert observed['Lokad.Lython.dll']==files['Lokad.Lython.dll']
    assert all(observed[name]==files[name] for name in observed.keys() & files.keys())
    for result in (record['verificationBefore'], *record['batches'], record['verificationAfter']):
        assert result['completedInvocations']>0
        for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'): assert result[key]==case[key]
        assert result['actualOutputSha256']==case['expectedOutputSha256']
        assert result.get('actualFilesSha256')==case.get('expectedFilesSha256')
out.mkdir(exist_ok=False)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz','attribution.json'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as tar:
    for name in ('identity.json','catalog.json','verify.json','prepare.py','ops-profile.py','collect.py','run.sh',
                 'remote-launch.py','observe-not-before.json','analyze.py','archive-profile.py','analysis.log','retrieval.log'):
        tar.add(lab/name,arcname=name)
print('Verified two exact retained profiles, goldens, worker images and persistent trace digests.')
