from pathlib import Path
import ast, hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
previous=lab.parent/'current-rule-profile-r695'
donor=lab.parent/'postfix-cpython-b1130'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value): write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

prior=load(previous/'config.json')
stage=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor/'observations.tgz')==receipt['archiveSHA256']
verified=load(donor/'verify.json')
files=stage['identity']['imageFiles']['candidate']
frozen=donor/'frozen/candidate'
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert verified['state']=='Completed' and verified['catalogSha256']==stage['catalogSHA256']==sha(donor/'representative.json')
shutil.copyfile(donor/'representative.json',lab/'catalog.json')
shutil.copyfile(donor/'verify.json',lab/'verify.json')
identity=dict(sourceRevision=stage['identity']['sourceRevision'],purpose='B1132 validator and manifest warm CPU attribution after shared postfix parsing',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']),imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True)
assert identity['sourceRevision'].startswith('a472eb2a4')
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/validator-warm-profile-b1132-20261119'
unit='lython-b1132-validator-warm-profile-20261119'
jobs=[('validator','scripts.config-generated-guards.medium','warm'),('manifest','scripts.config-manifest.small','warm')]
labels=[label for label,_,_ in jobs]
old_jobs=[('rules','scripts.rule-default-closures','warm'),('annotated','scripts.annotated-rule-closures','warm'),('captured','scripts.captured-rule-closures','warm')]
for name in ('ops-profile.py','collect.py','launch.py','retrieve.py','run.sh','analyze.py'):
    text=(previous/name).read_text(encoding='utf-8').replace(prior['root'],root)
    text=text.replace('R695/B1125 current rule CPU attribution','B1132 validator and manifest warm CPU attribution')
    if name=='ops-profile.py':
        a=text.index('    for name, case_id, lane in ')
        b=text.index('\n',a)
        text=text[:a]+'    for name, case_id, lane in '+repr(jobs)+':'+text[b:]
        text=text.replace('count = 512','count = 2048')
        assert 'elapsed >= 8' in text
    elif name=='collect.py':
        text=text.replace("['rules', 'annotated', 'captured']",repr(labels)).replace('len(records)==3','len(records)==2')
    elif name=='launch.py':
        text=text.replace('seconds=100','seconds=83').replace('100 seconds','83 seconds')
    elif name=='analyze.py':
        text=text.replace("['rules', 'annotated', 'captured']",repr(labels))
    write(name,text)
assert b'\r' not in (lab/'run.sh').read_bytes()
names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names), donorArchive=receipt['archiveSHA256'])
save('config.json',config)
text=(previous/'remote-launch.py').read_text(encoding='utf-8')
a,b=text.index('\nc=')+1,text.index('\nb=Path(')
text=(text[:a]+'c='+repr(config)+text[b:]).replace('lython-b1125-fixtures','lython-b1132-fixtures')
assert text.count("source/'reference'/n")==2
text=text.replace("source/'reference'/n","source/'candidate'/n")
text=text.replace(" assert sha(source/'representative.json')==c['sourceCatalogSHA256']", 
                  " assert sha(source/'representative.json')==c['sourceCatalogSHA256']\n assert sha(source/'observations.tgz')==c['donorArchive']")
write('remote-launch.py',text)
print('Profile staging verified the exact B1130 image and both existing goldens.')
