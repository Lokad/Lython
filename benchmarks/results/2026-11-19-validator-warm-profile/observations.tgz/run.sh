set -eu
root=/home/lokad/lython-bench-checks/validator-warm-profile-b1132-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
