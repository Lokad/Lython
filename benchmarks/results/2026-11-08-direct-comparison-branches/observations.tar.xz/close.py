from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;p=r/'dedicated-handler';out=Path('benchmarks/results/2026-11-08-direct-comparison-branches');out.mkdir(exist_ok=True)
identity=json.loads((p/'identity.json').read_text())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
for name,expected in [('public-dedicated11',76),('public-dedicated10',76),('internal-dedicated11',61),('internal-dedicated10',61),('public-close11',6),('public-close10',6)]:
 text=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in text and re.search(r'Passed:\s+'+str(expected)+r'\b',text)
for label in ['b455','b456']:
 b=r/label;receipt=json.loads((b/'archive-receipt.json').read_text());assert receipt['complete']and receipt['jobs']==6 and not json.loads((b/'terminal-status.json').read_text())['remainingWorkers']
 assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 with tarfile.open(b/'observations.tgz')as archive:
  archived=json.loads((b/'identity.json').read_text())['coreSHA256']
  for member,role in [('current-core.dll','candidate'),('baseline-core.dll','reference')]:
   assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==archived[role]
# Stronger file-close assertions were added after production/core freeze. Preserve
# those final test sources and their actual11/10 logs as a separate test snapshot.
for name in ['ComparisonBranchTests.cs','ComparisonBranchOwnershipTests.cs']:
 directory='Lokad.Lython.PublicApi.Tests'if name=='ComparisonBranchTests.cs'else'Lokad.Lython.Tests'
 destination=r/'final-test-sources'/name;destination.parent.mkdir(exist_ok=True);shutil.copyfile(Path('tests')/directory/name,destination)
notes='''Original conditions and corrections retained:
- Migration's first guard matched "fallback" in retained comments, before writing
  the operator file; corrected guard checks removed code, not comment vocabulary.
- First operator build exposed10 existing callers outside OperatorDispatch. Those
  exposed methods/sorting callers now use the same enum contract; no compatibility
  forwarding overload remains. Original failing build log preserved.
- Exact strings' completed synchronous path under both APIs was restored before
  the first measured cde freeze. All corresponding source/test logs remain.
- B455 cde text elapsed/CPU adverse is preserved. One refinement moves comparison
  control into its own handler, restores the unchanged ordinary value handler and
  removes its per-value control tests. Same six jobs/settings/qualified68 baseline.
- Fresh disk inventory rejected alias paths before any mutation; targets resolved
  and checked inside the intended base. Atomic exact-byte hardlinks preserved six
  targets/all aliases/data and all archives, freed28,057,600B. B456 launch verified
  all original aliases again. No evidence was deleted or collector/CI rerun hidden.
- Refined9d text elapsed+1.28to+3.50%/CPU0to+2.90% is retained explicit debt.
  Retain decision weighs coherent removal and affected complete-script gains;
  no unrelated historical gain repays it, and no full causal explanation claimed.
- Frontend diagnostics describe original cde; uncontrolled desktop elapsed and all
  adverse/unstable controls remain. No extra retiming to erase the debt.
'''
(r/'original-conditions.txt').write_text(notes,encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz',preset=6)as a:
 for file in sorted(r.rglob('*')):
  relative=file.relative_to(r)
  if not file.is_file()or any(part in {'images','retrieved','__pycache__'}for part in relative.parts)or file.name in {'payload.tgz','current-core.dll'}:continue
  a.add(file,arcname=relative.as_posix())
with tarfile.open(out/'observations.tar.xz')as a:
 for member in a.getmembers():assert member.isfile()and hashlib.sha256(a.extractfile(member).read()).digest()==hashlib.sha256((r/member.name).read_bytes()).digest()
for src,name in [(p/'identity.json','identity.json'),(p/'assessment-local.json','allocation-and-local.json'),(r/'assessment-frontend.json','original-frontend-diagnostic.json'),(r/'b455/assessment.json','original-controlled.json'),(r/'b456/assessment.json','retained-controlled.json')]:shutil.copyfile(src,out/name)
summary=dict(status='Retained source selected; focused Release peractual11/10 passes, full delivery pending',baselineSource=identity['baselineSource'],candidateSource=identity['candidateSource'],coreSHA256=identity['coreSHA256'],originalCoreSHA256=json.loads((r/'identity.json').read_text())['coreSHA256']['candidate'],retainedTextElapsedDebtPercent=[1.281,3.496],retainedTextCpuDebtPercent=[0,2.899],noRemainingVMUsersOrFixtures=True,originalAdverseDataPreserved=True,archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest())
(out/'status.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('Original/refined cores/sources/failures/raw observations archived and verified;', (out/'observations.tar.xz').stat().st_size,'bytes. Full delivery pending.')

