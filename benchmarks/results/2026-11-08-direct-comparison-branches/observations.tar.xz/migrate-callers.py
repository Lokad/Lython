from pathlib import Path
for name in ['LythonRuntime.Members.cs','LythonRuntime.BuiltinIterables.Ordering.cs']:
 p=Path('src/Lokad.Lython/Runtime')/name;s=p.read_text(encoding='utf-8')
 for op,method,reflected,test in [('Less','__lt__','__gt__','value < 0'),('LessEqual','__le__','__ge__','value <= 0'),('Greater','__gt__','__lt__','value > 0'),('GreaterEqual','__ge__','__le__','value >= 0')]:
  s=s.replace(f'"{method}", "{reflected}", context, span, static value => {test}',f'BinaryOperatorSyntax.{op}, context, span')
 p.write_text(s,encoding='utf-8',newline='\r\n')
