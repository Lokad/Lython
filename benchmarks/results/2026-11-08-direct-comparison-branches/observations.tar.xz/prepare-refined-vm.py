from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r/'b455';p=r/'dedicated-handler';b=r/'b456';b.mkdir()
source=json.loads((p/'identity.json').read_text());previous=json.loads((old/'identity.json').read_text())
identity={**previous,'sourceRevision':source['candidateSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification']}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('direct-comparison-b455-20261108','dedicated-comparison-b456-20261108').replace('lython-b455-direct-comparison','lython-b456-dedicated-comparison').replace('direct-comparison-b455-launch.py','dedicated-comparison-b456-launch.py')
 if name=='collect.py':s=s.replace('R95 shared typed numeric comparison/ordered enum transport/direct comparison branches; CSV and JSON affected, text/report controls','R95 dedicated comparison control handler restores unchanged value handler after B455 text CPU regression; same six source-pair jobs and controls')
 if name=='launch.py':
  needle=" identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'reference','reference-control','candidate','candidate-control'}"
  assert needle in s
  s=s.replace(needle,needle+"""
 space=json.loads((root/'space-inventory.json').read_text());digest=next(iter(space['groups']))
 for alias,resolved in space['aliases'].items():
  path=Path(alias);assert path.resolve()==Path(resolved) and base.resolve() in path.resolve().parents
  assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
 (root/'alias-verification.json').write_text(json.dumps(dict(allOriginalAliasPathsAndBytesPreserved=True,aliases=len(space['aliases']),sha256=digest))+'\\n')
""")
 if name=='archive-owned.py':s=s.replace("'new-sources']", "'new-sources','space-inventory.json','dedup-proof.json','alias-verification.json']")
 (b/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(p/'images/candidate/Lokad.Lython.dll','current-core.dll'),(p/'catalog.json','representative.json'),(p/'identity.json','focused.json'),(p/'source.patch','source.patch'),(p/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json'),(r/'dedup-proof.json','dedup-proof.json'),(r/'space-inventory.json','space-inventory.json')]:shutil.copyfile(src,b/name)
shutil.copytree(p/'new-sources',b/'new-sources')
contract=(old/'contract.md').read_text(encoding='utf-8')+'''
B455168.446s all gates/archive/local verify pass. Affected CSV sync-8.29to-8.81%,
async-13.45to-16.53%; returnedCSV/JSON favorable but old controls variable.
Text elapsed+0.72to+6.58%, coarseCPU+4.41to+7.46%; report inconclusive. Original
cde core, source, desktop adverse results and raw B455 remain preserved.
One bounded refinement removes new control-op tests from all ordinary value
operations and gives the control instruction its own normal opcode handler.
No new framework/options/owner and no numerical/kernel/semantic change.
Same source pair baseline68, identical six jobs/settings/controls.76public/
61internal peractual11/10 pass. Source ordering/JIT changes preclude attributing
a timing difference to one branch. Explicit retain/correct/reject decision follows.
Space: fresh single-group inventory rejected alias paths before mutations;
resolved targets then verified inside intended base, with exact-byte SHA proof.
Atomic hardlinks preserve six targets/all aliases/contents and all archives,
free28,057,600B. Aliases verified again before this collection. No data deletion.
'''
(b/'contract.md').write_text(contract,encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','new-sources','dedup-proof.json','space-inventory.json']:a.add(b/n,arcname=n)
print('One refined B456 same-six-job confirmation prepared; original B455 intact, exact aliases checked in launch.')

