from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;prior=r.parent/'shared-cased-split-r92'
groups=json.loads((prior/'space-inventory.json').read_text())['groups']
digest=next(k for k in groups if k.startswith('520b3eb0a5d7'))
paths=[row['path']for row in groups[digest]]
remote='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
paths=PATHS;digest=DIGEST
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 rows=[];aliases={}
 for name in paths:
  p=Path(name).resolve();assert base in p.parents
  aliases[name]=str(p)
  if any(row['path']==str(p)for row in rows):continue
  stat=p.stat();assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
  rows.append(dict(path=str(p),inode=stat.st_ino,bytes=stat.st_size,links=stat.st_nlink))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,groups={digest:rows},aliases=aliases),indent=2))
'''.replace('PATHS',repr(paths)).replace('DIGEST',repr(digest))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True);assert done.returncode==0,done.stderr
(r/'space-inventory.json').write_bytes(done.stdout)
s=(prior/'deduplicate-cores.py').read_text(encoding='utf-8').replace('r92-core-dedup-proof.json','r95-core-dedup-proof.json').replace('.r92-identical-link','.r95-identical-link')
(r/'deduplicate-cores.py').write_text(s,encoding='utf-8')
print('Fresh idle-lease inventory of one previously identified exact-byte group;',len(paths),'paths; no mutations yet.')

