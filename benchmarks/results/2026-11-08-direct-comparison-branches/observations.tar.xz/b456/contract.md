R95 bounded source pair, not another CPython refresh. Exact fully qualified
05d81b83/core68f63d29 baseline, candidate frozen80143659 plus shared comparison and
conditional instruction migration. Same unchanged worker7cf37ca5/optional0.4.
Six complete jobs: CSV helper sync/async and returned records, JSON numeric
filter (affected), rsplit text/report (controls). All sources/fixtures/goldens
unchanged from R90. Five-second warmup per process/job, normal GC/tiering,
7x150ms rotated samples, two old/two current processes, coarse process CPU.
210s owner+30sstop+30smargin. Persistent raw/core/archive storage separate from
128MiB owned guest RAM. Existing exact baseline/auxiliary bytes hardlinked after
SHA proof; no old evidence/path/content deleted. Preflight240MiB OS floor+7MiB
trace/archive headroom and actual payload sizing. All source/Ready/runtime/full
golden/quiet/Closed/join/fixture/archive/local verification gates required.
Retain adverse/inconclusive results. Architectural deletion, allocation, elapsed/
CPU and controls are distinct; no fixed-percentage veto or universal speed claim.
Final source76public/61internal peractual11/10 includes 3CPython-golden programs
and real suspended comparison/truth cancellation, origin/alias/budget cleanup.
No public API change, unsafe code, new owner/cache/pool or alternative engine.

B455168.446s all gates/archive/local verify pass. Affected CSV sync-8.29to-8.81%,
async-13.45to-16.53%; returnedCSV/JSON favorable but old controls variable.
Text elapsed+0.72to+6.58%, coarseCPU+4.41to+7.46%; report inconclusive. Original
cde core, source, desktop adverse results and raw B455 remain preserved.
One bounded refinement removes new control-op tests from all ordinary value
operations and gives the control instruction its own normal opcode handler.
No new framework/options/owner and no numerical/kernel/semantic change.
Same source pair baseline68, identical six jobs/settings/controls.76public/
61internal peractual11/10 pass. Source ordering/JIT changes preclude attributing
a timing difference to one branch. Explicit retain/correct/reject decision follows.
Space: fresh single-group inventory rejected alias paths before mutations;
resolved targets then verified inside intended base, with exact-byte SHA proof.
Atomic hardlinks preserve six targets/all aliases/contents and all archives,
free28,057,600B. Aliases verified again before this collection. No data deletion.
