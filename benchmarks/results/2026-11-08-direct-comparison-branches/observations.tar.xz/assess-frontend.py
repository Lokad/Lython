from pathlib import Path
import json,statistics
r=Path(__file__).parent;result={}
for phase in ['compile','fresh']:
 d=json.loads((r/(phase+'-sync')/'measurements.json').read_text())
 assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for o in d['observations']:
  roles={role:dict(milliseconds=statistics.median(s['elapsedMilliseconds']/s['jobs']for s in o['samples']if s['image']==role),allocation=statistics.median(s['allocatedBytes']/s['jobs']for s in o['samples']if s['image']==role))for role in ['before','before-control','candidate']}
  row=dict(case=o['caseId'],roles=roles,allocationPercent=[100*(roles['candidate']['allocation']/roles[b]['allocation']-1)for b in ['before','before-control']],elapsedPercent=[100*(roles['candidate']['milliseconds']/roles[b]['milliseconds']-1)for b in ['before','before-control']],oldSpreadPercent=100*(roles['before-control']['milliseconds']/roles['before']['milliseconds']-1))
  rows.append(row);print(phase,o['caseId'],'allocation%',*[round(v,3)for v in row['allocationPercent']],'elapsed%',*[round(v,3)for v in row['elapsedPercent']],'oldSpread',round(row['oldSpreadPercent'],3))
 result[phase]=rows
result['limitations']='Same-process ALC allocation diagnostic; normal GC/tiering, desktop elapsed uncontrolled. Fresh means compilation plus complete execution; compilation phase separate. No controlled CPU claim.'
(r/'assessment-frontend.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
