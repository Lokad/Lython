from pathlib import Path
r=Path('src/Lokad.Lython/Runtime')
p=r/'LythonRuntime.Executable.Inputs.cs';s=p.read_text(encoding='utf-8')
a=s.index('                if (instruction.OpCode == ExecutableOpCode.CompareJumpIfFalse)');z=s.index('                if (instruction.OpCode is ExecutableOpCode.StoreSubscript',a)
branch=s[a:z]
a2=s.index('        private static bool CompleteComparisonBranch(');z2=s.index('        private async ValueTask ExecuteCapturedValueOperationAsync(',a2)
completion=s[a2:z2]
s=s[:a2]+s[z2:];s=s[:a]+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
# Move the unchanged control operation into its own normal opcode handler. All
# ordinary value operations regain their original handler without the new test.
prefix='''using System.Runtime.CompilerServices;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        private static InstructionPause ExecuteComparisonInstruction(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, in ExecutableInstruction instruction, bool asynchronous,
            out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)
        {
            pending = default;
            pendingSpan = null;
            var inputs = ReadInstructionInputs(ref execution, instruction, scope, invocation);
            try
            {
'''
# Strip the now-redundant control opcode test and one indentation level.
body=branch.splitlines()[2:-1]
# The final closing line belongs to the opcode condition; retain its body only.
assert branch.splitlines()[0].strip()=='if (instruction.OpCode == ExecutableOpCode.CompareJumpIfFalse)'
assert branch.splitlines()[-1].strip()=='}'
body='\n'.join(line[4:]for line in branch.splitlines()[2:-1])
suffix='''            }
            catch { execution.Stack.RetireTo(instruction.LiveExtent); throw; }
        }

'''+completion+'''    }
}
'''
(r/'LythonRuntime.Executable.Comparisons.cs').write_text(prefix+body+'\n'+suffix,encoding='utf-8',newline='\r\n')
p=r/'LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
s=s.replace(' or ExecutableOpCode.CompareJumpIfFalse:\n', ':\n')
line='''                            if (instruction.OpCode == ExecutableOpCode.CompareJumpIfFalse) jumped = ConsumeOperation(ref pending);
'''
assert line in s;s=s.replace(line,'')
needle='''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented'''
assert needle in s
s=s.replace(needle,'''                        case ExecutableOpCode.CompareJumpIfFalse:
                            var comparisonPause = ExecuteComparisonInstruction(ref execution, scope, invocation, instruction, asynchronous,
                                out pending, out pendingSpan);
                            if (comparisonPause != InstructionPause.Continue) return comparisonPause;
                            jumped = ConsumeOperation(ref pending);
                            break;
'''+needle)
p.write_text(s,encoding='utf-8',newline='\r\n')
print('Ordinary value handler restored; comparison control has one dedicated existing-engine opcode handler, no new framework.')

