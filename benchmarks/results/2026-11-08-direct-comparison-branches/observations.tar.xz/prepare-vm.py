from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'shared-cased-split-r92/b453';b=r/'b455';b.mkdir()
source=json.loads((r/'identity.json').read_text());previous=json.loads((old/'identity.json').read_text())
identity={**previous,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification']}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('shared-cased-split-b453-20261108','direct-comparison-b455-20261108').replace('lython-b453-shared-cased-split','lython-b455-direct-comparison').replace('shared-cased-split-b453-launch.py','direct-comparison-b455-launch.py')
 if name=='collect.py':
  a=s.index('jobs=[');z=s.index('\n',a)
  s=s[:a]+'jobs='+repr([['scripts.csv-summary-functions.large','warm'],['scripts.csv-summary-functions.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.report-render.large','warm-async']])+s[z:]
  s=s.replace('R92 one shared existing casing-split recipe for ordinary/native execution; guarded text affected, fused/rsplit/CSV/report unchanged controls','R95 shared typed numeric comparison/ordered enum transport/direct comparison branches; CSV and JSON affected, text/report controls')
 if name=='launch.py':s=s.replace("reference=base/'direct-native-fusion-b451-20261108/candidate'","reference=base/'shared-cased-split-b453-20261108/candidate'")
 if name=='archive-owned.py':s=s.replace(",'dedup-proof.json'","")
 (b/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json')]:shutil.copyfile(src,b/name)
shutil.copytree(r/'new-sources',b/'new-sources')
contract='''R95 bounded source pair, not another CPython refresh. Exact fully qualified
05d81b83/core68f63d29 baseline, candidate frozen80143659 plus shared comparison and
conditional instruction migration. Same unchanged worker7cf37ca5/optional0.4.
Six complete jobs: CSV helper sync/async and returned records, JSON numeric
filter (affected), rsplit text/report (controls). All sources/fixtures/goldens
unchanged from R90. Five-second warmup per process/job, normal GC/tiering,
7x150ms rotated samples, two old/two current processes, coarse process CPU.
210s owner+30sstop+30smargin. Persistent raw/core/archive storage separate from
128MiB owned guest RAM. Existing exact baseline/auxiliary bytes hardlinked after
SHA proof; no old evidence/path/content deleted. Preflight240MiB OS floor+7MiB
trace/archive headroom and actual payload sizing. All source/Ready/runtime/full
golden/quiet/Closed/join/fixture/archive/local verification gates required.
Retain adverse/inconclusive results. Architectural deletion, allocation, elapsed/
CPU and controls are distinct; no fixed-percentage veto or universal speed claim.
Final source76public/61internal peractual11/10 includes 3CPython-golden programs
and real suspended comparison/truth cancellation, origin/alias/budget cleanup.
No public API change, unsafe code, new owner/cache/pool or alternative engine.
'''
(b/'contract.md').write_text(contract,encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','new-sources']:a.add(b/n,arcname=n)
print('B455 six unchanged complete-script jobs/exact source pair prepared; independent VM collection only.')

