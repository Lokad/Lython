from pathlib import Path
import re
root=Path('src/Lokad.Lython/Runtime')
p=root/'LythonRuntime.OperatorDispatch.cs';s=p.read_text(encoding='utf-8')
# Both public execution strategies use the same exact numeric comparison.
needle='''        if (op == BinaryOperatorSyntax.MatrixMultiply)'''
s=s.replace(needle,'''        if (TryEvaluateNumericComparison(op, left, right, context, span, out var numericComparison))
            return numericComparison;

'''+needle)
for op,method,reflected,test in [('Less','__lt__','__gt__','value < 0'),('LessEqual','__le__','__ge__','value <= 0'),('Greater','__gt__','__lt__','value > 0'),('GreaterEqual','__ge__','__le__','value >= 0')]:
 for suffix in ['', 'Async']:
  before=f'EvaluateRichComparison{suffix}(left, right, "{method}", "{reflected}", context, span, static value => {test})'
  assert before in s
  s=s.replace(before,f'EvaluateRichComparison{suffix}(left, right, op, context, span)')
a=s.index('    private static object EvaluateRichComparison(');z=s.index('    private static bool Contains(object container',a)
segment=s[a:z]
sig='''        string method,
        string reflectedMethod,
        ExecutionContext context,
        LythonSourceSpan span,
        Func<int, bool> fallback'''
assert segment.count(sig)==6,segment.count(sig)
segment=segment.replace(sig,'''        BinaryOperatorSyntax op,
        ExecutionContext context,
        LythonSourceSpan span''')
segment=segment.replace('method, reflectedMethod, context, span, fallback','op, context, span').replace('methods.Left, methods.Right, context, span, fallback','op, context, span')
segment=segment.replace('''                method,
                reflectedMethod,
                context,
                span,
                fallback''','''                op,
                context,
                span''')
segment=segment.replace('''                methods.Left,
                methods.Right,
                context,
                span,
                fallback''','''                op,
                context,
                span''')
segment=segment.replace('new BinarySpecialMethodPair(method, reflectedMethod),','op,')
segment=segment.replace('''            fallback,
''','')
segment=segment.replace('''        BinarySpecialMethodPair methods,
''','''        BinaryOperatorSyntax op,
''').replace('''        Func<int, bool> fallback,
''','')
segment=segment.replace('return fallback(left.Count.CompareTo(right.Count));','return CompareOrderedResult(op, left.Count.CompareTo(right.Count));').replace('return fallback(leftItems.Count.CompareTo(rightItems.Count));','return CompareOrderedResult(op, leftItems.Count.CompareTo(rightItems.Count));')
for name in ['method','methods.Left']:
 old=f'return CompareRelational(left, right, span, fallback, ComparisonSymbol({name}));'
 assert old in segment
 segment=segment.replace(old,'return CompareOrderedResult(op, PyComparison.Compare(left, right, span, ComparisonSymbol(op)));')
start=segment.index('    private static string ComparisonSymbol(')
segment=segment[:start]+segment[segment.index('    };',start)+7:]
needle='''    {
        // Sync twin of the async core below.'''
assert needle in segment
segment=segment.replace(needle,'''    {
        if (TryEvaluateNumericComparison(op, left, right, context, span, out var numericComparison)) return numericComparison;
        var methods = OrderedComparisonMethods(op);
        var method = methods.Left;
        var reflectedMethod = methods.Right;
        // Sync twin of the async core below.''',1)
pos=segment.index('    private static async ValueTask<object> EvaluateRichComparisonCoreAsync(')
core=segment[pos:];before='''    {
        if (left is PyCmpKey'''
assert before in core
core=core.replace(before,'''    {
        if (TryEvaluateNumericComparison(op, left, right, context, span, out var numericComparison)) return numericComparison;
        var methods = OrderedComparisonMethods(op);
        if (left is PyCmpKey''',1)
segment=segment[:pos]+core
# The ordered core never used a truth-evaluator parameter.
assert segment.count('evaluateTruthiness')==1
segment=segment.replace('''        BinarySpecialMethodInvoker invoke,
        TruthinessEvaluator evaluateTruthiness)''','''        BinarySpecialMethodInvoker invoke)''')
segment=segment.replace('''            InvokeBinarySpecialMethodAsync,
            IsTruthyAsync);''','''            InvokeBinarySpecialMethodAsync);''')
assert 'Func<int, bool>'not in segment and 'span, fallback'not in segment and 'return fallback('not in segment
s=s[:a]+segment+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'LythonRuntime.Resolution.cs';s=p.read_text(encoding='utf-8')
a=s.index('    private static bool CompareRelational(');z=s.index('    private static bool Contains(',a)
s=s[:a]+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
print('Shared numeric comparison; ordered helpers pass one enum instead of names/predicate; obsolete primitive fallback/truth parameter removed.')

