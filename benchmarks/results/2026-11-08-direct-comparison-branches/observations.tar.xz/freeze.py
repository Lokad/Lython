from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'shared-cased-split-r92'
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
d=json.loads((r.parent/'native-cpython-r90/representative.json').read_text(encoding='utf-8'))
ids=['scripts.csv-summary-functions.large','scripts.csv-validated-records.large','scripts.json-summary-helpers.large','scripts.text-summary-rsplit-helpers.large','scripts.report-render.large']
assert set(ids)<=set(c['id']for c in d['cases'])
d['cases']=[next(c for c in d['cases']if c['id']==i)for i in ids]
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks={}
for n,expected in [('public-strings11',76),('public-strings10',76),('internal-strings11',61),('internal-strings10',61)]:
 text=(r/(n+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in text and re.search(r'Passed:\s+'+str(expected)+r'\b',text)
 checks[n]=expected
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
identity=dict(baselineSource='05d81b83 fully qualified CI42467357131; metadata HEAD80143659',candidateSource='80143659 plus R95 direct comparison branches and ordered-comparison enum/typed logic',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=json.loads((old/'identity.json').read_text())['productionSources'],focusedChecks=checks,qualification='76 public semantics/61 internal ownership per actual11/10 final source; earlier646public pertarget includes cancellation/integer/protocol checks before the exact-string synchronous-path preservation. Full delivery pending.')
assert identity['coreSHA256']['before']=='68f63d2969afd9953fc848926685daea5a951996b942fa05a416227b2ab4bdb3'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests']))
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.NumericComparison.cs','tests/Lokad.Lython.PublicApi.Tests/ComparisonBranchTests.cs','tests/Lokad.Lython.Tests/ComparisonBranchOwnershipTests.cs']:
 p=r/'new-sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for n in ['measure.py','assess-local.py']:shutil.copyfile(old/n,r/n)
print(json.dumps(identity['coreSHA256']),'Final source frozen with focused gates; baseline/core/auxiliary worker unchanged.')

