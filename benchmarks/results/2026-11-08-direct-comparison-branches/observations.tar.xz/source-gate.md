# R95 source gate begun — not a prototype

Base committed05d81b83/core68f63d29, fully qualified CI42467357131, cached terminal.
R93 current CPU attribution and R94 sampled allocation are archived separately.
No current source change or performance claim.

Already checked:
- OperatorDispatch.cs EvaluateBinaryOperator/EvaluateBinaryOperatorAsync route
  order comparisons through general rich-comparison preparation, preserving raw
  custom results and reflected/NotImplemented semantics.
- EvaluateRichComparison enters ambient structural provenance before reaching
  exact numeric fallback; custom sets/counters/sequence comparisons need it.
- Resolution.cs CompareRelational already returns bool and uses
  PyNumberOps.TryCompare. Reuse this logic; do not invent another numeric kernel.
- PyNumberOps.TryCompare already handles NaN and exact mixed integer/float order.
- CompileIfStatement emits expression Binary then JumpIfFalse, same condition
  span. Check while/conditional/chained forms separately; no broad assumptions.
- ExecuteInputInstruction captures original operands and retains general
  asynchronous protocols. Conditional consumption must preserve that snapshot
  and the existing pending-cleanup continuations, managed admission and refusal.
- ExecutableInstruction is32bytes; do not enlarge every instruction or add a
  runtime side table merely for a speculative branch shortcut. Existing physical
  positions/result forwarding may support this; source gate must prove it.

Next: inspect all current comparison callers and conditional physical layout,
choose one shared typed boundary with removal of the old primitive fallback
branch, then implement direct native truth consumption only if spans/control/
cleanup fit. Dynamic/custom work stays original before effects, never retried.
No bool/integer cache, universal values, new owner/pool or alternate execution
engine. Preserve actual Python result objects when the comparison escapes.

Acceptance and bounded before/after controls are in ignored PLAN.md. This gate
is not complete; no retention or timing decision has been made.
