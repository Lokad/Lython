from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.OperatorDispatch.cs');s=p.read_text(encoding='utf-8')
for suffix in ['', 'Async']:
 lines=[]
 for op in ['Less','LessEqual','Greater','GreaterEqual']:
  call=f'EvaluateRichComparison{suffix}(left, right, op, context, span)'
  expression=call if not suffix else 'await '+call+'.ConfigureAwait(false)'
  lines.append(f'            BinaryOperatorSyntax.{op} => {expression},')
 before='\n'.join(lines);assert before in s
 s=s.replace(before,'            BinaryOperatorSyntax.Less or BinaryOperatorSyntax.LessEqual or BinaryOperatorSyntax.Greater or BinaryOperatorSyntax.GreaterEqual\n                => '+expression+',')
a=s.index('    private static ValueTask<object> EvaluateRichComparisonAsync(')
z=s.index('    private static async ValueTask<object> EvaluateRichComparisonCoreAsync(',a)
s=s[:a]+s[z:]
a=s.index('    private static async ValueTask<object> EvaluateRichComparisonCoreAsync(');z=s.index('    private static async ValueTask<bool> MultisetCompareAsync(',a)
segment=s[a:z].replace('EvaluateRichComparisonCoreAsync(', 'EvaluateRichComparisonAsync(')
assert segment.count('BinarySpecialMethodInvoker invoke')==1
segment=segment.replace('''        LythonSourceSpan span,
        BinarySpecialMethodInvoker invoke)''','''        LythonSourceSpan span)''')
assert segment.count('await invoke(')==4
segment=segment.replace('await invoke(', 'await InvokeBinarySpecialMethodAsync(')
s=s[:a]+segment+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
print('Removed ordered async forwarding wrapper/invoker transport; grouped identical relational dispatch.')

