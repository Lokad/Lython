from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;p=r/'dedicated-handler';p.mkdir()
for role in ['before','candidate']:shutil.copytree(r/'images/before',p/'images'/role,copy_function=os.link)
core=p/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
shutil.copyfile(r/'catalog.json',p/'catalog.json')
checks={}
for name,expected in [('public-dedicated11',76),('public-dedicated10',76),('internal-dedicated11',61),('internal-dedicated10',61)]:
 text=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in text and re.search(r'Passed:\s+'+str(expected)+r'\b',text);checks[name]=expected
base=json.loads((r/'identity.json').read_text())
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
identity={**base,'candidateSource':'80143659 plus R95 direct comparison migration with dedicated control handler after B455 text-control regression','coreSHA256':{role:hashlib.sha256((p/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},'productionSources':inventory,'focusedChecks':checks,'qualification':'76 public/61 internal focused Release peractual11/10 after dedicated-handler refinement. Full delivery pending.'}
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests']))
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.NumericComparison.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Comparisons.cs','tests/Lokad.Lython.PublicApi.Tests/ComparisonBranchTests.cs','tests/Lokad.Lython.Tests/ComparisonBranchOwnershipTests.cs']:
 path=p/'new-sources'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,path)
shutil.copyfile('PLAN.md',p/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
 s=(r/name).read_text(encoding='utf-8').replace("old=r.parent/'integer-utf8-r45'","old=r.parent.parent/'integer-utf8-r45'")
 (p/name).write_text(s,encoding='utf-8')
print(json.dumps(identity['coreSHA256']),'Original cde/B455 source/data preserved; one justified control-handler refinement frozen.')

