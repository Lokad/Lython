R95 bounded source pair, not another CPython refresh. Exact fully qualified
05d81b83/core68f63d29 baseline, candidate frozen80143659 plus shared comparison and
conditional instruction migration. Same unchanged worker7cf37ca5/optional0.4.
Six complete jobs: CSV helper sync/async and returned records, JSON numeric
filter (affected), rsplit text/report (controls). All sources/fixtures/goldens
unchanged from R90. Five-second warmup per process/job, normal GC/tiering,
7x150ms rotated samples, two old/two current processes, coarse process CPU.
210s owner+30sstop+30smargin. Persistent raw/core/archive storage separate from
128MiB owned guest RAM. Existing exact baseline/auxiliary bytes hardlinked after
SHA proof; no old evidence/path/content deleted. Preflight240MiB OS floor+7MiB
trace/archive headroom and actual payload sizing. All source/Ready/runtime/full
golden/quiet/Closed/join/fixture/archive/local verification gates required.
Retain adverse/inconclusive results. Architectural deletion, allocation, elapsed/
CPU and controls are distinct; no fixed-percentage veto or universal speed claim.
Final source76public/61internal peractual11/10 includes 3CPython-golden programs
and real suspended comparison/truth cancellation, origin/alias/budget cleanup.
No public API change, unsafe code, new owner/cache/pool or alternative engine.
