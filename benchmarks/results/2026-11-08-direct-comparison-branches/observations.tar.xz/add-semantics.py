from pathlib import Path
import json,subprocess
r=Path(__file__).parent
cases=[
('native-truth-and-escaped-values',"""pairs=[(0,0),(True,1),(2**100,float(2**100)),(2**100+1,float(2**100)),(float('nan'),0),(float('inf'),10**400),(-float('inf'),-10**400)]
for a,b in pairs:
 print(1 if a<b else 0,1 if a<=b else 0,1 if a>b else 0,1 if a>=b else 0,1 if a==b else 0,1 if a!=b else 0)
 print(a<b,a<=b,a>b,a>=b,a==b,a!=b)
count=0
while count<3:count+=1
print(count,[x for x in range(5) if x>=2])
"""),
('raw-results-reflection-and-order',"""events=[]
class Verdict:
 def __bool__(self):
  events.append('truth')
  return True
verdict=Verdict()
class Left:
 def __lt__(self,other):
  events.append('left')
  return verdict
 def __eq__(self,other):
  events.append('eq')
  return verdict
class Right(Left):
 def __gt__(self,other):
  events.append('reflected')
  return NotImplemented
left=Left()
right=Right()
stored=left<right
print(stored is verdict,events)
events.clear()
if left<right:events.append('branch')
print(events)
events.clear()
if left==right:events.append('equal branch')
print(events)
def value(label,result):
 events.append(label)
 return result
events.clear()
print(value('first',3)<value('middle',2)<value('last',4),events)
events.clear()
if value('first',1)<value('middle',2)<value('last',4):events.append('chain branch')
print(events)
"""),
('protected-failures-and-loops',"""events=[]
class Verdict:
 def __bool__(self):
  raise ValueError('truth failure')
class Left:
 def __lt__(self,other):return Verdict()
try:
 if Left()<0:events.append('wrong')
except ValueError as error:
 events.append(str(error))
finally:
 events.append('cleanup')
def check(value):
 try:
  if value<0:return 'negative'
  return 'nonnegative'
 finally:
  events.append('function cleanup')
print(check(-1),check(0))
for index in range(4):
 if index<2:continue
 events.append(index)
print(events)
"""),
]
goldens=[]
for name,source in cases:
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8')
 assert done.returncode==0,done.stderr
 goldens.append(dict(name=name,source=source,expected=done.stdout))
(r/'independent-goldens.json').write_text(json.dumps(goldens,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=['using Lokad.Lython.Tests.Harness;','','namespace Lokad.Lython.PublicApi.Tests;','','public sealed class ComparisonBranchTests','{','    // Independently captured with isolated CPython 3.13.','    public static TheoryData<string, string, string> Cases => new()','    {']
for g in goldens:lines.append('        { '+', '.join(json.dumps(g[k],ensure_ascii=False)for k in ['name','source','expected'])+' },')
lines+=['    };','', '''    [Theory]
    [MemberData(nameof(Cases))]
    public async Task ComparisonConditionsPreservePythonResults(string name, string source, string expected)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, name + ": " + string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, name + ": " + result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}''']
Path('tests/Lokad.Lython.PublicApi.Tests/ComparisonBranchTests.cs').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\r\n')
print('Three independent complete Python comparison goldens captured; both APIs and budget reuse will be checked.')

