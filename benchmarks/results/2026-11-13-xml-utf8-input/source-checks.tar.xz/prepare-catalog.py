from pathlib import Path
import base64, hashlib, json, struct, subprocess, tempfile
r = Path(__file__).parent
catalog = json.loads((r.parent / 'native-entry-ip-r327/catalog.json').read_text(encoding='utf-8'))
control = catalog['cases'][0]
source = '''import xml.etree.ElementTree as ET
with open('input.xml') as source:
    root = ET.fromstring(source.read())
total = 0
for row in root:
    total += int(row.get('count'))
with open('report.txt', 'w', newline='') as target:
    target.write(root.tag + '\\n')
    target.write(str(len(root)) + '\\n')
    target.write(str(total) + '\\n')
    target.write(root[0].text + '\\n')
print(len(root), total)
'''
n = 1024
value = 'café Ω😀 & tail ' * 8
escaped = value.replace('&', '&amp;')
input_bytes = ('<r>\n' + ''.join(f'<row count="{i}">{escaped}</row>\n' for i in range(n)) + '</r>\n').encode('utf-8')
total = n * (n - 1) // 2
output_bytes = f'r\n{n}\n{total}\n{value}\n'.encode('utf-8')
expected = f'{n} {total}\n'
fixture_data = json.loads(control['fixtureJson'])
fixture_data.update(size=n, text='', inputFiles={'input.xml': base64.b64encode(input_bytes).decode()}, outputFiles={'report.txt': base64.b64encode(output_bytes).decode()})
fixture = json.dumps(fixture_data, separators=(',', ':'), ensure_ascii=False)
sha = lambda s: hashlib.sha256(s.encode('utf-8')).hexdigest()
h = hashlib.sha256()
h.update(struct.pack('>i', 1)); name = b'report.txt'
h.update(struct.pack('>i', len(name))); h.update(name)
h.update(struct.pack('>i', len(output_bytes))); h.update(output_bytes)
case = dict(control)
case.update(id='scripts.xml-summary.large', scale='large', size=n, source=source, fixtureJson=fixture, expectedOutput=expected, sourceUtf8Bytes=len(source.encode('utf-8')), expectedOutputUtf8Bytes=len(expected.encode('utf-8')), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0, sourceSha256=sha(source), fixtureSha256=sha(fixture), expectedOutputSha256=sha(expected), expectedFilesSha256=h.hexdigest())
catalog['cases'] = [case, control]
(r / 'catalog.json').write_text(json.dumps(catalog, separators=(',', ':'), ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
with tempfile.TemporaryDirectory(prefix='xml-python-golden-', dir=r) as folder:
    p = Path(folder); (p / 'input.xml').write_bytes(input_bytes)
    done = subprocess.run(['C:/Python313/python.exe', '-I', '-X', 'utf8', '-c', source], cwd=folder, capture_output=True, text=True, encoding='utf-8')
    assert done.returncode == 0 and done.stdout == expected and done.stderr == '', (done.returncode, done.stdout, done.stderr)
    assert (p / 'report.txt').read_bytes() == output_bytes and (p / 'input.xml').read_bytes() == input_bytes
(r / 'python-golden.json').write_text(json.dumps(dict(python='3.13.2', rows=n, inputBytes=len(input_bytes), sourceSHA256=sha(source), fixtureSHA256=sha(fixture), stdout=expected, expectedOutputSHA256=sha(expected), expectedFilesSHA256=h.hexdigest(), exactFilesAndUnchangedInput=True, performanceNotMeasured=True), indent=2) + '\n', encoding='utf-8', newline='\n')
print('Complete XML file summary:', len(input_bytes), 'UTF8 input bytes,', n, 'records; independent arithmetic/stdout/file goldens pass CPython3.13.2.', flush=True)
