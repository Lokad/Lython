from pathlib import Path
import hashlib, json, subprocess
r = Path(__file__).parent
config = json.loads((r / 'config.json').read_text(encoding='utf-8'))
code = '''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
config=CONFIG
root=Path(config['root']);base=root.parent.resolve();assert root.resolve()==root and root.parent==base
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0' in service and 'ActiveState=active' not in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 fixture=root/'guest-fixtures';assert fixture.resolve(strict=True)==fixture and fixture.is_relative_to(base)and not list(fixture.iterdir())
 assert not(root/'observations.tgz').exists()
 paths=[p for p in root.rglob('*')if p.is_file()and p.suffix!='.dll'and not {'candidate','reference'}&set(p.relative_to(root).parts)]
 raw={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
 with tarfile.open(root/'observations.tgz','w:gz')as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(root)))
 with tarfile.open(root/'observations.tgz')as t:
  for name,sha in raw.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 free=shutil.disk_usage(root).free;assert free>252*1024*1024
 receipt=dict(complete=False,failedBeforeWorkerReady=True,timingSamplesCollected=False,allWorkersJoined=True,guestFixturesRemoved=True,rawArchiveVerifiedBeforeUnmount=True,finalMachineGateNotRun=True,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),freeBytes=free,service=service)
 (root/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n')
 print(json.dumps(receipt))
'''.replace('CONFIG', repr(config))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
done = subprocess.run(ssh + ['python3 -'], input=code, text=True, encoding='utf-8', capture_output=True)
assert done.returncode == 0, done.stderr
(r / 'failure-terminal-status.json').write_text(done.stdout, encoding='utf-8', newline='\n')
receipt = json.loads(done.stdout)
scp = ['C:/Windows/System32/OpenSSH/scp.exe', '-i', ssh[2], '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
for name in ['observations.tgz', 'failure-receipt.json']:
    done = subprocess.run(scp + ['lokad@20.166.121.73:' + config['root'] + '/' + name, str(r / name)], capture_output=True)
    assert done.returncode == 0, done.stderr
assert hashlib.sha256((r / 'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
print('Failed B696 archived and SHA-verified; no timing samples, all users joined, empty RAM fixture unmounted.', flush=True)
