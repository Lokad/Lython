from pathlib import Path
import hashlib, json, shutil, tarfile
r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-13-xml-utf8-input'); out.mkdir(exist_ok=True)
identity = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
assert len(identity['sources']) == 577
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in identity['sources'].items())
for label in ['reference', 'candidate']:
    worker = json.loads((r / ('worker-' + label + '-validation.json')).read_text(encoding='utf-8'))
    assert worker[1]['status'] == 'Equivalent' and worker[2]['status'] == 'Closed'
for stem in ['b696', 'b697']:
    folder = out / stem; folder.mkdir(exist_ok=True)
    for name in ['observations.tgz', 'failure-receipt.json', 'failure-terminal-status.json', 'archive-receipt.json', 'terminal-status.json', 'summary.json']:
        if (r / stem / name).exists(): shutil.copy2(r / stem / name, folder / name)
summary = json.loads((r / 'b697/summary.json').read_text(encoding='utf-8'))
assert summary['complete']
names = ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','freeze.py','freeze-build.log','check.py','internal-net11.0.log','internal-net10.0.log','public-net11.0.log','public-net10.0.log', 'prepare-catalog.py','correct-manifest.py','catalog.json','python-golden.json','allocation-catalog.json','allocation-python-golden.json','manifest-correction.json','measure-allocation.py','allocation-summary.json','verify-workers.py','worker-reference-validation.json','worker-candidate-validation.json','worker-reference.stderr','worker-candidate.stderr','worker-reference-fixture.json','worker-candidate-fixture.json','local-worker-validation-corrections.json','b697-launch-template.py','prepare-b697.py','save.py']
names += [p.name for p in r.glob('*-allocation-*.*')]
with tarfile.open(out / 'source-checks.tar.xz', 'w:xz') as t:
    for name in dict.fromkeys(names): t.add(r / name, arcname=name)
    for p in (r / 'candidate').glob('Allocation.*'):
        t.add(p, arcname='unchanged-allocation-tool/' + p.name)
    for stem in ['b696', 'b697']:
        for name in ['config.json','launch-command.py','launch.log','retrieve.py','summarize.py','archive-failure.py','failure-inspection.json','worker-errors.json']:
            if (r / stem / name).exists(): t.add(r / stem / name, arcname=stem + '/' + name)
shutil.copy2(r / 'allocation-summary.json', out / 'allocation-summary.json')
shutil.copy2(r / 'b697/summary.json', out / 'summary.json')
print('Archived source-specific checks, allocations, original failed VM condition and corrected comparison.', flush=True)
