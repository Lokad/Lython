from pathlib import Path
import ast, hashlib, json, tarfile
r = Path(__file__).parent
old = r / 'b696'; out = r / 'b697'; out.mkdir()
root = '/home/lokad/lython-bench-checks/xml-utf8-input-b697-20261113'
source_root = '/home/lokad/lython-bench-checks/xml-utf8-input-b696-20261113'
unit = 'lython-b697-xml-utf8-input-20261113'
identity = json.loads((old / 'identity.json').read_text(encoding='utf-8'))
identity['catalogSHA256'] = hashlib.sha256((r / 'catalog.json').read_bytes()).hexdigest()
identity['purpose'] += '; corrected required fixture size/text fields after B696 failed before Ready; identical frozen runtimes and guest bytes'
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    s = (old / name).read_text(encoding='utf-8').replace(source_root, root).replace('lython-b696-xml-utf8-input-20261113', unit).replace('B696', 'B697')
    if name == 'archive-owned.py':
        s = s.replace("'current-core.dll','reference-core.dll'", "'current-core.dll','candidate-core.dll','reference-core.dll'")
    if name.endswith('.py'): ast.parse(s)
    (out / name).write_text(s, encoding='utf-8', newline='\n')
with tarfile.open(out / 'payload.tgz', 'w:gz') as t:
    for name in ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']: t.add(out / name, arcname=name)
    t.add(r / 'catalog.json', arcname='representative.json')
    t.add(r / 'manifest-correction.json', arcname='manifest-correction.json')
with tarfile.open(out / 'payload.tgz') as t: unpacked = sum(m.size for m in t.getmembers())
config = dict(root=root, sourceRoot=source_root, unit=unit, identity=identity, payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((out / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=unpacked)
(out / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8')
print('Prepared corrected manifest; frozen images reused; no core upload or historical working-image deletion.', flush=True)
