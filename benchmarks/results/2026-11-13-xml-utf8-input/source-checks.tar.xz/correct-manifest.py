from pathlib import Path
import hashlib, json, runpy
r = Path(__file__).parent
for source, target in [('catalog.json', 'allocation-catalog.json'), ('python-golden.json', 'allocation-python-golden.json')]:
    assert not (r / target).exists()
    (r / target).write_bytes((r / source).read_bytes())
before = json.loads((r / 'catalog.json').read_text(encoding='utf-8'))
runpy.run_path(str(r / 'prepare-catalog.py'))
after = json.loads((r / 'catalog.json').read_text(encoding='utf-8'))
for left, right in zip(before['cases'], after['cases']):
    assert left['id'] == right['id'] and left['source'] == right['source'] and left['expectedOutput'] == right['expectedOutput']
    a, b = json.loads(left['fixtureJson']), json.loads(right['fixtureJson'])
    assert a['inputFiles'] == b['inputFiles'] and a['outputFiles'] == b['outputFiles']
(r / 'manifest-correction.json').write_text(json.dumps(dict(reason='Worker fixture schema requires size metadata; preserve valid template fields and text type.', originalArchive='b696/observations.tgz', originalAllocationCatalogSHA256=hashlib.sha256((r / 'allocation-catalog.json').read_bytes()).hexdigest(), correctedWorkerCatalogSHA256=hashlib.sha256((r / 'catalog.json').read_bytes()).hexdigest(), guestSourcesStdoutAndFileBytesUnchanged=True, runtimeImagesUnchanged=True, allocationDiagnosticUsesPublicAPIWithoutFixtureGlobals=True, cpuOrTimingNotInferredFromManifestCorrection=True), indent=2) + '\n', encoding='utf-8', newline='\n')
