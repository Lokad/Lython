from pathlib import Path
import hashlib, json, os, struct, subprocess, tempfile
r = Path(__file__).parent
identity = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
catalog = json.loads((r / 'catalog.json').read_text(encoding='utf-8'))
case = catalog['cases'][0]
env = dict(os.environ)
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['PATH'] = env['DOTNET_ROOT'] + ';C:/Python313;' + env['PATH']
fixture = (r / 'worker-validation-fixtures').resolve(); fixture.mkdir(exist_ok=True)
env['TEMP'] = env['TMP'] = str(fixture)
def message(operation, number):
    data = json.dumps(dict(protocolVersion=2, requestId=number, operation=operation, caseId=case['id'], lane='warm', iterations=1, **{k: case[k] for k in ['sourceSha256', 'fixtureSha256', 'expectedOutputSha256']})).encode()
    return struct.pack('>I', len(data)) + data
for role in ['reference', 'candidate']:
    image = (r / role).resolve()
    folder = tempfile.TemporaryDirectory(prefix='lython-comparison-files-', dir=fixture)
    folder_root = Path(folder.name).resolve()
    assert folder_root.parent == fixture and folder_root.is_relative_to(Path.cwd().resolve()) and folder_root.name.startswith('lython-comparison-files-')
    process = subprocess.Popen([env['DOTNET_ROOT'] + '/dotnet.exe', str(image / 'Lokad.Lython.Benchmarks.dll'), '--compare', 'worker', '--catalog', str((r / 'catalog.json').resolve())], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=folder.name)
    try: output, error = process.communicate(message('verify', 1) + message('quit', 2), timeout=30)
    except BaseException:
        process.kill(); process.communicate(); raise
    (r / ('worker-' + role + '.stderr')).write_bytes(error)
    assert process.returncode == 0, error.decode('utf-8', errors='replace')
    rows = []
    while output:
        size = struct.unpack('>I', output[:4])[0]
        rows.append(json.loads(output[4:4+size])); output = output[4+size:]
    assert len(rows) == 3 and rows[1]['status'] == 'Equivalent' and rows[2]['status'] == 'Closed', rows
    core = next(v for v in rows[0]['libraries'] if Path(v['path']).name == 'Lokad.Lython.dll')
    assert core['sha256'] == identity['coreSHA256'][role]
    assert rows[1]['actualOutputSha256'] == case['expectedOutputSha256'] and rows[1]['actualFilesSha256'] == case['expectedFilesSha256']
    (r / ('worker-' + role + '-validation.json')).write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
    (r / ('worker-' + role + '-fixture.json')).write_text(json.dumps([str(p.relative_to(folder_root)) for p in folder_root.rglob('*')], indent=2) + '\n', encoding='utf-8')
    folder.cleanup()
    print(role, 'Ready / exact stdout+files Equivalent / Closed; actual worker joined.', flush=True)
assert not list(fixture.iterdir()); fixture.rmdir()
