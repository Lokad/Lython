from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
selection='Category!=Stress&(FullyQualifiedName~CasedWhitespacePipelineTests|FullyQualifiedName~ImmediateCasedSplitIterationTests|FullyQualifiedName~DictionaryCountingLoopTests|FullyQualifiedName~NativeWordBindingTests|FullyQualifiedName~Comprehension|FullyQualifiedName~Cleanup|FullyQualifiedName~CallExpansion|FullyQualifiedName~GeneratorClose)'
log=r/'cleanup-public.log'
with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--filter',selection,'--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
print(done.returncode,'\n'.join(log.read_text(encoding='utf-8').splitlines()[-16:]),flush=True);assert done.returncode==0
