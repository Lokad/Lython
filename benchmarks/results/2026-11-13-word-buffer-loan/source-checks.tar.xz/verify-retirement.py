from pathlib import Path
import hashlib,os,subprocess
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs');fixed=p.read_bytes();s=fixed.decode('utf-8');a=s.index('                else if (_items[i] is ExecutableTemporaryValue temporary)\n');b=s.index('\n            }',a)
old=s[:a]+'                else if (_items[i] is ExecutableTemporaryValue temporary) temporary.Dispose();'+s[b:]
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];sdk=env['DOTNET_ROOT']+'/dotnet.exe';project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'
try:
 p.write_text(old,encoding='utf-8',newline='\n')
 with(r/'retirement-original-failure.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test',project,'-c','Release','-f','net11.0','--filter','FullyQualifiedName~WordBufferLoanTests.FailedReentrantRetirementDoesNotDisposeTheNewBorrowerOnRetry','--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
 assert done.returncode!=0,'Original retirement unexpectedly passed the new lifetime regression'
 print('Original retirement fails:', '\n'.join((r/'retirement-original-failure.log').read_text(encoding='utf-8').splitlines()[-13:]),flush=True)
finally:p.write_bytes(fixed)
assert p.read_bytes()==fixed
with(r/'retirement-fixed-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build',project,'-c','Release','-f','net11.0','--no-incremental','--disable-build-servers','--nologo','-m:1'],stdout=f,stderr=subprocess.STDOUT,env=env)
assert done.returncode==0,(r/'retirement-fixed-build.log').read_text(encoding='utf-8')[-1500:]
with(r/'retirement-fixed-tests.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test',project,'-c','Release','-f','net11.0','--no-build','--filter','Category!=Stress&(FullyQualifiedName~WordBufferLoanTests|FullyQualifiedName~DictionaryCountingLoopAdmissionTests|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~WhitespaceStorageOwnershipTests)','--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
print('Fixed retirement:', '\n'.join((r/'retirement-fixed-tests.log').read_text(encoding='utf-8').splitlines()[-10:]),flush=True);assert done.returncode==0
(r/'restored-proof.txt').write_text('Exact fixed source restored before forced nonincremental build. SHA256='+hashlib.sha256(fixed).hexdigest()+'\n',encoding='utf-8',newline='\n')
