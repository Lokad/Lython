from pathlib import Path
import json
r=Path(__file__).parent;delivery=json.loads((r.parent/'json-byte-input-r322/corrected-source.json').read_text(encoding='utf-8'))
s='''# Lokad.Lython 0.11.0

Updated 2026-11-13. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. An isolated experiment or green CI does not finish it.

## Actual status

| State | Evidence and limit |
| --- | --- |
| Committed and fully qualified | **R319 runtime976f9439/tests307f6f41/frozen97bb**, GREEN43465190359: Windows/Ubuntu actual.NET11/10 ordinary, original stress and installed Release consumers.575frozen inputs source-match; logs/16summaries cached. [Delivery](benchmarks/results/2026-11-13-positional-zip/delivery/README.md). Reuse completed qualification. |
| Committed; corrected full delivery running | **R322 runtime23a65e9e/testsdbcd4051/frozenbff487b5**,576inputs source-match. Initial43473827059 fails only five stale diagnostic assertions per platform;4691white-box and17597/17602public pass. Corrected135focused checks per actual11/10 pass. **DELIVERY** covers both platforms/targets/stress/installed consumers; no runtime/timing replay. [Source/checks/failed conditions](benchmarks/results/2026-11-13-json-byte-input/README.md). |
| Active prototype | **R324 word buffer/cursor consolidation**, three production files changed afterdbcd.190internal/311public initial checks; ordinary retirement then corrected to clear its slot before disposal. New reentrant-loan regression fails old retirement and passes with47focused lifetime/admission cases after exact restoration/nonincremental build. No CPU/allocation benefit claimed yet. |
| Current external evidence | **B683 qualifiedcb8736ff/frozen5a18**,2026-11-13, stockCPython3.13.16, quietF4as_v7;7jobs/296.496s/all gates. Invoice warm1.25–1.27×, compile1.09–1.11×, fresh1.21–1.24×; captured text1.60–1.63×, search1.68–1.72×, JSON0.84–0.86×, report1.21–1.25×(variable). [Sources/boundaries/uncertainty](benchmarks/results/2026-11-13-fixed-definitions-cpython-checkpoint/README.md). Later prototypes are excluded. |

## Completed milestones and retained debt

- Shared compiler facts/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. Direct UTF8 storage/formatting and native helper
  returns are delivered with source-specific qualification. Formatting allocation−8.67%
  is distinct from the original adverse15.125ms and later CPU-supported comparisons.
  Helper allocation−19.92%Run/−19.31%Async is distinct from diagnostic elapsed gains.
- Native calls use final slots and the existing linear continuation runner. Separate
  graph/proof/evaluation and redundant selection/logical admission are removed.
  Preserve measured sync optimizations and corrected small-stack depth handoff;
  slower call-arena/control designs and original crashes remain history.
- Tuple return/unpack and40d integer chains are qualified. Integer chains remove
  16384boxes/524288B per4096invoice records (−8.46..−8.48%allocation); report CPU debt
  remains uncertain. R317 invocation definitionscb/90de are fully qualified; historical
  factory−25.06%allocation is that factory, not a whole-script gain. No repeated qualification.
- Revised bulk CSV construction already shipped (historical6–8%opportunity). Current
  rows adopt funded arrays/keys; JSON construction is iterative. R308shared fields and
  R314window grants are withdrawn; useful lifetime regressions survive. Preserve all
  original/refined/adverse evidence; percentages do not permanently reject a design.
- R319 removes whole-archive retention on positional hosts using one parser and
  genuine async operations. ZIP64/overlap/header/index fixes survive. B685large ZIP
  elapsed−77..79% has wider CPU support; small ZIP+2.2–2.5µselapsed is accepted debt,
  broader small CPU uncertain. Original partial/image/CI failures remain linked.
- R322 adds native bytes/binary JSON, Python UTF8/16/32 detection and funded windows;
  obsolete text-only readers are deleted. It removes a required guest decode call and
  duplicate payload charging; old full-array UTF8 decode already could share storage.
  B687str control is adverse; split cold bytes/remove duplicate str check. B688/B689
  remain uncertain: longer1s confirmation spans−2.97..+4.10%elapsed/−3.46..+5.28%widerCPU.
  Retain compatibility/ownership benefits with this small unresolved debt and no
  CPU/allocated-byte win claim. Finalbff differs from timed5fc only in arity wording;
  final-source timing is not inferred. Stop unchanged retiming for this iteration.

Detailed evidence, failed conditions and rejected forms live in immutable results
and [EXPERIMENTS](benchmarks/EXPERIMENTS.md), not current guides or this active plan.

## Prioritized deliverables

1. **Close R322 corrected delivery.** Track DELIVERY minutes apart; cache terminal.
   Initial stale assertions and exact576source proof are preserved. Do not requery
   terminal runs or repeat unchanged successful focused tests/comparisons. Advance
   independent runtime work while full qualification runs; publication stays held.

2. **R324: one owned word-buffer/cursor loan.** R321CPU profiles identify word
   preparation11.73%and dictionary loop18.74%of captured-text guest samples; owning
   frames include useful work. [R323 allocation origins](benchmarks/results/2026-11-13-allocation-origins/README.md)
   resolve1989/2016text and1286/1408search triggers. Per-line cursor/reservation packets
   are concrete; sampled trigger types are not exact byte/CPU shares and loss is unknown.
   Consolidate the existing range-array cache and private cursor state into one loan.
   Remove per-line cursor construction/transaction wrapper and separate array-cache
   ownership; add no second pool, return dispatcher, policy or configuration.
   Preserve eager complete word admission, Unicode/sigma/whitespace, final bindings,
   dynamic fallback, nested/reentrant/suspended users, cancellation/terminal refusal,
   capacity/replacement funding and retained immutable words. Idle loans clear guest
   references; ending reuse keeps active loans funded. Ordinary retirement now clears
   slots before cleanup, matching native/async ownership transfer; preserve its regression.
   Finish affected lifetime/cleanup checks, one short whole-script allocation diagnostic,
   then one bounded quiet-VM captured-text comparison with unchanged search. Admit
   larger plain-split buffer metadata conservatively; tiny thresholds may change.
   Stop at a coherent storage removal and an explicit decision on any remaining debt.

3. **Continue substantial construction/transport redesigns from demonstrated costs.**
   Each selected design names eliminated work/storage/pass, affected complete scripts,
   semantics, displaced code and a bounded source-pair comparison with controls.
   New attribution or observability can justify confirmation/refinement; no blind inventories.

   | Area | Remaining design boundary |
   | --- | --- |
   | Calls/frames/operands | Search CPU dispatch14.54%and native entry7.93%matter, but sampled allocations mainly line text/bytes/counters. Existing binding already uses final slots/prepared default names; do not rebuild an arena. Caller free slots3vs callee6(search),7vs12(invoice) are real boundaries. A migration must remove a demonstrated activation/packet/workspace, preserve defaults/receivers/closures/error order and exact suspension transfer, and keep the256KiB continuation safe. |
   | Scalars/per-record collections | Native dictionary updates already share one probe/unboxed counters; current CSV/JSON and UTF8 formatting/casing remove old intermediates. Select an actual remaining representation/pass before a new counter store or universal tagged-value rewrite. Preserve identity, promotion, eager errors, hooks, aliases and bounded host batches. |
   | Frontend | Duplicate name strings model only0.41–0.95%allocation, not removable CPU. Find repeated substantive facts/retained IR before caches or visitor merges; preserve flow diagnostics, binding/annotation facts, cancellation and admission. Include compile-to-result, not warm clocks alone. |

4. **Regex remains independent.** The core Python-specific UTF8 contract covers
   frontend/runtime/imports, original windows, byte/scalar positions, flags/captures/errors,
   current-token work and explicit cache/result ownership. Continue implementation/testing
   independently of producer publication; adapter-local bridges/pinned development releases
   are allowed. Dev80/15b248dc changed-source checks88internal/534public per11/10 are complete;
   normal29inputs/binaries/core are unchanged, normal optional pin0.4/nonpackable remains.
   Precise producer gaps: separate one-match working/result owners; UTF8 group-name
   enumeration/copy (lookup exists); token-independent cursor construction with cancellable
   preparation. Defer only affected final adapter qualification. Distinguish contract/semantic
   checks from actual backend performance/safety. Cached patterns retain no prior token.

5. **R320 later: ordinary XML scripts.** Reuse ElementTree for namespace-aware .//,
   document-order iter(tag), mixed-text itertext, clear and iterparse start/end events.
   Preserve depth1024, DTD/entity containment, explicit unsupported selectors, Python
   errors, cancellation/refusal, joined owned inputs and borrowed-stream ownership.
   clear must not refund retained aliases or introduce tracing; document conservative
   command retention/earlier denial. Long scans use host-batch ownership, not promised
   constant charged memory after arbitrary reference withdrawal. Validate CPython goldens,
   fragmented input/events, depth/errors, early close, refusal and retained aliases.

## Evidence policy and lasting constraints

Distinguish simplification, allocation reduction and demonstrated CPU improvement.
Fixed percentages inform decisions; they do not veto useful changes. Timeouts, unstable
unchanged controls and inconclusive measurements establish uncertainty. Allow bounded
confirmation/refinement/correction with reasons and original/adverse conditions retained;
no one-attempt/no-retiming/permanent-closure rules. Temporary setbacks need a named
completion milestone and a decision on regression debt. Full/stress/platform/installed
Release qualification is batched at delivery; short focused Release checks during iteration.

Remain fully managed/memory-safe: no unsafe compilation/C#/APIs, pointers, P/Invoke or
native probing. Preserve managed stack/recursion safety, cancellation, capabilities/original
paths+Cwd, cycles/XML depth, checked bounds and bounded I/O chunks. No fuel/quotas, hidden
caps/default allowance, regex work/time policies, tracing, weak reclamation, forcedGC or
abandoned work. Borrowed shared allowance funds capacity, overlap, aliases/results/caches
and pending users. First refused admission is terminal through suppression/finally;
preserve its structured origin, await cleanup and never retry. See [AGENTS](AGENTS.md).
Force nonincremental builds after restoration. Copy mutable benchmark images; verify all
workers/adapters, not only core. Persist evidence, join users and SHA-verify RAM archives
before unmount. Preserve VM floors/current images. Current docs stay concise/Lython-centric.
'''
s=s.replace('DELIVERY','['+delivery['runId']+']('+delivery['url']+')')
Path('PLAN.md').write_text(s,encoding='utf-8',newline='\n')
print('PLAN refreshed:',len(s.splitlines()),'lines; completed history retained, delivery/prototype/uncertainty separated')
