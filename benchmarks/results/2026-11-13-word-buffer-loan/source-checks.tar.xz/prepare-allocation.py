from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'json-byte-input-r322/final';baseline=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sources={p:sha(p)for p in baseline['sources']}
assert sorted(p for p in sources if sources[p]!=baseline['sources'][p])==sorted(['src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs'])
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH'];sdk=env['DOTNET_ROOT']+'/dotnet.exe'
with(r/'benchmark-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],stdout=f,stderr=subprocess.STDOUT,env=env)
assert done.returncode==0 and sources=={p:sha(p)for p in sources},(r/'benchmark-build.log').read_text(encoding='utf-8')[-2000:]
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate-core.dll')
for role in ['candidate','reference']:
 out=r/role;out.mkdir()
 for p in (r.parent/'zip-positional-r319/candidate').iterdir():
  if p.is_file():shutil.copyfile(p,out/p.name)
 shutil.copyfile(r/'candidate-core.dll'if role=='candidate'else prior/'candidate-core.dll',out/'Lokad.Lython.dll')
shutil.copyfile(r.parent/'next-profile-r321/catalog.json',r/'catalog.json')
with(r/'allocation-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build',str(r/'allocation/Allocation.csproj'),'-c','Release','--nologo'],env=env,stdout=f,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'allocation-build.log').read_text(encoding='utf-8')[-2000:]
build=r/'allocation/bin/Release/net11.0'
for role in ['reference','candidate']:
 for p in build.iterdir():
  if p.is_file()and p.name.startswith('Allocation.')and p.suffix!='.pdb':shutil.copyfile(p,r/role/p.name)
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=576,auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},catalogSHA256=sha(r/'catalog.json'),qualified=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
print('Frozen',identity['coreSHA256'],'576inputs; identical fixed workers/adapters/allocation tool')
