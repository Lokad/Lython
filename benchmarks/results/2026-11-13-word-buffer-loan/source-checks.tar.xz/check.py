from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
for label,project,selection in [('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','FullyQualifiedName~Whitespace|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~DictionaryCountingLoopAdmissionTests|FullyQualifiedName~DirectStringSplitTests|FullyQualifiedName~SeparatedSplitOwnershipTests|FullyQualifiedName~FullCaseExpansionTests|FullyQualifiedName~WordBufferLoanTests'),('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','FullyQualifiedName~CasedWhitespacePipelineTests|FullyQualifiedName~ImmediateCasedSplitIterationTests|FullyQualifiedName~DictionaryCountingLoopTests|FullyQualifiedName~NativeWordBindingTests|FullyQualifiedName~Whitespace|FullyQualifiedName~DeferredSplitBehaviorTests|FullyQualifiedName~SplitLifetimeScenarioTests|FullyQualifiedName~DirectStringSplitExecutionTests|FullyQualifiedName~SeparatedStringSplitTests|FullyQualifiedName~FullCaseExpansionExecutionTests')]:
 log=r/(label+'-focused.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',project,'-c','Release','-f','net11.0','--filter',selection,'--nologo'],stdout=f,stderr=subprocess.STDOUT,env=env)
 print(label,done.returncode,'\n'.join(log.read_text(encoding='utf-8').splitlines()[-18:]),flush=True)
 assert done.returncode==0
