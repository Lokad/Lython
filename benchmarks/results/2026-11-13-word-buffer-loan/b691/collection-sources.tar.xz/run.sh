cd /home/lokad/lython-bench-checks/word-buffer-loan-b691-20261113
python3 -u collect.py > collection.log 2>&1
code=$?
printf "%s\n" "$code" > exit-code.txt
exit "$code"
