from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
terminal=json.loads((r.parent.parent/'zip-positional-r319/corrected-delivery/ci-terminal.json').read_text(encoding='utf-8'));assert terminal['conclusion']=='success'
identity=json.loads((r.parent/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
assert hashlib.sha256((r.parent/'candidate-core.dll').read_bytes()).hexdigest()==config['identity']['coreSHA256']['candidate']
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['candidateAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(source/'reference/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free
 old=base/config['retire']['path'];st=old.lstat()
 assert old.resolve(strict=True)==old and old.is_relative_to(base)and old.is_file()and not old.is_symlink()and st.st_uid==os.getuid()and st.st_nlink==1 and st.st_size==config['retire']['bytes']and digest(old)==config['retire']['sha256']
 assert before+st.st_blocks*512>254*1024*1024+config['unpackedBytes']
 old.unlink()
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
  assert set(t.getnames())=={'collect.py','archive-owned.py','run.sh','identity.json'}
  t.extractall(root,filter='data')
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name in ['cpython-worker.py','representative.json','source-identity.json']:os.link(source/name,root/name)
 os.link(source/'reference-source-identity.json',root/'reference-source-identity.json')
 for role in ['candidate','reference']:
  (root/role).mkdir()
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():
   assert digest(source/'candidate'/name)==sha;os.link(source/'candidate'/name,root/role/name)
  os.link(source/role/'Lokad.Lython.dll',root/role/'Lokad.Lython.dll')
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=after,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b691-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+["python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,done.stderr
print(done.stdout.decode(),flush=True)
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=150)).isoformat(),ownerSeconds=180,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
