from pathlib import Path
import ast,hashlib,json,tarfile

notes=Path(__file__).parent;old=notes/'fresh-config-r386';r=notes/'async-cpython-r393';r.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
runtime=notes/'invocation-lifetime-r390';f=json.loads((runtime/'candidate-identity.json').read_text(encoding='utf-8'))
delivery=json.loads((runtime/'delivery/delivery-candidate.json').read_text(encoding='utf-8'))
assert all(sha(p)==h for p,h in f['sources'].items())
config=json.loads((old/'config.json').read_text(encoding='utf-8'))
remote_old='fresh-config-b774-20261115';remote_new='async-cpython-b780-20261115';unit_old='lython-b774-fresh-config-20261115';unit_new='lython-b780-async-cpython-20261115'
identity=dict(sourceRevision=delivery['head']+'/frozenf304b3db',runtimeCommit=delivery['head'],purpose='Targeted primary CPython baseline for public RunAsync on existing complete text and protected file-search scripts. Completed host I/O, no startup/pending-I/O/source-pair gain claim.',
              coreSHA256={label:f['coreSHA256']['candidate']for label in ['candidate','candidate-control']},auxiliaryFiles=json.loads((runtime/'quiet/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],
              catalogSHA256=sha(runtime/'catalog.json'),runtimeSourceIdentitySHA256=sha(runtime/'candidate-identity.json'),runtimeSourceProofSHA256=sha(runtime/'delivery/source-proof.json'),qualification='Focused Release actual.NET11/10 passed; full43700041511 currently in progress, terminal not yet claimed.',
              apiBoundary='Lython warm-async versus CPython warm, same source/goldens',publicationHeld=True)
config.update(root=config['root'].replace(remote_old,remote_new),sourceRoot='/home/lokad/lython-bench-checks/invocation-lifetime-b777-20261115',catalogRoot='/home/lokad/lython-bench-checks/invocation-lifetime-b777-20261115',unit=unit_new,identity=identity)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(question='What is the current complete-script cost of public RunAsync against stock CPython, missing from the primarily synchronous table?',
                   cases=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.file-search.large.protected'],
                   boundary='Lython awaited RunAsync with completed benchmark host I/O; CPython synchronous warm execution. Same source/inputs/goldens, two independent processes per engine, five rotating rounds. Guest clocks include mediated RAM I/O, full validation and prior-result cleanup; reset/protocol/startup/compile/final cache cleanup excluded.',
                   warmupSeconds=5,textWarmupSeconds=12,targetRequestSeconds=.5,ownerSeconds=180,
                   stoppingCriterion='Finish these two targeted deployment comparisons, retain uncertainty and all controls. Reuse earlier named-revision compile/fresh measurements; do not infer a whole-HEAD or source-pair speedup.',noNewRuntimeFrameworkOrImageUpload=True,publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(remote_old,remote_new).replace(unit_old,unit_new).replace('B774','B780')
    if name=='collect.py':
        start=text.index('\njobs=')+1;end=text.index('\nenv =',start)
        text=text[:start]+'jobs='+repr([[case,'warm-async-vs-cpython-warm']for case in prospective['cases']])+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+text[end:]
        text=text.replace("{'reference','reference-control','candidate','candidate-control'}","{'candidate','candidate-control'}")
        text=text.replace('label, case, lane, 0',"label, case, ('warm' if label.startswith('CPython') else 'warm-async'), 0")
        text=text.replace('identities={w.label:w.identity for w in workers},','identities={w.label:w.identity for w in workers}, executionLanes={w.label:w.lane for w in workers},')
    elif name in ['archive-owned.py','summarize.py']:text=text.replace('==3','==2').replace('jobs=3','jobs=2')
    elif name=='retrieve.py':text=text.replace("['jobs']==3","['jobs']==2").replace('three-job','two-job')
    if name.endswith('.py'):ast.parse(text)
    (r/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for name in ['identity.json','prospective.json','collect.py','archive-owned.py','run.sh']:archive.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as archive:unpacked=sum(m.size for m in archive.getmembers())
config.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
text=(old/'launch-command.py').read_text(encoding='utf-8');start=text.index('config=');end=text.index('\nbase=',start);text=text[:start]+'config='+repr(config)+text[end:]
text=text.replace(" assert digest(root/'representative.json')==config['identity']['catalogSHA256']", " assert digest(source/'representative.json')==config['identity']['catalogSHA256']\n os.link(source/'representative.json',root/'representative.json')")
text=text.replace('lython-b774-fixtures','lython-b780-fixtures').replace('newSmallCatalog=True','noNewCatalogUpload=True')
ast.parse(text);(r/'launch-command.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'launch.py').read_text(encoding='utf-8').replace("r.parent/'entry-stage-r385/terminal-status.json'","r.parent/'invocation-lifetime-r390/confirmation/terminal-status.json'").replace('seconds=120','seconds=125')
ast.parse(text);(r/'launch.py').write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=2,payloadBytes=config['payloadBytes'],unpackedBytes=unpacked,core=f['coreSHA256']['candidate'])))
