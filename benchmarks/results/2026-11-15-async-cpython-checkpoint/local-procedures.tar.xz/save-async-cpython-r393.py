from pathlib import Path
import hashlib,json,shutil,tarfile

notes=Path(__file__).parent;r=notes/'async-cpython-r393';out=Path('benchmarks/results/2026-11-15-async-cpython-checkpoint');out.mkdir(exist_ok=False)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
terminal=json.loads((notes/'invocation-lifetime-r390/delivery/ci-terminal.json').read_text(encoding='utf-8'));assert terminal['conclusion']=='success'
for name in ['summary.json','identity.json','prospective.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/name,out/name)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'local-procedures.tar.xz','w:xz')as archive:
    for name in ['prepare-async-cpython-r393.py','save-async-cpython-r393.py']:archive.add(notes/name,arcname=name)
    for name in ['config.json','launch.py','launch-command.py','launch-attempt.json','launch.log','observe-not-before.json','retrieve.py','summarize.py']:archive.add(r/name,arcname='local/'+name)
print(json.dumps(dict(saved=str(out),runtimeQualified=True,elapsedSeconds=receipt['elapsedSeconds'],archiveSHA256=receipt['archiveSHA256'])))
