from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab=Path(__file__).resolve().parent
frozen=lab/"frozen-candidate"
donor=lab.with_name("native-call-construction-20261125")
identity=json.loads((lab/"comparison/quiet/identity.json").read_text(encoding="utf-8"))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in (lab/"candidate").iterdir()}==identity["imageFiles"]["candidate"]
source=lab/"route-source"
shutil.copytree(frozen,source)
p=source/"src/Lokad.Lython/Runtime/PyExecutableFunction.cs"
original=p.read_text(encoding="utf-8")
s=original
start="internal sealed class PyExecutableFunction : PyFunctionBase\n{\n"
s=s.replace(start,start+"    internal static int DiagnosticBorrowedInputs;\n    internal static int DiagnosticCopiedInputs;\n    internal static int DiagnosticBorrowedContinuations;\n")
line="                subscriptArgument = arguments[0].Reference;"
assert s.count(line)==1
s=s.replace(line,"            {\n"+line+"\n                Interlocked.Increment(ref DiagnosticBorrowedInputs);\n            }")
line="                arguments.CopyTo(values[first..]);"
assert s.count(line)==1
s=s.replace(line,"                Interlocked.Add(ref DiagnosticCopiedInputs, arguments.Length);\n"+line)
line="                state.CopyToContinuation(owned.Values);"
assert s.count(line)==1
s=s.replace(line,line+"\n                if (subscriptArgument is not null) Interlocked.Increment(ref DiagnosticBorrowedContinuations);")
p.write_text(s,encoding="utf-8",newline="\n")
import difflib
(lab/"route.patch").write_text("".join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),p.name,p.name)),encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
def run(*args,cwd=lab,log=None):
    if log:
        with (lab/log).open("wb") as f:
            subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=120,stdout=f,stderr=subprocess.STDOUT,check=True)
    else:
        subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=70,check=True)
run("build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental","--artifacts-path",lab/"route-build",cwd=source,log="route-build.log")
image=lab/"image"
image.mkdir()
for name in identity["imageFiles"]["candidate"]:
    f=lab/"route-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll" if name=="Lokad.Lython.dll" else lab/"candidate"/name
    shutil.copyfile(f,image/name)
files={p.name:sha(p) for p in image.iterdir()}
assert {k for k,v in files.items() if v!=identity["imageFiles"]["candidate"][k]}=={"Lokad.Lython.dll"}
cs=(donor/"Program.cs").read_text(encoding="utf-8")
start=cs.index("string[] names = ")
cs=cs[:start]+'string[] names = ["BorrowedInputs", "CopiedInputs", "BorrowedContinuations"];\n'+cs[cs.index("var runtime =",start):]
(lab/"Program.cs").write_text(cs,encoding="utf-8",newline="\n")
shutil.copyfile(donor/"RouteProbe.csproj",lab/"RouteProbe.csproj")
shutil.copyfile(donor/"cases.json",lab/"route-cases.json")
run("build","RouteProbe.csproj","-c","Release","--no-incremental",log="route-probe-build.log")
for item in (lab/"bin/Release/net11.0").glob("RouteProbe.*"):shutil.copyfile(item,image/item.name)
run(image/"RouteProbe.dll",image,lab/"route-cases.json",lab/"routes.json")
assert {n:sha(image/n) for n in files}==files
(lab/"route-identity.json").write_text(json.dumps({"sourcePatch":identity["sourcePatchSHA256"],"routePatch":sha(lab/"route.patch"),"files":files},indent=2)+"\n",encoding="utf-8")
for row in json.loads((lab/"routes.json").read_text(encoding="utf-8"))["rows"]:
    print(row["id"],row["routes"],row["peakExecutionMemoryBytes"],flush=True)
