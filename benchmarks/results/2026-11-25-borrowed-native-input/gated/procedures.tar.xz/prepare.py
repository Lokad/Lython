from pathlib import Path
import hashlib,json,shutil,tarfile
notes=Path(".git/agent-notes/review-20261031")
base=notes/"borrowed-native-input-20261125"
q0=base/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s): p.write_text(s,encoding="utf-8",newline="\n")
def save(p,data): write(p,json.dumps(data,indent=2)+"\n")
def prepare(label, run, folder, jobs, timeout, wait, results):
    lab=notes/folder
    q=lab/"comparison/quiet"
    save(q/"jobs.json",{"warm":jobs})
    collect=(q0/"collect.py").read_text(encoding="utf-8").replace("b1703-fixtures",label+"-fixtures").replace("len(jobs) == 6",f"len(jobs) == {len(jobs)}")
    compile(collect,"collect.py","exec")
    write(q/"collect.py",collect)
    shutil.copyfile(q0/"run.sh",q/"run.sh")
    assert b"\r" not in (q/"run.sh").read_bytes()
    launcher=(base/"quiet.py").read_text(encoding="utf-8").replace("b1703",label).replace("lython-"+label+"-borrowed-native-input","lython-"+label+"-"+run)
    launcher=launcher.replace("'candidate-core.dll','reference-core.dll'", "'candidate-core.dll'")
    launcher=launcher.replace("if name=='Lokad.Lython.dll':","if name=='Lokad.Lython.dll' and role=='candidate':")
    launcher=launcher.replace("os.link(reference/'candidate'/name,image/name)","os.link(reference/'reference'/name,image/name)")
    terminal=read(q0/"terminal-status.json")
    anchor=terminal["receipt"]["archiveSHA256"]
    assert anchor==sha(q0/"observations.tar.xz")
    start=launcher.index("assert donor['archiveSHA256']=='")
    end=launcher.index("\n",start)
    launcher=launcher[:start]+"assert donor['archiveSHA256']=="+repr(anchor)+launcher[end:]
    launcher=launcher.replace("seconds=274",f"seconds={wait}").replace("RuntimeMaxSec=350",f"RuntimeMaxSec={timeout}")
    compile(launcher,"quiet.py","exec")
    write(lab/"quiet.py",launcher)
    save(lab/"verified-raw-replicas.json",[])
    summary=(base/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-borrowed-native-input",results).replace(
        '==receipt["warmJobs"]==6', f'==receipt["warmJobs"]=={len(jobs)}').replace("timedBatches=168,lanes=6",f"timedBatches={28*len(jobs)},lanes={len(jobs)}")
    compile(summary,"archive.py","exec")
    write(lab/"archive.py",summary)
    identity=read(q/"identity.json")
    assert identity["imageFiles"]["reference"]==read(q0/"identity.json")["imageFiles"]["reference"]
    for role,files in identity["imageFiles"].items():
        assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
        assert read(lab/"comparison"/(role+"-verify.json"))["caseCount"]==5
    identity["catalogs"]["jobs.json"]={"sha256":sha(q/"jobs.json")}
    save(q/"identity.json",identity)
    tar=q/"payload.tar.gz"
    with tarfile.open(tar,"w:gz",compresslevel=3) as payload:
        for label_file in ("identity.json","jobs.json","representative.json","run.sh","collect.py"):
            payload.add(q/label_file,arcname=label_file)
        payload.add(lab/"candidate/Lokad.Lython.dll",arcname="candidate-core.dll")
    save(q/"upload.json",{"root":run+"-"+label+"-20261125","reference":"borrowed-native-input-b1703-20261125","payloadSHA256":sha(tar),"payloadBytes":tar.stat().st_size})

gated_jobs=[
    ["scripts.csv-invoice.method-policy.quoted-control","warm"],
    ["diagnostic.shipment-file-fed-map","warm-async"],
    ["diagnostic.shipment-routing-callbacks","warm-async"],
    ["scripts.rule-default-closures","compile-run"],
    ["diagnostic.generated-ordinary-definitions","compile-run"],
]
prepare("b1703b","gated-native-input","borrowed-native-input-gated-20261125",gated_jobs,305,235,
        "2026-11-25-borrowed-native-input/gated")
csv_jobs=[
    ["scripts.csv-meter-report.typed-unicode","warm-async"],
    ["scripts.csv-meter-report.explicit-float","warm-async"],
    ["scripts.csv-invoice.method-policy.quoted-control","warm"],
    ["diagnostic.shipment-file-fed-map","warm-async"],
    ["diagnostic.text-summary.nonlocal-computed-width.large","warm-async"],
    ["scripts.csv-meter-report.typed-unicode","warm"],
]
prepare("b1704","csv-read-completed-prefix","csv-read-completed-prefix-20261125",csv_jobs,350,274,
        "2026-11-25-csv-completed-read")
