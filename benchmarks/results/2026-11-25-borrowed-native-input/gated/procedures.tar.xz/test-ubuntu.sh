set -eu
export DOTNET_ROOT="$HOME/.dotnet"
tree="$PWD/.git/agent-worktrees/borrowed-native-input-20261125"
lab="$PWD/.git/agent-notes/review-20261031/borrowed-native-input-gated-20261125"
"$DOTNET_ROOT/dotnet" test "$tree/tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~NativeReturnFunction)&Category!=Stress' > "$lab/ubuntu-public.log" 2>&1 || { tail -35 "$lab/ubuntu-public.log"; exit 1; }
tail -3 "$lab/ubuntu-public.log"
