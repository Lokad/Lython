set -eu
lab="$PWD/.git/agent-notes/review-20261031/borrowed-native-input-20261125"
worktree="$PWD/.git/agent-worktrees/borrowed-native-input-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/ubuntu-net10-$suite.log"
 filter='(FullyQualifiedName~DelayedHostComposition|FullyQualifiedName~NativeReturn|FullyQualifiedName~Operand|FullyQualifiedName~CompiledCall|FullyQualifiedName~Function|FullyQualifiedName~Csv|FullyQualifiedName~Iterator|FullyQualifiedName~Terminal|FullyQualifiedName~Frame)&Category!=Stress'
 if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
     tail -3 "$log"
 else
     tail -48 "$log"
     exit 1
 fi
done