# D64B2 complete custom-set query resolution — before code

Committed f64bc7c5 actual-hash candidate selection passes1397public/461internal
per actual11/10; earlier aec4f785 delivery CI42100526619 still runs independently.
Isolated CPython/public probes demonstrate empty custom membership omits hashing
and native-only membership misses an equal custom key. Current Add/Contains/Remove
also duplicate side-candidate scans; Contains lacks native fallback and returns a
stale match after equality clears the set. This is one query pipeline problem.

Share one synchronous custom-set resolver using existing actual-hash snapshots,
insertion sequences and native fallback. Each public operation hashes once before
empty misses. Add/Contains/Remove consume one resolved retained item; pop/internal
cleanup keep no-guest stored removal. Recheck sticky refusal/cancellation after
hash/equality callbacks and verify the candidate is still retained before use.
Sequence changes restart candidate selection without repeating earlier side
entries. Keep explicit native-only fallback, capacity preflight and snapshot owners
through actual callbacks. No new engine, async framework, per-object ledger, policy,
cache, enum dispatch or configuration; synchronous key callbacks remain explicit.

Delete the three independent contextual lookup/collision/fallback loops rather
than wrapping them. Keep context-free structural helpers for real internal uses.
Set-to-set genuine async equality stays on its existing awaited path. General key
slot mutation/mutable native hashes and nested slice/dataclass hashing are separate
limits; do not reopen tracing or arbitrary reference reclamation.

Acceptance: independent CPython goldens for empty/native matches and query failures,
custom hash callback counts, equality clearing the set during contains/add/remove,
existing reentry/copy/iteration/async-comparison/ownership/cancellation/refusal
checks on actual11/10. Compare only at coherent retention, with correct baseline
controls; do not attribute speed to removing required callbacks. Full stress/
platform/installed qualification batches after this coherent set migration.
