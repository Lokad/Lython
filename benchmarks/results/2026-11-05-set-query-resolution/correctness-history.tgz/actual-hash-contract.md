# D64B actual-hash authority — before code

Retained aec4f785 has full4154internal/16015public per actual11/10 passing;
CI42100526619 active. The stable dataclass structural-collision probe demonstrates
three extra equality callbacks for unequal actual guest hashes (Python zero).
This is an observable correctness defect, not a mutable-hash conjecture.

Use actual hashes exclusively for guest equality candidate selection. The existing
structural index remains for set stored-entry identity/hash reuse: it is not dead.
Keep one existing index, preserving insertion-ordered positions. Register a position
only once if actual/structural hashes coincide, and update rollback/removal together.
Within one synchronous snapshot no guest code/await mutates buckets; count/filter
one actual bucket, allocate one final array and fill in that existing order. Delete
candidate HashSet, sort, intermediate lists, CollectCandidates, builtinOnly mode,
structural selection argument and missing-index alternate scan. Side lists and
indexes are created/cloned together; an aborted unpublished object is not reusable.
Keep existing conservative candidate reservations initially; no hidden allowance,
prehash wrapper, per-object ledger or new storage/dispatch framework.

Raw-storage fallback must not compare already-indexed protocol keys again, or
accept native structural hashes in place of the query's actual hash. Existing
native insertion filtering already classifies protocol keys; apply that invariant
consistently to lookup/removal too. Class mutation and arbitrary mutable native
hashes have additional limits; do not claim universal key-mutation correctness.
Preserve native/custom same-actual-hash matches, identity, callback errors/reentry,
insertion order, first refusal/cancellation, retained snapshots and cleanup.

Affects custom/compound keys in complete CSV/text/JSON aggregation and custom-key
scripts. No claim they dominate native representative workloads. New public
CPython goldens for unequal custom hashes and changed-hash query behavior;
existing collision/order/copy/reentry/async-comparison/refusal/ownership checks.
Focused actual11/10 checks first. One short affected comparison only at coherent
retention if a performance claim is useful, not a new framework/campaign. Do not
claim speed from removing callbacks that Python requires. Missing empty/native-
only set query hashing and nested slice/dataclass callback dispatch are separate
source findings requiring explicit follow-up, not silently declared solved.
