#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/direct-byte-file-read-b1920-final-20261128"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
public='Category!=Stress&(FullyQualifiedName~OwnedByteFile|FullyQualifiedName~PositionalZip|FullyQualifiedName~HostReadPrereservation|FullyQualifiedName~StructuredHostFailure|FullyQualifiedName~SynchronousHostBorrow|FullyQualifiedName~Chunked|FullyQualifiedName~Filecmp|FullyQualifiedName~Xml|FullyQualifiedName~ZipReadSurface|FullyQualifiedName~ZipAsyncHost|FullyQualifiedName~TextFileOwnerLifetime|FullyQualifiedName~BinaryFileScopeLifetime|FullyQualifiedName~CsvDelayed)'
internal='Category!=Stress&(FullyQualifiedName~ChunkedRead|FullyQualifiedName~SynchronousHostCompletion|FullyQualifiedName~TextRead|FullyQualifiedName~ZipHost|FullyQualifiedName~BinaryFileScopeLifetime|FullyQualifiedName~Xml)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    if [[ "$suite" == Lokad.Lython.PublicApi.Tests ]]; then filter="$public"; else filter="$internal"; fi
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$suite-net11.0.log"
done
