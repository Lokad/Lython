set -eu
root=/home/lokad/lython-bench-checks/child-declaration-preparation-b1097-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
