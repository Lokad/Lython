from pathlib import Path
import ast
import json
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / 'retained-runtime-cpython-r661'
template = lab.parent / 'capture-charge-transfer-r666'
compiler_template = lab.parent / 'final-block-targets-r658'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

rules = ['scripts.rule-default-closures', 'scripts.annotated-rule-closures', 'scripts.captured-rule-closures']
controls = ['scripts.config-manifest.small', 'scripts.config-generated-guards.medium']
shipment = 'scripts.report-render.format-selectors.large'
jobs = [(case, 'compile') for case in rules + controls] + [(case, 'compile-run') for case in rules] + [(shipment, 'warm')]
selected = {case for case, _ in jobs}
catalog = json.loads(read(donor / 'representative.json'))
historical = Path('benchmarks/results/2026-11-19-final-block-targets/checks-and-procedures.tar.xz')
with tarfile.open(historical) as evidence:
    extra = json.load(evidence.extractfile('catalog.json'))
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in rules]
catalog['cases'].extend(case for case in extra['cases'] if case['id'] in controls + [shipment])
assert {case['id'] for case in catalog['cases']} == selected
write(lab / 'catalog.json', json.dumps(catalog, indent=2, ensure_ascii=False) + '\n')

freeze = read(compiler_template / 'freeze-and-verify.py')
freeze = freeze.replace("previous=lab.parent/'definition-publication-r654'", "previous=lab.parent/'retained-runtime-cpython-r661'")
freeze = freeze.replace("/'.git/agent-worktrees/final-block-targets-r658'", "/'.git/agent-worktrees/child-declaration-preparation-r667'")
freeze = freeze.replace("'118e6e0db'", "'482b45a89'")
freeze = freeze.replace("manifest=load(previous/'frozen-identity.json')", "manifest=load(previous/'identity.json')")
start = freeze.index("assert not git('diff','--name-only',manifest['candidateCommit']")
end = freeze.index("\nassert not git('-C'", start)
freeze = freeze[:start] + "assert manifest['sourceRevision'].startswith('06b40a712')" + freeze[end:]
start, end = freeze.index('\noriginal='), freeze.index('\npython=')
freeze = freeze[:start] + '\nassert len(load(catalog_path)["cases"]) == 6' + freeze[end:]
freeze = freeze.replace("files=manifest['images']['candidate']", "files=manifest['imageFiles']['candidate']")
freeze = freeze.replace("if role=='candidate' and name==core:", 'if name == core:')
freeze = freeze.replace("lab/'build-win/bin/Lokad.Lython/release_net11.0'/name",
                        "lab/('build-'+role)/'bin/Lokad.Lython/release_net11.0'/name")
freeze = freeze.replace("if role=='candidate':assert expected[core]!=files[core]",
                        "if role=='candidate':assert expected[core]!=images['reference'][core]")
write(lab / 'freeze-and-verify.py', freeze.replace('five exact', 'six exact'))

stage = read(template / 'stage-quiet.py').replace('capture-charge-transfer-b1096', 'child-declaration-preparation-b1097')
stage = stage.replace('b1096-capture-charge-transfer', 'b1097-child-declaration-preparation').replace('b1096-fixtures', 'b1097-fixtures')
stage = stage.replace('R666 transfer the funded local capture cell', 'R667 consolidate compiler declaration preparation')
stage = stage.replace('for role in ("candidate",):', 'for role in ("reference", "candidate"):')
stage = stage.replace('"candidate/" + core]', '"candidate/" + core, "reference/" + core]')
stage = stage.replace('==8', '==9').replace('jobs=8,', 'jobs=9,').replace('eight-job', 'nine-job')
stage = stage.replace('"323","420"', '"323","465"')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
stage += '''
staged = load(quiet / 'config.json')
assert all(sha(quiet / role / core) == images[role][core] for role in images)
assert staged['sourceFiles'] == source_files
assert 'timedelta(seconds=465)' in read(lab / 'launch-quiet.py')
'''
write(lab / 'stage-quiet.py', stage)
