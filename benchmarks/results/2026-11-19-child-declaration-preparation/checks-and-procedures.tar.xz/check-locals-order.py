from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])

source = '''def outer():
    a = 1
    b = 2
    def middle():
        read_b = lambda: b
        def read_a(): return a
        return tuple(locals()), read_a(), read_b()
    return middle()
print(outer())
'''
expected = subprocess.check_output([python, '-X', 'utf8', '-I', '-c', source], text=True, encoding='utf-8')
catalog = json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))
shape = dict(catalog['cases'][0])
assert 'expectedFilesSha256' not in shape
shape.update(id='scripts.closure-locals-order', source=source, expectedOutput=expected)
for stem in ('source','expectedOutput'):
    data = shape[stem].encode('utf-8')
    shape[stem + 'Utf8Bytes'] = len(data)
    shape[stem + 'Sha256'] = hashlib.sha256(data).hexdigest()
catalog['cases'] = [shape]
path = lab / 'locals-order.json'
path.write_text(json.dumps(catalog, ensure_ascii=False), encoding='utf-8', newline='\n')
print('CPython output', expected.strip(), flush=True)
for role in ('reference', 'candidate'):
    receipt = lab / f'locals-order-{role}-verify.json'
    done = subprocess.run([dotnet, lab / 'frozen' / role / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify',
        '--catalog', path, '--dotnet', dotnet, '--python', python, '--python-worker', repo / 'benchmarks/cpython-worker.py',
        '--out', receipt], env=env, text=True, encoding='utf-8', capture_output=True, timeout=40)
    result = json.loads(receipt.read_text(encoding='utf-8-sig'))
    print(role, done.returncode, result['state'], done.stdout + done.stderr, flush=True)
    for response in result['responses']:
        if response.get('status') != 'Equivalent': print(response)
