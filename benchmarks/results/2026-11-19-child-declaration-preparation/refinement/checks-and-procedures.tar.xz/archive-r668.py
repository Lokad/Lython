from pathlib import Path

lab = Path(__file__).resolve().parent
original = (lab.parent / 'keyword-copy-path-r662/archive-r662.py').read_text(encoding='utf-8')
prefix = original[:original.index('initial = verify(')]
prefix = prefix.replace('2026-11-19-keyword-copy-path', '2026-11-19-child-declaration-preparation/refinement')
start, end = prefix.index('    independently_retained = '), prefix.index('\ncases = ')
prefix = prefix[:start] + '    assert not changed(candidate, retained, "src", "tests")\n' + prefix[end:]
exec(compile(prefix, __file__, 'exec'))

summary = verify('quiet', 7, 'quiet-summary.json')
before, after = [load(lab / f'{role}-allocation.json')['rows'] for role in ('reference', 'candidate')]
compile_rows = []
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['characters'] == right['characters']
    a, b = [statistics.median(row['bytes']) for row in (left, right)]
    compile_rows.append(dict(case=left['id'], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1)))
summary['localCompilationAllocation'] = compile_rows
assert load(lab / 'locals-order-candidate-verify.json')['state'] == 'Completed'
summary['localsOrderMatchesReferenceAndCPython'] = True
out.mkdir(exist_ok=False)
save(out / 'summary.json', summary)
quiet = lab / 'quiet'
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, out / name)
core = lab / 'frozen/candidate/Lokad.Lython.dll'
assert digest(core) == images['candidate'][core.name]
(out / 'measured-core.dll.gz').write_bytes(gzip.compress(core.read_bytes(), mtime=0))
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as evidence:
    for name in ('config.json', 'identity.json', 'representative.json', 'remote-launch.py', 'retrieve.py',
                 'observe-not-before.json', 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        evidence.add(quiet / name, arcname='quiet/' + name)
    for name in ('prepare-scripts.py', 'stage-quiet.py', 'launch-quiet.py', 'summarize-quiet.py',
                 'archive-r668.py', 'freeze-and-verify.py', 'frozen-identity.json', 'catalog.json',
                 'local-pair.log', 'measured-source.patch', 'reference-verify.json', 'candidate-verify.json',
                 'reference-allocation.json', 'candidate-allocation.json', 'build-candidate.log',
                 'check-locals-order.py', 'locals-order.json', 'locals-order-candidate-verify.json', 'retrieval.log'):
        evidence.add(lab / name, arcname=name)
    first = lab.parent / 'child-declaration-preparation-r667'
    for name in ('refined-win-net11-whitebox.log', 'refined-win-net11-public.log', 'refined-ubuntu-net10-Tests.log',
                 'refined-ubuntu-net10-PublicApi.Tests.log', 'test-ubuntu.sh'):
        evidence.add(first / name, arcname=name)
print('Verified 140 golden batches, exact paired images, the corrected scope probe, and the lease receipt.')
