set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/child-declaration-preparation-r667
notes=/mnt/d/code/Lython/.git/agent-notes/review-20261031/child-declaration-preparation-r667
label=${1:-ubuntu-net10}
filter='(FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Comprehension|FullyQualifiedName~ClassScope|FullyQualifiedName~ClassMethodExecutionBoundary|FullyQualifiedName~ExecutableFunction|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Generator|FullyQualifiedName~Annotation|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~CompileMemory|FullyQualifiedName~ModuleImport)&Category!=Stress'
status=0
for suite in Tests PublicApi.Tests; do
    log="$notes/$label-$suite.log"
    if ! ~/.dotnet/dotnet test "tests/Lokad.Lython.$suite" -c Release -f net10.0 --artifacts-path ~/lython-r667-artifacts --filter "$filter" > "$log" 2>&1; then
        status=1
    fi
    tail -n 7 "$log"
done
exit "$status"
