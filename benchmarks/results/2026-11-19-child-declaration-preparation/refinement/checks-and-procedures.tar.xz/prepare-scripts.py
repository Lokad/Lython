from pathlib import Path
import ast
import shutil

lab = Path(__file__).resolve().parent
previous = lab.parent / 'child-declaration-preparation-r667'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

shutil.copyfile(previous / 'catalog.json', lab / 'catalog.json')
freeze = read(previous / 'freeze-and-verify.py')
freeze = freeze.replace("previous=lab.parent/'retained-runtime-cpython-r661'", "previous=lab.parent/'child-declaration-preparation-r667'")
freeze = freeze.replace("manifest=load(previous/'identity.json')", "manifest=load(previous/'frozen-identity.json')")
freeze = freeze.replace("assert manifest['sourceRevision'].startswith('06b40a712')", "assert manifest['referenceCommit']==ref")
freeze = freeze.replace("source=previous/'frozen/candidate'", "source=previous/'frozen/reference'")
freeze = freeze.replace("files=manifest['imageFiles']['candidate']", "files=manifest['images']['reference']")
freeze = freeze.replace('if name == core:', "if role=='candidate' and name==core:")
start = freeze.index("    with (lab/(role+'-verify.log'))")
freeze = freeze[:start] + '''    if role == 'reference':
        assert sha(catalog_path.read_bytes()) == manifest['casesSHA256']
        for kind in ('verify.json', 'verify.log', 'allocation.json', 'allocation.log'):
            shutil.copyfile(previous / ('reference-' + kind), lab / ('reference-' + kind))
        verified = load(lab/'reference-verify.json')
        assert verified['state']=='Completed' and verified['catalogSha256']==manifest['casesSHA256']
        assert load(lab/'reference-allocation.json')['coreSha256']==expected[core]
        images[role] = expected
        continue
''' + freeze[start:]
write(lab / 'freeze-and-verify.py', freeze)

stage = read(previous / 'stage-quiet.py')
stage = stage.replace('prior = lab.parent / "retained-runtime-cpython-r661"',
                      'prior = lab.parent / "child-declaration-preparation-r667" / "quiet"')
stage = stage.replace('["imageFiles"]["candidate"]', '["imageFiles"]["reference"]')
stage = stage.replace('sourceRole="candidate"', 'sourceRole="reference"')
stage = stage.replace('child-declaration-preparation-b1097', 'ordered-declaration-preparation-b1098')
stage = stage.replace('b1097-child-declaration-preparation', 'b1098-ordered-declaration-preparation')
stage = stage.replace('b1097-fixtures', 'b1098-fixtures')
stage = stage.replace('for role in ("reference", "candidate"):', 'for role in ("candidate",):')
stage = stage.replace(', "reference/" + core]', ']')
stage = stage.replace('assert all(sha(quiet / role / core) == images[role][core] for role in images)',
                      'assert sha(quiet / "candidate" / core) == images["candidate"][core]')
stage = stage.replace('R667 consolidate compiler declaration preparation', 'R668 prepare child declarations in forwarding order')
stage = stage.replace('==9', '==7').replace('jobs=9,', 'jobs=7,').replace('nine-job', 'seven-job')
stage = stage.replace('465', '350')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
jobs = [(case, 'compile') for case in ('scripts.rule-default-closures', 'scripts.annotated-rule-closures',
        'scripts.captured-rule-closures', 'scripts.config-generated-guards.medium')]
jobs.extend([('scripts.annotated-rule-closures','compile-run'), ('scripts.captured-rule-closures','compile-run'),
             ('scripts.report-render.format-selectors.large','warm')])
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
write(lab / 'stage-quiet.py', stage)

probe = read(previous / 'check-locals-order.py').replace("for role in ('reference', 'candidate'):", "for role in ('candidate',):")
probe = probe[:probe.index('    for response in result')] + "    assert done.returncode == 0 and result['state'] == 'Completed'\n"
write(lab / 'check-locals-order.py', probe)
