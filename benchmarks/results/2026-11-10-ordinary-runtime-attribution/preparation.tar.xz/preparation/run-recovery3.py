from pathlib import Path
import subprocess,shlex
h=Path(__file__).parent/'b529';s=(h/'recovery3.py').read_bytes();ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage="from pathlib import Path;import sys;p=Path('/home/lokad/lython-bench-checks/ordinary-work-b529-20261110/recovery3.py');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
r=subprocess.run(ssh+['python3 -c '+shlex.quote(stage)],input=s,capture_output=True,timeout=20);assert r.returncode==0,r.stderr
cmd='sudo -n systemd-run --wait --unit=lython-b529-archive-recovery3-20261110 --property=User=lokad --property=WorkingDirectory=/home/lokad/lython-bench-checks/ordinary-work-b529-20261110 --property=RuntimeMaxSec=60 --property=TimeoutStopSec=15 --property=KillMode=control-group python3 /home/lokad/lython-bench-checks/ordinary-work-b529-20261110/recovery3.py'
r=subprocess.run(ssh+[cmd],text=True,encoding='utf-8',capture_output=True,timeout=85);(h/'recovery3.log').write_text(r.stdout+chr(10)+r.stderr,encoding='utf-8');print(r.stdout+r.stderr);assert r.returncode==0
