from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil
root=Path.cwd();h=root/'.git/agent-notes/review-20261031/ordinary-work-r182';h.mkdir(exist_ok=True);d=h/'b529';assert not list(d.iterdir());d.mkdir(exist_ok=True);old=h.parent/'shared-operand-r180/b527'
def adapt(s):return s.replace('text-proof-b527-20261110','ordinary-work-b529-20261110').replace('lython-b527-text-proof-20261110','lython-b529-ordinary-work-20261110').replace('lython-b527','lython-b529').replace('text-proof-b527-launch','ordinary-work-b529-launch').replace('B527','B529')
identity=json.loads((root/'benchmarks/results/2026-11-10-current-cpython-checkpoint/identity.json').read_text(encoding='utf-8'));identity['coreSHA256']=identity['coreSHA256']['candidate'];identity['sourceRevision']='Qualified ee448715 production, unchanged through49d58627, precommit frozen coreb49e50a6. Profiling only; no new elapsed comparison.'
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
baseline=json.loads((h.parent/'handler-native-entry-r179/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in baseline['productionSources'].items());baseline['coreSHA256']=identity['coreSHA256'];(d/'core-source.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf-8')
(d/'current-source-delta.json').write_text(json.dumps(dict(productionChanged=False,mainCommit='49d58627',source='core-source.json',prototypeAbsent=True),indent=2)+'\n',encoding='utf-8')
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py','attribute.py','launch.py','launch-command.py']:
 s=adapt((old/n).read_text(encoding='utf-8'))
 if n=='ops-profile.py':s=s.replace('[("text-warm", "scripts.text-summary-helpers.large", "warm")]', '[("csv-warm", "scripts.csv-validated-records.large", "warm"), ("search-warm", "scripts.file-search-protected.control", "warm")]')
 if n=='run.sh':s=s.replace('in text-warm;', 'in csv-warm search-warm;')
 if n=='archive.py':
  s=s.replace("['text-warm']", "['csv-warm','search-warm']").replace('assert seconds<10','assert seconds<20')
  s=s.replace(" seconds+=record['response']['elapsedTicks']/record['response']['clockFrequency']", " elapsed=record['response']['elapsedTicks']/record['response']['clockFrequency'];assert elapsed<10;seconds+=elapsed")
 if n=='retrieve.py':s=s.replace("['capturedSeconds']<10", "['capturedSeconds']<20")
 if n=='attribute.py':
  s=s.replace("['::GuardClosedPath','::GuardClosedPrefix','::GuardClosedBranches']", "['::GuardNativeReturn','::GuardNativeBody']").replace("('closed execution',['::ExecuteClosedPrefix'])", "('native evaluation',['::EvaluateNativeReturn'])")
  s=s.replace("['::BindFunctionArguments','::BindInto','::BindPositionalFunctionArguments','::RentFunctionArgumentStorage']", "['::BindFunctionArguments','FunctionBindingPlan::','::BindInto','::BindPositionalFunctionArguments','::RentFunctionArgumentStorage']")
  s=s.replace('One current text capture;', 'Two qualified production CSV/search captures;')
 (d/n).write_text(s,encoding='utf-8',newline='\n')
# Use the exact original production catalog; this is not the withdrawn CSV helper variant.
with tarfile.open(root/'benchmarks/results/2026-11-10-current-cpython-checkpoint/observations.tgz') as t:catalog=t.extractfile('representative.json').read()
assert hashlib.sha256(catalog).hexdigest()==identity['catalogSHA256'];cats=json.loads(catalog)['cases'];print([c['id']for c in cats if 'search' in c['id']])
search=next(c['id']for c in cats if 'file-search' in c['id']);p=d/'ops-profile.py';s=p.read_text(encoding='utf-8').replace('scripts.file-search-protected.control',search);p.write_text(s,encoding='utf-8',newline='\n')
(d/'catalog.json').write_bytes(catalog)
contract='''R182 one qualified-production CSV validation and one protected file-search capture.
Existing6CPU-second profiler per case, original scripts/goldens, stockGC/tiering
plus diagnostic perf maps only. Native returns remain; R180 is withdrawn/absent.
Attribute ordinary call/frame/binding/operand transport, record/text and I/O work
before selecting coherent simplification. No speedup/removable-tax inference from
innermost samples. One two-case owner120s/stop30s/margin30s, original warmup/capture/
frame guards unchanged per case. Each capture<10s, aggregate<20s. Join all users,
retire RAM/maps under owner, archive raw stacks/binaries/source/metadata, localSHA.
Stop after these two usable profiles or preserve concrete failed/inconclusive setup.
No extra unchanged text or CPython lane. Publication postponed.
'''
for n in ['contract.md','pre-measurement-plan.md']:(d/n).write_text(contract,encoding='utf-8',newline='\n')
launch=(d/'launch-command.py').read_text(encoding='utf-8').replace("source=(base/'shared-operand-b526-20261110/candidate').resolve()", "source=(base/'shared-operand-b528-20261110/reference').resolve()")
launch=launch.replace(" os.link(source.parent/'representative.json',root/'catalog.json')\n",'').replace(" os.link(source.parent/'final-source.json',root/'core-source.json')\n",'').replace("proof['cores']['candidate']", "proof['coreSHA256']")
assert b'\r'not in(d/'run.sh').read_bytes()
# Exclude launch program from payload; it receives the final payload hash separately.
with tarfile.open(d/'payload.tgz','w:gz') as t:
 for p in sorted(d.iterdir()):
  if p.is_file()and p.name not in ['payload.tgz','launch-command.py']:t.add(p,arcname=p.name)
payload=(d/'payload.tgz').read_bytes();lines=[]
for line in launch.splitlines():
 if line.startswith(' payload=sys.stdin.buffer.read('):line=' payload=sys.stdin.buffer.read('+str(len(payload))+'+1)'
 elif line.startswith(' assert len(payload)=='):line=' assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())
 lines.append(line)
(d/'launch-command.py').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(d/'payload.tgz') as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+256*1024
(d/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),qualifiedFrozenCoreReused=True),indent=2)+'\n',encoding='utf-8')
p=root/'benchmarks/results/2026-11-10-shared-prefix-assessment/fixed-facts/observations.tgz';rel=p.relative_to(root).as_posix();assert subprocess.check_output(['git','ls-files','--',rel],text=True).strip()==rel
spec=[dict(path='/home/lokad/lython-bench-checks/shared-operand-b528-20261110/observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=str(p),tracked=True)]
s=adapt((old/'space-recovery-command.py').read_text(encoding='utf-8')).replace('text-proof-b527','ordinary-work-b529').replace(str(json.loads((old/'payload-sizing.json').read_text())['requiredFreeBytes']),str(required))
s='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in s.splitlines())+'\n';(d/'space-recovery-command.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'recover-space.py',d/'recover-space.py')
print('Prepared two-case source-verified production profile;',required,'free bytes required; no remote action.')
