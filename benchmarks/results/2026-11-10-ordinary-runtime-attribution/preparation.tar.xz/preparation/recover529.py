from pathlib import Path
import subprocess,shlex,json
h=Path('.git/agent-notes/review-20261031/ordinary-work-r182/b529');ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
s='''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile,shutil,os
r=Path('/home/lokad/lython-bench-checks/ordinary-work-b529-20261110');base=r.parent
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 csv=json.loads((r/'profiles/csv-warm/record.json').read_text());failed=json.loads((r/'profiles/search-warm/record.json').read_text())
 assert csv['exitCode']==0 and csv['closed']['status']=='Closed' and all(csv[n]['status']=='Equivalent' for n in ['verificationBefore','verificationAfter'])
 assert failed['exitCode']==-9
 subprocess.run(['python3',str(r/'analyze-cpu-guest.py'),str(r/'profiles/csv-warm')],check=True,timeout=20)
 subprocess.run(['sudo','-n','chown','lokad:lokad',str(r/'profiles/csv-warm/perf.data')],check=True)
 fixture=Path('/dev/shm/lython-b529');assert fixture.is_mount() and not list(fixture.iterdir())
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent)
 subprocess.run([dotnet,str(r/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(r/'machine-after-recovery.json')],env=env,check=True,timeout=20)
 assert json.loads((r/'machine-after-recovery.json').read_text())['gate']['quiet']
 status=dict(originalOwnerFailed=True,originalExitCode=1,failure='search fixed128x128-job warmup cap cannot reach6seconds; no search capture. CSV capture succeeded and remains diagnostic.',allWorkersJoined=True,remainingRamFixtures=False,csvCapturedSeconds=csv['response']['elapsedTicks']/csv['response']['clockFrequency'],performanceQualified=False)
 (r/'recovery-status.json').write_text(json.dumps(status,indent=2)+'\\n')
 with tarfile.open(r/'partial-observations.tgz','w:gz',dereference=True) as a:
  for p in sorted(r.rglob('*')):
   if p.is_file() and p.name!='partial-observations.tgz' and 'candidate' not in p.relative_to(r).parts:a.add(p,arcname=p.relative_to(r).as_posix())
 with tarfile.open(r/'partial-observations.tgz') as a:assert json.loads(a.extractfile('recovery-status.json').read())['allWorkersJoined']
 assert shutil.disk_usage(r).free>240*1024*1024
 receipt=dict(**status,archivedAndVerifiedUnderRecoveryLease=True,archiveSHA256=hashlib.sha256((r/'partial-observations.tgz').read_bytes()).hexdigest())
 (r/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
(h/'recovery.py').write_text(s,encoding='utf-8',newline='\n');stage="from pathlib import Path;import sys;p=Path('/home/lokad/lython-bench-checks/ordinary-work-b529-20261110/recovery.py');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())"
r=subprocess.run(ssh+['python3 -c '+shlex.quote(stage)],input=s.encode('utf-8'),capture_output=True,timeout=20);assert r.returncode==0,r.stderr
cmd='sudo -n systemd-run --wait --unit=lython-b529-archive-recovery-20261110 --property=User=lokad --property=WorkingDirectory=/home/lokad/lython-bench-checks/ordinary-work-b529-20261110 --property=RuntimeMaxSec=60 --property=TimeoutStopSec=15 --property=KillMode=control-group python3 /home/lokad/lython-bench-checks/ordinary-work-b529-20261110/recovery.py'
r=subprocess.run(ssh+[cmd],text=True,encoding='utf-8',capture_output=True,timeout=85);(h/'recovery.log').write_text(r.stdout+'\n'+r.stderr,encoding='utf-8');print(r.stdout+r.stderr);assert r.returncode==0
