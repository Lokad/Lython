R182 one qualified-production CSV validation and one protected file-search capture.
Existing6CPU-second profiler per case, original scripts/goldens, stockGC/tiering
plus diagnostic perf maps only. Native returns remain; R180 is withdrawn/absent.
Attribute ordinary call/frame/binding/operand transport, record/text and I/O work
before selecting coherent simplification. No speedup/removable-tax inference from
innermost samples. One two-case owner120s/stop30s/margin30s, original warmup/capture/
frame guards unchanged per case. Each capture<10s, aggregate<20s. Join all users,
retire RAM/maps under owner, archive raw stacks/binaries/source/metadata, localSHA.
Stop after these two usable profiles or preserve concrete failed/inconclusive setup.
No extra unchanged text or CPython lane. Publication postponed.
