from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile,shutil,os
r=Path('/home/lokad/lython-bench-checks/ordinary-work-b529-20261110');base=r.parent
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 csv=json.loads((r/'profiles/csv-warm/record.json').read_text());failed=json.loads((r/'profiles/search-warm/record.json').read_text())
 assert csv['exitCode']==0 and csv['closed']['status']=='Closed' and all(csv[n]['status']=='Equivalent' for n in ['verificationBefore','verificationAfter'])
 assert failed['exitCode']==-9
 subprocess.run(['python3',str(r/'analyze-cpu-guest.py'),str(r/'profiles/csv-warm')],check=True,timeout=20)
 subprocess.run(['sudo','-n','chown','lokad:lokad',str(r/'profiles/csv-warm/perf.data')],check=True)
 fixture=Path('/dev/shm/lython-b529');assert fixture.is_mount()
 pid=failed['identity']['processId'];assert not Path('/proc/'+str(pid)).exists()
 import re,stat
 retired=[]
 for q in fixture.iterdir():
  meta=q.lstat();assert meta.st_uid==os.getuid() and meta.st_size==0
  assert re.fullmatch(r'(?:clr-debug-pipe-'+str(pid)+r'-[0-9]+-(?:in|out)|dotnet-diagnostic-'+str(pid)+r'-[0-9]+-socket)',q.name)
  assert stat.S_ISFIFO(meta.st_mode) or stat.S_ISSOCK(meta.st_mode)
  retired.append(dict(path=str(q),mode=oct(meta.st_mode),uid=meta.st_uid,device=meta.st_dev,inode=meta.st_ino))
 (r/'retired-dead-worker-ipc.json').write_text(json.dumps(dict(processId=pid,deadProcessVerified=True,entries=retired),indent=2)+'\n')
 for item in retired:
  q=Path(item['path']);meta=q.lstat();assert (meta.st_dev,meta.st_ino)==(item['device'],item['inode']);q.unlink()
 assert not list(fixture.iterdir())
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent)
 subprocess.run([dotnet,str(r/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(r/'machine-after-recovery.json')],env=env,check=True,timeout=20)
 assert json.loads((r/'machine-after-recovery.json').read_text())['gate']['quiet']
 status=dict(originalOwnerFailed=True,originalExitCode=1,failure='search fixed128x128-job warmup cap cannot reach6seconds; no search capture. CSV capture succeeded and remains diagnostic.',allWorkersJoined=True,remainingRamFixtures=False,csvCapturedSeconds=csv['response']['elapsedTicks']/csv['response']['clockFrequency'],performanceQualified=False)
 (r/'recovery-status.json').write_text(json.dumps(status,indent=2)+'\n')
 with tarfile.open(r/'partial-observations.tgz','w:gz',dereference=True) as a:
  for p in sorted(r.rglob('*')):
   if p.is_file() and p.name!='partial-observations.tgz' and 'candidate' not in p.relative_to(r).parts:a.add(p,arcname=p.relative_to(r).as_posix())
 with tarfile.open(r/'partial-observations.tgz') as a:assert json.loads(a.extractfile('recovery-status.json').read())['allWorkersJoined']
 assert shutil.disk_usage(r).free>240*1024*1024
 receipt=dict(**status,archivedAndVerifiedUnderRecoveryLease=True,archiveSHA256=hashlib.sha256((r/'partial-observations.tgz').read_bytes()).hexdigest())
 (r/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
