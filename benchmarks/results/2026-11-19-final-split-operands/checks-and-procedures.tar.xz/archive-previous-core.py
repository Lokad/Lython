from pathlib import Path
import gzip,hashlib,json
lab=Path(__file__).resolve().parent
prior=lab.parent/'abstract-value-facts-r589'
image=prior/'frozen/candidate'
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((prior/'frozen-identity.json').read_text(encoding='utf-8-sig'))['images']['candidate']
assert len(manifest)==32 and all(sha((image/n).read_bytes())==h for n,h in manifest.items())
core=(image/'Lokad.Lython.dll').read_bytes()
assert sha(core).startswith('c9969271')
target=Path('benchmarks/results/2026-11-18-abstract-value-facts/lython-core.dll.gz')
blob=gzip.compress(core,6,mtime=0)
if target.exists(): assert target.read_bytes()==blob
else: target.write_bytes(blob)
assert gzip.decompress(target.read_bytes())==core
print('Archived the exact B1015 candidate core.')