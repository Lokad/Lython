from pathlib import Path
import json, os, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
source = [
    "s='é,水,,🙂'; a,b,c,d=s.split(','); print(repr((a,b,c,d)))",
    "s='🙂x🙂水'; a,b,c=s.split('🙂'); print(repr((a,b,c)))",
    "s='   α　β  '; a,b=s.split(); print(a,b)",
    "s='α　β  γ'; a,b=s.split(None,1); print(repr((a,b)))",
    "s='a,b,c'; a,b=s.split(',',True); print(a,b)",
    "s='a,b'; a,=s.split(',',0); print(a is s, a)",
    "s='αβ'*80; a,=s.split('!'); print(a is s, len(a))",
    """for text in ('a', 'a,b,c'):
    a,b='before','kept'
    try: a,b=text.split(',')
    except ValueError as e: print(type(e).__name__, str(e), a,b)
""",
    """for delimiter, maximum in [('',3), ('',None), ('a',2**200), (3,1), ('a',-2**200)]:
    try: first,second='abc'.split(delimiter,maximum)
    except Exception as error: print(type(error).__name__, str(error))
""",
    """events=[]
class Index:
    def __index__(self):
        events.append('index')
        return 1
a,b='a:b:c'.split(':', Index())
print(events, a,b)
""",
    """class Words:
    def split(self, sep):
        print('guest', sep)
        return ['a','b']
a,b=Words().split(':')
print(a,b)
""",
    """items = dict()
events=[]
def loc(name):
    events.append(name)
    return name
items[loc('left')], items[loc('right')]='a:b'.split(':')
print(events, items)
try: items[loc('never')], items[loc('later')]='z'.split(':')
except ValueError: print(events, items)
""",
    """s='a,b'; a,b=stored=s.split(',')
stored.append('c')
print(a,b,stored)
a,*rest='a,b,c'.split(',')
print(a,rest)
""",
    """def parse(s):
    a,b=s.split('::')
    return a+b
print(parse('é::水'), parse('🙂::🙂'))
""",
    """def generate():
    x,y=(yield 'give input').split(','); yield x+y
g=generate(); print(next(g)); print(g.send('a,b'))
""",
    """s='é'*80+':'+ '水'*80
x,y=s.split(':')
del s
print(x[:2], y[:2], len(x), len(y))
""",
]
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probes={
 'reference':repo/'.git/agent-worktrees/direct-function-definitions-r593/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
 'candidate':repo/'.git/agent-worktrees/final-split-operands-r595/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
}
compared=[]
fields=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
for mode in ['sync','async']:
 rows={}
 for label,probe in probes.items():
  args=[str(sdk/'dotnet.exe'),str(probe),'--batch-json','--max-memory-bytes','4194304']
  if mode=='async':args+=['--async']
  actual=subprocess.run(args,env=env,input=(lab/'probes.json').read_bytes(),capture_output=True,timeout=90)
  (lab/f'{label}-{mode}.jsonl').write_bytes(actual.stdout)
  (lab/f'{label}-{mode}.stderr').write_bytes(actual.stderr)
  records=[json.loads(line) for line in actual.stdout.decode('utf-8-sig').splitlines()]
  assert len(records)==len(source),(label,mode,len(records),actual.stderr)
  rows[label]=[{k:r['Lython'].get(k) for k in fields} for r in records]
 differences=[i for i,(a,b) in enumerate(zip(rows['reference'],rows['candidate'])) if a!=b]
 compared.append(dict(mode=mode,matching=len(source)-len(differences),total=len(source),differences=differences))
(lab/'comparison.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')
print(compared)
assert all(not row['differences'] for row in compared)
