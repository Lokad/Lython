from pathlib import Path
from difflib import unified_diff
import subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=lab/'candidate-source'
tree.mkdir()
archive=lab/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',archive,'df71fc295','--','src','tests','tools/LythonProbe',
                'benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts',
                'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
                'Directory.Packages.props','global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(archive) as packed:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in packed.namelist())
    packed.extractall(tree)
changes=[]
def edit(relative,replacements):
    path=tree/relative
    before=path.read_text(encoding='utf-8')
    after=before
    for old,new in replacements:
        assert after.count(old)==1,(relative,old)
        after=after.replace(old,new)
    path.write_text(after,encoding='utf-8',newline='\n')
    changes.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+relative,'b/'+relative))
front='src/Lokad.Lython/Frontend/'
engine='src/Lokad.Lython/Runtime/'
edit(front+'CompiledRegexPrograms.cs',[
    ('    internal readonly record struct Entry(ILythonRegexPattern Program, int CaptureSlotCount);',
'''    // The exact provider list was validated during compilation and remains
    // immutable and funded by Program until the last borrowing run ends.
    internal readonly record struct NamedGroupEntries(IReadOnlyList<LythonRegexNamedGroup> Entries, int Count);
    internal readonly record struct Entry(ILythonRegexPattern Program, int CaptureSlotCount, NamedGroupEntries Groups);'''),
    ('        CancellationToken token, LythonSourceSpan span)\n    {\n        // The analysis preflight',
     '        NamedGroupEntries groups, CancellationToken token, LythonSourceSpan span)\n    {\n        // The analysis preflight'),
    ('new(program, captureSlotCount)))','new(program, captureSlotCount, groups)))')])
edit(front+'StaticAnalysisContext.cs',[
    ('    internal IReadOnlyDictionary<Runtime.Text.PyString, int> ReadRegexGroupFacts(ILythonRegexPattern program,',
     '    internal (IReadOnlyDictionary<Runtime.Text.PyString, int> Names, CompiledRegexPrograms.NamedGroupEntries Groups) ReadRegexGroupFacts(ILythonRegexPattern program,'),
    ('        int captureSlotCount, LythonSourceSpan span)\n        => _regexPrograms.Add(encoded, options, program, captureSlotCount, CancellationToken, span);',
     '        int captureSlotCount, CompiledRegexPrograms.NamedGroupEntries groups, LythonSourceSpan span)\n        => _regexPrograms.Add(encoded, options, program, captureSlotCount, groups, CancellationToken, span);')])
edit(front+'StaticRegexReturnResolver.cs',[
    ('''                regex = new(program, captureSlotCount,
                    analysis.ReadRegexGroupFacts(program, captureSlotCount, span));
                analysis.RetainRegexProgram(encoded, options, program, captureSlotCount, span);''',
'''                var (names, groups) = analysis.ReadRegexGroupFacts(program, captureSlotCount, span);
                regex = new(program, captureSlotCount, names);
                analysis.RetainRegexProgram(encoded, options, program, captureSlotCount, groups, span);''')])
edit(engine+'LythonRuntime.RegexCompiler.cs',[
    ('        internal static IReadOnlyDictionary<PyString, int> CopyAnalysisNamedGroups(ILythonRegexPattern pattern,',
     '        internal static (IReadOnlyDictionary<PyString, int> Names, CompiledRegexPrograms.NamedGroupEntries Groups) CopyAnalysisNamedGroups(ILythonRegexPattern pattern,'),
    ('''                var (entries, count) = ReadNamedGroupEntries(pattern, captureSlotCount, governor, token, span);
                if (count == 0) return (IReadOnlyDictionary<PyString, int>)FrozenDictionary<PyString, int>.Empty;''',
'''                var groups = ReadNamedGroupEntries(pattern, captureSlotCount, governor, token, span);
                var (entries, count) = groups;
                if (count == 0) return ((IReadOnlyDictionary<PyString, int>)FrozenDictionary<PyString, int>.Empty, groups);'''),
    ('''                    static (table, name, index) => table.TryAdd(name, index), factsStorage);
                return names;''',
'''                    static (table, name, index) => table.TryAdd(name, index), factsStorage);
                return ((IReadOnlyDictionary<PyString, int>)names, groups);'''),
    ('''        private static PyDict CopyRuntimeNamedGroups(ILythonRegexPattern pattern, int captureSlotCount,
            ExecutionContext context, CancellationToken token, LythonSourceSpan span, PyString sourcePattern)
            => ProviderCall((pattern, captureSlotCount, context, token, span), static state =>
            {
                var (pattern, captureSlotCount, context, token, span) = state;
                var governor = context.MemoryGovernor;
                var (entries, count) = ReadNamedGroupEntries(pattern, captureSlotCount, governor, token, span);''',
'''        private static PyDict CopyRuntimeNamedGroups(ILythonRegexPattern pattern, int captureSlotCount,
            CompiledRegexPrograms.NamedGroupEntries? prepared, ExecutionContext context,
            CancellationToken token, LythonSourceSpan span, PyString sourcePattern)
            => ProviderCall((pattern, captureSlotCount, prepared, context, token, span), static state =>
            {
                var (pattern, captureSlotCount, prepared, context, token, span) = state;
                var governor = context.MemoryGovernor;
                var (entries, count) = prepared ?? ReadNamedGroupEntries(pattern, captureSlotCount, governor, token, span);'''),
    ('''                        static (state, name, index) => state.names.TryAddNativeStringInteger(name, index, state.context, state.span));''',
'''                        static (state, name, index) => state.names.TryAddNativeStringInteger(name, index, state.context, state.span),
                        validate: prepared is null);'''),
    ('        private static (IReadOnlyList<LythonRegexNamedGroup> Entries, int Count) ReadNamedGroupEntries(',
     '        private static CompiledRegexPrograms.NamedGroupEntries ReadNamedGroupEntries('),
    ('            return (entries!, count);','            return new(entries!, count);'),
    ('            T table, Func<T, PyString, int, bool> add, MemoryGovernor.TemporaryMemoryReservation? factsStorage = null)',
     '            T table, Func<T, PyString, int, bool> add, MemoryGovernor.TemporaryMemoryReservation? factsStorage = null,\n            bool validate = true)'),
    ('''                if (entry.Index <= previous || entry.Index >= captureSlotCount || entry.Name.IsEmpty)
                    throw RuntimeErrors.Runtime("Regex provider returned inconsistent named-group metadata.", span);
                var input = entry.Name.Span;
                for (int offset = 0, scalar = 0; offset < input.Length; scalar++)
                {
                    if ((scalar & 1023) == 0 && token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                    if (Rune.DecodeFromUtf8(input[offset..], out _, out var width) != System.Buffers.OperationStatus.Done)
                        throw RuntimeErrors.Runtime("Regex provider returned invalid UTF-8 group names.", span);
                    offset += width;
                }''',
'''                var input = entry.Name.Span;
                if (validate)
                {
                    if (entry.Index <= previous || entry.Index >= captureSlotCount || input.IsEmpty)
                        throw RuntimeErrors.Runtime("Regex provider returned inconsistent named-group metadata.", span);
                    for (int offset = 0, scalar = 0; offset < input.Length; scalar++)
                    {
                        if ((scalar & 1023) == 0 && token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                        if (Rune.DecodeFromUtf8(input[offset..], out _, out var width) != System.Buffers.OperationStatus.Done)
                            throw RuntimeErrors.Runtime("Regex provider returned invalid UTF-8 group names.", span);
                        offset += width;
                    }
                }'''),
    ('CopyRuntimeNamedGroups(compiled, captureSlotCount, context, token, span, pattern);',
     'CopyRuntimeNamedGroups(compiled, captureSlotCount, artifact?.Groups, context, token, span, pattern);')])
(lab/'candidate.patch').write_text(''.join(changes),encoding='utf-8',newline='\n')
