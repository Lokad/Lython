from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('post-update-arithmetic-routes-20261126')
reference=prior/'frozen/candidate'
proof=json.loads((prior/'frozen-identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
sha=lambda bytes:hashlib.sha256(bytes).hexdigest()
assert {p.name:sha(p.read_bytes()) for p in reference.iterdir()}==proof
old=json.loads((lab.with_name('post-deferral-factory-cpu-20261126')/'comparison/quiet/catalog.json').read_text(encoding='utf-8'))
directory=lab/'parity'
directory.mkdir()
cases=[]
for count in (1,24):
    code='import re\npatterns=[\n'
    for index in range(count):
        code+=f"    re.compile(r'(?P<label>\\w+):(?P<tail>\\d+)(?#{index})'),\n"
    code+="]\ntotal=0\nfor p in patterns:\n    m=p.fullmatch('café:42')\n    assert list(p.groupindex)==['label','tail']\n    assert m.span('label')==(0,4) and m.group('label')=='café'\n    total+=int(m.group('tail'))\nprint(total)\n"
    fixture=json.dumps(dict(size=count,text=None),separators=(',',':'))
    expected=f'{count*42}\n'
    cases.append(dict(id=f'diagnostic.regex-compiled-group-names.{count}',family='scripts',category='whole-script',
                      scale='small',size=count,source=code,fixtureJson=fixture,expectedOutput=expected,
                      sourceUtf8Bytes=len(code.encode()),expectedOutputUtf8Bytes=len(expected.encode()),
                      fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
                      sourceSha256=sha(code.encode()),fixtureSha256=sha(fixture.encode()),
                      expectedOutputSha256=sha(expected.encode())))
old['cases']=cases
catalog=directory/'catalog.json'
catalog.write_text(json.dumps(old,ensure_ascii=False),encoding='utf-8',newline='\n')
core=lab/'candidate-source/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
for role in ('reference','candidate'):
    image=directory/role
    shutil.copytree(reference,image)
    if role=='candidate': shutil.copyfile(core,image/core.name)
    files={p.name:sha(p.read_bytes()) for p in image.iterdir()}
    assert len(files)==32 and set(k for k,v in files.items() if proof[k]!=v)==({'Lokad.Lython.dll'} if role=='candidate' else set())
    report=directory/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py','--out',report],
        cwd=repo,env=env,check=True,timeout=55)
    result=json.loads(report.read_text(encoding='utf-8'))
    assert result['state']=='Completed' and result['caseCount']==2
    assert result['catalogSha256']==sha(catalog.read_bytes())
    assert result['launched']['library']['sha256'].lower()==files[core.name].lower()
    (directory/(role+'-files.json')).write_text(json.dumps(files,indent=2),encoding='utf-8',newline='\n')
