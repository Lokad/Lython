export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/inline-function-binding-r690
filter='(FullyQualifiedName~BindingPlan|FullyQualifiedName~FunctionDefault|FullyQualifiedName~OrdinaryFunction|FullyQualifiedName~ExpandedCall|FullyQualifiedName~BoundBox|FullyQualifiedName~CallBinding|FullyQualifiedName~GeneratorCleanup|FullyQualifiedName~FunctionConstruction|FullyQualifiedName~Dataclass)&Category!=Stress'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="$lab/$suite-ubuntu.log"
    ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" >"$log" 2>&1
    result=$?
    tail -n 8 "$log"
    if test "$result" -ne 0; then exit "$result"; fi
done