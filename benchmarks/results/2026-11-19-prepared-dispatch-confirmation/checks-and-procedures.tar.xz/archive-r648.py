from pathlib import Path
import hashlib
import gzip
import json
import shutil
import statistics
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "prepared-definition-dispatch-r646"
out = Path("benchmarks/results/2026-11-19-prepared-dispatch-confirmation")
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

pair = load(donor / "frozen-identity.json")
images = pair["images"]
base = pair["referenceCommit"]
candidate = pair["candidateCommit"]
retained = sys.argv[1]
if retained != "private":
    subprocess.run(["git", "diff", "--exit-code", candidate, retained, "--", "src"], check=True)
    subprocess.run(["git", "diff", "--exit-code", candidate, retained, "--", "tests"], check=True)
cases = {case["id"]: case for case in load(donor / "catalog.json")["cases"]}
assert digest(donor / "catalog.json") == pair["casesSHA256"]

def verify(folder, jobs, summary):
    scan = lab / folder
    identity = load(scan / "identity.json")
    assert identity["imageFiles"] == images and identity["catalogSHA256"] == pair["casesSHA256"]
    assert digest(scan / "representative.json") == pair["casesSHA256"]
    for role, files in images.items():
        frozen = donor / "frozen" / role
        assert len(files) == 32
        assert {entry.name: digest(entry) for entry in frozen.iterdir() if entry.is_file() and entry.name in files} == files
    receipt = load(scan / "archive-receipt.json")
    terminal = load(scan / "terminal-status.json")
    assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
    assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
    assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                        "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"))
    assert receipt["jobs"] == jobs and receipt["archiveSHA256"] == digest(scan / "observations.tgz")
    raw = load(scan / "retrieved/confirmation/confirmation.json")
    assert raw["complete"] and len(raw["jobs"]) == jobs
    for job in raw["jobs"]:
        case = cases[job["case"]]
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 20
        assert set(job["identities"]) == set(identity["coreSHA256"])
        for role, worker in job["identities"].items():
            image = images[role.removesuffix("-control")]
            relevant = {Path(lib["path"]).name: lib["sha256"].lower() for lib in worker["libraries"]
                        if Path(lib["path"]).name in image}
            assert "Lokad.Lython.dll" in relevant
            assert all(image[name] == value for name, value in relevant.items())
            assert sorted(row["round"] for row in job["samples"] if row["engine"] == role) == list(range(5))
        for row in job["samples"]:
            value = row["response"]
            assert value["status"] == "Completed" and value["completedInvocations"] > 0
            for key in ("sourceSha256", "fixtureSha256", "expectedOutputSha256"):
                assert value[key] == case[key]
            for field, golden in (("actualOutputSha256", "expectedOutputSha256"), ("actualFilesSha256", "expectedFilesSha256")):
                assert value.get(field) == (None if job["lane"] == "compile" else case.get(golden))
    result = load(lab / summary)
    result.update(referenceRuntime=base, measuredPrototype=candidate, cores=identity["coreSHA256"],
        archiveSHA256=receipt["archiveSHA256"], retentionDecisionPending=False, retained=retained != "private")
    if retained != "private":
        result["retainedCommit"] = retained
    return result

summary = verify("quiet", 4, "quiet-summary.json")
assert summary["retained"]
summary["initialComparison"] = "B1075"
summary["warmupSeconds"] = 12
out.mkdir(exist_ok=False)
save(out / "summary.json", summary)
for filename in ("observations.tgz", "archive-receipt.json", "terminal-status.json"):
    shutil.copyfile(lab / "quiet" / filename, out / filename)
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as tar:
    for filename in ("preflight.json", "quiet-space.json", "stage-quiet.py", "launch-quiet.py",
                     "summarize-quiet.py", "archive-r648.py", "retrieval.log"):
        tar.add(lab / filename, arcname=filename)
    for filename in ("config.json", "identity.json", "remote-launch.py", "retrieve.py", "observe-not-before.json",
                     "launch.log", "collect.py", "archive-owned.py", "run.sh", "representative.json"):
        tar.add(lab / "quiet" / filename, arcname="quiet/" + filename)
    tar.add(donor / "frozen-identity.json", arcname="b1075-frozen-identity.json")
print("Verified 80 golden batches, both complete images, catalog, archive hash and worker joins.")
