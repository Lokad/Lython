from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
local = lab / 'comparison/local'
quiet = lab / 'comparison/quiet-cpython'
quiet.mkdir()
donor = notes / 'shared-iterable-call-arguments-20261127' / 'comparison/quiet'
template = notes / 'iterable-starmap-cpython-20261127'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: sha256(p.read_bytes()).hexdigest()
write = lambda p, value: p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
core = 'Lokad.Lython.dll'
base = read(local / 'identity.json')
donor_identity = read(donor / 'identity.json')
donor_files = donor_identity['imageFiles']['candidate']
receipt = read(donor / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256'] == sha(donor / 'observations.tar.xz')
files = base['imageFiles']['candidate']
assert {p.name: sha(p) for p in (local / 'candidate').iterdir()} == files and len(files) == 32
assert {p.name: sha(p) for p in (donor.parent / 'local/candidate').iterdir()} == donor_files
assert [name for name in files if files[name] != donor_files[name]] == [core]
patch = subprocess.check_output(['git', 'diff', '--binary', base['sourceRevision'], '--', 'src'], cwd=repo)
assert sha256(patch).hexdigest() == base['sourcePatchSHA256'] == sha(lab / 'candidate.patch')

catalog = read(local / 'representative.json')
target = 'diagnostic.shipment-dictwriter-report'
control = 'diagnostic.shipment-file-fed-map'
cases = {case['id']: case for case in catalog['cases']}
catalog['cases'] = [cases[target], cases[control]]
jobs = [[target, 'warm'], [target, 'warm-async'], [control, 'warm-async'], [target, 'compile'], [target, 'compile-run']]
write(quiet / 'representative.json', catalog)
write(quiet / 'jobs.json', jobs)
for name in ('cpython-worker.py', 'run.sh'):
    shutil.copyfile(template / 'comparison/quiet' / name, quiet / name)
assert sha(quiet / 'cpython-worker.py') == base['cpythonWorkerSHA256'] and b'\r' not in (quiet / 'run.sh').read_bytes()
root = 'csv-dictwriter-cpython-b1869-20261127'
identity = dict(sourceRevision=base['sourceRevision'], comparisonHostRevision=base['comparisonHostRevision'],
    frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate', auxiliaryFiles={n: h for n, h in files.items() if n != core},
    overlay=[core], imageFiles={'candidate': files}, coreSHA256={role: files[core] for role in ('candidate', 'candidate-control')},
    catalogs={name: {'sha256': sha(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=donor_identity['expectedCPythonSHA256'], cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'], sourcePatchSHA256=base['sourcePatchSHA256'],
    purpose='Compare the direct dictionary CSV output report with CPython, including separate compile and warm lanes.')
write(quiet / 'identity.json', identity)
collector = (template / 'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector = collector.replace('lython-b1865-fixtures', 'lython-b1869-fixtures').replace('len(jobs) == 3', 'len(jobs) == 5')
compile(collector, 'collect.py', 'exec')
(quiet / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')

shell = (template / 'quiet-vm.py').read_text(encoding='utf-8').replace("'comparison/quiet'", "'comparison/quiet-cpython'")
shell = shell.replace('lython-b1865-iterable-starmap-cpython-20261127','lython-b1869-csv-dictwriter-cpython-20261127')
shell = shell.replace('RuntimeMaxSec=175', 'RuntimeMaxSec=252')
old_gate = ' assert before>=floor,(before,floor)\n cleared=before'
assert old_gate in shell
shell = shell.replace(old_gate, ''' reclaimed=[]
 if before<floor:
  pin=cfg['retiredReplica']
  retired=base/pin['root']
  assert retired.parent==base and retired.resolve(strict=True)==retired and retired!=donor
  retired_receipt=json.loads((retired/'archive-receipt.json').read_text())
  assert retired_receipt['complete'] and retired_receipt['allWorkersJoined'] and retired_receipt['guestFixturesRemoved']
  assert retired_receipt['archiveSHA256']==pin['archiveSHA256']==sha(retired/'observations.tar.xz')
  replica=retired/'candidate/Lokad.Lython.dll'
  assert replica.is_file() and replica.resolve(strict=True)==replica and sha(replica)==pin['coreSHA256']
  file=replica.stat()
  assert file.st_nlink==1 and file.st_size==pin['length'] and before+file.st_size>=floor
  replica.unlink()
  reclaimed.append(str(replica))
 cleared=shutil.disk_usage(base).free
 assert cleared>=floor,(cleared,floor)''')
shell = shell.replace('afterStaging=after,', 'afterStaging=after,reclaimed=reclaimed,retiredReplica=cfg[\'retiredReplica\'],')
compile(shell, 'quiet-vm-cpython.py', 'exec')
(lab / 'quiet-vm-cpython.py').write_text(shell, encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
verify = quiet / 'candidate-verify.json'
subprocess.run([dotnet, local / 'candidate/Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', quiet / 'representative.json',
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', quiet / 'cpython-worker.py', '--out', verify],
    env=dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk)), check=True, timeout=65)
proof = read(verify)
assert proof['state'] == 'Completed' and proof['caseCount'] == 2
assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert proof['launched']['adapter']['sha256'] == files['Lokad.Lython.Benchmarks.dll'] and proof['launched']['library']['sha256'] == files[core]

old_root = notes / 'ready-fixed-unpack-20261127'
old = repo / 'benchmarks/results/2026-11-27-ready-fixed-unpack'
old_image = old_root / 'local/candidate'
old_pin = read(old / 'identity.json')
assert len(old_pin['imageFiles']['candidate']) == 32 and {p.name: sha(p) for p in old_image.iterdir()} == old_pin['imageFiles']['candidate']
old_receipt = read(old / 'terminal-status.json')['receipt']
assert old_receipt['complete'] and old_receipt['allWorkersJoined'] and sha(old / 'observations.tar.xz') == old_receipt['archiveSHA256']
retired_replica = dict(root=read(old_root / 'comparison/quiet/upload.json')['root'], archiveSHA256=old_receipt['archiveSHA256'],
    coreSHA256=old_pin['imageFiles']['candidate'][core], length=(old_image / core).stat().st_size)
assert retired_replica['root'] == 'ready-fixed-unpack-b1852-20261127'
(quiet / 'candidate').mkdir()
shutil.copyfile(local / 'candidate' / core, quiet / 'candidate' / core)
names = ['identity.json', 'representative.json', 'jobs.json', 'cpython-worker.py', 'run.sh', 'collect.py', f'candidate/{core}']
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in names:
        archive.add(quiet / name, arcname=name)
staged = {name: dict(length=(quiet / name).stat().st_size, sha256=sha(quiet / name)) for name in names}
write(quiet / 'upload.json', dict(root=root, donor=read(donor / 'upload.json')['root'], donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'], retiredReplica=retired_replica, payloadSHA256=sha(payload), files=staged,
    expandedBytes=sum(row['length'] for row in staged.values()), minimumAfterStageBytes=6 * 1024 * 1024))
