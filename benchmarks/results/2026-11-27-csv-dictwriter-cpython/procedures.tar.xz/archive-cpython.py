from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet-cpython'
out = repo / 'benchmarks/results/2026-11-27-csv-dictwriter-cpython'
local = out.parent / '2026-11-27-csv-dictwriter-native-validation'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
identity = read(quiet / 'identity.json')
first = read(local / 'identity.json')
assert identity['sourcePatchSHA256'] == first['sourcePatchSHA256']
assert identity['imageFiles']['candidate'] == first['imageFiles']['candidate']
measured = subprocess.check_output(['git', 'rev-parse', '6e59cd41e'], cwd=repo, text=True).strip()
patch = subprocess.check_output(['git', 'diff', '--binary', identity['sourceRevision'], measured, '--', 'src'], cwd=repo)
assert sha256(patch).hexdigest() == identity['sourcePatchSHA256']
summary = read(quiet / 'summary.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
assert summary['source'] == identity['sourceRevision'] and summary['timedBatches'] == 140
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'guestFixturesRemoved', 'allWorkersJoined', 'archivedAndVerifiedUnderLease'))
assert terminal['exitCode'] == '0' and not terminal['live'] and not terminal['fixtures']
assert 'ActiveState=inactive' in terminal['service'] and 'MainPID=0' in terminal['service']
assert receipt['archiveSHA256'] == sha(quiet / 'observations.tar.xz')
for filename in ('candidate-verify.json', 'remote-verify.json'):
    proof = read(quiet / filename)
    files = identity['imageFiles']['candidate']
    assert proof['state'] == 'Completed' and proof['caseCount'] == 2
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']
    assert proof['launched']['adapter']['sha256'] == files['Lokad.Lython.Benchmarks.dll']
    if filename.startswith('remote'):
        assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
with tarfile.open(quiet / 'observations.tar.xz') as bundle:
    for key in ('machine-before', 'machine-after'):
        assert json.load(bundle.extractfile(f'confirmation/{key}.json'))['gate']['quiet']
    assert json.load(bundle.extractfile('identity.json')) == identity
    for name, item in identity['catalogs'].items():
        assert sha256(bundle.extractfile(name).read()).hexdigest() == item['sha256']
custody = read(quiet / 'stage-custody.json')
assert custody['streamed'] and custody['afterReclaim'] >= custody['requiredBeforeStage']
assert custody['afterStaging'] >= 6 * 1024 * 1024
assert identity['overlay'] == ['Lokad.Lython.dll'] and len(identity['auxiliaryFiles']) == 31
assert summary['cpythonVersion'] == '3.13.16' and summary['cpythonExecutableSHA256'] == identity['expectedCPythonSHA256']
out.mkdir(exist_ok=True)
summarized = dict(summary, productionSource=measured, frozenBase=identity['sourceRevision'])
summarized['source'] = measured
write(out / 'summary.json', summarized)
for name in ('identity.json', 'observations.tar.xz', 'terminal-status.json', 'stage-custody.json'):
    shutil.copyfile(quiet / name, out / name)
files = {name: quiet / name for name in ('collect.py', 'run.sh', 'candidate-verify.json', 'remote-verify.json',
    'representative.json', 'jobs.json', 'upload.json', 'launch.log')}
files.update({name: lab / name for name in ('quiet-vm-cpython.py', 'prepare-cpython.py', 'prepare-cpython.log',
    'launch-cpython.log', 'summarize-cpython.py', 'archive-cpython.py')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as bundle:
    for name, path in files.items():
        bundle.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as bundle:
    assert set(bundle.getnames()) == set(files)
    assert all(sha256(bundle.extractfile(name).read()).hexdigest() == sha(path) for name, path in files.items())
