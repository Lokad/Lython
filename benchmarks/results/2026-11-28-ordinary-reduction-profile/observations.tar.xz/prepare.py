from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab = Path(__file__).resolve().parent
donor = lab.parent / 'current-checkpoint-b1932-20261128/attribution/profile'
frozen = lab.parent / 'current-shipment-checkpoint-b1937-20261128/comparison/quiet'
actual = lab.parent / 'staged-generator-activation-refined-b1936-20261128/comparison'
profile = lab / 'attribution/profile'
profile.mkdir(parents=True)
identity = json.loads((frozen/'identity.json').read_bytes())
members = identity['imageFiles']['candidate']
assert len(members)==32 and {path.name:sha256(path.read_bytes()).hexdigest() for path in (frozen/'local-image').iterdir()}==members
roles = [
    ['reduction-async','diagnostic.shipment-row-generator-reduction','warm-async'],
    ['reduction-sync','diagnostic.shipment-row-generator-reduction','warm'],
    ['map-async','diagnostic.shipment-file-fed-map','warm-async'],
]
identity.update(inspectedHead=identity['sourceRevision'],profiles=roles)
(profile/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('cpython-worker.py','representative.json','candidate-verify.json'):
    copy2(actual/name,profile.parent/name)
assert sha256((profile.parent/'representative.json').read_bytes()).hexdigest()==identity['catalogs']['representative.json']['sha256']
collect = (donor/'collect.py').read_text(encoding='utf-8')
collect = collect.replace("lab.parent.parent/'comparison/quiet/local-image'",
    "lab.parents[2]/'current-shipment-checkpoint-b1937-20261128/comparison/quiet/local-image'").replace('verification["caseCount"]==7','verification["caseCount"]==4')
compile(collect,'collect.py','exec')
(profile/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
run = (donor/'run.sh').read_text(encoding='utf-8')
(profile/'run.sh').write_text(run,encoding='utf-8',newline='\n')
assert b'\r' not in (profile/'run.sh').read_bytes()
analysis = (donor/'analyze-managed.py').read_text(encoding='utf-8')
begin = analysis.index('REGIONS = {')
end = analysis.index('WAIT_FRAMES',begin)
regions = {
    'ordinary map': ('PyMapIterator',),
    'generator construction': ('PyGenerator+<CreateExpressionAsync>', 'PyGenerator.CreateExpressionAsync', 'PyGeneratorFunction.CreateBoundGenerator'),
    'generator advancement': ('PyGenerator.Advance', 'PyGenerator+<AdvanceFrameAsync>'),
    'generator exception/stack entry': ('PyGenerator.EnterFrame', 'ResumeGeneratorException', 'EnterInterpreterFrame', 'EnterFunctionCall'),
    'generator outer iteration': ('AcquireGeneratorOuter', 'ExecutableValueStorage.TryPrepareNativeIteration'),
    'callback entry': ('StartIterationCallback','TryStartPositionalCallback','StartInline'),
    'argument binding/storage': ('BindFunctionArgumentsInto','RentFunctionArgumentStorage','ReturnBoundArguments'),
    'numeric reduction': ('SumState','SumBuiltin','SumCore','DrainGeneratorForSum','TryAppendBufferedYield'),
    'native arithmetic': ('TryExecuteBuiltinArithmetic','TryEvaluateBuiltinArithmetic','TryExecuteNativeCall'),
    'subscript and dictionary': ('Subscript','PyDict.TryGetValue','TryReadNative'),
    'memory reservation': ('MemoryGovernor.Reserve','MemoryGovernor.ReserveTemporary'),
    'memory refund': ('MemoryGovernor.Release',),
    'CSV record': ('CsvRecordParser','CsvDictReader'),
    'mediated text file': ('OpenedByteFile','TextFileHandle','ChunkedTextFileReadState'),
    'instruction prefix': ('ExecuteInstructionPrefix','RunNativePrefix','NativeExecution.Run'),
}
analysis = (analysis[:begin]+'REGIONS = '+repr(regions)+'\n'+analysis[end:]).replace("('iterable-async', 'iterable-sync', 'document-async')",repr(tuple(row[0] for row in roles)))
analysis = analysis.replace("if any('InvokeIterableRowAsync' in frame or 'StartGeneratorRow' in frame or 'FinishGeneratorRowAsync' in frame for frame in active):",
    "if any(mark in frame for frame in active for mark in REGIONS['generator construction'] + REGIONS['generator advancement']):")
compile(analysis,'analyze-managed.py','exec')
(profile/'analyze-managed.py').write_text(analysis,encoding='utf-8',newline='\n')
print(identity['sourceRevision'], 'three managed profiles prepared')
