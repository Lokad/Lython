using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private static bool CallResultConsumedByIteration(in ExecutableWorkState execution, ExecutableCallSite call)
            => call.ConsumedByIteration || execution.ReturnConsumedByIteration && call.ReturnedDirectly;

        internal static Span<ExecutableSlot> PrepareUnpackedCallReturn(Span<ExecutableSlot> values, ref ExecutableValueStorage storage,
            ExecutableCallSite call, int start, out int originalExtent)
        {
            originalExtent = storage.LiveExtent;
            // Eligibility depends on these actual input values, not ownership
            // metadata for unrelated users of the same physical slots.
            if (call.UnpackedReturnCount == 0 || call.ArgumentCount > NativeValueCapacity
                || !storage.CanRetireWithoutCleanup(start)) return default;
            var returned = values.Slice(start, call.UnpackedReturnCount);
            // Track every reference before the callee writes, including results
            // wider than the inputs. Nothing reaches guest targets before cleanup.
            storage.RestoreNativeExtent(Math.Max(originalExtent, start + returned.Length));
            return returned;
        }

        internal static void CompleteUnpackedCallReturn(ExecutableCodeObject code, Span<ExecutableSlot> values,
            ref ExecutableValueStorage storage, ref int index, ExecutionContext scope, int start, int count)
        {
            ref readonly var unpack = ref code.Instructions[index + 1];
            scope.CheckExecution(unpack.Span);
            storage.RetireTo(start + count);
            values.Slice(start, count).Reverse();
            index++;
        }

        internal static void AbortPreparedNativeCall(ExecutionContext frame, MemoryGovernor storageOwner)
        {
            try
            {
                if (frame.TakePreparedNativeChild() is { } child)
                {
                    try { AbortPreparedNativeCall(child, child._boundStorageOwner!); }
                    finally { frame.LeaveInterpreterFrame(); }
                }
            }
            finally { AbortPreparedNativeFrame(frame, storageOwner); }
        }

        private static void AbortPreparedNativeFrame(ExecutionContext frame, MemoryGovernor storageOwner)
        {
            try
            {
                frame.LeaveExecutableSlots();
                try { frame.AbandonFrame(); }
                finally { frame._execution.Stack.ReleaseStorage(); }
            }
            finally
            {
                try { frame.LeaveFunctionCall(); }
                finally
                {
                    try { ReturnBoundArguments(frame._execution.Locals, storageOwner, frame._execution.Code.ValueStorageCapacity); }
                    finally { frame.DetachExecutableExecution(); }
                }
            }
        }

        // The opcode has already read its evaluated target and offered it to the
        // linear frame runner. Both APIs use the same remaining call selection.
        private ValueTask ExecuteOrdinaryCall(ExecutableCallSite call, int start, object target, bool asynchronous)
        {
            try
            {
                object result;
                if (call.HasReceiver && target is ReceiverMethod receiverMethod && call.IsPositionalOnly && receiverMethod.AcceptsPositional(call.ArgumentCount))
                {
                    var receiver = _execution.Stack[start];
                    var arguments = _execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                    if (asynchronous) return CompleteCallValue(InvokeReceiverMethodAsync(receiverMethod, receiver, new ReceiverArguments(_execution.Stack.Values, start + call.ArgumentOffset, call.ArgumentCount), call.CallSpan, this), start);
                    result = InvokeReceiverMethod(receiverMethod, receiver, new ReceiverArguments(_execution.Stack.Values, start + call.ArgumentOffset, call.ArgumentCount), call.CallSpan, this);
                }
                else if (target is PyFunctionBase function)
                {
                    var arguments = _execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                    var receiver = call.HasReceiver && _execution.Stack[start] is not PyNone ? _execution.Stack[start] : null;
                    if (asynchronous) return CompleteCallValue(InvokeCallableFromOperandsAsync(function, arguments,
                        call.CallSpan, this, receiver, call), start);
                    result = InvokeCallableFromOperands(function, arguments, call.CallSpan, this, receiver, call);
                }
                else if (target is PyBoundMethod { Function: PyFunctionBase method } bound)
                {
                    var arguments = _execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                    if (asynchronous) return CompleteCallValue(InvokeCallableFromOperandsAsync(method, arguments,
                        call.CallSpan, this, bound.Receiver, call), start);
                    result = InvokeCallableFromOperands(method, arguments, call.CallSpan, this, bound.Receiver, call);
                }
                else
                {
                    var pending = InvokeExecutableGeneralTargetAsync(call, start, target, asynchronous);
                    if (asynchronous) return CompleteCallValue(pending, start);
                    result = pending.GetAwaiter().GetResult();
                }
                PublishInstructionResult(_execution.Code.Instructions[_execution.InstructionIndex], result);
                return default;
            }
            catch
            {
                _execution.Stack.RetireTo(start);
                throw;
            }
        }

        // Native results above travel as objects. Only potentially asynchronous
        // branches reach this completion helper; their operands stay borrowed.
        private ValueTask CompleteCallValue(ValueTask<object> pending, int start)
        {
            if (!pending.IsCompleted) return AwaitCallValueAsync(pending, start);
            PublishInstructionResult(_execution.Code.Instructions[_execution.InstructionIndex], pending.GetAwaiter().GetResult());
            return default;
        }

        private async ValueTask AwaitCallValueAsync(ValueTask<object> pending, int start)
        {
            try { PublishInstructionResult(_execution.Code.Instructions[_execution.InstructionIndex], await pending.ConfigureAwait(false)); }
            catch { _execution.Stack.RetireTo(start); throw; }
        }

        private ValueTask<object> InvokeExecutableGeneralTargetAsync(ExecutableCallSite call, int start, object target, bool asynchronous)
        {
            if (target is ReceiverMethod method)
                target = method.Bind(_execution.Stack[start]);
            // Constructors can consume the same packet across __new__/__init__
            // suspension. Other short calls bind a managed stack borrow before
            // returning any pending work; retain no per-thread packet lifecycle.
            if (call.ArgumentCount > 3 || _preparedCallValue is PyInstance)
                return InvokeOwnedExecutableTargetAsync(call, start, target, asynchronous);
            CallableInvocation.Arguments arguments = default;
            PrepareExecutableCallArguments(call, ref _execution.Stack, start, arguments[..call.ArgumentCount], this);
            return asynchronous
                ? InvokeBorrowedCallableTargetAsync(target, call, arguments[..call.ArgumentCount], this)
                : new(InvokeBorrowedCallableTarget(target, call, arguments[..call.ArgumentCount], this));
        }

        private async ValueTask<object> InvokeOwnedExecutableTargetAsync(ExecutableCallSite call, int start, object target, bool asynchronous)
        {
            using var storage = ReserveExecutableCallArguments(call, this);
            var arguments = new CallArgumentValue[call.ArgumentCount];
            try
            {
                PrepareExecutableCallArguments(call, ref _execution.Stack, start, arguments, this);
                if (_preparedCallValue is PyInstance instance)
                {
                    _preparedCallValue = null;
                    return await InitializePreparedConstructorAsync(instance, arguments, call.CallSpan, this, asynchronous).ConfigureAwait(false);
                }
                return asynchronous
                    ? await InvokeCallableTargetAsync(target, call.TargetSpan, call.CallSpan, this, arguments).ConfigureAwait(false)
                    : InvokeCallableTarget(target, call.TargetSpan, call.CallSpan, this, arguments);
            }
            finally { Array.Clear(arguments); }
        }
    }
}
