using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal ref partial struct ExecutableKernel
    {
        private bool TryExecuteDictionaryLoop(in ExecutableInstruction head)
        {
            var scope = _scope;
            var invocation = _invocation;
            // The ordinary ForNext owns wider/pending stack retirement. A
            // native source advances here only after that ownership is settled.
            if (_storage.LiveExtent != head.ResultSlot || _storage.HasPendingDisposals) return false;
            var headIndex = Index;
            var callIndex = head.DictionaryLoopCallIndex;
            var call = Code.CallSites[Code.Instructions[callIndex].CallSiteIndex];
            ref readonly var member = ref Code.Instructions[headIndex + 2];
            ref readonly var add = ref Code.Instructions[callIndex + 1];
            ref readonly var store = ref Code.Instructions[callIndex + 2];
            var fallback = Code.Constants[Code.Instructions[headIndex + 4].ConstantIndex]!;
            var increment = (BigInteger)Code.Constants[~add.SecondInput]!;
            var totalIndex = callIndex + 3;
            var hasTotal = Code.Instructions[totalIndex].OpCode == ExecutableOpCode.Augmented;
            ref readonly var total = ref Code.Instructions[totalIndex];
            var totalIncrement = hasTotal ? (BigInteger)Code.Constants[~total.SecondInput]! : BigInteger.Zero;
            // No callback can observe these uncaptured slots inside the native
            // segment. Observable namespaces retain their ordinary stores.
            var privateBindings = !Code.RequiresLocalVariableMirroring
                && invocation?.MirrorLocalStores != true && invocation?.GlobalNamespace is null;
            var deferTotal = hasTotal && privateBindings;
            var cursor = privateBindings
                ? Values[head.InputStart].Object.RequireNotNull() as PyStringOps.CasedWhitespaceIteration : null;
            if (cursor is not null && !ReferenceEquals(cursor.MemoryGovernor, scope.MemoryGovernor)) cursor = null;
            if (!TryReadDictionaryWord(cursor, head.InputStart, out var word, out var hasWord)) return false;
            if (!hasWord)
            {
                _storage.RetireTo(head.InputStart);
                Index = head.TargetIndex;
                return true;
            }
            var wordChanged = false;
            PyStringOps.CompactWord pendingWord = default;
            var totalChanged = false;
            long pendingTotal = 0;
            var exhausted = false;
            PyDict? dictionary = null;
            object? priorTotal = null;
            var wordFrameEntered = false;
            try
            {
                while (true)
                {
                    Index = headIndex;
                    var compact = word.Value is null;
                    if (compact)
                    {
                        // The callback-free segment keeps this binding private;
                        // publication precedes every continuation and unwind.
                        pendingWord = word;
                        wordChanged = true;
                    }
                    else
                    {
                        Publish(head, word.Value!);
                        wordChanged = false;
                    }
                    if (!wordFrameEntered)
                    {
                        // Observable bindings may admit/reenter. Private words
                        // use prepaid storage and leave these uncaptured slots
                        // unchanged until this callback-free segment ends.
                        scope.CheckExecution(member.Span);
                        dictionary = Values[store.SecondInput].Object as PyDict;
                        priorTotal = hasTotal ? Values[total.InputStart].Object : null;
                        if (dictionary is null || hasTotal &&
                            (priorTotal is not BigInteger integer || integer.GetByteCount() >= 8))
                        {
                            Index = headIndex + 2;
                            return true;
                        }
                    }
                    var key = compact ? null : Values[store.ThirdInput].Object as PyString;
                    if (!compact && key is null)
                    {
                        Index = headIndex + 2;
                        return true;
                    }

                    Index = callIndex;
                    if (!wordFrameEntered)
                    {
                        scope.EnterInterpreterFrame(call.CallSpan);
                        if (cursor is not null)
                        {
                            wordFrameEntered = true;
                            if (!dictionary!.CanAccumulateInlineWords(scope))
                            {
                                Index = headIndex + 2;
                                return true;
                            }
                        }
                    }
                    bool updated;
                    try
                    {
                        updated = compact
                            ? dictionary!.TryAccumulateInlineWord(PyStringOps.CompactWordBytes(ref word), fallback, increment, scope,
                                call.CallSpan)
                            : dictionary!.TryAccumulateWithoutAdmission(key!, fallback, increment, scope,
                                call.CallSpan);
                    }
                    finally { if (!wordFrameEntered) scope.LeaveInterpreterFrame(); }
                    if (!updated)
                    {
                        // Only the loop binding happened. The original body now
                        // performs any required admission/protocol, exactly once.
                        Index = headIndex + 2;
                        return true;
                    }
                    if (!wordFrameEntered) _storage.RetireTo(store.LiveExtent);
                    if (hasTotal)
                    {
                        Index = totalIndex;
                        // Retirement can refund/reenter. Observe a first refusal
                        // before performing the following Python store.
                        if (!wordFrameEntered) scope.CheckExecution(total.Span);
                        if (deferTotal)
                        {
                            // Both operands fit seven signed bytes. Stop this
                            // segment before that bound changes; the ordinary
                            // arithmetic path keeps exact promotion and admission.
                            var value = (totalChanged ? pendingTotal : (long)(BigInteger)priorTotal!) + (long)totalIncrement;
                            pendingTotal = value;
                            totalChanged = true;
                            if (value < -(1L << 55) || value >= (1L << 55))
                            {
                                Index = totalIndex + 2;
                                return true;
                            }
                        }
                        else
                        {
                            var value = AddExactIntegers((BigInteger)priorTotal!, totalIncrement, scope.MemoryGovernor, total.Span);
                            Publish(total, value);
                        }
                    }
                    Index = headIndex;
                    scope.CheckExecution(head.Span);
                    if (!TryReadDictionaryWord(cursor, head.InputStart, out var nextWord, out hasWord))
                        throw new InvalidOperationException("A native loop lost its private iteration source.");
                    if (hasWord) { word = nextWord; continue; }
                    exhausted = true;
                    Index = head.TargetIndex;
                    return true;
                }
            }
            finally
            {
                try { if (wordFrameEntered) scope.LeaveInterpreterFrame(); }
                finally
                {
                    // Publish before any continuation, callback or error handler.
                    // This private scalar store cannot admit or invoke guest code;
                    // it must not replace a cancellation or first refusal.
                    try
                    {
                        if (wordChanged) Values[store.ThirdInput].Object = cursor!.Materialize(ref pendingWord);
                    }
                    finally
                    {
                        if (totalChanged) Values[total.InputStart].Object = new BigInteger(pendingTotal);
                        // Returning the prepared ranges can refund storage and
                        // reenter. Publish both Python bindings before that point.
                        if (exhausted) _storage.RetireTo(head.InputStart);
                    }
                }
            }
        }

        private bool TryReadDictionaryWord(PyStringOps.CasedWhitespaceIteration? cursor, int slot, out PyStringOps.CompactWord word, out bool hasWord)
        {
            if (cursor is not null) { hasWord = cursor.TryReadWord(out word); return true; }
            word = default;
            if (!_storage.TryAdvanceNativeIteration(Values, slot, out hasWord, out var next)) return false;
            if (hasWord) word.Value = next.Object;
            return true;
        }

        private bool TryExecuteDictionaryAccumulation(ExecutableCallSite call, int start, PyDict dictionary, PyString key)
        {
            var context = _scope;
            ref readonly var add = ref Code.Instructions[Index + 1];
            ref readonly var store = ref Code.Instructions[Index + 2];
            // Future inputs are pure locals/constants. A missing or different
            // value leaves the original instructions to preserve read errors,
            // source spans and all dynamic evaluation/assignment behavior.
            if (!ReferenceEquals(Values[store.SecondInput].Object, dictionary)
                || !ReferenceEquals(Values[store.ThirdInput].Object, key)) return false;
            var source = add.SecondInput;
            var increment = source < 0 ? Code.Constants[~source] : Values[source].Object;
            if (increment is not BigInteger integer || integer.GetByteCount() >= 8) return false;
            var fallback = call.ArgumentCount == 2 ? Values[start + call.ArgumentOffset + 1].Object.RequireNotNull() : PyNone.Instance;
            context.EnterInterpreterFrame(call.CallSpan);
            try
            {
                if (!dictionary.TryAccumulateWithoutAdmission(key, fallback, integer, context,
                    call.CallSpan)) return false;
            }
            finally { context.LeaveInterpreterFrame(); }
            // Only the plain receiver/target/key/default inputs are retired.
            // Outer iteration and its ownership stay below this result slot.
            _storage.RetireTo(store.LiveExtent);
            Index += 2;
            return true;
        }
    }
}
