using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;
using System.Numerics;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Completed builtin value computation borrows final slots. It neither owns
    // operand retirement/publication nor manufactures asynchronous call state.
    // Unknown protocol values return before executing their operation.
    private static bool TryEvaluateBuiltinArithmetic(ExecutableCodeObject code, Span<ExecutableSlot> values,
        int index, ExecutionContext scope, out ExecutableSlot result)
    {
        result = default;
        ref readonly var instruction = ref code.Instructions[index];
        var augmented = instruction.OpCode == ExecutableOpCode.Augmented;
        if (augmented && instruction.AugmentedOperator == AugmentedAssignmentOperatorSyntax.MatrixMultiply)
            return false;
        var first = ReadExecutableOperand(code, values, instruction.InputStart, index, 0, scope);
        if (instruction.OpCode == ExecutableOpCode.Unary)
        {
            if (instruction.UnaryOperator == ExecutableUnaryOperator.Not ? !CanUseNativeTruth(first)
                : first is not (BigInteger or double or bool)) return false;
            result.Object = EvaluateExecutableUnary(instruction.UnaryOperator, first, scope, instruction.Span);
            return true;
        }
        var second = ReadExecutableOperand(code, values, instruction.SecondInput, index, 1, scope);
        if (!augmented && TryEvaluateScalarComparison(instruction.BinaryOperator, first, second,
            scope, instruction.Span, out var truth))
        {
            result.Object = RuntimeValue(truth);
            return true;
        }
        var operation = augmented ? AugmentedBinaryOperator(instruction.AugmentedOperator) : instruction.BinaryOperator;
        if (first is PyString && second is PyString)
        {
            if (operation != BinaryOperatorSyntax.Add) return false;
        }
        else
        {
            if (first is not (BigInteger or double or bool) || second is not (BigInteger or double or bool))
                return false;
            if (!(operation switch
            {
                BinaryOperatorSyntax.Add or BinaryOperatorSyntax.Subtract or BinaryOperatorSyntax.Multiply
                    or BinaryOperatorSyntax.FloorDivide or BinaryOperatorSyntax.Modulo or BinaryOperatorSyntax.Divide
                    or BinaryOperatorSyntax.Equal or BinaryOperatorSyntax.NotEqual or BinaryOperatorSyntax.Less
                    or BinaryOperatorSyntax.LessEqual or BinaryOperatorSyntax.Greater or BinaryOperatorSyntax.GreaterEqual => true,
                BinaryOperatorSyntax.BitwiseOr or BinaryOperatorSyntax.BitwiseXor or BinaryOperatorSyntax.BitwiseAnd
                    or BinaryOperatorSyntax.LeftShift or BinaryOperatorSyntax.RightShift => first is not double && second is not double,
                _ => false,
            })) return false;
        }
        result.Object = augmented
            ? EvaluateAugmentedBuiltin(first, second, instruction.AugmentedOperator, scope, instruction.Span)
            : EvaluateBinaryOperator(instruction.BinaryOperator, first, second, scope, instruction.Span);
        return true;
    }

    private static object ReadExecutableOperand(ExecutableCodeObject code, Span<ExecutableSlot> values,
        int source, int index, int input, ExecutionContext scope)
    {
        if (source < 0) return RuntimeValue(code.Constants[~source]);
        var value = values[source].Object;
        if (source < code.FirstTemporarySlot)
        {
            if (value is ExecutableCell cell) value = cell.Value;
            if (value is null) return LoadMissingLocal(code, source, code.OperandReadSpan(index, input), scope);
        }
        return value.RequireNotNull();
    }

    private static object TakeExecutableOperand(ExecutableCodeObject code, Span<ExecutableSlot> values,
        ref ExecutableValueStorage storage, int index, in ExecutableInstruction instruction, ExecutionContext scope)
    {
        if (instruction.InputStart >= code.FirstTemporarySlot)
            return storage.TakeValue(values, instruction.InputStart, instruction.LiveExtent);
        var value = ReadExecutableOperand(code, values, instruction.InputStart, index, 0, scope);
        storage.RetireTo(values, instruction.LiveExtent);
        return value;
    }

    internal ref partial struct ExecutableKernel
    {
        private bool TryArithmetic(in ExecutableInstruction instruction)
        {
            // Persistent cleanup still owns its general per-operation route.
            if (_persistent && !_storage.CanRetireWithoutCleanup(instruction.ResultSlot)) return false;
            try
            {
                var end = Index;
                ExecutableSlot value = default;
                var completed = instruction.OpCode != ExecutableOpCode.Unary &&
                    TryEvaluateIntegerInstruction(Code, Values, end, _scope, out end, out value);
                if (!completed && !TryEvaluateBuiltinArithmetic(Code, Values, end, _scope, out value)) return false;
                Index = end;
                Publish(Code.Instructions[end], value);
                return true;
            }
            catch
            {
                if (_persistent) Trim(instruction.ResultSlot);
                throw;
            }
        }
    }
}
