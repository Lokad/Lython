from pathlib import Path
import ast,datetime,hashlib,json,subprocess
r=Path(__file__).parent/'direct/quiet';c=json.loads((r/'config.json').read_text(encoding='utf-8'));old=json.loads((r.parents[1]/'quiet/config.json').read_text(encoding='utf-8'))
originals={};replacements={}
newunit='lython-b841-shared-kernel-direct-corrected-20261116'
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 p=r/n;s=p.read_text(encoding='utf-8');originals[n]=hashlib.sha256(s.encode()).hexdigest();(r/('initial-'+n)).write_text(s,encoding='utf-8',newline='\n')
 s=s.replace(old['root'],c['root']).replace(old['unit'],newunit).replace('B840','B841')
 assert old['root']not in s and old['unit']not in s
 assert c['root']in s
 if n.endswith('.py'):ast.parse(s)
 p.write_text(s,encoding='utf-8',newline='\n')
 if n!='retrieve.py':replacements[n]=s
assert "['calls.positional.large', 'warm']"in replacements['collect.py']and 'compile-run'not in replacements['collect.py'].split('jobs=')[1].split('\nassert len(jobs)')[0]
code='''from pathlib import Path
import ast,fcntl,hashlib,json,os,stat,subprocess
root=Path('/home/lokad/lython-bench-checks/shared-kernel-direct-b841-20261116')
originals=ORIGINALS
texts=TEXTS
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not(root/'guest-fixtures').exists()
 assert json.loads((root/'initial-failed-cleanup.json').read_text())['archivedAndVerifiedBeforeUnmount']
 for n,text in texts.items():
  p=root/n;m=p.lstat();assert stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and p.resolve()==p
  assert hashlib.sha256(p.read_bytes()).hexdigest()==originals[n]
  if n.endswith('.py'):ast.parse(text)
  p.write_text(text)
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 ident=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for n,h in ident['imageFiles'][role].items():assert hashlib.sha256((root/role/n).read_bytes()).hexdigest()==h
 catalog=json.loads((root/'representative.json').read_text());assert len(catalog['cases'])==6
 assert 'calls.positional.large'in {c['id']for c in catalog['cases']}
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b841-corrected-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit=lython-b841-shared-kernel-direct-corrected-20261116','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print('Validated all concrete paths,full images and six-case catalog; corrected collection launched. Original pre-worker failure preserved.')
'''.replace('ORIGINALS',repr(originals)).replace('TEXTS',repr(replacements))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=45)
(r/'correction-launch.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stderr
(r/'initial-config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8');c['unit']=newunit;(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat()),indent=2)+'\n',encoding='utf-8')
print(p.stdout)
