from pathlib import Path
import re
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439');base=w/'src/Lokad.Lython/Runtime'
def read(n):return(base/n).read_text(encoding='utf-8')
def save(n,s):(base/n).write_text(s,encoding='utf-8',newline='\n')
n='LythonRuntime.Executable.Kernel.cs';s=read(n)
s=s.replace('private readonly bool _persistent => _work.Stack.IsPersistent;', 'private readonly bool _persistent => _storage.IsPersistent;')
s=s.replace('private readonly ref ExecutableWorkState _work;', 'private readonly ref ExecutableValueStorage _storage;\n        private readonly ref int _index;\n        private readonly IReadOnlyList<ExecutableCell>? _cells;')
s=s.replace('private readonly bool _consumedByIteration => _work.ReturnConsumedByIteration;', 'private readonly bool _consumedByIteration;')
s=s.replace('_work.InstructionIndex','_index').replace('_work.Stack','_storage').replace('_work.ClosureCells','_cells')
a=s.index('        internal ExecutableKernel(PyExecutableFunction function,');b=s.index('        internal void ExecuteClosedPrefix()',a)
s=s[:a]+'''        internal ExecutableKernel(PyExecutableFunction function, Span<ExecutableSlot> values,
            ref ExecutableValueStorage storage, ref int index, bool consumedByIteration, int unpackedReturnCount)
        {
            _scope = function.DefinitionContext;
            _storage = ref storage;
            _index = ref index;
            Code = function.CodeObject;
            _cells = function.ClosureCells;
            _consumedByIteration = consumedByIteration;
            Values = values;
            _unpackedReturnCount = unpackedReturnCount;
        }

        internal ExecutableKernel(ref ExecutableWorkState work, ExecutionContext scope, ExecutionContext? invocation)
        {
            _storage = ref work.Stack;
            _index = ref work.InstructionIndex;
            Code = work.Code;
            _cells = work.ClosureCells;
            _consumedByIteration = work.ReturnConsumedByIteration;
            Values = work.Stack.Values;
            _scope = scope;
            _invocation = invocation;
        }

'''+s[b:]
s=s.replace('TryLoadClosure(in _work, _invocation, instruction.ClosureSlot, instruction.Span, out var captured)', 'TryLoadClosure(instruction.ClosureSlot, instruction.Span, out var captured)')
s=s.replace('TryStoreClosure(ref _work, Values, _scope, _invocation, instruction)', 'TryStoreClosure(instruction)')
s=s.replace('ExecutionContext.TryExecuteDictionaryLoop(ref _work, _scope, _invocation, instruction)', 'TryExecuteDictionaryLoop(instruction)')
s=s.replace('ExecutionContext.TryExecuteDictionaryAccumulation(\n                            ref _work, _scope, call, start, dictionary, (PyString)key)', 'TryExecuteDictionaryAccumulation(\n                            call, start, dictionary, (PyString)key)')
s=s.replace('ExecutionContext.PrepareUnpackedCallReturn(ref _work, call, start, out originalExtent)', 'ExecutionContext.PrepareUnpackedCallReturn(Values, ref _storage, call, start, out originalExtent)')
s=s.replace('ExecutionContext.CompleteUnpackedCallReturn(ref _work, _scope, start, unpackedCount)', 'ExecutionContext.CompleteUnpackedCallReturn(Code, Values, ref _storage, ref _index, _scope, start, unpackedCount)')
s=s.replace('TakeExecutableOperand(ref _work, Values, instruction, _scope)', 'TakeExecutableOperand(Code, Values, ref _storage, Index, instruction, _scope)')
s=s.replace('PublishExecutableSlot(ref _work, Values, _invocation, instruction, value)', 'PublishExecutableSlot(Code, Values, ref _storage, ref _index, _invocation, instruction, value)')
assert '_work'not in s;save(n,s)

n='LythonRuntime.Executable.Arithmetic.cs';s=read(n).replace('private static object TakeExecutableOperand(ref ExecutableWorkState work, Span<ExecutableSlot> values,\n        in ExecutableInstruction instruction, ExecutionContext scope)', 'private static object TakeExecutableOperand(ExecutableCodeObject code, Span<ExecutableSlot> values,\n        ref ExecutableValueStorage storage, int index, in ExecutableInstruction instruction, ExecutionContext scope)')
s=s.replace('work.Code','code').replace('work.Stack','storage').replace('work.InstructionIndex','index').replace('_work.Stack','_storage');save(n,s)
n='LythonRuntime.Executable.Interpreter.cs';s=read(n).replace('TakeExecutableOperand(ref execution, execution.Stack.Values, instruction, scope)', 'TakeExecutableOperand(execution.Code, execution.Stack.Values, ref execution.Stack, execution.InstructionIndex, instruction, scope)');save(n,s)

n='LythonRuntime.Executable.Results.cs';s=read(n).replace('PublishExecutableSlot(ref execution, execution.Stack.Values, invocation, instruction, value)', 'PublishExecutableSlot(execution.Code, execution.Stack.Values, ref execution.Stack, ref execution.InstructionIndex, invocation, instruction, value)')
s=s.replace('private static void PublishExecutableSlot(ref ExecutableWorkState execution, Span<ExecutableSlot> values,', 'private static void PublishExecutableSlot(ExecutableCodeObject code, Span<ExecutableSlot> values,\n        ref ExecutableValueStorage storage, ref int index,')
a=s.index('    private static void PublishExecutableSlot(');b=s.index('    // Captured cells own',a);body=s[a:b].replace('execution.Stack','storage').replace('execution.Code','code').replace('execution.InstructionIndex','index');s=s[:a]+body+s[b:];save(n,s)

n='LythonRuntime.Executable.Binding.cs';s=read(n)
a=s.index('    private static bool TryLoadClosure(');b=s.index('    private static object ResolveExecutableGlobal(',a);load=s[a:b];s=s[:a]+s[b:]
a=s.index('    private static bool TryStoreClosure(');b=s.index('    private static void StoreExecutableClosure(',a);store=s[a:b];s=s[:a]+s[b:]
load=load.replace('private static bool TryLoadClosure(in ExecutableWorkState execution, ExecutionContext? context,\n        int slot, LythonSourceSpan span, out object value)', 'private bool TryLoadClosure(int slot, LythonSourceSpan span, out object value)')
load=load.replace('execution.Code','Code').replace('execution.ClosureCells','_cells');load=re.sub(r'\bcontext\b','_invocation',load)
store=store.replace('private static bool TryStoreClosure(ref ExecutableWorkState execution, Span<ExecutableSlot> values,\n        ExecutionContext scope, ExecutionContext? context, in ExecutableInstruction instruction)', 'private bool TryStoreClosure(in ExecutableInstruction instruction)')
store=store.replace('execution.ClosureCells','_cells').replace('execution.Code','Code').replace('TakeExecutableOperand(ref execution, values, instruction, scope)','Take(instruction)');store=re.sub(r'\bcontext\b','_invocation',store)
insert='    internal ref partial struct ExecutableKernel\n    {\n'+''.join('    '+line+'\n'for line in(load+store).splitlines())+'    }\n\n'
a=s.index('    private static object ResolveExecutableGlobal(');s=s[:a]+insert+s[a:];save(n,s)

n='LythonRuntime.Executable.Calls.Invoke.cs';s=read(n)
a=s.index('        internal static Span<ExecutableSlot> PrepareUnpackedCallReturn');b=s.index('        internal static void AbortPreparedNativeCall(',a);part=s[a:b]
part=part.replace('PrepareUnpackedCallReturn(ref ExecutableWorkState execution,', 'PrepareUnpackedCallReturn(Span<ExecutableSlot> values, ref ExecutableValueStorage storage,')
part=part.replace('CompleteUnpackedCallReturn(ref ExecutableWorkState execution,\n            ExecutionContext scope,', 'CompleteUnpackedCallReturn(ExecutableCodeObject code, Span<ExecutableSlot> values,\n            ref ExecutableValueStorage storage, ref int index, ExecutionContext scope,')
part=part.replace('execution.Stack.Values.AsSpan(', 'values.Slice(').replace('execution.Stack','storage').replace('execution.Code','code').replace('execution.InstructionIndex','index')
s=s[:a]+part+s[b:];save(n,s)
n='LythonRuntime.Executable.Calls.cs';s=read(n).replace('PrepareUnpackedCallReturn(ref _execution, site, start, out originalExtent)', 'PrepareUnpackedCallReturn(_execution.Stack.Values, ref _execution.Stack, site, start, out originalExtent)').replace('CompleteUnpackedCallReturn(ref _execution, this, start, site!.UnpackedReturnCount)', 'CompleteUnpackedCallReturn(_execution.Code, _execution.Stack.Values, ref _execution.Stack, ref _execution.InstructionIndex, this, start, site!.UnpackedReturnCount)');save(n,s)

n='LythonRuntime.Executable.DictionaryAccumulation.cs';s=read(n).replace('internal sealed partial class ExecutionContext','internal ref partial struct ExecutableKernel')
s=s.replace('internal static bool TryExecuteDictionaryLoop(ref ExecutableWorkState execution, ExecutionContext scope,\n            ExecutionContext? invocation, in ExecutableInstruction head)\n        {', 'private bool TryExecuteDictionaryLoop(in ExecutableInstruction head)\n        {\n            var scope = _scope;\n            var invocation = _invocation;')
s=s.replace('private static bool TryReadDictionaryWord(ref ExecutableWorkState execution,\n            PyStringOps.CasedWhitespaceIteration? cursor', 'private bool TryReadDictionaryWord(PyStringOps.CasedWhitespaceIteration? cursor')
s=s.replace('internal static bool TryExecuteDictionaryAccumulation(ref ExecutableWorkState execution, ExecutionContext context,\n            ExecutableCallSite call, int start, PyDict dictionary, PyString key)\n        {', 'private bool TryExecuteDictionaryAccumulation(ExecutableCallSite call, int start, PyDict dictionary, PyString key)\n        {\n            var context = _scope;')
s=s.replace('TryReadDictionaryWord(ref execution, ', 'TryReadDictionaryWord(').replace('PublishInstructionResult(ref execution, invocation, ', 'Publish(')
s=s.replace('execution.Stack.Values','Values').replace('execution.Locals','Values').replace('execution.InstructionIndex','Index').replace('execution.Code','Code')
s=re.sub(r'execution\.Stack\[([^\]]+)\]',r'Values[\1].Object.RequireNotNull()',s).replace('execution.Stack','_storage')
assert 'execution.'not in s and 'ref execution'not in s;save(n,s)

n='PyExecutableFunction.cs';s=read(n);a=s.index('        var work = new LythonRuntime.ExecutableWorkState');b=s.index('        var entered = false;',a)
s=s[:a]+'''        var storage = new LythonRuntime.ExecutableValueStorage(_codeObject, Closure.State, this);
        var index = _codeObject.EntryIndex;
        var state = new LythonRuntime.ExecutableKernel(this, values, ref storage, ref index,
            consumedByIteration, unpackedReturn.Length);
'''+s[b:];save(n,s)
p=w/'tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs';s=p.read_text(encoding='utf-8');s=s.replace('''            var work = new LythonRuntime.ExecutableWorkState
            { Code = code, ClosureCells = [], ReturnConsumedByIteration = true };
            var execution = new LythonRuntime.ExecutableKernel(function, values, ref work, default)''','''            var storage = new LythonRuntime.ExecutableValueStorage(code, context.State, function);
            var execution = new LythonRuntime.ExecutableKernel(function, values, ref storage, ref index, true, default)''');p.write_text(s,encoding='utf-8',newline='\n')
print('Private full WorkState removed. Existing kernel borrows actual index/storage; common operand/publication/closure/dictionary/unpack helpers use those primitives. No new type,controller,mode or state synchronization.')
