from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/shared-kernel-r439';d=r/'direct';d.mkdir();f=d/'frozen';f.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((r/'refined/frozen/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 shutil.copytree(r/'frozen/reference',f/role)
 if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
assert images['reference']==prior['images']['reference']and all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
sources={n:sha((w/n).read_bytes())for n in prior['sources']};changed=[n for n,h in sources.items()if h!=prior['sources'][n]];assert len(changed)==10,changed
identity=dict(prior,images=images,sources=sources,refinement=json.loads((r/'direct-borrow-decision.json').read_text(encoding='utf-8')),previousCandidateImage=prior['images']['candidate']['Lokad.Lython.dll'],firstAdverseEvidenceCommit='a3d87c5f',attributionEvidenceCommit='b9b66020')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'direct-borrows-checks').glob('*.trx')];assert len(checks)==4 and sorted(int(x['passed'])for x in checks)==[1787,1787,1976,1976]and all(x['failed']=='0'for x in checks)
(d/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalBothTargetReleaseBuild=True,earlierBroadChecks='First coherent91ca call/continuation2838/6402 per runtime; recorded separately,not summed.',fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 for n in sources:t.add(w/n,arcname=n)
 t.add(r/'direct-borrows-checks',arcname='checks');t.add(r/'direct-borrows-final-build.log',arcname='build.log');t.add(w/'docs/RUNTIME.md',arcname='docs/RUNTIME.md')
a=d/'allocation-short';a.mkdir()
for n in ['Program.cs','Allocation.csproj','catalog.json']:shutil.copyfile(r/'allocation-short'/n,a/n)
shutil.copytree(r/'allocation-short/bin',a/'bin');shutil.copyfile(r/'measure-allocation.py',d/'measure-allocation.py')
q=d/'quiet';q.mkdir();before=json.loads((r/'refined/quiet/config.json').read_text(encoding='utf-8'));root='/home/lokad/lython-bench-checks/shared-kernel-direct-b841-20261116';unit='lython-b841-shared-kernel-direct-20261116';files=before['identity']['imageFiles']['reference'];imageFiles={role:{n:images[role][n]for n in files}for role in ['reference','candidate']}
ident=dict(before['identity'],sourceRevision='R439 direct index/storage borrows '+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified312f5911/0443b5cf',purpose='One changed-source private-state deletion comparison after B838/B840 adversity and B839 attribution. Six-case catalog includes existing ordinary-call diagnostic; six warm jobs and independent controls. No cross-collection source gain.',coreSHA256={label:imageFiles['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=imageFiles,candidateFocusedChecks=json.loads((d/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()))
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(r/'quiet/representative.json',q/'representative.json')
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(r/'quiet'/n).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B838','B840')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
catalog=json.loads((q/'representative.json').read_text(encoding='utf-8'))
calls=next(c for c in json.loads((r/'allocation-short/catalog.json').read_text(encoding='utf-8'))['cases']if c['id']=='calls.positional.large');calls=dict(calls);calls.pop('runAsync',None);catalog['cases'].append(calls)
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=q/'collect.py';body=p.read_text(encoding='utf-8').replace("['scripts.text-normalization.large', 'compile-run']", "['calls.positional.large', 'warm']");assert body!=p.read_text(encoding='utf-8');ast.parse(body);p.write_text(body,encoding='utf-8',newline='\n')
shutil.copyfile(r/'launch-quiet.py',d/'launch-quiet.py');shutil.copyfile(r/'summarize.py',d/'summarize.py')
# The exact first-prototype image has two current aliases. The final remote
# preflight verifies every alias/UID/path/hash before any retirement.
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();proofs=[]
specs=[('benchmarks/results/2026-11-16-shared-executable-kernel/refined/procedure-and-image.tar.xz','frozen/candidate/Lokad.Lython.dll',['shared-kernel-refine-b840-20261116/candidate/Lokad.Lython.dll']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz',None,['shared-kernel-refine-b840-20261116/observations.tgz']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz','confirmation/confirmation.json',['shared-kernel-refine-b840-20261116/confirmation/confirmation.json']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz','representative.json',['shared-kernel-b838-20261116/representative.json','shared-kernel-attribution-b839-20261116/catalog.json','shared-kernel-refine-b840-20261116/representative.json'])]
for archive,member,paths in specs:
 raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile(member).read()
 else:content=raw
 proofs.append(dict(bytes=len(content),sha256=sha(content),links=len(paths),paths=paths,custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha((q/'representative.json').read_bytes()),identity=ident,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'candidate'","source/'reference'")
s=s.replace('lython-b838-fixtures','lython-b841-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(core=images['candidate']['Lokad.Lython.dll'],changedSources=changed,inputs=len(sources),jobs=6,unpackedBytes=c['unpackedBytes'],retireGroups=[x['paths']for x in proofs],retireBytes=sum(x['bytes']for x in proofs),catalogUnchanged=sha((q/'representative.json').read_bytes())==before['catalogSHA256'])))
