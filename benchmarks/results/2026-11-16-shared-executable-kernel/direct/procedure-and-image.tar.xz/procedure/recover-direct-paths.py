from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'direct/quiet';c=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/shared-kernel-direct-b841-20261116')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show','lython-b841-shared-kernel-direct-20261116.service','--property=MainPID,ActiveState,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in service and 'ActiveState=failed'in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 trace=root/'guest-fixtures';assert trace.is_mount();assert not list(trace.iterdir())
 journal=subprocess.check_output(['journalctl','-u','lython-b841-shared-kernel-direct-20261116.service','--no-pager'],text=True)
 (root/'initial-failed-service.txt').write_text(service);(root/'initial-failed-journal.txt').write_text(journal)
 # The stale run.sh wrote only the old collection's redundant exit marker.
 old=root.parent/'shared-kernel-b838-20261116/exit-code.txt'
 before=old.read_bytes();assert before==b'1\\n',before
 (root/'initial-stale-marker.txt').write_bytes(before)
 archive=root/'initial-failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz')as t:
  for p in root.iterdir():
   if p.is_file()and p!=archive:t.add(p,arcname=p.name)
  t.add(trace,arcname='guest-fixtures')
 with tarfile.open(archive)as t:
  assert t.extractfile('initial-stale-marker.txt').read()==before
  assert b'FileNotFoundError'in t.extractfile('initial-failed-journal.txt').read()
 subprocess.run(['sudo','-n','umount',str(trace)],check=True);trace.rmdir()
 # Original B838 terminal is already independently archived/committed. Restore
 # that exact old marker only; retain B841's failure and stale-marker evidence.
 old.write_bytes(b'0\\n')
 receipt=dict(complete=True,failedBeforeWorker=True,emptyRamArea=True,allUsersJoined=True,archivedAndVerifiedBeforeUnmount=True,originalB838MarkerRestoredFromCommittedEvidence=True,service=service,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(root).free)
 (root/'initial-failed-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'initial-failed-terminal.json').write_text(p.stdout,encoding='utf-8');receipt=json.loads(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['initial-failed-observations.tgz','initial-failed-cleanup.json']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+c['root']+'/'+n,str(r/n)],capture_output=True);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'initial-failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(json.dumps(receipt))
