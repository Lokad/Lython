from pathlib import Path
import ast,json
r=Path(__file__).parent;repo=Path('D:/code/Lython')
decision=dict(hypothesis='Private completed entry initializes a full ExecutableWorkState solely to lend code/index/storage/cells to the shared kernel. Borrow actual primitive index/storage instead,while keeping immutable code/cell references; eliminate unused private WorkState fields and work-state-specific common helper contracts.',eliminated='Full ExecutableWorkState construction in PyExecutableFunction.StartInline and CasedSplitOwnership private setup. Existing kernel no longer retains a WorkState reference. Publication/operand/unpack helpers take actual code,slots,storage,index; closure/dictionary handlers are one kernel implementation.',preserved='One closed dispatch,existing persistent/deferred work and real frame driver,actual PC/live extent across callbacks,stable cell identities,first cleanup frontier,private cursor/child transfer,observed aliases,current cancellation and terminal refusal. No new type,controller,mode,owner,Unsafe API,ref-escape annotation or copied/synchronized PC.',workloads=['CSV invoice','normalization','captured-helper text','protected search','JSON helpers','ordinary positional calls diagnostic'],semanticAcceptance='Both-target nonincremental Release build and1787internal/1976public per actual11/10 focused regressions. Complete allocation goldens/cleanup and fixed-catalog source controls before retention.',measurement='One six-job warm changed-source pair against qualified0443; add existing positional calls to both catalogs and replace unchanged fresh-normalization job. New catalog must not be compared causally with B838/B840. Allocation and CPU remain separate. Preserve all adverse images/controls and B839 unknowns/initial failure.',completion='Managed primitive borrows working with private full state removed,then explicit retain/refine/remove and residual-debt decision. Full platform/stress/installed consumers at retention,not every prototype. Broader performance objective and independent regex track remain active.',performanceClaim=False,retained=False)
(r/'direct-borrow-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'prepare-refined.py').read_text(encoding='utf-8')
s=s.replace("d=r/'refined'", "d=r/'direct'")
s=s.replace("(r/'frozen/identity.json')", "(r/'refined/frozen/identity.json')")
s=s.replace("assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Kernel.cs'],changed", "assert len(changed)==10,changed")
s=s.replace("r/'refinement-decision.json'", "r/'direct-borrow-decision.json'")
s=s.replace("firstAdverseImage=prior['images']['candidate']['Lokad.Lython.dll']", "previousCandidateImage=prior['images']['candidate']['Lokad.Lython.dll']")
s=s.replace("r/'refined-facts-checks'", "r/'direct-borrows-checks'").replace("r/'refined-facts-build.log'", "r/'direct-borrows-final-build.log'")
s=s.replace('[45,45,143,143]', '[1787,1787,1976,1976]')
s=s.replace("r/'quiet/config.json'", "r/'refined/quiet/config.json'")
s=s.replace('shared-kernel-refine-b840-20261116','shared-kernel-direct-b841-20261116').replace('lython-b840-shared-kernel-refine-20261116','lython-b841-shared-kernel-direct-20261116')
s=s.replace('R439 immutable-fact refinement ', 'R439 direct index/storage borrows ')
s=s.replace('One changed-source shared-kernel comparison after B838 adversity and B839 attribution. Identical five-case catalog,six complete jobs and independent source controls. No cross-collection gain claim.', 'One changed-source private-state deletion comparison after B838/B840 adversity and B839 attribution. Six-case catalog includes existing ordinary-call diagnostic; six warm jobs and independent controls. No cross-collection source gain.')
needle="(q/n).write_text(s,encoding='utf-8',newline='\\n')\nshutil.copyfile"
assert s.count(needle)==1
s=s.replace(needle,"""(q/n).write_text(s,encoding='utf-8',newline='\\n')
catalog=json.loads((q/'representative.json').read_text(encoding='utf-8'))
calls=next(c for c in json.loads((r/'allocation-short/catalog.json').read_text(encoding='utf-8'))['cases']if c['id']=='calls.positional.large');calls=dict(calls);calls.pop('runAsync',None);catalog['cases'].append(calls)
(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8',newline='\\n')
p=q/'collect.py';body=p.read_text(encoding='utf-8').replace("['scripts.text-normalization.large', 'compile-run']", "['calls.positional.large', 'warm']");assert body!=p.read_text(encoding='utf-8');ast.parse(body);p.write_text(body,encoding='utf-8',newline='\\n')
shutil.copyfile""")
a=s.index('specs=');b=s.index('\nfor archive,member,paths in specs:',a)
s=s[:a]+"""specs=[('benchmarks/results/2026-11-16-shared-executable-kernel/refined/procedure-and-image.tar.xz','frozen/candidate/Lokad.Lython.dll',['shared-kernel-refine-b840-20261116/candidate/Lokad.Lython.dll']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz',None,['shared-kernel-refine-b840-20261116/observations.tgz']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz','confirmation/confirmation.json',['shared-kernel-refine-b840-20261116/confirmation/confirmation.json']),('benchmarks/results/2026-11-16-shared-executable-kernel/refined/observations.tgz','representative.json',['shared-kernel-b838-20261116/representative.json','shared-kernel-attribution-b839-20261116/catalog.json','shared-kernel-refine-b840-20261116/representative.json'])]"""+s[b:]
s=s.replace("['identity.json','collect.py','archive-owned.py','run.sh']", "['identity.json','representative.json','collect.py','archive-owned.py','run.sh']")
s=s.replace("catalogSHA256=before['catalogSHA256'],identity=ident", "catalogSHA256=sha((q/'representative.json').read_bytes()),identity=ident")
# New catalog is included in the payload; use the original launcher that does
# not hardlink the old catalog after its verified replicas are retired.
a=s.index('s=(r/\'quiet/remote-launch.py\')');b=s.index("s=s.replace('lython-b838-fixtures'",a)
s=s[:a]+"""s=(r/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'candidate'","source/'reference'")
"""+s[b:]
s=s.replace('lython-b840-fixtures','lython-b841-fixtures')
ast.parse(s);(r/'prepare-direct.py').write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';text=p.read_text(encoding='utf-8');text=text.replace('direct index/storage borrow migration next. No retention/full delivery.', 'direct index/storage migration implemented; Release1787internal/1976public pass eachactual11/10. Changed-source comparison next; no retention/full delivery.')
text=text.replace('Next coherent migration removes full ExecutableWorkState initialization from', 'Implemented coherent migration removes full ExecutableWorkState initialization from')
text=text.replace('The existing kernel borrows actual index and\nExecutableValueStorage directly; immutable code/cell-array references remain', 'The existing kernel now borrows actual index and\nExecutableValueStorage directly; immutable code/cell-array references remain')
text=text.replace('Stop at working managed primitive borrows with no unused full state on private\nentry,focused semantic/cancellation/ownership checks and one bounded changed-source\ncomparison with controls.', 'Both-target nonincremental Release build and1787internal/1976public eachactual\n11/10 pass. No Unsafe/ref-escape annotations. Next freeze609inputs and run complete\nallocation/cleanup diagnostics plus one six-warm-job source pair with controls.\nThe new identical six-case catalog adds existing ordinary calls; replacing fresh\nnormalization avoids unchanged compilation work. Preserve catalog/init differences;\nno causal cross-collection comparison. Private full state is removed.')
p.write_text(text,encoding='utf-8',newline='\n')
print('Prepared direct-borrow stage and explicit six-warm-job boundary; original B838/B840 conditions remain preserved.')
