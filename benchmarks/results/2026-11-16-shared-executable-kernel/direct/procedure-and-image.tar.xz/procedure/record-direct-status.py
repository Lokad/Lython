from pathlib import Path
import json
r=Path(__file__).parent;repo=Path('D:/code/Lython')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('The kernel borrows a managed Span');b=s.index('\nUnify call selection/publication',a)
s=s[:a]+'''The existing kernel borrows final managed slots plus references to the actual
instruction index and value-storage metadata. Private completed calls supply
their existing inline/bound slots,one storage value and an index local; no full
ExecutableWorkState is initialized for them. Persistent/deferred array execution
borrows those actual fields in its existing WorkState. Code,closure-cell-array
identity and return-consumption flags are immutable invocation facts; cell values,
PC and live extent stay live. No copied PC synchronized after callbacks,per-call
heap controller,virtual storage,ref-escape annotation,stored mode or new owner.
Persistent retirement clears/queues actual async cleanup; private dead references
end at bounded prefix exit/transfer. Locals keeps its actual loan-return handle.
'''+s[b:]
s=s.replace('Main runtime remains\nqualified0443,evidence commitsa3d87c5f/b9b66020;', 'Direct stageba4ad0ec freezes609inputs. B841six warm jobs are running with the\nnew six-case catalog; local eight-job goldens/cleanup pass,allocation flat(<0.05%\nabsolute changes),accounted peaks unchanged. No CPU/retention claim. Main branch\n8ff5fdfd/runtimequalified0443,evidencea3d87c5f/b9b66020/8ff5fdfd;')
s=s.replace('Before each selected redesign record hypothesis,complete workloads,eliminated stage,', 'Import execution consolidation stays a later,separate milestone. Keep the lowered\nevaluator for actual import/class/annotation and opcode consumers.\n\nBefore each selected redesign record hypothesis,complete workloads,eliminated stage,')
p.write_text(s,encoding='utf-8',newline='\n')
status=dict(stage='Direct actual index/storage borrows; private full WorkState removed',frozenCore='ba4ad0ecf926d05a2afb59530844502cc944070672c3aa910823abbb5a25af36',sourceInputs=609,checksEachRuntime=dict(internal=1787,public=1976),nonincrementalBothTargetReleaseBuild=True,unsafeOrRefEscapeAnnotations=False,allocation=json.loads((r/'direct/allocation-summary.json').read_text(encoding='utf-8')),quietComparison='B841 six warm jobs running; observe after recorded not-before',productionRetention=False,fullQualificationPending=True,performanceClaim=False)
(r/'current-stage-checks.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'DESIGN.md';s=p.read_text(encoding='utf-8');a=s.index('Frozen91ca4a41');b=s.index('Persistent publish/retire',a)
s=s[:a]+'''Current direct-borrow stageba4ad0ec/609inputs: no retained runtime change.
One closed loop shares both slot lifetimes; ordinary duplicate handlers/call
selection and compiler full-opcode inventory are removed. No temporary gate.
The existing kernel borrows actual instruction index and ExecutableValueStorage
directly. Private calls use one existing storage value/index local,removing full
ExecutableWorkState initialization. Persistent/deferred work keeps its real state.
Code,cell-array identity and return flags are immutable invocation facts; cell
values and PC/live extent remain live during callbacks. No extra state type,
controller,mode,owner,Unsafe API,ref-escape annotation or PC synchronization.

Common operand/publication/unpack helpers consume those actual primitives;
closure/dictionary handlers are one kernel implementation. Existing driver owns
genuine protocols,suspension,exception/return/finally and prepared-child routing.
Nonincremental both-target Release plus1787internal/1976public eachactual11/10
pass. Eight local complete jobs pass goldens/budget cleanup; allocation flat,
accounted peaks unchanged. B841 six warm jobs running; no CPU/retention claim.

Prior91ca/B838 and4f73/B840 remain frozen/committed with all adverse/moving controls.
B839 attribution does not isolate a causal added call bottleneck. Its original
identity-schema pre-worker failure and corrected raw/map evidence are preserved;
all users joined and traces archived/verified before unmount. All terminals cached.
No causal cross-collection gain: B841 adds the existing ordinary-call diagnostic
and drops unchanged fresh normalization from the timed jobs.

Earlier overlapping passing stages remain separate. Final direct sources/checks
are in direct/frozen/sources-and-checks.tar.xz. No intermediate allocation/CPU
improvement or broad qualification claim. Full delivery remains at retention.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n');print('Recorded current direct-borrow ownership/PC contract,exact prototype state and independent later import scope.')
