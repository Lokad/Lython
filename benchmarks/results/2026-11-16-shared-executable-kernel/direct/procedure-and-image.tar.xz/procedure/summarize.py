from pathlib import Path
import json,statistics
r=Path(__file__).parent;raw=json.loads((r/'quiet/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==6;rows=[]
for j in raw['jobs']:
 med={};cpu={};iqr={}
 for label in j['identities']:
  samples=[s for s in j['samples']if s['engine']==label]
  timings=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in samples]
  med[label]=statistics.median(timings)
  quartiles=statistics.quantiles(timings,n=4,method='inclusive');iqr[label]=100*(quartiles[2]-quartiles[0])/med[label]
  cpu[label]=statistics.median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in samples)
 change=lambda values:sorted(100*(values[a]/values[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control'])
 spread=lambda role:100*(max(med[role],med[role+'-control'])/min(med[role],med[role+'-control'])-1)
 rows.append(dict(case=j['case'],lane=j['lane'],elapsedMilliseconds=med,cpuMilliseconds=cpu,elapsedIQRPercent=iqr,elapsedChangePercent=change(med),cpuChangePercent=change(cpu),referenceSpreadPercent=spread('reference'),candidateSpreadPercent=spread('candidate')))
(r/'summary.json').write_text(json.dumps(dict(complete=True,elapsedSeconds=raw['elapsedSeconds'],quietBeforeAndAfter=True,allUsersJoinedAndFixturesRemoved=True,rows=rows,retentionDecisionPending=True,CPythonRefreshed=False),indent=2)+'\n',encoding='utf-8',newline='\n')
for x in rows:print(x['case'],x['lane'],'elapsed',x['elapsedChangePercent'],'CPU',x['cpuChangePercent'],'spreads',x['referenceSpreadPercent'],x['candidateSpreadPercent'],'maxIQR',max(x['elapsedIQRPercent'].values()))
