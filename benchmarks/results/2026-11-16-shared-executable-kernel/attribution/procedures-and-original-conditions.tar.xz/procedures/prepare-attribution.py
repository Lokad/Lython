from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'matched-calls-r414/profile';q=r/'profile';q.mkdir()
root='/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116';unit='lython-b839-shared-kernel-attribution-20261116';priorRoot='/home/lokad/lython-bench-checks/matched-calls-b808-20261115'
ident=json.loads((r/'quiet/identity.json').read_text(encoding='utf-8'));ident.update(purpose='One bounded matched source CPU attribution after adverse coherent-kernel B838. Same complete captured-helper script; profiling overrides,not a timing/source-speedup comparison.',priorComparison='B838 all six jobs206.412s; raw adverse evidence committeda3d87c5f; unchanged qualification not repeated.')
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['ops-profile.py','collect.py','run.sh']:
    s=(old/n).read_text(encoding='utf-8').replace(priorRoot,root)
    if n=='ops-profile.py':
        s=s.replace("[('inline','scripts.helper-boundary.inline','warm'),('helper','scripts.helper-boundary.helper','warm')]", "[('reference','scripts.text-summary-helpers.nonlocal-counter.large','warm'),('candidate','scripts.text-summary-helpers.nonlocal-counter.large','warm')]")
        s=s.replace('worker = tree / "candidate/Lokad.Lython.Benchmarks.dll"','worker = tree / name / "Lokad.Lython.Benchmarks.dll"')
        s=s.replace("expected['coreSHA256']['candidate']", "expected['coreSHA256'][name]")
        s=s.replace('count = 512 # Existing complete matched scripts; bounded warmed CPU attribution.', 'count = 256 # Same complete captured script per source; bounded attribution,not a timing comparison.')
    if n=='collect.py':
        s=s.replace("['inline','helper']", "['reference','candidate']")
        s=s.replace('Committed2865f619/frozen55ba4c8a; R414 matched helper/inline attribution', 'R439/B839 matched source attribution,91ca4a41 versus0443b5cf; elapsed not comparable with unprofiled B838')
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
sha=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();archive='benchmarks/results/2026-11-16-shared-executable-kernel/observations.tgz';raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive]);proofs=[]
for relative,member in [('observations.tgz',None),('confirmation/confirmation.json','confirmation/confirmation.json')]:
    if member:
        with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile(member).read()
    else:content=raw
    proofs.append(dict(bytes=len(content),sha256=sha(content),links=1,paths=['shared-kernel-b838-20261116/'+relative],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes()for n in ['identity.json','ops-profile.py','collect.py','run.sh']}
with tarfile.open(q/'payload.tgz','w:gz')as t:
    for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
previous=json.loads((r/'quiet/config.json').read_text(encoding='utf-8'))
c=dict(root=root,unit=unit,source=previous['root'],sourceFiles=ident['imageFiles']['reference'],sourceCatalogSHA256=previous['catalogSHA256'],catalogSHA256=previous['catalogSHA256'],identity=ident,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("for n,h in c['sourceFiles'].items():assert sha(source/'candidate'/n)==h,n", "for n,h in c['sourceFiles'].items():assert sha(source/'reference'/n)==h,n")
s=s.replace("os.link(source/'candidate'/n,p)","os.link(source/role/n,p)")
s=s.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py');assert sha(root/'representative.json')==c['catalogSHA256']", " os.link(source/'catalog.json' if (source/'catalog.json').exists() else source/'representative.json',root/'catalog.json')\n assert sha(root/'catalog.json')==c['catalogSHA256']")
s=s.replace("for n in ['collect.py','archive-owned.py']", "for n in ['collect.py','ops-profile.py']")
s=s.replace('lython-b838-fixtures','lython-b839-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=150')
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch-quiet.py').read_text(encoding='utf-8').replace("__file__).parent/'quiet'", "__file__).parent/'profile'").replace('seconds=200','seconds=90').replace('Six-job shared-kernel comparison launched; do not poll before200seconds.','Two-source CPU attribution launched; do not observe before90seconds.');ast.parse(s);(r/'launch-attribution.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(profileSources=['0443b5cf','91ca4a41'],wholeScript='scripts.text-summary-helpers.nonlocal-counter.large',payloadBytes=c['unpackedBytes'],retiredOnly=[x['paths']for x in proofs],retiredBytes=sum(x['bytes']for x in proofs),sameImagesAndCatalogBorrowed=True)))
