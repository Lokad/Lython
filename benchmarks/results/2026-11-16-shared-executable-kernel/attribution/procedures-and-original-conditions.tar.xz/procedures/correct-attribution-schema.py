from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess
r=Path(__file__).parent/'profile';p=r/'ops-profile.py';original=p.read_text(encoding='utf-8');s=original.replace("dict(expected_image['auxiliaryFiles'], **{'Lokad.Lython.dll': expected_image['coreSHA256']['candidate']})", "expected_image['imageFiles'][name]").replace("(candidate/'candidate'/filename)","(candidate/name/filename)");assert s!=original;ast.parse(s)
(r/'initial-ops-profile.py').write_text(original,encoding='utf-8',newline='\n');p.write_text(s,encoding='utf-8',newline='\n')
config=json.loads((r/'config.json').read_text(encoding='utf-8'));(r/'initial-config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');config['unit']='lython-b839-shared-kernel-attribution-corrected-20261116'
code='''from pathlib import Path
import ast,fcntl,hashlib,json,os,stat,subprocess
root=Path('/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not(root/'guest-fixtures').exists()
 assert json.loads((root/'initial-failed-cleanup.json').read_text())['archivedAndVerifiedBeforeUnmount']
 path=root/'ops-profile.py';m=path.lstat();assert stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and path.resolve()==path
 assert hashlib.sha256(path.read_bytes()).hexdigest()==ORIGINAL
 text=REPLACEMENT;ast.parse(text);path.write_text(text)
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b839-corrected-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit=lython-b839-shared-kernel-attribution-corrected-20261116','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print('Corrected only two-source identity validation; original failed setup archived and cached. Same core images,catalog,collector and workload.')
'''.replace('ORIGINAL',repr(hashlib.sha256(original.encode()).hexdigest())).replace('REPLACEMENT',repr(s))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=45)
(r/'correction-launch.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat()),indent=2)+'\n',encoding='utf-8')
print(done.stdout)
