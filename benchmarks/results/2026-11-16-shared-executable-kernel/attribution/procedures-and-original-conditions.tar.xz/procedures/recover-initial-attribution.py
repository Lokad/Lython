from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent/'profile';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show','lython-b839-shared-kernel-attribution-20261116.service','--property=MainPID,ActiveState,Result,ExecMainStatus'],text=True)
 assert 'MainPID=0'in service and 'ActiveState=failed'in service and 'ExecMainStatus=1'in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 trace=root/'guest-fixtures';assert trace.is_mount()
 files={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 assert files=={'profiles/reference/worker.stderr':hashlib.sha256(b'').hexdigest()},files
 (root/'initial-failed-service.txt').write_text(service)
 (root/'initial-failed-journal.txt').write_text(subprocess.check_output(['journalctl','-u','lython-b839-shared-kernel-attribution-20261116.service','--no-pager'],text=True))
 archive=root/'initial-failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz')as t:
  for p in root.iterdir():
   if p.is_file()and p!=archive:t.add(p,arcname=p.name)
  t.add(trace,arcname='guest-fixtures')
 with tarfile.open(archive)as t:
  for n,h in files.items():assert hashlib.sha256(t.extractfile('guest-fixtures/'+n).read()).hexdigest()==h
  assert 'auxiliaryFiles'in t.extractfile('initial-failed-journal.txt').read().decode()
 subprocess.run(['sudo','-n','umount',str(trace)],check=True);trace.rmdir()
 receipt=dict(complete=True,failedBeforeWorker=True,service=service,onlyEmptyWorkerStderr=True,allUsersJoined=True,archivedAndVerifiedBeforeUnmount=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(root).free)
 (root/'initial-failed-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'initial-failed-terminal.json').write_text(p.stdout,encoding='utf-8');receipt=json.loads(p.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['initial-failed-observations.tgz','initial-failed-cleanup.json']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+n,str(r/n)],capture_output=True);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'initial-failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(json.dumps(receipt))
