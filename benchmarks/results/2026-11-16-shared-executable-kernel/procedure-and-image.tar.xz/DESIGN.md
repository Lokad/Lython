# Shared closed instruction kernel: active migration

Baseline9f07335c; production equals fully qualified312f5911/0443b5cf.
Frozen91ca4a41/609inputs: no retained runtime change. One closed instruction loop
now shares both slot lifetimes; ordinary duplicate handlers/call selector and the
compiler full-opcode inventory are removed. Temporary conversion gate is gone.
Real protocol/suspension/finally actions keep the existing driver. Nonincremental
both-target build plus focused calls/continuations/cancellation/refusal/cleanup
pass; no Unsafe API,per-call object,ref-escape annotation or new exception router.
B838 whole-script source pair running; local allocations essentially flat.

The new ExecutableKernel borrows ExecutableWorkState by ref; Code, PC, closure
cells, return-consumption intent and live extent come from that real metadata.
Private calls supply a local state plus their existing final-slot Span. The
persistent constructor borrows the frame state and array. Do not synchronize a
copied PC after callbacks. Private Stack now has initialized shared metadata and
definition-owned lookup storage but no array/allowance. Publication/local stores/
retirement take the actual Span. Persistent storage keeps its actual owner.

Passing intermediate stages are preserved separately,not summed: metadata902/3296,
first cases1168/3296,arithmetic991/2728,iteration455/1357,storage2379/3651,
closures1065/4663,values1799/3094,calls2838/6402,eachactual.NET11/10 Release.
Final filename/nonincremental build adds focused81/45checks. Final sources/checks
are in frozen/sources-and-checks.tar.xz; coherent benchmark images are copied,
not hardlinked. No intermediate elapsed claim. Eight-job allocation changes<0.10%
with unchanged accounted peaks. Full delivery is pending a retention decision.

Persistent publish/retire must reuse existing clearing and queued async disposal;
private dead references remain only until bounded prefix exit/transfer. The Locals
array remains the real binding-loan return handle. A queued disposal must stop the
closed prefix immediately with the same original PC/jump disposition expected by
the existing async driver. That driver currently advances nonjumped instructions
after awaiting disposal. Do not advance once in the kernel and again in the driver,
or execute the instruction again after its completed effects. Fault routing must
read the actual originating PC even when a closed prefix covered many operations.

Calls must preserve child admission before callbacks, same-PC prepared-child
transfer, no replay, exact result/finally identity, current exception and cleanup.
Consolidate duplicate native call selection as part of removing old routes; do not
invent a new completion controller or exception router. Unknown opcodes remain
compiler defects; supported dynamic operations stop before effects and use the
existing driver. No per-call heap workspace/view/interface layer or new policy.

Metadata fixture CasedSplitOwnershipTests directly constructs the old native view
to verify cancellation after a prepared range loan. Adapt its setup to shared state;
keep its independent funding/cleanup assertions. Initial missing-type compile log
is preserved. No supported behavior/test was removed to make the migration compile.

Completion: one closed instruction kernel, old switch/publication/eligibility
machinery removed; focused native/ordinary calls, real I/O, aliases, returns,
closures/generators, fault PCs, managed stack, cancellation/refusal/cleanup pass.
Then one bounded allocation plus complete normalization/captured-text/search/invoice
source pair with unchanged controls and explicit regression-debt decision. Temporary
setbacks are acceptable only through that coherent gate; no partial promotion.
