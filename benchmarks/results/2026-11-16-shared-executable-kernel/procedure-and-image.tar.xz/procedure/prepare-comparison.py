from pathlib import Path
import ast, hashlib, io, json, shutil, subprocess, tarfile, xml.etree.ElementTree as E
r=Path(__file__).parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/shared-kernel-r439';old=r.parent/'materialization-r438'
sha=lambda b:hashlib.sha256(b).hexdigest()
f=r/'frozen';f.mkdir();images={}
reference=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
    shutil.copytree(old/'frozen/reference',f/role)
    if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
    images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
assert images['reference']==reference['images']['reference']
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
prior=json.loads((r.parent/'kernel-r436/refined/frozen/identity.json').read_text(encoding='utf-8'))
paths=list(prior['sources']);paths.remove('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs')
paths+=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Kernel.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs','tests/Lokad.Lython.Tests/DrainCleanupOwnershipTests.cs']
assert len(paths)==len(set(paths))==609
identity=dict(buildSourceCommit=subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:sha((w/n).read_bytes())for n in paths},
    contract='One closed executable kernel borrows real metadata/final slots. Shared publication/retirement,closures,branches,receivers,subscripts,formatting,calls and exact prepared child transfer. Real protocols/suspension/finally use existing driver. Full native opcode inventory and temporary gate removed. Private lexical/cleanup boundaries and funded retained lifetimes remain; no per-call heap controller or new policy.',
    referenceQualification='312f5911/measured0443b5cf full43828954661 GREEN,607inputs/16summaries; terminal cached forever.',publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[]
for stage in ['shared-closures-checks','shared-values-checks','shared-calls-checks','coherent-checks']:
    rows=[dict(stage=stage,file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/stage).glob('*.trx')]
    assert len(rows)==4 and all(x['failed']=='0' and int(x['passed'])>0 for x in rows),stage
    checks+=rows
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,earlierPassingStagesPreserved=True,overlappingFiltersNotSummed=True,fullQualificationPending=True,sourceRenameOnlyAfterCallChecks=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
    for n in paths:t.add(w/n,arcname=n)
    for n in ['metadata-checks','first-shared-prefix-checks','shared-arithmetic-checks','shared-iteration-checks','shared-storage-checks','shared-closures-checks','shared-values-checks','shared-calls-checks','coherent-checks']:t.add(r/n,arcname=n)
    for p in r.glob('*.log'):t.add(p,arcname='builds/'+p.name)
    for n in ['docs/RUNTIME.md','tests/README.md']:t.add(w/n,arcname=n)
catalog=json.loads((r.parent/'checkpoint-r437/catalog.json').read_text(encoding='utf-8'))
captured=json.loads((r.parent/'format-layout-r418/checkpoint/retrieved/representative.json').read_text(encoding='utf-8'))
catalog['cases'].append(next(c for c in captured['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large'))
rawCatalog=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()
d=r/'allocation-short';d.mkdir();allocation=dict(catalog);allocation['cases']=[]
for x in catalog['cases']:
    c=dict(x,runAsync=False);allocation['cases'].append(c)
    if x['id']=='scripts.text-normalization.large':allocation['cases'].append(dict(c,id=x['id']+'.async',runAsync=True))
extra=json.loads((old/'allocation-short/catalog.json').read_text(encoding='utf-8'))
allocation['cases']+=[next(x for x in extra['cases']if x['id']==n)for n in ['generators.drain.large','calls.positional.large']]
(d/'catalog.json').write_text(json.dumps(allocation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(old/'allocation-short'/n,d/n)
shutil.copytree(old/'allocation-short/bin',d/'bin');shutil.copyfile(old/'measure-allocation.py',r/'measure-allocation.py')
q=r/'quiet';q.mkdir();before=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'))
root='/home/lokad/lython-bench-checks/shared-kernel-b838-20261116';unit='lython-b838-shared-kernel-20261116'
files=before['identity']['imageFiles']['reference'];imageFiles={role:{n:images[role][n]for n in files}for role in ['reference','candidate']}
ident=dict(sourceRevision='R439 isolated '+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified312f5911/0443b5cf',purpose='One shared-kernel source pair: complete normalization warm/fresh,captured-helper text,protected search,CSV and JSON controls. Distinguish simplification,allocation and CPU.',coreSHA256={label:imageFiles['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=imageFiles,prototype=True,publicationHeld=True,candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()),referenceQualification=identity['referenceQualification'])
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'representative.json').write_bytes(rawCatalog)
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.file-search.large.protected','warm'],['scripts.csv-invoice.large','warm'],['scripts.json-summary-helpers.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=(old/'quiet'/n).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B837','B838')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:];s=s.replace('len(jobs)==5','len(jobs)==6')
    if n=='archive-owned.py':s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace('jobs=5','jobs=6')
    if n=='retrieve.py':s=s.replace("['jobs']==5","['jobs']==6").replace('five-job','six-job')
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
base='benchmarks/results/2026-11-16-direct-materialization-withdrawn/'
proofs=[]
for row in json.loads((r/'stage-space.json').read_text(encoding='utf-8'))['rows']:
    archive=base+('procedure-and-image.tar.xz' if row['path'].endswith('/candidate/Lokad.Lython.dll') else 'observations.tgz')
    member='frozen/candidate/Lokad.Lython.dll' if row['path'].endswith('/candidate/Lokad.Lython.dll') else ('confirmation/confirmation.json' if row['path'].endswith('/confirmation/confirmation.json') else None)
    if row['path'].endswith('representative.json'):
        archive='benchmarks/results/2026-11-16-representative-cpython-checkpoint/phase-2/observations.tgz';member='representative.json'
    raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
    if member:
        with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile(member).read()
    else:content=raw
    assert len(content)==row['bytes']and sha(content)==row['sha256']
    proofs.append(dict(bytes=row['bytes'],sha256=row['sha256'],links=row['links'],paths=row['paths'],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
    for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['source'],sourceFiles=files,sourceCatalogSHA256=before['sourceCatalogSHA256'],catalogSHA256=sha(rawCatalog),identity=ident,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b837-fixtures','lython-b838-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'launch-quiet.py',r/'launch-quiet.py');shutil.copyfile(old/'summarize.py',r/'summarize.py')
print(json.dumps(dict(core=images['candidate']['Lokad.Lython.dll'],sourceInputs=len(paths),allocationCases=len(allocation['cases']),quietJobs=len(jobs),catalogBytes=len(rawCatalog),unpackedBytes=c['unpackedBytes'],retireBytes=sum(x['bytes']for x in proofs),projectedFreeBytes=json.loads((r/'stage-space.json').read_text(encoding='utf-8'))['freeBytes']+sum(x['bytes']for x in proofs)-c['unpackedBytes'],retiredOnly=[x['paths']for x in proofs])))
