from pathlib import Path

w = Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439/src/Lokad.Lython/Runtime')
def read(n): return (w/n).read_text(encoding='utf-8')
def save(n,s): (w/n).write_text(s,encoding='utf-8',newline='\n')

n='LythonRuntime.Executable.NativePrefix.cs';s=read(n)
s=s.replace('        internal bool ClosedJumped { get; private set; }','        internal bool ClosedJumped { get; private set; }\n        internal readonly ExecutionContext? StartedCall => _persistent ? _preparedChild : null;')
s=s.replace('or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField)) return false;', 'or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField\n                    or ExecutableOpCode.Call)) return false;')
a=s.index('        private bool Call(in ExecutableInstruction instruction)');b=s.index('        private bool TryReturnUnpackedTuple(',a)
s=s[:a]+'''        private bool Call(in ExecutableInstruction instruction)
        {
            var call = Code.CallSites[instruction.CallSiteIndex];
            var start = instruction.InputStart;
            var target = Values[start + call.TargetOffset].Object.RequireNotNull();
            var function = target as PyExecutableFunction;
            object? receiver = call.HasReceiver && Values[start].Object is not PyNone ? Values[start].Object : null;
            if (target is PyBoundMethod { Function: PyExecutableFunction boundFunction } bound)
            {
                function = boundFunction;
                receiver = bound.Receiver;
            }
            if (function is not null) return CallFunction(instruction, call, start, function, receiver);
            if (!call.IsPositionalOnly) return false;
            if (call.CasedSplit is { } recipe && ReferenceEquals(target, recipe.CasingMethod) && receiver is PyString cased)
                return CasedSplit(call, start, recipe, cased);
            var result = default(ExecutableSlot);
            try
            {
                if (!call.HasReceiver && ExecutionContext.IsRangeBuiltin(target))
                {
                    if (!TryInvokeNativeRange(Values.Slice(start + call.ArgumentOffset, call.ArgumentCount),
                        call.CallSpan, _scope, out var rangeResult)) return false;
                    result.Object = rangeResult;
                }
                else if (call.HasReceiver && receiver is PyDict dictionary)
                {
                    if (call.ArgumentCount == 0 && target is ReceiverMethod method && method.AcceptsPositional(0))
                        result.Object = InvokeReceiverMethod(method, dictionary, call.CallSpan, _scope);
                    else if (call.ArgumentCount is 1 or 2 && ReferenceEquals(target, ReceiverMethods.DictionaryGet)
                        && dictionary.CanReadKeySynchronously(Values[start + call.ArgumentOffset].Object!))
                    {
                        var key = Values[start + call.ArgumentOffset].Object!;
                        if (_persistent && call.AccumulatesDictionary && ExecutionContext.TryExecuteDictionaryAccumulation(
                            ref _work, _scope, call, start, dictionary, (PyString)key)) return true;
                        result.Object = InvokeDictionaryGet(dictionary, key,
                            call.ArgumentCount == 2 ? Values[start + call.ArgumentOffset + 1].Object! : PyNone.Instance, call.CallSpan, _scope);
                    }
                    else return false;
                }
                else if (call.HasReceiver && receiver is PyString text)
                {
                    if (call.ArgumentCount == 0 && target is ReceiverMethod method && method.AcceptsPositional(0))
                        result.Object = InvokeReceiverMethod(method, text, call.CallSpan, _scope);
                    else
                    {
                        var args = Values.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                        var first = args.Length > 0 ? args[0].Object : null;
                        var second = args.Length > 1 ? args[1].Object : null;
                        var third = args.Length > 2 ? args[2].Object : null;
                        if (SelectNativeStringOperation(target, args.Length) is not { } operation
                            || !CanUseNativeStringCall(operation, first, second, third)) return false;
                        result.Object = InvokeNativeStringOperation(operation, text, first, second, third, call.CallSpan, _scope);
                    }
                }
                else
                {
                    var argument = call.ArgumentCount == 1 && !call.HasReceiver
                        ? Values[start + call.ArgumentOffset].Object : null;
                    var closed = false;
                    var operation = argument is not null ? SelectNativeUnaryOperation(target, argument, out closed) : null;
                    if (operation is null || !closed && _invocation is null) return false;
                    if (operation is Func<object, LythonSourceSpan, ExecutionContext, BigInteger> integerOperation)
                    {
                        var integer = InvokeSingleInput(argument!, integerOperation, call.CallSpan, _scope);
                        if (TryMachineInteger(integer, out var integerResult)) result.SetInteger(integerResult);
                        else result.Object = integer;
                    }
                    else result.Object = InvokeSingleInput(argument!, operation, call.CallSpan, _scope);
                }
            }
            catch (Exception error)
            {
                if (_persistent) Trim(start);
                if (TryTranslateCallableException(error, call.CallSpan, out var translated)) throw translated;
                throw;
            }
            // The caller's publication/store checkpoint is outside translation
            // of callable failures, for both actual storage lifetimes.
            try { Publish(instruction, result); }
            catch { if (_persistent) Trim(start); throw; }
            return true;
        }

        private bool CasedSplit(ExecutableCallSite call, int start, ExecutableCasedSplit recipe, PyString receiver)
        {
            ref readonly var final = ref Code.Instructions[Index + 2];
            var consumer = Code.CallSites[final.CallSiteIndex];
            try
            {
                object result;
                _scope.EnterInterpreterFrame(recipe.CasingCallSpan);
                try { result = ExecuteCasedSplit(recipe, receiver, _scope,
                    consumer.ConsumedByIteration || _consumedByIteration && consumer.ReturnedDirectly); }
                catch (Exception error) when (TryTranslateCallableException(error, recipe.SplitCallSpan, out var translated)) { throw translated; }
                finally { _scope.LeaveInterpreterFrame(); }
                Index += 2;
                Publish(final, result);
                return true;
            }
            catch { if (_persistent) Trim(start); throw; }
        }

        private bool CallFunction(in ExecutableInstruction instruction, ExecutableCallSite call, int start,
            PyExecutableFunction function, object? receiver)
        {
            if (!function.CanStartInline || _persistent && _invocation is null
                || !_persistent && _scope.State.CurrentRecursionDepth >= NativeCallDepth) return false;
            var borrow = call.IsPositionalOnly && function.SupportsDirectPositional
                && function.CanBorrowPositionalArguments(call.ArgumentCount, receiver);
            if (!borrow && !function.CanBindNativeArguments) return false;
            var entered = false;
            var unpacked = false;
            ExecutableSlot result;
            var unpackedCount = 0;
            try
            {
                _scope.EnterInterpreterFrame(call.CallSpan);
                entered = true;
                _scope.CheckExecution(call.CallSpan);
                var arguments = Values.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                var originalExtent = LiveExtent;
                var returned = _persistent
                    ? ExecutionContext.PrepareUnpackedCallReturn(ref _work, call, start, out originalExtent) : default;
                function.StartNativeCall(call, arguments, receiver, _scope, call.CallSpan,
                    call.ConsumedByIteration || _consumedByIteration && call.ReturnedDirectly,
                    borrow, returned, out unpacked, out result, out var child);
                if (!unpacked) LiveExtent = originalExtent;
                unpackedCount = returned.Length;
                if (child is not null)
                {
                    if (_persistent)
                    {
                        try
                        {
                            child.EnterExecutableSlots();
                            _invocation!.AttachPreparedCall(child, call, start, call.CallSpan,
                                ExecutionContext.CallCompletion.Call, function.DefinitionContext.MemoryGovernor);
                        }
                        catch
                        {
                            ExecutionContext.AbortPreparedNativeCall(child, function.DefinitionContext.MemoryGovernor);
                            throw;
                        }
                    }
                    // A real child owns its exact PC and interpreter admission.
                    // Private callers first acquire their own durable frame;
                    // persistent callers return it to the existing linear runner.
                    _preparedChild = child;
                    _preparedChildOwner = function.DefinitionContext.MemoryGovernor;
                    entered = false;
                    return false;
                }
            }
            catch (Exception error)
            {
                if (_persistent) Trim(start);
                if (TryTranslateCallableException(error, call.CallSpan, out var translated)) throw translated;
                throw;
            }
            finally { if (entered) _scope.LeaveInterpreterFrame(); }
            try
            {
                if (unpacked) ExecutionContext.CompleteUnpackedCallReturn(ref _work, _scope, start, unpackedCount);
                else Publish(instruction, result);
            }
            catch { if (_persistent) Trim(start); throw; }
            return true;
        }

'''+s[b:];save(n,s)

n='LythonRuntime.Executable.Calls.Invoke.cs';s=read(n)
a=s.index('        // The same native selection serves');b=s.index('        private static Span<ExecutableSlot> PrepareUnpackedCallReturn',a)
s=s[:a]+s[b:]
s=s.replace('private static Span<ExecutableSlot> PrepareUnpackedCallReturn','internal static Span<ExecutableSlot> PrepareUnpackedCallReturn').replace('private static void CompleteUnpackedCallReturn','internal static void CompleteUnpackedCallReturn')
save(n,s)
n='LythonRuntime.Executable.CasedSplits.cs';s=read(n);a=s.index('    internal sealed partial class ExecutionContext');s=s[:a]+'}\n';save(n,s)
n='LythonRuntime.Executable.DictionaryAccumulation.cs';s=read(n).replace('private static bool TryExecuteDictionaryAccumulation','internal static bool TryExecuteDictionaryAccumulation');save(n,s)
n='LythonRuntime.Executable.Calls.cs';s=read(n).replace('private enum CallCompletion','internal enum CallCompletion').replace('private void AttachPreparedCall(','internal void AttachPreparedCall(');save(n,s)
n='LythonRuntime.Executable.Interpreter.Dispatch.cs';s=read(n)
needle='''                    kernel.ExecuteClosedPrefix();
                    if (asynchronous''';assert s.count(needle)==1
s=s.replace(needle,'''                    kernel.ExecuteClosedPrefix();
                    if (kernel.StartedCall is { } started)
                    {
                        nextCall = new(started);
                        pendingSpan = execution.Code.CallSites[instructions[execution.InstructionIndex].CallSiteIndex].CallSpan;
                        return InstructionPause.Call;
                    }
                    if (asynchronous''')
a=s.index('                            if (TryExecuteNativeCall(');b=s.index('                            if (invocation is null) return InstructionPause.ContextRequired;',a);s=s[:a]+s[b:];save(n,s)
print('Unified completed call selection, cased-split recipe and child transfer; deleted ordinary duplicate selector. Genuine binder/async operations and shared unpack helpers remain.')
