from pathlib import Path
import ast,json
r=Path(__file__).parent;q=r/'quiet';old=r.parent/'materialization-r438/quiet'
c=json.loads((q/'config.json').read_text(encoding='utf-8'));previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
# The current reference is B834's candidate. B837's candidate is the withdrawn
# image being retired, so it must never serve as the new reference source.
c['source']=previous['source'];c['sourceCatalogSHA256']=previous['sourceCatalogSHA256']
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b837-fixtures','lython-b838-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
p=r/'launch-quiet.py';s=p.read_text(encoding='utf-8').replace('Four-job comparison launched','Six-job shared-kernel comparison launched');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'prepare-comparison.py';s=p.read_text(encoding='utf-8').replace("source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256']", "source=before['source'],sourceFiles=files,sourceCatalogSHA256=before['sourceCatalogSHA256']");p.write_text(s,encoding='utf-8',newline='\n')
print('Verified source selection uses qualified B834 candidate; six-job payload and frozen candidate unchanged.')
