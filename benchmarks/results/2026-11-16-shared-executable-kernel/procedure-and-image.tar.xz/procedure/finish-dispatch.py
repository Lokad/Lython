from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8')
a=s.index('                // Conversion gate:');b=s.index('                _scope.State.CheckExecution(instruction.Span);',a);s=s[:a]+s[b:]
s=s.replace('if (Code.NativePrefixEnd != Code.Instructions.Length) return false;', 'if (_persistent || Code.NativePrefixEnd != Code.Instructions.Length) return false;')
s=s.replace('''                    default:
                        throw new InvalidOperationException($"Unexpected inline opcode: {instruction.OpCode}");''','''                    default:
                        // Valid protocol/control instructions transfer before
                        // effects. Invalid opcodes remain compiler defects.
                        if (!Enum.IsDefined(instruction.OpCode))
                            throw new InvalidOperationException($"Unknown executable opcode: {instruction.OpCode}");
                        return false;''')
s=s.replace('return CasedSplit(call, start, recipe, cased);','return CasedSplit(start, recipe, cased);').replace('private bool CasedSplit(ExecutableCallSite call, int start,','private bool CasedSplit(int start,')
p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8');s=s.replace('''            && EntryIndex < NativePrefixEnd
            && SupportsNativeInstructions();''','''            && EntryIndex < NativePrefixEnd;''')
a=s.index('    private bool SupportsNativeInstructions()');b=s.index('    private bool CrossesExceptionBoundary(',a);s=s[:a]+s[b:]
a=s.index('    private static bool IsInlineInstruction(');s=s[:a]+'}\n';p.write_text(s,encoding='utf-8',newline='\n')
print('Removed temporary persistent opcode gate and whole-function native-opcode inventory. Real scope/cleanup boundaries remain; unknown opcodes still throw.')
