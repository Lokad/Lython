from pathlib import Path
import tarfile
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439');r=Path(__file__).parent
with tarfile.open(r/'metadata-stage.tar.xz','w:xz')as t:
 for n in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']:t.add(w/n,arcname=n)
 t.add(r/'metadata-checks',arcname='checks');t.add(r/'metadata-build.log',arcname='build.log')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8').replace('private readonly PyExecutableFunction _function;','private readonly PyExecutableFunction? _function;\n        private readonly bool _persistent;\n        private readonly ExecutionContext? _invocation;');needle='        internal bool Run(LythonSourceSpan entrySpan,';assert s.count(needle)==1;s=s.replace(needle,'''        internal ExecutableKernel(ref ExecutableWorkState work, ExecutionContext scope, ExecutionContext? invocation)
        {
            _work = ref work;
            Values = work.Stack.Values;
            _scope = scope;
            _invocation = invocation;
            _persistent = true;
        }

        internal void ExecuteClosedPrefix() => _ = RunCore(out _);

'''+needle)
s=s.replace('while (Index < Code.NativePrefixEnd)','while (Index < (_persistent ? Code.Instructions.Length : Code.NativePrefixEnd))')
needle='                _scope.State.CheckExecution(instruction.Span);\n                switch (instruction.OpCode)';assert s.count(needle)==1;s=s.replace(needle,'''                // Conversion gate: remove this temporary classification as the
                // remaining closed cases move out of the ordinary driver.
                if (_persistent && instruction.OpCode is not (ExecutableOpCode.LoadConst or ExecutableOpCode.LoadLocal
                    or ExecutableOpCode.LoadGlobal or ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple
                    or ExecutableOpCode.Dup or ExecutableOpCode.PopTop)) return false;
                _scope.State.CheckExecution(instruction.Span);
                switch (instruction.OpCode)''')
s=s.replace('var caches = _function.GetLookupCaches(instruction.Span);','var caches = _function!.GetLookupCaches(instruction.Span);')
needle='                Index++;\n            }\n            return Index >= Code.Instructions.Length;';assert s.count(needle)==1;s=s.replace(needle,'''                if (_persistent && _work.Stack.HasPendingDisposals) return false;
                Index++;
            }
            return Index >= Code.Instructions.Length;''')
needle='''        private void Publish(in ExecutableInstruction instruction, ExecutableSlot value)
        {
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''            if (_persistent)
            {
                ExecutionContext.PublishInstructionResult(ref _work, _invocation, instruction, value);
                return;
            }
''')
needle='''        private void Put(int slot, int liveExtent, ExecutableSlot value)
        {
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''            if (_persistent) { _work.Stack.PublishSlot(slot, liveExtent, value); return; }
''')
needle='''        private void Trim(int liveExtent)
        {
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''            if (_persistent) { _work.Stack.RetireTo(liveExtent); return; }
''');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8');assert s.count('private static void PublishInstructionResult(')==2;s=s.replace('private static void PublishInstructionResult(','internal static void PublishInstructionResult(');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8');needle='''                ref readonly var instruction = ref instructions[execution.InstructionIndex];
                scope.State.CheckExecution(instruction.Span);
                try
                {
''';assert s.count(needle)==1;s=s.replace(needle,'''                try
                {
                    var kernel = new ExecutableKernel(ref execution, scope, invocation);
                    kernel.ExecuteClosedPrefix();
                    if (asynchronous && execution.Stack.HasPendingDisposals)
                    {
                        // The completed producer remains current. The existing
                        // async driver advances it after awaited retirement.
                        pending = new(false);
                        return InstructionPause.Disposal;
                    }
                    if (execution.InstructionIndex >= instructions.Length) return InstructionPause.Boundary;
                    ref readonly var instruction = ref instructions[execution.InstructionIndex];
                    scope.State.CheckExecution(instruction.Span);
''')
a=s.index('                        case ExecutableOpCode.LoadLocal:');b=s.index('                        case ExecutableOpCode.LoadClosure:',a);s=s[:a]+s[b:]
s=s.replace('''                        case ExecutableOpCode.LoadConst or ExecutableOpCode.LoadGlobal or
                             ExecutableOpCode.LoadName''','''                        case ExecutableOpCode.LoadName''')
s=s.replace('''                             ExecutableOpCode.StoreGlobal or ExecutableOpCode.StoreName or
                             ExecutableOpCode.Dup or ExecutableOpCode.PopTop:''','''                             ExecutableOpCode.StoreGlobal or ExecutableOpCode.StoreName:''')
s=s.replace('''                            if (invocation is null && instruction.OpCode is not (ExecutableOpCode.LoadConst or ExecutableOpCode.LoadGlobal or ExecutableOpCode.Dup or ExecutableOpCode.PopTop))''','''                            if (invocation is null)''')
a=s.index('                        case ExecutableOpCode.MakeList:');b=s.index('                        case ExecutableOpCode.MakeSet or',a);s=s[:a]+s[b:]
a=s.index('                catch (ReturnSignal signal)');b=s.index('\n                if (asynchronous &&',a);s=s[:a]+s[a:b].replace('instruction.Span','instructions[execution.InstructionIndex].Span')+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');a=s.index('                case ExecutableOpCode.LoadConst:',s.index('private static void ExecuteStackTransfer'));b=s.index('                case ExecutableOpCode.LoadName:',a);s=s[:a]+s[b:];a=s.index('                case ExecutableOpCode.Dup:',s.index('private static void ExecuteStackTransfer'));b=s.index('\n            }',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs';s=p.read_text(encoding='utf-8');a=s.index('    private static object LoadLocal(');b=s.index('    private static object LoadMissingLocal(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Seven closed cases use one borrowed-slot loop; matching ordinary cases/helpers removed. Temporary gate/remaining dispatch migration still incomplete.')
