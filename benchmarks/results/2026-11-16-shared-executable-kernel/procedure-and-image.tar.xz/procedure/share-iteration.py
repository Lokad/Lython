from pathlib import Path
import subprocess,tarfile
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439');r=Path(__file__).parent
with tarfile.open(r/'shared-arithmetic-stage.tar.xz','w:xz')as t:
 for n in subprocess.check_output(['git','-C',str(w),'diff','--name-only'],text=True).splitlines():t.add(w/n,arcname=n)
 t.add(r/'shared-arithmetic-checks',arcname='checks');t.add(r/'shared-arithmetic-build.log',arcname='build.log')
p=w/'src/Lokad.Lython/Runtime/PyIteration.cs';s=p.read_text(encoding='utf-8');a=s.index('        internal bool IsBuiltinRange');b=s.index('        private bool TryMoveNextCore(',a);s=s[:a]+'''        internal bool TryMoveNextBuiltin(out bool hasValue, out LythonRuntime.ExecutableSlot value)
        {
            hasValue = false;
            value = default;
            if (_disposed) return true;
            // This exact-source path cannot reach a guest callback or I/O.
            if (_iterator is not null || _value is not (PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet))
                return false;
            CheckExecution();
            if (_value is PyRange range)
            {
                _syncEnumerator ??= range.GetEnumerator();
                if (_syncEnumerator is PyRange.Enumerator { HasMachineBounds: true } integers)
                {
                    hasValue = integers.MoveNext();
                    if (hasValue) value = LythonRuntime.ExecutableSlot.FromInteger(integers.MachineValue);
                    return true;
                }
            }
            hasValue = TryMoveNextCore(out var item);
            if (hasValue) value = LythonRuntime.ExecutableSlot.FromObject(item);
            return true;
        }

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8').replace('TryAdvanceNativeIteration(int slot, out bool hasValue, out ExecutableSlot next)','TryAdvanceNativeIteration(Span<ExecutableSlot> values, int slot, out bool hasValue, out ExecutableSlot next)').replace('var source = _items[slot].Object.RequireNotNull();','var source = values[slot].Object.RequireNotNull();');a=s.index('                case PyIteration.Cursor { IsBuiltinRange: true } cursor:');b=s.index('                default:',a);s=s[:a]+'''                case PyIteration.Cursor cursor:
                    return cursor.TryMoveNextBuiltin(out hasValue, out next);
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs';s=p.read_text(encoding='utf-8').replace('private static bool TryExecuteDictionaryLoop(','internal static bool TryExecuteDictionaryLoop(').replace('execution.Stack.TryAdvanceNativeIteration(slot,','execution.Stack.TryAdvanceNativeIteration(execution.Stack.Values, slot,');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');needle='        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        internal bool ClosedJumped { get; private set; }');s=s.replace('or ExecutableOpCode.Augmented or ExecutableOpCode.Unary)) return false;','or ExecutableOpCode.Augmented or ExecutableOpCode.Unary or ExecutableOpCode.GetIter\n                    or ExecutableOpCode.ForNext or ExecutableOpCode.ForNextDictionaryAccumulation\n                    or ExecutableOpCode.Jump)) return false;');a=s.index('                    case ExecutableOpCode.GetIter:');b=s.index('                    case ExecutableOpCode.MakeTuple:',a);s=s[:a]+'''                    case ExecutableOpCode.GetIter:
                    {
                        var source = Read(instruction.InputStart, 0);
                        if (_persistent && _work.Stack.TryPrepareNativeIteration(source, instruction.ResultSlot,
                            instruction.LiveExtent, instruction.Span)) break;
                        if (source is PyStringOps.CasedWhitespaceIteration)
                            Publish(instruction, source);
                        else if (source is PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)
                            Publish(instruction, PyIteration.Cursor.Create(source, instruction.Span, _invocation ?? _scope));
                        else return false;
                        break;
                    }
                    case ExecutableOpCode.ForNextDictionaryAccumulation:
                        if (_persistent && ExecutionContext.TryExecuteDictionaryLoop(ref _work, _scope, _invocation, instruction))
                        {
                            if (_work.Stack.HasPendingDisposals) { ClosedJumped = true; return false; }
                            continue;
                        }
                        goto case ExecutableOpCode.ForNext;
                    case ExecutableOpCode.ForNext:
                    {
                        if (!_work.Stack.TryAdvanceNativeIteration(Values, instruction.InputStart, out var hasValue, out var next))
                            return false;
                        if (!hasValue)
                        {
                            Trim(instruction.InputStart);
                            Index = instruction.TargetIndex;
                            if (_persistent && _work.Stack.HasPendingDisposals) { ClosedJumped = true; return false; }
                            continue;
                        }
                        Publish(instruction, next);
                        break;
                    }
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8');s=s.replace('pending = new(false);\n                        return InstructionPause.Disposal;','pending = new(kernel.ClosedJumped);\n                        return InstructionPause.Disposal;',1);a=s.index('                        case ExecutableOpCode.ForNextDictionaryAccumulation:');b=s.index('                        case ExecutableOpCode.Call:',a);s=s[:a]+'''                        case ExecutableOpCode.ForNextDictionaryAccumulation:
                        case ExecutableOpCode.ForNext:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) jumped = invocation.ExecuteForNext(instruction);
                            else
                            {
                                pending = invocation.ExecuteForNextAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
'''+s[b:];a=s.index('                        case ExecutableOpCode.GetIter:');b=s.index('                        case ExecutableOpCode.Slice:',a);s=s[:a]+s[a:b].replace('''                            if (execution.Stack.TryPrepareNativeIteration(
                                ReadOperand(ref execution, instruction.InputStart, scope, 0),
                                instruction.ResultSlot, instruction.LiveExtent, instruction.Span)) break;
''','')+s[b:];s=s.replace('case ExecutableOpCode.AbruptJump or ExecutableOpCode.Jump or ExecutableOpCode.MatchException or','case ExecutableOpCode.AbruptJump or ExecutableOpCode.MatchException or').replace('instruction.OpCode is not (ExecutableOpCode.Jump or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone)','instruction.OpCode is not (ExecutableOpCode.Return or ExecutableOpCode.ReturnNone)');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');needle='''                case ExecutableOpCode.Jump:
                    execution.InstructionIndex = instruction.TargetIndex;
                    return true;

''';assert s.count(needle)==1;s=s.replace(needle,'');p.write_text(s,encoding='utf-8',newline='\n');print('Builtin iteration and plain jumps share the closed loop; native range publication and indexed frame sources retain existing ownership. Pending jump disposition forwarded.')
