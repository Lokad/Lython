from pathlib import Path
import subprocess,tarfile
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439');r=Path(__file__).parent
with tarfile.open(r/'first-shared-prefix-stage.tar.xz','w:xz')as t:
 for n in subprocess.check_output(['git','-C',str(w),'diff','--name-only'],text=True).splitlines():t.add(w/n,arcname=n)
 t.add(r/'first-shared-prefix-checks',arcname='checks');t.add(r/'first-shared-prefix-build.log',arcname='build.log')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Arithmetic.cs';s=p.read_text(encoding='utf-8');a=s.index('    internal sealed partial class ExecutionContext');s=s[:a]+'''    internal ref partial struct ExecutableKernel
    {
        private bool TryArithmetic(in ExecutableInstruction instruction)
        {
            // Persistent cleanup still owns its general per-operation route.
            if (_persistent && !_work.Stack.CanRetireWithoutCleanup(instruction.ResultSlot)) return false;
            try
            {
                var end = Index;
                ExecutableSlot value = default;
                var completed = instruction.OpCode != ExecutableOpCode.Unary &&
                    TryEvaluateIntegerInstruction(Code, Values, end, _scope, out end, out value);
                if (!completed && !TryEvaluateBuiltinArithmetic(Code, Values, end, _scope, out value)) return false;
                Index = end;
                Publish(Code.Instructions[end], value);
                return true;
            }
            catch
            {
                if (_persistent) Trim(instruction.ResultSlot);
                throw;
            }
        }
    }
}
''';p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs';s=p.read_text(encoding='utf-8');a=s.index('        private bool TryIntegerOperation()');b=s.index('        private bool TryIntegerComparison(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8');s=s.replace('or ExecutableOpCode.Dup or ExecutableOpCode.PopTop)) return false;','or ExecutableOpCode.Dup or ExecutableOpCode.PopTop or ExecutableOpCode.Binary\n                    or ExecutableOpCode.Augmented or ExecutableOpCode.Unary)) return false;');a=s.index('                    case ExecutableOpCode.Binary:');b=s.index('                    case ExecutableOpCode.CompareJumpIfFalse:',a);s=s[:a]+'''                    case ExecutableOpCode.Binary:
                    case ExecutableOpCode.Augmented:
                    case ExecutableOpCode.Unary:
                        if (!TryArithmetic(instruction)) return false;
                        break;
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8');needle='''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary:
                            if (TryExecuteBuiltinArithmetic(ref execution, scope, invocation, instruction)) break;
                            goto case ExecutableOpCode.Subscript;
''';assert s.count(needle)==1;s=s.replace(needle,'''                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary:
''');p.write_text(s,encoding='utf-8',newline='\n');print('Closed arithmetic selection/publication now shared; old ordinary arithmetic helper and native-only integer wrapper removed.')
