from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent;repo=Path('D:/code/Lython')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('| Active isolated migration |');b=s.index('\n| Independent adapter',a)
s=s[:a]+'''| Active isolated migration / measurement running | R439, frozen91ca4a41/609inputs versus qualified0443b5cf. One closed managed-slot loop; duplicate selectors,temporary gate and full-function opcode inventory removed. Call/continuation2838internal/6402public pass eachactual11/10, then nonincremental rebuild and81/45 focused cleanup checks. Eight-job local allocation essentially flat (all changes<0.10%),accounted peaks unchanged. B838six-job quiet comparison running; no retention,full delivery or CPU claim. |'''+s[b:]
a=s.index('### 1. R436 delivery complete');b=s.index('### 3. Select and complete a substantial displaced stage',a)
s=s[:a]+'''### 1. Complete the shared execution kernel and decide remaining regression debt

R436 is fully delivered; R437 is the current fixed-catalog CPython checkpoint.
Their evidence and boundaries are recorded above and in the performance guide.
No unchanged qualification or external comparison is pending. Continue the active
redesign below; batch full delivery checks only after a retention decision.

'''+s[b:];s=s.replace('### 3. Select and complete a substantial displaced stage','### 2. Substantial redesign roadmap').replace('### 4. Independent regex implementation/qualification','### 3. Independent regex implementation/qualification')
a=s.index('Latest completed Release closure');b=s.index('\n| Candidate/hypothesis',a)
s=s[:a]+'''Frozen91ca4a41/609inputs follows a nonincremental Release build. Call/continuation
2838internal/6402public pass eachactual11/10,then81internal/45public focused cleanup
checks on the final filename/build. Earlier closure1065/4663,value1799/3094 and
other stage checks remain archived; overlapping filters are not summed.
Eight complete local jobs pass all goldens/cleanup; allocation changes<0.10% and
accounted peaks are unchanged. This establishes no allocation or CPU improvement.

B838 six-job fixed-catalog comparison is running on the quiet VM: normalization
warm/fresh,captured-helper text,protected search,CSV and JSON,with two independent
process controls per source. Original conditions/observations will be preserved.
At completion separate architecture,allocation and CPU; retain/refine/remove with
explicit regression debt,then batch full platform/stress/installed consumers at
retention. No automatic percent veto or unchanged retiming. Prototype guide/source
remain isolated; main branch stays9f07335c/runtime0443b5cf. Publication held.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
status=dict(stage='One shared closed instruction kernel, frozen coherent source',frozenCore='91ca4a41df93790d8e860d4c287dd9802bc58ec93a03083764dcd90e9ce8033b',sourceInputs=609,callChecksEachRuntime=dict(internal=2838,public=6402),postNonincrementalBuildChecksEachRuntime=dict(internal=81,public=45),allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8')),quietComparison='B838 six jobs running; observe after recorded not-before',productionRetention=False,fullQualificationPending=True,performanceClaim=False)
(r/'current-stage-checks.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'DESIGN.md';s=p.read_text(encoding='utf-8');a=s.index('No retained runtime change');b=s.index('The new ExecutableKernel',a)
s=s[:a]+'''Frozen91ca4a41/609inputs: no retained runtime change. One closed instruction loop
now shares both slot lifetimes; ordinary duplicate handlers/call selector and the
compiler full-opcode inventory are removed. Temporary conversion gate is gone.
Real protocol/suspension/finally actions keep the existing driver. Nonincremental
both-target build plus focused calls/continuations/cancellation/refusal/cleanup
pass; no Unsafe API,per-call object,ref-escape annotation or new exception router.
B838 whole-script source pair running; local allocations essentially flat.

'''+s[b:];a=s.index('Completed intermediate stages:');b=s.index('Persistent publish/retire',a)
s=s[:a]+'''Passing intermediate stages are preserved separately,not summed: metadata902/3296,
first cases1168/3296,arithmetic991/2728,iteration455/1357,storage2379/3651,
closures1065/4663,values1799/3094,calls2838/6402,eachactual.NET11/10 Release.
Final filename/nonincremental build adds focused81/45checks. Final sources/checks
are in frozen/sources-and-checks.tar.xz; coherent benchmark images are copied,
not hardlinked. No intermediate elapsed claim. Eight-job allocation changes<0.10%
with unchanged accounted peaks. Full delivery is pending a retention decision.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n');print('Condensed completed plan sections and recorded exact frozen/prototype/allocation status; CPU/retention pending.')
