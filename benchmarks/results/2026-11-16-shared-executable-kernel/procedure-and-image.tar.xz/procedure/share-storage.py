from pathlib import Path
import subprocess,tarfile
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439');r=Path(__file__).parent
with tarfile.open(r/'shared-iteration-stage.tar.xz','w:xz')as t:
 for n in subprocess.check_output(['git','-C',str(w),'diff','--name-only'],text=True).splitlines():t.add(w/n,arcname=n)
 t.add(r/'shared-iteration-checks',arcname='checks');t.add(r/'shared-iteration-build.log',arcname='build.log')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8');needle='        internal readonly ExecutableSlot[] Values => _items;';assert s.count(needle)==1;s=s.replace(needle,'''        // Private prefixes borrow slots held by their caller. No capacity or
        // independent owner is created by this metadata value.
        internal ExecutableValueStorage(ExecutableCodeObject code, ExecutionState state, PyExecutableFunction lookupOwner)
        {
            _items = null!;
            _state = state;
            _firstTemporarySlot = code.FirstTemporarySlot;
            _lastOwnedTemporarySlot = code.LastOwnedTemporarySlot;
            _lookupStorage = lookupOwner;
            LiveExtent = code.FirstTemporarySlot;
        }

        internal readonly bool IsPersistent => _items is not null;

'''+needle)
needle='''        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)
        {
''';assert s.count(needle)==1;s=s.replace(needle,'''        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)
            => PublishSlot(_items, resultSlot, liveExtent, result);

        internal void PublishSlot(Span<ExecutableSlot> values, int resultSlot, int liveExtent, ExecutableSlot result)
        {
''');a=s.index('        internal void PublishSlot(Span<');b=s.index('        internal object TakeValue(',a);part=s[a:b].replace('RetireTo(liveExtent)','RetireTo(values, liveExtent)').replace('_items[resultSlot]','values[resultSlot]');s=s[:a]+part+s[b:]
a=s.index('        internal object TakeValue(');b=s.index('        internal ExecutableSlot TakeSlotValue(',a);s=s[:a]+'''        internal object TakeValue(int inputSlot, int liveExtent) => TakeValue(_items, inputSlot, liveExtent);

        internal object TakeValue(Span<ExecutableSlot> values, int inputSlot, int liveExtent)
        {
            var value = values[inputSlot].Object.RequireNotNull();
            values[inputSlot] = default;
            if (IsPersistent) LiveExtent = liveExtent;
            else RetireTo(values, liveExtent);
            return value;
        }

'''+s[b:]
a=s.index('        internal void ForgetResultInput(');b=s.index('        internal bool TryPrepareNativeIteration(',a);s=s[:a]+'''        internal void ForgetResultInput(int resultSlot) => ForgetResultInput(_items, resultSlot);

        internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)
        {
            values[resultSlot] = default;
            LiveExtent = resultSlot;
        }

'''+s[b:]
needle='''        public void RetireTo(int liveExtent)
        {
''';assert s.count(needle)==1;s=s.replace(needle,'''        public void RetireTo(int liveExtent) => RetireTo(_items, liveExtent);

        internal void RetireTo(Span<ExecutableSlot> values, int liveExtent)
        {
''');a=s.index('        internal void RetireTo(Span<');b=s.index('\n    public LythonExecutionResult Run(',a);part=s[a:b].replace('_items[i]','values[i]').replace('Array.Clear(_items, newCount, LiveExtent - newCount);','''// Private dead references end with their bounded prefix/transfer;
            // persistent frames clear every retired guest reference now.
            if (IsPersistent) values.Slice(newCount, LiveExtent - newCount).Clear();''');s=s[:a]+part+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8').replace('        private readonly PyExecutableFunction? _function;\n','').replace('        private readonly bool _persistent;','        private readonly bool _persistent => _work.Stack.IsPersistent;').replace('            _function = function;\n','').replace('            _persistent = true;\n','');needle='''            _work = ref work;
            Values = values;''';assert s.count(needle)==1;s=s.replace(needle,'''            _work = ref work;
            _work.Stack = new ExecutableValueStorage(function.CodeObject, _scope.State, function);
            Values = values;''');s=s.replace('var caches = _function!.GetLookupCaches(instruction.Span);','var caches = _work.Stack.GetLookupCaches(Code.LookupCacheCount, instruction.Span);');s=s.replace('or ExecutableOpCode.Jump)) return false;','or ExecutableOpCode.Jump or ExecutableOpCode.StoreLocal)) return false;');s=s.replace('Values[instruction.LocalSlot].Object = Take(instruction);','StoreLocalValue(Code, Values, _invocation, instruction.LocalSlot, Take(instruction), instruction.Span);')
a=s.index('        private object Take(in ExecutableInstruction instruction)');b=s.index('        private void Publish(in ExecutableInstruction instruction, object value)',a);s=s[:a]+'''        private object Take(in ExecutableInstruction instruction)
        {
            if (instruction.InputStart >= Code.FirstTemporarySlot)
                return _work.Stack.TakeValue(Values, instruction.InputStart, instruction.LiveExtent);
            var value = Read(instruction.InputStart, 0);
            Trim(instruction.LiveExtent);
            return value;
        }

'''+s[b:]
a=s.index('        private void Publish(in ExecutableInstruction instruction, ExecutableSlot value)');b=s.index('        private void Put(int slot, int liveExtent, object value)',a);s=s[:a]+'''        private void Publish(in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishExecutableSlot(ref _work, Values, _invocation, instruction, value);

'''+s[b:];a=s.index('        private void Put(int slot, int liveExtent, ExecutableSlot value)');b=s.index('        internal void PrepareTransfer()',a);s=s[:a]+'''        private void Put(int slot, int liveExtent, ExecutableSlot value)
            => _work.Stack.PublishSlot(Values, slot, liveExtent, value);

        private void Trim(int liveExtent) => _work.Stack.RetireTo(Values, liveExtent);

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/PyExecutableFunction.cs';s=p.read_text(encoding='utf-8');s=s.replace('        work.Stack.RestoreNativeExtent(_codeObject.FirstTemporarySlot);\n','');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');a=s.index('        // Stores through the same captured-cell');b=s.index('        private static object ReadOperand(',a);stores=s[a:s.index('        private static void StoreExecutableLocal(',a)];stores=stores.replace('ExecutableSlot[] locals','Span<ExecutableSlot> locals');s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Results.cs';s=p.read_text(encoding='utf-8');a=s.index('        internal static void PublishInstructionResult(ref ExecutableWorkState execution,\n            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)');s=s[:a]+'''        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishExecutableSlot(ref execution, execution.Stack.Values, invocation, instruction, value);
    }

    private static void PublishExecutableSlot(ref ExecutableWorkState execution, Span<ExecutableSlot> values,
        ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
    {
        if (!instruction.HasLocalResult)
        {
            execution.Stack.PublishSlot(values, instruction.ResultSlot, instruction.LiveExtent, value);
            return;
        }
        if (instruction.LiveExtent < execution.Stack.LiveExtent)
            execution.Stack.RetireTo(values, instruction.LiveExtent);
        if (execution.Stack.HasPendingDisposals)
        {
            execution.Stack.PublishSlot(values, instruction.ResultSlot, instruction.LiveExtent, value);
            return;
        }
        execution.Stack.ForgetResultInput(values, instruction.ResultSlot);
        ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 1];
        execution.Stack.CheckExecution(store.Span);
        StoreLocalValue(execution.Code, values, invocation, store.LocalSlot, value, store.Span);
        execution.InstructionIndex++;
    }

'''+stores+'}\n';s=s.replace('internal static void PublishInstructionResult(','private static void PublishInstructionResult(');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8');needle='''                        case ExecutableOpCode.StoreLocal:
                            StoreExecutableLocal(ref execution, scope, invocation, instruction);
                            break;
''';assert s.count(needle)==1;s=s.replace(needle,'');p.write_text(s,encoding='utf-8',newline='\n');print('One shared publication/local-store/retirement implementation; native metadata holds no array/allowance and keeps only its genuine private lifetime distinction.')
