from pathlib import Path
import json, re
r=Path('D:/code/Lython');w=r/'.git/agent-worktrees/shared-kernel-r439';n=r/'.git/agent-notes/review-20261031/shared-kernel-r439'
old=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';new=old.with_name('LythonRuntime.Executable.Kernel.cs')
assert old.exists() and not new.exists();old.rename(new)
p=w/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');a=s.index('Each call opcode prepares the evaluated function');b=s.index('Eligible native prefixes support backward branches',a)
s=s[:a]+'''The executable engine uses one closed instruction kernel over final managed slots.
Private completed calls borrow their existing inline or bound storage; persistent
frames borrow their own admitted array and execution metadata. Both share operand
reads, builtin call selection, publication, local/cell stores and retirement. No
borrow survives suspension. Persistent retirement clears references and queues
real asynchronous disposal; private dead references end at prefix exit or transfer.
Each call prepares the evaluated function and receiver at its current instruction.
Completed bodies publish after call and workspace cleanup. Genuine binding,
protocols, exception/finally routing and pending children use the existing frame
driver. Unsupported closed shapes transfer before effects, at the exact current
instruction, without replay; invalid opcodes are compiler defects. Lexical context
requirements and the first cleanup boundary govern private admission, without a
second whole-function opcode inventory. Conservative durable-frame admission can
occur after an earlier completed prefix; refused admission remains terminal.
''' + s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=r/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('| Active isolated migration |');b=s.index('\n| Independent adapter',a)
s=s[:a]+'''| Active isolated migration | R439, `.git/agent-worktrees/shared-kernel-r439`,baseline9f07335c. One closed managed-slot loop now shares operand/storage,closures,branches,receiver/subscript/format handlers and completed call/child transfer. Old ordinary selectors,temporary gate and full-function native-opcode inventory removed. Closure checks1065internal/4663public; value checks1799/3094 per actual11/10 pass. Call/continuation checks running; no retention,full qualification or CPU claim. |'''+s[b:]
a=s.index('**R439 active implementation:**');b=s.index('\n| Candidate/hypothesis',a)
s=s[:a]+'''**R439 active implementation:** isolated `.git/agent-worktrees/shared-kernel-r439`,
baseline9f07335c/runtime0443b5cf. One closed loop now borrows real managed metadata
and final slots for private completed calls and persistent frames. Shared storage,
closures,closed branches,receiver loading,builtin subscripts,formatting and completed
call selection replace their duplicate handlers. Genuine protocols/suspension and
return/finally routing retain the existing frame driver. No new call controller,
allowance,exception router or heap workspace. Temporary classification and compiler
full-function opcode inventory removed; actual lexical/cleanup boundaries remain.

Latest completed Release closure1065internal/4663public and value1799/3094 checks
pass eachactual11/10; overlapping filters are not summed. Call/continuation checks
are running after a successful both-target build. Next correct any demonstrated
failures,freeze the coherent source,run one bounded allocation/whole-script source
pair,decide regression debt,and batch full delivery checks at retention. No timing
or retention claim. Private passing snapshots/logs stay outside current docs;
normal branch remains unchanged except independent cleanup coverage9f07335c.
Publication held.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Updated ignored plan and prototype runtime guide; renamed the shared kernel file. No production promotion.')
for source in ['materialization-r438/allocation-short/catalog.json','checkpoint-r437/catalog.json','kernel-r436/refined/allocation-short/catalog.json']:
    catalog=json.loads((n.parent/source).read_text(encoding='utf-8'))
    print(source, [c['id'] for c in catalog['cases']])
