from pathlib import Path
import json, shlex, subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
b=Path('/home/lokad/lython-bench-checks')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 own={str(os.getpid()),str(os.getppid())}
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 paths=['materialization-b837-20261116/candidate/Lokad.Lython.dll',
 'materialization-b837-20261116/observations.tgz',
 'materialization-b837-20261116/confirmation/confirmation.json',
 'representative-b836-20261116/representative.json']
 rows=[];inodes={}
 for n in paths:
  p=b/n;m=p.lstat();assert stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and p.resolve()==p
  key=(m.st_dev,m.st_ino);assert key not in inodes;inodes[key]=[]
  rows.append(dict(path=n,bytes=m.st_size,links=m.st_nlink,sha256=sha(p)))
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;m=p.lstat();key=(m.st_dev,m.st_ino)
   if key in inodes:inodes[key].append(str(p.relative_to(b)))
 for row in rows:
  m=(b/row['path']).stat();row['paths']=inodes[(m.st_dev,m.st_ino)]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,rows=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=60)
assert p.returncode==0,p.stderr
(r/'stage-space.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
