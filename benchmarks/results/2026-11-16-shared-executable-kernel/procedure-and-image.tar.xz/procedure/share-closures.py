from pathlib import Path
w=Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Arithmetic.cs';s=p.read_text(encoding='utf-8');needle='    internal ref partial struct ExecutableKernel';assert s.count(needle)==1;s=s.replace(needle,'''    private static object TakeExecutableOperand(ref ExecutableWorkState work, Span<ExecutableSlot> values,
        in ExecutableInstruction instruction, ExecutionContext scope)
    {
        if (instruction.InputStart >= work.Code.FirstTemporarySlot)
            return work.Stack.TakeValue(values, instruction.InputStart, instruction.LiveExtent);
        var value = ReadExecutableOperand(work.Code, values, instruction.InputStart, work.InstructionIndex, 0, scope);
        work.Stack.RetireTo(values, instruction.LiveExtent);
        return value;
    }

'''+needle);p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');a=s.index('        private static object TakeOperand(');b=s.index('        private static ExecutableSlot TakeReturnOperand(',a);s=s[:a]+'''        private static object TakeOperand(ref ExecutableWorkState execution, in ExecutableInstruction instruction, ExecutionContext scope)
            => TakeExecutableOperand(ref execution, execution.Stack.Values, instruction, scope);

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs';s=p.read_text(encoding='utf-8');a=s.index('    private static bool TryStoreClosure(');b=s.index('    private static void StoreExecutableClosure(',a);s=s[:a]+'''    private static bool TryStoreClosure(ref ExecutableWorkState execution, Span<ExecutableSlot> values,
        ExecutionContext scope, ExecutionContext? context, in ExecutableInstruction instruction)
    {
        var slot = instruction.ClosureSlot;
        if (execution.ClosureCells is { } cells && (uint)slot < (uint)cells.Count && cells[slot].CanStoreThroughOwner)
        {
            cells[slot].Value = TakeExecutableOperand(ref execution, values, instruction, scope);
            return true;
        }
        if (context is null) return false;
        StoreExecutableClosure(execution.Code, context, slot,
            TakeExecutableOperand(ref execution, values, instruction, scope), instruction.Span);
        return true;
    }

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs';s=p.read_text(encoding='utf-8').replace('        private readonly IReadOnlyList<ExecutableCell> _cells => _work.ClosureCells!;\n','');s=s.replace('or ExecutableOpCode.Jump or ExecutableOpCode.StoreLocal)) return false;','or ExecutableOpCode.Jump or ExecutableOpCode.StoreLocal or ExecutableOpCode.LoadClosure\n                    or ExecutableOpCode.StoreClosure or ExecutableOpCode.CompareJumpIfFalse\n                    or ExecutableOpCode.JumpIfFalse)) return false;');a=s.index('                    case ExecutableOpCode.LoadClosure:');b=s.index('                    case ExecutableOpCode.StoreLocal:',a);s=s[:a]+'''                    case ExecutableOpCode.LoadClosure:
                        if (!_work.Stack.HasPendingDisposals && TryExecuteClosureArithmetic(Code,
                            _work.ClosureCells, Index, LiveExtent, _scope))
                        { Index += 2; break; }
                        if (!TryLoadClosure(in _work, _invocation, instruction.ClosureSlot, instruction.Span, out var captured))
                            return false;
                        Publish(instruction, captured);
                        break;
                    case ExecutableOpCode.StoreClosure:
                        if (!TryStoreClosure(ref _work, Values, _scope, _invocation, instruction)) return false;
                        break;
'''+s[b:];a=s.index('                    case ExecutableOpCode.CompareJumpIfFalse:');b=s.index('                    case ExecutableOpCode.Jump:',a);s=s[:a]+'''                    case ExecutableOpCode.CompareJumpIfFalse:
                    {
                        bool truth;
                        try
                        {
                            if (!TryIntegerComparison(instruction, out truth))
                            {
                                var first = Read(instruction.InputStart, 0);
                                var second = Read(instruction.SecondInput, 1);
                                if (!TryEvaluateScalarComparison(instruction.BinaryOperator, first, second,
                                    _scope, instruction.Span, out truth)) return false;
                            }
                            Trim(instruction.LiveExtent);
                            _scope.CheckExecution(instruction.Span);
                        }
                        catch { if (_persistent) Trim(instruction.LiveExtent); throw; }
                        if (!truth)
                        {
                            Index = instruction.TargetIndex;
                            if (_persistent && _work.Stack.HasPendingDisposals) { ClosedJumped = true; return false; }
                            continue;
                        }
                        break;
                    }
                    case ExecutableOpCode.JumpIfFalse:
                    {
                        var value = Read(instruction.InputStart, 0);
                        if (!CanUseNativeTruth(value)) return false;
                        _ = Take(instruction);
                        if (!IsTruthy(value, _scope, instruction.Span))
                        {
                            Index = instruction.TargetIndex;
                            if (_persistent && _work.Stack.HasPendingDisposals) { ClosedJumped = true; return false; }
                            continue;
                        }
                        break;
                    }
'''+s[b:];a=s.index('        private bool TryCell(');b=s.index('        private ExecutableSlot ReadReturnSlot(',a);s=s[:a]+s[b:];a=s.index('        private object Take(in ExecutableInstruction instruction)');b=s.index('        private void Publish(',a);s=s[:a]+'''        private object Take(in ExecutableInstruction instruction)
            => TakeExecutableOperand(ref _work, Values, instruction, _scope);

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8');a=s.index('                        case ExecutableOpCode.LoadClosure:');b=s.index('                        case ExecutableOpCode.StoreMember:',a);s=s[:a]+'''                        case ExecutableOpCode.LoadClosure or ExecutableOpCode.StoreClosure:
                            return InstructionPause.ContextRequired;
'''+s[b:];s=s.replace('if (invocation is null && !CanUseNativeTruth(condition))','if (invocation is null)');p.write_text(s,encoding='utf-8',newline='\n')
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8');needle='''                if (TryEvaluateScalarComparison(instruction.BinaryOperator, first, second!, scope, instruction.Span, out var truth))
                    pending = new(CompleteComparisonBranch(ref execution, scope, instruction, truth));
                else if (invocation is null) return InstructionPause.ContextRequired;
                else if (!asynchronous)''';assert s.count(needle)==1;s=s.replace(needle,'''                if (invocation is null) return InstructionPause.ContextRequired;
                if (!asynchronous)''');p.write_text(s,encoding='utf-8',newline='\n');print('Closures, operand consumption and closed conditional branches now share the kernel; dynamic protocols still use the existing driver.')
