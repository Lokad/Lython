from pathlib import Path

w = Path('D:/code/Lython/.git/agent-worktrees/shared-kernel-r439')
base = w / 'src/Lokad.Lython/Runtime'

def read(name):
    return (base / name).read_text(encoding='utf-8')

def save(name, text):
    (base / name).write_text(text, encoding='utf-8', newline='\n')

name = 'LythonRuntime.Executable.Interpreter.cs'
s = read(name)
a = s.index('        private static bool TryLoadDirectCallReceiver(')
b = s.index('        internal void AdoptExecutableExecution(', a)
member = s[a:b]
s = s[:a] + s[b:]
s = s.replace('''                case ExecutableOpCode.LoadCallMember:
                    if (TryLoadDirectCallReceiver(ref execution, scope, invocation, instruction)) break;
                    goto case ExecutableOpCode.LoadMember;
''', '''                case ExecutableOpCode.LoadCallMember:
''')
s = s.replace('        internal void AdoptExecutableExecution(', '        internal bool HasPreparedTypeSubscription => _preparedCallValue is not null;\n\n        internal void AdoptExecutableExecution(', 1)
save(name, s)

member = member.replace('private static bool TryLoadDirectCallReceiver(ref ExecutableWorkState execution, ExecutionContext scope,\n            ExecutionContext? invocation, in ExecutableInstruction instruction)', 'private bool LoadCallMember(in ExecutableInstruction instruction)')
member = member.replace('            if (instruction.OpCode != ExecutableOpCode.LoadCallMember) return false;\n', '')
member = member.replace('execution.Code', 'Code').replace('ReadOperand(ref execution, instruction.InputStart, scope, 0)', 'Read(instruction.InputStart, 0)')
member = member.replace('invocation is not null', '_invocation is not null')
member = member.replace('execution.Stack.PublishValue(', 'Put(')

name = 'LythonRuntime.Executable.NativePrefix.cs'
s = read(name)
s = s.replace('or ExecutableOpCode.JumpIfFalse)) return false;', '''or ExecutableOpCode.JumpIfFalse or ExecutableOpCode.LoadCallMember
                    or ExecutableOpCode.Subscript or ExecutableOpCode.StartFormattedString
                    or ExecutableOpCode.AppendFormattedText or ExecutableOpCode.FinishFormattedString
                    or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField)) return false;''')
a = s.index('                    case ExecutableOpCode.LoadCallMember:')
b = s.index('                    case ExecutableOpCode.Binary:', a)
s = s[:a] + '''                    case ExecutableOpCode.LoadCallMember:
                        if (!LoadCallMember(instruction)) return false;
                        break;
                    case ExecutableOpCode.Call:
                        if (!Call(instruction)) return false;
                        break;
                    case ExecutableOpCode.Subscript:
                        if (!Subscript(instruction)) return false;
                        break;
''' + s[b:]
a = s.index('        private bool Format(')
s = s[:a] + member + '''        private bool Subscript(in ExecutableInstruction instruction)
        {
            // A resumed descriptor retains its original operands in the real
            // invocation; never rerun its receiver/key or bypass its completion.
            if (_invocation?.HasPreparedTypeSubscription == true) return false;
            var target = Read(instruction.InputStart, 0);
            var key = Read(instruction.SecondInput, 1);
            try
            {
                if (target is PyTuple tuple && key is BigInteger integer && TryMachineInteger(integer, out var tupleIndex)
                    && tuple.TryBorrowInteger(tupleIndex, out var item))
                {
                    _scope.CheckExecution(instruction.Span);
                    Publish(instruction, item);
                    return true;
                }
                if (instruction.LookupCacheIndex >= 0 && target is PyDict { HasSharedRecordKeys: true } record
                    && key is PyString field)
                {
                    // Admission may reenter and mutate this very dictionary.
                    // Obtain backing first, then prove the current live layout.
                    var caches = _work.Stack.GetLookupCaches(Code.LookupCacheCount, instruction.Span);
                    if (record.TryReadRecordValue(field, ref caches[instruction.LookupCacheIndex], _scope,
                        instruction.Span, out var cached))
                    {
                        Publish(instruction, cached);
                        return true;
                    }
                }
                if (!(key is BigInteger && target is PyList or PyTuple or PyBytes or PyString or PyRange
                    || target is PyDict dictionary && dictionary.CanReadKeySynchronously(key))) return false;
                Publish(instruction, ReadSubscriptValue(target, key, instruction.Span, _scope));
                return true;
            }
            catch { if (_persistent) Trim(instruction.ResultSlot); throw; }
        }

''' + s[a:]
a = s.index('        private object TakeFormattedInput(')
b = s.index('        private bool Call(', a)
s = s[:a] + '''        private object TakeFormattedInput(int source, int liveExtent)
            => _work.Stack.TakeValue(Values, source, liveExtent);

''' + s[b:]
save(name, s)

name = 'LythonRuntime.Executable.PreparedOperations.cs'
s = read(name)
a = s.index('        private static bool TryExecuteFormattedInstruction(')
b = s.index('        // Only actual protocol values', a)
s = s[:a] + s[b:]
save(name, s)

name = 'LythonRuntime.Executable.Interpreter.Dispatch.cs'
s = read(name)
s = s.replace('                            if (TryExecuteFormattedInstruction(ref execution, invocation, instruction, invocation ?? scope)) break;\n', '')
a = s.index('                        case ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember:')
b = s.index('                        case ExecutableOpCode.LoadName', a)
s = s[:a] + '''                        case ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) ExecuteStackTransfer(ref execution, scope, invocation, instruction);
                            else
                            {
                                pending = invocation.ExecuteMemberLoadAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
''' + s[b:]
save(name, s)

name = 'LythonRuntime.Executable.Inputs.cs'
s = read(name)
a = s.index('                if (instruction.OpCode == ExecutableOpCode.Subscript && first is PyTuple tuple')
b = s.index('                if (instruction.OpCode is ExecutableOpCode.StoreSubscript', a)
s = s[:a] + s[b:]
a = s.index('                if (instruction.OpCode == ExecutableOpCode.Subscript && instruction.LookupCacheIndex')
b = s.index('                var immediate', a)
s = s[:a] + s[b:]
s = s.replace('''                    ExecutableOpCode.Subscript => second is BigInteger && first is PyList or PyTuple or PyBytes or PyString or PyRange ||
                        first is PyDict dictionary && dictionary.CanReadKeySynchronously(second!),''', '''                    ExecutableOpCode.Subscript => false,''')
save(name, s)
print('Shared receiver loading, builtin subscripts and formatting; removed duplicate completed handlers. Dynamic/prepared protocols keep the existing driver.')
