from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/shared-kernel-r439'
p=w/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Kernel.cs';s=p.read_text(encoding='utf-8');original=s
s=s.replace('        internal readonly ExecutableCodeObject Code => _work.Code;', '''        // Code and storage shape stay fixed throughout this borrowed view.
        // PC/live extent/cells still refer to the actual mutable work metadata.
        internal readonly ExecutableCodeObject Code;''')
s=s.replace('''            _work = ref work;
            _work.Stack = new ExecutableValueStorage''','''            _work = ref work;
            Code = work.Code;
            _work.Stack = new ExecutableValueStorage''')
s=s.replace('''            _work = ref work;
            Values = work.Stack.Values;''','''            _work = ref work;
            Code = work.Code;
            Values = work.Stack.Values;''')
s=s.replace('''            result = ExecutableSlot.FromObject(PyNone.Instance);
            while (Index < (_persistent ? Code.Instructions.Length : Code.NativePrefixEnd))''','''            result = ExecutableSlot.FromObject(PyNone.Instance);
            // Derive this fixed view fact once, without a stored policy/mode.
            var persistent = _persistent;
            var end = persistent ? Code.Instructions.Length : Code.NativePrefixEnd;
            while (Index < end)''')
a=s.index('        private bool RunCore(');b=s.index('        private bool LoadCallMember(',a);body=s[a:b].replace('if (_persistent', 'if (persistent');s=s[:a]+body+s[b:]
assert s!=original and s.count('Code = work.Code;')==2
p.write_text(s,encoding='utf-8',newline='\n')
decision=dict(hypothesis='A shared borrowed kernel should borrow changing execution metadata,but carry immutable compiled code and derive its fixed storage shape/loop boundary once. Removing repeated aliased metadata reads may reduce dispatch cost without a second engine or state synchronization.',evidence='B838 captured/search adversity; B839938/974active samples with3840invocations each and225/223combined dispatch/call leaves do not isolate a causal added call/binding bottleneck. Useful/inlined work and unknowns remain.',changedWork='One existing view caches its immutable Code reference; one loop derives persistent/cleanup boundary once. No cached PC/live extent/cells,stored mode,heap allocation,new owner,API,policy or exception router.',workloads=['complete captured-helper text','protected search','normalization','CSV invoice','JSON helpers'],semantics='Code/storage backing cannot be replaced during an active borrowed view,as the existing outer instruction-array snapshot already requires. Current PC/live extent/cells remain actual metadata during callbacks. Preserve child transfer,no replay,first refusal,awaited cleanup,closures/identity,stack safety and active cancellation.',acceptance='Both-target focused semantics/cancellation/ownership,then one bounded changed-source pair with independent unchanged controls against qualified0443. Preserve91ca/B838 and B839 including initial schema failure. Decide residual regression debt at coherent retention; no claim of explaining original regression from sampling or cross-collection source gain.',fullDeliveryPending=True,retained=False)
(r/'refinement-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('| Active isolated migration / measurement running |','| Active isolated migration / refinement |').replace('Attribution/refinement next; no retention or full delivery.', 'B839attribution complete; immutable-code/view-fact refinement active. No retention/full delivery.')
a=s.index('Next one bounded source/CPU attribution');b=s.index('\n| Candidate/hypothesis',a)
s=s[:a]+'''B839 matched captured-script CPU attribution completes with938/974active samples
and3840invocations each;75/80unknown leaves remain. Combined dispatch/call leaves
225/223 do not isolate a causal new binding/call bottleneck or removable share.
Raw/maps,all thread CPU and initial old-schema pre-worker failure are preserved;
all users joined and RAM evidence archived/verified before unmount. Terminal cached.

One bounded refinement separates immutable code/view facts from actual changing
metadata: retain Code on the existing view and derive loop storage/cleanup boundary
once. No cached/synchronized PC,live extent or cells,no stored mode,new controller,
owner,policy or engine. Existing instruction-array snapshot already requires code/
backing stability during a view. Hypothesis,not an established regression cause.
Focused both-target semantics/cancellation/ownership,then one changed-source pair
with controls versus qualified0443; preserve91ca/B838/B839. Decide residual debt
and batch full delivery at retention. Main brancha3d87c5f/runtime0443b5cf;
publication held. Continue the substantial roadmap after this milestone.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Refined immutable facts in the existing view; mutable execution metadata remains shared. Original91ca source/image stays frozen.')
