using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref execution, invocation, instruction, ExecutableSlot.FromObject(value));

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishExecutableSlot(ref execution, execution.Stack.Values, invocation, instruction, value);
    }

    private static void PublishExecutableSlot(ref ExecutableWorkState execution, Span<ExecutableSlot> values,
        ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
    {
        if (!instruction.HasLocalResult)
        {
            execution.Stack.PublishSlot(values, instruction.ResultSlot, instruction.LiveExtent, value);
            return;
        }
        if (instruction.LiveExtent < execution.Stack.LiveExtent)
            execution.Stack.RetireTo(values, instruction.LiveExtent);
        if (execution.Stack.HasPendingDisposals)
        {
            execution.Stack.PublishSlot(values, instruction.ResultSlot, instruction.LiveExtent, value);
            return;
        }
        execution.Stack.ForgetResultInput(values, instruction.ResultSlot);
        ref readonly var store = ref execution.Code.Instructions[execution.InstructionIndex + 1];
        execution.Stack.CheckExecution(store.Span);
        StoreLocalValue(execution.Code, values, invocation, store.LocalSlot, value, store.Span);
        execution.InstructionIndex++;
    }

    // Captured cells own their binding policy. Ordinary unmirrored stores need
    // neither a namespace lookup nor a guest name; synthetic stores share this rule.
    private static void StoreLocalValue(ExecutableCodeObject codeObject, Span<ExecutableSlot> locals,
        ExecutionContext? context, int slot, object value, LythonSourceSpan span)
        => StoreLocalValue(codeObject, locals, context, slot, ExecutableSlot.FromObject(value), span);

    private static void StoreLocalValue(ExecutableCodeObject codeObject, Span<ExecutableSlot> locals,
        ExecutionContext? context, int slot, ExecutableSlot value, LythonSourceSpan span)
    {
        if (context?.GlobalNamespace is not null)
        {
            var name = codeObject.LocalNames[slot];
            if (!name.StartsWith('<'))
            {
                StoreGlobalNamespaceName(context, name, value.Object.RequireNotNull());
                return;
            }
        }
        if (locals[slot].Reference is ExecutableCell localCell)
        {
            localCell.Value = value.Object.RequireNotNull();
            return;
        }
        locals[slot] = value;
        if (codeObject.RequiresLocalVariableMirroring || context?.MirrorLocalStores == true)
        {
            var name = codeObject.LocalNames[slot];
            if (!name.StartsWith('<')) context!.Variables[name] = locals[slot].Object.RequireNotNull();
        }
    }
}
