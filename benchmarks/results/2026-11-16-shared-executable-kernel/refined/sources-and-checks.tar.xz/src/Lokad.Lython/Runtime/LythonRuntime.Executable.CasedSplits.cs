using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static object ExecuteCasedSplit(ExecutableCasedSplit recipe, PyString receiver, ExecutionContext context,
        bool consumedByIteration = false)
    {
        context.CheckExecution(recipe.CasingMemberSpan);
        context.CheckExecution(recipe.CasingCallSpan);
        context.CheckExecution(recipe.SplitMemberSpan);
        context.CheckExecution(recipe.SplitCallSpan);
        return consumedByIteration
            ? PyStringOps.PrepareCasedWhitespaceIteration(receiver, recipe.Upper, context, recipe.SplitCallSpan)
            : PyStringOps.SplitCasedWhitespace(receiver, recipe.Upper,
                context.MemoryGovernor, recipe.SplitCallSpan, context);
    }

}
