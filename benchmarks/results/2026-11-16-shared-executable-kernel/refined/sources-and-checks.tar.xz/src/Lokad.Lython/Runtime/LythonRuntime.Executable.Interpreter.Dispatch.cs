using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private enum InstructionPause { Continue, Boundary, Call, Operation, Disposal, ContextRequired }

        // Both APIs execute completed instructions here, outside an async state
        // machine. An incomplete operation leaves its instruction/span current.
        // The async driver owns the pending value and all disposal until resume.
        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutionContext?> nextCall)
        {
            pending = default;
            pendingSpan = default;
            nextCall = default;
            var instructions = execution.Code.Instructions;
            while (execution.InstructionIndex < instructions.Length)
            {
                var jumped = false;
                try
                {
                    var kernel = new ExecutableKernel(ref execution, scope, invocation);
                    kernel.ExecuteClosedPrefix();
                    if (kernel.StartedCall is { } started)
                    {
                        nextCall = new(started);
                        pendingSpan = execution.Code.CallSites[instructions[execution.InstructionIndex].CallSiteIndex].CallSpan;
                        return InstructionPause.Call;
                    }
                    if (asynchronous && execution.Stack.HasPendingDisposals)
                    {
                        // The completed producer remains current. The existing
                        // async driver advances it after awaited retirement.
                        pending = new(kernel.ClosedJumped);
                        return InstructionPause.Disposal;
                    }
                    if (execution.InstructionIndex >= instructions.Length) return InstructionPause.Boundary;
                    ref readonly var instruction = ref instructions[execution.InstructionIndex];
                    scope.State.CheckExecution(instruction.Span);
                    switch (instruction.OpCode)
                    {
                        case ExecutableOpCode.Complete:
                            return InstructionPause.Boundary;
                        case ExecutableOpCode.LoadClosure or ExecutableOpCode.StoreClosure:
                            return InstructionPause.ContextRequired;
                        case ExecutableOpCode.StoreMember:
                        case ExecutableOpCode.StoreMemberLast
                            or ExecutableOpCode.StoreSlice or ExecutableOpCode.StoreSliceLast
                            or ExecutableOpCode.ReadRetainedSubscript or ExecutableOpCode.ReadRetainedSlice
                            or ExecutableOpCode.UnpackValues or ExecutableOpCode.FailAssertion or ExecutableOpCode.Raise
                            or ExecutableOpCode.DeleteName or ExecutableOpCode.DeleteMember
                            or ExecutableOpCode.DeleteSubscript or ExecutableOpCode.DeleteSlice:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation!.ExecuteTargetInstruction(instruction, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(invocation!.ExecuteTargetInstruction(instruction, true));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText
                            or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation.ExecuteFormattedValueAsync(instruction, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(invocation.ExecuteFormattedValueAsync(instruction, true));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.ApplyOperation:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous)
                                invocation!.ExecutePreparedOperationAsync(instruction, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(invocation!.ExecutePreparedOperationAsync(instruction, true));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Yield:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            invocation!.YieldValue = execution.Stack.TakeValue(instruction.InputStart, instruction.ResultSlot);
                            invocation!.HasYield = true;
                            invocation!._waitingForSend = true;
                            execution.InstructionIndex++;
                            return InstructionPause.Boundary;
                        case ExecutableOpCode.YieldFrom:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (asynchronous)
                            {
                                pending = invocation!.ExecuteDelegationAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            else
                            {
                                if (invocation!._delegation is null)
                                {
                                    var source = execution.Stack.TakeValue(instruction.InputStart, instruction.ResultSlot);
                                    invocation!._delegation = new GeneratorDelegation(Iter([source], instruction.Span, invocation!), invocation!, instruction.Span);
                                }
                                invocation!.CompleteDelegatedStep(invocation!._delegation.Advance(invocation!._sentValue, invocation!._injectedException), instruction);
                            }
                            if (invocation!.HasYield) return InstructionPause.Boundary;
                            break;
                        case ExecutableOpCode.Import or ExecutableOpCode.DefineFunction or ExecutableOpCode.ExecuteFallbackStatement:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation!.ExecuteDefinitionOrFallback(instruction);
                            else
                            {
                                pending = WithoutJump(invocation!.ExecuteDefinitionOrFallbackAsync(instruction));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) ExecuteStackTransfer(ref execution, scope, invocation, instruction);
                            else
                            {
                                pending = invocation.ExecuteMemberLoadAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.LoadName or ExecutableOpCode.PreloadImplicitSuperArguments or
                             ExecutableOpCode.StoreGlobal or ExecutableOpCode.StoreName:
                            if (invocation is null)
                                return InstructionPause.ContextRequired;
                            ExecuteStackTransfer(ref execution, scope, invocation, instruction);
                            break;
                        case ExecutableOpCode.MakeSet or ExecutableOpCode.MakeDict or ExecutableOpCode.MatchCase:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            jumped = invocation!.ExecuteStructure(instruction);
                            break;
                        case ExecutableOpCode.ResolveContextManager or ExecutableOpCode.EnterContextManager or ExecutableOpCode.ExitContextManager:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) jumped = invocation!.ExecuteStructure(instruction);
                            else
                            {
                                pending = invocation!.ExecuteContextManagerAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.CompareJumpIfFalse:
                            var comparisonPause = ExecuteComparisonInstruction(ref execution, scope, invocation, instruction, asynchronous,
                                out pending, out pendingSpan);
                            if (comparisonPause != InstructionPause.Continue) return comparisonPause;
                            jumped = ConsumeOperation(ref pending);
                            break;
                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary:
                        case ExecutableOpCode.Subscript:
                        case ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast:
                            var pause = ExecuteInputInstruction(ref execution, scope, invocation, instruction, asynchronous,
                                out pending, out pendingSpan, out nextCall);
                            if (pause != InstructionPause.Continue) return pause;
                            break;
                        case ExecutableOpCode.ForNextDictionaryAccumulation:
                        case ExecutableOpCode.ForNext:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) jumped = invocation.ExecuteForNext(instruction);
                            else
                            {
                                pending = invocation.ExecuteForNextAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Call:
                            var call = execution.Code.CallSites[instruction.CallSiteIndex];
                            var callStart = instruction.InputStart;
                            var target = execution.Stack[callStart + call.TargetOffset];
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (invocation!.TryBeginExecutableCall(call, callStart, target, asynchronous, out nextCall))
                            {
                                if (!nextCall.IsCompletedSuccessfully || !ReferenceEquals(nextCall.Result, invocation))
                                {
                                    pendingSpan = call.CallSpan;
                                    return InstructionPause.Call;
                                }
                                nextCall = default;
                                // Completed calls already published after cleanup.
                                jumped = true;
                                break;
                            }
                            if (!asynchronous) invocation!.ExecuteOrdinaryCall(call, callStart, target, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(invocation!.ExecuteOrdinaryCall(call, callStart, target, true));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.GetIter:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation!.ExecuteValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(invocation!.ExecuteGetIteratorAsync(instruction));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Slice:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            if (!asynchronous) invocation!.ExecuteValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(invocation!.ExecuteSliceValueOperationAsync(instruction));
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.MakeSlice:
                            if (invocation is null) return InstructionPause.ContextRequired;
                            invocation!.ExecuteValueOperation(instruction);
                            break;
                        case ExecutableOpCode.JumpIfFalse:
                            var condition = ReadOperand(ref execution, instruction.InputStart, scope, 0);
                            if (invocation is null)
                                return InstructionPause.ContextRequired;
                            if (!asynchronous || condition is not PyInstance)
                                jumped = ExecuteControlFlow(ref execution, scope, invocation, instruction);
                            else
                            {
                                pending = invocation!.ExecuteConditionalJumpAsync(instruction);
                                if (!pending.IsCompleted) return PauseOperation(instruction.Span, out pendingSpan);
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.AbruptJump or ExecutableOpCode.MatchException or
                             ExecutableOpCode.BindException or ExecutableOpCode.ReraiseException or ExecutableOpCode.ClearException or
                             ExecutableOpCode.EndFinally or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone:
                            if (invocation is null && instruction.OpCode is not (ExecutableOpCode.Return or ExecutableOpCode.ReturnNone))
                                return InstructionPause.ContextRequired;
                            jumped = ExecuteControlFlow(ref execution, scope, invocation, instruction);
                            if (!execution.ReturnValue.IsUnassigned)
                            {
                                // Keep the returning instruction/span current and
                                // finish queued native disposal before leaving.
                                if (asynchronous && execution.Stack.HasPendingDisposals)
                                {
                                    pending = new(jumped);
                                    return InstructionPause.Disposal;
                                }
                                return InstructionPause.Boundary;
                            }
                            break;
                        default:
                            throw new InvalidOperationException($"Unknown executable opcode: {instruction.OpCode}");
                    }
                }
                catch (ReturnSignal signal)
                {
                    if (invocation is null) throw;
                    if (!invocation.TryRouteReturn(signal, instructions[execution.InstructionIndex].Span)) return InstructionPause.Boundary;
                    jumped = true;
                }
                catch (ControlSignal signal)
                {
                    if (invocation is null || !invocation.TryRouteControl(signal, instructions[execution.InstructionIndex].Span)) throw;
                    jumped = true;
                }
                catch (LythonRuntimeException error)
                {
                    if (invocation is null)
                    {
                        var previous = scope.State.CurrentException;
                        if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous)) error.PythonContext ??= previous;
                        throw;
                    }
                    if (!invocation.TryRouteRuntimeException(error, instructions[execution.InstructionIndex].Span)) throw;
                    jumped = true;
                }

                if (asynchronous && execution.Stack.HasPendingDisposals)
                {
                    pending = new(jumped);
                    return InstructionPause.Disposal;
                }
                if (!jumped) execution.InstructionIndex++;
            }
            return InstructionPause.Boundary;
        }

        private static InstructionPause PauseOperation(LythonSourceSpan span, out LythonSourceSpan? pendingSpan)
        {
            // The helper can finish and update the jump target before its
            // awaiter resumes. Keep the originating span independent of that.
            pendingSpan = span;
            return InstructionPause.Operation;
        }

        private static bool ConsumeOperation(ref ValueTask<bool> pending)
        {
            var operation = pending;
            pending = default;
            return operation.GetAwaiter().GetResult();
        }

        private static ValueTask<bool> WithoutJump(ValueTask operation)
        {
            if (operation.IsCompleted)
            {
                operation.GetAwaiter().GetResult();
                return new(false);
            }
            return AwaitOperation(operation);

            static async ValueTask<bool> AwaitOperation(ValueTask pending)
            {
                await pending.ConfigureAwait(false);
                return false;
            }
        }
    }
}
