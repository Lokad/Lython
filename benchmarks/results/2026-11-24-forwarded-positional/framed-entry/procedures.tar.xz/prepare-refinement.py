from pathlib import Path
lab = Path(__file__).resolve().parent
previous = lab.with_name("forwarded-positional-20261124")
text = (previous / "prepare.py").read_text(encoding="utf-8")
text = text.replace("Forward evaluated unary positional operands through native calls",
                    "Forward positional operands through the established framed call entry")
text = text.replace('    ["scripts.annotated-rule-closures.nested-factories.postponed", "warm"],\n', '')
text = text.replace('b1623-fixtures', 'b1624-fixtures').replace('len(jobs) == 7', 'len(jobs) == 6')
text = text.replace('forwarded-positional-b1623-20261124', 'forwarded-positional-framed-b1624-20261124')
text = text.replace('lython-b1623-forwarded-positional-', 'lython-b1624-forwarded-positional-framed-')
text = text.replace('"b1623-"', '"b1624-"')
text = text.replace('"RuntimeMaxSec=315"', '"RuntimeMaxSec=268"').replace('"seconds=235"', '"seconds=202"')
text = text.replace("verified six goldens", "verified five goldens")
compile(text, "prepare.py", "exec")
(lab / "prepare.py").write_text(text, encoding="utf-8", newline="\n")
