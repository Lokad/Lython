from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
donor = lab.with_name('closed-capture-pair-20261124') / 'probe-candidate'
cases = [
'''def make(n):
    def f(x, first=n * 3, /, last=1024, *, offset=n % 5 + 2, test=n % 3 != 0):
        return (x + first + last + offset) if test else x
    g = lambda x, y=(n + 1) // 9, /, *, z=3: (x - y) * z
    return f, g
for i in (0, 1, -1, 9223372036854775807, -9223372036854775808, 1 << 80, True):
    a, b = make(i)
    c, d = make(i)
    print(a(19), b(7), a.__defaults__, a.__kwdefaults__, a.__defaults__ is c.__defaults__, b.__kwdefaults__ is d.__kwdefaults__)
''',
'''def make(n):
    def f(*, scale=n * 2):
        return scale
    g = lambda a=n // 7, b=1024, c=n % 3: (a, b, c)
    return f, g
a, b = make(14)
x, y = make(19)
print(a(), b(), x(), y())
a.__kwdefaults__['scale'] = 99
print(a(), x())
''',
'''def make(n):
    def f(x=n + 1):
        return x
    g = lambda x=12 // n, y=n: x + y
    return f, g
f, g = make(3)
try:
    f, g = make(0)
except ZeroDivisionError as error:
    print(type(error).__name__, f(), g())
''',
'''Tag = str
def bind(owner):
    def make(n):
        def f(x: Tag, y=n * 7, *, owner=owner):
            return owner, x, y
        return f
    return make
saved = []
factory = bind(saved)
f = factory(17)
Tag = int
g = factory(9223372036854775807)
print(f.__kwdefaults__['owner'] is saved, g.__annotations__['x'] is int, f.__annotations__['x'] is str)
print(f(2), g(2))
''',
'''events = []
class Number:
    def __mod__(self, rhs):
        events.append(rhs)
        return rhs + 1
    def __add__(self, rhs):
        events.append(rhs)
        return rhs * 2
def make(n):
    def f(x=n % 7, *, addon=(n + 1) % 3):
        return x, addon
    g = lambda x=n % 17: x
    return f, g
f, g = make(Number())
print(f(),g(),events)
''',
'''from __future__ import annotations
def make(n):
    def answer(x: int, /, y: int = 27 // n, *, offset=n % 7 + 1) -> tuple:
        return (x, y, offset)
    return answer
f = make(3)
try:
    make(0)
except ZeroDivisionError:
    pass
print(f(75), f.__annotations__)
''']
cases += ['def make(n):\n    def inner(pos=n // 7, *, step=(n + 1) % 5):\n        return pos, step\n    return inner\nfor n in (-5, 0, 13, (1 << 63) - 1, -(1 << 63), 1 << 95):\n    f, g = make(n), make(n)\n    print(f(), f.__defaults__ is g.__defaults__, f.__kwdefaults__ is g.__kwdefaults__)\n', "def make(n):\n    def inner(pos: Missing = 12 // n, *, step=n % 5):\n        return pos, step\n    return inner\nfor n in (0, 2):\n    try:\n        f = make(n)\n    except (NameError, ZeroDivisionError) as e:\n        print(type(e).__name__)\nMissing = int\nprint(make(3)(), make(3).__annotations__['pos'] is int)\n"]
cases += ['def run(flag):\n    if flag == 1:\n        target = abs\n    if flag == 2:\n        argument = 7\n    return target(argument)\nfor choice in (0, 1, 2):\n    try:\n        print(run(choice))\n    except UnboundLocalError as error:\n        print(type(error).__name__, "\'target\'" in str(error), "\'argument\'" in str(error))\n', 'events = []\nclass Callable:\n    def __call__(self, value):\n        events.append(value)\n        return (value, value)\ndef caller(target, argument):\n    x, y = target(argument)\n    return x, y\nargument = [1, 2]\none, two = caller(Callable(), argument)\nprint(one is two, two is argument, events[0] is argument, len(events))\n', 'class Owner:\n    def call(self, arg, *, missing=7):\n        return self, arg, missing\ndef invoke(target, argument):\n    return [target(argument)]\nowner = Owner()\nargument = []\nbound = owner.call\noutput = invoke(bound, argument)\nprint(output[0][0] is owner, output[0][1] is argument, output[0][2])\n', 'def same(value):\n    return value\ndef forward(target, number):\n    arg = number + 17\n    computed = target(arg)\n    return [arg is computed, computed]\nfor number in (1024, 1 << 70):\n    print(forward(same, number))\n', "def generator(value):\n    try:\n        yield value\n    finally:\n        print('closed')\ndef forward(target, argument):\n    return target(argument)\narg = [9]\nitems = forward(generator, arg)\nprint(next(items) is arg)\nitems.close()\n", 'effects = []\ndef dynamic(value, extra):\n    effects.append(value)\ndef call(target, argument):\n    return (target(argument), 7)\ntry:\n    call(dynamic, [])\nexcept TypeError as failure:\n    print(type(failure).__name__, effects)\n', "values = []\ndef helper(item):\n    values.append(item)\n    raise ValueError('observed')\ndef call(target, argument):\n    try:\n        return target(argument)\n    except ValueError as error:\n        return (str(error), argument is values[0])\nargument = []\nprint(call(helper, argument), len(values))\n"]
request = json.dumps(cases)
(lab/'oracle-input.json').write_text(request+'\n', encoding='utf-8', newline='\n')
identity = json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
for role in ('reference','candidate'):
    probe = lab/f'probe-{role}'
    probe.mkdir(exist_ok=True)
    for path in donor.iterdir():
        if path.suffix == '.pdb': continue
        shutil.copyfile(lab/role/path.name if path.name == 'Lokad.Lython.dll' else path,probe/path.name)
    assert hashlib.sha256((probe/'Lokad.Lython.dll').read_bytes()).hexdigest() == identity['coreSHA256'][role]
    for mode in ('sync','async'):
        options=['--async'] if mode=='async' else []
        run=subprocess.run([sdk/'dotnet.exe',probe/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe',*options],
            input=request,text=True,encoding='utf-8',env=env,capture_output=True,timeout=70)
        (lab/f'oracle-{role}-{mode}.jsonl').write_text(run.stdout,encoding='utf-8',newline='\n')
        results=[json.loads(line) for line in run.stdout.splitlines()]
        print(role,mode,len(results),sum(row['Matches'] and row['Lython']['Success'] for row in results))
        assert run.returncode == 0 and len(results) == len(cases) and all(row['Compared'] and row['Matches'] and row['Lython']['Success'] for row in results), (run.stdout,run.stderr)