from pathlib import Path

lab = Path(__file__).resolve().parent
source = (lab.with_name("forwarded-positional-20261124") / "archive.py").read_text(encoding="utf-8")
source = source.replace('repo / "benchmarks/results/2026-11-24-forwarded-positional"',
                        'repo / "benchmarks/results/2026-11-24-forwarded-positional/framed-entry"')
source = source.replace('proof["caseCount"] == 6', 'proof["caseCount"] == 5')
source = source.replace('Passed:  1423', 'Passed:    73').replace('Passed:  3878', 'Passed:   252')
source = source.replace('-white-verified.log', '-white.log').replace('-public-verified.log', '-public.log')
source = source.replace('"prepare-trial.py"', '"prepare-refinement.py"')
source = source.replace('"prepare-oracle.py"', '"launch-insufficient-space.log"')
source = source.replace('"windows-build.log", "windows-probe-build.log", "windows-public.log",',
                        '"windows-build.log",')
source = source.replace('"prepare-final.log"', '"prepare.log"').replace('"archive.py", "archive-quiet.py"',
    '"archive.py", "archive-quiet.py", "prepare-archive.py"')
compile(source, "archive.py", "exec")
(lab / "archive.py").write_text(source, encoding="utf-8", newline="\n")
