from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
donor = lab.with_name("current-defaulted-report-cpu-20261124") / "tape-inspector"
sdk = Path.home() / ".dotnet11"
environment = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
data = lambda path: json.loads(path.read_text(encoding="utf-8"))
identity = data(lab / "comparison/identity.json")
catalog = data(lab / "comparison/quiet/representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in
                    ("scripts.rule-default-closures", "scripts.annotated-rule-closures")]
op = lambda instruction: instruction["<OpCode>k__BackingField"]
result = {}
eager_tapes = {}

for role in ("reference", "candidate"):
    stage = lab / (role + "-tape")
    stage.mkdir(exist_ok=True)
    for name in ("Inspect.deps.json", "Inspect.dll", "Inspect.runtimeconfig.json"):
        shutil.copyfile(donor / "bin/Release/net11.0" / name, stage / name)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", stage / "Lokad.Lython.dll")
    (stage / "catalog.json").write_text(json.dumps(catalog, indent=2) + "\n", encoding="utf-8")
    subprocess.run([sdk / "dotnet.exe", stage / "Inspect.dll", stage / "catalog.json", stage / "tape.json"],
                   env=environment, timeout=20, check=True)
    proof = data(stage / "tape.json")
    assert proof["coreSHA256"] == identity["coreSHA256"][role]
    codes = next(row["codes"] for row in proof["rows"] if row["id"] == "scripts.rule-default-closures")
    eager_tapes[role] = next(row["codes"] for row in proof["rows"] if row["id"] == "scripts.annotated-rule-closures")
    module = next(code for code in codes if code["name"] == "<module>")
    tape = module["tape"]
    calls = [dict(index=i, span=entry["<Span>k__BackingField"],
                  forwarded=entry["_secondaryOperand"] != 2**31-1,
                  priorOpcodes=list(map(op, tape[i-2:i])), nextOpcode=op(tape[i+1]))
             for i, entry in enumerate(tape) if op(entry) == 42 and 9 <= entry["<Span>k__BackingField"]["Line"] <= 10]
    assert len(calls) == 3 and all(call["forwarded"] == (role == "candidate") for call in calls)
    assert role != "reference" or all(call["priorOpcodes"] == [2, 2] for call in calls)
    result[role] = dict(calls=calls, totalModuleInstructions=len(tape), codeSHA=proof["coreSHA256"],
                        nativeTargets={code["name"]: [code["native"],code["definitionPair"],code["directIntegerReturn"]]
                                       for code in codes if code is not module})
assert result["reference"]["totalModuleInstructions"] - result["candidate"]["totalModuleInstructions"] == 6
assert eager_tapes["reference"] == eager_tapes["candidate"]
summary = dict(loops=2048, removedLocalLoadsPerGroup=6, roles=result, eagerTapeAndMetadataMatch=True)
(lab / "call-tape-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary))
