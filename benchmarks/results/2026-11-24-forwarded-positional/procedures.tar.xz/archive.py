from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-forwarded-positional"
out.mkdir(exist_ok=True)
quiet = lab / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(quiet / "identity.json")
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab / "candidate.patch").read_bytes() == subprocess.check_output(
    ["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
assert read(lab / "call-tape-summary.json")["removedLocalLoadsPerGroup"] == 6

for role, manifest in identity["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == manifest
    proof = read(lab / "comparison" / f"{role}-verify.json")
    assert proof["caseCount"] == 6 and proof["state"] == "Completed"
    for mode in ("sync", "async"):
        checks = [json.loads(line) for line in (lab / f"oracle-{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(checks) == 15 and all(row["Matches"] and row["Compared"] for row in checks)
for platform in ("windows", "ubuntu"):
    assert "Passed:  1423" in (lab / (platform + "-white-verified.log")).read_text(encoding="utf-8-sig")
    assert "Passed:  3878" in (lab / (platform + "-public-verified.log")).read_text(encoding="utf-8-sig")

for relative, name in (("comparison/quiet/identity.json", "identity.json"),
                      ("allocation-summary.json", "allocation-summary.json"),
                      ("call-tape-summary.json", "call-tape-summary.json")):
    shutil.copyfile(lab / relative, out / name)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in ["archive.py", "archive-quiet.py", "prepare-trial.py", "prepare.py", "prepare-oracle.py",
                 "oracle.py", "oracle-input.json", "inspect-tapes.py", "allocations.py", "quiet.py",
                 "windows-build.log", "windows-probe-build.log", "windows-public.log",
                 "windows-white-verified.log", "windows-public-verified.log",
                 "ubuntu-white-verified.log", "ubuntu-public-verified.log",
                 "reference-tape/tape.json", "candidate-tape/tape.json", "reference-tape/catalog.json",
                 "reference-allocation.json", "candidate-allocation.json",
                 "candidate.patch", "prepare-final.log", "launch.log", "retrieve.log", "catalog-custody.json",
                 "comparison/candidate-verify.json", "comparison/reference-verify.json",
                 "comparison/quiet/jobs.json", "comparison/quiet/representative.json", "comparison/quiet/run.sh",
                 "comparison/quiet/collect.py", "comparison/quiet/storage-custody.json"] + [
                     f"oracle-{role}-{mode}.jsonl" for role in ("reference", "candidate") for mode in ("sync", "async")]:
        archive.add(lab / name, arcname=name, recursive=False)
    source = lab.with_name("current-defaulted-report-cpu-20261124") / "tape-inspector/Program.cs"
    archive.add(source, arcname="tape-inspector/Program.cs", recursive=False)
