from pathlib import Path

lab = Path(__file__).resolve().parent
past = lab.with_name("closed-definition-construction-20261124")
text = (past / "prepare.py").read_text(encoding="utf-8")
text = text.replace('assert head.startswith("bfae5253b")', 'assert head.startswith("48790b2c7")')
text = text.replace('assert b"private static PyFunctionBase CreateClosedDefinition" in patch.read_bytes()',
                    'assert b"forwardedArgument" in patch.read_bytes()')
text = text.replace('Run single computed definitions and closed pair members through one constructor',
                    'Forward evaluated unary positional operands through native calls')
text = text.replace('b1622-fixtures', 'b1623-fixtures').replace('len(jobs) == 5', 'len(jobs) == 7')
text = text.replace('compile(collector,', 'collector = collector.replace("len(jobs) == 5", "len(jobs) == 7")\ncompile(collector,')
text = text.replace('closed-definition-construction-b1622-20261124', 'forwarded-positional-b1623-20261124')
text = text.replace('lython-b1622-closed-definition-construction-', 'lython-b1623-forwarded-positional-')
text = text.replace('\"b1622-\"', '\"b1623-\"')
text = text.replace('launch = launch.replace(oldsha, newsha)',
                    'launch = launch.replace(oldsha, newsha).replace("RuntimeMaxSec=230", "RuntimeMaxSec=315").replace("seconds=170", "seconds=235")')
text = text.replace('["scripts.csv-invoice.method-policy.quoted-control", "warm"]',
    '''["scripts.captured-rule-closures", "warm"],
    ["diagnostic.text-summary.nonlocal-computed-width.large", "warm"],
    ["scripts.csv-invoice.method-policy.quoted-control", "warm"]''')
text = text.replace('verified four goldens', 'verified six goldens')
compile(text, "prepare.py", "exec")
(lab / "prepare.py").write_text(text, encoding="utf-8", newline="\n")
