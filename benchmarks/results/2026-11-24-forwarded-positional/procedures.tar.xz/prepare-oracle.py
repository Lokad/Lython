from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.with_name("closed-definition-construction-20261124")
old = (prior / "oracle.py").read_text(encoding="utf-8")
i = old.index("request = json.dumps(cases)")
cases = [
"""def run(flag):
    if flag == 1:
        target = abs
    if flag == 2:
        argument = 7
    return target(argument)
for choice in (0, 1, 2):
    try:
        print(run(choice))
    except UnboundLocalError as error:
        print(type(error).__name__, "'target'" in str(error), "'argument'" in str(error))
""",
"""events = []
class Callable:
    def __call__(self, value):
        events.append(value)
        return (value, value)
def caller(target, argument):
    x, y = target(argument)
    return x, y
argument = [1, 2]
one, two = caller(Callable(), argument)
print(one is two, two is argument, events[0] is argument, len(events))
""",
"""class Owner:
    def call(self, arg, *, missing=7):
        return self, arg, missing
def invoke(target, argument):
    return [target(argument)]
owner = Owner()
argument = []
bound = owner.call
output = invoke(bound, argument)
print(output[0][0] is owner, output[0][1] is argument, output[0][2])
""",
"""def same(value):
    return value
def forward(target, number):
    arg = number + 17
    computed = target(arg)
    return [arg is computed, computed]
for number in (1024, 1 << 70):
    print(forward(same, number))
""",
"""def generator(value):
    try:
        yield value
    finally:
        print('closed')
def forward(target, argument):
    return target(argument)
arg = [9]
items = forward(generator, arg)
print(next(items) is arg)
items.close()
""",
"""effects = []
def dynamic(value, extra):
    effects.append(value)
def call(target, argument):
    return (target(argument), 7)
try:
    call(dynamic, [])
except TypeError as failure:
    print(type(failure).__name__, effects)
""",
"""values = []
def helper(item):
    values.append(item)
    raise ValueError('observed')
def call(target, argument):
    try:
        return target(argument)
    except ValueError as error:
        return (str(error), argument is values[0])
argument = []
print(call(helper, argument), len(values))
""",
]
(lab / "oracle.py").write_text(old[:i] + "cases += " + repr(cases) + "\n" + old[i:], encoding="utf-8", newline="\n")
subprocess.run([sys.executable, "-I", "-X", "utf8", lab / "oracle.py"], check=True)
