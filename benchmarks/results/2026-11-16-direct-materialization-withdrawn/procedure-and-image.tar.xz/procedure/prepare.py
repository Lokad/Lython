from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;old=r.parent/'kernel-r436/refined';w=Path('D:/code/Lython/.git/agent-worktrees/materialization-r438');sha=lambda b:hashlib.sha256(b).hexdigest();f=r/'frozen';f.mkdir();previous=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'));images={}
for role in ['reference','candidate']:
 shutil.copytree(old/'frozen/candidate',f/role)
 if role=='candidate':shutil.copyfile(w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p.read_bytes())for p in(f/role).iterdir()if p.is_file()}
assert images['reference']==previous['images']['candidate']and all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(previous['sources'])+['tests/Lokad.Lython.Tests/DrainCleanupOwnershipTests.cs','tests/Lokad.Lython.Tests/MaterializationAdmissionTests.cs'];assert len(set(paths))==609
identity=dict(buildSourceCommit=subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:sha((w/n).read_bytes())for n in paths},contract='Direct existing Cursor transport for object materialization, one DrainLease growth rule. Initial storage admitted before live iterator acquisition, permitting earlier refusal. Await disposal before refund. No new owner/controller/policy/cache; general enumerable bridges retain genuine users.',referenceQualification='312f5911/measured0443b5cf full43828954661 GREEN,607inputs/16summaries; terminal cached forever.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in(r/'checks').glob('*.trx')];assert sorted(int(x['passed'])for x in checks)==sorted([1092,1092,1897,1897,202,202,820,820,2,2,4,4])and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fullQualificationPending=True,overlappingFiltersNotSummed=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 for n in paths:t.add(w/n,arcname=n)
 t.add(r/'checks',arcname='checks');t.add(r/'final-build.log',arcname='final-build.log')
catalog=json.loads((r.parent/'checkpoint-r437/catalog.json').read_text(encoding='utf-8'));extra=json.loads((old/'allocation-short/catalog.json').read_text(encoding='utf-8'));catalog['cases'].append(next(x for x in extra['cases']if x['id']=='generators.drain.large'));rawCatalog=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()
d=r/'allocation-short';d.mkdir();allocation=dict(catalog);allocation['cases']=[]
for x in catalog['cases']:
 c=dict(x,runAsync=False);allocation['cases'].append(c)
 if x['id']=='scripts.text-normalization.large':allocation['cases'].append(dict(c,id=x['id']+'.async',runAsync=True))
allocation['cases'].append(next(x for x in extra['cases']if x['id']=='calls.positional.large'))
(d/'catalog.json').write_text(json.dumps(allocation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['Program.cs','Allocation.csproj']:shutil.copyfile(old/'allocation-short'/n,d/n)
shutil.copytree(old/'allocation-short/bin',d/'bin');shutil.copyfile(old/'measure-allocation.py',r/'measure-allocation.py')
q=r/'quiet';q.mkdir();before=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'));root='/home/lokad/lython-bench-checks/materialization-b837-20261116';unit='lython-b837-materialization-20261116';files=before['identity']['imageFiles']['candidate'];imageFiles={role:{n:images[role][n]for n in files}for role in ['reference','candidate']}
ident=dict(sourceRevision='R438 isolated'+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified312f5911/0443b5cf',purpose='One bounded direct-materialization source pair: complete normalization warm/fresh, generator drain and CSV/JSON controls. Separate allocation,CPU and source simplification.',coreSHA256={label:imageFiles['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=imageFiles,prototype=True,publicationHeld=True,candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((f/'identity.json').read_bytes()),referenceQualification=identity['referenceQualification'])
(q/'identity.json').write_text(json.dumps(ident,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'representative.json').write_bytes(rawCatalog)
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/'quiet'/n).read_text(encoding='utf-8').replace(before['root'],root).replace(before['unit'],unit).replace('B834','B837')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+"jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['generators.drain.large','warm'],['scripts.csv-invoice.large','warm'],['scripts.json-summary-helpers.large','warm']]"+s[b:]
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
archiveProof=json.loads((r/'archives.json').read_text(encoding='utf-8'))['archives'][0];assert archiveProof['links']==1
matches=[p for p in Path('benchmarks/results').rglob('observations.tgz')if p.stat().st_size==archiveProof['bytes']and sha(p.read_bytes())==archiveProof['sha256']];assert len(matches)==1,matches;archive=matches[0].as_posix();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();raw=matches[0].read_bytes();assert raw==subprocess.check_output(['git','show',head+':'+archive])
proof=dict(bytes=len(raw),sha256=sha(raw),links=1,paths=[archiveProof['path']],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=None))
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(rawCatalog),identity=ident,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'reference'","source/'candidate'").replace(" os.link(source/'representative.json',root/'representative.json')\n",'').replace('lython-b834-fixtures','lython-b837-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'launch-quiet.py',r/'launch-quiet.py');shutil.copyfile(old/'summarize.py',r/'summarize.py')
print(json.dumps(dict(core=images['candidate']['Lokad.Lython.dll'],inputs=len(paths),checks=len(checks),allocationCases=len(allocation['cases']),quietJobs=5,retiredOnly=archiveProof['path'],custody=archive,catalogBytes=len(rawCatalog))))
