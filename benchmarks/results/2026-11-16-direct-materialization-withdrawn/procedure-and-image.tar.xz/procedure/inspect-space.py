from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,json,os,shutil,stat,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 rows=[]
 for name in ['iteration-refine-b834-20261116','representative-b835-20261116','representative-b836-20261116']:
  for p in(b/name).rglob('*'):
   if not p.is_file()or{'candidate','reference'}&set(p.relative_to(b/name).parts):continue
   m=p.lstat();assert stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()
   rows.append(dict(path=str(p.relative_to(b)),bytes=m.st_size,links=m.st_nlink))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,files=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr;(r/'space.json').write_text(p.stdout,encoding='utf-8');v=json.loads(p.stdout);print(json.dumps(dict(freeBytes=v['freeBytes'],largeFiles=[x for x in v['files']if x['bytes']>10000],total=sum(x['bytes']for x in v['files']))))
