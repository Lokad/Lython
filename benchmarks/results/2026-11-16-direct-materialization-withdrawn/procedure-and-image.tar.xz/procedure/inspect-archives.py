from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 archives=sorted(b.glob('*/observations.tgz'),key=lambda p:p.stat().st_size,reverse=True)[:4]
 print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,archives=[dict(path=str(p.relative_to(b)),bytes=p.stat().st_size,links=p.stat().st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in archives])))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr;(r/'archives.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
