from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-16-direct-materialization-withdrawn');out.mkdir();receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=False,decision='Withdraw complete transport prototype: flat allocation, stable adverse warm normalization,extra cleanup wrappers; broader kernel remains independent.',CPythonRefreshed=False);(r/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['summary.json','allocation-summary.json','focused-checks.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/sources-and-checks.tar.xz',out/'sources-and-checks.tar.xz')
with tarfile.open(out/'procedure-and-image.tar.xz','w:xz')as t:
 for n in ['identity.json','candidate/Lokad.Lython.dll']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for p in r.glob('*.json'):t.add(p,arcname=p.name)
 for p in r.glob('*.log'):t.add(p,arcname=p.name)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='quiet/'+p.name)
 for n in ['Program.cs','Allocation.csproj','catalog.json','reference.json','candidate.json','image-hashes.json']:t.add(r/'allocation-short'/n,arcname='allocation/'+n)
(out/'README.md').write_text('''# Direct materialization transport: withdrawn

R438/B837,2026-11-16UTC. Isolated **e0d2bdea** versus fully qualified
**312f5911 /0443b5cf**. Withdraw the complete prototype; normal runtime unchanged.
This does not close the larger call/frame/operand performance objective or forbid
a changed materialization design with new evidence.

Hypothesis: use existing Cursor directly in object materialization, removing
CheckedSequence/AsyncSequence and CLR-yield transport around Python iterators.
One DrainLease capacity-growth rule replaces two copies. Initial list admission
precedes live iterator acquisition, with earlier refusal and awaited cursor disposal.
No new owner/controller/policy/cache; genuine enumerable consumers remain.
However, four entry/cleanup wrappers and a shared per-item append call add work
and35production lines. The wrapping classes still have genuine other consumers;
this does not displace a whole execution stage. No source cause is isolated by timing.

| Complete job | Candidate elapsed change | Wider CPU change | Ref/candidate process-median spreads |
| --- | ---: | ---: | ---: |
| Normalization warm | +2.90..+4.56% | +1.89..+3.86% | 0.06/1.55% |
| Normalization compile-to-result | −6.58..+0.05% | −6.12..+1.63% | 6.24/0.80% |
| Generator draining warm | −3.89..+6.36% | −3.41..+6.00% | 1.63/8.88% |
| CSV invoice control warm | −2.38..+2.84% | −0.56..+2.78% | 4.51/0.81% |
| JSON aggregation control warm | −0.15..+1.25% | −1.96..+1.42% | 0.03/1.37% |

Five jobs/173.539s, all image/golden/quiet/Closed/exit/join/archive gates pass.
Two independent processes per source;5s full-request warmup and five rotated~0.5s
rounds. Four pairings, not confidence intervals; maximum within-process IQR2.98%.
Warm normalization is adverse with supporting CPU and stable reference. Fresh,
drain and CSV controls are inconclusive; moving controls establish uncertainty,
not failed semantic correctness. All originals remain. No unchanged retiming or
permanent one-attempt rule follows from withdrawal.

Separate local seven-job natural-GC allocation is effectively flat (largest
absolute change<0.02%); all accounted peaks unchanged. Existing focused checks:
1,092internal/1,897public plus202internal/820public affected consumers per actual
.NET11/10, overlapping filters not summed. Six additional cases per target check
pending disposal/cancellation funding and live admission/replacement/refusal.
609source inputs frozen after nonincremental Release build. New test namespace
compile error corrected before its tests; original log preserved.

The four acquisition-order cases specify the proposed contract and are withdrawn
with it. Two pending-cleanup cases assert independent ownership behavior and will
be checked against the retained runtime. No admission contract/API change is shipped.
No full platform/package qualification is needed for the withdrawn product prototype;
qualified0443remains normal. Future larger redesign must preserve these lifetimes.

Quiet F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 natural
workstation GC/normal tiering. Warm includes mediated RAM I/O,full stdout/file
goldens and prior-result cleanup; excludes compilation/startup,reset/protocol and
final cache teardown. Fresh includes compilation and one execution; wider CPU includes
reset/protocol. No CPython/source-additive/heap/pending-I/O/embedding-tail claim.

Evidence persisted and independently verified before RAM teardown; no users remain,
terminal cached. Only one exact committed historical archive replica retired after
fresh lease/UID/path/hash/all-alias proof: B445observations.tgz equals nested
b445/observations.tgz in committed prepared-consumers observations.tar.xz. The
initial direct-file custody lookup failed safely before VM mutation; corrected
proof did not change measurement conditions. Current0443/e0images and toolchains,
254/252MiB floors preserved. Publication/tagging held.

[All controls](summary.json),[allocation](allocation-summary.json),[raw](observations.tgz),
[source/tests](sources-and-checks.tar.xz),[images/procedures/original conditions](procedure-and-image.tar.xz).
''',encoding='utf-8',newline='\n')
cleanup='tests/Lokad.Lython.Tests/DrainCleanupOwnershipTests.cs';w=Path('D:/code/Lython/.git/agent-worktrees/materialization-r438');shutil.copyfile(w/cleanup,Path(cleanup))
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R438/B837 direct materialization withdrawn](results/2026-11-16-direct-materialization-withdrawn/README.md):e0d2bdea/qualified0443b5cf,fivejobs/173.539s/all gates. Normalization warm+2.90..4.56%elapsed/+1.89..3.86%CPU,allocation effectively flat. Fresh/drain/CSV controls move6.24/8.88/4.51%; preserve uncertainty, not blanket failure. Four cleanup wrappers/shared append add work and35lines while generic bridges retain genuine users. Withdraw complete transport/proposed acquisition contract; qualified runtime unchanged. Independent two pending-cleanup tests carried forward for baseline verification. Larger coherent kernel remains open; no permanent retry ban or new full qualification campaign.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('All adverse original measurements/source preserved; product unchanged, independent cleanup tests copied for baseline checks.')
