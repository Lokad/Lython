from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';f=r/'frozen';old=r.parent/'kernel-r436/refined';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'));ident=json.loads((q/'identity.json').read_text(encoding='utf-8'));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive='benchmarks/results/2026-11-08-prepared-consumers/observations.tar.xz';raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',head+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as t:body=t.extractfile('b445/observations.tgz').read()
previous=json.loads((r/'archives.json').read_text(encoding='utf-8'))['archives'][0];assert previous['sha256']==sha(body)and previous['bytes']==len(body)and previous['links']==1
proof=dict(bytes=len(body),sha256=sha(body),links=1,paths=[previous['path']],custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member='b445/observations.tgz'))
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(f/'candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root='/home/lokad/lython-bench-checks/materialization-b837-20261116',unit='lython-b837-materialization-20261116',source=before['root'],sourceFiles=before['identity']['imageFiles']['candidate'],sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(payload['representative.json']),identity=ident,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("source/'reference'","source/'candidate'").replace(" os.link(source/'representative.json',root/'representative.json')\n",'').replace('lython-b834-fixtures','lython-b837-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(old/'launch-quiet.py',r/'launch-quiet.py');shutil.copyfile(old/'summarize.py',r/'summarize.py')
print(json.dumps(dict(candidate=ident['coreSHA256']['candidate'],reference=ident['coreSHA256']['reference'],unpackedBytes=c['unpackedBytes'],retireBytes=len(body),archivedMember='b445/observations.tgz',catalogSHA256=c['catalogSHA256'])))
