from pathlib import Path
import hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = repo/'benchmarks/results/2026-11-23-closed-definition-return'
dest = repo/'benchmarks/results/2026-11-23-retained-short-text-cpu'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda blob: hashlib.sha256(blob).hexdigest()
identity = read(lab/'identity.json')
assert identity['imageFiles'] == read(source/'identity.json')['imageFiles']
terminal = read(lab/'terminal-status.json')
assert terminal['exitCode'] == '0' and not terminal['live'] and not terminal['fixtures']
assert all(terminal['receipt'][name] for name in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
failed = read(lab/'initial-failed-terminal-status.json')
assert failed['exitCode'] == '1' and not failed['receipt']['complete'] and not failed['fixtures']
assert sha((lab/'initial-failed-observations.tar.xz').read_bytes()) == failed['receipt']['archiveSHA256']
assert sha((lab/'observations.tar.xz').read_bytes()) == terminal['receipt']['archiveSHA256']
rows = read(lab/'attribution.json')['rows']
assert len(rows) == 3 and all(row['sampleCount'] > 0 and row['invocations'] > 0 for row in rows)
dest.mkdir(exist_ok=True)
for name in ('identity.json','terminal-status.json','observations.tar.xz','attribution.json','initial-failed-terminal-status.json','initial-failed-observations.tar.xz'):
    shutil.copyfile(lab/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','quiet.py','collect.py','ops-profile.py','analyze.py','run.sh','stage.log','verification.json','launch.log','retrieve.log','analysis.log','observe-not-before','initial-failed-retrieve.log','initial-failed-launch.log'):
        archive.add(lab/name,arcname=name,recursive=False)
print(dest)
