R97 combined94cb8963/cored6254b2e CPython checkpoint after R92/R95/R96.
Same maintained26 jobs, scripts/fixtures/goldens/worker/protocol and boundaries as R90.
Separate compile/warm/compile-to-result, two identical Lython processes and isolated
CPython3.13.16; actual.NET11RC3/optional0.4 unchanged. Normal GC/tiering.
5s warmup per role/job, seven rotated150ms rounds, quiet dedicated F4as_v7.
All source/core/auxiliary/Ready/golden/quiet/Closed/exit/join/fixture/archive gates.
570s owner+30s stop+30s margin. Full CI independent; no release/publication claim.
Included mediated RAM I/O, full output checks, prior-result cleanup; startup,
fixture reset, protocol and final cache teardown outside timing. No causal attribution,
old-debt repayment or overall objective closure inferred from external ratios.
Persistent evidence; owned128MiB RAM for guest fixtures only. Reuse archived B457core.
Measured R90 raw+archive footprint plus25% and actual payload required above240MiB
OS floor before launch. No evidence/core/path deletion or new framework.
