from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.parent/'terminal-tuple-reads-20261123'
base=lab.parent/'closed-factory-operand-20261123'
source=(prior/'prepare.py').read_text(encoding='utf-8')
pairs=(
    ('terminal-tuple-reads-20261123','plain-class-module-slots-20261123'),
    ("donor=notes/'closed-factory-operand-20261123'","donor=notes/'terminal-tuple-reads-20261123'"),
    ("assert reference==git('rev-parse','HEAD') and not git('status','--porcelain',cwd=tree)","assert reference.startswith('48bf2bc2f') and not git('status','--porcelain',cwd=tree)"),
    ("assert not git('status','--porcelain')","assert not git('diff','--name-only',reference,'HEAD','--','src','tests')"),
    ("    'scripts.ordinary-fully-supplied-helper.local-function',","    'scripts.ordinary-fully-supplied-helper.local-function',\n    'scripts.config-manifest.small',"),
    ("for role,build in (('reference','reference-build'),('candidate','frozen')):","for role in ('reference','candidate'):"),
    ("source=lab/build/'bin/Lokad.Lython/release_net11.0'/core if name==core else donor/'candidate'/name",
     "source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name"),
    ("purpose='Test terminal integer transport into the existing fixed return window'",
     "purpose='B1532 keep module slots for a plain class and reuse fixed integer return transport'"),
)
for a,b in pairs:
    assert source.count(a)==1,a
    source=source.replace(a,b)
target=lab/'prepare.py'
compile(source,str(target),'exec')
target.write_text(source,encoding='utf-8',newline='\n')

def adapt(name,changes):
    code=(base/name).read_text(encoding='utf-8')
    for a,b in changes:
        assert code.count(a)==1,(name,a)
        code=code.replace(a,b)
    compile(code,str(lab/name),'exec')
    (lab/name).write_text(code,encoding='utf-8',newline='\n')
adapt('stage.py',(
    ('closed-factory-operand-b1529-20261123','plain-class-module-slots-b1532-20261123'),
    ('supplied-lexical-call-b1526-20261123','terminal-tuple-reads-b1531-20261123'),
    ('lython-b1529-fixtures','lython-b1532-fixtures'),
    ('len(jobs) == 6','len(jobs) == 5'),('< 320,','< 270,'),
))
adapt('quiet.py',(
    ('lython-b1529-closed-factory-operand-20261123','lython-b1532-plain-class-module-slots-20261123'),
    ('.+b1529-','.+b1532-'),('lython-b1529-stage-','lython-b1532-stage-'),
    ('Six bounded lanes write under 1 MiB of receipts. A 34 MiB','Five bounded lanes write under 1 MiB of receipts. A 20 MiB'),
    ('34 * 1024 * 1024','20 * 1024 * 1024'),
    ('RuntimeMaxSec=380','RuntimeMaxSec=320'),('seconds=294','seconds=248'),
))
adapt('summarize.py',(
    ('== 6\nassert hashlib','== 5\nassert hashlib'),('len(warm["jobs"])==6','len(warm["jobs"])==5'),
    ('timedBatches=168','timedBatches=140'),
))
