from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
comparison = lab / "comparison/quiet"
comparison.mkdir(parents=True)
b1926 = notes / "compiler-checkpoint-b1926-20261128/comparison/quiet"
b1921 = notes / "current-checkpoint-b1921-20261128/comparison/quiet"
b1914 = notes / "current-checkpoint-b1914-20261128/comparison/quiet"
b1931 = notes / "regex-group-costs-b1931-20261128/comparison-corrected"
core = "Lokad.Lython.dll"

def read(path): return json.loads(path.read_bytes())
def digest(path): return sha256(path.read_bytes()).hexdigest()
def manifest(folder): return {path.name:digest(path) for path in folder.iterdir()}
def write(path, content): path.write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8", newline="\n")
def git(*args): return subprocess.check_output(["git", *args], cwd=repo)

head = git("rev-parse", "HEAD").decode().strip()
assert not git("status", "--porcelain")
measured = read(b1931 / "identity.json")
assert sha256(git("diff", "--binary", measured["sourceRevision"], head, "--", "src/Lokad.Lython")).hexdigest() == measured["sourcePatchSHA256"]
assert not git("diff", "081f6b831", head, "--", "src", "Directory.Build.props", "Directory.Packages.props")
image = measured["imageFiles"]["candidate"]
assert len(image) == 32 and manifest(b1931 / "candidate") == image
copytree(b1931 / "candidate", comparison / "local-image")
assert manifest(comparison / "local-image") == image
assert all(not path.samefile(b1931 / "candidate" / path.name) for path in (comparison / "local-image").iterdir())

def archived(folder, tag):
    folder_image = read(folder / "identity.json")["imageFiles"]["candidate"]
    old_local = folder / "local-image"
    assert manifest(old_local) == folder_image and len(folder_image) == 32
    terminal = read(folder / "terminal-status.json")
    assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"] == "0"
    receipt = terminal["receipt"]
    assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"))
    assert digest(folder / "observations.tar.xz") == receipt["archiveSHA256"]
    return dict(name=read(folder / "upload.json")["root"], unit=f"lython-b{tag}-current-cpython",
        image=folder_image, role="candidate", localImage=str(old_local.relative_to(repo)),
        archive=receipt["archiveSHA256"])

donor = archived(b1926, 1926)
removals = [archived(b1921, 1921), donor]
assert {name for name, checksum in image.items() if donor["image"][name] != checksum} == {core}

def catalog(folder):
    p = folder / "representative.json"
    assert digest(p) == read(folder / "identity.json")["catalogs"][p.name]["sha256"]
    return read(p)

selected = catalog(b1926)
regex = catalog(b1914)
regex_cases = [c for c in regex["cases"] if c["id"].startswith("scripts.regex-log-search.")]
assert len(regex_cases) == 2
selected["cases"].extend(regex_cases)
assert len(selected["cases"]) == 7
write(comparison / "representative.json", selected)
jobs = [
    ["diagnostic.shipment-starmap-iterable-rows", "warm-async"],
    ["scripts.regex-log-search.compiled", "warm"],
    ["diagnostic.generated-ordinary-definitions", "compile"],
    ["diagnostic.shipment-starmap-iterable-rows", "warm"],
    ["scripts.regex-log-search.module", "warm"],
    ["diagnostic.nested-json-document", "warm-async"],
    ["diagnostic.file-search-first-line", "warm"],
    ["scripts.config-edit.small", "compile-run"],
]
assert {case for case, lane in jobs} == {case["id"] for case in selected["cases"]}
write(comparison / "jobs.json", jobs)
for name in ("cpython-worker.py", "run.sh"):
    copy2(b1926 / name, comparison / name)
assert b"\r" not in (comparison / "run.sh").read_bytes()
assert digest(comparison / "cpython-worker.py") == measured["cpythonWorkerSHA256"]
stage_name = "script-cpython-quiet-b1932-20261128"
identity = dict(sourceRevision=head, productionHead=head, sourcePatchSHA256=measured["sourcePatchSHA256"],
    purpose="Whole-script CPython comparison after generator call binding, frontend metadata, and direct regex group selection.",
    imageFiles={"candidate":image},
    coreSHA256={key:image[core] for key in ("candidate", "candidate-control")},
    auxiliaryFiles={name:sha for name,sha in image.items() if name!=core},
    frozenImage="/home/lokad/lython-bench-checks/" + stage_name + "/candidate",
    catalogs={name:{"sha256":digest(comparison / name)} for name in ("representative.json", "jobs.json")},
    expectedCPythonSHA256=read(b1926 / "identity.json")["expectedCPythonSHA256"],
    cpythonWorkerSHA256=measured["cpythonWorkerSHA256"], donorArchiveSHA256=donor["archive"])
write(comparison / "identity.json", identity)

collect = (b1926 / "collect.py").read_text(encoding="utf-8")
assert collect.count("len(jobs) == 6")==1
assert "lython-b1926-cpython-fixtures" in collect
collect=collect.replace("len(jobs) == 6","len(jobs) == 8").replace("lython-b1926-cpython-fixtures","lython-b1932-cpython-fixtures")
compile(collect, "collect.py", "exec")
(comparison / "collect.py").write_text(collect, encoding="utf-8", newline="\n")

paths = {name:comparison / name for name in ("identity.json","representative.json","jobs.json","cpython-worker.py","run.sh","collect.py")}
paths["candidate/" + core] = comparison / "local-image" / core
payload = comparison / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(archive.extractfile(name).read()==path.read_bytes() for name,path in paths.items())
files = {name:dict(length=path.stat().st_size, sha256=digest(path)) for name,path in paths.items()}
write(comparison / "upload.json", dict(root=stage_name, donor=donor["name"], donorFiles=donor["image"],
    donorArchive=donor["archive"], payloadSHA256=digest(payload), files=files,
    expandedBytes=sum(row["length"] for row in files.values()), minimumAfterStageBytes=5*1024*1024,
    removals=removals, caseCount=len(selected["cases"])))
print(stage_name, head, len(jobs), "lanes", sum(row["length"] for row in files.values()), "expanded bytes")
