from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
profile=lab/'attribution/profile'
allocation=lab/'allocation'
output=repo/'benchmarks/results/2026-11-28-current-cpython-regex-checkpoint'
output.mkdir(exist_ok=True)
def digest(path): return sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def archive(path, entries):
    assert len(entries)==len(set(entries))
    with tarfile.open(path,'w:xz',preset=3) as a:
        for name,item in entries.items(): a.add(item,arcname=name)
    with tarfile.open(path) as a:
        assert len(a.getmembers())==len(entries)
        assert all(sha256(a.extractfile(member).read()).hexdigest()==digest(entries[member.name]) for member in a.getmembers())

timing=read(quiet/'summary.json')
assert timing['timedBatches']==224 and timing['passedQuietCheck']
profile_summary=read(profile/'run-summary.json')
assert profile_summary['sourceRevision']==timing['source'] and profile_summary['allProcessesJoined']
checked_profile=read(profile/'identity.json')
ident=read(quiet/'identity.json')
assert checked_profile['imageFiles']==ident['imageFiles']
assert checked_profile['catalogs']==ident['catalogs']
observations=0
profile_files={}
for role, work, lane in checked_profile['profiles']:
    folder=profile/role
    record=read(folder/'record.json')
    assert record['coreSha']==ident['coreSHA256']['candidate']
    assert record['nettraceSha']==digest(folder/'run.nettrace')
    assert record['allProcessesJoined'] and record['lane']==lane and record['workload']==work
    observations+=len(record['batches'])
    for name in ('run.nettrace','run.speedscope.json','record.json','capture.log','worker.stderr','exclusive.txt','inclusive.txt'):
        profile_files['profile/'+role+'/'+name]=folder/name
assert observations==profile_summary['totalVerifiedBatches']
for name in ('identity.json','run-summary.json','managed-attribution.json','managed-analysis.log','collection.log','collect.py','analyze-managed.py','run.sh'):
    profile_files['profile/'+name]=profile/name
for name in ('representative.json','cpython-worker.py','candidate-verify.json'):
    profile_files[name]=profile.parent/name
archive(output/'profile-observations.tar.xz',profile_files)

paths={
 'identity.json':quiet/'identity.json','summary.json':quiet/'summary.json','archive-receipt.json':quiet/'archive-receipt.json',
 'observations.tar.xz':quiet/'observations.tar.xz','stage-custody.json':quiet/'stage-custody.json',
 'terminal-status.json':quiet/'terminal-status.json','profile-summary.json':profile/'run-summary.json',
 'profile-attribution.json':profile/'managed-attribution.json','allocation.json':allocation/'summary.json',
}
for name,item in paths.items():
    copy2(item,output/name)
    assert digest(output/name)==digest(item)
assert len(read(allocation/'summary.json'))==6
procedure = {}
for name in ('prepare.py','quiet-vm.py','summarize.py','measure-allocation.py','publish.py','local-verify.json','nearest-callers.json','launch-console.log'):
    procedure[name]=lab/name
for name in ('upload.json','retry-launch.log','candidate-remote-verify.json','exit-code.txt'):
    procedure[name]=quiet/name
for item in sorted((quiet/'attempt-initial').iterdir()):
    procedure['attempt-initial/'+item.name]=item
for item in allocation.glob('*.json'):
    procedure['allocation/'+item.name]=item
archive(output/'procedures.tar.xz',procedure)
print('Verified evidence',timing['timedBatches'],observations,'profiled batches')
