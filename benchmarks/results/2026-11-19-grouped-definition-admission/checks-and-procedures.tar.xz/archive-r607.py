from pathlib import Path
import hashlib
import gzip
import json
import shutil
import statistics
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-19-grouped-definition-admission")
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

pair = load(lab / "frozen-identity.json")
images = pair["images"]
base = pair["referenceCommit"]
candidate = pair["candidateCommit"]
retained = sys.argv[1]
if retained != "private":
    subprocess.run(["git", "diff", "--exit-code", candidate, retained, "--", "src", "tests"], check=True)
cases = {case["id"]: case for case in load(lab / "catalog.json")["cases"]}
assert digest(lab / "catalog.json") == pair["casesSHA256"]

def verify(folder, jobs, summary):
    scan = lab / folder
    identity = load(scan / "identity.json")
    assert identity["imageFiles"] == images and identity["catalogSHA256"] == pair["casesSHA256"]
    receipt = load(scan / "archive-receipt.json")
    terminal = load(scan / "terminal-status.json")
    assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
    assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
    assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                        "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"))
    assert receipt["jobs"] == jobs and receipt["archiveSHA256"] == digest(scan / "observations.tgz")
    raw = load(scan / "retrieved/confirmation/confirmation.json")
    assert raw["complete"] and len(raw["jobs"]) == jobs
    for job in raw["jobs"]:
        case = cases[job["case"]]
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 20
        assert set(job["identities"]) == set(identity["coreSHA256"])
        for role, worker in job["identities"].items():
            image = images[role.removesuffix("-control")]
            relevant = {Path(lib["path"]).name: lib["sha256"].lower() for lib in worker["libraries"]
                        if Path(lib["path"]).name in image}
            assert "Lokad.Lython.dll" in relevant
            assert all(image[name] == value for name, value in relevant.items())
            assert sorted(row["round"] for row in job["samples"] if row["engine"] == role) == list(range(5))
        for row in job["samples"]:
            value = row["response"]
            assert value["status"] == "Completed" and value["completedInvocations"] > 0
            for key in ("sourceSha256", "fixtureSha256", "expectedOutputSha256"):
                assert value[key] == case[key]
            for field, golden in (("actualOutputSha256", "expectedOutputSha256"), ("actualFilesSha256", "expectedFilesSha256")):
                assert value.get(field) == (None if job["lane"] == "compile" else case.get(golden))
    result = load(lab / summary)
    result.update(referenceRuntime=base, measuredPrototype=candidate, cores=identity["coreSHA256"],
        archiveSHA256=receipt["archiveSHA256"], retentionDecisionPending=False, retained=retained != "private")
    if retained != "private":
        result["retainedCommit"] = retained
    return result

initial = verify("quiet", 9, "quiet-summary.json")
confirmation = verify("confirmation", 3, "confirmation-summary.json")
allocations = []
before = load(lab / "reference-allocation.json")["rows"]
after = load(lab / "candidate-allocation.json")["rows"]
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    a = statistics.median(left["allocatedBytesPerInvocation"])
    b = statistics.median(right["allocatedBytesPerInvocation"])
    allocations.append(dict(case=left["id"], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1),
        accountedPeak=[left["peakExecutionMemoryBytes"],right["peakExecutionMemoryBytes"]]))
initial["localAllocation"] = allocations
resizes = {}
for role in ("reference","candidate"):
    observation = lab / "admission-observation" / role
    assert digest(observation / "Lokad.Lython.dll") == images[role]["Lokad.Lython.dll"]
    resizes[role] = load(lab / "admission-observation" / f"{role}.json")
assert [row["id"] for row in resizes["reference"]] == [row["id"] for row in resizes["candidate"]]
initial["executionHostAdmissionObservation"] = resizes

out.mkdir(exist_ok=False)
(out / "confirmation").mkdir()
save(out / "summary.json", initial)
save(out / "confirmation/summary.json", confirmation)
for folder, target in (("quiet",out),("confirmation",out/"confirmation")):
    for name in ("observations.tgz","archive-receipt.json","terminal-status.json"):
        shutil.copyfile(lab/folder/name,target/name)
core = lab / "frozen/candidate/Lokad.Lython.dll"
assert digest(core) == images["candidate"][core.name]
(out / "measured-core.dll.gz").write_bytes(gzip.compress(core.read_bytes(),mtime=0))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as tar:
    for name in ("measured-source.patch","catalog.json","frozen-identity.json","verify-pair.py",
                 "reference-verify.json","candidate-verify.json","reference-allocation.json","candidate-allocation.json",
                 "final-core-build.log","quiet-space.json","initial-quiet-space.json","preflight.json","canonical-space.py","stage-quiet.py",
                 "stage-confirmation.py","launch-confirmation.py","summarize-confirmation.py",
                 "launch-quiet.py","summarize-quiet.py","archive-r607.py","final-public-win-net11.log",
                 "final-white-win-net11.log","final-focused-wsl-net10.log","local-pair.log"):
        tar.add(lab/name, arcname=name)
    for folder in ("quiet","confirmation"):
        for name in ("config.json","identity.json","remote-launch.py","retrieve.py","observe-not-before.json","launch.log"):
            tar.add(lab/folder/name, arcname=folder+"/"+name)
    for name in ("Program.cs","AdmissionObservation.csproj","reference.json","candidate.json"):
        tar.add(lab/"admission-observation"/name,arcname="admission-observation/"+name)
print("Verified all 240 golden batches, both archive hashes, exact catalog, worker images, joins and disposition.")
