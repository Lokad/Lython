using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var observations = new List<object>();
foreach (var row in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = row.GetProperty("id").GetString();
    if (id is not ("scripts.rule-default-closures" or "scripts.annotated-rule-closures" or
        "scripts.annotated-rule-closure.first-use" or "calls.defaults.medium")) continue;
    using var script = new LythonEngine().Compile(row.GetProperty("source").GetString()!);
    var budget = new CountingBudget();
    var options = new LythonRunOptions { MemoryBudget = budget };
    long peak;
    using (var result = script.Run(new PureHost(), options))
    {
        if (!result.Success || result.StandardOutput != row.GetProperty("expectedOutput").GetString())
            throw new InvalidOperationException("Execution disagreed with its golden");
        peak = budget.Root.ReservedBytes;
    }
    if (budget.Root.ReservedBytes != 0) throw new InvalidOperationException("Budget did not balance");
    observations.Add(new { id, budget.PositiveReservations, budget.PositiveResizes, bytesBeforeResultDisposal = peak });
}
Console.WriteLine(JsonSerializer.Serialize(observations));

sealed class CountingBudget : ILythonMemoryBudget
{
    public readonly LythonMemoryBudget Root = new(128 * 1024 * 1024);
    public int PositiveReservations;
    public int PositiveResizes;
    public ILythonMemoryScope CreateScope() => new Scope(this, Root.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Reserve(Root, bytes, out reservation);

    private bool Reserve(ILythonMemoryBudget owner, long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        reservation = null;
        if (!owner.TryReserve(bytes, out var inner)) return false;
        if (bytes > 0) Interlocked.Increment(ref PositiveReservations);
        reservation = new Reservation(this, inner);
        return true;
    }

    private sealed class Scope(CountingBudget root, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(root, inner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => root.Reserve(inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(CountingBudget root, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var growth = bytes > inner.Bytes;
            if (!inner.TryResize(bytes)) return false;
            if (growth) Interlocked.Increment(ref root.PositiveResizes);
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}

sealed class PureHost : ILythonHost, ILythonSynchronousHostCapability
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public bool CompletesSynchronously => true;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
