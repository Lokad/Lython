from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
filter='Category!=Stress&(FullyQualifiedName~Annotation|FullyQualifiedName~Match|FullyQualifiedName~Import|FullyQualifiedName~Locals|FullyQualifiedName~BoundLoopName|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~ContextManager)'
for framework in ['net11.0','net10.0']:
 log=r/('supplement-'+framework+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as output:
  done=subprocess.run([str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter',filter],env=env,stdout=output,stderr=subprocess.STDOUT)
 print('\n'.join(log.read_text(encoding='utf-8').splitlines()[-8:]),flush=True)
 if done.returncode:sys.exit(done.returncode)
