from pathlib import Path
import tarfile,subprocess
r=Path(__file__).parent;p=r/'prepare-vm.py';s=p.read_text(encoding='utf-8')
with tarfile.open(r/'initial-four-job-preparation.tar.xz','w:xz')as t:
 t.add(p,arcname='prepare-vm.py')
 for name in ['collect.py','config.json','launch.py','remote-launch.py']:t.add(r/'b638'/name,arcname='b638/'+name)
s=s.replace("out.mkdir()","out.mkdir(exist_ok=True)")
s=s.replace("['scripts.csv-validated-records.large','warm'],","['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],")
s=s.replace('len(jobs)==4','len(jobs)==5').replace('==4 ','==5 ').replace('jobs=4','jobs=5')
s=s.replace('ownerSeconds=300','ownerSeconds=360').replace('RuntimeMaxSec=300','RuntimeMaxSec=360').replace('timedelta(seconds=360)','timedelta(seconds=420)')
s=s.replace("['elapsedSeconds']<360","['elapsedSeconds']<420").replace('B638 four-job','B638 five-job').replace("< 260, 'Reserve40seconds","< 310, 'Reserve50seconds")
s=s.replace('Four jobs,300s owner','Five jobs,360s owner')
p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8',str(p)],check=True)
