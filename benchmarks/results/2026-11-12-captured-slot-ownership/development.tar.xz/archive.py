from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
decision=dict(retained=True,reason='One authoritative captured binding removes sparse arrays, backpointers and synchronization; controlled capturedRun improves with supporting CPU. Accept small CSVAsync elapsed debt; async captured/report remain uncertain.',fullyQualified=False,core=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))['coreSHA256'],publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
out=Path('benchmarks/results/2026-11-12-captured-slot-ownership');out.mkdir(exist_ok=True)
for name in ['candidate-identity.json','source-gate.md','decision.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'development.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in('.py','.log','.json','.patch','.md','.txt')or p.name=='initial-four-job-preparation.tar.xz':t.add(p,arcname=p.name)
 t.add(r/'initial',arcname='initial')
 for phase in ['warm-sync','warm-async','compile','fresh']:t.add(r/phase,arcname=phase)
 for name in ['Program.cs','complete-jobs.csproj','packages.lock.json']:t.add(r/'tool'/name,arcname='tool/'+name)
for name in ['b638','b639']:
 target=out/name;target.mkdir(exist_ok=True)
 for filename in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','inventory.json','extraction.json']:shutil.copyfile(r/name/filename,target/filename)
 with tarfile.open(target/'preparation.tar.xz','w:xz')as t:
  for filename in ['collect.py','archive-owned.py','remote-launch.py','launch.py','launch-command.py','launch.log','retrieve.py','summarize.py','config.json','observe-not-before.json']:t.add(r/name/filename,arcname=filename)
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.rglob('*')if p.is_file()and p.name not in('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Retained source, original failed checks, diagnostic adversity and both controlled comparisons archived.')
