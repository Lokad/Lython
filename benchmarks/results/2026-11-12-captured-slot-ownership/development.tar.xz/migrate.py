from pathlib import Path
root=Path('src/Lokad.Lython/Runtime')
def edit(name,operation):
 p=root/name;s=p.read_text(encoding='utf-8');n=operation(s);assert s!=n,name;p.write_text(n,encoding='utf-8',newline='\n')
def replace(s,old,new):
 assert old in s,old
 return s.replace(old,new)
def main(s):
 s=replace(s,'        private readonly int _ownerSlot;\n','')
 s=replace(s,'string? name = null, int ownerSlot = -1)','string? name = null)')
 s=replace(s,'            _ownerSlot = ownerSlot;\n','')
 start=s.index('                // Only an active owner may expose its operand cache:')
 end=s.index('                if (_owner is { MirrorsExecutableLocals:',start)
 s=s[:start]+s[end:]
 s=replace(s,'        internal ExecutableCell?[]? LocalCells;\n','')
 s=replace(s,'            LocalCells = null;\n','')
 s=replace(s,'            _execution.LocalCells = null;\n','')
 s=replace(s,'_execution.LocalCells?[slot] is { } cell ? cell.Value : _execution.Locals[slot]','ReadLocalValue(_execution.Locals, slot)')
 s=replace(s,'var local = _execution.Locals[localSlot];','var local = ReadLocalValue(_execution.Locals, localSlot);')
 s=replace(s,'var value = _execution.Locals[pair.Value];','var value = ReadLocalValue(_execution.Locals, pair.Value);')
 s=replace(s,'if (_execution.LocalCells is not null && _execution.Code.LocalNameToSlot.TryGetValue(name, out var localSlot))','if (_execution.Code.LocalNameToSlot.TryGetValue(name, out var localSlot))')
 s=replace(s,'_execution.LocalCells[localSlot] is ExecutableCell localCell','_execution.Locals[localSlot] is ExecutableCell localCell')
 s=replace(s,'                if (_execution.LocalCells?[localSlot] is ExecutableCell localCell) localCell.Value = value;\n                else _execution.Locals[localSlot] = value;','                WriteLocalValue(_execution.Locals, localSlot, value);')
 start=s.index('                var removed = _execution.Locals[localSlot] is not null;')
 end=s.index('                return removed;',start)
 s=s[:start]+'''                var removed = ReadLocalValue(_execution.Locals, localSlot) is not null;
                WriteLocalValue(_execution.Locals, localSlot, null);

'''+s[end:]
 s=replace(s,'bytes = checked(bytes + EstimateObjectArrayBytes(codeObject.LocalNames.Count)\n                + 48L * codeObject.CapturedLocalSlots.Count);','bytes = checked(bytes + 48L * codeObject.CapturedLocalSlots.Count);')
 start=s.index('            var needsLocalCells = codeObject.CapturedLocalSlots.Count != 0;')
 end=s.index('            return new ExecutableWorkState',start)
 s=s[:start]+'''            var argumentValues = boundArguments.Values ?? Array.Empty<object>();
            for (var i = 0; !argumentsAreLocals && i < boundArguments.Assigned.Length; i++)
                locals[i] = argumentValues[i];
            // A captured slot holds its cell, never a second cached value. The
            // frame array and escaped closures borrow this same identity.
            for (var i = 0; i < codeObject.CapturedLocalSlots.Count; i++)
            {
                var slot = codeObject.CapturedLocalSlots[i];
                locals[slot] = new ExecutableCell(locals[slot], context, codeObject.LocalNames[slot]);
            }

'''+s[end:]
 s=replace(s,'                LocalCells = localCells,\n','')
 return s
edit('LythonRuntime.Executable.cs',main)
def binding(s):
 s=replace(s,'        var value = locals[slot];','        var value = ReadLocalValue(locals, slot);')
 # One local convention serves bytecode, namespace and fallback consumers.
 marker='    private static object LoadLocal('
 pos=s.index(marker)
 s=s[:pos]+'''    private static object? ReadLocalValue(object[] locals, int slot)
    {
        var value = locals[slot];
        return value is ExecutableCell cell ? cell.Value : value;
    }

    private static void WriteLocalValue(object[] locals, int slot, object? value)
    {
        if (locals[slot] is ExecutableCell cell) cell.Value = value;
        else locals[slot] = value!;
    }

'''+s[pos:]
 s=replace(s,'object[] locals, IReadOnlyList<ExecutableCell?>? localCells, Span<object> storage)','object[] locals, Span<object> storage)')
 s=replace(s,'                locals[slot] = value;\n                if (localCells?[slot] is ExecutableCell localCell) localCell.Value = value;','                WriteLocalValue(locals, slot, value);')
 s=replace(s,'        ExecutableCell?[]? localCells,\n','')
 s=s.replace('locals, localCells,','locals,')
 start=s.index('            if (!context.Variables.TryGetValue(codeObject.LocalNames[i], out var value))')
 end=s.index('\n        }\n    }',start)
 s=s[:start]+'''            context.Variables.TryGetValue(codeObject.LocalNames[i], out var value);
            WriteLocalValue(locals, i, value);
'''+s[end:]
 s=replace(s,'        locals[slot] = value;\n        if (localCells?[slot] is ExecutableCell localCell)\n        {\n            localCell.Value = value;\n        }','        WriteLocalValue(locals, slot, value);')
 return s
edit('LythonRuntime.Executable.Binding.cs',binding)
def interpreter(s):
 s=replace(s,'            _execution.Locals[_execution.Code.LocalNameToSlot[".0"]] = iterator;','            WriteLocalValue(_execution.Locals, _execution.Code.LocalNameToSlot[".0"], iterator);')
 start=s.index('            else\n                for (var index = 0; index < _execution.Code.CapturedLocalSlots.Count; index++)')
 end=s.index('            HasYield = false;',start)
 s=s[:start]+s[end:]
 s=replace(s,'            // while this generator is suspended. Other frames need only their\n            // captured cells, which can be written through escaped closures.','            // while this generator is suspended. Captured slots already hold\n            // the authoritative cells written through escaped closures.')
 s=replace(s,'            ExecutableCell?[]? localCells,\n','')
 s=replace(s,'if (localCells?[slot] is ExecutableCell localCell)','if (locals[slot] is ExecutableCell localCell)')
 s=replace(s,'// The cell owns both its local cache and namespace policy.','// The cell owns this binding and its namespace policy.')
 old='''            var value = execution.Stack.Values[source];
            if (source < execution.Code.FirstTemporarySlot && value is null)
                return LoadLocal(execution.Code, execution.Locals, source,
                    execution.Code.OperandReadSpan(execution.InstructionIndex, input), scope);
            return value.RequireNotNull();'''
 new='''            var value = source < execution.Code.FirstTemporarySlot
                ? ReadLocalValue(execution.Locals, source) : execution.Stack.Values[source];
            if (value is null && source < execution.Code.FirstTemporarySlot)
                return LoadLocal(execution.Code, execution.Locals, source,
                    execution.Code.OperandReadSpan(execution.InstructionIndex, input), scope);
            return value.RequireNotNull();'''
 s=replace(s,old,new)
 return s
edit('LythonRuntime.Executable.Interpreter.cs',interpreter)
# Remove sparse-array transport after all policies have one local representation.
for p in root.glob('LythonRuntime.Executable*.cs'):
 s=p.read_text(encoding='utf-8');n=s.replace('_execution.Locals, _execution.LocalCells,','_execution.Locals,').replace('execution.Locals, execution.LocalCells,','execution.Locals,').replace('                        execution.LocalCells,\n','').replace('                            _execution.LocalCells,\n','')
 if p.name=='LythonRuntime.Executable.DictionaryAccumulation.cs':
  n=replace(n,'privateBindings && execution.LocalCells?[store.ThirdInput] is null','privateBindings')
 if n!=s:p.write_text(n,encoding='utf-8',newline='\n')
print('Captured slots migrated; inspect remaining direct accesses and test fixtures before build.')
