from pathlib import Path
import json,hashlib
r=Path(__file__).parent
old=r/'initial-namespace-failure.patch';new=r/'namespace-corrected.patch'
if old.exists():
 assert old.resolve().is_relative_to(r.resolve()) and new.resolve().is_relative_to(r.resolve()) and not new.exists()
 old.rename(new)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
with (r/'source-gate.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''
## Implemented source checkpoint

Seven production files now use authoritative cells in the local array. Two
existing white-box fixtures build that storage directly; all independent refusal,
funding, retention and value assertions survive. The namespace retention handover
must seed cells before setting MirrorLocalStores. Initial actual11 checks pass1055
internal but fail three public generic-function cases; original logs survive under
initial/. The correction removes the old cache-dependent handover. migrate.py
reproduces the initial source; namespace-corrected.patch describes the corrected
source, not a frozen first-form binary. Do not relabel the initial failures.

Corrected nonincremental build succeeds. Focused1055internal/2674public per actual
11/10 pass (7458 executions). A second, overlapping public annotation/match/import/
locals/context-manager filter passes3683per target; these are not additional unique
test counts. Cancellation/refusal/actual pending cleanup checks remain unchanged.
All seven existing scripts pass both APIs, compilation and fresh execution; every
golden, shared balance and joined fixture check passes. Compile allocation flat;
whole warm allocations effectively flat (-0.00..-0.04%, not a substantial reduction).
The sparse array removal is per captured frame, not per native helper invocation.

Desktop capturedRun elapsed-5..-9%/Async-13..-14% is diagnostic. CSVRun+1.8..2.5%
and Async+3.9..4.1% with stable local controls are adverse; retain them. Fresh captured
+4..26%/17%control and freshCSV123%control remain uncertain. No source-independent
compiler CPU change or causal JIT explanation follows. Initial four-job VM
preparation is preserved; before launch it expands to five to include the actual
CSVAsync adversity. Same source, not retiming. B638 has360sowner/30sstop/30smargin.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
needle='   retention/regression-debt decision; full delivery only after retention.\n'
assert needle in s
s=s.replace(needle,needle+'''   Current prototype: seven production files migrated; initial three generic
   failures corrected by seeding namespaces before mirroring.7458focused actual-
   target checks pass; overlapping supplemental3683public per target pass. Seven
   scripts/both APIs/compile/fresh pass; whole allocation effectively flat. Desktop
   captured timing favorable, CSV adverse; B638five-job confirmation is active.
   Production remains qualified only throughb3369e3e until new delivery completes.
''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Development status and original failures recorded without CPU/qualification promotion.')
