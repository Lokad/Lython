from pathlib import Path
import shutil
r=Path(__file__).parent;d=r/'delivery';d.mkdir(exist_ok=True)
old=r.parent/'json-existing-windows-r279/delivery'
shutil.copyfile(old/'observe.py',d/'observe.py')
code=(old/'archive.py').read_text(encoding='utf-8').replace('2026-11-12-json-existing-windows/delivery','2026-11-12-captured-slot-ownership/delivery').replace('R279 terminal qualification/source proof/logs archived; current R280 prototype not relabelled as qualified.','R281 terminal qualification/source proof/logs archived; all measured sources identified separately.')
(d/'archive.py').write_text(code,encoding='utf-8',newline='\n')
print('Delivery observers prepared; no CI dispatch or new qualification claim.')
