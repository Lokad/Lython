from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'json-existing-windows-r279'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
source={p:digest(Path(p))for p in baseline['sources']}
changed=[p for p in source if Path(p).read_bytes().replace(b'\r\n',b'\n')!=subprocess.check_output(['git','show','HEAD:'+p]).replace(b'\r\n',b'\n')]
assert len(source)==568 and len(changed)==7,changed
assert all('LythonRuntime.Executable' in p for p in changed)
for name in ['reference','candidate']:
 assert not(r/name).exists();shutil.copytree(old/'candidate',r/name,copy_function=os.link)
assert digest(r/'reference/Lokad.Lython.dll')=='4f57ca332a6d83b36427a37934e1d2f112089d089ad0e9aee86d4cd5ce9af941'
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
for name,folder in [('before-core.dll','reference'),('candidate-core.dll','candidate')]:shutil.copyfile(r/folder/'Lokad.Lython.dll',r/name)
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in source:t.add(p,arcname=p)
(r/'candidate-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+' plus R281 uncommitted',sources=source,coreSHA256=digest(r/'candidate-core.dll'),referenceSHA256=digest(r/'before-core.dll'),changed=changed),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json')
tool=r/'tool';tool.mkdir()
for name in ['complete-jobs.csproj','packages.lock.json']:shutil.copyfile(old/'tool'/name,tool/name)
code=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R279 JSON tokens reuse existing immutable UTF8 windows; only same-owner plain tokens share;', 'R281 authoritative captured local slots; sparse cell arrays, cache propagation and generator cell synchronization removed;')
(tool/'Program.cs').write_text(code,encoding='utf-8',newline='\n')
env=os.environ.copy();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(r/'build-driver.log').open('w',encoding='utf-8',newline='\n')as log:
 done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(tool/'complete-jobs.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build-driver.log').read_text(encoding='utf-8')
assert all(digest(Path(p))==h for p,h in source.items())
for name in ['diagnostic.py','run-diagnostics.py','summarize.py']:
 shutil.copyfile(r.parent/'native-boundaries-r280'/name,r/name)
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.Tests']))
print(json.dumps(dict(sources=len(source),changed=changed,core=digest(r/'candidate-core.dll'),driverBuilt=True)),flush=True)
subprocess.run(['python','-X','utf8',str(r/'run-diagnostics.py')],check=True)
