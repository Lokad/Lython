from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r/'b638';out=r/'b639';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/captured-slots-b638-20261112'
root='/home/lokad/lython-bench-checks/captured-slots-b639-20261112';oldunit='lython-b638-captured-slots-20261112';unit='lython-b639-captured-slots-confirmation-20261112'
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit)
config['identity']['sourceRevision']+='; same-source B638 report/CSVAsync adversity confirmation;12s warmups'
jobs=[['scripts.csv-validated-records.large','warm-async'],['scripts.report-render.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R281 single authoritative captured-slot representation; sparse cell array/cache synchronization removed; captured both APIs and general local-load controls; preserve all adversity.'","purpose='R281 same-source report/CSVAsync debt confirmation with12s warmups; original B638 adverse/control conditions retained; no native body changes.'")
collect=collect.replace("< 310, 'Reserve50seconds for final owned work/cleanup.'","< 145, 'Reserve35seconds for final owned work/cleanup.'")
collect=collect.replace('warmupSeconds=5, affectedWarmupSeconds=8, capturedWarmupSeconds=12','warmupSeconds=12, affectedWarmupSeconds=12, capturedWarmupSeconds=12')
start=collect.index('count=1; end=time.monotonic()+(');end=collect.index('; rows=[]',start)
collect=collect[:start]+'count=1; end=time.monotonic()+12'+collect[end:]
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
 text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
 if name=='archive-owned.py':text=text.replace('==5 ','==2 ').replace('jobs=5','jobs=2')
 if name=='remote-launch.py':text=text.replace('lython-b638-fixtures','lython-b639-fixtures').replace('jobs=5,ownerSeconds=360','jobs=2,ownerSeconds=180').replace('RuntimeMaxSec=360','RuntimeMaxSec=180')
 if name=='launch.py':text=text.replace('captured-slots-b638-launch.py','captured-slots-b639-launch.py').replace('timedelta(seconds=420)','timedelta(seconds=240)').replace('ownerSeconds=360','ownerSeconds=180')
 if name=='retrieve.py':text=text.replace("['jobs']==5","['jobs']==2").replace("['elapsedSeconds']<420","['elapsedSeconds']<240").replace('B638 five-job','B639 two-job')
 if name=='summarize.py':text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2')
 if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
 (out/name).write_text(text,encoding='utf-8',newline='\n')
for name in ['current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json']:shutil.copyfile(old/name,out/name)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Two same-source affected/control jobs;12s warmups;180s owner/30s stop/30s margin.')
