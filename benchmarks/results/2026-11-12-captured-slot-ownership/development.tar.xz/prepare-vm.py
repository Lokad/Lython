from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'native-boundaries-r280/b637';out=r/'b638';out.mkdir(exist_ok=True)
oldroot='/home/lokad/lython-bench-checks/native-boundaries-b637-20261112'
root='/home/lokad/lython-bench-checks/captured-slots-b638-20261112';unit='lython-b638-captured-slots-20261112';oldunit='lython-b637-native-kernel-boundary-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit,retire=[])
config['identity'].update(sourceRevision=identity['head']+'; R281 authoritative captured slots;7458focused actual-target checks; desktop phases separate',coreSHA256={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],['scripts.report-render.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R280 kernel-only refinement: loop publication checks restored; original capturedRun/report adversity preserved; no source-independent retiming.'","purpose='R281 single authoritative captured-slot representation; sparse cell array/cache synchronization removed; captured both APIs and general local-load controls; preserve all adversity.'")
collect=collect.replace("< 145, 'Reserve35seconds for final owned work/cleanup.'","< 310, 'Reserve50seconds for final owned work/cleanup.'")
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
 text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
 if name=='archive-owned.py':text=text.replace('==2 ','==5 ').replace('jobs=2','jobs=5')
 if name=='remote-launch.py':text=text.replace('lython-b637-fixtures','lython-b638-fixtures').replace('jobs=2,ownerSeconds=180','jobs=5,ownerSeconds=360').replace('RuntimeMaxSec=180','RuntimeMaxSec=360')
 if name=='launch.py':text=text.replace('native-boundaries-b637-launch.py','captured-slots-b638-launch.py').replace('timedelta(seconds=240)','timedelta(seconds=420)').replace('ownerSeconds=180','ownerSeconds=360')
 if name=='retrieve.py':text=text.replace("['jobs']==2","['jobs']==4").replace("['elapsedSeconds']<240","['elapsedSeconds']<420").replace('B637 two-job','B638 five-job')
 if name=='summarize.py':text=text.replace("len(raw['jobs'])==2","len(raw['jobs'])==4").replace('jobs=2','jobs=5')
 if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
 (out/name).write_text(text,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Five jobs,360s owner,30s stop,30s margin; unchanged protocol/runtime/quiet/ownership gates.')
