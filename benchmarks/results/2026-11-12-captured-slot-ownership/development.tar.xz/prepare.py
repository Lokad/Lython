from pathlib import Path
import subprocess
r=Path(__file__).parent
(r/'base.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True),encoding='utf-8',newline='\n')
(r/'source-gate.md').write_text('''# R281: authoritative captured slots

Qualified production is b3369e3e, documentation98585baa. R280 is withdrawn.
Source demonstrates duplicate cell/local storage, not another frame/argument
array: ExecutableCell.Value writes its defining frame's LocalCells-indexed cache;
generator resume resynchronizes it. Ordinary variable resolution, enumeration,
binding, pattern/import/fallback writes also carry the sparse cell array.

Represent captured slots by their existing cell object in the already-owned local/
operand array. All guest reads unwrap it; all writes update that one cell. Remove
the sparse LocalCells array, owner-slot backpointer, active-frame cache propagation,
generator cell-to-slot synchronization and duplicate method parameters. Keep live
namespace mirroring, incoming closure identities, unbound diagnostics and actual
generator storage. This is neither raw-long cell storage nor the slower R268
prefix/R272 segment/R280 check-removal design. No new backend/cache/opcode/policy.

Captured-text and closure-heavy scripts are affected. Existing R272 native guard/
evaluation and instruction samples establish recurring execution but do not isolate
the setter's CPU or predict savings. Guaranteed outcome sought is one authoritative
storage location and one fewer per-captured-frame array; CPU remains a hypothesis.
Uncaptured loads acquire an internal-cell type test, a potential general-path debt.
Native dictionary loops prove relevant slots uncaptured and retain their raw access.

Acceptance: exact aliases and live updates through defining/sibling functions,
generators, class/annotation fallback, namespace mirroring, match/import/handler
deletion, real protocol suspension, terminal refusal, cancellation, retained users
and shared-budget reuse. Borrowed argument arrays remain alive and are cleared only
after frame users end. Captured cells keep their existing retained owner/funding.
Remove obsolete internal representation assertions, preserve semantic tests.

Complete migration then focused Release actual11/10 and seven unchanged scripts/
both APIs/compile/fresh. One bounded captured-text/general-load-control comparison
will decide retention/debt; refine only for a demonstrated semantic/cost issue.
No automatic wider tagged-value/closure/compiler project or unchanged profile replay.
If retained, batch full platforms/stress/installed consumers at delivery. Publication
held; missing regex producer capabilities block only affected final qualification.
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');start=s.index('1. **Whole-script redesign selection:');end=s.index('2. **Independent regex',start)
s=s[:start]+'''1. **R281 — one authoritative captured-slot representation.** Replace duplicate
   cell values/executable caches with existing cells stored in captured local slots.
   Delete LocalCells sparse arrays/parameters, owner-slot backpointers, active-frame
   cache writes and generator cell-to-slot resume loops. Keep namespace mirroring,
   live closure identities, generator lifetimes and Python unbound diagnostics.
   Affected: captured-text, closures/helpers/generators. This removes real storage
   and synchronization; CPU benefit remains a hypothesis, with a possible type-test
   cost for ordinary local loads. No raw-long/tagged-value or new execution route.
   Validate aliases, match/import/handler/fallback writes, actual suspension,
   cancellation, first refusal, retained results and budget reuse; then seven
   unchanged complete scripts/both APIs/compile/fresh plus one bounded affected/
   ordinary-load-control comparison. Finish with mechanism deletion and an explicit
   retention/regression-debt decision; full delivery only after retention.

2. **Following redesign gates.** Use existing profiles and whole-script gaps to
   select an actual recurring stage to remove. Locals/operands and span binding
   already share storage; record adoption/shared keys, prepared word ranges,
   formatting plans, immutable reader/JSON windows and bulk UTF16 already ship.
   Do not replay slower call arenas, linear native proof, ordered prefixes or
   segment forms unchanged. For each selected milestone name eliminated work,
   displaced implementation, semantic/ownership acceptance and affected/control
   comparison before implementation. A materially different design remains open.
   Config compile is near CPython; no dominant duplicate frontend pass is proven.
   Keep frontend consolidation behind that evidence gate rather than expanding it.

'''+s[end:];s=s.replace('2. **Independent regex','3. **Independent regex');p.write_text(s,encoding='utf-8',newline='\n')
print('Source gate and explicit deletion/acceptance milestone recorded before implementation.')
