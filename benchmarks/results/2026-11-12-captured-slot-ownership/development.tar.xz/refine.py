from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent
initial=r/'initial';initial.mkdir()
for p in r.glob('*.log'):shutil.move(str(p),str(initial/p.name))
(r/'initial-namespace-failure.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
print('Original three generic-function failures preserved; rerun includes namespace seed correction.')
subprocess.run(['python','-X','utf8',str(r/'check.py')],check=True)
