from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
state=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))
assert state['status']=='completed'and state['conclusion']=='success'
proof=json.loads((r/'source-proof.json').read_text(encoding='utf-8'));assert proof['head']==state['headSha']and proof['sourceCount']==568 and proof['allMatchWithExplicitNewlineNormalization']
run=json.loads((r/'dispatch.json').read_text(encoding='utf-8'))['run']
if not(r/'ci-full.log').exists():
    done=subprocess.run(['gh','run','view',str(run),'--log'],capture_output=True);assert done.returncode==0,done.stderr.decode('utf-8',errors='replace');(r/'ci-full.log').write_bytes(done.stdout)
out=Path('benchmarks/results/2026-11-12-captured-slot-ownership/delivery');out.mkdir(exist_ok=True)
for name in ['terminal-status.json','source-proof.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'logs.tar.xz','w:xz')as t:
    for name in ['ci-full.log','dispatch.log','dispatch.json','observe.py','archive.py']:t.add(r/name,arcname=name)
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print('R281 terminal qualification/source proof/logs archived; all measured sources identified separately.')
