from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).parent
if(r/'terminal-status.json').exists():print('Terminal cached; no query.');raise SystemExit(0)
d=json.loads((r/'dispatch.json').read_text(encoding='utf-8'));now=datetime.datetime.now(datetime.timezone.utc)
assert now>=datetime.datetime.fromisoformat(d['doNotQueryBeforeUTC'])
done=subprocess.run(['gh','run','view',str(d['run']),'--json','status,conclusion,headSha,jobs,url'],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
data=json.loads(done.stdout);assert data['headSha']==d['head']
(r/('observation-'+now.strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(done.stdout,encoding='utf-8',newline='\n')
d.update(lastObservationUTC=now.isoformat(),doNotQueryBeforeUTC=(now+datetime.timedelta(minutes=5)).isoformat())
(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
if data['status']=='completed':(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8',newline='\n')
print(json.dumps(dict(status=data['status'],conclusion=data['conclusion'],jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'],current=[s['name']for s in j['steps']if s['status']=='in_progress'])for j in data['jobs']])),flush=True)
