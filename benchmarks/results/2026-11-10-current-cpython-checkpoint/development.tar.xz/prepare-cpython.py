from pathlib import Path
import hashlib,json,shutil,tarfile
home=Path(__file__).parent;old=home.parent/'cpython-checkpoint-r169';dest=home/'b525';dest.mkdir()
def adapt(s):return s.replace('cpython-checkpoint-b517-20261109','cpython-checkpoint-b525-20261110').replace('lython-b517-cpython-checkpoint-20261109','lython-b525-cpython-checkpoint-20261110').replace('lython-b517-fixtures','lython-b525-fixtures').replace('B517','B525')
current=json.loads((home/'b522/identity.json').read_text());identity=json.loads((old/'identity.json').read_text())
identity['coreSHA256']={role:current['coreSHA256']['candidate']for role in ['candidate','candidate-control']}
identity['auxiliaryFiles']=current['auxiliaryFiles']
identity['sourceRevision']='ee448715: qualified R173 production plus R178 terminal JSON storage and R179 caller-handler closed-native admission. Full platform delivery running separately; frozen source/binary explicit.'
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    (dest/name).write_text(adapt((old/name).read_text()),newline='\n')
for name in ['setup-contract.json','sizing.json']:shutil.copyfile(old/name,dest/name)
shutil.copyfile(home/'source.patch',dest/'source.patch')
shutil.copyfile('docs/BENCHMARKS.md',dest/'prior-BENCHMARKS.md')
shutil.copyfile(home/'b522/focused.json',dest/'focused.json')
contract='''R181 representative checkpoint at ee448715 using existing comparison protocol.
Five complete CSV/text/report/search/config scripts, compilation/warm/compile-to-result
separate. Four processes: two candidate and two CPython3.13.16,5srolewarmup,
7rotated150msrounds, ordinary GC/tiering. Includes mediated RAM I/O/full output
validation/prior-result cleanup; excludes startup/reset/protocol/final caches.
ProcessCPU wider. Keep adverse/inconclusive results; no universal speedup claim.
Reuse frozen B522 candidate/core/auxiliaries and exact B517 catalog. Full source
identity recorded, adapter unchanged. Owner540s/stop30s/margin30s, owned joins,
unmount/archive/localSHA. No quota, forcedGC or abandoned background work.
'''
for name in ['contract.md','pre-measurement-plan.md','selection.md']:(dest/name).write_text(contract)
assert b'\r'not in(dest/'run.sh').read_bytes()
with tarfile.open(dest/'payload.tgz','w:gz')as t:
    for p in sorted(dest.iterdir()):
        if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
payload=(dest/'payload.tgz').read_bytes()
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),frozenCoreAndCatalogReused=True),indent=2)+'\n')
script=adapt((old/'launch-command.py').read_text())
script=script.replace("reference=base/'native-construction-b516-20261109/candidate'","reference=base/'handler-native-entry-b522-20261110/candidate'")
script=script.replace("os.link(reference.parent/'representative.json',root/'representative.json')","os.link(base/'cpython-checkpoint-b517-20261109/representative.json',root/'representative.json')")
script='\n'.join(' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())if line.startswith(' payload=')else line for line in script.splitlines())+'\n'
(dest/'launch-command.py').write_text(script,newline='\n')
launch=adapt((old/'launch.py').read_text());start=launch.index("remote=r'''");end=launch.index("ssh=[",start)
launch=launch[:start]+"remote=(r/'launch-command.py').read_text()\n"+launch[end:]
(dest/'launch.py').write_text(launch)
print('Existing15job CPython checkpoint prepared; required free',required,'small payload',len(payload),'bytes; no new binaries.')
