from pathlib import Path
import json,os,re,subprocess,sys
root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
for framework in ['net11.0','net10.0']:
    log=root/('delivery-pinned-'+framework+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8') as output:
        r=subprocess.run([env['DOTNET_HOST_PATH'],'test','Lokad.Lython.slnx','-c','Release','-f',framework,'--no-build','--no-restore','--nologo','--tl:off'],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8');print(framework,r.returncode,text[-2000:],flush=True)
    checks[framework]={'exitCode':r.returncode,'summaries':re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',text)}
    (root/'delivery-local.json').write_text(json.dumps(dict(checks=checks,environment=dict(DOTNET_ROOT=env['DOTNET_ROOT'],DOTNET_HOST_PATH=env['DOTNET_HOST_PATH']),
        initialFailure='Original net11 run used an unpinned child launcher path:33 subprocess cases failed while16162public cases passed. Original log preserved. Corrected SDK environment, no test/timeout relaxation.',
        stress='Original scales deferred to combined Windows/Ubuntu workflow dispatch checkpoint',package='Awaiting explicit Release pack/installed consumers after source commit'),indent=2)+'\n',encoding='utf-8')
    if r.returncode:sys.exit(r.returncode)
