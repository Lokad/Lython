from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lokad/lython-bench-checks/regex-capture-b355-20261106');base=Path('/home/lokad/lython-bench-checks/delivery-comparison-b352-20261106/candidate')
for label in ['candidate','reference']:
    folder=root/label;folder.mkdir()
    for f in base.iterdir():
        if f.name=='Lokad.Lython.pdb':continue
        if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:
            os.link(f,folder/f.name)
        else:
            source=(root/f.name if label=='candidate' else base/f.name) if f.name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll'] else f
            (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
i=json.loads((root/'identity.json').read_text())
for label in ['candidate','control','reference']:
    folder=root/('candidate' if label=='control' else label)
    assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
    for name,digest in i['auxiliaryFiles'].items():
        if label!='reference' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
        assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
assert shutil.disk_usage(root).free>6*1024*1024
print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,coreSHA256=i['coreSHA256'])))
