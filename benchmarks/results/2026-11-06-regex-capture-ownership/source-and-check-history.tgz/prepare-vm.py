from pathlib import Path
import base64,hashlib,json,shutil,subprocess,tarfile,tempfile
home=Path(__file__).resolve().parent;root=home/'b355';root.mkdir(exist_ok=True)
old=home.parent/'shared-targets-r18/b354'
remote='/home/lokad/lython-bench-checks/regex-capture-b355-20261106'
oldremote='/home/lokad/lython-bench-checks/shared-targets-b354-20261106'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
def write(n,s):
    with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
source=r'''import re
with open('input.txt', encoding='utf-8') as source:
    text = source.read()
pattern = re.compile(r'(?m)^(?P<name>[^\t\r\n]+)\t(?P<count>[0-9]+)\t(?P<state>ready|held)(?P<empty>)$')
rows = 0
total = 0
positions = 0
for match in pattern.finditer(text):
    rows += 1
    if match.group('state') == 'ready':
        total += int(match.group('count'))
    positions += match.end()
print(rows, total, positions)
'''
text='';total=positions=offset=0
for i in range(1024):
    ready=i%3!=0;value=i%97
    line=f"café😀-{i}\t{value}\t{'ready' if ready else 'held'}\n"
    text+=line;offset+=len(line);positions+=offset-1
    if ready:total+=value
expected=f'1024 {total} {positions}\n'
fixture=json.dumps(dict(text=None,inputFiles={'input.txt':base64.b64encode(text.encode('utf-8')).decode()},outputFiles={}),separators=(',',':'),ensure_ascii=True)
with tempfile.TemporaryDirectory(prefix='lython-regex-reference-') as directory:
    Path(directory,'input.txt').write_bytes(text.encode('utf-8'))
    r=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=directory,capture_output=True,text=True,encoding='utf-8')
    assert r.returncode==0 and not r.stderr and r.stdout==expected,(r.stdout,r.stderr,expected)
write('reference.json',json.dumps(dict(runtime='CPython3.13',stdout=r.stdout,expected=expected,inputBytes=len(text.encode('utf-8')),inputScalars=len(text),source=source),indent=2)+'\n')
case=dict(id='scripts.regex-capture-summary.large',family='scripts.regex-capture-summary',category='regex',scale='large',size=1024,
    source=source,fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected),
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(expected),
    expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest())
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'))
control=next(c for c in catalog['cases'] if c['id']=='scripts.text-summary-helpers.large')
catalog['cases']=[case,control];write('representative.json',json.dumps(catalog,separators=(',',':'),ensure_ascii=True)+'\n')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
adapter=Path('src/Lokad.Lython.Utf8Regex/bin/Release/net11.0/Lokad.Lython.Utf8Regex.dll')
identity['sourceRevision']='ffa17260 plus U04 caller-owned capture buffers and lazy retained groups'
identity['coreSHA256'].update(candidate=sha(core),control=sha(core))
identity['candidateAdapterSHA256']=sha(adapter)
identity['qualification']={'normalPublicPerRuntime':476,'normalInternalPerRuntime':84,'developmentPublicPerRuntime':482,'developmentInternalPerRuntime':84}
identity['purpose']='One same-producer whole regex script warm/fresh plus unaffected text warm control; intentional provider API break, role-specific adapters'
identity.pop('priorObservation',None)
write('identity.json',json.dumps(identity,indent=2)+'\n')
shutil.copyfile(core,root/'Lokad.Lython.dll');shutil.copyfile(adapter,root/'Lokad.Lython.Utf8Regex.dll')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
write('pre-measurement-plan.md',Path('PLAN.md').read_text(encoding='utf-8'))
for name in ['setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py','launch-stream.py']:
    s=(old/name).read_text(encoding='utf-8').replace(oldremote,remote).replace('b354','b355').replace('shared-targets-20261106','regex-capture-20261106')
    if name=='setup.py':
        s=s.replace("source=(root/'Lokad.Lython.dll' if label=='candidate' else base/'Lokad.Lython.dll') if f.name=='Lokad.Lython.dll' else f",
            "source=(root/f.name if label=='candidate' else base/f.name) if f.name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll'] else f")
        s=s.replace("for name,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest",
            "for name,digest in i['auxiliaryFiles'].items():\n        if label!='reference' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']\n        assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest")
    if name=='collect.py':
        start=s.index('jobs=[');end=s.index('\nenv =',start)
        s=s[:start]+"jobs=[('scripts.regex-capture-summary.large','warm'),('scripts.regex-capture-summary.large','compile-run'),('scripts.text-summary-helpers.large','warm')]\nassert len(jobs)==3\n"+s[end:]
        s=s.replace('< 140','< 110')
        start=s.index("purpose='")+len("purpose='");end=s.index("',",start)
        s=s[:start]+identity['purpose']+s[end:]
        duplicated='    subprocess.run(["python3",str(root/"archive-owned.py")],check=True)'
        assert s.count(duplicated)==2
        a=s.index(duplicated);b=s.index(duplicated,a+len(duplicated));s=s[:b]+s[b+len(duplicated):]
    if name=='archive-owned.py':
        s=s.replace("len(r['jobs'])==4","len(r['jobs'])==3").replace('jobs=4','jobs=3')
        s=s.replace("'source-snapshot.tgz',",'').replace("'focused-results.json',",'')
    if name=='launch-stream.py':s=s.replace('RuntimeMaxSec=180','RuntimeMaxSec=150')
    write(name,s)
write('contract.md','''# U04 bounded complete-script gate
Same unchanged b94 worker/protocol, normal0.4 producer, qualified b665 reference
and current candidate with matching role-specific adapter. Two identical current
roles, CPython reference, normal GC/tiering, quiet VM, five-second warmup and seven
rotated150ms batches. Regex input1024UTF8records, file read, actual capture access,
numeric aggregation/scalar endpoints and complete output checks. Warm excludes
compilation; fresh includes compile/disposal. Actual mediated RAM I/O and prior
result cleanup included, fixture staging/final shutdown excluded. No abandoned
users. Retain all failures/adverse data, archive under lease before owner exits.
One150s owner/110s job-start guard, no10minlanes, exact allocation separate.
''')
write('focused-results.json',json.dumps(identity['qualification'],indent=2)+'\n')
names=['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','identity.json','source.patch','representative.json','focused-results.json',
    'pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py','reference.json']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in names:a.add(root/name,arcname=name)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer=dict(payloadBytes=(root/'payload.tgz').stat().st_size,payloadSHA256=sha(root/'payload.tgz'),expandedBytes=expanded,requiredFreeBeforeStreamedSetup=expanded+6*1024*1024)
write('transfer.json',json.dumps(transfer,indent=2)+'\n');print(transfer)
