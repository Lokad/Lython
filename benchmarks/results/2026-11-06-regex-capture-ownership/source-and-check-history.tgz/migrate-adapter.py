from pathlib import Path
p=Path('src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs');s=p.read_text(encoding='utf-8')
s=s.replace('''public LythonRegexMatch? Match(LythonRegexMatchMode mode, CancellationToken cancellationToken)
        {''','''public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex,
            CancellationToken cancellationToken)
        {
            lastIndex = null;
            if (captures.Length != Pattern.CaptureSlotCount) throw new ArgumentException("Capture buffer length must equal CaptureSlotCount.", nameof(captures));''')
s=s.replace('if (mode != LythonRegexMatchMode.Match) return null;','if (mode != LythonRegexMatchMode.Match) return false;')
s=s.replace('''            return data.Success ? Convert(data, cancellationToken) : null;''','''            if (!data.Success) return false;
            CopyCaptures(data, captures, cancellationToken);
            lastIndex = data.LastIndex;
            return true;''')
s=s.replace('''private LythonRegexMatch Convert(Utf8PythonDetailedMatchData data, CancellationToken token)
        {
            var captures = new LythonRegexCapture?[data.CaptureSlotCount];''','''private static void CopyCaptures(Utf8PythonDetailedMatchData data, Span<LythonRegexCapture?> captures, CancellationToken token)
        {''')
s=s.replace('''                if (!data.TryGetGroup(i, out var group) || !group.Success) continue;
                var start = group.StartOffsetInBytes;''','''                if (!data.TryGetGroup(i, out var group) || !group.Success) { captures[i] = null; continue; }
                var start = group.StartOffsetInBytes;''')
s=s.replace('''            return new(captures, data.LastIndex);
        }''','''        }''')
s=s.replace('''public LythonRegexMatch? Next(CancellationToken token)
            {''','''public bool TryNext(Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
            {
                lastIndex = null;
                if (captures.Length != _subject.Pattern.CaptureSlotCount) throw new ArgumentException("Capture buffer length must equal CaptureSlotCount.", nameof(captures));''')
s=s.replace('if (_cursor is null) return null;','if (_cursor is null) return false;')
s=s.replace('''                        if (next.success) return _subject.Convert(next.match, token);''','''                        if (next.success)
                        {
                            CopyCaptures(next.match, captures, token);
                            lastIndex = next.match.LastIndex;
                            return true;
                        }''')
s=s.replace('Close(); return null;','Close(); return false;')
assert 'LythonRegexMatch?' not in s and 'return new(captures' not in s
p.write_text(s,encoding='utf-8')
