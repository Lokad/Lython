from pathlib import Path
import hashlib,importlib.util,json,subprocess,tarfile
home=Path(__file__).resolve().parent;old=home/'b355';root=home/'b356';root.mkdir()
prior='/home/lokad/lython-bench-checks/regex-capture-b355-20261106'
remote='/home/lokad/lython-bench-checks/regex-capture-b356-20261106'
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'))
case=catalog['cases'][0];fixture=json.loads(case['fixtureJson']);fixture['size']=case['size']
case['fixtureJson']=json.dumps(fixture,separators=(',',':'),ensure_ascii=True)
case['fixtureSha256']=hashlib.sha256(case['fixtureJson'].encode('utf-8')).hexdigest()
(root/'representative.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=True)+'\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('protocol',old/'cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
protocol.load_manifest(str(root/'representative.json'))
for name in ['identity.json','reference.json','source.patch','pre-measurement-plan.md','contract.md','focused-results.json','cpython-worker.py','collect.py','run.sh','archive-owned.py']:
    s=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
with (root/'contract.md').open('a',encoding='utf-8') as f:f.write('\nB355 stopped before Ready/measurement: new fixture omitted size metadata. Preserve all failed conditions; B356 corrects only catalog metadata, same source/images/boundaries/jobs. Local CPython manifest validation passes.\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');old=base/'regex-capture-b355-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (old/'exit-code.txt').read_text().strip()=='1'
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 names=['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','source.patch','contract.md','focused-results.json','started.utc','stopped.utc','exit-code.txt','run.sh']
 with tarfile.open(old/'failed-observations.tgz','w:gz') as a:
  for name in names:a.add(old/name,arcname=name)
 with tarfile.open(old/'failed-observations.tgz') as a:assert not json.loads(a.extractfile('confirmation/confirmation.json').read())['jobs']
 receipt=dict(complete=False,measuredJobs=0,allWorkersJoined=True,guestFixtureDirectories=[],failure='Catalog fixture missing size; worker rejected before Ready',archiveSHA256=hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest(),archivedAndVerifiedUnderLease=True)
 (old/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);assert r.returncode==0,r.stderr
(old/'failed-archive-receipt.json').write_text(r.stdout,encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run([*scp,'lokad@20.166.121.73:'+prior+'/failed-observations.tgz',str(old/'failed-observations.tgz')],capture_output=True,text=True);assert r.returncode==0,r.stderr
assert hashlib.sha256((old/'failed-observations.tgz').read_bytes()).hexdigest()==json.loads((old/'failed-archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.is_file() and p.name!='payload.tgz':a.add(p,arcname=p.name)
payload=(root/'payload.tgz').read_bytes()
launch='''from pathlib import Path
import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
root=Path('REMOTE');old=Path('PRIOR')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(root.parent).free>sum(m.size for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role in ['candidate','reference']:(root/role).symlink_to(old/role,target_is_directory=True)
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert b'\\r' not in (root/'run.sh').read_bytes();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(root).free>6*1024*1024
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b356-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(payload))).replace('PAYLOADHASH',hashlib.sha256(payload).hexdigest())
(root/'launch.py').write_text(launch,encoding='utf-8')
r=subprocess.run([*scp,str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b356-launch.py'],capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b356-launch.py'],input=payload,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print(r.stdout.decode('utf-8')+r.stderr.decode('utf-8'),flush=True)
