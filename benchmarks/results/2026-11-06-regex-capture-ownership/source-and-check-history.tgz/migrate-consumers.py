from pathlib import Path
p=Path('tests/Lokad.Lython.PublicApi.Tests/RegexProviderContractTests.cs');s=p.read_text(encoding='utf-8')
s=s.replace('LythonRegexMatch?>? MatchFactory','FixtureMatch?>? MatchFactory')
marker='        private sealed class Subject(CooperatingProvider'
at=s.index(marker)
s=s[:at]+'''        // Immutable scenario data; provider output itself uses the caller's buffer.
        private sealed record FixtureMatch(LythonRegexCapture?[] Captures, int? LastIndex);

'''+s[at:]
start=s.index('            public LythonRegexMatch? Match(');end=s.index('            public ILythonRegexCursor Find(',start)
s=s[:start]+'''            public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex,
                CancellationToken token)
            {
                provider.Work("match", token);
                lastIndex = null;
                if (provider.MatchFactory is { } factory)
                {
                    var fixture = factory(input, window);
                    if (fixture is null) return false;
                    fixture.Captures.CopyTo(captures);
                    lastIndex = fixture.LastIndex;
                    return true;
                }
                if (provider.Refuse) Reserve(owner, long.MaxValue);
                var text = Encoding.UTF8.GetString(input.Span);
                if (!text.Equals("x", (pattern.Flags & 2) != 0 ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)) return false;
                for (var i = 0; i < captures.Length; i++)
                {
                    if (i == 1) provider.CancelCapture?.Cancel();
                    token.ThrowIfCancellationRequested();
                    captures[i] = new(0, input.Length);
                }
                return true;
            }
'''+s[end:]
s=s.replace('''            public LythonRegexMatch? Next(CancellationToken token)
            { provider.Work("next", token); if (_done) return null; _done = true; return subject.Match(LythonRegexMatchMode.Search, token); }''','''            public bool TryNext(Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
            {
                provider.Work("next", token); lastIndex = null;
                if (_done) return false;
                _done = true;
                return subject.TryMatch(LythonRegexMatchMode.Search, captures, out lastIndex, token);
            }''')
start=s.index('        private sealed class Captures(');end=s.index('        public void Dispose() { _cached?',start);s=s[:start]+s[end:]
s=s.replace('CancellationDuringCaptureProjection','CancellationDuringCaptureFilling')
p.write_text(s,encoding='utf-8')

p=Path('tests/Lokad.Lython.PublicApi.Tests/RegexPatternErrorLifetimeTests.cs');s=p.read_text(encoding='utf-8')
s=s.replace('public LythonRegexMatch? Match(LythonRegexMatchMode mode, CancellationToken token)',
'''public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)''')
s=s.replace('return inner.Match(mode, token);','return inner.TryMatch(mode, captures, out lastIndex, token);')
s=s.replace('public LythonRegexMatch? Next(CancellationToken token)',
'''public bool TryNext(Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)''')
s=s.replace('return inner.Next(token);','return inner.TryNext(captures, out lastIndex, token);');p.write_text(s,encoding='utf-8')

p=Path('tests/Lokad.Lython.WorkerFixture/RegexCancellationFixture.cs');s=p.read_text(encoding='utf-8')
s=s.replace('_ = subject.Match(LythonRegexMatchMode.Search, default);','_ = subject.TryMatch(LythonRegexMatchMode.Search, new LythonRegexCapture?[warm.CaptureSlotCount], out _, default);')
s=s.replace('''                operation = stage switch''','''                var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
                operation = stage switch''')
s=s.replace('subject.Match(LythonRegexMatchMode.Search, cancellation.Token)','subject.TryMatch(LythonRegexMatchMode.Search, captures, out _, cancellation.Token)')
s=s.replace('cursor!.Next(cancellation.Token)','cursor!.TryNext(captures, out _, cancellation.Token)');p.write_text(s,encoding='utf-8')

p=Path('tests/Lokad.Lython.PublicApi.Tests/RegexAdapterLifetimeTests.cs');s=p.read_text(encoding='utf-8')
s=s.replace('Assert.NotNull(subject.Match(LythonRegexMatchMode.Match, default));','Assert.True(subject.TryMatch(LythonRegexMatchMode.Match, new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default));')
s=s.replace('''                var working = budget.ReservedBytes;
                for''','''                var working = budget.ReservedBytes;
                var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
                for''')
s=s.replace('''                    var match = Assert.IsType<LythonRegexMatch>(cursor.Next(default));
                    Assert.Equal(i, match.Captures[0]!.Value.StartByte);''','''                    Assert.True(cursor.TryNext(captures, out _, default));
                    Assert.Equal(i, captures[0]!.Value.StartByte);''')
s=s.replace('Assert.Null(cursor.Next(default));','Assert.False(cursor.TryNext(captures, out _, default));')
s=s.replace('Assert.NotNull(next.Match(LythonRegexMatchMode.Match, default));','Assert.True(next.TryMatch(LythonRegexMatchMode.Match, new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default));')
p.write_text(s,encoding='utf-8')

p=Path('tools/PackageSmokeTest/Program.cs');s=p.read_text(encoding='utf-8')
s=s.replace('''        public LythonRegexMatch? Match(LythonRegexMatchMode mode, CancellationToken token)
        { token.ThrowIfCancellationRequested(); return new(new LythonRegexCapture?[] { new(2, 3) }, null); }''','''        public bool TryMatch(LythonRegexMatchMode mode, Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
        { token.ThrowIfCancellationRequested(); captures[0] = new(2, 3); lastIndex = null; return true; }''')
s=s.replace('''        public LythonRegexMatch? Next(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            if (_done) return null;
            _done = true;
            return subject.Match(LythonRegexMatchMode.Search, token);
        }''','''        public bool TryNext(Span<LythonRegexCapture?> captures, out int? lastIndex, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            lastIndex = null;
            if (_done) return false;
            _done = true;
            return subject.TryMatch(LythonRegexMatchMode.Search, captures, out lastIndex, token);
        }''')
p.write_text(s,encoding='utf-8')
