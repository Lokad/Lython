from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent
assert not (root/'baseline.json').exists()
assert not subprocess.check_output(['git','status','--porcelain']).strip()
names=subprocess.check_output(['rg','-l',r'\bLythonRegexMatch\b|\bReCapture\b|\bReMatchObject\b','src','tests','tools','-g','*.cs'],text=True).splitlines()
names+=['src/Lokad.Lython/Runtime/LythonRuntime.RegexCompiler.cs','src/Lokad.Lython/Frontend/StaticRegexReturnResolver.cs']
names=sorted(set(names));files={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in names}
with tarfile.open(root/'baseline-source.tgz','w:gz') as a:
    for name in names:a.add(name,arcname=name)
binaries={}
for framework in ['net11.0','net10.0']:
    folder=root/'baseline'/framework;folder.mkdir(parents=True)
    for name in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
        p=Path('tests/Lokad.Lython.PublicApi.Tests/bin/Release')/framework/(name+'.dll')
        shutil.copyfile(p,folder/p.name);binaries[framework+'/'+p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'baseline.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtimeSource':'b6650f09 unchanged; later evidence commits only','files':files,'binaries':binaries},indent=2)+'\n',encoding='utf-8')
shutil.copyfile('PLAN.md',root/'plan-before.md')
