from pathlib import Path
root=Path(__file__).resolve().parent
old=root.parent/'adapter44-cursor/cursor-diagnostic'
source=(old/'Program.cs').read_text(encoding='utf-8')
source=source.replace('finalBudgetBytes = budget.ReservedBytes, peakWorkingBytes = budget.PeakBytes - baseline,','finalBudgetBytes = budget.ReservedBytes,')
new=source.replace('''    while (cursor.Next(active.Token) is { } match)''','''    if (!owner.TryReserve(32 + 16 * pattern.CaptureSlotCount, out var captureStorage)) throw new Exception("Capture admission failed");
    using var admitted = captureStorage;
    var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
    while (cursor.TryNext(captures, out var lastIndex, active.Token))''')
new=new.replace('match.Captures.Count','captures.Length').replace('match.Captures[','captures[').replace('match.LastIndex','lastIndex')
assert 'cursor.Next(' not in new and 'match.Captures' not in new
for role,text in [('baseline',source),('candidate',new)]:
    folder=root/('diagnostic-'+role);folder.mkdir()
    (folder/'Program.cs').write_text(text,encoding='utf-8')
    dependencies=root/'baseline/net11.0' if role=='baseline' else Path('D:/code/Lython/tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0')
    project=(old/'CursorDiagnostic.csproj').read_text(encoding='utf-8')
    a=str(root.parent/'adapter44-cursor/out/Lokad.Lython.PublicApi.Tests/Release/net11.0').replace('\\','/')
    project=project.replace('D:\\code\\Lython\\.git\\agent-notes\\review-20261031\\adapter44-cursor/out/Lokad.Lython.PublicApi.Tests/Release/net11.0',a)
    project=project.replace(a,str(dependencies).replace('\\','/'))
    assert 'adapter44-cursor/out' not in project
    (folder/'CursorDiagnostic.csproj').write_text(project,encoding='utf-8')
print('Prepared matched direct diagnostics; buffer allocation/admission included for candidate')
