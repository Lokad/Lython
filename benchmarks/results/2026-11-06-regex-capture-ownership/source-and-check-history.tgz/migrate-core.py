from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexCompiler.cs');s=p.read_text(encoding='utf-8')
start=s.index('            catch (OperationCanceledException)');end=s.index('        internal readonly record struct RegexPatternRange',start)
s=s[:start]+'''            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, cancellationToken, span, pattern, operationName); }
        }

        internal static bool TryMatch(ILythonRegexSubject subject, LythonRegexMatchMode mode,
            Span<LythonRegexCapture?> captures, out int? lastIndex, MemoryGovernor? governor,
            CancellationToken token, LythonSourceSpan? span, PyString? pattern = null)
        {
            governor?.ThrowIfAdmissionFailed();
            if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            try
            {
                var success = subject.TryMatch(mode, captures, out lastIndex, token);
                governor?.ThrowIfAdmissionFailed();
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                return success;
            }
            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, token, span, pattern); }
        }

        internal static bool TryNext(ILythonRegexCursor cursor, Span<LythonRegexCapture?> captures,
            out int? lastIndex, MemoryGovernor governor, CancellationToken token,
            LythonSourceSpan span, PyString pattern)
        {
            governor.ThrowIfAdmissionFailed();
            if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            try
            {
                var success = cursor.TryNext(captures, out lastIndex, token);
                governor.ThrowIfAdmissionFailed();
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                return success;
            }
            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, token, span, pattern); }
        }

        private static LythonRuntimeException ProviderFailure(Exception error, MemoryGovernor? governor,
            CancellationToken token, LythonSourceSpan? span, PyString? pattern,
            string operationName = "Regex provider")
        {
            if (error is OperationCanceledException)
            {
                governor?.ThrowIfAdmissionFailed();
                return RuntimeErrors.Cancelled(span);
            }
            if (error is not LythonRegexException providerError)
                return RuntimeErrors.Host("regex provider", error, span);
            governor?.ThrowIfAdmissionFailed();
            if (providerError.Failure != LythonRegexFailure.MemoryAdmission && token.IsCancellationRequested)
                return RuntimeErrors.Cancelled(span);
            return providerError.Failure switch
            {
                LythonRegexFailure.Capability => RuntimeErrors.Capability(providerError.Message, span),
                LythonRegexFailure.MemoryAdmission => governor?.RefuseAdmission($"{operationName}: {providerError.Message}", providerError.RequestedBytes, span, providerError)
                    ?? RuntimeErrors.Attributed("MemoryError", $"{operationName}: {providerError.Message}", span,
                        LythonFailureReason.SharedMemoryAllowance, requested: providerError.RequestedBytes),
                _ => CreatePatternErrorFailure(providerError.Message, pattern, providerError.Position, governor, token, span),
            };
        }

'''+s[end:];p.write_text(s,encoding='utf-8')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs');s=p.read_text(encoding='utf-8')
s=s.replace('internal static ILythonRegexSubject Prepare','internal static PreparedSubject Prepare').replace('private static ILythonRegexSubject Prepare','private static PreparedSubject Prepare')
old='''            => RegexCompiler.ProviderCall(() => pattern.Regex.Prepare(range.Original.Utf8Bytes, window,
                context.MemoryGovernor.Budget, context.State.CancellationToken), context.MemoryGovernor,
                context.State.CancellationToken, span, pattern.Pattern);'''
new='''            => new(pattern, range, window, context, span);

        // One admitted capture buffer belongs to the prepared operation, never
        // to a cached pattern or a retained Python match. Native users close first.
        internal sealed class PreparedSubject : IDisposable
        {
            private readonly RePatternObject _pattern;
            private readonly ExecutionContext _context;
            private readonly LythonSourceSpan _span;
            private readonly MemoryGovernor.TemporaryMemoryReservation _storage;
            private ILythonRegexSubject? _subject;
            internal readonly LythonRegexCapture?[] Captures;
            internal int? LastIndex;

            internal PreparedSubject(RePatternObject pattern, RegexSubjectRange range, LythonRegexWindow window,
                ExecutionContext context, LythonSourceSpan span)
            {
                _pattern = pattern; _context = context; _span = span;
                _storage = context.MemoryGovernor.ReserveTemporary(checked(128L + 16L * pattern.CaptureSlotCount), span);
                try
                {
                    context.CheckExecution(span);
                    Captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
                    _subject = RegexCompiler.ProviderCall(() => pattern.Regex.Prepare(range.Original.Utf8Bytes, window,
                        context.MemoryGovernor.Budget, context.State.CancellationToken), context.MemoryGovernor,
                        context.State.CancellationToken, span, pattern.Pattern);
                }
                catch { _storage.Dispose(); throw; }
            }

            internal bool Match(LythonRegexMatchMode mode)
            {
                ObjectDisposedException.ThrowIf(_subject is null, this);
                return RegexCompiler.TryMatch(_subject, mode, Captures, out LastIndex,
                    _context.MemoryGovernor, _context.State.CancellationToken, _span, _pattern.Pattern);
            }

            internal ILythonRegexCursor Find()
            {
                ObjectDisposedException.ThrowIf(_subject is null, this);
                return RegexCompiler.ProviderCall(() => _subject.Find(_context.State.CancellationToken),
                    _context.MemoryGovernor, _context.State.CancellationToken, _span, _pattern.Pattern);
            }

            internal bool Next(ILythonRegexCursor cursor)
                => RegexCompiler.TryNext(cursor, Captures, out LastIndex, _context.MemoryGovernor,
                    _context.State.CancellationToken, _span, _pattern.Pattern);

            public void Dispose()
            {
                var subject = _subject; _subject = null;
                try { subject?.Dispose(); }
                finally { _storage.Dispose(); }
            }
        }'''
assert old in s;s=s.replace(old,new).replace('LythonRegexMatch match','PreparedSubject match').replace('match.Captures.Count','match.Captures.Length')
s=s.replace('''            var match = RegexCompiler.ProviderCall(() => subject.Match(mode, context.State.CancellationToken),
                context.MemoryGovernor, context.State.CancellationToken, span, pattern.Pattern);
            return match is null ? PyNone.Instance : CreateMatchObject(pattern, range, match, context, span);''','''            return subject.Match(mode) ? CreateMatchObject(pattern, range, subject, context, span) : PyNone.Instance;''')
s=s.replace('''using var cursor = RegexCompiler.ProviderCall(() => subject.Find(context.State.CancellationToken),
                context.MemoryGovernor, context.State.CancellationToken, span, pattern.Pattern);''','''using var cursor = subject.Find();''')
s=s.replace('''using var cursor = RegexCompiler.ProviderCall(() => subject.Find(context.State.CancellationToken),
                    context.MemoryGovernor, context.State.CancellationToken, span, pattern.Pattern);''','''using var cursor = subject.Find();''')
s=s.replace('''RegexCompiler.ProviderCall(() => cursor.Next(context.State.CancellationToken),
                context.MemoryGovernor, context.State.CancellationToken, span, pattern.Pattern) is { } match''','''subject.Next(cursor)''')
s=s.replace('''RegexCompiler.ProviderCall(() => cursor.Next(context.State.CancellationToken),
                        context.MemoryGovernor, context.State.CancellationToken, span, pattern.Pattern) is { } match''','''subject.Next(cursor)''')
s=s.replace('''RegexCompiler.ProviderCall(() => cursor.Next(context.State.CancellationToken), context.MemoryGovernor,
                        context.State.CancellationToken, span, pattern.Pattern) is { } match''','''subject.Next(cursor)''')
# The prepared subject is the private current capture view; it never escapes.
s=s.replace('''while (subject.Next(cursor))
            {
''','''while (subject.Next(cursor))
            {
                var match = subject;
''')
s=s.replace('''subject.Next(cursor))
                {
''','''subject.Next(cursor))
                {
                    var match = subject;
''')
assert 'LythonRegexMatch match' not in s and 'cursor.Next(' not in s
p.write_text(s,encoding='utf-8')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexObjects.cs');s=p.read_text(encoding='utf-8').replace('private ILythonRegexSubject? _subject','private RegexMatcher.PreparedSubject? _subject')
s=s.replace('''_cursor = RegexCompiler.ProviderCall(() => _subject.Find(_context.State.CancellationToken),
                        _context.MemoryGovernor, _context.State.CancellationToken, _span, _pattern.Pattern);''','''_cursor = _subject.Find();''')
s=s.replace('''                var match = RegexCompiler.ProviderCall(() => _cursor!.Next(_context.State.CancellationToken),
                    _context.MemoryGovernor, _context.State.CancellationToken, _span, _pattern.Pattern);
                if (match is null) { Dispose(); return false; }
                value = RegexMatcher.CreateMatchObject(_pattern, _range, match, ref _position, _context, _span);''','''                if (!_subject.Next(_cursor!)) { Dispose(); return false; }
                value = RegexMatcher.CreateMatchObject(_pattern, _range, _subject, ref _position, _context, _span);''')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexReplacement.cs');s=p.read_text(encoding='utf-8').replace('LythonRegexMatch match','RegexMatcher.PreparedSubject match');p.write_text(s,encoding='utf-8')
