from pathlib import Path
import hashlib,json,shutil,statistics,subprocess,tarfile
home=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-06-regex-capture-ownership');out.mkdir()
assessment={}
for number in ['b356','b357']:
    source=home/number
    receipt=json.loads((source/'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and hashlib.sha256((source/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
    shutil.copyfile(source/'observations.tgz',out/(number+'-observations.tgz'))
    shutil.copyfile(source/'archive-receipt.json',out/(number+'-archive-receipt.json'))
    data=json.loads((source/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
    jobs=[]
    for job in data['jobs']:
        roles={}
        for role in ['CPython','reference','candidate','control']:
            samples=[s for s in job['samples'] if s['engine']==role]
            ms=[1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in samples]
            cpu=[1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in samples]
            quartiles=statistics.quantiles(ms,n=4,method='inclusive')
            roles[role]=dict(milliseconds=statistics.median(ms),minimum=min(ms),maximum=max(ms),
                iqrPercent=100*(quartiles[2]-quartiles[0])/statistics.median(ms),externalCpuMilliseconds=statistics.median(cpu))
        reference=roles['reference']['milliseconds']
        jobs.append(dict(case=job['case'],lane=job['lane'],roles=roles,
            deltaPercent={r:100*(roles[r]['milliseconds']/reference-1) for r in ['candidate','control']},
            ratioToCPython={r:roles[r]['milliseconds']/roles['CPython']['milliseconds'] for r in ['candidate','control']},
            currentRoleSpreadPercent=100*(max(roles[r]['milliseconds'] for r in ['candidate','control'])/min(roles[r]['milliseconds'] for r in ['candidate','control'])-1)))
    assessment[number]=dict(jobs=jobs,receipt=receipt,performanceQualified=number=='b357',
        limitation='B356 includes early SSH status observation and an archive-only owner failure, recovered under lease. B357 undisturbed confirmation; process CPU is coarse tick data, no CPU/RSS/tail claim.')
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
for name in ['baseline.json','baseline-source.tgz','direct-diagnostic.json','reference.json']:
    shutil.copyfile(home/name,out/name)
shutil.copyfile(home/'development44/qualification.json',out/'development-qualification.json')
(home/'retained-source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff']))
with tarfile.open(out/'source-and-check-history.tgz','w:gz') as a:
    for p in sorted(home.iterdir()):
        if p.is_file():a.add(p,arcname=p.name)
    for name in ['b355','b356','b357']:
        for p in sorted((home/name).iterdir()):
            if p.is_file() and p.suffix not in ['.dll'] and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname=name+'/'+p.name)
    for p in sorted((home/'development44').iterdir()):
        if p.is_file():a.add(p,arcname='development44/'+p.name)
    for name in ['diagnostic-baseline','diagnostic-candidate']:
        for p in sorted((home/name).iterdir()):
            if p.is_file():a.add(p,arcname=name+'/'+p.name)
    a.add('tests/Lokad.Lython.PublicApi.Tests/RegexCaptureMaterializationTests.cs',arcname='RegexCaptureMaterializationTests.cs')
print(json.dumps({n:[dict(case=j['case'],lane=j['lane'],delta=j['deltaPercent'],ratio=j['ratioToCPython'],spread=j['currentRoleSpreadPercent']) for j in row['jobs']] for n,row in assessment.items()},indent=2))
