from pathlib import Path
home=Path(__file__).resolve().parent
source=(home.parent/'delivery-comparison-b352/retrieve.py').read_text(encoding='utf-8')
source=source.replace('root=Path(__file__).parent',"root=Path(__file__).resolve().parent/'b357'")
source=source.replace('delivery-comparison-b352','regex-capture-b357').replace('lython-b352-delivery-comparison','lython-b357-regex-capture')
source=source.replace("['jobs']==15","['jobs']==3")
exec(compile(source,str(Path(__file__).resolve()),'exec'),{'__file__':str(Path(__file__).resolve()),'__name__':'__main__'})
