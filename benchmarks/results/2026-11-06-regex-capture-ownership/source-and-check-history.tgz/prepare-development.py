from pathlib import Path
import hashlib,json

root=Path(__file__).resolve().parent
old=root.parent/'adapter44-cursor'
dev=root/'development44'
dev.mkdir(exist_ok=True)
for name in ('Directory.Build.props','Directory.Packages.props','NuGet.Config'):
    s=(old/name).read_text(encoding='utf-8').replace(str(old).replace('\\','/'),str(dev).replace('\\','/'))
    if name=='Directory.Build.props':
        s=s.replace('<RestoreFallbackFolders>','<RestoreFallbackFolders>'+str(old/'packages').replace('\\','/')+';')
    (dev/name).write_text(s,encoding='utf-8')

# Reapply the same contract migration to the independently qualified immutable
# development bridge. Keep the old evidence/source/outputs untouched.
target=dev/'Utf8RegexProvider.cs'
target.write_bytes((old/'Utf8RegexProvider.cs').read_bytes())
transform=(root/'migrate-adapter.py').read_text(encoding='utf-8')
transform=transform.replace("p=Path('src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs')",'p=target')
transform=transform.replace("assert 'LythonRegexMatch?' not in s and 'return new(captures' not in s",'')
exec(compile(transform,str(root/'migrate-adapter.py'),'exec'),{'target':target})
s=target.read_text(encoding='utf-8')
s=s.replace('if (next.success) return Convert(next.match, token);','''if (next.success)
                        {
                            CopyCaptures(next.match, captures, token);
                            lastIndex = next.match.LastIndex;
                            return true;
                        }''')
s=s.replace('''private static LythonRegexMatch Convert(Utf8PythonRangeMatch data, CancellationToken token)
            {
                var captures = new LythonRegexCapture?[data.Groups.Length];''','''private static void CopyCaptures(Utf8PythonRangeMatch data, Span<LythonRegexCapture?> captures, CancellationToken token)
            {''')
s=s.replace('if (!data.TryGetGroup(i, out var group) || !group.Success) continue;',
            'if (!data.TryGetGroup(i, out var group) || !group.Success) { captures[i] = null; continue; }')
s=s.replace('                return new(captures, data.LastIndex);\n','')
assert 'LythonRegexMatch?' not in s and 'return new(captures' not in s
target.write_text(s,encoding='utf-8')

s=(old/'CursorAdmissionTests.cs').read_text(encoding='utf-8')
s=s.replace('cursor.Next(default);','cursor.TryNext(new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default);')
s=s.replace('Assert.NotNull(recovery.Next(default));','Assert.True(recovery.TryNext(new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default));')
s=s.replace('Assert.Null(recovery.Next(default));','Assert.False(recovery.TryNext(new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default));')
s=s.replace('''                for (var i=0;i<input.Length;i++)''','''                var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
                for (var i=0;i<input.Length;i++)''')
s=s.replace('var match=Assert.IsType<LythonRegexMatch>(cursor.Next(default));','Assert.True(cursor.TryNext(captures, out _, default));')
s=s.replace('match.Captures[','captures[')
s=s.replace('Assert.Null(cursor.Next(default));','Assert.False(cursor.TryNext(captures, out _, default));')
assert 'LythonRegexMatch>' not in s and '.Next(' not in s
(dev/'CursorAdmissionTests.cs').write_text(s,encoding='utf-8')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(baseProviderSHA256=hashlib.sha256((old/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),
    providerSHA256=hashlib.sha256(target.read_bytes()).hexdigest(),
    migration='U04 caller-owned capture buffers; existing native allowance bridge unchanged')
(dev/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(str(dev))
