import re,sys,pathlib,json
source="éab😀 βab"
pattern=re.compile(r"(?P<head>ab)(?P<empty>)|(?P<tail>β)")
matches=list(pattern.finditer(source))
re.purge()
assert all(m.string is source for m in matches)
marker=[]
assert matches[0].groups(marker)[2] is marker
assert matches[1].groupdict(marker)['head'] is marker
prefix=re.compile(r"(?<=(é))ab").search(source,1,3)
empty=re.match(r"(?P<missing>a)?(?P<empty>)","")
full=re.fullmatch(r"(.+)",source)
assert full.group() is source and full.group(1) is source
result=[(m.span(),m.groups(),m.lastindex,m.lastgroup,m.regs) for m in matches]
result += [(prefix.span(1),prefix.group(1),prefix.pos,prefix.endpos),
           (empty.groups(),empty.regs,empty.lastindex,empty.lastgroup),
           (matches[0].group(2,1,3),matches[0].expand(r"\g<head>|\g<empty>|\g<tail>"))]
print(repr(result))
pathlib.Path(__file__).with_name('reference.json').write_text(json.dumps({'python':sys.version,'expected':repr(result)+'\n'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
