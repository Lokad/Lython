from pathlib import Path
import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
root=Path('/home/lokad/lython-bench-checks/regex-capture-b356-20261106');old=Path('/home/lokad/lython-bench-checks/regex-capture-b355-20261106')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(35682+1);assert len(payload)==35682 and hashlib.sha256(payload).hexdigest()=='d452d5bf878311d893edcdcc63f23a1ca13bf5bcedb86f01d167af51d463c33f'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(root.parent).free>sum(m.size for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for role in ['candidate','reference']:(root/role).symlink_to(old/role,target_is_directory=True)
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert b'\r' not in (root/'run.sh').read_bytes();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(root).free>6*1024*1024
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b356-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
