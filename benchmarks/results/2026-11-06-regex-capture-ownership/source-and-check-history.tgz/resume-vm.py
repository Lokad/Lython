from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b355';old=home.parent/'shared-targets-r18/b354'
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined']
assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');old=base/'shared-targets-b354-20261106';root=base/'regex-capture-b355-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (root/'confirmation').exists() and not (root/'started.utc').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 archive=old/'observations.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='ARCHIVE'
 retired=[]
 with tarfile.open(archive) as a:
  for m in a.getmembers():
   if not m.isfile() or not m.name.startswith('confirmation/'):continue
   p=old/m.name
   assert old/'confirmation' in p.resolve().parents and not p.is_symlink() and p.stat().st_nlink==1
   assert p.read_bytes()==a.extractfile(m).read()
   retired.append(p)
 # All bytes have verified independent persistent/local archive copies. Retire
 # only this ended collection's expanded raw files, never another dependency.
 for p in retired:p.unlink()
 for p in sorted((old/'confirmation').rglob('*'),key=lambda p:len(p.parts),reverse=True):
  assert p.is_dir();p.rmdir()
 (old/'confirmation').rmdir()
 (old/'expanded-observations-retired-u04.json').write_text(json.dumps(dict(archiveSHA256='ARCHIVE',files=[str(p.relative_to(old)) for p in retired],localArchiveVerified=True),indent=2)+'\\n')
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role
  assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 free=shutil.disk_usage(root).free;assert free>6*1024*1024,free
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=free,retiredExpandedFiles=len(retired),archivesAndActiveImagesPreserved=True)))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b355-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('ARCHIVE',receipt['archiveSHA256'])
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'resumed-launch.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stdout+r.stderr
print(r.stdout+r.stderr,flush=True)
