from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b356'
status=json.loads((root/'terminal-status.json').read_text(encoding='utf-8'))
assert status['exitCode']=='1' and 'MainPID=0' in status['service'] and not status['remainingWorkers'] and not status['remainingFixtures']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['launch.py','failure-journal.log','early-active-status.json','terminal-status.json']:
    p=subprocess.run([*scp,str(root/name),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/regex-capture-b356-20261106/'+name],capture_output=True,text=True);assert p.returncode==0,p.stderr
script='''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/regex-capture-b356-20261106')
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 r=json.loads((root/'confirmation/confirmation.json').read_text());assert r['complete'] and len(r['jobs'])==3
 assert all(j['workersJoinedAndFixturesRemoved'] for j in r['jobs'])
 assert json.loads((root/'confirmation/machine-before.json').read_text())['gate']['quiet']
 assert json.loads((root/'confirmation/machine-after.json').read_text())['gate']['quiet']
 assert not (root/'observations-incomplete.tgz').exists()
 (root/'observations.tgz').rename(root/'observations-incomplete.tgz')
 correction=dict(originalOwnerExitCode=1,workloadCollectionComplete=True,workloadsRetimed=False,
   reason='Archive file list named setup.py, but corrected setup uses launch.py. All3 jobs, users and immediate quiet gates completed before this archive-only failure.',
   recovery='Rearchive persistent raw evidence under an exclusive recovery lease; original script/journal/partial archive preserved.',
   measurementObserver='One early SSH status read occurred during the original collection; treat timings as diagnostic rather than fully undisturbed qualification.')
 (root/'archive-correction.json').write_text(json.dumps(correction,indent=2)+'\\n')
 names=['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','launch.py','source.patch','contract.md','focused-results.json','started.utc','stopped.utc','exit-code.txt','run.sh','archive-owned.py','failure-journal.log','early-active-status.json','terminal-status.json','archive-correction.json','observations-incomplete.tgz']
 with tarfile.open(root/'observations.tgz','w:gz') as a:
  for name in names:a.add(root/name,arcname=name)
 with tarfile.open(root/'observations.tgz') as a:assert json.loads(a.extractfile('confirmation/confirmation.json').read())['complete']
 receipt=dict(complete=True,jobs=3,elapsedSeconds=r['elapsedSeconds'],allWorkersJoined=True,guestFixtureDirectories=[],quietBeforeAndAfter=True,
  originalOwnerExitCode=1,archiveRecoveredUnderLease=True,archivedAndVerifiedUnderLease=True,performanceQualified=False,
  archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'archive-recovery.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
for name in ['observations.tgz','archive-receipt.json']:
    r=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/regex-capture-b356-20261106/'+name,str(root/name)],capture_output=True,text=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
dest=root/'retrieved';dest.mkdir()
with tarfile.open(root/'observations.tgz') as a:a.extractall(dest,filter='data')
print(receipt,flush=True)
