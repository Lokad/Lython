from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;old=home/'b356';root=home/'b357';root.mkdir()
prior='/home/lokad/lython-bench-checks/regex-capture-b356-20261106';remote='/home/lokad/lython-bench-checks/regex-capture-b357-20261106'
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['collect.py','run.sh','archive-owned.py']:
    s=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    if name=='archive-owned.py':
        s=s.replace("'setup.py'","'setup-contract.json'")
        s=s.replace("t.add(root/n,arcname=n)","t.add((root/n).resolve(),arcname=n)")
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
contract='One unchanged-source confirmation corrects B356 observer interference, not a percent veto or search for favorable results. Same3 jobs/images/producer/workers/normal GC/tiering/quiet/goldens/ownership. No SSH/status/profiler before terminal owner bound. Preserve B355 fixture rejection and B356 original archive failure/all timings. Existing150s owner, allow30s stop; observe only after180s. Publication postponed.'
(root/'setup-contract.json').write_text(json.dumps(dict(contract=contract,images=prior,coreIdentity=json.loads((old/'identity.json').read_text(encoding='utf-8')),sourceArchive=receipt['archiveSHA256']),indent=2)+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
proofold=home.parent/'shared-targets-r18/b353'
oldreceipt=json.loads((proofold/'archive-receipt.json').read_text(encoding='utf-8'))
assert oldreceipt['complete'] and oldreceipt['allWorkersJoined'] and hashlib.sha256((proofold/'observations.tgz').read_bytes()).hexdigest()==oldreceipt['archiveSHA256']
payload=root/'payload.tgz'
with tarfile.open(payload,'w:gz') as a:
    for name in ['collect.py','run.sh','archive-owned.py','setup-contract.json']:a.add(root/name,arcname=name)
data=payload.read_bytes()
script='''from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');old=Path('PRIOR');retired=base/'shared-targets-b353-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()=='PRIORARCHIVE'
 assert hashlib.sha256((retired/'observations.tgz').read_bytes()).hexdigest()=='OLDARCHIVE'
 removed=[]
 if (retired/'confirmation').exists():
  with tarfile.open(retired/'observations.tgz') as a:
   for m in a.getmembers():
    if m.isfile() and m.name.startswith('confirmation/'):
     p=retired/m.name;assert not p.is_symlink() and p.stat().st_nlink==1 and retired/'confirmation' in p.resolve().parents
     assert p.read_bytes()==a.extractfile(m).read();removed.append(p)
  for p in removed:p.unlink()
  for p in sorted((retired/'confirmation').rglob('*'),key=lambda p:len(p.parts),reverse=True):assert p.is_dir();p.rmdir()
  (retired/'confirmation').rmdir()
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['candidate','reference','identity.json','representative.json','cpython-worker.py','pre-measurement-plan.md','source.patch','contract.md','focused-results.json']:
  source=old/name;assert source.exists();(root/name).symlink_to(source,target_is_directory=source.is_dir())
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 free=shutil.disk_usage(base).free;assert free>6*1024*1024
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=free,retiredExpandedFiles=len(removed),priorRawAndAllArchivesPreserved=True)))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b357-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIORARCHIVE',receipt['archiveSHA256']).replace('PRIOR',prior).replace('OLDARCHIVE',oldreceipt['archiveSHA256']).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
(root/'launch.py').write_text(script,encoding='utf-8')
r=subprocess.run([*scp,str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b357-launch.py'],capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b357-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode('utf-8')
print(r.stdout.decode('utf-8')+r.stderr.decode('utf-8'),flush=True)
