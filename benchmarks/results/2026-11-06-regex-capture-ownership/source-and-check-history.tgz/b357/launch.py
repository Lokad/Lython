from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/regex-capture-b357-20261106');old=Path('/home/lokad/lython-bench-checks/regex-capture-b356-20261106');retired=base/'shared-targets-b353-20261106'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()=='2ec2e37efe7d2d55c90fbaaf46fef697c23773f136b6361512ca439d7e1b362a'
 assert hashlib.sha256((retired/'observations.tgz').read_bytes()).hexdigest()=='a00470e5024a0bf3fe5ca6f9346afe8fdc97528938211142e03e018b1d9ffd38'
 removed=[]
 if (retired/'confirmation').exists():
  with tarfile.open(retired/'observations.tgz') as a:
   for m in a.getmembers():
    if m.isfile() and m.name.startswith('confirmation/'):
     p=retired/m.name;assert not p.is_symlink() and p.stat().st_nlink==1 and retired/'confirmation' in p.resolve().parents
     assert p.read_bytes()==a.extractfile(m).read();removed.append(p)
  for p in removed:p.unlink()
  for p in sorted((retired/'confirmation').rglob('*'),key=lambda p:len(p.parts),reverse=True):assert p.is_dir();p.rmdir()
  (retired/'confirmation').rmdir()
 payload=sys.stdin.buffer.read(5141+1);assert len(payload)==5141 and hashlib.sha256(payload).hexdigest()=='57d21690f6e7e16cffded0941765d4f10725de66fb026e302c0e1e6d72d66dff'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(m.size for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['candidate','reference','identity.json','representative.json','cpython-worker.py','pre-measurement-plan.md','source.patch','contract.md','focused-results.json']:
  source=old/name;assert source.exists();(root/name).symlink_to(source,target_is_directory=source.is_dir())
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 free=shutil.disk_usage(base).free;assert free>6*1024*1024
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=free,retiredExpandedFiles=len(removed),priorRawAndAllArchivesPreserved=True)))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b357-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
