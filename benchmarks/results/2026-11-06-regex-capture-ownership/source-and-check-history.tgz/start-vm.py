from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).resolve().parent;root=home/'b355';old=home.parent/'shared-targets-r18'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof={}
for name in ['b353','b354']:
    folder=old/name;receipt=json.loads((folder/'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and sha(folder/'observations.tgz')==receipt['archiveSHA256']
    with tarfile.open(folder/'observations.tgz') as a:
        assert a.extractfile('representative.json').read()==(folder/'representative.json').read_bytes()
    proof[name]=dict(archiveSHA256=receipt['archiveSHA256'],catalogSHA256=sha(folder/'representative.json'))
proof['b354']['coreSHA256']=sha(old/'b354/Lokad.Lython.dll')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks');proof=PROOF
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 folders={name:root/('shared-targets-'+name+'-20261106') for name in proof}
 for name,folder in folders.items():
  receipt=json.loads((folder/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined']
  assert hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest()==proof[name]['archiveSHA256']
  catalog=folder/'representative.json'
  if catalog.exists():
   assert not catalog.is_symlink() and catalog.resolve().parent==folder and catalog.stat().st_nlink==1
   assert hashlib.sha256(catalog.read_bytes()).hexdigest()==proof[name]['catalogSHA256']
 core=folders['b354']/'Lokad.Lython.dll';alias=folders['b354']/'candidate/Lokad.Lython.dll'
 assert not core.is_symlink() and core.resolve().parent==folders['b354'] and core.stat().st_nlink==1
 assert hashlib.sha256(core.read_bytes()).hexdigest()==proof['b354']['coreSHA256']
 assert alias.is_symlink() and alias.resolve()==core
 dependencies=[];catalogs=[folder/'representative.json' for folder in folders.values() if (folder/'representative.json').exists()]
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   path=Path(directory)/name
   if path.is_symlink():
    target=path.resolve()
    assert all(target!=catalog and target not in catalog.parents for catalog in catalogs)
    if target==core or target in core.parents:dependencies.append(str(path))
 assert sorted(dependencies)==[str(alias)],dependencies
 assert (root/'delivery-comparison-b352-20261106/candidate/Lokad.Lython.dll').resolve()!=core
 alias.unlink();core.unlink()
 for catalog in catalogs:catalog.unlink()
 record=dict(retiredUnusedPrototypeImage=str(core),catalogs=[str(p) for p in catalogs],proof=proof,freeBytes=shutil.disk_usage(root).free,
  localBackupsAndRemoteArchivesVerified=True,currentImagesPreserved=True)
 (folders['b354']/'image-retired-u04.json').write_text(json.dumps(record,indent=2)+'\\n');print(json.dumps(record))
'''.replace('PROOF',repr(proof))
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
log=root/'retirement.log'
if log.exists():log=root/'retirement-corrected.log'
assert not log.exists()
log.write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
transfer=json.loads((root/'transfer.json').read_text(encoding='utf-8'))
assert json.loads(r.stdout)['freeBytes']>transfer['requiredFreeBeforeStreamedSetup'],r.stdout
print(r.stdout,flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name,target in [('transfer.json','b355-transfer.json'),('launch-stream.py','b355-launch.py')]:
    p=subprocess.run([*scp,str(root/name),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/'+target],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
with (root/'payload.tgz').open('rb') as payload:
    p=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b355-launch.py'],stdin=payload,capture_output=True)
(root/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8')
print(p.stdout.decode('utf-8')+p.stderr.decode('utf-8'),flush=True)
