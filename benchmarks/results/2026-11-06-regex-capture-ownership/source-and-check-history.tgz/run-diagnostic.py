from pathlib import Path
import hashlib,json,os,statistics,subprocess
root=Path(__file__).resolve().parent
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for role in ['baseline','candidate']:
    folder=root/('diagnostic-'+role)
    with (folder/'build.log').open('w',encoding='utf-8') as log:
        r=subprocess.run([dotnet,'build',str(folder/'CursorDiagnostic.csproj'),'-c','Release','--nologo','--tl:off'],env=env,stdout=log,stderr=subprocess.STDOUT)
    assert r.returncode==0,(folder/'build.log').read_text(encoding='utf-8')[-1800:]
results=[]
for i,role in enumerate(['baseline','candidate','candidate','baseline']):
    r=subprocess.run([dotnet,str(root/('diagnostic-'+role)/'bin/Release/net11.0/CursorDiagnostic.dll'),f'{role}-{i}'],env=env,capture_output=True,text=True,encoding='utf-8')
    (root/f'direct-{i}-{role}.json').write_text(r.stdout,encoding='utf-8')
    (root/f'direct-{i}-{role}.stderr.log').write_text(r.stderr,encoding='utf-8')
    assert r.returncode==0,r.stdout+r.stderr
    row=json.loads(r.stdout);assert row['finalBudgetBytes']==0 and row['matches']==64
    results.append(row);print(role,row['medianAllocatedBytes'],row['medianMilliseconds'],flush=True)
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    assert len({r['hashes'][name] for r in results})==1
allocated={role:statistics.median(r['medianAllocatedBytes'] for r in results if r['role'].startswith(role)) for role in ['baseline','candidate']}
elapsed={role:statistics.median(r['medianMilliseconds'] for r in results if r['role'].startswith(role)) for role in ['baseline','candidate']}
summary=dict(results=results,sameProducer=True,normalPin='0.4.0 unchanged',
    allocationDeltaPercent=100*(allocated['candidate']/allocated['baseline']-1),
    diagnosticElapsedDeltaPercent=100*(elapsed['candidate']/elapsed['baseline']-1),
    limitation='Direct provider cursor operations, no retained guest matches. Includes candidate caller buffer allocation and reservation per drain, old carriers per match. Busy Windows elapsed diagnostic only, no whole-script/CPU/CPython/RSS claim.')
(root/'direct-diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print({k:v for k,v in summary.items() if k!='results'},flush=True)
