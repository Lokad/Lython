from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexModule.cs');s=p.read_text(encoding='utf-8')
start=s.index('    internal sealed record ReCapture(');end=s.index('    internal sealed record RePatternObject(',start)
s=s[:start]+'''    internal readonly record struct ReCaptureRange(int StartByte, int EndByte, int Start, int End);

    // Retained matches own immutable ranges over their already-funded subject.
    // Current group access owns any new string, independently of cursor scratch.
    internal sealed class ReMatchObject(RePatternObject pattern, PyString input, int pos, int endPos,
        ReCaptureRange[] captures, int? lastIndex, MemoryGovernor owner) : IPyContextualDynamicAttributes
    {
        public RePatternObject Pattern { get; } = pattern;
        public PyString String { get; } = input;
        public int Pos { get; } = pos;
        public int EndPos { get; } = endPos;
        public ReCaptureRange[] Captures { get; } = captures;
        public int CaptureSlotCount => Captures.Length;
        public IReadOnlyDictionary<PyString, int> NamedGroups => Pattern.NamedGroups;
        public int? LastCapturedIndex { get; } = lastIndex;
        public int Start => Captures[0].Start;
        public int End => Captures[0].End;

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
            => ReMatchMembers.TryGetMember(this, name, context, span, out value);

        internal ReadOnlyMemory<byte> GroupBytes(int index)
        {
            var capture = Captures[index];
            return capture.StartByte < 0 ? ReadOnlyMemory<byte>.Empty
                : String.Utf8Bytes.Slice(capture.StartByte, capture.EndByte - capture.StartByte);
        }

        internal PyString MaterializeGroup(int index, ExecutionContext? context, LythonSourceSpan? span)
        {
            context ??= PyStructuralGuard.AmbientContext;
            var governor = context?.MemoryGovernor ?? owner;
            governor.ThrowIfAdmissionFailed();
            context?.CheckExecution(span);
            var bytes = GroupBytes(index);
            if (bytes.IsEmpty) return PyString.Empty;
            if (bytes.Length == String.Utf8Bytes.Length) return String;
            using var storage = governor.ReserveTemporary(PyString.EstimateApproximateBytes(bytes.Length), span);
            context?.CheckExecution(span);
            var copy = new byte[bytes.Length];
            for (var offset = 0; offset < copy.Length;)
            {
                context?.CheckExecution(span);
                var count = Math.Min(4096, copy.Length - offset);
                bytes.Span.Slice(offset, count).CopyTo(copy.AsSpan(offset, count));
                offset += count;
            }
            context?.CheckExecution(span);
            return PyString.FromOwnedUtf8(copy, governor, span, storage);
        }
    }

'''+s[end:];p.write_text(s,encoding='utf-8')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs');s=p.read_text(encoding='utf-8')
start=s.index('        private static void ProjectScalarBounds(');end=s.index('        internal static object Match(',start)
s=s[:start]+'''        private static void ProjectScalarBounds(RegexSubjectRange range, ReCaptureRange[] captures,
            ref RegexScalarPosition previous, ExecutionContext context, LythonSourceSpan span)
        {
            var count = checked(2 * captures.Length);
            var input = range.Original.Utf8Bytes.Span;
            if (range.Original.Length == input.Length)
            {
                for (var i = 0; i < captures.Length; i++)
                {
                    context.CheckExecution(span);
                    var capture = captures[i];
                    captures[i] = capture with { Start = capture.StartByte, End = capture.EndByte };
                }
                return;
            }
            var bytes = new int[count];
            var slots = new int[count];
            for (var i = 0; i < captures.Length; i++)
            {
                context.CheckExecution(span);
                bytes[2 * i] = captures[i].StartByte;
                bytes[2 * i + 1] = captures[i].EndByte;
                slots[2 * i] = 2 * i; slots[2 * i + 1] = 2 * i + 1;
            }
            Array.Sort(bytes, slots);
            var offset = previous.ByteOffset;
            var scalar = previous.ScalarOffset;
            for (var i = 0; i < count; i++)
            {
                context.CheckExecution(span);
                if (bytes[i] >= 0 && bytes[i] < offset) { offset = 0; scalar = 0; }
                while (offset < bytes[i])
                {
                    if ((scalar & 1023) == 0) context.CheckExecution(span);
                    Rune.DecodeFromUtf8(input[offset..], out _, out var width);
                    offset += width;
                    scalar++;
                }
                var value = bytes[i] < 0 ? -1 : scalar;
                var slot = slots[i] / 2;
                captures[slot] = (slots[i] & 1) == 0
                    ? captures[slot] with { Start = value } : captures[slot] with { End = value };
            }
            previous = new(captures[0].EndByte, captures[0].End);
        }

'''+s[end:]
start=s.index('            var whole = match.Captures[0]!.Value;',s.index('        internal static ReMatchObject CreateMatchObject('));end=s.index('            storage.Commit(bytes);',start)
s=s[:start]+'''            var bytes = checked(128L + 32L * match.Captures.Length);
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
            using var projection = context.MemoryGovernor.ReserveTemporary(checked(64L + 16L * match.Captures.Length), span);
            context.CheckExecution(span);
            var captures = new ReCaptureRange[match.Captures.Length];
            for (var i = 0; i < captures.Length; i++)
            {
                context.CheckExecution(span);
                captures[i] = match.Captures[i] is { } capture
                    ? new(capture.StartByte, capture.EndByte, -1, -1) : new(-1, -1, -1, -1);
            }
            ProjectScalarBounds(range, captures, ref position, context, span);
            var result = new ReMatchObject(pattern, range.Original, range.Pos, range.EndPos,
                captures, match.LastIndex, context.MemoryGovernor);
'''+s[end:];p.write_text(s,encoding='utf-8')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexObjects.cs');s=p.read_text(encoding='utf-8')
s=s.replace('''public static bool TryGetMember(ReMatchObject match, string name, [MaybeNullWhen(false)] out object value)''','''public static bool TryGetMember(ReMatchObject match, string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)''')
s=s.replace('"pos" => match.Pos,','"pos" => new BigInteger(match.Pos),').replace('"endpos" => match.EndPos,','"endpos" => new BigInteger(match.EndPos),')
s=s.replace('''                "lastgroup" => LastGroup(match),''','''                "lastgroup" => LastGroup(match),
                "regs" => CreateTuple(match.CaptureSlotCount, i =>
                    CreateTuple(2, j => new BigInteger(j == 0 ? match.Captures[i].Start : match.Captures[i].End), context, span), context, span),''')
old='''                    var groups = new object[Math.Max(0, match.CaptureSlotCount - 1)];
                    for (var i = 1; i < match.CaptureSlotCount; i++)
                    {
                        groups[i - 1] = ResolveIndexedGroup(match, i, span, defaultValue);
                    }

                    return new PyTuple(groups, context.MemoryGovernor, span);'''
new='''                    return CreateTuple(match.CaptureSlotCount - 1,
                        i => ResolveIndexedGroup(match, i + 1, span, context, defaultValue), context, span);'''
assert old in s;s=s.replace(old,new)
s=s.replace('ResolveIndexedGroup(match, entry.Value, span, defaultValue)','ResolveIndexedGroup(match, entry.Value, span, context, defaultValue)')
s=s.replace('ResolveIndexedGroup(match, index, span)\n','ResolveIndexedGroup(match, index, span, context)\n')
s=s.replace('return match.Value;','return match.MaterializeGroup(0, context, span);')
start=s.index('        private static object ResolveIndexedGroup(');end=s.index('        private static bool TryResolveGroupIndex(',start)
s=s[:start]+'''        private static object ResolveIndexedGroup(ReMatchObject match, int index, LythonSourceSpan span, ExecutionContext? context)
            => ResolveIndexedGroup(match, index, span, context, PyNone.Instance);

        private static object ResolveIndexedGroup(ReMatchObject match, int index, LythonSourceSpan span,
            ExecutionContext? context, object defaultValue)
        {
            if (index < 0 || index >= match.CaptureSlotCount)
                throw new LythonRuntimeException("IndexError", "Regex group index is out of range.", span);
            return match.Captures[index].StartByte < 0 ? defaultValue : match.MaterializeGroup(index, context, span);
        }

        private static RegexGroupBounds ResolveGroupBounds(ReMatchObject match, object group, LythonSourceSpan span)
        {
            if (TryResolveGroupIndex(match, group, span, out var index))
            {
                var capture = match.Captures[index];
                return new RegexGroupBounds(capture.Start, capture.End);
            }
            throw new LythonRuntimeException("IndexError", "no such group", span);
        }

'''+s[end:];p.write_text(s,encoding='utf-8')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.RegexReplacement.cs');s=p.read_text(encoding='utf-8')
s=s.replace('''                else if (part.Group == 0) AppendRegexBytes(builder, match.Value.Utf8Bytes.Span, context, span);
                else if (match.Captures[part.Group - 1] is { } capture)
                    AppendRegexBytes(builder, capture.Value.Utf8Bytes.Span, context, span);''','''                else AppendRegexBytes(builder, match.GroupBytes(part.Group).Span, context, span);''')
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/PyMemberAccess.cs');s=p.read_text(encoding='utf-8');s='\n'.join(line for line in s.split('\n') if '[typeof(LythonRuntime.ReMatchObject)]' not in line);p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/PyRendering.cs');s=p.read_text(encoding='utf-8').replace('ToReprPyStringCore(match.Value, context, activeContainers)','ToReprPyStringCore(match.MaterializeGroup(0, context.Context, PyStructuralGuard.AmbientSpan), context, activeContainers)');p.write_text(s,encoding='utf-8')
for name in ['StaticContracts.MemberSurfaces.cs','StaticContracts.MemberValues.cs']:
    p=Path('src/Lokad.Lython/Frontend')/name;s=p.read_text(encoding='utf-8')
    if name.endswith('Surfaces.cs'):s=s.replace('        "lastgroup",','        "lastgroup",\n        "regs",',1)
    else:s=s.replace('        new(AbstractValueKind.RegexMatch, "lastgroup", StaticReturnShape.Unknown),','        new(AbstractValueKind.RegexMatch, "lastgroup", StaticReturnShape.Unknown),\n        new(AbstractValueKind.RegexMatch, "regs", StaticReturnShape.Unknown),')
    p.write_text(s,encoding='utf-8')
