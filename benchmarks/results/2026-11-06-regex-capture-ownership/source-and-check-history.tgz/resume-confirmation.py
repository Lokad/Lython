from pathlib import Path
import hashlib,json,subprocess
home=Path(__file__).resolve().parent;root=home/'b357'
proof={}
for name,local in [('delivery-comparison-b352-20261106',home.parent/'delivery-comparison-b352'),('regex-capture-b356-20261106',home/'b356')]:
    receipt=json.loads((local/'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['allWorkersJoined'] and hashlib.sha256((local/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
    proof[name]=receipt['archiveSHA256']
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'regex-capture-b357-20261106';proof=PROOF
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (root/'confirmation').exists() and not (root/'started.utc').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 removed=[]
 for name,digest in proof.items():
  folder=base/name;archive=folder/'observations.tgz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==digest
  if not (folder/'confirmation').exists():continue
  files=[]
  with tarfile.open(archive) as a:
   for m in a.getmembers():
    if m.isfile() and m.name.startswith('confirmation/'):
     p=folder/m.name;assert not p.is_symlink() and p.stat().st_nlink==1 and folder/'confirmation' in p.resolve().parents
     assert p.read_bytes()==a.extractfile(m).read();files.append(p)
  for p in files:p.unlink()
  for p in sorted((folder/'confirmation').rglob('*'),key=lambda p:len(p.parts),reverse=True):assert p.is_dir();p.rmdir()
  (folder/'confirmation').rmdir();removed.extend(str(p) for p in files)
  (folder/'expanded-observations-retired-u04.json').write_text(json.dumps(dict(archiveSHA256=digest,localAndRemoteArchivesVerified=True,files=[str(p.relative_to(folder)) for p in files]),indent=2)+'\\n')
 i=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  folder=root/role;assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][role]
  for name,digest in i['auxiliaryFiles'].items():
   if role=='candidate' and name=='Lokad.Lython.Utf8Regex.dll':digest=i['candidateAdapterSHA256']
   assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 free=shutil.disk_usage(base).free;assert free>7*1024*1024,free
 print(json.dumps(dict(freeBytes=free,retiredExpandedFiles=len(removed),imagesAndArchivesPreserved=True)))
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b357-regex-capture-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('PROOF',repr(proof))
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'resumed-launch.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stdout+r.stderr
print(r.stdout+r.stderr,flush=True)
