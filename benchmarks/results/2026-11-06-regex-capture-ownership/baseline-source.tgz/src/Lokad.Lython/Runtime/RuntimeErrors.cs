using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal static class RuntimeErrors
{
    public static LythonRuntimeException CannotImportMember(string moduleName, string memberName, LythonSourceSpan? span)
        => new("ImportError", $"cannot import name '{memberName}' from '{moduleName}'", span);

    public static LythonRuntimeException NoModuleNamed(string moduleName, LythonSourceSpan? span)
        => new("ModuleNotFoundError", $"No module named '{moduleName}'", span);

    public static string DatetimeQualifiedTypeName(object? value, LythonRuntime.ExecutionContext context)
        => value is PyDate or PyTime or PyDateTime or PyTimedelta or PyTimezone
            ? "datetime." + LythonRuntime.UnboundTypeMethod.PythonTypeName(value, context)
            : LythonRuntime.UnboundTypeMethod.PythonTypeName(value, context);

    public static LythonRuntimeException Type(string message, LythonSourceSpan? span)
        => new("TypeError", message, span);

    public static LythonRuntimeException UnsupportedOperands(
        string operation,
        object left,
        object right,
        LythonSourceSpan? span)
    {
        return Type($"unsupported operand type(s) for {operation}: '{OperandTypeName(left)}' and '{OperandTypeName(right)}'", span);
    }

    public static LythonRuntimeException BadUnaryOperand(
        string operation,
        object operand,
        LythonSourceSpan? span)
    {
        return Type($"bad operand type for unary {operation}: '{OperandTypeName(operand)}'", span);
    }

    public static LythonRuntimeException UnsupportedComparison(
        string operation,
        object left,
        object right,
        LythonSourceSpan? span)
    {
        return Type($"'{operation}' not supported between instances of '{OperandTypeName(left)}' and '{OperandTypeName(right)}'", span);
    }

    public static LythonRuntimeException ConcatError(string left, object right, LythonSourceSpan? span)
        => Type($"can only concatenate {left} (not \"{OperandTypeName(right)}\") to {left}", span);

    public static LythonRuntimeException CantConcatToBytes(object right, LythonSourceSpan? span)
        => Type($"can't concat {OperandTypeName(right)} to bytes", span);

    public static LythonRuntimeException MultiplySequenceError(object other, LythonSourceSpan? span)
        => Type($"can't multiply sequence by non-int of type '{OperandTypeName(other)}'", span);

    public static LythonRuntimeException UnhashableType(object value, LythonSourceSpan? span)
        => Type($"unhashable type: '{OperandTypeName(value)}'", span);

    public static LythonRuntimeException NotAnIterator(object value, LythonSourceSpan? span)
        => Type($"'{OperandTypeName(value)}' object is not an iterator", span);

    public static PyNotIterableException NotIterable(object? value, LythonSourceSpan? span)
        => new PyNotIterableException($"\'{OperandTypeName(value)}\' object is not iterable", span);

    public static LythonRuntimeException ArgumentNotIterable(object? value, LythonSourceSpan? span)
        => Type($"argument of type '{OperandTypeName(value)}' is not iterable", span);

    public static string OperandTypeName(object? value) => value switch
    {
        null => "NoneType",
        PyNone => "NoneType",
        PyEllipsis => "ellipsis",
        PyNotImplemented => "NotImplementedType",
        PyString => "str",
        double => "float",
        PyComplex => "complex",
        bool => "bool",
        _ when PyNumberOps.IsInteger(value) => "int",
        PyList => "list",
        PyMappingProxy => "mappingproxy",
        PyDict => "dict",
        PyCounter => "Counter",
        PyDefaultDict => "collections.defaultdict",
        PyTuple or PyNamedTupleObject => "tuple",
        PySet => "set",
        PyBytes => "bytes",
        PyRange => "range",
        PySlice => "slice",
        PyDeque => "collections.deque",
        PyChainMap => "ChainMap",
        LythonRuntime.DictKeysView => "dict_keys",
        LythonRuntime.DictValuesView => "dict_values",
        LythonRuntime.DictItemsView => "dict_items",
        ChainMapKeysView => "KeysView",
        ChainMapValuesView => "ValuesView",
        ChainMapItemsView => "ItemsView",
        LythonRuntime.CsvReaderObject => "csv.reader",
        LythonRuntime.CsvDictReaderObject => "csv.DictReader",
        PyDecimal => "decimal.Decimal",
        PyDate => "datetime.date",
        PyTime => "datetime.time",
        PyDateTime => "datetime.datetime",
        PyTimedelta => "datetime.timedelta",
        PyTimezone => "datetime.timezone",
        PyIsoCalendarDate => "datetime.IsoCalendarDate",
        LythonRuntime.StatisticsModule.PyNormalDist => "NormalDist",
        LythonRuntime.TimeStructTimeValue => "time.struct_time",
        LythonRuntime.RandomModule.PyRandom => "Random",
        LythonRuntime.RePatternObject => "re.Pattern",
        LythonRuntime.ReMatchObject => "re.Match",
        LythonRuntime.ElementTreeModule.Element => "xml.etree.ElementTree.Element",
        PyInstance instance => instance.Type.Name,
        _ => LythonRuntime.CallableOperandTypeName(value),
    };

    public static LythonRuntimeException Value(string message, LythonSourceSpan? span)
        => new("ValueError", message, span);

    public static LythonRuntimeException Runtime(string message, LythonSourceSpan? span)
        => new("RuntimeError", message, span);

    internal static LythonRuntimeException Attributed(
        string exceptionType, string message, LythonSourceSpan? span,
        LythonFailureReason reason, long? limit = null, long? observed = null, long? requested = null)
        => new(exceptionType, message, span) { Attribution = new(reason, limit, observed, requested) };

    internal static LythonRuntimeException Cancelled(LythonSourceSpan? span)
        => Attributed("RuntimeError", "execution canceled", span, LythonFailureReason.Cancelled);

    internal static LythonRuntimeException Capability(string message, LythonSourceSpan? span)
        => Attributed("RuntimeError", message, span, LythonFailureReason.HostCapabilityUnavailable);

    public static LythonRuntimeException Recursion(string message, LythonSourceSpan? span)
        => new("RecursionError", message, span);

    public static LythonRuntimeException Memory(string message, LythonSourceSpan? span)
        => new("MemoryError", message, span);

    public static LythonRuntimeException Host(string operation, Exception exception, LythonSourceSpan? span)
        => new HostOperationException("RuntimeError", $"Host {operation} failed.", span, exception);

    // Mapping misses carry their key as the payload so str/args render like
    // CPython; the fixed text stays for the message member and failure paths.
    public static LythonRuntimeException MissingKey(object key, LythonSourceSpan? span)
        => new("KeyError", "Key was not found.", span, null, key);

    public static LythonRuntimeException NotCallable(LythonSourceSpan span)
        => Type("Object is not callable.", span);

    public static LythonRuntimeException NotSubscriptable(LythonSourceSpan span)
        => Type("Object is not subscriptable.", span);

    public static LythonRuntimeException NotSliceable(LythonSourceSpan span)
        => Type("Object does not support slicing.", span);

    public static LythonRuntimeException NameNotDefined(string name, LythonSourceSpan? span)
        => new("NameError", $"name '{name}' is not defined", span);

    public static LythonRuntimeException UnboundLocalVariable(string name, LythonSourceSpan? span)
        => new("UnboundLocalError", $"cannot access local variable '{name}' where it is not associated with a value", span);

    public static LythonRuntimeException FreeVariableNotAssociated(string name, LythonSourceSpan? span)
        => new("NameError", $"cannot access free variable '{name}' where it is not associated with a value in enclosing scope", span);

    public static LythonRuntimeException RaiseExpectsException(LythonSourceSpan? span)
        => Type("exceptions must derive from BaseException", span);

    public static LythonRuntimeException ImportedModuleReturned(string moduleName, LythonSourceSpan? span)
        => Runtime($"Imported module '{moduleName}' returned from top level.", span);

    public static LythonRuntimeException CannotImportModule(string moduleName, string message, LythonSourceSpan? span)
        => new("SyntaxError", $"Cannot import module '{moduleName}': {message}", span);

}
