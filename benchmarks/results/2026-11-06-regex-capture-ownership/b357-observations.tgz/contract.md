# U04 bounded complete-script gate
Same unchanged b94 worker/protocol, normal0.4 producer, qualified b665 reference
and current candidate with matching role-specific adapter. Two identical current
roles, CPython reference, normal GC/tiering, quiet VM, five-second warmup and seven
rotated150ms batches. Regex input1024UTF8records, file read, actual capture access,
numeric aggregation/scalar endpoints and complete output checks. Warm excludes
compilation; fresh includes compile/disposal. Actual mediated RAM I/O and prior
result cleanup included, fixture staging/final shutdown excluded. No abandoned
users. Retain all failures/adverse data, archive under lease before owner exits.
One150s owner/110s job-start guard, no10minlanes, exact allocation separate.

B355 stopped before Ready/measurement: new fixture omitted size metadata. Preserve all failed conditions; B356 corrects only catalog metadata, same source/images/boundaries/jobs. Local CPython manifest validation passes.
