#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
filter='(FullyQualifiedName~ExecutableFunctionInvocation|FullyQualifiedName~CallBinding|FullyQualifiedName~RecordKeyOwnership|FullyQualifiedName~RecordFieldLookupOwnership|FullyQualifiedName~ExecutableLocalImportBinding|FullyQualifiedName~CsvRecordValueOwnership)&Category!=Stress'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --filter "$filter" 2>&1 | tee /mnt/d/code/Lython/.git/agent-notes/review-20261031/compiled-definition-keys/white-ubuntu.log
