from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'keyword-default-record-r715'
stage = (prior/'stage-quiet.py').read_text(encoding='utf8')
stage = stage.replace('keyword-default-record-b1146', 'compiled-definition-keys-b1149')
stage = stage.replace('lython-b1146-keyword-default-record', 'lython-b1149-compiled-definition-keys')
stage = stage.replace('lython-b1146-fixtures', 'lython-b1149-fixtures')
stage = stage.replace('R715 live keyword-default record slots', 'R716 compiler-owned definition keys')
stage = stage.replace('Live keyword-default record slots', 'Compiler-owned definition keys')
stage = stage.replace('six-job', 'seven-job')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
annotated = 'scripts.annotated-rule-closures'
jobs = [(annotated+'.nested-factories','warm'), (annotated,'warm'), (annotated+'.observed','warm'),
        ('scripts.csv-invoice.large','warm'), ('scripts.captured-rule-closures','warm'),
        (annotated,'compile'), (annotated,'compile-run')]
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
for old, new in [('len(jobs)==6','len(jobs)==7'), ("len(raw['jobs'])==6","len(raw['jobs'])==7"),
                 ('jobs=6,','jobs=7,'), ("['jobs']==6","['jobs']==7")]:
    # Assertions refer to the new job count. Keep replacements sourced from the six-job template.
    stage = stage.replace(old, new)
    stage = stage.replace('"'+new+'","'+new+'"','"'+old+'","'+new+'"')
stage = stage.replace('.replace("323","350")','.replace("323","435")')
stage = stage.replace('timedelta(seconds=350)', 'timedelta(seconds=435)')
stage = stage.replace('read(template / "summarize-quiet.py"))',
                      'read(template / "summarize-quiet.py").replace("len(raw[\'jobs\'])==6","len(raw[\'jobs\'])==7"))')
assert repr(jobs) in stage
proof = (prior/'prove-quiet-space.py').read_text(encoding='utf8')
proof = proof.replace('pairs = []', '''pairs = [
    ('keyword-default-record-r715/quiet', '2026-11-19-keyword-default-record', 'reference', 'reference-core.dll.gz'),
    ('keyword-default-record-r715/quiet', '2026-11-19-keyword-default-record', 'candidate', 'measured-core.dll.gz'),
]''')
for name,value in [('prove-quiet-space.py',proof),('stage-quiet.py',stage)]:
    (lab/name).write_text(value, encoding='utf8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab/name],check=True)
