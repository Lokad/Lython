from pathlib import Path
import copy
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
old = lab.parent / 'keyword-default-record-r715'
additional_cases = lab.parent / 'source-annotation-mode-r714' / 'catalog.json'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
catalog = load(old / 'catalog.json')
cases = catalog['cases']
cases.append(next(c for c in load(additional_cases)['cases'] if c['id'] == 'scripts.annotated-rule-closures.observed'))
nested = copy.deepcopy(next(c for c in cases if c['id'] == 'scripts.annotated-rule-closures'))
nested['id'] = 'scripts.annotated-rule-closures.nested-factories'
nested['source'] = """def for_policy(multiplier):
    def compile_rule(seed):
        def evaluate(record: int, /, base: int = seed % 11, *, weight: int = multiplier) -> int:
            return (record + base) * weight
        return evaluate
    return compile_rule

total = 0
for index in range(2048):
    compile_rule = for_policy(index % 7 + 1)
    latest = compile_rule(index)
    total += latest(index)
print(total, list(latest.__annotations__))
"""
python = Path('C:/Python313/python.exe')
source = nested['source'].encode()
output = subprocess.run([python, '-I', '-X', 'utf8', '-'], input=source, stdout=subprocess.PIPE, check=True).stdout.replace(b'\r\n', b'\n')
assert output.decode() == nested['expectedOutput']
nested.update(sourceUtf8Bytes=len(source), sourceSha256=hashlib.sha256(source).hexdigest())
cases.append(nested)
(lab/'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False)+'\n', encoding='utf8', newline='\n')

freeze = (old/'freeze-and-verify.py').read_text(encoding='utf-8')
freeze = freeze.replace('keyword-default-record-r715', 'compiled-definition-keys').replace("'c76c59159'", "'fad73f098'")
freeze = freeze.replace("'%s'" % 'unused', "'unused'")
freeze = freeze.replace('["cases"]) == 6', '["cases"]) == 8').replace('all six cases', 'all eight cases')
freeze = freeze.replace("            build_dir='windows' if role=='candidate' else 'reference'\n            origin=lab/build_dir/'bin/Lokad.Lython/release_net11.0'/name",
    "            origin=(trial/'src/Lokad.Lython/bin/Release/net11.0' if role=='candidate' else lab/'reference/bin/Lokad.Lython/release_net11.0')/name")
assert "'src/Lokad.Lython/bin/Release/net11.0'" in freeze
(lab/'freeze-and-verify.py').write_text(freeze, encoding='utf8', newline='\n')
