#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
filter='FullyQualifiedName~ProjectedDefinitionRecordsSurviveCompilationDisposal'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --filter "$filter" 2>&1 | tee /mnt/d/code/Lython/.git/agent-notes/review-20261031/compiled-definition-keys/projection-ubuntu.log
