from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'keyword-default-record-r715'
code = (prior/'build-confirmation.py').read_text(encoding='utf8')
code = code.replace('keyword-default-record-b1147-20261119','compiled-definition-keys-b1150-20261119')
code = code.replace('lython-b1147-keyword-default-record','lython-b1150-compiled-definition-keys')
code = code.replace('lython-b1147-control-fixtures','lython-b1150-control-fixtures')
code = code.replace("jobs = [('scripts.csv-invoice.large', 'warm'), ('scripts.annotated-rule-closures', 'warm'), ('calls.defaults.medium', 'warm')]",
    "jobs = [('scripts.annotated-rule-closures', 'warm'), ('scripts.csv-invoice.large', 'warm'), ('scripts.annotated-rule-closures', 'compile-run')]")
code = code.replace('B1146 lane', 'B1149 lane')
code = code.replace('==6','==7').replace('jobs=6,','jobs=7,').replace('job_index == 1','job_index == 0')
code = code.replace("replace('350','185')","replace('435','185')")
assert 'job_index == 0' in code
p = lab/'build-confirmation.py'
p.write_text(code,encoding='utf8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',p],check=True)
