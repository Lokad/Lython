from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab/'quiet'
out = lab/'confirmation-corrected'
out.mkdir(exist_ok=False)
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original = load(prior/'config.json')
receipt = load(prior/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(prior/'observations.tgz') == receipt['archiveSHA256']
identity = load(prior/'identity.json')
source = original['root']
root = '/home/lokad/lython-bench-checks/compiled-definition-keys-b1150-20261119'
unit = 'lython-b1150-compiled-definition-keys-20261119'
assert all(len(files)==32 for files in identity['imageFiles'].values())
assert sha(prior/'representative.json')==identity['catalogSHA256']
cases = {case['id'] for case in load(prior/'representative.json')['cases']}
jobs = [('scripts.annotated-rule-closures', 'warm'), ('scripts.csv-invoice.large', 'warm'), ('scripts.annotated-rule-closures', 'compile-run')]
assert all(case in cases for case,_ in jobs)
def write(path, value):
    if path.suffix == '.py': ast.parse(value)
    path.write_text(value,encoding='utf-8',newline='\n')
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    code=(prior/name).read_text(encoding='utf-8').replace(source,root)
    code=code.replace('len(jobs)==7','len(jobs)==3').replace("len(raw['jobs'])==7","len(raw['jobs'])==3")
    code=code.replace('jobs=7,','jobs=3,').replace("['jobs']==7","['jobs']==3")
    if name == 'collect.py':
        start,end=code.index('\njobs = ')+1,code.index('\nassert len(jobs)')
        code=code[:start]+'jobs = '+repr(jobs)+code[end:]
        # Reverse the order of each input relative to its B1149 lane.
        assert '            if job_index >= 2: labels.reverse()\n' in code
        code=code.replace('            if job_index >= 2: labels.reverse()\n','            if job_index == 0: labels.reverse()\n')
    write(out/name,code)
for name in ('representative.json','identity.json'):
    shutil.copyfile(prior/name,out/name)
protocol=lab.parent/'integer-transport-cpython-b1136/cpython-worker.py'
assert sha(protocol)==load(protocol.parent/'identity.json')['cpythonWorkerSHA256']
shutil.copyfile(protocol,out/'cpython-worker.py')
names=('collect.py','archive-owned.py','run.sh','identity.json','cpython-worker.py')
with tarfile.open(out/'payload.tgz','w:gz') as tar:
    for name in names:tar.add(out/name,arcname=name)
config=dict(root=root,unit=unit,source=source,sourceFiles=identity['imageFiles'],protocolSHA256=sha(protocol),
    sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,
    retireGroups=[],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),
    unpackedBytes=sum((out/name).stat().st_size for name in names),donorArchiveSHA256=receipt['archiveSHA256'])
write(out/'config.json',json.dumps(config,indent=2)+'\n')
template=lab.parent/'framed-unpacked-return-r680/confirmation/remote-launch.py'
launcher=template.read_text(encoding='utf-8')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
launcher=launcher.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n",
                         " assert sha(root/'cpython-worker.py')==c['protocolSHA256']\n")
launcher=launcher.replace('lython-b1113-control-fixtures','lython-b1150-control-fixtures')
launcher=launcher.replace('RuntimeMaxSec=340','RuntimeMaxSec=260')
write(out/'remote-launch.py',launcher)
launch=(lab/'launch-quiet.py').read_text(encoding='utf-8').replace("/'quiet'","/'confirmation-corrected'").replace('435','185')
write(lab/'launch-confirmation.py',launch)
analyze=(lab/'summarize-quiet.py').read_text(encoding='utf-8').replace("quiet/retrieved/","confirmation-corrected/retrieved/")
analyze=analyze.replace("len(raw['jobs'])==7","len(raw['jobs'])==3").replace('quiet-summary.json','confirmation-summary.json')
write(lab/'summarize-confirmation.py',analyze)
print('Prepared three unchanged cases with reversed worker order and verified image reuse.')

