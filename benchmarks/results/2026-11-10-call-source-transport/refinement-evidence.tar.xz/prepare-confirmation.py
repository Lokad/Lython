from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile

h=Path(__file__).resolve().parent;repo=h.parents[3];old=h/'b556';d=h/'diagnostic-confirmed';p=h/'b557';p.mkdir()
source=json.loads((d/'identity.json').read_text(encoding='utf-8'));base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((h/'tree'/n).read_bytes()).hexdigest()==v for n,v in source['source']['candidate'].items())
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']in ['scripts.text-summary-helpers.large','scripts.csv-validated-records.large']];assert len(catalog['cases'])==2
(p/'representative.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
for a,b in [('images/candidate/Lokad.Lython.dll','current-core.dll'),('source.patch','source.patch'),('script-goldens.json','script-goldens.json')]:shutil.copyfile(d/a,p/b)
identity={**base,'sourceRevision':'R204 corrected native-selection refinement e7f365b5 versus fully qualified101. Original4de/41a adversity preserved; no full candidate qualification.', 'coreSHA256':{role:source['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'catalogSHA256':hashlib.sha256((p/'representative.json').read_bytes()).hexdigest()}
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'source-identity.json').write_text(json.dumps(dict(cores=source['cores'],sourceDifferences=source['sourceDifferences'],fullLocalIdentitySHA256=hashlib.sha256((d/'identity.json').read_bytes()).hexdigest(),purpose='Native dictionary/unary values remain in existing C# locals; general/function paths capture before effects. Eligibility precedes reads; no duplicate general reads. Same compiled frontend as original4de.'),indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('call-operands-b556-20261110','call-operands-b557-20261110').replace('lython-b556-call-operands-20261110','lython-b557-call-operands-20261110').replace('lython-b556-fixtures','lython-b557-fixtures').replace('B556','B557')
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:];s=s.replace('len(jobs)==5','len(jobs)==3').replace(' < 170',' < 110')
        a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R204 one corrected native-argument confirmation: existing managed locals avoid unnecessary packets; general sources captured once. Original adversity preserved; same exact selected scripts/fixtures/goldens. No compiler retiming for unchanged frontend"+s[b:]
    if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3')
    if name=='retrieve.py':s=s.replace("['jobs']==5","['jobs']==3").replace("['elapsedSeconds']<210","['elapsedSeconds']<150").replace('five-job','three-job')
    if name=='summarize.py':s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3')
    if name.endswith('.py'):ast.parse(s)
    (p/name).write_text(s,encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-10-call-source-transport/original/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();copies=[]
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz')as a:
    for name,paths in [('current-core.dll',['current-core.dll','candidate/Lokad.Lython.dll']),('representative.json',['representative.json']),('confirmation/confirmation.json',['confirmation/confirmation.json'])]:
        b=a.extractfile(name).read();copies.append(dict(paths=['call-operands-b556-20261110/'+v for v in paths],bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=canonical+':'+name))
copies.append(dict(paths=['call-operands-b556-20261110/observations.tgz'],bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical))
canonical='benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz')as a:b=a.extractfile('source-identity.json').read()
copies.append(dict(paths=['coarse-admission-b554-20261110/source-identity.json'],bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=canonical+':source-identity.json'))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R204 one bounded native-selection confirmation

Qualified101 vs corrected e7f365b5; three exact selected warm jobs: CSV, text,
async text. Four independent source/control processes,5s warmup/role and
7rotated400msrounds;150sowner/30stop/30margin. Same stockGC/tiering and full
semantic/ownership checks. Warm includes mediated RAM I/O, capture/projection,
prior-result cleanup; excludes reset/verification/protocol. Wider CPU coarse.
Original adversities and staging failures persist. Compiler unchanged: original
compile+0.72–1.01% allocation debt not relabelled or retimed. No current CPU claim.
Retire only exact committed4de/raw/archive copies and old metadata; keep
qualified039/E294/101, fixed240MiBfloor/12MiBheadroom. No unrelated cleanup.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
    for name in ['current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
payload=(p/'payload.tgz').read_bytes();(p/'footprint.json').write_text(json.dumps(dict(payloadBytes=len(payload),footprintBytes=footprint,requiredFreeBytes=252*1024*1024+max(3*len(payload),footprint),recoverableLogicalBytes=sum(c['bytes']for c in copies)),indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-catalog-corrected.py').read_text(encoding='utf-8').replace('call-operands-b556-20261110','call-operands-b557-20261110').replace('lython-b556-call-operands-20261110','lython-b557-call-operands-20261110').replace('call-operands-b556-catalog-corrected-launch.py','call-operands-b557-launch.py').replace('lython-b556-fixtures','lython-b557-fixtures').replace('jobs=5,ownerSeconds=210','jobs=3,ownerSeconds=150').replace('RuntimeMaxSec=210','RuntimeMaxSec=150').replace('seconds=270','seconds=210').replace('ownerSeconds=210','ownerSeconds=150')
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n');print((p/'footprint.json').read_text(encoding='utf-8'),flush=True)
