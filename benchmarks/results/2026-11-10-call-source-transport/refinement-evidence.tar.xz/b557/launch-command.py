from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1896466, 'payloadSHA256': 'c76805c3c793fd42ba96fa1e0eddb74194cdfdb66d0f1912db3f7cd067224dee', 'required': 270254080, 'copies': [{'paths': ['call-operands-b556-20261110/current-core.dll', 'call-operands-b556-20261110/candidate/Lokad.Lython.dll'], 'bytes': 5663744, 'sha256': '4de5dd92d4c2aa1358f2fc82b042bbdfa63b46c5f2cdb2b78d7bc36d2297befd', 'canonical': 'benchmarks/results/2026-11-10-call-source-transport/original/observations.tgz:current-core.dll'}, {'paths': ['call-operands-b556-20261110/representative.json'], 'bytes': 295672, 'sha256': '0ce933c35bc4088a7983d30e9e35547fa26031126e1bb0f1843b85050a173324', 'canonical': 'benchmarks/results/2026-11-10-call-source-transport/original/observations.tgz:representative.json'}, {'paths': ['call-operands-b556-20261110/confirmation/confirmation.json'], 'bytes': 458108, 'sha256': '10628fb3b59c2145639b48e6e6fdc1b2a64401875298b33d276adf7072b4f2ae', 'canonical': 'benchmarks/results/2026-11-10-call-source-transport/original/observations.tgz:confirmation/confirmation.json'}, {'paths': ['call-operands-b556-20261110/observations.tgz'], 'bytes': 3820707, 'sha256': '7c79e5e6173aa7c6b486c41f4ff080b5255e626d4dba6a77f1d6b24c3f64f1c1', 'canonical': 'benchmarks/results/2026-11-10-call-source-transport/original/observations.tgz'}, {'paths': ['coarse-admission-b554-20261110/source-identity.json'], 'bytes': 150523, 'sha256': '95815907080ef8ad395d64786831b02cde2e7ffdf35246643dff8f0d3ea497b8', 'canonical': 'benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz:source-identity.json'}], 'expectedCores': {'reference': '101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897', 'reference-control': '101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897', 'candidate': 'e7f365b51297df824dc5a2cf6651fee3c4d8b86007045a092a55d00ceccc9263', 'candidate-control': 'e7f365b51297df824dc5a2cf6651fee3c4d8b86007045a092a55d00ceccc9263'}}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'call-operands-b557-20261110';source=base/'transient-split-b555-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()==config['expectedCores']['reference']
 assert hashlib.sha256((base/'deferred-method-b548-20261110/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 prior=base/'json-cpython-b546-20261110/candidate/Lokad.Lython.dll'
 assert hashlib.sha256(prior.read_bytes()).hexdigest()=='e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for copy in config['copies']:
   paths=[base/v for v in copy['paths']];first=paths[0].lstat();key=(first.st_dev,first.st_ino)
   for path in paths:
    st=path.lstat()
    assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
    assert(st.st_dev,st.st_ino)==key and st.st_nlink==len(paths)
    assert st.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)==key:aliases.append(path.relative_to(base).as_posix())
   assert sorted(aliases)==sorted(copy['paths']),aliases
   reclaim+=first.st_blocks*512;retired.append(dict(copy,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:
   for path in copy['paths']:(base/path).unlink()
 assert shutil.disk_usage(base).free>config['required']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,qualified039AndPriorE294Preserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b557-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=3,ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b557-call-operands-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b557-call-operands-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
