# R204 one bounded native-selection confirmation

Qualified101 vs corrected e7f365b5; three exact selected warm jobs: CSV, text,
async text. Four independent source/control processes,5s warmup/role and
7rotated400msrounds;150sowner/30stop/30margin. Same stockGC/tiering and full
semantic/ownership checks. Warm includes mediated RAM I/O, capture/projection,
prior-result cleanup; excludes reset/verification/protocol. Wider CPU coarse.
Original adversities and staging failures persist. Compiler unchanged: original
compile+0.72–1.01% allocation debt not relabelled or retimed. No current CPU claim.
Retire only exact committed4de/raw/archive copies and old metadata; keep
qualified039/E294/101, fixed240MiBfloor/12MiBheadroom. No unrelated cleanup.
