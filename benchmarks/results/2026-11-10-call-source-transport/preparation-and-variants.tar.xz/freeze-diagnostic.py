from pathlib import Path
import hashlib,json,os,shutil,subprocess

h=Path(__file__).resolve().parent;t=h/'tree';repo=h.parents[3];old=h.parent/'transient-split-r203/diagnostic-refined';d=h/'diagnostic';d.mkdir()
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
green=json.loads((h.parent/'transient-split-r203/delivery-ci-terminal.json').read_text(encoding='utf-8-sig'))
assert green['conclusion']=='success'and green['headSha']=='dba779a5eadf98f3a95c6c2df20e6232953eeae2'
assert not subprocess.check_output(['git','diff','--','src','tests'],cwd=repo)
assert all(hashlib.sha256((repo/n).read_text(encoding='utf-8').encode()).hexdigest()==v for n,v in base['normalizedSource']['candidate'].items())
for name in ['retained-gates-internal-net11.0.log','default-metadata-net11.0.log','wide-error-spans-net11.0.log','phase-bcd-public-net11.0.log','phase-bcd-internal-net10.0.log','phase-bcd-public-net10.0.log']:
    assert 'Failed:     0' in (h/name).read_text(encoding='utf-8'),name
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',d/'images'/role)
assert hashlib.sha256((d/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()=='101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with(h/'freeze-candidate.log').open('w',encoding='utf-8')as log:
    run=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build',str(t/'src/Lokad.Lython/Lokad.Lython.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert run.returncode==0
shutil.copyfile(t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
raw={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
normalized={p.relative_to(t).as_posix():hashlib.sha256(p.read_text(encoding='utf-8').encode()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
differences=[n for n in normalized if normalized[n]!=base['normalizedSource']['candidate'][n]]
assert len(differences)==8,differences
assert not list((t/'tests/Lokad.Lython.Tests').glob('PreparedCallCensusDiagnostic.cs'))
for name in ['catalog.json','script-goldens.json','hash-witness.json']:shutil.copyfile(old/name,d/name)
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision='dba779a5, fully qualified GREEN42866605644; reused immutable R203 refined101 source-equivalent image after validating all568 normalized sources.',
    cores=dict(before=base['cores']['candidate'],candidate=hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()),
    source=dict(before=base['source']['candidate'],candidate=raw),normalizedSource=dict(before=base['normalizedSource']['candidate'],candidate=normalized),sourceDifferences=differences,
    freeze='Baseline reused from documented forced R203 build, now source-qualified by dba delivery; no source restore/retiming. Candidate forced nonincremental build. Same auxiliary bytes.',
    candidate='Logical native argument edges owned by graph nodes; remove NativeInput/NativeArgumentSource mutation. Existing forwarding pass removes48 pure argument loads; freeze tail once into original admitted packet, existing LiveExtent across context promotion. Shared wide-index cold error spans; full packet capacity retained.',
    catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),status='Focused checks/source census only; timing/promotion pending. No allocation/CPU prediction.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
script=(h.parent/'transient-split-r203/measure.py').read_text(encoding='utf-8').replace("[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds')]","[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds'),('compile','sync','elapsedMilliseconds')]")
assert "('compile','sync','elapsedMilliseconds')"in script
(h/'measure.py').write_text(script,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['cores'],sourceFiles=len(raw),sourceDifferences=differences),indent=2),flush=True)
