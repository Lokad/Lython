from pathlib import Path
import hashlib,json,os,shutil,subprocess

h=Path(__file__).resolve().parent;t=h/'tree';old=h/'diagnostic';d=h/'diagnostic-confirmed';d.mkdir()
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
for tfm in ['net11.0','net10.0']:
    for kind in ['internal','public']:assert 'Failed:     0' in (h/f'refinement1b-{kind}-{tfm}.log').read_text(encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(old/'images'/role,d/'images'/role)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with(h/'freeze-refinement1b.log').open('w',encoding='utf-8')as log:
    run=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build',str(t/'src/Lokad.Lython/Lokad.Lython.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert run.returncode==0
shutil.copyfile(t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
raw={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
normalized={p.relative_to(t).as_posix():hashlib.sha256(p.read_text(encoding='utf-8').encode()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
changed=[n for n in raw if raw[n]!=identity['source']['candidate'][n]]
assert len(changed)==3,changed
identity.update(originalCandidate=identity['cores']['candidate'],refinement='Only eligible native targets read logical operands, avoiding duplicate reads on general calls; native dictionary/unary operations consume values in existing C# locals; function/general calls retain funded snapshot before binding/promotion/effects. No new reader type/binder/pending state.')
identity['cores']['candidate']=hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest();identity['source']['candidate']=raw;identity['normalizedSource']['candidate']=normalized
identity['sourceDifferences']=[n for n in raw if normalized[n]!=identity['normalizedSource']['before'][n]]
for name in ['catalog.json','script-goldens.json','hash-witness.json']:shutil.copyfile(old/name,d/name)
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
s=(h/'measure.py').read_text(encoding='utf-8').replace("d=h/'diagnostic'","d=h/'diagnostic-confirmed'")
s=s.replace(",('compile','sync','elapsedMilliseconds')",'')
(h/'measure-confirmed.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['cores'],refinementSourceChanges=changed),indent=2),flush=True)
