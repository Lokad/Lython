from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile

h=Path(__file__).resolve().parent;repo=h.parents[3];d=h/'diagnostic';p=h/'b556';p.mkdir();old=h.parent/'transient-split-r203/b555'
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((h/'tree'/n).read_bytes()).hexdigest()==v for n,v in source['source']['candidate'].items())
for phase in ['warm','warm-async','compile']:
    raw=json.loads((d/phase/'measurements.json').read_text(encoding='utf-8'))
    assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
for a,b in [('catalog.json','representative.json'),('source.patch','source.patch'),('script-goldens.json','script-goldens.json')]:shutil.copyfile(d/a,p/b)
shutil.copyfile(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll')
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R204 on dba779a5: fully qualified immutable101 before, private4de5dd92 candidate. Only the eight recorded source files differ; no full candidate qualification.',
    coreSHA256={role:source['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},
    auxiliaryFiles=base['auxiliaryFiles'],protocolSHA256=base['protocolSHA256'],catalogSHA256=base['catalogSHA256'],performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'source-identity.json').write_text(json.dumps(dict(baseRevision=source['baseRevision'],cores=source['cores'],sourceDifferences=source['sourceDifferences'],fullLocalIdentitySHA256=hashlib.sha256((d/'identity.json').read_bytes()).hexdigest(),baseline='Reuse verified immutable101, whose568 normalized sources match fully qualified dba779a5; original forced freeze retained.'),indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async'],['scripts.text-summary-helpers.large','compile']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('transient-split-b555-20261110','call-operands-b556-20261110').replace('lython-b555-transient-split-20261110','lython-b556-call-operands-20261110').replace('lython-b555-fixtures','lython-b556-fixtures').replace('B555','B556')
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
        s=s.replace('len(jobs)==4','len(jobs)==5').replace(' < 140',' < 170')
        a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R204 shared call-source forwarding, original caller-packet capture and native logical-edge consolidation. Warm CSV/text/JSON, async text and compile text; independent controls, original desktop adversity and compile allocation debt preserved"+s[b:]
    if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
    if name=='retrieve.py':s=s.replace("['jobs']==4","['jobs']==5").replace("['elapsedSeconds']<180","['elapsedSeconds']<210").replace('four-job','five-job')
    if name=='summarize.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
    if name.endswith('.py'):ast.parse(s)
    (p/name).write_text(s,encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-10-transient-split-iteration/quiet/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();copies=[]
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz')as a:
    for name,paths in [('baseline-core.dll',['baseline-core.dll','reference/Lokad.Lython.dll']),('representative.json',['representative.json']),('confirmation/confirmation.json',['confirmation/confirmation.json'])]:
        b=a.extractfile(name).read();copies.append(dict(paths=['transient-split-b555-20261110/'+v for v in paths],bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=canonical+':'+name))
copies.append(dict(paths=['transient-split-b555-20261110/observations.tgz'],bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R204 bounded call-source comparison

Fully qualified dba779a5/immutable101 before versus focused-tested4de5dd92.
Logical native argument edges move into graph nodes; existing forwarding pass
eliminates48 pure argument loads. Original caller-owned packet freezes before
effects and survives context promotion via existing live extent. Capacity stays
funded; no new binder, pending state, arena, quota or engine. Five jobs: warm CSV,
text, JSON; async text; text compilation. Four independent source/control workers,
5s warmup/role,7rotated400msrounds;210sowner/30stop/30margin. Normal GC/tiering.
Warm clocks include mediated RAM I/O/capture/projection/prior-result cleanup;
compile includes prior-script disposal. Reset/verification/protocol are outside,
external CPU wider/coarse. Original sync CSV and async/control adversity retained,
compile allocation+0.72–1.01% stays explicit. No current CPython or speedup claim.
Reuse qualified101 and same auxiliaries; retire only Git-verified old1ac aliases
and exact B555 raw/archive duplicates. Keep039/priorE294/101,240MiBfloor/12MiBheadroom.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
    for name in ['current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
payload=(p/'payload.tgz').read_bytes();(p/'footprint.json').write_text(json.dumps(dict(payloadBytes=len(payload),footprintBytes=footprint,requiredFreeBytes=252*1024*1024+max(3*len(payload),footprint),recoverableLogicalBytes=sum(c['bytes']for c in copies)),indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('transient-split-b555-20261110','call-operands-b556-20261110').replace('lython-b555-transient-split-20261110','lython-b556-call-operands-20261110').replace('transient-split-b555-launch.py','call-operands-b556-launch.py').replace('lython-b555-fixtures','lython-b556-fixtures')
s=s.replace("source=base/'deferred-method-b548-20261110/candidate'","source=base/'transient-split-b555-20261110/candidate'")
s=s.replace("[('baseline-core.dll','reference'),('current-core.dll','candidate')]","[('current-core.dll','candidate')]")
s=s.replace("assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'","assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()==config['expectedCores']['reference']\n assert hashlib.sha256((base/'deferred-method-b548-20261110/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'")
s=s.replace("shutil.copyfile(protocol,root/'cpython-worker.py')","shutil.copyfile(protocol,root/'cpython-worker.py')\n os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')")
s=s.replace('jobs=4,ownerSeconds=180','jobs=5,ownerSeconds=210').replace('RuntimeMaxSec=180','RuntimeMaxSec=210').replace('seconds=240','seconds=270').replace('ownerSeconds=180','ownerSeconds=210')
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print((p/'footprint.json').read_text(encoding='utf-8'),flush=True)
