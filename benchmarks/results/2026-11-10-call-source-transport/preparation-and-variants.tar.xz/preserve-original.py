from pathlib import Path
import hashlib,json,shutil,tarfile

h=Path(__file__).resolve().parent;repo=h.parents[3];out=repo/'benchmarks/results/2026-11-10-call-source-transport';out.mkdir();q=h/'b556'
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
quiet=out/'original';quiet.mkdir()
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','summary.json','identity.json']:shutil.copyfile(q/name,quiet/name)
for variant in ['diagnostic','diagnostic-refined']:
    dest=out/('desktop-original'if variant=='diagnostic'else'desktop-refinement1');dest.mkdir()
    for phase in ['warm','warm-async','compile']:
        if not(h/variant/phase).exists():continue
        (dest/phase).mkdir()
        for name in ['measurements.json','summary.json','stderr.txt']:shutil.copyfile(h/variant/phase/name,dest/phase/name)
with tarfile.open(out/'preparation-and-variants.tar.xz','w:xz')as a:
    for path in sorted(h.iterdir()):
        if path.is_file()and path.suffix in ['.py','.json','.log','.cs']:a.add(path,arcname=path.name)
    for variant in ['diagnostic','diagnostic-refined','diagnostic-confirmed']:
        for name in ['identity.json','source.patch','script-goldens.json','catalog.json','hash-witness.json']:
            a.add(h/variant/name,arcname=variant+'/'+name)
    a.add(h/'diagnostic-refined/images/candidate/Lokad.Lython.dll',arcname='refinement1-core-41a.dll')
    a.add(h/'diagnostic-confirmed/images/candidate/Lokad.Lython.dll',arcname='selection-corrected-core-e7.dll')
    for path in sorted(q.iterdir()):
        if path.is_file()and path.suffix in ['.py','.json','.log','.md','.sh']:
            a.add(path,arcname='b556/'+path.name)
    for name in ['space-recovery.json','setup.json']:a.add(q/'retrieved'/name,arcname='b556/'+name)
(out/'README.md').write_text('''# R204 — call-source transport (active prototype)

2026-11-10. Baseline immutable101ba9d3 has all568 normalized sources equal to
fully qualified dba779a5. Original candidate4de5dd92, first refinement41a76b3f,
selection-corrected refinemente7f365b5 remain isolated. **No source promotion or
speedup claim.** Publication remains held. [Preparation, all source patches/images,
census, staged tests and original failures](preparation-and-variants.tar.xz).

The existing forwarding pass removes48 pure argument-load instructions across
five module bodies. Logical native-call dependencies move into native graph nodes,
removing NativeInput/NativeArgumentSource mutation from ordinary argument forms.
Cold operand error spans use full input indexes for wide calls. Original full
caller-packet capacity stays admitted; existing live extent records captured inputs
across context promotion. No new binder, arena, pending state, quotas or engine.
Static instruction counts are not dynamic execution counts or removable CPU shares.

Original focused checks pass52internal/464public each actualNET11/10 (stagedNET11),
plus104namespace/import/stack/terminal-admission cases each. Wide-argument errors
preserve spans before effects; actual I/O, cancellation, aliases, memory refusal,
cleanup and budget reuse pass. The private census fixture was removed, not retained
as an exact-architecture test. Candidate force-built nonincrementally; immutable
baseline reused with its original forced-build/source proof. Same worker/auxiliaries.

Original desktop sync text −5.46..−6.85%elapsed, CSV +4.63..+5.15%; async/control
spread leaves other cases inconclusive. Warm allocation is flat. Compilation
allocation +0.72..+1.01% is established debt; elapsed is uncertain. Original full
five-script catalog and all three phase observations survive under desktop-original/.

B556: five jobs180.631s, F4as_v7 Ubuntu24.04.4/.NET11RC3, stock GC/tiering,
four independent source/control workers,5s warmup/role and7rotated400msrounds.
All identity/golden/ownership/quiet/join/RAM/archive/localSHA gates pass.

| Complete script / phase | Elapsed change | Wider process CPU change |
| --- | ---: | ---: |
| CSV validation / warm | −3.55..+0.66% | −4.49..0% |
| Text helpers / warm | +5.28..+6.07% | +2.71..+6.06% |
| JSON-lines helpers / warm | −1.05..+1.57% | −2.38..−0.62% |
| Text helpers / async warm | −1.03..+3.20% | 0..+3.52% |
| Text helpers / compile | −1.69..−0.10% | −0.06..+1.23% |

Ranges compare both candidates with both references, not confidence intervals.
Sync text adversity has supporting CPU with reference/candidate spreads0.57/0.17%.
CSV reference spread4.23%, JSON mixed clocks and async candidate spread3.95% leave
those effects uncertain. Compile CPU is inconclusive. [Raw observations/cores](original/observations.tgz),
[medians/controls](original/summary.json), [receipt](original/archive-receipt.json).
Warm clocks include mediated RAM I/O/capture/projection/prior-result cleanup;
compile includes prior-script disposal. Fixture reset/verification/protocol are
outside; wider CPU includes surrounds/coarse ticks. No new CPython measurements.

Source-guided refinement: folding loads still materializes every caller packet.
Selected native dictionary/unary operations can retain values in their existing
C# locals; function/general calls keep the existing funded snapshot. First variant
passes52internal/267public each target but desktop remains adverse/inconclusive.
Its eligibility check read some general-call arguments twice before fallback;
the selection correction removes that introduced duplicate work. The corrected
variant passes the same gates. One short controlled confirmation is pending;
the complete milestone will be retained or removed with explicit regression debt.
The logical-edge move alone will not be promoted as an unrelated isolated win.

Two original staging failures had zero timed jobs, no acknowledged unit and no
deletions: insufficient fixed headroom, then a missing already-archived R197 raw
copy. That missing path must not be probed again. Final staging transfers only
the three cases used by the same five jobs, preserving every case field/source/
fixture/golden; original full catalog and failed commands remain. The fixed
240MiBfloor/12MiBheadroom stays unchanged. Only all-alias/UID/path/SHA verified
old1ac/B555 canonical copies were retired; qualified039/priorE294/current101 survive.
No remaining B556 users/RAM; terminal cached. Independent development continues.
''',encoding='utf-8',newline='\n')
print('Original evidence preserved:',out.relative_to(repo).as_posix(),flush=True)
