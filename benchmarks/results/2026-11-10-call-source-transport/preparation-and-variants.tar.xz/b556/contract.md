# R204 bounded call-source comparison

Fully qualified dba779a5/immutable101 before versus focused-tested4de5dd92.
Logical native argument edges move into graph nodes; existing forwarding pass
eliminates48 pure argument loads. Original caller-owned packet freezes before
effects and survives context promotion via existing live extent. Capacity stays
funded; no new binder, pending state, arena, quota or engine. Five jobs: warm CSV,
text, JSON; async text; text compilation. Four independent source/control workers,
5s warmup/role,7rotated400msrounds;210sowner/30stop/30margin. Normal GC/tiering.
Warm clocks include mediated RAM I/O/capture/projection/prior-result cleanup;
compile includes prior-script disposal. Reset/verification/protocol are outside,
external CPU wider/coarse. Original sync CSV and async/control adversity retained,
compile allocation+0.72–1.01% stays explicit. No current CPython or speedup claim.
Reuse qualified101 and same auxiliaries; retire only Git-verified old1ac aliases
and exact B555 raw/archive duplicates. Keep039/priorE294/101,240MiBfloor/12MiBheadroom.
