using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Tests;

// Private source census only. No execution, timing or permanent architecture test.
public sealed class PreparedCallCensusDiagnostic
{
    [Fact]
    public void WriteCurrentCallShapes()
    {
        using var catalog = JsonDocument.Parse(File.ReadAllText(Environment.GetEnvironmentVariable("LYTHON_CALL_CENSUS_CATALOG")!, Encoding.UTF8));
        var rows = new List<object>();
        foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
        {
            var source = item.GetProperty("source").GetString()!;
            Assert.Equal(item.GetProperty("sourceSha256").GetString(), Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(source))));
            var frontend = LythonFrontend.Compile(source);
            Assert.DoesNotContain(frontend.Diagnostics, d => d.Severity == LythonDiagnosticSeverity.Error);
            var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
            Read(item.GetProperty("id").GetString()!, code, source);
        }
        File.WriteAllText(Environment.GetEnvironmentVariable("LYTHON_CALL_CENSUS_OUTPUT")!, JsonSerializer.Serialize(new
        {
            revision = "dba779a5",
            purpose = "Static compiled source census; no dynamic execution counts, eliminated-cost estimate or predicted CPU gain.",
            rows,
        }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));

        void Read(string scope, ExecutableCodeObject code, string source)
        {
            var entries = new HashSet<int> { code.EntryIndex };
            foreach (var instruction in code.Instructions)
            {
                if (instruction.OpCode is ExecutableOpCode.Jump or ExecutableOpCode.AbruptJump or ExecutableOpCode.JumpIfFalse
                    or ExecutableOpCode.CompareJumpIfFalse or ExecutableOpCode.ForNext or ExecutableOpCode.EndFinally)
                    entries.Add(instruction.TargetIndex);
                if (instruction.OpCode == ExecutableOpCode.MatchCase) entries.Add(instruction.FailureIndex);
            }
            foreach (var region in code.ExceptionRegions)
            {
                entries.Add(region.ProtectedStartIndex);
                if (region.ExceptIndex is { } handler) entries.Add(handler);
                if (region.FinallyIndex is { } cleanup) entries.Add(cleanup);
            }
            var calls = new List<object>();
            var blockStart = 0;
            for (var index = 0; index < code.Instructions.Length; index++)
            {
                if (entries.Contains(index)) blockStart = index;
                var instruction = code.Instructions[index];
                if (instruction.OpCode != ExecutableOpCode.Call) continue;
                var site = code.CallSites[instruction.CallSiteIndex];
                var tail = new List<object>();
                for (var argument = site.ArgumentCount - 1; argument >= 0; argument--)
                {
                    var at = index - (site.ArgumentCount - argument);
                    if (at < blockStart) break;
                    var leaf = code.Instructions[at];
                    if (leaf.HasLocalResult || leaf.OpCode is not (ExecutableOpCode.LoadLocal or ExecutableOpCode.LoadConst)) break;
                    var eligible = leaf.OpCode == ExecutableOpCode.LoadConst || !code.RequiresLocalVariableMirroring
                        && !code.CapturedLocalSlots.Contains(leaf.LocalSlot);
                    tail.Add(new { argument, operation = leaf.OpCode.ToString(), eligible,
                        source = leaf.OpCode == ExecutableOpCode.LoadConst ? ~leaf.ConstantIndex : leaf.LocalSlot,
                        leaf.Span.Line, leaf.Span.Column });
                    if (!eligible) break;
                }
                calls.Add(new { index, instruction.CallSiteIndex, site.ArgumentCount, site.HasReceiver, site.IsPositionalOnly,
                    site.ConsumedByIteration, site.StackArgumentCount, site.CallSpan.Line, site.CallSpan.Column,
                    source = source.Substring(site.CallSpan.Start, site.CallSpan.Length),
                    forms = site.Arguments.Select(a => a.Kind.ToString()).ToArray(),
                    runtimeSources = site.Arguments.Select(a => a.RuntimeInput).ToArray(), tail });
            }
            rows.Add(new { scope, code.FirstTemporarySlot, code.ValueStorageCapacity, code.RequiresLocalVariableMirroring,
                nativeBody = code.NativeBody is not null,
                instructionCounts = code.Instructions.GroupBy(i => i.OpCode.ToString()).ToDictionary(g => g.Key, g => g.Count()), calls });
            foreach (var function in code.Functions) Read(scope + "/" + function.Name, function.CodeObject, source);
        }
    }
}
