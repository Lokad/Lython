#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/machine-arithmetic-cpython-20261122
white='Category!=Stress&(FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~IntegerBinaryAdmission|FullyQualifiedName~ManagedStack|FullyQualifiedName~Regex)'
public='Category!=Stress&(FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~IntegerBinarySemantics|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~Regex)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" > "$dir/white-ubuntu.log" 2>&1 || { tail -45 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" > "$dir/public-ubuntu.log" 2>&1 || { tail -65 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"