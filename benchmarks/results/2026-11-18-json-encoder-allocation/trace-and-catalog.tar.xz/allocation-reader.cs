using System.Text.Json;
using Microsoft.Diagnostics.Tracing;

var types = new Dictionary<string, (int Samples, long Weight)>();
using (var source = new EventPipeEventSource(args[0]))
{
    source.Clr.GCAllocationTick += data =>
    {
        var name = data.TypeName ?? "<unknown>";
        types.TryGetValue(name, out var before);
        types[name] = (before.Samples + 1, before.Weight + (long)data.AllocationAmount64);
    };
    source.Process();
}
var total = types.Values.Sum(v => v.Weight);
var rows = types.OrderByDescending(p => p.Value.Weight).Select(p => new
{
    Type = p.Key, p.Value.Samples, SampleWeightBytes = p.Value.Weight,
    SampleWeightPercent = total == 0 ? 0 : 100.0 * p.Value.Weight / total
}).ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(new
{
    Boundary = "One local warmed complete-worker EventPipe GC allocation sample. Tick weight is approximate attribution to the sampled type, not exact allocated bytes, object counts or removable CPU. Includes reset, I/O, validation and protocol.",
    Samples = rows.Sum(r => r.Samples), TotalSampleWeight = total, Rows = rows
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", System.Text.Encoding.UTF8);
foreach (var row in rows.Take(16)) Console.WriteLine($"{row.Type}: {row.Samples} ticks, {row.SampleWeightPercent:F2}% approximate weight");
