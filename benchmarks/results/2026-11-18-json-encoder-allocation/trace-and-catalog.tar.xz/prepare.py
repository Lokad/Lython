from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import os
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
previous = lab.parent / 'native-json-encoding-options-r540'
image = previous / 'frozen/candidate'
spec = importlib.util.spec_from_file_location('protocol', repo / 'benchmarks/cpython-worker.py')
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
python = 'C:/Python313/python.exe'
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])

def sha(data):
    return hashlib.sha256(data).hexdigest()

catalog = json.loads((previous / 'representative.json').read_text(encoding='utf-8'))
small = next(c for c in catalog['cases'] if c['id'] == 'scripts.config-manifest.small')
fixture = json.loads(small['fixtureJson'])
inputs = {k:base64.b64decode(v) for k,v in fixture['inputFiles'].items()}
config = json.loads(inputs['config.json'])
original = config['targets']
size = 256
config['targets'] = [dict(original[i % len(original)], name=f"Service-{i:03}", path=f" ./src/service-{i:03} ") for i in range(size)]
inputs['config.json'] = (json.dumps(config, ensure_ascii=False, indent=2) + '\n').encode()
with tempfile.TemporaryDirectory(prefix='lython-manifest-golden-') as tmp:
    folder = Path(tmp)
    for name, data in inputs.items():
        (folder / name).write_bytes(data)
    reference = subprocess.run([python, '-I', '-S', '-X', 'utf8', '-'], input=small['source'].encode(), cwd=folder,
                               capture_output=True, check=True, timeout=20)
    assert not reference.stderr
    outputs = {name:(folder / name).read_bytes() for name in fixture['outputFiles']}
out = reference.stdout.replace(b'\r\n', b'\n')
expected_count = sum(t.get('enabled', True) for t in config['targets'])
assert int(out.split()[0]) == expected_count and len(json.loads(outputs['manifest.json'])['targets']) == expected_count
encode = lambda value: base64.b64encode(value).decode('ascii')
fixture.update(size=size, inputFiles={k:encode(v) for k,v in inputs.items()}, outputFiles={k:encode(v) for k,v in outputs.items()})
fixture_json = json.dumps(fixture, ensure_ascii=False, separators=(',', ':'))
case = dict(small, id='scripts.config-manifest.deep-records', scale='medium', size=size, fixtureJson=fixture_json,
            fixtureSha256=sha(fixture_json.encode()), expectedOutput=out.decode(), expectedOutputSha256=sha(out),
            expectedOutputUtf8Bytes=len(out), expectedFilesSha256=protocol.file_digest(outputs))
catalog['cases'] = [case]
catalog['performanceQualified'] = False
path = lab / 'catalog.json'
path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
identity = json.loads((previous / 'frozen-identity.json').read_text(encoding='utf-8'))
files = identity['imageFiles']['candidate']
assert len(files) == 32 and all(sha((image / name).read_bytes()) == h for name,h in files.items())
with (lab / 'verify.log').open('w',encoding='utf-8') as log:
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', path,
                    '--dotnet', dotnet, '--python', python, '--python-worker', repo / 'benchmarks/cpython-worker.py',
                    '--out', lab / 'verification.json'], cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=90)
print(size, 'source targets,', expected_count, 'emitted targets;', sum(map(len,inputs.values())), 'input bytes,',
      sum(map(len,outputs.values())), 'output bytes; actual-image verification passed', flush=True)
