from pathlib import Path
import datetime
import hashlib
import json
import subprocess

r=Path(__file__).resolve().parent/"quiet"
config=json.loads((r/"config.json").read_text(encoding="utf-8"))
root=config["root"]
original=config["unit"]
corrected=original+"-corrected"
payload=dict(root=root, original=original, corrected=corrected, identity=config["identity"],
             purpose="Replace per-container encoder frames with governed value capacity and live sequence positions")
script=r"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, tarfile
root=Path(PARAMETERS['root'])
assert root==root.resolve() and root.parent==Path('/home/lokad/lython-bench-checks')
original=PARAMETERS['original']+'.service'
corrected=PARAMETERS['corrected']+'.service'
fixture=root/'guest-fixtures'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def state(service):
 return subprocess.check_output(['systemctl','show',service,'--property=LoadState,ActiveState,MainPID,ExecMainStatus'],text=True)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 old=state(original)
 assert 'ActiveState=failed'in old and 'MainPID=0'in old and 'ExecMainStatus=1'in old
 new_state=subprocess.run(['systemctl','show',corrected,'--property=LoadState,MainPID'],capture_output=True,text=True).stdout
 assert 'LoadState=not-found'in new_state and 'MainPID=0'in new_state
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True)
 assert workers.returncode==1,workers.stdout
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert fixture.resolve()==fixture and os.path.ismount(fixture) and not list(fixture.iterdir())
 assert fixture.stat().st_uid==os.getuid()
 journal=subprocess.check_output(['journalctl','-u',original,'-n','25','--no-pager'],text=True)
 assert "KeyError: 'purpose'" in journal
 identity=json.loads((root/'identity.json').read_text())
 assert identity==PARAMETERS['identity'] and 'purpose'not in identity
 for role,entries in identity['imageFiles'].items():
  for n,h in entries.items():assert sha(root/role/n)==h,(role,n)
 assert sha(root/'representative.json')==identity['catalogSHA256']
 failed=root/'failed-purpose'
 failed.mkdir()
 (failed/'service.txt').write_text(old)
 (failed/'journal.txt').write_text(journal)
 for n in ['identity.json','collect.py','run.sh','exit-code.txt']:
  shutil.copyfile(root/n,failed/n)
 (root/'confirmation').rename(failed/'confirmation')
 evidence=root/'failed-purpose.tar.gz'
 with tarfile.open(evidence,'w:gz')as archive:
  archive.add(failed,arcname=failed.name)
 with tarfile.open(evidence)as archive:
  for p in failed.rglob('*'):
   if p.is_file():assert archive.extractfile(p.relative_to(root).as_posix()).read()==p.read_bytes()
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True)
 fixture.rmdir()
 identity['purpose']=PARAMETERS['purpose']
 (root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
 assert shutil.disk_usage(root).free>254*1024*1024
 fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b974-corrected-fixtures',str(fixture)],check=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit='+PARAMETERS['corrected'],'--property=User=lokad','--property=WorkingDirectory='+str(root),
                 '--property=RuntimeMaxSec=330','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True)
 fixture.rmdir()
 raise
print(json.dumps(dict(launched=True,unit=PARAMETERS['corrected'],root=str(root),failedArchiveSHA256=sha(evidence),freeBytes=shutil.disk_usage(root).free)))
""".replace('PARAMETERS',repr(payload))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,timeout=65)
(r/"correction-launch.log").write_text(done.stdout+done.stderr,encoding="utf-8",newline="\n")
assert done.returncode==0,done.stderr
launched=json.loads(done.stdout.splitlines()[-1])
assert launched["unit"]==corrected
config["unit"]=corrected
config["identity"]["purpose"]=payload["purpose"]
(r/"corrected-config.json").write_text(json.dumps(config,indent=2)+"\n",encoding="utf-8",newline="\n")
retrieve=(r/"retrieve.py").read_text(encoding="utf-8").replace("'config.json'","'corrected-config.json'").replace("'observe-not-before.json'","'corrected-observe-not-before.json'")
(r/"retrieve-corrected.py").write_text(retrieve,encoding="utf-8",newline="\n")
now=datetime.datetime.now(datetime.timezone.utc)
(r/"corrected-observe-not-before.json").write_text(json.dumps(dict(
    launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=255)).isoformat()),indent=2)+"\n",encoding="utf-8")
print(done.stdout,flush=True)
