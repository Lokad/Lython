from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor = lab.parent.parent/"native-json-encoding-options-r540"
work = repo/".git/agent-worktrees/json-encoder-frames"
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, value):
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")

for framework in ("net11.0", "net10.0"):
    results = (lab.parent/f"prototype-final-focus-{framework}.log").read_text(encoding="utf-8-sig")
    assert results.count("Passed!") == 2 and "Failed!" not in results, results[-600:]
assert "Build succeeded." in (lab.parent/"prototype-final-build.log").read_text(encoding="utf-8-sig")
base = donor/"frozen/candidate"
core = "Lokad.Lython.dll"
candidate = work/"src/Lokad.Lython/bin/Release/net11.0"/core
assert sha(candidate) == sha(work/"benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0"/core)
manifest = read(donor/"frozen-identity.json")["imageFiles"]["candidate"]
assert len(manifest)==32 and all(sha(base/n)==h for n,h in manifest.items())
representative = read(donor/"representative.json")
scaled = read(lab.parent/"catalog.json")["cases"][0]
representative["cases"] = [c for c in representative["cases"] if c["id"] in ("scripts.config-manifest.small","calls.positional.large")]
representative["cases"].insert(0,scaled)
assert len(representative["cases"])==3
catalog = lab/"representative.json"
save(catalog,representative)
images = {}
for role, source in [("reference",base/core),("candidate",candidate)]:
    image = lab/"frozen"/role
    image.mkdir(parents=True)
    for n in manifest:
        shutil.copyfile(source if n==core else base/n,image/n)
    for file in base.glob("ValidatedAllocation.*"):
        shutil.copyfile(file,image/file.name)
    images[role] = {n:sha(image/n) for n in manifest}
    assert images[role] == manifest | {core:sha(source)}
    with (lab/f"{role}-verification.log").open("w",encoding="utf-8") as log:
        subprocess.run([dotnet, image/"Lokad.Lython.Benchmarks.dll", "--compare","verify","--catalog",catalog,"--dotnet",dotnet,
                        "--python","C:/Python313/python.exe","--python-worker",repo/"benchmarks/cpython-worker.py",
                        "--out",lab/f"{role}-verification.json"],env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,lab/f"{role}-allocation.json"],env=env,cwd=repo,check=True,timeout=90)
    assert all(sha(image/n)==h for n,h in images[role].items())
    print(role,images[role][core],"three goldens and allowance reuse verified",flush=True)
save(lab/"frozen-identity.json",dict(sourceRevision="bdab88c54 versus final governed encoder frame prototype",
     imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin="0.4.0",
     coreSHA256={label:images[role][core] for role in images for label in (role,role+"-control")}))
(lab/"prototype.patch").write_bytes(subprocess.check_output(["git","-C",work,"diff","--binary","bdab88c54","--","src"]))
