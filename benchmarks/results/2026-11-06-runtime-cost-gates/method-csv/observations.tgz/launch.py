from pathlib import Path
import subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/method-frame-b327-20261106')
root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b327-payload.tgz') as t:t.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b327-method-frame-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=60','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
