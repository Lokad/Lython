from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
prior=lab.parent/'direct-affix-return-20261126'
template=prior/'comparison/quiet'
reference=lab.parent/'short-path-cpython-20261126/comparison/quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data): path.write_text(data,encoding='utf-8',newline='\n')
def save(path,data): write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

manifest=read(lab/'identity.json')
prior_id=read(reference/'identity.json')
assert manifest['sourceRevision']==prior_id['sourceRevision']
assert manifest['imageFiles']['reference']==prior_id['imageFiles']['candidate']
receipt=read(reference/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(reference/'observations.tar.xz')==receipt['archiveSHA256']
for role,files in manifest['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
    verification=read(lab/f'{role}-verify.json')
    assert verification['state']=='Completed' and verification['caseCount']==3
    assert verification['catalogSha256']==manifest['catalogSHA256']
    assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
shutil.copyfile(lab/'representative.json',quiet/'representative.json')
shutil.copyfile(reference/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==manifest['cpythonWorkerSHA256']
save(quiet/'jobs.json',{'warm':[
    ['scripts.json-summary-helpers.decimal-4096-digits','warm-async'],
    ['scripts.json-summary-helpers.large','warm-async'],
    ['scripts.json-summary-helpers.decimal-40-digits','warm-async'],
]})
manifest['coreSHA256'].update({role+'-control':manifest['coreSHA256'][role] for role in manifest['imageFiles']})
manifest['catalogs']={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')}
manifest['purpose']='Bounded confirmation of wide JSON integer parsing and an unchanged JSON control.'
save(quiet/'identity.json',manifest)
body=(template/'collect.py').read_text(encoding='utf-8-sig').replace('lython-b1746-fixtures','lython-b1751-fixtures')
body=body.replace('len(jobs) == 5','len(jobs) == 3')
tree=ast.parse(body)
required={node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript)
          and isinstance(node.value,ast.Name) and node.value.id=='identity' and isinstance(node.slice,ast.Constant)}
assert required<=manifest.keys(),required-manifest.keys()
write(quiet/'collect.py',body)
shutil.copyfile(template/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()

source=(prior/'quiet.py').read_text(encoding='utf-8-sig')
source=source.replace('lython-b1746b-direct-affix-return-20261126','lython-b1751-json-magnitude-utf8-20261126')
source=source.replace(" donor=base/'native-cursor-stack-b1743-20261126'/'candidate'",
                      " donor=base/'short-path-cpython-b1750-20261126'/'candidate'")
source=source.replace(" assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==sha(donor.parent/'observations.tar.xz')",
                      " assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')")
source=source.replace("verified['caseCount']==4","verified['caseCount']==3")
source=source.replace('RuntimeMaxSec=320','RuntimeMaxSec=210').replace('seconds=263','seconds=170')
compile(source,'quiet.py','exec'); write(lab/'quiet.py',source)
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as arc:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        arc.add(quiet/name,arcname=name,recursive=False)
    arc.add(lab/'candidate/Lokad.Lython.dll',arcname='new-core.dll',recursive=False)
save(quiet/'upload.json',dict(root='json-magnitude-utf8-b1751-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
     donorSHA256=receipt['archiveSHA256']))
