from pathlib import Path
from statistics import median
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
prior=lab.parent/'json-integer-r46'
driver=lab.parent/'integer-utf8-r45/tool/out/complete-jobs.dll'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet))
manifest=json.loads((lab/'identity.json').read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

for role,files in manifest['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
catalog=prior/'catalog.json'
record=[]
for api in ('sync','async'):
    out=lab/f'warm-{api}'
    out.mkdir()
    witness=out/'hash-witness.json'
    witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
    with (out/'measurements.json').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        subprocess.run([dotnet,driver,lab/'reference/Lokad.Lython.Benchmarks.dll',lab/'candidate/Lokad.Lython.Benchmarks.dll',
                        catalog,witness,'reverse' if api=='sync' else 'forward','warm',api],env=env,stdout=stdout,
                       stderr=stderr,check=True,timeout=60)
    diagnostic=json.loads((out/'measurements.json').read_text(encoding='utf-8'))
    assert all(diagnostic[key] for key in ('allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'))
    assert diagnostic['asynchronous']==(api=='async') and diagnostic['catalogSHA256'].lower()==sha(catalog)
    for row in diagnostic['observations']:
        for role,files in row['identities'].items():
            assert files['Lokad.Lython.dll'].lower()==manifest['coreSHA256']['candidate' if role=='candidate' else 'reference']
        labels=('before','before-control','candidate')
        medians={label:{field:median(p[field]/p['jobs'] for p in row['samples'] if p['image']==label)
                             for field in ('allocatedBytes','elapsedMilliseconds','cpuMilliseconds')} for label in labels}
        elapsed=[100*(medians['candidate']['elapsedMilliseconds']/medians[label]['elapsedMilliseconds']-1) for label in labels[:2]]
        record.append(dict(case=row['caseId'],api=api,median=medians,elapsedChangePercent=elapsed,admittedPeaks=row['admittedPeaks']))
        print(api,row['caseId'],[round(value,2) for value in elapsed],flush=True)
(lab/'local-timing-summary.json').write_text(json.dumps(dict(driverSHA256=sha(driver),catalogSHA256=sha(catalog),rows=record),indent=2)+'\n',encoding='utf-8')
