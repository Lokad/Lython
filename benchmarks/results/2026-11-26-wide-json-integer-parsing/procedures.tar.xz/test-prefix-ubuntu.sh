set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/json-magnitude-utf8-20261126"
filter='FullyQualifiedName~JsonNumberExecutionTests&Category!=Stress'
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/prefix-ubuntu.log" 2>&1 || { tail -60 "$lab/prefix-ubuntu.log"; exit 1; }
tail -5 "$lab/prefix-ubuntu.log"
