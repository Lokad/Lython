using System.Diagnostics;
using System.Globalization;
using System.Numerics;
using System.Text;

foreach (var length in new[] { 20, 39, 40, 64, 100, 127, 128, 256, 512, 4096 })
{
    var raw = Encoding.ASCII.GetBytes("-" + new string('9', length));
    var wanted = Transcoded(raw);
    const int repetitions = 256;
    foreach (var (name, parse) in new (string, ParseNumber)[]
    {
        ("transcoded", Transcoded), ("native", Native), ("native-sign", NativeSign), ("chars", Chars)
    })
    {
        if (parse(raw) != wanted) throw new InvalidOperationException("Magnitude differs");
        for (var i = 0; i < 64; i++) _ = parse(raw);
        var before = GC.GetAllocatedBytesForCurrentThread();
        var started = Stopwatch.GetTimestamp();
        var number = BigInteger.Zero;
        for (var i = 0; i < repetitions; i++) number = parse(raw);
        var elapsed = Stopwatch.GetElapsedTime(started).TotalMicroseconds / repetitions;
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        if (number != wanted) throw new InvalidOperationException("Magnitude differs");
        Console.WriteLine($"{length} {name} {bytes / (double)repetitions:F2} B {elapsed:F3} µs");
    }
}
static BigInteger Transcoded(ReadOnlySpan<byte> input) => BigInteger.Parse(Encoding.UTF8.GetString(input), CultureInfo.InvariantCulture);
static BigInteger Native(ReadOnlySpan<byte> input) => BigInteger.Parse(input, CultureInfo.InvariantCulture);
static BigInteger NativeSign(ReadOnlySpan<byte> input) => BigInteger.Parse(input, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture);
static BigInteger Chars(ReadOnlySpan<byte> input)
{
    Span<char> characters = input.Length <= 128 ? stackalloc char[128] : new char[input.Length];
    var count = Encoding.UTF8.GetChars(input, characters);
    return BigInteger.Parse(characters[..count], CultureInfo.InvariantCulture);
}
delegate BigInteger ParseNumber(ReadOnlySpan<byte> input);
