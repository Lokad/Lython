using System.Globalization;
using System.Numerics;
using System.Reflection;
using System.Runtime.Versioning;
var type = typeof(BigInteger);
Console.WriteLine(System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription);
Console.WriteLine(Assembly.GetExecutingAssembly().GetCustomAttribute<TargetFrameworkAttribute>()?.FrameworkName);
foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static).Where(m => m.Name.Contains("Parse", StringComparison.Ordinal)))
{
    if (method.GetParameters().Any(parameter => parameter.ParameterType == typeof(ReadOnlySpan<byte>)))
        Console.WriteLine(method);
}
foreach (var method in type.GetInterfaceMap(typeof(IUtf8SpanParsable<BigInteger>)).TargetMethods)
    Console.WriteLine($"{method.DeclaringType}: {method}");
var digits = "-1234567890123456789012345678901234567890"u8;
var number = Parse<BigInteger>(digits);
Console.WriteLine(number.ToString(CultureInfo.InvariantCulture));
static T Parse<T>(ReadOnlySpan<byte> input) where T : IUtf8SpanParsable<T> => T.Parse(input, CultureInfo.InvariantCulture);
