from pathlib import Path
import hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
comparison=lab/'comparison'
catalog=json.loads((comparison/'catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[row for row in catalog['cases'] if 'nonlocal' in row['id'] or 'fully-supplied-helper' in row['id']]
assert len(catalog['cases'])==2
diagnostic=comparison/'jit-catalog.json'
diagnostic.write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=json.loads((comparison/'images.json').read_text(encoding='utf-8'))['imageFiles']
sdk=Path.home()/'.dotnet11'
for role in ('reference','candidate'):
    image=comparison/('frozen-'+role)
    assert {n:hashlib.sha256((image/n).read_bytes()).hexdigest()for n in manifest[role]}==manifest[role]
    report=lab/(role+'-jit.txt')
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'],
             DOTNET_TieredCompilation='0',
             DOTNET_JitDisasm='*ExecutableSlot:get_Object* *TakeReturnOperand* *PublishDeferredValue* *PublishTupleBorrow*',
             DOTNET_JitStdOutFile=str(report))
    subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,diagnostic,
                    comparison/(role+'-jit-invocations.json')],env=env,check=True,timeout=75)
    for line in report.read_text(encoding='utf-8').splitlines():
        if line.startswith(('; Assembly listing','; Total bytes')):
            print(role,line)
