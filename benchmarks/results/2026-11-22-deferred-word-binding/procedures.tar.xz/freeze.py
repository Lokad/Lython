from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/deferred-word-binding-20261122"
previous = lab.parent / "retained-current-cpython-b1406"
out = lab / "comparison"
out.mkdir(exist_ok=True)
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

def git(path, *args): return subprocess.check_output(["git", *args], cwd=path)

def archived_catalog(name):
    path = repo / "benchmarks/results" / name / "observations.tgz"
    receipt = read(path.with_name("archive-receipt.json"))
    assert receipt["complete"] and sha(path) == receipt["archiveSHA256"]
    with tarfile.open(path) as bundle:
        return json.load(bundle.extractfile("representative.json"))

def verify(image, catalog, expected, out_path):
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", catalog, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", out_path], env=env, cwd=repo, check=True, timeout=135)
    result = read(out_path)
    assert result["state"] == "Completed" and result["caseCount"] == expected and result["catalogSha256"] == sha(catalog)

archives = (
    "2026-11-22-current-source-cpython",
    "2026-11-22-prepared-histogram-refined",
    "2026-11-22-unicode-decimal-cpython",
    "2026-11-22-scalar-default-binding/refined",
)
catalogs = [archived_catalog(name) for name in archives]
by_id = {}
for suite in catalogs:
    for row in suite["cases"]:
        if row["id"] in by_id:
            assert row["sourceSha256"] == by_id[row["id"]]["sourceSha256"]
            assert row["fixtureSha256"] == by_id[row["id"]]["fixtureSha256"]
        by_id[row["id"]] = row
ids = (
    "diagnostic.text-summary.nonlocal-computed-width.large",
    "diagnostic.text-summary.ordinary-histogram.large",
    "diagnostic.text-summary.dense-line",
    "scripts.csv-invoice.method-policy.quoted-control",
    "scripts.csv-meter-report.typed-unicode",
    "scripts.json-lines-shipment.expanded-options.large",
    "scripts.ordinary-fully-supplied-helper",
)
catalog = out / "catalog.json"
save(catalog, dict(catalogs[0], cases=[by_id[name] for name in ids], performanceQualified=False))
save(out / "jobs.json", [[ids[0], "warm"], [ids[0], "compile-run"]] + [[name, "warm"] for name in ids[1:]])
strict = lab.parent / "text-target-publication-20261122/strict-snapshot-controls.json"
control_count = len(read(strict)["cases"])
assert control_count == 2 and all(row["id"].startswith(ids[0]) for row in read(strict)["cases"])
shutil.copyfile(strict, out / "strict-snapshot-controls.json")
source = read(previous / "images.json")
base = source["revision"]
candidate = git(worktree, "rev-parse", "HEAD").decode().strip()
assert candidate.startswith("03e166590") and base.startswith("55424591f")
assert not git(worktree, "status", "--porcelain", "--untracked-files=no")
assert not git(repo, "diff", "--name-only", base, "HEAD", "--", "src", "tests")
manifest = source["imageFiles"]["candidate"]
donor = previous / "frozen"
assert len(manifest) == 32 and {name: sha(donor / name) for name in manifest} == manifest
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == source["protocolSHA256"]
candidate_core = lab / "frozen-build/bin/Lokad.Lython/release_net11.0" / core
images = {}
for label in ("reference", "candidate"):
    image = out / ("frozen-" + label)
    image.mkdir(exist_ok=True)
    for name in manifest:
        binary = candidate_core if name == core and label == "candidate" else donor / name
        shutil.copyfile(binary, image / name)
    expected = manifest if label == "reference" else {**manifest, core: sha(candidate_core)}
    assert {p.name: sha(p) for p in image.iterdir() if p.is_file()} == expected
    verify(image, catalog, len(ids), out / (label + "-verify.json"))
    verify(image, out / "strict-snapshot-controls.json", control_count, out / (label + "-snapshot-verify.json"))
    images[label] = expected
patch = out / "source.patch"
patch.write_bytes(git(repo, "diff", "--binary", base, candidate, "--", "src", "tests"))
save(out / "images.json", dict(reference=base, candidate=candidate, imageFiles=images,
    catalogSHA256=sha(catalog), protocolSHA256=sha(protocol), sourcePatchSHA256=sha(patch), catalogOrigins=archives))
