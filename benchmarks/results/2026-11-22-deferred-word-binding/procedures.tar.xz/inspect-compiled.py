from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
out=lab/'comparison'
source=lab.parent/'module-leading-indentation-20261122/comparison/inspect-reference'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
expected=read(out/'images.json')['imageFiles']
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
receipts={}
for label in ('reference','candidate'):
    image=out/('frozen-'+label)
    assert {n:hashlib.sha256((image/n).read_bytes()).hexdigest()for n in expected[label]}==expected[label]
    inspect=out/('inspect-'+label)
    inspect.mkdir(exist_ok=True)
    for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
        shutil.copyfile(source/name,inspect/name)
    shutil.copyfile(image/'Lokad.Lython.dll',inspect/'Lokad.Lython.dll')
    for name in ('catalog.json','strict-snapshot-controls.json'):
        output=inspect/(name+'-tapes.json')
        subprocess.run([dotnet,inspect/'Inspect.dll',out/name,output],env=env,check=True,timeout=60)
        data=read(output)
        assert data['coreSHA256']==expected[label]['Lokad.Lython.dll']
        if label=='reference':
            receipts[name]=data['rows']
        else: assert receipts[name]==data['rows']
print('Exact compiler metadata agrees for',sum(len(row['codes'])for rows in receipts.values()for row in rows),'code objects.')
(out/'matching-tapes.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8',newline='\n')
