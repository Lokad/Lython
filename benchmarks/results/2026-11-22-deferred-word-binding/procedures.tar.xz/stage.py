from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = lab / "comparison"
quiet = out / "quiet"
quiet.mkdir(parents=True, exist_ok=True)
previous = lab.parent / "retained-current-cpython-b1406/comparison/quiet"
template = lab.parent / "closed-return-bound-slots-20261122/comparison"
base = "/home/lokad/lython-bench-checks"
root = base + "/deferred-word-binding-b1410-20261122"
unit = "lython-b1410-deferred-word-binding-20261122"
core = "Lokad.Lython.dll"

def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob): return hashlib.sha256(blob).hexdigest()

def write(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data): write(path, json.dumps(data, indent=2) + "\n")

def archived(directory, leaf):
    return subprocess.check_output(
        ["git", "show", "origin/master:benchmarks/results/" + directory + "/" + leaf], cwd=repo)

def check_archive(directory):
    receipt = json.loads(archived(directory, "archive-receipt.json"))
    assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
    assert sha(archived(directory, "observations.tgz")) == receipt["archiveSHA256"]
    return receipt

refs = read(out / "images.json")
manifest = refs["imageFiles"]
catalog = out / "catalog.json"
assert sha(catalog.read_bytes()) == refs["catalogSHA256"]
donor = read(previous / "config.json")
assert manifest["reference"] == donor["identity"]["imageFiles"]["candidate"]
receipt = check_archive("2026-11-22-current-source-cpython")
archive_profile = check_archive("2026-11-22-retained-runtime-profile")

for role, files in manifest.items():
    image = out / ("frozen-" + role)
    assert len(files) == 32 and files == {n: sha((image / n).read_bytes()) for n in files}
    record = read(out / (role + "-verify.json"))
    assert record["state"] == "Completed" and record["caseCount"] == 7 and record["catalogSha256"] == refs["catalogSHA256"]

identity = dict(sourceRevision=refs["reference"] + " versus " + refs["candidate"],
    reference=refs["reference"], candidate=refs["candidate"], imageFiles=manifest,
    purpose="Defer prepaid short-word publication while preserving local snapshots",
    normalAdapterPin="0.4.0", sourcePatchSHA256=refs["sourcePatchSHA256"],
    coreSHA256={role + suffix: files[core] for role, files in manifest.items() for suffix in ("", "-control")},
    catalogs={"representative.json": {"sha256": refs["catalogSHA256"]}})
save(quiet / "identity.json", identity)
shutil.copyfile(catalog, quiet / "representative.json")
(quiet / "candidate").mkdir(exist_ok=True)
shutil.copyfile(out / "frozen-candidate" / core, quiet / "candidate" / core)
old = read(template / "quiet/config.json")
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    program = (template / "quiet" / name).read_text(encoding="utf-8")
    program = program.replace(old["root"], root).replace(old["unit"], unit).replace("B1404", "B1410")
    program = program.replace("len(jobs)==6","len(jobs)==8").replace("len(raw['jobs'])==6","len(raw['jobs'])==8")
    program = program.replace("jobs=6,","jobs=8,").replace("['jobs']==6","['jobs']==8")
    if name == "collect.py":
        jobs = [tuple(row) for row in read(out/"jobs.json")]
        ids = {row["id"] for row in read(catalog)["cases"]}
        assert len(jobs) == 8 and {case for case,lane in jobs} == ids
        first, end = program.index("\njob_catalog = "), program.index("\nassert len(jobs)")
        program = program[:first] + "\njob_catalog = " + repr({case:"representative.json" for case in sorted(ids)}) + "\njobs = " + repr(jobs) + program[end:]
        program = program.replace("started < 345","started < 455")
    write(quiet / name, program)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "run.sh", "archive-owned.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts:
        bundle.add(quiet / name, arcname=name)
unpacked = sum((quiet / n).stat().st_size for n in parts)

# The current B1406 image is the donor. If needed, retire only the superseded
# scalar binding binary and trace with verified canonical copies.
older = "2026-11-22-scalar-default-binding/refined"
folded = check_archive(older)
displaced = gzip.decompress(archived(older, "candidate-core.dll.gz"))
digest = sha(displaced)
assert json.loads(archived(older, "source.json"))["imageFiles"]["candidate"][core] == digest
assert digest not in (manifest["candidate"][core], manifest["reference"][core])
path = "closed-default-scalar-bind-b1409-20261122/candidate/" + core
profile_path = "current-retained-runtime-b1407-20261122/observations.tgz"
query = f"""
import fcntl, hashlib, json, os, shutil, stat
from pathlib import Path
b = Path({base!r})
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 p = b / {path!r}
 m = p.lstat()
 assert p.resolve() == p and stat.S_ISREG(m.st_mode) and m.st_uid == os.getuid()
 assert hashlib.sha256(p.read_bytes()).hexdigest() == {digest!r}
 paths = []
 for folder, dirs, names in os.walk(b):
  for name in names:
   q = Path(folder) / name
   s = q.lstat()
   if (s.st_dev, s.st_ino) == (m.st_dev, m.st_ino):
    assert q.resolve() == q and q.is_relative_to(b) and q.name == p.name
    paths.append(str(q.relative_to(b)))
 assert len(paths) == m.st_nlink and all(not name.startswith({Path(donor["root"]).name!r}) for name in paths)
 trace = b/{profile_path!r}
 trace_proof = None
 if trace.exists():
  t = trace.lstat()
  assert trace.resolve()==trace and trace.is_relative_to(b) and stat.S_ISREG(t.st_mode) and t.st_uid==os.getuid() and t.st_nlink==1
  trace_proof=dict(paths=[{profile_path!r}],bytes=t.st_size,links=t.st_nlink,sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),archives={{}})
 print(json.dumps(dict(free=shutil.disk_usage(b).free, paths=sorted(paths), bytes=m.st_size, links=m.st_nlink, sha256={digest!r}, trace=trace_proof)))
"""
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home() / ".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]
inventory = json.loads(subprocess.check_output(ssh + ["python3 -"], input=query.encode(), timeout=40))
save(out / "inventory.json", inventory)
floor = 176160768 + unpacked + 640 * 1024
free = inventory["free"]
retire = []
if free <= floor:
    assert inventory["sha256"] == digest and inventory["bytes"] == len(displaced)
    retire.append({**{key: inventory[key] for key in ("paths", "bytes", "links", "sha256")}, "archives": {}})
    free += inventory["bytes"]
if free <= floor and inventory["trace"] is not None:
    trace = inventory["trace"]
    assert trace["sha256"] == archive_profile["archiveSHA256"]
    retire.append(trace)
    free += trace["bytes"]
assert free > floor, (free, floor)
config = dict(root=root, unit=unit, identity=identity, source=donor["root"], sourceRole="candidate",
    sourceFiles=manifest["reference"], sourceCatalogSHA256=donor["identity"]["catalogs"]["representative.json"]["sha256"],
    donorArchiveSHA256=receipt["archiveSHA256"], protocolSource=donor["protocolSource"],
    protocolSHA256=refs["protocolSHA256"], retireGroups=retire, payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload.read_bytes()), unpackedBytes=unpacked)
save(quiet / "config.json", config)
launch = (template / "quiet/remote-launch.py").read_text(encoding="utf-8").replace("b1404-fixtures", "b1410-fixtures").replace("RuntimeMaxSec=405", "RuntimeMaxSec=520")
start, end = launch.index("\nc=") + 1, launch.index("\nb=Path(")
write(quiet / "remote-launch.py", launch[:start] + "c=" + repr(config) + launch[end:])
write(out / "launch.py", (template / "launch.py").read_text(encoding="utf-8").replace(
    "Closed return from bound slots comparison", "Deferred short-word binding comparison").replace("355","475"))
write(out / "summarize.py", (template / "summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==6","len(raw['jobs'])==8"))
print("Both complete images and seven CPython goldens verified for the quiet comparison.")
