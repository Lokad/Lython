from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import tarfile

base = Path("/home/lokad/lython-bench-checks").resolve()
root = base / "deferred-word-binding-b1410-20261122"
candidate = root / "candidate/Lokad.Lython.dll"
unit = "lython-b1410-deferred-word-binding-20261122.service"
known_local_core = "151f5f516cffc6e69c71e722590f59ac16ab1287d6a3193194e33c2c3bc0aff3"
floor = 176160768
digest = lambda data: hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

with (base / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    status = subprocess.check_output(["systemctl", "show", unit, "--property=ActiveState,Result,MainPID,ExecMainStatus"], text=True)
    assert all(line in status.splitlines() for line in ("ActiveState=failed", "Result=exit-code", "MainPID=0", "ExecMainStatus=1"))
    assert (root / "exit-code.txt").read_text().strip() == "1"
    assert not (root / "guest-fixtures").exists()
    assert subprocess.run(["pgrep", "-af", "[d]otnet.* --compare worker|[p]erf record"],
                          capture_output=True).returncode == 1
    identity = json.loads((root / "identity.json").read_text())
    for role, files in identity["imageFiles"].items():
        assert len(files) == 32
        for filename, expected in files.items():
            assert sha(root / role / filename) == expected, (role, filename)
    assert root.resolve() == root and candidate.resolve() == candidate and candidate.is_relative_to(root)
    detail = candidate.lstat()
    assert stat.S_ISREG(detail.st_mode) and detail.st_nlink == 1 and detail.st_uid == os.getuid()
    assert sha(candidate) == known_local_core == identity["imageFiles"]["candidate"][candidate.name]
    initial_archive = root / "observations.tgz"
    initial_sha = sha(initial_archive)
    confirmation_path = "confirmation/confirmation.json"
    with tarfile.open(initial_archive) as archive:
        regular = [m for m in archive.getmembers() if m.isfile()]
        assert regular and all((root / m.name).is_relative_to(root) and
                               sha(root / m.name) == digest(archive.extractfile(m).read()) for m in regular)
        complete = json.loads(archive.extractfile(confirmation_path).read())
        assert complete["complete"] and len(complete["jobs"]) == 8
    before = shutil.disk_usage(root).free
    candidate.unlink()
    after = shutil.disk_usage(root).free
    assert after > floor + (512 << 10)
    evidence = dict(originalService=status, originalExitCode=1, originalArchiveSHA256=initial_sha,
                    originalArchiveRegularFilesVerified=len(regular), confirmationSHA256=sha(root / confirmation_path),
                    originalFailure="Persistent disk floor after archive",
                    recoveredUnderFreshExclusiveLease=True, allImagesReverifiedBeforeRetirement=True,
                    retiredVMDuplicate=str(candidate.relative_to(root)), localCopySHA256=known_local_core,
                    requiredFreeBytes=floor, freeBefore=before, freeAfter=after)
    (root / "archive-recovery.json").write_text(json.dumps(evidence, indent=2) + "\n")
    subprocess.run(["python3", str(root / "archive-owned.py")], check=True, cwd=root)
    print(json.dumps(evidence))
