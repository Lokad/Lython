from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'commit': '0ceb88e6a8dd3deb4691c67822a462c5cb82908f', 'canonicalArchive': 'benchmarks/results/2026-11-14-native-entry-admission/prototype-checks-and-restoration.tar.xz', 'canonicalArchiveSHA256': '880ab7836ce7d06c8ff5d5826f9dba7447572044710d2897f814298bdadd77c1', 'member': 'candidate-core.dll', 'bytes': 5746688, 'sha256': 'c3bbdafd3d7c1aec2b56a26e6847988f49b3415d5187f6b6830e1802238d7ad5', 'paths': ['native-entry-b758-20261114/candidate-core.dll', 'native-entry-b758-20261114/candidate/Lokad.Lython.dll'], 'expectedLinks': 2, 'plannedUnpackedBytes': 5766095}
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
 paths=[base/n for n in proof['paths']]
 metadata=[p.lstat() for p in paths]
 observations=[dict(path=str(p),inode=s.st_ino,links=s.st_nlink,uid=s.st_uid,bytes=s.st_size) for p,s in zip(paths,metadata)]
 print(json.dumps(dict(preflight=observations)),flush=True)
 assert all(p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_nlink==proof['expectedLinks'] and s.st_size==proof['bytes'] for p,s in zip(paths,metadata))
 assert len({(s.st_dev,s.st_ino) for s in metadata})==1
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256'] for p in paths)
 before=shutil.disk_usage(base).free
 assert before+proof['bytes']>254*1024*1024+proof['plannedUnpackedBytes']+32768
 for p in paths:p.unlink()
 receipt=dict(proof=proof,allMetadataHashesVerifiedBeforeMutation=True,freshIdleLease=True,retiredOnly=[str(p) for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,currentb5ff2AllCatalogsAuxiliariesAndToolchainsPreserved=True,floorsUnchanged=True)
 (base/'b759-proved-withdrawn-prototype-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
