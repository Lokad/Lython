from pathlib import Path
import ast,hashlib,json,tarfile

r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(n)==h for n,h in identity['sources'].items())
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
ids=['scripts.csv-fulfillment.large','scripts.csv-invoice.large','scripts.text-summary-helpers.nonlocal-counter.large','diagnostic.loop-helper.short-zero.large']
cases={c['id']:c for c in catalog['cases']}
if ids[0] not in cases:
    matches=[n for n in cases if 'fulfillment' in n]
    assert len(matches)==1,matches
    ids[0]=matches[0]
for role in ['reference','candidate']:
    (r/('allocation-'+role+'-catalog.json')).write_text(json.dumps(dict(catalog,cases=[cases[n] for n in ids]),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
code=(r.parent/'native-call-transport-r365/measure-allocation.py').read_text(encoding='utf-8').replace('timeout=30','timeout=60').replace('start<100','start<130')
ast.parse(code);(r/'measure-allocation.py').write_text(code,encoding='utf-8',newline='\n')

b=r/'b759';b.mkdir()
old=r.parent/'protected-activation-r368/b756'
prior=r.parent/'native-entry-r369/b758'
remote='/home/lokad/lython-bench-checks/scalar-results-b759-20261114'
unit='lython-b759-scalar-results-20261114'
source=json.loads((old/'identity.json').read_text(encoding='utf-8'))
source.update(sourceRevision='R370uncommitted/frozen'+identity['coreSHA256']['candidate'][:8]+' vs qualified3994dfda/frozenb5a6426e;43640155007 GREEN cached',purpose='Keep shared int-text/len results typed until ordinary observation or existing private integer publication. No second parser, new bank, new binder or relaxed admission. Same complete scripts, controls, worker/settings; allocation measured separately.',coreSHA256={k:identity['coreSHA256']['candidate' if k.startswith('candidate') else 'reference'] for k in source['coreSHA256']},fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),catalogSHA256=sha(r/'catalog.json'),sourceFormComparison=False,runtimeComparison=True)
assert sha(r/'catalog.json')==sha(r.parent/'protected-activation-r368/catalog.json')
(b/'identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[[ids[0],'warm'],[ids[0],'compile-run'],[ids[1],'warm'],[ids[2],'warm'],[ids[3],'warm'],['diagnostic.loop-helper.observed.large','warm'],['scripts.json-summary-helpers.large','warm']]
if jobs[-2][0] not in cases:
    matches=[n for n in cases if 'observed' in n]
    assert len(matches)==1,matches
    jobs[-2][0]=matches[0]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('protected-activation-b756-20261114','scalar-results-b759-20261114').replace('lython-b756-protected-activation-20261114',unit).replace('B756','B759')
    if name=='collect.py':
        a=s.index('jobs=');end=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n'+s[end:]
    elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==7").replace('jobs=8','jobs=7')
    elif name=='retrieve.py':s=s.replace("['jobs']==8","['jobs']==7").replace('eight-job','seven-job')
    elif name=='summarize.py':s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==7").replace('jobs=8','jobs=7')
    if name.endswith('.py'):ast.parse(s)
    (b/name).write_text(s,encoding='utf-8',newline='\n')
(b/'prospective.json').write_text(json.dumps(dict(purpose=source['purpose'],jobs=jobs,bound='One420sowner/350sstartguard,7completejobs,4freshprocesses/job,5srequestwarmups/12stext,5rotating0.5sbatches. NormalGC/tiering; every image/golden/file/budget/quiet/join/archive gate.',acceptance='Exact Python results and publication/alias/error order; cooperative cancellation/refusal, major allocation preflights, stack protection and joined cleanup. No new storage for otherwise bankless functions. Typed values only stay private in existing bank.',stopping='Usable affected/control comparison or bounded evidence-backed correction/refinement; preserve every adverse point. Decide retention/debt or withdrawal. Architecture, allocation and CPU separate; whole-script goal continues.',storage='Hardlink prior catalog/auxiliaries/currentb5reference, upload only newcore/scripts. Retire only archived withdrawnC3twoaliases after fresh path/uid/inode/link/hash verification;254/252MiB floors unchanged.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(b/'payload.tgz','w:gz')as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(b/n,arcname=n)
    t.add(r/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(b/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/protected-activation-b756-20261114',unit=unit,identity=source,payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
s=(prior/'launch-command.py').read_text(encoding='utf-8');a=s.index('c=');end=s.index('\nbase=',a);s=s[:a]+'c='+repr(config)+s[end:]
s=s.replace('lython-b758-fixtures','lython-b759-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=420').replace('b758-proved-withdrawn-prototype-retirement.json','b759-proved-withdrawn-prototype-retirement.json')
ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8').replace("protected-activation-r368/b757/terminal-status.json","native-entry-r369/b758/terminal-status.json").replace('seconds=180','seconds=350').replace('ownerSeconds=240','ownerSeconds=420')
ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=jobs,unpackedBytes=unpacked,core=identity['coreSHA256'])),flush=True)
