from pathlib import Path
import json,subprocess

r=Path(__file__).parent;b=r/'b759'
summary=json.loads((b/'summary.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['jobs']==7
debt='Invoice warm elapsed+0.94..1.87%, widerCPU+2..4%, with0.59/0.32%reference/candidate process spread. Retain as explicit0.11regression debt for this bounded allocation/publication change; not a universal CPU improvement. Whole-call/publication milestone or final0.11decision must correct, accept with justification, or withdraw it before release.'
uncertainty='Text elapsed+0.53..4.28%, CPU-1.43..5.98%, process spreads1.75/1.95%; short reference spread7.08%, observed candidate spread5.62%. Preserve every adverse point; no control-neutrality or causal layout claim.'
decision=dict(status='retain',fullQualificationPending=True,publicationHeld=True,removed='Boxed-return stage for shared int-text/length kernels before private native arithmetic; closed text int bypasses the general conversion dispatcher. Shared parser and invocation wrapper remain.',notAdded='No parser/selector duplicate, integer bank for nonnumeric helpers, frame/value framework, pool, frontend pass, runtime option or dependency.',allocation='Complete fulfillment-18.20%,invoice-5.00%; text/short flat. Process-wide CLR allocation only, separate from CPU.',cpu='Fulfillment warm elapsed-3.95..-3.02%, widerCPU-4.84%; fresh elapsed-5.59..-2.64%, widerCPU-5.28..-1.46%. Useful modest affected-script improvement, not substantial overall objective completion.',acceptedDebt=debt,uncertainty=uncertainty,semanticAcceptance='Actual11/10 each62internal+561public,136independentCPythoncontrols and16source/phasegoldens. Retained results/aliases, suspended users/cancellation/join, terminal refused parse admission, exact wider/Unicode/error/protocol/builtin-rebinding behavior. Conservative major parse charge including box headroom remains.',next='One full Windows/Ubuntu actual11/10/originalstress/installedRelease delivery cycle, source proof and cached terminal outcome. Then complete-call/publication source gate with existing whole-script profiles; select a complete eliminated bridge, not another arena or marginal poll removal. Regex independent; no unchanged external nine-job refresh.')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'save.py')],check=True)
rows=[]
for row in summary['timing']:
    pair=lambda key:'..'.join(f'{x:+.2f}%'for x in [min(row[key]),max(row[key])])
    rows.append('|'+row['case']+' /'+row['lane']+'|'+pair('lythonSourcePairElapsedPercent')+'|'+pair('lythonSourcePairWiderCpuPercent')+'|'+f"{row['referenceControlPercent']:.2f}/{row['lythonControlPercent']:.2f}%"+'|')
out=Path('benchmarks/results/2026-11-14-builtin-scalar-publication')
(out/'README.md').write_text('''# Typed builtin scalar publication

R370/B759, 2026-11-14 UTC. Retain frozen `bed6e57e` against qualified
`3994dfda` / `b5a6426e`, pending full platform/stress/installed-consumer checks.
All582production inputs and the complete frozen worker/adapter image are recorded.
No public API, regex contract or package dependency change; publication held.

Shared int-text and length kernels return BigInteger directly through the existing
managed invocation/exception/cleanup wrapper. Closed text calls use the same
admitted parser directly. Ordinary observations still box; native arithmetic can
publish into its existing integer bank without first allocating an object result.
No extra bank for nonnumeric helpers, second parser/binder/selector, value framework,
pool or analysis pass. Exact wider promotion, stable aliases, materialization before
calls/returns, async protocols, stack protection and cancellation remain. Major
parse estimates still conservatively fund box headroom even for a private result.

Separate complete warm allocation diagnostics: fulfillment5,762,044.25→4,713,427.75B
(−18.20%); invoice5,245,458.125→4,983,303.25B(−5.00%); text and short controls flat.
Both roles measured with identical existing allocation tool/catalog. Process-wide
CLR allocation, no forced GC; not CPU, RSS or embedding-latency evidence. Includes
reset/mediated I/O/full output-file checks/result cleanup, excludes compilation,
startup/final cache teardown. Every invocation returns the shared budget to baseline.

| Complete script /phase | Elapsed change | Wider CPU change | Reference/candidate process spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Negative means lower/faster. All independent process-median pairings, not
confidence intervals. Fulfillment has a modest useful CPU improvement. Invoice
is adverse with stable processes: retain its measured0.94–1.87%elapsed/2–4%CPU
regression as explicit0.11debt, to correct or decide before release. Text remains
adverse/uncertain; short and observed controls move substantially. JSON CPU is
mixed. No neutrality, universal/cumulative speedup or attributed layout cause.
The allocation benefit and shared typed publication justify this bounded stage;
they do not close the substantial whole-script performance objective.

One seven-job269.972s quiet collection, AzureF4as_v7/Ubuntu24.04.4/fourEPYC9V45/
.NET11RC3, normal GC/tiering and fixed worker/nonpackable adapter0.4. Four fresh
processes/job, five-second full-request warmups/twelve for text, five rotating
half-second batches. Warm includes mediated RAM I/O, full output/file validation
and prior-result cleanup; excludes startup/compile/reset/protocol/final cache
teardown. Compile-run adds per-invocation compilation/disposal. Wider CPU includes
reset/protocol. CPython external timings are not refreshed by this source pair;
the guide keeps exact earlier revisions. Startup/heap/tail latency remain unmeasured.

Focused actual11/10 each62internal+561public pass,136isolatedCPythoncontrols and
16source/phasegoldens match. New cases preserve boundaries/Unicode/bytes/errors,
rebinding/protocol order, aliases, wide working storage, retained results across
executions, genuine I/O/cancellation/join and terminal parse refusal. The first
internal run found a reflection delegate still expecting the old object result;
change its return type only, preserving every cancellation/admission assertion.
The original four failed cases/logs remain archived; no runtime recovery path added.

All image/catalog/golden/file/budget/quiet/join/archive gates pass. Exact withdrawn
C3twoaliases match committed evidence and retire under idle lease only after all
path/UID/inode/link/hash checks; all current images/catalogs/toolchains survive.
Actual planned staging bytes, unchanged254MiB staging/252MiB archive floors.
After archive265,588,736Bfree. Raw bytes verify under lease before RAM teardown;
no VM users/fixtures remain. SHA256:
`20160450963b2396dcbfabbb98c962f8caeb6bd4f86a2f25e50e3068b96b84ed`.

[Decision and completion debt](decision.json),[all timing/control/IQR](timing-summary.json),
[allocation](allocation-summary.json),[raw](observations.tgz),
[source/image/local checks/first failure/custody](sources-and-local-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## R370 — typed builtin scalar publication retained with debt

[B759](results/2026-11-14-builtin-scalar-publication/README.md), bed6e57e versus
qualified3994/b5, removes shared int-text/len object-result erasure before private
numeric publication. Existing parser, managed wrapper and private bank remain;
no new bank/arena/framework. Complete fulfillment allocation−18.20%,invoice−5.00%,
text/short flat. Seven jobs269.972s/all gates: fulfillment warm3–4%/fresh2.6–5.6%
lower elapsed with CPU support. Invoice+.94..1.87%elapsed/+2..4%CPU is accepted
explicit0.11debt; text adverse/uncertain, short/observed controls variable, JSON
CPU mixed. No universal/substantial CPU completion or embedding-latency claim.
Actual11/10 each62internal+561public,136Pythoncontrols/16goldens pass. Test-only
reflection return mismatch is corrected with all assertions/first failure retained.
Full platform/originalstress/installed consumers follow at this retained boundary.
Complete-call/publication and independent regex milestones continue; publication held.
''',encoding='utf-8',newline='\n')
print('Retained with explicit invoice regression debt; full delivery pending.',flush=True)
