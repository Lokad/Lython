# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once. Individual experiments do not close this objective.
Current contracts belong in docs; historical evidence and rejected designs belong
in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and its immutable results.

## Actual delivery status

| Status | Delivered behavior and limits |
| --- | --- |
| Completed foundations | Shared compiler facts/nonlocal correction; lowered-tree retention cleanup; direct UTF8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable plain builtins; native/owned loops and tuple returns; primitive working storage/shared arithmetic; CSV adoption/shared keys; UTF8 JSON/incremental XML. Preserve their fixes and cached qualification. |
| Closed earlier measurement gaps | Native returns: about 19–20% less allocation; original elapsed results remain diagnostic. Formatting: allocation −8.67%; [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU −5–8%. Original adverse 15.125ms remains unexplained. Historical revisions, not HEAD claims. |
| Latest fully qualified runtime | `3994dfda` / frozen `b5a6426e`, [43640155007 GREEN](benchmarks/results/2026-11-14-protected-helper-activation/delivery/README.md). Windows/Ubuntu actual .NET11/10, 4,775 internal +17,838 public ordinary and original 13/406 stress each; installed Release consumers. 582-input proof/16 summaries/full logs cached. Never requery terminal runs or repeat unchanged qualification. Older R365 qualification stays cached. |
| Latest retained allocation change | [R365 workspace reuse](benchmarks/results/2026-11-14-native-integer-workspace/completion/README.md) removes per-wide-call arrays/reservation objects using the existing one-idle-cache policy. Fulfillment allocation −14.57%; warm CPU mixed, fresh modestly lower. Short calls retain elapsed +0.62–2.91%/CPU +1.22–2.71% debt. Cleanup refinement was completely withdrawn. No substantial CPU or embedding-latency claim. |
| Prior retained range work | R361/R362 keep per-run constructors and one explicit range state. [R362](benchmarks/results/2026-11-14-range-iteration-stage/refined/README.md): counter warm/fresh about 28–31% lower, allocation −99.52%; materialization allocation +1.26%. Original text +12.91% and bounded confirmation remain visible; cause unresolved. No neutrality, universal or cumulative claim. |
| External comparison | [B747 guide](docs/BENCHMARKS.md), exact earlier qualified `fa40d674`/`73a1b233` versus stock CPython3.13.16: invoice warm 1.26–1.31×, compile 1.07–1.09×, fresh 1.24–1.26×; text 1.45–1.50×, JSON 0.83–0.86×, search 1.61–1.69× variable, report 1.21–1.23× variable, fulfillment 1.26–1.29×, for-CSV 1.29–1.33×. Compilation, warm execution, mediated RAM I/O and cleanup boundaries explicit. Do not relabel these as today's HEAD. |
| Current source assessment | [R366/B754](benchmarks/results/2026-11-14-invocation-stage/README.md) finds host filesystem work dominates tiny config edits; no dominant removable builtin or scheduling stage established. Search retains material call/dispatch/iteration work. Direct iterator slots/shared decoded windows already exist. This assessment introduced no runtime change. |
| New whole-script source evidence | [R367/B755](benchmarks/results/2026-11-14-protected-helper-cost/README.md): on the same image/data, defensive try/except helpers add invoice elapsed 21.1–21.4% with stable controls/supporting CPU; search 63–78% with 7.87% protected-process spread. Separate allocation +41.23%/+294.91%; 16 independent source/phase goldens. Whole syntax cost, not isolated frame attribution. Evidence committed in `a4be4783`; R368 delivered and qualified below. |
| Protected helper milestone complete | R368 removes eager normal try/except activation and routes exact faults through the existing handler engine. Warm protected invoice17–18.5%lower, fresh16–19%lower, search41–43%lower; allocation−29.19%/−74.65%. Keep short-call debt and text uncertainty. B757 measures this same qualified runtime; [all source-pair controls](benchmarks/results/2026-11-14-protected-helper-activation/README.md). |
| Withdrawn R369 | [Native entry prototype](benchmarks/results/2026-11-14-native-entry-admission/README.md): C3one-check deletion removed; all582production inputs restore exactly to qualifiedb5. Four-jobCPU effect uncertain with6.06%search reference spread and shortCPU−.25..+4.20%. Keep body-local admission and the independent low-stack native test.428candidate focused/124Pythoncontrols/16goldens, then60restored checks/forcedbuilds preserved. No inherent-regression claim or permanent ban. |
| Withdrawn, not dormant | R360 frame scalar arrays, R364 merged activation, R365 cleanup refinement and R355 raw CSV ranges are removed. Keep adverse controls, independent semantics/lifetime/refusal fixes and contextual decisions. No permanent design ban; do not replay slower call arenas/controllers or the same R268 single-engine design unchanged. |

## Prioritized deliverables

1. **R370: preserve closed builtin scalar results through existing native storage.**
   Source gate confirms int(text)/len return object before native arithmetic reads
   a private integer. The common UTF8decimal parser already exists; do not add a
   second parser. Existing fulfillment has eight int calls per helper, invoicefour,
   each over4096records. These are producer occurrences, not eliminated boxes or
   physical-byte/CPU estimates: returned arguments and promotion remain observable.

   Proposed coherent migration: typed BigInteger results from shared int-text/len
   kernels through the same managed invocation/translation/cleanup wrapper; box at
   ordinary observation, or publish into the existing private integer bank when
   present. No new bank for otherwise nonnumeric helpers. Remove their boxed-return
   →numeric-read stage and unnecessary generic int dispatch for closed text inputs.
   Keep object/alias-producing operations and dynamic protocols on existing routes.
   No second selector/parser/binder, universal tagged values, pool or frontend pass.

   Preserve Unicode/bytes/base/error behavior, live builtin rebinding, signed/wider
   exact values, identities/aliases and materialization before calls/returns,
   genuine async callbacks, cancellation, first refusal, major preflights and
   funding through users/cleanup. Retain conservative major parse charges even if
   a private result avoids a box. Shared typed publication must use nonthrowing
   signed-range checks; no narrowing/overflow-based control flow.

   First implement/test the whole boundary, then separate whole fulfillment
   warm/fresh allocation/CPU, invoice/text and short/observed/JSON controls in one
   bounded quiet comparison. Preserve all adverse points; refine/confirm/correct
   only for concrete evidence. Retain/debt or fully withdraw; no speedup forecast
   from source boxing alone. Full platform/stress/installed package checks at a
   coherent retained delivery, keeping completed R368qualification cached.

2. **Continue the substantial execution/collection roadmap from evidence.**
   Call/frame work is selected only for a complete bridge removed. Final local
   and operand storage already shares one array; direct positional binding,
   receiver-independent methods, shared lookup caches and deferred contexts exist.
   Native operands materialize before helper binding, but invoice has only two
   private computed inputs; returned/aliased values are observable. Do not infer
   four inputs, missing slot transport or a universal tagged-value requirement.

   Bulk CSV's historical 6–8% observations missed rigid thresholds, not Python
   correctness. Current parser already bulk-admits fields/rows and adopts keys/
   storage. [R355 reassessment](benchmarks/results/2026-11-14-owned-csv-field-ranges/README.md)
   withdrew raw-field ranges for limited whole-script benefit and extra state/
   scratch retention; keep control regression and escaped/borrowed evidence. A
   revised per-record design must remove an actual remaining construction/copy
   stage without heuristics, retaining malformed-record timing, wide rows,
   aliases, cancellation, construction overlap and terminal refusal. Do not
   automatically promote the old prototype or repeat the same form unchanged.

   Remaining text/JSON conversions require an identified whole conversion/build
   stage and affected script. Current final tuple backing, UTF8 output, decoded
   file windows and bulk managed UTF16 transcoding already remove proposed copies.
   Preserve Unicode/context/expansion, hooks and reentry. Frontend shared facts
   and retention cleanup are complete; invoice compile around 0.1ms versus 7–8ms
   execution does not justify claiming analysis dominates. Select frontend work
   from a genuinely costly fresh-script shape, sharing facts rather than adding
   passes. No heavyweight JIT or new benchmark framework without owning evidence.

3. **Make a coherent 0.11 performance/debt decision.** Architectural simplification,
   allocation reduction and demonstrated CPU gains are separate deliverables.
   R359/R361/R365/R368 short-helper debt and R362 materialization/text uncertainty stay
   open until an explicit final decision. New measurements must address changed
   source or a material unresolved question. Refresh representative CPython at the
   next substantial retained CPU milestone; reuse qualified B757 for protected forms
   and B747 for its unchanged older rows until then. State exact
   source, reference/runtime/machine/date, compilation, startup, mediated I/O,
   validation and result/cache cleanup. Do not repeat an unchanged nine-job run.
   Quiet-VM complete scripts plus source/semantic acceptance decide useful
   retention; a fixed percentage cannot automatically veto a coherent design.

4. **Keep regex implementation independent.** The core owns Python semantics,
   native UTF8/original-subject windows, byte/scalar coordinates, captures/errors,
   explicit ownership and the current token. Development producers/adapter-local
   bridges are allowed; distinguish contract tests, semantic checks and backend
   performance. Optional adapter stays non-packable at0.4; completed dev80 checks
   are cached. [Assessment through 8af3a569](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   records only final released-adapter gaps: separate one-match scratch/escaping
   result owners, native UTF8 group-name enumeration/copy, and token-independent
   cursor creation with cancellable preparation. Search filtering cannot replace
   anchored/fullmatch. Cached state must not retain prior tokens. Missing producer
   APIs defer only affected final adapter qualification; no blanket stopping rule,
   unchanged producer qualification or core dependency/pin promotion.

## Evidence, validation and lasting constraints

Timeouts, unstable unchanged controls and inconclusive measurements establish
uncertainty, not a failed design. Bounded confirmation/refinement/measurement
correction is allowed when evidence justifies it. Preserve original failed
conditions and every adverse point. No one-attempt/no-retiming/permanent-closure
rule and no open-ended campaign. Finish each milestone with retention/debt,
supported withdrawal or explicit uncertainty; the whole-script objective continues.

Use focused Release correctness/cancellation/ownership checks during iteration.
Batch full Windows/Ubuntu, actual11/10, original stress and installed-package
consumers at meaningful retained boundaries. Force nonincremental builds after
restoration, freeze copies and prove source/image identity. Cache terminal CI;
space live queries240s apart. Verify persistent raw evidence under its lease before
RAM teardown. Preserve current images/catalog/toolchain and254/252MiB floors.
Startup, pending-I/O latency, contention, heap/RSS peaks and embedding tail latency
remain unmeasured; fewer allocations or full collections do not establish them.

[AGENTS.md](AGENTS.md) remains binding: fully managed/memory-safe; no unsafe,
Unsafe APIs, pointers, P/Invoke or native probes. Keep managed stack/recursion
admission, host mediation, original paths/contained Cwd, cooperative cancellation,
cycle detection/XML depth, checked representation bounds and bounded I/O chunks.
No fuel/quotas, independent caps/default allowance, regex work/time policy, tracing,
weak reclamation, forced GC or abandoned users. Borrowed allowance funds major
capacity, replacement overlap, retained aliases/results/caches and pending borrows.
First refused admission fails the command with its original origin; never retry.
Await cleanup. Long streaming uses bounded host commands. Only core is packaged;
the adapter stays in-repo and non-packable. Publication remains postponed.
