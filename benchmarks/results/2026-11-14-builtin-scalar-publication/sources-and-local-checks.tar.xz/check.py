from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
selections={'Lokad.Lython.Tests': ['DirectIntegerTextCallTests', 'DirectLengthCallTests', 'IntegerTextAdmissionTests', 'IntegerTextCancellationTests', 'IntegerProtocolAsyncTests', 'IntegerConversionSlotTests', 'NativeIntegerWorkspaceOwnershipTests', 'NativeIntegerChainTests', 'ManagedStackGuardTests'], 'Lokad.Lython.PublicApi.Tests': ['BuiltinScalarPublicationTests', 'DirectIntegerTextCallTests', 'DirectLengthCallTests', 'UnicodeIntegerTextTests', 'Utf8IntegerParseTests', 'GeneralIntegerTextTests', 'NumericProtocolContractTests', 'IntegerConversionAsyncTests', 'IntegerPublicationTests', 'ProtectedHelperExecutionTests', 'FrameIntegerLifetimeTests', 'StackGuardScenarioTests']}
for framework in ['net11.0','net10.0']:
    log=r/('probe-build-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework,'--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-4000:]
    print(framework,'forced probe/core build pass',flush=True)
    for project,classes in selections.items():
        name='r370-'+project+'-'+framework+'.trx';log=r/(project+'-'+framework+'.log');selection='(Category!=Stress)&('+'|'.join('FullyQualifiedName~'+v for v in classes)+')'
        with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',selection,'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
        trx=Path('tests')/project/'TestResults'/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib if trx.exists()else None
        if trx.exists():shutil.copyfile(trx,r/name)
        rows.append(dict(framework=framework,project=project,selection=selection,exitCode=done.returncode,counters=counts));(r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
        assert done.returncode==0,log.read_text(encoding='utf-8')[-5000:]
        print(framework,project,counts['passed'],'activation/binding/cleanup/stack checks pass',flush=True)
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'));changed=[n for n,h in baseline['sources'].items()if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h];assert set(changed)==set(['src/Lokad.Lython/Runtime/LythonRuntime.Builtins.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeCalls.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']);print('Five production inputs changed: typed int-text/length results and shared invocation, private publication only with existing integer storage. No new parser, allocation bank, owner, public API or stack policy. Prototype pending affected/control comparison.',flush=True)
