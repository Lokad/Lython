from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent;b=r/'b759'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity['sources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'))
assert len(checks)==4 and all(x['exitCode']==0 for x in checks)
controls=json.loads((r/'python-controls.json').read_text(encoding='utf-8'))
assert controls['complete'] and all(x['matched'] for x in controls['controls'])
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
assert allocation['allGoldensAndBudgetBaselineChecksPassed'] and allocation['allWorkersJoinedAndFixturesRemoved']
decision=json.loads((r/'decision.json').read_text(encoding='utf-8'))
assert decision['status'] in ['retain','withdraw']
out=Path('benchmarks/results/2026-11-14-builtin-scalar-publication');out.mkdir()
for src,name in [(b/'observations.tgz','observations.tgz'),(b/'summary.json','timing-summary.json'),(b/'archive-receipt.json','archive-receipt.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'candidate-identity.json','candidate-identity.json'),(r/'focused-checks.json','focused-checks.json'),(r/'decision.json','decision.json')]:shutil.copyfile(src,out/name)
with tarfile.open(out/'sources-and-local-checks.tar.xz','w:xz')as t:
    for p in sorted(r.iterdir()):
        if p.is_file():t.add(p,arcname=p.name)
    t.add(r/'originals',arcname='originals')
    t.add(r/'initial-failed-checks',arcname='initial-failed-checks')
    t.add('tests/Lokad.Lython.PublicApi.Tests/BuiltinScalarPublicationTests.cs',arcname='final-public-tests.cs')
    t.add('tests/Lokad.Lython.Tests/IntegerTextCancellationTests.cs',arcname='final-parser-tests.cs')
    for p in sorted(b.iterdir()):
        if p.is_file() and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='comparison/'+p.name)
print('R370 exact source/image, first failure, local checks, ownership and raw timing archived.',flush=True)
