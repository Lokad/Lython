# Lokad.Lython 0.11.0

Updated 2026-11-12. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-to-result. Closing an experiment does not complete this objective.

## Actual delivery

| State | Outcome / evidence |
| --- | --- |
| Fully qualified production | `beeb828e`: R269 iterative JSON depth-policy removal, R270 shared annotation demand and R271 admitted immutable reader windows. Cached GREEN43225489349: Windows/Ubuntu, actual.NET11/10, original stress, installed Release consumers. All568 frozen production files match; production equals measured8ec7bfab. [Delivery](benchmarks/results/2026-11-12-reader-windows/delivery/README.md). Prior GREEN43213984464 remains closed. No unchanged qualification replay. |
| Completed compiler correction | Shared facts remove repeated/exponential analysis and correct nonlocal diagnostics. R270 additionally deletes the duplicate demand walk/dictionary; compile allocation −432..−456B for common scripts, combined quiet elapsed −1..−3%, CPU/warm uncertain. No substantial whole-script CPU claim. |
| Completed text milestone | Direct UTF-8 formatting/storage: allocation −8.67%; controlled elapsed/CPU supports 5–8% improvement. Original adverse15.125ms observation remains unexplained and preserved. No requirement to erase an adverse observation before accepting controlled evidence. |
| Completed native-return milestone | Allocation −19.92% Run /−19.31% RunAsync. Focused, platform/stress/package qualification and throwing-refund correction complete. Original elapsed gains remain diagnostic. No repeat of unchanged checks. |
| Fully qualified storage | `8ec7bfab` R271 immutable admitted reader windows replace per-line payload copies without enlarging ordinary strings. 5,506 focused actual-target case-executions (overlapping filters), including refusal/cancellation and CSV/gzip/regex. Six complete scripts/both APIs/compile pass. Desktop allocation: search −18%, captured text/JSON −5%; report/CSV flat. Elapsed mixed, including report adversity. B622 search elapsed−2..−6%, CPU−0.8..−7%; text/JSON CPU uncertain. B623 confirms report elapsed+0.6..+2.8%, accepted debt for storage/allocation benefit. First full43223095054 fails an inherited close-refund fixture (public17,443 each pass); corrected private/shared-capacity fixture passes68 focused actual-target cases. Production unchanged; corrected-source GREEN43225489349 on beeb828e closes full delivery. [Evidence](benchmarks/results/2026-11-12-reader-windows/README.md). |
| External baseline refreshed | `8ec7bfab` vs CPython3.13.16: native search warm1.54–1.56× /compile-to-result1.45–1.48×, captured-text warm1.60–1.68×, JSON warm0.86× /fresh0.86–0.87×, report warm1.20–1.23×. Compile search0.91–0.93× /JSON1.00–1.03×. Older CSV/guarded/text/UTF-16 phases remain source-labelled. [Guide](docs/BENCHMARKS.md), [eight bounded jobs/source proof](benchmarks/results/2026-11-12-reader-cpython-checkpoint/README.md). |
| Independent regex | Immutable dev73/eae880c8 compatibility complete:86internal/532public per actual target. Core development stays independent; normal optional nonpackable adapter remains0.4. Only affected released-adapter capabilities await producer support below. |

Already delivered: direct calls, reused workers/shared workspace, lexical cells,
captured helpers, CSV row adoption/shared keys, bulk UTF-8/JSON, integer-container
accumulation, private totals and final-byte output. Preserve them and their fixes.
Historical evidence belongs in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable
results; old ignored plans are snapshotted privately.

## Active deliverables

1. **R273 native operation facts — committedcb8f59c3, delivery active.** Remove the
   embedded ordinary instruction/physical positions/opcode and unused third word.
   Nodes now hold semantic operation/source facts; existing guard/evaluator and
   ordinary executable route remain. No controller/arena/solver/cache/option.
   1,032focused actual.NET11/10 checks and six scripts/both APIs/compile/fresh pass.
   Managed array diagnostics72→48B pernode; affected script compile allocation
   −0.06..−0.18%, warm flat. B627four jobs184.637s; moving6–8%reference controls
   leave CPU uncertain. Retain actual representation/storage simplification,
   not a CPU forecast; all adverse/first56B form/staging conditions preserved.
   Full43240684453 is active on cb8f59c3: Windows/Ubuntu, actual.NET11/10,
   original stress and installed Release consumers. Continue independent work. No unchanged earlier qualification replay.
   [Evidence](benchmarks/results/2026-11-12-native-operation-facts/README.md).
2. **Continue the substantial frontier below after the fact migration.** Current
   captured-text execution remains1.60–1.68× CPython; compilation is near parity
   in measured search/JSON. Use the saved source/cost evidence, without replaying
   unchanged profiles or promising speedups from leaf shares. Text sizing currently
   scans before effects and consumption scans again; range inventories add storage
   and analytic bounds can over-admit heavily. Preserve eager preflight; do not
   automatically promote either alternative or reopen memory tracing.
3. **Independent regex track.** Core architecture is implemented; continue useful
   contract work independently of the precise final producer gaps below. No repeat
   qualification of unchanged APIs or blanket dependency stop.

## Closed checkpoint

- R269/R270/R271 are delivered and fully qualified at beeb828e (cached GREEN).
  Accepted R271 report elapsed debt+0.6..+2.8%, conservative window retention and
  source/binary limits remain in [evidence](benchmarks/results/2026-11-12-reader-windows/README.md).
- B624/B625 refresh eight bounded external jobs with separate phases and current
  source proof. Guide updated; no cross-collection attribution or unchanged retiming.
- R272 records one captured-text profile and two segment-entry forms,742focused
  checks each, six scripts/both APIs. Allocation flat; affected desktop elapsed
  adverse. Both withdrawn, all568production hashes restored/nonincrementally rebuilt,
  80restored checks pass. No dormant segment/cache/option remains. Original/adverse
  conditions and the bounded refinement survive in
  [evidence](benchmarks/results/2026-11-12-captured-text-costs/segment-entry-withdrawn/README.md).
  These forms are rejected, not a permanent architecture ban. No further VM run
  is justified by their added state and current evidence; new work may reopen them.

## Redesign roadmap

| Priority / hypothesis | Eliminated work, affected scripts | Semantic acceptance / completion and decision |
| --- | --- | --- |
| Call/frame/body construction | Guarded/native search, captured text, CSV validation and report helpers. Eliminate a complete duplicate binding/preparation/proof stage, rather than wrapping the same binder or adding a controller. Existing profiles show real instruction/transport work, not a removable second frame/array. | Produce end-to-end source/removal proof with one authority for effects and continuation. Preserve defaults/keywords/descriptors, argument snapshots/order, closures, generators, handlers, actual suspension/reentry, native borrows and cleanup. Then six existing complete scripts, separate compile/warm/allocation, one bounded affected/control comparison. Delete displaced route/metadata at completion; explicitly decide any remaining regression debt. Revise the design if proof only renames work. Current instruction format already compacts fields into five operand words and dispatch reads it by reference; do not claim either as a new optimization. |
| Per-record construction / remaining conversions | CSV/text/JSON/report: eliminate a remaining complete scanner, collection-construction or conversion stage. Current row adoption/shared keys and integer/UTF-8 paths already exist. R271 addresses the reader-to-string payload-copy stage. | Header mutation/order, Unicode expansion/context, hooks/aliases, capacity/overlap, refusal before mutation, retained results and cancellation agree. Complete affected/control scripts. Source inspection finding no removable stage redirects effort; no broad ownership audit or accumulation of isolated special cases. |
| Scalar / operand representation | Demonstrated dispatch/boxing costs in counters, indexes and aggregation. Target operand transport or a complete representation boundary; boxing alone is not evidence of dominant cost. | Exact integer promotion, bool/int semantics, identity/aliases and funded projection. Universal tagged slots require a complete migration/deletion milestone and explicit regression-debt decision. Use current profiles before another targeted capture. |
| Frontend consolidation | Newly generated config/report/helper scripts; eliminate an actual repeated traversal or retained representation. Shared lexical/compiler facts and annotation demand already ship. | Preserve diagnostics, scopes, annotations, imports/generators, cancellation and admission. Compare compilation separately. Delete the displaced pass; no speculative JIT/compiler rewrite merely because several passes exist. |

Former bulk-CSV6–8% work was reassessed and revised into current construction;
inspect present relevance before any new form, not automatic promotion/replay.
Call-arena~5–7%, call-control~2–4% and shared-prefix text CPU+29–53% regressions
remain lessons about recurring transport/control cost. R268's broader ordered
prefix/body form was refined then withdrawn after B617/B620 CPU regressions;
all568 qualified production hashes were restored/nonincrementally rebuilt.
Its independent partial-formatting/I/O/cancellation regression survives.
[Original/refinement/withdrawal](benchmarks/results/2026-11-12-ordered-helper-prototype/README.md).
These outcomes reject measured forms, not permanently close architecture choices.

## Measurement / stopping criteria

- Architectural simplification, allocation reduction, allowance use and demonstrated
  CPU improvement are separate outcomes. Fixed improvement percentages inform a
  decision; they do not automatically veto a useful redesign.
- Timeout, moving unchanged control or inconclusive observations establish
  uncertainty. Allow bounded confirmation, refinement or measurement correction
  when evidence justifies it. Retain original conditions and every adverse result;
  no blanket one-attempt/no-retiming/permanent-closure rules.
- Size runs for usable observations on the existing quiet VM. A source proof,
  focused checks and one short affected/control comparison normally decide a form;
  explicitly state the unresolved question and bounded next observation for any
  justified follow-up. No open-ended qualification campaign or routine10min lanes.
- Focused Release semantics/effective cancellation/ownership during iteration.
  Batch Windows/Ubuntu, actual.NET11/10, original stress and installed Release
  consumers at retained-source delivery checkpoints. Force nonincremental builds
  after restored timestamps before no-build checks or worker freezes.
- Separate compilation, warm and compile-to-result. Record source/runtime/machine,
  normal GC/tiering, startup/reset/protocol, I/O, goldens and prior/final cleanup.
  Pending-I/O latency, RSS, large-file throughput and embedding-tail impact remain
  unqualified. Historical narratives do not belong in current docs.

## Independent regex

Continue the Lython-owned Python/native-UTF-8 contract: byte/scalar coordinates,
original-subject windows, effective flags, current tokens and explicit cache/result
owners. Core remains decoupled. Immutable development producers and adapter-local
bridges may support tests. Contract tests, semantic qualification and actual backend
performance/memory/safety claims stay separate. No unchanged qualification/release
polling. Missing publication blocks only the corresponding final adapter check:

- Independent single-match working/result owners.
- Native UTF-8 group-name enumeration; lookup exists.
- Token-independent cursor construction with cancellable preparation; per-move
  checks do not prove preparation interruption.

Relevant APIs are unchanged through dev68–73. Remove adapter conversions and
DetailedData when supported; missing producer publication never blocks core work.

## Lasting contracts

Fully managed/memory-safe; preserve managed stack admission, host mediation,
cancellation, cycle/XML-depth safety, checked representation and bounded I/O.
No unsafe code, fuel/quotas, independent caps/hidden allowance, tracing/weak
reclamation, forced GC, retries or abandoned users. Borrowed shared allowance funds
capacity, overlap, results/aliases/caches and pending users through awaited cleanup.
First admission refusal is terminal with original structured origin; guest-raised
MemoryError stays catchable. Original path/Cwd requests remain host mediated;
refused copy preserves destination. Bounded streaming uses host-driven commands.

GC fixtures stay nonparallel. Cache terminal CI/VM states and space live CI checks
minutes apart. Archive/verify persistent evidence under the lease after joining
users, before RAM cleanup. Retire exact duplicates/superseded images only with
committed canonical Git/SHA and fresh UID/path/inode/all-alias proof; keep existing
OS/evidence floors and qualified/current images. No sibling edits/publication.
