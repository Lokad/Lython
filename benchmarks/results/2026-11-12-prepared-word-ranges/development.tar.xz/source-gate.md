# R274 source gate

Baseline cb8f59c3, clean tracked tree. Prepared casing currently scans the complete
source before effects to fund word payloads, then scans whitespace again while
consuming. Shared collector already emits (start,end,capacity). The execution
already owns one reusable function workspace cache and stack retirement for
ExecutableTemporaryValue, conservatively covering GetIter slots.

Prototype replaces the second scanner with cursor indexing and consolidates the
cache implementation for two explicit typed buffers. No global pool, tracing,
registry, new allowance or policy. Active loans remain funded; cache shutdown
refunds only idle loans. Eager output funding remains. Exhausted dictionary
segments must restore pending bindings before returning the range loan, since
refund can reenter. Source remains immutable through all users. A cursor is a
private executable temporary, never a Python exposed list/iterator substitute.

Costs to measure: inventory copy, array initialization/clearing, cursor allocation
shape, generic cache call overhead, long-line scratch overlap. Three-word and
empty lines in the captured-text fixture are existing representative input, not a
new dispatch threshold. No speedup forecast from profile leaf shares.
