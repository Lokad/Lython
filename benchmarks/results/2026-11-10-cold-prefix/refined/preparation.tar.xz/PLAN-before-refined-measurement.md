# Lokad.Lython 0.11.0

Updated 2026-11-10. Git-ignored; never force-add. Publication/tagging postponed.
Goal: coherent simplification and substantial whole-script improvement. Completing
an isolated experiment does not finish it. Current contracts live in docs/;
historical evidence lives in benchmarks/results/ and benchmarks/EXPERIMENTS.md.
Prior detailed plans remain privately under .git/agent-notes/review-20261031/.

## Actual delivery status

Main runtime **66ebdb4b is fully qualified** by cached GREEN42822411897:
Windows/Ubuntu, actual .NET11/10 ordinary, original Stress and installed Release
consumers. Receipt recorded once in the method-context evidence. Never re-query
terminal runs/repeat unchanged qualification. Main has no runtime changes from R200.
R200 original9e0b is isolated, tested and measured, not promoted; refinement below.

| Deliverable | Status / remaining uncertainty |
| --- | --- |
| Shared compiler facts; direct UTF-8 formatting/storage; native helper returns | Delivered/fully qualified. Helper allocation−19.92%sync/−19.31%async; original elapsed diagnostic. Formatting allocation−8.67%, controlled elapsed/CPU about5–8% lower; original adverse15.125ms remains unexplained/preserved. |
| Shared binding, dictionary accumulation, receiver-native entry | Delivered/fully qualified through1a83. Source-pair gains and adverse controls remain linked in experimental history. Do not recreate shipped optimizations. |
| R196 iterative JSON construction/decoder admission | Delivered/fully qualified8d44. Removes recursive container completion/leaf admission/pending numeric-frame transport. Modest report benefit, flat allocation; text/JSON-lines uncertainty. Entry may deny earlier near managed nesting bound. |
| R197 CPython refresh | Complete/committed28cb. Postcommit8d44/E294,9jobs245.513s, all gates. Warm report1.22–1.24×, text1.43–1.46×, JSON-lines0.89–0.92×CPython3.13.16. Guide separates phases/I/O/cleanup and keeps variation/history visible. |
| R198 scope-based ordinary methods | Delivered/fully qualified66eb. About28.5% less CLR allocation bothAPIs; quiet class-report elapsed7–10%lower sync/5–10%lower async, supporting widerCPU. Plain report inconclusive; desktop asyncCSV/compile adversity remains. |
| R199 current-text attribution | Complete/committeda632.1144samples/6.21%unknown, all gates. Prefix19.58%, operand transport5.86%, native call selection6.99%, text15.21%, dictionary/hash12.85% include useful work. No prominent frame/binder category. No unchanged recapture. |
| R200 cold-body extraction | Original private prototype9e0b; main unchanged. Code/frame shape improves but adds a helper frame, allocation flat, controlled CPU mixed. Original preserved; not promoted. Bounded jump-transport refinement selected below. |
| Regex | Core contract independent/delivered. Optional normal adapter pin0.4 unchanged; dev64 development-qualified, dev65 source-only gate. Only affected final adapter qualification waits. |

R188 integer-local and R194 continuous-prefix variants were withdrawn; their
allocation results, larger-code/frame debt and slower call-arena/control lessons
remain. R195 attribution is partial (configuration/final gates missing), with
offline thread correction preserved. Do not silently relabel these as qualified.

## Active R200: consolidate cold-operation result transport

Evidence: benchmarks/results/2026-11-10-cold-prefix/. Original source on a632,
reference039 matches qualified66eb; prototype9e0b has one private synchronous helper
for target/general/yield/definition/container/context-manager/slice opcode bodies.
Original inline bodies deleted; native call/operand/formatting/iteration/control
paths and outer instruction exception/cancellation/disposal boundary stay intact.
No new state/owner/option/backend. Source+27lines; this is not a line-count reduction.

Windows JIT: simple-loop OSR8932→6725B, primary stack subtraction512→336B. Generator
OSR11083→9218B/544→416B, plus helper2363B Tier0/896B primary subtraction; optimized
helper not observed in the bounded longer confirmation. No total stack/code or
Linux-byte reduction claim. Focused6838public/1237internal pass eachactual11/10.
Current cancellation, terminal refusal, managed stack safety, retained users and
genuinely suspended protocol/cleanup paths remain covered; no new architecture-only tests.

B550 six jobs215.904s passes identity/goldens/ownership/quiet/join/RAM/archive/SHA.
Warm text elapsed+0.50..1.79%/CPU+0.29..0.85%; report elapsed−3.77..−0.74% but CPU
uncertain. CSV/generator inconclusive. Search candidate processes differ14.76%,
so their−5.22..+9.41% range cannot establish a gain/regression. Compile inconclusive;
allocation effectively flat. All desktop adversity and original conditions survive.
The original variant remains unpromoted. Uncertainty is not a failed design.

**Selected bounded refinement, before editing:** remove the helper's duplicate
`out bool jumped`. Its existing `ValueTask<bool>` already carries jump status across
pending context-manager work; use that same result for completed/synchronous
operations. Main consumes it through existing ConsumeOperation after Continue,
as comparison/iteration already do. Delete the extra output/duplicate writes;
add no enum, state carrier, dispatcher framework, policy or switch. Hypothesis:
consolidate one jump invariant and reduce output/address transport while keeping
the coherent hot/cold footprint benefit. No speedup prediction or automatic promotion.

Preserve original9e0b/source/cores before mutation. Focused checks must cover match
case failure jumps, synchronous/asynchronous context-manager suppression, protected
control flow, yields/delegation, error spans/order, cancellation/first refusal,
owned operands and joined cleanup. Use existing ContextManagerSubsystemTests,
ProtectedLoopControlTests, ProtectedLoopCompilationTests plus generator/exception/
ownership regressions; no checkpoint-count tests. Force-build/freeze the refined
image, inspect actual code/frame, reuse short five-script diagnostics. If justified,
one bounded controlled source pair covers complete CSV/text/report/search/generator
warm executions; original compile controls already show uncertainty, no frontend
change. Keep async semantics/genuine suspension checks and all adverse observations.

Decision milestone: retain/refine/remove with explicit whole-script outcome and
remaining regression debt. Code size, allocation and CPU are separate; fixed
percentages inform judgment. Extend confirmation only for explicit new evidence,
preserving original conditions; no blanket permanent one-attempt rule. Delete
a withdrawn implementation completely; retain no dormant backend. Initial original
prototype remains intact in private cold-prefix-r200/tree. Refinement not implemented
yet; no active local/VM work. B550 terminal cached, reference039/priorE294/prototype9e0b
images retained. Never restart/re-probe terminal owners or known-retired copies.

## Remaining redesign roadmap

1. Finish R200's coherent instruction/result-transport milestone before further
   local tweaks. Shared final slots, native receiver entry, deferred contexts and
   prepared operands already exist. Follow measured costs; no new argument arena,
   call-control protocol, alternate engine or universal tagged-value commitment.
2. Text: about1.45×CPython remains. R199 source gate found already-fused case-capacity
   collection/direct final UTF-8 words, direct current-token native hashing and no
   host resize on MemoryGovernor.Commit. A new milestone must remove a different
   material intermediate/pass. Do not weaken checks or reopen a broad ownership audit.
3. Per-record construction: B74's6–8% opportunity already shipped in revised native
   constructors, row-array adoption and shared keys. Source reassessment preserved
   original growth adversity. New work needs a different allocation/scan; preserve
   mutable/custom/duplicate/wide headers, reentry, retained rows and refusal rollback.
4. Frontend: shared compiler facts delivered; remaining passes often compute distinct
   facts. R195 proves no dominant duplicate. Identify a measured repeated walk/retained
   form before consolidation and delete it. Uncached compile-to-result target, warm
   control, Python diagnostics/scoping/imports preserved; no heavyweight JIT assumption.

For each selected redesign record hypothesis, complete affected scripts, work/storage
eliminated, displaced code, semantic gates and bounded controls BEFORE editing.
Temporary setbacks can support a coherent migration with a completion/debt decision;
do not accumulate them indefinitely. Refresh representative CPython rows at coherent
milestones, separating compile/warm/compile-to-result, I/O and cleanup; historical
rows describe their exact source, never arbitrary HEAD. Publication stays held.

## Independent regex delivery

Lython-owned Python semantics/native UTF-8 names/data, byte ranges/scalar positions,
original-subject windows, effective flags/captures/replacements/errors and explicit
pattern/cache/result ownership/current-token work remain independent of the backend.
One provider across frontend/runtime/imports; no backend types/dependencies in core.
Development producers/adapter-local bridges can support independent implementation.

Immutable dev64/9af7141f development-qualified86internal/524public eachactualtarget
on unchanged dev59bridge. Supplied dev65/998c630f has identical APIXML/production C#;
source-only gate committedd836. No new-byte safety/performance qualification, pin
promotion or unchanged test replay. Precise missing capabilities: separate single-
match working owner, native UTF-8 group-name enumeration, token-independent cursor
creation (per-move tokens exist). Only affected final released-adapter checks wait.
Core contract tests, semantic validation and backend performance/safety are distinct.
Keep in-flight current-token cancellation, terminal refusal and retained cache/result
funding/reuse effective. Qualify final immutable released package when supplied.

## Delivery and lasting constraints

Focused Release checks during iteration; batch Windows/Ubuntu, actual11/10, original
Stress and installed Release consumers at retained delivery boundaries. No overlapping
local builds/tests/timing. Force nonincremental builds after timestamp restores/before
freezing. CI observations>=5minapart, terminal results cached. No unchanged replay.

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native stack probing.
Preserve managed stack/recursion admission, host mediation, CancellationToken,
cycle detection, checked representation bounds, XML depth and bounded I/O chunks.
Borrowed-root coarse preflights fund capacity/replacement overlap, retained aliases,
caches/results/pending users through awaited cleanup. First refused admission stays
terminal with original attribution. No quotas/watchdogs/hidden independent caps,
guest-heap tracing, weak reclamation, forcedGC or new ownership infrastructure.

Only core Release packages via tools/pack.ps1 to artifacts/nuget/; adapter nonpackable.
No publication/tagging. VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent
workers/catalogs/evidence, RAM only for guest fixtures. Preserve idle lease, joins,
archive/SHA and exact canonical-copy/all-alias retirement proofs. Fixed240MiB disk
floor/12MiB setup headroom; derive staging needs from actual uncompressed payload,
preserving source images/sole evidence. B550 retired only three canonical duplicate
compressed archives from B547/B548/B549; receipt has exact paths. Do not probe those
missing copies. Other historical retirements remain in receipts, not repeated here.
