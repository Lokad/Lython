from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
h=Path(__file__).parent;d=h/'refined-diagnostic';d.mkdir();old=h/'diagnostic';t=h/'tree'
assert all('Passed!'in(h/('refined-'+name+'-'+framework+'.log')).read_text(encoding='utf-8')for name in ['public','internal']for framework in ['net11.0','net10.0'])
for role in ['before','candidate']:shutil.copytree(old/'images/before',d/'images'/role)
shutil.copyfile(h/'refined-simple-jit/image/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
for name in ['catalog.json','hash-witness.json','script-goldens.json']:shutil.copyfile(old/name,d/name)
before=h/'original-source/LythonRuntime.Executable.Interpreter.Dispatch.cs';after=t/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs'
(d/'original-to-refined.patch').write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(keepends=True),after.read_text(encoding='utf-8').splitlines(keepends=True),fromfile='original9e0b',tofile='refined')),encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision='a63229c2; reference039 matches fullyqualified66eb/CI42822411897 GREEN.',cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},source={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),status='Isolated single pending-result refinement, not promoted/final-qualified.',focused='218public/939internal eachactual.NET11/10; original broader6838/1237 preserved. Forced-build/JIT frozen; source unchanged afterward.',jit='Simple OSR6733B/336B; generator9219B/416B; helperTier02443B/960B. Windows diagnostics, no total stack/code or CPU gain claim.',reuse='Exact original five scripts/fixtures/independentPython goldens/worker/aux bytes. Existing original compile controls remain; no frontend change. Only sync/async warm diagnostics selected.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(h/'measure.py').read_text(encoding='utf-8').replace("d=h/'diagnostic'","d=h/'refined-diagnostic'")
old="[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds'),('compile','sync','elapsedMilliseconds')]";assert s.count(old)==1;s=s.replace(old,"[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds')]")
ast.parse(s);(h/'measure-refined.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['cores'],unchangedScriptsAndAuxiliaries=True,phases=['warm','warm-async'],sourceFiles=len(identity['source'])),indent=2),flush=True)
subprocess.run(['python','-X','utf8',str(h/'measure-refined.py')],check=True)
