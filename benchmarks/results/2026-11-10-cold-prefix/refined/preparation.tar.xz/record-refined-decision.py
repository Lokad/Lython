from pathlib import Path
import hashlib,json,shutil,tarfile
h=Path(__file__).parent;repo=Path('D:/code/Lython');d=h/'refined-diagnostic';p=h/'b551';dest=repo/'benchmarks/results/2026-11-10-cold-prefix';out=dest/'refined';out.mkdir()
identity=json.loads((d/'identity.json').read_text(encoding='utf-8'));assert len(identity['source'])==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in identity['source'].items())
receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==6 and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','summary.json','identity.json','terminal-status.json','extraction.json']:shutil.copyfile(p/name,out/name)
for phase in ['warm','warm-async']:
 folder=out/'desktop'/phase;folder.mkdir(parents=True)
 for name in ['measurements.json','summary.json','stderr.txt']:shutil.copyfile(d/phase/name,folder/name)
for name in ['identity.json','source.patch','original-to-refined.patch']:shutil.copyfile(d/name,out/('source-'+name))
(h/'refined-setup-condition.json').write_text(json.dumps(dict(condition='Initial edit refused transactionally because a hunk named a nonexistent slice overload; no source write/build/measurement occurred. Corrected hunk uses actual existing signature.',runtimeOrMeasurementFailure=False),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
 for path in sorted(h.rglob('*')):
  if not path.is_file():continue
  rel=path.relative_to(h)
  if rel.parts[0]=='tree'or'retrieved'in rel.parts or'images'in rel.parts or'image'in rel.parts or path.name in ['observations.tgz','payload.tgz']:continue
  if rel.parts[0]in ['diagnostic','refined-diagnostic']and len(rel.parts)>1 and rel.parts[1]in ['warm','warm-async','compile']:continue
  a.add(path,arcname=rel.as_posix())
 for name in identity['source']:a.add(h/'tree'/name,arcname='refined-source/'+name)
rows=[]
for x in json.loads((p/'summary.json').read_text(encoding='utf-8'))['timing']:
 e=list(x['changePercent'].values());c=list(x['processCpuChangePercent'].values());sp=x['controlSpreadPercent'];rows.append(f"| {x['case'].removeprefix('scripts.')} / {x['lane']} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {sp['reference']:.2f}% / {sp['candidate']:.2f}% |")
with(dest/'README.md').open('a',encoding='utf-8',newline='\n')as file:file.write('''

## Single-result refinement and decision

Frozen6e52 removes the duplicate out-bool jump channel. Completed operations return
the same ValueTask<bool> decision as suspended work, consumed centrally; yield-from
still observes errors before deciding its yield boundary. No new enum/state/owner
or dispatch mode. Focused218public/939internal pass on each actual.NET11/10,
including match/context-manager jumps, real suspension/cancellation, terminal
refusal and joined ownership cleanup. Original broader gates remain preserved.

Windows simple-loop OSR6733B/336B, generator9219B/416B; helperTier02443B/960B.
This does not improve the hot frame further and increases the observed helper frame.
[Refined source/patch](refined/source-source.patch), [identity](refined/source-identity.json),
[all diagnostics/JIT/source/logs](refined/preparation.tar.xz). All568 source hashes
match the frozen refinement. The unchanged original compile controls are reused;
no frontend change or causal compile-gain claim. Desktop allocation remains flat,
with CSV/text/generator gains alongside syncsearch+5.2..8.3% and asyncreport+1.6..3.6%
adversity; [all desktop data](refined/desktop/) survives.

B551 completes six jobs217.415s with all identity/output/ownership/quiet/join/
RAM/archive/SHA checks: five same warm scripts plus async report, identical worker,
adapter0.4, role controls,5s warmup and seven rotated400ms rounds. [Raw evidence](refined/observations.tgz),
[all pairings/medians/IQR](refined/summary.json), [receipt](refined/archive-receipt.json).
Clock boundaries and range limitations are the same as the original above.

| Complete workload / phase | Elapsed change | Wider process CPU | Reference / candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Decision: **withdraw both variants**. The smaller hot code does not establish
enough useful work eliminated to offset the added dispatch/helper frame and
remaining regression debt. The refined generator's modest improvement remains
valid evidence; ordinary text is adverse, search stays adverse/variable, and
CSV/report controls are inconclusive. Flat allocation provides no storage benefit.
This is a workload/complexity/debt decision, not a percentage veto or a declaration
that uncertain controls prove a failed design. Both variants and all adverse data
remain available for a changed design with new evidence; no unchanged retiming.

Main stays fully qualified66ebdb4b. The private implementation will be removed
after committed archive verification; no dormant runtime/backend will survive.
No new semantic tests or public options need removal. No full platform/package
replay for withdrawn code. Next source assessment targets actual hot operand/result
work rather than moving cold bodies; broader performance/independent regex tracks
remain active. Publication stays postponed.
''')
exp=repo/'benchmarks/EXPERIMENTS.md';s=exp.read_text(encoding='utf-8');a=s.index('The [R200 cold-body prototype]');b=s.index('\nThe [R199 current-text attribution]',a)
s=s[:a]+'''The [R200 cold-body variants](results/2026-11-10-cold-prefix/README.md) are withdrawn.
Original/refined code and focused semantic gates pass; hot code/frame shrink while
an extra helper frame remains. Original/refined six-job comparisons preserve
modest report/generator benefits, text/search adversity and variable controls.
Allocation is flat. Added dispatch/frame and regression debt do not justify keeping
the code. Both variants survive as evidence, without a permanent design veto.
'''+s[b:];exp.write_text(s,encoding='utf-8',newline='\n')
plan=repo/'PLAN.md';s=plan.read_text(encoding='utf-8');shutil.copyfile(plan,h/'PLAN-before-withdrawal.md');a=s.index('## Active R200:');b=s.index('\n## Remaining redesign roadmap',a)
s=s[:a]+'''## R200 closed: remove both cold-body variants

Original9e0b and refined6e52 are withdrawn, with complete immutable evidence in
benchmarks/results/2026-11-10-cold-prefix/. Main runtime66eb stays unchanged/fully
qualified. Original6838public/1237internal eachtarget; refinement218/939 eachtarget.
Code/frame diagnostics, both source snapshots, original failures, all desktop/VM
observations and control uncertainty survive. No new architecture-only tests.

Original/refined six-job runs215.904/217.415s pass all gates/join/RAM/archive/SHA.
Refined text elapsed+0.08..2.82%/CPU+0.42..4.39%, search+0.87..8.79%elapsed with
candidate spread7.04%; generator−2.43..−1.13% with CPU−1.56..0%. CSV/report controls
inconclusive; async report−2.19..+2.61%. Allocation flat. Preserve the modest gains
and all adverse results. Smaller hot code adds a helper frame (refinedTier0960B).
No storage disappears; complexity/remaining regression debt outweigh keeping the
extraction. No fixed percentage veto/permanent rejection or unchanged retiming.

Required cleanup now: verify committed archives/source, remove the private linked
worktree, retire only fully archived original/refined VM core aliases under an idle
lease with SHA/path/UID/all-link proofs, preserving qualified039/priorE294. No new
full qualification for withdrawn code. No active local/VM users or RAM fixtures.
Publication remains held. After cleanup assess actual hot operand/result work.
'''+s[b:]
s=s.replace('R200 original9e0b is isolated, tested and measured, not promoted; refinement below.','R200 variants are withdrawn; evidence preserved and cleanup pending below.').replace('R200 original9e0b is preserved/unpromoted. Refined6e52 is isolated, tested and\ncurrently measured; main unchanged.','R200 variants are withdrawn; evidence preserved and cleanup pending. Main unchanged.')
s=s.replace('Original9e0b preserved/unpromoted; refined6e52 implemented and focused-tested. Single pending result replaces duplicate jump output; VM comparison running. Main unchanged.','Both variants withdrawn. Smaller hot code adds a helper frame; controlled whole-script benefit insufficient to carry text/search regression debt. Cleanup below; main unchanged.')
s=s.replace("1. Finish R200's coherent instruction/result-transport milestone before further\n   local tweaks.","1. Finish R200 cleanup, then assess actual hot operand/result transport before\n   selecting the next coherent redesign.")
plan.write_text(s,encoding='utf-8',newline='\n')
print('Both variants preserved; explicit workload/complexity/debt withdrawal recorded. Cleanup remains required.',flush=True)
