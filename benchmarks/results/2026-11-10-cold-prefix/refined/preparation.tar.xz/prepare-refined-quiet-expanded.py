from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;d=h/'refined-diagnostic';p=h/'b551';p.mkdir();repo=Path('D:/code/Lython');old=h.parent/'deferred-method-r198/b548'
source=json.loads((d/'identity.json').read_text(encoding='utf-8'));assert len(source['source'])==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
shutil.copyfile(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll');assert hashlib.sha256((p/'current-core.dll').read_bytes()).hexdigest()==source['cores']['candidate']
for a,b in [('catalog.json','representative.json'),('identity.json','source-identity.json'),('source.patch','source.patch'),('script-goldens.json','script-goldens.json')]:shutil.copyfile(d/a,p/b)
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R200 single-pending-result refinement on a63229c2; reference039 matches fullyqualified66eb. Candidate6e52 unpromoted; original9e0b evidence preserved.',coreSHA256={role:source['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=base['auxiliaryFiles'],catalogSHA256=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest(),protocolSHA256=base['protocolSHA256'],performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('deferred-method-b548-20261110','cold-prefix-b551-20261110').replace('lython-b548-deferred-method-20261110','lython-b551-cold-prefix-20261110').replace('B548 five-job','B551 six-job')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a)
  s=s[:a]+"jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.report-render.large','warm'],['scripts.file-search.large','warm'],['scripts.text-summary-helpers.generator.large','warm'],['scripts.report-render.large','warm-async']]"+s[b:]
  a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R200 refined single pending result; same five complete warm CSV/text/report/search/generator scripts plus async report. Original desktop/VM adversity and helper-frame tradeoffs preserved"+s[b:]
  s=s.replace('R198 ordinary-method context deferral through existing instruction prefix.','R200 cold opcode bodies and hot instruction frame.')
 s=s.replace('len(jobs)==5','len(jobs)==6').replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace('jobs=5','jobs=6').replace("['jobs']==5","['jobs']==6")
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
copies=[]
canonical=repo/'benchmarks/results/2026-11-10-cold-prefix/original/observations.tgz'
assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='dd5b62c85ce4dbe287cf02e986289a171b2b972fa8a02a956955804c9aba9eef'
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
copies.append(dict(path='cold-prefix-b550-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=hashlib.sha256(canonical.read_bytes()).hexdigest(),canonical=str(canonical.relative_to(repo))))
with tarfile.open(canonical)as archive:
 for name in ['confirmation/confirmation.json','representative.json']:
  item=archive.getmember(name);copies.append(dict(path='cold-prefix-b550-20261110/'+name,bytes=item.size,sha256=hashlib.sha256(archive.extractfile(item).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R200 bounded source pair

Reference039/qualified66eb versus frozen6e52 single-result refinement. Same exact five
complete scripts/fixtures/goldens:CSV/text/report/search/generator text. Six jobs:
five warm synchronous plus async report. Original compile controls reused; all adversity and Windows
JIT shape/cold-helper frame tradeoffs retained. No primary CPython replacement.
Four independent source/control processes,5s warmup,7rotated400msrounds.240sowner,
30sstop/30smargin. Preserve all identity/ownership/quiet/join/archive/SHA gates.
No promotion/CPU/equivalence claim before actual results/debt decision.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','exact-copies.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
s=(old/'launch.py').read_text(encoding='utf-8').replace('deferred-method-b548-20261110','cold-prefix-b551-20261110').replace('lython-b548-deferred-method-20261110','lython-b551-cold-prefix-20261110').replace('deferred-method-b548-launch.py','cold-prefix-b551-launch.py').replace('lython-b548-fixtures','lython-b551-fixtures')
s=s.replace("source=base/'json-cpython-b546-20261110/candidate'","source=base/'deferred-method-b548-20261110/candidate'").replace('e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9',source['cores']['before'])
a=s.index('before=shutil.disk_usage(base).free\n');b=s.index(' with tarfile.open(fileobj=',a)
s=s[:a]+'''before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for copy in config['copies']:
   path=base/copy['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(copy,allocatedBytes=st.st_blocks*512))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualified039AndPriorE294Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired)
'''+s[b:]
s=s.replace(" os.link(prototype,root/'current-core.dll')\n",'').replace('jobs=5,ownerSeconds=240','jobs=6,ownerSeconds=240')
payload=(p/'payload.tgz').read_bytes()
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
s=s.replace("required=(240+12)*1024*1024+3*len(payload),copies=[]",f"required=(240+12)*1024*1024+max(3*len(payload),{footprint}),copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8'))")
assert 'prototype='not in s and 'os.link(prototype'not in s and 'max(3*len(payload)'in s;ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=6,catalogCases=5,cores=identity['coreSHA256'],payloadBytes=len(payload),uncompressedFootprintWithMetadata=footprint),indent=2),flush=True)
subprocess.run(['python','-X','utf8',str(p/'launch.py')],check=True)
