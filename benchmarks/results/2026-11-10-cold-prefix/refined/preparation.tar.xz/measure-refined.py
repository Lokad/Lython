from pathlib import Path
import json,os,statistics,subprocess
h=Path(__file__).parent;d=h/'refined-diagnostic';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
for phase,api,metric in [('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds')]:
 p=d/phase;p.mkdir()
 with(p/'measurements.json').open('w',encoding='utf-8')as out,(p/'stderr.txt').open('w',encoding='utf-8')as err:
  r=subprocess.run([dotnet,str(h.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(d/'images/before/Lokad.Lython.Benchmarks.dll'),str(d/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(d/'catalog.json'),str(d/'hash-witness.json'),'reverse','compile'if phase=='compile'else'warm',api],env=env,stdout=out,stderr=err,timeout=120)
 assert r.returncode==0,(p/'stderr.txt').read_text(encoding='utf-8')[-2500:]
 raw=json.loads((p/'measurements.json').read_text(encoding='utf-8'));assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
 rows=[]
 for c in raw['observations']:
  roles={role:{name:statistics.median(s[field]/s['jobs']for s in c['samples']if s['image']==role)for name,field in [('bytes','allocatedBytes'),('runOnlyMs','executionMilliseconds'),('fullEnvelopeMs','elapsedMilliseconds')]}for role in ['before','before-control','candidate']}
  changes={control:{name:100*(roles['candidate'][name]/roles[control][name]-1)if roles[control][name]else None for name in roles[control]}for control in ['before','before-control']}
  rows.append(dict(case=c['caseId'],roles=roles,changePercent=changes));key='fullEnvelopeMs'if phase=='compile'else'runOnlyMs';print(phase,c['caseId'],{control:{'elapsed':round(changes[control][key],2),'allocation':round(changes[control]['bytes'],2)}for control in changes},flush=True)
 (p/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
