from pathlib import Path
import os,subprocess
h=Path(__file__).parent;t=h/'tree';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
public='(Category!=Stress)&(FullyQualifiedName~ContextManagerSubsystemTests|FullyQualifiedName~ProtectedLoopControlTests|FullyQualifiedName~MatchSubjectExpressionListTests|FullyQualifiedName~MatchGuardScopeTests|FullyQualifiedName~LoweredMatchBodyTests|FullyQualifiedName~GeneratorStorageSemanticsTests|FullyQualifiedName~GeneratorCleanupCompositionTests|FullyQualifiedName~GeneratorStatementCompositionTests|FullyQualifiedName~GeneratorTargetCompositionTests|FullyQualifiedName~GeneratorSemanticsScenarioTests|FullyQualifiedName~ExceptionLifetimeScenarioTests|FullyQualifiedName~CooperativeCancellationTests|FullyQualifiedName~DeferredFunctionContextTests)'
internal='(Category!=Stress)&(FullyQualifiedName~ProtectedLoopCompilationTests|FullyQualifiedName~ExecutableException|FullyQualifiedName~Generator|FullyQualifiedName~Pending|FullyQualifiedName~Disposal|FullyQualifiedName~Terminal|FullyQualifiedName~Admission|FullyQualifiedName~Refusal|FullyQualifiedName~DeferredFunctionOwnershipTests)'
for framework in ['net11.0','net10.0']:
 for name,project,selection in [('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj',public),('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj',internal)]:
  log=h/('refined-'+name+'-'+framework+'.log')
  with log.open('w',encoding='utf-8')as out:r=subprocess.run([dotnet,'test',project,'-c','Release','-f',framework,'--filter',selection],cwd=t,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
  print(log.name,log.read_text(encoding='utf-8')[-900:],flush=True);assert r.returncode==0
print('Focused refinement checks pass on both actual frameworks.',flush=True)
