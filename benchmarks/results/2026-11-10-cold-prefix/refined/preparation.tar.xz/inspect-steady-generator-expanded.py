from pathlib import Path
import subprocess
h=Path(__file__).parent;base=(h/'inspect-baseline.py').read_text(encoding='utf-8')
source="def words(text):\n for word in text.lower().split():\n  yield word\ncounts={}\nfor i in range(65536):\n for word in words('ALPHA beta Gamma'):\n  counts[word]=counts.get(word,0)+1\nprint(counts['alpha'],counts['beta'],counts['gamma'])"
for role in ['before','candidate']:
 s=base.replace("out=h/'baseline-jit'",f"out=h/'generator-steady-jit-{role}'").replace("h/'pre-assessment-PLAN.md'",f"h/'generator-steady-PLAN-{role}.md'")
 start=s.index("core=h.parent/");end=s.index('\nshutil.copyfile(core',start)
 s=s[:start]+f"core=h/'diagnostic/images/{role}/Lokad.Lython.dll';assert core.is_file()"+s[end:]
 s=s.replace("source='total=0\\nfor i in range(1000000):total+=i\\nprint(total)'",'source='+repr(source))
 s=s.replace("DOTNET_JitDisasm='*ExecuteInstructionPrefix*'","DOTNET_JitDisasm='*Execute*Instruction*'").replace("'499999500000'in r.stdout","'65536 65536 65536'in r.stdout")
 # Retain all matching method dumps; reports identify prefix/context methods.
 (h/('inspect-generator-steady-expanded-'+role+'.py')).write_text(s,encoding='utf-8',newline='\n')
 subprocess.run(['python','-X','utf8',str(h/('inspect-generator-steady-expanded-'+role+'.py'))],check=True)
