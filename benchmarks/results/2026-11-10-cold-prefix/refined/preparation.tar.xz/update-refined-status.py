from pathlib import Path
import json,shutil
h=Path(__file__).parent;repo=Path('D:/code/Lython');p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');shutil.copyfile(p,h/'PLAN-before-refined-measurement.md')
s=s.replace('R200 original9e0b is isolated, tested and measured, not promoted; refinement below.','R200 original9e0b is preserved/unpromoted. Refined6e52 is isolated, tested and\ncurrently measured; main unchanged.')
s=s.replace('Original private prototype9e0b; main unchanged. Code/frame shape improves but adds a helper frame, allocation flat, controlled CPU mixed. Original preserved; not promoted. Bounded jump-transport refinement selected below.','Original9e0b preserved/unpromoted; refined6e52 implemented and focused-tested. Single pending result replaces duplicate jump output; VM comparison running. Main unchanged.')
start=s.index('**Selected bounded refinement, before editing:**');end=s.index('\n## Remaining redesign roadmap',start)
s=s[:start]+'''The selected refinement is implemented only in the private tree, frozen **6e52**:
remove `out bool jumped`, publish synchronous/complete jump decisions through
existing ValueTask<bool>, and consume completed results centrally after Continue.
Remove per-helper duplicate consumption except yield-from, which must observe
errors before selecting its yield boundary. No enum/state/owner/framework/option.
Original9e0b/source/cores remain preserved and committed in original evidence.

Focused218public/939internal pass each actual11/10. Match failure jumps, sync/async
context-manager suppression, protected loops, generators, error order, cancellation,
first refusal and owned cleanup remain covered. Forced-build/frozen image and all568
source hashes recorded. No architecture-only tests or unchanged full-suite replay.

Refined Windows JIT: simple-loop OSR6733B/336B; generator9219B/416B; helperTier0
2443B/960B. This does not further reduce the hot frame; observed helper frame is
larger. Source consolidation, code/frame footprint and CPU remain separate claims.
Short desktop same-script diagnostics: flat allocation; CSV/text/generator gains
roughly1–7%, but syncsearch+5.2..8.3% and asyncreport+1.6..3.6% adversity retained.
Original compile controls reused; no frontend change or causal compile-gain claim.

**Owned B551 active once**, reference039/qualified66eb versus refined6e52. Six jobs:
five same complete warm scripts plus async report, existing workers/adapter0.4,
four independent source/control processes,5s warmup/7rotated400msrounds,
240sowner/30sstop/30smargin. Observe the same handle only after **2026-11-10
14:17:40.473UTC**. No restart/retiming on observation expiry. No local work active.
Identity/goldens/ownership/quiet/join/RAM/archive/SHA gates required before decision.

Completion: retain/refine/remove with explicit whole-script outcome and remaining
regression debt. Code size/allocation/CPU are separate; fixed percentages inform
judgment. Extend confirmation only for explicit new evidence, preserve original
conditions, no blanket permanent one-attempt rule. Remove a withdrawn implementation
completely and leave no dormant backend. Reference039/priorE294/original9e0b images
remain funded/retained externally; all earlier owners terminal/cached. Publication held.
'''+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
print('Recorded implemented/tested refinement, actual JIT tradeoffs, desktop adversity and single active owned comparison.')
