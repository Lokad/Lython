from pathlib import Path
import os,subprocess
h=Path(__file__).parent;t=h/'tree';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
public='(Category!=Stress)&(FullyQualifiedName~Exception|FullyQualifiedName~ContextManager|FullyQualifiedName~Generator|FullyQualifiedName~Match|FullyQualifiedName~Slice|FullyQualifiedName~Unpack|FullyQualifiedName~Import|FullyQualifiedName~Annotation|FullyQualifiedName~With|FullyQualifiedName~Async|FullyQualifiedName~Cancellation|FullyQualifiedName~Admission|FullyQualifiedName~Refusal|FullyQualifiedName~DeferredFunction|FullyQualifiedName~ClassCell|FullyQualifiedName~Descriptor)'
internal='(Category!=Stress)&(FullyQualifiedName~Executable|FullyQualifiedName~Exception|FullyQualifiedName~Generator|FullyQualifiedName~Stack|FullyQualifiedName~Temporary|FullyQualifiedName~Admission|FullyQualifiedName~Refusal|FullyQualifiedName~Imported|FullyQualifiedName~Annotation|FullyQualifiedName~FunctionClassCell)'
for framework in ['net11.0','net10.0']:
 for name,project,selection in [('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj',public),('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj',internal)]:
  log=h/(name+'-'+framework+'.log')
  with log.open('w',encoding='utf-8')as out:r=subprocess.run([dotnet,'test',project,'-c','Release','-f',framework,'--filter',selection],cwd=t,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
  print(log.name,log.read_text(encoding='utf-8')[-900:],flush=True);assert r.returncode==0
print('Focused semantic/protocol/cancellation/refusal/ownership checks pass on both actual frameworks.',flush=True)
