# Lokad.Lython 0.11.0

Updated2026-11-10. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvement.
One isolated experiment does not complete it. Current contracts: docs/; history:
benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. Detailed prior plans
remain in .git/agent-notes/review-20261031/.

## Actual delivery status

Committed/pushed HEADa63229c2 (evidence); runtime66ebdb4b (R198). Full
qualification42822411897 pending.
Last fully qualified runtime8d44bd4e. No active source prototype. No conflation of
committed, qualified or measured; regex source assessment committedd836b910.

| Deliverable | Status / remaining uncertainty |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Delivered/fully qualified. Native returns allocate−19.92%sync/−19.31%async; original elapsed diagnostic. Formatting allocates−8.67%; controlled B102 elapsed/CPU−5–8%; original adverse15.125ms unexplained/preserved. No repeated qualification selected. |
| Shared Span binding, native dictionary accumulation, receiver-aware native entry | Delivered/fully qualified through1a83c64f. Source-pair gains and adverse controls remain linked in experimental history; do not reapply shipped optimizations. |
| R196 iterative JSON construction and one decoder admission | Delivered/fully qualified8d44. Removes recursive completion/leaf admission/pending numeric-frame transport. Conservative entry may deny earlier near managed nesting bound. Modest report benefit, flat allocation; text/JSON-lines uncertainty remains. Both variants/original failures preserved in benchmarks/results/2026-11-10-iterative-json-construction/. |
| R197 representative CPython checkpoint | Complete, committed28cb. Fresh postcommit8d44/E294,9jobs245.513s, all gates/SHA/join pass. Warm report1.22–1.24×, text1.43–1.46×, JSON-lines0.89–0.92×CPython3.13.16. Report complete/control variation remains visible. docs/BENCHMARKS.md separates compile/warm/compile-to-result and I/O/cleanup. No single-change attribution. |
| Rejected/partial investigations | R188 integer-local and R194 continuous-prefix variants withdrawn; call-arena/control slower lessons retained. R195 report/compile attribution partial, config/final gates absent; offline thread correction preserved. No unchanged replay selected. |
| Regex | Independent contract delivered. Normal optional adapter pin0.4 unchanged; dev64 development-qualified, dev65 source-only assessment below. Missing released capabilities do not stop core work. |

Full Windows/Ubuntu, actual.NET11/10 ordinary, original Stress and installed Release
consumer qualification is cached GREEN in42813970365 (exact8d44). Earlier receipts
remain linked once in evidence. Never query terminal runs/repeat unchanged gates.

## Retained R198 / active delivery qualification

Committed66ebdb4b removes the owner-type proxy from deferred context eligibility;
scope facts alone keep class-cell/super/capture/protected-body requirements. No
new path/cache/option/owner. Per-record ordinary-method context construction is
eliminated in the complete class-renderer report. docs/RUNTIME and CHANGELOG updated.

Focused102public/71internal pass eachactual11/10, plus18supplemental public cases
eachtarget (15overlap) for classmethods/exact method traceback spans. Reentry,
refusal, real suspendedI/O, cancellation, retained aliases and reuse are covered.
Frozen039 source matches all568 committed production files; image is precommit,
not a claimed identical rebuilt DLL. All source/patches/raw evidence are in
benchmarks/results/2026-11-10-method-contexts/.

CLR allocation−28.51%sync/−28.50%async is established separately. B548 fivejobs
179.869s pass all identity/goldens/quiet/join/RAM/archive/SHA gates. Quiet class-report
elapsed−9.71..−7.06%sync/−9.89..−4.62%async with supporting widerCPU. Plain report
control remains inconclusive, CPU up to+1.57% possible debt. Desktop asyncCSV
+6.2..6.5% and compileCSV+17..20% adversity remains unresolved; no general neutrality
or causal compile-gain claim. Retain the coherent scope invariant/frame reduction,
carry debt to later representative checkpoints; no further unchanged retiming.

Original B547 manifest error stopped before warmups/timed jobs; archived3b28b5e4
after joins/RAMcleanup. B548 corrects only control hashes. Preparation refusals/
canonical-copy retirements are preserved; no failed/adverse condition discarded.
All VM owners are terminal/cached, no users/RAM fixtures. E294/039 images retained.

Full Windows/Ubuntu actual11/10 ordinary, original Stress and installed Release
consumers dispatched once, **42822411897**, exact66ebdb4b. Pending; do not infer
success from focused tests. First observation no earlier than 2026-11-10T13:18:56.876848+00:00.
Observed13:24UTC: Windows.NET11 passed/.NET10 running; Ubuntu ordinary11/10
and installed consumers passed, originalStress running. Next observation no
earlier than 2026-11-10T13:29:27.246660+00:00. Checks>=5minapart; cache terminal.
No duplicate full local suite.
Continue independent roadmap work meanwhile. Publication/tagging remain held.

## Completed R199 / next R200 source assessment

Current-text attribution completed one six-second wall window:1,144 execution-thread
samples,6.21%unmapped,5.76threadCPU seconds. Actual active worker selected; raw maps,
all thread CPU, unknowns and wider reset/protocol boundary preserved. All verify,
normal close/join, quiet, temporary-map copy/SHA, RAM unmount and archive/localSHA
checks pass. B549 terminal/cached; no active VM/local users. Evidence:
benchmarks/results/2026-11-10-current-text-attribution/. No elapsed/source gain claim.

Prefix19.58%, operand/result transport5.86%, native call selection6.99%, text
kernels15.21%, native dictionary/hash12.85% include useful/inlined work, not removable
taxes. Monitor5.07% has no proved caller attribution. Frames/binding are not prominent.
Source gate confirms case capacity already collected during whitespace scan,
direct current-token native hashing and no host resize on MemoryGovernor.Commit.
Do not recreate those optimizations, remove checks speculatively or infer a broad
frontend/ownership project. This bounded capture/source gate is complete; no replay.

**R200 priority assessment: hot instruction loop versus cold operation bodies.**
Hypothesis: separating existing cold/contextful operation code/live temporaries from
the hot prefix may reduce JIT code/frame size and operand/dispatch overhead. R194
showed that merely widening a continuous loop can make code/OSR frames larger and
slower. Inspect current method/tier code size, frame and actual source responsibilities
before choosing a replacement; no implementation or speedup prediction selected yet.

Affected whole scripts: text/CSV helper loops and report, with keyword-default
search and compilation controls. Candidate work to eliminate: cold operation locals/
bodies kept live in the hot method and repeated driver transport, where source/JIT
inspection proves it. Retained replacement must delete the displaced inline cases;
one executable engine and existing pause/pending/disposal protocol, no new dispatcher
framework, option, dormant route or giant duplicated native interpreter.

Semantic acceptance: exact instruction/span/error routing and evaluation order;
protected cleanup/return/break/continue, closures/generators; context promotion and
real protocol/host suspension; current cancellation in nonallocating loops and
terminal refusal; funded operands/aliases/pending disposal through joined cleanup.
Use focused Release gates, short allocation diagnostics, then one bounded controlled
complete-script source pair if a material design is justified. Current code/frame
inspection is the stopping point if no concrete eliminated work emerges. Extend
confirmation/refinement only for explicit evidence, retaining original adversity;
no permanent one-attempt or percentage veto. Record completion/regression-debt
decision before promotion. No source changes or new collection launched for R200.

## Next coherent redesigns

1. **Whole calls/frames and operands:** R198 is retained; complete its
   pending delivery qualification. R200 assesses demonstrated instruction/operand
   costs before another frame redesign. Shared binding/final slots,
   native receiver entry, deferred contexts and prepared operands already exist.
   CSV/helper/report targets; text/search controls. Do not introduce another arena,
   control protocol, dormant backend or universal tagged-value representation.
2. **Remaining text representation:** current text remains~1.45×CPython. R199 current
   attribution/source gate is complete; already-fused casing/whitespace and native
   hashing remain. A future milestone needs a different concrete intermediate or
   duplicate pass. No broad ownership audit, unchanged replay or new framework.
3. **Per-record construction:** B74's6–8% opportunity already shipped in revised
   constructors/row-array adoption/shared keys. Reassessment and adverse growth
   evidence are in2026-11-10-record-construction-assessment/. A new milestone must
   remove different material allocation/scan; preserve duplicate/custom/wide and
   mutable headers, reentry, retained rows, refusal rollback and cancellation.
4. **Frontend:** shared compiler facts delivered; remaining passes often compute
   distinct facts. R195 traversal samples prove no dominant duplicate. Select a
   measured repeated walk/retained representation before consolidation; remove it.
   Uncached compile-to-result target, warm control; preserve diagnostics/scoping,
   closures/imports and one-provider semantics. No heavyweight JIT assumption.

For every selected redesign, record hypothesis, complete affected scripts, actual
work/storage eliminated, displaced code, semantic gates and bounded controlled
comparison BEFORE editing. Temporary setbacks can support a coherent migration
with explicit completion/debt decision. Timeouts or unstable controls establish
uncertainty; allow justified confirmation/refinement/measurement correction. Retain
all adverse results/original failed conditions. Fixed percentages inform judgment.

## Independent regex delivery

Continue Lython-owned Python semantics: nativeUTF-8 names/data, byte ranges/scalar
positions, original-subject windows, effective flags/captures/replacements/errors,
explicit pattern/cache/result ownership and current-token work. One provider for
frontend/runtime/imports; no backend types/dependencies in core. Development
producers and adapter-local bridges support independent implementation/testing.

Immutable dev64/9af7141f development-qualified86internal/524public eachactualtarget
on unchanged dev59bridge. Supplied dev65/998c630f has identical APIXML/production
C#; only version properties change. Source-only assessment, no new-byte safety/
performance qualification, pin promotion or unchanged test replay.

Precise missing capabilities: separate single-match working owner; nativeUTF-8
group-name enumeration; token-independent cursor creation (per-move tokens exist).
Only affected final released-adapter qualification waits. Contract tests, semantic
validation and backend performance/safety are distinct. Keep in-flight current-token
cancellation, terminal refusal, retained caches/results and budget reuse effective.
Qualify final immutable released package when supplied; publication remains held.

## Delivery / lasting constraints

Focused Release regressions during iteration; batch full Windows/Ubuntu, actual11/10,
original Stress and installed Release consumers at retained coherent milestones.
No simultaneous local builds/tests/timing. Force nonincremental build after timestamp
restores and before freezing. CI observations>=5minapart; cache terminal results.

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native stack probing.
Preserve managed stack/recursion admission, host mediation, CancellationToken,
cycle detection, checked representation bounds, XML depth and boundedI/Ochunks.
Borrowed-root coarse preflights fund capacity/replacement peaks and retained aliases,
caches/results/pending users through awaited cleanup. First refusal stays terminal
with original attribution. No quotas/watchdogs, independent hidden caps, guest-heap
tracing, weak reclamation, forcedGC or new memory-management infrastructure.

Only core Release packages via tools/pack.ps1 to artifacts/nuget/; adapter stays
nonpackable. No publication/tagging. VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem.
Persistent workers/catalogs/evidence; RAM only for guest fixtures. Preserve idle
lease, joins, archive/SHA and exact canonical-copy/all-alias retirement proof.
Never remove sole evidence/active users/current qualified reference or candidate.
Known superseded images/copies are retired: use receipts, do not probe missing
paths. If space again obstructs preparation, recover a bounded set of committed
duplicate terminal archives in one idle operation instead of repeated tiny cleanup.


## Selected R200 prototype (before editing)

Current frozen039 baseline JIT confirms8932B optimized OSR code and512B primary
stack subtraction, matching earlier source evidence. Logging diagnostics are not
elapsed/CPU measurements. Concrete replacement: move target/delete/unpack/raise,
general operations, yields/delegation, definitions/imports/fallback, set/dict/match,
context-manager and slice bodies into one private synchronous helper returning the
existing InstructionPause/pending/jump outputs. Keep ordinary native call, operand,
formatting, iteration, list/tuple and control paths inline. Delete original cold
case bodies from the hot loop; retain its per-instruction exception/cancellation/
disposal boundary exactly. No new state, backend, dispatch framework or public API.

Hypothesis: fewer cold temporaries/inlined helper bodies in the hot frame reduce
code/frame pressure on complete CSV/text/report loops. Protected, generator and
actual pending operations must retain exact evaluation/error/cleanup semantics;
current admission/refusal, cancellation, stack protection and aliases stay funded.
Run focused Release checks, force-build/freeze and compare JIT code/frame first.
If shape improves coherently, use the existing short allocation/whole-script driver,
then bounded quiet confirmation where useful, with search/compile controls. Preserve
all adversity. Code movement alone or a fixed percentage does not decide retention;
record remaining regression debt and remove a withdrawn prototype fully. This
initial scope excludes moving native fallbacks or redesigning exception routing.
