from pathlib import Path
import json,shutil
h=Path(__file__).parent;repo=Path('D:/code/Lython');ciPath=h.parent/'deferred-method-r198/delivery/ci-state.json';ci=json.loads(ciPath.read_text(encoding='utf-8'));assert ci['terminal']and ci['allRequiredGatesPassed']
dest=repo/'benchmarks/results/2026-11-10-method-contexts';shutil.copyfile(ciPath,dest/'delivery-ci.json')
p=dest/'README.md';s=p.read_text(encoding='utf-8');s+='''

## Delivery qualification

Committed runtime `66ebdb4b6528c62eeaebe7707f7ce522470dd99e` is fully qualified by
[42822411897](https://github.com/Lokad/Lython/actions/runs/42822411897): Windows and
Ubuntu, actual .NET 11/.NET 10 ordinary tests, original Stress and installed Release
package consumers all pass. [Cached terminal receipt](delivery-ci.json). This does
not change measured precommit images, control uncertainty or the retained desktop
CSV debt. Publication remains postponed; later isolated prototypes are not qualified
by this run.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');shutil.copyfile(p,h/'PLAN-before-qualification.md')
start=s.index('Committed/pushed HEAD');end=s.index('\n| Deliverable',start)
s=s[:start]+'''Committed/pushed HEADa63229c2 (evidence); runtime66ebdb4b fully qualified by
42822411897 GREEN. R200 is an isolated uncommitted prototype; main runtime is
unchanged. Regex source assessment committedd836b910. Keep statuses distinct.
'''+s[end:]
s=s.replace('## Retained R198 / active delivery qualification','## Completed R198 delivery')
start=s.index('Full Windows/Ubuntu actual11/10 ordinary, original Stress and installed Release\nconsumers dispatched once');end=s.index('\n## Completed R199',start)
s=s[:start]+'''Exact-source66ebdb4b workflow42822411897 is terminal GREEN (observed13:35UTC):
Windows/Ubuntu, actual11/10 ordinary, original Stress and installed Release
consumers all pass. Receipt linked once in R198 evidence. Never query/repeat it.
Publication/tagging remain held; later isolated changes require their own delivery.
'''+s[end:]
s=s.replace('## Completed R199 / next R200 source assessment','## Completed R199 attribution')
start=s.index('**R200 priority assessment:');end=s.index('\n## Next coherent redesigns',start)
s=s[:start]+'''## Active R200: isolate cold operation bodies

Selected before editing, implemented only in private cold-prefix-r200/tree above
a63229c2. Frozen reference039 (qualified66eb source), prototype9e0b1085. One private
synchronous context-operation helper replaces target/delete/unpack/raise, general
operations, yields/delegation, definitions/imports/fallback, set/dict/match, context
manager and slice bodies inside the hot prefix. Old inline bodies deleted; native
operand/call/formatting/iteration/list/tuple/control paths and existing pause protocol
remain. No new state/backend/options/owner. Production source+27lines from movement,
not a line-count reduction. Main untouched.

Windows.NET11RC3 validated JIT bytes: optimized hot prefix8932→6725B; primary stack
subtraction512→336B (not total stack usage). Instrumented Tier0 also smaller. This
supports timing; it is not CPU or Linux-byte qualification. Unlike R194's wider
loop, original per-instruction exception/cancellation/disposal boundaries remain.

Focused6838public/1237internal pass eachactual11/10. Includes context managers,
exceptions/yields/delegation/imports/slices, real async protocols, cancellation,
first refusal, retained operands/aliases and cleanup. No new architecture-only tests.
Reference/prototype images frozen after forced nonincremental build;568 source
hashes/patch and independent Python3.13.2 stdout/file goldens recorded.

Existing five-case desktop diagnostic running: ordinaryCSV/text/report/file-search
plus existing complete generator-text pipeline (yield is not cold there). Warm,
warm-async and compile separate; all allocations/Run-only/full-envelope clocks
and adverse controls retained. No CPU gain/promotion claim yet. If useful, six-job
quiet source pair covers the five warm scripts plus representative compilation,
5s warmup/7rotated400msrounds,240sowner/30sstop/30smargin. No new framework.

Acceptance preserves exact instruction/error spans and order, protected cleanup,
closures/generators/context promotion, genuine host/protocol suspension, current
cancellation, managed stack protection, terminal refusal and funded users through
joined disposal. Decide retain/refine/remove with explicit regression debt; code
size alone or fixed percentages do not decide. Extend only for concrete evidence,
preserving original failed/adverse conditions. Remove a withdrawn prototype fully.
'''+s[end:]
s=s.replace('R198 is retained; complete its\n   pending delivery qualification. R200 assesses demonstrated instruction/operand\n   costs before another frame redesign.','R198 is fully qualified; no unchanged\n   replay. R200 implements the selected instruction/frame footprint hypothesis\n   before another call-frame redesign.')
if '\n\n## Selected R200 prototype (before editing)'in s:s=s[:s.index('\n\n## Selected R200 prototype (before editing)')]+'\n'
p.write_text(s,encoding='utf-8',newline='\n');print('Recorded terminal full qualification once and isolated R200 actual status.')
