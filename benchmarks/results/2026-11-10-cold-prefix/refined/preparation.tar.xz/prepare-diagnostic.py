from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,tempfile
h=Path(__file__).parent;t=h/'tree';d=h/'diagnostic';d.mkdir();repo=Path('D:/code/Lython')
assert all('Passed!'in(h/(name+'-'+framework+'.log')).read_text(encoding='utf-8')for framework in ['net11.0','net10.0']for name in ['public','internal'])
source=h.parent/'deferred-method-r198/diagnostic/images/candidate'
for role in ['before','candidate']:shutil.copytree(source,d/'images'/role)
gate=json.loads((h/'candidate-jit/source-gate.json').read_text(encoding='utf-8'))
shutil.copyfile(h/'candidate-jit/image/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
assert hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==gate['coreSHA256']
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
catalog=json.loads((h.parent/'receiver-native-entry-r192/diagnostic/catalog.json').read_text(encoding='utf-8'))
catalog['cases']=[c for c in catalog['cases']if'class-callable'not in c['id']]
gens=json.loads((h.parent/'generator-storage-r142/catalog.json').read_text(encoding='utf-8'));catalog['cases'].append(next(c for c in gens['cases']if c['id']=='scripts.text-summary-helpers.generator.large'));assert len(catalog['cases'])==5
(d/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(h.parent/'receiver-native-entry-r192/diagnostic/hash-witness.json',d/'hash-witness.json')
goldens=[]
for c in catalog['cases']:
 fixture=json.loads(c['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='lython-r200-golden-')as directory:
  folder=Path(directory)
  for name,encoded in fixture['inputFiles'].items():
   target=folder/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(base64.b64decode(encoded,validate=True))
  r=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,text=True,encoding='utf-8',capture_output=True,timeout=15)
  assert r.returncode==0 and not r.stderr and r.stdout==c['expectedOutput'],(c['id'],r.stderr)
  assert all((folder/name).read_bytes()==base64.b64decode(encoded,validate=True)for name,encoded in fixture['outputFiles'].items())
  goldens.append(dict(case=c['id'],sourceSHA256=c['sourceSha256'],stdout=r.stdout,allFileGoldensPassed=True,reference='CPython3.13.2, semantic goldens only'))
(d/'script-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision='a63229c2; committed66eb runtime, frozen039 reference; CI42822411897 pending at prototype selection.',cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},source={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),status='Isolated cold-body extraction prototype; no promotion/qualification/CPU gain claim.',focused='6838public/1237internal eachactual11/10; no source changes after forced nonincremental build/JIT freeze.',jit='Optimized prefix8932->6725B; primary stack subtraction512->336B. Windows diagnostics, not Linux timing/CPU qualification.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(cases=[c['id']for c in catalog['cases']],cores=identity['cores'],semanticGoldensPassed=True,imagesFrozen=True),indent=2),flush=True)
