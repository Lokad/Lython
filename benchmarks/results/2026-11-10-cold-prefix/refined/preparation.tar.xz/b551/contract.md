# R200 bounded source pair

Reference039/qualified66eb versus frozen6e52 single-result refinement. Same exact five
complete scripts/fixtures/goldens:CSV/text/report/search/generator text. Six jobs:
five warm synchronous plus async report. Original compile controls reused; all adversity and Windows
JIT shape/cold-helper frame tradeoffs retained. No primary CPython replacement.
Four independent source/control processes,5s warmup,7rotated400msrounds.240sowner,
30sstop/30smargin. Preserve all identity/ownership/quiet/join/archive/SHA gates.
No promotion/CPU/equivalence claim before actual results/debt decision.
