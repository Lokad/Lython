from pathlib import Path
import ast,subprocess
h=Path(__file__).parent;s=(h/'prepare-quiet.py').read_text(encoding='utf-8')
s=s.replace("d=h/'diagnostic'","d=h/'refined-diagnostic'").replace("p=h/'b550'","p=h/'b551'").replace('cold-prefix-b550-20261110','cold-prefix-b551-20261110').replace('lython-b550-cold-prefix-20261110','lython-b551-cold-prefix-20261110').replace('cold-prefix-b550-launch.py','cold-prefix-b551-launch.py').replace('lython-b550-fixtures','lython-b551-fixtures').replace('B550 six-job','B551 six-job')
s=s.replace('R200 isolated cold-body extraction on a63229c2; reference frozen039 matches qualified66ebdb4b. Candidate9e0b not promoted/final-qualified.','R200 single-pending-result refinement on a63229c2; reference039 matches fullyqualified66eb. Candidate6e52 unpromoted; original9e0b evidence preserved.')
old="['scripts.text-summary-helpers.large','compile']]";assert s.count(old)==1;s=s.replace(old,"['scripts.report-render.large','warm-async']]")
s=s.replace('R200 cold-context bodies out of hot prefix; same five complete CSV/text/report/search/generator scripts plus text compilation. Desktop adversity and JIT tradeoffs retained','R200 refined single pending result; same five complete warm CSV/text/report/search/generator scripts plus async report. Original desktop/VM adversity and helper-frame tradeoffs preserved')
a=s.index('copies=[]\n');b=s.index("(p/'exact-copies.json')",a)
s=s[:a]+'''copies=[]
canonical=repo/'benchmarks/results/2026-11-10-cold-prefix/original/observations.tgz'
assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='dd5b62c85ce4dbe287cf02e986289a171b2b972fa8a02a956955804c9aba9eef'
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
copies.append(dict(path='cold-prefix-b550-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=hashlib.sha256(canonical.read_bytes()).hexdigest(),canonical=str(canonical.relative_to(repo))))
with tarfile.open(canonical)as archive:
 for name in ['confirmation/confirmation.json','representative.json']:
  item=archive.getmember(name);copies.append(dict(path='cold-prefix-b550-20261110/'+name,bytes=item.size,sha256=hashlib.sha256(archive.extractfile(item).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
'''+s[b:]
s=s.replace('Reference039/qualified66eb versus frozen9e0b cold-body prototype.','Reference039/qualified66eb versus frozen6e52 single-result refinement.').replace('five warm synchronous plus text compilation. All desktop adversity and Windows','five warm synchronous plus async report. Original compile controls reused; all adversity and Windows')
ast.parse(s);path=h/'prepare-refined-quiet-expanded.py';path.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8',str(path)],check=True)
