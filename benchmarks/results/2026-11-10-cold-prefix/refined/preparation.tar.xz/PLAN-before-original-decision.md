# Lokad.Lython 0.11.0

Updated2026-11-10. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvement.
One isolated experiment does not complete it. Current contracts: docs/; history:
benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. Detailed prior plans
remain in .git/agent-notes/review-20261031/.

## Actual delivery status

Committed/pushed HEADa63229c2 (evidence); runtime66ebdb4b fully qualified by
42822411897 GREEN. R200 is an isolated uncommitted prototype; main runtime is
unchanged. Regex source assessment committedd836b910. Keep statuses distinct.

| Deliverable | Status / remaining uncertainty |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Delivered/fully qualified. Native returns allocate−19.92%sync/−19.31%async; original elapsed diagnostic. Formatting allocates−8.67%; controlled B102 elapsed/CPU−5–8%; original adverse15.125ms unexplained/preserved. No repeated qualification selected. |
| Shared Span binding, native dictionary accumulation, receiver-aware native entry | Delivered/fully qualified through1a83c64f. Source-pair gains and adverse controls remain linked in experimental history; do not reapply shipped optimizations. |
| R196 iterative JSON construction and one decoder admission | Delivered/fully qualified8d44. Removes recursive completion/leaf admission/pending numeric-frame transport. Conservative entry may deny earlier near managed nesting bound. Modest report benefit, flat allocation; text/JSON-lines uncertainty remains. Both variants/original failures preserved in benchmarks/results/2026-11-10-iterative-json-construction/. |
| R197 representative CPython checkpoint | Complete, committed28cb. Fresh postcommit8d44/E294,9jobs245.513s, all gates/SHA/join pass. Warm report1.22–1.24×, text1.43–1.46×, JSON-lines0.89–0.92×CPython3.13.16. Report complete/control variation remains visible. docs/BENCHMARKS.md separates compile/warm/compile-to-result and I/O/cleanup. No single-change attribution. |
| Rejected/partial investigations | R188 integer-local and R194 continuous-prefix variants withdrawn; call-arena/control slower lessons retained. R195 report/compile attribution partial, config/final gates absent; offline thread correction preserved. No unchanged replay selected. |
| Regex | Independent contract delivered. Normal optional adapter pin0.4 unchanged; dev64 development-qualified, dev65 source-only assessment below. Missing released capabilities do not stop core work. |

Full Windows/Ubuntu, actual.NET11/10 ordinary, original Stress and installed Release
consumer qualification is cached GREEN in42813970365 (exact8d44). Earlier receipts
remain linked once in evidence. Never query terminal runs/repeat unchanged gates.

## Completed R198 delivery

Committed66ebdb4b removes the owner-type proxy from deferred context eligibility;
scope facts alone keep class-cell/super/capture/protected-body requirements. No
new path/cache/option/owner. Per-record ordinary-method context construction is
eliminated in the complete class-renderer report. docs/RUNTIME and CHANGELOG updated.

Focused102public/71internal pass eachactual11/10, plus18supplemental public cases
eachtarget (15overlap) for classmethods/exact method traceback spans. Reentry,
refusal, real suspendedI/O, cancellation, retained aliases and reuse are covered.
Frozen039 source matches all568 committed production files; image is precommit,
not a claimed identical rebuilt DLL. All source/patches/raw evidence are in
benchmarks/results/2026-11-10-method-contexts/.

CLR allocation−28.51%sync/−28.50%async is established separately. B548 fivejobs
179.869s pass all identity/goldens/quiet/join/RAM/archive/SHA gates. Quiet class-report
elapsed−9.71..−7.06%sync/−9.89..−4.62%async with supporting widerCPU. Plain report
control remains inconclusive, CPU up to+1.57% possible debt. Desktop asyncCSV
+6.2..6.5% and compileCSV+17..20% adversity remains unresolved; no general neutrality
or causal compile-gain claim. Retain the coherent scope invariant/frame reduction,
carry debt to later representative checkpoints; no further unchanged retiming.

Original B547 manifest error stopped before warmups/timed jobs; archived3b28b5e4
after joins/RAMcleanup. B548 corrects only control hashes. Preparation refusals/
canonical-copy retirements are preserved; no failed/adverse condition discarded.
All VM owners are terminal/cached, no users/RAM fixtures. E294/039 images retained.

Exact-source66ebdb4b workflow42822411897 is terminal GREEN (observed13:35UTC):
Windows/Ubuntu, actual11/10 ordinary, original Stress and installed Release
consumers all pass. Receipt linked once in R198 evidence. Never query/repeat it.
Publication/tagging remain held; later isolated changes require their own delivery.

## Completed R199 attribution

Current-text attribution completed one six-second wall window:1,144 execution-thread
samples,6.21%unmapped,5.76threadCPU seconds. Actual active worker selected; raw maps,
all thread CPU, unknowns and wider reset/protocol boundary preserved. All verify,
normal close/join, quiet, temporary-map copy/SHA, RAM unmount and archive/localSHA
checks pass. B549 terminal/cached; no active VM/local users. Evidence:
benchmarks/results/2026-11-10-current-text-attribution/. No elapsed/source gain claim.

Prefix19.58%, operand/result transport5.86%, native call selection6.99%, text
kernels15.21%, native dictionary/hash12.85% include useful/inlined work, not removable
taxes. Monitor5.07% has no proved caller attribution. Frames/binding are not prominent.
Source gate confirms case capacity already collected during whitespace scan,
direct current-token native hashing and no host resize on MemoryGovernor.Commit.
Do not recreate those optimizations, remove checks speculatively or infer a broad
frontend/ownership project. This bounded capture/source gate is complete; no replay.

## Active R200: isolate cold operation bodies

Selected before editing, implemented only in private cold-prefix-r200/tree above
a63229c2. Frozen reference039 (qualified66eb source), prototype9e0b1085. One private
synchronous context-operation helper replaces target/delete/unpack/raise, general
operations, yields/delegation, definitions/imports/fallback, set/dict/match, context
manager and slice bodies inside the hot prefix. Old inline bodies deleted; native
operand/call/formatting/iteration/list/tuple/control paths and existing pause protocol
remain. No new state/backend/options/owner. Production source+27lines from movement,
not a line-count reduction. Main untouched.

Windows.NET11RC3 validated JIT bytes: optimized hot prefix8932→6725B; primary stack
subtraction512→336B (not total stack usage). Instrumented Tier0 also smaller. This
supports timing; it is not CPU or Linux-byte qualification. Unlike R194's wider
loop, original per-instruction exception/cancellation/disposal boundaries remain.

Focused6838public/1237internal pass eachactual11/10. Includes context managers,
exceptions/yields/delegation/imports/slices, real async protocols, cancellation,
first refusal, retained operands/aliases and cleanup. No new architecture-only tests.
Reference/prototype images frozen after forced nonincremental build;568 source
hashes/patch and independent Python3.13.2 stdout/file goldens recorded.

Existing five-case desktop diagnostic running: ordinaryCSV/text/report/file-search
plus existing complete generator-text pipeline (yield is not cold there). Warm,
warm-async and compile separate; all allocations/Run-only/full-envelope clocks
and adverse controls retained. No CPU gain/promotion claim yet. If useful, six-job
quiet source pair covers the five warm scripts plus representative compilation,
5s warmup/7rotated400msrounds,240sowner/30sstop/30smargin. No new framework.

Acceptance preserves exact instruction/error spans and order, protected cleanup,
closures/generators/context promotion, genuine host/protocol suspension, current
cancellation, managed stack protection, terminal refusal and funded users through
joined disposal. Decide retain/refine/remove with explicit regression debt; code
size alone or fixed percentages do not decide. Extend only for concrete evidence,
preserving original failed/adverse conditions. Remove a withdrawn prototype fully.

## Next coherent redesigns

1. **Whole calls/frames and operands:** R198 is fully qualified; no unchanged
   replay. R200 implements the selected instruction/frame footprint hypothesis
   before another call-frame redesign. Shared binding/final slots,
   native receiver entry, deferred contexts and prepared operands already exist.
   CSV/helper/report targets; text/search controls. Do not introduce another arena,
   control protocol, dormant backend or universal tagged-value representation.
2. **Remaining text representation:** current text remains~1.45×CPython. R199 current
   attribution/source gate is complete; already-fused casing/whitespace and native
   hashing remain. A future milestone needs a different concrete intermediate or
   duplicate pass. No broad ownership audit, unchanged replay or new framework.
3. **Per-record construction:** B74's6–8% opportunity already shipped in revised
   constructors/row-array adoption/shared keys. Reassessment and adverse growth
   evidence are in2026-11-10-record-construction-assessment/. A new milestone must
   remove different material allocation/scan; preserve duplicate/custom/wide and
   mutable headers, reentry, retained rows, refusal rollback and cancellation.
4. **Frontend:** shared compiler facts delivered; remaining passes often compute
   distinct facts. R195 traversal samples prove no dominant duplicate. Select a
   measured repeated walk/retained representation before consolidation; remove it.
   Uncached compile-to-result target, warm control; preserve diagnostics/scoping,
   closures/imports and one-provider semantics. No heavyweight JIT assumption.

For every selected redesign, record hypothesis, complete affected scripts, actual
work/storage eliminated, displaced code, semantic gates and bounded controlled
comparison BEFORE editing. Temporary setbacks can support a coherent migration
with explicit completion/debt decision. Timeouts or unstable controls establish
uncertainty; allow justified confirmation/refinement/measurement correction. Retain
all adverse results/original failed conditions. Fixed percentages inform judgment.

## Independent regex delivery

Continue Lython-owned Python semantics: nativeUTF-8 names/data, byte ranges/scalar
positions, original-subject windows, effective flags/captures/replacements/errors,
explicit pattern/cache/result ownership and current-token work. One provider for
frontend/runtime/imports; no backend types/dependencies in core. Development
producers and adapter-local bridges support independent implementation/testing.

Immutable dev64/9af7141f development-qualified86internal/524public eachactualtarget
on unchanged dev59bridge. Supplied dev65/998c630f has identical APIXML/production
C#; only version properties change. Source-only assessment, no new-byte safety/
performance qualification, pin promotion or unchanged test replay.

Precise missing capabilities: separate single-match working owner; nativeUTF-8
group-name enumeration; token-independent cursor creation (per-move tokens exist).
Only affected final released-adapter qualification waits. Contract tests, semantic
validation and backend performance/safety are distinct. Keep in-flight current-token
cancellation, terminal refusal, retained caches/results and budget reuse effective.
Qualify final immutable released package when supplied; publication remains held.

## Delivery / lasting constraints

Focused Release regressions during iteration; batch full Windows/Ubuntu, actual11/10,
original Stress and installed Release consumers at retained coherent milestones.
No simultaneous local builds/tests/timing. Force nonincremental build after timestamp
restores and before freezing. CI observations>=5minapart; cache terminal results.

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native stack probing.
Preserve managed stack/recursion admission, host mediation, CancellationToken,
cycle detection, checked representation bounds, XML depth and boundedI/Ochunks.
Borrowed-root coarse preflights fund capacity/replacement peaks and retained aliases,
caches/results/pending users through awaited cleanup. First refusal stays terminal
with original attribution. No quotas/watchdogs, independent hidden caps, guest-heap
tracing, weak reclamation, forcedGC or new memory-management infrastructure.

Only core Release packages via tools/pack.ps1 to artifacts/nuget/; adapter stays
nonpackable. No publication/tagging. VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem.
Persistent workers/catalogs/evidence; RAM only for guest fixtures. Preserve idle
lease, joins, archive/SHA and exact canonical-copy/all-alias retirement proof.
Never remove sole evidence/active users/current qualified reference or candidate.
Known superseded images/copies are retired: use receipts, do not probe missing
paths. If space again obstructs preparation, recover a bounded set of committed
duplicate terminal archives in one idle operation instead of repeated tiny cleanup.

