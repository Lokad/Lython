from pathlib import Path
import ast,json,subprocess
h=Path(__file__).parent
for name,sourceFile,oldOut,newOut,oldCore in [
 ('simple','inspect-candidate-expanded.py',"out=h/'candidate-jit'","out=h/'refined-simple-jit'",None),
 ('generator','inspect-generator-steady-expanded-before.py',"out=h/'generator-steady-jit-before'","out=h/'refined-generator-jit'","core=h/'diagnostic/images/before/Lokad.Lython.dll';assert core.is_file()")]:
 s=(h/sourceFile).read_text(encoding='utf-8');assert s.count(oldOut)==1;s=s.replace(oldOut,newOut)
 if oldCore:
  assert s.count(oldCore)==1;s=s.replace(oldCore,"core=h/'tree/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll';assert core.is_file()")
 s=s.replace("h/'candidate-PLAN.md'","h/'refined-simple-PLAN.md'").replace("h/'generator-steady-PLAN-before.md'","h/'refined-generator-PLAN.md'")
 path=h/('inspect-refined-'+name+'-expanded.py');ast.parse(s);path.write_text(s,encoding='utf-8',newline='\n')
 subprocess.run(['python','-X','utf8',str(path)],check=True)
