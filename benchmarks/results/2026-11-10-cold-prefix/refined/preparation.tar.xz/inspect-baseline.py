from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
h=Path(__file__).parent;repo=Path('D:/code/Lython');out=h/'baseline-jit';out.mkdir()
shutil.copyfile(repo/'PLAN.md',h/'pre-assessment-PLAN.md')
image=out/'image';shutil.copytree(repo/'tools/LythonProbe/bin/Release/net11.0',image)
core=h.parent/'deferred-method-r198/diagnostic/images/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
shutil.copyfile(core,image/'Lokad.Lython.dll')
source='total=0\nfor i in range(1000000):total+=i\nprint(total)'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
env.update(DOTNET_JitDisasm='*ExecuteInstructionPrefix*',DOTNET_JitDisasmWithCodeBytes='1',DOTNET_JitStdOutFile=str((out/'prefix.txt').resolve()))
r=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(image/'LythonProbe.dll'),'-c',source],env=env,text=True,encoding='utf-8',capture_output=True,timeout=30)
(out/'stdout.txt').write_text(r.stdout,encoding='utf-8',newline='\n');(out/'stderr.txt').write_text(r.stderr,encoding='utf-8',newline='\n');assert r.returncode==0 and'499999500000'in r.stdout,(r.stdout,r.stderr)
methods=[]
for chunk in re.split(r'(?=; Assembly listing for method )',(out/'prefix.txt').read_text(encoding='utf-8')):
 if not chunk.startswith('; Assembly'):continue
 count=0;instructions=[]
 for line in chunk.splitlines():
  if g:=re.match(r'^(G_M\d+_IG\d+):\s*;; offset=0x([0-9A-Fa-f]+)',line):assert int(g[2],16)==count,(g[1],count)
  if i:=re.match(r'^\s+([0-9A-F]{2,30})\s+([a-z].*)$',line):
   assert len(i[1])%2==0;instructions.append(dict(offset=count,bytes=i[1],assembly=i[2]));count+=len(i[1])//2
 assert [int(x)for x in re.findall(r'; Total bytes of code (\d+)',chunk)]==[count]
 methods.append(dict(header=chunk.splitlines()[0],bytes=count,stackSubtracts=re.findall(r'sub\s+rsp,\s+(0x[0-9A-Fa-f]+|[0-9]+)',chunk),instructions=instructions))
assert any('Tier1'in m['header']for m in methods)
proof=dict(coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),source=source,methods=methods,outputEquivalent=True,performanceSample=False,limits='Windows/.NET11RC3 diagnostic code bytes/frame shape, not elapsed/CPU qualification or Linux byte identity.',previousGoalTurn='Progress: committed method simplification, qualified prior runtime, refreshed CPython rows, current-text attribution; full new-runtime CI still pending.')
(out/'source-gate.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps([dict(header=m['header'],codeBytes=m['bytes'],stackSubtracts=m['stackSubtracts'])for m in methods],indent=2),flush=True)
