from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1925028, 'payloadSHA256': '873306d6c1ec650f8e0ce3cb0f961353d9797378ae51a2244b0e22b4f5c81f5a', 'required': 270876672, 'copies': [{'path': 'deferred-method-b547-20261110/observations-partial.tgz', 'bytes': 3834959, 'sha256': '3b28b5e4591c68fbcdcea52335b11c3407e0b6d08f81f23c658eaddfe08f8652', 'canonical': 'benchmarks\\results\\2026-11-10-method-contexts\\startup-observations-partial.tgz'}, {'path': 'deferred-method-b548-20261110/observations.tgz', 'bytes': 3847326, 'sha256': '53823fac4c4be783fe08dac2a992ae8c078ee1ad9d8f4c3d8b4d370f820dbe88', 'canonical': 'benchmarks\\results\\2026-11-10-method-contexts\\observations.tgz'}, {'path': 'current-text-b549-20261110/observations.tgz', 'bytes': 2110809, 'sha256': 'efa4ad30b9f81cac544f1c5e3794097a385bd80a89fec4a51aa52f3845ef924c', 'canonical': 'benchmarks\\results\\2026-11-10-current-text-attribution\\observations.tgz'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'cold-prefix-b550-20261110';source=base/'deferred-method-b548-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for copy in config['copies']:
   path=base/copy['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(copy,allocatedBytes=st.st_blocks*512))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualified039AndPriorE294Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b550-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b550-cold-prefix-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b550-cold-prefix-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
