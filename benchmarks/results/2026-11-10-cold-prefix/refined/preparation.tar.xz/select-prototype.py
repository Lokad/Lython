from pathlib import Path
import hashlib,json,shutil,subprocess,textwrap
h=Path(__file__).parent;repo=Path('D:/code/Lython');t=h/'tree'
if t.exists():assert not subprocess.check_output(['git','status','--porcelain'],cwd=t,text=True).strip()
gate=json.loads((h/'baseline-jit/source-gate.json').read_text(encoding='utf-8'));optimized=next(m for m in gate['methods']if'Tier1-OSR'in m['header']);assert optimized['bytes']==8932 and optimized['stackSubtracts'][0]=='512'
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');selection='''

## Selected R200 prototype (before editing)

Current frozen039 baseline JIT confirms8932B optimized OSR code and512B primary
stack subtraction, matching earlier source evidence. Logging diagnostics are not
elapsed/CPU measurements. Concrete replacement: move target/delete/unpack/raise,
general operations, yields/delegation, definitions/imports/fallback, set/dict/match,
context-manager and slice bodies into one private synchronous helper returning the
existing InstructionPause/pending/jump outputs. Keep ordinary native call, operand,
formatting, iteration, list/tuple and control paths inline. Delete original cold
case bodies from the hot loop; retain its per-instruction exception/cancellation/
disposal boundary exactly. No new state, backend, dispatch framework or public API.

Hypothesis: fewer cold temporaries/inlined helper bodies in the hot frame reduce
code/frame pressure on complete CSV/text/report loops. Protected, generator and
actual pending operations must retain exact evaluation/error/cleanup semantics;
current admission/refusal, cancellation, stack protection and aliases stay funded.
Run focused Release checks, force-build/freeze and compare JIT code/frame first.
If shape improves coherently, use the existing short allocation/whole-script driver,
then bounded quiet confirmation where useful, with search/compile controls. Preserve
all adversity. Code movement alone or a fixed percentage does not decide retention;
record remaining regression debt and remove a withdrawn prototype fully. This
initial scope excludes moving native fallbacks or redesigning exception routing.
'''
if '## Selected R200 prototype (before editing)'not in s:s+=selection
p.write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(p,h/'selected-PLAN.md')
if not t.exists():subprocess.run(['git','worktree','add','--detach',str(t),'HEAD'],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
file=t/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';before=file.read_text(encoding='utf-8');(h/'original-dispatch.cs').write_text(before,encoding='utf-8',newline='\n')
pairs=[('StoreMember:\n','StartFormattedString'),('ApplyOperation:\n','Yield:\n'),('Yield:\n','LoadMember or'),('MakeSet or','CompareJumpIfFalse'),('Slice:\n','JumpIfFalse:\n')]
pieces=[]
for first,last in pairs:
 a=before.index('                        case ExecutableOpCode.'+first);b=before.index('                        case ExecutableOpCode.'+last,a)
 pieces.append(before[a:b])
# Every copied group contains only its original top-level switch breaks.
helper=''.join(pieces)
headers=[]
for group in pieces:
 for chunk in group.split('                        case ')[1:]:
  header=chunk[:chunk.index(':\n')];headers.append('                        case '+header+':\n')
assert len(headers)==10,len(headers)
group=''.join(headers)+'''                            if (invocation is null) return InstructionPause.ContextRequired;
                            var contextPause = ExecuteContextInstruction(ref execution, invocation, instruction, asynchronous,
                                out jumped, out pending, out pendingSpan);
                            if (contextPause != InstructionPause.Continue) return contextPause;
                            break;
'''
after=before
for i,piece in enumerate(pieces):
 assert after.count(piece)==1
 after=after.replace(piece,group if i==0 else'')
helper=helper.replace('                            if (invocation is null) return InstructionPause.ContextRequired;\n','').replace('invocation!','invocation').replace('                            break;','                            return InstructionPause.Continue;')
helper='''        // Keep cold operation temporaries out of the common instruction frame.
        // The caller retains exception routing, current-token checks and disposal.
        private static InstructionPause ExecuteContextInstruction(ref ExecutableWorkState execution, ExecutionContext invocation,
            in ExecutableInstruction instruction, bool asynchronous, out bool jumped,
            out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)
        {
            jumped = false;
            pending = default;
            pendingSpan = default;
            switch (instruction.OpCode)
            {
'''+textwrap.indent(textwrap.dedent(helper),'                ')+'''                default:
                    throw new InvalidOperationException($"Unknown context opcode: {instruction.OpCode}");
            }
        }

'''
needle='        private static InstructionPause PauseOperation(';assert after.count(needle)==1;after=after.replace(needle,helper+needle)
file.write_text(after,encoding='utf-8',newline='\n')
(h/'source-selection.json').write_text(json.dumps(dict(baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip(),baselineCoreSHA256=gate['coreSHA256'],baselineOptimizedCodeBytes=8932,baselineStackSubtraction=512,coldCaseHeaders=len(headers),originalLines=len(before.splitlines()),prototypeLines=len(after.splitlines()),sourceOnlyPrototype=True,notPromoted=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Isolated R200 cold-body prototype selected; original bodies removed, one existing pause protocol. Worktree:',t,flush=True)
