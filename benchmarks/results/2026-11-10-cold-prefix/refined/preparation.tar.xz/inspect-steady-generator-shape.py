from pathlib import Path
import subprocess
h=Path(__file__).parent;s=(h/'inspect-generator-shape.py').read_text(encoding='utf-8')
s=s.replace("out=h/'generator-jit-{role}'","out=h/'generator-steady-jit-{role}'").replace("h/'generator-PLAN-{role}.md'","h/'generator-steady-PLAN-{role}.md'")
s=s.replace('4096','65536').replace("'inspect-generator-expanded-'","'inspect-generator-steady-expanded-'")
(h/'inspect-steady-generator-expanded.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8',str(h/'inspect-steady-generator-expanded.py')],check=True)
