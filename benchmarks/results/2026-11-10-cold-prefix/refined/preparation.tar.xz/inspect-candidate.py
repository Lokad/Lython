from pathlib import Path
import subprocess
h=Path(__file__).parent;s=(h/'inspect-baseline.py').read_text(encoding='utf-8')
s=s.replace("out=h/'baseline-jit'","out=h/'candidate-jit'").replace("h/'pre-assessment-PLAN.md'","h/'candidate-PLAN.md'")
old="core=h.parent/'deferred-method-r198/diagnostic/images/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'"
assert s.count(old)==1;s=s.replace(old,"core=h/'tree/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll';assert core.is_file()")
(h/'inspect-candidate-expanded.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8',str(h/'inspect-candidate-expanded.py')],check=True)
