from pathlib import Path
import hashlib,json,shutil,tarfile
h=Path(__file__).parent;repo=Path('D:/code/Lython');p=h/'b550';d=h/'diagnostic';dest=repo/'benchmarks/results/2026-11-10-cold-prefix';dest.mkdir();o=dest/'original';o.mkdir()
identity=json.loads((d/'identity.json').read_text(encoding='utf-8'));assert len(identity['source'])==568 and all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in identity['source'].items())
receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==6 and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','summary.json','identity.json','terminal-status.json','extraction.json']:shutil.copyfile(p/name,o/name)
for phase in ['warm','warm-async','compile']:
 folder=o/'desktop'/phase;folder.mkdir(parents=True)
 for name in ['measurements.json','summary.json','stderr.txt']:shutil.copyfile(d/phase/name,folder/name)
originalSource=h/'original-source';originalSource.mkdir();shutil.copyfile(h/'tree/src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',originalSource/'LythonRuntime.Executable.Interpreter.Dispatch.cs');shutil.copyfile(d/'identity.json',originalSource/'identity.json');shutil.copyfile(d/'source.patch',originalSource/'source.patch')
(h/'initial-setup-condition.json').write_text(json.dumps(dict(condition='Local extraction guard initially expected12 switch headers; source contained10. Guard stopped before mutating production source. Corrected header count, same proposed source movement.',runtimeOrMeasurementFailure=False),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(o/'preparation.tar.xz','w:xz')as a:
 for path in sorted(h.rglob('*')):
  if not path.is_file():continue
  rel=path.relative_to(h)
  if rel.parts[0]=='tree'or'retrieved'in rel.parts or'images'in rel.parts or'image'in rel.parts or path.name in ['observations.tgz','payload.tgz']:continue
  if rel.parts[0]=='diagnostic'and len(rel.parts)>1 and rel.parts[1]in ['warm','warm-async','compile']:continue
  a.add(path,arcname=rel.as_posix())
 for name in identity['source']:a.add(h/'tree'/name,arcname='source/'+name)
summary=json.loads((p/'summary.json').read_text(encoding='utf-8'));rows=[]
for x in summary['timing']:
 e=list(x['changePercent'].values());c=list(x['processCpuChangePercent'].values());sp=x['controlSpreadPercent'];rows.append(f"| {x['case'].removeprefix('scripts.')} / {x['lane']} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {sp['reference']:.2f}% / {sp['candidate']:.2f}% |")
(dest/'README.md').write_text('''# R200 — cold opcode bodies and hot instruction footprint

The isolated original variant moves contextful target/general/yield/definition/
container/context-manager/slice bodies out of ExecuteInstructionPrefix into one
private synchronous helper. Existing pause/pending/jump results and outer per-
instruction exception/cancellation/disposal routing remain. Original inline bodies
are deleted; native call/operand/formatting/iteration/control paths stay inline.
Source grows27lines (337→364); no state, owner, option or alternative engine.

**Original variant is not promoted.** Main remains fully qualified66ebdb4b. The
source pair is frozen039 reference versus9e0b prototype on a63229c2; all568 source
hashes, complete source/patch, original conditions, JIT bytes and test logs are in
[preparation](original/preparation.tar.xz). Focused6838public/1237internal cases
pass on each actual.NET11/10; no full platform/package replay for isolated code.

## Code and stack-shape evidence

Windows.NET11RC3 diagnostics validate every byte offset against declared native
size. A simple counter's optimized OSR prefix shrinks8932→6725B, primary stack
subtraction512→336B. This is a hot-method result, not total stack usage or CPU gain.
On a generator kernel, OSR prefix11083→9218B and primary subtraction544→416B;
the new helper separately has2363B Tier0 code and896B primary subtraction. Its
optimized tier was not observed, including the bounded longer65536-iteration
confirmation. No total code/stack reduction or Linux-byte identity is claimed.
The extra helper frame and dispatch are real tradeoffs; all dumps survive.

## Controlled complete scripts

Same five existing CSV/text/report/search/generator-text scripts, fixtures and full
stdout/file goldens; independent CPython3.13.2 verifies semantics, not timed baseline.
Existing common workers and optional adapter0.4 are unchanged. CLR allocation is
effectively flat. Desktop syncCSV/text gains coexist with report+2.2..5.5%, search
+1.9..9.9%; async search+4.7..10.8%/generator+0.9..9.2%, and compile variability.
[All desktop observations](original/desktop/) preserve every pairing. Run-only
excludes reset/goldens/result disposal; its full envelope/allocation adds them.

Quiet Azure F4as_v7/Ubuntu24.04.4/.NET11RC3, stockGC/tiering, six jobs215.904s:
five warm scripts plus text compilation, two independent processes per source,
5s warmup and seven rotated400ms rounds. All identity/output/ownership/quiet/
join/RAM/archive/SHA checks pass. [Raw](original/observations.tgz),
[all medians/CPU/IQR/pairings](original/summary.json), [receipt](original/archive-receipt.json).

| Complete workload / phase | Elapsed change | Wider process CPU | Reference / candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Ranges span all four source-median pairings, not confidence intervals. Wider CPU
includes reset/protocol and coarse100Hz ticks. Warm VM clocks include mediated
RAM I/O, full validation and prior-result cleanup; reset, compilation/startup are
excluded. Compile includes construction/disposal. Async desktop I/O completes
synchronously; genuine suspension remains covered by correctness tests.

Report elapsed improves modestly with uncertain CPU. Text has a small consistent
adverse range. CSV/generator remain inconclusive. Identical candidate search
processes differ14.76% with low within-process IQR; that uncertainty cannot establish
a design regression or gain. Compilation is inconclusive and allocation flat.
Smaller hot code alone is insufficient for promotion, and unstable controls do not
establish a failed design. No primary CPython row or general CPU claim changes.

## Bounded next refinement

The helper returns jump status twice: through an out bool and through its existing
ValueTask<bool> for pending context-manager operations. Consolidate on the existing
pending result, matching comparison/iteration operation handling, and remove the
extra bool output. Hypothesis: eliminate redundant transport/address exposure
without adding a state or dispatcher. Preserve original9e0b and all adverse data.
Validate exact match/context-manager jumps, async suppression/cleanup, cancellation,
terminal refusal and owned operands before another bounded source pair. No fixed
percentage veto, permanent one-attempt rule or automatic promotion.

All VM users joined, RAM removed and persistent archive/SHA verified; terminal
owner is cached. Preparation uses the frozen uncompressed payload footprint as
well as compressed size, preserving240MiB disk floor/12MiB setup headroom. Three
exact committed duplicate compressed archives were retired under an idle lease;
reference039, priorE294, prototype9e0b and sole evidence survive. Full receipt is
in raw evidence. Publication and adapter promotion remain postponed. The broader
performance roadmap stays active.
''',encoding='utf-8',newline='\n')
exp=repo/'benchmarks/EXPERIMENTS.md';s=exp.read_text(encoding='utf-8');i=s.index('The [R199 current-text attribution]');s=s[:i]+'''The [R200 cold-body prototype](results/2026-11-10-cold-prefix/README.md) reduces
the hot method's JIT code/frame while adding a separate helper frame. All focused
semantic checks pass; six controlled jobs215.904s retain modest report gains,
small text adversity and14.76%candidate search variation. Allocation stays flat.
Original is not promoted; a bounded refinement removes duplicate jump transport
using the existing pending result. All code/measurements/failures remain preserved.

'''+s[i:];exp.write_text(s,encoding='utf-8',newline='\n')
print('Original source/evidence preserved; prototype unpromoted, concrete refinement recorded.',flush=True)
