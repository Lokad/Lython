using Lokad.Lython.Frontend;
using System.Numerics;
using System.Globalization;
using System.Text;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static object EvaluateFormattedString(FormattedStringExpressionSyntax formatted, ExecutionContext context)
        => EvaluateFormattedStringParts(formatted.Parts, context, formatted.Span);

    private static PyString EvaluateFormattedStringParts(
        IReadOnlyList<FormattedStringPartSyntax> parts,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
        try
        {
            foreach (var part in parts)
            {
                switch (part)
                {
                    case FormattedStringTextPartSyntax text:
                        builder.AppendString(text.Text);
                        break;
                    case FormattedStringExpressionPartSyntax expression:
                        var fieldValue = EvaluateExpression(expression.Expression, context);
                        if (expression.Conversion is { } conversion)
                            fieldValue = FormatInterpolatedStringPart(fieldValue, conversion, null, context, span);
                        var formatSpecifier = expression.FormatSpecifierParts is null
                            ? expression.FormatSpecifier
                            : EvaluateFormattedStringParts(expression.FormatSpecifierParts, context, span).AsString();
                        AppendInterpolatedStringPart(builder, fieldValue, null, formatSpecifier, context, span);
                        break;
                    default:
                        throw new InvalidOperationException($"Unknown formatted string part: {part.GetType().Name}");
                }
            }
            var value = builder.ToPyStringAndRelease();
            context.CheckExecution(span);
            return value;
        }
        finally { builder.Release(); }
    }

    private static PyString ToInterpolatedPyString(object value, ExecutionContext context)
        => PyRendering.ToInterpolatedPyString(value, new PyRenderingContext(context));

    private static string ToInterpolatedString(object value, ExecutionContext context)
        => PyRendering.ToInterpolatedString(value, new PyRenderingContext(context));

    private static PyString ToPythonPyString(object value, ExecutionContext context)
        => PyRendering.ToPythonPyString(value, new PyRenderingContext(context));

    private static string ToPythonString(object value, ExecutionContext context)
        => PyRendering.ToPythonString(value, new PyRenderingContext(context));

    private static PyString ToReprPyString(object value, ExecutionContext context)
        => PyRendering.ToReprPyString(value, new PyRenderingContext(context));

    private static PyString FormatInterpolatedStringPart(
        object value,
        char? conversion,
        string? formatSpecifier,
        ExecutionContext context,
        LythonSourceSpan span,
        InterpolatedFormatSpecifier? prepared = null)
    {
        value = ConvertInterpolatedValue(value, conversion, context, span);
        if (string.IsNullOrEmpty(formatSpecifier) && value is not PyInstance)
        {
            return ToInterpolatedPyString(value, context);
        }
        return FormatValue(value, formatSpecifier ?? "", context, span, prepared);
    }

    private static object ConvertInterpolatedValue(object value, char? conversion, ExecutionContext context, LythonSourceSpan span)
        => conversion switch
        {
            null => value,
            's' => ToInterpolatedPyString(value, context),
            'r' => ToReprPyString(value, context),
            'a' => EscapeNonAsciiPyString(ToReprPyString(value, context), context, span),
            _ => throw new LythonRuntimeException("ValueError", $"Unknown conversion specifier '!{conversion}'.", span)
        };

    private static void AppendInterpolatedStringPart(GovernedByteBuilder output, object value, char? conversion,
        string? specifier, ExecutionContext context, LythonSourceSpan span, InterpolatedFormatSpecifier? prepared = null)
    {
        value = ConvertInterpolatedValue(value, conversion, context, span);
        if (string.IsNullOrEmpty(specifier) && value is not PyInstance)
            output.Append(ToInterpolatedPyString(value, context));
        else if (value is PyDate or PyTime or PyDateTime or PyInstance)
            output.Append(FormatValue(value, specifier ?? "", context, span));
        else AppendInterpolatedStringValue(output, value, specifier ?? "", context, span, prepared);
    }

    private static PyString FormatValue(object value, string specifier, ExecutionContext context, LythonSourceSpan span,
        InterpolatedFormatSpecifier? prepared = null)
        => value is PyDate or PyTime or PyDateTime
            ? PyDateTimeOps.FormatValue(value, PyString.FromString(specifier, context.MemoryGovernor, span), span, context)
            : value is PyInstance instance
            ? (PyString)FormatInstanceAsync(instance, specifier, context, span, false).GetAwaiter().GetResult()
            : FormatInterpolatedStringValue(value, specifier, context, span, prepared);

    private static async ValueTask<object> FormatInstanceAsync(PyInstance instance, string specifier,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        if (instance.Type.TryLookupInMro("__format__", 0, out var raw, out _))
        {
            var member = asynchronous
                ? await PyAttributeLookup.BindForInstanceAsync(instance, raw, context, span).ConfigureAwait(false)
                : PyAttributeLookup.BindForInstance(instance, raw, context, span);
            if (member is not ICallable callable) throw NotCallableError(member, context, span);
            var argument = PyString.FromString(specifier, context.MemoryGovernor, span);
            var formatted = asynchronous
                ? await CallableInvocation.InvokeUnaryAsync(callable, argument, span, context).ConfigureAwait(false)
                : CallableInvocation.InvokeUnary(callable, argument, span, context);
            if (!PyStringOps.TryAsString(formatted, out var text))
                throw new LythonRuntimeException("TypeError", "__format__ returned non-string", span);
            return text;
        }

        return FormatInterpolatedStringValue(instance, specifier, context, span);
    }

    private static PyString EscapeNonAsciiPyString(PyString text, ExecutionContext context, LythonSourceSpan span)
    {
        var input = text.Utf8Span;
        var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
        const string hex = "0123456789abcdef";
        try
        {
            for (var offset = 0; offset < input.Length;)
            {
                Rune.DecodeFromUtf8(input[offset..], out var rune, out var consumed);
                offset += consumed;
                var width = rune.Value <= 0x7f ? 1 : rune.Value <= 0xff ? 4 : rune.Value <= 0xffff ? 6 : 10;
                if (rune.Value <= 0x7f)
                {
                    builder.Append((byte)rune.Value);
                    continue;
                }
                var digits = rune.Value <= 0xff ? 2 : rune.Value <= 0xffff ? 4 : 8;
                builder.Append((byte)'\\');
                builder.Append((byte)(digits == 2 ? 'x' : digits == 4 ? 'u' : 'U'));
                for (var shift = (digits - 1) * 4; shift >= 0; shift -= 4)
                    builder.Append((byte)hex[(rune.Value >> shift) & 15]);
            }
            var result = builder.ToPyStringAndRelease();
            return result;
        }
        finally
        {
            builder.Release();
        }
    }

    private static PyString FormatInterpolatedStringValue(
        object value,
        string formatSpecifier,
        ExecutionContext context,
        LythonSourceSpan span,
        InterpolatedFormatSpecifier? prepared = null)
    {
        // Standalone string formatting preserves an unchanged input's identity.
        if (value is PyString text)
        {
            var stringSpec = prepared ?? ParseInterpolatedFormatSpecifier(formatSpecifier, value, span);
            ValidateStringFormatSpecifier(value, formatSpecifier, stringSpec, span);
            return PyStringOps.FormatStringValue(text, stringSpec.Width, stringSpec.Precision,
                new Rune(stringSpec.Fill >= 0 ? stringSpec.Fill : stringSpec.ZeroPad ? '0' : ' '), stringSpec.Align ?? '<', context, span);
        }
        var output = new GovernedByteBuilder(context.MemoryGovernor, span);
        try
        {
            AppendInterpolatedStringValue(output, value, formatSpecifier, context, span, prepared);
            context.CheckExecution(span);
            return output.ToPyStringAndRelease();
        }
        finally { output.Release(); }
    }

    private static void AppendInterpolatedStringValue(GovernedByteBuilder output, object value,
        string formatSpecifier, ExecutionContext context, LythonSourceSpan span, InterpolatedFormatSpecifier? prepared = null)
    {
        if (value is PyComplex complex)
        {
            AppendComplexValue(output, complex, formatSpecifier, context, span, prepared);
            return;
        }
        var spec = prepared ?? ParseInterpolatedFormatSpecifier(formatSpecifier, value, span);
        if (TryAppendNumericValue(output, value, spec, context, span)) return;

        ValidateStringFormatSpecifier(value, formatSpecifier, spec, span);
        PyStringOps.AppendFormattedStringValue(output, value as PyString ?? ToInterpolatedPyString(value, context),
            spec.Width, spec.Precision, new Rune(spec.Fill >= 0 ? spec.Fill : spec.ZeroPad ? '0' : ' '),
            spec.Align ?? '<', context, span);
    }

    private static void ValidateStringFormatSpecifier(object value, string formatSpecifier,
        InterpolatedFormatSpecifier spec, LythonSourceSpan span)
    {

        // CPython's default __format__ only accepts the empty spec; any
        // other spec on a non-string value reports TypeError naming the
        // type instead of formatting str(value).
        if (value is not PyString && formatSpecifier.Length != 0)
        {
            throw new LythonRuntimeException("TypeError", $"unsupported format string passed to {RuntimeErrors.OperandTypeName(value)}.__format__", span);
        }

        if (spec.Grouping is { } stringGrouping)
        {
            throw new LythonRuntimeException("ValueError", $"Cannot specify '{stringGrouping}' with '{spec.Type ?? 's'}'.", span);
        }

        if (spec.Type is not null and not 's')
        {
            throw new LythonRuntimeException("ValueError", $"Unknown format code '{spec.Type}' for object of type '{RuntimeErrors.OperandTypeName(value)}'", span);
        }

        if (spec.Sign is '+' or '-')
        {
            throw new LythonRuntimeException("ValueError", "Sign not allowed in string format specifier", span);
        }

        if (spec.Sign is ' ')
        {
            throw new LythonRuntimeException("ValueError", "Space not allowed in string format specifier", span);
        }

        if (spec.Alternate)
        {
            throw new LythonRuntimeException("ValueError", "Alternate form (#) not allowed in string format specifier", span);
        }

        if (spec.Align == '=')
        {
            throw new LythonRuntimeException("ValueError", "'=' alignment not allowed in string format specifier", span);
        }

    }

    private static bool TryAppendNumericValue(GovernedByteBuilder output, object value,
        InterpolatedFormatSpecifier spec, ExecutionContext context, LythonSourceSpan span)
    {
        if (TryGetIntegerFormatValue(value, out var integer))
        {
            if (spec.Type is 'f' or 'F' or 'g' or 'G' or '%' or 'e' or 'E')
            {
                var asDouble = (double)integer;
                if (!double.IsFinite(asDouble))
                    throw new LythonRuntimeException("OverflowError", "int too large to convert to float", span);
                AppendFloatingFormat(output, asDouble, spec, context, span, RuntimeErrors.OperandTypeName(value));
            }
            else AppendIntegerFormat(output, integer, spec, context, span, RuntimeErrors.OperandTypeName(value));
            return true;
        }
        if (value is double floating)
        {
            if (spec.Type is 'd' or 'b' or 'o' or 'x' or 'X' or 'n')
                throw new LythonRuntimeException("ValueError", $"Unknown format code '{spec.Type}' for object of type '{RuntimeErrors.OperandTypeName(floating)}'", span);
            AppendFloatingFormat(output, floating, spec, context, span, RuntimeErrors.OperandTypeName(floating));
            return true;
        }
        if (value is PyDecimal decimalValue)
        {
            AppendNumericText(output, FormatDecimalText(decimalValue, spec, span, context), spec, context, span);
            return true;
        }
        return false;
    }

    // Decimal has its own format grammar: exact coefficient rendering with
    // the ambient context rounding, per-code default precisions, single-digit
    // exponents and 'invalid format string' failures.
    private static string FormatDecimalText(
        PyDecimal decimalValue,
        InterpolatedFormatSpecifier spec,
        LythonSourceSpan span,
        ExecutionContext context)
    {
        var type = spec.Type;
        var supported = type is null or 'f' or 'F' or 'e' or 'E' or 'g' or 'G' or 'n' or '%';
        if (!supported || spec.Grouping == '_' || (type == 'n' && spec.Grouping == ','))
        {
            throw new LythonRuntimeException("ValueError", "invalid format string", span);
        }

        // Guest-controlled precision scales the output without bound from a
        // tiny input, so bound it before materializing digit runs.
        var precisionBytes = spec.Precision is { } digits && digits > 1024
            ? checked(4L * (32L + (type is null or 'g' or 'G' or 'n' ? 16L : 320L) + digits)) : 0;
        using var precisionStorage = precisionBytes == 0 ? null
            : context.MemoryGovernor.ReserveTemporary(precisionBytes, span);

        var tuple = PyDecimalOps.AsTuple(decimalValue);
        var negative = tuple.Sign == 1;
        var coefficient = PyDecimalOps.DigitsToString(tuple.Digits);
        var exponent = decimalValue.Exponent;
        var isZero = coefficient is "0";
        var rounding = context.DecimalContext.Rounding;

        string body = type switch
        {
            '%' => RenderDecimalPercent(coefficient, exponent, isZero, spec, rounding, negative, span),
            'e' or 'E' => RenderDecimalScientific(coefficient, exponent, isZero, spec.Precision is null ? null : spec.Precision.Value + 1, spec.Alternate, upper: type == 'E', rounding, negative, span),
            'g' or 'G' or 'n' => RenderDecimalGeneral(coefficient, exponent, isZero, spec, upper: type == 'G', rounding, negative, span),
            null => RenderDecimalDefault(decimalValue, spec),
            _ => RenderDecimalFixed(coefficient, exponent, isZero, spec.Precision, spec.Alternate, rounding, negative, span),
        };

        if (negative && !body.StartsWith('-'))
        {
            body = "-" + body;
        }

        var text = ApplyNumericSign(body, spec.Sign);
        precisionStorage?.Commit(checked(32L + (2L * text.Length)));
        return text;
    }

    private static string RenderDecimalDefault(PyDecimal decimalValue, InterpolatedFormatSpecifier spec)
    {
        var body = PyDecimalOps.Format(decimalValue);
        if (spec.Alternate && !body.Contains('.'))
        {
            var marker = body.IndexOf('E');
            body = marker < 0 ? body + "." : body[..marker] + "." + body[marker..];
        }

        return body;
    }

    // Unsigned fixed-point body. A null precision renders the natural scale.
    private static string RenderDecimalFixed(
        string coefficient,
        int exponent,
        bool isZero,
        int? precision,
        bool alternate,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
    {
        string digits;
        int point;
        if (precision is null)
        {
            digits = coefficient;
            point = coefficient.Length + exponent;
        }
        else
        {
            (digits, var scaled) = RoundToFractionDigits(coefficient, exponent, isZero, precision.Value, rounding, negative, span);
            point = digits.Length + scaled;
        }

        string body;
        if (point <= 0)
        {
            body = "0." + new string('0', -point) + digits;
        }
        else if (point >= digits.Length)
        {
            body = StripLeadingZeros(digits + new string('0', point - digits.Length));
        }
        else
        {
            body = digits[..point] + "." + digits[point..];
        }

        if (alternate && !body.Contains('.'))
        {
            body += ".";
        }

        return body;
    }

    private static string RenderDecimalPercent(
        string coefficient,
        int exponent,
        bool isZero,
        InterpolatedFormatSpecifier spec,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
        => RenderDecimalFixed(coefficient, exponent + 2, isZero, spec.Precision, spec.Alternate, rounding, negative, span) + "%";

    // Unsigned scientific body with single-digit-minimum Decimal exponents.
    private static string RenderDecimalScientific(
        string coefficient,
        int exponent,
        bool isZero,
        int? precision,
        bool alternate,
        bool upper,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
    {
        var keep = precision ?? coefficient.Length;
        if (keep < 1)
        {
            keep = 1;
        }

        string digits;
        int scaled;
        if (isZero)
        {
            digits = new string('0', keep);
            scaled = exponent;
        }
        else
        {
            (digits, scaled) = RoundSignificant(coefficient, exponent, keep, rounding, negative, span);
        }

        return RenderDecimalMantissa(digits, scaled, alternate, upper);
    }

    private static string RenderDecimalMantissa(string digits, int scaled, bool alternate, bool upper)
    {
        var mantissa = digits.Length == 1 ? digits : digits[0] + "." + digits[1..];
        if (alternate && digits.Length == 1)
        {
            mantissa += ".";
        }

        var shown = scaled + digits.Length - 1;
        return mantissa + (upper ? 'E' : 'e') + (shown < 0 ? "-" : "+") + Math.Abs(shown).ToString(CultureInfo.InvariantCulture);
    }

    // Unsigned general body: an explicit precision rounds first and then
    // picks fixed/scientific from the rounded digits; the default shows
    // every digit with the str() cut. Zeros are never padded or stripped
    // here, so exactly the significant digits survive.
    private static string RenderDecimalGeneral(
        string coefficient,
        int exponent,
        bool isZero,
        InterpolatedFormatSpecifier spec,
        bool upper,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
    {
        if (spec.Precision is null)
        {
            var spontaneous = isZero ? exponent : coefficient.Length - 1 + exponent;
            var body = exponent > 0 || spontaneous < -6
                ? RenderDecimalScientific(coefficient, exponent, isZero, null, alternate: false, upper, rounding, negative, span)
                : RenderDecimalFixed(coefficient, exponent, isZero, null, alternate: false, rounding, negative, span);
            return ForceGeneralPoint(body, spec.Alternate);
        }

        var keep = spec.Precision.Value < 1 ? 1 : spec.Precision.Value;
        var effective = isZero ? 1 : Math.Min(keep, coefficient.Length);
        var (digits, scaled) = RoundSignificant(coefficient, exponent, effective, rounding, negative, span);

        var adjusted = digits.Length - 1 + scaled;
        if (exponent > 0 || adjusted < -6 || adjusted >= keep)
        {
            return ForceGeneralPoint(RenderDecimalMantissa(digits, scaled, spec.Alternate, upper), spec.Alternate);
        }

        int? fraction = isZero ? null : keep - (adjusted + 1);
        var fixedBody = RenderDecimalFixed(digits, scaled, isZero, fraction, alternate: false, rounding, negative, span);
        if (isZero)
        {
            return ForceGeneralPoint(fixedBody, spec.Alternate);
        }

        var floor = Math.Max(0, digits.Length - (adjusted + 1));
        return ForceGeneralPoint(StripToFloor(fixedBody, floor, spec.Alternate), spec.Alternate);
    }

    private static string StripToFloor(string body, int floor, bool alternate)
    {
        var point = body.IndexOf('.');
        if (point < 0)
        {
            return body;
        }

        var end = body.Length;
        var kept = body.Length - point - 1;
        while (kept > floor && body[end - 1] == '0')
        {
            end--;
            kept--;
        }

        var trimmed = body[..end];
        if (trimmed.EndsWith('.') && !alternate)
        {
            trimmed = trimmed[..^1];
        }

        return trimmed;
    }

    private static string ForceGeneralPoint(string body, bool alternate)
    {
        if (!alternate || body.Contains('.'))
        {
            return body;
        }

        var marker = body.IndexOfAny(['e', 'E']);
        return marker < 0 ? body + "." : body[..marker] + "." + body[marker..];
    }

    private static string StripLeadingZeros(string digits)
    {
        var stripped = digits.TrimStart('0');
        return stripped.Length == 0 ? "0" : stripped;
    }

    private static (string Digits, int Exponent) RoundToFractionDigits(
        string coefficient,
        int exponent,
        bool isZero,
        int precision,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
    {
        if (isZero)
        {
            return ("0", -precision);
        }

        var shift = exponent + precision;
        if (shift >= 0)
        {
            return (coefficient + new string('0', shift), -precision);
        }

        var keep = coefficient.Length + shift;
        if (keep < 1)
        {
            coefficient = new string('0', 1 - keep) + coefficient;
            keep = 1;
        }

        return RoundSignificant(coefficient, exponent, keep, rounding, negative, span);
    }

    // Rounds the coefficient to `keep` significant digits (keep >= 1),
    // shifting the exponent so the value is preserved (zeros keep theirs).
    private static (string Digits, int Exponent) RoundSignificant(
        string coefficient,
        int exponent,
        int keep,
        DecimalRoundingMode rounding,
        bool negative,
        LythonSourceSpan span)
    {
        if (coefficient is "0")
        {
            return ("0", exponent);
        }

        if (keep >= coefficient.Length)
        {
            var pad = keep - coefficient.Length;
            return (pad == 0 ? coefficient : coefficient + new string('0', pad), exponent - pad);
        }

        var head = coefficient[..keep];
        var scaled = exponent + (coefficient.Length - keep);
        if (RoundUp(head[^1] - '0', coefficient[keep..], rounding, negative, span))
        {
            head = IncrementDigits(head);
            if (head.Length > keep)
            {
                head = head[..^1];
                scaled += 1;
            }
        }

        return (head, scaled);
    }

    private static bool RoundUp(int lastKept, string tail, DecimalRoundingMode rounding, bool negative, LythonSourceSpan span)
    {
        var first = tail[0] - '0';
        var sticky = false;
        for (var i = 1; i < tail.Length; i++)
        {
            if (tail[i] != '0')
            {
                sticky = true;
                break;
            }
        }

        return rounding switch
        {
            DecimalRoundingMode.HalfEven => first > 5 || (first == 5 && (sticky || lastKept % 2 == 1)),
            DecimalRoundingMode.HalfUp => first >= 5,
            DecimalRoundingMode.HalfDown => first > 5 || (first == 5 && sticky),
            DecimalRoundingMode.Down => false,
            DecimalRoundingMode.Up => first > 0 || sticky,
            DecimalRoundingMode.Ceiling => !negative && (first > 0 || sticky),
            DecimalRoundingMode.Floor => negative && (first > 0 || sticky),
            DecimalRoundingMode.ZeroFiveUp => (first > 0 || sticky) && lastKept is 0 or 5,
            _ => throw new LythonRuntimeException("ValueError", "Unsupported decimal rounding mode.", span),
        };
    }

    private static string IncrementDigits(string head)
    {
        var chars = head.ToCharArray();
        for (var i = chars.Length - 1; i >= 0; i--)
        {
            if (chars[i] != '9')
            {
                chars[i]++;
                return new string(chars);
            }

            chars[i] = '0';
        }

        return "1" + new string(chars);
    }

    private static bool TryGetIntegerFormatValue(object value, out BigInteger integer)
        => Numbers.PyNumberOps.TryAsInteger(value, out integer);

    private static string FormatFloatingText(
        double value,
        InterpolatedFormatSpecifier spec,
        LythonSourceSpan span,
        MemoryGovernor? governor,
        string typeName)
    {
        var type = spec.Type;
        var precision = spec.Precision;
        if (type is 'b' or 'o' or 'x' or 'X' or 'd' or 'n')
        {
            throw new LythonRuntimeException("ValueError", $"Unknown format code '{type}' for object of type '{typeName}'", span);
        }

        if (spec.Grouping is { } floatGrouping &&
            type is not null and not 'f' and not 'F' and not 'g' and not 'G' and not '%' and not 'e' and not 'E')
        {
            throw new LythonRuntimeException("ValueError", $"Cannot specify '{floatGrouping}' with '{type}'.", span);
        }

        if (!double.IsFinite(value))
        {
            var nonFinite = double.IsNaN(value) ? "nan" : value < 0 ? "-inf" : "inf";
            if (spec.Type is 'F' or 'E' or 'G')
            {
                nonFinite = nonFinite.ToUpperInvariant();
            }
            if (spec.Type == '%')
            {
                nonFinite += "%";
            }

            return ApplyNumericSign(nonFinite, spec.Sign);
        }

        // Guest-controlled precision scales the output without bound from a
        // tiny input, so bound it before BCL formatting materializes it.
        // Small precisions behave exactly as before; non-finite values
        // always render short. Integer digits of a double need at most 309
        // chars; significant-digit codes need at most precision plus a few.
        var precisionBytes = double.IsFinite(value) && spec.Precision is { } digits && digits > 1024
            ? checked(4L * (32L + (spec.Type is null or 'g' or 'G' ? 16L : 320L) + digits)) : 0;
        using var precisionStorage = precisionBytes == 0 ? null
            : governor?.ReserveTemporary(precisionBytes, span);

        var formatted = type switch
        {
            null when precision is null => Numbers.PyNumberOps.RenderFloat(value),
            null => RenderFloatDefaultPrecision(value, precision.Value, spec.Alternate),
            'g' => FormatGeneralFloat(value, precision, spec.Alternate, upper: false),
            'G' => FormatGeneralFloat(value, precision, spec.Alternate, upper: true),
            '%' => FormatPercentText(value, precision),
            _ => throw new LythonRuntimeException("ValueError", $"Unknown format code '{type}' for object of type '{typeName}'", span)
        };

        // General and precision-bearing default forms already handle alternate
        // significant digits. The remaining text forms only need a decimal point.
        var hashType = type == '%' || (type is null && precision is null);
        if (spec.Alternate && type is null && precision is null)
        {
            // CPython renders the no-type form float-style (lowercase
            // marker); the bare rendering keeps the shared BCL shape.
            formatted = formatted.Replace('E', 'e');
        }
        if (spec.Alternate && hashType && !formatted.Contains('.'))
        {
            var pointAt = formatted.IndexOfAny(['e', 'E']);
            if (pointAt < 0 && formatted.EndsWith('%'))
            {
                pointAt = formatted.Length - 1;
            }

            if (pointAt >= 0)
            {
                formatted = formatted[..pointAt] + "." + formatted[pointAt..];
            }
            else
            {
                // With no presentation type the point carries a zero so the
                // rendering still parses as a float.
                formatted += type is null ? ".0" : ".";
            }
        }

        var text = ApplyNumericSign(formatted, spec.Sign);
        precisionStorage?.Commit(checked(32L + (2L * text.Length)));
        return text;
    }

    // Scaling by 100 can overflow a large finite value to infinity;
    // CPython then renders the non-finite word with the percent suffix.
    // Unsigned null-type body with an explicit precision: CPython renders
    // repr-style significant digits (BCL G expands exactly past 17 digits),
    // picks fixed/scientific from the rounded digits, and strips to float
    // form unless alternate keeps the width.
    private static string RenderFloatDefaultPrecision(double value, int precision, bool alternate)
    {
        var keep = precision < 1 ? 1 : precision;
        var negative = double.IsNegative(value);
        // BCL G forms: [-]ddd[.ddd][E[+-]ddd]; shortest and correctly rounded.
        var raw = Math.Abs(value).ToString("G" + keep.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
        var unsigned = raw.StartsWith('-') ? raw[1..] : raw;
        var marker = unsigned.IndexOf('E');
        var exponent = 0;
        var mantissa = unsigned;
        if (marker >= 0)
        {
            exponent = int.Parse(mantissa[(marker + 1)..], CultureInfo.InvariantCulture);
            mantissa = mantissa[..marker];
        }

        var point = mantissa.IndexOf('.');
        var digits = point < 0 ? mantissa : mantissa[..point] + mantissa[(point + 1)..];
        if (point >= 0)
        {
            exponent -= mantissa.Length - point - 1;
        }

        digits = digits.TrimStart('0');
        var isZero = digits.Length == 0;
        if (isZero)
        {
            digits = "0";
            exponent = 0;
        }

        if (alternate && !isZero && digits.Length < keep)
        {
            // Alternate keeps the full width: pad the mantissa out.
            exponent -= keep - digits.Length;
            digits += new string('0', keep - digits.Length);
        }

        var adjusted = digits.Length - 1 + exponent;
        string body;
        if (adjusted < -4 || adjusted >= keep - 1)
        {
            body = RenderFloatDefaultScientific(digits, exponent, alternate);
        }
        else
        {
            var fraction = keep - (adjusted + 1);
            var shifted = exponent + fraction;
            var padded = digits + new string('0', shifted);
            var split = padded.Length - fraction;
            body = split <= 0
                ? "0." + new string('0', -split) + padded
                : padded[..split] + "." + padded[split..];
        }

        if (!alternate)
        {
            body = StripFloatBody(body);
        }

        if (negative)
        {
            body = "-" + body;
        }

        return body;
    }

    private static string RenderFloatDefaultScientific(string digits, int exponent, bool alternate)
    {
        var mantissa = digits.Length == 1 ? digits : digits[0] + "." + digits[1..];
        if (alternate && digits.Length == 1)
        {
            mantissa += ".";
        }

        var shown = exponent + digits.Length - 1;
        return mantissa + 'e' + (shown < 0 ? "-" : "+") + Math.Abs(shown).ToString("D2", CultureInfo.InvariantCulture);
    }

    // Strips padded zeros; a bare integer regains float form. Scientific
    // mantissas keep their marker without further ado.
    private static string StripFloatBody(string body)
    {
        var marker = body.IndexOf('e');
        var head = marker < 0 ? body : body[..marker];
        var tail = marker < 0 ? string.Empty : body[marker..];
        if (head.Contains('.'))
        {
            head = head.TrimEnd('0').TrimEnd('.');
        }

        if (!head.Contains('.') && marker < 0)
        {
            head += ".0";
        }

        return head + tail;
    }

    private static string FormatPercentText(double value, int? precision)
    {
        var scaled = value * 100.0;
        if (!double.IsFinite(scaled))
        {
            return (double.IsNaN(scaled) ? "nan" : scaled < 0 ? "-inf" : "inf") + "%";
        }

        return scaled.ToString("F" + (precision ?? 6).ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture) + "%";
    }

    // BCL scientific notation pads exponents to three digits with an
    // uppercase marker; CPython uses a lowercase marker for 'e'/'g' and a
    // minimum of two exponent digits.
    // General float rendering with CPython precision semantics (a zero
    // precision keeps one digit). Alternate pads the mantissa to the full
    // width and forces a decimal point. BCL G rounds to at most keep digits.
    private static string FormatGeneralFloat(double value, int? precision, bool alternate, bool upper)
    {
        var keep = precision is null ? 6 : precision.Value < 1 ? 1 : precision.Value;
        var raw = value.ToString("G" + keep.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
        return NormalizeExponentMarker(PadAlternateGeneral(raw, keep, alternate), upper);
    }

    private static string PadAlternateGeneral(string raw, int precision, bool alternate)
    {
        if (!alternate)
        {
            return raw;
        }

        var marker = raw.IndexOf('E');
        var mantissa = marker < 0 ? raw : raw[..marker];
        var tail = marker < 0 ? string.Empty : raw[marker..];
        var sign = mantissa.StartsWith('-') ? "-" : string.Empty;
        var unsigned = sign.Length == 0 ? mantissa : mantissa[1..];
        var point = unsigned.IndexOf('.');
        var intPart = point < 0 ? unsigned : unsigned[..point];
        var fracPart = point < 0 ? string.Empty : unsigned[(point + 1)..];
        var significant = (intPart + fracPart).TrimStart('0');
        if (significant.Length == 0)
        {
            return sign + "0." + new string('0', precision - 1) + tail;
        }

        // Padding extends the fraction so the integer digits keep their value.
        var padded = point < 0 ? unsigned + "." : unsigned;
        padded += new string('0', precision - significant.Length);
        return sign + padded + tail;
    }

    private static string NormalizeExponentMarker(string raw, bool upper)
    {
        var marker = raw.IndexOf('E');
        if (marker < 0)
        {
            return raw;
        }

        var digits = raw[(marker + 2)..];
        var stripped = digits.TrimStart('0');
        stripped = stripped.Length switch
        {
            0 => "00",
            1 => "0" + stripped,
            _ => stripped,
        };

        return raw[..marker] + (upper ? 'E' : 'e') + raw[marker + 1] + stripped;
    }

    // Native grammar does not constrain custom __format__. Invalid or oversized
    // literal specs must still reach the original runtime call and error order.
    internal static InterpolatedFormatSpecifier? PrepareConstantFormatSpecifier(string? text, LythonSourceSpan span)
    {
        if (string.IsNullOrEmpty(text)) return null;
        try { return ParseInterpolatedFormatSpecifier(text, PyNone.Instance, span); }
        catch (LythonRuntimeException error) when (error.Attribution is null && error.ExceptionType == "ValueError") { return null; }
        catch (ArgumentException) { return null; }
        catch (OverflowException) { return null; }
    }

    private static InterpolatedFormatSpecifier ParseInterpolatedFormatSpecifier(string text, object value, LythonSourceSpan span)
    {
        var index = 0;
        var fill = -1;
        char? align = null;

        if (text.Length > 0)
        {
            var first = Rune.GetRuneAt(text, 0);
            var next = first.Utf16SequenceLength;
            if (next < text.Length && IsFormatAlign(text[next]))
            {
                fill = first.Value;
                align = text[next];
                index = next + 1;
            }
            else if (IsFormatAlign(text[0]))
            {
                align = text[0];
                index = 1;
            }
        }

        char? sign = null;
        if (index < text.Length && text[index] is '+' or '-' or ' ')
        {
            sign = text[index++];
        }

        var alternate = false;
        if (index < text.Length && text[index] == '#')
        {
            alternate = true;
            index++;
        }

        var zeroPad = false;
        if (index < text.Length && text[index] == '0')
        {
            zeroPad = true;
            index++;
        }

        int? width = null;
        var widthStart = index;
        while (index < text.Length && char.IsAsciiDigit(text[index]))
        {
            index++;
        }

        if (index > widthStart)
        {
            width = int.Parse(text[widthStart..index], CultureInfo.InvariantCulture);
        }

        char? grouping = null;
        if (index < text.Length && text[index] is ',' or '_')
        {
            grouping = text[index++];
        }

        int? precision = null;
        if (index < text.Length && text[index] == '.')
        {
            index++;
            var precisionStart = index;
            while (index < text.Length && char.IsAsciiDigit(text[index]))
            {
                index++;
            }

            if (precisionStart == index)
            {
                throw new LythonRuntimeException("ValueError", "Format specifier missing precision", span);
            }

            precision = int.Parse(text[precisionStart..index], CultureInfo.InvariantCulture);
        }

        char? type = null;
        if (index < text.Length)
        {
            type = text[index++];
        }

        if (index != text.Length)
        {
            throw new LythonRuntimeException("ValueError", $"Invalid format specifier '{text}' for object of type '{RuntimeErrors.OperandTypeName(value)}'", span);
        }

        return new InterpolatedFormatSpecifier(fill, align, sign, alternate, zeroPad, width, grouping, precision, type);
    }

    private static bool IsFormatAlign(char value)
        => value is '<' or '>' or '^' or '=';

    private static string ApplyNumericSign(string text, char? sign)
    {
        if (text.StartsWith("-", StringComparison.Ordinal) ||
            text.StartsWith("+", StringComparison.Ordinal) ||
            text.StartsWith(" ", StringComparison.Ordinal))
        {
            return text;
        }

        return sign switch
        {
            '+' => "+" + text,
            ' ' => " " + text,
            _ => text
        };
    }

    internal sealed record InterpolatedFormatSpecifier(
        int Fill, // Unicode scalar; -1 means unspecified, so NUL remains a valid fill.
        char? Align,
        char? Sign,
        bool Alternate,
        bool ZeroPad,
        int? Width,
        char? Grouping,
        int? Precision,
        char? Type);

}
