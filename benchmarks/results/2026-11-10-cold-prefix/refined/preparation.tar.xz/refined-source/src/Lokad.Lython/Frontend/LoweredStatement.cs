namespace Lokad.Lython.Frontend;

internal enum LoweredStatementKind
{
    Import,
    FunctionDefinition,
    ClassDefinition,
    ControlFlow,
    Assignment,
    Expression,
    Other,
}

internal abstract record LoweredStatement(LythonSourceSpan Span)
{
    /// <summary>Gets the stable lowered statement discriminator used by interpreters and analyzers.</summary>
    public abstract LoweredStatementKind Kind { get; }
}

internal sealed record LoweredTypeParameter(TypeParameterSyntax Syntax, LoweredExpression? Bound, LoweredExpression? Default);
internal sealed record LoweredTypeAliasStatement(TypeAliasStatementSyntax Syntax, LoweredExpression Value) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
    public IReadOnlyList<LoweredTypeParameter>? TypeParameters { get; } = LoweredScript.LowerTypeParameters(Syntax.TypeParameters);
}

internal sealed record LoweredImportStatement(
    ImportStatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Import;
}

internal sealed record LoweredScopeDirectiveStatement(
    ScopeDirectiveStatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredFunctionParameter(
    string Name,
    FunctionParameterKind Kind,
    LoweredExpression? Annotation,
    LoweredExpression? DefaultValue);

internal sealed record LoweredFunctionDefinitionStatement(
    FunctionDefinitionStatementSyntax Syntax,
    IReadOnlyList<LoweredExpression> Decorators,
    IReadOnlyList<LoweredFunctionParameter> Parameters,
    LoweredExpression? ReturnAnnotation,
    IReadOnlyList<LoweredStatement> Body,
    ScopeDirectiveFacts ScopeFacts) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.FunctionDefinition;
    public FunctionParameterLayout ParameterLayout => Syntax.ParameterLayout;
    // Class suites still execute lowered; their method bodies are
    // prepared once, without retaining an unused second lowered body.
    public ExecutableCodeObject? PreparedCode { get; init; }
    public string? Docstring { get; } = Runtime.PyFunctionBase.LeadingDocstring(Body);
    public IReadOnlyList<LoweredTypeParameter>? TypeParameters { get; } = LoweredScript.LowerTypeParameters(Syntax.TypeParameters);
}

internal sealed record LoweredClassDefinitionStatement(
    ClassDefinitionStatementSyntax Syntax,
    IReadOnlyList<LoweredExpression> Decorators,
    IReadOnlyList<LoweredExpression> Bases,
    IReadOnlyList<LoweredCallArgument> KeywordArguments,
    IReadOnlyList<LoweredStatement> Body) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ClassDefinition;
    public IReadOnlyList<LoweredTypeParameter>? TypeParameters { get; } = LoweredScript.LowerTypeParameters(Syntax.TypeParameters);
    public IReadOnlyList<LoweredCallArgument> HeaderArguments { get; init; } = Syntax.HeaderArguments is { } arguments
        ? arguments.Select(argument => new LoweredCallArgument(argument.Form, LoweredScript.LowerExpression(argument.Expression))).ToArray()
        : Bases.Select(expression => new LoweredCallArgument(CallArgumentForm.Positional, expression)).Concat(KeywordArguments).ToArray();
}

internal abstract record LoweredAssignmentStatement(
    StatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Assignment;
}

internal sealed record LoweredNameAssignmentStatement(
    AssignmentStatementSyntax Assignment,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment);

internal sealed record LoweredChainedAssignmentStatement(
    ChainedAssignmentStatementSyntax Assignment,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment)
{
    public IReadOnlyList<LoweredStoreTarget> Targets { get; } = Assignment.Targets.Select(target => new LoweredStoreTarget(target)).ToArray();
}

internal sealed record LoweredAnnotatedAssignmentStatement(
    AnnotatedAssignmentStatementSyntax Assignment,
    LoweredExpression Annotation,
    LoweredExpression? Expression) : LoweredAssignmentStatement(Assignment)
{
    public LoweredStoreTarget Target { get; } = new(Assignment.Target);
}

internal abstract record LoweredAugmentedAssignmentTarget(
    AssignmentTargetSyntax Syntax)
{
    public LythonSourceSpan Span => Syntax.Span;
}

internal sealed record LoweredNameAugmentedAssignmentTarget(
    NameAssignmentTargetSyntax Target) : LoweredAugmentedAssignmentTarget(Target);

internal sealed record LoweredSubscriptAugmentedAssignmentTarget(
    SubscriptAssignmentTargetSyntax Target,
    LoweredExpression Receiver,
    LoweredExpression Index) : LoweredAugmentedAssignmentTarget(Target);

internal sealed record LoweredSliceAugmentedAssignmentTarget(
    SliceAssignmentTargetSyntax Target,
    LoweredExpression Receiver,
    LoweredExpression? Start,
    LoweredExpression? End,
    LoweredExpression? Step) : LoweredAugmentedAssignmentTarget(Target);

internal sealed record LoweredMemberAugmentedAssignmentTarget(
    MemberAssignmentTargetSyntax Target,
    LoweredExpression Receiver) : LoweredAugmentedAssignmentTarget(Target);

internal sealed record LoweredAugmentedAssignmentStatement(
    AugmentedAssignmentStatementSyntax Assignment,
    LoweredAugmentedAssignmentTarget Target,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment);

internal sealed record LoweredUnpackingAssignmentStatement(
    UnpackingAssignmentStatementSyntax Assignment,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment)
{
    public LoweredStoreTarget Target { get; } = new(new UnpackingAssignmentTargetGroupSyntax(Assignment.Targets, Expression.Span));
}

internal sealed record LoweredSubscriptAssignmentStatement(
    SubscriptAssignmentStatementSyntax Assignment,
    LoweredExpression Receiver,
    LoweredExpression Index,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment);

internal sealed record LoweredSliceAssignmentStatement(
    SliceAssignmentStatementSyntax Assignment,
    LoweredExpression Receiver,
    LoweredExpression? Start,
    LoweredExpression? End,
    LoweredExpression? Step,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment);

internal sealed record LoweredMemberAssignmentStatement(
    MemberAssignmentStatementSyntax Assignment,
    LoweredExpression Receiver,
    LoweredExpression Expression) : LoweredAssignmentStatement(Assignment);

internal sealed record LoweredExpressionStatement(
    ExpressionStatementSyntax Syntax,
    LoweredExpression Expression) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Expression;
}

internal sealed record LoweredIfStatement(
    IfStatementSyntax Syntax,
    LoweredExpression Condition,
    IReadOnlyList<LoweredStatement> ThenStatements,
    IReadOnlyList<LoweredStatement>? ElseStatements) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredForStatement(
    ForStatementSyntax Syntax,
    LoweredExpression Iterable,
    IReadOnlyList<LoweredStatement>? ElseStatements,
    IReadOnlyList<LoweredStatement> Body) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredWhileStatement(
    WhileStatementSyntax Syntax,
    LoweredExpression Condition,
    IReadOnlyList<LoweredStatement>? ElseStatements,
    IReadOnlyList<LoweredStatement> Body) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredMatchCase(
    MatchCaseSyntax Syntax,
    LoweredRootPattern Pattern,
    IReadOnlyList<LoweredStatement> Body,
    LoweredExpression? Guard = null);

internal sealed record LoweredMatchStatement(
    MatchStatementSyntax Syntax,
    LoweredExpression Subject,
    IReadOnlyList<LoweredMatchCase> Cases) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredWithStatement(
    WithStatementSyntax Syntax,
    LoweredExpression ContextExpression,
    IReadOnlyList<LoweredStatement> Body) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredExceptClause(
    ExceptClauseSyntax Syntax,
    IReadOnlyList<LoweredStatement> Body,
    LoweredExpression? ExceptionType = null);

internal sealed record LoweredTryStatement(
    TryStatementSyntax Syntax,
    IReadOnlyList<LoweredStatement> TryBody,
    IReadOnlyList<LoweredExceptClause> ExceptClauses,
    IReadOnlyList<LoweredStatement>? ElseBody,
    IReadOnlyList<LoweredStatement>? FinallyBody) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.ControlFlow;
}

internal sealed record LoweredPassStatement(
    PassStatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredBreakStatement(
    BreakStatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredContinueStatement(
    ContinueStatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredAssertStatement(
    AssertStatementSyntax Syntax,
    LoweredExpression Condition,
    LoweredExpression? Message) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredDeleteStatement(
    DeleteStatementSyntax Syntax,
    LoweredExpression Target) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredReturnStatement(
    ReturnStatementSyntax Syntax,
    LoweredExpression? Expression) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredRaiseStatement(
    RaiseStatementSyntax Syntax,
    LoweredExpression? Expression,
    LoweredExpression? CauseExpression) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}

internal sealed record LoweredOtherStatement(
    StatementSyntax Syntax) : LoweredStatement(Syntax.Span)
{
    public override LoweredStatementKind Kind => LoweredStatementKind.Other;
}
