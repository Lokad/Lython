using System.Buffers;
using System.Globalization;
using System.Text;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal enum TextErrorMode
    {
        Strict,
        Ignore,
        Replace,
        BackslashReplace,
    }

    internal enum TextNewlineMode
    {
        TranslateUniversal,
        PreserveUniversal,
        PreserveLineFeed,
        PreserveCarriageReturn,
        PreserveCarriageReturnLineFeed,
    }

    private static string TextEncodingName(TextEncodingMode encoding) => encoding switch
    {
        TextEncodingMode.Utf8Bom => "utf-8-sig",
        TextEncodingMode.Latin1 => "iso8859-1",
        TextEncodingMode.Ascii => "ascii",
        TextEncodingMode.Windows1252 => "cp1252",
        TextEncodingMode.Utf16 => "utf-16",
        TextEncodingMode.Utf16LittleEndian => "utf-16-le",
        TextEncodingMode.Utf16BigEndian => "utf-16-be",
        _ => "utf-8",
    };

    private static TextEncodingMode ParseTextEncoding(object value, string owner, LythonSourceSpan span)
    {
        if (value is PyNone)
        {
            return TextEncodingMode.Utf8;
        }

        if (!PyStringOps.TryAsString(value, out var encoding))
        {
            throw UnsupportedTextEncoding(owner, span);
        }

        var encodingName = encoding.AsString();
        if (StaticTextContractFacts.IsUtf8EncodingName(encodingName))
        {
            return TextEncodingMode.Utf8;
        }

        if (StaticTextContractFacts.IsUtf8SigEncodingName(encodingName))
        {
            return TextEncodingMode.Utf8Bom;
        }

        if (StaticTextContractFacts.IsLatin1EncodingName(encodingName))
        {
            return TextEncodingMode.Latin1;
        }

        if (StaticTextContractFacts.IsAsciiEncodingName(encodingName)) return TextEncodingMode.Ascii;
        if (StaticTextContractFacts.IsWindows1252EncodingName(encodingName)) return TextEncodingMode.Windows1252;
        switch (StaticTextContractFacts.Utf16EncodingKind(encodingName))
        {
            case 1: return TextEncodingMode.Utf16;
            case 2: return TextEncodingMode.Utf16LittleEndian;
            case 3: return TextEncodingMode.Utf16BigEndian;
        }

        throw new LythonRuntimeException("LookupError", $"unknown encoding: {encodingName}", span);
    }

    private static LythonRuntimeException UnsupportedTextEncoding(string owner, LythonSourceSpan span)
        => new(
            "ValueError",
            $"{owner} only supports encoding='utf-8', 'utf-8-sig', 'latin-1', 'ascii', 'cp1252', 'utf-16', 'utf-16-le', or 'utf-16-be'.",
            span);

    private static TextErrorMode ParseTextErrors(object value, string owner, LythonSourceSpan span)
    {
        if (value is PyNone)
        {
            return TextErrorMode.Strict;
        }

        if (!PyStringOps.TryAsString(value, out var errors))
        {
            throw UnsupportedTextErrors(owner, span);
        }

        return errors.AsString() switch
        {
            "strict" => TextErrorMode.Strict,
            "ignore" => TextErrorMode.Ignore,
            "replace" => TextErrorMode.Replace,
            "backslashreplace" => TextErrorMode.BackslashReplace,
            "surrogateescape" or "surrogatepass" => throw new LythonRuntimeException("NotImplementedError", $"{owner} does not support surrogate error handlers because Lython strings are UTF-8 scalar values.", span),
            _ => throw new LythonRuntimeException("LookupError", "unknown error handler name: '" + errors.AsString() + "'", span)
        };
    }

    // str()/bytes() reject non-string codec names up front with a per-argument
    // TypeError, unlike the shared Parse helpers which serve hosts that accept
    // None and report values. CPython names the offending type; bytes() spells
    // a None name bare while str() uses the type name.
    private static void RequireCodecNameType(object value, string owner, string argument, LythonSourceSpan span)
    {
        if (PyStringOps.TryAsString(value, out _))
        {
            return;
        }

        var typeName = value is PyNone && owner == "bytes()"
            ? "None"
            : RuntimeErrors.OperandTypeName(value);
        throw new LythonRuntimeException("TypeError", $"{owner} argument '{argument}' must be str, not {typeName}", span);
    }

    private static LythonRuntimeException UnsupportedTextErrors(string owner, LythonSourceSpan span)
        => new(
            "ValueError",
            $"{owner} only supports text error handlers 'strict', 'ignore', 'replace', and 'backslashreplace'.",
            span);

    private static string TextErrorName(TextErrorMode mode)
        => mode switch
        {
            TextErrorMode.Ignore => "ignore",
            TextErrorMode.Replace => "replace",
            TextErrorMode.BackslashReplace => "backslashreplace",
            _ => "strict",
        };

    private static TextNewlineMode ParseTextNewline(object value, string owner, LythonSourceSpan span)
    {
        if (value is null or PyNone)
        {
            return TextNewlineMode.TranslateUniversal;
        }

        if (!PyStringOps.TryAsString(value, out var newline))
        {
            throw new LythonRuntimeException("ValueError", $"{owner} newline must be None, '', '\\n', '\\r', or '\\r\\n'.", span);
        }

        var newlineName = newline.AsString();
        if (!StaticTextContractFacts.IsSupportedNewlineName(newlineName))
        {
            throw new LythonRuntimeException("ValueError", $"{owner} newline must be None, '', '\\n', '\\r', or '\\r\\n'.", span);
        }

        return newlineName switch
        {
            "" => TextNewlineMode.PreserveUniversal,
            "\n" => TextNewlineMode.PreserveLineFeed,
            "\r" => TextNewlineMode.PreserveCarriageReturn,
            "\r\n" => TextNewlineMode.PreserveCarriageReturnLineFeed,
            _ => throw new LythonRuntimeException("ValueError", $"{owner} newline must be None, '', '\\n', '\\r', or '\\r\\n'.", span)
        };
    }

    private static TextFileOperation ParseTextOpenMode(PyString mode, string owner, LythonSourceSpan span)
    {
        var text = mode.AsString();
        if (text.Contains('b', StringComparison.Ordinal))
        {
            throw new LythonRuntimeException("ValueError", $"{owner} only supports text modes; binary modes like 'rb' and 'wb' are unsupported.", span);
        }

        if (text.Contains('+', StringComparison.Ordinal))
        {
            throw new LythonRuntimeException("NotImplementedError", $"{owner} does not support updating text modes such as 'r+'.", span);
        }

        return text switch
        {
            "r" or "rt" => TextFileOperation.Read,
            "w" or "wt" => TextFileOperation.Write,
            "a" or "at" => TextFileOperation.Append,
            _ => throw new LythonRuntimeException("ValueError", $"{owner} only supports modes 'r', 'w', and 'a' with optional text marker 't'.", span)
        };
    }

    private static string TextOpenModeName(TextFileOperation operation)
        => operation switch
        {
            TextFileOperation.Read => "r",
            TextFileOperation.Write => "w",
            TextFileOperation.Append => "a",
            _ => throw new ArgumentOutOfRangeException(nameof(operation), operation, "Unknown text file operation."),
        };

    private static void ValidateTextBuffering(object value, string owner, LythonSourceSpan span)
    {
        if (value is null or PyNone)
        {
            return;
        }

        if (!PyNumberOps.TryAsInteger(value, out _))
        {
            throw new LythonRuntimeException("TypeError", $"{owner} expects buffering to be an integer or None.", span);
        }
    }

    private static void ValidateCloseFd(object value, string owner, LythonSourceSpan span)
    {
        if (value is null or PyNone or true)
        {
            return;
        }

        if (value is false)
        {
            throw new LythonRuntimeException("NotImplementedError", $"{owner} only supports closefd=True for host-mediated paths.", span);
        }

        throw new LythonRuntimeException("TypeError", $"{owner} expects closefd to be a bool.", span);
    }

    private static void ValidateOpener(object value, string owner, LythonSourceSpan span)
    {
        if (value is null or PyNone)
        {
            return;
        }

        throw new LythonRuntimeException("NotImplementedError", $"{owner} opener is not supported because file access is host-mediated.", span);
    }

    private static PyString DecodeUtf8Text(ReadOnlyMemory<byte> utf8, ExecutionContext context, LythonSourceSpan? span)
        => DecodeUtf8Text(utf8, context, span, TextErrorMode.Strict, TextNewlineMode.TranslateUniversal);

    private static PyString DecodeUtf8Text(ReadOnlyMemory<byte> utf8, ExecutionContext context, LythonSourceSpan? span, TextErrorMode errors)
        => DecodeUtf8Text(utf8, context, span, errors, TextNewlineMode.TranslateUniversal);

    private static PyString DecodeUtf8Text(
        ReadOnlyMemory<byte> utf8,
        ExecutionContext context,
        LythonSourceSpan? span,
        TextErrorMode errors,
        TextNewlineMode newline)
        => DecodeUtf8Text(utf8, context.MemoryGovernor, span, errors, newline, context.State);

    internal static PyString DecodeUtf8Text(ReadOnlyMemory<byte> utf8, MemoryGovernor governor,
        LythonSourceSpan? span, ExecutionState? guards = null)
        => DecodeUtf8Text(utf8, governor, span, TextErrorMode.Strict, TextNewlineMode.TranslateUniversal, guards);

    internal static PyString DecodeUtf8Text(ReadOnlyMemory<byte> utf8, MemoryGovernor governor, LythonSourceSpan? span, TextErrorMode errors)
        => DecodeUtf8Text(utf8, governor, span, errors, TextNewlineMode.TranslateUniversal);

    internal static PyString DecodeUtf8Text(
        ReadOnlyMemory<byte> utf8,
        MemoryGovernor governor,
        LythonSourceSpan? span,
        TextErrorMode errors,
        TextNewlineMode newline,
        ExecutionState? guards = null)
    {
        guards?.CheckExecution(span);
        if (utf8.Length == 0)
        {
            return PyString.Empty;
        }

        if (IsUnchangedUtf8Text(utf8.Span, newline))
        {
            guards?.CheckExecution(span);
            var result = PyString.FromUtf8(utf8, governor, span);
            try { guards?.CheckExecution(span); return result; }
            catch { governor.RefundUnpublishedValue(result); throw; }
        }

        return DecodeUtf8WithErrors(utf8.Span, governor, span, errors, newline, guards);
    }

    private static bool IsUnchangedUtf8Text(ReadOnlySpan<byte> utf8, TextNewlineMode newline)
        => (newline != TextNewlineMode.TranslateUniversal || !utf8.Contains((byte)'\r'))
            && System.Text.Unicode.Utf8.IsValid(utf8);

    private static PyString DecodeText(ReadOnlyMemory<byte> payload, TextEncodingMode encoding, ExecutionContext context, LythonSourceSpan? span)
        => DecodeText(payload, encoding, context, span, TextErrorMode.Strict, TextNewlineMode.TranslateUniversal);

    private static PyString DecodeText(ReadOnlyMemory<byte> payload, TextEncodingMode encoding, ExecutionContext context, LythonSourceSpan? span, TextErrorMode errors)
        => DecodeText(payload, encoding, context, span, errors, TextNewlineMode.TranslateUniversal);

    internal static PyString DecodeText(
        ReadOnlyMemory<byte> payload,
        TextEncodingMode encoding,
        ExecutionContext context,
        LythonSourceSpan? span,
        TextErrorMode errors,
        TextNewlineMode newline,
        bool stream = false)
    {
        if (IsUtf16Encoding(encoding))
        {
            var result = DecodeUtf16Text(payload.Span, encoding, context, span, errors, newline, stream);
            return result;
        }
        if (encoding is TextEncodingMode.Ascii or TextEncodingMode.Windows1252)
        {
            var result = encoding == TextEncodingMode.Ascii
                ? DecodeAsciiText(payload.Span, context, span, errors, newline)
                : DecodeWindows1252Text(payload.Span, context, span, errors, newline);
            return result;
        }
        if (encoding != TextEncodingMode.Latin1)
        {
            if (encoding == TextEncodingMode.Utf8Bom &&
                payload.Length >= 3 &&
                payload.Span[0] == 0xEF &&
                payload.Span[1] == 0xBB &&
                payload.Span[2] == 0xBF)
            {
                payload = payload[3..];
            }

            return DecodeUtf8Text(payload, context, span, errors, newline);
        }

        return DecodeLatin1Text(payload.Span, context.State, span, newline);
    }

    private static PyString DecodeLatin1Text(ReadOnlySpan<byte> payload, ExecutionState services,
        LythonSourceSpan? span, TextNewlineMode newline)
    {
        if (payload.IsEmpty)
        {
            return PyString.Empty;
        }

        // Latin-1 expands to at most two UTF-8 bytes per input byte: gate the
        // transient before decoding so an undersized budget fails before the
        // host-sized allocation, matching the previous gate-first order.
        using var storage = services.MemoryGovernor.ReserveTemporary(128L + 2L * payload.Length, span);
        var utf8 = DecodeLatin1ToBytes(payload, newline, services, span);
        return PyString.FromOwnedUtf8(utf8, services.MemoryGovernor, span, storage);
    }

    // Shared latin-1 window decoder: every byte maps to exactly one latin-1
    // character (two UTF-8 bytes above 0x7F), so windows need no character
    // carry, only the universal-newline carriage-return holdback applied by
    // the caller. Chunked readers reuse this so latin-1 cannot drift from
    // whole-buffer decoding.
    private static byte[] DecodeLatin1ToBytes(ReadOnlySpan<byte> source, TextNewlineMode newline,
        ExecutionState guards, LythonSourceSpan? span)
    {
        var outputLength = 0;
        var work = 0;
        for (var i = 0; i < source.Length; i++)
        {
            if ((work++ & 1023) == 0) guards.CheckExecution(span);
            if (newline == TextNewlineMode.TranslateUniversal && source[i] == (byte)'\r')
            {
                if (i + 1 < source.Length && source[i + 1] == (byte)'\n')
                {
                    i++;
                }

                outputLength++;
                continue;
            }

            outputLength = checked(outputLength + (source[i] < 0x80 ? 1 : 2));
        }

        var utf8 = new byte[outputLength];
        var offset = 0;
        work = 0;
        for (var i = 0; i < source.Length; i++)
        {
            if ((work++ & 1023) == 0) guards.CheckExecution(span);
            var value = source[i];
            if (newline == TextNewlineMode.TranslateUniversal && value == (byte)'\r')
            {
                if (i + 1 < source.Length && source[i + 1] == (byte)'\n')
                {
                    i++;
                }

                utf8[offset++] = (byte)'\n';
                continue;
            }

            if (value < 0x80)
            {
                utf8[offset++] = value;
            }
            else
            {
                utf8[offset++] = (byte)(0xC0 | value >> 6);
                utf8[offset++] = (byte)(0x80 | value & 0x3F);
            }
        }

        return utf8;
    }

    private static PyString StripUtf8Bom(PyString text, TextEncodingMode encoding)
    {
        var utf8 = text.Utf8Bytes;
        if (encoding != TextEncodingMode.Utf8Bom ||
            utf8.Length < 3 ||
            utf8.Span[0] != 0xEF ||
            utf8.Span[1] != 0xBB ||
            utf8.Span[2] != 0xBF)
        {
            return text;
        }

        return PyString.FromUtf8(utf8[3..]);
    }

    private static PyBytes EncodeGuestBytes(PyString text, TextEncodingMode encoding, TextErrorMode errors,
        ExecutionContext context, LythonSourceSpan span)
    {
        using var storage = context.MemoryGovernor.ReserveTemporary(0, span);
        var bytes = EncodeText(text, encoding, errors, TextNewlineMode.PreserveUniversal, context, span, outputStorage: storage);
        return new PyBytes(bytes, context.MemoryGovernor, span, storage);
    }

    private static byte[] EncodeText(
        PyString text,
        TextEncodingMode encoding,
        TextErrorMode errors,
        TextNewlineMode newline,
        ExecutionContext context,
        LythonSourceSpan? span,
        bool outputAlreadyFunded = false, MemoryGovernor.TemporaryMemoryReservation? outputStorage = null)
        => EncodeText(text, encoding, errors, newline, context.State, span, outputAlreadyFunded, outputStorage);

    private static byte[] EncodeText(PyString text, TextEncodingMode encoding, TextErrorMode errors,
        TextNewlineMode newline, ExecutionState context, LythonSourceSpan? span,
        bool outputAlreadyFunded = false, MemoryGovernor.TemporaryMemoryReservation? outputStorage = null)
        => EncodeText(text.Utf8Span, encoding, errors, newline, context, span, outputAlreadyFunded, outputStorage, text);

    private static byte[] EncodeText(
        ReadOnlySpan<byte> source,
        TextEncodingMode encoding,
        TextErrorMode errors,
        TextNewlineMode newline,
        ExecutionState context,
        LythonSourceSpan? span,
        bool outputAlreadyFunded = false, MemoryGovernor.TemporaryMemoryReservation? outputStorage = null, PyString? originalText = null)
    {
        context.CheckExecution(span);
        if (IsUtf16Encoding(encoding)) return EncodeUtf16Text(source, encoding, newline, context, span, outputAlreadyFunded, outputStorage);
        if (IsSingleByteEncoding(encoding))
        {
            return EncodeSingleByte(source, encoding, errors, newline, context, span, outputAlreadyFunded, outputStorage, originalText);
        }

        var newlineExpansion = 0;
        if (newline == TextNewlineMode.PreserveCarriageReturnLineFeed)
        {
            var work = 0;
            foreach (var value in source)
            {
                if ((work++ & 1023) == 0) context.CheckExecution(span);
                if (value == (byte)'\n')
                {
                    newlineExpansion++;
                }
            }
        }

        var bomLength = encoding == TextEncodingMode.Utf8Bom ? 3 : 0;
        var byteCount = checked(source.Length + newlineExpansion + bomLength);
        using var storage = outputAlreadyFunded || outputStorage is not null ? null
            : context.MemoryGovernor.ReserveTemporary(PyBytes.EstimateApproximateBytes(byteCount), span);
        outputStorage?.Grow(PyBytes.EstimateApproximateBytes(byteCount), span);
        var bytes = new byte[byteCount];
        var offset = 0;
        if (bomLength != 0)
        {
            bytes[0] = 0xEF;
            bytes[1] = 0xBB;
            bytes[2] = 0xBF;
            offset = 3;
        }

        if (newline is TextNewlineMode.TranslateUniversal or TextNewlineMode.PreserveUniversal or TextNewlineMode.PreserveLineFeed)
        {
            source.CopyTo(bytes.AsSpan(offset));
            storage?.Commit(PyBytes.EstimateApproximateBytes(byteCount));
        return bytes;
        }

        var copyWork = 0;
        foreach (var value in source)
        {
            if ((copyWork++ & 1023) == 0) context.CheckExecution(span);
            if (value != (byte)'\n')
            {
                bytes[offset++] = value;
                continue;
            }

            bytes[offset++] = (byte)'\r';
            if (newline == TextNewlineMode.PreserveCarriageReturnLineFeed)
            {
                bytes[offset++] = (byte)'\n';
            }
        }

        storage?.Commit(PyBytes.EstimateApproximateBytes(byteCount));
        return bytes;
    }

    private static byte[] EncodeSingleByte(
        ReadOnlySpan<byte> source,
        TextEncodingMode encoding,
        TextErrorMode errors,
        TextNewlineMode newline,
        ExecutionState context,
        LythonSourceSpan? span,
        bool outputAlreadyFunded, MemoryGovernor.TemporaryMemoryReservation? outputStorage, PyString? originalText)
    {
        var byteCount = 0;
        var position = 0;
        for (var sourceOffset = 0; sourceOffset < source.Length; position++)
        {
            if ((position & 1023) == 0) context.CheckExecution(span);
            _ = Rune.DecodeFromUtf8(source[sourceOffset..], out var rune, out var consumed);
            sourceOffset += consumed;
            if (rune.Value == '\n' && newline == TextNewlineMode.PreserveCarriageReturnLineFeed)
            {
                byteCount = checked(byteCount + 2);
                continue;
            }

            if (TryEncodeSingleByteScalar(rune.Value, encoding, out _))
            {
                byteCount++;
            }
            else
            {
                byteCount = errors switch
                {
                    TextErrorMode.Ignore => byteCount,
                    TextErrorMode.Replace => checked(byteCount + 1),
                    TextErrorMode.BackslashReplace => checked(byteCount + BackslashEscapedRuneLength(rune)),
                    _ => throw SingleByteEncodeError(position, encoding, span, context.MemoryGovernor, source, sourceOffset, originalText, context)
                };
            }
        }

        using var storage = outputAlreadyFunded || outputStorage is not null ? null
            : context.MemoryGovernor.ReserveTemporary(PyBytes.EstimateApproximateBytes(byteCount), span);
        outputStorage?.Grow(PyBytes.EstimateApproximateBytes(byteCount), span);
        if (byteCount == 0)
        {
            return [];
        }

        var bytes = new byte[byteCount];
        var offset = 0;
        position = 0;
        for (var sourceOffset = 0; sourceOffset < source.Length;)
        {
            if ((position++ & 1023) == 0) context.CheckExecution(span);
            _ = Rune.DecodeFromUtf8(source[sourceOffset..], out var rune, out var consumed);
            sourceOffset += consumed;
            if (rune.Value == '\n' && newline is TextNewlineMode.PreserveCarriageReturn or TextNewlineMode.PreserveCarriageReturnLineFeed)
            {
                bytes[offset++] = (byte)'\r';
                if (newline == TextNewlineMode.PreserveCarriageReturnLineFeed)
                {
                    bytes[offset++] = (byte)'\n';
                }

                continue;
            }

            if (TryEncodeSingleByteScalar(rune.Value, encoding, out var singleByte))
            {
                bytes[offset++] = singleByte;
                continue;
            }

            switch (errors)
            {
                case TextErrorMode.Ignore:
                    break;
                case TextErrorMode.Replace:
                    bytes[offset++] = (byte)'?';
                    break;
                case TextErrorMode.BackslashReplace:
                    WriteBackslashEscapedRune(rune, bytes, ref offset);
                    break;
            }
        }

        storage?.Commit(PyBytes.EstimateApproximateBytes(byteCount));
        return bytes;
    }

    private static void WriteBackslashEscapedRune(Rune rune, byte[] destination, ref int offset)
    {
        const string hex = "0123456789abcdef";
        var digits = rune.Value <= 0xff ? 2 : rune.Value <= 0xFFFF ? 4 : 8;
        destination[offset++] = (byte)'\\';
        destination[offset++] = rune.Value <= 0xff ? (byte)'x' : rune.Value <= 0xFFFF ? (byte)'u' : (byte)'U';
        for (var shift = (digits - 1) * 4; shift >= 0; shift -= 4)
        {
            destination[offset++] = (byte)hex[(rune.Value >> shift) & 0xF];
        }
    }

    private static LythonRuntimeException SingleByteEncodeError(int position, TextEncodingMode encoding,
        LythonSourceSpan? span, MemoryGovernor governor, ReadOnlySpan<byte> source, int nextOffset,
        PyString? original, ExecutionState guards)
    {
        var end = position + 1;
        for (var offset = nextOffset; offset < source.Length;)
        {
            if ((end & 1023) == 0) guards.CheckExecution(span);
            _ = Rune.DecodeFromUtf8(source[offset..], out var rune, out var consumed);
            if (TryEncodeSingleByteScalar(rune.Value, encoding, out _)) break;
            offset += consumed;
            end++;
        }
        var name = encoding == TextEncodingMode.Windows1252 ? "charmap" : encoding == TextEncodingMode.Ascii ? "ascii" : "latin-1";
        var reason = encoding == TextEncodingMode.Windows1252 ? "character maps to <undefined>"
            : "ordinal not in range(" + (SingleByteMaximumScalar(encoding) + 1) + ")";
        guards.CheckExecution(span);
        if (original is null)
        {
            using var storage = governor.ReserveTemporary(PyString.EstimateApproximateBytes(source.Length), span);
            original = PyString.FromOwnedUtf8(source.ToArray(), governor, span, storage);
        }
        return CodecError("UnicodeEncodeError", name, original,
            position, end, reason, governor, span, guards);
    }

    private static PyString DecodeUtf8WithErrors(ReadOnlySpan<byte> source, MemoryGovernor governor,
        LythonSourceSpan? span, TextErrorMode errors, TextNewlineMode newline, ExecutionState? guards)
    {
        var translate = newline == TextNewlineMode.TranslateUniversal;
        long length = 0;
        var afterCarriageReturn = false;
        var work = 0;
        for (var index = 0; index < source.Length;)
        {
            if ((work++ & 1023) == 0) guards?.CheckExecution(span);
            if (TryDecodeUtf8Rune(source[index..], out var rune, out var valid, out var invalid, out var reason))
            {
                if (!(translate && rune.Value == '\n' && afterCarriageReturn)) length += valid;
                afterCarriageReturn = translate && rune.Value == '\r';
                index += valid;
                continue;
            }

            length += errors switch
            {
                TextErrorMode.Ignore => 0,
                TextErrorMode.Replace => 3,
                TextErrorMode.BackslashReplace => 4L * invalid,
                _ => throw DecodeError(source, "utf-8", index, index + invalid, reason, governor, span, guards),
            };
            // Ignored bytes do not separate a decoded CR/LF pair.
            if (errors != TextErrorMode.Ignore) afterCarriageReturn = false;
            index += invalid;
        }
        guards?.CheckExecution(span);
        if (length == 0) return PyString.Empty;
        if (length > int.MaxValue) throw RuntimeErrors.Runtime("UTF-8 decoded text exceeds the supported buffer size", span);
        using var storage = governor.ReserveTemporary(PyString.EstimateApproximateBytes(0) + length, span);
        var bytes = new byte[(int)length];
        var offset = 0;
        afterCarriageReturn = false;
        work = 0;
        const string hex = "0123456789abcdef";
        for (var index = 0; index < source.Length;)
        {
            if ((work++ & 1023) == 0) guards?.CheckExecution(span);
            if (TryDecodeUtf8Rune(source[index..], out var rune, out var valid, out var invalid, out _))
            {
                if (translate && rune.Value == '\r') bytes[offset++] = (byte)'\n';
                else if (!(translate && rune.Value == '\n' && afterCarriageReturn))
                {
                    source.Slice(index, valid).CopyTo(bytes.AsSpan(offset));
                    offset += valid;
                }
                afterCarriageReturn = translate && rune.Value == '\r';
                index += valid;
                continue;
            }

            if (errors == TextErrorMode.Replace)
            {
                bytes[offset++] = 0xef; bytes[offset++] = 0xbf; bytes[offset++] = 0xbd;
            }
            else if (errors == TextErrorMode.BackslashReplace)
            {
                foreach (var value in source.Slice(index, invalid))
                {
                    bytes[offset++] = (byte)'\\'; bytes[offset++] = (byte)'x';
                    bytes[offset++] = (byte)hex[value >> 4]; bytes[offset++] = (byte)hex[value & 15];
                }
            }
            if (errors != TextErrorMode.Ignore) afterCarriageReturn = false;
            index += invalid;
        }
        guards?.CheckExecution(span);
        return PyString.FromOwnedUtf8(bytes, governor, span, storage);
    }

    private static bool TryDecodeUtf8Rune(ReadOnlySpan<byte> utf8, out Rune rune, out int validLength,
        out int invalidLength, out string reason)
    {
        rune = default; validLength = 0; invalidLength = 1;
        reason = "invalid start byte";
        var first = utf8[0];
        if (first < 128) { rune = new Rune(first); validLength = 1; return true; }
        var expected = first is >= 0xC2 and <= 0xDF ? 2
            : first is >= 0xE0 and <= 0xEF ? 3 : first is >= 0xF0 and <= 0xF4 ? 4 : 0;
        if (expected == 0) return false;
        for (var i = 1; i < expected; i++)
        {
            invalidLength = i;
            if (i == utf8.Length) { reason = "unexpected end of data"; return false; }
            var next = utf8[i];
            if (!IsUtf8Continuation(next) || i == 1 &&
                (first == 0xE0 && next < 0xA0 || first == 0xED && next >= 0xA0 ||
                 first == 0xF0 && next < 0x90 || first == 0xF4 && next >= 0x90))
            { reason = "invalid continuation byte"; return false; }
        }
        _ = Rune.DecodeFromUtf8(utf8[..expected], out rune, out validLength);
        return true;
    }

    private static bool IsUtf8Continuation(byte value)
        => (value & 0b1100_0000) == 0b1000_0000;

}
