using System.Text;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed class TextwrapModule : PyModule
    {
        internal static readonly TextwrapModule Instance = new();
        private TextwrapModule() : base("textwrap") { }

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "dedent" => BuiltinCallable.Create(LythonKnownCallableSignatures.TextwrapDedent, Dedent),
                "indent" => BuiltinCallable.Create(LythonKnownCallableSignatures.TextwrapIndent,
                    (args, span, context) => IndentAsync(args, span, context, false).GetAwaiter().GetResult(),
                    (args, span, context) => IndentAsync(args, span, context, true)),
                _ => MissingMemberValue.Instance,
            };
            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        private static object Dedent(object[] args, LythonSourceSpan span, ExecutionContext context)
        {
            if (!PyStringOps.TryAsString(args[0], out var text))
                throw new LythonRuntimeException("TypeError", "textwrap.dedent() expects string text", span);
            return DedentText(text, span, context.State);
        }

        private static ValueTask<object> IndentAsync(object[] args, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var predicate = args.Length == 3 ? args[2] : PyNone.Instance;
            return PyStringOps.TryAsString(args[0], out var text)
                ? IndentTextAsync(text, args[1], predicate, span, context, asynchronous)
                : IndentOtherAsync(args[0], args[1], predicate, span, context, asynchronous);
        }

        internal static PyString DedentText(PyString text, LythonSourceSpan span, ExecutionState services)
        {
            var source = text.Utf8Span;
            var marginStart = 0;
            var marginLength = -1;
            var normalizeBlankLines = false;
            for (var start = 0; start < source.Length;)
            {
                services.CheckExecution(span);
                var end = FindLf(source, start, span, services);
                var indent = LeadingIndent(source, start, end, span, services);
                if (indent == end - start)
                {
                    normalizeBlankLines |= indent != 0;
                }
                else if (marginLength < 0)
                {
                    marginStart = start;
                    marginLength = indent;
                }
                else
                {
                    marginLength = Math.Min(marginLength, indent);
                    var shared = 0;
                    while (shared < marginLength && source[marginStart + shared] == source[start + shared])
                    {
                        if ((shared & 1023) == 0) services.CheckExecution(span);
                        shared++;
                    }
                    marginLength = shared;
                }
                start = end == source.Length ? end : end + 1;
            }
            if (marginLength <= 0 && !normalizeBlankLines) return text;
            marginLength = Math.Max(0, marginLength);
            var builder = new GovernedByteBuilder(services.MemoryGovernor, span);
            try
            {
                for (var start = 0; start < source.Length;)
                {
                    services.CheckExecution(span);
                    var end = FindLf(source, start, span, services);
                    var indent = LeadingIndent(source, start, end, span, services);
                    if (indent != end - start) builder.Append(source[(start + marginLength)..end]);
                    if (end != source.Length) builder.Append((byte)'\n');
                    start = end == source.Length ? end : end + 1;
                }
                return Finish(builder, span, services);
            }
            finally { builder.Release(); }
        }

        // Dedent's multiline regex rules use LF anchors, unlike splitlines.
        private static int FindLf(ReadOnlySpan<byte> source, int start, LythonSourceSpan span, ExecutionState services)
        {
            var end = start;
            while (end < source.Length && source[end] != (byte)'\n')
            {
                if ((end & 1023) == 0) services.CheckExecution(span);
                end++;
            }
            return end;
        }

        private static int LeadingIndent(ReadOnlySpan<byte> source, int start, int end, LythonSourceSpan span, ExecutionState services)
        {
            var cursor = start;
            while (cursor < end && source[cursor] is (byte)' ' or (byte)'\t')
            {
                if ((cursor & 1023) == 0) services.CheckExecution(span);
                cursor++;
            }
            return cursor - start;
        }

        internal static async ValueTask<object> IndentTextAsync(PyString text, object prefix, object predicate,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var services = context.State;
            var builder = new GovernedByteBuilder(services.MemoryGovernor, span);
            object? invalidItem = null;
            try
            {
                for (var start = 0; start < text.ByteLength;)
                {
                    var line = ScanLine(text.Utf8Span, start, span, services);
                    var selected = line.HasNonWhitespace;
                    PyString? lineText = null;
                    if (predicate is not PyNone)
                    {
                        lineText = PyString.FromUtf8(text.Utf8Bytes.Slice(start, line.EndByte - start), services.MemoryGovernor, span);
                        selected = await SelectLineAsync(lineText, predicate, span, context, asynchronous).ConfigureAwait(false);
                    }
                    services.CheckExecution(span);
                    if (selected && prefix is not PyString)
                    {
                        invalidItem ??= prefix;
                    }
                    else if (invalidItem is null)
                    {
                        if (selected) builder.Append(((PyString)prefix).Utf8Span);
                        builder.Append(text.Utf8Span[start..line.EndByte]);
                    }
                    start = line.EndByte;
                }
                // Python 3.13 joins prefixes as separate items, without an
                // addition operator, and validates after every predicate ran.
                if (invalidItem is not null)
                    throw new LythonRuntimeException("TypeError", "indent produced a non-string item", span);
                return Finish(builder, span, services);
            }
            finally { builder.Release(); }
        }

        private static async ValueTask<object> IndentOtherAsync(object text, object prefix, object predicate,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var lines = await CallMemberAsync(text, "splitlines", [CallArgumentValue.Positional(true)],
                span, context, asynchronous).ConfigureAwait(false);
            var services = context.State;
            var builder = new GovernedByteBuilder(services.MemoryGovernor, span);
            var invalidItem = false;
            try
            {
                if (asynchronous)
                {
                    await foreach (var line in PyIteration.ToSequenceAsync(lines, span, context).ConfigureAwait(false))
                        await AppendLineAsync(line).ConfigureAwait(false);
                }
                else
                {
                    foreach (var line in PyIteration.ToSequence(lines, span, context))
                        await AppendLineAsync(line).ConfigureAwait(false);
                }
                if (invalidItem)
                    throw new LythonRuntimeException("TypeError", "indent produced a non-string item", span);
                return Finish(builder, span, services);
            }
            finally { builder.Release(); }

            async ValueTask AppendLineAsync(object line)
            {
                services.CheckExecution(span);
                var selected = await SelectLineAsync(line, predicate, span, context, asynchronous).ConfigureAwait(false);
                services.CheckExecution(span);
                if (line is not PyString lineText || (selected && prefix is not PyString))
                    invalidItem = true;
                else if (!invalidItem)
                {
                    if (selected) builder.Append(((PyString)prefix).Utf8Span);
                    builder.Append(lineText.Utf8Span);
                }
            }
        }

        private static async ValueTask<bool> SelectLineAsync(object line, object predicate,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            object result;
            if (predicate is PyNone)
                result = await CallMemberAsync(line, "isspace", [], span, context, asynchronous).ConfigureAwait(false);
            else
            {
                if (predicate is not ICallable callable)
                    throw new LythonRuntimeException("TypeError", "predicate is not callable", span);
                result = asynchronous
                    ? await CallableInvocation.InvokeUnaryAsync(callable, line, span, context).ConfigureAwait(false)
                    : CallableInvocation.InvokeUnary(callable, line, span, context);
            }
            var truth = asynchronous
                ? await IsTruthyAsync(result, context, span).ConfigureAwait(false)
                : IsTruthy(result, context, span);
            return predicate is PyNone ? !truth : truth;
        }

        private static async ValueTask<object> CallMemberAsync(object target, string name, CallArgumentValue[] arguments,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var member = asynchronous
                ? await PyTextStream.ResolveMemberAsync(target, name, span, context).ConfigureAwait(false)
                : PyTextStream.ResolveMember(target, name, span, context);
            var result = asynchronous
                ? await InvokeCallableTargetAsync(member, span, span, context,
                    () => ValueTask.FromResult(arguments)).ConfigureAwait(false)
                : InvokeCallableTarget(member, span, span, context, () => arguments);
            return result;
        }

        private readonly record struct LineFacts(int EndByte, bool HasNonWhitespace);

        private static LineFacts ScanLine(ReadOnlySpan<byte> source, int start, LythonSourceSpan span, ExecutionState services)
        {
            var cursor = start;
            var nonWhitespace = false;
            long nextCheck = start;
            while (cursor < source.Length)
            {
                if (cursor >= nextCheck) { services.CheckExecution(span); nextCheck = (long)cursor + 1024; }
                if (PyStringOps.TryGetLineBreakByteLength(source, cursor, out var endingBytes))
                {
                    return new LineFacts(cursor + endingBytes, nonWhitespace);
                }
                Rune.DecodeFromUtf8(source[cursor..], out var rune, out var width);
                nonWhitespace |= !PyStringOps.IsPythonWhitespace(rune);
                cursor += width;
            }
            return new LineFacts(cursor, nonWhitespace);
        }

        private static PyString Finish(GovernedByteBuilder builder, LythonSourceSpan span, ExecutionState services)
        {
            var result = builder.ToPyStringAndRelease();
            return result;
        }
    }
}
