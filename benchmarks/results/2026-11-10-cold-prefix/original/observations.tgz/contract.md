# R200 bounded source pair

Reference039/qualified66eb versus frozen9e0b cold-body prototype. Same exact five
complete scripts/fixtures/goldens:CSV/text/report/search/generator text. Six jobs:
five warm synchronous plus text compilation. All desktop adversity and Windows
JIT shape/cold-helper frame tradeoffs retained. No primary CPython replacement.
Four independent source/control processes,5s warmup,7rotated400msrounds.240sowner,
30sstop/30smargin. Preserve all identity/ownership/quiet/join/archive/SHA gates.
No promotion/CPU/equivalence claim before actual results/debt decision.
