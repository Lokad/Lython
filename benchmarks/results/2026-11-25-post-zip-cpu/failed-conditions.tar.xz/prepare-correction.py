from pathlib import Path
import shutil
r=Path(__file__).parent
q=r.parent/'post-zip-cpu-corrected-20261125';q.mkdir(exist_ok=True)
for name in ['identity.json','catalog.json','candidate-verification.json','verified-raw-replicas.json','analyze.py','archive.py','run.sh']:
 shutil.copyfile(r/name,q/name)
for name in ['quiet.py','collect.py','ops-profile.py']:
 source=(r/name).read_text(encoding='utf-8').replace('post-zip-cpu-b1666-20261125','post-zip-cpu-corrected-b1666-20261125').replace('lython-b1666-post-zip-cpu-20261125','lython-b1666-post-zip-cpu-corrected-20261125')
 if name=='quiet.py':source=source.replace('4*1024*1024','6*1024*1024').replace('seconds=87','seconds=90')
 if name=='collect.py':source=source.replace('3840*1024','6*1024*1024-256*1024')
 if name=='ops-profile.py':
  source=source.replace('                if perf_map.exists():shutil.copyfile(perf_map, folder/\'perf.map\')','''                if perf_map.exists(): preserve_map(perf_map, folder/'perf.map.gz')''')
  source=source.replace('        def control(command, wait=True):','''        def preserve_map(source, target):
            blob = source.read_bytes()
            with gzip.open(target, 'wb') as stream: stream.write(blob)
            with gzip.open(target, 'rb') as stream: assert stream.read() == blob

        def control(command, wait=True):''')
  source=source.replace('                    retained = folder / ("perf.map" if prefix == "perf" else "perfinfo.map")\n                    shutil.copyfile(temporary, retained)\n                    assert hashlib.sha256(temporary.read_bytes()).digest() == hashlib.sha256(retained.read_bytes()).digest()','''                    retained = folder / ("perf.map.gz" if prefix == "perf" else "perfinfo.map.gz")
                    preserve_map(temporary, retained)''')
  source=source[:source.index("        for map_name in ['perf.map','perfinfo.map']:")]+source[source.index('        print(json.dumps({"name": name,'):]
 (q/name).write_text(source,encoding='utf-8',newline='\n')
