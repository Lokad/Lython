import collections,json,re
from pathlib import Path
r=Path(__file__).parent;a=json.loads((r/'attribution.json').read_text(encoding='utf-8'))['rows'][1]
counts=collections.Counter(); phase=collections.Counter()
for frame,count in a['nearestLythonFrames']:
    found=re.search(r' Lokad\.Lython\.Frontend\.(\S+::[^\s(]+)\(',frame)
    if found is None: continue
    key=found[1]; counts[key]+=count
    phase[key.split('::')[0].split('+')[0]]+=count
for key,count in phase.most_common(17): print(count,key)
print('local diagnostics',[(k,v) for k,v in counts.most_common() if 'StaticNameBindingDiagnostics' in k]); print(counts.most_common(12))
