from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
lab=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73']
with tarfile.open(lab/'failed-observations.tar.xz') as archive: proof=json.load(archive.extractfile('verified-members.json'))
source="""
from pathlib import Path
import fcntl,hashlib,json,os,stat,shutil,subprocess
parent=Path('/home/lokad/lython-bench-checks'); root=parent/'post-zip-cpu-b1666-20261125'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['systemctl','show','lython-b1666-post-zip-cpu-20261125.service','--property=MainPID','--value'],capture_output=True,text=True).stdout.strip()=='0'
 assert not Path('/proc/328827').exists()
 temp=Path('/tmp/perf-328827.map'); partial=root/'profiles/validator-compile/perf.map'
 for name,path in [('surviving-runtime-map.txt',temp),('profiles/validator-compile/perf.map',partial)]:
  assert path.resolve()==path and path.stat().st_nlink==1 and sha(path)==proof[name]
  path.unlink()
 fixtures=root/'guest-fixtures'
 assert fixtures.resolve()==fixtures and os.path.ismount(fixtures)
 leftovers={p.name:stat.filemode(p.lstat().st_mode) for p in fixtures.iterdir()}
 assert leftovers and all('328827' in name and mode[0] in 'ps' for name,mode in leftovers.items())
 subprocess.run(['sudo','-n','umount',str(fixtures)],check=True)
 fixtures.rmdir()
 print(json.dumps(dict(freeAfter=shutil.disk_usage(root).free, fixtureEntries=leftovers, rawCopiesRetired=[str(temp),str(partial)])))
"""
result=subprocess.check_output(ssh+['python3 -c '+shlex.quote(f'proof={proof!r}\n'+source)],encoding='utf-8',timeout=25)
print(result);(lab/'failed-cleanup.json').write_text(result,encoding='utf-8')
