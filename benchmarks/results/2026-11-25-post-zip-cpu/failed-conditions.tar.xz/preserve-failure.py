from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
lab=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73']
state=json.loads((lab/'status-000709.json').read_text())
assert not state['live'] and 'MainPID=0' in state['service']
remote="""
from pathlib import Path
import fcntl,io,hashlib,json,subprocess,sys,tarfile
parent=Path('/home/lokad/lython-bench-checks'); root=parent/'post-zip-cpu-b1666-20261125'
with (parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['systemctl','show','lython-b1666-post-zip-cpu-20261125.service','--property=MainPID','--value'],capture_output=True,text=True).stdout.strip()=='0'
 assert not Path('/proc/328827').exists()
 with tarfile.open(fileobj=sys.stdout.buffer,mode='w|xz') as stream:
  verified={}
  for p in sorted(root.rglob('*')):
   if p.is_file() and not p.is_symlink():
    name=p.relative_to(root).as_posix(); stream.add(p,arcname=name,recursive=False);verified[name]=hashlib.sha256(p.read_bytes()).hexdigest()
  retained=Path('/tmp/perf-328827.map')
  assert retained.is_file() and retained.stat().st_uid==root.stat().st_uid
  stream.add(retained,arcname='surviving-runtime-map.txt',recursive=False)
  verified['surviving-runtime-map.txt']=hashlib.sha256(retained.read_bytes()).hexdigest()
  related=subprocess.check_output(['findmnt','--json','--mountpoint',root/'guest-fixtures'])
  inputs={'mounted-fixtures.json':related,'verified-members.json':json.dumps(verified,indent=2).encode()}
  for name,data in inputs.items():
   item=tarfile.TarInfo(name);item.size=len(data);stream.addfile(item,io.BytesIO(data))
"""
out=lab/'failed-observations.tar.xz'
with out.open('wb') as stream:
 subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],stdout=stream,check=True,timeout=45)
with tarfile.open(out) as archive:
 proof=json.load(archive.extractfile('verified-members.json'))
 for name,hash in proof.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==hash
 print([(n,hash) for n,hash in proof.items() if ('perf.map' in n or n=='surviving-runtime-map.txt')])
 print(out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),len(proof))
