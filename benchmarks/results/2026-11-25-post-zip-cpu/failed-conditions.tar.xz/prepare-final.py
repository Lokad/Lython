from pathlib import Path
import json,shlex,subprocess,hashlib,tarfile,shutil
r=Path(__file__).parent;q=r.parent/'post-zip-cpu-corrected-20261125';final=r.parent/'post-zip-cpu-final-20261125';final.mkdir(exist_ok=True)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73']
script=(r/'preserve-failure.py').read_text(encoding='utf-8');start=script.index('remote=');stop=script.index('out=lab')
selected=script[start:stop].replace('post-zip-cpu-b1666','post-zip-cpu-corrected-b1666').replace('lython-b1666-post-zip-cpu-20261125','lython-b1666-post-zip-cpu-corrected-20261125').replace('328827','329418').replace("related=subprocess.check_output(['findmnt','--json','--mountpoint',root/'guest-fixtures'])", "related=b'directory unmounted' if not (root/'guest-fixtures').exists() else b'directory remains'")
exec(selected)
failed=q/'failed-observations.tar.xz'
with failed.open('wb') as stream:subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],stdout=stream,check=True,timeout=30)
with tarfile.open(failed) as evidence:
    proof=json.load(evidence.extractfile('verified-members.json'))
    assert all(hashlib.sha256(evidence.extractfile(n).read()).hexdigest()==h for n,h in proof.items())
for n in ['identity.json','catalog.json','candidate-verification.json','verified-raw-replicas.json','analyze.py','archive.py','run.sh','ops-profile.py']:
    shutil.copyfile(q/n,final/n)
shutil.copyfile(r/'prepare.py',final/'prepare.py')
for n in ['quiet.py','collect.py']:
    data=(q/n).read_text(encoding='utf-8').replace('post-zip-cpu-corrected-b1666','post-zip-cpu-final-b1666').replace('lython-b1666-post-zip-cpu-corrected-20261125','lython-b1666-post-zip-cpu-final-20261125').replace('6*1024*1024','32*1024*1024')
    (final/n).write_text(data,encoding='utf-8',newline='\n')
print('Retained failed follow-up',len(proof),hashlib.sha256(failed.read_bytes()).hexdigest())
