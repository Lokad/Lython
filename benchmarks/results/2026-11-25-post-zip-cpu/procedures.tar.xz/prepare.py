from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.with_name('zip-unpack-20261125')
base=lab.with_name('shared-function-local-slots-20261125')
template=lab.with_name('shipment-and-defaulted-cpu-20261125')
quiet=source/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
git=lambda args:subprocess.check_output(['git',*args],cwd=repo)
production=git(['rev-parse','ac9f9211b']).decode().strip()
old=read(quiet/'identity.json')
patch=git(['diff','--binary',old['sourceRevision'],production,'--','src','Directory.Build.props','Directory.Packages.props','global.json'])
assert patch==(source/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==old['sourcePatchSHA256']
assert not git(['diff','--name-only',production,'--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'])
files=old['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in (source/'candidate').iterdir()}==files
receipt=read(quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
catalog=read(quiet/'representative.json')
shipment='diagnostic.shipment-routing-callbacks'
sparse='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
cases={c['id']:c for p in (quiet/'representative.json',base/'comparison/quiet/representative.json') for c in read(p)['cases']}
catalog['cases']=[cases[k] for k in (shipment,sparse)]
save(lab/'catalog.json',catalog)
identity=dict(sourceRevision=production,measurementReference=old['sourceRevision'],sourcePatchSHA256=old['sourcePatchSHA256'],
    imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']},cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    profiles=[('shipment-warm',shipment,'candidate'),('validator-compile',sparse,'candidate')],
    purpose='Attribute shipment CPU after direct zip unpack and check whether local-flow diagnostics dominate sparse compilation',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(lab/'catalog.json'))
save(lab/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
proof=lab/'candidate-verification.json'
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,source/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,check=True,timeout=65)
checked=read(proof)
assert checked['state']=='Completed' and checked['caseCount']==2 and checked['catalogSha256']==identity['profileCatalogSHA256']
assert checked['launched']['library']['sha256']==identity['coreSHA256']['candidate']
shutil.copyfile(template/'run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()
records=[]
results=repo/'benchmarks/results'
for stage,p in (
    ('zip-unpack-confirm-b1665-20261125','2026-11-25-zip-unpack/confirmation'),
    ('single-pass-operand-layout-refined-b1652-20261124','2026-11-24-single-pass-operand-layout/refinement'),
    ('prepared-default-pair-boundaries-refined-b1646-20261124','2026-11-24-prepared-default-pair-boundaries/refined'),
    ('prepared-default-pair-boundaries-b1645-20261124','2026-11-24-prepared-default-pair-boundaries'),
    ('shared-comprehension-facts-b1642-20261124','2026-11-24-shared-comprehension-facts'),
    ('regex-cursor-original-b1641-20261124','2026-11-24-regex-cursor-original'),
    ('shared-literal-decoding-b1639-20261124','2026-11-24-shared-literal-decoding/refinement'),
    ('shared-literal-decoding-b1638-20261124','2026-11-24-shared-literal-decoding'),
    ('shared-prepared-definitions-b1636-20261124','2026-11-24-shared-prepared-definitions/confirmation'),
    ('shared-prepared-definitions-b1635-20261124','2026-11-24-shared-prepared-definitions'),
):
    path=results/p
    if not (path/'quiet-terminal-status.json').is_file():continue
    closed=read(path/'quiet-terminal-status.json')['receipt']
    archive=path/'quiet-observations.tar.xz'
    assert closed['allWorkersJoined'] and closed['archivedAndVerifiedUnderLease'] and sha(archive)==closed['archiveSHA256']
    with tarfile.open(archive) as bundle:
        raw=bundle.extractfile('confirmation/confirmation.json').read()
    records.append(dict(location=stage,bytes=len(raw),archiveSHA256=closed['archiveSHA256'],rawSHA256=hashlib.sha256(raw).hexdigest()))
save(lab/'verified-raw-replicas.json',records)
launcher=(template/'quiet.py').read_text(encoding='utf-8').replace('shipment-and-defaulted-cpu-b1664','post-zip-cpu-b1666')
launcher=launcher.replace('lython-b1664-shipment-and-defaulted-cpu','lython-b1666-post-zip-cpu')
launcher=launcher.replace('shared-locals-cpython-20261125','zip-unpack-20261125').replace('checked["caseCount"]==4','checked["caseCount"]==2')
collector=(template/'collect.py').read_text(encoding='utf-8').replace('shared-locals-cpython-b1663','zip-unpack-b1665').replace('b1664-fixtures','b1666-fixtures')
ops=(template/'ops-profile.py').read_text(encoding='utf-8').replace('else "warm"','else "compile" if name.endswith("-compile") else "warm"')
analysis=(template/'analyze.py').read_text(encoding='utf-8')
archive=(template/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-shipment-and-defaulted-cpu','2026-11-25-post-zip-cpu')
archive=archive.replace('startswith("788be8f35")','startswith("ac9f9211b")').replace('else "warm"','else "compile" if row["label"].endswith("-compile") else "warm"')
for name,s in (('quiet.py',launcher),('collect.py',collector),('archive.py',archive),('analyze.py',analysis),('ops-profile.py',ops)):
    compile(s,name,'exec')
    write(lab/name,s)
