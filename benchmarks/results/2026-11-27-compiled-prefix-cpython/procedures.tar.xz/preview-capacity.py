from hashlib import sha256
from pathlib import Path
import gzip
import json
import re
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = Path.home() / ".ssh/id_lython-bench.pem"

def digest(data): return sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))

prior = lab.with_name("starmap-frame-inputs-20261126") / "comparison/quiet"
donor_archive_sha = read(prior / "terminal-status.json")["receipt"]["archiveSHA256"]
assert donor_archive_sha == sha(prior / "observations.tar.xz")
donor_files = read(prior / "identity.json")["imageFiles"]["candidate"]
new_files = read(lab / "corrected/identity.json")["imageFiles"]["candidate"]
assert set(new_files) == set(donor_files) and len(new_files) == 32
assert [name for name, value in new_files.items() if value != donor_files[name]] == ["Lokad.Lython.dll"]

eligible = []
choices = [
    ("native-dictionary-layout-only-20261125", "2026-11-25-native-dictionary-slots/layout-only/quiet-observations.tar.xz"),
    ("native-dictionary-prepared-consumers-20261125", "2026-11-25-native-dictionary-slots/prepared/quiet-observations.tar.xz"),
    ("unified-builtin-operands-20261125", "2026-11-25-unified-builtin-operands/quiet-observations.tar.xz"),
]
for source, archive in choices:
    prior = lab.with_name(source)
    run = prior / "comparison/quiet"
    terminal = read(run / "terminal-status.json")
    receipt = terminal["receipt"]
    assert terminal["exitCode"] == "0" and not terminal["live"] and not terminal["fixtures"]
    assert all(receipt[field] for field in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
    published = subprocess.check_output(["git", "show", "origin/master:benchmarks/results/" + archive], cwd=repo)
    assert digest(published) == receipt["archiveSHA256"] == sha(run / "observations.tar.xz")
    unit, = set(re.findall(r"lython-b[a-z0-9-]+\.service", terminal["journal"]))
    with tarfile.open(run / "observations.tar.xz") as data:
        image = json.load(data.extractfile("identity.json"))["imageFiles"]["candidate"]
    local = prior / "candidate"
    assert len(image) == 32 and {file.name: sha(file) for file in local.iterdir()} == image
    core = local / "Lokad.Lython.dll"
    keep = lab / (source + ".core.dll.gz")
    if not keep.exists():
        keep.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert digest(gzip.decompress(keep.read_bytes())) == sha(core)
    eligible.append(dict(root=read(run / "upload.json")["root"], unit=unit, image=image, size=core.stat().st_size,
                         archive=receipt["archiveSHA256"], backup=str(keep)))

cfg = dict(choices=eligible, donor="starmap-frame-inputs-b1804-20261126",
           donorArchive=donor_archive_sha, donorFiles=donor_files)
program = r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    donor=base/cfg['donor']
    assert donor.resolve()==donor and donor.parent==base
    donor_receipt=json.loads((donor/'archive-receipt.json').read_text())
    assert donor_receipt['archiveSHA256']==cfg['donorArchive']==sha(donor/'observations.tar.xz')
    assert {p.name:sha(p) for p in (donor/'candidate').iterdir()}==cfg['donorFiles']
    aliases=[p for role in ('candidate','reference') for p in base.glob('*/'+role+'/Lokad.Lython.dll') if p.exists()]
    found=[]
    for choice in cfg['choices']:
        root=base/choice['root']
        image=root/'candidate'
        core=image/'Lokad.Lython.dll'
        if not core.exists() or core.resolve()!=core or root.resolve()!=root or root.parent!=base:
            found.append(dict(root=choice['root'], eligible=False));continue
        equivalent=[str(p.relative_to(base)) for p in aliases if p.resolve()==core]
        meta=core.lstat()
        state=subprocess.check_output(['systemctl','show',choice['unit'],'--property=ActiveState,MainPID'],text=True).splitlines()
        receipt=json.loads((root/'archive-receipt.json').read_text())
        actual={p.name:sha(p) for p in image.iterdir()}
        checks=dict(aliases=equivalent==[str(core.relative_to(base))],owner=meta.st_uid==os.getuid(),regular=stat.S_ISREG(meta.st_mode),
                  soleHardLink=meta.st_nlink==1,size=meta.st_size==choice['size'],inactive='ActiveState=inactive' in state and 'MainPID=0' in state,
                  archive=receipt['archiveSHA256']==choice['archive']==sha(root/'observations.tar.xz'),
                  terminal=receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'],image=actual==choice['image'])
        found.append(dict(root=choice['root'], eligible=all(checks.values()), physicalBytes=meta.st_blocks*512, references=equivalent,
                  failed=[name for name,passed in checks.items() if not passed], otherFiles=sorted(actual.keys()-choice['image'].keys()),
                  unequalFiles=sorted(name for name,value in choice['image'].items() if actual.get(name)!=value)))
    print(json.dumps(dict(free=shutil.disk_usage(base).free,results=found)))
"""
run = subprocess.run(["ssh", "-i", str(base), "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", "lokad@20.166.121.73", "python3 -"],
                     input="cfg=" + repr(cfg) + "\n" + program, encoding="utf-8", capture_output=True, timeout=50)
if run.returncode:
    print(run.stderr)
    run.check_returncode()
proof = dict(result=json.loads(run.stdout), configuration=cfg)
(lab / "vm-duplicate-preview.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(run.stdout.strip())
