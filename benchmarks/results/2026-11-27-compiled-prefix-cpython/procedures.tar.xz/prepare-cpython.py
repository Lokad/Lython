from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("post-starmap-cpython-20261126")
collection = prior / "comparison/quiet"
source = lab / "corrected"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)

def read(file): return file.read_text(encoding="utf-8-sig")
def sha(file): return sha256(file.read_bytes()).hexdigest()
def write(file, data): file.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
def edit(text, replacements):
    for old, new in replacements:
        assert text.count(old)==1, old
        text=text.replace(old,new)
    return text

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head.startswith("c10f06884") and subprocess.check_output(["git", "rev-parse", "origin/master"], cwd=repo, text=True).strip() == head
original = json.loads(read(source / "identity.json"))
assert sha(source / "candidate.patch") == original["sourcePatchSHA256"]
assert subprocess.check_output(["git", "diff", "--binary", original["sourceRevision"], head, "--", "src"], cwd=repo) == (source / "candidate.patch").read_bytes()
assert not subprocess.check_output(["git", "status", "--porcelain", "--", "src"], cwd=repo)
proof = json.loads(read(source / "candidate-verify.json"))
assert proof["caseCount"] == 3 and proof["state"] == "Completed" and proof["catalogSha256"] == original["catalogSHA256"]
files = original["imageFiles"]["candidate"]
assert len(files) == 32 and {file.name:sha(file) for file in (source / "candidate").iterdir()} == files
assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    shutil.copyfile(source / name, quiet / name)
assert sha(quiet / "representative.json") == original["catalogSHA256"]
assert sha(quiet / "cpython-worker.py") == original["cpythonWorkerSHA256"] == sha(repo / "benchmarks/cpython-worker.py")
assert b"\r" not in (quiet / "run.sh").read_bytes()
late = "scripts.file-search.large"
early = "diagnostic.file-search-first-line"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
write(quiet / "jobs.json", [[late,"warm"],[early,"warm"],[text,"warm"],[late,"compile"],[late,"warm-async"],[late,"compile-run"]])
old = json.loads(read(collection / "identity.json"))
remote = "compiled-prefix-cpython-b1815-20261127"
core = "Lokad.Lython.dll"
preview = json.loads(read(lab / "vm-duplicate-preview.json"))
assert preview["configuration"]["donorArchive"] == old["donorArchiveSHA256"]
assert all(value == preview["configuration"]["donorFiles"][name] for name, value in files.items() if name != core)
identity = dict(sourceRevision=head, productionSource=head, candidate=head,
    frozenImage=f"/home/lokad/lython-bench-checks/{remote}/candidate",
    auxiliaryFiles={name: sha for name, sha in files.items() if name != core},
    imageFiles={"candidate": files}, coreSHA256={role: files[core] for role in ("candidate","candidate-control")},
    cpythonWorkerSHA256=original["cpythonWorkerSHA256"], expectedCPythonSHA256=old["expectedCPythonSHA256"],
    donorArchiveSHA256=old["donorArchiveSHA256"], sourcePatchSHA256=original["sourcePatchSHA256"],
    catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")},
    priorExternalSource=old["sourceRevision"], purpose="Compare early and late protected file search against CPython with a Unicode report control.")
write(quiet / "identity.json", identity)
for name in ("collect.py","summarize.py"):
    updated = read(collection / name).replace("lython-b1805-fixtures", "lython-b1815-fixtures")
    compile(updated, name, "exec")
    (quiet / name).write_text(updated, encoding="utf-8", newline="\n")
names = ("identity.json", "jobs.json", "representative.json", "collect.py", "run.sh", "cpython-worker.py")
payload = quiet / "stage.tar.gz"
raw_core = source / "candidate" / core
with tarfile.open(payload,"w:gz",compresslevel=6) as bundle:
    for name in names:
        bundle.add(quiet / name, arcname=name, recursive=False)
    bundle.add(raw_core, arcname="candidate/"+core, recursive=False)
write(quiet / "upload.json",dict(root=remote,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
      expandedBytes=sum((quiet / name).stat().st_size for name in names)+raw_core.stat().st_size,minimumAfterStageBytes=4_800_000))
shutil.copyfile(source / "candidate-verify.json", quiet / "candidate-verify.json")

stage = edit(read(prior / "quiet.py"), [
    ("lython-b1805-post-starmap-cpython-20261126", "lython-b1815-compiled-prefix-cpython-20261127"),
    ("assert len(frames)==6 and len(set(f.name for f in frames))==6 and all(f.isfile() for f in frames)",
     "assert {f.name for f in frames}=={'identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py','candidate/Lokad.Lython.dll'} and len(frames)==7 and all(f.isfile() for f in frames)"),
    (" (root/'candidate').symlink_to(origin,target_is_directory=True)\n assert Path(image['frozenImage']) == root/'candidate' and Path(image['frozenImage']).resolve()==origin",
     """ candidate=root/'candidate'
 assert {p.name:sha(p) for p in origin.iterdir()}==dict(image['auxiliaryFiles'], **{'Lokad.Lython.dll':sha(origin/'Lokad.Lython.dll')})
 assert {p.name:sha(p) for p in candidate.iterdir()}=={'Lokad.Lython.dll': files['Lokad.Lython.dll']}
 for name in image['auxiliaryFiles']: os.link(origin/name,candidate/name)
 assert Path(image['frozenImage']) == candidate and candidate.resolve()==candidate
 assert {p.name:sha(p) for p in candidate.iterdir()}==files"""),
    ("assert len(files)==32 and {p.name:sha(p) for p in origin.iterdir()}==files", "assert len(files)==32"),
    ("origin/'Lokad.Lython.Benchmarks.dll'", "candidate/'Lokad.Lython.Benchmarks.dll'"),
    ("proof['caseCount']==4", "proof['caseCount']==3"),
    ("seconds=250", "seconds=220"),
])
compile(stage, "quiet-launch.py", "exec")
(lab / "quiet-launch.py").write_text(stage, encoding="utf-8", newline="\n")
print(read(quiet / "upload.json"))
