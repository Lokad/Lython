from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib,json,os,subprocess,sys

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
remote='/home/lokad/lython-bench-checks'
unit='lython-b1815-compiled-prefix-cpython-20261127'
vm=os.environ['LYTHON_BENCH_HOST']
common=['-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12']
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
configuration.update(base=remote,unit=unit)
prefix='cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,tarfile,json,os,shutil,subprocess
base=Path(cfg['base'])
root=base/cfg['root']
unit=cfg['unit']
assert root.resolve()==root and root.parent==base and base.resolve()==base
archive=base/(cfg['root']+'.tar.gz')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
'''
invoke=lambda code:subprocess.check_output(['ssh',*common,vm,'python3 -'],input=prefix+code,encoding='utf-8',timeout=48)
scp=['scp',*common]
if sys.argv[1]=='launch':
    payload=quiet/'stage.tar.gz'
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration['payloadSHA256']
    before=json.loads(invoke('''
assert not root.exists() and not archive.exists()
bytes=shutil.disk_usage(base).free
assert bytes>=cfg['payloadBytes']+cfg['expandedBytes']+cfg['minimumAfterStageBytes'],bytes
print(json.dumps(dict(freeBeforeUploadBytes=bytes)))
'''))
    subprocess.run(scp+[payload,vm+':'+remote+'/'+configuration['root']+'.tar.gz'],check=True,timeout=90)
    staged=invoke('''
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and archive.resolve()==archive and sha(archive)==cfg['payloadSHA256']
 with tarfile.open(archive) as package:
  frames=package.getmembers()
  assert {f.name for f in frames}=={'identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py','candidate/Lokad.Lython.dll'} and len(frames)==7 and all(f.isfile() for f in frames)
  expanded=sum(f.size for f in frames)
  assert expanded==cfg['expandedBytes']
  assert shutil.disk_usage(base).free>=expanded+cfg['minimumAfterStageBytes']
  root.mkdir()
  package.extractall(root,filter='data')
 image=json.loads((root/'identity.json').read_text())
 donor=base/'starmap-frame-inputs-b1804-20261126'
 receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert receipt['complete'] and receipt['allWorkersJoined']
 assert receipt['archiveSHA256']==image['donorArchiveSHA256']==sha(donor/'observations.tar.xz')
 origin=(donor/'candidate').resolve(strict=True)
 assert origin==base/'starmap-frame-inputs-b1804-20261126'/'candidate'
 files=image['imageFiles']['candidate']
 assert len(files)==32
 candidate=root/'candidate'
 assert {p.name:sha(p) for p in origin.iterdir()}==dict(image['auxiliaryFiles'], **{'Lokad.Lython.dll':sha(origin/'Lokad.Lython.dll')})
 assert {p.name:sha(p) for p in candidate.iterdir()}=={'Lokad.Lython.dll': files['Lokad.Lython.dll']}
 for name in image['auxiliaryFiles']: os.link(origin/name,candidate/name)
 assert Path(image['frozenImage']) == candidate and candidate.resolve()==candidate
 assert {p.name:sha(p) for p in candidate.iterdir()}==files
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==image['expectedCPythonSHA256']
 for name,metadata in image['catalogs'].items(): assert sha(root/name)==metadata['sha256']
 assert sha(root/'cpython-worker.py')==image['cpythonWorkerSHA256']
 archive.unlink()
 dotnet=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 verification=root/'remote-verify.json'
 subprocess.run([dotnet,candidate/'Lokad.Lython.Benchmarks.dll','--compare','verify',
  '--catalog',root/'representative.json','--dotnet',dotnet,'--python',python,
  '--python-worker',root/'cpython-worker.py','--out',verification],
  env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=28)
 proof=json.loads(verification.read_text())
 assert proof['state']=='Completed' and proof['caseCount']==3
 assert proof['catalogSha256']==image['catalogs']['representative.json']['sha256']
 assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
 print(json.dumps(dict(freeBeforeLaunchBytes=shutil.disk_usage(base).free,expandedBytes=expanded)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=320','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
''')
    (quiet/'launch.log').write_text(json.dumps(before)+'\n'+staged,encoding='utf-8')
    (quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=220)).isoformat(),encoding='utf-8')
    print(staged)
else:
    assert sys.argv[1]=='retrieve' and datetime.now(timezone.utc)>=datetime.fromisoformat((quiet/'observe-not-before').read_text(encoding='utf-8'))
    status=invoke('''
state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in state:
 print(json.dumps(dict(live=True,service=state)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps(dict(live=False,service=state,exitCode=code.read_text().strip() if code.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','38','--no-pager'],capture_output=True,text=True).stdout)))
''')
    result=json.loads(status)
    (quiet/f'status-{datetime.now(timezone.utc):%H%M%S}.json').write_text(status,encoding='utf-8')
    if not result['live']:
        (quiet/'terminal-status.json').write_text(status,encoding='utf-8')
        if result['receipt']:
            archive=quiet/'observations.tar.xz'
            subprocess.run(scp+[vm+':'+remote+'/'+configuration['root']+'/'+archive.name,archive],check=True,timeout=45)
            assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['receipt']['archiveSHA256']
    print(status)
