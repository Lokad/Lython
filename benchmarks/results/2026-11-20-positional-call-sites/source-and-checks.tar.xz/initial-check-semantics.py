from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases={'ordinary-and-variadic-methods': 'class Box:\n    def pack(self, head=0, /, *rest, flag=3, **kw): return head,rest,flag,kw\nb=Box()\nsaved=b.pack\nprint(b.pack(), b.pack(1,2,3), saved(5,6,7,head=9,flag=10,tail=11))\n', 'callback-operand-order': "events=[]\ndef value(label,result):\n    events.append(label)\n    return result\ndef f(first,*,last):\n    events.append('body')\n    return first,last\nprint(value('receiver', f)(value('positional',1),last=value('keyword',2)))\nprint(events)\n", 'prepared-format-operand-offset': "text='{0}:{first}:{second}:{0}'\nprint(text.format(5,second='état',first='🍎'))\nprint((text.format)(7, first='a', second='b'))\nprint('{}-{}'.format('a','b'))\n", 'expanded-shape-parity': "events=[]\ndef trace(name,value):\n    events.append(name)\n    return value\ndef f(*args,**kw):return args,kw\nprint(f(1,n=trace('named',2),*trace('star',[3]),**trace('mapping',{'r':4})))\nprint(events)\n", 'ordinary-protocol-fallback': "events=[]\nclass Target:\n    def __call__(self,*args,**kwargs):\n        events.append('call')\n        return args,kwargs\nclass HasTarget:\n    @property\n    def target(self):\n        events.append('lookup')\n        return Target()\nprint(HasTarget().target(1,2))\nprint(HasTarget().target(3,label=4))\nprint(events)\n", 'argument-effects-before-failure': "events=[]\ndef arg(name):events.append(name);return name\ndef f(a, /, *, b):return a,b\nfor call in [lambda:f(arg('pos'),b=arg('keyword'),extra=arg('extra')),lambda:f(arg('pos'),a=arg('invalid'),b=arg('valid'))]:\n    try:call()\n    except TypeError:events.append('error')\nprint(events)\n", 'default-replacement-during-operands': "def f(a,*,b):\n    return a,b\nf.__kwdefaults__={'b':1}\ndef replace():\n    f.__kwdefaults__={'b':2}\n    return 5\nprint(f(replace()))\nprint(f(6,b=7))\n"}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'format-continuation-scratch/probe/candidate'
pair=load(lab/'frozen-identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
(lab/'probe-cases.json').write_bytes(body)
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
