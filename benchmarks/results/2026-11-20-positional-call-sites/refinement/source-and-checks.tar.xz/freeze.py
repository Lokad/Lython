from pathlib import Path
import hashlib,json,shutil,subprocess
lab=Path(__file__).resolve().parent
first=lab.with_name('positional-call-sites')
trial=Path('.git/agent-worktrees/positional-call-sites')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(trial),*args],encoding='utf-8').strip()
assert not git('status','--porcelain')
pair=json.loads((first/'frozen-identity.json').read_text(encoding='utf-8'))
pair['candidateCommit']=git('rev-parse','HEAD')
assert pair['candidateCommit'].startswith('e887f7e4b')
assert not git('diff','--name-only',pair['referenceCommit'],'master','--','src','tests')
shutil.copyfile(first/'catalog.json',lab/'catalog.json')
assert sha(lab/'catalog.json')==pair['casesSHA256']
with (lab/'measured-source.patch').open('wb') as stream:
    subprocess.run(['git','-C',trial,'diff','--binary',pair['referenceCommit'],'HEAD','--','src','tests'],stdout=stream,check=True)
for role,files in pair['images'].items():
    source=first/'frozen'/role
    assert len(files)==32 and all(sha(source/name)==h for name,h in files.items())
    target=lab/'frozen'/role
    shutil.copytree(source,target)
    if role=='candidate':
        core='Lokad.Lython.dll'
        shutil.copyfile(trial/'src/Lokad.Lython/bin/Release/net11.0'/core,target/core)
        files[core]=sha(target/core)
    assert all(sha(target/name)==h for name,h in files.items())
(lab/'frozen-identity.json').write_text(json.dumps(pair,indent=2)+'\n',encoding='utf-8',newline='\n')
