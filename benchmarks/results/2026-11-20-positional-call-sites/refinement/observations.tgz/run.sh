set -eu
root=/home/lokad/lython-bench-checks/positional-call-sites-refined-b1211-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
