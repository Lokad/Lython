from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('direct-operand-return-20261124')
previous=donor/'comparison/quiet'
output=lab/'confirmation'
output.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,text:path.write_text(text,encoding='utf-8',newline='\n')
save=lambda path,data:write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')
identity=read(previous/'identity.json')
archive=previous/'observations.tar.xz'
receipt=read(previous/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(archive)==receipt['archiveSHA256']
assert identity['sourcePatchSHA256']==sha(donor/'candidate.patch')
catalog=read(previous/'representative.json')
rules='scripts.rule-default-closures'
manifest='scripts.config-manifest.small'
catalog['cases']=[row for row in catalog['cases'] if row['id'] in (rules,manifest)]
assert len(catalog['cases'])==2
save(output/'representative.json',catalog)
save(output/'jobs.json',dict(warm=[[rules,'compile'],[rules,'warm'],[manifest,'compile'],[rules,'compile-run']]))
identity['catalogs']={name:dict(sha256=sha(output/name)) for name in ('representative.json','jobs.json')}
identity['purpose']='Isolate defaulted-rule compilation and execution on the same B1659 pair with a compiler control'
save(output/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,expected in identity['imageFiles'].items():
    image=donor/role
    assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
    proof=lab/f'{role}-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',output/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],env=env,cwd=repo,check=True,timeout=70)
    data=read(proof)
    assert data['state']=='Completed' and data['caseCount']==2 and data['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert data['launched']['library']['sha256']==expected['Lokad.Lython.dll']
shutil.copyfile(previous/'run.sh',output/'run.sh')
assert b'\r' not in (output/'run.sh').read_bytes()
collect=(previous/'collect.py').read_text(encoding='utf-8').replace('b1659-fixtures','b1660-fixtures').replace('len(jobs) == 6','len(jobs) == 4').replace('targetBatchSeconds=.52','targetBatchSeconds=.75')
compile(collect,'collect.py','exec')
write(output/'collect.py',collect)
launcher=(donor/'confirm.py').read_text(encoding='utf-8').replace("lab / 'comparison/quiet'","lab.parent / 'direct-operand-return-20261124/comparison/quiet'")
launcher=launcher.replace('lython-b1659-direct-operand-confirmation-20261124','lython-b1660-defaulted-rule-phase-split-20261125').replace('direct-operand-confirmation-b1659-20261124','defaulted-rule-phase-split-b1660-20261125').replace('seconds=166','seconds=202').replace('RuntimeMaxSec=235','RuntimeMaxSec=260')
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
report=(donor/'archive.py').read_text(encoding='utf-8').replace('lab/"comparison/quiet"','lab/"confirmation"').replace('2026-11-24-direct-operand-return','2026-11-25-defaulted-rule-phase-split').replace('receipt["warmJobs"]==6','receipt["warmJobs"]==4').replace('timedBatches=168,lanes=6','timedBatches=112,lanes=4')
compile(report,'archive.py','exec')
write(lab/'archive.py',report)
duplicates=[]
for loc,path in [('pair-owned-defaults-b1658-20261124',lab.with_name('pair-owned-defaults-20261124')/'comparison/quiet'),
                 ('direct-operand-return-b1659-20261124',previous)]:
    marker=read(path/'terminal-status.json')['receipt']
    assert marker['complete'] and marker['allWorkersJoined'] and sha(path/'observations.tar.xz')==marker['archiveSHA256']
    with tarfile.open(path/'observations.tar.xz') as saved:
        raw=saved.extractfile('confirmation/confirmation.json').read()
        duplicates.append(dict(location=loc,bytes=len(raw),archiveSHA256=marker['archiveSHA256'],rawSHA256=hashlib.sha256(raw).hexdigest()))
save(lab/'verified-raw-replicas.json',duplicates)