from pathlib import Path
import hashlib,json,re,shutil,tarfile
p=Path(__file__).parent;r=p/'b584'
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs']==18 and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
summary=json.loads((r/'summary.json').read_text(encoding='utf-8')); assert summary['complete']and summary['jobs']==18
with tarfile.open(r/'observations.tgz')as t:
 core=t.extractfile('current-core.dll').read();assert hashlib.sha256(core).hexdigest()==summary['coreSHA256']['candidate']
 raw=json.loads(t.extractfile('confirmation/confirmation.json').read());assert raw['complete']and len(raw['jobs'])==18
 for j in raw['jobs']:
  assert j['workersJoinedAndFixturesRemoved']
  for label,identity in j['identities'].items():
   if label.startswith('candidate'):
    h=next(v['sha256']for v in identity['libraries']if Path(v['path']).name=='Lokad.Lython.dll')
    assert h.lower()==summary['coreSHA256']['candidate']
out=Path('benchmarks/results/2026-11-11-captured-helper-cpython-checkpoint');out.mkdir(exist_ok=False)
guide=Path('docs/BENCHMARKS.md');(out/'prior-BENCHMARKS.md').write_bytes(guide.read_bytes())
for name in ['summary.json','identity.json','source-identity.json','archive-receipt.json','observations.tgz','terminal-status.json','inventory.json','config.json','observe-not-before.json','launch.log']:
 shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for f in [*r.glob('*.py'),r/'run.sh',p/'prepare-cpython-checkpoint.py',p/'record-cpython-checkpoint.py']:t.add(f,arcname=f.name)
mapping={'scripts.text-summary-helpers.nonlocal-counter.large':'Text / captured helper + counter','scripts.text-summary-helpers.large':'Text summary/helpers','scripts.csv-validated-records.large':'CSV validation/helper calls','scripts.json-summary-helpers.large':'JSON-lines/helpers','scripts.report-render.large':'JSON-to-Markdown report','scripts.file-search.large':'File search / keyword-default helper'}
rows={(mapping[j['case']],j['lane']):j for j in summary['timing']}
def times(v):
 multiplier,unit,digits=(1,'ms',3)if max(v)>=.5 else(1000,'µs',2)
 return f'{min(v)*multiplier:.{digits}f}–{max(v)*multiplier:.{digits}f} {unit}'
text=guide.read_text(encoding='utf-8');lane='compile-run';count=0;lines=[]
for line in text.splitlines():
 if line=='## Warm execution, compilation and startup':lane='warm'
 if line.startswith('Compilation alone includes'):lane='compile'
 fields=line.split('|')
 if len(fields)>=7 and fields[1].strip()in mapping.values():
  row=rows[(fields[1].strip(),lane)]
  start=3 if lane=='compile-run' else 2
  fields[start]=' '+times(row['timeRangeMilliseconds'])+' '
  fields[start+1]=' '+times(row['pythonTimeRangeMilliseconds'])+' '
  fields[start+2]=f" {min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}× "
  fields[start+3]=' `6904093e` '
  fields[start+4]=f" {row['status']}; L{row['controlPercent']:.2f}%, P{row['pythonControlPercent']:.2f}% / {max(row['iqrPercent'].values()):.2f}% "
  line='|'.join(fields);count+=1
 lines.append(line)
assert count==18,count
text='\n'.join(lines)+'\n'
start=text.index('**Measured sources:**');end=text.index('The captured-helper variant',start)
text=text[:start]+'''**Measured current source:** retained `6904093e`, 2026-11-11, frozen refined
core `ccdd645d` with precommit metadata. All production source hashes match.
The six refreshed scripts use stock CPython 3.13.16 on the same VM; exact-source
full delivery qualification is recorded in the linked checkpoint. Earlier rows remain
historical: `4aa` = qualified `4aa2d46d` (patch, 2026-11-11), `ee44` = `ee448715`
(config/original search, 2026-11-10), `6f76` = `6f76f99d` (CSV summary, 2026-11-08),
`4598` = `459813a3` (manifest, 2026-11-09). They do not describe current HEAD.

The [six-script checkpoint](../benchmarks/results/2026-11-11-captured-helper-cpython-checkpoint/README.md)
refreshes compilation, warm execution and compile-to-result using the existing
workers/protocol and unchanged sources/fixtures. All loaded hashes, output,
ownership, quiet, join and archive gates pass. Its
[prior guide](../benchmarks/results/2026-11-11-captured-helper-cpython-checkpoint/prior-BENCHMARKS.md)
preserves every replaced source-labelled measurement, including the earlier
`fe6648b2` CSV/text and `e122` JSON/report checkpoints. Separate checkpoints cannot
attribute differences to a single change.

''' +text[end:]
start=text.index('Actual .NET 11 RC3');end=text.index('Identical scripts and fixtures',start)
text=text[:start]+'''Actual .NET 11 RC3 and isolated CPython 3.13.16 use ordinary GC/tiering;
five-second warmups per role/job and seven rotated 150 ms rounds. Six current
scripts use core `ccdd645d` (retained `6904093e` production sources), fixed common
worker `fec79afd` and optional adapter 0.4. Other rows keep their recorded images.
These source-labelled observations do not qualify a newer regex producer.

''' +text[end:]
start=text.index('The current CSV/text checkpoint measures');end=text.index('Original literal-prefix search and config',start)
parts=[]
for key in mapping.values():
 w=rows[(key,'warm')];c=rows[(key,'compile-run')]
 parts.append(f"{key}: warm {min(w['ratioRange']):.2f}–{max(w['ratioRange']):.2f}×; compile-to-result {min(c['ratioRange']):.2f}–{max(c['ratioRange']):.2f}×.")
text=text[:start]+'The current six-script checkpoint retains these ratios and their stability:\n\n'+'\n'.join('- '+s for s in parts)+'''\n\nControls and IQRs in the tables limit precision; neither a diagnostic label nor
allocation reduction establishes universal CPU improvement or unchanged-script
neutrality. The captured variant remains a distinct script with an observable
nonlocal counter. Compilation and warm medians are independent. Earlier adverse
source-pair results and unresolved regression debt remain in the linked evidence.

'''+text[end:]
guide.write_text(text,encoding='utf-8')
files={f.relative_to(out).as_posix():dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in out.rglob('*')if f.is_file()}
(out/'archive-identity.json').write_text(json.dumps(dict(files=files,all18LoadedIdentitiesVerified=True,allUsersJoined=True,allArchivesVerified=True),indent=2)+'\n',encoding='utf-8')
print('Six-script guide refreshed, prior guide/raw18jobs/source/core identities preserved. Add concise evidence README and current delivery status before commit.')
