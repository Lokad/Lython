from pathlib import Path
import ast,hashlib,io,json,re,shutil,subprocess,tarfile
parent=Path(__file__).parent; r=parent/'b584'; r.mkdir(exist_ok=True)
assert not(r/'config.json').exists()
old=parent.parent/'native-counter-loops-r237/b577'
name='captured-checkpoint-b584-20261111';unit='lython-b584-captured-checkpoint-20261111'
replace=lambda s:s.replace('native-loops-cpython-b577-20261111',name).replace('lython-b577-native-loops-cpython-20261111',unit).replace('lython-b577-fixtures','lython-b584-fixtures')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
core='ccdd645dc6d2a541dbea0aaf170e33381666563d2579cd6f596fbebce427aeaa'
source=json.loads((parent/'refined/b583/source-identity.json').read_text(encoding='utf-8'))
for path,h in source['sourceSHA256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
source.update(retainedRevision='6904093e',prototypeUncommitted=False,documentationRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
(r/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
identity.update(sourceRevision='Retained6904093e, exact frozen refined R243 production sources. Measured core ccdd with precommit metadata, all source hashes verified. 4742focused actual11/10 checks and ten Python goldens pass; full43058223560 separately pending. Six unchanged complete scripts versus stockCPython3.13.16; no attribution to one optimization.',coreSHA256={'candidate':core,'candidate-control':core})
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'))
searchCatalog=json.loads((parent.parent/'dictionary-cpython-r191/b539/representative.json').read_text(encoding='utf-8'))
for c in searchCatalog['cases']:
 if c['id']not in {x['id']for x in catalog['cases']}:catalog['cases'].append(c)
ids=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.text-summary-helpers.large','scripts.csv-validated-records.large','scripts.json-summary-helpers.large','scripts.report-render.large','scripts.file-search.large']
byid={c['id']:c for c in catalog['cases']}
missing=[c for c in ids if c not in byid]
if missing:
 print('Missing intended case IDs:',missing,'available:',list(byid))
 raise SystemExit(2)
(r/'representative.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
identity['catalogSHA256']=hashlib.sha256((r/'representative.json').read_bytes()).hexdigest()
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[[c,lane]for c in ids for lane in ['compile','warm','compile-run']]
collect=replace((old/'collect.py').read_text(encoding='utf-8'))
collect=re.sub(r'jobs=\[.*?\]\nassert len\(jobs\)==9',lambda _: 'jobs='+repr(jobs)+'\nassert len(jobs)==18',collect,count=1)
collect=collect.replace("'R237 retainedfe6648b2 versus stockCPython3.13.16, two unchanged text scripts and original CSV validation.","'R243 retained6904093e versus stockCPython3.13.16, six unchanged representative scripts.")
collect=collect.replace("< 290, 'Reserve40seconds", "< 520, 'Reserve50seconds")
(r/'collect.py').write_text(collect,encoding='utf-8',newline='\n');ast.parse(collect)
archive=replace((old/'archive-owned.py').read_text(encoding='utf-8')).replace("==9","==18").replace('jobs=9','jobs=18')
(r/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(r/'run.sh').write_text(replace((old/'run.sh').read_text(encoding='utf-8')),encoding='utf-8',newline='\n')
remote=replace((old/'remote-launch.py').read_text(encoding='utf-8')).replace("native-counter-loops-b576-20261111/candidate","captured-sequence-b583-20261111/candidate")
remote=remote.replace('jobs=9','jobs=18').replace('ownerSeconds=330','ownerSeconds=570').replace('RuntimeMaxSec=330','RuntimeMaxSec=570')
remote=remote.replace("canonicalStorage='Pre-existing independently verified persistent local source.tar; exact path/bytes/SHA recorded in files'","canonicalStorage='Exact canonical Git evidence independently verified locally before launch; exact path/bytes/SHA recorded in files'")
(r/'remote-launch.py').write_text(remote,encoding='utf-8',newline='\n')
for name2 in ['launch.py','retrieve.py','summarize.py']:
 t=replace((old/name2).read_text(encoding='utf-8')).replace('B577','B584').replace('nine-job','eighteen-job')
 t=t.replace('==9','==18').replace('len(external)==9','len(external)==18').replace('<330','<570').replace('seconds=390','seconds=630').replace('ownerSeconds=330','ownerSeconds=570').replace('native-loops-cpython-b577-launch.py','captured-checkpoint-b584-launch.py')
 (r/name2).write_text(t,encoding='utf-8',newline='\n');ast.parse(t)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','source-identity.json','representative.json']:t.add(r/n,arcname=n)
(r/'payload.tgz').write_bytes(buf.getvalue())
retire=[]
for remoteName,canonical in [('mirrored-storage-b581-20261111/observations.tgz','benchmarks/results/2026-11-11-mirrored-function-storage/quiet/observations.tgz'),('captured-sequence-b583-20261111/observations.tgz','benchmarks/results/2026-11-11-native-closure-sequences/quiet/observations.tgz')]:
 data=Path(canonical).read_bytes();gitdata=subprocess.run(['git','show','HEAD:'+canonical],capture_output=True,check=True).stdout
 assert data==gitdata
 retire.append(dict(kind='exact',knownPath=remoteName,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalStorage=canonical,canonicalCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reason='Terminal historical raw archive duplicate, exact canonical committed Git bytes verified; retain core roles and every original observation. Fresh absolute path/UID/inode/all-alias proof before retirement.'))
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),requiredFreeBytes=252*1024*1024+(r/'payload.tgz').stat().st_size+1024*1024,retire=retire,identity=identity)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print('Prepared18jobs; no new worker/framework; exact retained source/core/canonical Git archive gates. Next: fresh inventory, inspect, then launch.')
