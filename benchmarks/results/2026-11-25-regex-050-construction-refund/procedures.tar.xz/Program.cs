using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;
using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;

var cases = new (string Name, string Expression, string Input)[]
{
    ("literal", "ERROR", "ERROR ERROR"),
    ("named-log", "(?P<level>ERROR|WARN) (?P<id>\\d{1,5})", "ERROR 123 WARN 42"),
    ("unicode", "(?P<word>\\w+)(?=:)", "éclair: ŕ: 東京:"),
    ("wide-captures", string.Concat(Enumerable.Repeat("(ab)", 64)), string.Concat(Enumerable.Repeat("ab", 128))),
};
var rows = new List<object>();
foreach (var (name, expression, input) in cases)
{
    var bytes = Encoding.UTF8.GetBytes(expression);
    var subject = Encoding.UTF8.GetBytes(input);
    var program = new TraceAllowance();
    var working = new TraceAllowance();
    ulong directProgram, directCursorBefore, directAfterFirst, directFirstRetained;
    using (var pattern = Utf8PythonRegex.Compile(bytes, PythonReCompileOptions.None,
        new Utf8RegexPolicy { ProgramMemoryAllowance = program }))
    {
        directProgram = program.Live;
        using var cursor = pattern.CreateMatchCursor(subject, 0, default, working);
        directCursorBefore = working.Live;
        {
            if (!cursor.MoveNextRetained(out var match, default)) throw new InvalidOperationException(name);
            using (match) directFirstRetained = working.Live;
        }
        directAfterFirst = working.Live;
    }
    if (program.Live != 0 || working.Live != 0) throw new InvalidOperationException("Producer owner did not return to baseline");
    var retained = new LythonMemoryBudget();
    var work = new LythonMemoryBudget();
    long adapterProgram, adapterBefore, adapterAfterFirst, adapterAfterEnd;
    int captureSlots;
    using (var pattern = Utf8RegexProvider.Instance.Compile(bytes, new(32, false), retained, default))
    {
        adapterProgram = retained.ReservedBytes;
        captureSlots = pattern.CaptureSlotCount;
        int scalarLength = input.EnumerateRunes().Count();
        using var prepared = pattern.Prepare(subject, new(0, scalarLength, 0, subject.Length), work, default);
        using var cursor = prepared.Find(default);
        adapterBefore = work.ReservedBytes;
        var captures = new LythonRegexCapture?[pattern.CaptureSlotCount];
        if (!cursor.TryNext(captures, out _, default)) throw new InvalidOperationException(name);
        adapterAfterFirst = work.ReservedBytes;
        while (cursor.TryNext(captures, out _, default)) { }
        adapterAfterEnd = work.ReservedBytes;
    }
    if (retained.ReservedBytes != 0 || work.ReservedBytes != 0) throw new InvalidOperationException("Bridge owner did not return to baseline");
    rows.Add(new { name, directProgram, producerProgramPeak = program.Peak,
        wrapperEstimate = checked(256L + 64L * captureSlots + bytes.Length),
        adapterProgram, directCursorBefore, directAfterFirst, directFirstRetained, producerCursorPeak = working.Peak,
        adapterBefore, adapterAfterFirst, adapterAfterEnd });
}
Console.WriteLine(JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));

sealed class TraceAllowance : IUtf8MemoryAllowance
{
    public ulong Live { get; private set; }
    public ulong Peak { get; private set; }
    public bool TryReserve(ulong bytes)
    {
        Live = checked(Live + bytes);
        Peak = Math.Max(Live, Peak);
        return true;
    }
    public void Release(ulong bytes) => Live = checked(Live - bytes);
}
