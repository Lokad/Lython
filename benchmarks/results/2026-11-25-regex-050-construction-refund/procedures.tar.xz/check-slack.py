from pathlib import Path
import hashlib, json, shutil, subprocess
lab=Path(__file__).resolve().parent
baseline=lab.with_name('regex-050-funded-20261125')/'windows/bin/Lokad.Lython.PublicApi.Tests/release_net11.0'
trim=lab/'windows/bin/Lokad.Lython.PublicApi.Tests/release_net11.0'
identity=json.loads((lab.with_name('regex-050-funded-allocation-20261125')/'comparison/quiet/identity.json').read_text(encoding='utf-8'))
names=['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in names[1:]: assert sha(baseline/n)==identity['images']['candidate'][n]
for n in names[2:]: assert sha(baseline/n)==sha(trim/n)
proof={}
for label,adapter in (('original',baseline),('trimmed',trim)):
    out=lab/('frozen-'+label);out.mkdir(exist_ok=True)
    exe=lab/'probe-original/bin/Slack/release_net11.0'
    for n in ('Slack.dll','Slack.deps.json','Slack.runtimeconfig.json'):shutil.copyfile(exe/n,out/n)
    for n in names:shutil.copyfile((adapter if n=='Lokad.Lython.Utf8Regex.dll' else baseline)/n,out/n)
    proof[label]={p.name:sha(p) for p in sorted(out.iterdir())}
    assert proof[label]['Lokad.Lython.Utf8Regex.dll']==sha(adapter/'Lokad.Lython.Utf8Regex.dll')
    with (lab/(label+'-unverified.json')).open('wb') as f:
        p=lab/(label+'.json')
        if p.exists():f.write(p.read_bytes())
    data=subprocess.check_output([Path.home()/'.dotnet11/dotnet.exe',out/'Slack.dll'],cwd=out,timeout=20)
    (lab/(label+'.json')).write_bytes(data)
    assert proof[label]=={p.name:sha(p) for p in sorted(out.iterdir())}
assert {n for n in proof['original'] if proof['original'][n]!=proof['trimmed'][n]}=={'Lokad.Lython.Utf8Regex.dll'}
(lab/'image-files.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
a,b=(json.loads((lab/(n+'.json')).read_text(encoding='utf-8-sig')) for n in ('original','trimmed'))
for old,new in zip(a,b,strict=True):
    assert old['adapterProgram']==old['producerProgramPeak']+old['wrapperEstimate']
    assert new['adapterProgram']==new['directProgram']+new['wrapperEstimate']
    assert {k:v for k,v in old.items() if k!='adapterProgram'}=={k:v for k,v in new.items() if k!='adapterProgram'}
    print(old['name'],old['adapterProgram'],new['adapterProgram'],new['adapterAfterFirst'],new['adapterAfterEnd'])
