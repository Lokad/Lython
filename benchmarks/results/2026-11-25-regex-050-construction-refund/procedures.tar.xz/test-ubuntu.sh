#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-050-owner-slack-20261125
previous=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-050-range-adapter-20261122
export NUGET_PACKAGES="${lab%/*}/regex-050-funded-20261125/nuget-linux"
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-050-funded-20261125
dotnet restore tests/Lokad.Lython.PublicApi.Tests --artifacts-path "$lab/ubuntu" --configfile "$previous/NuGet.Ubuntu.Config" > "$lab/ubuntu-restore.log" 2>&1 || {
    tail -24 "$lab/ubuntu-restore.log"
    exit 1
}
filter='(FullyQualifiedName~RegexScalarCursorTests|FullyQualifiedName~RegexAdapterLifetimeTests|FullyQualifiedName~RegexFlagProtocolTests|FullyQualifiedName~RegexProviderContractTests)&Category!=Stress'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-restore --artifacts-path "$lab/ubuntu" --filter "$filter" 2>&1 | tee "$lab/ubuntu-net10.log"
