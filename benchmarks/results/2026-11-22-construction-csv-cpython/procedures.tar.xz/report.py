from pathlib import Path
import json


out = Path("benchmarks/results/2026-11-22-construction-csv-cpython")
summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
names = {
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword": "Mixed literal-default factory",
    "scripts.csv-invoice.large": "Ordinary CSV invoice",
    "scripts.csv-invoice.method-policy.quoted-control": "Quoted policy invoice",
}
boundaries = {"warm": "Warm", "compile": "Compilation", "compile-run": "Compile to result"}


def extent(values, digits):
    first, last = (f"{value:.{digits}f}" for value in values)
    return first if first == last else f"{first}–{last}"


rows = [
    "| Complete script | Boundary | Lython | CPython | Lython / CPython | Controls L/C | Maximum IQR |",
    "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    digits = {"compile": 5, "warm": 4, "compile-run": 3}[row["lane"]]
    controls = f"{row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.3f}%"
    rows.append(f"| {names[row['case']]} | {boundaries[row['lane']]} | "
                f"{extent(row['lythonMs'], digits)} ms | {extent(row['cpythonMs'], digits)} ms | "
                f"{extent(row['ratio'], 3)}× | {controls} | {row['maxIQRPercent']:.2f}% |")
report = f"""# B1356 Current factory and CSV invoices against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu
24.04.4 and .NET 11 RC3. The frozen Lython image was built from
`{summary['source'][:9]}`. The external baseline is stock
CPython 3.13.16. The mixed factory creates 4,096 functions for 2,048
inputs and uses no files. The invoices read 4,096 records and produce
155 output bytes from 127,031 and 174,147 input bytes respectively.

"""
report += "\n".join(rows)
report += f"""

Ratios divide Lython elapsed by CPython elapsed and span all pairings
of two process medians per engine. Above one means Lython takes longer.
Two workers per engine and phase warmed for at least eight seconds
and supplied seven rotated timed batches each. Controls show the spread
of the two process medians for each engine.

Warm execution includes mediated RAM-backed input and output, captured
stdout, golden verification and prior-result disposal.
Compile-only timing includes code-owner cleanup. Time to result covers
both compilation and execution with their cleanup. Process startup and
final teardown have separate boundaries.

All 140 timed batches and both quiet gates passed in
{summary['elapsedSeconds']:.0f} seconds. Stdout and output files matched their CPython goldens. The 32-file Lython image and both CPython worker identities
verified. Every worker joined and the persistent archive was checked
before releasing the VM lease.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Previous CPython checkpoint](../2026-11-22-post-range-cpython/README.md) ·
[Capture-construction source pair](../2026-11-22-native-single-capture-construction/README.md) ·
[ASCII parsing source pair](../2026-11-22-complete-decimal-ascii/README.md) ·
[Earlier JSON checkpoint](../2026-11-21-cpython-expanded-builtin/README.md) ·
[Image verification and procedures](procedures.tar.xz).
"""
(out / "README.md").write_text(report, encoding="utf-8", newline="\n")
