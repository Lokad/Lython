from base64 import b64decode, b64encode
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
template = notes / 'current-json-construction-profile-20261126'
donor_lab = notes / 'csv-dictwriter-native-validation-20261127'
donor = donor_lab / 'comparison/quiet-cpython'
donor_name = 'csv-dictwriter-cpython-b1869-20261127'
unit = 'lython-b1871-current-json-read-export-profile-20261127'
root_name = 'current-json-read-export-profile-b1871-20261127'
python = Path('C:/Python313/python.exe')
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: sha256(p.read_bytes()).hexdigest()
write = lambda p, contents: p.write_text(contents, encoding='utf-8', newline='\n')
save = lambda p, value: write(p, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
measured = subprocess.check_output(['git','rev-parse','6e59cd41e'],cwd=repo,text=True).strip()
changed = subprocess.check_output(['git','diff','--name-only',measured,head,'--','src','benchmarks/scripts'],cwd=repo,text=True).splitlines()
assert changed == ['src/Lokad.Lython/Runtime/LythonRuntime.CsvDictWriter.cs']
assert not subprocess.check_output(['git','status','--porcelain','--','src','benchmarks/scripts'],cwd=repo)
donor_id = read(donor / 'identity.json')
receipt = read(donor / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert sha(donor / 'observations.tar.xz') == receipt['archiveSHA256']
patch = subprocess.check_output(['git','diff','--binary',donor_id['sourceRevision'],measured,'--','src'],cwd=repo)
assert sha256(patch).hexdigest() == donor_id['sourcePatchSHA256']
files = donor_id['imageFiles']['candidate']
image = donor_lab / 'comparison/local/candidate'
assert len(files) == 32 and {p.name:sha(p) for p in image.iterdir()} == files

read_catalog = read(notes / 'post-ready-insertion-cpython-20261127/comparison/quiet/representative.json')
read_case = next(case for case in read_catalog['cases'] if case['id'] == 'diagnostic.nested-json-document')
export_catalog = read(notes / 'json-traversal-20261124/comparison/representative.json')
export_case = dict(next(case for case in export_catalog['cases'] if case['id'] == 'scripts.json-lines-shipment.default-options.large'))
fixture = json.loads(export_case['fixtureJson'])
records = json.loads(b64decode(fixture['inputFiles']['records.json']))[:768]
input_bytes = json.dumps(records, ensure_ascii=False, separators=(',',':')).encode('utf-8')
with tempfile.TemporaryDirectory(prefix='lython-b1871-goldens-') as location:
    path = Path(location)
    (path / 'records.json').write_bytes(input_bytes)
    (path / 'export.py').write_bytes(export_case['source'].encode('utf-8'))
    output = subprocess.check_output([python,'-I','-X','utf8',path/'export.py'], cwd=path, timeout=15).decode('utf-8').replace('\r\n','\n')
    file = (path / 'shipments.jsonl').read_bytes()
    assert (path / 'records.json').read_bytes() == input_bytes
    assert sorted(p.name for p in path.iterdir()) == ['export.py','records.json','shipments.jsonl']
assert len(file.splitlines()) == len(records) == 768
worker = donor_lab / 'comparison/local/cpython-worker.py'
assert sha(worker) == donor_id['cpythonWorkerSHA256']
spec = importlib.util.spec_from_file_location('protocol',worker)
protocol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
fixture.update(size=len(records),inputFiles={'records.json':b64encode(input_bytes).decode('ascii')},
    outputFiles={'shipments.jsonl':b64encode(file).decode('ascii')})
fixture_text = json.dumps(fixture,separators=(',',':'))
export_case.update(id='diagnostic.json-lines-shipment.default-export-768',size=len(records),fixtureJson=fixture_text,
    fixtureSha256=sha256(fixture_text.encode()).hexdigest(), expectedOutput=output,
    expectedOutputUtf8Bytes=len(output.encode()),expectedOutputSha256=sha256(output.encode()).hexdigest(),
    expectedFilesSha256=protocol.file_digest({'shipments.jsonl':file}))
read_catalog['cases'] = [read_case,export_case]
save(quiet/'catalog.json',read_catalog)
profiles = [['nested-json-document',read_case['id'],'candidate'],['default-json-export-async',export_case['id'],'candidate']]
identity = dict(sourceRevision=measured,inspectedHead=head,sourceDifference=changed,imageFiles={'candidate':files},
    coreSHA256={'candidate':files['Lokad.Lython.dll']},donorArchiveSHA256=receipt['archiveSHA256'],
    profileCatalogSHA256=sha(quiet/'catalog.json'),profiles=profiles,
    purpose='Locate JSON construction and export costs in complete, verified workloads.',
    exportRecords=len(records),exportInputBytes=len(input_bytes),exportOutputBytes=len(file))
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','run.sh','analyze.py'):
    source=(template/'comparison/quiet'/name).read_text(encoding='utf-8')
    if name=='collect.py':
        assert source.count('native-segments-at-emission-b1800-20261126')==2
        source=source.replace('native-segments-at-emission-b1800-20261126',donor_name).replace('b1801-fixtures','b1871-fixtures')
    if name.endswith('.py'): compile(source,name,'exec')
    write(quiet/name,source)
assert b'\r' not in (quiet/'run.sh').read_bytes()
source=(template/'quiet.py').read_text(encoding='utf-8')
source=source.replace('native-segments-at-emission-b1800-20261126',donor_name)
source=source.replace('lython-b1801-current-json-construction-profile-20261126',unit)
compile(source,'quiet.py','exec')
write(lab/'quiet.py',source)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
proof=quiet/'verification.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
    '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',proof],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
report=read(proof)
assert report['state']=='Completed' and report['caseCount']==2
assert report['catalogSha256']==identity['profileCatalogSHA256'] and report['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root_name,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expectedDonorArchiveSHA256=receipt['archiveSHA256']))
print(repr(output),len(input_bytes),len(file),payload.stat().st_size)
