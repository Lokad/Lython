# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication and tagging
remain postponed. Objective: coherent simplification and substantial complete-script
performance. Finishing an isolated experiment does not complete that objective.
Current contracts belong in docs; [experimental history](benchmarks/EXPERIMENTS.md)
and immutable results retain old variants, failed conditions and adverse evidence.

## Actual delivery status

- **Fully qualified:** shared compiler-fact correction and earlier UTF-8/native-return
  work; R119–R121 lookup facts (runtime6f76/coreC617 + fixture d97), R125 pending
  text-read funding/awaited cleanup (3109/core004e), R126 obsolete liveness fences
  (9f2e/core85e), R127 shared declaration metadata (847/coreac6b), R129 literal
  construction (459/core1be2). Cached Windows/Ubuntu, actual .NET11/10, original
  stress both and installed-core consumers pass. Do not repeat unchanged qualification.
- **Committed, full qualification pending:** R132 c343687b/core95fc removes consumed
  native read nodes and shares ordinary operand sources/fixed local-prefix facts.
  Every real variant passed 87 internal/394 public focused checks per framework.
  CI42552506089: both platforms' full11/10 and installed-package checks pass;
  stress is running. Last observed03:12:19UTC; next >=03:17:19UTC. Cache terminal.
  [Evidence](benchmarks/results/2026-11-09-native-inputs/README.md).
- **R133 retained candidate, ready to commit:** canonical ordinary static-call syntax
  partition; inferred values and expansions remain binding-state-dependent. Removes
  repeated positional/keyword/value-container construction, adds no runtime binder,
  owner or public API. Frozen36fd versus c343/core95fc; 47 internal/206 public checks
  per actual framework pass, including3 new binding-state cases. Compilation allocation
  falls2.59–4.14%; no general CPU gain established. Seven quiet jobs196.114s, all
  identity/golden/ownership/quiet/join/RAM/archive/local-SHA gates pass. Completeconfig
  remains inconclusive with candidate spread3.34% and wider processCPU+3.17–5.14%
  possible debt. Original desktop configcompile+15.74–17.70% remains preserved,
  without consistent reproduction on VM. Full delivery batches at a coherent boundary.
  [Evidence](benchmarks/results/2026-11-09-static-call-shape/README.md).
- **Held prototypes:** R124 prepared named maps added a registry/guard while general
  binding remained; no stable whole-script CPU benefit, compilation allocation rose.
  Production was freshly restored; useful semantic/lifetime regressions survive.
  Slower arena/call-control and shared-string-window designs remain evidence, not
  permanent design bans. No unchanged replays selected.

## What the measurements establish

[Maintained CPython comparison](docs/BENCHMARKS.md) labels every row by measured
source (6f76 or459), not today's HEAD. Compilation, warm execution and compile-to-result
are separate. The latest small config/search/two-file manifest complete ratios are
1.09–1.10x(variable),1.40–1.41x,1.47–1.48x versus CPython3.13.16. Earlier main-five
rows remain accurately historical. Included: mediated RAM-file I/O, full validation,
prior-result cleanup. Excluded: startup, fixture reset/protocol and final cache teardown.
Wider processCPU has a different boundary. Large-tree throughput/embedding tails/RSS
remain unmeasured. Refresh at a meaningful checkpoint, not after each source edit.

Native helper-return allocation reductions19.92/19.31% are established independently
of their original diagnostic elapsed gains. Formatting allocation falls8.67%; controlled
B102 elapsed/CPU supports retention. The original adverse15.125ms remains unexplained
and preserved. R132 improves bounded syncsearch elapsed2.45–3.40% with close controls,
but textCPU and other control spreads remain debt; no universal gain/neutrality claim.

R128 compilation attribution shows parsing26–43%, abstract analysis19–29%, executable
construction~19%, lexical7–8%, lowering2–4%. These include useful work. R131 config/search
separates caller/reset/protocol/tiering; builtin setup is not dominant. No runtime
compilation phase or missing buffering layer was observed. Ordinary calls already
borrow operands into final locals and use the linear runner/lazy promotion. Current
CSV adopts rows and shares key layouts; the old6–8% copying premise is gone. Do not
rebuild already-removed phases from inclusive sample counts.

## Prioritized deliverables

1. **Close the current delivery and commit R133.** Observe only live42552506089 at
   >=5min intervals, cache terminal, verify remaining stress outcomes. Never query
   cached terminal runs. Keep working meanwhile. Commit current code/tests/evidence;
   batch its full platform/stress/package qualification with the next coherent
   source milestone. Preserve all allocation/elapsed/CPU distinctions and regression
   debt. No unchanged full local suite or CPython replay.

2. **R134: select the next substantial runtime redesign from current allocation
   attribution.** Existing CPU profiles do not isolate boxed-value traffic from
   useful work; older allocation profiles precede native-return, bulk storage and
   frame changes or use different scripts. Reuse the existing D36 allocation-tick
   collector, comparison worker/catalog/goldens on current36fd for text helpers and
   validatedCSV. One bounded local collection (120s outer ownership, two scripts,
   finite checked warmup/capture, no elapsed claim), zero lost events, postverification,
   joined collector/worker and removed fixtures. Preserve every thread/raw tick;
   distinguish guest-specific types from reset/protocol buffers. Sampling assigns an
   allocation interval to its threshold-crossing type: not exact type bytes or CPU
   attribution. No forced GC, rundown, heap/root tracing or new benchmark framework.
   Then a~20min source gate must identify a complete construction/transport phase,
   affected scripts, work/storage eliminated and displaced implementation removed.
   Choose at most one coherent redesign; if no justified removal emerges, record
   uncertainty and move to independent work, not a speculative universal value/JIT/VM
   stack. Cheap scalar handling, complete call/frame construction and bulk text are
   hypotheses until this gate. Cancellation, first refusal, overflow/promotion,
   Python identity/protocols/order, retained aliases and cleanup are acceptance gates.
   Any intermediate performance setback needs an implementation-completion milestone
   and explicit remaining-debt decision. Separate compile/warm/I/O/cleanup/allocation;
   use bounded normal-GC/tiering source-pair comparisons and unchanged controls.

3. **Consolidate frontend/record/text construction where evidence supports it.**
   R133 completes static ordinary-call partition sharing. Source finds separate
   LoweredCallArgument wrappers and duplicated forms before executable metadata,
   but class headers/dynamic prepared definitions also use them; inspect those real
   consumers before replacement. Do not add a carrier/registry/binder for one shape.
   Current record adoption, native JSON layouts, final-buffer formatting/casing and
   governed I/O buffering stay. Retire displaced code when a selected design completes.
   Lexical walks needing complete parent bindings are not duplicates merely because
   they have multiple callers. No automatic promotion of historical bulkCSV work.

## Independent regex delivery

Core owns Python/nativeUTF-8 names, byte ranges/scalar positions/original windows,
effective flags/errors/replacements, current tokens, one frontend/runtime/import
provider and explicit owners. Core development and contract tests are independent
of producer publication; adapter-local bridges/pinned development producers are
allowed. Optional nonpackable adapter ordinary pin0.4; Dev55/d6067925 focused86internal/
514public per actual11/10 already pass. No unchanged replay or sibling edits/builds.
Selected final-package qualification still needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without
an earlier caller token. Only affected final adapter checks defer. Keep forwarding/
unwind, Python semantics and real-backend performance as separate evidence.

## Iteration and lasting constraints

A timeout, unstable unchanged control or inconclusive measurement establishes
uncertainty, not a failed design. Allow bounded confirmation/refinement/correction
when source-specific evidence warrants it. Percentages inform decisions, not vetoes.
Preserve original adverse/failed conditions; simplification, allocation reduction
and demonstrated CPU improvement are distinct outcomes. Focused Release checks
while developing; full platform/stress/installed-package checks at delivery boundaries.

AGENTS.md remains authoritative: fully managed safety and validated managed stack
admission; host mediation and current cancellation; coarse borrowed shared admission,
preflights/replacement overlap, funded aliases/results/caches/pending users and awaited
cleanup. Refusal is terminal. No unsafe/native probing, quotas/caps/hidden allowance,
heap tracing/weak reclaim/forcedGC, silent regex fallback or abandoned work. Keep
compilation estimates conservative; no tiny-budget precision or exact GC reachability.

No overlapping local build/test/timing. Fresh nonincremental builds after restored
snapshots, explicit UTF-8. Only core Release packages under artifacts/nuget; no publication.
VM lokad@20.166.121.73/key ~/.ssh/id_lython-bench.pem. ThroughB494 terminal/cached/local
verified, no users/fixtures; never requery. Evidence stays persistent, separate from
RAM fixtures; join/unmount/archive under lease/local SHA. Space recovery requires
fresh idle exact bytes/all inode aliases/SHA/permitted ownership/modes/writable parents
and a persisted pre-mutation plan. Preserve all historical paths and bytes; floors stay.
