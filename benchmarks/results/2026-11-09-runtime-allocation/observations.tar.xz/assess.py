from pathlib import Path
import collections,datetime,json
r=Path(__file__).parent;summary=[]
for label in ['text','csv']:
 folder=r/'allocation'/label;record=json.loads((folder/'record.json').read_text())
 begin=datetime.datetime.fromisoformat(record['captureBeginUtc']);end=datetime.datetime.fromisoformat(record['captureEndUtc'])
 ticks=[json.loads(line)for line in(folder/'allocation-ticks.jsonl').read_text().splitlines()]
 selected=[row for row in ticks if begin<=datetime.datetime.fromisoformat(row['utc'])<=end]
 counts=collections.Counter(row['type']or'[unnamed]'for row in selected)
 proxy=collections.Counter()
 for row in selected:proxy[row['type']or'[unnamed]']+=row['bytesSinceTick']
 rows=[dict(type=name,ticks=count,tickPercent=100*count/len(selected),allocationIntervalProxyBytes=proxy[name])for name,count in counts.most_common()]
 output=dict(label=label,capturedTicks=len(ticks),withinCaptureTicks=len(selected),eventsLost=record['collector']['eventsLost'],captureSeconds=(end-begin).total_seconds(),rows=rows)
 summary.append(output)
 print(label,'selected',len(selected),'of',len(ticks),'ticks; seconds',output['captureSeconds'])
 for row in rows[:12]:print(' ',round(row['tickPercent'],2),row['ticks'],row['type'])
limitations='Allocation-tick type association is sampled, not exact per-type bytes/object count or CPU causality. Interval proxy belongs to the interval ending at a sampled type, not exclusively that type. Complete batch includes reset, mediated disk I/O, full validation and prior result cleanup; startup/compile/warmup/final teardown excluded. Windows local diagnostic, normal GC/tiering; no comparison speed claim.'
(r/'assessment.json').write_text(json.dumps(dict(records=summary,limitations=limitations),indent=2)+'\n',encoding='utf-8')
