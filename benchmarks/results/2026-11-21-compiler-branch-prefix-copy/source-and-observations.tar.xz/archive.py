from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-21-compiler-branch-prefix-copy")
identity = json.loads((lab / "identity.json").read_text(encoding="utf-8"))
assert identity["candidate"].startswith("9c2b6e46d")
for role, manifest in identity["imageFiles"].items():
    image = lab / "workers" / role
    assert len(manifest) == 32 and {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in image.iterdir()} == manifest
    proof = json.loads((lab / f"{role}-verify.json").read_text(encoding="utf-8-sig"))
    assert proof["state"] == "Completed" and proof["caseCount"] == 3 and proof["catalogSha256"] == identity["catalogSHA256"]
rows = json.loads((lab / "micro-summary.json").read_text(encoding="utf-8"))
assert len(rows) == 8 and all("elapsedChangePercent" in row for row in rows)
for filename, start, end in (
    ("measured.patch", identity["reference"], identity["candidate"]),
    ("terminal-tail-correction.patch", identity["candidate"], "798c97274"),
):
    (lab / filename).write_bytes(subprocess.check_output(["git", "diff", start, end, "--", "src"]))
out.mkdir(exist_ok=True)
shutil.copyfile(lab / "README.md", out / "README.md")
shutil.copyfile(lab / "micro-summary.json", out / "summary.json")
artifact = (lab / "candidate/inspect/Lokad.Lython.dll").read_bytes()
compressed = gzip.compress(artifact, mtime=0)
assert hashlib.sha256(gzip.decompress(compressed)).hexdigest() == identity["imageFiles"]["candidate"]["Lokad.Lython.dll"]
(out / "candidate-core.dll.gz").write_bytes(compressed)
with tarfile.open(out / "source-and-observations.tar.xz", "w:xz", preset=6) as archive:
    for path in sorted(lab.iterdir()):
        if path.is_file() and not path.name.startswith("forwarding-cancellation-"):
            archive.add(path, arcname=path.name)
print("Archived all eight diagnostic lanes and the original and corrected source.")
