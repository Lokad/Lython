from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
history = lab.parent / "current-frontend-phases"
old_phase = lab.parent / "compiler-layout-phase-boundary"
candidate_build = lab.parents[3] / ".git/agent-worktrees/pinned-unicode-casing-20261121/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
reference_build = lab.parent / "joint-lexical-admission-on-current/frozen/reference/Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare_worker(role, name, source, core):
    target = lab / role / name
    target.mkdir(parents=True, exist_ok=True)
    for path in source.iterdir():
        if path.is_file():
            shutil.copyfile(path, target / path.name)
    shutil.copyfile(core, target / "Lokad.Lython.dll")
    assert sha(target / "Lokad.Lython.dll") == sha(core)
    return target

catalog = lab / "catalog.json"
shutil.copyfile(history / "catalog.json", catalog)
for role, core in (("reference", reference_build), ("candidate", candidate_build)):
    inspect = prepare_worker(role, "inspect", history / "inspect/bin/Release/net11.0", core)
    sample = prepare_worker(role, "compile", old_phase / "bulk-runner/bin/Release/net11.0", core)
    subprocess.run([dotnet, inspect / "Inspect.dll", catalog, lab / f"{role}-inspection.json"], env=env, check=True)

reference, candidate = [load(lab / f"{role}-inspection.json") for role in ("reference", "candidate")]
assert reference["rows"] == candidate["rows"]
assert reference["coreSHA256"] == sha(reference_build)
assert candidate["coreSHA256"] == sha(candidate_build)
print(f"Matched {sum(len(script['codes']) for script in reference['rows'])} code objects on {len(reference['rows'])} scripts.")
