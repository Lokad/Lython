from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.with_name('closed-capture-cpython-20261124')
source=(prior/'prepare.py').read_text(encoding='utf-8')
source=source.replace('closed-capture-pair-seeded-20261124','closed-line-helper-20261124')
source=source.replace('0400f185c','675900142')
source=source.replace('closed-capture-cpython-b1604-20261124','closed-line-helper-cpython-b1609-20261124')
source=source.replace('closed-capture-seeded-b1603-20261124','closed-line-helper-b1608-20261124')
source=source.replace("('scripts.captured-rule-closures', 'scripts.annotated-rule-closures.nested-factories.postponed')",
    "('diagnostic.text-summary.nonlocal-computed-width.large', 'scripts.rule-default-closures')")
source=source.replace('lython-b1604-closed-capture-cpython','lython-b1609-closed-line-helper-cpython')
source=source.replace('b1604-', 'b1609-')
source=source.replace('the delivered closed captured pair and postponed control','the delivered short report and defaulted rules')
start=source.index('archiver=(template/'); end=source.index("print('Prepared four",start)
source=source[:start]+"""archiver=(lab.with_name('closed-capture-cpython-20261124')/'archive.py').read_text(encoding='utf-8')
archiver=archiver.replace('2026-11-24-closed-capture-cpython','2026-11-24-closed-line-helper-cpython')
archiver=archiver.replace('0400f185c','675900142').replace('Archived B1604','Archived B1609')
archiver=archiver.replace(",'archive-before-case-check.py'",'')
compile(archiver,'archive.py','exec')
write(lab/'archive.py',archiver)
"""+source[end:]
compile(source,'prepare.py','exec')
(lab/'prepare.py').write_text(source,encoding='utf-8',newline='\n')