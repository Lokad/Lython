from pathlib import Path
import json
import os
import shutil
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('closed-line-helper-20261124')
work=lab/'default-owner'
work.mkdir(exist_ok=True)
source=work/'diagnostic-source'
source.mkdir(exist_ok=True)
archive=work/'diagnostic-source.zip'
comparison=work/'comparison'
comparison.mkdir(exist_ok=True)
identity=json.loads((donor/'comparison/identity.json').read_text(encoding='utf-8'))
subprocess.run(['git','archive','--format=zip','--output='+str(archive),identity['candidate'],
    'src/Lokad.Lython','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
    'Directory.Packages.props','NuGet.Config','global.json'],cwd=repo,check=True)
with zipfile.ZipFile(archive) as package:package.extractall(source)
changes={
    'PyTuple.cs':(
        '''        => count == 1 ? new SingletonDefault(governor, span, bytes)
            : new PyTuple(new LythonRuntime.ExecutableSlot[count], governor, span, bytes);''',
        '''    {
        if (count != 1) return new PyTuple(new LythonRuntime.ExecutableSlot[count], governor, span, bytes);
        var before = GC.GetAllocatedBytesForCurrentThread();
        var singleton = new SingletonDefault(governor, span, bytes);
        var delta = GC.GetAllocatedBytesForCurrentThread() - before;
        System.Console.Error.WriteLine("LYTHON_ROUTE singleton " + delta);
        return singleton;
    }'''),
    'Calls/FunctionBindingPlan.cs':(
        '''        value = name switch
        {
            "__defaults__" => PositionalDefaults ?? PyNone.Instance,''',
        '''        if (name == "__defaults__") System.Console.Error.WriteLine("LYTHON_ROUTE positional defaults read");
        value = name switch
        {
            "__defaults__" => PositionalDefaults ?? PyNone.Instance,'''),
}
for name,(before,after) in changes.items():
    path=source/'src/Lokad.Lython/Runtime'/name
    text=path.read_text(encoding='utf-8-sig')
    assert text.count(before)==1
    path.write_text(text.replace(before,after),encoding='utf-8',newline='\n')
shutil.copyfile(donor/'comparison/identity.json',comparison/'identity.json')
shutil.copyfile(donor/'comparison/representative.json',comparison/'representative.json')
candidate=work/'candidate'
candidate.mkdir(exist_ok=True)
for name in identity['imageFiles']['candidate']:shutil.copyfile(donor/'candidate'/name,candidate/name)
routes=(lab.with_name('closed-capture-pair-20261124')/'routes.py').read_text(encoding='utf-8')
routes=routes[:routes.index("affected='scripts.captured-rule-closures'")]
routes=routes.replace('root=lab.parents[3]','root=lab.parents[4]')
routes=routes.replace("for case in read(catalog)['cases']:",'''for case in read(catalog)['cases']:
    if case['id'] not in {'scripts.rule-default-closures', 'scripts.csv-invoice.method-policy.quoted-control'}:continue''')
compile(routes,'routes.py','exec')
(work/'routes.py').write_text(routes,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
subprocess.run([sdk/'dotnet.exe','build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
    '--no-incremental','--artifacts-path',work/'diagnostic-build','--nologo'],env=env,cwd=source,check=True,timeout=130)
subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',work/'routes.py'],cwd=repo,check=True,timeout=130)
rows=json.loads((work/'route-counts.json').read_text(encoding='utf-8'))['rows']
assert [row['case'] for row in rows]==['scripts.rule-default-closures','scripts.csv-invoice.method-policy.quoted-control']
assert sum(count for name,count in rows[0]['routes'].items() if name.startswith('singleton ')) == 16384
assert not any(row['routes'].get('positional defaults read',0) for row in rows)
