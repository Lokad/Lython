; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -528
 
G_M000_IG77:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x004B
       mov      dword ptr [rbp-0x1C4], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x124]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0099
       mov      rdi, 0x7FCF57F2EAF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rdi, 0x7FCF57F2EAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1AC], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, 0x7FCF57F2EB00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG07:                ;; offset=0x010D
       cmp      dword ptr [rbp-0x1AC], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0128
       mov      rdi, 0x7FCF57F2EB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0139
       mov      rdi, 0x7FCF57F2EB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG10:                ;; offset=0x015A
       mov      rdi, 0x7FCF57F2EB0C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x128], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017F
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG12:                ;; offset=0x0187
       movzx    rax, byte  ptr [rbp-0x128]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x130], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      esi, dword ptr [rbp-0x1CC]
       mov      rdi, bword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rsi, gword ptr [rbp-0x1D8]
       mov      rdi, 0x7FCF57EDBAF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x138]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0224
       mov      rdi, 0x7FCF57F2EB10
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0233
       mov      rdi, 0x7FCF57F2EB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C8], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0267
       mov      rdi, 0x7FCF57F2EB18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0278
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x1C0]
       mov      rsi, 0x7FCF57F2EB20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      rdi, gword ptr [rbp-0x1E0]
       mov      esi, dword ptr [rbp-0x1E4]
       mov      r11, 0x7FCF55C21D80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x148]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x150]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7FCF5777B020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0473
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x047F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x260]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rsi, gword ptr [rbp-0x1F8]
       mov      rdi, 0x7FCF57BE98D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0510
       mov      rdi, 0x7FCF57F2EC28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051F
       mov      rdi, 0x7FCF57F2EC2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x200], rcx
       mov      rdi, bword ptr [rbp-0x200]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7FCF57F2EC30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0611
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x061A
       mov      rdi, 0x7FCF57F2EC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x208], rax
       mov      rsi, gword ptr [rbp-0x208]
       mov      rdi, 0x7FCF5777B020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0686
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG28:                ;; offset=0x0692
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06AD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06DA
       mov      eax, dword ptr [rbp-0x1C4]
       dec      eax
       mov      dword ptr [rbp-0x1C4], eax
       cmp      dword ptr [rbp-0x1C4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06F1
       lea      rdi, [rbp-0x1C4]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0704
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0726
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0736
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rsi, gword ptr [rbp-0x228]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07AD
       mov      rdi, 0x7FCF57F2EC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07C6
       cmp      gword ptr [rbp-0x108], 0
       jne      G_M000_IG39
 
G_M000_IG37:                ;; offset=0x07D4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG38:                ;; offset=0x07E4
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x170]
       mov      rdx, qword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      rdi, 0x7FCF57F2EC3C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x11C], eax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x100]
       mov      rdx, qword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      edx, dword ptr [rbp-0x11C]
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0906
       mov      rdi, 0x7FCF57F2EC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG40:                ;; offset=0x0976
       cmp      dword ptr [rbp-0x10C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x099B
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x09ED
       mov      rdi, 0x7FCF57F2EC44
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x09FC
       mov      rdi, 0x7FCF57F2EC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0A2A
       mov      rdi, 0x7FCF57F2EC4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0A39
       mov      rdi, 0x7FCF57F2EC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x0A7B
       mov      rdi, 0x7FCF57F2EC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
 
G_M000_IG47:                ;; offset=0x0AAF
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0AB6
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0ABD
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0AC3
       mov      rdi, 0x7FCF57F2EC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x120]
       mov      dword ptr [rbp-0x1C8], eax
 
G_M000_IG51:                ;; offset=0x0ADE
       movzx    rax, byte  ptr [rbp-0x1C8]
 
G_M000_IG52:                ;; offset=0x0AE5
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0AEE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0AF4
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0AF8
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7FCF57F2EC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x250], rcx
       mov      rdi, bword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0B62
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7FCF57F2EC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      esi, dword ptr [rbp-0x254]
       mov      rdi, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0BB2
       mov      rdi, 0x7FCF57F2EC70
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0BC2
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0BC7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0BCD
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0BD1
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0BEE
       mov      rdi, 0x7FCF57F2EC5C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0C02
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0C08
       mov      rdi, 0x7FCF57F2EC60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0C17
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x178], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x178]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x180], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7FCF57F2EC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG66:                ;; offset=0x0C96
       mov      rdi, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0CAA
       nop      
 
G_M000_IG68:                ;; offset=0x0CAB
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0CB1
       mov      rdi, 0x7FCF57F2EC74
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0CC1
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0CC6
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0CCA
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7FCF57F2EC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0CEE
       nop      
 
G_M000_IG74:                ;; offset=0x0CEF
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0CF5
       mov      rdi, 0x7FCF57F2EC78
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0D05
       add      rsp, 24
       ret      
 
; Total bytes of code 3338

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0031
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG05
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG03
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       lea      rdi, [rbp-0x58]
       mov      esi, dword ptr [rbp-0x48]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x20]
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rax], rcx
 
G_M000_IG03:                ;; offset=0x00BC
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x00BE
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x00C4
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG07
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x60], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x60]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG06:                ;; offset=0x0130
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0136
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 316

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7FCF57F2EF10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7FCF57F2EF14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7FCF57F2EF18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7FCF57F2EF1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7FCF57F2EF20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7FCF57F2EF24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7FCF57F2EF28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7FCF57F2EF2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7FCF57F2EF30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7FCF57F2EF34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7FCF57F2EF38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0031
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x38], rax
       lea      rax, [rbp-0x48]
       mov      qword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      rdi, gword ptr [rbp-0x38]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x3C], 0
       jge      SHORT G_M000_IG06
       cmp      dword ptr [rbp-0x10], 8
       jle      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG05
       mov      rdi, 0x7FCF5839E270
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       lea      rdi, [rbp-0x58]
       mov      esi, dword ptr [rbp-0x48]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x20]
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rax], rcx
 
G_M000_IG03:                ;; offset=0x00CB
       mov      rdi, 0x7FCF5839E274
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x00DC
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x00E2
       mov      rdi, 0x7FCF5839E278
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG03
 
G_M000_IG06:                ;; offset=0x00F3
       mov      rdi, 0x7FCF5839E27C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG08
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, bword ptr [rbp-0x50]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x60], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x60]
       mov      rax, bword ptr [rbp-0x50]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x3C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x016E
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0174
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 378

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x10]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0073
       mov      rdi, 0x7FCF57F2EF10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x0087
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00C0
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00CD
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7FCF57F2EF14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x012A
       mov      rdi, 0x7FCF57F2EF18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0139
       mov      rdi, 0x7FCF57F2EF1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG09:                ;; offset=0x0150
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0167
       lea      rdi, [rbp-0xB4]
       mov      esi, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x017A
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7FCF57F2EF20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x019A
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG13:                ;; offset=0x01A7
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7FCF57F2EF24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG14:                ;; offset=0x01FD
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      edi, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7FCF578AFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7FCF57F2EF28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02E3
       mov      rdi, 0x7FCF57F2EF2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02F4
       mov      rdi, 0x7FCF57F2EF30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x0303
       mov      rdi, 0x7FCF57F2EF34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0331
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0348
       lea      rdi, [rbp-0xB4]
       mov      esi, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x035B
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7FCF57F2EF38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0374
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0379
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0382
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0388
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 919

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 640
       lea      rbp, [rsp+0x280]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -528
 
G_M000_IG77:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x004B
       mov      dword ptr [rbp-0x1C4], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x124]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0099
       mov      rdi, 0x7FCF57F2EAF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rdi, 0x7FCF57F2EAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1AC], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, 0x7FCF57F2EB00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG07:                ;; offset=0x010D
       cmp      dword ptr [rbp-0x1AC], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0128
       mov      rdi, 0x7FCF57F2EB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0139
       mov      rdi, 0x7FCF57F2EB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B8], rax
 
G_M000_IG10:                ;; offset=0x015A
       mov      rdi, 0x7FCF57F2EB0C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x128], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017F
       xor      eax, eax
       mov      dword ptr [rbp-0x128], eax
 
G_M000_IG12:                ;; offset=0x0187
       movzx    rax, byte  ptr [rbp-0x128]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x130], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      esi, dword ptr [rbp-0x1CC]
       mov      rdi, bword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rsi, gword ptr [rbp-0x1D8]
       mov      rdi, 0x7FCF57EDBAF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x138]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0224
       mov      rdi, 0x7FCF57F2EB10
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0233
       mov      rdi, 0x7FCF57F2EB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C8], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0267
       mov      rdi, 0x7FCF57F2EB18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0278
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, gword ptr [rbp-0x140]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, gword ptr [rbp-0x1C0]
       mov      rsi, 0x7FCF57F2EB20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      rdi, gword ptr [rbp-0x1E0]
       mov      esi, dword ptr [rbp-0x1E4]
       mov      r11, 0x7FCF55C22200
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x148]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x150], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x150]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7FCF5777B020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0473
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x047F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x260], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x260]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rsi, gword ptr [rbp-0x1F8]
       mov      rdi, 0x7FCF57BE98D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0510
       mov      rdi, 0x7FCF57F2EC28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051F
       mov      rdi, 0x7FCF57F2EC2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x200], rcx
       mov      rdi, bword ptr [rbp-0x200]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7FCF57F2EC30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0611
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x061A
       mov      rdi, 0x7FCF57F2EC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x208], rax
       mov      rsi, gword ptr [rbp-0x208]
       mov      rdi, 0x7FCF5777B020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0686
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG28:                ;; offset=0x0692
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06AD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06DA
       mov      eax, dword ptr [rbp-0x1C4]
       dec      eax
       mov      dword ptr [rbp-0x1C4], eax
       cmp      dword ptr [rbp-0x1C4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06F1
       lea      rdi, [rbp-0x1C4]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0704
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0726
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0736
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rsi, gword ptr [rbp-0x228]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07AD
       mov      rdi, 0x7FCF57F2EC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07C6
       cmp      gword ptr [rbp-0x108], 0
       jne      G_M000_IG39
 
G_M000_IG37:                ;; offset=0x07D4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x170], xmm0
 
G_M000_IG38:                ;; offset=0x07E4
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       lea      rax, [rbp-0x118]
       mov      qword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x170]
       mov      rdx, qword ptr [rbp-0x168]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG40
       mov      rdi, 0x7FCF57F2EC3C
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x118]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x11C], eax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, bword ptr [rbp-0x100]
       mov      rdx, qword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0xE0]
       mov      edx, dword ptr [rbp-0x11C]
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0x10C], eax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0906
       mov      rdi, 0x7FCF57F2EC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x160], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x160]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG40:                ;; offset=0x0976
       cmp      dword ptr [rbp-0x10C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x099B
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x09ED
       mov      rdi, 0x7FCF57F2EC44
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x09FC
       mov      rdi, 0x7FCF57F2EC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0A2A
       mov      rdi, 0x7FCF57F2EC4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0A39
       mov      rdi, 0x7FCF57F2EC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rsi, gword ptr [rbp-0x248]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x0A7B
       mov      rdi, 0x7FCF57F2EC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x120], 1
 
G_M000_IG47:                ;; offset=0x0AAF
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0AB6
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0ABD
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0AC3
       mov      rdi, 0x7FCF57F2EC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x120]
       mov      dword ptr [rbp-0x1C8], eax
 
G_M000_IG51:                ;; offset=0x0ADE
       movzx    rax, byte  ptr [rbp-0x1C8]
 
G_M000_IG52:                ;; offset=0x0AE5
       add      rsp, 640
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0AEE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0AF4
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0AF8
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7FCF57F2EC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x250], rcx
       mov      rdi, bword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0B62
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7FCF57F2EC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      esi, dword ptr [rbp-0x254]
       mov      rdi, bword ptr [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0BB2
       mov      rdi, 0x7FCF57F2EC70
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0BC2
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0BC7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0BCD
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0BD1
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0BEE
       mov      rdi, 0x7FCF57F2EC5C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0C02
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0C08
       mov      rdi, 0x7FCF57F2EC60
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0C17
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x178], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x178]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x180], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x188], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7FCF57F2EC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x188], rax
 
G_M000_IG66:                ;; offset=0x0C96
       mov      rdi, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0CAA
       nop      
 
G_M000_IG68:                ;; offset=0x0CAB
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0CB1
       mov      rdi, 0x7FCF57F2EC74
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0CC1
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0CC6
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0CCA
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7FCF57F2EC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0CEE
       nop      
 
G_M000_IG74:                ;; offset=0x0CEF
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0CF5
       mov      rdi, 0x7FCF57F2EC78
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0D05
       add      rsp, 24
       ret      
 
; Total bytes of code 3338

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 642519
; 53 inlinees with PGO data; 103 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0xD0], r8
       mov      dword ptr [rbp-0x94], r9d
       mov      rbx, rdi
       mov      r13, rsi
       mov      r15d, edx
       mov      r14, gword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x004B
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG94
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG93
 
G_M000_IG03:                ;; offset=0x0074
       mov      rdx, gword ptr [rbx+0x28]
       mov      gword ptr [rbp-0xC8], rdx
       mov      esi, dword ptr [rbx+0x4C]
       mov      dword ptr [rbp-0x2C], esi
       mov      bword ptr [rbp-0xD8], r13
       mov      edi, r15d
       cmp      esi, 4
       jle      G_M000_IG95
 
G_M000_IG04:                ;; offset=0x0098
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       xor      r8d, r8d
       mov      dword ptr [rbp-0x54], r8d
       cmp      r8d, r15d
       jge      G_M000_IG35
 
G_M000_IG05:                ;; offset=0x00B1
       mov      rdi, gword ptr [r14+0x98]
       mov      r9, gword ptr [rdi+0x88]
       cmp      gword ptr [r9+0x20], 0
       jne      G_M000_IG106
       mov      r9, gword ptr [rdi+0x180]
       test     r9, r9
       jne      G_M000_IG105
 
G_M000_IG06:                ;; offset=0x00DA
       mov      r8d, dword ptr [rbp-0x54]
       mov      r9d, r15d
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jge      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x00F1
       mov      dword ptr [rbp-0x58], r9d
       mov      edi, r8d
       mov      r10d, r9d
       add      rdi, r10
       mov      r10d, r15d
       cmp      rdi, r10
       ja       G_M000_IG113
       mov      dword ptr [rbp-0x54], r8d
       mov      r10d, r8d
       add      r10, r13
       mov      bword ptr [rbp-0xE0], r10
       mov      r11, r10
       mov      edi, r9d
       cmp      edi, 16
       jl       G_M000_IG17
 
G_M000_IG08:                ;; offset=0x012A
       cmp      dword ptr [rbp-0x34], 0
       jne      G_M000_IG107
       mov      r10, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], r10
       mov      r10, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], r10
 
G_M000_IG09:                ;; offset=0x0150
       cmp      edi, 16
       jl       G_M000_IG17
 
G_M000_IG10:                ;; offset=0x0159
       mov      r10d, dword ptr [rbp-0x50]
       imul     ecx, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      ecx, r10d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], ecx
       mov      ecx, dword ptr [rbp-0x4C]
       lea      r10, bword ptr [r11+0x04]
       imul     r10d, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      ecx, r10d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], ecx
       mov      ecx, dword ptr [rbp-0x48]
       lea      r10, bword ptr [r11+0x08]
       imul     r10d, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      ecx, r10d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], ecx
       mov      ecx, dword ptr [rbp-0x44]
       lea      r10, bword ptr [r11+0x0C]
       imul     r10d, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      ecx, r10d
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], ecx
       mov      ecx, dword ptr [rbp-0x34]
       add      ecx, 4
       mov      dword ptr [rbp-0x34], ecx
       add      r11, 16
       add      edi, -16
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x01DF
       cmp      ecx, 3
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01E4
       mov      rcx, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], rcx
       mov      rcx, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], rcx
 
G_M000_IG13:                ;; offset=0x0200
       imul     ecx, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x50]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], ecx
       imul     ecx, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x4C]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], ecx
       imul     ecx, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x48]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], ecx
       imul     r10d, r10d, 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0x44]
       rol      r10d, 13
       imul     ecx, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], ecx
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x025D
       mov      dword ptr [rbp-0x3C], r10d
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0263
       mov      dword ptr [rbp-0x40], r10d
 
G_M000_IG16:                ;; offset=0x0267
       add      r11, 4
       add      edi, -4
       mov      r12, r11
       mov      r11, r12
 
G_M000_IG17:                ;; offset=0x0274
       cmp      edi, 4
       jl       SHORT G_M000_IG23
 
G_M000_IG18:                ;; offset=0x0279
       mov      r10d, dword ptr [r11]
       mov      ecx, dword ptr [rbp-0x34]
       lea      r12d, [rcx+0x01]
       mov      dword ptr [rbp-0x34], r12d
       mov      r12d, ecx
       and      r12d, 3
       je       SHORT G_M000_IG15
 
G_M000_IG19:                ;; offset=0x0290
       cmp      r12d, 1
       je       SHORT G_M000_IG14
 
G_M000_IG20:                ;; offset=0x0296
       cmp      r12d, 2
       jne      G_M000_IG11
 
G_M000_IG21:                ;; offset=0x02A0
       mov      dword ptr [rbp-0x38], r10d
       jmp      SHORT G_M000_IG16
 
G_M000_IG22:                ;; offset=0x02A6
       mov      r9d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x02B1
       mov      r10, r11
       xor      r11d, r11d
       test     edi, edi
       je       G_M000_IG34
 
G_M000_IG24:                ;; offset=0x02BF
       movzx    rcx, byte  ptr [r10+r11]
       mov      r12d, dword ptr [rbp-0x34]
       lea      eax, [r12+0x01]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, r12d
       and      eax, 3
       je       G_M000_IG32
 
G_M000_IG25:                ;; offset=0x02DC
       cmp      eax, 1
       je       G_M000_IG31
 
G_M000_IG26:                ;; offset=0x02E5
       cmp      eax, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02EA
       mov      dword ptr [rbp-0x38], ecx
       jmp      G_M000_IG33
 
G_M000_IG28:                ;; offset=0x02F2
       cmp      r12d, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02F8
       mov      rax, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], rax
       mov      rax, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG30:                ;; offset=0x0314
       imul     eax, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x50]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], eax
       imul     eax, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x4C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], eax
       imul     eax, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x48]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], eax
       imul     ecx, ecx, 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x44]
       rol      ecx, 13
       imul     eax, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG33
 
G_M000_IG31:                ;; offset=0x036D
       mov      dword ptr [rbp-0x3C], ecx
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0372
       mov      dword ptr [rbp-0x40], ecx
 
G_M000_IG33:                ;; offset=0x0375
       inc      r11d
       cmp      r11d, edi
       jl       G_M000_IG24
 
G_M000_IG34:                ;; offset=0x0381
       mov      r8d, dword ptr [rbp-0x54]
       add      r8d, dword ptr [rbp-0x58]
       cmp      r8d, r15d
       mov      dword ptr [rbp-0x54], r8d
       jl       G_M000_IG05
 
G_M000_IG35:                ;; offset=0x0396
       mov      eax, dword ptr [rbp-0x34]
       mov      edi, eax
       and      edi, 3
       cmp      eax, 4
       jae      G_M000_IG92
 
G_M000_IG36:                ;; offset=0x03A7
       mov      ecx, 0xFFFFFFFF8E1204ED
 
G_M000_IG37:                ;; offset=0x03AC
       lea      eax, [rcx+4*rax]
       test     edi, edi
       je       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x03B3
       imul     ecx, dword ptr [rbp-0x40], 0xFFFFFFFFC2B2AE3D
       add      eax, ecx
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edi, 1
       jbe      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x03CA
       imul     ecx, dword ptr [rbp-0x3C], 0xFFFFFFFFC2B2AE3D
       add      ecx, eax
       rol      ecx, 17
       imul     eax, ecx, 0x27D4EB2F
       cmp      edi, 2
       jbe      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x03E1
       imul     edi, dword ptr [rbp-0x38], 0xFFFFFFFFC2B2AE3D
       add      edi, eax
       rol      edi, 17
       imul     eax, edi, 0x27D4EB2F
 
G_M000_IG41:                ;; offset=0x03F3
       mov      edi, eax
       shr      edi, 15
       xor      edi, eax
       imul     eax, edi, 0xFFFFFFFF85EBCA77
       mov      edi, eax
       shr      edi, 13
       xor      edi, eax
       imul     eax, edi, 0xFFFFFFFFC2B2AE3D
       mov      edi, eax
       shr      edi, 16
       xor      eax, edi
       mov      edi, -2
       cmp      eax, -1
       cmovne   edi, eax
       mov      eax, edi
       shr      eax, 16
       xor      eax, edi
       imul     eax, eax, 0xFFFFFFFF9E3779B9
       mov      edi, eax
       shr      edi, 16
       xor      edi, eax
       mov      r12d, edi
       test     esi, esi
       je       G_M000_IG134
 
G_M000_IG42:                ;; offset=0x043E
       mov      r9d, dword ptr [rdx+0x08]
       mov      ecx, r9d
       mov      edi, ecx
       blsr     eax, edi
       jne      G_M000_IG114
       dec      edi
       and      edi, r12d
 
G_M000_IG43:                ;; offset=0x0457
       mov      dword ptr [rbp-0xAC], ecx
       cmp      edi, ecx
       jae      G_M000_IG154
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      eax, dword ptr [rdx+8*rdi+0x30]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       test     eax, eax
       jl       G_M000_IG116
       jmp      SHORT G_M000_IG46
 
G_M000_IG44:                ;; offset=0x0485
       mov      rdx, gword ptr [rbp-0xC8]
 
G_M000_IG45:                ;; offset=0x048C
       mov      r8, bword ptr [rbp-0xF8]
       mov      eax, dword ptr [r8+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       js       G_M000_IG134
 
G_M000_IG46:                ;; offset=0x04A2
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG117
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG115
 
G_M000_IG47:                ;; offset=0x04CB
       mov      eax, dword ptr [rbp-0x30]
       cmp      eax, dword ptr [rbp-0xAC]
       jae      G_M000_IG154
       mov      dword ptr [rbp-0x30], eax
       mov      edi, eax
       lea      rdi, [rdi+4*rdi]
       mov      rdx, gword ptr [rbp-0xC8]
       lea      r8, bword ptr [rdx+8*rdi+0x10]
       mov      bword ptr [rbp-0xF8], r8
       cmp      dword ptr [r8+0x18], r12d
       jne      SHORT G_M000_IG45
 
G_M000_IG48:                ;; offset=0x04FC
       mov      rdi, gword ptr [rdx+8*rdi+0x10]
       test     rdi, rdi
       je       G_M000_IG44
 
G_M000_IG49:                ;; offset=0x050A
       mov      rsi, 0x7FCF578AFBC0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG91
 
G_M000_IG50:                ;; offset=0x051D
       mov      esi, r15d
       movzx    r9, byte  ptr [rdi+0x24]
       test     r9d, r9d
       je       G_M000_IG74
 
G_M000_IG51:                ;; offset=0x052E
       cmp      r9d, 255
       je       G_M000_IG72
 
G_M000_IG52:                ;; offset=0x053B
       lea      r9, bword ptr [rdi+0x28]
       mov      r10d, dword ptr [rdi+0x18]
       cmp      r10d, 8
       ja       G_M000_IG113
 
G_M000_IG53:                ;; offset=0x054D
       mov      bword ptr [rbp-0xF0], r9
       mov      dword ptr [rbp-0x9C], r10d
       cmp      r10d, esi
       jne      G_M000_IG120
       xor      r11d, r11d
       mov      dword ptr [rbp-0x5C], r11d
       cmp      r11d, r15d
       jge      G_M000_IG61
 
G_M000_IG54:                ;; offset=0x0574
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG122
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG121
 
G_M000_IG55:                ;; offset=0x059D
       mov      r11d, dword ptr [rbp-0x5C]
       mov      edi, r15d
       sub      edi, r11d
       cmp      edi, 0x1000
       jge      G_M000_IG76
 
G_M000_IG56:                ;; offset=0x05B3
       mov      dword ptr [rbp-0x60], edi
       mov      esi, r11d
       mov      r9d, edi
       mov      qword ptr [rbp-0xB8], r9
       add      rsi, r9
       mov      r10d, r15d
       cmp      rsi, r10
       ja       G_M000_IG113
       mov      r10d, r11d
       add      r10, r13
       mov      edi, dword ptr [rbp-0x9C]
       cmp      rsi, rdi
       ja       G_M000_IG113
       mov      edi, r11d
       add      rdi, bword ptr [rbp-0xF0]
       mov      rsi, r10
       mov      r9, rdi
       mov      r13, qword ptr [rbp-0xB8]
       cmp      r13, 8
       jae      G_M000_IG82
 
G_M000_IG57:                ;; offset=0x0608
       cmp      r13, 4
       jb       G_M000_IG77
 
G_M000_IG58:                ;; offset=0x0612
       add      r13, -4
       mov      esi, dword ptr [r10]
       sub      esi, dword ptr [rdi]
       mov      r10d, dword ptr [r10+r13]
       sub      r10d, dword ptr [rdi+r13]
       or       esi, r10d
       sete     sil
       movzx    rsi, sil
 
G_M000_IG59:                ;; offset=0x062E
       test     esi, esi
       je       G_M000_IG123
 
G_M000_IG60:                ;; offset=0x0636
       add      r11d, dword ptr [rbp-0x60]
       cmp      r11d, r15d
       mov      dword ptr [rbp-0x5C], r11d
       mov      r13, bword ptr [rbp-0xD8]
       jl       G_M000_IG54
 
G_M000_IG61:                ;; offset=0x064E
       mov      eax, dword ptr [rbp-0x30]
       mov      r13d, eax
 
G_M000_IG62:                ;; offset=0x0654
       xor      edi, edi
       mov      r14, bword ptr [rbp+0x20]
       mov      qword ptr [r14], rdi
       test     r13d, r13d
       jl       G_M000_IG135
 
G_M000_IG63:                ;; offset=0x0666
       mov      rdx, gword ptr [rbp-0xC8]
       mov      edi, dword ptr [rdx+0x08]
       mov      edi, r13d
       lea      rdi, [rdi+4*rdi]
       lea      rsi, bword ptr [rdx+8*rdi+0x10]
       mov      r15d, r13d
       mov      rax, gword ptr [rsi]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x068A
       mov      rcx, 0x7FCF578AFBC0
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG140
 
G_M000_IG65:                ;; offset=0x069D
       mov      r12d, dword ptr [rsi+0x18]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG141
       mov      rsi, gword ptr [rbx+0x30]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG154
       mov      eax, r15d
       cmp      gword ptr [rsi+8*rax+0x10], 0
       jne      G_M000_IG141
 
G_M000_IG66:                ;; offset=0x06C9
       mov      rsi, gword ptr [rbx+0x28]
       cmp      r15d, dword ptr [rsi+0x08]
       jae      G_M000_IG154
       mov      rsi, qword ptr [rsi+8*rdi+0x20]
       mov      rdi, 0xFF80000000000000
       cmp      rsi, rdi
       jl       G_M000_IG142
       mov      rdi, 0x80000000000000
       cmp      rsi, rdi
       jge      G_M000_IG142
 
G_M000_IG67:                ;; offset=0x0702
       mov      rdi, gword ptr [rbp-0xD0]
       test     rdi, rdi
       jne      G_M000_IG147
       movsxd   rax, dword ptr [rbp-0x94]
 
G_M000_IG68:                ;; offset=0x0719
       add      rsi, rax
       mov      eax, dword ptr [rbx+0x4C]
       mov      dword ptr [rbp-0x7C], eax
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG152
       mov      rdi, gword ptr [rbx+0x28]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG154
       mov      ecx, r15d
       lea      rcx, [rcx+4*rcx]
       mov      qword ptr [rdi+8*rcx+0x20], rsi
       mov      rdi, gword ptr [rbx+0x30]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG154
       mov      esi, r15d
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rsi+0x10], rcx
 
G_M000_IG69:                ;; offset=0x075F
       mov      eax, dword ptr [rbp-0x7C]
       cmp      dword ptr [rbx+0x4C], eax
       jne      G_M000_IG153
 
G_M000_IG70:                ;; offset=0x076B
       mov      eax, 1
 
G_M000_IG71:                ;; offset=0x0770
       vzeroupper 
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG72:                ;; offset=0x0785
       mov      r9, gword ptr [rdi+0x08]
       lea      r10, bword ptr [rdi+0x28]
       mov      r10d, dword ptr [r10]
       mov      edi, dword ptr [rdi+0x18]
       test     r9, r9
       je       G_M000_IG119
       mov      qword ptr [rbp-0xA8], r10
       mov      r11d, edi
       add      r11, r10
       mov      r10d, dword ptr [r9+0x08]
       cmp      r11, r10
       ja       G_M000_IG113
       mov      r10, qword ptr [rbp-0xA8]
       lea      r9, bword ptr [r9+r10+0x10]
       mov      r10d, edi
 
G_M000_IG73:                ;; offset=0x07C5
       jmp      G_M000_IG53
 
G_M000_IG74:                ;; offset=0x07CA
       mov      r9, gword ptr [rdi+0x08]
       mov      r10d, dword ptr [rdi+0x18]
       test     r9, r9
       je       G_M000_IG118
       cmp      dword ptr [r9+0x08], r10d
       jb       G_M000_IG113
       add      r9, 16
 
G_M000_IG75:                ;; offset=0x07E9
       jmp      G_M000_IG53
 
G_M000_IG76:                ;; offset=0x07EE
       mov      edi, 0x1000
       jmp      G_M000_IG56
 
G_M000_IG77:                ;; offset=0x07F8
       xor      esi, esi
       mov      r9, r13
       and      r9, 2
       mov      qword ptr [rbp-0x68], r9
       test     r9, r9
       je       SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x080A
       movzx    rsi, word  ptr [r10]
       mov      dword ptr [rbp-0xFC], esi
       movzx    rsi, word  ptr [rdi]
       movzx    r9, dword ptr [rbp-0xFC]
       sub      r9d, esi
       mov      esi, r9d
 
G_M000_IG79:                ;; offset=0x0825
       test     r13b, 1
       je       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x082B
       mov      r9, qword ptr [rbp-0x68]
       movzx    r10, byte  ptr [r10+r9]
       movzx    rdi, byte  ptr [rdi+r9]
       sub      r10d, edi
       or       esi, r10d
 
G_M000_IG81:                ;; offset=0x083F
       test     esi, esi
       sete     sil
       movzx    rsi, sil
       jmp      G_M000_IG59
 
G_M000_IG82:                ;; offset=0x084E
       cmp      rsi, r9
       je       G_M000_IG60
 
G_M000_IG83:                ;; offset=0x0857
       cmp      r13, 32
       jae      SHORT G_M000_IG86
 
G_M000_IG84:                ;; offset=0x085D
       cmp      r13, 16
       jae      G_M000_IG127
 
G_M000_IG85:                ;; offset=0x0867
       lea      rsi, [r13-0x08]
       mov      r9, qword ptr [r10]
       sub      r9, qword ptr [rdi]
       mov      r10, qword ptr [r10+rsi]
       sub      r10, qword ptr [rdi+rsi]
       or       r9, r10
       sete     sil
       movzx    rsi, sil
       jmp      G_M000_IG59
 
G_M000_IG86:                ;; offset=0x0889
       xor      edi, edi
       lea      r10, [r13-0x20]
       test     r10, r10
       je       SHORT G_M000_IG90
 
G_M000_IG87:                ;; offset=0x0894
       vmovups  ymm0, ymmword ptr [rsi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9]
       vpmovmskb r13d, ymm0
       cmp      r13d, -1
       jne      G_M000_IG124
 
G_M000_IG88:                ;; offset=0x08AB
       add      rdi, 32
       cmp      r10, rdi
       jbe      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x08B4
       vmovups  ymm0, ymmword ptr [rsi+rdi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+rdi]
       vpmovmskb r13d, ymm0
       cmp      r13d, -1
       jne      G_M000_IG125
       jmp      SHORT G_M000_IG88
 
G_M000_IG90:                ;; offset=0x08CF
       vmovups  ymm0, ymmword ptr [rsi+r10]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+r10]
       vpmovmskb edi, ymm0
       cmp      edi, -1
       jne      G_M000_IG126
       jmp      G_M000_IG60
 
G_M000_IG91:                ;; offset=0x08ED
       mov      rdx, gword ptr [rbp-0xC8]
       jmp      G_M000_IG45
 
G_M000_IG92:                ;; offset=0x08F9
       rorx     ecx, dword ptr [rbp-0x50], 31
       rorx     r8d, dword ptr [rbp-0x4C], 25
       add      ecx, r8d
       rorx     r8d, dword ptr [rbp-0x48], 20
       add      ecx, r8d
       rorx     r8d, dword ptr [rbp-0x44], 14
       add      ecx, r8d
       jmp      G_M000_IG37
 
G_M000_IG93:                ;; offset=0x0923
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG03
 
G_M000_IG94:                ;; offset=0x0937
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG95:                ;; offset=0x0946
       cmp      edi, 8
       jg       G_M000_IG04
 
G_M000_IG96:                ;; offset=0x094F
       xor      r14d, r14d
       xor      r8d, r8d
       test     esi, esi
       jle      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0959
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r8d, r9d
       jae      G_M000_IG154
       mov      qword ptr [rbp-0xC0], r8
       lea      rdi, [r8+4*r8]
       mov      rdi, gword ptr [rdx+8*rdi+0x10]
       test     rdi, rdi
       jne      SHORT G_M000_IG99
       jmp      SHORT G_M000_IG102
 
G_M000_IG98:                ;; offset=0x097D
       mov      r12d, r14d
       jmp      G_M000_IG134
 
G_M000_IG99:                ;; offset=0x0985
       mov      r9, 0x7FCF578AFBC0
       cmp      qword ptr [rdi], r9
       jne      SHORT G_M000_IG102
 
G_M000_IG100:                ;; offset=0x0994
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      rsi, rax
       cmp      r15d, edx
       jne      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x09A2
       mov      edx, edx
       mov      rdi, r13
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG104
 
G_M000_IG102:                ;; offset=0x09B1
       mov      r8, qword ptr [rbp-0xC0]
       inc      r8d
       mov      rdi, r8
       mov      esi, dword ptr [rbp-0x2C]
       cmp      edi, esi
       mov      r8, rdi
       mov      rdx, gword ptr [rbp-0xC8]
       jl       SHORT G_M000_IG97
 
G_M000_IG103:                ;; offset=0x09CF
       mov      r12d, r14d
       jmp      G_M000_IG134
 
G_M000_IG104:                ;; offset=0x09D7
       mov      r13, qword ptr [rbp-0xC0]
       mov      r12d, r14d
       jmp      G_M000_IG62
 
G_M000_IG105:                ;; offset=0x09E6
       cmp      dword ptr [r9+0x20], 0
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       je       G_M000_IG06
 
G_M000_IG106:                ;; offset=0x09FC
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      esi, dword ptr [rbp-0x2C]
       jmp      G_M000_IG06
 
G_M000_IG107:                ;; offset=0x0A15
       mov      ecx, dword ptr [rbp-0x34]
       and      ecx, 3
       dec      ecx
       cmp      ecx, 2
       ja       G_M000_IG09
       mov      qword ptr [rbp-0x104], rcx
       lea      rcx, [reloc @RWD00]
       mov      dword ptr [rbp-0x98], edi
       mov      r12, qword ptr [rbp-0x104]
       mov      ecx, dword ptr [rcx+4*r12]
       lea      rax, G_M000_IG02
       add      rcx, rax
       jmp      rcx
 
G_M000_IG108:                ;; offset=0x0A51
       mov      rax, r11
       mov      r12d, dword ptr [rbp-0x58]
       jmp      SHORT G_M000_IG112
 
G_M000_IG109:                ;; offset=0x0A5A
       mov      rax, r11
       mov      r12d, dword ptr [rbp-0x58]
       jmp      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0A63
       mov      esi, dword ptr [r10]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      r12, bword ptr [rbp-0xE0]
       add      r12, 4
       mov      r11, r12
       mov      r12d, dword ptr [rbp-0x58]
       lea      edi, [r12-0x04]
       mov      rax, r11
       mov      dword ptr [rbp-0x98], edi
 
G_M000_IG111:                ;; offset=0x0A90
       mov      bword ptr [rbp-0xE8], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0xE8]
       add      rax, 4
       mov      ecx, dword ptr [rbp-0x98]
       add      ecx, -4
       mov      dword ptr [rbp-0x98], ecx
 
G_M000_IG112:                ;; offset=0x0ABD
       mov      bword ptr [rbp-0xE8], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0xE8]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x98]
       add      edx, -4
       mov      edi, edx
       mov      r11, rax
       mov      rdx, gword ptr [rbp-0xC8]
       mov      esi, dword ptr [rbp-0x2C]
       jmp      G_M000_IG09
 
G_M000_IG113:                ;; offset=0x0AF8
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG114:                ;; offset=0x0AFF
       mov      eax, r12d
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       jmp      G_M000_IG43
 
G_M000_IG115:                ;; offset=0x0B0D
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG47
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0B23
       mov      rdx, gword ptr [rbp-0xC8]
       jmp      G_M000_IG134
 
G_M000_IG117:                ;; offset=0x0B2F
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG47
 
G_M000_IG118:                ;; offset=0x0B3E
       test     r10d, r10d
       jne      SHORT G_M000_IG113
       xor      r9, r9
       xor      r10d, r10d
       jmp      G_M000_IG75
 
G_M000_IG119:                ;; offset=0x0B4E
       or       r10d, edi
       jne      SHORT G_M000_IG113
       xor      r9, r9
       xor      r10d, r10d
       jmp      G_M000_IG73
 
G_M000_IG120:                ;; offset=0x0B5E
       mov      rdx, gword ptr [rbp-0xC8]
       jmp      G_M000_IG45
 
G_M000_IG121:                ;; offset=0x0B6A
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG55
 
G_M000_IG122:                ;; offset=0x0B7E
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG55
 
G_M000_IG123:                ;; offset=0x0B8D
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG124:                ;; offset=0x0BA0
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG125:                ;; offset=0x0BB3
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG126:                ;; offset=0x0BC6
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG127:                ;; offset=0x0BD9
       xor      edi, edi
       lea      r10, [r13-0x10]
       test     r10, r10
       je       SHORT G_M000_IG132
 
G_M000_IG128:                ;; offset=0x0BE4
       vmovups  xmm0, xmmword ptr [rsi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       je       SHORT G_M000_IG130
 
G_M000_IG129:                ;; offset=0x0BFA
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG130:                ;; offset=0x0C0D
       add      rdi, 16
       cmp      r10, rdi
       jbe      SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x0C16
       vmovups  xmm0, xmmword ptr [rsi+rdi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+rdi]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       je       SHORT G_M000_IG130
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG132:                ;; offset=0x0C41
       vmovups  xmm0, xmmword ptr [rsi+r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+r10]
       vpmovmskb esi, xmm0
       cmp      esi, 0xFFFF
       je       G_M000_IG60
 
G_M000_IG133:                ;; offset=0x0C5D
       mov      rdx, gword ptr [rbp-0xC8]
       mov      r13, bword ptr [rbp-0xD8]
       jmp      G_M000_IG45
 
G_M000_IG134:                ;; offset=0x0C70
       mov      r13d, -1
       jmp      G_M000_IG62
 
G_M000_IG135:                ;; offset=0x0C7B
       cmp      r15d, 8
       jle      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x0C81
       mov      eax, dword ptr [rbx+0x4C]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      ecx, dword ptr [rdx+0x08]
       mov      ebx, ecx
       cmp      eax, ebx
       jge      SHORT G_M000_IG138
 
G_M000_IG137:                ;; offset=0x0C94
       mov      byte  ptr [r14], 1
       mov      dword ptr [r14+0x04], r12d
 
G_M000_IG138:                ;; offset=0x0C9C
       xor      eax, eax
 
G_M000_IG139:                ;; offset=0x0C9E
       vzeroupper 
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG140:                ;; offset=0x0CB3
       mov      rsi, rax
       mov      rdi, rcx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG141:                ;; offset=0x0CBF
       mov      rdi, rbx
       mov      esi, r15d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x0CD0
       xor      eax, eax
       jmp      G_M000_IG71
 
G_M000_IG143:                ;; offset=0x0CD7
       mov      rdi, 0x7FCF5777B020
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG142
 
G_M000_IG144:                ;; offset=0x0CE6
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG145:                ;; offset=0x0CF0
       lea      rdi, [rbp-0x78]
       xor      esi, esi
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jge      SHORT G_M000_IG142
 
G_M000_IG146:                ;; offset=0x0D01
       mov      rdi, gword ptr [rbp-0x78]
       mov      rsi, qword ptr [rbp-0x70]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       jmp      G_M000_IG67
 
G_M000_IG147:                ;; offset=0x0D17
       cmp      dword ptr [rdi+0x08], 1
       jle      SHORT G_M000_IG148
       mov      rdi, 0x7FCF57D28130
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x0D4A
       cmp      dword ptr [rdi+0x08], 0
       jbe      G_M000_IG154
       mov      rax, qword ptr [rdi+0x10]
       mov      rdi, rax
       neg      rdi
       mov      ecx, dword ptr [rbp-0x94]
       test     ecx, ecx
       cmovle   rax, rdi
       test     rax, rax
       jle      SHORT G_M000_IG149
       test     ecx, ecx
       jg       SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x0D73
       test     rax, rax
       jge      SHORT G_M000_IG151
       test     ecx, ecx
       jge      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x0D7C
       jmp      G_M000_IG68
 
G_M000_IG151:                ;; offset=0x0D81
       mov      rdi, 0x7FCF57D28130
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG152:                ;; offset=0x0DAE
       lea      rdi, [rbp-0x90]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7FCF5777B020
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x08]
       mov      rsi, gword ptr [rbp-0x90]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x88]
       mov      dword ptr [r15+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, r15
       mov      rdi, rbx
       mov      esi, r13d
       mov      rdx, r14
       mov      r8d, r12d
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG69
 
G_M000_IG153:                ;; offset=0x0E0B
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG70
 
G_M000_IG154:                ;; offset=0x0E13
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000A18h ; case G_M000_IG110
       	dd	00000A0Fh ; case G_M000_IG109
       	dd	00000A06h ; case G_M000_IG108

; Total bytes of code 3609

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 948482
; 47 inlinees with PGO data; 94 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 136
       lea      rbp, [rsp+0xB0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      rbx, rdi
       mov      eax, esi
       mov      r12, rdx
       mov      r15d, ecx
       mov      rcx, r9
       mov      r14, r8
       mov      r13, bword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x0038
       cmp      eax, 4
       jle      G_M000_IG84
 
G_M000_IG03:                ;; offset=0x0041
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       xor      edx, edx
       mov      dword ptr [rbp-0x54], edx
       cmp      edx, r15d
       jl       G_M000_IG77
 
G_M000_IG04:                ;; offset=0x0058
       mov      gword ptr [rbp-0x80], rcx
 
G_M000_IG05:                ;; offset=0x005C
       mov      edx, dword ptr [rbp-0x34]
       mov      edi, edx
       and      edi, 3
       cmp      edx, 4
       jae      G_M000_IG51
 
G_M000_IG06:                ;; offset=0x006D
       mov      esi, 0xFFFFFFFF8E1204ED
 
G_M000_IG07:                ;; offset=0x0072
       lea      edx, [rsi+4*rdx]
       test     edi, edi
       je       SHORT G_M000_IG11
 
G_M000_IG08:                ;; offset=0x0079
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFFC2B2AE3D
       add      edx, esi
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      edi, 1
       jbe      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0090
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFFC2B2AE3D
       add      esi, edx
       rol      esi, 17
       imul     edx, esi, 0x27D4EB2F
       cmp      edi, 2
       jbe      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00A7
       imul     edi, dword ptr [rbp-0x38], 0xFFFFFFFFC2B2AE3D
       add      edi, edx
       rol      edi, 17
       imul     edx, edi, 0x27D4EB2F
 
G_M000_IG11:                ;; offset=0x00B9
       mov      edi, edx
       shr      edi, 15
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFF85EBCA77
       mov      edi, edx
       shr      edi, 13
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFFC2B2AE3D
       mov      edi, edx
       shr      edi, 16
       xor      edx, edi
       mov      edi, -2
       cmp      edx, -1
       cmovne   edi, edx
       mov      edx, edi
       shr      edx, 16
       xor      edx, edi
       imul     edx, edx, 0xFFFFFFFF9E3779B9
       mov      edi, edx
       shr      edi, 16
       xor      edi, edx
       mov      dword ptr [r13], edi
       test     eax, eax
       je       G_M000_IG115
 
G_M000_IG12:                ;; offset=0x0105
       mov      eax, dword ptr [r13]
       mov      edx, dword ptr [rbx+0x08]
       mov      ecx, edx
       mov      edi, ecx
       blsr     edx, edi
       jne      G_M000_IG103
       dec      edi
       and      edi, eax
 
G_M000_IG13:                ;; offset=0x011F
       mov      dword ptr [rbp-0x74], ecx
       cmp      edi, ecx
       jae      G_M000_IG117
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      eax, dword ptr [rbx+8*rdi+0x30]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       test     eax, eax
       jl       G_M000_IG115
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0143
       mov      rdx, bword ptr [rbp-0xA0]
       mov      eax, dword ptr [rdx+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       js       G_M000_IG115
 
G_M000_IG15:                ;; offset=0x0158
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG105
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG104
 
G_M000_IG16:                ;; offset=0x0181
       mov      eax, dword ptr [rbp-0x30]
       cmp      eax, dword ptr [rbp-0x74]
       jae      G_M000_IG117
       mov      dword ptr [rbp-0x30], eax
       mov      edi, eax
       lea      rdi, [rdi+4*rdi]
       lea      rdx, bword ptr [rbx+8*rdi+0x10]
       mov      bword ptr [rbp-0xA0], rdx
       mov      esi, dword ptr [rdx+0x18]
       cmp      esi, dword ptr [r13]
       jne      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x01AB
       mov      rdi, gword ptr [rbx+8*rdi+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG14
 
G_M000_IG18:                ;; offset=0x01B5
       mov      rsi, 0x7FCF578AFBC0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG14
 
G_M000_IG19:                ;; offset=0x01C8
       mov      esi, r15d
       movzx    r8, byte  ptr [rdi+0x24]
       test     r8d, r8d
       je       G_M000_IG34
 
G_M000_IG20:                ;; offset=0x01D9
       cmp      r8d, 255
       je       G_M000_IG32
 
G_M000_IG21:                ;; offset=0x01E6
       lea      r8, bword ptr [rdi+0x28]
       mov      r9d, dword ptr [rdi+0x18]
       cmp      r9d, 8
       ja       G_M000_IG102
 
G_M000_IG22:                ;; offset=0x01F8
       mov      bword ptr [rbp-0x98], r8
       mov      dword ptr [rbp-0x70], r9d
       cmp      r9d, esi
       jne      G_M000_IG14
       xor      r10d, r10d
       mov      dword ptr [rbp-0x5C], r10d
       cmp      r10d, r15d
       jge      G_M000_IG30
 
G_M000_IG23:                ;; offset=0x021C
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG109
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG108
 
G_M000_IG24:                ;; offset=0x0245
       mov      r10d, dword ptr [rbp-0x5C]
       mov      edi, r15d
       sub      edi, r10d
       cmp      edi, 0x1000
       jge      G_M000_IG36
 
G_M000_IG25:                ;; offset=0x025B
       mov      dword ptr [rbp-0x60], edi
       mov      esi, r10d
       mov      r11d, edi
       add      rsi, r11
       mov      r8d, r15d
       cmp      rsi, r8
       ja       G_M000_IG102
       mov      r8d, r10d
       add      r8, r12
       mov      r9d, dword ptr [rbp-0x70]
       cmp      rsi, r9
       ja       G_M000_IG102
       mov      esi, r10d
       add      rsi, bword ptr [rbp-0x98]
       mov      r9, r8
       mov      rdi, rsi
       cmp      r11, 8
       jae      G_M000_IG42
 
G_M000_IG26:                ;; offset=0x02A0
       cmp      r11, 4
       jb       G_M000_IG37
 
G_M000_IG27:                ;; offset=0x02AA
       add      r11, -4
       mov      edi, dword ptr [r8]
       sub      edi, dword ptr [rsi]
       mov      r8d, dword ptr [r8+r11]
       sub      r8d, dword ptr [rsi+r11]
       or       edi, r8d
       sete     dil
       movzx    rdi, dil
 
G_M000_IG28:                ;; offset=0x02C6
       test     edi, edi
       je       G_M000_IG14
 
G_M000_IG29:                ;; offset=0x02CE
       add      r10d, dword ptr [rbp-0x60]
       cmp      r10d, r15d
       mov      dword ptr [rbp-0x5C], r10d
       jl       G_M000_IG23
 
G_M000_IG30:                ;; offset=0x02DF
       mov      eax, dword ptr [rbp-0x30]
 
G_M000_IG31:                ;; offset=0x02E2
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x02F7
       mov      r8, gword ptr [rdi+0x08]
       lea      r9, bword ptr [rdi+0x28]
       mov      r9d, dword ptr [r9]
       mov      edi, dword ptr [rdi+0x18]
       test     r8, r8
       je       G_M000_IG107
       mov      r10d, edi
       add      r10, r9
       mov      r11d, dword ptr [r8+0x08]
       cmp      r10, r11
       ja       G_M000_IG102
       lea      r8, bword ptr [r8+r9+0x10]
       mov      r9d, edi
 
G_M000_IG33:                ;; offset=0x0329
       jmp      G_M000_IG22
 
G_M000_IG34:                ;; offset=0x032E
       mov      r8, gword ptr [rdi+0x08]
       mov      r9d, dword ptr [rdi+0x18]
       test     r8, r8
       je       G_M000_IG106
       cmp      dword ptr [r8+0x08], r9d
       jb       G_M000_IG102
       add      r8, 16
 
G_M000_IG35:                ;; offset=0x034D
       jmp      G_M000_IG22
 
G_M000_IG36:                ;; offset=0x0352
       mov      edi, 0x1000
       jmp      G_M000_IG25
 
G_M000_IG37:                ;; offset=0x035C
       xor      edi, edi
       mov      r9, r11
       and      r9, 2
       mov      qword ptr [rbp-0x68], r9
       test     r9, r9
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x036E
       movzx    rdi, word  ptr [r8]
       mov      dword ptr [rbp-0xA4], edi
       movzx    rdi, word  ptr [rsi]
       movzx    r9, dword ptr [rbp-0xA4]
       sub      r9d, edi
       mov      edi, r9d
 
G_M000_IG39:                ;; offset=0x0389
       test     r11b, 1
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x038F
       mov      r9, qword ptr [rbp-0x68]
       movzx    r11, byte  ptr [r8+r9]
       movzx    r8, byte  ptr [rsi+r9]
       sub      r11d, r8d
       or       edi, r11d
 
G_M000_IG41:                ;; offset=0x03A3
       test     edi, edi
       sete     dil
       movzx    rdi, dil
       jmp      G_M000_IG28
 
G_M000_IG42:                ;; offset=0x03B2
       cmp      r9, rdi
       je       G_M000_IG29
 
G_M000_IG43:                ;; offset=0x03BB
       cmp      r11, 32
       jae      SHORT G_M000_IG46
 
G_M000_IG44:                ;; offset=0x03C1
       cmp      r11, 16
       jae      G_M000_IG110
 
G_M000_IG45:                ;; offset=0x03CB
       add      r11, -8
       mov      r9, qword ptr [r8]
       sub      r9, qword ptr [rsi]
       mov      rdi, qword ptr [r8+r11]
       sub      rdi, qword ptr [rsi+r11]
       or       rdi, r9
       sete     dil
       movzx    rdi, dil
       jmp      G_M000_IG28
 
G_M000_IG46:                ;; offset=0x03ED
       xor      esi, esi
       lea      r8, [r11-0x20]
       test     r8, r8
       je       SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x03F8
       vmovups  ymm0, ymmword ptr [r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdi]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG14
 
G_M000_IG48:                ;; offset=0x040F
       add      rsi, 32
       cmp      r8, rsi
       jbe      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0418
       vmovups  ymm0, ymmword ptr [r9+rsi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdi+rsi]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG14
       jmp      SHORT G_M000_IG48
 
G_M000_IG50:                ;; offset=0x0433
       vmovups  ymm0, ymmword ptr [r9+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdi+r8]
       vpmovmskb edi, ymm0
       cmp      edi, -1
       jne      G_M000_IG14
       jmp      G_M000_IG29
 
G_M000_IG51:                ;; offset=0x0451
       rorx     esi, dword ptr [rbp-0x50], 31
       rorx     ecx, dword ptr [rbp-0x4C], 25
       add      esi, ecx
       rorx     ecx, dword ptr [rbp-0x48], 20
       add      esi, ecx
       rorx     ecx, dword ptr [rbp-0x44], 14
       add      esi, ecx
       jmp      G_M000_IG07
 
G_M000_IG52:                ;; offset=0x0478
       mov      edi, dword ptr [r10]
       mov      esi, dword ptr [rbp-0x34]
       lea      r9d, [rsi+0x01]
       mov      dword ptr [rbp-0x34], r9d
       mov      r9d, esi
       and      r9d, 3
       je       G_M000_IG60
 
G_M000_IG53:                ;; offset=0x0493
       cmp      r9d, 1
       je       G_M000_IG59
 
G_M000_IG54:                ;; offset=0x049D
       cmp      r9d, 2
       jne      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x04A3
       mov      dword ptr [rbp-0x38], edi
       jmp      G_M000_IG61
 
G_M000_IG56:                ;; offset=0x04AB
       cmp      esi, 3
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x04B0
       mov      rsi, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], rsi
       mov      rsi, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG58:                ;; offset=0x04CC
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x50]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], esi
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x4C]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], esi
       imul     esi, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x48]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], esi
       imul     edi, edi, 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x44]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       jmp      SHORT G_M000_IG61
 
G_M000_IG59:                ;; offset=0x0525
       mov      dword ptr [rbp-0x3C], edi
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x052A
       mov      dword ptr [rbp-0x40], edi
 
G_M000_IG61:                ;; offset=0x052D
       add      r10, 4
       add      r11d, -4
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
 
G_M000_IG62:                ;; offset=0x0541
       cmp      r11d, 4
       jge      G_M000_IG52
 
G_M000_IG63:                ;; offset=0x054B
       mov      rdi, r10
       mov      esi, r11d
       xor      r9d, r9d
       test     esi, esi
       mov      gword ptr [rbp-0x80], rcx
       je       G_M000_IG75
 
G_M000_IG64:                ;; offset=0x0560
       movzx    r10, byte  ptr [rdi+r9]
       mov      r11d, dword ptr [rbp-0x34]
       lea      ecx, [r11+0x01]
       mov      dword ptr [rbp-0x34], ecx
       mov      ecx, r11d
       and      ecx, 3
       je       G_M000_IG73
 
G_M000_IG65:                ;; offset=0x057C
       cmp      ecx, 1
       je       G_M000_IG72
 
G_M000_IG66:                ;; offset=0x0585
       cmp      ecx, 2
       jne      SHORT G_M000_IG69
 
G_M000_IG67:                ;; offset=0x058A
       mov      dword ptr [rbp-0x38], r10d
       jmp      G_M000_IG74
 
G_M000_IG68:                ;; offset=0x0593
       mov      r8d, 0x1000
       jmp      G_M000_IG80
 
G_M000_IG69:                ;; offset=0x059E
       cmp      r11d, 3
       jne      SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x05A4
       mov      rcx, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], rcx
       mov      rcx, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], rcx
 
G_M000_IG71:                ;; offset=0x05C0
       imul     ecx, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x50]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], ecx
       imul     ecx, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x4C]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], ecx
       imul     ecx, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rbp-0x48]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], ecx
       imul     r10d, r10d, 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0x44]
       rol      r10d, 13
       imul     ecx, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], ecx
       jmp      SHORT G_M000_IG74
 
G_M000_IG72:                ;; offset=0x061D
       mov      dword ptr [rbp-0x3C], r10d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0623
       mov      dword ptr [rbp-0x40], r10d
 
G_M000_IG74:                ;; offset=0x0627
       inc      r9d
       cmp      r9d, esi
       jl       G_M000_IG64
 
G_M000_IG75:                ;; offset=0x0633
       mov      edx, dword ptr [rbp-0x54]
       add      edx, dword ptr [rbp-0x58]
       cmp      edx, r15d
       mov      dword ptr [rbp-0x54], edx
       jge      G_M000_IG05
 
G_M000_IG76:                ;; offset=0x0645
       mov      rcx, gword ptr [rbp-0x80]
 
G_M000_IG77:                ;; offset=0x0649
       test     r14, r14
       je       SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x064E
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG94
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG93
 
G_M000_IG79:                ;; offset=0x0677
       mov      edx, dword ptr [rbp-0x54]
       mov      r8d, r15d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG68
 
G_M000_IG80:                ;; offset=0x068D
       mov      dword ptr [rbp-0x58], r8d
       mov      esi, edx
       mov      edi, r8d
       add      rsi, rdi
       mov      edi, r15d
       cmp      rsi, rdi
       ja       G_M000_IG102
       mov      dword ptr [rbp-0x54], edx
       mov      r9d, edx
       add      r9, r12
       mov      bword ptr [rbp-0x88], r9
       mov      r10, r9
       mov      r11d, r8d
       cmp      r11d, 16
       jl       G_M000_IG62
 
G_M000_IG81:                ;; offset=0x06C5
       cmp      dword ptr [rbp-0x34], 0
       jne      G_M000_IG96
       mov      r9, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x50], r9
       mov      rsi, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG82:                ;; offset=0x06EB
       cmp      r11d, 16
       jl       G_M000_IG62
 
G_M000_IG83:                ;; offset=0x06F5
       mov      edi, dword ptr [rbp-0x50]
       imul     esi, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], edi
       mov      edi, dword ptr [rbp-0x4C]
       lea      rsi, bword ptr [r10+0x04]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], edi
       mov      edi, dword ptr [rbp-0x48]
       lea      rsi, bword ptr [r10+0x08]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], edi
       mov      edi, dword ptr [rbp-0x44]
       lea      rsi, bword ptr [r10+0x0C]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       mov      edi, dword ptr [rbp-0x34]
       add      edi, 4
       mov      dword ptr [rbp-0x34], edi
       add      r10, 16
       add      r11d, -16
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
       jmp      G_M000_IG82
 
G_M000_IG84:                ;; offset=0x0780
       cmp      r15d, 8
       jg       G_M000_IG03
 
G_M000_IG85:                ;; offset=0x078A
       xor      edi, edi
       mov      dword ptr [r13], edi
 
G_M000_IG86:                ;; offset=0x0790
       xor      r14d, r14d
       mov      dword ptr [rbp-0x2C], eax
       test     eax, eax
       jle      G_M000_IG115
 
G_M000_IG87:                ;; offset=0x079E
       mov      r13d, dword ptr [rbx+0x08]
       cmp      r14d, r13d
       jae      G_M000_IG117
       lea      rdi, [r14+4*r14]
       mov      rdi, gword ptr [rbx+8*rdi+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x07B9
       mov      rcx, 0x7FCF578AFBC0
       cmp      qword ptr [rdi], rcx
       jne      SHORT G_M000_IG91
 
G_M000_IG89:                ;; offset=0x07C8
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      rsi, rax
       cmp      r15d, edx
       jne      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x07D6
       mov      edx, edx
       mov      rdi, r12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x07E5
       inc      r14d
       mov      eax, dword ptr [rbp-0x2C]
       cmp      r14d, eax
       mov      dword ptr [rbp-0x2C], eax
       jl       SHORT G_M000_IG87
       jmp      G_M000_IG115
 
G_M000_IG92:                ;; offset=0x07F8
       mov      eax, r14d
       jmp      G_M000_IG31
 
G_M000_IG93:                ;; offset=0x0800
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG79
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0819
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG95:                ;; offset=0x081C
       mov      gword ptr [rbp-0x80], rcx
       mov      rsi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x2C]
       mov      rcx, gword ptr [rbp-0x80]
       jmp      G_M000_IG79
 
G_M000_IG96:                ;; offset=0x0835
       mov      esi, dword ptr [rbp-0x34]
       and      esi, 3
       dec      esi
       cmp      esi, 2
       ja       G_M000_IG82
       mov      gword ptr [rbp-0x80], rcx
       lea      rdi, [reloc @RWD00]
       mov      dword ptr [rbp-0x6C], r11d
       mov      dword ptr [rbp-0x2C], eax
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rcx, G_M000_IG02
       add      rdi, rcx
       jmp      rdi
 
G_M000_IG97:                ;; offset=0x0867
       mov      rax, r10
       jmp      SHORT G_M000_IG101
 
G_M000_IG98:                ;; offset=0x086C
       mov      rcx, r10
       jmp      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0871
       mov      esi, dword ptr [r9]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      r10, bword ptr [rbp-0x88]
       add      r10, 4
       mov      eax, dword ptr [rbp-0x58]
       lea      r11d, [rax-0x04]
       mov      rcx, r10
       mov      dword ptr [rbp-0x6C], r11d
 
G_M000_IG100:                ;; offset=0x0897
       mov      bword ptr [rbp-0x90], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0x90]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0x6C]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0x6C], edx
 
G_M000_IG101:                ;; offset=0x08C1
       mov      bword ptr [rbp-0x90], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0x90]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x6C]
       add      edx, -4
       mov      r10, rax
       mov      r11d, edx
       mov      eax, dword ptr [rbp-0x2C]
       mov      rcx, gword ptr [rbp-0x80]
       jmp      G_M000_IG82
 
G_M000_IG102:                ;; offset=0x08F7
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG103:                ;; offset=0x08FE
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       jmp      G_M000_IG13
 
G_M000_IG104:                ;; offset=0x0909
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG16
 
G_M000_IG105:                ;; offset=0x091D
       mov      rsi, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG16
 
G_M000_IG106:                ;; offset=0x092C
       test     r9d, r9d
       jne      SHORT G_M000_IG102
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG35
 
G_M000_IG107:                ;; offset=0x093C
       or       r9d, edi
       jne      SHORT G_M000_IG102
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG33
 
G_M000_IG108:                ;; offset=0x094C
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG24
 
G_M000_IG109:                ;; offset=0x0960
       mov      rsi, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG24
 
G_M000_IG110:                ;; offset=0x096F
       xor      esi, esi
       add      r11, -16
       je       SHORT G_M000_IG114
 
G_M000_IG111:                ;; offset=0x0977
       vmovups  xmm0, xmmword ptr [r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdi]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      G_M000_IG14
 
G_M000_IG112:                ;; offset=0x0991
       add      rsi, 16
       cmp      r11, rsi
       jbe      SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x099A
       vmovups  xmm0, xmmword ptr [r9+rsi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdi+rsi]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      G_M000_IG14
       jmp      SHORT G_M000_IG112
 
G_M000_IG114:                ;; offset=0x09B8
       vmovups  xmm0, xmmword ptr [r9+r11]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdi+r11]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      G_M000_IG14
       jmp      G_M000_IG29
 
G_M000_IG115:                ;; offset=0x09DA
       mov      eax, -1
 
G_M000_IG116:                ;; offset=0x09DF
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG117:                ;; offset=0x09F4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000839h ; case G_M000_IG99
       	dd	00000834h ; case G_M000_IG98
       	dd	0000082Fh ; case G_M000_IG97

; Total bytes of code 2554

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 186336
; 81 inlinees with PGO data; 188 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 648
       lea      rbp, [rsp+0x2B0]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x110], xmm8
       mov      rax, -192
 
G_M000_IG294:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG294
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x170], rdi
       mov      gword ptr [rbp-0x178], rsi
       mov      bword ptr [rbp-0x180], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x006D
       mov      r15d, dword ptr [rdi+0x60]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0079
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG235
 
G_M000_IG04:                ;; offset=0x008D
       mov      eax, dword ptr [rcx+0x14]
 
G_M000_IG05:                ;; offset=0x0090
       cmp      r15d, eax
       jne      G_M000_IG19
       mov      rdi, bword ptr [rbp-0x170]
       cmp      gword ptr [rdi+0x40], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rdi]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x00BB
       test     rbx, rbx
       je       G_M000_IG236
 
G_M000_IG07:                ;; offset=0x00C4
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG21
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00D8
       test     rax, rax
       sete     r15b
       movzx    r15, r15b
 
G_M000_IG09:                ;; offset=0x00E3
       test     r15d, r15d
       je       G_M000_IG232
       mov      rax, gword ptr [rdi+0x20]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG260
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rsi, 0x7FBFAD8016E8
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG237
 
G_M000_IG10:                ;; offset=0x011B
       mov      rdx, gword ptr [rax]
       mov      rsi, 0x7FBFAD8016F0
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG238
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG239
       mov      r14, gword ptr [rax]
 
G_M000_IG11:                ;; offset=0x013F
       test     r14, r14
       je       G_M000_IG240
       mov      rax, 0x7FCF57EDBAF8
       cmp      qword ptr [r14], rax
       jne      G_M000_IG232
 
G_M000_IG12:                ;; offset=0x015B
       mov      gword ptr [rbp-0x188], r14
       mov      rax, gword ptr [rbp-0x188]
       mov      rax, gword ptr [rax+0x08]
       mov      r14, gword ptr [rbp-0x178]
       mov      rdx, gword ptr [r14+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG232
       mov      rdi, bword ptr [rbp-0x170]
       mov      ebx, dword ptr [rdi+0x18]
       mov      dword ptr [rbp-0x2C], ebx
       mov      rcx, bword ptr [rbp-0x180]
       cmp      dword ptr [rcx+0x1C], 68
       jne      G_M000_IG241
       mov      r15d, dword ptr [rcx+0x0C]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG260
       mov      esi, r15d
       shl      rsi, 5
       lea      rdx, bword ptr [rdx+rsi+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG242
       mov      esi, dword ptr [rdx+0x08]
       mov      rdx, 0x7FCF57BE21C0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG244
       cmp      dword ptr [rax+0x08], esi
       jbe      G_M000_IG243
       mov      edx, esi
       mov      r13, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG13:                ;; offset=0x0204
       mov      gword ptr [rbp-0x190], r13
       mov      rdi, bword ptr [rbp-0x170]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rax, rsi
       lea      edx, [rbx+0x02]
       mov      r8d, dword ptr [rax+0x08]
       cmp      edx, r8d
       jae      G_M000_IG260
       lea      edx, [rbx+0x02]
       shl      rdx, 5
       lea      r12, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x198], r12
       mov      rax, rsi
       lea      edx, [r15+0x01]
       cmp      edx, r8d
       jae      G_M000_IG260
       lea      edx, [r15+0x01]
       shl      rdx, 5
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, rsi
       lea      r9d, [r15+0x02]
       cmp      r9d, r8d
       jae      G_M000_IG260
       lea      r9d, [r15+0x02]
       shl      r9, 5
       lea      rdx, bword ptr [rdx+r9+0x10]
       mov      bword ptr [rbp-0x1A0], rdx
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x30]
       mov      r9, rdx
       lea      r10d, [rbx+0x04]
       cmp      r10d, r8d
       jae      G_M000_IG260
       lea      r8d, [rbx+0x04]
       shl      r8, 5
       lea      r8, bword ptr [rsi+r8+0x10]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 35
       jg       G_M000_IG246
       cmp      esi, 35
       ja       G_M000_IG245
       mov      r10, 0x7FFFFFFBD
       bt       r10, rsi
       jb       G_M000_IG245
 
G_M000_IG14:                ;; offset=0x02D1
       mov      esi, dword ptr [r8+0x08]
       cmp      esi, dword ptr [r9+0x08]
       jae      G_M000_IG260
       mov      r8, gword ptr [r9+8*rsi+0x10]
       mov      gword ptr [rbp-0x1A8], r8
       mov      esi, dword ptr [rax+0x0C]
       not      esi
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG260
       mov      rax, gword ptr [rdx+8*rsi+0x10]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rsi, 0x7FCF5777B020
       cmp      qword ptr [rax], rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0314
       mov      rsi, rax
       mov      rdi, 0x7FCF5777B020
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x1D0]
 
G_M000_IG16:                ;; offset=0x032D
       mov      rdx, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x238], rdx
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x120], eax
       mov      rdi, bword ptr [rbp-0x170]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x1A0]
       mov      r10d, dword ptr [r9+0x0C]
       cmp      r10d, dword ptr [rsi+0x08]
       jae      G_M000_IG260
       shl      r10, 4
       lea      rsi, bword ptr [rsi+r10+0x10]
       mov      r10, gword ptr [rsi]
       mov      r11, 0x7FBFAD8016E8
       cmp      r10, gword ptr [r11]
       je       G_M000_IG247
 
G_M000_IG17:                ;; offset=0x0380
       mov      r10, gword ptr [rsi]
       mov      r11, 0x7FBFAD8016F0
       cmp      r10, gword ptr [r11]
       je       G_M000_IG248
       cmp      qword ptr [rsi+0x08], 0
       jne      G_M000_IG249
       mov      r10, gword ptr [rsi]
 
G_M000_IG18:                ;; offset=0x03A4
       test     r10, r10
       jne      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x03A9
       xor      eax, eax
 
G_M000_IG20:                ;; offset=0x03AB
       vzeroupper 
       add      rsp, 648
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x03C0
       xor      r15d, r15d
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x03C8
       mov      rsi, 0x7FCF57BE98D0
       cmp      qword ptr [r10], rsi
       jne      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x03D7
       mov      gword ptr [rbp-0x1B0], r10
       cmp      gword ptr [r10+0x28], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r10+0x30], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG19
       cmp      dword ptr [r10+0x50], 0
       jne      SHORT G_M000_IG19
       mov      rsi, gword ptr [r10+0x10]
       mov      r11, gword ptr [r14+0x98]
       cmp      rsi, gword ptr [r11+0x88]
       jne      SHORT G_M000_IG19
       lea      r11d, [r15+0x03]
       mov      dword ptr [rbp-0x30], r11d
       mov      rdi, bword ptr [rbp-0x170]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x88]
       cmp      r11d, dword ptr [rsi+0x08]
       jae      G_M000_IG260
       mov      r8d, r11d
       shl      r8, 5
       lea      rsi, bword ptr [rsi+r8+0x10]
       mov      bword ptr [rbp-0x1B8], rsi
       mov      rsi, bword ptr [rbp-0x1B8]
       cmp      dword ptr [rsi+0x1C], 47
       sete     r8b
       movzx    r8, r8b
       mov      dword ptr [rbp-0x34], r8d
       xor      esi, esi
       mov      qword ptr [rbp-0x40], rsi
 
G_M000_IG24:                ;; offset=0x0461
       test     r8d, r8d
       je       G_M000_IG31
 
G_M000_IG25:                ;; offset=0x046A
       mov      rsi, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x1B8]
       mov      r9d, dword ptr [r9+0x10]
       cmp      r9d, dword ptr [rsi+0x08]
       jae      G_M000_IG260
       shl      r9, 4
       lea      r9, bword ptr [rsi+r9+0x10]
       mov      bword ptr [rbp-0x1E0], r9
       mov      rsi, gword ptr [r9]
       mov      r11, 0x7FBFAD8016E8
       cmp      rsi, gword ptr [r11]
       jne      G_M000_IG250
 
G_M000_IG26:                ;; offset=0x04A9
       mov      r9, qword ptr [r9+0x08]
       mov      qword ptr [rbp-0x40], r9
 
G_M000_IG27:                ;; offset=0x04B1
       mov      rsi, 0xFF80000000000000
       cmp      qword ptr [rbp-0x40], rsi
       jl       G_M000_IG19
       mov      rsi, 0x80000000000000
       cmp      qword ptr [rbp-0x40], rsi
       jge      G_M000_IG19
       mov      rdi, bword ptr [rbp-0x170]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x30]
       mov      r9, bword ptr [rbp-0x1B8]
       mov      r11d, dword ptr [r9+0x0C]
       not      r11d
       cmp      r11d, dword ptr [rsi+0x08]
       jae      G_M000_IG260
       mov      r11, gword ptr [rsi+8*r11+0x10]
       mov      gword ptr [rbp-0x1D8], r11
       mov      rsi, 0x7FCF5777B020
       cmp      qword ptr [r11], rsi
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x051A
       mov      rsi, r11
       mov      rdi, 0x7FCF5777B020
       call     CORINFO_HELP_UNBOX
       mov      r11, gword ptr [rbp-0x1D8]
 
G_M000_IG29:                ;; offset=0x0533
       mov      rsi, gword ptr [r11+0x08]
       mov      r11d, dword ptr [r11+0x10]
       test     rsi, rsi
       jne      G_M000_IG255
       movsxd   rsi, r11d
 
G_M000_IG30:                ;; offset=0x0547
       mov      qword ptr [rbp-0x48], rsi
       mov      rdi, bword ptr [rbp-0x170]
 
G_M000_IG31:                ;; offset=0x0552
       xor      r11, r11
       mov      bword ptr [rbp-0x240], r11
 
G_M000_IG32:                ;; offset=0x055C
       mov      dword ptr [rbp-0x124], r11d
 
G_M000_IG33:                ;; offset=0x0563
       mov      gword ptr [rbp-0x1C0], r11
 
G_M000_IG34:                ;; offset=0x056A
       mov      dword ptr [rbp-0x4C], r11d
 
G_M000_IG35:                ;; offset=0x056E
       mov      dword ptr [rbp-0x50], r11d
 
G_M000_IG36:                ;; offset=0x0572
       mov      dword ptr [rbp-0x54], r11d
 
G_M000_IG37:                ;; offset=0x0576
       xor      r11, r11
       xor      r9d, r9d
       xor      r8, r8
       mov      r12, gword ptr [rbp-0x188]
       mov      r12d, dword ptr [r12+0x34]
       mov      rax, gword ptr [rbp-0x188]
       cmp      r12d, dword ptr [rax+0x30]
       je       G_M000_IG110
 
G_M000_IG38:                ;; offset=0x059C
       mov      rax, gword ptr [rbp-0x188]
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       je       G_M000_IG151
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG39:                ;; offset=0x05BB
       mov      rdx, gword ptr [rbp-0x188]
       add      rdx, 52
       mov      esi, dword ptr [rdx]
       add      esi, 4
       mov      r13d, dword ptr [rdx]
       cmp      r13d, eax
       mov      bword ptr [rbp-0x250], r12
       ja       G_M000_IG224
       mov      r12d, r13d
       add      r12, bword ptr [rbp-0x250]
       sub      eax, r13d
       cmp      eax, 4
       jl       G_M000_IG225
       mov      eax, dword ptr [r12]
       lea      r13d, [rsi+rax]
       mov      dword ptr [rdx], r13d
       mov      r13d, dword ptr [rdx]
       cmp      eax, 0x1000
       jg       G_M000_IG153
       mov      r11, gword ptr [rbp-0x188]
       mov      r9, gword ptr [r11+0x10]
       test     r9, r9
       je       G_M000_IG152
       mov      edx, esi
       mov      r11d, eax
       add      rdx, r11
       mov      r11d, dword ptr [r9+0x08]
       cmp      rdx, r11
       ja       G_M000_IG224
       lea      r11, bword ptr [r9+rsi+0x10]
       mov      r9d, eax
 
G_M000_IG40:                ;; offset=0x063E
       mov      bword ptr [rbp-0x248], r11
       mov      dword ptr [rbp-0x128], r9d
 
G_M000_IG41:                ;; offset=0x064C
       mov      r12, bword ptr [rbp-0x248]
       mov      bword ptr [rbp-0x240], r12
       mov      r13d, dword ptr [rbp-0x128]
       mov      dword ptr [rbp-0x124], r13d
       mov      gword ptr [rbp-0x1C8], r8
       mov      gword ptr [rbp-0x1C0], r8
       cmp      dword ptr [rbp-0x50], 0
       je       G_M000_IG131
 
G_M000_IG42:                ;; offset=0x0680
       mov      dword ptr [rdi+0x18], r15d
 
G_M000_IG43:                ;; offset=0x0684
       cmp      gword ptr [rbp-0x1C8], 0
       jne      G_M000_IG219
       mov      dword ptr [rbp-0x134], r13d
       mov      rdx, gword ptr [rbp-0x190]
       mov      r8, gword ptr [rdx+0x18]
       mov      gword ptr [rbp-0x1E8], r8
       mov      rsi, gword ptr [r14+0x98]
       mov      r9, gword ptr [rsi+0x88]
       cmp      gword ptr [r9+0x20], 0
       jne      G_M000_IG157
       mov      r9, gword ptr [rsi+0x180]
       test     r9, r9
       jne      G_M000_IG156
 
G_M000_IG44:                ;; offset=0x06D4
       mov      r10, gword ptr [rbp-0x1B0]
       mov      rsi, gword ptr [r10+0x28]
       mov      gword ptr [rbp-0x1F0], rsi
       mov      r9d, dword ptr [r10+0x4C]
       mov      dword ptr [rbp-0x6C], r9d
       mov      bword ptr [rbp-0x258], r12
       cmp      r9d, 4
       jle      G_M000_IG158
 
G_M000_IG45:                ;; offset=0x06FF
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       xor      edx, edx
       mov      dword ptr [rbp-0x94], edx
       cmp      edx, r13d
       jl       G_M000_IG145
 
G_M000_IG46:                ;; offset=0x0728
       mov      eax, dword ptr [rbp-0x74]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG109
 
G_M000_IG47:                ;; offset=0x0739
       mov      r8d, 0xFFFFFFFF8E1204ED
 
G_M000_IG48:                ;; offset=0x073F
       lea      eax, [r8+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG52
 
G_M000_IG49:                ;; offset=0x0747
       imul     r8d, dword ptr [rbp-0x80], 0xFFFFFFFFC2B2AE3D
       add      eax, r8d
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0760
       imul     r8d, dword ptr [rbp-0x7C], 0xFFFFFFFFC2B2AE3D
       add      r8d, eax
       rol      r8d, 17
       imul     eax, r8d, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x077B
       imul     edx, dword ptr [rbp-0x78], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG52:                ;; offset=0x078D
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       cmp      eax, -1
       je       G_M000_IG176
 
G_M000_IG53:                ;; offset=0x07B7
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      ebx, eax
       cmp      dword ptr [rbp-0x6C], 0
       je       G_M000_IG197
 
G_M000_IG54:                ;; offset=0x07D7
       mov      r11d, dword ptr [rsi+0x08]
       mov      r8d, r11d
       mov      r9d, r8d
       blsr     eax, r9d
       jne      G_M000_IG177
       dec      r9d
       and      r9d, ebx
 
G_M000_IG55:                ;; offset=0x07F2
       mov      dword ptr [rbp-0x154], r8d
       cmp      r9d, r8d
       jae      G_M000_IG229
       mov      eax, r9d
       lea      rax, [rax+4*rax]
       mov      eax, dword ptr [rsi+8*rax+0x30]
       dec      eax
       mov      dword ptr [rbp-0x70], eax
       test     eax, eax
       jl       G_M000_IG179
       jmp      G_M000_IG105
 
G_M000_IG56:                ;; offset=0x081F
       mov      r11, 0x7FCF578AFBC0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG103
 
G_M000_IG57:                ;; offset=0x0832
       movzx    r11, byte  ptr [rdx+0x24]
       test     r11d, r11d
       je       G_M000_IG86
 
G_M000_IG58:                ;; offset=0x0840
       cmp      r11d, 255
       je       G_M000_IG84
 
G_M000_IG59:                ;; offset=0x084D
       lea      r11, bword ptr [rdx+0x28]
       mov      edx, dword ptr [rdx+0x18]
       cmp      edx, 8
       ja       G_M000_IG224
 
G_M000_IG60:                ;; offset=0x085D
       mov      bword ptr [rbp-0x270], r11
       mov      dword ptr [rbp-0x13C], edx
       cmp      edx, dword ptr [rbp-0x134]
       jne      G_M000_IG183
       xor      r11d, r11d
       mov      dword ptr [rbp-0xA4], r11d
       cmp      r11d, dword ptr [rbp-0x134]
       jge      G_M000_IG70
 
G_M000_IG61:                ;; offset=0x088D
       mov      bword ptr [rbp-0x248], r12
 
G_M000_IG62:                ;; offset=0x0894
       mov      rdx, gword ptr [r14+0x98]
       mov      r12, gword ptr [rdx+0x88]
       cmp      gword ptr [r12+0x20], 0
       jne      G_M000_IG185
       mov      r12, gword ptr [rdx+0x180]
       test     r12, r12
       jne      G_M000_IG184
 
G_M000_IG63:                ;; offset=0x08BE
       mov      r12d, dword ptr [rbp-0x134]
       mov      r11d, dword ptr [rbp-0xA4]
       mov      edx, r12d
       sub      edx, r11d
       cmp      edx, 0x1000
       jge      G_M000_IG88
 
G_M000_IG64:                ;; offset=0x08DE
       mov      dword ptr [rbp-0xA8], edx
       mov      edx, r11d
       mov      r12d, dword ptr [rbp-0xA8]
       mov      qword ptr [rbp-0x160], r12
       add      rdx, r12
       mov      qword ptr [rbp-0x148], rdx
       mov      edx, dword ptr [rbp-0x134]
       cmp      qword ptr [rbp-0x148], rdx
       ja       G_M000_IG224
       mov      edx, r11d
       add      rdx, bword ptr [rbp-0x258]
       mov      bword ptr [rbp-0x278], rdx
       mov      r12d, dword ptr [rbp-0x13C]
       cmp      qword ptr [rbp-0x148], r12
       ja       G_M000_IG224
       mov      r12d, r11d
       add      r12, bword ptr [rbp-0x270]
       mov      bword ptr [rbp-0x280], r12
       mov      bword ptr [rbp-0x200], rdx
       mov      bword ptr [rbp-0x208], r12
       mov      rdx, qword ptr [rbp-0x160]
       cmp      rdx, 8
       jae      G_M000_IG94
 
G_M000_IG65:                ;; offset=0x0967
       cmp      rdx, 4
       jb       G_M000_IG89
 
G_M000_IG66:                ;; offset=0x0971
       add      rdx, -4
       mov      qword ptr [rbp-0xD8], rdx
       mov      rdx, bword ptr [rbp-0x278]
       mov      edx, dword ptr [rdx]
       sub      edx, dword ptr [r12]
       mov      dword ptr [rbp-0x294], edx
       mov      rdx, bword ptr [rbp-0x278]
       mov      r12, qword ptr [rbp-0xD8]
       mov      edx, dword ptr [rdx+r12]
       mov      rcx, bword ptr [rbp-0x280]
       sub      edx, dword ptr [rcx+r12]
       or       edx, dword ptr [rbp-0x294]
       sete     dl
       movzx    rdx, dl
 
G_M000_IG67:                ;; offset=0x09B8
       test     edx, edx
       je       G_M000_IG186
 
G_M000_IG68:                ;; offset=0x09C0
       add      r11d, dword ptr [rbp-0xA8]
       mov      r12d, dword ptr [rbp-0x134]
       cmp      r11d, r12d
       mov      dword ptr [rbp-0xA4], r11d
       jl       G_M000_IG62
 
G_M000_IG69:                ;; offset=0x09DE
       mov      r12, bword ptr [rbp-0x248]
 
G_M000_IG70:                ;; offset=0x09E5
       mov      eax, dword ptr [rbp-0x70]
 
G_M000_IG71:                ;; offset=0x09E8
       mov      byte  ptr [rbp-0x12C], 0
       xor      r9d, r9d
       mov      dword ptr [rbp-0x130], r9d
       test     eax, eax
       jl       G_M000_IG198
 
G_M000_IG72:                ;; offset=0x0A01
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r8d, dword ptr [rsi+0x08]
       mov      r8d, eax
       lea      r8, [r8+4*r8]
       lea      rsi, bword ptr [rsi+8*r8+0x10]
       mov      dword ptr [rbp-0x68], eax
       mov      ebx, eax
       mov      r11, gword ptr [rsi]
       mov      r9, r11
       test     r9, r9
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0A28
       mov      rdx, 0x7FCF578AFBC0
       cmp      qword ptr [r9], rdx
       jne      G_M000_IG202
 
G_M000_IG74:                ;; offset=0x0A3B
       mov      gword ptr [rbp-0x218], r9
       mov      r11d, dword ptr [rsi+0x18]
       mov      dword ptr [rbp-0x11C], r11d
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
       mov      r10, gword ptr [rbp-0x1B0]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG203
       mov      rsi, gword ptr [r10+0x30]
       cmp      ebx, dword ptr [rsi+0x08]
       jae      G_M000_IG229
       mov      edx, ebx
       cmp      gword ptr [rsi+8*rdx+0x10], 0
       jne      G_M000_IG203
 
G_M000_IG75:                ;; offset=0x0A86
       mov      rsi, gword ptr [r10+0x28]
       cmp      ebx, dword ptr [rsi+0x08]
       jae      G_M000_IG229
       mov      rdx, qword ptr [rsi+8*r8+0x20]
       mov      rsi, rdx
       mov      rdx, 0xFF80000000000000
       cmp      rsi, rdx
       jl       G_M000_IG205
       mov      rdx, 0x80000000000000
       cmp      rsi, rdx
       mov      qword ptr [rbp-0x100], rsi
       jge      G_M000_IG205
 
G_M000_IG76:                ;; offset=0x0AC8
       mov      rdi, gword ptr [rbp-0x238]
       mov      esi, dword ptr [rbp-0x120]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       add      rsi, qword ptr [rbp-0x100]
       mov      rax, gword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x104], ecx
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG214
       mov      rdi, gword ptr [rax+0x28]
       cmp      ebx, dword ptr [rdi+0x08]
       jae      G_M000_IG229
       mov      edx, ebx
       lea      rdx, [rdx+4*rdx]
       mov      qword ptr [rdi+8*rdx+0x20], rsi
       mov      rdi, gword ptr [rax+0x30]
       cmp      ebx, dword ptr [rdi+0x08]
       jae      G_M000_IG229
       mov      esi, ebx
       xor      rdx, rdx
       mov      gword ptr [rdi+8*rsi+0x10], rdx
 
G_M000_IG77:                ;; offset=0x0B2E
       mov      rax, gword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0x104]
       cmp      dword ptr [rax+0x4C], ecx
       jne      G_M000_IG215
 
G_M000_IG78:                ;; offset=0x0B44
       mov      ecx, 1
 
G_M000_IG79:                ;; offset=0x0B49
       movzx    rdx, byte  ptr [rbp-0x12C]
       test     edx, edx
       jne      G_M000_IG216
 
G_M000_IG80:                ;; offset=0x0B58
       test     ecx, ecx
       je       G_M000_IG226
 
G_M000_IG81:                ;; offset=0x0B60
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0B66
       mov      rdx, qword ptr [rbp-0x48]
       mov      rsi, rdx
       add      rsi, qword ptr [rbp-0x40]
       mov      qword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x4C], 1
       mov      rsi, 0xFF80000000000000
       cmp      qword ptr [rbp-0x40], rsi
       jl       G_M000_IG227
       mov      rsi, 0x80000000000000
       cmp      qword ptr [rbp-0x40], rsi
       jge      G_M000_IG227
 
G_M000_IG83:                ;; offset=0x0BA4
       mov      rdi, bword ptr [rbp-0x170]
       mov      ebx, dword ptr [rbp-0x2C]
       mov      dword ptr [rdi+0x18], ebx
       mov      r8, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [r8]
       mov      r9, gword ptr [r14+0x98]
       mov      r10, gword ptr [r9+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG223
       mov      r10, gword ptr [r9+0x180]
       test     r10, r10
       mov      gword ptr [rbp-0x288], r10
       mov      gword ptr [rbp-0x230], rsi
       mov      rdi, bword ptr [rbp-0x170]
       jne      G_M000_IG220
       mov      rsi, qword ptr [rbp-0x48]
       jmp      G_M000_IG37
 
G_M000_IG84:                ;; offset=0x0C02
       mov      r11, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x1F8], r11
       lea      r11, bword ptr [rdx+0x28]
       mov      r11d, dword ptr [r11]
       mov      edx, dword ptr [rdx+0x18]
       mov      dword ptr [rbp-0xAC], edx
       cmp      gword ptr [rbp-0x1F8], 0
       je       G_M000_IG182
       mov      qword ptr [rbp-0x150], r11
       mov      r11d, edx
       add      r11, qword ptr [rbp-0x150]
       mov      qword ptr [rbp-0x29C], r11
       mov      r11, gword ptr [rbp-0x1F8]
       mov      r11d, dword ptr [r11+0x08]
       cmp      qword ptr [rbp-0x29C], r11
       ja       G_M000_IG224
       mov      r11, gword ptr [rbp-0x1F8]
       mov      rdx, qword ptr [rbp-0x150]
       lea      r11, bword ptr [r11+rdx+0x10]
       mov      edx, dword ptr [rbp-0xAC]
 
G_M000_IG85:                ;; offset=0x0C74
       jmp      G_M000_IG60
 
G_M000_IG86:                ;; offset=0x0C79
       mov      r11, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x18]
       test     r11, r11
       je       G_M000_IG181
       cmp      dword ptr [r11+0x08], edx
       jb       G_M000_IG224
       add      r11, 16
 
G_M000_IG87:                ;; offset=0x0C97
       jmp      G_M000_IG60
 
G_M000_IG88:                ;; offset=0x0C9C
       mov      edx, 0x1000
       jmp      G_M000_IG64
 
G_M000_IG89:                ;; offset=0x0CA6
       xor      r12d, r12d
       mov      dword ptr [rbp-0xDC], r12d
       mov      r12, rdx
       and      r12, 2
       mov      qword ptr [rbp-0xE8], r12
       test     r12, r12
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0CC3
       mov      r12, bword ptr [rbp-0x278]
       movzx    r12, word  ptr [r12]
       mov      dword ptr [rbp-0x294], r12d
       mov      r12, bword ptr [rbp-0x280]
       movzx    r12, word  ptr [r12]
       movzx    rcx, dword ptr [rbp-0x294]
       sub      ecx, r12d
       mov      r12d, ecx
       mov      dword ptr [rbp-0xDC], r12d
 
G_M000_IG91:                ;; offset=0x0CF6
       test     dl, 1
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0CFB
       mov      rdx, bword ptr [rbp-0x278]
       mov      r12, qword ptr [rbp-0xE8]
       movzx    rdx, byte  ptr [rdx+r12]
       mov      dword ptr [rbp-0x294], edx
       mov      rdx, bword ptr [rbp-0x280]
       movzx    rdx, byte  ptr [rdx+r12]
       movzx    r12, dword ptr [rbp-0x294]
       sub      r12d, edx
       or       r12d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xDC], r12d
 
G_M000_IG93:                ;; offset=0x0D39
       cmp      dword ptr [rbp-0xDC], 0
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG67
 
G_M000_IG94:                ;; offset=0x0D4B
       mov      r12, bword ptr [rbp-0x200]
       cmp      r12, bword ptr [rbp-0x208]
       je       G_M000_IG68
 
G_M000_IG95:                ;; offset=0x0D5F
       cmp      rdx, 32
       jae      SHORT G_M000_IG98
 
G_M000_IG96:                ;; offset=0x0D65
       cmp      rdx, 16
       jae      G_M000_IG190
 
G_M000_IG97:                ;; offset=0x0D6F
       add      rdx, -8
       mov      qword ptr [rbp-0xB8], rdx
       mov      r12, bword ptr [rbp-0x278]
       mov      rdx, qword ptr [r12]
       mov      r12, bword ptr [rbp-0x280]
       sub      rdx, qword ptr [r12]
       mov      qword ptr [rbp-0x29C], rdx
       mov      rdx, bword ptr [rbp-0x278]
       mov      r12, qword ptr [rbp-0xB8]
       mov      rdx, qword ptr [rdx+r12]
       mov      rcx, bword ptr [rbp-0x280]
       sub      rdx, qword ptr [rcx+r12]
       or       rdx, qword ptr [rbp-0x29C]
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG67
 
G_M000_IG98:                ;; offset=0x0DC6
       xor      r12d, r12d
       add      rdx, -32
       mov      qword ptr [rbp-0xD0], rdx
       test     rdx, rdx
       je       SHORT G_M000_IG102
 
G_M000_IG99:                ;; offset=0x0DD9
       mov      rdx, bword ptr [rbp-0x200]
       vmovups  ymm0, ymmword ptr [rdx]
       mov      rdx, bword ptr [rbp-0x208]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG187
 
G_M000_IG100:                ;; offset=0x0DFC
       add      r12, 32
       cmp      qword ptr [rbp-0xD0], r12
       jbe      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0E09
       mov      rdx, bword ptr [rbp-0x200]
       vmovups  ymm0, ymmword ptr [rdx+r12]
       mov      rdx, bword ptr [rbp-0x208]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rdx+r12]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG188
       jmp      SHORT G_M000_IG100
 
G_M000_IG102:                ;; offset=0x0E32
       mov      r12, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0xD0]
       vmovups  ymm0, ymmword ptr [r12+rdx]
       mov      r12, bword ptr [rbp-0x208]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12+rdx]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG189
       jmp      G_M000_IG68
 
G_M000_IG103:                ;; offset=0x0E65
       mov      rsi, gword ptr [rbp-0x1F0]
 
G_M000_IG104:                ;; offset=0x0E6C
       mov      r9, bword ptr [rbp-0x290]
       mov      eax, dword ptr [r9+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x70], eax
       js       G_M000_IG197
 
G_M000_IG105:                ;; offset=0x0E82
       mov      rdx, gword ptr [r14+0x98]
       mov      r9, gword ptr [rdx+0x88]
       cmp      gword ptr [r9+0x20], 0
       jne      G_M000_IG180
       mov      r9, gword ptr [rdx+0x180]
       test     r9, r9
       jne      G_M000_IG178
 
G_M000_IG106:                ;; offset=0x0EAB
       mov      eax, dword ptr [rbp-0x70]
       cmp      eax, dword ptr [rbp-0x154]
       jae      G_M000_IG229
       mov      dword ptr [rbp-0x70], eax
       mov      edx, eax
       lea      rdx, [rdx+4*rdx]
       mov      rsi, gword ptr [rbp-0x1F0]
       lea      r9, bword ptr [rsi+8*rdx+0x10]
       mov      bword ptr [rbp-0x290], r9
       cmp      dword ptr [r9+0x18], ebx
       jne      SHORT G_M000_IG104
 
G_M000_IG107:                ;; offset=0x0EDC
       mov      rdx, gword ptr [rsi+8*rdx+0x10]
       test     rdx, rdx
       jne      G_M000_IG56
 
G_M000_IG108:                ;; offset=0x0EEA
       mov      rsi, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG104
 
G_M000_IG109:                ;; offset=0x0EF6
       rorx     r8d, dword ptr [rbp-0x90], 31
       rorx     r9d, dword ptr [rbp-0x8C], 25
       add      r8d, r9d
       rorx     r9d, dword ptr [rbp-0x88], 20
       add      r8d, r9d
       rorx     r9d, dword ptr [rbp-0x84], 14
       add      r8d, r9d
       jmp      G_M000_IG48
 
G_M000_IG110:                ;; offset=0x0F2C
       mov      dword ptr [rbp-0x54], 1
       mov      rcx, bword ptr [rbp-0x180]
       mov      esi, dword ptr [rcx+0x1C]
       cmp      esi, 51
       jg       G_M000_IG149
 
G_M000_IG111:                ;; offset=0x0F46
       cmp      esi, 41
       je       SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0F4B
       add      esi, -49
       cmp      esi, 2
       ja       G_M000_IG228
 
G_M000_IG113:                ;; offset=0x0F57
       mov      eax, dword ptr [rcx+0x08]
       mov      dword ptr [rdi+0x18], eax
 
G_M000_IG114:                ;; offset=0x0F5D
       mov      dword ptr [rbp-0x58], 1
       jmp      G_M000_IG230
 
G_M000_IG115:                ;; offset=0x0F69
       mov      r9d, dword ptr [r11]
       mov      dword ptr [rbp-0x9C], r9d
       mov      r9d, dword ptr [rbp-0x74]
       lea      ebx, [r9+0x01]
       mov      dword ptr [rbp-0x74], ebx
       mov      ebx, r9d
       and      ebx, 3
       je       G_M000_IG123
 
G_M000_IG116:                ;; offset=0x0F8A
       cmp      ebx, 1
       je       G_M000_IG122
 
G_M000_IG117:                ;; offset=0x0F93
       cmp      ebx, 2
       jne      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0F98
       mov      r9d, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x78], r9d
       jmp      G_M000_IG124
 
G_M000_IG119:                ;; offset=0x0FA8
       cmp      r9d, 3
       jne      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0FAE
       mov      r9, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x90], r9
       mov      r9, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x88], r9
 
G_M000_IG121:                ;; offset=0x0FD0
       imul     r9d, dword ptr [rbp-0x80], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x90]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x90], r9d
       imul     r9d, dword ptr [rbp-0x7C], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x8C]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x8C], r9d
       imul     r9d, dword ptr [rbp-0x78], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x88]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x88], r9d
       imul     r9d, dword ptr [rbp-0x9C], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x84]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x84], r9d
       jmp      SHORT G_M000_IG124
 
G_M000_IG122:                ;; offset=0x1059
       mov      r9d, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x7C], r9d
       jmp      SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x1066
       mov      r9d, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x80], r9d
 
G_M000_IG124:                ;; offset=0x1071
       add      r11, 4
       add      eax, -4
       mov      rbx, r11
       mov      r11, rbx
 
G_M000_IG125:                ;; offset=0x107E
       cmp      eax, 4
       jge      G_M000_IG115
 
G_M000_IG126:                ;; offset=0x1087
       mov      r9, r11
       mov      bword ptr [rbp-0x268], r9
       xor      r11d, r11d
       test     eax, eax
       je       G_M000_IG143
 
G_M000_IG127:                ;; offset=0x109C
       movzx    r9, byte  ptr [r9+r11]
       mov      dword ptr [rbp-0xA0], r9d
       mov      ebx, dword ptr [rbp-0x74]
       lea      r9d, [rbx+0x01]
       mov      dword ptr [rbp-0x74], r9d
       mov      r9d, ebx
       and      r9d, 3
       je       G_M000_IG141
 
G_M000_IG128:                ;; offset=0x10C0
       cmp      r9d, 1
       je       G_M000_IG140
 
G_M000_IG129:                ;; offset=0x10CA
       cmp      r9d, 2
       jne      G_M000_IG137
 
G_M000_IG130:                ;; offset=0x10D4
       mov      r9d, dword ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x78], r9d
       jmp      G_M000_IG142
 
G_M000_IG131:                ;; offset=0x10E4
       mov      rax, bword ptr [rbp-0x198]
       mov      rsi, gword ptr [rax]
       mov      rdx, gword ptr [r14+0x98]
       mov      r9, gword ptr [rdx+0x88]
       cmp      gword ptr [r9+0x20], 0
       jne      G_M000_IG155
       mov      r9, gword ptr [rdx+0x180]
       test     r9, r9
       jne      G_M000_IG154
 
G_M000_IG132:                ;; offset=0x1117
       mov      dword ptr [rdi+0x18], r15d
       mov      rdx, gword ptr [rbp-0x190]
       mov      rsi, gword ptr [rdx+0x18]
       mov      rdi, gword ptr [r14+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x50], 1
       jmp      G_M000_IG43
 
G_M000_IG133:                ;; offset=0x1141
       mov      r8d, 0x1000
       jmp      G_M000_IG147
 
G_M000_IG134:                ;; offset=0x114C
       cmp      dword ptr [rbp-0x74], 0
       jne      G_M000_IG170
       mov      r9, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x90], r9
       mov      r9, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x88], r9
 
G_M000_IG135:                ;; offset=0x1178
       cmp      eax, 16
       jl       G_M000_IG125
 
G_M000_IG136:                ;; offset=0x1181
       mov      r9d, dword ptr [rbp-0x90]
       imul     ebx, dword ptr [r11], 0xFFFFFFFF85EBCA77
       add      r9d, ebx
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x90], r9d
       mov      r9d, dword ptr [rbp-0x8C]
       lea      rbx, bword ptr [r11+0x04]
       imul     ebx, dword ptr [rbx], 0xFFFFFFFF85EBCA77
       add      r9d, ebx
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x8C], r9d
       mov      r9d, dword ptr [rbp-0x88]
       lea      rbx, bword ptr [r11+0x08]
       imul     ebx, dword ptr [rbx], 0xFFFFFFFF85EBCA77
       add      r9d, ebx
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x88], r9d
       mov      r9d, dword ptr [rbp-0x84]
       lea      rbx, bword ptr [r11+0x0C]
       imul     ebx, dword ptr [rbx], 0xFFFFFFFF85EBCA77
       add      r9d, ebx
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x84], r9d
       mov      r9d, dword ptr [rbp-0x74]
       add      r9d, 4
       mov      dword ptr [rbp-0x74], r9d
       add      r11, 16
       add      eax, -16
       mov      rbx, r11
       mov      r11, rbx
       jmp      G_M000_IG135
 
G_M000_IG137:                ;; offset=0x1234
       cmp      ebx, 3
       jne      SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x1239
       mov      rbx, 0xFDA767B39BDEE164
       mov      qword ptr [rbp-0x90], rbx
       mov      rbx, 0xD984238B77BB9D3C
       mov      qword ptr [rbp-0x88], rbx
 
G_M000_IG139:                ;; offset=0x125B
       imul     ebx, dword ptr [rbp-0x80], 0xFFFFFFFF85EBCA77
       add      ebx, dword ptr [rbp-0x90]
       rol      ebx, 13
       imul     ebx, ebx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x90], ebx
       imul     ebx, dword ptr [rbp-0x7C], 0xFFFFFFFF85EBCA77
       add      ebx, dword ptr [rbp-0x8C]
       rol      ebx, 13
       imul     ebx, ebx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x8C], ebx
       imul     ebx, dword ptr [rbp-0x78], 0xFFFFFFFF85EBCA77
       add      ebx, dword ptr [rbp-0x88]
       rol      ebx, 13
       imul     ebx, ebx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x88], ebx
       imul     r9d, dword ptr [rbp-0xA0], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x84]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x84], r9d
       jmp      SHORT G_M000_IG142
 
G_M000_IG140:                ;; offset=0x12D5
       mov      r9d, dword ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x7C], r9d
       jmp      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x12E2
       mov      r9d, dword ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x80], r9d
 
G_M000_IG142:                ;; offset=0x12ED
       inc      r11d
       cmp      r11d, eax
       mov      r9, bword ptr [rbp-0x268]
       jl       G_M000_IG127
 
G_M000_IG143:                ;; offset=0x1300
       mov      edx, dword ptr [rbp-0x94]
       add      edx, dword ptr [rbp-0x98]
       cmp      edx, r13d
       mov      dword ptr [rbp-0x94], edx
       jge      G_M000_IG46
 
G_M000_IG144:                ;; offset=0x131B
       mov      r9d, dword ptr [rbp-0x6C]
 
G_M000_IG145:                ;; offset=0x131F
       mov      r8, gword ptr [r14+0x98]
       mov      r11, gword ptr [r8+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG169
       mov      r11, gword ptr [r8+0x180]
       test     r11, r11
       jne      G_M000_IG168
 
G_M000_IG146:                ;; offset=0x1348
       mov      edx, dword ptr [rbp-0x94]
       mov      r8d, r13d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG133
 
G_M000_IG147:                ;; offset=0x1361
       mov      dword ptr [rbp-0x98], r8d
       mov      r11d, edx
       mov      eax, r8d
       add      rax, r11
       mov      r11d, r13d
       cmp      rax, r11
       ja       G_M000_IG224
       mov      dword ptr [rbp-0x94], edx
       mov      eax, edx
       mov      bword ptr [rbp-0x248], r12
       add      rax, r12
       mov      bword ptr [rbp-0x260], rax
       mov      r11, rax
       mov      eax, r8d
       cmp      r8d, 16
       mov      r12, bword ptr [rbp-0x248]
       jge      G_M000_IG134
 
G_M000_IG148:                ;; offset=0x13AD
       jmp      G_M000_IG125
 
G_M000_IG149:                ;; offset=0x13B2
       cmp      esi, 56
       je       G_M000_IG113
 
G_M000_IG150:                ;; offset=0x13BB
       cmp      esi, 62
       je       G_M000_IG113
       add      esi, -68
       cmp      esi, 1
       ja       G_M000_IG228
       jmp      G_M000_IG113
 
G_M000_IG151:                ;; offset=0x13D5
       xor      r12, r12
       mov      bword ptr [rbp-0x250], r12
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rsi
       mov      r12, bword ptr [rbp-0x250]
       jmp      G_M000_IG39
 
G_M000_IG152:                ;; offset=0x13F1
       or       esi, eax
       jne      G_M000_IG224
       xor      r11, r11
       xor      r9d, r9d
       jmp      G_M000_IG40
 
G_M000_IG153:                ;; offset=0x1404
       mov      dword ptr [rbp-0x128], r9d
       mov      bword ptr [rbp-0x248], r11
       mov      edx, eax
       mov      eax, r13d
       shl      rax, 32
       mov      esi, esi
       or       rsi, rax
       mov      rdi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ValueTuple`3[int,int,int]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      r13, rax
       mov      r8, r13
       mov      rdi, bword ptr [rbp-0x170]
       jmp      G_M000_IG41
 
G_M000_IG154:                ;; offset=0x143F
       cmp      dword ptr [r9+0x20], 0
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       je       G_M000_IG132
 
G_M000_IG155:                ;; offset=0x1455
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x170]
       jmp      G_M000_IG132
 
G_M000_IG156:                ;; offset=0x146A
       cmp      dword ptr [r9+0x20], 0
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       je       G_M000_IG44
 
G_M000_IG157:                ;; offset=0x1480
       mov      rdi, rsi
       mov      rsi, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp-0x1E8]
       jmp      G_M000_IG44
 
G_M000_IG158:                ;; offset=0x1498
       cmp      dword ptr [rbp-0x134], 8
       jg       G_M000_IG45
 
G_M000_IG159:                ;; offset=0x14A5
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       xor      r8d, r8d
       test     r9d, r9d
       jle      SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x14B2
       mov      r11d, dword ptr [rsi+0x08]
       cmp      r8d, r11d
       jae      G_M000_IG229
       mov      qword ptr [rbp-0x168], r8
       lea      r11, [r8+4*r8]
       mov      r11, gword ptr [rsi+8*r11+0x10]
       test     r11, r11
       jne      SHORT G_M000_IG162
       jmp      SHORT G_M000_IG165
 
G_M000_IG161:                ;; offset=0x14D6
       mov      ebx, dword ptr [rbp-0x64]
       jmp      G_M000_IG197
 
G_M000_IG162:                ;; offset=0x14DE
       mov      r8, 0x7FCF578AFBC0
       cmp      qword ptr [r11], r8
       jne      SHORT G_M000_IG165
 
G_M000_IG163:                ;; offset=0x14ED
       mov      rdi, r11
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      rsi, rax
       cmp      r13d, edx
       jne      SHORT G_M000_IG165
 
G_M000_IG164:                ;; offset=0x14FE
       mov      edx, edx
       mov      rdi, r12
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x150D
       mov      r8, qword ptr [rbp-0x168]
       inc      r8d
       mov      r9d, dword ptr [rbp-0x6C]
       cmp      r8d, r9d
       mov      rsi, gword ptr [rbp-0x1F0]
       jl       SHORT G_M000_IG160
 
G_M000_IG166:                ;; offset=0x1527
       mov      ebx, dword ptr [rbp-0x64]
       jmp      G_M000_IG197
 
G_M000_IG167:                ;; offset=0x152F
       mov      r8, qword ptr [rbp-0x168]
       mov      eax, r8d
       mov      ebx, dword ptr [rbp-0x64]
       jmp      G_M000_IG71
 
G_M000_IG168:                ;; offset=0x1541
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG146
 
G_M000_IG169:                ;; offset=0x1557
       mov      rdi, r8
       mov      rsi, gword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r9d, dword ptr [rbp-0x6C]
       jmp      G_M000_IG146
 
G_M000_IG170:                ;; offset=0x1577
       mov      r9d, dword ptr [rbp-0x74]
       and      r9d, 3
       dec      r9d
       cmp      r9d, 2
       ja       G_M000_IG135
       mov      bword ptr [rbp-0x248], r12
       mov      qword ptr [rbp-0x29C], r9
       lea      r9, [reloc @RWD00]
       mov      dword ptr [rbp-0x138], eax
       mov      rbx, qword ptr [rbp-0x29C]
       mov      r9d, dword ptr [r9+4*rbx]
       lea      r12, G_M000_IG02
       add      r9, r12
       jmp      r9
 
G_M000_IG171:                ;; offset=0x15BF
       mov      r12, r11
       mov      ebx, dword ptr [rbp-0x98]
       jmp      SHORT G_M000_IG175
 
G_M000_IG172:                ;; offset=0x15CA
       mov      r12, r11
       mov      ebx, dword ptr [rbp-0x98]
       jmp      SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x15D5
       mov      rbx, bword ptr [rbp-0x260]
       mov      esi, dword ptr [rbx]
       lea      rdi, [rbp-0x90]
       call     [System.HashCode:Add(int):this]
       add      rbx, 4
       mov      r11, rbx
       mov      ebx, dword ptr [rbp-0x98]
       lea      eax, [rbx-0x04]
       mov      r12, r11
       mov      dword ptr [rbp-0x138], eax
 
G_M000_IG174:                ;; offset=0x1604
       mov      esi, dword ptr [r12]
       lea      rdi, [rbp-0x90]
       call     [System.HashCode:Add(int):this]
       add      r12, 4
       mov      eax, dword ptr [rbp-0x138]
       add      eax, -4
       mov      dword ptr [rbp-0x138], eax
 
G_M000_IG175:                ;; offset=0x1628
       mov      esi, dword ptr [r12]
       lea      rdi, [rbp-0x90]
       call     [System.HashCode:Add(int):this]
       add      r12, 4
       mov      eax, dword ptr [rbp-0x138]
       add      eax, -4
       mov      r11, r12
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG135
 
G_M000_IG176:                ;; offset=0x165C
       mov      eax, -2
       jmp      G_M000_IG53
 
G_M000_IG177:                ;; offset=0x1666
       mov      eax, ebx
       xor      edx, edx
       div      edx:eax, r9d
       mov      r9d, edx
       jmp      G_M000_IG55
 
G_M000_IG178:                ;; offset=0x1675
       cmp      dword ptr [r9+0x20], 0
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       je       G_M000_IG106
       jmp      SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x168D
       mov      rsi, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG197
 
G_M000_IG180:                ;; offset=0x1699
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG106
 
G_M000_IG181:                ;; offset=0x16AE
       test     edx, edx
       jne      G_M000_IG224
       xor      r11, r11
       xor      edx, edx
       jmp      G_M000_IG87
 
G_M000_IG182:                ;; offset=0x16C0
       or       r11d, edx
       jne      G_M000_IG224
       xor      r11, r11
       xor      edx, edx
       jmp      G_M000_IG85
 
G_M000_IG183:                ;; offset=0x16D3
       mov      rsi, gword ptr [rbp-0x1F0]
       jmp      G_M000_IG104
 
G_M000_IG184:                ;; offset=0x16DF
       cmp      dword ptr [r12+0x20], 0
       setne    r12b
       movzx    r12, r12b
       test     r12d, r12d
       je       G_M000_IG63
 
G_M000_IG185:                ;; offset=0x16F6
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG63
 
G_M000_IG186:                ;; offset=0x170B
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG187:                ;; offset=0x171E
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG188:                ;; offset=0x1731
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG189:                ;; offset=0x1744
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG190:                ;; offset=0x1757
       xor      r12d, r12d
       mov      qword ptr [rbp-0xC0], r12
       add      rdx, -16
       mov      qword ptr [rbp-0xC8], rdx
       test     rdx, rdx
       je       G_M000_IG195
 
G_M000_IG191:                ;; offset=0x1775
       mov      r12, bword ptr [rbp-0x200]
       vmovups  xmm0, xmmword ptr [r12]
       mov      rdx, bword ptr [rbp-0x208]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rdx]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       je       SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x1799
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG193:                ;; offset=0x17AC
       mov      rdx, qword ptr [rbp-0xC0]
       add      rdx, 16
       cmp      qword ptr [rbp-0xC8], rdx
       ja       SHORT G_M000_IG194
       jmp      SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x17C2
       vmovups  xmm0, xmmword ptr [r12+rdx]
       mov      r12, bword ptr [rbp-0x208]
       mov      qword ptr [rbp-0xC0], rdx
       vpcmpeqb xmm0, xmm0, xmmword ptr [r12+rdx]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       mov      r12, bword ptr [rbp-0x200]
       je       SHORT G_M000_IG193
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG195:                ;; offset=0x1802
       mov      r12, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0xC8]
       vmovups  xmm0, xmmword ptr [r12+rdx]
       mov      r12, bword ptr [rbp-0x208]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r12+rdx]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       je       G_M000_IG68
 
G_M000_IG196:                ;; offset=0x1833
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r12, bword ptr [rbp-0x248]
       jmp      G_M000_IG104
 
G_M000_IG197:                ;; offset=0x1846
       mov      eax, -1
       jmp      G_M000_IG71
 
G_M000_IG198:                ;; offset=0x1850
       cmp      r13d, 8
       jle      SHORT G_M000_IG201
 
G_M000_IG199:                ;; offset=0x1856
       mov      r10, gword ptr [rbp-0x1B0]
       mov      eax, dword ptr [r10+0x4C]
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r8d, dword ptr [rsi+0x08]
       cmp      eax, r8d
       jge      SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x1871
       mov      edx, 1
       mov      dword ptr [rbp-0x130], ebx
       mov      dword ptr [rbp-0x12C], edx
 
G_M000_IG201:                ;; offset=0x1882
       xor      eax, eax
       mov      ecx, eax
       mov      rax, gword ptr [rbp-0x1B0]
       jmp      G_M000_IG79
 
G_M000_IG202:                ;; offset=0x1892
       mov      rsi, r11
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG203:                ;; offset=0x189E
       mov      rdi, r10
       mov      esi, ebx
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      gword ptr [rbp-0x210], rax
       test     rax, rax
       jne      SHORT G_M000_IG206
 
G_M000_IG204:                ;; offset=0x18B5
       mov      r10, gword ptr [rbp-0x1B0]
 
G_M000_IG205:                ;; offset=0x18BC
       xor      eax, eax
       mov      ecx, eax
       mov      rax, r10
       jmp      G_M000_IG79
 
G_M000_IG206:                ;; offset=0x18C8
       mov      rsi, qword ptr [rax]
       mov      rdi, 0x7FCF5777B020
       cmp      rsi, rdi
       je       SHORT G_M000_IG208
 
G_M000_IG207:                ;; offset=0x18DA
       mov      r10, gword ptr [rbp-0x1B0]
       jmp      SHORT G_M000_IG205
 
G_M000_IG208:                ;; offset=0x18E3
       mov      rdi, 0x7FCF5777B020
       cmp      rsi, rdi
       je       SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x18F2
       mov      rsi, rax
       mov      rdi, 0x7FCF5777B020
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x210]
 
G_M000_IG210:                ;; offset=0x190B
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG211:                ;; offset=0x1918
       lea      rdi, [rbp-0xF8]
       xor      esi, esi
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x192C
       mov      r10, gword ptr [rbp-0x1B0]
       jmp      SHORT G_M000_IG205
 
G_M000_IG213:                ;; offset=0x1935
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, qword ptr [rbp-0xF0]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x100], rax
       jmp      G_M000_IG76
 
G_M000_IG214:                ;; offset=0x1955
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
       lea      rdi, [rbp-0x118]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7FCF5777B020
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbp-0x118]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x110]
       mov      dword ptr [rbx+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, rbx
       mov      rdi, gword ptr [rbp-0x1B0]
       mov      esi, dword ptr [rbp-0x68]
       mov      rdx, gword ptr [rbp-0x218]
       mov      r8d, dword ptr [rbp-0x11C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG77
 
G_M000_IG215:                ;; offset=0x19C9
       inc      dword ptr [rax+0x48]
       jmp      G_M000_IG78
 
G_M000_IG216:                ;; offset=0x19D1
       mov      rbx, gword ptr [rbp-0x190]
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x220], rcx
       mov      rdx, gword ptr [r14+0x98]
       mov      gword ptr [rbp-0x228], rdx
       cmp      byte  ptr [rdx], dl
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG218
 
G_M000_IG217:                ;; offset=0x1A00
       mov      rdi, gword ptr [rbp-0x228]
       mov      rsi, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG218:                ;; offset=0x1A14
       mov      rsi, r12
       mov      edx, r13d
       mov      rdi, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      r13, gword ptr [rbp-0x238]
       mov      gword ptr [rsp], r13
       mov      r12d, dword ptr [rbp-0x120]
       mov      dword ptr [rsp+0x08], r12d
       mov      rdi, gword ptr [rbp-0x1B0]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      ecx, dword ptr [rbp-0x130]
       mov      r8, gword ptr [rbp-0x1A8]
       mov      esi, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      ecx, eax
       mov      rax, gword ptr [rbp-0x1B0]
       jmp      G_M000_IG80
 
G_M000_IG219:                ;; offset=0x1A79
       mov      r10, gword ptr [rbp-0x1B0]
       mov      r12d, dword ptr [rbp-0x120]
       mov      r13, gword ptr [rbp-0x238]
       mov      rax, gword ptr [rbp-0x190]
       mov      rsi, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rsi
       mov      rcx, r13
       mov      r8d, r12d
       mov      rdi, r10
       mov      rsi, gword ptr [rbp-0x1C8]
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      ecx, eax
       mov      rax, gword ptr [rbp-0x1B0]
       jmp      G_M000_IG80
 
G_M000_IG220:                ;; offset=0x1ACB
       mov      r11, r9
       mov      rsi, gword ptr [rbp-0x288]
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       mov      r9, r11
       mov      rsi, gword ptr [rbp-0x230]
       je       SHORT G_M000_IG222
       mov      ebx, dword ptr [rbp-0x2C]
 
G_M000_IG221:                ;; offset=0x1AF2
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x170]
       jmp      G_M000_IG37
 
G_M000_IG222:                ;; offset=0x1B0B
       mov      rsi, qword ptr [rbp-0x48]
       jmp      G_M000_IG37
 
G_M000_IG223:                ;; offset=0x1B14
       jmp      SHORT G_M000_IG221
 
G_M000_IG224:                ;; offset=0x1B16
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG225:                ;; offset=0x1B1D
       mov      edi, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG226:                ;; offset=0x1B29
       mov      ebx, dword ptr [rbp-0x2C]
       add      ebx, 2
       mov      rdi, bword ptr [rbp-0x170]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x180]
       mov      rdi, bword ptr [rbp-0x170]
       jmp      G_M000_IG114
 
G_M000_IG227:                ;; offset=0x1B4C
       mov      ebx, dword ptr [rbp-0x30]
       add      ebx, 2
       mov      rdi, bword ptr [rbp-0x170]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x180]
       jmp      G_M000_IG114
 
G_M000_IG228:                ;; offset=0x1B68
       mov      rdi, rcx
       mov      rsi, 0x7FCFD15B86F0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG229:                ;; offset=0x1B84
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG230:                ;; offset=0x1B8A
       call     G_M000_IG288
       nop      
 
G_M000_IG231:                ;; offset=0x1B90
       mov      ebx, dword ptr [rbp-0x58]
       jmp      SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x1B95
       mov      rdi, bword ptr [rbp-0x170]
       mov      rcx, bword ptr [rbp-0x180]
       mov      rsi, gword ptr [rbp-0x178]
       mov      rdx, rbx
       mov      r8d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG233:                ;; offset=0x1BB8
       movzx    rax, bl
 
G_M000_IG234:                ;; offset=0x1BBB
       vzeroupper 
       add      rsp, 648
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG235:                ;; offset=0x1BD0
       mov      rdi, rcx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp-0x180]
       jmp      G_M000_IG05
 
G_M000_IG236:                ;; offset=0x1BE5
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG237:                ;; offset=0x1BEC
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG238:                ;; offset=0x1BFD
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG239:                ;; offset=0x1C0E
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG11
 
G_M000_IG240:                ;; offset=0x1C1F
       mov      rdi, 0x7FCF5725C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7FCFD1599540
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG241:                ;; offset=0x1C4D
       mov      rdi, rcx
       mov      rsi, 0x7FCFD15BD3D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG242:                ;; offset=0x1C69
       mov      rdi, rdx
       mov      rsi, 0x7FCFD15B7BF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG243:                ;; offset=0x1C85
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG244:                ;; offset=0x1C8C
       mov      rdi, rax
       mov      r11, 0x7FCF55C228F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r13, rax
       jmp      G_M000_IG13
 
G_M000_IG245:                ;; offset=0x1CA4
       mov      rdi, r8
       mov      rsi, 0x7FCFD15B8668
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG246:                ;; offset=0x1CC0
       cmp      esi, 64
       je       G_M000_IG14
       cmp      esi, 67
       je       G_M000_IG14
       cmp      esi, 70
       jne      SHORT G_M000_IG245
       jmp      G_M000_IG14
 
G_M000_IG247:                ;; offset=0x1CDC
       mov      rdi, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG248:                ;; offset=0x1CED
       mov      rdi, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG249:                ;; offset=0x1CFE
       mov      rdi, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG250:                ;; offset=0x1D0F
       cmp      qword ptr [r9+0x08], 0
       jle      SHORT G_M000_IG253
 
G_M000_IG251:                ;; offset=0x1D16
       mov      rsi, gword ptr [r9]
       mov      rdi, 0x7FCF57CF2AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG252
       mov      rcx, bword ptr [rbp-0x1E0]
       mov      esi, dword ptr [rcx+0x08]
       dec      esi
       lea      rdx, [rbp-0x40]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG254
 
G_M000_IG252:                ;; offset=0x1D48
       mov      r9, bword ptr [rbp-0x1E0]
 
G_M000_IG253:                ;; offset=0x1D4F
       mov      rdi, gword ptr [r9]
       lea      rsi, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG254:                ;; offset=0x1D5C
       test     eax, eax
       je       G_M000_IG19
       jmp      G_M000_IG27
 
G_M000_IG255:                ;; offset=0x1D69
       cmp      dword ptr [rsi+0x08], 1
       jle      SHORT G_M000_IG256
       mov      rdi, 0x7FCF57D28130
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r12
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG256:                ;; offset=0x1D9C
       cmp      dword ptr [rsi+0x08], 0
       jbe      SHORT G_M000_IG260
       mov      rsi, qword ptr [rsi+0x10]
       mov      qword ptr [rbp-0x60], rsi
       neg      rsi
       test     r11d, r11d
       cmovg    rsi, qword ptr [rbp-0x60]
       test     rsi, rsi
       jle      SHORT G_M000_IG257
       test     r11d, r11d
       jg       SHORT G_M000_IG258
 
G_M000_IG257:                ;; offset=0x1DBF
       test     rsi, rsi
       jge      SHORT G_M000_IG259
       test     r11d, r11d
       jge      SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1DC9
       jmp      G_M000_IG30
 
G_M000_IG259:                ;; offset=0x1DCE
       mov      rdi, 0x7FCF57D28130
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r15
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG260:                ;; offset=0x1DFB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG261:                ;; offset=0x1E01
       sub      rsp, 24
 
G_M000_IG262:                ;; offset=0x1E05
       cmp      dword ptr [rbp-0x4C], 0
       je       SHORT G_M000_IG264
 
G_M000_IG263:                ;; offset=0x1E0B
       mov      rdi, bword ptr [rbp-0x170]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x1B8]
       mov      eax, dword ptr [r9+0x10]
       cmp      eax, dword ptr [rsi+0x08]
       jae      SHORT G_M000_IG268
       shl      rax, 4
       lea      rbx, bword ptr [rsi+rax+0x10]
       mov      r15, qword ptr [rbp-0x40]
       mov      rsi, 0x7FBFAD8016E8
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], r15
 
G_M000_IG264:                ;; offset=0x1E4C
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG266
 
G_M000_IG265:                ;; offset=0x1E52
       mov      rdi, bword ptr [rbp-0x170]
       add      rdi, 32
       mov      rcx, bword ptr [rbp-0x180]
       mov      esi, dword ptr [rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG266:                ;; offset=0x1E6D
       nop      
 
G_M000_IG267:                ;; offset=0x1E6E
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG268:                ;; offset=0x1E76
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG269:                ;; offset=0x1E7C
       sub      rsp, 24
 
G_M000_IG270:                ;; offset=0x1E80
       cmp      gword ptr [rbp-0x1C0], 0
       jne      SHORT G_M000_IG272
 
G_M000_IG271:                ;; offset=0x1E8A
       cmp      dword ptr [rbp-0x124], 0
       je       G_M000_IG286
 
G_M000_IG272:                ;; offset=0x1E97
       mov      rdi, bword ptr [rbp-0x170]
       mov      rax, gword ptr [rdi+0x08]
       mov      rdx, bword ptr [rbp-0x1A0]
       mov      ecx, dword ptr [rdx+0x1C]
       cmp      ecx, 9
       je       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x1EB1
       cmp      ecx, 10
       je       SHORT G_M000_IG274
       mov      rdi, rdx
       mov      rsi, 0x7FCFD15B8698
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG274:                ;; offset=0x1ED2
       mov      ecx, dword ptr [rdx+0x14]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG284
       shl      rcx, 4
       lea      r14, bword ptr [rax+rcx+0x10]
       mov      rsi, gword ptr [rbp-0x1C0]
       cmp      gword ptr [rbp-0x1C0], 0
       jne      G_M000_IG285
 
G_M000_IG275:                ;; offset=0x1EFC
       mov      ebx, dword ptr [rbp-0x124]
       add      rbx, 128
       mov      rax, gword ptr [rbp-0x188]
       cmp      rbx, qword ptr [rax+0x28]
       jle      SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x1F16
       mov      rdi, 0x7FCF5725C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdi, r14
       mov      rsi, 0x7FCFD15BD418
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG277:                ;; offset=0x1F44
       mov      rax, gword ptr [rbp-0x188]
       mov      r15, gword ptr [rax+0x08]
       mov      rdi, 0x7FCF578AFBC0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      dword ptr [r13+0x1C], -1
       cmp      dword ptr [rbp-0x124], 0
       jne      SHORT G_M000_IG279
 
G_M000_IG278:                ;; offset=0x1F72
       xor      edi, edi
       mov      rsi, 0x7FCFD1594B28
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG279:                ;; offset=0x1F85
       cmp      dword ptr [rbp-0x124], 8
       jg       SHORT G_M000_IG281
 
G_M000_IG280:                ;; offset=0x1F8E
       mov      esi, dword ptr [rbp-0x124]
       mov      byte  ptr [r13+0x24], sil
       jmp      SHORT G_M000_IG282
 
G_M000_IG281:                ;; offset=0x1F9A
       mov      esi, dword ptr [rbp-0x124]
       mov      rdi, 0x7FCF56F5CCD0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG282:                ;; offset=0x1FBB
       mov      edi, dword ptr [rbp-0x124]
       mov      dword ptr [r13+0x18], edi
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rdi, rax
       cmp      dword ptr [rbp-0x124], edx
       jg       SHORT G_M000_IG283
       mov      edx, dword ptr [rbp-0x124]
       mov      rsi, bword ptr [rbp-0x240]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rdi, r13
       mov      esi, dword ptr [rbp-0x124]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x188]
       sub      qword ptr [rax+0x28], rbx
       mov      rsi, r13
       jmp      SHORT G_M000_IG285
 
G_M000_IG283:                ;; offset=0x2017
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG284:                ;; offset=0x201E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG285:                ;; offset=0x2024
       mov      rdi, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [r14+0x08], rdi
 
G_M000_IG286:                ;; offset=0x2032
       call     G_M000_IG261
       nop      
 
G_M000_IG287:                ;; offset=0x2038
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG288:                ;; offset=0x2040
       sub      rsp, 24
 
G_M000_IG289:                ;; offset=0x2044
       cmp      dword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG292
 
G_M000_IG290:                ;; offset=0x204A
       mov      r14, gword ptr [rbp-0x178]
       mov      rdi, gword ptr [r14+0x98]
       mov      rax, qword ptr [rdi+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG292
 
G_M000_IG291:                ;; offset=0x2064
       dec      rax
       mov      qword ptr [rdi+0x160], rax
 
G_M000_IG292:                ;; offset=0x206E
       call     G_M000_IG269
       nop      
 
G_M000_IG293:                ;; offset=0x2074
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	00001568h ; case G_M000_IG173
       	dd	0000155Dh ; case G_M000_IG172
       	dd	00001552h ; case G_M000_IG171

; Total bytes of code 8316

