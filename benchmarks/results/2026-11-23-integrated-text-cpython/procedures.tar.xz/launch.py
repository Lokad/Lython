from pathlib import Path
import datetime
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "borrowed-cased-words-refined-20261123"
source = json.loads((repo / "benchmarks/results/2026-11-23-borrowed-cased-words-append/identity.json").read_text(encoding="utf-8"))
base = "/home/lokad/lython-bench-checks"
donor = "borrowed-cased-words-b1457-20261123"
root = "integrated-text-cpython-20261123"
unit = "lython-integrated-text-cpython-20261123"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo, encoding="utf-8").strip()
head = git("rev-parse", "HEAD")
assert not git("diff", "--name-only", source["retainedRevision"], head, "--", "src", "tests")
assert head == git("rev-parse", "origin/master")
catalog = lab / "representative.json"
jobs = lab / "jobs.json"
verified = json.loads((lab / "candidate-verify.json").read_text(encoding="utf-8"))
files = source["imageFiles"]["candidate"]
core = files["Lokad.Lython.dll"]
assert verified["state"] == "Completed" and verified["caseCount"] == 6 and verified["catalogSha256"] == sha(catalog)
assert verified["launched"]["library"]["sha256"] == core
assert len(files) == 32 and all(sha(prior / "candidate" / name) == digest for name,digest in files.items())
terminal = json.loads((prior / "comparison/quiet/terminal-status.json").read_text(encoding="utf-8"))
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
configuration = dict(sourceRevision=head, candidate=source["candidate"], retainedRevision=source["retainedRevision"],
    frozenImage=f"{base}/{donor}/candidate",
    imageFiles={"candidate":files}, coreSHA256={role:core for role in ("candidate","candidate-control")},
    auxiliaryFiles={name:digest for name,digest in files.items() if name!="Lokad.Lython.dll"},
    cpythonWorkerSHA256=source["cpythonWorkerSHA256"], expectedCPythonSHA256=source["expectedCPythonSHA256"],
    catalogs={path.name: dict(sha256=sha(path)) for path in (catalog,jobs)})
(lab / "identity.json").write_text(json.dumps(configuration, indent=2)+"\n",encoding="utf-8",newline="\n")
collector = lab / "collect.py"
source = collector.read_text(encoding="utf-8")
if "def digest(path)" not in source:
    source = source.replace("def check_image():", "def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()\n\ndef check_image():")
source = source.replace("str(root/('reference' if label.startswith('reference') else 'candidate')/'Lokad.Lython.Benchmarks.dll')", "str(worker)")
assert "candidate' else" not in source and "str(worker), '--compare', 'worker'" in source
compile(source, "collect.py", "exec")
collector.write_text(source,encoding="utf-8",newline="\n")
run = lab / "run.sh"
run.write_text("""set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
trap 'status=$?; printf "%s\\n" "$status" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
""",encoding="utf-8",newline="\n")
assert b"\r" not in run.read_bytes()
payload = lab / "payload.tar.gz"
names = {"identity.json","representative.json","jobs.json","collect.py","run.sh"}
if payload.exists():
    with tarfile.open(payload) as bundle:
        assert {member.name for member in bundle.getmembers()} == names
        assert all(bundle.extractfile(name).read() == (lab/name).read_bytes() for name in names)
else:
    with tarfile.open(payload,"w:gz") as bundle:
        for name in sorted(names):
            bundle.add(lab/name,arcname=name)
options=["-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15"]
host="lokad@20.166.121.73"
scp=["C:/Windows/System32/OpenSSH/scp.exe",*options]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*options,host,"python3 -"]
uploaded=f"{base}/.integrated-{sha(payload)[:12]}.tar.gz"
subprocess.run(scp+[str(payload),host+":"+uploaded],check=True,timeout=35)
params=dict(base=base, root=root, donor=donor, unit=unit, payload=uploaded, payloadSHA=sha(payload),
            previousSHA=terminal["receipt"]["archiveSHA256"], members=sorted(names))
recorded = "origin/master:benchmarks/results/2026-11-23-dispatch-known-call-semantics/"
archived = lambda name: subprocess.check_output(["git", "show", recorded + name], cwd=repo)
old_receipt = json.loads(archived("terminal-status.json"))["receipt"]
old_core = gzip.decompress(archived("candidate-core.dll.gz"))
old_hash = json.loads(archived("source.json"))["coreSHA256"]["candidate"]
assert hashlib.sha256(old_core).hexdigest() == old_hash
assert hashlib.sha256(archived("observations.tar.xz")).hexdigest() == old_receipt["archiveSHA256"]
params["retire"] = {"root":"dispatch-known-call-semantics-b1454-20261123", "hash":old_hash,
    "bytes":len(old_core), "observations":old_receipt["archiveSHA256"]}
body = """
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess, tarfile
base=Path(p['base']).resolve()
root=base/p['root']
donor=base/p['donor']
payload=Path(p['payload'])
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(donor/'observations.tar.xz')==p['previousSHA']
 assert digest(payload)==p['payloadSHA'] and payload.parent==base
 with tarfile.open(payload) as archive:
  assert {member.name for member in archive.getmembers()}==set(p['members'])
  block=os.statvfs(base).f_frsize
  needed=sum(((member.size+block-1)//block)*block for member in archive.getmembers())
  minimum=138*1024*1024 + needed + 512*1024
  free=shutil.disk_usage(base).free
  if free < minimum:
   old=base/p['retire']['root']
   assert old!=donor and old.is_relative_to(base)
   assert digest(old/'observations.tar.xz')==p['retire']['observations']
   replica=old/'candidate/Lokad.Lython.dll'
   facts=replica.lstat()
   assert replica.resolve()==replica and replica.is_relative_to(old)
   assert stat.S_ISREG(facts.st_mode) and facts.st_uid==os.getuid() and facts.st_nlink==1
   assert facts.st_size==p['retire']['bytes'] and digest(replica)==p['retire']['hash']
   assert free+facts.st_size>=minimum,(free,minimum,facts.st_size)
   replica.unlink()
   print('Retired archived B1454 working core',flush=True)
  assert shutil.disk_usage(base).free >= minimum,(free,minimum)
  root.mkdir()
  archive.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 image=Path(identity['frozenImage'])
 assert image==donor/'candidate' and image.is_relative_to(base)
 for name,sha in identity['imageFiles']['candidate'].items():
  assert digest(image/name)==sha
 os.link(donor/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 payload.unlink()
subprocess.run(['sudo','-n','systemd-run','--unit='+p['unit'],'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=395','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
receipt=subprocess.run(ssh,input="p="+repr(params)+"\n"+body,capture_output=True,encoding="utf-8",timeout=35)
(lab/"launch.log").write_text(receipt.stdout+receipt.stderr,encoding="utf-8")
receipt.check_returncode()
gate = datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=355)
(lab/"observe-not-before").write_text(gate.isoformat(),encoding="utf-8")
print(receipt.stdout, receipt.stderr, unit, gate.isoformat())
