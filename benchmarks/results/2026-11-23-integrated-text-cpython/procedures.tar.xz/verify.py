from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "borrowed-cased-words-refined-20261123"
identity = json.loads((prior / "comparison/identity.json").read_text(encoding="utf-8"))
catalog = lab / "representative.json"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
dotnet = Path.home() / ".dotnet11/dotnet.exe"
proto = repo / "benchmarks/cpython-worker.py"
assert sha(proto) == identity["cpythonWorkerSHA256"]
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
for role, files in identity["imageFiles"].items():
    image = prior / role
    assert len(files) == 32 and all(sha(image / name) == digest for name, digest in files.items())
    output = lab / (role + "-verify.json")
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", proto, "--out", output],
        env=env, check=True, timeout=95)
    proof = json.loads(output.read_text(encoding="utf-8"))
    assert proof["state"] == "Completed" and proof["caseCount"] == 6 and proof["catalogSha256"] == sha(catalog)
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert all(sha(image / name) == digest for name, digest in files.items())
