; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 688
       lea      rbp, [rsp+0x2B0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG83:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG83
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1AC], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x100], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x100]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02DE63D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02DE63D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x194], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02DE63D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x194], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x194], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02DE63DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02DE63E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A0], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02DE63E4
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x104]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x110], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, bword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, 0x7FFA02D930D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x118]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02DE63E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02DE63EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B0], eax
       jmp      G_M000_IG55
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02DE63F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, gword ptr [rbp-0x1A8]
       mov      rdx, 0x7FFA02DE63F8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rcx, gword ptr [rbp-0x1C8]
       mov      edx, dword ptr [rbp-0x1CC]
       mov      r11, 0x7FFA02541DC8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x130]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x280]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG57
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02BC9908
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateInlineWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02DE6500
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02DE6504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1E8], rcx
       mov      rcx, bword ptr [rbp-0x1E8]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02DE6508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02DE650C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x200], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x200]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1AC]
       dec      eax
       mov      dword ptr [rbp-0x1AC], eax
       cmp      dword ptr [rbp-0x1AC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1AC]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG50
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02DE6510
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       je       SHORT G_M000_IG39
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG37:                ;; offset=0x07D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG38:                ;; offset=0x07E3
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x220]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
       jmp      G_M000_IG44
 
G_M000_IG39:                ;; offset=0x0837
       mov      rcx, 0x7FFA02DE6514
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG40:                ;; offset=0x0846
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG41:                ;; offset=0x0856
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG42:                ;; offset=0x0866
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG43:                ;; offset=0x0876
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x238]
       lea      r9, [rbp-0x248]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
 
G_M000_IG44:                ;; offset=0x08C5
       cmp      dword ptr [rbp-0x14C], 0
       jne      SHORT G_M000_IG45
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x08EA
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG49
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG47
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x093C
       mov      rcx, 0x7FFA02DE6518
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG47:                ;; offset=0x094B
       mov      rcx, 0x7FFA02DE651C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG53
 
G_M000_IG48:                ;; offset=0x0979
       mov      rcx, 0x7FFA02DE6520
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0988
       mov      rcx, 0x7FFA02DE6524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG50:                ;; offset=0x09CA
       mov      rcx, 0x7FFA02DE6528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
 
G_M000_IG51:                ;; offset=0x09FE
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0A05
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0A0C
       call     G_M000_IG77
       nop      
 
G_M000_IG54:                ;; offset=0x0A12
       mov      rcx, 0x7FFA02DE6550
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xFC]
       mov      dword ptr [rbp-0x1B0], eax
 
G_M000_IG55:                ;; offset=0x0A2D
       movzx    rax, byte  ptr [rbp-0x1B0]
 
G_M000_IG56:                ;; offset=0x0A34
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x0A3D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0A43
       sub      rsp, 56
 
G_M000_IG59:                ;; offset=0x0A47
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG60
       mov      rcx, 0x7FFA02DE653C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x180]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x270], rcx
       mov      rcx, bword ptr [rbp-0x270]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG60:                ;; offset=0x0AB1
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG61
       mov      rcx, 0x7FFA02DE6540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x178], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x274], eax
       mov      edx, dword ptr [rbp-0x274]
       mov      rcx, bword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG61:                ;; offset=0x0B01
       mov      rcx, 0x7FFA02DE6544
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG62:                ;; offset=0x0B11
       add      rsp, 56
       ret      
 
G_M000_IG63:                ;; offset=0x0B16
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B1C
       sub      rsp, 56
 
G_M000_IG65:                ;; offset=0x0B20
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG69
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG66
       jmp      SHORT G_M000_IG68
 
G_M000_IG66:                ;; offset=0x0B3D
       mov      rcx, 0x7FFA02DE6530
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG73
 
G_M000_IG67:                ;; offset=0x0B51
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0B57
       mov      rcx, 0x7FFA02DE6534
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x0B66
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x160]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x168], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG72
       mov      rcx, 0x7FFA02DE6538
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x0BC4
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG71:                ;; offset=0x0BD4
       lea      rdx, [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x170], rax
 
G_M000_IG72:                ;; offset=0x0BEE
       mov      rcx, bword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG73:                ;; offset=0x0C02
       nop      
 
G_M000_IG74:                ;; offset=0x0C03
       call     G_M000_IG58
       nop      
 
G_M000_IG75:                ;; offset=0x0C09
       mov      rcx, 0x7FFA02DE6548
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C19
       add      rsp, 56
       ret      
 
G_M000_IG77:                ;; offset=0x0C1E
       sub      rsp, 56
 
G_M000_IG78:                ;; offset=0x0C22
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG79
       mov      rcx, 0x7FFA02DE652C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG79:                ;; offset=0x0C46
       nop      
 
G_M000_IG80:                ;; offset=0x0C47
       call     G_M000_IG64
       nop      
 
G_M000_IG81:                ;; offset=0x0C4D
       mov      rcx, 0x7FFA02DE654C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:                ;; offset=0x0C5D
       add      rsp, 56
       ret      
 
; Total bytes of code 3170

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0034
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x005E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG04:                ;; offset=0x0067
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x28]
       mov      edx, dword ptr [rbp-0x2C]
       lea      r8, [rbp-0x20]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       mov      dword ptr [rbp-0x04], eax
       cmp      dword ptr [rbp-0x04], 0
       jge      SHORT G_M000_IG06
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x0090
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0099
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      ecx, dword ptr [rbp-0x04]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG10
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x10], rax
       mov      rax, bword ptr [rbp-0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x48], rax
       mov      rax, bword ptr [rbp-0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG07:                ;; offset=0x00EA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG08:                ;; offset=0x00F3
       mov      r8, gword ptr [rbp-0x48]
       mov      r9d, dword ptr [rbp-0x4C]
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x04]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0112
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x011B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 289

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       xor      eax, eax
       mov      dword ptr [rbp-0x40], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, 0x7FFA02DED9D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x008E
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00CF
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00D8
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00EB
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x00F8
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0108
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02DED9D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x013D
       mov      rcx, 0x7FFA02DED9D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x014C
       mov      rcx, 0x7FFA02DED9DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x40]
       inc      eax
       mov      dword ptr [rbp-0x40], eax
 
G_M000_IG12:                ;; offset=0x0163
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x017A
       lea      rcx, [rbp-0x94]
       mov      edx, 59
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x018D
       mov      eax, dword ptr [rbp-0x40]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02DED9E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01AD
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG16
       mov      rcx, 0x7FFA02DED9E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG16:                ;; offset=0x01C7
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG17:                ;; offset=0x01CB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG18:                ;; offset=0x01D4
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG19:                ;; offset=0x01DA
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG20:                ;; offset=0x01E7
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0248
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02BC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02C8
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02DED9E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0302
       mov      rcx, 0x7FFA02DED9EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0313
       mov      rcx, 0x7FFA02DED9F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0322
       mov      rcx, 0x7FFA02DED9F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0350
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0367
       lea      rcx, [rbp-0x94]
       mov      edx, 206
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x037A
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02DED9F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x0393
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x0398
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03A1
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03A7
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03B0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 950

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0034
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x005E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG04:                ;; offset=0x0067
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x28]
       mov      edx, dword ptr [rbp-0x2C]
       lea      r8, [rbp-0x20]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       mov      dword ptr [rbp-0x04], eax
       cmp      dword ptr [rbp-0x04], 0
       jge      SHORT G_M000_IG06
       mov      rcx, 0x7FFA02F260C8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x009F
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00A8
       mov      rcx, 0x7FFA02F260CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      ecx, dword ptr [rbp-0x04]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG10
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x10], rax
       mov      rax, bword ptr [rbp-0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x48], rax
       mov      rax, bword ptr [rbp-0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG07:                ;; offset=0x0108
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG08:                ;; offset=0x0111
       mov      r8, gword ptr [rbp-0x48]
       mov      r9d, dword ptr [rbp-0x4C]
       lea      rax, [rbp-0x40]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x04]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0130
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0139
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 319

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       xor      eax, eax
       mov      dword ptr [rbp-0x40], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, 0x7FFA02DED9D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x008E
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x40]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00CE
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00D7
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00EA
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x00F7
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0107
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02DED9D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x013C
       mov      rcx, 0x7FFA02DED9D8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x014B
       mov      rcx, 0x7FFA02DED9DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x40]
       inc      eax
       mov      dword ptr [rbp-0x40], eax
 
G_M000_IG12:                ;; offset=0x0162
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0179
       lea      rcx, [rbp-0x94]
       mov      edx, 59
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x018C
       mov      eax, dword ptr [rbp-0x40]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02DED9E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01AC
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG16
       mov      rcx, 0x7FFA02DED9E4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG16:                ;; offset=0x01C6
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG17:                ;; offset=0x01CA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG18:                ;; offset=0x01D3
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG19:                ;; offset=0x01D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG20:                ;; offset=0x01E6
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0247
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02BA
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02C6
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02DED9E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0300
       mov      rcx, 0x7FFA02DED9EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0311
       mov      rcx, 0x7FFA02DED9F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0320
       mov      rcx, 0x7FFA02DED9F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x034E
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0365
       lea      rcx, [rbp-0x94]
       mov      edx, 206
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x0378
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02DED9F8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x0391
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x0396
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x039F
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03A5
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03AE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 948

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 688
       lea      rbp, [rsp+0x2B0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG83:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG83
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1AC], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x100], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x100]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02DE63D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02DE63D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x194], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02DE63D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x194], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x194], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02DE63DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02DE63E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A0], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02DE63E4
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x104]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x110], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      edx, dword ptr [rbp-0x1B4]
       mov      rcx, bword ptr [rbp-0x110]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, 0x7FFA02D930D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x118], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x118]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0222
       mov      rcx, 0x7FFA02DE63E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0231
       mov      rcx, 0x7FFA02DE63EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B0], eax
       jmp      G_M000_IG55
 
G_M000_IG15:                ;; offset=0x0268
       mov      rcx, 0x7FFA02DE63F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0279
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp-0x120]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, gword ptr [rbp-0x1A8]
       mov      rdx, 0x7FFA02DE63F8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1CC], eax
       mov      rcx, gword ptr [rbp-0x1C8]
       mov      edx, dword ptr [rbp-0x1CC]
       mov      r11, 0x7FFA025425D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036F
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x128]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x130]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044B
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG19:                ;; offset=0x0470
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047C
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, gword ptr [rbp-0x138]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x280]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG57
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA02BC9908
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateInlineWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0509
       mov      rcx, 0x7FFA02DE6500
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0518
       mov      rcx, 0x7FFA02DE6504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052C
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG57
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1E8], rcx
       mov      rcx, bword ptr [rbp-0x1E8]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02DE6508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x0608
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060A
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0613
       mov      rcx, 0x7FFA02DE650C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG27:                ;; offset=0x067E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x200], xmm0
 
G_M000_IG28:                ;; offset=0x068A
       lea      rcx, [rbp-0x200]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x069E
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CB
       mov      eax, dword ptr [rbp-0x1AC]
       dec      eax
       mov      dword ptr [rbp-0x1AC], eax
       cmp      dword ptr [rbp-0x1AC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E2
       lea      rcx, [rbp-0x1AC]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F5
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG50
 
G_M000_IG33:                ;; offset=0x0717
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x0727
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x208], rax
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x079E
       mov      rcx, 0x7FFA02DE6510
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07B7
       cmp      gword ptr [rbp-0xF8], 0
       je       SHORT G_M000_IG39
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x158], rax
 
G_M000_IG37:                ;; offset=0x07CF
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG38:                ;; offset=0x07DF
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x220]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
       jmp      G_M000_IG44
 
G_M000_IG39:                ;; offset=0x0833
       mov      rcx, 0x7FFA02DE6514
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG40:                ;; offset=0x0842
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x148], xmm0
 
G_M000_IG41:                ;; offset=0x0852
       vmovdqu  xmm0, xmmword ptr [rbp-0x148]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG42:                ;; offset=0x0862
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG43:                ;; offset=0x0872
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x238]
       lea      r9, [rbp-0x248]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x14C], eax
 
G_M000_IG44:                ;; offset=0x08C1
       cmp      dword ptr [rbp-0x14C], 0
       jne      SHORT G_M000_IG45
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x08E6
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG49
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG47
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x0938
       mov      rcx, 0x7FFA02DE6518
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG47:                ;; offset=0x0947
       mov      rcx, 0x7FFA02DE651C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
       jmp      G_M000_IG53
 
G_M000_IG48:                ;; offset=0x0975
       mov      rcx, 0x7FFA02DE6520
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0984
       mov      rcx, 0x7FFA02DE6524
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x258], rax
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG50:                ;; offset=0x09C6
       mov      rcx, 0x7FFA02DE6528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0xFC], 1
 
G_M000_IG51:                ;; offset=0x09FA
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0A01
       call     G_M000_IG77
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0A08
       call     G_M000_IG77
       nop      
 
G_M000_IG54:                ;; offset=0x0A0E
       mov      rcx, 0x7FFA02DE6550
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xFC]
       mov      dword ptr [rbp-0x1B0], eax
 
G_M000_IG55:                ;; offset=0x0A29
       movzx    rax, byte  ptr [rbp-0x1B0]
 
G_M000_IG56:                ;; offset=0x0A30
       add      rsp, 688
       pop      rbp
       ret      
 
G_M000_IG57:                ;; offset=0x0A39
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x0A3F
       sub      rsp, 56
 
G_M000_IG59:                ;; offset=0x0A43
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG60
       mov      rcx, 0x7FFA02DE653C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x180]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x270], rcx
       mov      rcx, bword ptr [rbp-0x270]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG60:                ;; offset=0x0AAD
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG61
       mov      rcx, 0x7FFA02DE6540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x178], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x274], eax
       mov      edx, dword ptr [rbp-0x274]
       mov      rcx, bword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG61:                ;; offset=0x0AFD
       mov      rcx, 0x7FFA02DE6544
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG62:                ;; offset=0x0B0D
       add      rsp, 56
       ret      
 
G_M000_IG63:                ;; offset=0x0B12
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B18
       sub      rsp, 56
 
G_M000_IG65:                ;; offset=0x0B1C
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG69
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG66
       jmp      SHORT G_M000_IG68
 
G_M000_IG66:                ;; offset=0x0B39
       mov      rcx, 0x7FFA02DE6530
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG73
 
G_M000_IG67:                ;; offset=0x0B4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0B53
       mov      rcx, 0x7FFA02DE6534
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG69:                ;; offset=0x0B62
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x160], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x160]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x168], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG72
       mov      rcx, 0x7FFA02DE6538
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x0BC0
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG71:                ;; offset=0x0BD0
       lea      rdx, [rbp-0x268]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x170], rax
 
G_M000_IG72:                ;; offset=0x0BEA
       mov      rcx, bword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG73:                ;; offset=0x0BFE
       nop      
 
G_M000_IG74:                ;; offset=0x0BFF
       call     G_M000_IG58
       nop      
 
G_M000_IG75:                ;; offset=0x0C05
       mov      rcx, 0x7FFA02DE6548
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C15
       add      rsp, 56
       ret      
 
G_M000_IG77:                ;; offset=0x0C1A
       sub      rsp, 56
 
G_M000_IG78:                ;; offset=0x0C1E
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG79
       mov      rcx, 0x7FFA02DE652C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG79:                ;; offset=0x0C42
       nop      
 
G_M000_IG80:                ;; offset=0x0C43
       call     G_M000_IG64
       nop      
 
G_M000_IG81:                ;; offset=0x0C49
       mov      rcx, 0x7FFA02DE654C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG82:                ;; offset=0x0C59
       add      rsp, 56
       ret      
 
; Total bytes of code 3166

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 362137
; 57 inlinees with PGO data; 124 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 280
       xor      eax, eax
       mov      qword ptr [rsp+0x78], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       vmovdqu  ymmword ptr [rsp+0xE0], ymm4
       vmovdqa  xmmword ptr [rsp+0x100], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, r9
       mov      rbp, gword ptr [rsp+0x180]
 
G_M000_IG02:                ;; offset=0x005C
       mov      rcx, gword ptr [rbp+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG112
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG111
 
G_M000_IG03:                ;; offset=0x0085
       mov      r14, gword ptr [rbx+0x28]
       mov      ecx, dword ptr [rbx+0x4C]
       mov      r15, bword ptr [rsi]
       mov      esi, dword ptr [rsi+0x08]
       cmp      ecx, 4
       jle      G_M000_IG86
 
G_M000_IG04:                ;; offset=0x009B
       test     ecx, ecx
       je       G_M000_IG147
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0xF0], ymm0
       xor      r13d, r13d
       cmp      r13d, esi
       jge      G_M000_IG35
 
G_M000_IG05:                ;; offset=0x00BC
       mov      rcx, gword ptr [rbp+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG127
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG126
 
G_M000_IG06:                ;; offset=0x00E5
       mov      r12d, esi
       sub      r12d, r13d
       cmp      r12d, 0x1000
       jge      G_M000_IG13
 
G_M000_IG07:                ;; offset=0x00F8
       mov      edx, r13d
       mov      ecx, r12d
       add      rdx, rcx
       mov      ecx, esi
       cmp      rdx, rcx
       ja       G_M000_IG125
       mov      eax, r13d
       add      rax, r15
       mov      bword ptr [rsp+0x58], rax
       mov      r8, rax
       mov      r10d, r12d
       cmp      r10d, 16
       jge      SHORT G_M000_IG14
 
G_M000_IG08:                ;; offset=0x0123
       cmp      r10d, 4
       jge      G_M000_IG17
 
G_M000_IG09:                ;; offset=0x012D
       mov      rax, r8
       mov      edx, r10d
       xor      ecx, ecx
       test     edx, edx
       je       G_M000_IG34
 
G_M000_IG10:                ;; offset=0x013D
       movzx    r8, byte  ptr [rax+rcx]
       mov      r10d, dword ptr [rsp+0x10C]
       lea      r9d, [r10+0x01]
       mov      dword ptr [rsp+0x10C], r9d
       mov      r9d, r10d
       and      r9d, 3
       je       G_M000_IG32
 
G_M000_IG11:                ;; offset=0x0163
       cmp      r9d, 1
       jne      G_M000_IG27
 
G_M000_IG12:                ;; offset=0x016D
       mov      dword ptr [rsp+0x104], r8d
       jmp      G_M000_IG33
 
G_M000_IG13:                ;; offset=0x017A
       mov      r12d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG14:                ;; offset=0x0185
       cmp      dword ptr [rsp+0x10C], 0
       jne      G_M000_IG128
       mov      rax, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0xF0], rax
       mov      rdx, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0xF8], rdx
 
G_M000_IG15:                ;; offset=0x01B7
       cmp      r10d, 16
       jl       G_M000_IG08
 
G_M000_IG16:                ;; offset=0x01C1
       mov      eax, dword ptr [rsp+0xF0]
       imul     edx, dword ptr [r8], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF0], eax
       mov      eax, dword ptr [rsp+0xF4]
       lea      rdx, bword ptr [r8+0x04]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF4], eax
       mov      eax, dword ptr [rsp+0xF8]
       lea      rdx, bword ptr [r8+0x08]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF8], eax
       mov      eax, dword ptr [rsp+0xFC]
       lea      rdx, bword ptr [r8+0x0C]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xFC], eax
       mov      eax, dword ptr [rsp+0x10C]
       add      eax, 4
       mov      dword ptr [rsp+0x10C], eax
       add      r8, 16
       add      r10d, -16
       mov      rax, r8
       mov      edx, r10d
       mov      r8, rax
       mov      r10d, edx
       jmp      G_M000_IG15
 
G_M000_IG17:                ;; offset=0x0274
       mov      eax, dword ptr [r8]
       mov      edx, dword ptr [rsp+0x10C]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rsp+0x10C], ecx
       mov      ecx, edx
       and      ecx, 3
       je       G_M000_IG25
 
G_M000_IG18:                ;; offset=0x0293
       cmp      ecx, 1
       jne      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0298
       mov      dword ptr [rsp+0x104], eax
       jmp      G_M000_IG26
 
G_M000_IG20:                ;; offset=0x02A4
       cmp      ecx, 2
       jne      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02A9
       mov      dword ptr [rsp+0x108], eax
       jmp      G_M000_IG26
 
G_M000_IG22:                ;; offset=0x02B5
       cmp      edx, 3
       jne      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x02BA
       mov      rdx, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0xF0], rdx
       mov      rdx, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0xF8], rdx
 
G_M000_IG24:                ;; offset=0x02DE
       imul     edx, dword ptr [rsp+0x100], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0xF0]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF0], edx
       imul     edx, dword ptr [rsp+0x104], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0xF4]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF4], edx
       imul     edx, dword ptr [rsp+0x108], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0xF8]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF8], edx
       imul     eax, eax, 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xFC]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xFC], eax
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0363
       mov      dword ptr [rsp+0x100], eax
 
G_M000_IG26:                ;; offset=0x036A
       add      r8, 4
       add      r10d, -4
       mov      rax, r8
       mov      edx, r10d
       mov      r8, rax
       mov      r10d, edx
       jmp      G_M000_IG08
 
G_M000_IG27:                ;; offset=0x0383
       cmp      r9d, 2
       jne      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0389
       mov      dword ptr [rsp+0x108], r8d
       jmp      G_M000_IG33
 
G_M000_IG29:                ;; offset=0x0396
       cmp      r10d, 3
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x039C
       mov      r10, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0xF0], r10
       mov      r10, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0xF8], r10
 
G_M000_IG31:                ;; offset=0x03C0
       imul     r10d, dword ptr [rsp+0x100], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0xF0]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF0], r10d
       imul     r10d, dword ptr [rsp+0x104], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0xF4]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF4], r10d
       imul     r10d, dword ptr [rsp+0x108], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0xF8]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xF8], r10d
       imul     r8d, r8d, 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rsp+0xFC]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xFC], r8d
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0459
       mov      dword ptr [rsp+0x100], r8d
 
G_M000_IG33:                ;; offset=0x0461
       inc      ecx
       cmp      ecx, edx
       jl       G_M000_IG10
 
G_M000_IG34:                ;; offset=0x046B
       add      r13d, r12d
       cmp      r13d, esi
       jl       G_M000_IG05
 
G_M000_IG35:                ;; offset=0x0477
       mov      eax, dword ptr [rsp+0x10C]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG134
 
G_M000_IG36:                ;; offset=0x048C
       mov      ecx, 0xFFFFFFFFE6F514E0
 
G_M000_IG37:                ;; offset=0x0491
       lea      eax, [rcx+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x0498
       imul     ecx, dword ptr [rsp+0x100], 0xFFFFFFFFC2B2AE3D
       add      eax, ecx
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x04B3
       imul     ecx, dword ptr [rsp+0x104], 0xFFFFFFFFC2B2AE3D
       add      ecx, eax
       rol      ecx, 17
       imul     eax, ecx, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x04CE
       imul     edx, dword ptr [rsp+0x108], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG41:                ;; offset=0x04E4
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     r13d, eax, 0xFFFFFFFF9E3779B9
       mov      r12d, r13d
       shr      r12d, 16
       xor      r12d, r13d
       mov      r13d, dword ptr [r14+0x08]
       mov      ecx, r13d
       blsr     eax, ecx
       jne      G_M000_IG135
       dec      ecx
       and      ecx, r12d
 
G_M000_IG42:                ;; offset=0x053F
       cmp      ecx, r13d
       jae      G_M000_IG162
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      eax, dword ptr [r14+8*rcx+0x30]
       dec      eax
       mov      dword ptr [rsp+0x110], eax
       test     eax, eax
       jl       G_M000_IG147
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0566
       mov      r8, bword ptr [rsp+0x38]
       mov      eax, dword ptr [r8+0x1C]
       dec      eax
       mov      dword ptr [rsp+0x110], eax
       js       G_M000_IG147
 
G_M000_IG44:                ;; offset=0x057E
       mov      rcx, gword ptr [rbp+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG137
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG136
 
G_M000_IG45:                ;; offset=0x05A7
       mov      eax, dword ptr [rsp+0x110]
       cmp      eax, r13d
       jae      G_M000_IG162
       mov      dword ptr [rsp+0x110], eax
       mov      ecx, eax
       lea      rcx, [rcx+4*rcx]
       lea      r8, bword ptr [r14+8*rcx+0x10]
       mov      bword ptr [rsp+0x38], r8
       cmp      dword ptr [r8+0x18], r12d
       jne      SHORT G_M000_IG43
 
G_M000_IG46:                ;; offset=0x05D4
       mov      rcx, gword ptr [r14+8*rcx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG43
 
G_M000_IG47:                ;; offset=0x05DE
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG43
 
G_M000_IG48:                ;; offset=0x05F1
       mov      edx, esi
       movzx    r10, byte  ptr [rcx+0x24]
       test     r10d, r10d
       je       SHORT G_M000_IG53
 
G_M000_IG49:                ;; offset=0x05FD
       cmp      r10d, 255
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x0606
       lea      r10, bword ptr [rcx+0x28]
       mov      r9d, dword ptr [rcx+0x18]
       cmp      r9d, 8
       ja       G_M000_IG125
       jmp      SHORT G_M000_IG54
 
G_M000_IG51:                ;; offset=0x061A
       mov      r10, gword ptr [rcx+0x08]
       lea      r9, bword ptr [rcx+0x28]
       mov      r9d, dword ptr [r9]
       mov      ecx, dword ptr [rcx+0x18]
       test     r10, r10
       je       G_M000_IG139
       mov      qword ptr [rsp+0x70], r9
       mov      r11d, ecx
       add      r11, r9
       mov      r9d, dword ptr [r10+0x08]
       cmp      r11, r9
       ja       G_M000_IG125
       mov      r9, qword ptr [rsp+0x70]
       lea      r10, bword ptr [r10+r9+0x10]
       mov      r9d, ecx
 
G_M000_IG52:                ;; offset=0x0656
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0658
       mov      r10, gword ptr [rcx+0x08]
       mov      r9d, dword ptr [rcx+0x18]
       test     r10, r10
       je       G_M000_IG138
       cmp      dword ptr [r10+0x08], r9d
       jb       G_M000_IG125
       add      r10, 16
 
G_M000_IG54:                ;; offset=0x0677
       mov      bword ptr [rsp+0x48], r10
       mov      dword ptr [rsp+0x98], r9d
       cmp      r9d, edx
       jne      G_M000_IG43
       xor      r11d, r11d
       mov      dword ptr [rsp+0xEC], r11d
       cmp      r11d, esi
       jge      G_M000_IG62
 
G_M000_IG55:                ;; offset=0x06A1
       mov      rcx, gword ptr [rbp+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG141
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG140
 
G_M000_IG56:                ;; offset=0x06CA
       mov      r11d, dword ptr [rsp+0xEC]
       mov      ecx, esi
       sub      ecx, r11d
       cmp      ecx, 0x1000
       jge      G_M000_IG72
 
G_M000_IG57:                ;; offset=0x06E3
       mov      dword ptr [rsp+0xE8], ecx
       mov      edx, r11d
       mov      r10d, ecx
       mov      qword ptr [rsp+0x68], r10
       add      rdx, r10
       mov      r9d, esi
       cmp      rdx, r9
       ja       G_M000_IG125
       mov      r9d, r11d
       add      r9, r15
       mov      ecx, dword ptr [rsp+0x98]
       cmp      rdx, rcx
       ja       G_M000_IG125
       mov      ecx, r11d
       add      rcx, bword ptr [rsp+0x48]
       mov      bword ptr [rsp+0x40], rcx
       mov      bword ptr [rsp+0x60], r9
       mov      r10, rcx
       mov      rdx, qword ptr [rsp+0x68]
       cmp      rdx, 8
       jae      G_M000_IG78
 
G_M000_IG58:                ;; offset=0x073E
       cmp      rdx, 4
       jb       G_M000_IG73
 
G_M000_IG59:                ;; offset=0x0748
       add      rdx, -4
       mov      r10d, dword ptr [r9]
       sub      r10d, dword ptr [rcx]
       mov      r9d, dword ptr [r9+rdx]
       sub      r9d, dword ptr [rcx+rdx]
       or       r10d, r9d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG60:                ;; offset=0x0763
       test     edx, edx
       je       G_M000_IG43
 
G_M000_IG61:                ;; offset=0x076B
       add      r11d, dword ptr [rsp+0xE8]
       cmp      r11d, esi
       mov      dword ptr [rsp+0xEC], r11d
       jl       G_M000_IG55
 
G_M000_IG62:                ;; offset=0x0784
       mov      eax, dword ptr [rsp+0x110]
       mov      r12d, eax
 
G_M000_IG63:                ;; offset=0x078E
       test     r12d, r12d
       jl       G_M000_IG148
 
G_M000_IG64:                ;; offset=0x0797
       mov      rcx, gword ptr [rbx+0x28]
       cmp      r12d, dword ptr [rcx+0x08]
       jae      G_M000_IG162
       mov      edx, r12d
       lea      rdx, [rdx+4*rdx]
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rdx, rcx
       mov      esi, r12d
       mov      rax, gword ptr [rdx]
       mov      rbp, rax
       test     rbp, rbp
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x07C2
       mov      r8, 0x7FFA02A61F30
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG150
 
G_M000_IG66:                ;; offset=0x07D6
       mov      r14d, dword ptr [rdx+0x18]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG151
       mov      rdx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG162
       mov      eax, esi
       cmp      gword ptr [rdx+8*rax+0x10], 0
       jne      G_M000_IG151
 
G_M000_IG67:                ;; offset=0x0800
       mov      r15, qword ptr [rcx+0x10]
       mov      rcx, 0xFF80000000000000
       cmp      r15, rcx
       jl       G_M000_IG152
       mov      rcx, 0x80000000000000
       cmp      r15, rcx
       jge      G_M000_IG152
 
G_M000_IG68:                ;; offset=0x082A
       mov      rcx, rdi
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       lea      rdx, [rax+r15]
       mov      edi, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG161
       mov      rcx, gword ptr [rbx+0x28]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG162
       mov      eax, esi
       lea      rax, [rax+4*rax]
       mov      qword ptr [rcx+8*rax+0x20], rdx
       mov      rcx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG162
       mov      edx, esi
       xor      rax, rax
       mov      gword ptr [rcx+8*rdx+0x10], rax
 
G_M000_IG69:                ;; offset=0x0873
       cmp      dword ptr [rbx+0x4C], edi
       jne      G_M000_IG85
 
G_M000_IG70:                ;; offset=0x087C
       mov      eax, 1
 
G_M000_IG71:                ;; offset=0x0881
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG72:                ;; offset=0x0898
       mov      ecx, 0x1000
       jmp      G_M000_IG57
 
G_M000_IG73:                ;; offset=0x08A2
       xor      r10d, r10d
       mov      dword ptr [rsp+0xD4], r10d
       mov      r10, rdx
       and      r10, 2
       mov      qword ptr [rsp+0xC8], r10
       test     r10, r10
       je       SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x08C1
       movzx    r10, word  ptr [r9]
       mov      dword ptr [rsp+0x114], r10d
       movzx    r10, word  ptr [rcx]
       movzx    rcx, dword ptr [rsp+0x114]
       sub      ecx, r10d
       mov      r10d, ecx
       mov      dword ptr [rsp+0xD4], r10d
       mov      rcx, bword ptr [rsp+0x40]
 
G_M000_IG75:                ;; offset=0x08EC
       test     dl, 1
       je       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x08F1
       mov      r10, qword ptr [rsp+0xC8]
       movzx    rdx, byte  ptr [r9+r10]
       movzx    r9, byte  ptr [rcx+r10]
       sub      edx, r9d
       mov      r10d, edx
       or       r10d, dword ptr [rsp+0xD4]
       mov      dword ptr [rsp+0xD4], r10d
 
G_M000_IG77:                ;; offset=0x0919
       cmp      dword ptr [rsp+0xD4], 0
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG60
 
G_M000_IG78:                ;; offset=0x092C
       mov      rcx, bword ptr [rsp+0x60]
       cmp      rcx, r10
       je       G_M000_IG61
       cmp      rdx, 32
       jae      SHORT G_M000_IG81
 
G_M000_IG79:                ;; offset=0x0940
       cmp      rdx, 16
       jae      G_M000_IG142
 
G_M000_IG80:                ;; offset=0x094A
       add      rdx, -8
       mov      rcx, qword ptr [r9]
       mov      r10, bword ptr [rsp+0x40]
       sub      rcx, qword ptr [r10]
       mov      r9, qword ptr [r9+rdx]
       sub      r9, qword ptr [r10+rdx]
       or       rcx, r9
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG60
 
G_M000_IG81:                ;; offset=0x096F
       xor      r9d, r9d
       add      rdx, -32
       mov      qword ptr [rsp+0xD8], rdx
       test     rdx, rdx
       je       SHORT G_M000_IG84
       vmovups  ymm0, ymmword ptr [rcx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG43
 
G_M000_IG82:                ;; offset=0x0999
       add      r9, 32
       cmp      qword ptr [rsp+0xD8], r9
       jbe      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x09A7
       vmovups  ymm0, ymmword ptr [rcx+r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+r9]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG43
       jmp      SHORT G_M000_IG82
 
G_M000_IG84:                ;; offset=0x09C2
       mov      rdx, qword ptr [rsp+0xD8]
       vmovups  ymm0, ymmword ptr [rcx+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+rdx]
       vpmovmskb ecx, ymm0
       cmp      ecx, -1
       jne      G_M000_IG43
       jmp      G_M000_IG61
 
G_M000_IG85:                ;; offset=0x09E7
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG70
 
G_M000_IG86:                ;; offset=0x09EF
       cmp      esi, 8
       jg       G_M000_IG04
       xor      edx, edx
       test     ecx, ecx
       jle      G_M000_IG147
       jmp      G_M000_IG96
 
G_M000_IG87:                ;; offset=0x0A07
       mov      r8, gword ptr [rax+0x08]
       lea      r10, bword ptr [rax+0x28]
       mov      r10d, dword ptr [r10]
       mov      eax, dword ptr [rax+0x18]
       test     r8, r8
       je       G_M000_IG114
       mov      r9d, eax
       add      r9, r10
       mov      r11d, dword ptr [r8+0x08]
       cmp      r9, r11
       ja       G_M000_IG125
       lea      r8, bword ptr [r8+r10+0x10]
       mov      r10d, eax
 
G_M000_IG88:                ;; offset=0x0A39
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0A3B
       mov      r8, gword ptr [rax+0x08]
       mov      r10d, dword ptr [rax+0x18]
       test     r8, r8
       je       G_M000_IG113
       cmp      dword ptr [r8+0x08], r10d
       jb       G_M000_IG125
       add      r8, 16
 
G_M000_IG90:                ;; offset=0x0A5A
       cmp      esi, r10d
       jne      SHORT G_M000_IG95
 
G_M000_IG91:                ;; offset=0x0A5F
       mov      rax, r15
       mov      r9, r8
       mov      r10d, r10d
       cmp      r10, 8
       jae      G_M000_IG105
 
G_M000_IG92:                ;; offset=0x0A72
       cmp      r10, 4
       jb       G_M000_IG101
 
G_M000_IG93:                ;; offset=0x0A7C
       add      r10, -4
       mov      eax, dword ptr [r15]
       sub      eax, dword ptr [r8]
       mov      r9d, dword ptr [r15+r10]
       sub      r9d, dword ptr [r8+r10]
       or       eax, r9d
       sete     al
       movzx    rax, al
 
G_M000_IG94:                ;; offset=0x0A97
       test     eax, eax
       jne      G_M000_IG110
 
G_M000_IG95:                ;; offset=0x0A9F
       inc      edx
       cmp      edx, ecx
       jge      G_M000_IG147
 
G_M000_IG96:                ;; offset=0x0AA9
       mov      r13d, dword ptr [r14+0x08]
       cmp      edx, r13d
       jae      G_M000_IG162
       lea      rax, [rdx+4*rdx]
       mov      rax, gword ptr [r14+8*rax+0x10]
       test     rax, rax
       je       SHORT G_M000_IG95
 
G_M000_IG97:                ;; offset=0x0AC4
       mov      r8, 0x7FFA02A61F30
       cmp      qword ptr [rax], r8
       jne      SHORT G_M000_IG95
 
G_M000_IG98:                ;; offset=0x0AD3
       movzx    r8, byte  ptr [rax+0x24]
       test     r8d, r8d
       je       G_M000_IG89
 
G_M000_IG99:                ;; offset=0x0AE1
       cmp      r8d, 255
       je       G_M000_IG87
 
G_M000_IG100:                ;; offset=0x0AEE
       lea      r8, bword ptr [rax+0x28]
       mov      r10d, dword ptr [rax+0x18]
       cmp      r10d, 8
       ja       G_M000_IG125
       jmp      G_M000_IG90
 
G_M000_IG101:                ;; offset=0x0B05
       xor      eax, eax
       mov      r9, r10
       and      r9, 2
       jne      G_M000_IG115
 
G_M000_IG102:                ;; offset=0x0B14
       test     r10b, 1
       je       SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0B1A
       movzx    r10, byte  ptr [r15+r9]
       movzx    r8, byte  ptr [r8+r9]
       sub      r10d, r8d
       or       eax, r10d
 
G_M000_IG104:                ;; offset=0x0B2A
       test     eax, eax
       sete     al
       movzx    rax, al
       jmp      G_M000_IG94
 
G_M000_IG105:                ;; offset=0x0B37
       cmp      rax, r9
       je       G_M000_IG123
       cmp      r10, 32
       jae      G_M000_IG116
 
G_M000_IG106:                ;; offset=0x0B4A
       cmp      r10, 16
       jae      G_M000_IG118
 
G_M000_IG107:                ;; offset=0x0B54
       add      r10, -8
       mov      r9, qword ptr [r15]
       sub      r9, qword ptr [r8]
       mov      rax, qword ptr [r15+r10]
       sub      rax, qword ptr [r8+r10]
       or       rax, r9
       sete     al
       movzx    rax, al
       jmp      G_M000_IG94
 
G_M000_IG108:                ;; offset=0x0B74
       add      rax, 32
       cmp      r8, rax
       jbe      G_M000_IG117
 
G_M000_IG109:                ;; offset=0x0B81
       vmovups  ymm0, ymmword ptr [r15+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+rax]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG124
       jmp      SHORT G_M000_IG108
 
G_M000_IG110:                ;; offset=0x0B9D
       mov      r12d, edx
       jmp      G_M000_IG63
 
G_M000_IG111:                ;; offset=0x0BA5
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG03
 
G_M000_IG112:                ;; offset=0x0BB7
       mov      rdx, gword ptr [rsp+0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG113:                ;; offset=0x0BCA
       test     r10d, r10d
       jne      G_M000_IG125
       xor      r8, r8
       xor      r10d, r10d
       jmp      G_M000_IG90
 
G_M000_IG114:                ;; offset=0x0BDE
       or       r10d, eax
       jne      G_M000_IG125
       xor      r8, r8
       xor      r10d, r10d
       jmp      G_M000_IG88
 
G_M000_IG115:                ;; offset=0x0BF2
       movzx    rax, word  ptr [r15]
       movzx    r11, word  ptr [r8]
       sub      eax, r11d
       jmp      G_M000_IG102
 
G_M000_IG116:                ;; offset=0x0C02
       xor      eax, eax
       lea      r8, [r10-0x20]
       test     r8, r8
       je       SHORT G_M000_IG117
       vmovups  ymm0, ymmword ptr [r15]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       je       G_M000_IG108
       jmp      G_M000_IG124
 
G_M000_IG117:                ;; offset=0x0C2A
       vmovups  ymm0, ymmword ptr [r15+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+r8]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      SHORT G_M000_IG124
       jmp      SHORT G_M000_IG123
 
G_M000_IG118:                ;; offset=0x0C41
       xor      eax, eax
       add      r10, -16
       je       SHORT G_M000_IG122
 
G_M000_IG119:                ;; offset=0x0C49
       vmovups  xmm0, xmmword ptr [r15]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0C60
       add      rax, 16
       cmp      r10, rax
       jbe      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x0C69
       vmovups  xmm0, xmmword ptr [r15+rax]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+rax]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG124
       jmp      SHORT G_M000_IG120
 
G_M000_IG122:                ;; offset=0x0C84
       vmovups  xmm0, xmmword ptr [r15+r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+r10]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x0C9D
       mov      eax, 1
       jmp      G_M000_IG94
 
G_M000_IG124:                ;; offset=0x0CA7
       xor      eax, eax
       jmp      G_M000_IG94
 
G_M000_IG125:                ;; offset=0x0CAE
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG126:                ;; offset=0x0CB5
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG127:                ;; offset=0x0CC7
       mov      rdx, gword ptr [rsp+0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG128:                ;; offset=0x0CDA
       mov      edx, dword ptr [rsp+0x10C]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG15
       lea      rcx, [reloc @RWD00]
       mov      dword ptr [rsp+0x9C], r10d
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      r9, G_M000_IG02
       add      rcx, r9
       jmp      rcx
 
G_M000_IG129:                ;; offset=0x0D0D
       mov      rax, r8
       jmp      SHORT G_M000_IG133
 
G_M000_IG130:                ;; offset=0x0D12
       mov      rax, r8
       jmp      SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x0D17
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0xF0]
       call     [System.HashCode:Add(int):this]
       mov      r8, bword ptr [rsp+0x58]
       add      r8, 4
       lea      r10d, [r12-0x04]
       mov      rax, r8
       mov      dword ptr [rsp+0x9C], r10d
 
G_M000_IG132:                ;; offset=0x0D40
       mov      bword ptr [rsp+0x50], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0xF0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x50]
       add      rax, 4
       mov      r8d, dword ptr [rsp+0x9C]
       add      r8d, -4
       mov      dword ptr [rsp+0x9C], r8d
 
G_M000_IG133:                ;; offset=0x0D72
       mov      bword ptr [rsp+0x50], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0xF0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x50]
       add      rax, 4
       mov      edx, dword ptr [rsp+0x9C]
       add      edx, -4
       mov      r8, rax
       mov      r10d, edx
       jmp      G_M000_IG15
 
G_M000_IG134:                ;; offset=0x0DA5
       rorx     ecx, dword ptr [rsp+0xF0], 31
       rorx     r8d, dword ptr [rsp+0xF4], 25
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0xF8], 20
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0xFC], 14
       add      ecx, r8d
       jmp      G_M000_IG37
 
G_M000_IG135:                ;; offset=0x0DDF
       mov      eax, r12d
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG42
 
G_M000_IG136:                ;; offset=0x0DED
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG45
 
G_M000_IG137:                ;; offset=0x0DFF
       mov      rdx, gword ptr [rsp+0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG45
 
G_M000_IG138:                ;; offset=0x0E12
       test     r9d, r9d
       jne      G_M000_IG125
       xor      r10, r10
       xor      r9d, r9d
       jmp      G_M000_IG54
 
G_M000_IG139:                ;; offset=0x0E26
       or       r9d, ecx
       jne      G_M000_IG125
       xor      r10, r10
       xor      r9d, r9d
       jmp      G_M000_IG52
 
G_M000_IG140:                ;; offset=0x0E3A
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG56
 
G_M000_IG141:                ;; offset=0x0E4C
       mov      rdx, gword ptr [rsp+0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG56
 
G_M000_IG142:                ;; offset=0x0E5F
       xor      r9d, r9d
       mov      qword ptr [rsp+0xE0], r9
       add      rdx, -16
       je       SHORT G_M000_IG146
 
G_M000_IG143:                ;; offset=0x0E70
       vmovups  xmm0, xmmword ptr [rcx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      G_M000_IG43
 
G_M000_IG144:                ;; offset=0x0E8A
       mov      r9, qword ptr [rsp+0xE0]
       add      r9, 16
       cmp      rdx, r9
       jbe      SHORT G_M000_IG146
 
G_M000_IG145:                ;; offset=0x0E9B
       vmovups  xmm0, xmmword ptr [rcx+r9]
       mov      qword ptr [rsp+0xE0], r9
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+r9]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      G_M000_IG43
       jmp      SHORT G_M000_IG144
 
G_M000_IG146:                ;; offset=0x0EC2
       vmovups  xmm0, xmmword ptr [rcx+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+rdx]
       vpmovmskb ecx, xmm0
       cmp      ecx, 0xFFFF
       jne      G_M000_IG43
       jmp      G_M000_IG61
 
G_M000_IG147:                ;; offset=0x0EE2
       mov      r12d, -1
       jmp      G_M000_IG63
 
G_M000_IG148:                ;; offset=0x0EED
       xor      eax, eax
 
G_M000_IG149:                ;; offset=0x0EEF
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG150:                ;; offset=0x0F06
       mov      rdx, rax
       mov      rcx, r8
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG151:                ;; offset=0x0F12
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x0F22
       xor      eax, eax
       jmp      G_M000_IG71
 
G_M000_IG153:                ;; offset=0x0F29
       mov      r8, 0x7FFA029E8768
       cmp      qword ptr [rax], r8
       jne      SHORT G_M000_IG152
 
G_M000_IG154:                ;; offset=0x0F38
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rsp+0xB8], xmm0
 
G_M000_IG155:                ;; offset=0x0F46
       xor      r8d, r8d
       mov      dword ptr [rsp+0xA0], r8d
 
G_M000_IG156:                ;; offset=0x0F51
       mov      bword ptr [rsp+0x88], r8
 
G_M000_IG157:                ;; offset=0x0F59
       mov      dword ptr [rsp+0x90], r8d
 
G_M000_IG158:                ;; offset=0x0F61
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rsp+0xA0]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rsp+0x88]
       lea      rcx, [rsp+0xB8]
       mov      edx, 1
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rsp+0xA0], 8
       jge      SHORT G_M000_IG152
 
G_M000_IG159:                ;; offset=0x0F9B
       vmovdqu  xmm0, xmmword ptr [rsp+0xB8]
       vmovdqu  xmmword ptr [rsp+0x78], xmm0
 
G_M000_IG160:                ;; offset=0x0FAA
       lea      rcx, [rsp+0x78]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      r15, rax
       jmp      G_M000_IG68
 
G_M000_IG161:                ;; offset=0x0FBD
       lea      rcx, [rsp+0xA8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x08]
       mov      rdx, gword ptr [rsp+0xA8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rsp+0xB0]
       mov      dword ptr [rsi+0x10], r9d
       mov      dword ptr [rsp+0x20], r14d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, rsi
       mov      rcx, rbx
       mov      edx, r12d
       mov      r8, rbp
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG69
 
G_M000_IG162:                ;; offset=0x1026
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000CBBh ; case G_M000_IG131
       	dd	00000CB6h ; case G_M000_IG130
       	dd	00000CB1h ; case G_M000_IG129

; Total bytes of code 4140

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 775844
; 52 inlinees with PGO data; 117 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 104
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       mov      rbx, rcx
       mov      rsi, r9
 
G_M000_IG02:                ;; offset=0x0020
       mov      rdi, bword ptr [r8]
       mov      ebp, dword ptr [r8+0x08]
       cmp      edx, 4
       jle      G_M000_IG77
 
G_M000_IG03:                ;; offset=0x0030
       test     edx, edx
       je       G_M000_IG136
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG35
 
G_M000_IG04:                ;; offset=0x004E
       test     rsi, rsi
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0053
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG116
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG115
 
G_M000_IG06:                ;; offset=0x007C
       mov      r15d, ebp
       sub      r15d, r14d
       cmp      r15d, 0x1000
       jge      SHORT G_M000_IG13
 
G_M000_IG07:                ;; offset=0x008B
       mov      edx, r14d
       mov      ecx, r15d
       add      rdx, rcx
       mov      ecx, ebp
       cmp      rdx, rcx
       ja       G_M000_IG114
       mov      r13d, r14d
       add      r13, rdi
       mov      r12, r13
       mov      eax, r15d
       cmp      r15d, 16
       jge      SHORT G_M000_IG14
 
G_M000_IG08:                ;; offset=0x00B1
       cmp      eax, 4
       jge      G_M000_IG17
 
G_M000_IG09:                ;; offset=0x00BA
       mov      rdx, r12
       xor      ecx, ecx
       test     eax, eax
       je       G_M000_IG34
 
G_M000_IG10:                ;; offset=0x00C7
       movzx    r8, byte  ptr [rdx+rcx]
       mov      r10d, dword ptr [rsp+0x5C]
       lea      r9d, [r10+0x01]
       mov      dword ptr [rsp+0x5C], r9d
       mov      r9d, r10d
       and      r9d, 3
       je       G_M000_IG32
 
G_M000_IG11:                ;; offset=0x00E7
       cmp      r9d, 1
       jne      G_M000_IG27
 
G_M000_IG12:                ;; offset=0x00F1
       mov      dword ptr [rsp+0x54], r8d
       jmp      G_M000_IG33
 
G_M000_IG13:                ;; offset=0x00FB
       mov      r15d, 0x1000
       jmp      SHORT G_M000_IG07
 
G_M000_IG14:                ;; offset=0x0103
       cmp      dword ptr [rsp+0x5C], 0
       jne      G_M000_IG117
       mov      rdx, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0x48], rdx
 
G_M000_IG15:                ;; offset=0x012C
       cmp      eax, 16
       jl       SHORT G_M000_IG08
 
G_M000_IG16:                ;; offset=0x0131
       mov      edx, dword ptr [rsp+0x40]
       imul     ecx, dword ptr [r12], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x40], edx
       mov      edx, dword ptr [rsp+0x44]
       lea      rcx, bword ptr [r12+0x04]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x44], edx
       mov      edx, dword ptr [rsp+0x48]
       lea      rcx, bword ptr [r12+0x08]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x48], edx
       mov      edx, dword ptr [rsp+0x4C]
       lea      rcx, bword ptr [r12+0x0C]
       imul     ecx, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      edx, ecx
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x4C], edx
       mov      edx, dword ptr [rsp+0x5C]
       add      edx, 4
       mov      dword ptr [rsp+0x5C], edx
       add      r12, 16
       add      eax, -16
       mov      r13d, eax
       mov      eax, r13d
       jmp      G_M000_IG15
 
G_M000_IG17:                ;; offset=0x01C3
       mov      edx, dword ptr [r12]
       mov      ecx, dword ptr [rsp+0x5C]
       lea      r8d, [rcx+0x01]
       mov      dword ptr [rsp+0x5C], r8d
       mov      r8d, ecx
       and      r8d, 3
       je       G_M000_IG25
 
G_M000_IG18:                ;; offset=0x01E1
       cmp      r8d, 1
       jne      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x01E7
       mov      dword ptr [rsp+0x54], edx
       jmp      G_M000_IG26
 
G_M000_IG20:                ;; offset=0x01F0
       cmp      r8d, 2
       jne      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x01F6
       mov      dword ptr [rsp+0x58], edx
       jmp      G_M000_IG26
 
G_M000_IG22:                ;; offset=0x01FF
       cmp      ecx, 3
       jne      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0204
       mov      rcx, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0x48], rcx
 
G_M000_IG24:                ;; offset=0x0222
       imul     ecx, dword ptr [rsp+0x50], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rsp+0x40]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x40], ecx
       imul     ecx, dword ptr [rsp+0x54], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rsp+0x44]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x44], ecx
       imul     ecx, dword ptr [rsp+0x58], 0xFFFFFFFF85EBCA77
       add      ecx, dword ptr [rsp+0x48]
       rol      ecx, 13
       imul     ecx, ecx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x48], ecx
       imul     edx, edx, 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0x4C]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x4C], edx
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0286
       mov      dword ptr [rsp+0x50], edx
 
G_M000_IG26:                ;; offset=0x028A
       add      r12, 4
       add      eax, -4
       mov      r13d, eax
       mov      eax, r13d
       jmp      G_M000_IG08
 
G_M000_IG27:                ;; offset=0x029C
       cmp      r9d, 2
       jne      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02A2
       mov      dword ptr [rsp+0x58], r8d
       jmp      G_M000_IG33
 
G_M000_IG29:                ;; offset=0x02AC
       cmp      r10d, 3
       jne      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02B2
       mov      r10, 0x568A77A6F4C1F157
       mov      qword ptr [rsp+0x40], r10
       mov      r10, 0x3267337ED09EAD2F
       mov      qword ptr [rsp+0x48], r10
 
G_M000_IG31:                ;; offset=0x02D0
       imul     r10d, dword ptr [rsp+0x50], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x40]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x40], r10d
       imul     r10d, dword ptr [rsp+0x54], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x44]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x44], r10d
       imul     r10d, dword ptr [rsp+0x58], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x48]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x48], r10d
       imul     r8d, r8d, 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rsp+0x4C]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x4C], r8d
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x0348
       mov      dword ptr [rsp+0x50], r8d
 
G_M000_IG33:                ;; offset=0x034D
       inc      ecx
       cmp      ecx, eax
       jl       G_M000_IG10
 
G_M000_IG34:                ;; offset=0x0357
       add      r14d, r15d
       cmp      r14d, ebp
       jl       G_M000_IG04
 
G_M000_IG35:                ;; offset=0x0363
       mov      eax, dword ptr [rsp+0x5C]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG123
 
G_M000_IG36:                ;; offset=0x0375
       mov      ecx, 0xFFFFFFFFE6F514E0
 
G_M000_IG37:                ;; offset=0x037A
       lea      eax, [rcx+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x0381
       imul     ecx, dword ptr [rsp+0x50], 0xFFFFFFFFC2B2AE3D
       add      eax, ecx
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x0399
       imul     ecx, dword ptr [rsp+0x54], 0xFFFFFFFFC2B2AE3D
       add      ecx, eax
       rol      ecx, 17
       imul     eax, ecx, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x03B1
       imul     edx, dword ptr [rsp+0x58], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG41:                ;; offset=0x03C4
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     r14d, eax, 0xFFFFFFFF9E3779B9
       mov      r15d, r14d
       shr      r15d, 16
       xor      r15d, r14d
       mov      r14d, dword ptr [rbx+0x08]
       mov      ecx, r14d
       blsr     eax, ecx
       jne      G_M000_IG124
       dec      ecx
       and      ecx, r15d
 
G_M000_IG42:                ;; offset=0x041F
       cmp      ecx, r14d
       jae      G_M000_IG138
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      r13d, dword ptr [rbx+8*rcx+0x30]
       dec      r13d
       js       G_M000_IG136
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x043E
       mov      r13d, dword ptr [r12+0x1C]
       dec      r13d
       js       G_M000_IG136
 
G_M000_IG44:                ;; offset=0x044C
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG126
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG125
 
G_M000_IG45:                ;; offset=0x0475
       cmp      r13d, r14d
       jae      G_M000_IG138
       mov      ecx, r13d
       lea      rcx, [rcx+4*rcx]
       lea      r12, bword ptr [rbx+8*rcx+0x10]
       cmp      dword ptr [r12+0x18], r15d
       jne      SHORT G_M000_IG43
 
G_M000_IG46:                ;; offset=0x0491
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG43
 
G_M000_IG47:                ;; offset=0x049B
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG43
 
G_M000_IG48:                ;; offset=0x04AA
       mov      edx, ebp
       movzx    rax, byte  ptr [rcx+0x24]
       test     eax, eax
       je       SHORT G_M000_IG53
 
G_M000_IG49:                ;; offset=0x04B4
       cmp      eax, 255
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x04BB
       lea      rax, bword ptr [rcx+0x28]
       mov      r8d, dword ptr [rcx+0x18]
       cmp      r8d, 8
       ja       G_M000_IG114
       jmp      SHORT G_M000_IG54
 
G_M000_IG51:                ;; offset=0x04CF
       mov      rax, gword ptr [rcx+0x08]
       lea      r8, bword ptr [rcx+0x28]
       mov      r8d, dword ptr [r8]
       mov      ecx, dword ptr [rcx+0x18]
       test     rax, rax
       je       G_M000_IG128
       mov      r10d, ecx
       add      r10, r8
       mov      r9d, dword ptr [rax+0x08]
       cmp      r10, r9
       ja       G_M000_IG114
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, ecx
 
G_M000_IG52:                ;; offset=0x0501
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0503
       mov      rax, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x18]
       test     rax, rax
       je       G_M000_IG127
       cmp      dword ptr [rax+0x08], r8d
       jb       G_M000_IG114
       add      rax, 16
 
G_M000_IG54:                ;; offset=0x0522
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x2C], r8d
       cmp      r8d, edx
       jne      G_M000_IG43
       xor      r10d, r10d
       mov      dword ptr [rsp+0x3C], r10d
       cmp      r10d, ebp
       jge      G_M000_IG62
 
G_M000_IG55:                ;; offset=0x0546
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG130
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG129
 
G_M000_IG56:                ;; offset=0x056F
       mov      r10d, dword ptr [rsp+0x3C]
       mov      ecx, ebp
       sub      ecx, r10d
       cmp      ecx, 0x1000
       jge      G_M000_IG64
 
G_M000_IG57:                ;; offset=0x0585
       mov      edx, r10d
       mov      r9d, ecx
       add      rdx, r9
       mov      r11d, ebp
       cmp      rdx, r11
       ja       G_M000_IG114
       mov      r11d, r10d
       add      r11, rdi
       mov      eax, dword ptr [rsp+0x2C]
       cmp      rdx, rax
       ja       G_M000_IG114
       mov      eax, r10d
       add      rax, bword ptr [rsp+0x20]
       mov      rdx, r11
       mov      r8, rax
       cmp      r9, 8
       jae      G_M000_IG70
 
G_M000_IG58:                ;; offset=0x05C5
       cmp      r9, 4
       jb       SHORT G_M000_IG65
 
G_M000_IG59:                ;; offset=0x05CB
       add      r9, -4
       mov      edx, dword ptr [r11]
       sub      edx, dword ptr [rax]
       mov      r11d, dword ptr [r11+r9]
       sub      r11d, dword ptr [rax+r9]
       or       edx, r11d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG60:                ;; offset=0x05E5
       test     edx, edx
       je       G_M000_IG43
 
G_M000_IG61:                ;; offset=0x05ED
       add      r10d, ecx
       cmp      r10d, ebp
       mov      dword ptr [rsp+0x3C], r10d
       jl       G_M000_IG55
 
G_M000_IG62:                ;; offset=0x05FE
       mov      eax, r13d
 
G_M000_IG63:                ;; offset=0x0601
       vzeroupper 
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG64:                ;; offset=0x0615
       mov      ecx, 0x1000
       jmp      G_M000_IG57
 
G_M000_IG65:                ;; offset=0x061F
       xor      edx, edx
       mov      r8, r9
       and      r8, 2
       mov      qword ptr [rsp+0x30], r8
       test     r8, r8
       je       SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x0632
       movzx    rdx, word  ptr [r11]
       mov      dword ptr [rsp+0x64], edx
       movzx    rdx, word  ptr [rax]
       movzx    r8, dword ptr [rsp+0x64]
       sub      r8d, edx
       mov      edx, r8d
 
G_M000_IG67:                ;; offset=0x0649
       test     r9b, 1
       je       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x064F
       mov      r8, qword ptr [rsp+0x30]
       movzx    r9, byte  ptr [r11+r8]
       movzx    r11, byte  ptr [rax+r8]
       sub      r9d, r11d
       or       edx, r9d
 
G_M000_IG69:                ;; offset=0x0664
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG60
 
G_M000_IG70:                ;; offset=0x0671
       cmp      rdx, r8
       je       G_M000_IG61
       cmp      r9, 32
       jae      SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x0680
       cmp      r9, 16
       jae      G_M000_IG131
 
G_M000_IG72:                ;; offset=0x068A
       add      r9, -8
       mov      rdx, qword ptr [r11]
       sub      rdx, qword ptr [rax]
       mov      r8, qword ptr [r11+r9]
       sub      r8, qword ptr [rax+r9]
       or       rdx, r8
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG60
 
G_M000_IG73:                ;; offset=0x06AA
       xor      eax, eax
       add      r9, -32
       je       SHORT G_M000_IG76
       vmovups  ymm0, ymmword ptr [rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG43
 
G_M000_IG74:                ;; offset=0x06C9
       add      rax, 32
       cmp      r9, rax
       jbe      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x06D2
       vmovups  ymm0, ymmword ptr [rdx+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+rax]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG43
       jmp      SHORT G_M000_IG74
 
G_M000_IG76:                ;; offset=0x06ED
       vmovups  ymm0, ymmword ptr [rdx+r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+r9]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      G_M000_IG43
       jmp      G_M000_IG61
 
G_M000_IG77:                ;; offset=0x070B
       cmp      ebp, 8
       jg       G_M000_IG03
       xor      ecx, ecx
       test     edx, edx
       jle      G_M000_IG136
       jmp      G_M000_IG87
 
G_M000_IG78:                ;; offset=0x0723
       mov      r8, gword ptr [rax+0x08]
       lea      r10, bword ptr [rax+0x28]
       mov      r10d, dword ptr [r10]
       mov      eax, dword ptr [rax+0x18]
       test     r8, r8
       je       G_M000_IG103
       mov      r9d, eax
       add      r9, r10
       mov      r11d, dword ptr [r8+0x08]
       cmp      r9, r11
       ja       G_M000_IG114
       lea      r8, bword ptr [r8+r10+0x10]
       mov      r10d, eax
 
G_M000_IG79:                ;; offset=0x0755
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0757
       mov      r8, gword ptr [rax+0x08]
       mov      r10d, dword ptr [rax+0x18]
       test     r8, r8
       je       G_M000_IG102
       cmp      dword ptr [r8+0x08], r10d
       jb       G_M000_IG114
       add      r8, 16
 
G_M000_IG81:                ;; offset=0x0776
       cmp      ebp, r10d
       jne      SHORT G_M000_IG86
 
G_M000_IG82:                ;; offset=0x077B
       mov      rax, rdi
       mov      r9, r8
       mov      r10d, r10d
       cmp      r10, 8
       jae      G_M000_IG96
 
G_M000_IG83:                ;; offset=0x078E
       cmp      r10, 4
       jb       G_M000_IG92
 
G_M000_IG84:                ;; offset=0x0798
       add      r10, -4
       mov      eax, dword ptr [rdi]
       sub      eax, dword ptr [r8]
       mov      r9d, dword ptr [rdi+r10]
       sub      r9d, dword ptr [r8+r10]
       or       eax, r9d
       sete     al
       movzx    rax, al
 
G_M000_IG85:                ;; offset=0x07B2
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG86:                ;; offset=0x07BA
       inc      ecx
       cmp      ecx, edx
       jge      G_M000_IG136
 
G_M000_IG87:                ;; offset=0x07C4
       mov      r14d, dword ptr [rbx+0x08]
       cmp      ecx, r14d
       jae      G_M000_IG138
       lea      rax, [rcx+4*rcx]
       mov      rax, gword ptr [rbx+8*rax+0x10]
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG88:                ;; offset=0x07DF
       mov      r8, 0x7FFA02A61F30
       cmp      qword ptr [rax], r8
       jne      SHORT G_M000_IG86
 
G_M000_IG89:                ;; offset=0x07EE
       movzx    r8, byte  ptr [rax+0x24]
       test     r8d, r8d
       je       G_M000_IG80
 
G_M000_IG90:                ;; offset=0x07FC
       cmp      r8d, 255
       je       G_M000_IG78
 
G_M000_IG91:                ;; offset=0x0809
       lea      r8, bword ptr [rax+0x28]
       mov      r10d, dword ptr [rax+0x18]
       cmp      r10d, 8
       ja       G_M000_IG114
       jmp      G_M000_IG81
 
G_M000_IG92:                ;; offset=0x0820
       xor      eax, eax
       mov      r9, r10
       and      r9, 2
       jne      G_M000_IG104
 
G_M000_IG93:                ;; offset=0x082F
       test     r10b, 1
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0835
       movzx    r10, byte  ptr [rdi+r9]
       movzx    r8, byte  ptr [r8+r9]
       sub      r10d, r8d
       or       eax, r10d
 
G_M000_IG95:                ;; offset=0x0845
       test     eax, eax
       sete     al
       movzx    rax, al
       jmp      G_M000_IG85
 
G_M000_IG96:                ;; offset=0x0852
       cmp      rax, r9
       je       G_M000_IG112
       cmp      r10, 32
       jae      G_M000_IG105
 
G_M000_IG97:                ;; offset=0x0865
       cmp      r10, 16
       jae      G_M000_IG107
 
G_M000_IG98:                ;; offset=0x086F
       add      r10, -8
       mov      r9, qword ptr [rdi]
       sub      r9, qword ptr [r8]
       mov      rax, qword ptr [rdi+r10]
       sub      rax, qword ptr [r8+r10]
       or       rax, r9
       sete     al
       movzx    rax, al
       jmp      G_M000_IG85
 
G_M000_IG99:                ;; offset=0x088F
       add      rax, 32
       cmp      r8, rax
       jbe      G_M000_IG106
 
G_M000_IG100:                ;; offset=0x089C
       vmovups  ymm0, ymmword ptr [rdi+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+rax]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG113
       jmp      SHORT G_M000_IG99
 
G_M000_IG101:                ;; offset=0x08B7
       mov      eax, ecx
       jmp      G_M000_IG63
 
G_M000_IG102:                ;; offset=0x08BE
       test     r10d, r10d
       jne      G_M000_IG114
       xor      r8, r8
       xor      r10d, r10d
       jmp      G_M000_IG81
 
G_M000_IG103:                ;; offset=0x08D2
       or       r10d, eax
       jne      G_M000_IG114
       xor      r8, r8
       xor      r10d, r10d
       jmp      G_M000_IG79
 
G_M000_IG104:                ;; offset=0x08E6
       movzx    rax, word  ptr [rdi]
       movzx    r11, word  ptr [r8]
       sub      eax, r11d
       jmp      G_M000_IG93
 
G_M000_IG105:                ;; offset=0x08F5
       xor      eax, eax
       lea      r8, [r10-0x20]
       test     r8, r8
       je       SHORT G_M000_IG106
       vmovups  ymm0, ymmword ptr [rdi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       je       G_M000_IG99
       jmp      SHORT G_M000_IG113
 
G_M000_IG106:                ;; offset=0x0919
       vmovups  ymm0, ymmword ptr [rdi+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r9+r8]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      SHORT G_M000_IG113
       jmp      SHORT G_M000_IG112
 
G_M000_IG107:                ;; offset=0x0930
       xor      eax, eax
       add      r10, -16
       je       SHORT G_M000_IG111
 
G_M000_IG108:                ;; offset=0x0938
       vmovups  xmm0, xmmword ptr [rdi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG113
 
G_M000_IG109:                ;; offset=0x094E
       add      rax, 16
       cmp      r10, rax
       jbe      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0957
       vmovups  xmm0, xmmword ptr [rdi+rax]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+rax]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG113
       jmp      SHORT G_M000_IG109
 
G_M000_IG111:                ;; offset=0x0971
       vmovups  xmm0, xmmword ptr [rdi+r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r9+r10]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       jne      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x098A
       mov      eax, 1
       jmp      G_M000_IG85
 
G_M000_IG113:                ;; offset=0x0994
       xor      eax, eax
       jmp      G_M000_IG85
 
G_M000_IG114:                ;; offset=0x099B
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG115:                ;; offset=0x09A2
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG116:                ;; offset=0x09B4
       mov      rdx, gword ptr [rsp+0xD0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG117:                ;; offset=0x09C7
       mov      edx, dword ptr [rsp+0x5C]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG15
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      r8, G_M000_IG02
       add      rcx, r8
       jmp      rcx
 
G_M000_IG118:                ;; offset=0x09EF
       mov      r13d, eax
       jmp      SHORT G_M000_IG122
 
G_M000_IG119:                ;; offset=0x09F4
       mov      r13d, eax
       jmp      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x09F9
       mov      edx, dword ptr [r13]
       lea      rcx, [rsp+0x40]
       call     [System.HashCode:Add(int):this]
       add      r13, 4
       mov      r12, r13
       lea      eax, [r15-0x04]
       mov      r13d, eax
 
G_M000_IG121:                ;; offset=0x0A16
       mov      edx, dword ptr [r12]
       lea      rcx, [rsp+0x40]
       call     [System.HashCode:Add(int):this]
       add      r12, 4
       add      r13d, -4
 
G_M000_IG122:                ;; offset=0x0A2D
       mov      edx, dword ptr [r12]
       lea      rcx, [rsp+0x40]
       call     [System.HashCode:Add(int):this]
       add      r12, 4
       add      r13d, -4
       mov      eax, r13d
       jmp      G_M000_IG15
 
G_M000_IG123:                ;; offset=0x0A4C
       rorx     ecx, dword ptr [rsp+0x40], 31
       rorx     r8d, dword ptr [rsp+0x44], 25
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x48], 20
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x4C], 14
       add      ecx, r8d
       jmp      G_M000_IG37
 
G_M000_IG124:                ;; offset=0x0A7A
       mov      eax, r15d
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG42
 
G_M000_IG125:                ;; offset=0x0A88
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG45
 
G_M000_IG126:                ;; offset=0x0A9A
       mov      rdx, gword ptr [rsp+0xD0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG45
 
G_M000_IG127:                ;; offset=0x0AAD
       test     r8d, r8d
       jne      G_M000_IG114
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG54
 
G_M000_IG128:                ;; offset=0x0AC0
       or       r8d, ecx
       jne      G_M000_IG114
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG52
 
G_M000_IG129:                ;; offset=0x0AD3
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG56
 
G_M000_IG130:                ;; offset=0x0AE5
       mov      rdx, gword ptr [rsp+0xD0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG56
 
G_M000_IG131:                ;; offset=0x0AF8
       xor      eax, eax
       add      r9, -16
       je       SHORT G_M000_IG135
 
G_M000_IG132:                ;; offset=0x0B00
       vmovups  xmm0, xmmword ptr [rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       jne      G_M000_IG43
 
G_M000_IG133:                ;; offset=0x0B1A
       add      rax, 16
       cmp      r9, rax
       jbe      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0B23
       vmovups  xmm0, xmmword ptr [rdx+rax]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+rax]
       vpmovmskb r11d, xmm0
       cmp      r11d, 0xFFFF
       jne      G_M000_IG43
       jmp      SHORT G_M000_IG133
 
G_M000_IG135:                ;; offset=0x0B41
       vmovups  xmm0, xmmword ptr [rdx+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+r9]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       jne      G_M000_IG43
       jmp      G_M000_IG61
 
G_M000_IG136:                ;; offset=0x0B62
       mov      eax, -1
 
G_M000_IG137:                ;; offset=0x0B67
       vzeroupper 
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG138:                ;; offset=0x0B7B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000009D9h ; case G_M000_IG120
       	dd	000009D4h ; case G_M000_IG119
       	dd	000009CFh ; case G_M000_IG118

; Total bytes of code 2945

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 259488
; 91 inlinees with PGO data; 190 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 616
       lea      rbp, [rsp+0x2A0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x260], xmm4
       mov      rax, -528
 
G_M000_IG286:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG286
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x28], r9
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x0058
       mov      esi, dword ptr [rcx+0x60]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0064
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG230
 
G_M000_IG04:                ;; offset=0x0078
       mov      eax, dword ptr [r9+0x14]
 
G_M000_IG05:                ;; offset=0x007C
       cmp      esi, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rcx]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG231
 
G_M000_IG06:                ;; offset=0x00A3
       test     rbx, rbx
       je       G_M000_IG21
 
G_M000_IG07:                ;; offset=0x00AC
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG231
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00C0
       test     rax, rax
       sete     sil
       movzx    rsi, sil
 
G_M000_IG09:                ;; offset=0x00CB
       test     esi, esi
       je       G_M000_IG227
       mov      rax, gword ptr [rcx+0x20]
       mov      edx, dword ptr [r9+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG255
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1C34D801FE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG232
 
G_M000_IG10:                ;; offset=0x0103
       mov      r8, 0x1C34D801FE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG233
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG234
 
G_M000_IG11:                ;; offset=0x0121
       test     rdx, rdx
       je       G_M000_IG235
       mov      rax, 0x7FFA02D930D0
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG227
 
G_M000_IG12:                ;; offset=0x013D
       mov      gword ptr [rbp-0x130], rdx
       mov      rax, gword ptr [rbp-0x130]
       mov      rax, gword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rdx+0x98]
       cmp      rax, gword ptr [r8+0x88]
       jne      G_M000_IG227
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x18]
       mov      r9, bword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x1C], 68
       jne      G_M000_IG236
       mov      ebx, dword ptr [r9+0x0C]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xA0]
       mov      r8, gword ptr [rcx]
       mov      r8, gword ptr [r8+0x88]
       cmp      ebx, dword ptr [r8+0x08]
       jae      G_M000_IG255
       mov      r10d, ebx
       shl      r10, 5
       lea      r8, bword ptr [r8+r10+0x10]
       cmp      dword ptr [r8+0x1C], 42
       jne      G_M000_IG237
       mov      r8d, dword ptr [r8+0x08]
       mov      r10, 0x7FFA02BC21E8
       cmp      qword ptr [rax], r10
       jne      G_M000_IG239
       cmp      dword ptr [rax+0x08], r8d
       jbe      G_M000_IG238
       mov      rdi, gword ptr [rax+8*r8+0x10]
 
G_M000_IG13:                ;; offset=0x01DC
       mov      gword ptr [rbp-0x138], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x88]
       mov      r8, rax
       lea      r14d, [rsi+0x02]
       mov      dword ptr [rbp-0x114], r14d
       mov      r10d, dword ptr [r8+0x08]
       cmp      r14d, r10d
       jae      G_M000_IG255
       mov      r11d, r14d
       shl      r11, 5
       lea      r15, bword ptr [r8+r11+0x10]
       mov      bword ptr [rbp-0x140], r15
       mov      r8, rax
       lea      r11d, [rbx+0x01]
       cmp      r11d, r10d
       jae      G_M000_IG255
       lea      r11d, [rbx+0x01]
       shl      r11, 5
       lea      r13, bword ptr [r8+r11+0x10]
       mov      r8, rax
       lea      r11d, [rbx+0x02]
       cmp      r11d, r10d
       jae      G_M000_IG255
       lea      r11d, [rbx+0x02]
       shl      r11, 5
       lea      r8, bword ptr [r8+r11+0x10]
       mov      bword ptr [rbp-0x148], r8
       mov      r8, gword ptr [rcx]
       mov      r12, gword ptr [r8+0x30]
       mov      r8, r12
       lea      r11d, [rsi+0x04]
       cmp      r11d, r10d
       jae      G_M000_IG255
       mov      r10d, r11d
       shl      r10, 5
       lea      rax, bword ptr [rax+r10+0x10]
       mov      r10d, dword ptr [rax+0x1C]
       cmp      r10d, 35
       jg       G_M000_IG241
       cmp      r10d, 35
       ja       G_M000_IG240
       mov      r11, 0x7FFFFFFBD
       bt       r11, r10
       jb       G_M000_IG240
 
G_M000_IG14:                ;; offset=0x02AF
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG255
       mov      rax, gword ptr [r8+8*rax+0x10]
       mov      gword ptr [rbp-0x150], rax
       mov      r8d, dword ptr [r13+0x0C]
       not      r8d
       cmp      r8d, dword ptr [r12+0x08]
       jae      G_M000_IG255
       mov      r13, gword ptr [r12+8*r8+0x10]
       mov      r8, 0x7FFA029E8768
       cmp      qword ptr [r13], r8
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02EF
       mov      rdx, r13
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG16:                ;; offset=0x0301
       mov      r12, gword ptr [r13+0x08]
       mov      gword ptr [rbp-0x1E8], r12
       mov      r13d, dword ptr [r13+0x10]
       mov      dword ptr [rbp-0xDC], r13d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x08]
       mov      r10, bword ptr [rbp-0x148]
       mov      r11d, dword ptr [r10+0x0C]
       cmp      r11d, dword ptr [r8+0x08]
       jae      G_M000_IG255
       shl      r11, 4
       lea      r8, bword ptr [r8+r11+0x10]
       mov      r11, gword ptr [r8]
       mov      r10, 0x1C34D801FE0
       cmp      r11, gword ptr [r10]
       je       G_M000_IG242
 
G_M000_IG17:                ;; offset=0x0353
       mov      r10, gword ptr [r8]
       mov      r11, 0x1C34D801FE8
       cmp      r10, gword ptr [r11]
       je       G_M000_IG243
       cmp      qword ptr [r8+0x08], 0
       jne      G_M000_IG244
       mov      r10, gword ptr [r8]
 
G_M000_IG18:                ;; offset=0x0377
       test     r10, r10
       jne      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x037C
       xor      eax, eax
 
G_M000_IG20:                ;; offset=0x037E
       add      rsp, 616
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0392
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG22:                ;; offset=0x0399
       mov      r8, 0x7FFA02BC9908
       cmp      qword ptr [r10], r8
       jne      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x03A8
       mov      r8, r10
       mov      gword ptr [rbp-0x158], r8
       cmp      gword ptr [r8+0x28], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r8+0x30], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r8+0x20], 0
       jne      SHORT G_M000_IG19
       cmp      dword ptr [r8+0x50], 0
       jne      SHORT G_M000_IG19
       mov      r10, gword ptr [r8+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r11, gword ptr [rdx+0x98]
       cmp      r10, gword ptr [r11+0x88]
       jne      SHORT G_M000_IG19
       lea      r10d, [rbx+0x03]
       mov      dword ptr [rbp-0x3C], r10d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0x88]
       cmp      r10d, dword ptr [r11+0x08]
       jae      G_M000_IG255
       shl      r10, 5
       lea      r10, bword ptr [r11+r10+0x10]
       mov      bword ptr [rbp-0x160], r10
       mov      r10, bword ptr [rbp-0x160]
       cmp      dword ptr [r10+0x1C], 47
       sete     r11b
       movzx    r11, r11b
       mov      dword ptr [rbp-0x40], r11d
       xor      r10d, r10d
       mov      qword ptr [rbp-0x48], r10
 
G_M000_IG24:                ;; offset=0x0435
       test     r11d, r11d
       je       G_M000_IG31
 
G_M000_IG25:                ;; offset=0x043E
       mov      r10, gword ptr [rcx+0x08]
       mov      rax, bword ptr [rbp-0x160]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [r10+0x08]
       jae      G_M000_IG255
       shl      rax, 4
       lea      rax, bword ptr [r10+rax+0x10]
       mov      bword ptr [rbp-0x178], rax
       mov      r10, gword ptr [rax]
       mov      gword ptr [rbp-0x260], r10
       mov      r10, 0x1C34D801FE0
       mov      r15, gword ptr [rbp-0x260]
       cmp      r15, gword ptr [r10]
       jne      G_M000_IG245
 
G_M000_IG26:                ;; offset=0x048A
       mov      rax, qword ptr [rax+0x08]
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG27:                ;; offset=0x0492
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x48], rax
       jl       G_M000_IG19
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x48], rax
       jge      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r10, bword ptr [rbp-0x160]
       mov      r15d, dword ptr [r10+0x0C]
       not      r15d
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG255
       mov      r15, gword ptr [rax+8*r15+0x10]
       mov      rax, 0x7FFA029E8768
       cmp      qword ptr [r15], rax
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x04F1
       mov      rdx, r15
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG29:                ;; offset=0x0503
       mov      rax, gword ptr [r15+0x08]
       mov      r15d, dword ptr [r15+0x10]
       test     rax, rax
       jne      G_M000_IG250
       movsxd   rax, r15d
 
G_M000_IG30:                ;; offset=0x0517
       mov      qword ptr [rbp-0x50], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10, qword ptr [rbp-0x50]
 
G_M000_IG31:                ;; offset=0x0523
       xor      r15, r15
       mov      bword ptr [rbp-0x1F0], r15
 
G_M000_IG32:                ;; offset=0x052D
       mov      dword ptr [rbp-0xE0], r15d
 
G_M000_IG33:                ;; offset=0x0534
       mov      gword ptr [rbp-0x168], r15
 
G_M000_IG34:                ;; offset=0x053B
       mov      dword ptr [rbp-0x54], r15d
 
G_M000_IG35:                ;; offset=0x053F
       mov      dword ptr [rbp-0x58], r15d
 
G_M000_IG36:                ;; offset=0x0543
       mov      dword ptr [rbp-0x5C], r15d
       mov      qword ptr [rbp-0x50], r10
 
G_M000_IG37:                ;; offset=0x054B
       xor      r15, r15
       xor      r11d, r11d
       xor      rax, rax
       mov      r10, gword ptr [rbp-0x130]
       mov      r10d, dword ptr [r10+0x34]
       mov      rdi, gword ptr [rbp-0x130]
       cmp      r10d, dword ptr [rdi+0x30]
       je       G_M000_IG152
 
G_M000_IG38:                ;; offset=0x056F
       mov      r10, gword ptr [rbp-0x130]
       mov      r10, gword ptr [r10+0x10]
       test     r10, r10
       je       G_M000_IG159
 
G_M000_IG39:                ;; offset=0x0583
       lea      rdi, bword ptr [r10+0x10]
       mov      r10d, dword ptr [r10+0x08]
       mov      bword ptr [rbp-0x1F8], rdi
 
G_M000_IG40:                ;; offset=0x0592
       mov      rdi, gword ptr [rbp-0x130]
       add      rdi, 52
       mov      r13d, dword ptr [rdi]
       add      r13d, 4
       mov      r12d, dword ptr [rdi]
       mov      dword ptr [rbp-0xE8], r10d
       cmp      r12d, r10d
       ja       G_M000_IG215
       mov      r10d, r12d
       add      r10, bword ptr [rbp-0x1F8]
       mov      r14d, dword ptr [rbp-0xE8]
       sub      r14d, r12d
       cmp      r14d, 4
       jl       G_M000_IG216
       mov      r14d, dword ptr [r10]
       lea      r10d, [r14+r13]
       mov      dword ptr [rdi], r10d
       mov      edi, r13d
       cmp      r14d, 8
       jg       G_M000_IG55
 
G_M000_IG41:                ;; offset=0x05EC
       mov      r11, gword ptr [rbp-0x130]
       mov      r10, gword ptr [r11+0x10]
       test     r10, r10
       je       G_M000_IG160
       mov      r11d, r13d
       mov      r13d, r14d
       add      r13, r11
       mov      r15d, dword ptr [r10+0x08]
       cmp      r13, r15
       ja       G_M000_IG215
       lea      r15, bword ptr [r10+r11+0x10]
       mov      r11d, r14d
 
G_M000_IG42:                ;; offset=0x061E
       mov      dword ptr [rbp-0xE4], r11d
 
G_M000_IG43:                ;; offset=0x0625
       mov      bword ptr [rbp-0x1F0], r15
       mov      r13d, dword ptr [rbp-0xE4]
       mov      dword ptr [rbp-0xE0], r13d
       mov      gword ptr [rbp-0x170], rax
       mov      gword ptr [rbp-0x168], rax
       cmp      dword ptr [rbp-0x58], 0
       je       G_M000_IG67
 
G_M000_IG44:                ;; offset=0x0652
       mov      dword ptr [rcx+0x18], ebx
 
G_M000_IG45:                ;; offset=0x0655
       mov      rax, gword ptr [rbp-0x170]
       test     rax, rax
       jne      G_M000_IG69
 
G_M000_IG46:                ;; offset=0x0665
       mov      r14, gword ptr [rbp-0x138]
       mov      r12, gword ptr [r14+0x18]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rax, gword ptr [rdx+0x98]
       mov      r10, gword ptr [rax+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG210
       mov      r10, gword ptr [rax+0x180]
       test     r10, r10
       jne      G_M000_IG209
 
G_M000_IG47:                ;; offset=0x069D
       mov      r8, gword ptr [rbp-0x158]
       mov      rax, gword ptr [r8+0x28]
       mov      r10d, dword ptr [r8+0x4C]
       mov      bword ptr [rbp-0x100], r15
       mov      dword ptr [rbp-0xF8], r13d
       mov      gword ptr [rsp+0x20], r12
       mov      rcx, rax
       mov      edx, r10d
       lea      r8, [rbp-0x100]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       test     eax, eax
       jl       G_M000_IG211
 
G_M000_IG48:                ;; offset=0x06DE
       mov      r15, gword ptr [rbp-0x158]
       mov      r8, gword ptr [r15+0x28]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG223
       mov      r9d, eax
       lea      r9, [r9+4*r9]
       lea      r8, bword ptr [r8+8*r9+0x10]
       mov      rdx, gword ptr [r8]
       mov      r9, rdx
       test     r9, r9
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x070A
       mov      rcx, 0x7FFA02A61F30
       cmp      qword ptr [r9], rcx
       jne      G_M000_IG212
 
G_M000_IG50:                ;; offset=0x071D
       mov      edx, dword ptr [r8+0x18]
       mov      r13, gword ptr [rbp-0x150]
       mov      gword ptr [rsp+0x20], r13
       mov      r12, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x110], r12
       mov      r10d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x108], r10d
       mov      r8, r9
       mov      r9d, edx
       lea      rdx, [rbp-0x110]
       mov      qword ptr [rsp+0x28], rdx
       mov      edx, eax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
 
G_M000_IG51:                ;; offset=0x0766
       test     eax, eax
       je       G_M000_IG220
 
G_M000_IG52:                ;; offset=0x076E
       cmp      dword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0774
       mov      r8, qword ptr [rbp-0x50]
       mov      r11, r8
       add      r11, qword ptr [rbp-0x48]
       mov      qword ptr [rbp-0x48], r11
       mov      dword ptr [rbp-0x54], 1
       mov      r11, 0xFF80000000000000
       cmp      qword ptr [rbp-0x48], r11
       jl       G_M000_IG221
       mov      r11, 0x80000000000000
       cmp      qword ptr [rbp-0x48], r11
       jge      G_M000_IG221
 
G_M000_IG54:                ;; offset=0x07B2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], esi
       mov      r9, bword ptr [rbp+0x28]
       mov      r11, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rdx+0x98]
       mov      rdi, gword ptr [r8+0x88]
       cmp      gword ptr [rdi+0x20], 0
       jne      G_M000_IG214
       mov      rdi, gword ptr [r8+0x180]
       test     rdi, rdi
       mov      gword ptr [rbp-0x248], rdi
       mov      gword ptr [rbp-0x1E0], r11
       mov      rcx, bword ptr [rbp+0x10]
       je       G_M000_IG37
       jmp      G_M000_IG213
 
G_M000_IG55:                ;; offset=0x0804
       mov      r13d, r14d
       add      r13, 128
       mov      rax, gword ptr [rbp-0x130]
       cmp      r13, qword ptr [rax+0x28]
       jg       G_M000_IG217
       mov      qword ptr [rbp-0x70], r13
       mov      rax, gword ptr [rbp-0x130]
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       je       G_M000_IG161
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0xE4], r11d
 
G_M000_IG56:                ;; offset=0x0845
       mov      dword ptr [rbp-0xEC], eax
       mov      r10, gword ptr [rbp-0x130]
       mov      r10, gword ptr [r10+0x08]
       mov      gword ptr [rbp-0x180], r10
       mov      r13, gword ptr [rbp-0x130]
       mov      r13, gword ptr [r13+0x20]
       mov      gword ptr [rbp-0x188], r13
       mov      r13, gword ptr [rbp-0x130]
       mov      r13, gword ptr [r13+0x18]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x190], rax
       mov      dword ptr [rax+0x1C], -1
       mov      edx, r14d
       mov      rcx, 0x7FFA027200F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       mov      rax, gword ptr [rbp-0x190]
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x190]
       mov      dword ptr [rax+0x18], r14d
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, gword ptr [rbp-0x180]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [rbp-0x190]
       movzx    rcx, byte  ptr [r14+0x24]
       mov      edx, ecx
       test     edx, edx
       jne      G_M000_IG64
 
G_M000_IG57:                ;; offset=0x08ED
       mov      rdx, gword ptr [r14+0x08]
       test     rdx, rdx
       je       G_M000_IG162
       lea      rax, bword ptr [rdx+0x10]
       mov      r8d, dword ptr [rdx+0x08]
 
G_M000_IG58:                ;; offset=0x0902
       mov      bword ptr [rbp-0x200], rax
       mov      dword ptr [rbp-0x74], r8d
       xor      r10d, r10d
 
G_M000_IG59:                ;; offset=0x0910
       mov      dword ptr [rbp-0x78], r10d
       cmp      r10d, r8d
       jge      G_M000_IG66
 
G_M000_IG60:                ;; offset=0x091D
       test     r13, r13
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0922
       mov      rcx, gword ptr [r13+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG164
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG163
 
G_M000_IG62:                ;; offset=0x094B
       mov      r8d, dword ptr [rbp-0x74]
       mov      r10d, dword ptr [rbp-0x78]
       mov      r9d, r8d
       sub      r9d, r10d
       cmp      r9d, 0x1000
       jge      G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0966
       mov      dword ptr [rbp-0x78], r10d
       lea      ecx, [rdi+r10]
       mov      edx, ecx
       mov      dword ptr [rbp-0x7C], r9d
       mov      ecx, r9d
       lea      r11, [rdx+rcx]
       mov      r10d, dword ptr [rbp-0xEC]
       cmp      r11, r10
       ja       G_M000_IG215
       add      rdx, r12
       mov      r11d, dword ptr [rbp-0x78]
       lea      r10, [r11+rcx]
       mov      eax, r8d
       cmp      r10, rax
       ja       G_M000_IG215
       add      r11, bword ptr [rbp-0x200]
       mov      r8, rcx
       mov      rcx, r11
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      r10d, dword ptr [rbp-0x7C]
       add      r10d, dword ptr [rbp-0x78]
       mov      ecx, r10d
       mov      r10d, ecx
       mov      r8d, dword ptr [rbp-0x74]
       jmp      G_M000_IG59
 
G_M000_IG64:                ;; offset=0x09CC
       cmp      edx, 255
       je       G_M000_IG218
       lea      rax, bword ptr [r14+0x28]
       mov      r8d, ecx
       cmp      r8d, 8
       ja       G_M000_IG215
       jmp      G_M000_IG58
 
G_M000_IG65:                ;; offset=0x09EE
       mov      r9d, 0x1000
       jmp      G_M000_IG63
 
G_M000_IG66:                ;; offset=0x09F9
       mov      r8d, dword ptr [rbp-0x74]
       mov      rcx, r14
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, r14
       mov      rcx, gword ptr [rbp-0x130]
       mov      r13, qword ptr [rbp-0x70]
       sub      qword ptr [rcx+0x28], r13
       mov      rdi, rax
       mov      rax, rdi
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG43
 
G_M000_IG67:                ;; offset=0x0A2A
       mov      rdi, bword ptr [rbp-0x140]
       mov      r10, gword ptr [rdi]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r11, gword ptr [rdx+0x98]
       mov      r14, gword ptr [r11+0x88]
       cmp      gword ptr [r14+0x20], 0
       jne      G_M000_IG166
       mov      r14, gword ptr [r11+0x180]
       test     r14, r14
       jne      G_M000_IG165
 
G_M000_IG68:                ;; offset=0x0A61
       mov      dword ptr [rcx+0x18], ebx
       mov      r14, gword ptr [rbp-0x138]
       mov      r10, gword ptr [r14+0x18]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, r10
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x58], 1
       jmp      G_M000_IG45
 
G_M000_IG69:                ;; offset=0x0A91
       mov      r15, rax
       mov      r12, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x208], r12
       mov      r10d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xF0], r10d
       mov      r14, gword ptr [rbp-0x138]
       mov      rax, gword ptr [r14+0x18]
       mov      gword ptr [rbp-0x198], rax
       mov      r8, gword ptr [rbp-0x158]
       cmp      gword ptr [r8+0x28], 0
       je       G_M000_IG179
       mov      rax, gword ptr [rbp-0x198]
       cmp      gword ptr [r8+0x30], 0
       je       G_M000_IG179
       cmp      dword ptr [r8+0x50], 0
       jne      G_M000_IG179
       mov      rdi, gword ptr [r8+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r11, gword ptr [rdx+0x98]
       cmp      rdi, gword ptr [r11+0x88]
       jne      G_M000_IG167
       mov      r11d, dword ptr [rbp-0xF0]
       test     r11d, r11d
       je       G_M000_IG77
 
G_M000_IG70:                ;; offset=0x0B1D
       cmp      gword ptr [rbp-0x208], 0
       jne      G_M000_IG169
       test     r11d, r11d
       jl       G_M000_IG168
       xor      edi, edi
 
G_M000_IG71:                ;; offset=0x0B36
       movsxd   r11, r11d
 
G_M000_IG72:                ;; offset=0x0B39
       mov      dword ptr [rbp-0x84], edi
       test     edi, edi
       jne      G_M000_IG173
       xor      edi, edi
       lzcnt    rdi, r11
       shr      edi, 3
       neg      edi
       add      edi, 7
       test     edi, edi
       jg       G_M000_IG172
 
G_M000_IG73:                ;; offset=0x0B5E
       xor      edi, edi
 
G_M000_IG74:                ;; offset=0x0B60
       mov      dword ptr [rbp-0x88], edi
       shl      edi, 3
       shrx     r11, r11, rdi
       movzx    r11, r11b
       and      r11d, 128
       mov      edi, dword ptr [rbp-0x84]
       and      edi, 128
       cmp      r11d, edi
       jne      G_M000_IG176
       xor      r11d, r11d
 
G_M000_IG75:                ;; offset=0x0B91
       test     r11d, r11d
       setne    r11b
       movzx    r11, r11b
       mov      edi, dword ptr [rbp-0x88]
       lea      r11d, [rdi+r11+0x01]
       mov      rdi, gword ptr [rbp-0x208]
       test     rdi, rdi
       jne      G_M000_IG177
 
G_M000_IG76:                ;; offset=0x0BB7
       cmp      r11d, 8
       jge      G_M000_IG178
 
G_M000_IG77:                ;; offset=0x0BC1
       mov      rdx, gword ptr [rbp+0x18]
       mov      r11, gword ptr [rdx+0x98]
       mov      rdi, gword ptr [r11+0x88]
       cmp      gword ptr [rdi+0x20], 0
       jne      G_M000_IG181
       mov      rdi, gword ptr [r11+0x180]
       test     rdi, rdi
       jne      G_M000_IG180
 
G_M000_IG78:                ;; offset=0x0BEE
       mov      rdx, gword ptr [rbp+0x18]
       mov      r11, gword ptr [rdx+0x98]
       mov      rdi, gword ptr [r11+0x180]
       mov      gword ptr [rbp-0x218], rdi
       cmp      byte  ptr [r15+0x25], 0
       jne      G_M000_IG200
 
G_M000_IG79:                ;; offset=0x0C12
       movzx    r11, byte  ptr [r15+0x24]
       test     r11d, r11d
       je       SHORT G_M000_IG82
 
G_M000_IG80:                ;; offset=0x0C1C
       cmp      r11d, 255
       je       G_M000_IG183
 
G_M000_IG81:                ;; offset=0x0C29
       lea      r11, bword ptr [r15+0x28]
       mov      bword ptr [rbp-0x1A8], r11
       mov      r11d, dword ptr [r15+0x18]
       cmp      r11d, 8
       ja       G_M000_IG215
       mov      rdi, bword ptr [rbp-0x1A8]
       mov      rcx, rdi
       mov      edi, r11d
       mov      r11, rcx
       jmp      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0C54
       mov      r11, gword ptr [r15+0x08]
       mov      edi, dword ptr [r15+0x18]
       test     r11, r11
       je       G_M000_IG182
       cmp      dword ptr [r11+0x08], edi
       jb       G_M000_IG215
       add      r11, 16
 
G_M000_IG83:                ;; offset=0x0C73
       mov      bword ptr [rbp-0x230], r11
       mov      r11, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x228], r11
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       test     r11, r11
       jne      G_M000_IG187
 
G_M000_IG84:                ;; offset=0x0C9D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       xor      eax, eax
 
G_M000_IG85:                ;; offset=0x0CAB
       cmp      eax, edi
       jl       G_M000_IG105
 
G_M000_IG86:                ;; offset=0x0CB3
       mov      eax, dword ptr [rbp-0x94]
       mov      r11d, eax
       and      r11d, 3
       cmp      eax, 4
       jae      G_M000_IG199
 
G_M000_IG87:                ;; offset=0x0CC9
       mov      edi, 0xFFFFFFFFE6F514E0
 
G_M000_IG88:                ;; offset=0x0CCE
       lea      eax, [rdi+4*rax]
       test     r11d, r11d
       je       SHORT G_M000_IG92
 
G_M000_IG89:                ;; offset=0x0CD6
       imul     edi, dword ptr [rbp-0xA0], 0xFFFFFFFFC2B2AE3D
       add      eax, edi
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      r11d, 1
       jbe      SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0CF1
       imul     edi, dword ptr [rbp-0x9C], 0xFFFFFFFFC2B2AE3D
       add      edi, eax
       rol      edi, 17
       imul     eax, edi, 0x27D4EB2F
       cmp      r11d, 2
       jbe      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0D0C
       imul     r11d, dword ptr [rbp-0x98], 0xFFFFFFFFC2B2AE3D
       add      r11d, eax
       rol      r11d, 17
       imul     eax, r11d, 0x27D4EB2F
 
G_M000_IG92:                ;; offset=0x0D25
       mov      r11d, eax
       shr      r11d, 15
       xor      r11d, eax
       imul     eax, r11d, 0xFFFFFFFF85EBCA77
       mov      r11d, eax
       shr      r11d, 13
       xor      r11d, eax
       imul     eax, r11d, 0xFFFFFFFFC2B2AE3D
       mov      r11d, eax
       shr      r11d, 16
       xor      r11d, eax
       mov      dword ptr [r15+0x20], r11d
       mov      byte  ptr [r15+0x25], 1
 
G_M000_IG93:                ;; offset=0x0D5A
       cmp      r11d, -1
       je       G_M000_IG201
 
G_M000_IG94:                ;; offset=0x0D64
       mov      edi, r11d
       shr      edi, 16
       xor      edi, r11d
       imul     edi, edi, 0xFFFFFFFF9E3779B9
       mov      r11d, edi
       shr      r11d, 16
       xor      edi, r11d
       mov      dword ptr [rbp-0x80], edi
       mov      r8, gword ptr [rbp-0x158]
       mov      r11, gword ptr [r8+0x28]
       mov      gword ptr [rbp-0x1B0], r11
       cmp      dword ptr [r8+0x4C], 0
       je       G_M000_IG208
 
G_M000_IG95:                ;; offset=0x0D9D
       mov      eax, dword ptr [r11+0x08]
       mov      dword ptr [rbp-0x118], eax
       mov      r13d, eax
       lea      r14d, [r13-0x01]
       test     r13d, r14d
       jne      G_M000_IG202
       and      r14d, edi
 
G_M000_IG96:                ;; offset=0x0DBA
       mov      eax, dword ptr [rbp-0x118]
       cmp      r14d, eax
       jae      G_M000_IG223
       mov      r14d, r14d
       lea      r14, [r14+4*r14]
       mov      r14d, dword ptr [r11+8*r14+0x30]
       dec      r14d
       js       G_M000_IG208
 
G_M000_IG97:                ;; offset=0x0DDE
       cmp      r14d, eax
       jae      G_M000_IG223
       mov      r13d, r14d
       lea      r13, [r13+4*r13]
       lea      r13, bword ptr [r11+8*r13+0x10]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG203
 
G_M000_IG98:                ;; offset=0x0DFF
       cmp      dword ptr [r13+0x18], edi
       mov      edi, dword ptr [rbp-0x80]
       jne      G_M000_IG149
 
G_M000_IG99:                ;; offset=0x0E0C
       mov      rax, 0x1C34D8016F8
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [r13]
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x1C0], rdx
       mov      r11, gword ptr [rbp-0x198]
       test     r11, r11
       mov      rdx, gword ptr [rbp+0x18]
       je       G_M000_IG204
 
G_M000_IG100:                ;; offset=0x0E43
       cmp      rax, r15
       je       G_M000_IG143
 
G_M000_IG101:                ;; offset=0x0E4C
       test     rax, rax
       mov      gword ptr [rbp-0x1C8], r11
       jne      G_M000_IG131
 
G_M000_IG102:                ;; offset=0x0E5C
       mov      r11, rax
       test     r11, r11
       je       G_M000_IG134
 
G_M000_IG103:                ;; offset=0x0E68
       mov      rdi, 0x7FFA02DEDD58
       cmp      qword ptr [r11], rdi
       je       G_M000_IG133
 
G_M000_IG104:                ;; offset=0x0E7B
       xor      r11, r11
       xor      rdi, rdi
       mov      r11, rdi
       mov      edi, dword ptr [rbp-0x80]
       jmp      G_M000_IG134
 
G_M000_IG105:                ;; offset=0x0E8B
       test     r11, r11
       jne      G_M000_IG188
 
G_M000_IG106:                ;; offset=0x0E94
       mov      r11d, edi
       sub      r11d, eax
       cmp      r11d, 0x1000
       jge      G_M000_IG113
 
G_M000_IG107:                ;; offset=0x0EA7
       mov      dword ptr [rbp-0xB8], r11d
       mov      dword ptr [rbp-0xB4], eax
       mov      r13d, eax
       mov      qword ptr [rbp-0x120], r13
       mov      r13d, r11d
       add      r13, qword ptr [rbp-0x120]
       mov      qword ptr [rbp-0x268], r13
       mov      r13d, edi
       cmp      qword ptr [rbp-0x268], r13
       ja       G_M000_IG215
       mov      r14, qword ptr [rbp-0x120]
       add      r14, bword ptr [rbp-0x230]
       mov      bword ptr [rbp-0x238], r14
       mov      r13, r14
       mov      r14d, r11d
       cmp      r11d, 16
       jge      G_M000_IG189
 
G_M000_IG108:                ;; offset=0x0F04
       cmp      r14d, 4
       jge      G_M000_IG116
 
G_M000_IG109:                ;; offset=0x0F0E
       mov      bword ptr [rbp-0x240], r13
       xor      eax, eax
       test     r14d, r14d
       je       G_M000_IG130
 
G_M000_IG110:                ;; offset=0x0F20
       movzx    r13, byte  ptr [rax+r13]
       mov      dword ptr [rbp-0xC4], r13d
       mov      r11d, dword ptr [rbp-0x94]
       lea      r13d, [r11+0x01]
       mov      dword ptr [rbp-0x94], r13d
       mov      r13d, r11d
       and      r13d, 3
       je       G_M000_IG128
 
G_M000_IG111:                ;; offset=0x0F4B
       cmp      r13d, 1
       jne      G_M000_IG123
 
G_M000_IG112:                ;; offset=0x0F55
       mov      r13d, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x9C], r13d
       jmp      G_M000_IG129
 
G_M000_IG113:                ;; offset=0x0F68
       mov      r11d, 0x1000
       jmp      G_M000_IG107
 
G_M000_IG114:                ;; offset=0x0F73
       mov      r12d, dword ptr [rbp-0xB0]
       imul     eax, dword ptr [r13], 0xFFFFFFFF85EBCA77
       add      eax, r12d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xB0], eax
       mov      eax, dword ptr [rbp-0xAC]
       lea      r12, bword ptr [r13+0x04]
       imul     r12d, dword ptr [r12], 0xFFFFFFFF85EBCA77
       add      eax, r12d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xAC], eax
       mov      eax, dword ptr [rbp-0xA8]
       lea      r12, bword ptr [r13+0x08]
       imul     r12d, dword ptr [r12], 0xFFFFFFFF85EBCA77
       add      eax, r12d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], eax
       mov      eax, dword ptr [rbp-0xA4]
       lea      r12, bword ptr [r13+0x0C]
       imul     r12d, dword ptr [r12], 0xFFFFFFFF85EBCA77
       add      eax, r12d
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], eax
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 4
       mov      dword ptr [rbp-0x94], eax
       add      r13, 16
       add      r14d, -16
 
G_M000_IG115:                ;; offset=0x1017
       cmp      r14d, 16
       jge      G_M000_IG114
       jmp      G_M000_IG108
 
G_M000_IG116:                ;; offset=0x1026
       mov      eax, dword ptr [r13]
       mov      dword ptr [rbp-0xBC], eax
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rbp-0xC0], eax
       inc      eax
       mov      dword ptr [rbp-0x94], eax
       mov      eax, dword ptr [rbp-0xC0]
       and      eax, 3
       je       SHORT G_M000_IG121
 
G_M000_IG117:                ;; offset=0x104F
       cmp      eax, 1
       jne      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x1054
       mov      eax, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0x9C], eax
       jmp      SHORT G_M000_IG122
 
G_M000_IG119:                ;; offset=0x1062
       cmp      eax, 2
       jne      G_M000_IG196
 
G_M000_IG120:                ;; offset=0x106B
       mov      eax, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0x98], eax
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x1079
       mov      eax, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0xA0], eax
 
G_M000_IG122:                ;; offset=0x1085
       add      r13, 4
       add      r14d, -4
       jmp      G_M000_IG108
 
G_M000_IG123:                ;; offset=0x1092
       cmp      r13d, 2
       jne      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x1098
       mov      r13d, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x98], r13d
       jmp      G_M000_IG129
 
G_M000_IG125:                ;; offset=0x10AB
       cmp      r11d, 3
       jne      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x10B1
       mov      r11, 0x568A77A6F4C1F157
       mov      qword ptr [rbp-0xB0], r11
       mov      r11, 0x3267337ED09EAD2F
       mov      qword ptr [rbp-0xA8], r11
 
G_M000_IG127:                ;; offset=0x10D3
       imul     r11d, dword ptr [rbp-0xA0], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0xB0]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xB0], r11d
       imul     r11d, dword ptr [rbp-0x9C], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0xAC]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xAC], r11d
       imul     r11d, dword ptr [rbp-0x98], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0xA8]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], r11d
       imul     r11d, dword ptr [rbp-0xC4], 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rbp-0xA4]
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], r11d
       jmp      SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x1165
       mov      r13d, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA0], r13d
 
G_M000_IG129:                ;; offset=0x1173
       inc      eax
       cmp      eax, r14d
       mov      r13, bword ptr [rbp-0x240]
       jl       G_M000_IG110
 
G_M000_IG130:                ;; offset=0x1185
       mov      r14d, dword ptr [rbp-0xB4]
       add      r14d, dword ptr [rbp-0xB8]
       mov      eax, r14d
       mov      r11, gword ptr [rbp-0x228]
       jmp      G_M000_IG85
 
G_M000_IG131:                ;; offset=0x11A2
       mov      r11, 0x7FFA02A61F30
       cmp      qword ptr [rax], r11
       jne      G_M000_IG102
 
G_M000_IG132:                ;; offset=0x11B5
       mov      rcx, rax
       mov      rdx, r15
       mov      r8, gword ptr [rbp-0x1C0]
       mov      r9, gword ptr [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       jmp      G_M000_IG142
 
G_M000_IG133:                ;; offset=0x11D4
       mov      edi, dword ptr [rbp-0x80]
 
G_M000_IG134:                ;; offset=0x11D7
       mov      gword ptr [rbp-0x1D0], r11
       test     r11, r11
       je       G_M000_IG148
 
G_M000_IG135:                ;; offset=0x11E7
       mov      r11, r15
       mov      rdi, 0x7FFA02DEDD58
       cmp      qword ptr [r11], rdi
       je       SHORT G_M000_IG137
 
G_M000_IG136:                ;; offset=0x11F9
       xor      r11, r11
       xor      rdi, rdi
       mov      r11, rdi
 
G_M000_IG137:                ;; offset=0x1201
       mov      rdi, r11
       test     rdi, rdi
       je       G_M000_IG147
 
G_M000_IG138:                ;; offset=0x120D
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1D8], rax
       mov      r11, gword ptr [rbp-0x1C8]
       test     r11, r11
       mov      rax, gword ptr [rbp-0x1D8]
       jne      G_M000_IG146
 
G_M000_IG139:                ;; offset=0x1232
       mov      r11, qword ptr GS:[0x0058]
       mov      r11, qword ptr [r11+0x48]
       cmp      dword ptr [r11+0x250], 12
       jle      G_M000_IG206
       mov      r11, gword ptr [r11+0x258]
       mov      r11, bword ptr [r11+0x60]
       test     r11, r11
       je       G_M000_IG205
 
G_M000_IG140:                ;; offset=0x1261
       mov      r11, gword ptr [r11+0x20]
 
G_M000_IG141:                ;; offset=0x1265
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      rdx, rdi
       mov      r8, rax
       mov      r9, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+RePatternObject:HasSameProgram(Lokad.Lython.Runtime.LythonRuntime+RePatternObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      edi, dword ptr [rbp-0x80]
 
G_M000_IG142:                ;; offset=0x127E
       test     eax, eax
       mov      r8, gword ptr [rbp-0x158]
       je       G_M000_IG149
 
G_M000_IG143:                ;; offset=0x128D
       mov      rdx, gword ptr [rbp+0x18]
 
G_M000_IG144:                ;; offset=0x1291
       mov      r13, gword ptr [rbp-0x150]
       mov      gword ptr [rsp+0x20], r13
       mov      r12, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x110], r12
       mov      r10d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0x108], r10d
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, r14d
       mov      r8, r15
       mov      r9d, edi
       mov      rcx, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
 
G_M000_IG145:                ;; offset=0x12DB
       mov      r14, gword ptr [rbp-0x138]
       mov      r15, gword ptr [rbp-0x158]
       jmp      G_M000_IG51
 
G_M000_IG146:                ;; offset=0x12EE
       jmp      G_M000_IG141
 
G_M000_IG147:                ;; offset=0x12F3
       mov      edi, dword ptr [rbp-0x80]
 
G_M000_IG148:                ;; offset=0x12F6
       mov      rcx, gword ptr [rbp-0x1B8]
       mov      rdx, rax
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      G_M000_IG142
 
G_M000_IG149:                ;; offset=0x130E
       mov      rdx, gword ptr [rbp+0x18]
       mov      r14, gword ptr [rbp-0x198]
       mov      rax, r14
       test     rax, rax
       je       G_M000_IG207
 
G_M000_IG150:                ;; offset=0x1325
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      edx, dword ptr [r13+0x1C]
       dec      edx
       mov      eax, dword ptr [rbp-0x118]
       mov      r8, gword ptr [rbp-0x158]
       mov      r11, gword ptr [rbp-0x1B0]
       js       G_M000_IG208
 
G_M000_IG151:                ;; offset=0x1351
       mov      r14d, edx
       jmp      G_M000_IG97
 
G_M000_IG152:                ;; offset=0x1359
       mov      dword ptr [rbp-0x5C], 1
       mov      r9, bword ptr [rbp+0x28]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 51
       jg       SHORT G_M000_IG157
 
G_M000_IG153:                ;; offset=0x136D
       cmp      eax, 41
       je       SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x1372
       add      eax, -49
       cmp      eax, 2
       ja       G_M000_IG222
 
G_M000_IG155:                ;; offset=0x137E
       mov      eax, dword ptr [r9+0x08]
       mov      dword ptr [rcx+0x18], eax
 
G_M000_IG156:                ;; offset=0x1385
       mov      dword ptr [rbp-0x60], 1
       jmp      G_M000_IG225
 
G_M000_IG157:                ;; offset=0x1391
       cmp      eax, 56
       je       SHORT G_M000_IG155
 
G_M000_IG158:                ;; offset=0x1396
       cmp      eax, 62
       je       SHORT G_M000_IG155
       add      eax, -68
       cmp      eax, 1
       ja       G_M000_IG222
       jmp      SHORT G_M000_IG155
 
G_M000_IG159:                ;; offset=0x13A9
       xor      rdi, rdi
       mov      bword ptr [rbp-0x1F8], rdi
       xor      r10d, r10d
       jmp      G_M000_IG40
 
G_M000_IG160:                ;; offset=0x13BA
       or       r13d, r14d
       jne      G_M000_IG215
       xor      r15, r15
       xor      r11d, r11d
       jmp      G_M000_IG42
 
G_M000_IG161:                ;; offset=0x13CE
       xor      r12, r12
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], r11d
       jmp      G_M000_IG56
 
G_M000_IG162:                ;; offset=0x13DF
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG58
 
G_M000_IG163:                ;; offset=0x13E9
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG62
 
G_M000_IG164:                ;; offset=0x13FB
       mov      rdx, gword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG62
 
G_M000_IG165:                ;; offset=0x140D
       cmp      dword ptr [r14+0x20], 0
       setne    r14b
       movzx    r14, r14b
       test     r14d, r14d
       je       G_M000_IG68
 
G_M000_IG166:                ;; offset=0x1423
       mov      rcx, r11
       mov      rdx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG68
 
G_M000_IG167:                ;; offset=0x1438
       mov      r8, gword ptr [rbp-0x158]
       jmp      G_M000_IG179
 
G_M000_IG168:                ;; offset=0x1444
       mov      edi, 255
       jmp      G_M000_IG71
 
G_M000_IG169:                ;; offset=0x144E
       cmp      r11d, -1
       jne      G_M000_IG171
       mov      dword ptr [rbp-0x84], 255
       mov      rdi, gword ptr [rbp-0x208]
       add      rdi, 16
       mov      bword ptr [rbp-0x210], rdi
       mov      rdi, gword ptr [rbp-0x208]
       mov      edi, dword ptr [rdi+0x08]
       mov      rcx, bword ptr [rbp-0x210]
       mov      r8d, edi
       xor      edx, edx
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      rdi, gword ptr [rbp-0x208]
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG223
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       mov      rcx, qword ptr [rdi+8*rcx+0x10]
       mov      r11, rcx
       not      r11
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       cmp      ecx, eax
       jne      SHORT G_M000_IG170
       inc      r11
       mov      rax, gword ptr [rbp-0x198]
       mov      edi, dword ptr [rbp-0x84]
       jmp      G_M000_IG72
 
G_M000_IG170:                ;; offset=0x14D3
       mov      rax, gword ptr [rbp-0x198]
       mov      edi, dword ptr [rbp-0x84]
       jmp      G_M000_IG72
 
G_M000_IG171:                ;; offset=0x14E5
       xor      r11d, r11d
       mov      dword ptr [rbp-0x84], r11d
       mov      rdi, gword ptr [rbp-0x208]
       mov      r11d, dword ptr [rdi+0x08]
       dec      r11d
       cmp      r11d, dword ptr [rdi+0x08]
       jae      G_M000_IG223
       mov      r11d, dword ptr [rdi+0x08]
       dec      r11d
       mov      r11, qword ptr [rdi+8*r11+0x10]
       mov      edi, dword ptr [rbp-0x84]
       jmp      G_M000_IG72
 
G_M000_IG172:                ;; offset=0x151E
       jmp      G_M000_IG74
 
G_M000_IG173:                ;; offset=0x1523
       mov      rdi, r11
       not      rdi
       lzcnt    rdi, rdi
       shr      edi, 3
       neg      edi
       add      edi, 7
       test     edi, edi
       jle      SHORT G_M000_IG174
       jmp      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x153C
       xor      edi, edi
 
G_M000_IG175:                ;; offset=0x153E
       jmp      G_M000_IG74
 
G_M000_IG176:                ;; offset=0x1543
       mov      r11d, 1
       jmp      G_M000_IG75
 
G_M000_IG177:                ;; offset=0x154E
       mov      edi, dword ptr [rdi+0x08]
       sub      edi, 1
       imul     edi, edi, 8
       jo       G_M000_IG224
       add      r11d, edi
       jo       G_M000_IG224
       jmp      G_M000_IG76
 
G_M000_IG178:                ;; offset=0x156B
       mov      r8, gword ptr [rbp-0x158]
 
G_M000_IG179:                ;; offset=0x1572
       xor      eax, eax
       mov      r12, gword ptr [rbp-0x1E8]
       mov      r13, gword ptr [rbp-0x150]
       jmp      G_M000_IG145
 
G_M000_IG180:                ;; offset=0x1587
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG78
 
G_M000_IG181:                ;; offset=0x159B
       mov      rcx, r11
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x198]
       jmp      G_M000_IG78
 
G_M000_IG182:                ;; offset=0x15B3
       test     edi, edi
       jne      G_M000_IG215
       xor      r11, r11
       xor      edi, edi
       jmp      G_M000_IG83
 
G_M000_IG183:                ;; offset=0x15C5
       mov      r11, gword ptr [r15+0x08]
       mov      gword ptr [rbp-0x1A0], r11
       lea      r11, bword ptr [r15+0x28]
       mov      r11d, dword ptr [r11]
       mov      dword ptr [rbp-0x8C], r11d
       mov      r11d, dword ptr [r15+0x18]
       mov      dword ptr [rbp-0x90], r11d
       cmp      gword ptr [rbp-0x1A0], 0
       jne      SHORT G_M000_IG185
 
G_M000_IG184:                ;; offset=0x15F3
       mov      r11d, dword ptr [rbp-0x8C]
       or       r11d, dword ptr [rbp-0x90]
       jne      G_M000_IG215
       xor      r11, r11
       mov      bword ptr [rbp-0x220], r11
       xor      r11d, r11d
       mov      rdi, bword ptr [rbp-0x220]
       jmp      SHORT G_M000_IG186
 
G_M000_IG185:                ;; offset=0x161D
       mov      r11d, dword ptr [rbp-0x8C]
       mov      qword ptr [rbp-0x128], r11
       mov      r11d, dword ptr [rbp-0x90]
       add      r11, qword ptr [rbp-0x128]
       mov      qword ptr [rbp-0x268], r11
       mov      r11, gword ptr [rbp-0x1A0]
       mov      r11d, dword ptr [r11+0x08]
       cmp      qword ptr [rbp-0x268], r11
       ja       G_M000_IG215
       mov      r11, gword ptr [rbp-0x1A0]
       mov      rdi, qword ptr [rbp-0x128]
       lea      rdi, bword ptr [r11+rdi+0x10]
       mov      r11d, dword ptr [rbp-0x90]
 
G_M000_IG186:                ;; offset=0x1672
       mov      rcx, rdi
       mov      edi, r11d
       mov      r11, rcx
       jmp      G_M000_IG83
 
G_M000_IG187:                ;; offset=0x1680
       cmp      dword ptr [r11+0x20], 0
       jne      G_M000_IG219
       jmp      G_M000_IG84
 
G_M000_IG188:                ;; offset=0x1690
       cmp      dword ptr [r11+0x20], 0
       je       G_M000_IG106
       mov      rax, gword ptr [rbp-0x198]
       jmp      G_M000_IG219
 
G_M000_IG189:                ;; offset=0x16A7
       cmp      dword ptr [rbp-0x94], 0
       jne      SHORT G_M000_IG190
       mov      r12, 0x568A77A6F4C1F157
       mov      qword ptr [rbp-0xB0], r12
       mov      r12, 0x3267337ED09EAD2F
       mov      qword ptr [rbp-0xA8], r12
       jmp      G_M000_IG115
 
G_M000_IG190:                ;; offset=0x16D7
       mov      r12d, dword ptr [rbp-0x94]
       and      r12d, 3
       dec      r12d
       cmp      r12d, 2
       ja       G_M000_IG115
       mov      qword ptr [rbp-0x268], r12
       lea      r12, [reloc @RWD00]
       mov      r11, qword ptr [rbp-0x268]
       mov      r12d, dword ptr [r12+4*r11]
       lea      r10, G_M000_IG02
       add      r12, r10
       jmp      r12
 
G_M000_IG191:                ;; offset=0x1715
       mov      r12d, r14d
       jmp      SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x171A
       mov      r12d, r14d
       jmp      SHORT G_M000_IG194
 
G_M000_IG193:                ;; offset=0x171F
       mov      r14, bword ptr [rbp-0x238]
       mov      edx, dword ptr [r14]
       lea      rcx, [rbp-0xB0]
       call     [System.HashCode:Add(int):this]
       add      r14, 4
       mov      r13, r14
       mov      r14d, dword ptr [rbp-0xB8]
       lea      edx, [r14-0x04]
       mov      r12d, edx
 
G_M000_IG194:                ;; offset=0x174B
       mov      edx, dword ptr [r13]
       lea      rcx, [rbp-0xB0]
       call     [System.HashCode:Add(int):this]
       add      r13, 4
       add      r12d, -4
 
G_M000_IG195:                ;; offset=0x1764
       mov      edx, dword ptr [r13]
       lea      rcx, [rbp-0xB0]
       call     [System.HashCode:Add(int):this]
       add      r13, 4
       add      r12d, -4
       mov      r14d, r12d
       jmp      G_M000_IG115
 
G_M000_IG196:                ;; offset=0x1785
       cmp      dword ptr [rbp-0xC0], 3
       jne      SHORT G_M000_IG198
 
G_M000_IG197:                ;; offset=0x178E
       mov      rax, 0x568A77A6F4C1F157
       mov      qword ptr [rbp-0xB0], rax
       mov      rax, 0x3267337ED09EAD2F
       mov      qword ptr [rbp-0xA8], rax
 
G_M000_IG198:                ;; offset=0x17B0
       imul     eax, dword ptr [rbp-0xA0], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xB0]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xB0], eax
       imul     eax, dword ptr [rbp-0x9C], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xAC]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xAC], eax
       imul     eax, dword ptr [rbp-0x98], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xA8]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], eax
       imul     eax, dword ptr [rbp-0xBC], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xA4]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG122
 
G_M000_IG199:                ;; offset=0x1831
       rorx     edi, dword ptr [rbp-0xB0], 31
       mov      dword ptr [rbp-0x254], edi
       rorx     edi, dword ptr [rbp-0xAC], 25
       add      edi, dword ptr [rbp-0x254]
       mov      dword ptr [rbp-0x254], edi
       rorx     edi, dword ptr [rbp-0xA8], 20
       add      edi, dword ptr [rbp-0x254]
       mov      dword ptr [rbp-0x254], edi
       rorx     edi, dword ptr [rbp-0xA4], 14
       add      edi, dword ptr [rbp-0x254]
       jmp      G_M000_IG88
 
G_M000_IG200:                ;; offset=0x1882
       mov      r11d, dword ptr [r15+0x20]
       jmp      G_M000_IG93
 
G_M000_IG201:                ;; offset=0x188B
       mov      r11d, -2
       jmp      G_M000_IG94
 
G_M000_IG202:                ;; offset=0x1896
       mov      eax, edi
       xor      edx, edx
       div      edx:eax, r13d
       mov      r14d, edx
       jmp      G_M000_IG96
 
G_M000_IG203:                ;; offset=0x18A5
       mov      rax, gword ptr [r8+0x30]
       cmp      dword ptr [rax+0x08], r14d
       jbe      G_M000_IG149
       mov      rax, gword ptr [r8+0x30]
       mov      gword ptr [rbp-0x250], rax
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      eax, r14d
       mov      r11, gword ptr [rbp-0x250]
       cmp      gword ptr [r11+8*rax+0x10], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG149
       jmp      G_M000_IG98
 
G_M000_IG204:                ;; offset=0x18EB
       mov      r11, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x1C8], r11
       mov      r8, gword ptr [rbp-0x158]
       mov      r11, gword ptr [rbp-0x1C8]
       jmp      G_M000_IG100
 
G_M000_IG205:                ;; offset=0x1909
       mov      ecx, 12
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       mov      r11, rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0x158]
       jmp      G_M000_IG140
 
G_M000_IG206:                ;; offset=0x192D
       jmp      SHORT G_M000_IG205
 
G_M000_IG207:                ;; offset=0x192F
       mov      rax, gword ptr [r8+0x18]
       jmp      G_M000_IG150
 
G_M000_IG208:                ;; offset=0x1938
       mov      eax, -1
       mov      r14d, eax
       jmp      G_M000_IG144
 
G_M000_IG209:                ;; offset=0x1945
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG47
 
G_M000_IG210:                ;; offset=0x195B
       mov      rcx, rax
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG47
 
G_M000_IG211:                ;; offset=0x196C
       xor      eax, eax
       mov      r12, gword ptr [rbp-0x1E8]
       mov      r15, gword ptr [rbp-0x158]
       jmp      G_M000_IG51
 
G_M000_IG212:                ;; offset=0x1981
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG213:                ;; offset=0x1987
       mov      r15, r8
       mov      r10, gword ptr [rbp-0x248]
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       mov      r8, r15
       mov      r11, gword ptr [rbp-0x1E0]
       je       G_M000_IG37
       mov      r12, gword ptr [rbp-0x1E8]
       mov      r14, gword ptr [rbp-0x138]
       mov      r15, gword ptr [rbp-0x158]
 
G_M000_IG214:                ;; offset=0x19C6
       mov      rcx, r8
       mov      rdx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG37
 
G_M000_IG215:                ;; offset=0x19DB
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG216:                ;; offset=0x19E2
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG217:                ;; offset=0x19EE
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C34A06E3E0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG218:                ;; offset=0x1A1C
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C34A06E460
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG219:                ;; offset=0x1A4A
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.RuntimeErrors:Cancelled(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG220:                ;; offset=0x1A5C
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14d, dword ptr [rbp-0x114]
       mov      dword ptr [rcx+0x18], r14d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG156
 
G_M000_IG221:                ;; offset=0x1A78
       mov      ebx, dword ptr [rbp-0x3C]
       add      ebx, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], ebx
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG156
 
G_M000_IG222:                ;; offset=0x1A8E
       mov      rcx, r9
       mov      rdx, 0x1C34A069B18
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x1AAA
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG224:                ;; offset=0x1AB0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG225:                ;; offset=0x1AB6
       call     G_M000_IG281
       nop      
 
G_M000_IG226:                ;; offset=0x1ABC
       mov      ebx, dword ptr [rbp-0x60]
       jmp      SHORT G_M000_IG228
 
G_M000_IG227:                ;; offset=0x1AC1
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], esi
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG228:                ;; offset=0x1ADC
       movzx    rax, bl
 
G_M000_IG229:                ;; offset=0x1ADF
       add      rsp, 616
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG230:                ;; offset=0x1AF3
       mov      rcx, r9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG05
 
G_M000_IG231:                ;; offset=0x1B05
       xor      esi, esi
       jmp      G_M000_IG09
 
G_M000_IG232:                ;; offset=0x1B0C
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG233:                ;; offset=0x1B1D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG234:                ;; offset=0x1B2E
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG11
 
G_M000_IG235:                ;; offset=0x1B3F
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1C34A04AC68
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG236:                ;; offset=0x1B6D
       mov      rcx, r9
       mov      rdx, 0x1C34A06E398
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG237:                ;; offset=0x1B89
       mov      rcx, r8
       mov      rdx, 0x1C34A0691C0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG238:                ;; offset=0x1BA5
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG239:                ;; offset=0x1BAC
       mov      rcx, rax
       mov      edx, r8d
       mov      r11, 0x7FFA025433E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG13
 
G_M000_IG240:                ;; offset=0x1BC7
       mov      rcx, rax
       mov      rdx, 0x1C34A069A90
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG241:                ;; offset=0x1BE3
       cmp      r10d, 64
       je       G_M000_IG14
       cmp      r10d, 67
       je       G_M000_IG14
       cmp      r10d, 70
       jne      SHORT G_M000_IG240
       jmp      G_M000_IG14
 
G_M000_IG242:                ;; offset=0x1C02
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG243:                ;; offset=0x1C13
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG244:                ;; offset=0x1C24
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG245:                ;; offset=0x1C35
       cmp      qword ptr [rax+0x08], 0
       jle      SHORT G_M000_IG248
 
G_M000_IG246:                ;; offset=0x1C3C
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02C520C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG247
       mov      r15, bword ptr [rbp-0x178]
       mov      edx, dword ptr [r15+0x08]
       dec      edx
       lea      r8, [rbp-0x48]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG249
 
G_M000_IG247:                ;; offset=0x1C6F
       mov      rax, bword ptr [rbp-0x178]
 
G_M000_IG248:                ;; offset=0x1C76
       mov      rcx, gword ptr [rax]
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG249:                ;; offset=0x1C83
       test     eax, eax
       je       G_M000_IG19
       jmp      G_M000_IG27
 
G_M000_IG250:                ;; offset=0x1C90
       cmp      dword ptr [rax+0x08], 1
       jle      SHORT G_M000_IG251
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rdi
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG251:                ;; offset=0x1CC3
       cmp      dword ptr [rax+0x08], 0
       jbe      SHORT G_M000_IG255
       mov      rax, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x68], rax
       neg      rax
       test     r15d, r15d
       cmovg    rax, qword ptr [rbp-0x68]
       test     rax, rax
       jle      SHORT G_M000_IG252
       test     r15d, r15d
       jg       SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x1CE6
       test     rax, rax
       jge      SHORT G_M000_IG254
       test     r15d, r15d
       jge      SHORT G_M000_IG254
 
G_M000_IG253:                ;; offset=0x1CF0
       jmp      G_M000_IG30
 
G_M000_IG254:                ;; offset=0x1CF5
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG255:                ;; offset=0x1D22
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG256:                ;; offset=0x1D28
       sub      rsp, 56
 
G_M000_IG257:                ;; offset=0x1D2C
       cmp      dword ptr [rbp-0x54], 0
       je       SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1D32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r10, bword ptr [rbp-0x160]
       mov      eax, dword ptr [r10+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG263
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, 0x1C34D801FE0
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], rsi
 
G_M000_IG259:                ;; offset=0x1D70
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x1D76
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG261:                ;; offset=0x1D8C
       nop      
 
G_M000_IG262:                ;; offset=0x1D8D
       add      rsp, 56
       ret      
 
G_M000_IG263:                ;; offset=0x1D92
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG264:                ;; offset=0x1D98
       sub      rsp, 56
 
G_M000_IG265:                ;; offset=0x1D9C
       cmp      gword ptr [rbp-0x168], 0
       jne      SHORT G_M000_IG267
 
G_M000_IG266:                ;; offset=0x1DA6
       cmp      dword ptr [rbp-0xE0], 0
       je       G_M000_IG279
 
G_M000_IG267:                ;; offset=0x1DB3
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8, bword ptr [rbp-0x148]
       mov      eax, dword ptr [r8+0x1C]
       cmp      eax, 9
       je       SHORT G_M000_IG269
 
G_M000_IG268:                ;; offset=0x1DCB
       cmp      eax, 10
       je       SHORT G_M000_IG269
       mov      rcx, r8
       mov      rdx, 0x1C34A069AC0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG269:                ;; offset=0x1DEC
       mov      eax, dword ptr [r8+0x14]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG277
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rbp-0x168]
       cmp      gword ptr [rbp-0x168], 0
       jne      G_M000_IG278
 
G_M000_IG270:                ;; offset=0x1E17
       mov      rcx, gword ptr [rbp-0x130]
       mov      edx, dword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:WordCharge(int):long:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp-0x130]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      dword ptr [r14+0x1C], -1
       cmp      dword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG272
 
G_M000_IG271:                ;; offset=0x1E5B
       xor      ecx, ecx
       mov      rdx, 0x1C34A046810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG272:                ;; offset=0x1E6E
       cmp      dword ptr [rbp-0xE0], 8
       jg       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x1E77
       mov      ecx, dword ptr [rbp-0xE0]
       mov      byte  ptr [r14+0x24], cl
       jmp      SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x1E83
       mov      edx, dword ptr [rbp-0xE0]
       mov      rcx, 0x7FFA027200F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       lea      rcx, bword ptr [r14+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG275:                ;; offset=0x1EA4
       mov      ecx, dword ptr [rbp-0xE0]
       mov      dword ptr [r14+0x18], ecx
       lea      rcx, bword ptr [r14+0x10]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdx, [rbp-0xD8]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rcx, bword ptr [rbp-0xD8]
       mov      r8d, dword ptr [rbp-0xD0]
       cmp      dword ptr [rbp-0xE0], r8d
       jg       SHORT G_M000_IG276
       mov      r8d, dword ptr [rbp-0xE0]
       mov      rdx, bword ptr [rbp-0x1F0]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rcx, r14
       mov      edx, dword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x130]
       sub      qword ptr [rax+0x28], rsi
       mov      rdx, r14
       jmp      SHORT G_M000_IG278
 
G_M000_IG276:                ;; offset=0x1F14
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG277:                ;; offset=0x1F1B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG278:                ;; offset=0x1F21
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
 
G_M000_IG279:                ;; offset=0x1F2F
       call     G_M000_IG256
       nop      
 
G_M000_IG280:                ;; offset=0x1F35
       add      rsp, 56
       ret      
 
G_M000_IG281:                ;; offset=0x1F3A
       sub      rsp, 56
 
G_M000_IG282:                ;; offset=0x1F3E
       cmp      dword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x1F44
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG284:                ;; offset=0x1F58
       call     G_M000_IG264
       nop      
 
G_M000_IG285:                ;; offset=0x1F5E
       add      rsp, 56
       ret      
 
RWD00  	dd	000016C7h ; case G_M000_IG193
       	dd	000016C2h ; case G_M000_IG192
       	dd	000016BDh ; case G_M000_IG191

; Total bytes of code 8035

