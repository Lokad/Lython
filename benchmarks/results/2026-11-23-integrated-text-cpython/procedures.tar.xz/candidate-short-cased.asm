; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 752
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG87:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1B4], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x114]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02DE63D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02DE63D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x19C], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02DE63D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02DE63DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02DE63E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02DE63E4
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x118], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x118], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x118]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      edx, dword ptr [rbp-0x1BC]
       mov      rcx, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, 0x7FFA02D930D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0223
       mov      rcx, 0x7FFA02DE63E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0232
       mov      rcx, 0x7FFA02DE63EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B8], eax
       jmp      G_M000_IG59
 
G_M000_IG15:                ;; offset=0x0269
       mov      rcx, 0x7FFA02DE63F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x027A
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdx, 0x7FFA02DE63F8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      edx, dword ptr [rbp-0x1D4]
       mov      r11, 0x7FFA02541DC8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x0370
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044C
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0472
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047E
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x2B0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG61
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, 0x7FFA02BC9928
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050C
       mov      rcx, 0x7FFA02DE6500
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x051B
       mov      rcx, 0x7FFA02DE6504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052F
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F0], rcx
       mov      rcx, bword ptr [rbp-0x1F0]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02DE6508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x060B
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060D
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0616
       mov      rcx, 0x7FFA02DE650C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0682
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG28:                ;; offset=0x068E
       lea      rcx, [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A2
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CF
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E6
       lea      rcx, [rbp-0x1B4]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F9
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG54
 
G_M000_IG33:                ;; offset=0x071B
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x072B
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A2
       mov      rcx, 0x7FFA02DE6510
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07BB
       cmp      gword ptr [rbp-0xF8], 0
       jne      G_M000_IG45
 
G_M000_IG37:                ;; offset=0x07C9
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG38:                ;; offset=0x07D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG39:                ;; offset=0x07E9
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG40:                ;; offset=0x07F9
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x228]
       lea      r9, [rbp-0x238]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG48
       mov      rcx, 0x7FFA02DE6514
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x10C], eax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG41:                ;; offset=0x08B1
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG42:                ;; offset=0x08C1
       lea      rdx, [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG43:                ;; offset=0x08DB
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG44:                ;; offset=0x08EB
       lea      rax, [rbp-0x268]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x10C]
       mov      r9, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x0920
       mov      rcx, 0x7FFA02DE6518
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG46:                ;; offset=0x093D
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG47:                ;; offset=0x094D
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x278]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG48:                ;; offset=0x099C
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG49
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG56
 
G_M000_IG49:                ;; offset=0x09C1
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG53
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG51
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A13
       mov      rcx, 0x7FFA02DE651C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0A22
       mov      rcx, 0x7FFA02DE6520
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0A50
       mov      rcx, 0x7FFA02DE6524
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0A5F
       mov      rcx, 0x7FFA02DE6528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG54:                ;; offset=0x0AA1
       mov      rcx, 0x7FFA02DE652C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
 
G_M000_IG55:                ;; offset=0x0AD5
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0ADC
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0AE3
       call     G_M000_IG81
       nop      
 
G_M000_IG58:                ;; offset=0x0AE9
       mov      rcx, 0x7FFA02DE6554
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x1B8], eax
 
G_M000_IG59:                ;; offset=0x0B04
       movzx    rax, byte  ptr [rbp-0x1B8]
 
G_M000_IG60:                ;; offset=0x0B0B
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x0B14
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG62:                ;; offset=0x0B1A
       sub      rsp, 56
 
G_M000_IG63:                ;; offset=0x0B1E
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG64
       mov      rcx, 0x7FFA02DE6540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x2A0], rcx
       mov      rcx, bword ptr [rbp-0x2A0]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG64:                ;; offset=0x0B88
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG65
       mov      rcx, 0x7FFA02DE6544
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      edx, dword ptr [rbp-0x2A4]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG65:                ;; offset=0x0BD8
       mov      rcx, 0x7FFA02DE6548
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG66:                ;; offset=0x0BE8
       add      rsp, 56
       ret      
 
G_M000_IG67:                ;; offset=0x0BED
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0BF3
       sub      rsp, 56
 
G_M000_IG69:                ;; offset=0x0BF7
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG73
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG70
       jmp      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0C14
       mov      rcx, 0x7FFA02DE6534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG77
 
G_M000_IG71:                ;; offset=0x0C28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0C2E
       mov      rcx, 0x7FFA02DE6538
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0C3D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x168]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG71
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x170], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG76
       mov      rcx, 0x7FFA02DE653C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG74:                ;; offset=0x0C9B
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG75:                ;; offset=0x0CAB
       lea      rdx, [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG76:                ;; offset=0x0CC5
       mov      rcx, bword ptr [rbp-0x170]
       mov      rdx, gword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG77:                ;; offset=0x0CD9
       nop      
 
G_M000_IG78:                ;; offset=0x0CDA
       call     G_M000_IG62
       nop      
 
G_M000_IG79:                ;; offset=0x0CE0
       mov      rcx, 0x7FFA02DE654C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG80:                ;; offset=0x0CF0
       add      rsp, 56
       ret      
 
G_M000_IG81:                ;; offset=0x0CF5
       sub      rsp, 56
 
G_M000_IG82:                ;; offset=0x0CF9
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG83
       mov      rcx, 0x7FFA02DE6530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG83:                ;; offset=0x0D1D
       nop      
 
G_M000_IG84:                ;; offset=0x0D1E
       call     G_M000_IG68
       nop      
 
G_M000_IG85:                ;; offset=0x0D24
       mov      rcx, 0x7FFA02DE6550
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG86:                ;; offset=0x0D34
       add      rsp, 56
       ret      
 
; Total bytes of code 3385

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0063
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG04:                ;; offset=0x006C
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x3C]
       lea      r8, [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x0C], 0
       jge      SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG05
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       lea      rcx, [rbp-0x28]
       mov      edx, dword ptr [rbp-0x18]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x00DD
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00DF
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00E8
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG11
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG08:                ;; offset=0x0135
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG09:                ;; offset=0x013E
       mov      r8, gword ptr [rbp-0x58]
       mov      r9d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG10:                ;; offset=0x015D
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x0166
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 364

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02DE67E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00E0
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x0100
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x0110
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02DE67EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0145
       mov      rcx, 0x7FFA02DE67F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0154
       mov      rcx, 0x7FFA02DE67F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016B
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0182
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0195
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02DE67F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B5
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C2
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D5
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02DE67FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021E
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D9
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02DE6800
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0313
       mov      rcx, 0x7FFA02DE6804
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0324
       mov      rcx, 0x7FFA02DE6808
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0333
       mov      rcx, 0x7FFA02DE680C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x0361
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0378
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x038B
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02DE6810
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A4
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A9
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B2
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B8
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0039
       mov      rcx, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rbp+0x38]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x08], rax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x3C], eax
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG03:                ;; offset=0x0063
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x38], xmm0
 
G_M000_IG04:                ;; offset=0x006C
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x18]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x3C]
       lea      r8, [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       cmp      dword ptr [rbp-0x0C], 0
       jge      SHORT G_M000_IG08
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 8
       jle      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x4C]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      eax, dword ptr [rcx+0x08]
       jge      SHORT G_M000_IG07
       mov      rcx, 0x7FFA02EF8FE8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       lea      rcx, [rbp-0x28]
       mov      edx, dword ptr [rbp-0x18]
       call     [System.Nullable`1[uint]:.ctor(uint):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x00EC
       mov      rcx, 0x7FFA02EF8FEC
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x00FD
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0106
       mov      rcx, 0x7FFA02EF8FF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG05
 
G_M000_IG08:                ;; offset=0x0117
       mov      rcx, 0x7FFA02EF8FF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      ecx, dword ptr [rbp-0x0C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG12
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0172
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG10:                ;; offset=0x017B
       mov      r8, gword ptr [rbp-0x58]
       mov      r9d, dword ptr [rbp-0x5C]
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rbp-0x0C]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x019A
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01A3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 425

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xD8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x94], 0x3E8
       cmp      dword ptr [rbp+0x18], 4
       jg       G_M000_IG15
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 8
       jg       SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x38]
       xor      ecx, ecx
       mov      dword ptr [rax], ecx
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, 0x7FFA02DE67E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x3C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG11
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x00D6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG06:                ;; offset=0x00DF
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00F2
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x00FF
       vmovdqu  xmm0, xmmword ptr [rbp-0x90]
       vmovdqu  xmmword ptr [rbp-0xB8], xmm0
 
G_M000_IG09:                ;; offset=0x010F
       lea      rcx, [rbp-0xA8]
       lea      rdx, [rbp-0xB8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02DE67EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG10:                ;; offset=0x0144
       mov      rcx, 0x7FFA02DE67F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0153
       mov      rcx, 0x7FFA02DE67F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG12:                ;; offset=0x016A
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0181
       lea      rcx, [rbp-0x94]
       mov      edx, 63
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG14:                ;; offset=0x0194
       mov      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG04
       mov      rcx, 0x7FFA02DE67F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x01B4
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG16:                ;; offset=0x01B8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG17:                ;; offset=0x01C1
       xor      eax, eax
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG18:                ;; offset=0x01C7
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG19:                ;; offset=0x01D4
       lea      rcx, [rbp-0xC8]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x30]
       mov      r9, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      rcx, bword ptr [rbp+0x38]
       mov      dword ptr [rcx], eax
       cmp      dword ptr [rbp+0x18], 0
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02DE67FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x021D
       mov      rax, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x38]
       mov      ecx, dword ptr [rax]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
       jmp      G_M000_IG27
 
G_M000_IG21:                ;; offset=0x0255
       mov      rcx, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       cmp      eax, dword ptr [rcx]
       jne      G_M000_IG26
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x02CB
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG23:                ;; offset=0x02D7
       lea      rdx, [rbp-0xD8]
       mov      rcx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG24
       mov      rcx, 0x7FFA02DE6800
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x98], eax
       jmp      G_M000_IG32
 
G_M000_IG24:                ;; offset=0x0311
       mov      rcx, 0x7FFA02DE6804
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0322
       mov      rcx, 0x7FFA02DE6808
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x0331
       mov      rcx, 0x7FFA02DE680C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x54]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG34
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x54], eax
 
G_M000_IG27:                ;; offset=0x035F
       mov      eax, dword ptr [rbp-0x94]
       dec      eax
       mov      dword ptr [rbp-0x94], eax
       cmp      dword ptr [rbp-0x94], 0
       jg       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0376
       lea      rcx, [rbp-0x94]
       mov      edx, 210
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG29:                ;; offset=0x0389
       cmp      dword ptr [rbp-0x54], 0
       jge      G_M000_IG21
       mov      rcx, 0x7FFA02DE6810
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG30:                ;; offset=0x03A2
       mov      eax, -1
 
G_M000_IG31:                ;; offset=0x03A7
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x03B0
       mov      eax, dword ptr [rbp-0x98]
 
G_M000_IG33:                ;; offset=0x03B6
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x03BF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 965

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 752
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG87:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG87
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004A
       mov      dword ptr [rbp-0x1B4], 0x3E8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x114], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x114]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, 0x7FFA02DE63D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A7
       mov      rcx, 0x7FFA02DE63D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x19C], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00E5
       mov      rcx, 0x7FFA02DE63D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG07:                ;; offset=0x010C
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1A8], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0127
       mov      rcx, 0x7FFA02DE63DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0138
       mov      rcx, 0x7FFA02DE63E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1A8], rax
 
G_M000_IG10:                ;; offset=0x0159
       mov      rcx, 0x7FFA02DE63E4
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1A8], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x118], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x017E
       xor      eax, eax
       mov      dword ptr [rbp-0x118], eax
 
G_M000_IG12:                ;; offset=0x0186
       movzx    rax, byte  ptr [rbp-0x118]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      edx, dword ptr [rbp-0x1BC]
       mov      rcx, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, 0x7FFA02D930D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x48], rax
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0222
       mov      rcx, 0x7FFA02DE63E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0231
       mov      rcx, 0x7FFA02DE63EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rsp+0x20], eax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1B8], eax
       jmp      G_M000_IG59
 
G_M000_IG15:                ;; offset=0x0268
       mov      rcx, 0x7FFA02DE63F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0279
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x4C], eax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      rdx, 0x7FFA02DE63F8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1D4], eax
       mov      rcx, gword ptr [rbp-0x1D0]
       mov      edx, dword ptr [rbp-0x1D4]
       mov      r11, 0x7FFA02542200
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x036F
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rcx, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x044B
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0471
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG20:                ;; offset=0x047D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x2B0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG61
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, 0x7FFA02BC9928
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG22
       mov      rcx, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateBorrowedWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x050A
       mov      rcx, 0x7FFA02DE6500
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0519
       mov      rcx, 0x7FFA02DE6504
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x052D
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x94], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x94]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG61
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xA4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xB0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F0], rcx
       mov      rcx, bword ptr [rbp-0x1F0]
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rcx, 0x7FFA02DE6508
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x0609
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x060B
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0614
       mov      rcx, 0x7FFA02DE650C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG61
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, 0x7FFA029E8768
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0680
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x208], xmm0
 
G_M000_IG28:                ;; offset=0x068C
       lea      rcx, [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG29:                ;; offset=0x06A0
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xD0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xD4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xD8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG30:                ;; offset=0x06CD
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x06E4
       lea      rcx, [rbp-0x1B4]
       mov      edx, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x06F7
       lea      rdx, [rbp-0xF0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG54
 
G_M000_IG33:                ;; offset=0x0719
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG34:                ;; offset=0x0729
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0xD0], rax
       cmp      dword ptr [rbp-0xD8], 0
       jne      SHORT G_M000_IG35
       mov      rcx, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x210], rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xD8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07A0
       mov      rcx, 0x7FFA02DE6510
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07B9
       cmp      gword ptr [rbp-0xF8], 0
       jne      G_M000_IG45
 
G_M000_IG37:                ;; offset=0x07C7
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG38:                ;; offset=0x07D7
       vmovdqu  xmm0, xmmword ptr [rbp-0x160]
       vmovdqu  xmmword ptr [rbp-0x228], xmm0
 
G_M000_IG39:                ;; offset=0x07E7
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x238], xmm0
 
G_M000_IG40:                ;; offset=0x07F7
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x240], rax
       lea      rax, [rbp-0x108]
       mov      qword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0x228]
       lea      r9, [rbp-0x238]
       mov      r8, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:get_HasValue():bool:this]
       test     eax, eax
       je       G_M000_IG48
       mov      rcx, 0x7FFA02DE6514
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x108]
       call     [System.Nullable`1[uint]:GetValueOrDefault():uint:this]
       mov      dword ptr [rbp-0x10C], eax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG41:                ;; offset=0x08AF
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG42:                ;; offset=0x08BF
       lea      rdx, [rbp-0x258]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0xD0], rax
 
G_M000_IG43:                ;; offset=0x08D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG44:                ;; offset=0x08E9
       lea      rax, [rbp-0x268]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0xD0]
       mov      r8d, dword ptr [rbp-0x10C]
       mov      r9, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAppendBorrowedWord(Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       mov      dword ptr [rbp-0xFC], eax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x091E
       mov      rcx, 0x7FFA02DE6518
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xF8]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG46:                ;; offset=0x093B
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x278], xmm0
 
G_M000_IG47:                ;; offset=0x094B
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rsp+0x28], rax
       lea      r9, [rbp-0x278]
       mov      r8, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0xFC], eax
 
G_M000_IG48:                ;; offset=0x099A
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG49
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG56
 
G_M000_IG49:                ;; offset=0x09BF
       cmp      dword ptr [rbp-0xA4], 0
       je       G_M000_IG53
       mov      rax, qword ptr [rbp-0xB0]
       add      rax, qword ptr [rbp-0xB8]
       mov      qword ptr [rbp-0xB0], rax
       mov      dword ptr [rbp-0xD4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG51
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xB0], rax
       jl       SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A11
       mov      rcx, 0x7FFA02DE651C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0A20
       mov      rcx, 0x7FFA02DE6520
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x94]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
       jmp      G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0A4E
       mov      rcx, 0x7FFA02DE6524
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0A5D
       mov      rcx, 0x7FFA02DE6528
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x18], ecx
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG54:                ;; offset=0x0A9F
       mov      rcx, 0x7FFA02DE652C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xDC], 1
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x110], 1
 
G_M000_IG55:                ;; offset=0x0AD3
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0ADA
       call     G_M000_IG81
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0AE1
       call     G_M000_IG81
       nop      
 
G_M000_IG58:                ;; offset=0x0AE7
       mov      rcx, 0x7FFA02DE6554
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x1B8], eax
 
G_M000_IG59:                ;; offset=0x0B02
       movzx    rax, byte  ptr [rbp-0x1B8]
 
G_M000_IG60:                ;; offset=0x0B09
       add      rsp, 752
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x0B12
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG62:                ;; offset=0x0B18
       sub      rsp, 56
 
G_M000_IG63:                ;; offset=0x0B1C
       cmp      dword ptr [rbp-0xD4], 0
       je       SHORT G_M000_IG64
       mov      rcx, 0x7FFA02DE6540
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, bword ptr [rbp-0xA0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG67
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x2A0], rcx
       mov      rcx, bword ptr [rbp-0x2A0]
       mov      rdx, qword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG64:                ;; offset=0x0B86
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG65
       mov      rcx, 0x7FFA02DE6544
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x180], rax
       mov      rcx, bword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      edx, dword ptr [rbp-0x2A4]
       mov      rcx, bword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG65:                ;; offset=0x0BD6
       mov      rcx, 0x7FFA02DE6548
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG66:                ;; offset=0x0BE6
       add      rsp, 56
       ret      
 
G_M000_IG67:                ;; offset=0x0BEB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG68:                ;; offset=0x0BF1
       sub      rsp, 56
 
G_M000_IG69:                ;; offset=0x0BF5
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG73
       lea      rcx, [rbp-0xC8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG70
       jmp      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0C12
       mov      rcx, 0x7FFA02DE6534
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG77
 
G_M000_IG71:                ;; offset=0x0C26
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0C2C
       mov      rcx, 0x7FFA02DE6538
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0C3B
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x168], rax
       mov      rcx, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x168]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG71
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x170], rcx
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0xD0], 0
       jne      SHORT G_M000_IG76
       mov      rcx, 0x7FFA02DE653C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG74:                ;; offset=0x0C99
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG75:                ;; offset=0x0CA9
       lea      rdx, [rbp-0x298]
       mov      rcx, gword ptr [rbp-0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x178], rax
 
G_M000_IG76:                ;; offset=0x0CC3
       mov      rcx, bword ptr [rbp-0x170]
       mov      rdx, gword ptr [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG77:                ;; offset=0x0CD7
       nop      
 
G_M000_IG78:                ;; offset=0x0CD8
       call     G_M000_IG62
       nop      
 
G_M000_IG79:                ;; offset=0x0CDE
       mov      rcx, 0x7FFA02DE654C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG80:                ;; offset=0x0CEE
       add      rsp, 56
       ret      
 
G_M000_IG81:                ;; offset=0x0CF3
       sub      rsp, 56
 
G_M000_IG82:                ;; offset=0x0CF7
       cmp      dword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG83
       mov      rcx, 0x7FFA02DE6530
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG83:                ;; offset=0x0D1B
       nop      
 
G_M000_IG84:                ;; offset=0x0D1C
       call     G_M000_IG68
       nop      
 
G_M000_IG85:                ;; offset=0x0D22
       mov      rcx, 0x7FFA02DE6550
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG86:                ;; offset=0x0D32
       add      rsp, 56
       ret      
 
; Total bytes of code 3383

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateBorrowedWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 382894
; 53 inlinees with PGO data; 103 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 296
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       vmovdqu  ymmword ptr [rsp+0xE0], ymm4
       vmovdqa  xmmword ptr [rsp+0x100], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, gword ptr [rsp+0x190]
 
G_M000_IG02:                ;; offset=0x0052
       mov      r14, gword ptr [r9]
       mov      gword ptr [rsp+0x60], r14
       mov      r15d, dword ptr [r9+0x08]
       mov      dword ptr [rsp+0x9C], r15d
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG84
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG83
 
G_M000_IG03:                ;; offset=0x008F
       mov      r13, gword ptr [rbx+0x28]
       mov      r12d, dword ptr [rbx+0x4C]
       mov      rax, bword ptr [rsi]
       mov      bword ptr [rsp+0x58], rax
       mov      r8d, dword ptr [rsi+0x08]
       mov      dword ptr [rsp+0x98], r8d
       cmp      r12d, 4
       jle      G_M000_IG85
 
G_M000_IG04:                ;; offset=0x00B5
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0xE0], ymm0
       xor      r10d, r10d
       mov      dword ptr [rsp+0xDC], r10d
       cmp      r10d, r8d
       jge      G_M000_IG35
 
G_M000_IG05:                ;; offset=0x00D6
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG97
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG96
 
G_M000_IG06:                ;; offset=0x00FF
       mov      r8d, dword ptr [rsp+0x98]
       mov      r10d, dword ptr [rsp+0xDC]
       mov      r9d, r8d
       sub      r9d, r10d
       cmp      r9d, 0x1000
       jge      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0122
       mov      dword ptr [rsp+0xD8], r9d
       mov      edx, r10d
       mov      ecx, r9d
       add      rdx, rcx
       mov      ecx, r8d
       cmp      rdx, rcx
       ja       G_M000_IG104
       mov      dword ptr [rsp+0xDC], r10d
       mov      r11d, r10d
       add      r11, bword ptr [rsp+0x58]
       mov      bword ptr [rsp+0x50], r11
       mov      rcx, r11
       mov      edx, r9d
       cmp      edx, 16
       jl       G_M000_IG17
 
G_M000_IG08:                ;; offset=0x0163
       cmp      dword ptr [rsp+0xFC], 0
       jne      G_M000_IG98
       mov      r11, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0xE0], r11
       mov      r11, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0xE8], r11
 
G_M000_IG09:                ;; offset=0x0195
       cmp      edx, 16
       jl       G_M000_IG17
 
G_M000_IG10:                ;; offset=0x019E
       mov      r11d, dword ptr [rsp+0xE0]
       imul     ebp, dword ptr [rcx], 0xFFFFFFFF85EBCA77
       add      r11d, ebp
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE0], r11d
       mov      r11d, dword ptr [rsp+0xE4]
       lea      rbp, bword ptr [rcx+0x04]
       imul     ebp, dword ptr [rbp], 0xFFFFFFFF85EBCA77
       add      r11d, ebp
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE4], r11d
       mov      r11d, dword ptr [rsp+0xE8]
       lea      rbp, bword ptr [rcx+0x08]
       imul     ebp, dword ptr [rbp], 0xFFFFFFFF85EBCA77
       add      r11d, ebp
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE8], r11d
       mov      r11d, dword ptr [rsp+0xEC]
       lea      rbp, bword ptr [rcx+0x0C]
       imul     ebp, dword ptr [rbp], 0xFFFFFFFF85EBCA77
       add      r11d, ebp
       rol      r11d, 13
       imul     r11d, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xEC], r11d
       mov      r11d, dword ptr [rsp+0xFC]
       add      r11d, 4
       mov      dword ptr [rsp+0xFC], r11d
       add      rcx, 16
       add      edx, -16
       mov      rbp, rcx
       mov      rcx, rbp
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x0263
       cmp      ebp, 3
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0268
       mov      rax, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0xE0], rax
       mov      rax, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0xE8], rax
 
G_M000_IG13:                ;; offset=0x028C
       imul     eax, dword ptr [rsp+0xF0], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE0]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE0], eax
       imul     eax, dword ptr [rsp+0xF4], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE4]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE4], eax
       imul     eax, dword ptr [rsp+0xF8], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE8]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE8], eax
       imul     r11d, r11d, 0xFFFFFFFF85EBCA77
       add      r11d, dword ptr [rsp+0xEC]
       rol      r11d, 13
       imul     eax, r11d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xEC], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0315
       mov      dword ptr [rsp+0xF4], r11d
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x031F
       mov      dword ptr [rsp+0xF0], r11d
 
G_M000_IG16:                ;; offset=0x0327
       add      rcx, 4
       add      edx, -4
       mov      rbp, rcx
       mov      eax, edx
       mov      rcx, rbp
       mov      edx, eax
 
G_M000_IG17:                ;; offset=0x0338
       cmp      edx, 4
       jl       SHORT G_M000_IG23
 
G_M000_IG18:                ;; offset=0x033D
       mov      r11d, dword ptr [rcx]
       mov      ebp, dword ptr [rsp+0xFC]
       lea      eax, [rbp+0x01]
       mov      dword ptr [rsp+0xFC], eax
       mov      eax, ebp
       and      eax, 3
       je       SHORT G_M000_IG15
 
G_M000_IG19:                ;; offset=0x0358
       cmp      eax, 1
       je       SHORT G_M000_IG14
 
G_M000_IG20:                ;; offset=0x035D
       cmp      eax, 2
       jne      G_M000_IG11
 
G_M000_IG21:                ;; offset=0x0366
       mov      dword ptr [rsp+0xF8], r11d
       jmp      SHORT G_M000_IG16
 
G_M000_IG22:                ;; offset=0x0370
       mov      r9d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x037B
       xor      r11d, r11d
       test     edx, edx
       je       G_M000_IG34
 
G_M000_IG24:                ;; offset=0x0386
       movzx    rbp, byte  ptr [rcx+r11]
       mov      eax, dword ptr [rsp+0xFC]
       lea      r9d, [rax+0x01]
       mov      dword ptr [rsp+0xFC], r9d
       mov      r9d, eax
       and      r9d, 3
       je       G_M000_IG32
 
G_M000_IG25:                ;; offset=0x03AB
       cmp      r9d, 1
       je       G_M000_IG31
 
G_M000_IG26:                ;; offset=0x03B5
       cmp      r9d, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03BB
       mov      dword ptr [rsp+0xF8], ebp
       jmp      G_M000_IG33
 
G_M000_IG28:                ;; offset=0x03C7
       cmp      eax, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x03CC
       mov      rax, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0xE0], rax
       mov      rax, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0xE8], rax
 
G_M000_IG30:                ;; offset=0x03F0
       imul     eax, dword ptr [rsp+0xF0], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE0]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE0], eax
       imul     eax, dword ptr [rsp+0xF4], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE4]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE4], eax
       imul     eax, dword ptr [rsp+0xF8], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xE8]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xE8], eax
       imul     eax, ebp, 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0xEC]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0xEC], eax
       jmp      SHORT G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0475
       mov      dword ptr [rsp+0xF4], ebp
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x047E
       mov      dword ptr [rsp+0xF0], ebp
 
G_M000_IG33:                ;; offset=0x0485
       inc      r11d
       cmp      r11d, edx
       jl       G_M000_IG24
 
G_M000_IG34:                ;; offset=0x0491
       mov      r10d, dword ptr [rsp+0xDC]
       add      r10d, dword ptr [rsp+0xD8]
       cmp      r10d, dword ptr [rsp+0x98]
       mov      dword ptr [rsp+0xDC], r10d
       jl       G_M000_IG05
 
G_M000_IG35:                ;; offset=0x04B7
       mov      edx, dword ptr [rsp+0xFC]
       mov      ecx, edx
       and      ecx, 3
       cmp      edx, 4
       jae      G_M000_IG82
 
G_M000_IG36:                ;; offset=0x04CC
       mov      r10d, 0x3E1D59A9
 
G_M000_IG37:                ;; offset=0x04D2
       lea      edx, [r10+4*rdx]
       test     ecx, ecx
       je       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x04DA
       imul     r10d, dword ptr [rsp+0xF0], 0xFFFFFFFFC2B2AE3D
       add      edx, r10d
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      ecx, 1
       jbe      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x04F7
       imul     r10d, dword ptr [rsp+0xF4], 0xFFFFFFFFC2B2AE3D
       add      r10d, edx
       rol      r10d, 17
       imul     edx, r10d, 0x27D4EB2F
       cmp      ecx, 2
       jbe      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0516
       imul     ecx, dword ptr [rsp+0xF8], 0xFFFFFFFFC2B2AE3D
       add      ecx, edx
       rol      ecx, 17
       imul     edx, ecx, 0x27D4EB2F
 
G_M000_IG41:                ;; offset=0x052C
       mov      ecx, edx
       shr      ecx, 15
       xor      ecx, edx
       imul     edx, ecx, 0xFFFFFFFF85EBCA77
       mov      ecx, edx
       shr      ecx, 13
       xor      ecx, edx
       imul     edx, ecx, 0xFFFFFFFFC2B2AE3D
       mov      ecx, edx
       shr      ecx, 16
       xor      edx, ecx
       mov      ecx, -2
       cmp      edx, -1
       cmovne   ecx, edx
       mov      edx, ecx
       shr      edx, 16
       xor      edx, ecx
       imul     edx, edx, 0xFFFFFFFF9E3779B9
       mov      ecx, edx
       shr      ecx, 16
       xor      ecx, edx
       mov      r10d, ecx
       test     r12d, r12d
       je       G_M000_IG105
 
G_M000_IG42:                ;; offset=0x0578
       mov      r9d, dword ptr [r13+0x08]
       mov      r12d, r9d
       mov      ecx, r12d
       blsr     edx, ecx
       jne      G_M000_IG106
       dec      ecx
       and      ecx, r10d
 
G_M000_IG43:                ;; offset=0x0592
       cmp      ecx, r12d
       jae      G_M000_IG154
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      r9d, dword ptr [r13+8*rcx+0x30]
       dec      r9d
       mov      dword ptr [rsp+0x114], r9d
       test     r9d, r9d
       jl       G_M000_IG109
       jmp      SHORT G_M000_IG46
 
G_M000_IG44:                ;; offset=0x05BC
       mov      r11, bword ptr [rsp+0x38]
       mov      r9d, dword ptr [r11+0x1C]
       dec      r9d
       mov      ecx, r9d
       test     ecx, ecx
       mov      dword ptr [rsp+0x114], ecx
       jl       G_M000_IG133
 
G_M000_IG45:                ;; offset=0x05DA
       mov      r10d, dword ptr [rsp+0x118]
 
G_M000_IG46:                ;; offset=0x05E2
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG108
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG107
 
G_M000_IG47:                ;; offset=0x060B
       mov      r9d, dword ptr [rsp+0x114]
       cmp      r9d, r12d
       jae      G_M000_IG154
       mov      dword ptr [rsp+0x114], r9d
       mov      ecx, r9d
       lea      rcx, [rcx+4*rcx]
       lea      r11, bword ptr [r13+8*rcx+0x10]
       mov      bword ptr [rsp+0x38], r11
       mov      dword ptr [rsp+0x118], r10d
       cmp      dword ptr [r11+0x18], r10d
       jne      G_M000_IG44
 
G_M000_IG48:                ;; offset=0x0647
       mov      rcx, gword ptr [r13+8*rcx+0x10]
       test     rcx, rcx
       je       G_M000_IG44
 
G_M000_IG49:                ;; offset=0x0655
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG44
 
G_M000_IG50:                ;; offset=0x0668
       mov      r8d, dword ptr [rsp+0x98]
       mov      edx, r8d
       movzx    rbp, byte  ptr [rcx+0x24]
       test     ebp, ebp
       je       G_M000_IG75
 
G_M000_IG51:                ;; offset=0x0680
       cmp      ebp, 255
       je       G_M000_IG73
 
G_M000_IG52:                ;; offset=0x068C
       lea      rbp, bword ptr [rcx+0x28]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, 8
       ja       G_M000_IG104
 
G_M000_IG53:                ;; offset=0x069C
       mov      bword ptr [rsp+0x40], rbp
       mov      dword ptr [rsp+0x90], ecx
       cmp      ecx, edx
       jne      G_M000_IG113
       xor      edx, edx
       mov      dword ptr [rsp+0xD4], edx
       cmp      edx, r8d
       jge      G_M000_IG62
 
G_M000_IG54:                ;; offset=0x06C2
       mov      rax, gword ptr [rdi+0x98]
       mov      r15, gword ptr [rax+0x88]
       cmp      gword ptr [r15+0x20], 0
       jne      G_M000_IG115
       mov      r15, gword ptr [rax+0x180]
       test     r15, r15
       jne      G_M000_IG114
 
G_M000_IG55:                ;; offset=0x06EB
       mov      r8d, dword ptr [rsp+0x98]
       mov      edx, dword ptr [rsp+0xD4]
       mov      eax, r8d
       sub      eax, edx
       cmp      eax, 0x1000
       jge      G_M000_IG77
 
G_M000_IG56:                ;; offset=0x070A
       mov      dword ptr [rsp+0xD0], eax
       mov      r15d, edx
       mov      ecx, eax
       add      r15, rcx
       mov      r14d, r8d
       cmp      r15, r14
       ja       G_M000_IG104
       mov      r14d, edx
       add      r14, bword ptr [rsp+0x58]
       mov      ebp, dword ptr [rsp+0x90]
       cmp      r15, rbp
       ja       G_M000_IG104
       mov      ebp, edx
       add      rbp, bword ptr [rsp+0x40]
       mov      r15, r14
       mov      rax, rbp
       cmp      rcx, 8
       jb       G_M000_IG80
 
G_M000_IG57:                ;; offset=0x0754
       cmp      r15, rax
       je       SHORT G_M000_IG61
       cmp      rcx, 32
       jae      G_M000_IG122
 
G_M000_IG58:                ;; offset=0x0763
       cmp      rcx, 16
       jae      G_M000_IG127
 
G_M000_IG59:                ;; offset=0x076D
       add      rcx, -8
       mov      rax, qword ptr [r14]
       sub      rax, qword ptr [rbp]
       mov      r15, qword ptr [r14+rcx]
       sub      r15, qword ptr [rcx+rbp]
       or       rax, r15
       sete     cl
       movzx    rcx, cl
 
G_M000_IG60:                ;; offset=0x0789
       test     ecx, ecx
       je       G_M000_IG121
 
G_M000_IG61:                ;; offset=0x0791
       add      edx, dword ptr [rsp+0xD0]
       cmp      edx, r8d
       mov      dword ptr [rsp+0xD4], edx
       jl       G_M000_IG54
 
G_M000_IG62:                ;; offset=0x07A8
       mov      r9d, dword ptr [rsp+0x114]
       mov      r12d, r9d
 
G_M000_IG63:                ;; offset=0x07B3
       xor      ecx, ecx
       mov      rbp, bword ptr [rsp+0x1A0]
       mov      qword ptr [rbp], rcx
       test     r12d, r12d
       jl       G_M000_IG134
 
G_M000_IG64:                ;; offset=0x07CA
       mov      ecx, dword ptr [r13+0x08]
       mov      ecx, r12d
       lea      rcx, [rcx+4*rcx]
       lea      rdx, bword ptr [r13+8*rcx+0x10]
       mov      esi, r12d
       mov      rax, gword ptr [rdx]
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x07E8
       mov      r8, 0x7FFA02A61F30
       cmp      qword ptr [r13], r8
       jne      G_M000_IG139
 
G_M000_IG66:                ;; offset=0x07FC
       mov      ebp, dword ptr [rdx+0x18]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG140
       mov      rdx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG154
       mov      eax, esi
       cmp      gword ptr [rdx+8*rax+0x10], 0
       jne      G_M000_IG140
 
G_M000_IG67:                ;; offset=0x0825
       mov      rdx, gword ptr [rbx+0x28]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG154
       mov      rdx, qword ptr [rdx+8*rcx+0x20]
       mov      rcx, 0xFF80000000000000
       cmp      rdx, rcx
       jl       G_M000_IG141
       mov      rcx, 0x80000000000000
       cmp      rdx, rcx
       jge      G_M000_IG141
 
G_M000_IG68:                ;; offset=0x085D
       mov      r14, gword ptr [rsp+0x60]
       test     r14, r14
       jne      G_M000_IG147
       movsxd   rcx, dword ptr [rsp+0x9C]
 
G_M000_IG69:                ;; offset=0x0873
       add      rdx, rcx
       mov      edi, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG152
       mov      rcx, gword ptr [rbx+0x28]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG154
       mov      eax, esi
       lea      rax, [rax+4*rax]
       mov      qword ptr [rcx+8*rax+0x20], rdx
       mov      rcx, gword ptr [rbx+0x30]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG154
       mov      edx, esi
       xor      rax, rax
       mov      gword ptr [rcx+8*rdx+0x10], rax
 
G_M000_IG70:                ;; offset=0x08B2
       cmp      dword ptr [rbx+0x4C], edi
       jne      G_M000_IG153
 
G_M000_IG71:                ;; offset=0x08BB
       mov      eax, 1
 
G_M000_IG72:                ;; offset=0x08C0
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG73:                ;; offset=0x08D7
       mov      rbp, gword ptr [rcx+0x08]
       mov      gword ptr [rsp+0x68], rbp
       lea      rbp, bword ptr [rcx+0x28]
       mov      ebp, dword ptr [rbp]
       mov      ecx, dword ptr [rcx+0x18]
       mov      dword ptr [rsp+0xCC], ecx
       cmp      gword ptr [rsp+0x68], 0
       je       G_M000_IG112
       mov      qword ptr [rsp+0x78], rbp
       mov      ebp, ecx
       add      rbp, qword ptr [rsp+0x78]
       mov      qword ptr [rsp+0x11C], rbp
       mov      rbp, gword ptr [rsp+0x68]
       mov      ebp, dword ptr [rbp+0x08]
       cmp      qword ptr [rsp+0x11C], rbp
       ja       G_M000_IG104
       mov      rbp, gword ptr [rsp+0x68]
       mov      rcx, qword ptr [rsp+0x78]
       lea      rbp, bword ptr [rbp+rcx+0x10]
       mov      ecx, dword ptr [rsp+0xCC]
 
G_M000_IG74:                ;; offset=0x093D
       jmp      G_M000_IG53
 
G_M000_IG75:                ;; offset=0x0942
       mov      rbp, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x18]
       test     rbp, rbp
       je       G_M000_IG111
       cmp      dword ptr [rbp+0x08], ecx
       jb       G_M000_IG104
       add      rbp, 16
 
G_M000_IG76:                ;; offset=0x095F
       jmp      G_M000_IG53
 
G_M000_IG77:                ;; offset=0x0964
       mov      eax, 0x1000
       jmp      G_M000_IG56
 
G_M000_IG78:                ;; offset=0x096E
       add      rbp, 32
       cmp      rcx, rbp
       jbe      G_M000_IG125
 
G_M000_IG79:                ;; offset=0x097B
       vmovups  ymm0, ymmword ptr [r15+rbp]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+rbp]
       vpmovmskb r14d, ymm0
       cmp      r14d, -1
       jne      G_M000_IG124
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x0996
       cmp      rcx, 4
       jb       G_M000_IG116
 
G_M000_IG81:                ;; offset=0x09A0
       add      rcx, -4
       mov      eax, dword ptr [r14]
       sub      eax, dword ptr [rbp]
       mov      r14d, dword ptr [r14+rcx]
       sub      r14d, dword ptr [rcx+rbp]
       or       eax, r14d
       sete     cl
       movzx    rcx, cl
       jmp      G_M000_IG60
 
G_M000_IG82:                ;; offset=0x09C0
       rorx     r10d, dword ptr [rsp+0xE0], 31
       rorx     r9d, dword ptr [rsp+0xE4], 25
       add      r10d, r9d
       rorx     r9d, dword ptr [rsp+0xE8], 20
       add      r10d, r9d
       rorx     r9d, dword ptr [rsp+0xEC], 14
       add      r10d, r9d
       jmp      G_M000_IG37
 
G_M000_IG83:                ;; offset=0x09FA
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG03
 
G_M000_IG84:                ;; offset=0x0A0C
       mov      rdx, gword ptr [rsp+0x198]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG85:                ;; offset=0x0A1F
       cmp      r8d, 8
       jg       SHORT G_M000_IG89
 
G_M000_IG86:                ;; offset=0x0A25
       xor      edi, edi
       xor      r10d, r10d
       test     r12d, r12d
       jle      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0A2F
       mov      r9d, dword ptr [r13+0x08]
       cmp      r10d, r9d
       jae      G_M000_IG154
       mov      qword ptr [rsp+0x70], r10
       lea      rdx, [r10+4*r10]
       mov      rcx, gword ptr [r13+8*rdx+0x10]
       test     rcx, rcx
       jne      SHORT G_M000_IG90
       jmp      SHORT G_M000_IG93
 
G_M000_IG88:                ;; offset=0x0A51
       mov      dword ptr [rsp+0x118], edi
       jmp      G_M000_IG133
 
G_M000_IG89:                ;; offset=0x0A5D
       mov      r8d, dword ptr [rsp+0x98]
       jmp      G_M000_IG04
 
G_M000_IG90:                ;; offset=0x0A6A
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG93
 
G_M000_IG91:                ;; offset=0x0A79
       lea      rdx, [rsp+0x100]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      r8d, dword ptr [rsp+0x108]
       mov      eax, dword ptr [rsp+0x98]
       cmp      eax, r8d
       jne      SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0A9B
       mov      rdx, bword ptr [rsp+0x100]
       mov      r8d, r8d
       mov      rcx, bword ptr [rsp+0x58]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x0AB5
       mov      r10, qword ptr [rsp+0x70]
       inc      r10d
       mov      rcx, r10
       cmp      ecx, r12d
       mov      r10, rcx
       jl       G_M000_IG87
 
G_M000_IG94:                ;; offset=0x0ACC
       mov      dword ptr [rsp+0x118], edi
       jmp      G_M000_IG133
 
G_M000_IG95:                ;; offset=0x0AD8
       mov      r12, qword ptr [rsp+0x70]
       mov      dword ptr [rsp+0x118], edi
       jmp      G_M000_IG63
 
G_M000_IG96:                ;; offset=0x0AE9
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG97:                ;; offset=0x0AFB
       mov      rdx, gword ptr [rsp+0x198]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG98:                ;; offset=0x0B0E
       mov      ebp, dword ptr [rsp+0xFC]
       and      ebp, 3
       dec      ebp
       cmp      ebp, 2
       ja       G_M000_IG09
       mov      qword ptr [rsp+0x11C], rbp
       lea      rbp, [reloc @RWD00]
       mov      dword ptr [rsp+0x94], edx
       mov      r11, qword ptr [rsp+0x11C]
       mov      ebp, dword ptr [rbp+4*r11]
       lea      rax, G_M000_IG02
       add      rbp, rax
       jmp      rbp
 
G_M000_IG99:                ;; offset=0x0B52
       mov      rax, rcx
       jmp      SHORT G_M000_IG103
 
G_M000_IG100:                ;; offset=0x0B57
       mov      rax, rcx
       jmp      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0B5C
       mov      rbp, bword ptr [rsp+0x50]
       mov      edx, dword ptr [rbp]
       lea      rcx, [rsp+0xE0]
       call     [System.HashCode:Add(int):this]
       add      rbp, 4
       mov      rcx, rbp
       mov      ebp, dword ptr [rsp+0xD8]
       lea      edx, [rbp-0x04]
       mov      rax, rcx
       mov      dword ptr [rsp+0x94], edx
 
G_M000_IG102:                ;; offset=0x0B8D
       mov      bword ptr [rsp+0x48], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0xE0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x48]
       add      rax, 4
       mov      r8d, dword ptr [rsp+0x94]
       add      r8d, -4
       mov      dword ptr [rsp+0x94], r8d
 
G_M000_IG103:                ;; offset=0x0BBF
       mov      bword ptr [rsp+0x48], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0xE0]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x48]
       add      rax, 4
       mov      edx, dword ptr [rsp+0x94]
       add      edx, -4
       mov      rcx, rax
       jmp      G_M000_IG09
 
G_M000_IG104:                ;; offset=0x0BEF
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG105:                ;; offset=0x0BF6
       mov      dword ptr [rsp+0x118], r10d
       jmp      G_M000_IG133
 
G_M000_IG106:                ;; offset=0x0C03
       mov      dword ptr [rsp+0x118], r10d
       mov      eax, r10d
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       mov      r10d, dword ptr [rsp+0x118]
       jmp      G_M000_IG43
 
G_M000_IG107:                ;; offset=0x0C21
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG47
       mov      dword ptr [rsp+0x118], r10d
       jmp      SHORT G_M000_IG110
 
G_M000_IG108:                ;; offset=0x0C3D
       mov      dword ptr [rsp+0x118], r10d
       jmp      SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0C47
       mov      dword ptr [rsp+0x118], r10d
       jmp      G_M000_IG133
 
G_M000_IG110:                ;; offset=0x0C54
       mov      rdx, gword ptr [rsp+0x198]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10d, dword ptr [rsp+0x118]
       jmp      G_M000_IG47
 
G_M000_IG111:                ;; offset=0x0C6F
       test     ecx, ecx
       jne      G_M000_IG104
       xor      rbp, rbp
       xor      ecx, ecx
       jmp      G_M000_IG76
 
G_M000_IG112:                ;; offset=0x0C80
       or       ebp, ecx
       jne      G_M000_IG104
       xor      rbp, rbp
       xor      ecx, ecx
       jmp      G_M000_IG74
 
G_M000_IG113:                ;; offset=0x0C91
       jmp      G_M000_IG44
 
G_M000_IG114:                ;; offset=0x0C96
       cmp      dword ptr [r15+0x20], 0
       setne    r15b
       movzx    r15, r15b
       test     r15d, r15d
       je       G_M000_IG55
 
G_M000_IG115:                ;; offset=0x0CAC
       mov      rcx, rax
       mov      rdx, gword ptr [rsp+0x198]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG55
 
G_M000_IG116:                ;; offset=0x0CC2
       xor      eax, eax
       mov      r15, rcx
       and      r15, 2
       mov      qword ptr [rsp+0xC0], r15
       test     r15, r15
       je       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x0CD8
       movzx    rax, word  ptr [r14]
       mov      dword ptr [rsp+0x124], eax
       movzx    rax, word  ptr [rbp]
       movzx    r15, dword ptr [rsp+0x124]
       sub      r15d, eax
       mov      eax, r15d
 
G_M000_IG118:                ;; offset=0x0CF6
       test     cl, 1
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0CFB
       mov      r15, qword ptr [rsp+0xC0]
       movzx    rcx, byte  ptr [r14+r15]
       movzx    rbp, byte  ptr [r15+rbp]
       sub      ecx, ebp
       or       eax, ecx
 
G_M000_IG120:                ;; offset=0x0D11
       test     eax, eax
       sete     cl
       movzx    rcx, cl
       jmp      G_M000_IG60
 
G_M000_IG121:                ;; offset=0x0D1E
       jmp      G_M000_IG44
 
G_M000_IG122:                ;; offset=0x0D23
       xor      ebp, ebp
       add      rcx, -32
       je       SHORT G_M000_IG125
       vmovups  ymm0, ymmword ptr [r15]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax]
       vpmovmskb r14d, ymm0
       cmp      r14d, -1
       je       G_M000_IG78
 
G_M000_IG123:                ;; offset=0x0D42
       jmp      G_M000_IG44
 
G_M000_IG124:                ;; offset=0x0D47
       jmp      G_M000_IG44
 
G_M000_IG125:                ;; offset=0x0D4C
       vmovups  ymm0, ymmword ptr [r15+rcx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+rcx]
       vpmovmskb ecx, ymm0
       cmp      ecx, -1
       je       G_M000_IG61
 
G_M000_IG126:                ;; offset=0x0D64
       jmp      G_M000_IG44
 
G_M000_IG127:                ;; offset=0x0D69
       xor      r14d, r14d
       add      rcx, -16
       je       SHORT G_M000_IG131
       vmovups  xmm0, xmmword ptr [r15]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax]
       vpmovmskb ebp, xmm0
       cmp      ebp, 0xFFFF
       je       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0D87
       jmp      G_M000_IG44
 
G_M000_IG129:                ;; offset=0x0D8C
       add      r14, 16
       cmp      rcx, r14
       jbe      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0D95
       vmovups  xmm0, xmmword ptr [r15+r14]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+r14]
       vpmovmskb ebp, xmm0
       cmp      ebp, 0xFFFF
       je       SHORT G_M000_IG129
       jmp      G_M000_IG44
 
G_M000_IG131:                ;; offset=0x0DB2
       vmovups  xmm0, xmmword ptr [r15+rcx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax+rcx]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       je       G_M000_IG61
 
G_M000_IG132:                ;; offset=0x0DCC
       jmp      G_M000_IG44
 
G_M000_IG133:                ;; offset=0x0DD1
       mov      r12d, -1
       jmp      G_M000_IG63
 
G_M000_IG134:                ;; offset=0x0DDC
       cmp      dword ptr [rsi+0x08], 8
       jle      SHORT G_M000_IG137
 
G_M000_IG135:                ;; offset=0x0DE2
       mov      eax, dword ptr [rbx+0x4C]
       mov      r12d, dword ptr [r13+0x08]
       cmp      eax, r12d
       jge      SHORT G_M000_IG137
 
G_M000_IG136:                ;; offset=0x0DEE
       mov      byte  ptr [rbp], 1
       mov      r10d, dword ptr [rsp+0x118]
       mov      dword ptr [rbp+0x04], r10d
 
G_M000_IG137:                ;; offset=0x0DFE
       xor      eax, eax
 
G_M000_IG138:                ;; offset=0x0E00
       vzeroupper 
       add      rsp, 296
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG139:                ;; offset=0x0E17
       mov      rdx, rax
       mov      rcx, r8
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG140:                ;; offset=0x0E23
       mov      rcx, rbx
       mov      edx, esi
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x0E33
       xor      eax, eax
       jmp      G_M000_IG72
 
G_M000_IG142:                ;; offset=0x0E3A
       mov      rcx, 0x7FFA029E8768
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG141
 
G_M000_IG143:                ;; offset=0x0E49
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rsp+0xB0], xmm0
 
G_M000_IG144:                ;; offset=0x0E57
       lea      rcx, [rsp+0xB0]
       xor      edx, edx
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jge      SHORT G_M000_IG141
 
G_M000_IG145:                ;; offset=0x0E6C
       vmovdqu  xmm0, xmmword ptr [rsp+0xB0]
       vmovdqu  xmmword ptr [rsp+0x80], xmm0
 
G_M000_IG146:                ;; offset=0x0E7E
       lea      rcx, [rsp+0x80]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rdx, rax
       jmp      G_M000_IG68
 
G_M000_IG147:                ;; offset=0x0E94
       cmp      dword ptr [r14+0x08], 1
       jle      SHORT G_M000_IG148
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x0EC8
       cmp      dword ptr [r14+0x08], 0
       jbe      G_M000_IG154
       mov      rcx, qword ptr [r14+0x10]
       mov      rax, rcx
       neg      rax
       mov      r15d, dword ptr [rsp+0x9C]
       test     r15d, r15d
       cmovle   rcx, rax
       test     rcx, rcx
       jle      SHORT G_M000_IG149
       test     r15d, r15d
       jg       SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x0EF6
       test     rcx, rcx
       jge      SHORT G_M000_IG151
       test     r15d, r15d
       jge      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x0F00
       jmp      G_M000_IG69
 
G_M000_IG151:                ;; offset=0x0F05
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG152:                ;; offset=0x0F32
       lea      rcx, [rsp+0xA0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x08]
       mov      rdx, gword ptr [rsp+0xA0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rsp+0xA8]
       mov      dword ptr [rsi+0x10], r9d
       mov      dword ptr [rsp+0x20], ebp
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, rsi
       mov      rcx, rbx
       mov      edx, r12d
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG70
 
G_M000_IG153:                ;; offset=0x0F9A
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG71
 
G_M000_IG154:                ;; offset=0x0FA2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000B0Ah ; case G_M000_IG101
       	dd	00000B05h ; case G_M000_IG100
       	dd	00000B00h ; case G_M000_IG99

; Total bytes of code 4008

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 694106
; 47 inlinees with PGO data; 94 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 136
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqa  xmmword ptr [rsp+0x70], xmm4
       mov      rbx, rcx
       mov      ebp, edx
       mov      rsi, r9
       mov      rdi, bword ptr [rsp+0xF8]
 
G_M000_IG02:                ;; offset=0x0033
       mov      r14, bword ptr [r8]
       mov      r15d, dword ptr [r8+0x08]
       cmp      ebp, 4
       jle      G_M000_IG73
 
G_M000_IG03:                ;; offset=0x0043
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0x50], ymm0
       xor      r13d, r13d
       cmp      r13d, r15d
       jge      G_M000_IG35
 
G_M000_IG04:                ;; offset=0x0059
       test     rsi, rsi
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005E
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG83
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG82
 
G_M000_IG06:                ;; offset=0x0087
       mov      r12d, r15d
       sub      r12d, r13d
       cmp      r12d, 0x1000
       jge      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x009A
       mov      edx, r13d
       mov      ecx, r12d
       add      rdx, rcx
       mov      ecx, r15d
       cmp      rdx, rcx
       ja       G_M000_IG90
       mov      eax, r13d
       add      rax, r14
       mov      bword ptr [rsp+0x30], rax
       mov      r8, rax
       mov      r10d, r12d
       cmp      r10d, 16
       jl       G_M000_IG17
 
G_M000_IG08:                ;; offset=0x00CA
       cmp      dword ptr [rsp+0x6C], 0
       jne      G_M000_IG84
       mov      rax, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0x50], rax
       mov      rdx, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0x58], rdx
 
G_M000_IG09:                ;; offset=0x00F3
       cmp      r10d, 16
       jl       G_M000_IG17
 
G_M000_IG10:                ;; offset=0x00FD
       mov      eax, dword ptr [rsp+0x50]
       imul     edx, dword ptr [r8], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x50], eax
       mov      eax, dword ptr [rsp+0x54]
       lea      rdx, bword ptr [r8+0x04]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x54], eax
       mov      eax, dword ptr [rsp+0x58]
       lea      rdx, bword ptr [r8+0x08]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x58], eax
       mov      eax, dword ptr [rsp+0x5C]
       lea      rdx, bword ptr [r8+0x0C]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, edx
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x5C], eax
       mov      eax, dword ptr [rsp+0x6C]
       add      eax, 4
       mov      dword ptr [rsp+0x6C], eax
       add      r8, 16
       add      r10d, -16
       mov      rax, r8
       mov      edx, r10d
       mov      r8, rax
       mov      r10d, edx
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x0192
       cmp      edx, 3
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0197
       mov      rdx, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0x50], rdx
       mov      rdx, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0x58], rdx
 
G_M000_IG13:                ;; offset=0x01B5
       imul     edx, dword ptr [rsp+0x60], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0x50]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x50], edx
       imul     edx, dword ptr [rsp+0x64], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0x54]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x54], edx
       imul     edx, dword ptr [rsp+0x68], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rsp+0x58]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x58], edx
       imul     eax, eax, 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rsp+0x5C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x5C], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0219
       mov      dword ptr [rsp+0x64], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x021F
       mov      dword ptr [rsp+0x60], eax
 
G_M000_IG16:                ;; offset=0x0223
       add      r8, 4
       add      r10d, -4
       mov      rax, r8
       mov      edx, r10d
       mov      r8, rax
       mov      r10d, edx
 
G_M000_IG17:                ;; offset=0x0237
       cmp      r10d, 4
       jl       SHORT G_M000_IG23
 
G_M000_IG18:                ;; offset=0x023D
       mov      eax, dword ptr [r8]
       mov      edx, dword ptr [rsp+0x6C]
       lea      ecx, [rdx+0x01]
       mov      dword ptr [rsp+0x6C], ecx
       mov      ecx, edx
       and      ecx, 3
       je       SHORT G_M000_IG15
 
G_M000_IG19:                ;; offset=0x0252
       cmp      ecx, 1
       je       SHORT G_M000_IG14
 
G_M000_IG20:                ;; offset=0x0257
       cmp      ecx, 2
       jne      G_M000_IG11
 
G_M000_IG21:                ;; offset=0x0260
       mov      dword ptr [rsp+0x68], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG22:                ;; offset=0x0266
       mov      r12d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x0271
       mov      rax, r8
       mov      edx, r10d
       xor      ecx, ecx
       test     edx, edx
       je       G_M000_IG34
 
G_M000_IG24:                ;; offset=0x0281
       movzx    r8, byte  ptr [rax+rcx]
       mov      r10d, dword ptr [rsp+0x6C]
       lea      r9d, [r10+0x01]
       mov      dword ptr [rsp+0x6C], r9d
       mov      r9d, r10d
       and      r9d, 3
       je       G_M000_IG32
 
G_M000_IG25:                ;; offset=0x02A1
       cmp      r9d, 1
       je       G_M000_IG31
 
G_M000_IG26:                ;; offset=0x02AB
       cmp      r9d, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02B1
       mov      dword ptr [rsp+0x68], r8d
       jmp      G_M000_IG33
 
G_M000_IG28:                ;; offset=0x02BB
       cmp      r10d, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02C1
       mov      r10, 0xADB2BC6F4BEA3620
       mov      qword ptr [rsp+0x50], r10
       mov      r10, 0x898F784727C6F1F8
       mov      qword ptr [rsp+0x58], r10
 
G_M000_IG30:                ;; offset=0x02DF
       imul     r10d, dword ptr [rsp+0x60], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x50]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x50], r10d
       imul     r10d, dword ptr [rsp+0x64], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x54]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x54], r10d
       imul     r10d, dword ptr [rsp+0x68], 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rsp+0x58]
       rol      r10d, 13
       imul     r10d, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x58], r10d
       imul     r8d, r8d, 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rsp+0x5C]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rsp+0x5C], r8d
       jmp      SHORT G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0357
       mov      dword ptr [rsp+0x64], r8d
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x035E
       mov      dword ptr [rsp+0x60], r8d
 
G_M000_IG33:                ;; offset=0x0363
       inc      ecx
       cmp      ecx, edx
       jl       G_M000_IG24
 
G_M000_IG34:                ;; offset=0x036D
       add      r13d, r12d
       cmp      r13d, r15d
       jl       G_M000_IG04
 
G_M000_IG35:                ;; offset=0x0379
       mov      eax, dword ptr [rsp+0x6C]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG72
 
G_M000_IG36:                ;; offset=0x038B
       mov      ecx, 0x3E1D59A9
 
G_M000_IG37:                ;; offset=0x0390
       lea      eax, [rcx+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x0397
       imul     ecx, dword ptr [rsp+0x60], 0xFFFFFFFFC2B2AE3D
       add      eax, ecx
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x03AF
       imul     ecx, dword ptr [rsp+0x64], 0xFFFFFFFFC2B2AE3D
       add      ecx, eax
       rol      ecx, 17
       imul     eax, ecx, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x03C7
       imul     edx, dword ptr [rsp+0x68], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG41:                ;; offset=0x03DA
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     eax, eax, 0xFFFFFFFF9E3779B9
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       mov      dword ptr [rdi], edx
       test     ebp, ebp
       je       G_M000_IG109
 
G_M000_IG42:                ;; offset=0x0424
       mov      eax, dword ptr [rdi]
       mov      r13d, dword ptr [rbx+0x08]
       mov      ecx, r13d
       blsr     edx, ecx
       jne      G_M000_IG91
       dec      ecx
       and      ecx, eax
 
G_M000_IG43:                ;; offset=0x043C
       cmp      ecx, r13d
       jae      G_M000_IG111
       mov      ecx, ecx
       lea      rcx, [rcx+4*rcx]
       mov      ebp, dword ptr [rbx+8*rcx+0x30]
       dec      ebp
       js       G_M000_IG109
       jmp      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0459
       mov      ebp, dword ptr [r12+0x1C]
       dec      ebp
       js       G_M000_IG109
 
G_M000_IG45:                ;; offset=0x0466
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG93
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG92
 
G_M000_IG46:                ;; offset=0x048F
       cmp      ebp, r13d
       jae      G_M000_IG111
       mov      ecx, ebp
       lea      rcx, [rcx+4*rcx]
       lea      r12, bword ptr [rbx+8*rcx+0x10]
       mov      edx, dword ptr [r12+0x18]
       cmp      edx, dword ptr [rdi]
       jne      SHORT G_M000_IG44
 
G_M000_IG47:                ;; offset=0x04AC
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG44
 
G_M000_IG48:                ;; offset=0x04B6
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG44
 
G_M000_IG49:                ;; offset=0x04C5
       mov      edx, r15d
       movzx    rax, byte  ptr [rcx+0x24]
       test     eax, eax
       je       G_M000_IG65
 
G_M000_IG50:                ;; offset=0x04D4
       cmp      eax, 255
       je       G_M000_IG63
 
G_M000_IG51:                ;; offset=0x04DF
       lea      rax, bword ptr [rcx+0x28]
       mov      r8d, dword ptr [rcx+0x18]
       cmp      r8d, 8
       ja       G_M000_IG90
 
G_M000_IG52:                ;; offset=0x04F1
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x38], r8d
       cmp      r8d, edx
       jne      G_M000_IG44
       xor      r10d, r10d
       mov      dword ptr [rsp+0x4C], r10d
       cmp      r10d, r15d
       jge      G_M000_IG61
 
G_M000_IG53:                ;; offset=0x0515
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG97
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG96
 
G_M000_IG54:                ;; offset=0x053E
       mov      r10d, dword ptr [rsp+0x4C]
       mov      ecx, r15d
       sub      ecx, r10d
       cmp      ecx, 0x1000
       jge      G_M000_IG67
 
G_M000_IG55:                ;; offset=0x0555
       mov      edx, r10d
       mov      r9d, ecx
       add      rdx, r9
       mov      r11d, r15d
       cmp      rdx, r11
       ja       G_M000_IG90
       mov      r11d, r10d
       add      r11, r14
       mov      eax, dword ptr [rsp+0x38]
       cmp      rdx, rax
       ja       G_M000_IG90
       mov      eax, r10d
       add      rax, bword ptr [rsp+0x20]
       mov      rdx, r11
       mov      r8, rax
       cmp      r9, 8
       jb       G_M000_IG70
 
G_M000_IG56:                ;; offset=0x0595
       cmp      rdx, r8
       je       SHORT G_M000_IG60
       cmp      r9, 32
       jae      G_M000_IG103
 
G_M000_IG57:                ;; offset=0x05A4
       cmp      r9, 16
       jae      G_M000_IG105
 
G_M000_IG58:                ;; offset=0x05AE
       add      r9, -8
       mov      rdx, qword ptr [r11]
       sub      rdx, qword ptr [rax]
       mov      r8, qword ptr [r11+r9]
       sub      r8, qword ptr [rax+r9]
       or       rdx, r8
       sete     dl
       movzx    rdx, dl
 
G_M000_IG59:                ;; offset=0x05C9
       test     edx, edx
       je       G_M000_IG44
 
G_M000_IG60:                ;; offset=0x05D1
       add      r10d, ecx
       cmp      r10d, r15d
       mov      dword ptr [rsp+0x4C], r10d
       jl       G_M000_IG53
 
G_M000_IG61:                ;; offset=0x05E2
       mov      eax, ebp
 
G_M000_IG62:                ;; offset=0x05E4
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG63:                ;; offset=0x05FB
       mov      rax, gword ptr [rcx+0x08]
       lea      r8, bword ptr [rcx+0x28]
       mov      r8d, dword ptr [r8]
       mov      ecx, dword ptr [rcx+0x18]
       test     rax, rax
       je       G_M000_IG95
       mov      r10d, ecx
       add      r10, r8
       mov      r9d, dword ptr [rax+0x08]
       cmp      r10, r9
       ja       G_M000_IG90
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, ecx
 
G_M000_IG64:                ;; offset=0x062D
       jmp      G_M000_IG52
 
G_M000_IG65:                ;; offset=0x0632
       mov      rax, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x18]
       test     rax, rax
       je       G_M000_IG94
       cmp      dword ptr [rax+0x08], r8d
       jb       G_M000_IG90
       add      rax, 16
 
G_M000_IG66:                ;; offset=0x0651
       jmp      G_M000_IG52
 
G_M000_IG67:                ;; offset=0x0656
       mov      ecx, 0x1000
       jmp      G_M000_IG55
 
G_M000_IG68:                ;; offset=0x0660
       add      rax, 32
       cmp      r9, rax
       jbe      G_M000_IG104
 
G_M000_IG69:                ;; offset=0x066D
       vmovups  ymm0, ymmword ptr [rdx+rax]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+rax]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG44
       jmp      SHORT G_M000_IG68
 
G_M000_IG70:                ;; offset=0x0688
       cmp      r9, 4
       jb       G_M000_IG98
 
G_M000_IG71:                ;; offset=0x0692
       add      r9, -4
       mov      edx, dword ptr [r11]
       sub      edx, dword ptr [rax]
       mov      r11d, dword ptr [r11+r9]
       sub      r11d, dword ptr [rax+r9]
       or       edx, r11d
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG59
 
G_M000_IG72:                ;; offset=0x06B1
       rorx     ecx, dword ptr [rsp+0x50], 31
       rorx     r8d, dword ptr [rsp+0x54], 25
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x58], 20
       add      ecx, r8d
       rorx     r8d, dword ptr [rsp+0x5C], 14
       add      ecx, r8d
       jmp      G_M000_IG37
 
G_M000_IG73:                ;; offset=0x06DF
       cmp      r15d, 8
       jg       G_M000_IG03
 
G_M000_IG74:                ;; offset=0x06E9
       xor      edx, edx
       mov      dword ptr [rdi], edx
 
G_M000_IG75:                ;; offset=0x06ED
       xor      esi, esi
       test     ebp, ebp
       jle      G_M000_IG109
 
G_M000_IG76:                ;; offset=0x06F7
       mov      r13d, dword ptr [rbx+0x08]
       cmp      esi, r13d
       jae      G_M000_IG111
       lea      rdx, [rsi+4*rsi]
       mov      rcx, gword ptr [rbx+8*rdx+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG80
 
G_M000_IG77:                ;; offset=0x0712
       mov      rdx, 0x7FFA02A61F30
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG80
 
G_M000_IG78:                ;; offset=0x0721
       lea      rdx, [rsp+0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      r8d, dword ptr [rsp+0x78]
       cmp      r15d, r8d
       jne      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0736
       mov      rdx, bword ptr [rsp+0x70]
       mov      r8d, r8d
       mov      rcx, r14
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x074B
       inc      esi
       cmp      esi, ebp
       jl       SHORT G_M000_IG76
       jmp      G_M000_IG109
 
G_M000_IG81:                ;; offset=0x0756
       mov      eax, esi
       jmp      G_M000_IG62
 
G_M000_IG82:                ;; offset=0x075D
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG06
 
G_M000_IG83:                ;; offset=0x076F
       mov      rdx, gword ptr [rsp+0xF0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG84:                ;; offset=0x0782
       mov      edx, dword ptr [rsp+0x6C]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG09
       lea      rcx, [reloc @RWD00]
       mov      dword ptr [rsp+0x3C], r10d
       mov      ecx, dword ptr [rcx+4*rdx]
       lea      r9, G_M000_IG02
       add      rcx, r9
       jmp      rcx
 
G_M000_IG85:                ;; offset=0x07AF
       mov      rax, r8
       jmp      SHORT G_M000_IG89
 
G_M000_IG86:                ;; offset=0x07B4
       mov      rax, r8
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x07B9
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x50]
       call     [System.HashCode:Add(int):this]
       mov      r8, bword ptr [rsp+0x30]
       add      r8, 4
       lea      r10d, [r12-0x04]
       mov      rax, r8
       mov      dword ptr [rsp+0x3C], r10d
 
G_M000_IG88:                ;; offset=0x07DC
       mov      bword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x28]
       add      rax, 4
       mov      r8d, dword ptr [rsp+0x3C]
       add      r8d, -4
       mov      dword ptr [rsp+0x3C], r8d
 
G_M000_IG89:                ;; offset=0x0805
       mov      bword ptr [rsp+0x28], rax
       mov      edx, dword ptr [rax]
       lea      rcx, [rsp+0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rsp+0x28]
       add      rax, 4
       mov      edx, dword ptr [rsp+0x3C]
       add      edx, -4
       mov      r8, rax
       mov      r10d, edx
       jmp      G_M000_IG09
 
G_M000_IG90:                ;; offset=0x0832
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG91:                ;; offset=0x0839
       xor      edx, edx
       div      edx:eax, ecx
       mov      ecx, edx
       jmp      G_M000_IG43
 
G_M000_IG92:                ;; offset=0x0844
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG46
 
G_M000_IG93:                ;; offset=0x0856
       mov      rdx, gword ptr [rsp+0xF0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG46
 
G_M000_IG94:                ;; offset=0x0869
       test     r8d, r8d
       jne      SHORT G_M000_IG90
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG66
 
G_M000_IG95:                ;; offset=0x0878
       or       r8d, ecx
       jne      SHORT G_M000_IG90
       xor      rax, rax
       xor      r8d, r8d
       jmp      G_M000_IG64
 
G_M000_IG96:                ;; offset=0x0887
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG54
 
G_M000_IG97:                ;; offset=0x0899
       mov      rdx, gword ptr [rsp+0xF0]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG54
 
G_M000_IG98:                ;; offset=0x08AC
       xor      edx, edx
       mov      r8, r9
       and      r8, 2
       mov      qword ptr [rsp+0x40], r8
       test     r8, r8
       je       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x08BF
       movzx    rdx, word  ptr [r11]
       mov      dword ptr [rsp+0x84], edx
       movzx    rdx, word  ptr [rax]
       movzx    r8, dword ptr [rsp+0x84]
       sub      r8d, edx
       mov      edx, r8d
 
G_M000_IG100:                ;; offset=0x08DC
       test     r9b, 1
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x08E2
       mov      r8, qword ptr [rsp+0x40]
       movzx    r9, byte  ptr [r11+r8]
       movzx    rax, byte  ptr [rax+r8]
       sub      r9d, eax
       or       edx, r9d
 
G_M000_IG102:                ;; offset=0x08F7
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG59
 
G_M000_IG103:                ;; offset=0x0904
       xor      eax, eax
       add      r9, -32
       je       SHORT G_M000_IG104
       vmovups  ymm0, ymmword ptr [rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       je       G_M000_IG68
       jmp      G_M000_IG44
 
G_M000_IG104:                ;; offset=0x0928
       vmovups  ymm0, ymmword ptr [rdx+r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+r9]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      G_M000_IG44
       jmp      G_M000_IG60
 
G_M000_IG105:                ;; offset=0x0946
       xor      r11d, r11d
       add      r9, -16
       je       SHORT G_M000_IG108
       vmovups  xmm0, xmmword ptr [rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      G_M000_IG44
 
G_M000_IG106:                ;; offset=0x0967
       add      r11, 16
       cmp      r9, r11
       jbe      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x0970
       vmovups  xmm0, xmmword ptr [rdx+r11]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+r11]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       jne      G_M000_IG44
       jmp      SHORT G_M000_IG106
 
G_M000_IG108:                ;; offset=0x098D
       vmovups  xmm0, xmmword ptr [rdx+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+r9]
       vpmovmskb edx, xmm0
       cmp      edx, 0xFFFF
       jne      G_M000_IG44
       jmp      G_M000_IG60
 
G_M000_IG109:                ;; offset=0x09AE
       mov      eax, -1
 
G_M000_IG110:                ;; offset=0x09B3
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG111:                ;; offset=0x09CA
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000786h ; case G_M000_IG87
       	dd	00000781h ; case G_M000_IG86
       	dd	0000077Ch ; case G_M000_IG85

; Total bytes of code 2512

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 139968
; 81 inlinees with PGO data; 188 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 696
       lea      rbp, [rsp+0x2F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       mov      rax, -288
 
G_M000_IG287:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG287
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x28], r9
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x0064
       mov      esi, dword ptr [rcx+0x60]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG228
 
G_M000_IG04:                ;; offset=0x0084
       mov      eax, dword ptr [r9+0x14]
 
G_M000_IG05:                ;; offset=0x0088
       cmp      esi, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rcx]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x00AF
       test     rbx, rbx
       je       G_M000_IG229
 
G_M000_IG07:                ;; offset=0x00B8
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG21
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00CC
       test     rax, rax
       sete     sil
       movzx    rsi, sil
 
G_M000_IG09:                ;; offset=0x00D7
       test     esi, esi
       je       G_M000_IG225
       mov      rax, gword ptr [rcx+0x20]
       mov      edx, dword ptr [r9+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG253
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x22A28C01FE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG230
 
G_M000_IG10:                ;; offset=0x010F
       mov      rdx, gword ptr [rax]
       mov      r8, 0x22A28C01FE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG231
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG232
       mov      rdi, gword ptr [rax]
 
G_M000_IG11:                ;; offset=0x0133
       test     rdi, rdi
       je       G_M000_IG233
       mov      rax, 0x7FFA02D930D0
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG225
 
G_M000_IG12:                ;; offset=0x014F
       mov      gword ptr [rbp-0x1B8], rdi
       mov      rax, gword ptr [rbp-0x1B8]
       mov      rax, gword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdi+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG225
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x18]
       mov      dword ptr [rbp-0x3C], esi
       mov      r9, bword ptr [rbp+0x28]
       cmp      dword ptr [r9+0x1C], 68
       jne      G_M000_IG234
       mov      ebx, dword ptr [r9+0x0C]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG253
       mov      r8d, ebx
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG235
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FFA02BC21E8
       cmp      qword ptr [rax], r8
       jne      G_M000_IG237
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG236
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG13:                ;; offset=0x01ED
       mov      gword ptr [rbp-0x1C0], r14
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rax, rdx
       lea      r8d, [rsi+0x02]
       mov      r10d, dword ptr [rax+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG253
       lea      r8d, [rsi+0x02]
       shl      r8, 5
       lea      r15, bword ptr [rax+r8+0x10]
       mov      bword ptr [rbp-0x1C8], r15
       mov      rax, rdx
       lea      r8d, [rbx+0x01]
       cmp      r8d, r10d
       jae      G_M000_IG253
       lea      r8d, [rbx+0x01]
       shl      r8, 5
       lea      r13, bword ptr [rax+r8+0x10]
       mov      rax, rdx
       lea      r8d, [rbx+0x02]
       cmp      r8d, r10d
       jae      G_M000_IG253
       lea      r8d, [rbx+0x02]
       shl      r8, 5
       lea      rax, bword ptr [rax+r8+0x10]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x30]
       mov      rax, r12
       lea      r8d, [rsi+0x04]
       cmp      r8d, r10d
       jae      G_M000_IG253
       lea      r8d, [rsi+0x04]
       shl      r8, 5
       lea      r8, bword ptr [rdx+r8+0x10]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 35
       jg       G_M000_IG239
       cmp      edx, 35
       ja       G_M000_IG238
       mov      r10, 0x7FFFFFFBD
       bt       r10, rdx
       jb       G_M000_IG238
 
G_M000_IG14:                ;; offset=0x02B9
       mov      edx, dword ptr [r8+0x08]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG253
       mov      rax, gword ptr [rax+8*rdx+0x10]
       mov      gword ptr [rbp-0x1D8], rax
       mov      edx, dword ptr [r13+0x0C]
       not      edx
       cmp      edx, dword ptr [r12+0x08]
       jae      G_M000_IG253
       mov      r13, gword ptr [r12+8*rdx+0x10]
       mov      rdx, 0x7FFA029E8768
       cmp      qword ptr [r13], rdx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02F8
       mov      rdx, r13
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG16:                ;; offset=0x030A
       mov      r12, gword ptr [r13+0x08]
       mov      gword ptr [rbp-0x250], r12
       mov      r13d, dword ptr [r13+0x10]
       mov      dword ptr [rbp-0x144], r13d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8, bword ptr [rbp-0x1D0]
       mov      r10d, dword ptr [r8+0x0C]
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG253
       shl      r10, 4
       lea      rdx, bword ptr [rdx+r10+0x10]
       mov      r10, gword ptr [rdx]
       mov      r11, 0x22A28C01FE0
       cmp      r10, gword ptr [r11]
       je       G_M000_IG240
 
G_M000_IG17:                ;; offset=0x035C
       mov      r10, gword ptr [rdx]
       mov      r11, 0x22A28C01FE8
       cmp      r10, gword ptr [r11]
       je       G_M000_IG241
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG242
       mov      r10, gword ptr [rdx]
 
G_M000_IG18:                ;; offset=0x0380
       test     r10, r10
       jne      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x0385
       xor      eax, eax
 
G_M000_IG20:                ;; offset=0x0387
       vzeroupper 
       add      rsp, 696
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x039E
       xor      esi, esi
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x03A5
       mov      rdx, 0x7FFA02BC9928
       cmp      qword ptr [r10], rdx
       jne      SHORT G_M000_IG19
 
G_M000_IG23:                ;; offset=0x03B4
       mov      gword ptr [rbp-0x1E0], r10
       cmp      gword ptr [r10+0x28], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r10+0x30], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG19
       cmp      dword ptr [r10+0x50], 0
       jne      SHORT G_M000_IG19
       mov      rdx, gword ptr [r10+0x10]
       mov      r11, gword ptr [rdi+0x98]
       cmp      rdx, gword ptr [r11+0x88]
       jne      SHORT G_M000_IG19
       lea      r11d, [rbx+0x03]
       mov      dword ptr [rbp-0x40], r11d
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG253
       mov      eax, r11d
       shl      rax, 5
       lea      rdx, bword ptr [rdx+rax+0x10]
       mov      bword ptr [rbp-0x1E8], rdx
       mov      rax, bword ptr [rbp-0x1E8]
       cmp      dword ptr [rax+0x1C], 47
       sete     dl
       movzx    rdx, dl
       mov      dword ptr [rbp-0x44], edx
       xor      eax, eax
       mov      qword ptr [rbp-0x50], rax
 
G_M000_IG24:                ;; offset=0x0438
       test     edx, edx
       je       G_M000_IG31
 
G_M000_IG25:                ;; offset=0x0440
       mov      rax, gword ptr [rcx+0x08]
       mov      r8, bword ptr [rbp-0x1E8]
       mov      r8d, dword ptr [r8+0x10]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG253
       shl      r8, 4
       lea      rax, bword ptr [rax+r8+0x10]
       mov      bword ptr [rbp-0x208], rax
       mov      r8, gword ptr [rax]
       mov      r11, 0x22A28C01FE0
       cmp      r8, gword ptr [r11]
       jne      G_M000_IG243
 
G_M000_IG26:                ;; offset=0x047F
       mov      rax, qword ptr [rax+0x08]
       mov      qword ptr [rbp-0x50], rax
 
G_M000_IG27:                ;; offset=0x0487
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x50], rax
       jl       G_M000_IG19
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x50], rax
       jge      G_M000_IG19
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x30]
       mov      r8, bword ptr [rbp-0x1E8]
       mov      r11d, dword ptr [r8+0x0C]
       not      r11d
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG253
       mov      rax, gword ptr [rax+8*r11+0x10]
       mov      gword ptr [rbp-0x200], rax
       mov      r11, 0x7FFA029E8768
       cmp      qword ptr [rax], r11
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x04ED
       mov      rdx, rax
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x200]
 
G_M000_IG29:                ;; offset=0x0506
       mov      r11, gword ptr [rax+0x08]
       mov      eax, dword ptr [rax+0x10]
       test     r11, r11
       jne      G_M000_IG248
       cdqe     
 
G_M000_IG30:                ;; offset=0x0518
       mov      qword ptr [rbp-0x58], rax
       mov      rcx, bword ptr [rbp+0x10]
 
G_M000_IG31:                ;; offset=0x0520
       xor      r11, r11
       mov      bword ptr [rbp-0x258], r11
 
G_M000_IG32:                ;; offset=0x052A
       mov      dword ptr [rbp-0x148], r11d
 
G_M000_IG33:                ;; offset=0x0531
       mov      gword ptr [rbp-0x1F0], r11
 
G_M000_IG34:                ;; offset=0x0538
       mov      dword ptr [rbp-0x5C], r11d
 
G_M000_IG35:                ;; offset=0x053C
       mov      dword ptr [rbp-0x60], r11d
 
G_M000_IG36:                ;; offset=0x0540
       mov      dword ptr [rbp-0x64], r11d
       mov      qword ptr [rbp-0x58], rax
 
G_M000_IG37:                ;; offset=0x0548
       xor      r11, r11
       xor      r8d, r8d
       xor      rdx, rdx
       mov      r15, gword ptr [rbp-0x1B8]
       mov      r15d, dword ptr [r15+0x34]
       mov      rax, gword ptr [rbp-0x1B8]
       cmp      r15d, dword ptr [rax+0x30]
       je       G_M000_IG127
 
G_M000_IG38:                ;; offset=0x056C
       mov      rax, gword ptr [rbp-0x1B8]
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       je       G_M000_IG137
 
G_M000_IG39:                ;; offset=0x0580
       lea      r15, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG40:                ;; offset=0x0587
       mov      r13, gword ptr [rbp-0x1B8]
       add      r13, 52
       mov      r12d, dword ptr [r13]
       add      r12d, 4
       mov      r14d, dword ptr [r13]
       cmp      r14d, eax
       mov      bword ptr [rbp-0x268], r15
       ja       G_M000_IG217
       mov      r15d, r14d
       add      r15, bword ptr [rbp-0x268]
       sub      eax, r14d
       cmp      eax, 4
       jl       G_M000_IG218
       mov      eax, dword ptr [r15]
       lea      r14d, [r12+rax]
       mov      dword ptr [r13], r14d
       mov      r14d, dword ptr [r13]
       cmp      eax, 0x1000
       jg       G_M000_IG139
       mov      r11, gword ptr [rbp-0x1B8]
       mov      r8, gword ptr [r11+0x10]
       test     r8, r8
       je       G_M000_IG138
       mov      r11d, r12d
       mov      r14d, eax
       add      r11, r14
       mov      r14d, dword ptr [r8+0x08]
       cmp      r11, r14
       ja       G_M000_IG217
       mov      r11d, r12d
       lea      r11, bword ptr [r8+r11+0x10]
       mov      r8d, eax
 
G_M000_IG41:                ;; offset=0x0613
       mov      bword ptr [rbp-0x260], r11
       mov      dword ptr [rbp-0x14C], r8d
 
G_M000_IG42:                ;; offset=0x0621
       mov      r14, bword ptr [rbp-0x260]
       mov      bword ptr [rbp-0x258], r14
       mov      r15d, dword ptr [rbp-0x14C]
       mov      dword ptr [rbp-0x148], r15d
       mov      gword ptr [rbp-0x1F8], rdx
       mov      gword ptr [rbp-0x1F0], rdx
       cmp      dword ptr [rbp-0x60], 0
       je       G_M000_IG132
 
G_M000_IG43:                ;; offset=0x0655
       mov      dword ptr [rcx+0x18], ebx
 
G_M000_IG44:                ;; offset=0x0658
       mov      rdx, gword ptr [rbp-0x1F8]
       test     rdx, rdx
       jne      G_M000_IG214
       mov      dword ptr [rbp-0x158], r15d
       mov      r12, gword ptr [rbp-0x1C0]
       mov      r8, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x210], r8
       mov      rdx, gword ptr [rdi+0x98]
       mov      r11, gword ptr [rdx+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG143
       mov      r11, gword ptr [rdx+0x180]
       test     r11, r11
       jne      G_M000_IG142
 
G_M000_IG45:                ;; offset=0x06AB
       mov      r10, gword ptr [rbp-0x1E0]
       mov      r11, gword ptr [r10+0x28]
       mov      gword ptr [rbp-0x218], r11
       mov      edx, dword ptr [r10+0x4C]
       mov      dword ptr [rbp-0x74], edx
       mov      bword ptr [rbp-0x270], r14
       cmp      edx, 4
       jle      G_M000_IG144
 
G_M000_IG46:                ;; offset=0x06D4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       xor      r12d, r12d
       cmp      r12d, r15d
       jge      G_M000_IG77
 
G_M000_IG47:                ;; offset=0x06F8
       mov      r8, gword ptr [rdi+0x98]
       mov      r13, gword ptr [r8+0x88]
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG153
       mov      r13, gword ptr [r8+0x180]
       test     r13, r13
       jne      G_M000_IG152
 
G_M000_IG48:                ;; offset=0x0721
       mov      r13d, r15d
       sub      r13d, r12d
       cmp      r13d, 0x1000
       jge      G_M000_IG64
 
G_M000_IG49:                ;; offset=0x0734
       mov      r8d, r12d
       mov      edx, r13d
       add      rdx, r8
       mov      r8d, r15d
       cmp      rdx, r8
       ja       G_M000_IG217
       mov      r8d, r12d
       mov      bword ptr [rbp-0x260], r14
       add      r8, r14
       mov      bword ptr [rbp-0x278], r8
       mov      rdx, r8
       mov      r8d, r13d
       cmp      r13d, 16
       jl       G_M000_IG59
 
G_M000_IG50:                ;; offset=0x076D
       cmp      dword ptr [rbp-0x8C], 0
       jne      G_M000_IG154
       mov      rax, 0xADB2BC6F4BEA3620
       mov      qword ptr [rbp-0xA8], rax
       mov      rax, 0x898F784727C6F1F8
       mov      qword ptr [rbp-0xA0], rax
 
G_M000_IG51:                ;; offset=0x079C
       cmp      r8d, 16
       jl       G_M000_IG59
 
G_M000_IG52:                ;; offset=0x07A6
       mov      eax, dword ptr [rbp-0xA8]
       imul     esi, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      eax, esi
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], eax
       mov      eax, dword ptr [rbp-0xA4]
       lea      rsi, bword ptr [rdx+0x04]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      eax, esi
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], eax
       mov      eax, dword ptr [rbp-0xA0]
       lea      rsi, bword ptr [rdx+0x08]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      eax, esi
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA0], eax
       mov      eax, dword ptr [rbp-0x9C]
       lea      rsi, bword ptr [rdx+0x0C]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      eax, esi
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x9C], eax
       mov      eax, dword ptr [rbp-0x8C]
       add      eax, 4
       mov      dword ptr [rbp-0x8C], eax
       add      rdx, 16
       add      r8d, -16
       mov      rsi, rdx
       mov      eax, r8d
       mov      rdx, rsi
       mov      r8d, eax
       jmp      G_M000_IG51
 
G_M000_IG53:                ;; offset=0x084E
       cmp      eax, 3
       jne      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0853
       mov      rax, 0xADB2BC6F4BEA3620
       mov      qword ptr [rbp-0xA8], rax
       mov      rax, 0x898F784727C6F1F8
       mov      qword ptr [rbp-0xA0], rax
 
G_M000_IG55:                ;; offset=0x0875
       imul     eax, dword ptr [rbp-0x98], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xA8]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], eax
       imul     eax, dword ptr [rbp-0x94], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xA4]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], eax
       imul     eax, dword ptr [rbp-0x90], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0xA0]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA0], eax
       imul     eax, dword ptr [rbp-0xAC], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x9C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x9C], eax
       jmp      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x08F3
       mov      eax, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0x94], eax
       jmp      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0901
       mov      eax, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0x98], eax
 
G_M000_IG58:                ;; offset=0x090D
       add      rdx, 4
       add      r8d, -4
       mov      rsi, rdx
       mov      eax, r8d
       mov      rdx, rsi
       mov      r8d, eax
 
G_M000_IG59:                ;; offset=0x0921
       cmp      r8d, 4
       jl       SHORT G_M000_IG65
 
G_M000_IG60:                ;; offset=0x0927
       mov      eax, dword ptr [rdx]
       mov      dword ptr [rbp-0xAC], eax
       mov      eax, dword ptr [rbp-0x8C]
       lea      esi, [rax+0x01]
       mov      dword ptr [rbp-0x8C], esi
       mov      esi, eax
       and      esi, 3
       je       SHORT G_M000_IG57
 
G_M000_IG61:                ;; offset=0x0945
       cmp      esi, 1
       je       SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x094A
       cmp      esi, 2
       jne      G_M000_IG53
 
G_M000_IG63:                ;; offset=0x0953
       mov      eax, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0x90], eax
       jmp      SHORT G_M000_IG58
 
G_M000_IG64:                ;; offset=0x0961
       mov      r13d, 0x1000
       jmp      G_M000_IG49
 
G_M000_IG65:                ;; offset=0x096C
       mov      rax, rdx
       mov      bword ptr [rbp-0x280], rax
       mov      edx, r8d
       xor      r8d, r8d
       test     edx, edx
       je       G_M000_IG76
 
G_M000_IG66:                ;; offset=0x0984
       movzx    rax, byte  ptr [rax+r8]
       mov      dword ptr [rbp-0xB0], eax
       mov      esi, dword ptr [rbp-0x8C]
       lea      eax, [rsi+0x01]
       mov      dword ptr [rbp-0x8C], eax
       mov      eax, esi
       and      eax, 3
       je       G_M000_IG74
 
G_M000_IG67:                ;; offset=0x09A9
       cmp      eax, 1
       je       G_M000_IG73
 
G_M000_IG68:                ;; offset=0x09B2
       cmp      eax, 2
       jne      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x09B7
       mov      eax, dword ptr [rbp-0xB0]
       mov      dword ptr [rbp-0x90], eax
       jmp      G_M000_IG75
 
G_M000_IG70:                ;; offset=0x09C8
       cmp      esi, 3
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x09CD
       mov      rsi, 0xADB2BC6F4BEA3620
       mov      qword ptr [rbp-0xA8], rsi
       mov      rsi, 0x898F784727C6F1F8
       mov      qword ptr [rbp-0xA0], rsi
 
G_M000_IG72:                ;; offset=0x09EF
       imul     esi, dword ptr [rbp-0x98], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0xA8]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA8], esi
       imul     esi, dword ptr [rbp-0x94], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0xA4]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA4], esi
       imul     esi, dword ptr [rbp-0x90], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0xA0]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0xA0], esi
       imul     eax, dword ptr [rbp-0xB0], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x9C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x9C], eax
       jmp      SHORT G_M000_IG75
 
G_M000_IG73:                ;; offset=0x0A6D
       mov      eax, dword ptr [rbp-0xB0]
       mov      dword ptr [rbp-0x94], eax
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0A7B
       mov      eax, dword ptr [rbp-0xB0]
       mov      dword ptr [rbp-0x98], eax
 
G_M000_IG75:                ;; offset=0x0A87
       inc      r8d
       cmp      r8d, edx
       mov      rax, bword ptr [rbp-0x280]
       jl       G_M000_IG66
 
G_M000_IG76:                ;; offset=0x0A9A
       add      r12d, r13d
       cmp      r12d, r15d
       mov      edx, dword ptr [rbp-0x74]
       mov      r14, bword ptr [rbp-0x260]
       jl       G_M000_IG47
 
G_M000_IG77:                ;; offset=0x0AB0
       mov      r12d, dword ptr [rbp-0x8C]
       mov      r8d, r12d
       and      r8d, 3
       cmp      r12d, 4
       jae      G_M000_IG134
 
G_M000_IG78:                ;; offset=0x0AC8
       mov      r13d, 0x3E1D59A9
 
G_M000_IG79:                ;; offset=0x0ACE
       lea      r13d, [r13+4*r12]
       test     r8d, r8d
       je       SHORT G_M000_IG83
 
G_M000_IG80:                ;; offset=0x0AD8
       imul     r12d, dword ptr [rbp-0x98], 0xFFFFFFFFC2B2AE3D
       add      r13d, r12d
       rol      r13d, 17
       imul     r13d, r13d, 0x27D4EB2F
       cmp      r8d, 1
       jbe      SHORT G_M000_IG83
 
G_M000_IG81:                ;; offset=0x0AF7
       imul     r12d, dword ptr [rbp-0x94], 0xFFFFFFFFC2B2AE3D
       add      r12d, r13d
       rol      r12d, 17
       imul     r13d, r12d, 0x27D4EB2F
       cmp      r8d, 2
       jbe      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0B16
       imul     r8d, dword ptr [rbp-0x90], 0xFFFFFFFFC2B2AE3D
       add      r8d, r13d
       rol      r8d, 17
       imul     r13d, r8d, 0x27D4EB2F
 
G_M000_IG83:                ;; offset=0x0B2F
       mov      r8d, r13d
       shr      r8d, 15
       xor      r8d, r13d
       imul     r8d, r8d, 0xFFFFFFFF85EBCA77
       mov      r13d, r8d
       shr      r13d, 13
       xor      r13d, r8d
       imul     r8d, r13d, 0xFFFFFFFFC2B2AE3D
       mov      r13d, r8d
       shr      r13d, 16
       xor      r13d, r8d
       cmp      r13d, -1
       je       G_M000_IG160
       mov      r8d, r13d
 
G_M000_IG84:                ;; offset=0x0B68
       mov      r13d, r8d
       shr      r13d, 16
       xor      r13d, r8d
       imul     r13d, r13d, 0xFFFFFFFF9E3779B9
       mov      r8d, r13d
       shr      r8d, 16
       xor      r13d, r8d
       test     edx, edx
       je       G_M000_IG190
 
G_M000_IG85:                ;; offset=0x0B8B
       mov      r8d, dword ptr [r11+0x08]
       mov      r12d, r8d
       mov      r8d, r12d
       blsr     edx, r8d
       jne      G_M000_IG161
       dec      r8d
       and      r8d, r13d
 
G_M000_IG86:                ;; offset=0x0BA6
       cmp      r8d, r12d
       jae      G_M000_IG222
       mov      edx, r8d
       lea      rdx, [rdx+4*rdx]
       mov      r8d, dword ptr [r11+8*rdx+0x30]
       dec      r8d
       mov      dword ptr [rbp-0x78], r8d
       test     r8d, r8d
       jl       G_M000_IG163
       jmp      SHORT G_M000_IG89
 
G_M000_IG87:                ;; offset=0x0BCD
       mov      r11, gword ptr [rbp-0x218]
 
G_M000_IG88:                ;; offset=0x0BD4
       mov      r8d, dword ptr [rsi+0x1C]
       dec      r8d
       mov      esi, r8d
       test     esi, esi
       mov      dword ptr [rbp-0x78], esi
       jl       G_M000_IG190
 
G_M000_IG89:                ;; offset=0x0BE9
       mov      rdx, gword ptr [rdi+0x98]
       mov      rsi, gword ptr [rdx+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG164
       mov      rsi, gword ptr [rdx+0x180]
       test     rsi, rsi
       jne      G_M000_IG162
 
G_M000_IG90:                ;; offset=0x0C12
       mov      r8d, dword ptr [rbp-0x78]
       cmp      r8d, r12d
       jae      G_M000_IG222
       mov      dword ptr [rbp-0x78], r8d
       mov      edx, r8d
       lea      rdx, [rdx+4*rdx]
       mov      r11, gword ptr [rbp-0x218]
       lea      rsi, bword ptr [r11+8*rdx+0x10]
       cmp      dword ptr [rsi+0x18], r13d
       jne      SHORT G_M000_IG88
 
G_M000_IG91:                ;; offset=0x0C3C
       mov      rdx, gword ptr [r11+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG87
 
G_M000_IG92:                ;; offset=0x0C46
       mov      rax, 0x7FFA02A61F30
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG126
 
G_M000_IG93:                ;; offset=0x0C59
       movzx    rax, byte  ptr [rdx+0x24]
       test     eax, eax
       je       G_M000_IG121
 
G_M000_IG94:                ;; offset=0x0C65
       cmp      eax, 255
       je       G_M000_IG119
 
G_M000_IG95:                ;; offset=0x0C70
       lea      rax, bword ptr [rdx+0x28]
       mov      edx, dword ptr [rdx+0x18]
       cmp      edx, 8
       ja       G_M000_IG217
 
G_M000_IG96:                ;; offset=0x0C80
       mov      bword ptr [rbp-0x288], rax
       mov      dword ptr [rbp-0x15C], edx
       mov      eax, dword ptr [rbp-0x158]
       cmp      edx, eax
       jne      G_M000_IG167
       xor      edx, edx
       mov      dword ptr [rbp-0xB4], edx
       cmp      edx, eax
       mov      bword ptr [rbp-0x260], r14
       jge      G_M000_IG105
 
G_M000_IG97:                ;; offset=0x0CB2
       mov      rax, gword ptr [rdi+0x98]
       mov      r14, gword ptr [rax+0x88]
       cmp      gword ptr [r14+0x20], 0
       jne      G_M000_IG169
       mov      r14, gword ptr [rax+0x180]
       test     r14, r14
       jne      G_M000_IG168
 
G_M000_IG98:                ;; offset=0x0CDB
       mov      r14d, dword ptr [rbp-0x158]
       mov      edx, dword ptr [rbp-0xB4]
       mov      eax, r14d
       sub      eax, edx
       cmp      eax, 0x1000
       jge      G_M000_IG123
 
G_M000_IG99:                ;; offset=0x0CF8
       mov      dword ptr [rbp-0xB8], eax
       mov      r14d, edx
       mov      eax, eax
       mov      qword ptr [rbp-0x1A8], rax
       add      r14, rax
       mov      qword ptr [rbp-0x198], r14
       mov      eax, dword ptr [rbp-0x158]
       cmp      r14, rax
       ja       G_M000_IG217
       mov      eax, edx
       add      rax, bword ptr [rbp-0x270]
       mov      bword ptr [rbp-0x290], rax
       mov      r14d, dword ptr [rbp-0x15C]
       cmp      qword ptr [rbp-0x198], r14
       ja       G_M000_IG217
       mov      r14d, edx
       add      r14, bword ptr [rbp-0x288]
       mov      bword ptr [rbp-0x298], r14
       mov      bword ptr [rbp-0x228], rax
       mov      bword ptr [rbp-0x230], r14
       mov      rax, qword ptr [rbp-0x1A8]
       cmp      rax, 8
       jb       G_M000_IG124
 
G_M000_IG100:                ;; offset=0x0D77
       mov      r14, bword ptr [rbp-0x228]
       cmp      r14, bword ptr [rbp-0x230]
       je       SHORT G_M000_IG104
       cmp      rax, 32
       jae      G_M000_IG176
 
G_M000_IG101:                ;; offset=0x0D91
       cmp      rax, 16
       jae      G_M000_IG184
 
G_M000_IG102:                ;; offset=0x0D9B
       add      rax, -8
       mov      qword ptr [rbp-0xC8], rax
       mov      r14, bword ptr [rbp-0x290]
       mov      rax, qword ptr [r14]
       mov      r14, bword ptr [rbp-0x298]
       sub      rax, qword ptr [r14]
       mov      qword ptr [rbp-0x2AC], rax
       mov      r14, bword ptr [rbp-0x290]
       mov      rax, qword ptr [rbp-0xC8]
       mov      r14, qword ptr [r14+rax]
       mov      r9, bword ptr [rbp-0x298]
       sub      r14, qword ptr [r9+rax]
       or       r14, qword ptr [rbp-0x2AC]
       sete     al
       movzx    rax, al
 
G_M000_IG103:                ;; offset=0x0DEB
       test     eax, eax
       je       G_M000_IG175
 
G_M000_IG104:                ;; offset=0x0DF3
       add      edx, dword ptr [rbp-0xB8]
       mov      r14d, dword ptr [rbp-0x158]
       cmp      edx, r14d
       mov      dword ptr [rbp-0xB4], edx
       jl       G_M000_IG97
 
G_M000_IG105:                ;; offset=0x0E0F
       mov      r8d, dword ptr [rbp-0x78]
       mov      r12d, r8d
 
G_M000_IG106:                ;; offset=0x0E16
       mov      byte  ptr [rbp-0x150], 0
       xor      eax, eax
       mov      dword ptr [rbp-0x154], eax
       test     r12d, r12d
       jl       G_M000_IG191
 
G_M000_IG107:                ;; offset=0x0E2E
       mov      r11, gword ptr [rbp-0x218]
       mov      edx, dword ptr [r11+0x08]
       mov      edx, r12d
       lea      rdx, [rdx+4*rdx]
       lea      r8, bword ptr [r11+8*rdx+0x10]
       mov      r13d, r12d
       mov      r11, gword ptr [r8]
       mov      rax, r11
       test     rax, rax
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x0E53
       mov      rsi, 0x7FFA02A61F30
       cmp      qword ptr [rax], rsi
       jne      G_M000_IG196
 
G_M000_IG109:                ;; offset=0x0E66
       mov      gword ptr [rbp-0x238], rax
       mov      r8d, dword ptr [r8+0x18]
       mov      dword ptr [rbp-0x12C], r8d
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
       mov      r10, gword ptr [rbp-0x1E0]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG197
       mov      r11, gword ptr [r10+0x30]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG222
       mov      esi, r13d
       cmp      gword ptr [r11+8*rsi+0x10], 0
       jne      G_M000_IG197
 
G_M000_IG110:                ;; offset=0x0EB3
       mov      r11, gword ptr [r10+0x28]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG222
       mov      rsi, qword ptr [r11+8*rdx+0x20]
       mov      rdx, 0xFF80000000000000
       cmp      rsi, rdx
       jl       G_M000_IG199
       mov      rdx, 0x80000000000000
       cmp      rsi, rdx
       jge      G_M000_IG199
 
G_M000_IG111:                ;; offset=0x0EEC
       mov      rdx, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x180], rdx
       mov      r11d, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x178], r11d
       lea      rcx, [rbp-0x180]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       lea      rdx, [rax+rsi]
       mov      rsi, gword ptr [rbp-0x1E0]
       mov      eax, dword ptr [rsi+0x4C]
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG209
       mov      rcx, gword ptr [rsi+0x28]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG222
       mov      r8d, r13d
       lea      r8, [r8+4*r8]
       mov      qword ptr [rcx+8*r8+0x20], rdx
       mov      rcx, gword ptr [rsi+0x30]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG222
       mov      edx, r13d
       xor      r8, r8
       mov      gword ptr [rcx+8*rdx+0x10], r8
 
G_M000_IG112:                ;; offset=0x0F67
       mov      eax, dword ptr [rbp-0x114]
       cmp      dword ptr [rsi+0x4C], eax
       jne      G_M000_IG210
 
G_M000_IG113:                ;; offset=0x0F76
       mov      eax, 1
 
G_M000_IG114:                ;; offset=0x0F7B
       movzx    r13, byte  ptr [rbp-0x150]
       test     r13d, r13d
       jne      G_M000_IG211
 
G_M000_IG115:                ;; offset=0x0F8C
       test     eax, eax
       je       G_M000_IG219
 
G_M000_IG116:                ;; offset=0x0F94
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x0F9A
       mov      r8, qword ptr [rbp-0x58]
       mov      rdx, r8
       add      rdx, qword ptr [rbp-0x50]
       mov      qword ptr [rbp-0x50], rdx
       mov      dword ptr [rbp-0x5C], 1
       mov      rdx, 0xFF80000000000000
       cmp      qword ptr [rbp-0x50], rdx
       jl       G_M000_IG220
       mov      rdx, 0x80000000000000
       cmp      qword ptr [rbp-0x50], rdx
       jge      G_M000_IG220
 
G_M000_IG118:                ;; offset=0x0FD8
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10d, dword ptr [rbp-0x3C]
       mov      dword ptr [rcx+0x18], r10d
       mov      r9, bword ptr [rbp+0x28]
       mov      rdx, gword ptr [r9]
       mov      r11, gword ptr [rdi+0x98]
       mov      r8, gword ptr [r11+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG216
       mov      r8, gword ptr [r11+0x180]
       test     r8, r8
       mov      gword ptr [rbp-0x2A0], r8
       mov      gword ptr [rbp-0x248], rdx
       mov      rcx, bword ptr [rbp+0x10]
       je       G_M000_IG37
       jmp      G_M000_IG215
 
G_M000_IG119:                ;; offset=0x102B
       mov      rax, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x220], rax
       lea      rax, bword ptr [rdx+0x28]
       mov      eax, dword ptr [rax]
       mov      edx, dword ptr [rdx+0x18]
       mov      dword ptr [rbp-0xBC], edx
       cmp      gword ptr [rbp-0x220], 0
       je       G_M000_IG166
       mov      qword ptr [rbp-0x1A0], rax
       mov      eax, edx
       add      rax, qword ptr [rbp-0x1A0]
       mov      qword ptr [rbp-0x2AC], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      eax, dword ptr [rax+0x08]
       cmp      qword ptr [rbp-0x2AC], rax
       ja       G_M000_IG217
       mov      rax, gword ptr [rbp-0x220]
       mov      rdx, qword ptr [rbp-0x1A0]
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      edx, dword ptr [rbp-0xBC]
 
G_M000_IG120:                ;; offset=0x109A
       jmp      G_M000_IG96
 
G_M000_IG121:                ;; offset=0x109F
       mov      rax, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x18]
       test     rax, rax
       je       G_M000_IG165
       cmp      dword ptr [rax+0x08], edx
       jb       G_M000_IG217
       add      rax, 16
 
G_M000_IG122:                ;; offset=0x10BC
       jmp      G_M000_IG96
 
G_M000_IG123:                ;; offset=0x10C1
       mov      eax, 0x1000
       jmp      G_M000_IG99
 
G_M000_IG124:                ;; offset=0x10CB
       cmp      rax, 4
       jb       G_M000_IG170
 
G_M000_IG125:                ;; offset=0x10D5
       add      rax, -4
       mov      qword ptr [rbp-0xF0], rax
       mov      rax, bword ptr [rbp-0x290]
       mov      eax, dword ptr [rax]
       mov      r14, bword ptr [rbp-0x298]
       sub      eax, dword ptr [r14]
       mov      dword ptr [rbp-0x2A4], eax
       mov      rax, bword ptr [rbp-0x290]
       mov      r14, qword ptr [rbp-0xF0]
       mov      eax, dword ptr [rax+r14]
       mov      r9, bword ptr [rbp-0x298]
       sub      eax, dword ptr [r9+r14]
       or       eax, dword ptr [rbp-0x2A4]
       sete     al
       movzx    rax, al
       jmp      G_M000_IG103
 
G_M000_IG126:                ;; offset=0x1127
       mov      r11, gword ptr [rbp-0x218]
       jmp      G_M000_IG88
 
G_M000_IG127:                ;; offset=0x1133
       mov      dword ptr [rbp-0x64], 1
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x1C]
       cmp      edx, 51
       jg       G_M000_IG135
 
G_M000_IG128:                ;; offset=0x114B
       cmp      edx, 41
       je       SHORT G_M000_IG130
 
G_M000_IG129:                ;; offset=0x1150
       add      edx, -49
       cmp      edx, 2
       ja       G_M000_IG221
 
G_M000_IG130:                ;; offset=0x115C
       mov      eax, dword ptr [r9+0x08]
       mov      dword ptr [rcx+0x18], eax
 
G_M000_IG131:                ;; offset=0x1163
       mov      dword ptr [rbp-0x68], 1
       jmp      G_M000_IG223
 
G_M000_IG132:                ;; offset=0x116F
       mov      r13, bword ptr [rbp-0x1C8]
       mov      rax, gword ptr [r13]
       mov      r8, gword ptr [rdi+0x98]
       mov      r11, gword ptr [r8+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG141
       mov      r11, gword ptr [r8+0x180]
       test     r11, r11
       jne      G_M000_IG140
 
G_M000_IG133:                ;; offset=0x11A3
       mov      dword ptr [rcx+0x18], ebx
       mov      r12, gword ptr [rbp-0x1C0]
       mov      rax, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x60], 1
       jmp      G_M000_IG44
 
G_M000_IG134:                ;; offset=0x11D0
       rorx     r13d, dword ptr [rbp-0xA8], 31
       mov      dword ptr [rbp-0x2A4], r13d
       rorx     r13d, dword ptr [rbp-0xA4], 25
       add      r13d, dword ptr [rbp-0x2A4]
       mov      dword ptr [rbp-0x2A4], r13d
       rorx     r13d, dword ptr [rbp-0xA0], 20
       add      r13d, dword ptr [rbp-0x2A4]
       mov      dword ptr [rbp-0x2A4], r13d
       rorx     r13d, dword ptr [rbp-0x9C], 14
       add      r13d, dword ptr [rbp-0x2A4]
       jmp      G_M000_IG79
 
G_M000_IG135:                ;; offset=0x1227
       cmp      edx, 56
       je       G_M000_IG130
 
G_M000_IG136:                ;; offset=0x1230
       cmp      edx, 62
       je       G_M000_IG130
       add      edx, -68
       cmp      edx, 1
       ja       G_M000_IG221
       jmp      G_M000_IG130
 
G_M000_IG137:                ;; offset=0x124A
       xor      r15, r15
       mov      bword ptr [rbp-0x268], r15
       xor      eax, eax
       mov      r15, bword ptr [rbp-0x268]
       jmp      G_M000_IG40
 
G_M000_IG138:                ;; offset=0x1262
       or       r12d, eax
       jne      G_M000_IG217
       xor      r11, r11
       xor      r8d, r8d
       jmp      G_M000_IG41
 
G_M000_IG139:                ;; offset=0x1276
       mov      dword ptr [rbp-0x14C], r8d
       mov      bword ptr [rbp-0x260], r11
       mov      dword ptr [rbp-0x170], r12d
       mov      dword ptr [rbp-0x16C], r14d
       mov      dword ptr [rbp-0x168], eax
       lea      rdx, [rbp-0x170]
       mov      rcx, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ValueTuple`3[int,int,int]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      r14, rax
       mov      rdx, r14
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG42
 
G_M000_IG140:                ;; offset=0x12BB
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG133
 
G_M000_IG141:                ;; offset=0x12D1
       mov      rcx, r8
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG133
 
G_M000_IG142:                ;; offset=0x12E6
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG45
 
G_M000_IG143:                ;; offset=0x12FC
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp-0x210]
       jmp      G_M000_IG45
 
G_M000_IG144:                ;; offset=0x1314
       cmp      dword ptr [rbp-0x158], 8
       jg       G_M000_IG46
 
G_M000_IG145:                ;; offset=0x1321
       xor      r13d, r13d
       xor      eax, eax
       test     edx, edx
       jle      G_M000_IG190
 
G_M000_IG146:                ;; offset=0x132E
       mov      r8d, dword ptr [r11+0x08]
       cmp      eax, r8d
       jae      G_M000_IG222
       mov      qword ptr [rbp-0x1B0], rax
       lea      r8, [rax+4*rax]
       mov      r8, gword ptr [r11+8*r8+0x10]
       test     r8, r8
       je       SHORT G_M000_IG150
 
G_M000_IG147:                ;; offset=0x1350
       mov      rax, 0x7FFA02A61F30
       cmp      qword ptr [r8], rax
       jne      SHORT G_M000_IG150
 
G_M000_IG148:                ;; offset=0x135F
       lea      rdx, [rbp-0x88]
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      r8d, dword ptr [rbp-0x80]
       cmp      r15d, r8d
       jne      SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x1378
       mov      rdx, bword ptr [rbp-0x88]
       mov      r8d, r8d
       mov      rcx, r14
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       jne      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x138F
       mov      rax, qword ptr [rbp-0x1B0]
       inc      eax
       mov      edx, dword ptr [rbp-0x74]
       cmp      eax, edx
       mov      r11, gword ptr [rbp-0x218]
       jl       SHORT G_M000_IG146
       jmp      G_M000_IG190
 
G_M000_IG151:                ;; offset=0x13AB
       mov      rax, qword ptr [rbp-0x1B0]
       mov      bword ptr [rbp-0x260], r14
       mov      r12d, eax
       jmp      G_M000_IG106
 
G_M000_IG152:                ;; offset=0x13C1
       cmp      dword ptr [r13+0x20], 0
       setne    r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG48
 
G_M000_IG153:                ;; offset=0x13D7
       mov      rcx, r8
       mov      rdx, gword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      edx, dword ptr [rbp-0x74]
       mov      r11, gword ptr [rbp-0x218]
       jmp      G_M000_IG48
 
G_M000_IG154:                ;; offset=0x13F6
       mov      eax, dword ptr [rbp-0x8C]
       and      eax, 3
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG51
       mov      qword ptr [rbp-0x2AC], rax
       lea      rax, [reloc @RWD00]
       mov      rsi, qword ptr [rbp-0x2AC]
       mov      eax, dword ptr [rax+4*rsi]
       lea      r14, G_M000_IG02
       add      rax, r14
       jmp      rax
 
G_M000_IG155:                ;; offset=0x142E
       mov      rsi, rdx
       mov      r14d, r8d
       jmp      SHORT G_M000_IG159
 
G_M000_IG156:                ;; offset=0x1436
       mov      rsi, rdx
       mov      r14d, r8d
       jmp      SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x143E
       mov      rsi, bword ptr [rbp-0x278]
       mov      edx, dword ptr [rsi]
       lea      rcx, [rbp-0xA8]
       call     [System.HashCode:Add(int):this]
       add      rsi, 4
       mov      rdx, rsi
       lea      r8d, [r13-0x04]
       mov      rsi, rdx
       mov      r14d, r8d
 
G_M000_IG158:                ;; offset=0x1465
       mov      edx, dword ptr [rsi]
       lea      rcx, [rbp-0xA8]
       call     [System.HashCode:Add(int):this]
       add      rsi, 4
       add      r14d, -4
 
G_M000_IG159:                ;; offset=0x147C
       mov      edx, dword ptr [rsi]
       lea      rcx, [rbp-0xA8]
       call     [System.HashCode:Add(int):this]
       add      rsi, 4
       add      r14d, -4
       mov      rdx, rsi
       mov      r8d, r14d
       mov      r11, gword ptr [rbp-0x218]
       jmp      G_M000_IG51
 
G_M000_IG160:                ;; offset=0x14A5
       mov      r8d, -2
       jmp      G_M000_IG84
 
G_M000_IG161:                ;; offset=0x14B0
       mov      eax, r13d
       xor      edx, edx
       div      edx:eax, r8d
       mov      r8d, edx
       jmp      G_M000_IG86
 
G_M000_IG162:                ;; offset=0x14C0
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG90
       jmp      SHORT G_M000_IG164
 
G_M000_IG163:                ;; offset=0x14D6
       mov      r11, gword ptr [rbp-0x218]
       jmp      G_M000_IG190
 
G_M000_IG164:                ;; offset=0x14E2
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG90
 
G_M000_IG165:                ;; offset=0x14F7
       test     edx, edx
       jne      G_M000_IG217
       xor      rax, rax
       xor      edx, edx
       jmp      G_M000_IG122
 
G_M000_IG166:                ;; offset=0x1508
       or       eax, edx
       jne      G_M000_IG217
       xor      rax, rax
       xor      edx, edx
       jmp      G_M000_IG120
 
G_M000_IG167:                ;; offset=0x1519
       mov      r11, gword ptr [rbp-0x218]
       jmp      G_M000_IG88
 
G_M000_IG168:                ;; offset=0x1525
       cmp      dword ptr [r14+0x20], 0
       setne    r14b
       movzx    r14, r14b
       test     r14d, r14d
       je       G_M000_IG98
 
G_M000_IG169:                ;; offset=0x153B
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG98
 
G_M000_IG170:                ;; offset=0x1550
       xor      r14d, r14d
       mov      dword ptr [rbp-0xF4], r14d
       mov      r14, rax
       and      r14, 2
       mov      qword ptr [rbp-0x100], r14
       test     r14, r14
       je       SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x156D
       mov      r14, bword ptr [rbp-0x290]
       movzx    r14, word  ptr [r14]
       mov      dword ptr [rbp-0x2A4], r14d
       mov      r14, bword ptr [rbp-0x298]
       movzx    r14, word  ptr [r14]
       movzx    r9, dword ptr [rbp-0x2A4]
       sub      r9d, r14d
       mov      r14d, r9d
       mov      dword ptr [rbp-0xF4], r14d
 
G_M000_IG172:                ;; offset=0x159F
       test     al, 1
       je       SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x15A3
       mov      rax, bword ptr [rbp-0x290]
       mov      r14, qword ptr [rbp-0x100]
       movzx    rax, byte  ptr [rax+r14]
       mov      dword ptr [rbp-0x2A4], eax
       mov      rax, bword ptr [rbp-0x298]
       movzx    rax, byte  ptr [rax+r14]
       movzx    r14, dword ptr [rbp-0x2A4]
       sub      r14d, eax
       or       r14d, dword ptr [rbp-0xF4]
       mov      dword ptr [rbp-0xF4], r14d
 
G_M000_IG174:                ;; offset=0x15E1
       cmp      dword ptr [rbp-0xF4], 0
       sete     al
       movzx    rax, al
       jmp      G_M000_IG103
 
G_M000_IG175:                ;; offset=0x15F3
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG176:                ;; offset=0x1606
       xor      r14d, r14d
       mov      qword ptr [rbp-0xE0], r14
       add      rax, -32
       mov      qword ptr [rbp-0xE8], rax
       test     rax, rax
       je       SHORT G_M000_IG178
       mov      rax, bword ptr [rbp-0x228]
       vmovups  ymm0, ymmword ptr [rax]
       mov      r14, bword ptr [rbp-0x230]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r14]
       vpmovmskb r14d, ymm0
       cmp      r14d, -1
       je       SHORT G_M000_IG179
 
G_M000_IG177:                ;; offset=0x1641
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG178:                ;; offset=0x1654
       mov      rax, bword ptr [rbp-0x228]
       jmp      SHORT G_M000_IG182
 
G_M000_IG179:                ;; offset=0x165D
       mov      r14, qword ptr [rbp-0xE0]
       add      r14, 32
       cmp      qword ptr [rbp-0xE8], r14
       jbe      SHORT G_M000_IG182
 
G_M000_IG180:                ;; offset=0x1671
       vmovups  ymm0, ymmword ptr [rax+r14]
       mov      rax, bword ptr [rbp-0x230]
       mov      qword ptr [rbp-0xE0], r14
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+r14]
       vpmovmskb r14d, ymm0
       cmp      r14d, -1
       jne      SHORT G_M000_IG181
       mov      rax, bword ptr [rbp-0x228]
       jmp      SHORT G_M000_IG179
 
G_M000_IG181:                ;; offset=0x169E
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG182:                ;; offset=0x16B1
       mov      r14, qword ptr [rbp-0xE8]
       vmovups  ymm0, ymmword ptr [rax+r14]
       mov      rax, bword ptr [rbp-0x230]
       vpcmpeqb ymm0, ymm0, ymmword ptr [rax+r14]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       je       G_M000_IG104
 
G_M000_IG183:                ;; offset=0x16D8
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG184:                ;; offset=0x16EB
       xor      r14d, r14d
       mov      qword ptr [rbp-0xD0], r14
       add      rax, -16
       mov      qword ptr [rbp-0xD8], rax
       test     rax, rax
       je       G_M000_IG188
       mov      r14, bword ptr [rbp-0x228]
       vmovups  xmm0, xmmword ptr [r14]
       mov      rax, bword ptr [rbp-0x230]
       vpcmpeqb xmm0, xmm0, xmmword ptr [rax]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       je       SHORT G_M000_IG186
 
G_M000_IG185:                ;; offset=0x172B
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG186:                ;; offset=0x173E
       mov      rax, qword ptr [rbp-0xD0]
       add      rax, 16
       cmp      qword ptr [rbp-0xD8], rax
       ja       SHORT G_M000_IG187
       jmp      SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x1754
       vmovups  xmm0, xmmword ptr [r14+rax]
       mov      r14, bword ptr [rbp-0x230]
       mov      qword ptr [rbp-0xD0], rax
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14+rax]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       mov      r14, bword ptr [rbp-0x228]
       je       SHORT G_M000_IG186
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG188:                ;; offset=0x1793
       mov      r14, bword ptr [rbp-0x228]
       mov      rax, qword ptr [rbp-0xD8]
       vmovups  xmm0, xmmword ptr [r14+rax]
       mov      r14, bword ptr [rbp-0x230]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r14+rax]
       vpmovmskb eax, xmm0
       cmp      eax, 0xFFFF
       je       G_M000_IG104
 
G_M000_IG189:                ;; offset=0x17C3
       mov      r11, gword ptr [rbp-0x218]
       mov      r14, bword ptr [rbp-0x260]
       jmp      G_M000_IG88
 
G_M000_IG190:                ;; offset=0x17D6
       mov      r12d, -1
       mov      bword ptr [rbp-0x260], r14
       jmp      G_M000_IG106
 
G_M000_IG191:                ;; offset=0x17E8
       cmp      r15d, 8
       jle      SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x17EE
       mov      r10, gword ptr [rbp-0x1E0]
       mov      edx, dword ptr [r10+0x4C]
       mov      r11, gword ptr [rbp-0x218]
       mov      r12d, dword ptr [r11+0x08]
       cmp      edx, r12d
       jge      SHORT G_M000_IG194
 
G_M000_IG193:                ;; offset=0x1809
       mov      esi, 1
       mov      eax, r13d
       mov      dword ptr [rbp-0x150], esi
       mov      dword ptr [rbp-0x154], eax
 
G_M000_IG194:                ;; offset=0x181D
       xor      edx, edx
       mov      eax, edx
       mov      rsi, r10
       jmp      G_M000_IG114
 
G_M000_IG195:                ;; offset=0x1829
       mov      r10, gword ptr [rbp-0x1E0]
       jmp      SHORT G_M000_IG194
 
G_M000_IG196:                ;; offset=0x1832
       mov      rdx, r11
       mov      rcx, rsi
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG197:                ;; offset=0x183E
       mov      rcx, r10
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG200
 
G_M000_IG198:                ;; offset=0x1852
       mov      r10, gword ptr [rbp-0x1E0]
 
G_M000_IG199:                ;; offset=0x1859
       xor      eax, eax
       mov      rsi, r10
       jmp      G_M000_IG114
 
G_M000_IG200:                ;; offset=0x1863
       mov      rdx, qword ptr [rsi]
       mov      rcx, 0x7FFA029E8768
       cmp      rdx, rcx
       je       SHORT G_M000_IG202
 
G_M000_IG201:                ;; offset=0x1875
       mov      r10, gword ptr [rbp-0x1E0]
       jmp      SHORT G_M000_IG199
 
G_M000_IG202:                ;; offset=0x187E
       mov      rcx, 0x7FFA029E8768
       cmp      rdx, rcx
       je       SHORT G_M000_IG204
 
G_M000_IG203:                ;; offset=0x188D
       mov      rdx, rsi
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_UNBOX
 
G_M000_IG204:                ;; offset=0x189F
       vmovdqu  xmm0, xmmword ptr [rsi+0x08]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
 
G_M000_IG205:                ;; offset=0x18AC
       lea      rcx, [rbp-0x110]
       xor      edx, edx
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x18C0
       mov      r10, gword ptr [rbp-0x1E0]
       jmp      SHORT G_M000_IG199
 
G_M000_IG207:                ;; offset=0x18C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG208:                ;; offset=0x18D9
       lea      rcx, [rbp-0x180]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       jmp      G_M000_IG111
 
G_M000_IG209:                ;; offset=0x18EE
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
       lea      rcx, [rbp-0x128]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rcx, 0x7FFA029E8768
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rbp-0x128]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r9d, dword ptr [rbp-0x120]
       mov      dword ptr [r13+0x10], r9d
       mov      r9d, dword ptr [rbp-0x12C]
       mov      dword ptr [rsp+0x20], r9d
       xor      r9d, r9d
       mov      dword ptr [rsp+0x28], r9d
       mov      dword ptr [rsp+0x30], 1
       mov      r9, r13
       mov      rcx, rsi
       mov      edx, r12d
       mov      r8, gword ptr [rbp-0x238]
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG112
 
G_M000_IG210:                ;; offset=0x196B
       inc      dword ptr [rsi+0x48]
       jmp      G_M000_IG113
 
G_M000_IG211:                ;; offset=0x1973
       mov      r12, gword ptr [rbp-0x1C0]
       mov      r13, gword ptr [r12+0x18]
       mov      rax, gword ptr [rdi+0x98]
       mov      gword ptr [rbp-0x240], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x199C
       mov      rcx, gword ptr [rbp-0x240]
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG213:                ;; offset=0x19AC
       mov      r14, bword ptr [rbp-0x260]
       mov      bword ptr [rbp-0x190], r14
       mov      dword ptr [rbp-0x188], r15d
       lea      rdx, [rbp-0x190]
       mov      rcx, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x1F0], rax
       mov      r14, gword ptr [rbp-0x1D8]
       mov      gword ptr [rsp+0x20], r14
       mov      r15, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x180], r15
       mov      r13d, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x178], r13d
       lea      rcx, [rbp-0x180]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, rsi
       mov      r8, gword ptr [rbp-0x1F0]
       mov      r9d, dword ptr [rbp-0x154]
       mov      edx, -1
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       jmp      G_M000_IG115
 
G_M000_IG214:                ;; offset=0x1A31
       mov      r10, gword ptr [rbp-0x1E0]
       mov      r14, gword ptr [rbp-0x1D8]
       mov      r15, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x180], r15
       mov      r11d, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x178], r11d
       mov      gword ptr [rsp+0x20], rdi
       mov      r12, gword ptr [rbp-0x1C0]
       mov      r8, gword ptr [r12+0x18]
       mov      gword ptr [rsp+0x28], r8
       lea      r9, [rbp-0x180]
       mov      r8, r14
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      rsi, gword ptr [rbp-0x1E0]
       jmp      G_M000_IG115
 
G_M000_IG215:                ;; offset=0x1A90
       mov      rax, gword ptr [rbp-0x2A0]
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       mov      rdx, gword ptr [rbp-0x248]
       je       G_M000_IG37
       mov      rsi, gword ptr [rbp-0x1E0]
 
G_M000_IG216:                ;; offset=0x1AB7
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG37
 
G_M000_IG217:                ;; offset=0x1AC9
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG218:                ;; offset=0x1AD0
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG219:                ;; offset=0x1ADC
       mov      esi, dword ptr [rbp-0x3C]
       add      esi, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], esi
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG131
 
G_M000_IG220:                ;; offset=0x1AF6
       mov      ebx, dword ptr [rbp-0x40]
       add      ebx, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x18], ebx
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG131
 
G_M000_IG221:                ;; offset=0x1B0C
       mov      rcx, r9
       mov      rdx, 0x24A4F8D9B18
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG222:                ;; offset=0x1B28
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG223:                ;; offset=0x1B2E
       call     G_M000_IG281
       nop      
 
G_M000_IG224:                ;; offset=0x1B34
       mov      ebx, dword ptr [rbp-0x68]
       jmp      SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x1B39
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], esi
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG226:                ;; offset=0x1B54
       movzx    rax, bl
 
G_M000_IG227:                ;; offset=0x1B57
       vzeroupper 
       add      rsp, 696
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG228:                ;; offset=0x1B6E
       mov      rcx, r9
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9, bword ptr [rbp+0x28]
       jmp      G_M000_IG05
 
G_M000_IG229:                ;; offset=0x1B80
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG230:                ;; offset=0x1B87
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG231:                ;; offset=0x1B98
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG232:                ;; offset=0x1BA9
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG11
 
G_M000_IG233:                ;; offset=0x1BBA
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x24A4F8BAC68
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG234:                ;; offset=0x1BE8
       mov      rcx, r9
       mov      rdx, 0x24A4F8DE398
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG235:                ;; offset=0x1C04
       mov      rcx, rdx
       mov      rdx, 0x24A4F8D91C0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG236:                ;; offset=0x1C20
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG237:                ;; offset=0x1C27
       mov      rcx, rax
       mov      r11, 0x7FFA02542798
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG13
 
G_M000_IG238:                ;; offset=0x1C3F
       mov      rcx, r8
       mov      rdx, 0x24A4F8D9A90
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG239:                ;; offset=0x1C5B
       cmp      edx, 64
       je       G_M000_IG14
       cmp      edx, 67
       je       G_M000_IG14
       cmp      edx, 70
       jne      SHORT G_M000_IG238
       jmp      G_M000_IG14
 
G_M000_IG240:                ;; offset=0x1C77
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG241:                ;; offset=0x1C88
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG242:                ;; offset=0x1C99
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r10, rax
       jmp      G_M000_IG18
 
G_M000_IG243:                ;; offset=0x1CAA
       cmp      qword ptr [rax+0x08], 0
       jle      SHORT G_M000_IG246
 
G_M000_IG244:                ;; offset=0x1CB1
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x7FFA02C520C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG245
       mov      r10, bword ptr [rbp-0x208]
       mov      edx, dword ptr [r10+0x08]
       dec      edx
       lea      r8, [rbp-0x50]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG247
 
G_M000_IG245:                ;; offset=0x1CE4
       mov      rax, bword ptr [rbp-0x208]
 
G_M000_IG246:                ;; offset=0x1CEB
       mov      rcx, gword ptr [rax]
       lea      rdx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG247:                ;; offset=0x1CF8
       test     eax, eax
       je       G_M000_IG19
       jmp      G_M000_IG27
 
G_M000_IG248:                ;; offset=0x1D05
       cmp      dword ptr [r11+0x08], 1
       jle      SHORT G_M000_IG249
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, r15
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG249:                ;; offset=0x1D39
       cmp      dword ptr [r11+0x08], 0
       jbe      SHORT G_M000_IG253
       mov      r11, qword ptr [r11+0x10]
       mov      qword ptr [rbp-0x70], r11
       neg      r11
       test     eax, eax
       cmovg    r11, qword ptr [rbp-0x70]
       test     r11, r11
       jle      SHORT G_M000_IG250
       test     eax, eax
       jg       SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x1D5B
       test     r11, r11
       jge      SHORT G_M000_IG252
       test     eax, eax
       jge      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x1D64
       mov      rax, r11
       jmp      G_M000_IG30
 
G_M000_IG252:                ;; offset=0x1D6C
       mov      rcx, 0x7FFA02C863A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG253:                ;; offset=0x1D99
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG254:                ;; offset=0x1D9F
       sub      rsp, 56
 
G_M000_IG255:                ;; offset=0x1DA3
       cmp      dword ptr [rbp-0x5C], 0
       je       SHORT G_M000_IG257
 
G_M000_IG256:                ;; offset=0x1DA9
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8, bword ptr [rbp-0x1E8]
       mov      eax, dword ptr [r8+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG261
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rsi, qword ptr [rbp-0x50]
       mov      rdx, 0x22A28C01FE0
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x08], rsi
 
G_M000_IG257:                ;; offset=0x1DE7
       cmp      dword ptr [rbp-0x64], 0
       je       SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1DED
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      r9, bword ptr [rbp+0x28]
       mov      edx, dword ptr [r9+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG259:                ;; offset=0x1E03
       nop      
 
G_M000_IG260:                ;; offset=0x1E04
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG261:                ;; offset=0x1E0C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG262:                ;; offset=0x1E12
       sub      rsp, 56
 
G_M000_IG263:                ;; offset=0x1E16
       cmp      gword ptr [rbp-0x1F0], 0
       jne      SHORT G_M000_IG265
 
G_M000_IG264:                ;; offset=0x1E20
       cmp      dword ptr [rbp-0x148], 0
       je       G_M000_IG279
 
G_M000_IG265:                ;; offset=0x1E2D
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rdx, bword ptr [rbp-0x1D0]
       mov      r8d, dword ptr [rdx+0x1C]
       cmp      r8d, 9
       je       SHORT G_M000_IG267
 
G_M000_IG266:                ;; offset=0x1E46
       cmp      r8d, 10
       je       SHORT G_M000_IG267
       mov      rcx, rdx
       mov      rdx, 0x24A4F8D9AC0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG267:                ;; offset=0x1E68
       mov      edx, dword ptr [rdx+0x14]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG277
       shl      rdx, 4
       lea      rdi, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x1F0]
       cmp      gword ptr [rbp-0x1F0], 0
       jne      G_M000_IG278
 
G_M000_IG268:                ;; offset=0x1E92
       mov      ebx, dword ptr [rbp-0x148]
       add      rbx, 128
       mov      rax, gword ptr [rbp-0x1B8]
       cmp      rbx, qword ptr [rax+0x28]
       jle      SHORT G_M000_IG270
 
G_M000_IG269:                ;; offset=0x1EAC
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, 0x24A4F8DE3E0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG270:                ;; offset=0x1EDA
       mov      rax, gword ptr [rbp-0x1B8]
       mov      rsi, gword ptr [rax+0x08]
       mov      rcx, 0x7FFA02A61F30
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      dword ptr [r14+0x1C], -1
       cmp      dword ptr [rbp-0x148], 0
       jne      SHORT G_M000_IG272
 
G_M000_IG271:                ;; offset=0x1F08
       xor      ecx, ecx
       mov      rdx, 0x24A4F8B6810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG272:                ;; offset=0x1F1B
       cmp      dword ptr [rbp-0x148], 8
       jg       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x1F24
       mov      edx, dword ptr [rbp-0x148]
       mov      byte  ptr [r14+0x24], dl
       jmp      SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x1F30
       mov      edx, dword ptr [rbp-0x148]
       mov      rcx, 0x7FFA027200F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       lea      rcx, bword ptr [r14+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG275:                ;; offset=0x1F51
       mov      ecx, dword ptr [rbp-0x148]
       mov      dword ptr [r14+0x18], ecx
       lea      rcx, bword ptr [r14+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdx, [rbp-0x140]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rcx, bword ptr [rbp-0x140]
       mov      r8d, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x148], r8d
       jg       SHORT G_M000_IG276
       mov      r8d, dword ptr [rbp-0x148]
       mov      rdx, bword ptr [rbp-0x258]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rcx, r14
       mov      edx, dword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x1B8]
       sub      qword ptr [rax+0x28], rbx
       mov      rdx, r14
       jmp      SHORT G_M000_IG278
 
G_M000_IG276:                ;; offset=0x1FC1
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG277:                ;; offset=0x1FC8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG278:                ;; offset=0x1FCE
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG279:                ;; offset=0x1FDC
       call     G_M000_IG254
       nop      
 
G_M000_IG280:                ;; offset=0x1FE2
       vzeroupper 
       add      rsp, 56
       ret      
 
G_M000_IG281:                ;; offset=0x1FEA
       sub      rsp, 56
 
G_M000_IG282:                ;; offset=0x1FEE
       cmp      dword ptr [rbp-0x60], 0
       je       SHORT G_M000_IG285
 
G_M000_IG283:                ;; offset=0x1FF4
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, qword ptr [rcx+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x200B
       dec      rax
       mov      qword ptr [rcx+0x160], rax
 
G_M000_IG285:                ;; offset=0x2015
       call     G_M000_IG262
       nop      
 
G_M000_IG286:                ;; offset=0x201B
       vzeroupper 
       add      rsp, 56
       ret      
 
RWD00  	dd	000013DAh ; case G_M000_IG157
       	dd	000013D2h ; case G_M000_IG156
       	dd	000013CAh ; case G_M000_IG155

; Total bytes of code 8227

