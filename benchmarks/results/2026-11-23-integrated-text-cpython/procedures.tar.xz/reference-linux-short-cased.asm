; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 608
       lea      rbp, [rsp+0x260]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x250], xmm8
       vmovdqa  xmmword ptr [rbp-0x240], xmm8
       mov      rax, -480
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x110], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x110]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00A9
       mov      rdi, 0x7F4C2355EAF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B8
       mov      rdi, 0x7F4C2355EAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00CC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1A4], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rdi, 0x7F4C2355EB00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1A4], eax
 
G_M000_IG07:                ;; offset=0x011D
       cmp      dword ptr [rbp-0x1A4], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0138
       mov      rdi, 0x7F4C2355EB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0149
       mov      rdi, 0x7F4C2355EB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B0], rax
 
G_M000_IG10:                ;; offset=0x016A
       mov      rdi, 0x7F4C2355EB0C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x114], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x018F
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
 
G_M000_IG12:                ;; offset=0x0197
       movzx    rax, byte  ptr [rbp-0x114]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, 0x7F4C2350BAF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0234
       mov      rdi, 0x7F4C2355EB10
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0243
       mov      rdi, 0x7F4C2355EB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C0], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0277
       mov      rdi, 0x7F4C2355EB18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0288
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, gword ptr [rbp-0x1B8]
       mov      rsi, 0x7F4C2355EB20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1DC], eax
       mov      rdi, gword ptr [rbp-0x1D8]
       mov      esi, dword ptr [rbp-0x1DC]
       mov      r11, 0x7F4C21251D80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x037E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x045D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rsi, gword ptr [rbp-0x1E8]
       mov      rdi, 0x7F4C22DAB020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0483
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x048F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F4C232198B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateInlineWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0520
       mov      rdi, 0x7F4C2355EC28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x052F
       mov      rdi, 0x7F4C2355EC2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0543
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F8], rcx
       mov      rdi, bword ptr [rbp-0x1F8]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F4C2355EC30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x061F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0621
       add      rsp, 608
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x062A
       mov      rdi, 0x7F4C2355EC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x200], rax
       mov      rsi, gword ptr [rbp-0x200]
       mov      rdi, 0x7F4C22DAB020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0696
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x06A2
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, qword ptr [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06BD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06EA
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0701
       lea      rdi, [rbp-0x1BC]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0714
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0736
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0746
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rsi, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07BD
       mov      rdi, 0x7F4C2355EC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07D6
       cmp      gword ptr [rbp-0x108], 0
       je       SHORT G_M000_IG37
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x168], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
       jmp      G_M000_IG40
 
G_M000_IG37:                ;; offset=0x0846
       mov      rdi, 0x7F4C2355EC3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0855
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG39:                ;; offset=0x0865
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x158]
       mov      rdx, qword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
 
G_M000_IG40:                ;; offset=0x08C4
       cmp      dword ptr [rbp-0x15C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x08E9
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x093B
       mov      rdi, 0x7F4C2355EC40
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x094A
       mov      rdi, 0x7F4C2355EC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0978
       mov      rdi, 0x7F4C2355EC48
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0987
       mov      rdi, 0x7F4C2355EC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x09C9
       mov      rdi, 0x7F4C2355EC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
 
G_M000_IG47:                ;; offset=0x09FD
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0A04
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0A0B
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0A11
       mov      rdi, 0x7F4C2355EC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x10C]
       mov      dword ptr [rbp-0x1C0], eax
 
G_M000_IG51:                ;; offset=0x0A2C
       movzx    rax, byte  ptr [rbp-0x1C0]
 
G_M000_IG52:                ;; offset=0x0A33
       add      rsp, 608
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0A3C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0A42
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0A46
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F4C2355EC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x240], rcx
       mov      rdi, bword ptr [rbp-0x240]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0AB0
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F4C2355EC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      esi, dword ptr [rbp-0x244]
       mov      rdi, bword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0B00
       mov      rdi, 0x7F4C2355EC6C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0B10
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0B15
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0B1B
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0B1F
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0B3C
       mov      rdi, 0x7F4C2355EC58
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0B50
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B56
       mov      rdi, 0x7F4C2355EC5C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0B65
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x170]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x178], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F4C2355EC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x180], rax
 
G_M000_IG66:                ;; offset=0x0BE4
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0BF8
       nop      
 
G_M000_IG68:                ;; offset=0x0BF9
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0BFF
       mov      rdi, 0x7F4C2355EC70
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0C0F
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0C14
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0C18
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F4C2355EC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0C3C
       nop      
 
G_M000_IG74:                ;; offset=0x0C3D
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0C43
       mov      rdi, 0x7F4C2355EC74
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C53
       add      rsp, 24
       ret      
 
; Total bytes of code 3160

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  xmmword ptr [rbp-0x48], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0032
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       mov      dword ptr [rbp-0x34], eax
       cmp      dword ptr [rbp-0x34], 0
       jge      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0072
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0078
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      ecx, dword ptr [rbp-0x34]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x48], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x48]
       mov      rax, bword ptr [rbp-0x40]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x34]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x00E8
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00EE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 244

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       xor      eax, eax
       mov      dword ptr [rbp-0x60], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x006B
       mov      rdi, 0x7F4C235760E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x007F
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00B8
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00C5
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F4C235760E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0122
       mov      rdi, 0x7F4C235760E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0131
       mov      rdi, 0x7F4C235760EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       inc      eax
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG09:                ;; offset=0x0148
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x015F
       lea      rdi, [rbp-0xB4]
       mov      esi, 59
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x0172
       mov      eax, dword ptr [rbp-0x60]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F4C235760F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x0192
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG13
       mov      rdi, 0x7F4C235760F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG13:                ;; offset=0x01AC
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG14:                ;; offset=0x01B9
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      edi, dword ptr [rbp-0x5C]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0227
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       cmp      eax, dword ptr [rbp-0x5C]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F4C235760F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02D2
       mov      rdi, 0x7F4C235760FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02E3
       mov      rdi, 0x7F4C23576100
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x02F2
       mov      rdi, 0x7F4C23576104
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0320
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0337
       lea      rdi, [rbp-0xB4]
       mov      esi, 206
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x034A
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F4C23576108
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0363
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0368
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0371
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0377
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0380
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 902

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  xmmword ptr [rbp-0x48], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      bword ptr [rbp-0x18], rsi
       mov      qword ptr [rbp-0x10], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      gword ptr [rbp-0x30], r8
       mov      qword ptr [rbp-0x28], r9
 
G_M000_IG02:                ;; offset=0x0032
       mov      rdi, gword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, bword ptr [rbp-0x18]
       mov      rcx, qword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x28]
       mov      rax, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rax+0x4C]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       mov      dword ptr [rbp-0x34], eax
       cmp      dword ptr [rbp-0x34], 0
       jge      SHORT G_M000_IG04
       mov      rdi, 0x7F4C239D9CC0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0081
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0087
       mov      rdi, 0x7F4C239D9CC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x28]
       mov      ecx, dword ptr [rbp-0x34]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x48], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x30]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdx, gword ptr [rbp-0x48]
       mov      rax, bword ptr [rbp-0x40]
       mov      ecx, dword ptr [rax+0x18]
       mov      esi, dword ptr [rbp-0x34]
       mov      rdi, gword ptr [rbp-0x08]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x0106
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x010C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 274

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqa  xmmword ptr [rbp-0x70], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      dword ptr [rbp-0x34], esi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      dword ptr [rbp-0xB4], 0x3E8
       cmp      dword ptr [rbp-0x34], 4
       jg       G_M000_IG12
       cmp      dword ptr [rbp-0x40], 8
       jg       SHORT G_M000_IG03
       xor      eax, eax
       mov      dword ptr [rbp-0x60], eax
       jmp      G_M000_IG09
 
G_M000_IG03:                ;; offset=0x006B
       mov      rdi, 0x7F4C235760E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG12
 
G_M000_IG04:                ;; offset=0x007F
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00B8
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG06:                ;; offset=0x00C5
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x98]
       mov      rdi, bword ptr [rbp-0xB0]
       mov      rsi, qword ptr [rbp-0xA8]
       call     [System.MemoryExtensions:SequenceEqual[byte](System.ReadOnlySpan`1[byte],System.ReadOnlySpan`1[byte]):bool]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rdi, 0x7F4C235760E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0122
       mov      rdi, 0x7F4C235760E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG08:                ;; offset=0x0131
       mov      rdi, 0x7F4C235760EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       inc      eax
       mov      dword ptr [rbp-0x60], eax
 
G_M000_IG09:                ;; offset=0x0148
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x015F
       lea      rdi, [rbp-0xB4]
       mov      esi, 59
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG11:                ;; offset=0x0172
       mov      eax, dword ptr [rbp-0x60]
       cmp      eax, dword ptr [rbp-0x34]
       jl       G_M000_IG04
       mov      rdi, 0x7F4C235760F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG12:                ;; offset=0x0192
       cmp      dword ptr [rbp-0x34], 0
       jne      SHORT G_M000_IG13
       mov      rdi, 0x7F4C235760F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG13:                ;; offset=0x01AC
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG14:                ;; offset=0x01B9
       xor      eax, eax
       mov      gword ptr [rbp-0x70], rax
       mov      rdi, bword ptr [rbp-0x90]
       mov      rsi, qword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, gword ptr [rbp-0x58]
       mov      r8, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.Text.PyString:HashUtf8(System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.Threading.CancellationToken):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyValueComparer:NormalizeHash(int):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp-0x30]
       mov      esi, dword ptr [rax+0x08]
       mov      edi, dword ptr [rbp-0x5C]
       call     [Lokad.Lython.Runtime.PyDict:NativeBucket(uint,int):int]
       mov      rcx, gword ptr [rbp-0x30]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG26
       mov      edx, eax
       imul     rdx, rdx, 40
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      eax, dword ptr [rcx+0x20]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0227
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x18]
       cmp      eax, dword ptr [rbp-0x5C]
       jne      G_M000_IG18
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rsi, gword ptr [rax]
       mov      rdi, 0x7F4C22EDFBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG17
       mov      rsi, bword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r8, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.PyDict:EqualNativeText(Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG16
       mov      rdi, 0x7F4C235760F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG24
 
G_M000_IG16:                ;; offset=0x02D2
       mov      rdi, 0x7F4C235760FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02E3
       mov      rdi, 0x7F4C23576100
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG18:                ;; offset=0x02F2
       mov      rdi, 0x7F4C23576104
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG26
       mov      edx, ecx
       imul     rdx, rdx, 40
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      eax, dword ptr [rax+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG19:                ;; offset=0x0320
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0337
       lea      rdi, [rbp-0xB4]
       mov      esi, 206
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG21:                ;; offset=0x034A
       cmp      dword ptr [rbp-0x74], 0
       jge      G_M000_IG15
       mov      rdi, 0x7F4C23576108
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x0363
       mov      eax, -1
 
G_M000_IG23:                ;; offset=0x0368
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG24:                ;; offset=0x0371
       mov      eax, dword ptr [rbp-0xB8]
 
G_M000_IG25:                ;; offset=0x0377
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x0380
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 902

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 608
       lea      rbp, [rsp+0x260]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x250], xmm8
       vmovdqa  xmmword ptr [rbp-0x240], xmm8
       mov      rax, -480
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0x1BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x110], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x110]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00A9
       mov      rdi, 0x7F4C2355EAF8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B8
       mov      rdi, 0x7F4C2355EAFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG05:                ;; offset=0x00CC
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG11
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG06
       mov      dword ptr [rbp-0x1A4], 1
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F6
       mov      rdi, 0x7F4C2355EB00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1A4], eax
 
G_M000_IG07:                ;; offset=0x011D
       cmp      dword ptr [rbp-0x1A4], 0
       je       SHORT G_M000_IG08
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG09
       xor      rax, rax
       mov      gword ptr [rbp-0x1B0], rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0138
       mov      rdi, 0x7F4C2355EB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0149
       mov      rdi, 0x7F4C2355EB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x1B0], rax
 
G_M000_IG10:                ;; offset=0x016A
       mov      rdi, 0x7F4C2355EB0C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x1B0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x114], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x018F
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
 
G_M000_IG12:                ;; offset=0x0197
       movzx    rax, byte  ptr [rbp-0x114]
       mov      dword ptr [rbp-0x4C], eax
       cmp      dword ptr [rbp-0x4C], 0
       je       G_M000_IG14
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x120], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      esi, dword ptr [rbp-0x1C4]
       mov      rdi, bword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, 0x7F4C2350BAF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG15
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x128], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x128]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0234
       mov      rdi, 0x7F4C2355EB10
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x0243
       mov      rdi, 0x7F4C2355EB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, bword ptr [rbp-0x48]
       mov      r8d, dword ptr [rbp-0x4C]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      dword ptr [rbp-0x1C0], eax
       jmp      G_M000_IG51
 
G_M000_IG15:                ;; offset=0x0277
       mov      rdi, 0x7F4C2355EB18
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0288
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x18]
       mov      dword ptr [rbp-0x5C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x60], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x130], rax
       mov      rax, gword ptr [rbp-0x130]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, gword ptr [rbp-0x1B8]
       mov      rsi, 0x7F4C2355EB20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x1DC], eax
       mov      rdi, gword ptr [rbp-0x1D8]
       mov      esi, dword ptr [rbp-0x1DC]
       mov      r11, 0x7F4C21252530
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG17:                ;; offset=0x037E
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x5C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x88], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x78]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
 
G_M000_IG18:                ;; offset=0x045D
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rsi, gword ptr [rbp-0x1E8]
       mov      rdi, 0x7F4C22DAB020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG19:                ;; offset=0x0483
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG20:                ;; offset=0x048F
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x148], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rdx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG53
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      rdi, 0x7F4C232198B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:CanAccumulateInlineWords(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0520
       mov      rdi, 0x7F4C2355EC28
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x052F
       mov      rdi, 0x7F4C2355EC2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0543
       mov      eax, dword ptr [rbp-0x60]
       add      eax, 3
       mov      dword ptr [rbp-0xA4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xA4]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 47
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB4], eax
       xor      eax, eax
       mov      qword ptr [rbp-0xC0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG29
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x198]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x1F8], rcx
       mov      rdi, bword ptr [rbp-0x1F8]
       lea      rsi, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadHistogramTotal(byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG26
       mov      rdi, 0x7F4C2355EC30
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG24:                ;; offset=0x061F
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x0621
       add      rsp, 608
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x062A
       mov      rdi, 0x7F4C2355EC34
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG53
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x200], rax
       mov      rsi, gword ptr [rbp-0x200]
       mov      rdi, 0x7F4C22DAB020
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG27:                ;; offset=0x0696
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG28:                ;; offset=0x06A2
       mov      rdi, gword ptr [rbp-0x210]
       mov      rsi, qword ptr [rbp-0x208]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
 
G_M000_IG29:                ;; offset=0x06BD
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0xE4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xE8], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xEC], eax
 
G_M000_IG30:                ;; offset=0x06EA
       mov      eax, dword ptr [rbp-0x1BC]
       dec      eax
       mov      dword ptr [rbp-0x1BC], eax
       cmp      dword ptr [rbp-0x1BC], 0
       jg       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0701
       lea      rdi, [rbp-0x1BC]
       mov      esi, 496
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG32:                ;; offset=0x0714
       lea      rsi, [rbp-0x100]
       lea      rdx, [rbp-0x108]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG33:                ;; offset=0x0736
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG34:                ;; offset=0x0746
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0xE0], rax
       cmp      dword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG35
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rsi, gword ptr [rbp-0x218]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rsi, gword ptr [rbp-0x220]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0xE8], 1
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x07BD
       mov      rdi, 0x7F4C2355EC38
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rax+0x18], ecx
 
G_M000_IG36:                ;; offset=0x07D6
       cmp      gword ptr [rbp-0x108], 0
       je       SHORT G_M000_IG37
       mov      rax, gword ptr [rbp-0x108]
       mov      gword ptr [rbp-0x168], rax
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x98]
       mov      r8, qword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x168]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
       jmp      G_M000_IG40
 
G_M000_IG37:                ;; offset=0x0846
       mov      rdi, 0x7F4C2355EC3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0855
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
 
G_M000_IG39:                ;; offset=0x0865
       mov      rdi, gword ptr [rbp-0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, gword ptr [rbp-0x230]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x98]
       mov      r9, qword ptr [rbp-0x90]
       mov      rsi, bword ptr [rbp-0x158]
       mov      rdx, qword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x88]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x15C], eax
 
G_M000_IG40:                ;; offset=0x08C4
       cmp      dword ptr [rbp-0x15C], 0
       jne      SHORT G_M000_IG41
       mov      eax, dword ptr [rbp-0x5C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG48
 
G_M000_IG41:                ;; offset=0x08E9
       cmp      dword ptr [rbp-0xB4], 0
       je       G_M000_IG45
       mov      rax, qword ptr [rbp-0xC0]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xC0], rax
       mov      dword ptr [rbp-0xE4], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG43
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0xC0], rax
       jl       SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x093B
       mov      rdi, 0x7F4C2355EC40
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG43:                ;; offset=0x094A
       mov      rdi, 0x7F4C2355EC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xA4]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
       jmp      G_M000_IG49
 
G_M000_IG44:                ;; offset=0x0978
       mov      rdi, 0x7F4C2355EC48
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0987
       mov      rdi, 0x7F4C2355EC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x5C]
       mov      dword ptr [rax+0x18], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x238], rax
       mov      rsi, gword ptr [rbp-0x238]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x09C9
       mov      rdi, 0x7F4C2355EC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xEC], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x18], eax
       mov      dword ptr [rbp-0x10C], 1
 
G_M000_IG47:                ;; offset=0x09FD
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0A04
       call     G_M000_IG71
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0A0B
       call     G_M000_IG71
       nop      
 
G_M000_IG50:                ;; offset=0x0A11
       mov      rdi, 0x7F4C2355EC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x10C]
       mov      dword ptr [rbp-0x1C0], eax
 
G_M000_IG51:                ;; offset=0x0A2C
       movzx    rax, byte  ptr [rbp-0x1C0]
 
G_M000_IG52:                ;; offset=0x0A33
       add      rsp, 608
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0A3C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0A42
       sub      rsp, 24
 
G_M000_IG55:                ;; offset=0x0A46
       cmp      dword ptr [rbp-0xE4], 0
       je       SHORT G_M000_IG56
       mov      rdi, 0x7F4C2355EC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x190], rax
       mov      rdi, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x190]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG59
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x240], rcx
       mov      rdi, bword ptr [rbp-0x240]
       mov      rsi, qword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:SetInteger(long):this]
 
G_M000_IG56:                ;; offset=0x0AB0
       cmp      dword ptr [rbp-0xEC], 0
       je       SHORT G_M000_IG57
       mov      rdi, 0x7F4C2355EC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 32
       mov      bword ptr [rbp-0x188], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      esi, dword ptr [rbp-0x244]
       mov      rdi, bword ptr [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG57:                ;; offset=0x0B00
       mov      rdi, 0x7F4C2355EC6C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG58:                ;; offset=0x0B10
       add      rsp, 24
       ret      
 
G_M000_IG59:                ;; offset=0x0B15
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0B1B
       sub      rsp, 24
 
G_M000_IG61:                ;; offset=0x0B1F
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG65
       lea      rdi, [rbp-0xD8]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       jmp      SHORT G_M000_IG64
 
G_M000_IG62:                ;; offset=0x0B3C
       mov      rdi, 0x7F4C2355EC58
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG67
 
G_M000_IG63:                ;; offset=0x0B50
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0B56
       mov      rdi, 0x7F4C2355EC5C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG65:                ;; offset=0x0B65
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x170]
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, eax
       imul     rdx, rdx, 16
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x178], rcx
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0xE0], 0
       jne      SHORT G_M000_IG66
       mov      rdi, 0x7F4C2355EC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0xD8]
       mov      rdx, qword ptr [rbp-0xD0]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(System.ReadOnlySpan`1[byte]):Lokad.Lython.Runtime.Text.PyString:this]
       mov      gword ptr [rbp-0x180], rax
 
G_M000_IG66:                ;; offset=0x0BE4
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, gword ptr [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG67:                ;; offset=0x0BF8
       nop      
 
G_M000_IG68:                ;; offset=0x0BF9
       call     G_M000_IG54
       nop      
 
G_M000_IG69:                ;; offset=0x0BFF
       mov      rdi, 0x7F4C2355EC70
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG70:                ;; offset=0x0C0F
       add      rsp, 24
       ret      
 
G_M000_IG71:                ;; offset=0x0C14
       sub      rsp, 24
 
G_M000_IG72:                ;; offset=0x0C18
       cmp      dword ptr [rbp-0xE8], 0
       je       SHORT G_M000_IG73
       mov      rdi, 0x7F4C2355EC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
 
G_M000_IG73:                ;; offset=0x0C3C
       nop      
 
G_M000_IG74:                ;; offset=0x0C3D
       call     G_M000_IG60
       nop      
 
G_M000_IG75:                ;; offset=0x0C43
       mov      rdi, 0x7F4C2355EC74
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG76:                ;; offset=0x0C53
       add      rsp, 24
       ret      
 
; Total bytes of code 3160

; Assembly listing for method Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 562945
; 54 inlinees with PGO data; 113 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      dword ptr [rbp-0x9C], r9d
       mov      rbx, rdi
       mov      r14, rsi
       mov      r13d, edx
       mov      r12, r8
       mov      r15, gword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x0050
       mov      rdi, gword ptr [r15+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG110
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG109
 
G_M000_IG03:                ;; offset=0x0079
       mov      rcx, gword ptr [rbx+0x28]
       mov      gword ptr [rbp-0xB8], rcx
       mov      edi, dword ptr [rbx+0x4C]
       cmp      edi, 4
       jle      G_M000_IG42
 
G_M000_IG04:                ;; offset=0x0090
       test     edi, edi
       je       G_M000_IG154
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       xor      edx, edx
       mov      dword ptr [rbp-0x54], edx
       cmp      edx, r13d
       jge      G_M000_IG34
 
G_M000_IG05:                ;; offset=0x00AF
       mov      rdi, gword ptr [r15+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG126
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG125
 
G_M000_IG06:                ;; offset=0x00D8
       mov      edx, dword ptr [rbp-0x54]
       mov      r8d, r13d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG69
 
G_M000_IG07:                ;; offset=0x00EE
       mov      dword ptr [rbp-0x58], r8d
       mov      esi, edx
       mov      edi, r8d
       add      rsi, rdi
       mov      edi, r13d
       cmp      rsi, rdi
       ja       G_M000_IG124
       mov      dword ptr [rbp-0x54], edx
       mov      r9d, edx
       add      r9, r14
       mov      bword ptr [rbp-0xC0], r9
       mov      r10, r9
       mov      r11d, r8d
       cmp      r8d, 16
       jl       G_M000_IG21
 
G_M000_IG08:                ;; offset=0x0126
       cmp      dword ptr [rbp-0x34], 0
       jne      G_M000_IG127
       mov      r9, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], r9
       mov      rsi, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG09:                ;; offset=0x014C
       cmp      r11d, 16
       jl       G_M000_IG21
 
G_M000_IG10:                ;; offset=0x0156
       mov      edi, dword ptr [rbp-0x50]
       imul     esi, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], edi
       mov      edi, dword ptr [rbp-0x4C]
       lea      rsi, bword ptr [r10+0x04]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], edi
       mov      edi, dword ptr [rbp-0x48]
       lea      rsi, bword ptr [r10+0x08]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], edi
       mov      edi, dword ptr [rbp-0x44]
       lea      rsi, bword ptr [r10+0x0C]
       imul     esi, dword ptr [rsi], 0xFFFFFFFF85EBCA77
       add      edi, esi
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       mov      edi, dword ptr [rbp-0x34]
       add      edi, 4
       mov      dword ptr [rbp-0x34], edi
       add      r10, 16
       add      r11d, -16
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x01E1
       mov      edi, dword ptr [r10]
       mov      esi, dword ptr [rbp-0x34]
       lea      r9d, [rsi+0x01]
       mov      dword ptr [rbp-0x34], r9d
       mov      r9d, esi
       and      r9d, 3
       je       G_M000_IG19
 
G_M000_IG12:                ;; offset=0x01FC
       cmp      r9d, 1
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0202
       mov      dword ptr [rbp-0x3C], edi
       jmp      G_M000_IG20
 
G_M000_IG14:                ;; offset=0x020A
       cmp      r9d, 2
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0210
       mov      dword ptr [rbp-0x38], edi
       jmp      G_M000_IG20
 
G_M000_IG16:                ;; offset=0x0218
       cmp      esi, 3
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x021D
       mov      rsi, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], rsi
       mov      rsi, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG18:                ;; offset=0x0239
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x50]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], esi
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x4C]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], esi
       imul     esi, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      esi, dword ptr [rbp-0x48]
       rol      esi, 13
       imul     esi, esi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], esi
       imul     edi, edi, 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x44]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edi
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0292
       mov      dword ptr [rbp-0x40], edi
 
G_M000_IG20:                ;; offset=0x0295
       add      r10, 4
       add      r11d, -4
       mov      rdi, r10
       mov      esi, r11d
       mov      r10, rdi
       mov      r11d, esi
 
G_M000_IG21:                ;; offset=0x02A9
       cmp      r11d, 4
       jge      G_M000_IG11
 
G_M000_IG22:                ;; offset=0x02B3
       mov      rdi, r10
       mov      esi, r11d
       xor      r9d, r9d
       test     esi, esi
       je       G_M000_IG33
 
G_M000_IG23:                ;; offset=0x02C4
       movzx    r10, byte  ptr [rdi+r9]
       mov      r11d, dword ptr [rbp-0x34]
       lea      eax, [r11+0x01]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, r11d
       and      eax, 3
       je       G_M000_IG31
 
G_M000_IG24:                ;; offset=0x02E0
       cmp      eax, 1
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02E5
       mov      dword ptr [rbp-0x3C], r10d
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x02EE
       cmp      eax, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02F3
       mov      dword ptr [rbp-0x38], r10d
       jmp      G_M000_IG32
 
G_M000_IG28:                ;; offset=0x02FC
       cmp      r11d, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0302
       mov      rax, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], rax
       mov      rax, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG30:                ;; offset=0x031E
       imul     eax, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x50]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], eax
       imul     eax, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x4C]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], eax
       imul     eax, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      eax, dword ptr [rbp-0x48]
       rol      eax, 13
       imul     eax, eax, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], eax
       imul     r10d, r10d, 0xFFFFFFFF85EBCA77
       add      r10d, dword ptr [rbp-0x44]
       rol      r10d, 13
       imul     eax, r10d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x037B
       mov      dword ptr [rbp-0x40], r10d
 
G_M000_IG32:                ;; offset=0x037F
       inc      r9d
       cmp      r9d, esi
       jl       G_M000_IG23
 
G_M000_IG33:                ;; offset=0x038B
       mov      edx, dword ptr [rbp-0x54]
       add      edx, dword ptr [rbp-0x58]
       cmp      edx, r13d
       mov      dword ptr [rbp-0x54], edx
       jl       G_M000_IG05
 
G_M000_IG34:                ;; offset=0x039D
       mov      edx, dword ptr [rbp-0x34]
       mov      edi, edx
       and      edi, 3
       cmp      edx, 4
       jae      G_M000_IG70
 
G_M000_IG35:                ;; offset=0x03AE
       mov      esi, 0x22BE37CA
 
G_M000_IG36:                ;; offset=0x03B3
       lea      edx, [rsi+4*rdx]
       test     edi, edi
       je       SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x03BA
       imul     esi, dword ptr [rbp-0x40], 0xFFFFFFFFC2B2AE3D
       add      edx, esi
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      edi, 1
       jbe      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x03D1
       imul     esi, dword ptr [rbp-0x3C], 0xFFFFFFFFC2B2AE3D
       add      esi, edx
       rol      esi, 17
       imul     edx, esi, 0x27D4EB2F
       cmp      edi, 2
       jbe      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03E8
       imul     edi, dword ptr [rbp-0x38], 0xFFFFFFFFC2B2AE3D
       add      edi, edx
       rol      edi, 17
       imul     edx, edi, 0x27D4EB2F
 
G_M000_IG40:                ;; offset=0x03FA
       mov      edi, edx
       shr      edi, 15
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFF85EBCA77
       mov      edi, edx
       shr      edi, 13
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFFC2B2AE3D
       mov      edi, edx
       shr      edi, 16
       xor      edx, edi
       mov      edi, -2
       cmp      edx, -1
       cmovne   edi, edx
       mov      edx, edi
       shr      edx, 16
       xor      edx, edi
       imul     r8d, edx, 0xFFFFFFFF9E3779B9
       mov      r9d, r8d
       shr      r9d, 16
       xor      r8d, r9d
       mov      dword ptr [rbp-0x2C], r8d
       mov      edx, dword ptr [rcx+0x08]
       mov      r9d, edx
       mov      edi, r9d
       blsr     edx, edi
       jne      G_M000_IG133
       dec      edi
       and      edi, r8d
 
G_M000_IG41:                ;; offset=0x045B
       mov      dword ptr [rbp-0xAC], r9d
       cmp      edi, r9d
       jae      G_M000_IG169
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      edx, dword ptr [rcx+8*rdi+0x30]
       dec      edx
       mov      dword ptr [rbp-0x30], edx
       test     edx, edx
       jl       G_M000_IG154
       jmp      G_M000_IG104
 
G_M000_IG42:                ;; offset=0x0487
       cmp      r13d, 8
       jg       G_M000_IG04
       xor      esi, esi
       test     edi, edi
       jle      G_M000_IG154
       jmp      SHORT G_M000_IG50
 
G_M000_IG43:                ;; offset=0x049D
       lea      r8, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [rdx+0x18]
       cmp      r9d, 8
       ja       G_M000_IG124
 
G_M000_IG44:                ;; offset=0x04AF
       cmp      r13d, r9d
       jne      SHORT G_M000_IG49
 
G_M000_IG45:                ;; offset=0x04B4
       mov      rdx, r14
       mov      r10, r8
       mov      r9d, r9d
       cmp      r9, 8
       jae      G_M000_IG62
 
G_M000_IG46:                ;; offset=0x04C7
       cmp      r9, 4
       jb       G_M000_IG58
 
G_M000_IG47:                ;; offset=0x04D1
       add      r9, -4
       mov      edx, dword ptr [r14]
       sub      edx, dword ptr [r8]
       mov      r10d, dword ptr [r14+r9]
       sub      r10d, dword ptr [r8+r9]
       or       edx, r10d
       sete     dl
       movzx    rdx, dl
 
G_M000_IG48:                ;; offset=0x04EC
       test     edx, edx
       jne      G_M000_IG68
 
G_M000_IG49:                ;; offset=0x04F4
       inc      esi
       cmp      esi, edi
       jge      G_M000_IG154
 
G_M000_IG50:                ;; offset=0x04FE
       mov      r15d, dword ptr [rcx+0x08]
       cmp      esi, r15d
       jae      G_M000_IG169
       lea      rdx, [rsi+4*rsi]
       mov      rdx, gword ptr [rcx+8*rdx+0x10]
       test     rdx, rdx
       je       SHORT G_M000_IG49
 
G_M000_IG51:                ;; offset=0x0519
       mov      r8, 0x7F4C22EDFBC0
       cmp      qword ptr [rdx], r8
       jne      SHORT G_M000_IG49
 
G_M000_IG52:                ;; offset=0x0528
       movzx    r8, byte  ptr [rdx+0x24]
       test     r8d, r8d
       je       SHORT G_M000_IG56
 
G_M000_IG53:                ;; offset=0x0532
       cmp      r8d, 255
       jne      G_M000_IG43
 
G_M000_IG54:                ;; offset=0x053F
       mov      r8, gword ptr [rdx+0x08]
       lea      r9, bword ptr [rdx+0x28]
       mov      r9d, dword ptr [r9]
       mov      edx, dword ptr [rdx+0x18]
       test     r8, r8
       je       G_M000_IG112
       mov      r10d, edx
       add      r10, r9
       mov      r11d, dword ptr [r8+0x08]
       cmp      r10, r11
       ja       G_M000_IG124
       lea      r8, bword ptr [r8+r9+0x10]
       mov      r9d, edx
 
G_M000_IG55:                ;; offset=0x0571
       jmp      G_M000_IG44
 
G_M000_IG56:                ;; offset=0x0576
       mov      r8, gword ptr [rdx+0x08]
       mov      r9d, dword ptr [rdx+0x18]
       test     r8, r8
       je       G_M000_IG111
       cmp      dword ptr [r8+0x08], r9d
       jb       G_M000_IG124
       add      r8, 16
 
G_M000_IG57:                ;; offset=0x0595
       jmp      G_M000_IG44
 
G_M000_IG58:                ;; offset=0x059A
       xor      edx, edx
       mov      r10, r9
       and      r10, 2
       jne      G_M000_IG113
 
G_M000_IG59:                ;; offset=0x05A9
       test     r9b, 1
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x05AF
       movzx    r9, byte  ptr [r14+r10]
       movzx    r8, byte  ptr [r8+r10]
       sub      r9d, r8d
       or       edx, r9d
 
G_M000_IG61:                ;; offset=0x05BF
       test     edx, edx
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG48
 
G_M000_IG62:                ;; offset=0x05CC
       cmp      rdx, r10
       je       G_M000_IG122
 
G_M000_IG63:                ;; offset=0x05D5
       cmp      r9, 32
       jae      G_M000_IG114
 
G_M000_IG64:                ;; offset=0x05DF
       cmp      r9, 16
       jae      G_M000_IG117
 
G_M000_IG65:                ;; offset=0x05E9
       add      r9, -8
       mov      r10, qword ptr [r14]
       sub      r10, qword ptr [r8]
       mov      rdx, qword ptr [r14+r9]
       sub      rdx, qword ptr [r8+r9]
       or       rdx, r10
       sete     dl
       movzx    rdx, dl
       jmp      G_M000_IG48
 
G_M000_IG66:                ;; offset=0x0609
       add      rdx, 32
       cmp      r8, rdx
       jbe      G_M000_IG116
 
G_M000_IG67:                ;; offset=0x0616
       vmovups  ymm0, ymmword ptr [r14+rdx]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+rdx]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG123
       jmp      SHORT G_M000_IG66
 
G_M000_IG68:                ;; offset=0x0632
       mov      r15d, esi
       jmp      G_M000_IG81
 
G_M000_IG69:                ;; offset=0x063A
       mov      r8d, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG70:                ;; offset=0x0645
       rorx     esi, dword ptr [rbp-0x50], 31
       rorx     r8d, dword ptr [rbp-0x4C], 25
       add      esi, r8d
       rorx     r8d, dword ptr [rbp-0x48], 20
       add      esi, r8d
       rorx     r8d, dword ptr [rbp-0x44], 14
       add      esi, r8d
       jmp      G_M000_IG36
 
G_M000_IG71:                ;; offset=0x066F
       mov      r10, 0x7F4C22EDFBC0
       cmp      qword ptr [rdi], r10
       jne      G_M000_IG102
 
G_M000_IG72:                ;; offset=0x0682
       mov      dword ptr [rbp-0xA8], r13d
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0xD0], rax
       mov      ecx, edx
       mov      dword ptr [rbp-0xA4], edx
       mov      edi, dword ptr [rbp-0xA8]
       cmp      ecx, edi
       jne      G_M000_IG136
       xor      edx, edx
       mov      dword ptr [rbp-0x5C], edx
       cmp      edx, r13d
       jge      G_M000_IG80
 
G_M000_IG73:                ;; offset=0x06BA
       mov      rdi, gword ptr [r15+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG138
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG137
 
G_M000_IG74:                ;; offset=0x06E3
       mov      edx, dword ptr [rbp-0x5C]
       mov      edi, r13d
       sub      edi, edx
       cmp      edi, 0x1000
       jge      G_M000_IG91
 
G_M000_IG75:                ;; offset=0x06F7
       mov      esi, edx
       mov      r8d, edi
       add      rsi, r8
       mov      r9d, r13d
       cmp      rsi, r9
       ja       G_M000_IG124
       mov      r9d, edx
       add      r9, r14
       mov      ecx, dword ptr [rbp-0xA4]
       mov      r10d, ecx
       cmp      rsi, r10
       ja       G_M000_IG124
       mov      esi, edx
       mov      rax, bword ptr [rbp-0xD0]
       add      rsi, rax
       mov      r10, r9
       mov      r11, rsi
       cmp      r8, 8
       jae      G_M000_IG96
 
G_M000_IG76:                ;; offset=0x073F
       cmp      r8, 4
       jb       G_M000_IG92
 
G_M000_IG77:                ;; offset=0x0749
       add      r8, -4
       mov      r10d, dword ptr [r9]
       sub      r10d, dword ptr [rsi]
       mov      r9d, dword ptr [r9+r8]
       sub      r9d, dword ptr [rsi+r8]
       or       r9d, r10d
       sete     r8b
       movzx    r8, r8b
 
G_M000_IG78:                ;; offset=0x0766
       test     r8d, r8d
       je       G_M000_IG140
 
G_M000_IG79:                ;; offset=0x076F
       add      edx, edi
       cmp      edx, r13d
       mov      dword ptr [rbp-0x5C], edx
       jl       G_M000_IG73
 
G_M000_IG80:                ;; offset=0x077D
       mov      r15d, dword ptr [rbp-0x30]
 
G_M000_IG81:                ;; offset=0x0781
       test     r15d, r15d
       jl       G_M000_IG155
 
G_M000_IG82:                ;; offset=0x078A
       mov      rdi, gword ptr [rbx+0x28]
       cmp      r15d, dword ptr [rdi+0x08]
       jae      G_M000_IG169
       mov      esi, r15d
       lea      rsi, [rsi+4*rsi]
       lea      rdi, bword ptr [rdi+8*rsi+0x10]
       mov      rsi, rdi
       mov      r14d, r15d
       mov      rcx, gword ptr [rsi]
       mov      r13, rcx
       test     r13, r13
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x07B5
       mov      rdx, 0x7F4C22EDFBC0
       cmp      qword ptr [r13], rdx
       jne      G_M000_IG157
 
G_M000_IG84:                ;; offset=0x07C9
       mov      ecx, dword ptr [rsi+0x18]
       mov      dword ptr [rbp-0x8C], ecx
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG158
       mov      rsi, gword ptr [rbx+0x30]
       cmp      r14d, dword ptr [rsi+0x08]
       jae      G_M000_IG169
       mov      edx, r14d
       cmp      gword ptr [rsi+8*rdx+0x10], 0
       jne      G_M000_IG158
 
G_M000_IG85:                ;; offset=0x07FA
       mov      rsi, qword ptr [rdi+0x10]
       mov      rdi, 0xFF80000000000000
       cmp      rsi, rdi
       jl       G_M000_IG159
       mov      rdi, 0x80000000000000
       cmp      rsi, rdi
       jge      G_M000_IG159
 
G_M000_IG86:                ;; offset=0x0824
       test     r12, r12
       jne      G_M000_IG163
       movsxd   rdi, dword ptr [rbp-0x9C]
 
G_M000_IG87:                ;; offset=0x0834
       add      rsi, rdi
       mov      r12d, dword ptr [rbx+0x4C]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG168
       mov      rdi, gword ptr [rbx+0x28]
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG169
       mov      eax, r14d
       lea      rax, [rax+4*rax]
       mov      qword ptr [rdi+8*rax+0x20], rsi
       mov      rdi, gword ptr [rbx+0x30]
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG169
       mov      esi, r14d
       xor      rax, rax
       mov      gword ptr [rdi+8*rsi+0x10], rax
 
G_M000_IG88:                ;; offset=0x0878
       cmp      dword ptr [rbx+0x4C], r12d
       jne      G_M000_IG108
 
G_M000_IG89:                ;; offset=0x0882
       mov      eax, 1
 
G_M000_IG90:                ;; offset=0x0887
       vzeroupper 
       add      rsp, 200
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG91:                ;; offset=0x089C
       mov      edi, 0x1000
       jmp      G_M000_IG75
 
G_M000_IG92:                ;; offset=0x08A6
       xor      r11d, r11d
       mov      r10, r8
       and      r10, 2
       mov      qword ptr [rbp-0x68], r10
       test     r10, r10
       jne      G_M000_IG139
 
G_M000_IG93:                ;; offset=0x08BD
       test     r8b, 1
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x08C3
       mov      r10, qword ptr [rbp-0x68]
       movzx    r8, byte  ptr [r9+r10]
       movzx    r9, byte  ptr [rsi+r10]
       sub      r8d, r9d
       or       r11d, r8d
 
G_M000_IG95:                ;; offset=0x08D7
       test     r11d, r11d
       sete     r8b
       movzx    r8, r8b
       jmp      G_M000_IG78
 
G_M000_IG96:                ;; offset=0x08E7
       cmp      r10, r11
       je       G_M000_IG79
 
G_M000_IG97:                ;; offset=0x08F0
       cmp      r8, 32
       jae      G_M000_IG141
 
G_M000_IG98:                ;; offset=0x08FA
       cmp      r8, 16
       jae      G_M000_IG147
 
G_M000_IG99:                ;; offset=0x0904
       add      r8, -8
       mov      r10, qword ptr [r9]
       sub      r10, qword ptr [rsi]
       mov      r11, qword ptr [r9+r8]
       sub      r11, qword ptr [rsi+r8]
       or       r10, r11
       sete     r8b
       movzx    r8, r8b
       jmp      G_M000_IG78
 
G_M000_IG100:                ;; offset=0x0926
       add      rsi, 32
       cmp      r8, rsi
       jbe      G_M000_IG145
 
G_M000_IG101:                ;; offset=0x0933
       vmovups  ymm0, ymmword ptr [r10+rsi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+rsi]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       jne      G_M000_IG144
       jmp      SHORT G_M000_IG100
 
G_M000_IG102:                ;; offset=0x094F
       mov      rcx, gword ptr [rbp-0xB8]
 
G_M000_IG103:                ;; offset=0x0956
       mov      rsi, bword ptr [rbp-0xD8]
       mov      edx, dword ptr [rsi+0x1C]
       dec      edx
       mov      dword ptr [rbp-0x30], edx
       mov      r8d, dword ptr [rbp-0x2C]
       js       G_M000_IG154
 
G_M000_IG104:                ;; offset=0x096F
       mov      rdi, gword ptr [r15+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG135
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG134
 
G_M000_IG105:                ;; offset=0x0998
       mov      edx, dword ptr [rbp-0x30]
       cmp      edx, dword ptr [rbp-0xAC]
       jae      G_M000_IG169
       mov      dword ptr [rbp-0x30], edx
       mov      edi, edx
       lea      rdi, [rdi+4*rdi]
       mov      rcx, gword ptr [rbp-0xB8]
       lea      rsi, bword ptr [rcx+8*rdi+0x10]
       mov      bword ptr [rbp-0xD8], rsi
       cmp      dword ptr [rsi+0x18], r8d
       jne      SHORT G_M000_IG103
 
G_M000_IG106:                ;; offset=0x09C9
       mov      rdi, gword ptr [rcx+8*rdi+0x10]
       test     rdi, rdi
       jne      G_M000_IG71
 
G_M000_IG107:                ;; offset=0x09D7
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG108:                ;; offset=0x09E3
       inc      dword ptr [rbx+0x48]
       jmp      G_M000_IG89
 
G_M000_IG109:                ;; offset=0x09EB
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG03
 
G_M000_IG110:                ;; offset=0x09FF
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG111:                ;; offset=0x0A0E
       test     r9d, r9d
       jne      G_M000_IG124
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG57
 
G_M000_IG112:                ;; offset=0x0A22
       or       r9d, edx
       jne      G_M000_IG124
       xor      r8, r8
       xor      r9d, r9d
       jmp      G_M000_IG55
 
G_M000_IG113:                ;; offset=0x0A36
       movzx    rdx, word  ptr [r14]
       movzx    r11, word  ptr [r8]
       sub      edx, r11d
       jmp      G_M000_IG59
 
G_M000_IG114:                ;; offset=0x0A46
       xor      edx, edx
       lea      r8, [r9-0x20]
       test     r8, r8
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0A51
       vmovups  ymm0, ymmword ptr [r14]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       G_M000_IG66
       jmp      G_M000_IG123
 
G_M000_IG116:                ;; offset=0x0A6E
       vmovups  ymm0, ymmword ptr [r14+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r10+r8]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      SHORT G_M000_IG123
       jmp      SHORT G_M000_IG122
 
G_M000_IG117:                ;; offset=0x0A85
       xor      edx, edx
       add      r9, -16
       je       SHORT G_M000_IG121
 
G_M000_IG118:                ;; offset=0x0A8D
       vmovups  xmm0, xmmword ptr [r14]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG123
 
G_M000_IG119:                ;; offset=0x0AA4
       add      rdx, 16
       cmp      r9, rdx
       jbe      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0AAD
       vmovups  xmm0, xmmword ptr [r14+rdx]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+rdx]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG123
       jmp      SHORT G_M000_IG119
 
G_M000_IG121:                ;; offset=0x0AC8
       vmovups  xmm0, xmmword ptr [r14+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r10+r9]
       vpmovmskb r10d, xmm0
       cmp      r10d, 0xFFFF
       jne      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0AE1
       mov      edx, 1
       jmp      G_M000_IG48
 
G_M000_IG123:                ;; offset=0x0AEB
       xor      edx, edx
       jmp      G_M000_IG48
 
G_M000_IG124:                ;; offset=0x0AF2
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG125:                ;; offset=0x0AF9
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG06
 
G_M000_IG126:                ;; offset=0x0B0D
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG06
 
G_M000_IG127:                ;; offset=0x0B23
       mov      esi, dword ptr [rbp-0x34]
       and      esi, 3
       dec      esi
       cmp      esi, 2
       ja       G_M000_IG09
       lea      rdi, [reloc @RWD00]
       mov      dword ptr [rbp-0xA0], r11d
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rax, G_M000_IG02
       add      rdi, rax
       jmp      rdi
 
G_M000_IG128:                ;; offset=0x0B51
       mov      rax, r10
       jmp      SHORT G_M000_IG132
 
G_M000_IG129:                ;; offset=0x0B56
       mov      rcx, r10
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0B5B
       mov      esi, dword ptr [r9]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      r10, bword ptr [rbp-0xC0]
       add      r10, 4
       mov      eax, dword ptr [rbp-0x58]
       lea      r11d, [rax-0x04]
       mov      rcx, r10
       mov      dword ptr [rbp-0xA0], r11d
 
G_M000_IG131:                ;; offset=0x0B84
       mov      bword ptr [rbp-0xC8], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0xC8]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0xA0]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0xA0], edx
 
G_M000_IG132:                ;; offset=0x0BB4
       mov      bword ptr [rbp-0xC8], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0xC8]
       add      rax, 4
       mov      edx, dword ptr [rbp-0xA0]
       add      edx, -4
       mov      r10, rax
       mov      r11d, edx
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG09
 
G_M000_IG133:                ;; offset=0x0BED
       mov      eax, r8d
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       mov      r8d, dword ptr [rbp-0x2C]
       jmp      G_M000_IG41
 
G_M000_IG134:                ;; offset=0x0BFF
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG105
 
G_M000_IG135:                ;; offset=0x0C13
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8d, dword ptr [rbp-0x2C]
       jmp      G_M000_IG105
 
G_M000_IG136:                ;; offset=0x0C26
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG137:                ;; offset=0x0C32
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG74
 
G_M000_IG138:                ;; offset=0x0C46
       mov      rsi, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG74
 
G_M000_IG139:                ;; offset=0x0C55
       movzx    r11, word  ptr [r9]
       mov      dword ptr [rbp-0xDC], r11d
       movzx    r11, word  ptr [rsi]
       movzx    r10, dword ptr [rbp-0xDC]
       sub      r10d, r11d
       mov      r11d, r10d
       jmp      G_M000_IG93
 
G_M000_IG140:                ;; offset=0x0C77
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG141:                ;; offset=0x0C83
       xor      esi, esi
       add      r8, -32
       je       SHORT G_M000_IG145
 
G_M000_IG142:                ;; offset=0x0C8B
       vmovups  ymm0, ymmword ptr [r10]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11]
       vpmovmskb r9d, ymm0
       cmp      r9d, -1
       je       G_M000_IG100
 
G_M000_IG143:                ;; offset=0x0CA3
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG144:                ;; offset=0x0CAF
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG145:                ;; offset=0x0CBB
       vmovups  ymm0, ymmword ptr [r10+r8]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r11+r8]
       vpmovmskb esi, ymm0
       cmp      esi, -1
       je       G_M000_IG79
 
G_M000_IG146:                ;; offset=0x0CD4
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG147:                ;; offset=0x0CE0
       xor      esi, esi
       add      r8, -16
       je       SHORT G_M000_IG152
 
G_M000_IG148:                ;; offset=0x0CE8
       vmovups  xmm0, xmmword ptr [r10]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       je       SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x0CFF
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG150:                ;; offset=0x0D0B
       add      rsi, 16
       cmp      r8, rsi
       jbe      SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x0D14
       vmovups  xmm0, xmmword ptr [r10+rsi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+rsi]
       vpmovmskb r9d, xmm0
       cmp      r9d, 0xFFFF
       je       SHORT G_M000_IG150
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG152:                ;; offset=0x0D39
       vmovups  xmm0, xmmword ptr [r10+r8]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r11+r8]
       vpmovmskb r10d, xmm0
       cmp      r10d, 0xFFFF
       je       G_M000_IG79
 
G_M000_IG153:                ;; offset=0x0D56
       mov      rcx, gword ptr [rbp-0xB8]
       jmp      G_M000_IG103
 
G_M000_IG154:                ;; offset=0x0D62
       mov      r15d, -1
       jmp      G_M000_IG81
 
G_M000_IG155:                ;; offset=0x0D6D
       xor      eax, eax
 
G_M000_IG156:                ;; offset=0x0D6F
       vzeroupper 
       add      rsp, 200
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG157:                ;; offset=0x0D84
       mov      rsi, rcx
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG158:                ;; offset=0x0D90
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       test     rax, rax
       jne      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x0DA1
       xor      eax, eax
       jmp      G_M000_IG90
 
G_M000_IG160:                ;; offset=0x0DA8
       mov      rdi, 0x7F4C22DAB020
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG159
 
G_M000_IG161:                ;; offset=0x0DB7
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG162:                ;; offset=0x0DC1
       xor      edi, edi
       mov      dword ptr [rbp-0x98], edi
       lea      rdi, [rbp-0x98]
       mov      qword ptr [rsp], rdi
       lea      rdi, [rbp-0x78]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      esi, 1
       xor      r8d, r8d
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rbp-0x98], 8
       jge      SHORT G_M000_IG159
       mov      rdi, gword ptr [rbp-0x78]
       mov      rsi, qword ptr [rbp-0x70]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       jmp      G_M000_IG86
 
G_M000_IG163:                ;; offset=0x0E0C
       cmp      dword ptr [r12+0x08], 1
       jle      SHORT G_M000_IG164
       mov      rdi, 0x7F4C23358130
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG164:                ;; offset=0x0E41
       cmp      dword ptr [r12+0x08], 0
       jbe      G_M000_IG169
       mov      rdi, qword ptr [r12+0x10]
       mov      rdx, rdi
       neg      rdx
       mov      eax, dword ptr [rbp-0x9C]
       test     eax, eax
       cmovle   rdi, rdx
       test     rdi, rdi
       jle      SHORT G_M000_IG165
       test     eax, eax
       jg       SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x0E6D
       test     rdi, rdi
       jge      SHORT G_M000_IG167
       test     eax, eax
       jge      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x0E76
       jmp      G_M000_IG87
 
G_M000_IG167:                ;; offset=0x0E7B
       mov      rdi, 0x7F4C23358130
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG168:                ;; offset=0x0EA8
       lea      rdi, [rbp-0x88]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7F4C22DAB020
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, gword ptr [rbp-0x88]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x80]
       mov      dword ptr [r14+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, r14
       mov      rdi, rbx
       mov      esi, r15d
       mov      rdx, r13
       mov      r8d, dword ptr [rbp-0x8C]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG88
 
G_M000_IG169:                ;; offset=0x0F06
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000B0Bh ; case G_M000_IG130
       	dd	00000B06h ; case G_M000_IG129
       	dd	00000B01h ; case G_M000_IG128

; Total bytes of code 3852

; Assembly listing for method Lokad.Lython.Runtime.PyDict:FindNativeTextIndex(Lokad.Lython.Runtime.PyDict+NativeKey[],int,System.ReadOnlySpan`1[byte],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1065704
; 52 inlinees with PGO data; 117 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      rbx, rdi
       mov      r13, rdx
       mov      r15d, ecx
       mov      r14, r8
       mov      r12, r9
 
G_M000_IG02:                ;; offset=0x0032
       cmp      esi, 4
       jle      G_M000_IG75
 
G_M000_IG03:                ;; offset=0x003B
       test     esi, esi
       je       G_M000_IG148
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       xor      eax, eax
       mov      dword ptr [rbp-0x54], eax
       cmp      eax, r15d
       jge      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x005A
       test     r14, r14
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005F
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG119
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG118
 
G_M000_IG06:                ;; offset=0x0088
       mov      eax, dword ptr [rbp-0x54]
       mov      ecx, r15d
       sub      ecx, eax
       cmp      ecx, 0x1000
       jge      G_M000_IG102
 
G_M000_IG07:                ;; offset=0x009C
       mov      dword ptr [rbp-0x58], ecx
       mov      esi, eax
       mov      edi, ecx
       add      rsi, rdi
       mov      edi, r15d
       cmp      rsi, rdi
       ja       G_M000_IG117
       mov      dword ptr [rbp-0x54], eax
       mov      edx, eax
       add      rdx, r13
       mov      bword ptr [rbp-0xA0], rdx
       mov      r8, rdx
       mov      r9d, ecx
       cmp      ecx, 16
       jl       G_M000_IG21
 
G_M000_IG08:                ;; offset=0x00D0
       cmp      dword ptr [rbp-0x34], 0
       jne      G_M000_IG120
       mov      rdx, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], rdx
       mov      rsi, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], rsi
 
G_M000_IG09:                ;; offset=0x00F6
       cmp      r9d, 16
       jl       G_M000_IG21
 
G_M000_IG10:                ;; offset=0x0100
       mov      edx, dword ptr [rbp-0x50]
       imul     edi, dword ptr [r8], 0xFFFFFFFF85EBCA77
       add      edx, edi
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], edx
       mov      edx, dword ptr [rbp-0x4C]
       lea      rdi, bword ptr [r8+0x04]
       imul     edi, dword ptr [rdi], 0xFFFFFFFF85EBCA77
       add      edx, edi
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], edx
       mov      edx, dword ptr [rbp-0x48]
       lea      rdi, bword ptr [r8+0x08]
       imul     edi, dword ptr [rdi], 0xFFFFFFFF85EBCA77
       add      edx, edi
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], edx
       mov      edx, dword ptr [rbp-0x44]
       lea      rdi, bword ptr [r8+0x0C]
       imul     edi, dword ptr [rdi], 0xFFFFFFFF85EBCA77
       add      edx, edi
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edx
       mov      edx, dword ptr [rbp-0x34]
       add      edx, 4
       mov      dword ptr [rbp-0x34], edx
       add      r8, 16
       add      r9d, -16
       mov      rdx, r8
       mov      edi, r9d
       mov      r8, rdx
       mov      r9d, edi
       jmp      G_M000_IG09
 
G_M000_IG11:                ;; offset=0x018B
       mov      edx, dword ptr [r8]
       mov      edi, dword ptr [rbp-0x34]
       lea      esi, [rdi+0x01]
       mov      dword ptr [rbp-0x34], esi
       mov      esi, edi
       and      esi, 3
       je       G_M000_IG19
 
G_M000_IG12:                ;; offset=0x01A2
       cmp      esi, 1
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01A7
       mov      dword ptr [rbp-0x3C], edx
       jmp      G_M000_IG20
 
G_M000_IG14:                ;; offset=0x01AF
       cmp      esi, 2
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01B4
       mov      dword ptr [rbp-0x38], edx
       jmp      G_M000_IG20
 
G_M000_IG16:                ;; offset=0x01BC
       cmp      edi, 3
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01C1
       mov      rdi, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], rdi
       mov      rdi, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], rdi
 
G_M000_IG18:                ;; offset=0x01DD
       imul     edi, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x50]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], edi
       imul     edi, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x4C]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], edi
       imul     edi, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      edi, dword ptr [rbp-0x48]
       rol      edi, 13
       imul     edi, edi, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], edi
       imul     edx, edx, 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x44]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], edx
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0236
       mov      dword ptr [rbp-0x40], edx
 
G_M000_IG20:                ;; offset=0x0239
       add      r8, 4
       add      r9d, -4
       mov      rdx, r8
       mov      edi, r9d
       mov      r8, rdx
       mov      r9d, edi
 
G_M000_IG21:                ;; offset=0x024D
       cmp      r9d, 4
       jge      G_M000_IG11
 
G_M000_IG22:                ;; offset=0x0257
       mov      rdx, r8
       mov      edi, r9d
       xor      esi, esi
       test     edi, edi
       je       G_M000_IG33
 
G_M000_IG23:                ;; offset=0x0267
       movzx    r8, byte  ptr [rdx+rsi]
       mov      r9d, dword ptr [rbp-0x34]
       lea      r10d, [r9+0x01]
       mov      dword ptr [rbp-0x34], r10d
       mov      r10d, r9d
       and      r10d, 3
       je       G_M000_IG31
 
G_M000_IG24:                ;; offset=0x0285
       cmp      r10d, 1
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x028B
       mov      dword ptr [rbp-0x3C], r8d
       jmp      G_M000_IG32
 
G_M000_IG26:                ;; offset=0x0294
       cmp      r10d, 2
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x029A
       mov      dword ptr [rbp-0x38], r8d
       jmp      G_M000_IG32
 
G_M000_IG28:                ;; offset=0x02A3
       cmp      r9d, 3
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02A9
       mov      r9, 0x92539A90308B1441
       mov      qword ptr [rbp-0x50], r9
       mov      r9, 0x6E3056680C67D019
       mov      qword ptr [rbp-0x48], r9
 
G_M000_IG30:                ;; offset=0x02C5
       imul     r9d, dword ptr [rbp-0x40], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x50]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x50], r9d
       imul     r9d, dword ptr [rbp-0x3C], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x4C]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x4C], r9d
       imul     r9d, dword ptr [rbp-0x38], 0xFFFFFFFF85EBCA77
       add      r9d, dword ptr [rbp-0x48]
       rol      r9d, 13
       imul     r9d, r9d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x48], r9d
       imul     r8d, r8d, 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rbp-0x44]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x44], r8d
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0332
       mov      dword ptr [rbp-0x40], r8d
 
G_M000_IG32:                ;; offset=0x0336
       inc      esi
       cmp      esi, edi
       jl       G_M000_IG23
 
G_M000_IG33:                ;; offset=0x0340
       mov      eax, dword ptr [rbp-0x54]
       add      eax, dword ptr [rbp-0x58]
       cmp      eax, r15d
       mov      dword ptr [rbp-0x54], eax
       jl       G_M000_IG04
 
G_M000_IG34:                ;; offset=0x0352
       mov      eax, dword ptr [rbp-0x34]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG103
 
G_M000_IG35:                ;; offset=0x0363
       mov      edi, 0x22BE37CA
 
G_M000_IG36:                ;; offset=0x0368
       lea      eax, [rdi+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x036F
       imul     edi, dword ptr [rbp-0x40], 0xFFFFFFFFC2B2AE3D
       add      eax, edi
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x0386
       imul     edi, dword ptr [rbp-0x3C], 0xFFFFFFFFC2B2AE3D
       add      edi, eax
       rol      edi, 17
       imul     eax, edi, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x039D
       imul     edx, dword ptr [rbp-0x38], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG40:                ;; offset=0x03AF
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      eax, edx
       mov      edx, -2
       cmp      eax, -1
       cmovne   edx, eax
       mov      eax, edx
       shr      eax, 16
       xor      eax, edx
       imul     ecx, eax, 0xFFFFFFFF9E3779B9
       mov      r8d, ecx
       shr      r8d, 16
       xor      ecx, r8d
       mov      dword ptr [rbp-0x2C], ecx
       mov      eax, dword ptr [rbx+0x08]
       mov      r8d, eax
       mov      edi, r8d
       blsr     eax, edi
       jne      G_M000_IG126
       dec      edi
       and      edi, ecx
 
G_M000_IG41:                ;; offset=0x040D
       mov      dword ptr [rbp-0x84], r8d
       cmp      edi, r8d
       jae      G_M000_IG150
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      eax, dword ptr [rbx+8*rdi+0x30]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       test     eax, eax
       jl       G_M000_IG148
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0436
       mov      rdx, bword ptr [rbp-0xB8]
       mov      eax, dword ptr [rdx+0x1C]
       dec      eax
       mov      dword ptr [rbp-0x30], eax
       mov      ecx, dword ptr [rbp-0x2C]
       js       G_M000_IG148
 
G_M000_IG43:                ;; offset=0x044E
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG128
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG127
 
G_M000_IG44:                ;; offset=0x0477
       mov      eax, dword ptr [rbp-0x30]
       cmp      eax, dword ptr [rbp-0x84]
       jae      G_M000_IG150
       mov      dword ptr [rbp-0x30], eax
       mov      edi, eax
       lea      rdi, [rdi+4*rdi]
       lea      rdx, bword ptr [rbx+8*rdi+0x10]
       mov      bword ptr [rbp-0xB8], rdx
       cmp      dword ptr [rdx+0x18], ecx
       jne      SHORT G_M000_IG42
 
G_M000_IG45:                ;; offset=0x04A0
       mov      rdi, gword ptr [rbx+8*rdi+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG42
 
G_M000_IG46:                ;; offset=0x04AA
       mov      rsi, 0x7F4C22EDFBC0
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG42
 
G_M000_IG47:                ;; offset=0x04BD
       mov      esi, r15d
       movzx    r9, byte  ptr [rdi+0x24]
       test     r9d, r9d
       je       G_M000_IG62
 
G_M000_IG48:                ;; offset=0x04CE
       cmp      r9d, 255
       je       G_M000_IG60
 
G_M000_IG49:                ;; offset=0x04DB
       lea      r9, bword ptr [rdi+0x28]
       mov      r10d, dword ptr [rdi+0x18]
       cmp      r10d, 8
       ja       G_M000_IG117
 
G_M000_IG50:                ;; offset=0x04ED
       mov      bword ptr [rbp-0xB0], r9
       mov      dword ptr [rbp-0x78], r10d
       cmp      r10d, esi
       jne      G_M000_IG42
       xor      r11d, r11d
       mov      dword ptr [rbp-0x5C], r11d
       cmp      r11d, r15d
       jge      G_M000_IG58
 
G_M000_IG51:                ;; offset=0x0511
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG132
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG131
 
G_M000_IG52:                ;; offset=0x053A
       mov      r11d, dword ptr [rbp-0x5C]
       mov      edi, r15d
       sub      edi, r11d
       cmp      edi, 0x1000
       jge      G_M000_IG64
 
G_M000_IG53:                ;; offset=0x0550
       mov      dword ptr [rbp-0x60], edi
       mov      esi, r11d
       mov      r9d, edi
       add      rsi, r9
       mov      r10d, r15d
       cmp      rsi, r10
       mov      gword ptr [rbp-0x90], r12
       ja       G_M000_IG117
       mov      r10d, r11d
       add      r10, r13
       mov      r12d, dword ptr [rbp-0x78]
       cmp      rsi, r12
       ja       G_M000_IG117
       mov      esi, r11d
       add      rsi, bword ptr [rbp-0xB0]
       mov      bword ptr [rbp-0x98], r10
       mov      r12, rsi
       cmp      r9, 8
       jae      G_M000_IG69
 
G_M000_IG54:                ;; offset=0x05A0
       cmp      r9, 4
       jb       G_M000_IG65
 
G_M000_IG55:                ;; offset=0x05AA
       add      r9, -4
       mov      r12d, dword ptr [r10]
       sub      r12d, dword ptr [rsi]
       mov      r10d, dword ptr [r10+r9]
       sub      r10d, dword ptr [rsi+r9]
       or       r10d, r12d
       sete     r9b
       movzx    r9, r9b
 
G_M000_IG56:                ;; offset=0x05C7
       test     r9d, r9d
       je       G_M000_IG134
 
G_M000_IG57:                ;; offset=0x05D0
       add      r11d, dword ptr [rbp-0x60]
       cmp      r11d, r15d
       mov      dword ptr [rbp-0x5C], r11d
       mov      r12, gword ptr [rbp-0x90]
       jl       G_M000_IG51
 
G_M000_IG58:                ;; offset=0x05E8
       mov      eax, dword ptr [rbp-0x30]
 
G_M000_IG59:                ;; offset=0x05EB
       vzeroupper 
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x0600
       mov      r9, gword ptr [rdi+0x08]
       lea      r10, bword ptr [rdi+0x28]
       mov      r10d, dword ptr [r10]
       mov      edi, dword ptr [rdi+0x18]
       test     r9, r9
       je       G_M000_IG130
       mov      qword ptr [rbp-0x80], r10
       mov      r11d, edi
       add      r11, r10
       mov      r10d, dword ptr [r9+0x08]
       cmp      r11, r10
       ja       G_M000_IG117
       mov      r10, qword ptr [rbp-0x80]
       lea      r9, bword ptr [r9+r10+0x10]
       mov      r10d, edi
 
G_M000_IG61:                ;; offset=0x063A
       jmp      G_M000_IG50
 
G_M000_IG62:                ;; offset=0x063F
       mov      r9, gword ptr [rdi+0x08]
       mov      r10d, dword ptr [rdi+0x18]
       test     r9, r9
       je       G_M000_IG129
       cmp      dword ptr [r9+0x08], r10d
       jb       G_M000_IG117
       add      r9, 16
 
G_M000_IG63:                ;; offset=0x065E
       jmp      G_M000_IG50
 
G_M000_IG64:                ;; offset=0x0663
       mov      edi, 0x1000
       jmp      G_M000_IG53
 
G_M000_IG65:                ;; offset=0x066D
       xor      r12d, r12d
       mov      dword ptr [rbp-0x64], r12d
       mov      r12, r9
       and      r12, 2
       mov      qword ptr [rbp-0x70], r12
       test     r12, r12
       jne      G_M000_IG133
 
G_M000_IG66:                ;; offset=0x0688
       test     r9b, 1
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x068E
       mov      r12, qword ptr [rbp-0x70]
       movzx    r9, byte  ptr [r10+r12]
       movzx    r10, byte  ptr [rsi+r12]
       sub      r9d, r10d
       mov      r12d, r9d
       or       r12d, dword ptr [rbp-0x64]
       mov      dword ptr [rbp-0x64], r12d
 
G_M000_IG68:                ;; offset=0x06AA
       cmp      dword ptr [rbp-0x64], 0
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG56
 
G_M000_IG69:                ;; offset=0x06BB
       mov      rdi, bword ptr [rbp-0x98]
       cmp      rdi, r12
       je       G_M000_IG57
 
G_M000_IG70:                ;; offset=0x06CB
       cmp      r9, 32
       jae      G_M000_IG135
 
G_M000_IG71:                ;; offset=0x06D5
       cmp      r9, 16
       jae      G_M000_IG141
 
G_M000_IG72:                ;; offset=0x06DF
       add      r9, -8
       mov      rdi, qword ptr [r10]
       sub      rdi, qword ptr [rsi]
       mov      r10, qword ptr [r10+r9]
       sub      r10, qword ptr [rsi+r9]
       or       rdi, r10
       sete     r9b
       movzx    r9, r9b
       jmp      G_M000_IG56
 
G_M000_IG73:                ;; offset=0x0701
       add      rsi, 32
       cmp      r9, rsi
       jbe      G_M000_IG139
 
G_M000_IG74:                ;; offset=0x070E
       vmovups  ymm0, ymmword ptr [rdi+rsi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12+rsi]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       jne      G_M000_IG138
       jmp      SHORT G_M000_IG73
 
G_M000_IG75:                ;; offset=0x0729
       cmp      r15d, 8
       jg       G_M000_IG03
       xor      edi, edi
       test     esi, esi
       jle      G_M000_IG148
       jmp      SHORT G_M000_IG83
 
G_M000_IG76:                ;; offset=0x073F
       lea      rcx, bword ptr [rax+0x28]
       mov      edx, dword ptr [rax+0x18]
       cmp      edx, 8
       ja       G_M000_IG117
 
G_M000_IG77:                ;; offset=0x074F
       cmp      r15d, edx
       jne      SHORT G_M000_IG82
 
G_M000_IG78:                ;; offset=0x0754
       mov      rax, r13
       mov      r8, rcx
       mov      edx, edx
       cmp      rdx, 8
       jae      G_M000_IG95
 
G_M000_IG79:                ;; offset=0x0766
       cmp      rdx, 4
       jb       G_M000_IG91
 
G_M000_IG80:                ;; offset=0x0770
       add      rdx, -4
       mov      eax, dword ptr [r13]
       sub      eax, dword ptr [rcx]
       mov      r8d, dword ptr [rdx+r13]
       sub      r8d, dword ptr [rcx+rdx]
       or       eax, r8d
       sete     al
       movzx    rax, al
 
G_M000_IG81:                ;; offset=0x078B
       test     eax, eax
       jne      G_M000_IG101
 
G_M000_IG82:                ;; offset=0x0793
       inc      edi
       cmp      edi, esi
       jge      G_M000_IG148
 
G_M000_IG83:                ;; offset=0x079D
       mov      r12d, dword ptr [rbx+0x08]
       cmp      edi, r12d
       jae      G_M000_IG150
       lea      rax, [rdi+4*rdi]
       mov      rax, gword ptr [rbx+8*rax+0x10]
       test     rax, rax
       je       SHORT G_M000_IG82
 
G_M000_IG84:                ;; offset=0x07B8
       mov      rcx, 0x7F4C22EDFBC0
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG82
 
G_M000_IG85:                ;; offset=0x07C7
       movzx    rcx, byte  ptr [rax+0x24]
       test     ecx, ecx
       je       SHORT G_M000_IG89
 
G_M000_IG86:                ;; offset=0x07CF
       cmp      ecx, 255
       jne      G_M000_IG76
 
G_M000_IG87:                ;; offset=0x07DB
       mov      rcx, gword ptr [rax+0x08]
       lea      rdx, bword ptr [rax+0x28]
       mov      edx, dword ptr [rdx]
       mov      eax, dword ptr [rax+0x18]
       test     rcx, rcx
       je       G_M000_IG105
       mov      r8d, eax
       add      r8, rdx
       mov      r9d, dword ptr [rcx+0x08]
       cmp      r8, r9
       ja       G_M000_IG117
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      edx, eax
 
G_M000_IG88:                ;; offset=0x080B
       jmp      G_M000_IG77
 
G_M000_IG89:                ;; offset=0x0810
       mov      rcx, gword ptr [rax+0x08]
       mov      edx, dword ptr [rax+0x18]
       test     rcx, rcx
       je       G_M000_IG104
       cmp      dword ptr [rcx+0x08], edx
       jb       G_M000_IG117
       add      rcx, 16
 
G_M000_IG90:                ;; offset=0x082D
       jmp      G_M000_IG77
 
G_M000_IG91:                ;; offset=0x0832
       xor      eax, eax
       mov      r8, rdx
       and      r8, 2
       jne      G_M000_IG106
 
G_M000_IG92:                ;; offset=0x0841
       test     dl, 1
       je       SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0846
       movzx    rdx, byte  ptr [r8+r13]
       movzx    rcx, byte  ptr [rcx+r8]
       sub      edx, ecx
       or       eax, edx
 
G_M000_IG94:                ;; offset=0x0854
       test     eax, eax
       sete     al
       movzx    rax, al
       jmp      G_M000_IG81
 
G_M000_IG95:                ;; offset=0x0861
       cmp      rax, r8
       je       G_M000_IG115
 
G_M000_IG96:                ;; offset=0x086A
       cmp      rdx, 32
       jae      G_M000_IG107
 
G_M000_IG97:                ;; offset=0x0874
       cmp      rdx, 16
       jae      G_M000_IG110
 
G_M000_IG98:                ;; offset=0x087E
       add      rdx, -8
       mov      r8, qword ptr [r13]
       sub      r8, qword ptr [rcx]
       mov      rax, qword ptr [rdx+r13]
       sub      rax, qword ptr [rcx+rdx]
       or       rax, r8
       sete     al
       movzx    rax, al
       jmp      G_M000_IG81
 
G_M000_IG99:                ;; offset=0x089F
       add      rax, 32
       cmp      rcx, rax
       jbe      G_M000_IG109
 
G_M000_IG100:                ;; offset=0x08AC
       vmovups  ymm0, ymmword ptr [rax+r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+rax]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       jne      G_M000_IG116
       jmp      SHORT G_M000_IG99
 
G_M000_IG101:                ;; offset=0x08C7
       mov      eax, edi
       jmp      G_M000_IG59
 
G_M000_IG102:                ;; offset=0x08CE
       mov      ecx, 0x1000
       jmp      G_M000_IG07
 
G_M000_IG103:                ;; offset=0x08D8
       rorx     edi, dword ptr [rbp-0x50], 31
       rorx     esi, dword ptr [rbp-0x4C], 25
       add      edi, esi
       rorx     esi, dword ptr [rbp-0x48], 20
       add      edi, esi
       rorx     esi, dword ptr [rbp-0x44], 14
       add      edi, esi
       jmp      G_M000_IG36
 
G_M000_IG104:                ;; offset=0x08FF
       test     edx, edx
       jne      G_M000_IG117
       xor      rcx, rcx
       xor      edx, edx
       jmp      G_M000_IG90
 
G_M000_IG105:                ;; offset=0x0910
       or       edx, eax
       jne      G_M000_IG117
       xor      rcx, rcx
       xor      edx, edx
       jmp      G_M000_IG88
 
G_M000_IG106:                ;; offset=0x0921
       movzx    rax, word  ptr [r13]
       movzx    r9, word  ptr [rcx]
       sub      eax, r9d
       jmp      G_M000_IG92
 
G_M000_IG107:                ;; offset=0x0932
       xor      eax, eax
       lea      rcx, [rdx-0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x093D
       vmovups  ymm0, ymmword ptr [r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8]
       vpmovmskb edx, ymm0
       cmp      edx, -1
       je       G_M000_IG99
       jmp      SHORT G_M000_IG116
 
G_M000_IG109:                ;; offset=0x0957
       vmovups  ymm0, ymmword ptr [rcx+r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+rcx]
       vpmovmskb eax, ymm0
       cmp      eax, -1
       jne      SHORT G_M000_IG116
       jmp      SHORT G_M000_IG115
 
G_M000_IG110:                ;; offset=0x096E
       xor      eax, eax
       add      rdx, -16
       je       SHORT G_M000_IG114
 
G_M000_IG111:                ;; offset=0x0976
       vmovups  xmm0, xmmword ptr [r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8]
       vpmovmskb ecx, xmm0
       cmp      ecx, 0xFFFF
       jne      SHORT G_M000_IG116
 
G_M000_IG112:                ;; offset=0x098D
       add      rax, 16
       cmp      rdx, rax
       jbe      SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0996
       vmovups  xmm0, xmmword ptr [rax+r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+rax]
       vpmovmskb ecx, xmm0
       cmp      ecx, 0xFFFF
       jne      SHORT G_M000_IG116
       jmp      SHORT G_M000_IG112
 
G_M000_IG114:                ;; offset=0x09B0
       vmovups  xmm0, xmmword ptr [rdx+r13]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+rdx]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x09C9
       mov      eax, 1
       jmp      G_M000_IG81
 
G_M000_IG116:                ;; offset=0x09D3
       xor      eax, eax
       jmp      G_M000_IG81
 
G_M000_IG117:                ;; offset=0x09DA
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG118:                ;; offset=0x09E1
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG06
 
G_M000_IG119:                ;; offset=0x09F5
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG120:                ;; offset=0x0A03
       mov      esi, dword ptr [rbp-0x34]
       and      esi, 3
       dec      esi
       cmp      esi, 2
       ja       G_M000_IG09
       lea      rdi, [reloc @RWD00]
       mov      dword ptr [rbp-0x74], r9d
       mov      edi, dword ptr [rdi+4*rsi]
       lea      r10, G_M000_IG02
       add      rdi, r10
       jmp      rdi
 
G_M000_IG121:                ;; offset=0x0A2E
       mov      rax, r8
       jmp      SHORT G_M000_IG125
 
G_M000_IG122:                ;; offset=0x0A33
       mov      rcx, r8
       jmp      SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x0A38
       mov      esi, dword ptr [rdx]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      r8, bword ptr [rbp-0xA0]
       add      r8, 4
       mov      eax, dword ptr [rbp-0x58]
       lea      r9d, [rax-0x04]
       mov      rcx, r8
       mov      dword ptr [rbp-0x74], r9d
 
G_M000_IG124:                ;; offset=0x0A5D
       mov      bword ptr [rbp-0xA8], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0xA8]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0x74]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0x74], edx
 
G_M000_IG125:                ;; offset=0x0A87
       mov      bword ptr [rbp-0xA8], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x50]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0xA8]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x74]
       add      edx, -4
       mov      r8, rax
       mov      r9d, edx
       jmp      G_M000_IG09
 
G_M000_IG126:                ;; offset=0x0AB6
       mov      eax, ecx
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       mov      ecx, dword ptr [rbp-0x2C]
       jmp      G_M000_IG41
 
G_M000_IG127:                ;; offset=0x0AC6
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG44
 
G_M000_IG128:                ;; offset=0x0ADA
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      ecx, dword ptr [rbp-0x2C]
       jmp      G_M000_IG44
 
G_M000_IG129:                ;; offset=0x0AEB
       test     r10d, r10d
       jne      G_M000_IG117
       xor      r9, r9
       xor      r10d, r10d
       jmp      G_M000_IG63
 
G_M000_IG130:                ;; offset=0x0AFF
       or       r10d, edi
       jne      G_M000_IG117
       xor      r9, r9
       xor      r10d, r10d
       jmp      G_M000_IG61
 
G_M000_IG131:                ;; offset=0x0B13
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG52
 
G_M000_IG132:                ;; offset=0x0B27
       mov      gword ptr [rbp-0x90], r12
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG52
 
G_M000_IG133:                ;; offset=0x0B43
       movzx    r12, word  ptr [r10]
       mov      dword ptr [rbp-0xBC], r12d
       movzx    r12, word  ptr [rsi]
       movzx    rdi, dword ptr [rbp-0xBC]
       sub      edi, r12d
       mov      r12d, edi
       mov      dword ptr [rbp-0x64], r12d
       jmp      G_M000_IG66
 
G_M000_IG134:                ;; offset=0x0B68
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG135:                ;; offset=0x0B74
       xor      esi, esi
       add      r9, -32
       je       SHORT G_M000_IG139
 
G_M000_IG136:                ;; offset=0x0B7C
       vmovups  ymm0, ymmword ptr [rdi]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12]
       vpmovmskb r10d, ymm0
       cmp      r10d, -1
       je       G_M000_IG73
 
G_M000_IG137:                ;; offset=0x0B94
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG138:                ;; offset=0x0BA0
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG139:                ;; offset=0x0BAC
       vmovups  ymm0, ymmword ptr [rdi+r9]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r12+r9]
       vpmovmskb edi, ymm0
       cmp      edi, -1
       je       G_M000_IG57
 
G_M000_IG140:                ;; offset=0x0BC5
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG141:                ;; offset=0x0BD1
       xor      esi, esi
       add      r9, -16
       je       SHORT G_M000_IG146
 
G_M000_IG142:                ;; offset=0x0BD9
       vmovups  xmm0, xmmword ptr [rdi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r12]
       vpmovmskb r10d, xmm0
       cmp      r10d, 0xFFFF
       je       SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x0BF0
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG144:                ;; offset=0x0BFC
       add      rsi, 16
       cmp      r9, rsi
       jbe      SHORT G_M000_IG146
 
G_M000_IG145:                ;; offset=0x0C05
       vmovups  xmm0, xmmword ptr [rdi+rsi]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r12+rsi]
       vpmovmskb r10d, xmm0
       cmp      r10d, 0xFFFF
       je       SHORT G_M000_IG144
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG146:                ;; offset=0x0C29
       vmovups  xmm0, xmmword ptr [rdi+r9]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r12+r9]
       vpmovmskb edi, xmm0
       cmp      edi, 0xFFFF
       je       G_M000_IG57
 
G_M000_IG147:                ;; offset=0x0C45
       mov      r12, gword ptr [rbp-0x90]
       jmp      G_M000_IG42
 
G_M000_IG148:                ;; offset=0x0C51
       mov      eax, -1
 
G_M000_IG149:                ;; offset=0x0C56
       vzeroupper 
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG150:                ;; offset=0x0C6B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000A06h ; case G_M000_IG123
       	dd	00000A01h ; case G_M000_IG122
       	dd	000009FCh ; case G_M000_IG121

; Total bytes of code 3185

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 457200
; 98 inlinees with PGO data; 210 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 776
       lea      rbp, [rsp+0x330]
       xor      eax, eax
       mov      qword ptr [rbp-0x318], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x310], xmm8
       mov      rax, -720
 
G_M000_IG348:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG348
       mov      bword ptr [rbp-0x198], rdi
       mov      gword ptr [rbp-0x1A0], rsi
       mov      bword ptr [rbp-0x1A8], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0069
       mov      r15d, dword ptr [rdi+0x60]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0075
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG295
 
G_M000_IG04:                ;; offset=0x0089
       mov      eax, dword ptr [rcx+0x14]
 
G_M000_IG05:                ;; offset=0x008C
       cmp      r15d, eax
       jne      G_M000_IG38
       mov      rdi, bword ptr [rbp-0x198]
       cmp      gword ptr [rdi+0x40], 0
       jne      G_M000_IG38
       mov      rax, gword ptr [rdi]
       cmp      byte  ptr [rax+0xDD], 0
       jne      G_M000_IG297
 
G_M000_IG06:                ;; offset=0x00B7
       test     rbx, rbx
       je       G_M000_IG296
 
G_M000_IG07:                ;; offset=0x00C0
       cmp      byte  ptr [rbx+0xFF], 0
       jne      G_M000_IG297
       mov      rax, gword ptr [rbx+0x88]
 
G_M000_IG08:                ;; offset=0x00D4
       test     rax, rax
       sete     r15b
       movzx    r15, r15b
 
G_M000_IG09:                ;; offset=0x00DF
       test     r15d, r15d
       je       G_M000_IG292
 
G_M000_IG10:                ;; offset=0x00E8
       mov      rax, gword ptr [rdi+0x20]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG317
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      rsi, 0x7F3C798016E8
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG298
 
G_M000_IG11:                ;; offset=0x0117
       mov      rsi, 0x7F3C798016F0
       cmp      rdx, gword ptr [rsi]
       je       G_M000_IG299
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG300
 
G_M000_IG12:                ;; offset=0x0135
       test     rdx, rdx
       je       G_M000_IG301
       mov      rax, 0x7F4C2350BAF8
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG292
 
G_M000_IG13:                ;; offset=0x0151
       mov      gword ptr [rbp-0x1B0], rdx
       mov      rax, gword ptr [rbp-0x1B0]
       mov      rax, gword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdx, gword ptr [rsi+0x98]
       cmp      rax, gword ptr [rdx+0x88]
       jne      G_M000_IG292
       mov      rdi, bword ptr [rbp-0x198]
       mov      ebx, dword ptr [rdi+0x18]
       mov      rcx, bword ptr [rbp-0x1A8]
       cmp      dword ptr [rcx+0x1C], 68
       jne      G_M000_IG302
       mov      r15d, dword ptr [rcx+0x0C]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x88]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG317
       mov      r8d, r15d
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [rdx+0x1C], 42
       jne      G_M000_IG303
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7F4C232121C0
       cmp      qword ptr [rax], r8
       jne      G_M000_IG305
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG304
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG14:                ;; offset=0x01F5
       mov      gword ptr [rbp-0x1B8], r14
       mov      rdi, bword ptr [rbp-0x198]
       mov      rax, gword ptr [rdi]
       mov      rax, gword ptr [rax+0x88]
       mov      rdx, rax
       lea      r13d, [rbx+0x02]
       mov      dword ptr [rbp-0x178], r13d
       mov      r8d, dword ptr [rdx+0x08]
       cmp      r13d, r8d
       jae      G_M000_IG317
       mov      r9d, r13d
       shl      r9, 5
       lea      r12, bword ptr [rdx+r9+0x10]
       mov      bword ptr [rbp-0x1C0], r12
       mov      rdx, rax
       lea      r9d, [r15+0x01]
       cmp      r9d, r8d
       jae      G_M000_IG317
       lea      r9d, [r15+0x01]
       shl      r9, 5
       lea      rdx, bword ptr [rdx+r9+0x10]
       mov      r9, rax
       lea      r10d, [r15+0x02]
       cmp      r10d, r8d
       jae      G_M000_IG317
       lea      r10d, [r15+0x02]
       shl      r10, 5
       lea      r9, bword ptr [r9+r10+0x10]
       mov      bword ptr [rbp-0x1C8], r9
       mov      r9, gword ptr [rdi]
       mov      r9, gword ptr [r9+0x30]
       mov      r10, r9
       lea      r11d, [rbx+0x04]
       cmp      r11d, r8d
       jae      G_M000_IG317
       mov      r8d, r11d
       shl      r8, 5
       lea      rax, bword ptr [rax+r8+0x10]
       mov      r8d, dword ptr [rax+0x1C]
       cmp      r8d, 35
       jg       G_M000_IG307
       cmp      r8d, 35
       ja       G_M000_IG306
       mov      r11, 0x7FFFFFFBD
       bt       r11, r8
       jb       G_M000_IG306
 
G_M000_IG15:                ;; offset=0x02CB
       mov      eax, dword ptr [rax+0x08]
       mov      r8d, dword ptr [r10+0x08]
       cmp      eax, r8d
       jae      G_M000_IG317
       mov      rax, gword ptr [r10+8*rax+0x10]
       mov      gword ptr [rbp-0x1D0], rax
       mov      edx, dword ptr [rdx+0x0C]
       not      edx
       cmp      edx, r8d
       jae      G_M000_IG317
       mov      rdx, gword ptr [r9+8*rdx+0x10]
       mov      gword ptr [rbp-0x1F8], rdx
       mov      r8, qword ptr [rdx]
       mov      r9, 0x7F4C22DAB020
       mov      qword ptr [rbp-0x190], r9
       cmp      r8, r9
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x031A
       mov      rsi, rdx
       mov      rdi, r9
       call     CORINFO_HELP_UNBOX
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      r9, qword ptr [rbp-0x190]
 
G_M000_IG17:                ;; offset=0x0333
       mov      r8, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x2A8], r8
       mov      edx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x158], edx
       mov      rdi, bword ptr [rbp-0x198]
       mov      r10, gword ptr [rdi+0x08]
       mov      r11, bword ptr [rbp-0x1C8]
       mov      r11d, dword ptr [r11+0x0C]
       cmp      r11d, dword ptr [r10+0x08]
       jae      G_M000_IG317
       shl      r11, 4
       lea      r10, bword ptr [r10+r11+0x10]
       mov      r11, gword ptr [r10]
       mov      rax, 0x7F3C798016E8
       cmp      r11, gword ptr [rax]
       je       G_M000_IG308
 
G_M000_IG18:                ;; offset=0x0386
       mov      rax, gword ptr [r10]
       mov      r11, 0x7F3C798016F0
       cmp      rax, gword ptr [r11]
       je       G_M000_IG309
       cmp      qword ptr [r10+0x08], 0
       jne      G_M000_IG310
       mov      rax, gword ptr [r10]
 
G_M000_IG19:                ;; offset=0x03AA
       test     rax, rax
       je       G_M000_IG38
 
G_M000_IG20:                ;; offset=0x03B3
       mov      r10, 0x7F4C232198B0
       cmp      qword ptr [rax], r10
       jne      G_M000_IG38
 
G_M000_IG21:                ;; offset=0x03C6
       mov      gword ptr [rbp-0x1D8], rax
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG38
       cmp      gword ptr [rax+0x30], 0
       je       G_M000_IG38
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG38
       cmp      dword ptr [rax+0x50], 0
       jne      G_M000_IG38
       mov      r10, gword ptr [rax+0x10]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, gword ptr [rsi+0x98]
       cmp      r10, gword ptr [r11+0x88]
       jne      G_M000_IG38
       lea      r10d, [r15+0x03]
       mov      dword ptr [rbp-0x2C], r10d
       mov      rdi, bword ptr [rbp-0x198]
       mov      r11, gword ptr [rdi]
       mov      r11, gword ptr [r11+0x88]
       cmp      r10d, dword ptr [r11+0x08]
       jae      G_M000_IG317
       shl      r10, 5
       lea      r10, bword ptr [r11+r10+0x10]
       mov      bword ptr [rbp-0x1E0], r10
       mov      r10, bword ptr [rbp-0x1E0]
       cmp      dword ptr [r10+0x1C], 47
       sete     r11b
       movzx    r11, r11b
       mov      dword ptr [rbp-0x30], r11d
       xor      r10d, r10d
       mov      qword ptr [rbp-0x38], r10
 
G_M000_IG22:                ;; offset=0x0469
       test     r11d, r11d
       je       G_M000_IG29
 
G_M000_IG23:                ;; offset=0x0472
       mov      r10, gword ptr [rdi+0x08]
       mov      r12, bword ptr [rbp-0x1E0]
       mov      r12d, dword ptr [r12+0x10]
       cmp      r12d, dword ptr [r10+0x08]
       jae      G_M000_IG317
       shl      r12, 4
       lea      r12, bword ptr [r10+r12+0x10]
       mov      r10, gword ptr [r12]
       mov      gword ptr [rbp-0x318], r10
       mov      r10, 0x7F3C798016E8
       mov      rdx, gword ptr [rbp-0x318]
       cmp      rdx, gword ptr [r10]
       jne      G_M000_IG35
 
G_M000_IG24:                ;; offset=0x04BA
       mov      rdx, qword ptr [r12+0x08]
       mov      qword ptr [rbp-0x38], rdx
 
G_M000_IG25:                ;; offset=0x04C3
       mov      rdx, 0xFF80000000000000
       cmp      qword ptr [rbp-0x38], rdx
       jl       G_M000_IG38
       mov      rdx, 0x80000000000000
       cmp      qword ptr [rbp-0x38], rdx
       jge      G_M000_IG38
       mov      rdi, bword ptr [rbp-0x198]
       mov      rdx, gword ptr [rdi]
       mov      rdx, gword ptr [rdx+0x30]
       mov      r12, bword ptr [rbp-0x1E0]
       mov      r10d, dword ptr [r12+0x0C]
       not      r10d
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG317
       mov      rdx, gword ptr [rdx+8*r10+0x10]
       mov      gword ptr [rbp-0x208], rdx
       cmp      qword ptr [rdx], r9
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0523
       mov      rsi, rdx
       mov      rdi, r9
       call     CORINFO_HELP_UNBOX
       mov      rdx, gword ptr [rbp-0x208]
       mov      r9, qword ptr [rbp-0x190]
 
G_M000_IG27:                ;; offset=0x053C
       mov      r10, gword ptr [rdx+0x08]
       mov      edx, dword ptr [rdx+0x10]
       test     r10, r10
       jne      G_M000_IG312
       movsxd   r10, edx
 
G_M000_IG28:                ;; offset=0x054F
       mov      qword ptr [rbp-0x40], r10
       mov      rdi, bword ptr [rbp-0x198]
       mov      r10, qword ptr [rbp-0x40]
 
G_M000_IG29:                ;; offset=0x055E
       xor      r12, r12
       mov      bword ptr [rbp-0x2B0], r12
 
G_M000_IG30:                ;; offset=0x0568
       mov      dword ptr [rbp-0x15C], r12d
 
G_M000_IG31:                ;; offset=0x056F
       mov      gword ptr [rbp-0x1E8], r12
 
G_M000_IG32:                ;; offset=0x0576
       mov      dword ptr [rbp-0x44], r12d
 
G_M000_IG33:                ;; offset=0x057A
       mov      dword ptr [rbp-0x48], r12d
 
G_M000_IG34:                ;; offset=0x057E
       mov      dword ptr [rbp-0x4C], r12d
       jmp      SHORT G_M000_IG40
 
G_M000_IG35:                ;; offset=0x0584
       cmp      qword ptr [r12+0x08], 0
       jg       G_M000_IG311
 
G_M000_IG36:                ;; offset=0x0590
       mov      rdi, gword ptr [r12]
       lea      rsi, [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG37:                ;; offset=0x059E
       test     eax, eax
       mov      r9, qword ptr [rbp-0x190]
       jne      G_M000_IG25
 
G_M000_IG38:                ;; offset=0x05AD
       xor      eax, eax
 
G_M000_IG39:                ;; offset=0x05AF
       vzeroupper 
       add      rsp, 776
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x05C4
       xor      r12, r12
       xor      r11d, r11d
       xor      rdx, rdx
       mov      r8, gword ptr [rbp-0x1B0]
       mov      r8d, dword ptr [r8+0x34]
       mov      r9, gword ptr [rbp-0x1B0]
       cmp      r8d, dword ptr [r9+0x30]
       je       G_M000_IG195
 
G_M000_IG41:                ;; offset=0x05E8
       mov      r8, gword ptr [rbp-0x1B0]
       mov      r8, gword ptr [r8+0x10]
       test     r8, r8
       je       G_M000_IG203
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       mov      bword ptr [rbp-0x2B8], r9
       mov      qword ptr [rbp-0x40], r10
 
G_M000_IG42:                ;; offset=0x060F
       mov      r10, gword ptr [rbp-0x1B0]
       add      r10, 52
       mov      r14d, dword ptr [r10]
       add      r14d, 4
       mov      r9d, dword ptr [r10]
       cmp      r9d, r8d
       ja       G_M000_IG280
       mov      r13d, r9d
       add      r13, bword ptr [rbp-0x2B8]
       sub      r8d, r9d
       cmp      r8d, 4
       jl       G_M000_IG281
       mov      r13d, dword ptr [r13]
       lea      r8d, [r14+r13]
       mov      dword ptr [r10], r8d
       mov      dword ptr [rbp-0x164], r14d
       cmp      r13d, 8
       jg       G_M000_IG55
 
G_M000_IG43:                ;; offset=0x0660
       mov      r11, gword ptr [rbp-0x1B0]
       mov      r8, gword ptr [r11+0x10]
       test     r8, r8
       je       G_M000_IG204
       mov      r9d, r14d
       mov      r10d, r13d
       add      r9, r10
       mov      r10d, dword ptr [r8+0x08]
       cmp      r9, r10
       ja       G_M000_IG280
       mov      r9d, r14d
       lea      r12, bword ptr [r8+r9+0x10]
       mov      r11d, r13d
 
G_M000_IG44:                ;; offset=0x0695
       mov      dword ptr [rbp-0x160], r11d
 
G_M000_IG45:                ;; offset=0x069C
       mov      bword ptr [rbp-0x2B0], r12
       mov      r14d, dword ptr [rbp-0x160]
       mov      dword ptr [rbp-0x15C], r14d
       mov      gword ptr [rbp-0x1F0], rdx
       mov      gword ptr [rbp-0x1E8], rdx
       cmp      dword ptr [rbp-0x48], 0
       je       G_M000_IG68
 
G_M000_IG46:                ;; offset=0x06C9
       mov      dword ptr [rdi+0x18], r15d
 
G_M000_IG47:                ;; offset=0x06CD
       mov      rdx, gword ptr [rbp-0x1F0]
       test     rdx, rdx
       jne      G_M000_IG125
 
G_M000_IG48:                ;; offset=0x06DD
       mov      r8, gword ptr [rbp-0x1B8]
       mov      rdx, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x280], rdx
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rsi+0x98]
       mov      r10, gword ptr [r9+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG246
       mov      r10, gword ptr [r9+0x180]
       test     r10, r10
       jne      G_M000_IG245
 
G_M000_IG49:                ;; offset=0x071F
       mov      rax, gword ptr [rbp-0x1D8]
       mov      r9, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x288], r9
       mov      r10d, dword ptr [rax+0x4C]
       cmp      r10d, 4
       jle      G_M000_IG102
 
G_M000_IG50:                ;; offset=0x073F
       test     r10d, r10d
       je       G_M000_IG274
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x148], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x148], ymm0
       xor      r10d, r10d
 
G_M000_IG51:                ;; offset=0x0763
       mov      dword ptr [rbp-0x14C], r10d
       cmp      r10d, r14d
       jge      G_M000_IG71
 
G_M000_IG52:                ;; offset=0x0773
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, gword ptr [rsi+0x98]
       mov      r13, gword ptr [r11+0x88]
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG265
       mov      r13, gword ptr [r11+0x180]
       test     r13, r13
       jne      G_M000_IG264
 
G_M000_IG53:                ;; offset=0x07A3
       mov      r10d, dword ptr [rbp-0x14C]
       mov      r13d, r14d
       sub      r13d, r10d
       cmp      r13d, 0x1000
       jge      G_M000_IG70
 
G_M000_IG54:                ;; offset=0x07BD
       mov      dword ptr [rbp-0x14C], r10d
       mov      r11d, r10d
       mov      edx, r13d
       add      rdx, r11
       mov      r8d, r14d
       cmp      rdx, r8
       ja       G_M000_IG280
       add      r11, r12
       mov      rsi, r11
       mov      edx, r13d
       lea      rdi, [rbp-0x148]
       call     [System.HashCode:AddBytes(System.ReadOnlySpan`1[byte]):this]
       mov      r10d, dword ptr [rbp-0x14C]
       add      r10d, r13d
       mov      rdx, gword ptr [rbp-0x280]
       jmp      G_M000_IG51
 
G_M000_IG55:                ;; offset=0x0805
       mov      r14d, r13d
       add      r14, 128
       mov      rdx, gword ptr [rbp-0x1B0]
       cmp      r14, qword ptr [rdx+0x28]
       jg       G_M000_IG282
       mov      qword ptr [rbp-0x60], r14
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      rdx, gword ptr [rdx+0x10]
       test     rdx, rdx
       je       G_M000_IG205
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0x160], r11d
 
G_M000_IG56:                ;; offset=0x0846
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x168], edx
       mov      r10, gword ptr [rbp-0x1B0]
       mov      r10, gword ptr [r10+0x08]
       mov      gword ptr [rbp-0x210], r10
       mov      r14, gword ptr [rbp-0x1B0]
       mov      r14, gword ptr [r14+0x20]
       mov      gword ptr [rbp-0x218], r14
       mov      r14, gword ptr [rbp-0x1B0]
       mov      r14, gword ptr [r14+0x18]
       mov      rdi, 0x7F4C22EDFBC0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x220], rax
       mov      dword ptr [rax+0x1C], -1
       mov      esi, r13d
       mov      rdi, 0x7F4C2258CCD0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rsi, rax
       mov      rax, gword ptr [rbp-0x220]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x220]
       mov      dword ptr [rax+0x18], r13d
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, gword ptr [rbp-0x210]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r13, gword ptr [rbp-0x220]
       movzx    rax, byte  ptr [r13+0x24]
       mov      edi, eax
       test     edi, edi
       je       G_M000_IG64
 
G_M000_IG57:                ;; offset=0x08F5
       cmp      edi, 255
       je       G_M000_IG283
       lea      rcx, bword ptr [r13+0x28]
       cmp      eax, 8
       ja       G_M000_IG280
 
G_M000_IG58:                ;; offset=0x090E
       mov      bword ptr [rbp-0x2C0], rcx
       mov      dword ptr [rbp-0x64], eax
       xor      edx, edx
 
G_M000_IG59:                ;; offset=0x091A
       mov      dword ptr [rbp-0x68], edx
       cmp      edx, eax
       jge      G_M000_IG67
 
G_M000_IG60:                ;; offset=0x0925
       test     r14, r14
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x092A
       mov      rdi, gword ptr [r14+0x98]
       mov      rsi, gword ptr [rdi+0x88]
       cmp      gword ptr [rsi+0x20], 0
       jne      G_M000_IG208
       mov      rsi, gword ptr [rdi+0x180]
       test     rsi, rsi
       jne      G_M000_IG207
 
G_M000_IG62:                ;; offset=0x0953
       mov      eax, dword ptr [rbp-0x64]
       mov      edx, dword ptr [rbp-0x68]
       mov      r8d, eax
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG66
 
G_M000_IG63:                ;; offset=0x096C
       mov      edi, edx
       add      edi, dword ptr [rbp-0x164]
       mov      esi, edi
       mov      dword ptr [rbp-0x6C], r8d
       mov      edi, r8d
       lea      r10, [rsi+rdi]
       mov      r11d, dword ptr [rbp-0x168]
       cmp      r10, r11
       ja       G_M000_IG280
       add      rsi, bword ptr [rbp-0x2C8]
       mov      dword ptr [rbp-0x68], edx
       mov      r11d, edx
       lea      r10, [r11+rdi]
       mov      ecx, eax
       cmp      r10, rcx
       ja       G_M000_IG280
       add      r11, bword ptr [rbp-0x2C0]
       mov      rdx, rdi
       mov      rdi, r11
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      edx, dword ptr [rbp-0x6C]
       add      edx, dword ptr [rbp-0x68]
       mov      edi, edx
       mov      edx, edi
       mov      eax, dword ptr [rbp-0x64]
       jmp      G_M000_IG59
 
G_M000_IG64:                ;; offset=0x09D2
       mov      rcx, gword ptr [r13+0x08]
       test     rcx, rcx
       je       G_M000_IG206
       lea      rax, bword ptr [rcx+0x10]
       mov      edi, dword ptr [rcx+0x08]
 
G_M000_IG65:                ;; offset=0x09E6
       mov      rcx, rax
       mov      eax, edi
       jmp      G_M000_IG58
 
G_M000_IG66:                ;; offset=0x09F0
       mov      r8d, 0x1000
       jmp      G_M000_IG63
 
G_M000_IG67:                ;; offset=0x09FB
       mov      eax, dword ptr [rbp-0x64]
       mov      rdi, r13
       mov      esi, eax
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rdx, r13
       mov      rdi, gword ptr [rbp-0x1B0]
       mov      r14, qword ptr [rbp-0x60]
       sub      qword ptr [rdi+0x28], r14
       mov      r14, rdx
       mov      rdx, r14
       mov      rdi, bword ptr [rbp-0x198]
       jmp      G_M000_IG45
 
G_M000_IG68:                ;; offset=0x0A2D
       mov      r13, bword ptr [rbp-0x1C0]
       mov      r8, gword ptr [r13]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rsi+0x98]
       mov      r10, gword ptr [r9+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG210
       mov      r10, gword ptr [r9+0x180]
       test     r10, r10
       jne      G_M000_IG209
 
G_M000_IG69:                ;; offset=0x0A68
       mov      dword ptr [rdi+0x18], r15d
       mov      r8, gword ptr [rbp-0x1B8]
       mov      r9, gword ptr [r8+0x18]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rsi, r9
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x48], 1
       jmp      G_M000_IG47
 
G_M000_IG70:                ;; offset=0x0A9C
       mov      r13d, 0x1000
       jmp      G_M000_IG54
 
G_M000_IG71:                ;; offset=0x0AA7
       mov      r10d, dword ptr [rbp-0x12C]
       mov      r11d, r10d
       and      r11d, 3
       cmp      r10d, 4
       jae      G_M000_IG200
 
G_M000_IG72:                ;; offset=0x0ABF
       mov      r13d, 0x22BE37CA
 
G_M000_IG73:                ;; offset=0x0AC5
       lea      r10d, [r13+4*r10]
       test     r11d, r11d
       je       SHORT G_M000_IG77
 
G_M000_IG74:                ;; offset=0x0ACF
       imul     r13d, dword ptr [rbp-0x138], 0xFFFFFFFFC2B2AE3D
       add      r10d, r13d
       rol      r10d, 17
       imul     r10d, r10d, 0x27D4EB2F
       cmp      r11d, 1
       jbe      SHORT G_M000_IG77
 
G_M000_IG75:                ;; offset=0x0AEE
       imul     r13d, dword ptr [rbp-0x134], 0xFFFFFFFFC2B2AE3D
       add      r13d, r10d
       rol      r13d, 17
       imul     r10d, r13d, 0x27D4EB2F
       cmp      r11d, 2
       jbe      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0B0D
       imul     r11d, dword ptr [rbp-0x130], 0xFFFFFFFFC2B2AE3D
       add      r11d, r10d
       rol      r11d, 17
       imul     r10d, r11d, 0x27D4EB2F
 
G_M000_IG77:                ;; offset=0x0B26
       mov      r11d, r10d
       shr      r11d, 15
       xor      r11d, r10d
       imul     r10d, r11d, 0xFFFFFFFF85EBCA77
       mov      r11d, r10d
       shr      r11d, 13
       xor      r11d, r10d
       imul     r10d, r11d, 0xFFFFFFFFC2B2AE3D
       mov      r11d, r10d
       shr      r11d, 16
       xor      r10d, r11d
       cmp      r10d, -1
       je       G_M000_IG266
 
G_M000_IG78:                ;; offset=0x0B5C
       mov      r11d, r10d
       shr      r11d, 16
       xor      r11d, r10d
       imul     r13d, r11d, 0xFFFFFFFF9E3779B9
       mov      r10d, r13d
       shr      r10d, 16
       xor      r13d, r10d
       mov      r9, gword ptr [rbp-0x288]
       mov      r10d, dword ptr [r9+0x08]
       lea      r11d, [r10-0x01]
       test     r10d, r11d
       jne      G_M000_IG267
       and      r11d, r13d
 
G_M000_IG79:                ;; offset=0x0B92
       cmp      r11d, dword ptr [r9+0x08]
       jae      G_M000_IG288
       mov      r10d, r11d
       lea      r10, [r10+4*r10]
       mov      r10d, dword ptr [r9+8*r10+0x30]
       dec      r10d
       mov      dword ptr [rbp-0xF4], r10d
       test     r10d, r10d
       jl       G_M000_IG274
       jmp      SHORT G_M000_IG82
 
G_M000_IG80:                ;; offset=0x0BBD
       mov      r9, gword ptr [rbp-0x288]
 
G_M000_IG81:                ;; offset=0x0BC4
       mov      r11, bword ptr [rbp-0x308]
       mov      r10d, dword ptr [r11+0x1C]
       dec      r10d
       mov      dword ptr [rbp-0xF4], r10d
       js       G_M000_IG274
 
G_M000_IG82:                ;; offset=0x0BDF
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [r11+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG269
       mov      rdx, gword ptr [r11+0x180]
       test     rdx, rdx
       jne      G_M000_IG268
 
G_M000_IG83:                ;; offset=0x0C0F
       mov      r10d, dword ptr [rbp-0xF4]
       mov      r9, gword ptr [rbp-0x288]
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG288
       mov      edx, r10d
       lea      rdx, [rdx+4*rdx]
       lea      r11, bword ptr [r9+8*rdx+0x10]
       mov      bword ptr [rbp-0x308], r11
       cmp      dword ptr [r11+0x18], r13d
       jne      SHORT G_M000_IG81
 
G_M000_IG84:                ;; offset=0x0C40
       mov      dword ptr [rbp-0xF4], r10d
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG288
       mov      rdx, gword ptr [r9+8*rdx+0x10]
       test     rdx, rdx
       je       G_M000_IG80
 
G_M000_IG85:                ;; offset=0x0C5F
       mov      r8, 0x7F4C22EDFBC0
       cmp      qword ptr [rdx], r8
       jne      G_M000_IG92
 
G_M000_IG86:                ;; offset=0x0C72
       mov      dword ptr [rbp-0x174], r14d
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0x2F0], rax
       mov      ecx, edx
       mov      dword ptr [rbp-0x170], edx
       mov      edi, dword ptr [rbp-0x174]
       cmp      ecx, edi
       jne      G_M000_IG270
       xor      edx, edx
 
G_M000_IG87:                ;; offset=0x0CA1
       mov      dword ptr [rbp-0x150], edx
       cmp      edx, r14d
       jge      G_M000_IG93
 
G_M000_IG88:                ;; offset=0x0CB0
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdi, gword ptr [rsi+0x98]
       mov      r8, gword ptr [rdi+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG272
       mov      r8, gword ptr [rdi+0x180]
       test     r8, r8
       jne      G_M000_IG271
 
G_M000_IG89:                ;; offset=0x0CE0
       mov      edx, dword ptr [rbp-0x150]
       mov      r8d, r14d
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0CF5
       mov      dword ptr [rbp-0x150], edx
       mov      edi, edx
       mov      r9d, r8d
       add      r9, rdi
       mov      r10d, r14d
       cmp      r9, r10
       ja       G_M000_IG280
       lea      r10, bword ptr [r12+rdi]
       mov      r11d, dword ptr [rbp-0x170]
       cmp      r9, r11
       ja       G_M000_IG280
       add      rdi, bword ptr [rbp-0x2F0]
       mov      r9, rdi
       mov      dword ptr [rbp-0x154], r8d
       mov      edx, r8d
       mov      rdi, r10
       mov      rsi, r9
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       test     eax, eax
       je       G_M000_IG273
       mov      edx, dword ptr [rbp-0x154]
       add      edx, dword ptr [rbp-0x150]
       jmp      G_M000_IG87
 
G_M000_IG91:                ;; offset=0x0D5C
       mov      r8d, 0x1000
       jmp      SHORT G_M000_IG90
 
G_M000_IG92:                ;; offset=0x0D64
       mov      r9, gword ptr [rbp-0x288]
       jmp      G_M000_IG81
 
G_M000_IG93:                ;; offset=0x0D70
       mov      r10d, dword ptr [rbp-0xF4]
 
G_M000_IG94:                ;; offset=0x0D77
       test     r10d, r10d
       jl       G_M000_IG275
 
G_M000_IG95:                ;; offset=0x0D80
       mov      rax, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rax+0x28]
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG288
       mov      r9d, r10d
       lea      r9, [r9+4*r9]
       lea      r9, bword ptr [rdx+8*r9+0x10]
       mov      r11, gword ptr [r9]
       mov      rdx, r11
       test     rdx, rdx
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x0DAC
       mov      r14, 0x7F4C22EDFBC0
       cmp      qword ptr [rdx], r14
       jne      G_M000_IG276
 
G_M000_IG97:                ;; offset=0x0DBF
       mov      r14, gword ptr [rbp-0x2A8]
       mov      gword ptr [rsp], r14
       mov      r12d, dword ptr [rbp-0x158]
       mov      dword ptr [rsp+0x08], r12d
       mov      ecx, dword ptr [r9+0x18]
       mov      esi, r10d
       mov      rdi, rax
       mov      r8, gword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateAt(int,Lokad.Lython.Runtime.Text.PyString,uint,System.Object,System.Numerics.BigInteger):bool:this]
 
G_M000_IG98:                ;; offset=0x0DED
       test     eax, eax
       je       G_M000_IG285
 
G_M000_IG99:                ;; offset=0x0DF5
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0DFB
       mov      rdx, qword ptr [rbp-0x40]
       mov      r9, rdx
       add      r9, qword ptr [rbp-0x38]
       mov      qword ptr [rbp-0x38], r9
       mov      dword ptr [rbp-0x44], 1
       mov      r9, 0xFF80000000000000
       cmp      qword ptr [rbp-0x38], r9
       jl       G_M000_IG286
       mov      r9, 0x80000000000000
       cmp      qword ptr [rbp-0x38], r9
       jge      G_M000_IG286
 
G_M000_IG101:                ;; offset=0x0E39
       mov      rdi, bword ptr [rbp-0x198]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      r9, gword ptr [rcx]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [r11+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG278
       mov      rdx, gword ptr [r11+0x180]
       test     rdx, rdx
       mov      gword ptr [rbp-0x2F8], rdx
       mov      gword ptr [rbp-0x2A0], r9
       mov      rdi, bword ptr [rbp-0x198]
       jne      G_M000_IG277
       mov      r10, qword ptr [rbp-0x40]
       jmp      G_M000_IG40
 
G_M000_IG102:                ;; offset=0x0E9B
       xor      edx, edx
       test     r10d, r10d
       jle      G_M000_IG274
       jmp      G_M000_IG110
 
G_M000_IG103:                ;; offset=0x0EAB
       lea      r13, bword ptr [r11+0x28]
       mov      r11d, dword ptr [r11+0x18]
       cmp      r11d, 8
       ja       G_M000_IG280
 
G_M000_IG104:                ;; offset=0x0EBD
       cmp      r14d, r11d
       jne      SHORT G_M000_IG109
 
G_M000_IG105:                ;; offset=0x0EC2
       mov      bword ptr [rbp-0x298], r12
       mov      r8, r13
       mov      r11d, r11d
       cmp      r11, 8
       jae      G_M000_IG118
 
G_M000_IG106:                ;; offset=0x0ED9
       cmp      r11, 4
       jb       G_M000_IG249
 
G_M000_IG107:                ;; offset=0x0EE3
       add      r11, -4
       mov      qword ptr [rbp-0x118], r11
       mov      r8d, dword ptr [r12]
       sub      r8d, dword ptr [r13]
       mov      dword ptr [rbp-0x30C], r8d
       mov      r11d, dword ptr [r12+r11]
       mov      r8, qword ptr [rbp-0x118]
       sub      r11d, dword ptr [r8+r13]
       or       r11d, dword ptr [rbp-0x30C]
       sete     r8b
       movzx    r8, r8b
 
G_M000_IG108:                ;; offset=0x0F1B
       test     r8d, r8d
       jne      G_M000_IG124
 
G_M000_IG109:                ;; offset=0x0F24
       inc      edx
       cmp      edx, r10d
       jge      G_M000_IG274
 
G_M000_IG110:                ;; offset=0x0F2F
       mov      r9, gword ptr [rbp-0x288]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG288
       lea      r11, [rdx+4*rdx]
       mov      r11, gword ptr [r9+8*r11+0x10]
       test     r11, r11
       je       SHORT G_M000_IG109
 
G_M000_IG111:                ;; offset=0x0F4E
       mov      r13, 0x7F4C22EDFBC0
       cmp      qword ptr [r11], r13
       jne      SHORT G_M000_IG109
 
G_M000_IG112:                ;; offset=0x0F5D
       movzx    r13, byte  ptr [r11+0x24]
       test     r13d, r13d
       je       G_M000_IG116
 
G_M000_IG113:                ;; offset=0x0F6B
       cmp      r13d, 255
       jne      G_M000_IG103
 
G_M000_IG114:                ;; offset=0x0F78
       mov      r13, gword ptr [r11+0x08]
       mov      gword ptr [rbp-0x290], r13
       lea      r13, bword ptr [r11+0x28]
       mov      r13d, dword ptr [r13]
       mov      r11d, dword ptr [r11+0x18]
       mov      dword ptr [rbp-0xF8], r11d
       cmp      gword ptr [rbp-0x290], 0
       je       G_M000_IG248
       mov      qword ptr [rbp-0x188], r13
       mov      r13d, r11d
       add      r13, qword ptr [rbp-0x188]
       mov      qword ptr [rbp-0x320], r13
       mov      r13, gword ptr [rbp-0x290]
       mov      r13d, dword ptr [r13+0x08]
       cmp      qword ptr [rbp-0x320], r13
       ja       G_M000_IG280
       mov      r13, gword ptr [rbp-0x290]
       mov      r11, qword ptr [rbp-0x188]
       lea      r13, bword ptr [r13+r11+0x10]
       mov      r11d, dword ptr [rbp-0xF8]
 
G_M000_IG115:                ;; offset=0x0FEE
       jmp      G_M000_IG104
 
G_M000_IG116:                ;; offset=0x0FF3
       mov      r13, gword ptr [r11+0x08]
       mov      r11d, dword ptr [r11+0x18]
       test     r13, r13
       je       G_M000_IG247
       cmp      dword ptr [r13+0x08], r11d
       jb       G_M000_IG280
       add      r13, 16
 
G_M000_IG117:                ;; offset=0x1012
       jmp      G_M000_IG104
 
G_M000_IG118:                ;; offset=0x1017
       mov      bword ptr [rbp-0x2E8], r13
       mov      r13, bword ptr [rbp-0x298]
       cmp      r13, r8
       je       G_M000_IG262
 
G_M000_IG119:                ;; offset=0x102E
       cmp      r11, 32
       jae      G_M000_IG254
 
G_M000_IG120:                ;; offset=0x1038
       cmp      r11, 16
       jae      G_M000_IG257
 
G_M000_IG121:                ;; offset=0x1042
       add      r11, -8
       mov      qword ptr [rbp-0x100], r11
       mov      r8, qword ptr [r12]
       mov      r13, bword ptr [rbp-0x2E8]
       sub      r8, qword ptr [r13]
       mov      qword ptr [rbp-0x320], r8
       mov      r11, qword ptr [r12+r11]
       mov      r8, qword ptr [rbp-0x100]
       sub      r11, qword ptr [r8+r13]
       or       r11, qword ptr [rbp-0x320]
       sete     r8b
       movzx    r8, r8b
       jmp      G_M000_IG108
 
G_M000_IG122:                ;; offset=0x1086
       add      r13, 32
       cmp      qword ptr [rbp-0x110], r13
       jbe      G_M000_IG256
 
G_M000_IG123:                ;; offset=0x1097
       vmovups  ymm0, ymmword ptr [r12+r13]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+r13]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       jne      G_M000_IG263
       jmp      SHORT G_M000_IG122
 
G_M000_IG124:                ;; offset=0x10B3
       mov      r10d, edx
       jmp      G_M000_IG94
 
G_M000_IG125:                ;; offset=0x10BB
       mov      gword ptr [rbp-0x200], rdx
       mov      r14, gword ptr [rbp-0x2A8]
       mov      gword ptr [rbp-0x2D0], r14
       mov      r12d, dword ptr [rbp-0x158]
       mov      edx, r12d
       mov      r8, gword ptr [rbp-0x1B8]
       mov      r11, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x228], r11
       mov      rax, gword ptr [rbp-0x1D8]
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG223
       mov      r11, gword ptr [rbp-0x228]
       cmp      gword ptr [rax+0x30], 0
       je       G_M000_IG223
       cmp      dword ptr [rax+0x50], 0
       jne      G_M000_IG223
       mov      r13, gword ptr [rax+0x10]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r10, gword ptr [rsi+0x98]
       cmp      r13, gword ptr [r10+0x88]
       jne      G_M000_IG211
       test     edx, edx
       je       G_M000_IG133
 
G_M000_IG126:                ;; offset=0x1141
       mov      r13, gword ptr [rbp-0x2D0]
       test     r13, r13
       jne      G_M000_IG213
       test     edx, edx
       jl       G_M000_IG212
       xor      r10d, r10d
 
G_M000_IG127:                ;; offset=0x115C
       movsxd   rdx, edx
 
G_M000_IG128:                ;; offset=0x115F
       mov      dword ptr [rbp-0x74], r10d
       test     r10d, r10d
       jne      G_M000_IG217
       xor      r10d, r10d
       lzcnt    r10, rdx
       shr      r10d, 3
       neg      r10d
       add      r10d, 7
       test     r10d, r10d
       jg       G_M000_IG216
 
G_M000_IG129:                ;; offset=0x1188
       xor      r10d, r10d
 
G_M000_IG130:                ;; offset=0x118B
       lea      r13d, [8*r10]
       shrx     rdx, rdx, r13
       movzx    rdx, dl
       and      edx, 128
       mov      r13d, dword ptr [rbp-0x74]
       and      r13d, 128
       cmp      edx, r13d
       jne      G_M000_IG220
       xor      edx, edx
 
G_M000_IG131:                ;; offset=0x11B7
       test     edx, edx
       setne    dl
       movzx    rdx, dl
       lea      edx, [r10+rdx+0x01]
       mov      r13, gword ptr [rbp-0x2D0]
       test     r13, r13
       jne      G_M000_IG221
 
G_M000_IG132:                ;; offset=0x11D4
       cmp      edx, 8
       jge      G_M000_IG222
 
G_M000_IG133:                ;; offset=0x11DD
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdx, gword ptr [rsi+0x98]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG225
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       jne      G_M000_IG224
 
G_M000_IG134:                ;; offset=0x120D
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdx, gword ptr [rsi+0x98]
       mov      r13, gword ptr [rdx+0x180]
       mov      r9, gword ptr [rbp-0x200]
       cmp      byte  ptr [r9+0x25], 0
       jne      G_M000_IG162
 
G_M000_IG135:                ;; offset=0x1234
       mov      rdi, r9
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      bword ptr [rbp-0x2E0], rax
       mov      ecx, edx
       mov      dword ptr [rbp-0x16C], edx
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       test     r13, r13
       jne      G_M000_IG226
 
G_M000_IG136:                ;; offset=0x1261
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       xor      r8d, r8d
       test     ecx, ecx
       je       SHORT G_M000_IG142
 
G_M000_IG137:                ;; offset=0x1274
       test     r13, r13
       jne      G_M000_IG227
 
G_M000_IG138:                ;; offset=0x127D
       mov      r9d, ecx
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jge      SHORT G_M000_IG141
 
G_M000_IG139:                ;; offset=0x128C
       mov      dword ptr [rbp-0x9C], r8d
       mov      esi, r8d
       mov      edx, r9d
       add      rdx, rsi
       mov      edi, ecx
       cmp      rdx, rdi
       ja       G_M000_IG280
       add      rsi, rax
       mov      dword ptr [rbp-0xA0], r9d
       mov      edx, r9d
       lea      rdi, [rbp-0x98]
       call     [System.HashCode:AddBytes(System.ReadOnlySpan`1[byte]):this]
       mov      r8d, dword ptr [rbp-0x9C]
       add      r8d, dword ptr [rbp-0xA0]
       mov      eax, dword ptr [rbp-0x16C]
       cmp      r8d, eax
       mov      ecx, eax
       jge      SHORT G_M000_IG142
 
G_M000_IG140:                ;; offset=0x12DC
       mov      rax, bword ptr [rbp-0x2E0]
       jmp      SHORT G_M000_IG137
 
G_M000_IG141:                ;; offset=0x12E5
       mov      r9d, 0x1000
       jmp      SHORT G_M000_IG139
 
G_M000_IG142:                ;; offset=0x12ED
       mov      eax, dword ptr [rbp-0x7C]
       mov      edx, eax
       and      edx, 3
       cmp      eax, 4
       jae      G_M000_IG161
 
G_M000_IG143:                ;; offset=0x12FE
       mov      edi, 0x22BE37CA
 
G_M000_IG144:                ;; offset=0x1303
       lea      eax, [rdi+4*rax]
       test     edx, edx
       je       SHORT G_M000_IG148
 
G_M000_IG145:                ;; offset=0x130A
       imul     edi, dword ptr [rbp-0x88], 0xFFFFFFFFC2B2AE3D
       add      eax, edi
       rol      eax, 17
       imul     eax, eax, 0x27D4EB2F
       cmp      edx, 1
       jbe      SHORT G_M000_IG148
 
G_M000_IG146:                ;; offset=0x1324
       imul     edi, dword ptr [rbp-0x84], 0xFFFFFFFFC2B2AE3D
       add      edi, eax
       rol      edi, 17
       imul     eax, edi, 0x27D4EB2F
       cmp      edx, 2
       jbe      SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x133E
       imul     edx, dword ptr [rbp-0x80], 0xFFFFFFFFC2B2AE3D
       add      edx, eax
       rol      edx, 17
       imul     eax, edx, 0x27D4EB2F
 
G_M000_IG148:                ;; offset=0x1350
       mov      edx, eax
       shr      edx, 15
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFF85EBCA77
       mov      edx, eax
       shr      edx, 13
       xor      edx, eax
       imul     eax, edx, 0xFFFFFFFFC2B2AE3D
       mov      edx, eax
       shr      edx, 16
       xor      edx, eax
       mov      r13, gword ptr [rbp-0x200]
       mov      dword ptr [r13+0x20], edx
       mov      byte  ptr [r13+0x25], 1
 
G_M000_IG149:                ;; offset=0x1381
       cmp      edx, -1
       je       G_M000_IG228
 
G_M000_IG150:                ;; offset=0x138A
       mov      r9d, edx
       shr      r9d, 16
       xor      r9d, edx
       imul     r9d, r9d, 0xFFFFFFFF9E3779B9
       mov      r10d, r9d
       shr      r10d, 16
       xor      r9d, r10d
       mov      dword ptr [rbp-0x70], r9d
       mov      rax, gword ptr [rbp-0x1D8]
       mov      r10, gword ptr [rax+0x28]
       mov      gword ptr [rbp-0x230], r10
       cmp      dword ptr [rax+0x4C], 0
       je       G_M000_IG188
 
G_M000_IG151:                ;; offset=0x13C5
       mov      edx, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x17C], edx
       mov      r11d, edx
       lea      r9d, [r11-0x01]
       test     r11d, r9d
       jne      G_M000_IG229
       mov      r11d, dword ptr [rbp-0x70]
       and      r9d, r11d
 
G_M000_IG152:                ;; offset=0x13E6
       mov      edx, dword ptr [rbp-0x17C]
       cmp      r9d, edx
       jae      G_M000_IG288
       mov      r9d, r9d
       lea      r9, [r9+4*r9]
       mov      r9d, dword ptr [r10+8*r9+0x30]
       dec      r9d
       js       G_M000_IG188
 
G_M000_IG153:                ;; offset=0x140A
       cmp      r9d, edx
       jae      G_M000_IG288
       mov      r11d, r9d
       lea      r11, [r11+4*r11]
       lea      r11, bword ptr [r10+8*r11+0x10]
       mov      bword ptr [rbp-0x238], r11
       mov      rax, gword ptr [rbp-0x1D8]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG230
 
G_M000_IG154:                ;; offset=0x1438
       mov      r11, bword ptr [rbp-0x238]
       mov      edx, dword ptr [rbp-0x70]
       cmp      dword ptr [r11+0x18], edx
       jne      G_M000_IG186
 
G_M000_IG155:                ;; offset=0x144C
       mov      rdx, 0x7F3C79800DD8
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rbp-0x240], rdx
       mov      rdx, gword ptr [r11]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x248], rsi
       mov      r11, gword ptr [rbp-0x228]
       test     r11, r11
       mov      rsi, gword ptr [rbp-0x1A0]
       je       G_M000_IG232
 
G_M000_IG156:                ;; offset=0x1488
       cmp      rdx, r13
       je       G_M000_IG175
 
G_M000_IG157:                ;; offset=0x1491
       test     rdx, rdx
       mov      gword ptr [rbp-0x250], r11
       jne      SHORT G_M000_IG163
 
G_M000_IG158:                ;; offset=0x149D
       mov      r11, rdx
       test     r11, r11
       je       G_M000_IG166
 
G_M000_IG159:                ;; offset=0x14A9
       mov      dword ptr [rbp-0xA8], r9d
       mov      r9, 0x7F4C23576468
       cmp      qword ptr [r11], r9
       je       G_M000_IG165
 
G_M000_IG160:                ;; offset=0x14C3
       xor      r11, r11
       xor      r9, r9
       mov      r11, r9
       mov      r9d, dword ptr [rbp-0xA8]
       jmp      G_M000_IG166
 
G_M000_IG161:                ;; offset=0x14D8
       rorx     edi, dword ptr [rbp-0x98], 31
       rorx     esi, dword ptr [rbp-0x94], 25
       add      edi, esi
       rorx     esi, dword ptr [rbp-0x90], 20
       add      edi, esi
       rorx     esi, dword ptr [rbp-0x8C], 14
       add      edi, esi
       jmp      G_M000_IG144
 
G_M000_IG162:                ;; offset=0x150B
       mov      edx, dword ptr [r9+0x20]
       mov      r13, r9
       jmp      G_M000_IG149
 
G_M000_IG163:                ;; offset=0x1517
       mov      r11, 0x7F4C22EDFBC0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG158
 
G_M000_IG164:                ;; offset=0x152A
       mov      dword ptr [rbp-0xA8], r9d
       mov      rdi, rdx
       mov      rsi, r13
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, gword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       jmp      G_M000_IG174
 
G_M000_IG165:                ;; offset=0x1550
       mov      r9d, dword ptr [rbp-0xA8]
 
G_M000_IG166:                ;; offset=0x1557
       mov      gword ptr [rbp-0x258], r11
       test     r11, r11
       mov      dword ptr [rbp-0xA8], r9d
       je       G_M000_IG185
 
G_M000_IG167:                ;; offset=0x156E
       mov      r9, r13
       mov      r11, 0x7F4C23576468
       cmp      qword ptr [r9], r11
       je       SHORT G_M000_IG169
 
G_M000_IG168:                ;; offset=0x1580
       xor      r9, r9
 
G_M000_IG169:                ;; offset=0x1583
       mov      gword ptr [rbp-0x260], r9
       test     r9, r9
       je       G_M000_IG184
 
G_M000_IG170:                ;; offset=0x1593
       mov      r9, gword ptr [rbp-0x260]
       mov      rdx, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x268], rdx
       mov      r11, gword ptr [rbp-0x250]
       test     r11, r11
       jne      SHORT G_M000_IG173
 
G_M000_IG171:                ;; offset=0x15B4
       mov      rdi, 0x7F4CA06F53F0
       mov      r11, 0x7F4CA0DD5810
       call     r11
       cmp      dword ptr [rax], 12
       jle      G_M000_IG233
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x60]
       test     rax, rax
       je       G_M000_IG233
 
G_M000_IG172:                ;; offset=0x15E5
       mov      r11, gword ptr [rax+0x20]
       mov      r9, gword ptr [rbp-0x260]
 
G_M000_IG173:                ;; offset=0x15F0
       mov      rdi, gword ptr [rbp-0x258]
       mov      rsi, r9
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+RePatternObject:HasSameProgram(Lokad.Lython.Runtime.LythonRuntime+RePatternObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG174:                ;; offset=0x160A
       test     eax, eax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      r9d, dword ptr [rbp-0xA8]
       mov      r11, bword ptr [rbp-0x238]
       je       G_M000_IG186
 
G_M000_IG175:                ;; offset=0x1627
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      edx, r9d
 
G_M000_IG176:                ;; offset=0x1631
       mov      dword ptr [rbp-0xA4], edx
       mov      r10d, edx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       test     r10d, r10d
       jl       G_M000_IG189
 
G_M000_IG177:                ;; offset=0x164F
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG236
       mov      r11, gword ptr [rax+0x30]
       cmp      r10d, dword ptr [r11+0x08]
       jae      G_M000_IG288
       mov      r9d, r10d
       cmp      gword ptr [r11+8*r9+0x10], 0
       jne      G_M000_IG236
 
G_M000_IG178:                ;; offset=0x1677
       mov      r11, gword ptr [rax+0x28]
       cmp      r10d, dword ptr [r11+0x08]
       jae      G_M000_IG288
       lea      r9, [r9+4*r9]
       mov      r9, qword ptr [r11+8*r9+0x20]
       mov      r11, 0xFF80000000000000
       cmp      r9, r11
       jl       G_M000_IG194
       mov      r11, 0x80000000000000
       cmp      r9, r11
       mov      dword ptr [rbp-0xAC], r10d
       mov      qword ptr [rbp-0xC8], r9
       jge      G_M000_IG194
 
G_M000_IG179:                ;; offset=0x16C2
       mov      rdi, r14
       mov      esi, r12d
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       add      rax, qword ptr [rbp-0xC8]
       mov      qword ptr [rbp-0xD0], rax
       mov      r10, gword ptr [rbp-0x1D8]
       mov      r11d, dword ptr [r10+0x4C]
       mov      dword ptr [rbp-0xD4], r11d
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG244
       mov      r9d, dword ptr [rbp-0xAC]
       test     r9d, r9d
       jl       G_M000_IG192
 
G_M000_IG180:                ;; offset=0x1709
       mov      rdi, gword ptr [r10+0x28]
       cmp      r9d, dword ptr [rdi+0x08]
       jae      G_M000_IG288
       mov      esi, r9d
       lea      rcx, [rsi+4*rsi]
       mov      rax, qword ptr [rbp-0xD0]
       mov      qword ptr [rdi+8*rcx+0x20], rax
       mov      rdi, gword ptr [r10+0x30]
       cmp      r9d, dword ptr [rdi+0x08]
       jae      G_M000_IG288
       xor      rax, rax
       mov      gword ptr [rdi+8*rsi+0x10], rax
 
G_M000_IG181:                ;; offset=0x173F
       mov      r10, gword ptr [rbp-0x1D8]
       mov      r11d, dword ptr [rbp-0xD4]
       cmp      dword ptr [r10+0x4C], r11d
       jne      G_M000_IG193
 
G_M000_IG182:                ;; offset=0x1757
       mov      eax, 1
 
G_M000_IG183:                ;; offset=0x175C
       jmp      G_M000_IG98
 
G_M000_IG184:                ;; offset=0x1761
 
G_M000_IG185:                ;; offset=0x1761
       mov      rdi, gword ptr [rbp-0x240]
       mov      rsi, rdx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      G_M000_IG174
 
G_M000_IG186:                ;; offset=0x1779
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x228]
       mov      rdx, r9
       test     rdx, rdx
       je       G_M000_IG234
 
G_M000_IG187:                ;; offset=0x1793
       mov      rdi, rsi
       mov      rsi, rdx
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rdi, bword ptr [rbp-0x238]
       mov      r9d, dword ptr [rdi+0x1C]
       dec      r9d
       mov      eax, r9d
       test     eax, eax
       mov      r9d, eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      r10, gword ptr [rbp-0x230]
       jge      G_M000_IG153
 
G_M000_IG188:                ;; offset=0x17C8
       mov      edx, -1
       mov      rax, gword ptr [rbp-0x1D8]
       mov      rsi, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG176
 
G_M000_IG189:                ;; offset=0x17E0
       cmp      gword ptr [rax+0x20], 0
       jne      SHORT G_M000_IG194
       mov      r11d, dword ptr [rax+0x4C]
       mov      rdx, gword ptr [rax+0x28]
       cmp      r11d, dword ptr [rdx+0x08]
       je       G_M000_IG235
 
G_M000_IG190:                ;; offset=0x17F9
       mov      r11, gword ptr [rbp-0x1D0]
       mov      rdx, r11
 
G_M000_IG191:                ;; offset=0x1803
       test     rdx, rdx
       jne      G_M000_IG238
       jmp      G_M000_IG237
 
G_M000_IG192:                ;; offset=0x1811
       mov      r9d, dword ptr [r10+0x4C]
       mov      dword ptr [rbp-0xAC], r9d
       mov      rdx, 0x7F3C79800B58
       mov      rdx, gword ptr [rdx]
       mov      rdi, r10
       mov      rsi, r13
       mov      ecx, dword ptr [rbp-0x70]
       xor      r8d, r8d
       xor      r9, r9
       call     [Lokad.Lython.Runtime.PyDict:AppendNativeItem(System.Object,System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      r9d, dword ptr [rbp-0xAC]
       mov      r10, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG180
 
G_M000_IG193:                ;; offset=0x1851
       inc      dword ptr [r10+0x48]
       mov      r10, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG182
 
G_M000_IG194:                ;; offset=0x1861
       xor      edx, edx
       mov      r10, rax
       mov      eax, edx
       jmp      G_M000_IG183
 
G_M000_IG195:                ;; offset=0x186D
       mov      dword ptr [rbp-0x4C], 1
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      eax, dword ptr [rcx+0x1C]
       cmp      eax, 51
       jg       SHORT G_M000_IG201
 
G_M000_IG196:                ;; offset=0x1883
       cmp      eax, 41
       je       SHORT G_M000_IG198
 
G_M000_IG197:                ;; offset=0x1888
       add      eax, -49
       cmp      eax, 2
       ja       G_M000_IG287
 
G_M000_IG198:                ;; offset=0x1894
       mov      eax, dword ptr [rcx+0x08]
       mov      dword ptr [rdi+0x18], eax
 
G_M000_IG199:                ;; offset=0x189A
       mov      dword ptr [rbp-0x50], 1
       jmp      G_M000_IG290
 
G_M000_IG200:                ;; offset=0x18A6
       rorx     r13d, dword ptr [rbp-0x148], 31
       mov      dword ptr [rbp-0x30C], r13d
       rorx     r13d, dword ptr [rbp-0x144], 25
       add      r13d, dword ptr [rbp-0x30C]
       mov      dword ptr [rbp-0x30C], r13d
       rorx     r13d, dword ptr [rbp-0x140], 20
       add      r13d, dword ptr [rbp-0x30C]
       mov      dword ptr [rbp-0x30C], r13d
       rorx     r13d, dword ptr [rbp-0x13C], 14
       add      r13d, dword ptr [rbp-0x30C]
       jmp      G_M000_IG73
 
G_M000_IG201:                ;; offset=0x18FD
       cmp      eax, 56
       je       SHORT G_M000_IG198
 
G_M000_IG202:                ;; offset=0x1902
       cmp      eax, 62
       je       SHORT G_M000_IG198
       add      eax, -68
       cmp      eax, 1
       ja       G_M000_IG287
       jmp      G_M000_IG198
 
G_M000_IG203:                ;; offset=0x1918
       xor      r9, r9
       mov      bword ptr [rbp-0x2B8], r9
       xor      r8d, r8d
       mov      qword ptr [rbp-0x40], r10
       jmp      G_M000_IG42
 
G_M000_IG204:                ;; offset=0x192E
       or       r14d, r13d
       jne      G_M000_IG280
       xor      r12, r12
       xor      r11d, r11d
       jmp      G_M000_IG44
 
G_M000_IG205:                ;; offset=0x1942
       xor      r9, r9
       xor      edx, edx
       mov      dword ptr [rbp-0x160], r11d
       jmp      G_M000_IG56
 
G_M000_IG206:                ;; offset=0x1953
       xor      rax, rax
       xor      edi, edi
       jmp      G_M000_IG65
 
G_M000_IG207:                ;; offset=0x195C
       cmp      dword ptr [rsi+0x20], 0
       setne    sil
       movzx    rsi, sil
       test     esi, esi
       je       G_M000_IG62
 
G_M000_IG208:                ;; offset=0x1970
       mov      rsi, gword ptr [rbp-0x218]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG62
 
G_M000_IG209:                ;; offset=0x1982
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG69
 
G_M000_IG210:                ;; offset=0x1998
       mov      rdi, r9
       mov      rsi, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x198]
       jmp      G_M000_IG69
 
G_M000_IG211:                ;; offset=0x19B0
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG223
 
G_M000_IG212:                ;; offset=0x19BC
       mov      r10d, 255
       jmp      G_M000_IG127
 
G_M000_IG213:                ;; offset=0x19C7
       cmp      edx, -1
       jne      SHORT G_M000_IG215
       mov      dword ptr [rbp-0x74], 255
       lea      rdx, bword ptr [r13+0x10]
       mov      bword ptr [rbp-0x2D8], rdx
       mov      edx, dword ptr [r13+0x08]
       mov      rdi, bword ptr [rbp-0x2D8]
       xor      esi, esi
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      edi, dword ptr [r13+0x08]
       dec      edi
       cmp      edi, dword ptr [r13+0x08]
       jae      G_M000_IG288
       mov      edi, dword ptr [r13+0x08]
       dec      edi
       mov      rdi, qword ptr [r13+8*rdi+0x10]
       mov      rdx, rdi
       not      rdx
       mov      edi, dword ptr [r13+0x08]
       dec      edi
       cmp      edi, eax
       jne      SHORT G_M000_IG214
       inc      rdx
       mov      r10d, dword ptr [rbp-0x74]
       mov      r11, gword ptr [rbp-0x228]
       jmp      G_M000_IG128
 
G_M000_IG214:                ;; offset=0x1A2F
       mov      r10d, dword ptr [rbp-0x74]
       mov      r11, gword ptr [rbp-0x228]
       jmp      G_M000_IG128
 
G_M000_IG215:                ;; offset=0x1A3F
       xor      r10d, r10d
       mov      edx, dword ptr [r13+0x08]
       dec      edx
       cmp      edx, dword ptr [r13+0x08]
       jae      G_M000_IG288
       mov      edx, dword ptr [r13+0x08]
       dec      edx
       mov      rdx, qword ptr [r13+8*rdx+0x10]
       mov      r13, gword ptr [rbp-0x2D0]
       jmp      G_M000_IG128
 
G_M000_IG216:                ;; offset=0x1A69
       jmp      G_M000_IG130
 
G_M000_IG217:                ;; offset=0x1A6E
       mov      r10, rdx
       not      r10
       lzcnt    r10, r10
       shr      r10d, 3
       neg      r10d
       add      r10d, 7
       test     r10d, r10d
       jle      SHORT G_M000_IG218
       jmp      SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x1A8B
       xor      r10d, r10d
 
G_M000_IG219:                ;; offset=0x1A8E
       jmp      G_M000_IG130
 
G_M000_IG220:                ;; offset=0x1A93
       mov      edx, 1
       jmp      G_M000_IG131
 
G_M000_IG221:                ;; offset=0x1A9D
       mov      r10d, dword ptr [r13+0x08]
       sub      r10d, 1
       imul     r10d, r10d, 8
       jo       G_M000_IG289
       add      edx, r10d
       jo       G_M000_IG289
       jmp      G_M000_IG132
 
G_M000_IG222:                ;; offset=0x1ABD
       mov      rax, gword ptr [rbp-0x1D8]
 
G_M000_IG223:                ;; offset=0x1AC4
       xor      edx, edx
       mov      r10, rax
       mov      eax, edx
       jmp      G_M000_IG183
 
G_M000_IG224:                ;; offset=0x1AD0
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG134
 
G_M000_IG225:                ;; offset=0x1AE6
       mov      rdi, rdx
       mov      rsi, r11
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r11, gword ptr [rbp-0x228]
       jmp      G_M000_IG134
 
G_M000_IG226:                ;; offset=0x1AFE
       cmp      dword ptr [r13+0x20], 0
       je       G_M000_IG136
       jmp      G_M000_IG284
 
G_M000_IG227:                ;; offset=0x1B0E
       cmp      dword ptr [r13+0x20], 0
       je       G_M000_IG138
       jmp      G_M000_IG284
 
G_M000_IG228:                ;; offset=0x1B1E
       mov      edx, -2
       jmp      G_M000_IG150
 
G_M000_IG229:                ;; offset=0x1B28
       mov      eax, dword ptr [rbp-0x70]
       xor      edx, edx
       div      edx:eax, r11d
       mov      r9d, edx
       mov      r11d, dword ptr [rbp-0x70]
       jmp      G_M000_IG152
 
G_M000_IG230:                ;; offset=0x1B3C
       mov      rdx, gword ptr [rax+0x30]
       cmp      dword ptr [rdx+0x08], r9d
       jbe      SHORT G_M000_IG231
       mov      rdx, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x300], rdx
       cmp      r9d, dword ptr [rdx+0x08]
       jae      G_M000_IG288
       mov      dword ptr [rbp-0xA8], r9d
       mov      edx, r9d
       mov      r11, gword ptr [rbp-0x300]
       cmp      gword ptr [r11+8*rdx+0x10], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       mov      r9d, dword ptr [rbp-0xA8]
       jne      G_M000_IG154
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, bword ptr [rbp-0x238]
       jmp      G_M000_IG186
 
G_M000_IG231:                ;; offset=0x1B9A
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r11, bword ptr [rbp-0x238]
       jmp      G_M000_IG186
 
G_M000_IG232:                ;; offset=0x1BAD
       mov      r11, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x250], r11
       mov      rax, gword ptr [rbp-0x1D8]
       mov      r11, gword ptr [rbp-0x250]
       jmp      G_M000_IG156
 
G_M000_IG233:                ;; offset=0x1BCB
       mov      edi, 12
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       jmp      G_M000_IG172
 
G_M000_IG234:                ;; offset=0x1BDB
       mov      rdx, gword ptr [rax+0x18]
       jmp      G_M000_IG187
 
G_M000_IG235:                ;; offset=0x1BE4
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG194
 
G_M000_IG236:                ;; offset=0x1BF0
       mov      rdi, rax
       mov      dword ptr [rbp-0xAC], r10d
       mov      esi, r10d
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      rdx, rax
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      r10d, dword ptr [rbp-0xAC]
       jmp      G_M000_IG191
 
G_M000_IG237:                ;; offset=0x1C19
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG194
 
G_M000_IG238:                ;; offset=0x1C25
       mov      gword ptr [rbp-0x270], rdx
       mov      rdx, qword ptr [rdx]
       mov      r9, qword ptr [rbp-0x190]
       cmp      rdx, r9
       mov      dword ptr [rbp-0xAC], r10d
       je       SHORT G_M000_IG240
 
G_M000_IG239:                ;; offset=0x1C42
       mov      rax, gword ptr [rbp-0x1D8]
       jmp      G_M000_IG194
 
G_M000_IG240:                ;; offset=0x1C4E
       mov      rdx, gword ptr [rbp-0x270]
       vmovdqu  xmm0, xmmword ptr [rdx+0x08]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG241:                ;; offset=0x1C62
       xor      edx, edx
       mov      dword ptr [rbp-0xF0], edx
       lea      rdx, [rbp-0xF0]
       mov      qword ptr [rsp], rdx
       lea      rdi, [rbp-0xC0]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      esi, 1
       xor      r8d, r8d
       xor      r9d, r9d
       call     [System.Numerics.BigInteger:TryGetBytes(int,System.Span`1[byte],bool,bool,byref):byte[]:this]
       cmp      dword ptr [rbp-0xF0], 8
       jl       SHORT G_M000_IG243
 
G_M000_IG242:                ;; offset=0x1C9A
       mov      rax, gword ptr [rbp-0x1D8]
       mov      rsi, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG194
 
G_M000_IG243:                ;; offset=0x1CAD
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, qword ptr [rbp-0xB8]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xC8], rax
       jmp      G_M000_IG179
 
G_M000_IG244:                ;; offset=0x1CCD
       mov      rax, qword ptr [rbp-0xD0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
       lea      rdi, [rbp-0xE8]
       mov      rsi, rax
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, qword ptr [rbp-0x190]
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x278], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0xE8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0xE0]
       mov      rdi, gword ptr [rbp-0x278]
       mov      dword ptr [rdi+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, rdi
       mov      rdi, gword ptr [rbp-0x1D8]
       mov      esi, dword ptr [rbp-0xA4]
       mov      rdx, r13
       mov      r8d, dword ptr [rbp-0x70]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG181
 
G_M000_IG245:                ;; offset=0x1D4F
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG49
 
G_M000_IG246:                ;; offset=0x1D65
       mov      rdi, r9
       mov      rsi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp-0x280]
       jmp      G_M000_IG49
 
G_M000_IG247:                ;; offset=0x1D7D
       test     r11d, r11d
       jne      G_M000_IG280
       xor      r13, r13
       xor      r11d, r11d
       jmp      G_M000_IG117
 
G_M000_IG248:                ;; offset=0x1D91
       or       r13d, r11d
       jne      G_M000_IG280
       xor      r13, r13
       xor      r11d, r11d
       jmp      G_M000_IG115
 
G_M000_IG249:                ;; offset=0x1DA5
       xor      r8d, r8d
       mov      dword ptr [rbp-0x11C], r8d
       mov      r8, r11
       and      r8, 2
       mov      qword ptr [rbp-0x128], r8
       test     r8, r8
       je       SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x1DC2
       movzx    r8, word  ptr [r12]
       mov      dword ptr [rbp-0x30C], r8d
       mov      bword ptr [rbp-0x2E8], r13
       movzx    r8, word  ptr [r13]
       movzx    r13, dword ptr [rbp-0x30C]
       sub      r13d, r8d
       mov      r8d, r13d
       mov      dword ptr [rbp-0x11C], r8d
       mov      r13, bword ptr [rbp-0x2E8]
 
G_M000_IG251:                ;; offset=0x1DF6
       test     r11b, 1
       je       SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x1DFC
       mov      r8, qword ptr [rbp-0x128]
       movzx    r11, byte  ptr [r12+r8]
       movzx    r8, byte  ptr [r8+r13]
       sub      r11d, r8d
       mov      r8d, r11d
       or       r8d, dword ptr [rbp-0x11C]
       mov      dword ptr [rbp-0x11C], r8d
 
G_M000_IG253:                ;; offset=0x1E21
       cmp      dword ptr [rbp-0x11C], 0
       sete     r8b
       movzx    r8, r8b
       jmp      G_M000_IG108
 
G_M000_IG254:                ;; offset=0x1E35
       xor      r13d, r13d
       add      r11, -32
       mov      qword ptr [rbp-0x110], r11
       test     r11, r11
       je       SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x1E48
       vmovups  ymm0, ymmword ptr [r12]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8]
       vpmovmskb r11d, ymm0
       cmp      r11d, -1
       je       G_M000_IG122
       jmp      G_M000_IG263
 
G_M000_IG256:                ;; offset=0x1E66
       mov      r11, qword ptr [rbp-0x110]
       vmovups  ymm0, ymmword ptr [r12+r11]
       vpcmpeqb ymm0, ymm0, ymmword ptr [r8+r11]
       vpmovmskb r8d, ymm0
       cmp      r8d, -1
       jne      G_M000_IG263
       jmp      SHORT G_M000_IG262
 
G_M000_IG257:                ;; offset=0x1E89
       xor      r13d, r13d
       mov      qword ptr [rbp-0x108], r13
       add      r11, -16
       je       SHORT G_M000_IG261
 
G_M000_IG258:                ;; offset=0x1E99
       vmovups  xmm0, xmmword ptr [r12]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       jne      SHORT G_M000_IG263
 
G_M000_IG259:                ;; offset=0x1EB1
       mov      r13, qword ptr [rbp-0x108]
       add      r13, 16
       cmp      r11, r13
       jbe      SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x1EC1
       vmovups  xmm0, xmmword ptr [r12+r13]
       mov      qword ptr [rbp-0x108], r13
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+r13]
       vpmovmskb r13d, xmm0
       cmp      r13d, 0xFFFF
       jne      SHORT G_M000_IG263
       jmp      SHORT G_M000_IG259
 
G_M000_IG261:                ;; offset=0x1EE3
       vmovups  xmm0, xmmword ptr [r12+r11]
       vpcmpeqb xmm0, xmm0, xmmword ptr [r8+r11]
       vpmovmskb r8d, xmm0
       cmp      r8d, 0xFFFF
       jne      SHORT G_M000_IG263
 
G_M000_IG262:                ;; offset=0x1EFC
       mov      r8d, 1
       jmp      G_M000_IG108
 
G_M000_IG263:                ;; offset=0x1F07
       xor      r8d, r8d
       jmp      G_M000_IG108
 
G_M000_IG264:                ;; offset=0x1F0F
       cmp      dword ptr [r13+0x20], 0
       setne    r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG53
 
G_M000_IG265:                ;; offset=0x1F25
       mov      rdi, r11
       mov      rsi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp-0x280]
       jmp      G_M000_IG53
 
G_M000_IG266:                ;; offset=0x1F3D
       mov      r10d, -2
       jmp      G_M000_IG78
 
G_M000_IG267:                ;; offset=0x1F48
       mov      eax, r13d
       xor      edx, edx
       div      edx:eax, r10d
       mov      r11d, edx
       mov      rdx, gword ptr [rbp-0x280]
       jmp      G_M000_IG79
 
G_M000_IG268:                ;; offset=0x1F5F
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG83
 
G_M000_IG269:                ;; offset=0x1F71
       mov      rdi, r11
       mov      rsi, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG83
 
G_M000_IG270:                ;; offset=0x1F86
       mov      r9, gword ptr [rbp-0x288]
       jmp      G_M000_IG81
 
G_M000_IG271:                ;; offset=0x1F92
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG89
 
G_M000_IG272:                ;; offset=0x1FA8
       mov      rsi, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG89
 
G_M000_IG273:                ;; offset=0x1FBA
       mov      r9, gword ptr [rbp-0x288]
       jmp      G_M000_IG81
 
G_M000_IG274:                ;; offset=0x1FC6
       mov      r10d, -1
       jmp      G_M000_IG94
 
G_M000_IG275:                ;; offset=0x1FD1
       xor      edx, edx
       mov      eax, edx
       mov      r12d, dword ptr [rbp-0x158]
       mov      r14, gword ptr [rbp-0x2A8]
       jmp      G_M000_IG98
 
G_M000_IG276:                ;; offset=0x1FE8
       mov      rsi, r11
       mov      rdi, r14
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG277:                ;; offset=0x1FF4
       mov      r12, r11
       mov      r9, qword ptr [rbp-0x190]
       mov      r10, gword ptr [rbp-0x2F8]
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       mov      r11, r12
       je       SHORT G_M000_IG279
       mov      r9, gword ptr [rbp-0x2A0]
       mov      r12d, dword ptr [rbp-0x158]
       mov      r14, gword ptr [rbp-0x2A8]
 
G_M000_IG278:                ;; offset=0x202F
       mov      rdi, r11
       mov      rsi, r9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x198]
       mov      r10, qword ptr [rbp-0x40]
       jmp      G_M000_IG40
 
G_M000_IG279:                ;; offset=0x204B
       mov      r10, qword ptr [rbp-0x40]
       jmp      G_M000_IG40
 
G_M000_IG280:                ;; offset=0x2054
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG281:                ;; offset=0x205B
       mov      edi, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG282:                ;; offset=0x2067
       mov      rdi, 0x7F4C2288C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F4C9CBF9418
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG283:                ;; offset=0x2095
       mov      rdi, 0x7F4C2288C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F4C9CBF9498
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG284:                ;; offset=0x20C3
       mov      rdi, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.RuntimeErrors:Cancelled(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG285:                ;; offset=0x20D9
       mov      rdi, bword ptr [rbp-0x198]
       mov      r13d, dword ptr [rbp-0x178]
       mov      dword ptr [rdi+0x18], r13d
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      rdi, bword ptr [rbp-0x198]
       jmp      G_M000_IG199
 
G_M000_IG286:                ;; offset=0x20FE
       mov      ebx, dword ptr [rbp-0x2C]
       add      ebx, 2
       mov      rdi, bword ptr [rbp-0x198]
       mov      dword ptr [rdi+0x18], ebx
       mov      rcx, bword ptr [rbp-0x1A8]
       jmp      G_M000_IG199
 
G_M000_IG287:                ;; offset=0x211A
       mov      rdi, rcx
       mov      rsi, 0x7F4C9CBF46F0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG288:                ;; offset=0x2136
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG289:                ;; offset=0x213C
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG290:                ;; offset=0x2142
       call     G_M000_IG343
       nop      
 
G_M000_IG291:                ;; offset=0x2148
       mov      ebx, dword ptr [rbp-0x50]
       jmp      SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x214D
       mov      rdi, bword ptr [rbp-0x198]
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdx, rbx
       mov      r8d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteOrdinaryDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool):bool]
       mov      ebx, eax
 
G_M000_IG293:                ;; offset=0x2170
       movzx    rax, bl
 
G_M000_IG294:                ;; offset=0x2173
       vzeroupper 
       add      rsp, 776
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG295:                ;; offset=0x2188
       mov      rdi, rcx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp-0x1A8]
       jmp      G_M000_IG05
 
G_M000_IG296:                ;; offset=0x219D
       xor      rax, rax
       jmp      G_M000_IG08
 
G_M000_IG297:                ;; offset=0x21A4
       xor      r15d, r15d
       jmp      G_M000_IG09
 
G_M000_IG298:                ;; offset=0x21AC
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG12
 
G_M000_IG299:                ;; offset=0x21BD
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG12
 
G_M000_IG300:                ;; offset=0x21CE
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdx, rax
       jmp      G_M000_IG12
 
G_M000_IG301:                ;; offset=0x21DF
       mov      rdi, 0x7F4C2288C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F4C9CBD5540
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG302:                ;; offset=0x220D
       mov      rdi, rcx
       mov      rsi, 0x7F4C9CBF93D0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG303:                ;; offset=0x2229
       mov      rdi, rdx
       mov      rsi, 0x7F4C9CBF3BF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG304:                ;; offset=0x2245
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG305:                ;; offset=0x224C
       mov      rdi, rax
       mov      esi, edx
       mov      r11, 0x7F4C212533B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG14
 
G_M000_IG306:                ;; offset=0x2266
       mov      rdi, rax
       mov      rsi, 0x7F4C9CBF4668
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG307:                ;; offset=0x2282
       cmp      r8d, 64
       je       G_M000_IG15
       cmp      r8d, 67
       je       G_M000_IG15
       cmp      r8d, 70
       jne      SHORT G_M000_IG306
       jmp      G_M000_IG15
 
G_M000_IG308:                ;; offset=0x22A1
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r9, qword ptr [rbp-0x190]
       jmp      G_M000_IG19
 
G_M000_IG309:                ;; offset=0x22B6
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r9, qword ptr [rbp-0x190]
       jmp      G_M000_IG19
 
G_M000_IG310:                ;; offset=0x22CB
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r9, qword ptr [rbp-0x190]
       jmp      G_M000_IG19
 
G_M000_IG311:                ;; offset=0x22E0
       mov      rsi, gword ptr [r12]
       mov      rdi, 0x7F4C23322AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG36
       mov      esi, dword ptr [r12+0x08]
       dec      esi
       lea      rdx, [rbp-0x38]
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      G_M000_IG37
 
G_M000_IG312:                ;; offset=0x2315
       cmp      dword ptr [r10+0x08], 1
       jle      SHORT G_M000_IG313
       mov      rdi, 0x7F4C23358130
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r14
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG313:                ;; offset=0x2349
       cmp      dword ptr [r10+0x08], 0
       jbe      SHORT G_M000_IG317
       mov      r10, qword ptr [r10+0x10]
       mov      qword ptr [rbp-0x58], r10
       neg      r10
       test     edx, edx
       cmovg    r10, qword ptr [rbp-0x58]
       test     r10, r10
       jle      SHORT G_M000_IG314
       test     edx, edx
       jg       SHORT G_M000_IG315
 
G_M000_IG314:                ;; offset=0x236B
       test     r10, r10
       jge      SHORT G_M000_IG316
       test     edx, edx
       jge      SHORT G_M000_IG316
 
G_M000_IG315:                ;; offset=0x2374
       jmp      G_M000_IG28
 
G_M000_IG316:                ;; offset=0x2379
       mov      rdi, 0x7F4C23358130
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       call     [System.SR:get_Overflow_Int64():System.String]
       mov      rsi, rax
       mov      rdi, r15
       call     [System.OverflowException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG317:                ;; offset=0x23A6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG318:                ;; offset=0x23AC
       sub      rsp, 24
 
G_M000_IG319:                ;; offset=0x23B0
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x23B6
       mov      rdi, bword ptr [rbp-0x198]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r12, bword ptr [rbp-0x1E0]
       mov      eax, dword ptr [r12+0x10]
       cmp      eax, dword ptr [rsi+0x08]
       jae      SHORT G_M000_IG325
       shl      rax, 4
       lea      r12, bword ptr [rsi+rax+0x10]
       mov      rbx, qword ptr [rbp-0x38]
       mov      rsi, 0x7F3C798016E8
       mov      rsi, gword ptr [rsi]
       mov      rdi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], rbx
 
G_M000_IG321:                ;; offset=0x23F9
       cmp      dword ptr [rbp-0x4C], 0
       je       SHORT G_M000_IG323
 
G_M000_IG322:                ;; offset=0x23FF
       mov      rdi, bword ptr [rbp-0x198]
       add      rdi, 32
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      esi, dword ptr [rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG323:                ;; offset=0x241A
       nop      
 
G_M000_IG324:                ;; offset=0x241B
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG325:                ;; offset=0x2423
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG326:                ;; offset=0x2429
       sub      rsp, 24
 
G_M000_IG327:                ;; offset=0x242D
       cmp      gword ptr [rbp-0x1E8], 0
       jne      SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0x2437
       cmp      dword ptr [rbp-0x15C], 0
       je       G_M000_IG341
 
G_M000_IG329:                ;; offset=0x2444
       mov      rdi, bword ptr [rbp-0x198]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r9, bword ptr [rbp-0x1C8]
       mov      eax, dword ptr [r9+0x1C]
       cmp      eax, 9
       je       SHORT G_M000_IG331
 
G_M000_IG330:                ;; offset=0x245F
       cmp      eax, 10
       je       SHORT G_M000_IG331
       mov      rdi, r9
       mov      rsi, 0x7F4C9CBF4698
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG331:                ;; offset=0x2480
       mov      eax, dword ptr [r9+0x14]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG339
       shl      rax, 4
       lea      rbx, bword ptr [rsi+rax+0x10]
       mov      rsi, gword ptr [rbp-0x1E8]
       cmp      gword ptr [rbp-0x1E8], 0
       jne      G_M000_IG340
 
G_M000_IG332:                ;; offset=0x24AB
       mov      rdi, gword ptr [rbp-0x1B0]
       mov      esi, dword ptr [rbp-0x15C]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:WordCharge(int):long:this]
       mov      r15, rax
       mov      rdi, gword ptr [rbp-0x1B0]
       mov      r14, gword ptr [rdi+0x08]
       mov      rdi, 0x7F4C22EDFBC0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      dword ptr [r13+0x1C], -1
       cmp      dword ptr [rbp-0x15C], 0
       jne      SHORT G_M000_IG334
 
G_M000_IG333:                ;; offset=0x24EF
       xor      edi, edi
       mov      rsi, 0x7F4C9CBD0B28
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG334:                ;; offset=0x2502
       cmp      dword ptr [rbp-0x15C], 8
       jg       SHORT G_M000_IG336
 
G_M000_IG335:                ;; offset=0x250B
       mov      esi, dword ptr [rbp-0x15C]
       mov      byte  ptr [r13+0x24], sil
       jmp      SHORT G_M000_IG337
 
G_M000_IG336:                ;; offset=0x2517
       mov      esi, dword ptr [rbp-0x15C]
       mov      rdi, 0x7F4C2258CCD0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG337:                ;; offset=0x2538
       mov      edi, dword ptr [rbp-0x15C]
       mov      dword ptr [r13+0x18], edi
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rdi, rax
       cmp      dword ptr [rbp-0x15C], edx
       jg       SHORT G_M000_IG338
       mov      edx, dword ptr [rbp-0x15C]
       mov      rsi, bword ptr [rbp-0x2B0]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rdi, r13
       mov      esi, dword ptr [rbp-0x15C]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      rax, gword ptr [rbp-0x1B0]
       sub      qword ptr [rax+0x28], r15
       mov      rsi, r13
       jmp      SHORT G_M000_IG340
 
G_M000_IG338:                ;; offset=0x2594
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG339:                ;; offset=0x259B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG340:                ;; offset=0x25A1
       mov      rdi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      edi, edi
       mov      qword ptr [rbx+0x08], rdi
 
G_M000_IG341:                ;; offset=0x25AF
       call     G_M000_IG318
       nop      
 
G_M000_IG342:                ;; offset=0x25B5
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG343:                ;; offset=0x25BD
       sub      rsp, 24
 
G_M000_IG344:                ;; offset=0x25C1
       cmp      dword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG346
 
G_M000_IG345:                ;; offset=0x25C7
       mov      rsi, gword ptr [rbp-0x1A0]
       mov      rdi, gword ptr [rsi+0x98]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG346:                ;; offset=0x25DE
       call     G_M000_IG326
       nop      
 
G_M000_IG347:                ;; offset=0x25E4
       vzeroupper 
       add      rsp, 24
       ret      
 
; Total bytes of code 9708

