from pathlib import Path
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
results = repo / "benchmarks/results"
def archive_cases(folder, file):
    base = results / folder
    receipt = json.loads((base / "terminal-status.json").read_text(encoding="utf-8"))["receipt"]
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
    path = base / file
    assert hashlib.sha256(path.read_bytes()).hexdigest() == receipt["archiveSHA256"]
    with tarfile.open(path) as archive:
        catalog = json.load(archive.extractfile("representative.json"))
    return catalog

external = archive_cases("2026-11-23-runtime-cpython-checkpoint", "observations.tgz")
init = archive_cases("2026-11-23-dispatch-known-call-semantics", "observations.tar.xz")
text = archive_cases("2026-11-23-borrowed-cased-words", "observations.tar.xz")
cases = {case["id"]: case for catalog in (external, init, text) for case in catalog["cases"]}
config = "scripts.config-edit.small"
postponed = "scripts.annotated-rule-closures.nested-factories.postponed"
mixed = "diagnostic.text-summary.borrowed-cased-words.mixed-width"
jobs = [
    [mixed, "warm"],
    [config, "compile"],
    ["scripts.csv-meter-report.typed-ascii", "warm"],
    [postponed, "compile-run"],
    ["diagnostic.text-summary.nonlocal-computed-width.large", "warm"],
    [config, "compile-run"],
    ["scripts.json-lines-shipment.expanded-options.large", "warm"],
]
external["cases"] = [cases[key] for key in dict.fromkeys(key for key, _ in jobs)]
external["performanceQualified"] = False
for name, data in (("representative.json", external), ("jobs.json", jobs)):
    (lab / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
print(len(external["cases"]), "cases", len(jobs), "lanes")
