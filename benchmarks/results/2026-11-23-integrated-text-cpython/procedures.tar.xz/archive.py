from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "borrowed-cased-words-refined-20261123"
dest = repo / "benchmarks/results/2026-11-23-integrated-text-cpython"
read = lambda file: json.loads((lab/file).read_text(encoding="utf-8"))
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
terminal = read("terminal-status.json")
assert terminal["exitCode"]=="0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha(lab/"observations.tar.xz") == terminal["receipt"]["archiveSHA256"]
assert len(read("summary.json")["rows"]) == 7 and read("summary.json")["timedBatches"] == 196
identity = read("identity.json")
assert all(sha(prior/"candidate"/name) == digest for name,digest in identity["imageFiles"]["candidate"].items())
dest.mkdir()
for file in ("identity.json", "summary.json", "terminal-status.json", "observations.tar.xz"):
    shutil.copyfile(lab/file,dest/file)
shutil.copyfile(prior/"short-jit-summary.json",dest/"short-jit-summary.json")
with tarfile.open(dest/"procedures.tar.xz","w:xz") as archive:
    for name in ("archive.py", "catalog.py", "collector.py", "verify.py", "launch.py", "retrieve.py",
            "summarize.py", "candidate-verify.json", "reference-verify.json", "launch.log",
            "retired-replica-launch.log", "initial-launch.log", "observe-not-before"):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ("inspect-short-jit.py", "linux-short-jit.py", "summarize-short-jit.py"):
        archive.add(prior/name,arcname=name,recursive=False)
    for role in ("reference", "candidate"):
        for suffix in ("-short-cased.asm","-linux-short-cased.asm","-jit-allocation.json","-linux-jit-allocation.json"):
            name=role+suffix
            archive.add(prior/name,arcname=name,recursive=False)
print(dest)
