from pathlib import Path
import datetime
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
gate = datetime.datetime.fromisoformat((lab/"observe-not-before").read_text(encoding="utf-8"))
assert datetime.datetime.now(datetime.timezone.utc) >= gate
base = "/home/lokad/lython-bench-checks"
root = base + "/integrated-text-cpython-20261123"
unit = "lython-integrated-text-cpython-20261123"
options = ["-i", str(Path.home()/".ssh/id_lython-bench.pem"), "-o", "BatchMode=yes", "-o", "ConnectTimeout=15"]
host = "lokad@20.166.121.73"
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", *options, host, "python3 -"]
scp = ["C:/Windows/System32/OpenSSH/scp.exe", *options]
script = """
from pathlib import Path
import fcntl,json,subprocess
root=Path(root)
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True,check=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  exit_file=root/'exit-code.txt'
  receipt_file=root/'archive-receipt.json'
  print(json.dumps(dict(live=False,service=service,exitCode=exit_file.read_text().strip() if exit_file.exists() else None,
   receipt=json.loads(receipt_file.read_text()) if receipt_file.exists() else None,
   fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
"""
result = subprocess.run(ssh, input=f"root={root!r}\nunit={unit!r}\n"+script, capture_output=True, encoding="utf-8", timeout=30, check=True)
terminal = json.loads(result.stdout)
print(result.stdout)
if not terminal["live"]:
    (lab/"terminal-status.json").write_text(result.stdout, encoding="utf-8", newline="\n")
    if terminal["receipt"] is not None:
        local = lab/"observations.tar.xz"
        subprocess.run(scp+[host+":"+root+"/"+local.name,str(local)], timeout=35, check=True)
        assert hashlib.sha256(local.read_bytes()).hexdigest() == terminal["receipt"]["archiveSHA256"]
