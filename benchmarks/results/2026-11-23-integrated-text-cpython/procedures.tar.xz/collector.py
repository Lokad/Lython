from pathlib import Path

lab = Path(__file__).resolve().parent
base = lab.parent / "cpython-runtime-checkpoint-20261123/comparison/quiet/collect.py"
paired = lab.parent / "borrowed-cased-words-refined-20261123/comparison/quiet/collect.py"
reference = base.read_text(encoding="utf-8")
wrapper = paired.read_text(encoding="utf-8")
prefix, body = reference.split("with (root.parent/'comparison-vm.lock')", 1)
prefix = prefix.replace("math, os, shutil", "math, os, shutil, tarfile")
prefix = prefix.replace("worker = root / 'candidate/Lokad.Lython.Benchmarks.dll'\n", "")
prefix = prefix.replace("assert set(identity", "image = Path(identity['frozenImage'])\nworker = image / 'Lokad.Lython.Benchmarks.dll'\nassert set(identity")
prefix = prefix.replace("owned_ram=root/'guest-fixtures';assert owned_ram.is_dir()", "owned_ram=root/'guest-fixtures'")
prefix = prefix.replace("assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev\n", "")
start = body.index("    started=time.monotonic()")
end = body.index("    assert not list(owned_ram.iterdir())")
lane_loop = body[start:end]
first = lane_loop.index("    for case_id,lane in [")
last = lane_loop.index("        assert time.monotonic()-started", first)
lane_loop = lane_loop[:first] + "    for case_id,lane in jobs:\n" + lane_loop[last:]
lane_loop = lane_loop.replace("B1451 retained-source", "Integrated 0.11.0")
lane_loop = lane_loop.replace("started<480", "started<368").replace("n*.65", "n*.40")
lane_loop = lane_loop.replace("['candidate','CPython','candidate-control','CPython-control']",
    "['CPython','candidate-control','CPython-control','candidate']")
lane_loop = lane_loop.replace("    time.sleep(3)\n    subprocess.run([str(dotnet)", "    time.sleep(3)\n    subprocess.run([str(dotnet)")
check = '''
def check_image():
    assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['cpythonWorkerSHA256']
    assert hashlib.sha256(python.read_bytes()).hexdigest()==identity['expectedCPythonSHA256']
    for name, sha in identity['imageFiles']['candidate'].items():
        assert hashlib.sha256((image/name).read_bytes()).hexdigest()==sha, name
    assert hashlib.sha256((root/'jobs.json').read_bytes()).hexdigest()==identity['catalogs']['jobs.json']['sha256']

jobs = json.loads((root/'jobs.json').read_text())
assert len(jobs) == 7 and manifest_hash == identity['catalogs']['representative.json']['sha256']

def warm():
'''
tail = wrapper[wrapper.index("def archive(complete, warm):"):]
tail = tail.replace("lython-b1457-fixtures", "lython-integrated-checkpoint-fixtures")
collector = prefix + check + lane_loop + "    return record\n\n" + tail
compile(collector, "collect.py", "exec")
(lab / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
