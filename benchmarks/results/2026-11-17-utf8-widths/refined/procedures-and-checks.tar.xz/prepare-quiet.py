from pathlib import Path
import ast,gzip,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent.parent;repo=Path('D:/code/Lython');q=r/'quiet';q.mkdir(exist_ok=False)
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));previous=r.parent;prior=json.loads((previous/'quiet/config.json').read_text(encoding='utf-8'))
canonical='benchmarks/results/2026-11-17-utf8-widths/first/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);sha=hashlib.sha256(data).hexdigest()
s=(notes/'instruction-global-slots-r479/inspect-retirement.py').read_text(encoding='utf-8');start=s.index("code='''");end=s.index("ssh=");scope={'sha':sha};exec(s[start:end],scope)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=scope['code'],text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;selected=json.loads(p.stdout);assert selected['bytes']==len(data)
groups=[selected|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededQualifiedSource='AdverseCountAnybcf4b5e3 prototype; currentqualified0315 reference preserved')]
for canonical,remotePath,member in [
 ('benchmarks/results/2026-11-17-utf8-widths/first/observations.tgz','utf8-widths-b898-20261117/confirmation/confirmation.json','confirmation/confirmation.json'),
 ('benchmarks/results/2026-11-03-current-call-costs/observations.tgz','native-operands-b159-20261103/observations.tgz','whole-archive'),
 ('benchmarks/results/2026-11-05-frontend-source-gate/observations.tgz','frontend-source-gate-b237-20261105/observations.tgz','whole-archive'),
 ('benchmarks/results/2026-11-06-runtime-cost-gates/compound/observations.tgz','compound-cost-b328-20261106/observations.tgz','whole-archive'),
 ('benchmarks/results/2026-11-14-call-publication-attribution/observations.tgz','call-publication-b760-20261114/observations.tgz','whole-archive')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=blob
 if member!='whole-archive':
  with tarfile.open(fileobj=__import__('io').BytesIO(blob))as a:data=a.extractfile(member).read()
 groups.append(dict(paths=[remotePath],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
remote='/home/lokad/lython-bench-checks/utf8-widths-b899-20261117';reference=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifiedd8611c85/frozen0315de0a versus R483 on50b33e17/frozen'+candidate,purpose='Refined direct managed Vector<byte> mask/population counts; no SearchValues tables or search/count per hit; first denseCPU+23% preserved. Bulk UTF8 scalar/UTF16 counting; original text warm/fresh, helper text, report and ASCII/denseUnicode controls. Actual copied5case images/CPython goldens pass before VM staging. No predicted gain or per-string state.',coreSHA256={'reference':reference,'reference-control':reference,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
s=(previous/'quiet/collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.text-normalization.helper-list','warm'],['scripts.report-render.large','warm'],['scripts.text-normalization.ascii','warm'],['scripts.text-normalization.dense','warm']];s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('R481 caller-window','R483 bulk UTF8 width').replace("< 190, 'Reserve60seconds","< 250, 'Reserve60seconds");(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(previous/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==6").replace('jobs=4','jobs=6');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((previous/'quiet/run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n');(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'catalog.json',q/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit='lython-b899-utf8-widths-20261117',source=prior['root'],sourceRole='reference',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(previous/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b898-fixtures','lython-b899-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=300');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((previous/'launch.py').read_text(encoding='utf-8').replace('seconds=190','seconds=260').replace('before190seconds','before260seconds').replace('Four-job native-call-windows','Six-job bulk UTF8 widths'),encoding='utf-8',newline='\n')
s=(previous/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==6").replace('B898','B899');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(previous/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==6");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Six bounded whole-script jobs prepared; source reference0315 preserved; retire only committed withdrawn27ed replica',selected)
