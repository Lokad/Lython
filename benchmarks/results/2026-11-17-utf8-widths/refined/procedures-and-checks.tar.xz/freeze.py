from pathlib import Path
import copy,hashlib,importlib.util,json,os,shutil,subprocess,tarfile,tempfile
r=Path(__file__).parent;notes=r.parent.parent;repo=Path('D:/code/Lython');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(r.parent/'catalog.json',r/'catalog.json')
reference=notes/'unary-slot-results-r477';files=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'];frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in files.items():assert sha(reference/'frozen/candidate'/n)==h;shutil.copyfile(reference/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 for p in (reference/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
images={role:{n:sha(frozen/role/n)for n in files}for role in ['reference','candidate']};assert[n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
old=json.loads((notes/'native-call-windows-r481/corrected/frozen/identity.json').read_text(encoding='utf-8'))
assert [n for n in old['sourceInputs']if not(repo/n).exists()]==['tests/Lokad.Lython.Tests/Harness/NativeCallWindow.cs']
inputs={n:sha(repo/n)for n in old['sourceInputs']if(repo/n).exists()}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in inputs:a.add(repo/n,arcname=n)
with tarfile.open(reference/'candidate-sources.tar.xz')as a:
 changed=[n for n in inputs if n.startswith('src/Lokad.Lython/')and(repo/n).read_text(encoding='utf-8-sig')!=a.extractfile(n).read().decode('utf-8-sig').replace('\r\n','\n')]
assert changed==['src/Lokad.Lython/Runtime/Text/PyString.cs'],changed
identity=dict(referenceSource='Qualifiedd8611c85/frozen0315de0a GREEN44050323147; all production restored at13a56f7d',candidateSource='R483 direct managedVector byte masks on50b33e17; first CountAny adversity preserved, bounded changed-source refinement',imageFiles=images,sourceInputs=inputs,productionFiles=585,changedProductionFiles=changed,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 image=frozen/role
 commands=[('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]
 for label,cmd in commands:
  with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('Five-case custom catalog goldens pass actual copied images; one production change, candidate',images['candidate']['Lokad.Lython.dll'],flush=True)
