from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-utf8-widths/refined';out.mkdir(exist_ok=False)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert summary['complete']and summary['quietBeforeAndAfter']and summary['allUsersJoinedAndFixturesRemoved'];summary['retentionDecisionPending']=False;(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for source,target in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'frozen/identity.json','identity.json'),(r/'candidate-sources.tar.xz','candidate-sources.tar.xz'),(r/'quiet/observations.tgz','observations.tgz'),(r/'quiet/archive-receipt.json','archive-receipt.json'),(r/'quiet/terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/target)
with gzip.open(out/'candidate-core.dll.gz','wb')as f:f.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in r.rglob('*'):
  if p.is_file()and not{'frozen','retrieved','__pycache__'}&set(p.relative_to(r).parts)and p.suffix in{'.py','.log','.json','.sh'}:a.add(p,arcname=p.relative_to(r).as_posix())
decision=dict(retain=True,reason='Shared managed byte counting removes scalar-width walking/boundary adjustment without per-string state/copies/owners; original text warm/fresh, helper text and report improve with CPU support.',reference='Qualifiedd8611c85/frozen0315de0a',candidate='One production change on50b33e17/frozena95ff2a4',removed=['per-scalar GetRuneLength loop in width counting','scalar-boundary chunk adjustment','first prototype SearchValues tables/repeated searches'],preserved=['current cancellation in4KiB chunks and completion','checked sums, validUTF8 invariant and real indexing users','projection funding/terminal first refusal, aliases/shared-budget cleanup'],allocation='Effectively flat,−0.006..+0.055%; all accounted peaks/compiled balances unchanged, baselines restored.',uncertainty='ASCII/dense reference movement7.17/6.77%; denseCPU−7.51..+0.72%. Fresh candidate movement3.09%; no precise Unicode gain or causal recovery across collections.',fullDeliveryPending=True,CPythonRefreshPending=True,broaderPerformanceObjectiveComplete=False,publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
table=[]
for row in summary['rows']:
 vals=lambda key:f"{min(row[key]):+.2f}..{max(row[key]):+.2f}%"
 table.append(f"| {row['case']} / {row['lane']} | {vals('elapsedChangePercent')} | {vals('cpuChangePercent')} | {row['referenceSpreadPercent']:.2f}/{row['candidateSpreadPercent']:.2f}% |")
(out/'README.md').write_text('''# Managed bulk scalar and UTF-16 widths

R483/B899,2026-11-17UTC. Retained, full delivery qualification pending. One
production file on50b33e17, frozena95ff2a4, compared with qualifiedd8611c85/
frozen0315de0a. Exact585production/2381build-test inputs and copied32file worker
hashes archived. Actual5case workers agree with CPython3.13.2 before staging;
Windows actual.NET11/10 each63internal/49public focused checks pass.

Valid UTF-8 scalar count is bytes minus continuation bytes; UTF-16 adds astral
leads. Safe managed Vector<byte> masks/population counts and a scalar tail replace
per-scalar width walking and chunk-boundary adjustment. Cancellation remains at
4KiB boundaries and completion. No per-string state, owner/copy/framework,
unsafe/pointer/intrinsic API or dependency. Indexing still uses GetRuneLength.
Projection admission/first refusal, retained aliases and budget cleanup remain.

The first SearchValues/CountAny implementation is discarded; stable dense
adversity and original failures remain in [first evidence](../first/README.md).
This is one justified changed-source refinement, not unchanged retiming.

| Complete workload / lane | Elapsed change | Wider process CPU change | Reference/candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

Original text, helper text and report improve with CPU support. ASCII/dense
reference movement limits precision; denseCPU spans−7.51..+0.72%, not a precise
gain or adverse-recovery attribution. Fresh candidate movement3.09% remains.
No universal speedup, RSS/heap, physical-GC, async-I/O or embedding-tail claim.
Allocation effectively flat (−0.006..+0.055%), all accounted peaks and compiled
balances unchanged, every shared-budget baseline restored. Dense2/3/4byte and
mixed counts are checked independently of the implementation.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3,6jobs229.23seconds,6second rotated
warmups/five samples/four processes; normal GC/tiering. Guest I/O/full goldens/
prior-result cleanup included; compilation only fresh. Staging/reset/protocol,
startup and final cache teardown excluded. WiderCPU includes request overhead and
is quantized. All quiet/golden/Closed/exit/join/archive gates pass; RAM removed,
terminal cached. Exact committed old raw/archive replicas and discardedbcfcore
retired after fresh lease/path/UID/hash/link/all-alias proof. Current0315,
toolchains/canonicals and254/252MiB floors preserved.

Full platform/stress/installed Release qualification and affected CPython refresh
are next. This milestone does not complete the broader call/frame/record/frontend
performance roadmap. Publication/tagging remain held.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[source](candidate-sources.tar.xz),[identity](identity.json),
[procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');needle='Unicode indexing caches use the active caller';i=s.index(needle);s=s[:i]+'Scalar and UTF-16 widths count UTF-8 leading bytes in bounded chunks, using\nmanaged vectors and a scalar tail. Counting needs no decoded string or indexing\ntable and checks the current cancellation token through completion.\n\n'+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');i=s.index('\n',s.index('## '));s=s[:i+1]+'\n- Count UTF-8 scalar and UTF-16 widths in managed bulk operations, preserving bounded cancellation and projection admission.\n'+s[i+1:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\nR483/B899: [managed vector refinement](results/2026-11-17-utf8-widths/refined/README.md) retained. Original textwarm−9.72..−7.58%,fresh−5.77..−2.85%; helpertext−5.47..−2.72%,report−3.49..−1.49%withCPU support. ASCII/dense reference7.17/6.77%movement limits magnitude; denseCPU−7.51..+0.72%. Allocation/peaks flat, shared balances restored; actual11/10each63internal/49public. First stable dense adversity remains separate. Full delivery/affectedCPython refresh next; broader roadmap/publication hold continue.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('Refinement retained with original adversity/uncertainty preserved; full delivery/CPython pending.')
