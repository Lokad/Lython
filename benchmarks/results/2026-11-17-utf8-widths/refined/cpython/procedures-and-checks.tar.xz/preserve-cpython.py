from pathlib import Path
import hashlib,json,shutil,tarfile
base=Path(__file__).parent;r=base/'cpython';repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-utf8-widths/refined/cpython';out.mkdir(exist_ok=False)
receipt=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==3 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter'];assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'summary.json',out/'summary.json')
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in [base/'prepare-cpython.py',base/'preserve-cpython.py']:a.add(p,arcname=p.name)
 for p in r.rglob('*'):
  if p.is_file()and'retrieved'not in p.parts and p.name not in['payload.tgz','observations.tgz']:a.add(p,arcname=p.relative_to(r).as_posix())
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));rows={x['lane']:x for x in v['timing']}
def fmt(x):
 m=x['medianMilliseconds'];l=[m[k]for k in ['candidate','candidate-control']];c=[m[k]for k in ['CPython','CPython-control']]
 return f'{min(l):.3f}–{max(l):.3f} ms',f'{min(c):.3f}–{max(c):.3f} ms',f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×",f"R483; diagnostic; controls L/C {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}%; IQR≤{x['maxIqrPercent']:.2f}%"
table=[]
for lane,title in [('compile','Compilation only'),('warm','Warm execution'),('compile-run','Compile and execute once')]:table.append('| '+title+' | '+' | '.join(fmt(rows[lane]))+' |')
(out/'README.md').write_text('''# Complete text normalization against CPython

B900,2026-11-17UTC. Committed **dbdf8262 / frozena95ff2a4**, stock **CPython3.13.16**.
Full runtime delivery44080812207 is pending independently. Original generator
text script,4096lines/52224B mixed Unicode input; reads, normalizes newlines/tabs/
trailing spaces, joins, writes and checks exact stdout/files.

| Phase | Lython | CPython | Lython / CPython | Measurement status |
| --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Ratio above one means Lython is slower. Two independent processes per engine;
process-median combinations are not confidence intervals. Warm CPython control
movement3.40% limits precision; retain all raw controls. Fresh controls0.45/0.36%.
This external baseline is not causal source gain across collections or attribution
of the remaining gap. Earlier unfavorable results remain preserved.

Three phases103.55seconds, quiet AzureF4as_v7/Ubuntu24.04.4,4EPYC9V45vCPUs,
16GiB/no swap; .NET11RC3 natural workstationGC/normaltiering,CPythonGIL/GC.
Rotated5second full-request warmups/five approximately0.5second samples. Warm
includes synchronous execution, mediated RAM I/O, exact stdout/file validation
and prior-result cleanup. Compile includes compiled-owner disposal; fresh adds
compilation/compiled-owner disposal. Reset/staging/protocol/startup/final cache
teardown excluded. Independently warmed phases are not additive. WiderCPU also
includes reset/protocol. CPython files have no equivalent host authorization or
shared-memory checks. No startup, genuine suspension, RSS or embedding-tail claim.

Same actual-worker-verified5case catalog/copied32file image as source comparison.
All identity/golden/quiet/Closed/exit/join/archive checks pass; RAM removed and
terminal cached. Only exact committed B899 raw replica retired with fresh path/
UID/hash/link/all-alias proof; current images/toolchains/canonicals and254/252MiB
floors preserved. Publication/tagging held; broader performance work continues.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[custody](archive-receipt.json),[procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Text normalization | 4,096 lines /'):lines[i]='| Text normalization | 4,096 lines / 52,224 B | '+' | '.join(fmt(rows['warm']))+' |'
 elif line.startswith('| Text normalization | Compilation only |'):lines[i]='| Text normalization | Compilation only | '+' | '.join(fmt(rows['compile']))+' |'
 elif line.startswith('| Text normalization | Compile and execute once |'):lines[i]='| Text normalization | Compile and execute once | '+' | '.join(fmt(rows['compile-run']))+' |'
s='\n'.join(lines)+'\n';needle='Measured **2026-11-17 UTC**: ';assert needle in s;s=s.replace(needle,'Measured **2026-11-17 UTC**: original text normalization uses **dbdf8262 /\nfrozena95ff2a4**, stock **CPython3.13.16**, with full runtime qualification pending.\nThree separated phases103.55s; all measurement gates pass.\n[Text baseline and exact boundaries](../benchmarks/results/2026-11-17-utf8-widths/refined/cpython/README.md).\nThe ',1).replace('CSV compilation/fresh, generator\nnormalization, JSON and search remain earlier','CSV compilation/fresh, JSON and search remain earlier')
p.write_text(s,encoding='utf-8',newline='\n')
p=out.parent/'decision.json';w=json.loads(p.read_text(encoding='utf-8'));w.update(CPythonRefreshPending=False,CPythonBaseline='B900,dbdf8262/a95ff2a4 vs3.13.16; originaltext warm1.75–1.81,fresh1.66–1.67,compile0.94–0.96; diagnostic controls retained.');p.write_text(json.dumps(w,indent=2)+'\n',encoding='utf-8')
p=out.parent/'README.md';s=p.read_text(encoding='utf-8').replace('Full platform/stress/installed Release qualification and affected CPython refresh\nare next.','Full platform/stress/installed Release qualification is pending. The affected\n[CPython refresh](cpython/README.md) is complete; original text warm1.75–1.81×,\nfresh1.66–1.67×,compile0.94–0.96×,with warm CPython control movement3.40%.');s=s.replace('unsafe/pointer/intrinsic API or dependency','unsafe code, raw pointers, P/Invoke or new dependency');p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\nR483/B900: [affected complete text versus CPython](results/2026-11-17-utf8-widths/refined/cpython/README.md), dbdf8262/a95ff2a4 versus3.13.16. Three phases103.55s, warm1.75–1.81×(CPythoncontrols3.40%),fresh1.66–1.67×,compile0.94–0.96×. All gates/usersjoined/RAMarchive pass. Diagnostic external ratio, not a causal gain across collections. Full runtime delivery independent/pending; publication held.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('Affected original-text CPython refresh B900 running:');b=s.index('\nNext R484:',a);s=s[:a]+'''Affected original-text CPython B900 complete103.55s: warm1.75–1.81×,
compile-to-result1.66–1.67×,compile0.94–0.96× versus3.13.16. Same5case catalog,
normal GC/tiering; all goldens/gates/join/archive pass. Warm CPython controls3.40%;
no causal source gain across collections. BENCHMARKS updated with exactdbdf8262/
a95ff2a4,boundaries and preserved older evidence. No unchanged retiming needed.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Affected text CPython evidence/guide updated; current source ratios, controls and boundaries explicit. Runtime CI remains independent.')

