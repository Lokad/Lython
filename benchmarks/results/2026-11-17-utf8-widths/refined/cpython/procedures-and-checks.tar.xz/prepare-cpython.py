from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
base=Path(__file__).parent;repo=Path('D:/code/Lython');notes=base.parent.parent
r=base/'cpython';r.mkdir(exist_ok=False);q=r/'quiet';q.mkdir()
old=notes/'unary-slot-results-r477/cpython';f=json.loads((base/'frozen/identity.json').read_text(encoding='utf-8'));prior=json.loads((base/'quiet/config.json').read_text(encoding='utf-8'))
head=json.loads((base/'retained-head.json').read_text(encoding='utf-8'))['head'];remote='/home/lokad/lython-bench-checks/width-cpython-b900-20261117'
identity=dict(sourceRevision='Committed'+head+'/frozen'+f['imageFiles']['candidate']['Lokad.Lython.dll'],purpose='Refresh affected original complete text normalization versus CPython3.13.16; compilation,warm,fresh separate. No causal source gains across collections.',coreSHA256={'candidate':f['imageFiles']['candidate']['Lokad.Lython.dll'],'candidate-control':f['imageFiles']['candidate']['Lokad.Lython.dll']},auxiliaryFiles={n:h for n,h in f['imageFiles']['candidate'].items()if n!='Lokad.Lython.dll'},imageFiles={'candidate':f['imageFiles']['candidate']},sourceInputsArchiveSHA256=hashlib.sha256((base/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py']:
 s=(old/'quiet'/name).read_text(encoding='utf-8').replace('scripts.csv-numeric-quality.large','scripts.text-normalization.large')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/unary-cpython-b891-20261117',remote),encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-17-utf8-widths/refined/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='confirmation/confirmation.json'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
groups=[dict(paths=['utf8-widths-b899-20261117/'+member],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True)]
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b900-width-cpython-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['candidate'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b891-fixtures','lython-b900-fixtures');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for name in ['launch.py','summarize.py']:
 (r/name).write_text((old/name).read_text(encoding='utf-8').replace('numeric CSV CPython baseline','text CPython baseline'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B891','B900'),encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+list(r.glob('*.py')):ast.parse(p.read_text(encoding='utf-8'))
print('Affected3phase text CPython refresh prepared; current images preserved, exact committed raw replica eligible for retirement.')
