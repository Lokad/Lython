from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path(__file__).parent;q=r/'quiet';repo=Path('D:/code/Lython');c=json.loads((q/'config.json').read_text(encoding='utf-8'))
assert len(c['retireGroups'])==1
for canonical,remote in [
 ('benchmarks/results/2026-11-14-representative-call-cost/observations.tgz','representative-stage-b749-20261114/observations.tgz'),
 ('benchmarks/results/2026-11-14-invocation-stage/observations.tgz','invocation-stage-b754-20261114/observations.tgz'),
 ('benchmarks/results/2026-11-04-current-text-report-cpu/observations.tgz','ordinary-text-report-cpu-b220-20261104/observations.tgz'),
 ('benchmarks/results/2026-11-16-native-iteration-attribution/observations.tgz','iteration-cost-b851-20261116/observations.tgz'),
 ('benchmarks/results/2026-11-17-native-call-windows/corrected/observations.tgz','call-window-corrected-b897-20261117/confirmation/confirmation.json')]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 member='whole-archive';data=blob
 if remote.endswith('.json'):
  member='confirmation/confirmation.json'
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 c['retireGroups'].append(dict(paths=[remote],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
(q/'launch.log').rename(q/'initial-space-guard.log');(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Additional exact committed archive/raw replicas verified locally; fresh remote path/UID/hash/link/all-alias guards remain before any retirement.')
