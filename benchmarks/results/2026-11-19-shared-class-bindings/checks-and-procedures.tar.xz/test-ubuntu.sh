export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/shared-class-bindings-r687
~/.dotnet/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~ClassScopeDirectiveTests|FullyQualifiedName~ImplicitClassCellTests|FullyQualifiedName~ComprehensionSuperCompatibilityTests|FullyQualifiedName~LiveSuperReceiverCompatibilityTests|FullyQualifiedName~ModuleFunctionSuperBoundaryTests|FullyQualifiedName~SuperMemberPreloadCompatibilityTests|FullyQualifiedName~SuperDescriptorParityTests|FullyQualifiedName~CompilerCancellationTests)&Category!=Stress' >"$lab/ubuntu-public.log" 2>&1
code=$?
tail -n 12 "$lab/ubuntu-public.log"
if test "$code" -ne 0; then exit "$code"; fi
~/.dotnet/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~FunctionClassCellBoundaryTests|FullyQualifiedName~SuperDescriptorFundingBoundaryTests|FullyQualifiedName~MethodBodyCompilationBoundaryTests)&Category!=Stress' >"$lab/ubuntu-whitebox.log" 2>&1
code=$?
tail -n 8 "$lab/ubuntu-whitebox.log"
exit "$code"
