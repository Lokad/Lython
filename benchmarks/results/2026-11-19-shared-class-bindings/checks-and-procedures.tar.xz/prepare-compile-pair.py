from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import textwrap

lab = Path(__file__).resolve().parent
repo = Path.cwd()
previous = lab.parent / 'keyword-table-copy-r686'
core = 'Lokad.Lython.dll'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


reference = json.loads((previous / 'frozen-identity.json').read_text(encoding='utf-8-sig'))
assert reference['referenceCommit'].startswith('47fbd2c1b')
candidate = subprocess.check_output(
    ['git', '-C', '.git/agent-worktrees/shared-class-bindings-r687', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', reference['referenceCommit'], '6772c0cf2', '--', 'src', 'tests'])
patch = subprocess.check_output(['git', 'diff', '--binary', reference['referenceCommit'], candidate, '--', 'src', 'tests'])
assert patch.count(b'diff --git ') == 2
(lab / 'source.patch').write_bytes(patch)
baseline_core = previous / 'frozen/reference' / core
assert sha(baseline_core) == reference['images']['reference'][core]
candidate_core = lab / 'build/bin/Lokad.Lython/release_net11.0' / core
helper = lab.parent / 'child-declaration-preparation-r668/compile-allocation/candidate'
files = ('CompileAllocation.dll', 'CompileAllocation.deps.json', 'CompileAllocation.runtimeconfig.json')
identity = {}
for role, image in [('reference', baseline_core), ('candidate', candidate_core)]:
    frozen = lab / 'frozen' / role
    frozen.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(image, frozen / core)
    for name in files:
        shutil.copyfile(helper / name, frozen / name)
    identity[role] = {name: sha(frozen / name) for name in (*files, core)}
    assert all(identity[role][name] == sha(helper / name) for name in files)
write(lab / 'frozen-identity.json', dict(referenceCommit=reference['referenceCommit'], candidateCommit=candidate, images=identity))

fixture = (repo / 'tests/Lokad.Lython.PublicApi.Tests/ImplicitClassCellTests.cs').read_text(encoding='utf-8-sig')
names = ('NestedClosuresAndGeneratorsEscape', 'NestedClassesHaveIndependentClassCells',
         'ExplicitLocalAndGlobalBindingsOverrideImplicitLookup', 'SuperUsesLexicalClassAndReceiver')
cases = []
for name in names:
    raw = re.search(r'"' + name + r'",\s+"""\n(.*?)\n\s+"""', fixture, re.S)
    assert raw
    cases.append(dict(id=name, source=textwrap.dedent(raw.group(1)) + '\n'))
controls = json.loads((lab.parent / 'token-source-transport-r673/catalog.json').read_text(encoding='utf-8-sig'))
for case in controls['cases']:
    if case['id'] in ('scripts.config-generated-guards.medium', 'scripts.config-manifest.small'):
        cases.append(dict(id=case['id'], source=case['source']))
assert len(cases) == 6
write(lab / 'compile-catalog.json', dict(cases=cases))
print('Verified the complete four-file compilation diagnostics, four existing class-cell fixtures and two catalog controls.')
