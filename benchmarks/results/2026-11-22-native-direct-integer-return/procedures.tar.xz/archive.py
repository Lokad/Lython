from pathlib import Path
import gzip,hashlib,json,re,shutil,tarfile

lab=Path(__file__).resolve().parent
out=Path("benchmarks/results/2026-11-22-native-direct-integer-return")
quiet=lab/"quiet"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path,value):
    path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")

identity=read(lab/"identity.json")
for role,files in identity["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {n:sha(image/n) for n in files}==files
    for prefix,name,count in (("","representative.json",8),("semantics-","semantics.json",6)):
        proof=read(lab/f"{role}-{prefix}verify.json")
        assert proof["state"]=="Completed" and proof["caseCount"]==count
        assert proof["catalogSha256"]==sha(lab/name)
allocation=read(lab/"allocation-summary.json")
assert len(allocation)==8 and all(r["allowanceRestored"] and r["referencePeak"]==r["candidatePeak"] for r in allocation)
assert all(row['allowanceRestored'] for row in allocation)
shape=read(lab/"shape-summary.json")
assert shape['cases']==8 and shape['codeObjects']==23 and shape['sameExecutableShape'] and len(shape['eligible'])==5
for platform in ("win","ubuntu"):
    for filename,count in ((f"white-{platform}.log",212),(("public-win.log" if platform=="win" else "public-ubuntu-final.log"),917)):
        log=(lab/filename).read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
reference=lab/"frozen/reference/Lokad.Lython.dll"
packed=Path("benchmarks/results/2026-11-22-native-fixed-returns-refined/candidate-core.dll.gz")
assert gzip.decompress(packed.read_bytes())==reference.read_bytes()
receipt=read(quiet/"archive-receipt.json")
status=read(quiet/"terminal-status.json")
assert status["exitCode"]=="0" and status["receipt"]==receipt and receipt["jobs"]==6
assert not status["remainingWorkers"] and not status["remainingTrace"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha(quiet/"observations.tgz")==receipt["archiveSHA256"]
sources=read(quiet/"identity.json")
assert sources["imageFiles"]==identity["imageFiles"]
cases={c["id"]:c for c in read(quiet/"representative.json")["cases"]}
assert sha(quiet/"representative.json")==sources["catalogSHA256"]
raw=read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and raw["warmupSeconds"]==8 and raw["rounds"]==7 and len(raw["jobs"])==6
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    case=cases[job["case"]]
    for sample in job["samples"]:
        response=sample["response"]
        assert response["completedInvocations"]>0 and response["status"]=="Completed"
        assert response["sourceSha256"]==case["sourceSha256"] and response["fixtureSha256"]==case["fixtureSha256"]
        assert response.get("actualOutputSha256")==case["expectedOutputSha256"] and response.get("actualFilesSha256")==case.get("expectedFilesSha256")
summary=read(quiet/"quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(measuredSources=sources["sourceRevision"],deliveryReference=identity["deliveryReference"],
    sourceImages=identity["imageFiles"],verifiedTimedBatches=168,decision=read(lab/"decision.json"),
    targetedPlatforms={"Windows":"net11.0","Ubuntu":"net10.0"})
out.mkdir(exist_ok=False)
save(out/"summary.json",summary)
for name in ("README.md","shape-summary.json","allocation-summary.json"):
    shutil.copyfile(lab/name,out/name)
for name in ("terminal-status.json","archive-receipt.json","observations.tgz"):
    shutil.copyfile(quiet/name,out/name)
(out/"candidate-core.dll.gz").write_bytes(gzip.compress((lab/"frozen/candidate/Lokad.Lython.dll").read_bytes(),mtime=0))
with tarfile.open(out/"procedures.tar.xz","w:xz",preset=6) as archive:
    for directory in (lab,quiet,lab/"inspect"):
        for p in sorted(directory.iterdir()):
            if p.is_file() and p.suffix not in (".tgz",".dll",".exe"):
                archive.add(p,arcname=p.relative_to(lab).as_posix())
print("Exact source, both frozen images, all goldens, focused tests, and raw batches verified.")
