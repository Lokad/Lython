from pathlib import Path
import json

lab=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
runs=read(lab/"quiet/quiet-summary.json")
ident=read(lab/"identity.json")
decision=read(lab/"decision.json")
alloc=read(lab/"allocation-summary.json")[0]
labels={
    "scripts.csv-invoice.helper-accumulation":"Nested-helper CSV invoice",
    "scripts.csv-invoice.large":"Ordinary CSV invoice",
    "scripts.csv-invoice.method-policy.quoted-control":"Quoted policy CSV invoice",
    "scripts.json-lines-shipment.expanded-options.large":"JSON Lines shipment report",
    "diagnostic.helper-placement.function-call":"Function-scoped helper",
    "diagnostic.helper-placement.module-call":"Module-scoped helper",
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword":"Mixed factory",
}
rows=["| Complete script | Boundary | Elapsed change | Wider process CPU change | Worker spread old/new |",
      "| --- | --- | ---: | ---: | ---: |"]
span=lambda a:f"{min(a):+.2f} to {max(a):+.2f}%"
for row in runs["rows"]:
    phase={"warm":"warm","compile-run":"compile to result"}[row["lane"]]
    rows.append(f"| {labels[row['case']]} | {phase} | {span(row['elapsedChangePercent'])} | {span(row['cpuChangePercent'])} | "
                f"{row['referenceSpreadPercent']:.2f} / {row['candidateSpreadPercent']:.2f}% |")
report=f"""# B1371 Evaluate complete integer returns from supplied operands

Compared the frozen `{ident['reference'][:9]}` core from delivery
`{ident['deliveryReference']}` with `{ident['candidate'][:9]}` on
November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu 24.04.4
and .NET 11 RC3. The rest of the 32-file image is identical, including
the benchmark worker and optional adapter.

A closed arithmetic body can read the caller's supplied positional span.
The compiler uses the existing integer continuations and verifies that
the body returns the chain's result. The runtime still enters through
both managed checks and leaves directly with the existing slot result.
This eliminates the inline frame buffer, argument copy and native
activation dispatch on that edge. Unsupported types and signed
overflow return to the ordinary compiled body before any guest effect.
The base code and both paired images emit the same 23 inspected tapes.
The candidate identifies five eligible bodies without changing the tape.

Warm allocations are flat locally, and all eight admitted peaks
match exactly. Every borrowed allowance returns to baseline. Both
actual images match local CPython 3.13.2 on all eight workloads and
six additional checks covering promotion, signed division, exception
context, reflected protocols, mutable globals and nested calls.

## Quiet comparison

"""+ "\n".join(rows)+f"""

Negative changes favor the candidate. Ranges span all pairings of two
process medians per image. The sample has seven rotating batches per
worker after at least eight seconds of warmup. Warm clocks include the
run, applicable mediated RAM-backed I/O, output verification and
prior-result cleanup. Compile to result adds compilation and disposal
of the compiled owner. Wider CPU also includes the worker's reset and
request handling. Startup remains separate.

All 168 timed batches and both quiet gates passed in
{runs['elapsedSeconds']:.0f} seconds. Workers joined and the raw
archive was checked under the lease before cleanup. The exact source
pair passes 1,129 focused Release checks per platform. The checks
cover genuine async operation transfer, in-flight cancellation and
funded fallback, along with integer promotion and call semantics.
The staged catalog was already verified byte-for-byte in both images.
The quiet lease retires only six aliases of an older core, with
the exact binary and all records preserved in their pushed archives.

## Decision

{decision["readerDecision"]}

[Summary](summary.json) · [Local allocation](allocation-summary.json) ·
[Executable shape](shape-summary.json) · [Raw observations](observations.tgz) ·
[Verification and procedures](procedures.tar.xz) ·
[Paired attribution and baseline](../2026-11-22-retained-call-cpu-profile/README.md).
"""
(lab/"README.md").write_text(report,encoding="utf-8",newline="\n")
