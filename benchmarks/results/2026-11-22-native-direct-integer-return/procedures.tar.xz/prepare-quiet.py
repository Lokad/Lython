from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template_lab = lab.parent/"native-fixed-return-refined-20261122"
template = template_lab/"quiet"
donor = template
catalog_donor = template
out = lab/"quiet"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2)+"\n")

out.mkdir()
config = read(donor/"config.json")
receipt = read(donor/"archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(donor/"observations.tgz")==receipt["archiveSHA256"]
local = read(lab/"identity.json")
files = local["imageFiles"]
assert files["reference"]==config["identity"]["imageFiles"]["candidate"]
assert len(files["reference"])==len(files["candidate"])==32
for role in files:
    image=lab/"frozen"/role
    assert {n:sha(image/n) for n in files[role]}==files[role]
    p=read(lab/f"{role}-verify.json")
    assert p["state"]=="Completed" and p["caseCount"]==8 and p["catalogSha256"]==local["catalogSHA256"]
catalog_config=read(catalog_donor/"config.json")
catalog_receipt=read(catalog_donor/"archive-receipt.json")
assert all(catalog_receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(catalog_donor/"observations.tgz")==catalog_receipt["archiveSHA256"]
assert catalog_config["catalogSHA256"]==local["catalogSHA256"]==sha(catalog_donor/"representative.json")
shutil.copyfile(lab/"representative.json",out/"representative.json")
assert sha(out/"representative.json")==local["catalogSHA256"]
core="Lokad.Lython.dll"
identity=dict(sourceRevision=local["reference"]+" versus "+local["candidate"],
    purpose="Evaluate complete checked scalar returns from supplied operands", imageFiles=files,
    normalAdapterPin="0.4.0",catalogSHA256=local["catalogSHA256"],
    coreSHA256={role+suffix:hashes[core] for role,hashes in files.items() for suffix in ("","-control")})
save(out/"identity.json",identity)
previous=read(template/"config.json")
root="/home/lokad/lython-bench-checks/native-direct-integer-return-b1371-20261122"
unit="lython-b1371-native-direct-integer-return-20261122"
cases=[case["id"] for case in read(out/"representative.json")["cases"]]
assert cases[-1]=="scripts.csv-meter-report.typed-ascii"
jobs=[(cases[4],"warm"),(cases[5],"warm"),(cases[0],"warm"),(cases[2],"warm"),(cases[3],"warm"),(cases[6],"compile-run")]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(template/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit)
    if name=="collect.py":
        start,end=source.index("\njobs = "),source.index("\nassert len(jobs)")
        source=source[:start]+"\njobs = "+repr(jobs)+source[end:]
        source=source.replace("len(jobs)==4","len(jobs)==6").replace("started < 230","started < 360")
    elif name in ("archive-owned.py","retrieve.py"):
        source=source.replace("jobs=4,","jobs=6,").replace("['jobs']==4","['jobs']==6").replace("len(raw['jobs'])==4","len(raw['jobs'])==6")
    write(out/name,source.replace("B1368","B1371"))
assert b"\r" not in (out/"run.sh").read_bytes()
(out/"candidate").mkdir()
shutil.copyfile(lab/"frozen/candidate"/core,out/"candidate"/core)
assert sha(out/"candidate"/core)==files["candidate"][core]
parts=("identity.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked=sum((out/name).stat().st_size for name in parts)
storage=read(lab/"retire-proof.json")
assert storage["free"]+sum(g["bytes"] for g in storage["proof"])>176160768+unpacked+640*1024
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
    sourceFiles=files["reference"],sourceCatalogSHA256=config["catalogSHA256"],
    donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["root"]+"/cpython-worker.py",
    protocolSHA256=config["protocolSHA256"],payloadBytes=payload.stat().st_size,
    catalogDonor=catalog_config["root"],catalogDonorArchiveSHA256=catalog_receipt["archiveSHA256"],
    payloadSHA256=sha(payload),retireGroups=storage['proof'],catalogSHA256=identity["catalogSHA256"],unpackedBytes=unpacked)
save(out/"config.json",stage)
remote=(template/"remote-launch.py").read_text(encoding="utf-8")
start,end=remote.index("\nc=")+1,remote.index("\nb=Path(")
remote=remote[:start]+"c="+repr(stage)+remote[end:]
assert "os.link(catalog_donor/'representative.json',root/'representative.json')" in remote
assert remote.count("RuntimeMaxSec=295")==1
write(out/"remote-launch.py",remote.replace("lython-b1368-fixtures","lython-b1371-fixtures").replace("RuntimeMaxSec=295","RuntimeMaxSec=385"))
write(lab/"launch.py",(template_lab/"launch.py").read_text(encoding="utf-8").replace("Refined nested fixed return comparison","Direct arithmetic return comparison").replace("265","365"))
write(lab/"summarize.py",(template_lab/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==4","len(raw['jobs'])==6"))
(lab/"measured-source.patch").write_bytes(subprocess.check_output(["git","diff",local["reference"],local["candidate"],"--","src","tests"],cwd=repo))
print("Staged six targeted complete-script phases, exact source and both image goldens.")
