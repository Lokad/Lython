from pathlib import Path
import gzip, hashlib, json, os, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
worktree = repo / ".git/agent-worktrees/native-direct-integer-return-20261122"
donor = lab.parent / "native-fixed-return-refined-20261122"
donor_quiet = donor / "quiet"
shape_donor = lab.parent / "module-helper-placement-20261122"
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")

base_id = read(donor_quiet / "identity.json")
reference = donor / "frozen/candidate"
files = base_id["imageFiles"]["candidate"]
assert len(files) == 32 and {n: sha(reference / n) for n in files} == files
assert gzip.decompress((repo / "benchmarks/results/2026-11-22-native-fixed-returns-refined/candidate-core.dll.gz").read_bytes()) == (reference / core).read_bytes()
candidate = subprocess.check_output(["git","rev-parse","HEAD"],cwd=worktree,text=True).strip()
assert candidate.startswith(read(lab/"candidate-source.json")["revision"])
assert not subprocess.check_output(["git","status","--porcelain"],cwd=worktree)
assert "0 Error(s)" in (lab / "build-committed-win.log").read_text(encoding="utf-8")

build = worktree / "artifacts/b1371-win-build/bin/Lokad.Lython.Benchmarks/release_net11.0"
catalog=lab/"representative.json"
shutil.copyfile(donor/"representative.json",catalog)
cases=read(catalog)["cases"]
assert len(cases)==8 and sha(catalog)==base_id["catalogSHA256"]
out = lab / "frozen"
inspect = lab / "inspect/bin/Release/net11.0"
allocation = shape_donor / "allocation-worker"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == read(donor_quiet/"config.json")["protocolSHA256"]
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
hashes = {}
for label, source in (("reference",reference),("candidate",build)):
    image = out / label
    image.mkdir(parents=True)
    for name in files:
        shutil.copyfile((source if name == core else reference)/name,image/name)
    hashes[label] = {name:sha(image/name) for name in files}
    for name in ("Inspect.dll","Inspect.deps.json","Inspect.runtimeconfig.json"):
        shutil.copyfile(inspect/name,image/name)
    for name in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(allocation/name,image/name)
    verify = lab / f"{label}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verify],
        env=env,timeout=95,check=True)
    proof=read(verify)
    assert proof["state"]=="Completed" and proof["caseCount"]==len(cases) and proof["catalogSha256"]==sha(catalog)
    subprocess.run([dotnet,image/"Inspect.dll",catalog,lab/f"{label}-shape.json"],env=env,timeout=45,check=True)
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,lab/f"{label}-allocation.json"],env=env,timeout=95,check=True)
    assert {name:sha(image/name) for name in files}==hashes[label]
assert hashes["reference"]==files
assert [n for n in files if hashes["reference"][n] != hashes["candidate"][n]]==[core]
identity=dict(reference=base_id["sourceRevision"].split()[-1],deliveryReference="880c6d958",candidate=candidate,imageFiles=hashes,catalogSHA256=sha(catalog))
save(lab/"identity.json",identity)

old_shape,new_shape = (read(lab/f"{label}-shape.json") for label in ("reference","candidate"))
assert old_shape["coreSHA256"]==files[core] and new_shape["coreSHA256"]==hashes["candidate"][core]
eligibility=[]
for left,right in zip(old_shape["rows"],new_shape["rows"],strict=True):
    assert left["id"]==right["id"]
    for a,b in zip(left["codes"],right["codes"],strict=True):
        assert a.pop("directIntegerReturn",None) is None
        if b.pop("directIntegerReturn",False):
            eligibility.append({"case":right["id"],"name":b["name"],"locals":b["locals"],"instructions":b["instructions"]})
        assert a==b
assert any(r["case"]=="diagnostic.helper-placement.function-call" and r["name"]=="evaluate" for r in eligibility)
shape=dict(cases=len(cases),codeObjects=sum(len(row["codes"]) for row in old_shape["rows"]),sameExecutableShape=True,eligible=eligibility)
save(lab/"shape-summary.json",shape)

old_alloc,new_alloc = (read(lab/f"{label}-allocation.json")["rows"] for label in ("reference","candidate"))
changes = []
for left,right in zip(old_alloc,new_alloc,strict=True):
    assert left["id"]==right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    a,b=[statistics.median(x["allocatedBytesPerInvocation"]) for x in (left,right)]
    row=dict(case=left["id"],referenceBytes=a,candidateBytes=b,allocationChangePercent=100*(b/a-1),
        referencePeak=left["peakExecutionMemoryBytes"],candidatePeak=right["peakExecutionMemoryBytes"],allowanceRestored=True)
    changes.append(row)
    print(row)

save(lab/"allocation-summary.json",changes)
