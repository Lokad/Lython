from pathlib import Path
import gzip,hashlib,io,json,shlex,subprocess,tarfile
base=Path('.git/agent-notes/review-20261031')
lab=base/'retained-definition-attribution-20261122'
donor=base/'retained-csv-cpython-20261122/quiet'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
assert load(donor/'terminal-status.json')['exitCode']=='0'

latest=base/'regex-index-borrow-combined-20261122/quiet'
latest_status=load(latest/'terminal-status.json')
assert latest_status['exitCode']=='0' and latest_status['receipt']['allWorkersJoined'] and latest_status['receipt']['guestFixturesRemoved']
assert sha((latest/'observations.tgz').read_bytes())==latest_status['receipt']['archiveSHA256']
observed=load(donor/'archive-receipt.json')
assert observed['complete'] and observed['allWorkersJoined'] and observed['guestFixturesRemoved']
assert sha((donor/'observations.tgz').read_bytes())==observed['archiveSHA256']
candidates=[('inline-keyword-default-20261121','2026-11-21-inline-keyword-default'),('direct-float-text-20261122','2026-11-22-direct-float-text'),
            ('regex-local-one-shot-20261121','2026-11-21-regex-local-one-shot'),('sparse-lexical-work-20261122','2026-11-22-sparse-lexical-preparation')]
old={}
for local,folder in candidates:
    cfg=load(base/local/'quiet/config.json')
    root=Path(cfg['root']).name
    old[root+'/candidate/Lokad.Lython.dll']=(folder,cfg)
source_folder=Path(load(donor/'config.json')['root']).name
# Inspect only older frozen inputs after the benchmark's terminal receipt.
code='''from pathlib import Path
import json,os,shutil,stat,sys
b=Path('/home/lokad/lython-bench-checks')
seen={}
for name in json.loads(sys.argv[1]):
 p=b/name
 if p.is_file() and p.resolve()==p and stat.S_ISREG(p.lstat().st_mode):
  m=p.lstat();key=(m.st_dev,m.st_ino);seen[key]=dict(path=name,size=m.st_size,links=m.st_nlink,aliases=[])
for directory,dirs,files in os.walk(b):
 for n in files:
  p=Path(directory)/n;m=p.lstat();key=(m.st_dev,m.st_ino)
  if key in seen:seen[key]['aliases'].append(str(p.relative_to(b)))
print(json.dumps(dict(free=shutil.disk_usage(b).free,groups=list(seen.values()))))'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
reply=subprocess.check_output(ssh+['python3 -c '+shlex.quote(code)+' '+shlex.quote(json.dumps(list(old)))],timeout=35)
(lab/'vm-frozen-duplicates.json').write_bytes(reply)
data=json.loads(reply)
qualified=[]
for group in sorted(data['groups'],key=lambda g:g['links']):
    if group['links']!=len(group['aliases']) or any(Path(n).parts[0]==source_folder for n in group['aliases']): continue
    origin, cfg = old[group['path']]
    core_path='benchmarks/results/'+origin+'/candidate-core.dll.gz'
    core=gzip.decompress(subprocess.check_output(['git','show','origin/master:'+core_path]))
    assert len(core)==group['size'] and sha(core)==cfg['identity']['imageFiles']['candidate']['Lokad.Lython.dll']
    archives={}
    for alias in group['aliases']:
        relative=Path(alias)
        remote=relative.parts[0]
        if len(relative.parts)!=3 or relative.name!='Lokad.Lython.dll':break
        found=[]
        for config in (*base.glob('*/quiet/config.json'), *base.glob('*/confirmation/config.json')):
            stage=load(config)
            receipts=config.parent/'archive-receipt.json'
            if Path(stage.get('root','')).name==remote and receipts.exists():found.append(receipts)
        if len(found)!=1:break
        proof=load(found[0])
        digest=proof.get('archiveSHA256')
        if not digest or not proof.get('complete') or not proof.get('archivedAndVerifiedUnderLease'):break
        files=subprocess.run(['rg','-l',digest,'benchmarks/results','-g','archive-receipt.json'],capture_output=True,text=True,encoding='utf-8')
        if files.returncode!=0:break
        verified=False
        for r in files.stdout.splitlines():
            tracked=(Path(r).parent/'observations.tgz').as_posix()
            check=subprocess.run(['git','show','origin/master:'+tracked],capture_output=True)
            if check.returncode==0 and sha(check.stdout)==digest:verified=True;break
        if not verified: break
        archives[remote+'/observations.tgz']=digest
    else:
        qualified.append(dict(paths=group['aliases'],bytes=len(core),links=group['links'],sha256=sha(core),archives=archives,optional=False))
        break
assert qualified,'No older immutable core has proof for every alias. Keep the current VM evidence.'

(lab/'retire-proof.json').write_text(json.dumps(dict(proof=qualified,freeBefore=data['free']),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(free=data['free'],selected=qualified)))
