from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
base=lab.parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-22-retained-definition-attribution"
load=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load(lab/"archive-receipt.json")
identity=load(lab/"identity.json")
terminal=load(lab/"terminal-status.json")
assert identity["sourceRevision"].startswith("318bf0e0a")
assert receipt==terminal["receipt"] and terminal["exitCode"]=="0"
for key in ("complete","allWorkersJoined","quietBeforeAndAfter","guestFixturesRemoved",
            "archivedAndVerifiedUnderLease","persistentTraceArchivedAndVerifiedBeforeUnmount"):
    assert receipt[key]
assert sha(lab/"observations.tgz")==receipt["archiveSHA256"]
files=identity["imageFiles"]["candidate"]
assert len(files)==32 and {n:sha(base/"regex-index-borrow-combined-20261122/frozen/reference"/n) for n in files}==files
assert load(lab/"verify.json")["state"]=="Completed" and sha(lab/"catalog.json")==identity["catalogSHA256"]
for row in load(lab/"attribution.json")["rows"]:
    record=load(lab/"retrieved/profiles"/row["label"]/"record.json")
    assert record["workload"]==row["case"] and record["exitCode"]==0 and record["closed"]["status"]=="Closed"
    assert record["verificationBefore"]["status"]==record["verificationAfter"]["status"]=="Equivalent"
    assert record["response"]["completedInvocations"]>0
    assert all(b["status"]=="Completed" and b["actualOutputSha256"]==record["verificationBefore"]["actualOutputSha256"] for b in record["batches"])
out.mkdir(exist_ok=False)
for name in ("observations.tgz","archive-receipt.json","attribution.json","terminal-status.json","README.md"):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as dst:
    for name in ("archive.py","launch.py","remote-launch.py","ops-profile.py","collect.py",
                 "analyze.py","retrieve.py","run.sh","identity.json","config.json","catalog.json","verify.json",
                 "launch.log","observe-not-before.json","retire-proof.json","verify-remote-duplicates.py","prepare.py"):
        dst.add(lab/name,arcname=name)
print("B1329 raw profiles, identity, verification and analysis archived.")
