from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
base = lab.parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))

donor = base / "retained-csv-cpython-20261122/quiet"
receipt = load(donor / "archive-receipt.json")
donor_config = load(donor / "config.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(donor / "observations.tgz") == receipt["archiveSHA256"]
image = base / "regex-index-borrow-combined-20261122/frozen/reference"
files = donor_config["identity"]["imageFiles"]["candidate"]
assert len(files) == 32 and {name: sha(image / name) for name in files} == files
assert gzip.decompress(Path("benchmarks/results/2026-11-22-retained-csv-cpython/measured-core.dll.gz").read_bytes()) == (image / "Lokad.Lython.dll").read_bytes()
catalog = sha(lab / "catalog.json")
verify = load(lab / "verify.json")
assert verify["catalogSha256"] == catalog and verify["caseCount"] == 3 and verify["state"] == "Completed"
parts = ("collect.py", "ops-profile.py", "run.sh", "catalog.json", "identity.json")
unit = "lython-b1329-retained-definition-attribution-20261122"
root = "/home/lokad/lython-bench-checks/retained-definition-attribution-b1329-20261122"
identity = dict(sourceRevision=donor_config["identity"]["productionEquivalent"],
    purpose="Current mixed and dynamic definition CPU attribution", coreSHA256=dict(candidate=files["Lokad.Lython.dll"]),
    imageFiles=dict(candidate=files), catalogSHA256=catalog, diagnosticOnly=True)
save = lambda path, contents: path.write_text(contents, encoding="utf-8", newline="\n")
save(lab / "identity.json", json.dumps(identity, indent=2) + "\n")
payload = lab / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(lab / name, arcname=name)
proof=load(lab/"retire-proof.json")
# The floor and archive reserve are those already used for the earlier profile.
unpacked = sum((lab / name).stat().st_size for name in parts)
minimum = 176160768 + unpacked + 4 * 1024 * 1024
retire = [] if proof["freeBefore"] > minimum else [group for group in proof["proof"] if not group.get("optional")]
assert proof["freeBefore"] + sum(group["bytes"] for group in retire) > minimum
configuration = dict(root=root, unit=unit, source=donor_config["root"], sourceFiles=dict(candidate=files),
    sourceCatalogSHA256=donor_config["catalogSHA256"], catalogSHA256=catalog, identity=identity, retireGroups=retire,
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=unpacked, donorArchive=receipt["archiveSHA256"])
save(lab / "config.json", json.dumps(configuration, indent=2) + "\n")
old = (base / "retained-factory-attribution-20261122/remote-launch.py").read_text(encoding="utf-8")
start, end = old.index("\nc=") + 1, old.index("\nb=Path(")
old = old[:start] + "c=" + repr(configuration) + old[end:]
old = old.replace("lython-b1310-fixtures", "lython-b1329-fixtures")
guard = "  m=ps[0].lstat();key=(m.st_dev,m.st_ino);assert key not in inodes;inodes[key]=[]"
assert guard in old
old = old.replace(guard, "  for name,digest in proof['archives'].items():\n   archive=b/name;assert archive.resolve()==archive and archive.is_relative_to(b) and sha(archive)==digest\n" + guard)
save(lab / "remote-launch.py", old)
print(f"Verified current 32-file image and three CPython goldens. Stage payload {payload.stat().st_size} bytes.")
