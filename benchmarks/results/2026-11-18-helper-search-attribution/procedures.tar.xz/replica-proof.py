from pathlib import Path
import fcntl, hashlib, json, shutil, stat, os
base=Path('/home/lokad/lython-bench-checks').resolve()
with (base/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    rows=[]
    for proof in [{'canonical': 'benchmarks/results/2026-11-18-trimmed-split-join/observations.tgz', 'canonicalSHA256': '9487e3f7b5487dc146f0e6bc2622873f171ce5e72ee82992db78896b201467e5', 'sha256': '3d4f0dc3aa94cf4cb9da86314b9747977ea8dd2b937a0c6fe79a03aefae76572', 'bytes': 481503, 'member': 'confirmation/confirmation.json', 'links': 1, 'paths': ['trimmed-split-join-b981-20261118/confirmation/confirmation.json'], 'optional': True, 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True}, {'canonical': 'benchmarks/results/2026-11-18-normalization-cpython-checkpoint/observations.tgz', 'canonicalSHA256': 'fdd3ba1b9af26eb2f4b73ede6ec1d4004b1c3df6fde068e3a1fc305f8f073437', 'sha256': 'f98c60991e03c4f6551083ba9c741b53bcd081964ecfce8b161aeb7c7c0270ee', 'bytes': 362367, 'member': 'confirmation/confirmation.json', 'links': 1, 'paths': ['trimmed-split-cpython-b982-20261118/confirmation/confirmation.json'], 'optional': True, 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True}, {'canonical': 'benchmarks/results/2026-11-18-private-line-count/observations.tgz', 'canonicalSHA256': 'ded3e5dba30dfd221e7e2cbf74103baf9de83098e55ddd6221dfecb7abbea45c', 'sha256': 'bbcd80b516885cb859abb53d20cbe23bc478279c4d178dba0c8a0a889fcb7b7c', 'bytes': 480566, 'member': 'confirmation/confirmation.json', 'links': 1, 'paths': ['split-line-count-b983-20261118/confirmation/confirmation.json'], 'optional': True, 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True}, {'canonical': 'benchmarks/results/2026-11-18-line-count-cpython-checkpoint/observations.tgz', 'canonicalSHA256': 'd2b5bc001532fcde2a5005d5cd5a33234bd52aaa5ebcdfb6109cd746be818630', 'sha256': '7a35f747531b7054e60a36b97405a23a888c68082ed881651e534079fcc0c682', 'bytes': 364121, 'member': 'confirmation/confirmation.json', 'links': 1, 'paths': ['line-count-cpython-b984-20261118/confirmation/confirmation.json'], 'optional': True, 'kind': 'exact committed raw observation replica', 'committedBlobVerified': True}]:
        path=base/proof['paths'][0]
        if not path.exists(): continue
        info=path.lstat()
        assert path.is_relative_to(base) and path.resolve()==path and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid()
        assert info.st_nlink==1 and info.st_size==proof['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256'],str(path)
        rows.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,retireOptions=rows)))
