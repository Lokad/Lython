from pathlib import Path
from hashlib import sha256
import json, os, subprocess

repo=Path.cwd(); notes=repo/'.git/agent-notes/review-20261031'
lab=notes/'helper-search-profile-r561'; source=notes/'syntax-validity-r559'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:sha256(p.read_bytes()).hexdigest()
prior=read(source/'quiet/config.json'); core=source/'frozen/candidate'; files=prior['identity']['imageFiles']['candidate']
assert len(files)==32 and all(sha(core/n)==h for n,h in files.items())
assert sha(source/'representative.json')==prior['catalogSHA256']
x=read(source/'representative.json'); y=read(notes/'search-costs-r441/profile/catalog.json')
helper=next(c for c in x['cases'] if c['id']=='scripts.text-normalization.helper-list')
protected=next(c for c in y['cases'] if c['id']=='scripts.file-search.large.protected')
x['cases']=[helper,protected]
x['performanceQualified']=False
catalog=lab/'catalog.json'; catalog.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verification.log').open('w',encoding='utf-8') as target:
    subprocess.run([dotnet,core/'Lokad.Lython.Benchmarks.dll','--compare','verify',
                 '--catalog',catalog,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                 '--out',lab/'verification.json'],cwd=repo,env=env,stdout=target,stderr=subprocess.STDOUT,check=True,timeout=90)
assert all(sha(core/n)==h for n,h in files.items())
print('Paired helper/protected catalog, exact image and both CPython goldens verified.')
