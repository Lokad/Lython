from pathlib import Path
from hashlib import sha256
import ast, json, shutil, subprocess, tarfile

repo=Path.cwd(); notes=repo/'.git/agent-notes/review-20261031'; lab=notes/'helper-search-profile-r561'; q=lab/'quiet'
old=notes/'normalization-cpu-r554'; phase=notes/'current-helper-phases-r560'; base=notes/'syntax-validity-r559'
read=lambda p:p.read_text(encoding='utf-8-sig')
sha=lambda data:sha256(data).hexdigest()
load=lambda p:json.loads(read(p))
def write(p,text):
    if p.suffix=='.py': ast.parse(text)
    p.write_text(text,encoding='utf-8',newline='\n')
def save(p,data): write(p,json.dumps(data,indent=2)+'\n')

terminal=load(phase/'terminal-status.json'); assert not terminal['live'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert load(phase/'archive-receipt.json')['complete']
assert sha((phase/'observations.tgz').read_bytes())==terminal['receipt']['archiveSHA256']
prior=load(base/'quiet/config.json'); manifest=prior['identity']['imageFiles']['candidate']
assert len(manifest)==32 and all(sha((base/'frozen/candidate'/n).read_bytes())==h for n,h in manifest.items())
assert '2 cases, 0 failed cases' in read(lab/'verification.log')
catalog=lab/'catalog.json'; cases=[c['id'] for c in load(catalog)['cases']]
assert cases==['scripts.text-normalization.helper-list','scripts.file-search.large.protected']
root='/home/lokad/lython-bench-checks/helper-search-profile-b987-20261118'; unit='lython-b987-helper-search-profile-20261118'
old_config=load(old/'quiet/config.json')
head=load(phase/'identity.json')['sourceRevision']
identity=dict(sourceRevision=head,purpose='Current RAM-backed helper normalization and protected-search CPU attribution',
    coreSHA256={'candidate':manifest['Lokad.Lython.dll']},imageFiles={'candidate':manifest},catalogSHA256=sha(catalog.read_bytes()),
    diagnosticOnly=True,publicationHeld=True)
q.mkdir()
save(q/'identity.json',identity)
shutil.copyfile(catalog,q/'catalog.json')
paths=[('helper',cases[0],'warm'),('protected',cases[1],'warm')]
ops=read(old/'quiet/ops-profile.py').replace(old_config['root'],root).replace("[('normalization', 'scripts.text-normalization.large', 'warm')]",repr(paths))
ops=ops.replace('        count = 256 # Correct128x64warmup shortfall; original failedcondition retained. Same8s warmup/5s capture/12s total guest cap.', '        count = 256 if name == "helper" else 512')
write(q/'ops-profile.py',ops)
collection=read(old/'quiet/collect.py').replace(old_config['root'],root).replace("['normalization']","['helper','protected']").replace('len(records)==1','len(records)==2')
collection=collection.replace('R554/B980 retained production b810f660b/frozen93739eed; normalization attribution; no elapsed comparison', f'R561/B987 {head}/frozen610d403d; helper and protected-search attribution')
write(q/'collect.py',collection)
write(q/'run.sh',read(old/'quiet/run.sh').replace(old_config['root'],root)); assert b'\r' not in (q/'run.sh').read_bytes()
members=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
with tarfile.open(q/'payload.tgz','w:gz') as tgz:
    for n in members: tgz.add(q/n,arcname=n)
needed=sum((q/n).stat().st_size for n in members)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
inspect=read(phase/'replica-proof.py')
write(lab/'replica-proof.py',inspect)
space=json.loads(subprocess.check_output(ssh+['python3 -'],input=inspect.encode('utf-8'),timeout=55)); save(lab/'space.json',space)
chosen=[]; available=space['freeBytes']
for row in space['retireOptions']:
    if available > 254*1024*1024+needed+155648: break
    assert '/confirmation/confirmation.json' in row['paths'][0]; available+=row['bytes']; chosen.append(row)
assert available > 254*1024*1024+needed+155648,(space,needed)
payload=q/'payload.tgz'
cfg=dict(root=root,unit=unit,source=prior['root'],sourceFiles=manifest,sourceCatalogSHA256=prior['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=chosen,payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload.read_bytes()),unpackedBytes=needed)
save(q/'config.json',cfg)
text=read(old/'quiet/remote-launch.py'); a,b=text.index('\nc=')+1,text.index('\nb=Path(')
write(q/'remote-launch.py',(text[:a]+'c='+repr(cfg)+text[b:]).replace('lython-b980-fixtures','lython-b987-fixtures'))
write(q/'launch.py',read(old/'quiet/launch.py').replace('B980','B987'))
write(q/'retrieve.py',read(old/'quiet/retrieve.py').replace('B980','B987'))
analysis=read(old/'quiet/analyze.py').replace("['normalization']","['helper','protected']")
analysis=analysis.replace("'split construction':('BuildSplitResult','SplitCore','TryReadSplitRange'),", "'split construction':('BuildSplitResult','SplitCore','TryReadSplitRange','CreateSplitFragment'),\n     'native calls':('StartNativeCall','TryInvokeClosedReceiver','InvokeReceiverMethod','CallFunction'),\n     'protected reads':('TryReadLine','ReadLineAsync','MoveNextLine','FileIterator'),")
write(q/'analyze.py',analysis)
print('Ready for the paired RAM-backed profiling capture.', dict(dataBytes=needed,archivedReplicaCount=len(chosen)))
