# B1286 joint lexical definition admission

The prototype groups newly retained closure cells and capture backing with
the callable and its final annotation storage in one allowance request.
It commits the capture storage independently once the cells are available
to the parent. The still-private callable can release its own reservation
on failure. Namespace-dependent captures continue to use the existing
separate path.

Reference `256c5e651` and prototype `f1ace4677` ran November 21, 2026 UTC
on the quiet Azure F4as_v7 with Ubuntu 24.04.4 and .NET 11 RC3. Two
processes per source warmed for at least eight seconds and contributed
seven rotated batches per lane. Ranges cover all four pairings of process
medians. Warm elapsed includes guest execution, captured stdout,
verification and prior-result disposal. Time to result also includes
compilation and code-owner disposal. These scripts do no guest file I/O.
Process CPU covers the full request. Startup and final teardown are separate.

{{results}}

Local counts show 10,265 allowance growths per nested factory invocation
on the reference and 8,217 on the prototype. Eager rules without new
captured cells remain at 6,169 and the fully supplied helper remains at
seven. CLR allocations and accounted peaks match on the three factory
cases. All seven locally checked cases return their allowance to baseline.

Both complete 32-file images verify against seven local goldens and
against the four goldens in the quiet catalog. Windows .NET 11 and
Ubuntu .NET 10 each pass 133 white-box and 587 public focused tests.

{{decision}}

All 140 timed batches passed. Workers joined, guest fixtures were removed
and persistent observations were verified under the lease.

[Timing](summary.json) · [Execution allocation](allocation-summary.json)
· [Reference admission counts](reference-growths.json)
· [Prototype admission counts](candidate-growths.json)
· [Raw observations](observations.tgz)
· [Source, tests and procedures](checks-and-procedures.tar.xz).
