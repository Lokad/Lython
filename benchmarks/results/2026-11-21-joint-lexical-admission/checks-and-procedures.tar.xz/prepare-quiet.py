from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
prior = lab.parent / "current-factories-cpython/quiet"
template = lab.parent / "shared-function-binding-facts-on-current/quiet"
quiet = lab / "quiet"
repo = lab.parents[3]
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


index = load(lab / "identity.json")
previous = load(prior / "config.json")
previous_receipt = load(prior / "archive-receipt.json")
assert previous_receipt["complete"] and previous_receipt["archivedAndVerifiedUnderLease"]
assert previous_receipt["archiveSHA256"] == sha(prior / "observations.tgz")
prior_template = load(template / "config.json")

images = index["imageFiles"]
source_files = previous["identity"]["imageFiles"]["candidate"]
assert index["reference"].startswith("256c5e651") and source_files == images["reference"]
assert len(source_files) == 32 and previous["cpythonWorkerSHA256"] == index["pythonWorkerSHA256"]
assert [name for name in source_files if source_files[name] != images["candidate"][name]] == [core]

postponed = "scripts.annotated-rule-closures.nested-factories.postponed"
jobs = [
    (postponed, "warm"),
    (postponed, "compile-run"),
    ("scripts.annotated-rule-closures.nested-factories", "warm"),
    ("scripts.ordinary-fully-supplied-helper", "warm"),
    ("scripts.annotated-rule-closures", "warm"),
]
catalog = load(lab / "representative.json")
assert sha(lab / "representative.json") == index["catalogSHA256"]
catalog["cases"] = [row for row in catalog["cases"] if row["id"] in {case for case, _ in jobs}]
assert len(catalog["cases"]) == 4
manifest = lab / "quiet-catalog.json"
save(manifest, catalog)
usage = (lab / "freeze.log").read_text(encoding="utf-8-sig")
assert usage.count("Supervised smoke: 7 cases, 0 failed cases;") == 2
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
for role, files in images.items():
    image = lab / "frozen" / role
    assert {name: sha(image / name) for name in files} == files
    check = lab / f"quiet-{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", repo / "benchmarks/cpython-worker.py", "--out", check],
                   check=True, env=env, timeout=120)
    verification = load(check)
    assert verification["state"] == "Completed" and verification["caseCount"] == 4
    assert verification["catalogSha256"] == sha(manifest)

# This stage reuses the immediately preceding frozen core. Its log and
# archive overhang was less than one MiB. Six MiB remains allocated to
# staging overhead above the unchanged persistent disk floor.
retire = []
root = "/home/lokad/lython-bench-checks/joint-lexical-admission-b1286-20261121"
unit = "lython-b1286-joint-lexical-admission-20261121"
quiet.mkdir(exist_ok=False)
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="One admission for the lexical callable and captured cells",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    text = read(template / name).replace(prior_template["root"], root).replace(prior_template["unit"], unit)
    if name == "collect.py":
        begin = text.index("\njobs = ")
        end = text.index("\nassert len(jobs)", begin)
        text = text[:begin] + "\njobs = " + repr(jobs) + text[end:]
    emit(quiet / name, text)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
(quiet / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, quiet / "candidate" / core)
shutil.copyfile(manifest, quiet / "representative.json")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=previous["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=previous["catalogSHA256"],
              donorArchiveSHA256=previous_receipt["archiveSHA256"], catalogSHA256=identity["catalogSHA256"],
              retireGroups=retire, protocolSource=previous["root"] + "/cpython-worker.py",
              protocolSHA256=index["pythonWorkerSHA256"], payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload), unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
code = read(template / "remote-launch.py")
begin = code.index("\nc=") + 1
end = code.index("\nb=Path(", begin)
code = code[:begin] + "c=" + repr(config) + code[end:]
emit(quiet / "remote-launch.py", code.replace("lython-b1284-fixtures", "lython-b1286-fixtures")
     .replace("c['unpackedBytes']+8*1024*1024", "c['unpackedBytes']+6*1024*1024"))
emit(lab / "launch.py", read(template.parent / "launch.py")
     .replace("Compiled call metadata comparison", "Joint lexical admission comparison"))
shutil.copyfile(template.parent / "summarize.py", lab / "summarize.py")
