set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/joint-lexical-admission-on-current
white='Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Capture|FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~FunctionExecutionBoundary|FullyQualifiedName~ExecutableFunctionInvocationBoundary|FullyQualifiedName~FunctionAttributeAccounting)'
public='Category!=Stress&(FullyQualifiedName~Closure|FullyQualifiedName~Capture|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~FunctionAttributeAccountingScenario|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~AnnotationEvaluation|FullyQualifiedName~Dataclass)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" | tee "$logs/public-ubuntu.log"
