set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/deferred-definition-r651
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/deferred-definition-r651
fixture=tests/artifacts/r651-wsl/bin/Lokad.Lython.WorkerFixture/release_net10.0
expected=tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0
mkdir -p "$expected"
cp -R "$fixture"/. "$expected"
log="$logs/focused-fixture-wsl-net10-corrected.log"
code=0
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r651-wsl" --filter '(FullyQualifiedName~PreparedFunctionDefaultsTests|FullyQualifiedName~StackGuardScenario)&Category!=Stress' > "$log" 2>&1 || code=$?
tail -18 "$log"
exit "$code"
