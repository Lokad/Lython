# R159 bounded current configuration comparison
Three existing lanes: compilation, warm execution, compile-to-result. Unchanged
complete config-edit.py, input/output JSON fixtures and stdout/file goldens. Two
independent CPython and two current Lython processes;5s warmup each,7rotated150ms
rounds. Stock CPython3.13.16, actual.NET11RC3, normal GC/tiering. Same existing
worker/protocol. Reuse verified R157 cfeb nonincremental freeze: production bytes
match7c10322c/current038f, creation revision3fb plus R157 source explicit. Never
relabel the binary as a new post-commit build. No source restore or new producer.
Warm includes actual mediated RAM-file I/O, full output validation and prior-result
cleanup; compile includes prior-script disposal; complete combines both. Startup,
fixture reset/protocol and final cache teardown excluded. CPython compiles source
directly, no AST rewrite. Independent process spread remains uncertainty. This
does not predict a setup cause or an individual R157 gain. Keep original historical
config ratios/capture separate; only this material gap, no15job refresh/framework.
Finite150sowner+30stop+30margin, reserve30s for final work/cleanup, expected95s.
Persistent workers/catalog/raw apart from RAM fixtures; source/aux/reference/golden/
quiet/funding/Closed/join/unmount/archive-underlease/localSHA gates. Original240MiB
OS floor and12MiB headroom unchanged. If needed, recover only exact redundant
remote B508 compressed archive with byte-identical Git-tracked local copy, fresh
idle/single-alias/SHA/metadata/parents/persisted-plan proof; all raw/receipts/frozen
workers survive. Do not retry timed work solely because an observation expires.
Current-source compilation/warm/complete evidence must precede any initialization
redesign. Full R157 platform/Stress/package checkpoint remains separate; publication
postponed and independent regex work unaffected.
