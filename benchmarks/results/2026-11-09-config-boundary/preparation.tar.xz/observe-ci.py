from pathlib import Path
from datetime import datetime, timedelta, timezone
import json, subprocess

r = Path(__file__).parent
state = json.loads((r/'ci-active.json').read_text(encoding='utf-8-sig'))
now = datetime.now(timezone.utc)
deadline = datetime.fromisoformat(state['observeNotBeforeUTC']).astimezone(timezone.utc)
if state['state'] == 'completed' or now < deadline:
    print('No query:', state['state'], 'next observation', deadline.isoformat())
    raise SystemExit()
done = subprocess.run(['gh', 'run', 'view', str(state['id']), '--repo', 'Lokad/Lython', '--json',
                       'status,conclusion,headSha,jobs,url,createdAt'], capture_output=True, encoding='utf-8', check=True)
run = json.loads(done.stdout)
observation = r / ('ci-observation-' + now.strftime('%Y%m%dT%H%M%SZ') + '.json')
observation.write_text(done.stdout, encoding='utf-8')
state.update(state=run['status'], lastObservationUTC=now.isoformat(), observeNotBeforeUTC=(now+timedelta(minutes=5)).isoformat())
(r/'ci-active.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
if run['status'] == 'completed':
    (r/'ci-terminal.json').write_text(done.stdout, encoding='utf-8')
print(run['status'], run['conclusion'], [(j['name'], j['status'], j['conclusion']) for j in run['jobs']])
