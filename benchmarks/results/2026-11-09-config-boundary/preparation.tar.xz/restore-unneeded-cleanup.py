from pathlib import Path
import hashlib,json,shlex,subprocess
r=Path(__file__).parent
plan=json.loads((r/'space-recovery.json').read_text(encoding='utf-8'))
required=json.loads((r/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']
assert plan['beforeFreeBytes']>required and len(plan['files'])==1
entry=plan['files'][0];payload=Path(entry['preservedLocal']).read_bytes()
assert hashlib.sha256(payload).hexdigest()==entry['sha256']
source='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,sys
base=Path('/home/lokad/lython-bench-checks');entry=ENTRY
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 target=Path(entry['path']);assert target.parent.parent==base and target.resolve()==target and not target.exists()
 for e in entry['parents']:
  p=Path(e['path']);s=p.lstat();assert stat.S_ISDIR(s.st_mode)and not p.is_symlink()and s.st_uid==e['uid']and s.st_gid==e['gid']and oct(s.st_mode)==e['mode']
 data=sys.stdin.buffer.read(entry['size']+1);assert len(data)==entry['size']and hashlib.sha256(data).hexdigest()==entry['sha256']
 assert shutil.disk_usage(base).free>entry['size']+REQUIRED
 stage=target.with_name('observations.restore-b509.tmp')
 with stage.open('xb')as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.chmod(stage,stat.S_IMODE(int(entry['mode'],8)));s=stage.lstat()
 assert s.st_uid==entry['uid']and s.st_gid==entry['gid']and s.st_nlink==1
 os.link(stage,target);assert target.stat().st_ino==s.st_ino;stage.unlink()
 assert target.stat().st_nlink==1 and hashlib.sha256(target.read_bytes()).hexdigest()==entry['sha256']
 result=dict(restoredExactArchive=True,sha256=entry['sha256'],path=str(target),originalModeOwnerGroupRestored=True,freshIdleLease=True,noTimedWorkStarted=True,reason='Fresh free space already exceeded original payload/floor requirement. Preparatory duplicate cleanup unnecessary; restore exact tracked bytes without overwriting another file.',freeBytes=shutil.disk_usage(base).free)
 (base/'config-boundary-b509-unneeded-cleanup-restored.json').write_text(json.dumps(result,indent=2)+'\\n')
 print(json.dumps(result))
'''.replace('ENTRY',repr(entry)).replace('REQUIRED',str(required))
compile(source,'restore','exec');(r/'restore-command.py').write_text(source,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/config-boundary-b509-restore.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=source.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(r/'restore.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr
result=json.loads(done.stdout);(r/'unneeded-cleanup-restored.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
