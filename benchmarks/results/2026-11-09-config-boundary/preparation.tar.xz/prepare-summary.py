from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'cpython-checkpoint-r146/summarize.py').read_text(encoding='utf-8')
s=s.replace("len(raw['jobs'])==12","len(raw['jobs'])==3").replace('len(external)==12','len(external)==3').replace('jobs=12,',"jobs=len(raw['jobs']),")
s=s.replace(" if 'CPython'in labels:", " row['pythonControlPercent']=100*abs(med['CPython-control']/med['CPython']-1)\n if 'CPython'in labels:")
s=s.replace("sorted(med[k]/med['CPython']for k in ['candidate','candidate-control'])", "sorted(med[k]/med[py]for k in ['candidate','candidate-control']for py in ['CPython','CPython-control'])")
s=s.replace("timeRangeMilliseconds=sorted(med[k]for k in ['candidate','candidate-control']),", "timeRangeMilliseconds=sorted(med[k]for k in ['candidate','candidate-control']),pythonTimeRangeMilliseconds=sorted(med[k]for k in ['CPython','CPython-control']),")
s=s.replace("row['controlPercent']<2 and max(iqr.values())<3", "max(row['controlPercent'],row['pythonControlPercent'])<2 and max(iqr.values())<3")
compile(s,'summarize.py','exec');(r/'summarize.py').write_text(s,encoding='utf-8')
p=r/'observe-ci.py';s=p.read_text(encoding='utf-8').replace('status,conclusion,headSha,jobs,url','status,conclusion,headSha,jobs,url,createdAt');p.write_text(s,encoding='utf-8')
