from pathlib import Path
import json
r=Path(__file__).parent
qualified=json.loads(Path('benchmarks/results/2026-11-09-managed-whitespace-search/receipt-qualification.json').read_text(encoding='utf-8'))
assert qualified['actualValidatedJobs']==3 and qualified['exactScheduleAndFourRolesValidated']
s=(r.parent/'borrowed-call-entry-r151/recover-space.py').read_text(encoding='utf-8')
s=s.replace("[('callback-transport-b504-20261109','2026-11-09-callback-arguments'),('json-runtime-b505-20261109','2026-11-09-json-runtime-attribution')]", "[('bulk-whitespace-b508-20261109','2026-11-09-managed-whitespace-search')]")
s=s.replace('borrowed-call-entry-b506','config-boundary-b509').replace('/dev/shm/lython-b505','/dev/shm/lython-b509')
required=json.loads((r/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']
s=s.replace(' plan=dict(',f" assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>{required}, 'No mutation: original payload/floor requirement cannot be met'\n plan=dict(")
s=s.replace('Two redundant remote archives','One exact redundant remote archive')
compile(s,'recover-space.py','exec');(r/'recover-space.py').write_text(s,encoding='utf-8')
