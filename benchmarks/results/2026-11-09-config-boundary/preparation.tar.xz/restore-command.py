from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,sys
base=Path('/home/lokad/lython-bench-checks');entry={'path': '/home/lokad/lython-bench-checks/bulk-whitespace-b508-20261109/observations.tgz', 'sha256': 'db1091c851b67974b2eef1cb2544f2ed662aa03cdda768ee19cbad9545175f6e', 'size': 4000648, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-managed-whitespace-search/observations.tgz', 'tracked': True, 'device': 66305, 'inode': 614714, 'links': 1, 'uid': 1000, 'gid': 1000, 'mode': '0o100644', 'parents': [{'path': '/home/lokad/lython-bench-checks/bulk-whitespace-b508-20261109', 'uid': 1000, 'gid': 1000, 'mode': '0o40775'}, {'path': '/home/lokad/lython-bench-checks', 'uid': 1000, 'gid': 1000, 'mode': '0o40775'}, {'path': '/home/lokad', 'uid': 1000, 'gid': 1000, 'mode': '0o40750'}, {'path': '/home', 'uid': 0, 'gid': 0, 'mode': '0o40755'}, {'path': '/', 'uid': 0, 'gid': 0, 'mode': '0o40755'}], 'allAliases': ['/home/lokad/lython-bench-checks/bulk-whitespace-b508-20261109/observations.tgz']}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 target=Path(entry['path']);assert target.parent.parent==base and target.resolve()==target and not target.exists()
 for e in entry['parents']:
  p=Path(e['path']);s=p.lstat();assert stat.S_ISDIR(s.st_mode)and not p.is_symlink()and s.st_uid==e['uid']and s.st_gid==e['gid']and oct(s.st_mode)==e['mode']
 data=sys.stdin.buffer.read(entry['size']+1);assert len(data)==entry['size']and hashlib.sha256(data).hexdigest()==entry['sha256']
 assert shutil.disk_usage(base).free>entry['size']+264404992
 stage=target.with_name('observations.restore-b509.tmp')
 with stage.open('xb')as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.chmod(stage,stat.S_IMODE(int(entry['mode'],8)));s=stage.lstat()
 assert s.st_uid==entry['uid']and s.st_gid==entry['gid']and s.st_nlink==1
 os.link(stage,target);assert target.stat().st_ino==s.st_ino;stage.unlink()
 assert target.stat().st_nlink==1 and hashlib.sha256(target.read_bytes()).hexdigest()==entry['sha256']
 result=dict(restoredExactArchive=True,sha256=entry['sha256'],path=str(target),originalModeOwnerGroupRestored=True,freshIdleLease=True,noTimedWorkStarted=True,reason='Fresh free space already exceeded original payload/floor requirement. Preparatory duplicate cleanup unnecessary; restore exact tracked bytes without overwriting another file.',freeBytes=shutil.disk_usage(base).free)
 (base/'config-boundary-b509-unneeded-cleanup-restored.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
