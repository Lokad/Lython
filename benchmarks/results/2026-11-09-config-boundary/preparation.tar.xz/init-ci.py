from pathlib import Path
from datetime import datetime,timedelta,timezone
import json,subprocess
r=Path(__file__).parent;now=datetime.now(timezone.utc)
state=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dispatchedUTC=now.isoformat(),
    workflow='ci.yml',stress=True,scope='R157/R158/config checkpoint: bothOS actual11/10, original Stress both and installed core consumers',
    state='dispatched',id=42627090614,url='https://github.com/Lokad/Lython/actions/runs/42627090614',observeNotBeforeUTC=(now+timedelta(minutes=5)).isoformat())
for name in ['ci-active.json','ci-dispatched.json']:(r/name).write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
(r/'observe-ci.py').write_bytes((r.parent/'valid-deflate-r155/observe-ci.py').read_bytes())
p=Path('PLAN.md');s=p.read_text(encoding='utf-8-sig')
s=s.replace('R159 active, prepared locally:', 'R159 active, B509 launched:')
s=s.replace('   all current production bytes verified; no new core copies, build or timed work.', '''   all current production bytes verified; no new core copies/build. Finite service
   launched13:37UTC; terminal observation after13:40:47UTC. Fresh free299122688B
   already sufficient; preparatory duplicate cleanup unnecessarily removedB508
   archive, then exact tracked bytes/mode/owner/group restored before timed work
   without overwriting a file. Both original action and restoration proofs retained.''')
s=s.replace('   Keep R157 full platform/Stress/package qualification pending until coherent\n   delivery;', '''   R157 full platform/Stress/package checkpoint42627090614/source038f7fb4 now
   dispatched; first observation no earlier than13:43UTC. Keep working meanwhile;''')
s+='\nCurrent: B509 finite VM collection awaiting terminal observation after13:40:47UTC; CI42627090614 active, first observation after'+state['observeNotBeforeUTC']+'. No local build/test/timing. Older terminal runs remain cached.\n'
p.write_text(s,encoding='utf-8');print(json.dumps(state,indent=2))
