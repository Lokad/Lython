from pathlib import Path
import json
r=Path(__file__).parent;data=json.loads((r/'summary.json').read_text(encoding='utf-8'))
rows={x['lane']:x for x in data['timing']};table=0;result=[]
for line in(r/'prior-BENCHMARKS.md').read_text(encoding='utf-8').splitlines():
    if line.startswith('| Workload |'):table+=1
    if table in[1,2,3]and line.startswith('| Config edit |'):
        cells=line.split('|');lane={1:'compile-run',2:'warm',3:'compile'}[table];d=rows[lane]
        a,b=d['timeRangeMilliseconds'];pa,pb=d['pythonTimeRangeMilliseconds'];lo,hi=min(d['ratioRange']),max(d['ratioRange'])
        def microseconds(first,last):
            first,last=f'{1000*first:.1f}',f'{1000*last:.1f}'
            return(first if first==last else first+'–'+last)+' µs'
        lt=microseconds(a,b);pt=microseconds(pa,pb)
        status=f"{d['status']}; L{d['controlPercent']:.2f}%, P{d['pythonControlPercent']:.2f}% /{max(d['iqrPercent'].values()):.2f}%"
        prefix='| Config edit | '+(cells[2].strip()+' | 'if table==1 else'')
        line=prefix+f'{lt} | {pt} | {lo:.2f}–{hi:.2f}× | `7c10` | {status} |'
    result.append(line)
s='\n'.join(result)+'\n'
s=s.replace('**Sources: `65ed`', '**Sources: `7c10` = `7c10322c`-equivalent source, 2026-11-09; `65ed`')
a=s.index('**Ratio =');b=s.index('Each row reports',a)
s=s[:a]+'''**Ratio = Lython elapsed / CPython elapsed; above one means slower.** Ranges span
two independent Lython medians; the `7c10` config row also spans two CPython medians.
Its ratio range includes all four process pairings, not confidence intervals.
Control is the absolute process-median difference (Lython; config also reports
Python as `P`). Max IQR includes both engines. Diagnostic/Variable describe short
observations, not design acceptance thresholds. Inconclusive rows remain visible.

''' +s[b:]
a=s.index('Each row reports');b=s.index('## Warm execution, compilation and startup',a)
s=s[:a]+'''Each row describes its named source, not arbitrary later HEAD. The `7c10` config
measurement reuses the verified nonincremental `cfeb99b0` freeze created before
commit; every production source byte matches `7c10322c` and documentation-only
`038f7fb4`. This is not a new post-commit binary. Its [three-phase config
checkpoint](../benchmarks/results/2026-11-09-config-boundary/README.md) finishes
three jobs/88.416s with two independent processes per engine and all output,
ownership, quiet and cleanup gates. Performance and delivery qualification are
separate; exact binaries and limits belong in the evidence.

The [four-workload checkpoint](../benchmarks/results/2026-11-09-cpython-callable-checkpoint/README.md)
measures `65ed`, before the later `58d3` scope correction: twelve jobs/250.847s.
Other rows retain `4598`/`6f76`. Prior tables, adverse observations and qualification
history are preserved behind those links. These ratios cannot attribute a gain
to one optimization.

''' +s[b:]
a=s.index('Current core `082a`');b=s.index('Identical scripts/fixtures',a)
s=s[:a]+'''The config row uses core `cfeb`/worker `fec79`; `65ed` rows use core `082a`/worker
`22331`. Optional adapter0.4 and the existing protocol remain unchanged; older rows
retain their own frozen images. Source, fixtures, complete goldens and timing
boundaries are identical between engines within each row. No newer regex producer
is qualified by these timings.

''' +s[b:]
s=s.replace('Four of eight rows use `65ed`; CSV summary/JSON-lines remain `6f76`, and config/manifest\nremain `4598`.', 'Four of eight rows use `65ed`; config uses `7c10`, CSV summary/JSON-lines remain\n`6f76`, and the manifest remains `4598`.')
Path('docs/BENCHMARKS.md').write_text(s,encoding='utf-8')
print('Only config rows refreshed across three phases; other source labels/timings preserved; qualification narrative linked.')
