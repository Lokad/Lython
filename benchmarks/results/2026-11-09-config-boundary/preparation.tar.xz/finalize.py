from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-09-config-boundary');out.mkdir(exist_ok=True)
status=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert status['exitCode']=='0'and receipt['complete']and receipt['allWorkersJoined']and receipt['jobs']==3
assert not status['remainingWorkers']and not status['remainingFixtures']and not status['ownedRamRemaining']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
proof=json.loads((r/'core-source.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in proof['productionSources'].items())
raw=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert [j['lane']for j in raw['jobs']]==['compile','warm','compile-run']
assert all(len(j['identities'])==4 and len(j['samples'])==28 and j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
restored=json.loads((r/'unneeded-cleanup-restored.json').read_text(encoding='utf-8'));assert restored['restoredExactArchive']
for name in ['summary.json','identity.json','core-source.json','terminal-status.json','archive-receipt.json','observations.tgz','unneeded-cleanup-restored.json']:
    assert not(out/name).exists();shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
    for p in r.iterdir():
        if p.is_file()and p.name not in['payload.tgz','observations.tgz']:archive.add(p,arcname=p.name)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8-sig')
a=s.index('   **R159 active');b=s.index('2. **R156',a)
s=s[:a]+'''   **R159 measured: current short-config phases complete; full checkpoint running.**
   Exact existing181B config edit, source7c-equivalent/corecfeb freeze (creation3fb
   plus R157; all current production bytes match), stock CPython3.13.16, common
   worker/protocol, two independent processes per engine. B5093jobs/88.416s, all
   identity/quiet/golden/ownership/Closed/join/RAM/archive/localSHA gates pass.
   Compile36.5–36.7µs versus34.4 (1.06–1.07×); warm78.7–79.0 versus61.6–62.1
   (1.27–1.28×); complete138.7–139.6 versus124.9–125.1 (1.11–1.12×). Stable short
   controls, maxIQR2.98%; ratios include all process pairs, not confidence intervals.
   Actual guest RAM I/O/full output/prior-result cleanup included; startup/reset/
   protocol/final cache teardown excluded. Medians of separate phases not additive;
   external CPU includes reset/protocol and cannot identify internal costs.
   Only config rows refreshed in BENCHMARKS; older source labels/adversity retained.
   This fills the measurement gap, not a setup-cause or individual-gain attribution.
   Preparatory duplicate cleanup was unnecessary with299MB free; exact trackedB508
   archive restored before measurement, raw/receipts/workers untouched. Both proofs
   retained; no floor change or timed rerun. Full CI42627090614/source038f7fb4
   running, observations >=5min apart; do not wait to continue independent work.
   Evidence: benchmarks/results/2026-11-09-config-boundary.

   **R160 next: usable current config execution attribution before redesign.**
   Warm residual about17µs may include initialization, JSON, mediated path/I/O and
   worker handoff. Do not infer immutable type/module sharing from aggregate ratios.
   One short existing-tool on-CPU capture on the same maintained config source and
   frozen code, with actual worker/caller/reset/protocol separated. Attribute useful
   work and unknowns honestly; CPU capture cannot explain off-CPU scheduling latency.
   Old54guest samples remain insufficient and are not repeated qualification.
   Current plain builtin callables/signatures are already shared; mutable type and
   cache isolation, current tokens and host-budget owners must survive any redesign.
   Stop after usable attribution plus bounded20min source gate: identify one current
   duplicated construction/work phase and displaced implementation, then one
   coherent before/after with semantic/cancellation/refusal/alias cleanup criteria.
   If no phase justifies change, record that rather than add a cache, guard VM,
   default-stack policy change or sequence of speculative tweaks. No new framework,
   broad measurement campaign or publication; regex development remains independent.

''' +s[b:]
s+='\nR159/B509 terminal/cached,88.416s, exact archive SHA verified locally; no VM users/fixtures. CI42627090614 still active. R160 is next; no local build/test/timing.\n'
p.write_text(s,encoding='utf-8')
print('Config benchmark source/goldens/four-role schedule verified; raw/archive and original cleanup/restoration evidence preserved. Guide refreshed; R160 cause attribution next.')
