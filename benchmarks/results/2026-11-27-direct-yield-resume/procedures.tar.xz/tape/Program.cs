using System.Collections;
using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var sources = catalog.RootElement.GetProperty("cases").EnumerateArray().ToDictionary(
    item => item.GetProperty("id").GetString()!, item => item.GetProperty("source").GetString()!);
sources.Add("generator-protocol", File.ReadAllText(args[1]));
var reports = sources.ToDictionary(pair => pair.Key, pair =>
{
    using var script = new LythonEngine().Compile(pair.Value);
    if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
    var rows = new List<object>();
    Visit(Member(Member(script, "_executable")!, "EntryPoint")!, rows);
    return rows;
});
File.WriteAllText(args[2], JsonSerializer.Serialize(reports, new JsonSerializerOptions { WriteIndented = true }));

static object? Member(object source, string name)
{
    const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    var type = source.GetType();
    return type.GetProperty(name, Flags)?.GetValue(source) ?? type.GetField(name, Flags)?.GetValue(source);
}

static void Visit(object code, List<object> rows)
{
    var steps = ((IEnumerable)Member(code, "Instructions")!).Cast<object>().ToArray();
    var opcodes = steps.Select(instruction => Member(instruction, "OpCode")!.ToString()).ToArray();
    var yields = opcodes.Select((op, index) => (op, index)).Where(step => step.op is "Yield" or "YieldFrom").Select(step => new
    {
        kind = step.op,
        discard = Member(steps[step.index], "DiscardsYieldResult") is true,
        popAfter = step.index + 1 < steps.Length && opcodes[step.index + 1] == "PopTop",
        extent = (int)Member(steps[step.index], "LiveExtent")!,
        input = (int)Member(steps[step.index], "InputStart")!,
        result = (int)Member(steps[step.index], "ResultSlot")!,
    }).ToArray();
    rows.Add(new { function = Member(code, "Name"), count = steps.Length, yields });
    foreach (var value in (object?[])Member(code, "Constants")!)
    {
        if (value is null) continue;
        var child = value.GetType().Name switch
        {
            "ExecutableCreateFunction" or "ExecutableCreateGeneratorExpression" => Member(value, "CodeObject"),
            "ExecutableCreateClass" => Member(value, "Body"),
            _ => null,
        };
        if (child is not null) Visit(child, rows);
    }
}
