from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
pair = lab / "comparison"
read = lambda path: json.loads(path.read_bytes())
identity = read(pair / "identity.json")
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
project = lab / "tape"
subprocess.run([dotnet, "build", project / "YieldTape.csproj", "-c", "Release"], cwd=project, env=env, check=True, timeout=60)
results = {}
for role, files in identity["imageFiles"].items():
    assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (pair / role).iterdir()} == files
    folder = lab / ("tape-" + role)
    copytree(project / "bin/Release/net11.0", folder)
    core = folder / "Lokad.Lython.dll"
    copyfile(pair / role / core.name, core)
    assert sha256(core.read_bytes()).hexdigest() == files[core.name]
    output = folder / "observed.json"
    subprocess.run([dotnet, folder / "YieldTape.dll", pair / "representative.json", lab / "resume.py", output], env=env, cwd=folder, check=True, timeout=30)
    results[role] = read(output)

summary = {}
for case, before in results["reference"].items():
    removed = 0
    result = []
    for a, b in zip(before, results["candidate"][case], strict=True):
        assert a["function"] == b["function"]
        for old, new in zip(a["yields"], b["yields"], strict=True):
            assert old["kind"] == new["kind"]
            if new["discard"]:
                assert not old["discard"] and old["popAfter"] and new["extent"] == new["input"]
            else:
                assert old == new
        count = sum(site["discard"] for site in b["yields"])
        assert count == a["count"] - b["count"]
        removed += count
        if a["yields"]: result.append(dict(function=b["function"], removed=count, yields=b["yields"]))
    summary[case] = dict(removed=removed, code=result)
assert summary["diagnostic.shipment-starmap-iterable-rows"]["removed"] == 5
assert summary["diagnostic.shipment-file-fed-map"]["removed"] == 0
(lab / "tape-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name, info in summary.items():
    print(name, info["removed"])
