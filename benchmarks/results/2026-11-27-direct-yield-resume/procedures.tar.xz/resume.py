def flow(events):
    try:
        (yield "discard")
        events.append("resumed")
        used = yield "capture"
        yield used
        try:
            yield "throw-here"
        except ValueError as error:
            yield str(error)
    finally:
        events.append("closed")

events = []
g = flow(events)
token = []
print(next(g))
print(g.send(object()))
print(g.send(token) is token)
print(next(g))
print(g.throw(ValueError("handled")))
g.close()
print(events, list(g))

def child():
    yield 1
    return 8

def parent():
    answer = yield from child()
    yield answer

print(list(parent()))
g = (item * 2 for item in (3, 4, 5))
print(next(g), g.send("ignored"), next(g))
