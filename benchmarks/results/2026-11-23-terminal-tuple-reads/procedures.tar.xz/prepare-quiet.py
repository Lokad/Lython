from pathlib import Path
import gzip,hashlib,json,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/'comparison'
prior=lab.parent/'supplied-call-accumulation-20261123'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
proof=read(comparison/'identity.json')
assert all(sha((lab/role/name).read_bytes())==expected
    for role,files in proof['imageFiles'].items() for name,expected in files.items())
catalog=read(comparison/'representative.json')
quoted,nested,plain,observer,_,supplied=catalog['cases']
jobs=[(nested['id'],'warm'),(nested['id'],'compile-run'),(plain['id'],'warm'),
    (quoted['id'],'warm'),(observer['id'],'warm'),(supplied['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})
proof['catalogs']['jobs.json']={'sha256':sha((comparison/'jobs.json').read_bytes())}
proof['coreSHA256']={k:files['Lokad.Lython.dll'] for role,files in proof['imageFiles'].items()
    for k in (role,role+'-control')}
write(comparison/'identity.json',proof)

archive='benchmarks/results/2026-11-23-integer-call-update/'
fetch=lambda name:subprocess.check_output(['git','show','origin/master:'+archive+name],cwd=repo)
prior_identity=json.loads(fetch('identity.json'))
prior_receipt=json.loads(fetch('terminal-status.json'))['receipt']
assert prior_receipt['complete'] and prior_receipt['archivedAndVerifiedUnderLease']
assert sha(fetch('observations.tar.xz'))==prior_receipt['archiveSHA256']
backup=gzip.decompress(fetch('reference-core.dll.gz'))
assert sha(backup)==prior_identity['imageFiles']['reference']['Lokad.Lython.dll']
replica=dict(path='supplied-call-accumulation-b1522-20261123/reference/Lokad.Lython.dll',sha256=sha(backup),
    observationSHA256=prior_receipt['archiveSHA256'],trackedArchive=archive+'reference-core.dll.gz')
write(comparison/'verified-replica.json',replica)

def adapt(name,pairs):
    source=(prior/name).read_text(encoding='utf-8')
    for a,b in pairs:
        assert source.count(a)==1,(name,a)
        source=source.replace(a,b)
    compile(source,str(lab/name),'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')
adapt('stage.py',(
    ('supplied-call-accumulation-b1522-20261123','terminal-tuple-reads-b1531-20261123'),
    ('csv-short-utf8-typed-reader-b1520-20261123','closed-factory-operand-b1529-20261123'),
    ('lython-b1522-fixtures','lython-b1531-fixtures'),('len(jobs) == 5','len(jobs) == 6'),('< 270,','< 320,'),
))
adapt('quiet.py',(
    ('lython-b1522-supplied-call-accumulation-20261123','lython-b1531-terminal-tuple-reads-20261123'),
    ('.+b1522-','.+b1531-'),('lython-b1522-stage-','lython-b1531-stage-'),
    ("configuration[\"unit\"]=unit","configuration[\"unit\"]=unit\nconfiguration['duplicate']=json.loads((lab/'comparison/verified-replica.json').read_text())"),
    ('Five bounded lanes write under 1 MiB of receipts. A 49 MiB',
     'Six bounded lanes write under 1 MiB of receipts. A 26 MiB'),
    ('49 * 1024 * 1024','26 * 1024 * 1024'),
    ("  assert free >= minimum,(free,'needs two cores, receipts and working room')", """  freed=None
  if free < minimum:
   saved=configuration['duplicate']
   replica=base/saved['path']
   archive=replica.parent.parent/'observations.tar.xz'
   assert replica.resolve()==replica and replica.is_file() and replica.stat().st_nlink==1
   assert free+replica.stat().st_blocks*512>=minimum
   assert digest(replica)==saved['sha256'] and digest(archive)==saved['observationSHA256']
   replica.unlink()
   freed=saved
   free=shutil.disk_usage(base).free
  assert free >= minimum,(free,'needs two cores, receipts and working room')"""),
    ('freeBefore=free,freeBeforeLaunch=', 'verifiedDuplicateRetired=freed,freeBefore=free,freeBeforeLaunch='),
    ('RuntimeMaxSec=320','RuntimeMaxSec=380'),('seconds=253','seconds=294'),
))
adapt('summarize.py',(
    ('== 5\nassert hashlib','== 6\nassert hashlib'),('len(warm["jobs"])==5','len(warm["jobs"])==6'),
    ('timedBatches=140','timedBatches=168'),
))
