from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
dest=repo/'benchmarks/results/2026-11-23-terminal-tuple-reads'
sha=lambda x:hashlib.sha256(x).hexdigest()
digest=lambda path:sha(path.read_bytes())
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
identity=read(lab/'comparison/identity.json')
revision=(lab/'retained-revision').read_text(encoding='utf-8-sig').strip()
assert not git('diff','--name-only',revision,identity['candidate'],'--','src')
assert not git('diff','--name-only',revision,'8798239b9','--','src','tests')
identity['retainedRevision']=revision
status=read(quiet/'terminal-status.json')
receipt=status['receipt']
assert status['exitCode']=='0' and not status['fixtures'] and not status['live']
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==168
allocations=read(lab/'allocation-summary-six.json')
assert all(row['peakAdmission'][0]==row['peakAdmission'][1] for row in allocations)
old,new=(read(lab/(role+'-tape.json')) for role in ('reference','candidate'))
proof=[]
for before,after in zip(old['rows'][:3],new['rows'][:3],strict=True):
    assert before['id']==after['id']
    helper=next(code for code in after['codes'] if code['name']=='price_line')
    assert helper['opcodeCounts']['IntegerTupleReturn']==1
    assert before['codes'][0]['mirrors']==after['codes'][0]['mirrors']
    proof.append(dict(workload=before['id'],moduleMirrored=after['codes'][0]['mirrors'],
        terminalHelperOpcodes=helper['opcodeCounts']))
(lab/'tape-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
patch=git('diff','--binary',identity['sourceRevision'],revision,'--','src','tests')
(lab/'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256']=sha(patch)
identity['verifiedDuplicateRetired']=json.loads((quiet/'launch.log').read_text(encoding='utf-8').splitlines()[0])['verifiedDuplicateRetired']
dest.mkdir(exist_ok=True)
assert all(path.name=='README.md' for path in dest.iterdir())
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(digest(lab/role/name)==expected for name,expected in files.items())
    (dest/(role+'-core.dll.gz')).write_bytes(gzip.compress((lab/role/'Lokad.Lython.dll').read_bytes(),mtime=0))
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for filename in ('observations.tar.xz','summary.json','terminal-status.json'):
    shutil.copyfile(quiet/filename,dest/filename)
for filename in ('allocation-summary-six.json','tape-proof.json'):
    shutil.copyfile(lab/filename,dest/filename)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as bundle:
    for filename in ('archive.py','prepare.py','prepare-quiet.py','stage.py','quiet.py','summarize.py','allocations.py',
        'test-ubuntu.sh','comparison.patch','reference-tape.json','candidate-tape.json',
        'windows-public.log','windows-white.log','ubuntu-public.log','ubuntu-white.log',
        'reference-allocation-six.json','candidate-allocation-six.json','comparison/reference-verify.json',
        'comparison/candidate-verify.json','comparison/verified-replica.json','comparison/quiet/launch.log'):
        bundle.add(lab/filename,arcname=filename)
print(dest)
