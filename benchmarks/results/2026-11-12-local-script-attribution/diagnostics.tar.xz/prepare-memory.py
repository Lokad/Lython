from pathlib import Path
import os,subprocess
r=Path(__file__).parent;out=r/'memory-control';out.mkdir(exist_ok=True)
code=(r/'Program.cs').read_text(encoding='utf-8')
code=code.replace('Local Windows sampled cost diagnostic. Existing complete synchronous scripts, mediated disk-file I/O, reset, validation and result cleanup.','Local Windows sampled cost diagnostic. Same captured script with existing in-memory BenchmarkHost, reset, validation and result cleanup. Host differs from quiet-VM comparison; no CPU or speedup conclusion.')
code=code.replace('private readonly MethodInfo _reset, _outputs, _digest, _validate;','private readonly MethodInfo _digest;\n    private readonly Action _reset;\n    private readonly Func<object> _outputs;')
start=code.index('        var hostType = benchmark.GetType(')
end=code.index('        try\n',start)
code=code[:start]+'''        var hostType = benchmark.GetType("Lokad.Lython.Benchmarks.BenchmarkHost", true)!;
        _owned = "";
        _host = Activator.CreateInstance(hostType, nonPublic: true)!;
        var inputs = (IReadOnlyDictionary<string, byte[]>)fixtureType.GetProperty("Inputs")!.GetValue(fixture)!;
        var outputs = (IReadOnlyDictionary<string, byte[]>)fixtureType.GetProperty("Outputs")!.GetValue(fixture)!;
        var seed = hostType.GetMethod("SeedBytes")!;
        var read = hostType.GetMethod("ReadBytes")!;
        _reset = () => { foreach (var pair in inputs) seed.Invoke(_host, ["/" + pair.Key, pair.Value]); };
        _outputs = () => outputs.Keys.ToDictionary(name => name, name => (byte[])read.Invoke(_host, ["/" + name])!);
        _digest = fixtureType.GetMethod("Digest")!;
        _reset();
'''+code[end:]
code=code.replace('_reset.Invoke(_host, null);','_reset();').replace('_outputs.Invoke(_host, null)','_outputs()')
code=code.replace('            _validate.Invoke(null, [_owned]);\n            if (Directory.Exists(_owned)) Directory.Delete(_owned, recursive: true);','            // In-memory fixture; no owned filesystem paths.\n            if (_owned.Length != 0) throw new InvalidOperationException("Unexpected fixture path.");')
assert '_validate' not in code and '_reset.Invoke' not in code
(out/'Program.cs').write_text(code,encoding='utf-8',newline='\n')
(out/'profile.csproj').write_text((r/'profile.csproj').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
collect=(r/'collect.py').read_text(encoding='utf-8').replace("old=r.parent/'lexical-cell-storage-r284'","old=r.parent.parent/'lexical-cell-storage-r284'")
collect=collect.replace("cases=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.csv-validated-records.large','scripts.report-render.large']","cases=['scripts.text-summary-helpers.nonlocal-counter.large']")
(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with (out/'build.log').open('w',encoding='utf-8',newline='\n') as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(out/'profile.csproj'),'-c','Release','-f','net11.0'],env=env,stdout=log,stderr=subprocess.STDOUT)
print((out/'build.log').read_text(encoding='utf-8')[-1600:]);assert done.returncode==0
