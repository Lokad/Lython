from pathlib import Path
import os,subprocess,shutil
r=Path(__file__).parent;r.mkdir(exist_ok=True)
old=r.parent/'lexical-cell-storage-r284'
code=(old/'tool/Program.cs').read_text(encoding='utf-8')
imports=code[:code.index('// One private adaptation')]
classes=code[code.index('sealed class Image : IDisposable'):]
top='''
if (System.Runtime.GCSettings.IsServerGC) throw new InvalidDataException("Expected normal workstation GC.");
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
using var witness = JsonDocument.Parse(File.ReadAllBytes(args[2]));
var item = catalog.RootElement.GetProperty("cases").EnumerateArray().Single(c => c.GetProperty("id").GetString() == args[3]);
var output = Path.GetFullPath(args[4]);
using var image = new Image(Path.GetFullPath(args[0]), item, witness.RootElement.GetProperty("source").GetString()!, "qualified-current", false);
image.Once();
var warmup = Stopwatch.StartNew();
var warmups = 0;
while (warmup.Elapsed < TimeSpan.FromSeconds(5)) { image.Once(); warmups++; }
image.FreezeBalance();
File.WriteAllText(output + ".ready", Environment.ProcessId.ToString(CultureInfo.InvariantCulture));
var clock = Stopwatch.StartNew();
var runs = 0;
while (!File.Exists(output + ".stop") && clock.Elapsed < TimeSpan.FromSeconds(60)) { image.Once(); runs++; }
var ownedStop = !File.Exists(output + ".stop");
image.Dispose();
File.WriteAllText(output + ".json", JsonSerializer.Serialize(new {
    caseId = args[3], runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    Environment.ProcessId, warmups, runs, ownedStop, wallSeconds = clock.Elapsed.TotalSeconds,
    allGoldensPassed = true, allBalancesZero = true, ownedFixturesRemoved = true,
    image.Files, image.Hashes, catalogSHA256 = Hash(args[1]), witnessSHA256 = Hash(args[2]), normalGcAndTiering = true, asynchronous = false,
    boundary = "Local Windows sampled cost diagnostic. Existing complete synchronous scripts, mediated disk-file I/O, reset, validation and result cleanup. Startup/warmup excluded by readiness; all worker/runtime threads retained. Not quiet-VM timing or a speedup estimate."
}));
if (ownedStop) throw new TimeoutException("Profiler did not finish inside owned worker bound.");

static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

'''
(r/'Program.cs').write_text(imports+top+classes,encoding='utf-8',newline='\n')
(r/'profile.csproj').write_text((old/'tool/complete-jobs.csproj').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
if (r/'build.log').exists(): shutil.copyfile(r/'build.log',r/'initial-build.log')
with (r/'build.log').open('w',encoding='utf-8',newline='\n') as log:
    result=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'profile.csproj'),'-c','Release','-f','net11.0'],env=env,stdout=log,stderr=subprocess.STDOUT)
print((r/'build.log').read_text(encoding='utf-8')[-1800:]);assert result.returncode==0
