from pathlib import Path
import shutil,subprocess
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-12-private-iteration-source-gate');out.mkdir(exist_ok=True)
shutil.copyfile(r.parent/'private-iteration-r285/source-gate.md',out/'README.md')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');start=s.index('1. **R285 whole-script redesign:');end=s.index('2. **Other roadmap axes',start)
s=s[:start]+'''1. **R287: ordinary tuple storage, active coherent prototype.** CSV's complete
   `validated_record` helper returns an observable two-item tuple on each accepted
   row. Its tuple literal copies operand references into a separate small array;
   tuple unpacking already borrows immutable storage. Preserve the tuple itself,
   its aliases and Python identity. Do not add an unboxed return/unpack protocol.
   - Hypothesis: keep up to two references in managed inline tuple storage and
     remove that per-record backing allocation/copy. Array-backed large tuples
     retain adoption. Unknown iterable construction keeps existing protocol work.
     This consolidates ordinary collection construction, not a compiler pattern.
   - Cost/tradeoff: a larger tuple header and an indexed-storage branch affect
     all tuples. Admit conservative metadata/capacity and unchanged scalar funding
     before construction; retain input overlap and exact cancellation/refusal order.
     Earlier rejection is acceptable, retained aliases are never refunded.
   - Acceptance: tuple identity, hashes/keys, iteration/unpacking/slicing, defaults,
     named tuples, projection, retained results, mutation during admission, genuine
     async callbacks/cancellation and terminal refusal. Use existing focused tests;
     add only independent observable gaps. No Unsafe, native layout assumption,
     tagged scalar VM, extra cache, allocator or consumer-specific backend.
   - Measure actual constructor/array allocation and complete CSV against the
     frozen qualified baseline, plus captured text/JSON/report controls. Separate
     allocation benefit from CPU. Use a bounded desktop diagnostic first; retain
     original adversity and seek quiet-VM confirmation if source remains justified.
     Finish by retaining a coherent migration with explicit debt or removing the
     entire prototype, then batch full qualification only for retained source.

2. **R285 source gate closed; broader result ownership remains a later design.**
   Existing range reuse is delivered. A private cased cursor carries a real loan
   across native/framed/protected returns and asynchronous finally work. Moving
   only its fields into the immediate caller misses those paths; a result union,
   side table or pool adds a broader protocol. No local cursor prototype selected.
   [Source/lifetime proof](benchmarks/results/2026-11-12-private-iteration-source-gate/README.md).
   A future coherent transfer must remove the cursor, separate positions and old
   cleanup together; preserve eager admission and binding/refund order. No permanent
   ban follows. R286's three short Windows disk-host traces and one existing-memory-
   host correction preserve all goldens/balances but sampled wall time is not CPU;
   unmanaged waits and sampling bias remain unresolved. Do not promote its apparent
   MapCaseRune dominance to a CPU claim or retime it unchanged. R267/R272 quiet-VM
   samples remain source-labelled evidence, not exact attribution of today's HEAD.

'''+s[end:]
s=s.replace('2. **Other roadmap axes','3. **Other roadmap axes').replace('3. **Independent regex','4. **Independent regex')
s=s.replace('| Committed evidence | 632a867c archives the current CPython checkpoint and bounded admission source gate. No production change or repeated qualification. |','| Committed evidence | 7bbf3b9d records final qualification and current CPython guide; da61f00f records complete R284 withdrawal and the retained two-case alias regression. Production is unchanged. |\n| Active development | R287 ordinary tuple-storage prototype selected from the actual CSV construction path; no allocation/CPU result or full qualification claimed yet. R285 source gate closes without a runtime change. |')
p.write_text(s,encoding='utf-8',newline='\n')
target=r.parent/'inline-tuples-r287';target.mkdir(exist_ok=True)
shutil.copyfile('PLAN.md',target/'selected-plan.md')
shutil.copyfile('src/Lokad.Lython/Runtime/PyTuple.cs',target/'before-PyTuple.cs')
(target/'base.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True),encoding='utf-8',newline='\n')
print('Updated ignored plan before tuple-storage prototype; R285 proof retained, R286 uncertainty explicit.')
