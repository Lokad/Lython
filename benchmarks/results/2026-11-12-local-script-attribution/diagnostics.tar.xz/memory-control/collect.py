from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).parent.resolve(); old=r.parent.parent/'lexical-cell-storage-r284'
if (r/'trace-0.log').exists() and "does not apply" in (r/'trace-0.log').read_text(encoding='utf-8'):
    for p in list(r.glob('capture-0.*'))+[r/'worker-0.log',r/'trace-0.log']:
        assert p.resolve().is_relative_to(r)
        p.rename(r/('initial-'+p.name))
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
overrides=['DOTNET_gcServer','COMPlus_gcServer','DOTNET_GCHeapCount','COMPlus_GCHeapCount','DOTNET_GCHeapHardLimit','COMPlus_GCHeapHardLimit','DOTNET_GCHeapHardLimitPercent','COMPlus_GCHeapHardLimitPercent','DOTNET_TieredCompilation','COMPlus_TieredCompilation','DOTNET_TieredPGO','COMPlus_TieredPGO','DOTNET_TC_QuickJit','COMPlus_TC_QuickJit','DOTNET_TC_QuickJitForLoops','COMPlus_TC_QuickJitForLoops','DOTNET_ReadyToRun','COMPlus_ReadyToRun','DOTNET_PROCESSOR_COUNT']
assert all(env.get(n) is None for n in overrides)
core=old/'reference/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
cases=['scripts.text-summary-helpers.nonlocal-counter.large']
for i,case in enumerate(cases):
    output=r/('capture-'+str(i)); assert not output.with_suffix('.ready').exists()
    args=[str(sdk/'dotnet.exe'),str(r/'bin/Release/net11.0/profile.dll'),str(old/'reference/Lokad.Lython.Benchmarks.dll'),str(old/'catalog.json'),str(old/'warm-sync/witness.json'),case,str(output)]
    with (r/f'worker-{i}.log').open('w',encoding='utf-8',newline='\n') as log:
        worker=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            deadline=time.monotonic()+30
            while not output.with_suffix('.ready').exists():
                assert worker.poll() is None,(r/f'worker-{i}.log').read_text(encoding='utf-8')
                assert time.monotonic()<deadline,'Readiness timeout'
                time.sleep(.05)
            assert int(output.with_suffix('.ready').read_text(encoding='utf-8'))==worker.pid
            traceargs=['C:/Users/JoannesVermorel/.dotnet/tools/dotnet-trace.exe','collect','-p',str(worker.pid),'--profile','dotnet-sampled-thread-time','--duration','00:00:00:08','--format','Speedscope','--buffersize','32','-o',str(output.with_suffix('.nettrace'))]
            with (r/f'trace-{i}.log').open('w',encoding='utf-8',newline='\n') as trace:
                done=subprocess.run(traceargs,stdout=trace,stderr=subprocess.STDOUT,timeout=35)
            assert done.returncode==0,(r/f'trace-{i}.log').read_text(encoding='utf-8')
        finally:
            output.with_suffix('.stop').write_text('owned profiler cleanup\n',encoding='utf-8',newline='\n')
            code=worker.wait(timeout=30)
        assert code==0,(r/f'worker-{i}.log').read_text(encoding='utf-8')
    result=json.loads(output.with_suffix('.json').read_text(encoding='utf-8'))
    assert not result['ownedStop'] and result['allGoldensPassed'] and result['allBalancesZero'] and result['ownedFixturesRemoved']
    print(case,'joined/closed/goldens/balances pass',flush=True)
(r/'terminal.json').write_text(json.dumps(dict(complete=True,cases=cases,coreSHA256=hashlib.sha256(core.read_bytes()).hexdigest(),source='9bca1337 qualified production, HEAD da61f00f source unchanged',allWorkersJoined=True,allFixturesRemoved=True,normalRuntimeOverrides={n:env.get(n) for n in overrides},quietComparison=False),indent=2)+'\n',encoding='utf-8',newline='\n')
