using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;


if (System.Runtime.GCSettings.IsServerGC) throw new InvalidDataException("Expected normal workstation GC.");
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
using var witness = JsonDocument.Parse(File.ReadAllBytes(args[2]));
var item = catalog.RootElement.GetProperty("cases").EnumerateArray().Single(c => c.GetProperty("id").GetString() == args[3]);
var output = Path.GetFullPath(args[4]);
using var image = new Image(Path.GetFullPath(args[0]), item, witness.RootElement.GetProperty("source").GetString()!, "qualified-current", false);
image.Once();
var warmup = Stopwatch.StartNew();
var warmups = 0;
while (warmup.Elapsed < TimeSpan.FromSeconds(5)) { image.Once(); warmups++; }
image.FreezeBalance();
File.WriteAllText(output + ".ready", Environment.ProcessId.ToString(CultureInfo.InvariantCulture));
var clock = Stopwatch.StartNew();
var runs = 0;
while (!File.Exists(output + ".stop") && clock.Elapsed < TimeSpan.FromSeconds(60)) { image.Once(); runs++; }
var ownedStop = !File.Exists(output + ".stop");
image.Dispose();
File.WriteAllText(output + ".json", JsonSerializer.Serialize(new {
    caseId = args[3], runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    Environment.ProcessId, warmups, runs, ownedStop, wallSeconds = clock.Elapsed.TotalSeconds,
    allGoldensPassed = true, allBalancesZero = true, ownedFixturesRemoved = true,
    image.Files, image.Hashes, catalogSHA256 = Hash(args[1]), witnessSHA256 = Hash(args[2]), normalGcAndTiering = true, asynchronous = false,
    boundary = "Local Windows sampled cost diagnostic. Existing complete synchronous scripts, mediated disk-file I/O, reset, validation and result cleanup. Startup/warmup excluded by readiness; all worker/runtime threads retained. Not quiet-VM timing or a speedup estimate."
}));
if (ownedStop) throw new TimeoutException("Profiler did not finish inside owned worker bound.");

static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

sealed class Image : IDisposable
{
    private readonly object _budget;
    private readonly PropertyInfo _balance;
    private readonly object _host;
    private readonly MethodInfo _reset, _outputs, _digest, _validate;
    private object _script;
    private readonly object _engine;
    private readonly MethodInfo _compile;
    private readonly string _source;
    private readonly MethodInfo _run, _runAsync;
    private readonly PropertyInfo _asyncResult;
    private readonly bool _asynchronous;
    private readonly string _owned, _stdout, _fileGolden;
    private long _expected = -1;
    private bool _disposed;
    public long PhaseTicks { get; private set; }
    private bool _capturePeak = true;
    public long PeakExecutionBytes { get; private set; }
    public long PeakRootBytes { get; private set; }
    public string Label { get; }
    public Assembly Core { get; }
    public Type EngineType { get; }
    public string[] Hashes { get; }
    public Dictionary<string, string> Files { get; }
    public object NativeNodeStorage { get; }

    public Image(string path, JsonElement item, string hashSource, string label, bool asynchronous)
    {
        Label = label;
        _asynchronous = asynchronous;
        var directory = Path.GetDirectoryName(path)!;
        var context = new ImageContext(directory, label);
        var benchmark = context.LoadFromAssemblyPath(path);
        Core = context.LoadFromAssemblyPath(Path.Combine(directory, "Lokad.Lython.dll"));
        EngineType = Core.GetType("Lokad.Lython.LythonEngine", true)!;
        // Host-only allocation observation outside guest timing; no Unsafe.SizeOf
        // or layout assumption. Two array lengths cancel shared array metadata.
        var nodeType = Core.GetType("Lokad.Lython.Frontend.NativeReturnValue", true)!;
        _ = MeasureNodeArray(nodeType, 128); _ = MeasureNodeArray(nodeType, 256);
        var small = MeasureNodeArray(nodeType, 128);
        var large = MeasureNodeArray(nodeType, 256);
        NativeNodeStorage = new { length128Bytes = small, length256Bytes = large,
            derivedStrideBytes = (large - small) / 128, outsideGuestClocks = true, cellConstruction = MeasureCells(Core.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutableCell", true)!) };
        var adapter=context.LoadFromAssemblyPath(Path.Combine(directory,"Lokad.Lython.Utf8Regex.dll"));
        var provider=adapter.GetType("Lokad.Lython.Utf8Regex.Utf8RegexProvider",true)!.GetProperty("Instance")!.GetValue(null)!;
        var engine = Activator.CreateInstance(EngineType,[provider])!;
        _engine = engine;
        _source = item.GetProperty("source").GetString()!;
        var budgetType = Core.GetType("Lokad.Lython.LythonMemoryBudget", true)!;
        _budget = Activator.CreateInstance(budgetType, [null])!;
        _balance = budgetType.GetProperty("ReservedBytes")!;
        var compile = EngineType.GetMethod("Compile", [typeof(string), Core.GetType("Lokad.Lython.ILythonMemoryBudget", true)!])!;
        _compile = compile;
        var fixtureType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
        var fixture = fixtureType.GetMethod("Parse")!.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;
        var hostType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
        _validate = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.OwnedWorkerProcess", true)!
            .GetMethod("ValidateFixtureDirectory", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
        _owned = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
        _host = Activator.CreateInstance(hostType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
            null, [fixture, _owned], null)!;
        _reset = hostType.GetMethod("Reset")!; _outputs = hostType.GetMethod("ReadOutputs")!;
        _digest = fixtureType.GetMethod("Digest")!;
        try
        {
            using (var hashProgram = (IDisposable)compile.Invoke(engine, [hashSource, _budget])!)
            {
                RequireValid(hashProgram);
                var run = hashProgram.GetType().GetMethods().Single(m => m.Name == "Run" && m.GetParameters().Length == 1);
                using var result = (IDisposable)run.Invoke(hashProgram, [_host])!;
                RequireSuccess(result);
                var values = (IEnumerable)result.GetType().GetProperty("ReturnValue")!.GetValue(result)!;
                Hashes = values.Cast<object>().Select(v => ((IFormattable)v).ToString(null, CultureInfo.InvariantCulture)).ToArray();
            }
            if (Balance != 0) throw new InvalidDataException("Witness ownership did not end.");
            _script = compile.Invoke(engine, [item.GetProperty("source").GetString(), _budget])!;
            RequireValid(_script);
            _run = _script.GetType().GetMethods().Single(m => m.Name == "Run" && m.GetParameters().Length == 1);
            _runAsync = _script.GetType().GetMethods().Single(m => m.Name == "RunAsync" && m.GetParameters().Length == 1);
            _asyncResult = _runAsync.ReturnType.GetProperty("Result")!;
            _stdout = item.GetProperty("expectedOutput").GetString()!;
            _fileGolden = item.GetProperty("expectedFilesSha256").GetString()!;
            Files = Directory.EnumerateFiles(directory, "Lokad.*.dll").Order().ToDictionary(p => Path.GetFileName(p),
                p => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))));
        }
        catch { Dispose(); throw; }
    }

    private static object MeasureCells(Type type)
    {
        var constructor = type.GetConstructors().Single(c => c.GetParameters().Length == 3);
        object?[] arguments = [null, null, null];
        for (var i = 0; i < 32; i++) _ = constructor.Invoke(arguments);
        var values = new object[256];
        var before = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < values.Length; i++) values[i] = constructor.Invoke(arguments);
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        GC.KeepAlive(values);
        return new { instances = values.Length, bytes, bytesPerConstructionIncludingReflection = bytes / (double)values.Length, outsideGuestClocks = true };
    }

    private static long MeasureNodeArray(Type type, int length)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        var values = Array.CreateInstance(type, length);
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        GC.KeepAlive(values);
        return bytes;
    }

    private long Balance => (long)_balance.GetValue(_budget)!;
    public void FreezeBalance() => _expected = Balance;
    public void Measure(string phase)
    {
        if (phase == "warm") { Once(); return; }
        var original = _script;
        var expected = _expected;
        using (var fresh = (IDisposable)_compile.Invoke(_engine, [_source, _budget])!)
        {
            RequireValid(fresh);
            if (phase == "fresh")
            {
                _script = fresh;
                _expected = -1;
                try { Once(); }
                finally { _script = original; _expected = expected; }
            }
        }
        if (expected >= 0 && Balance != expected) throw new InvalidDataException("Fresh ownership did not end.");
    }
    public void Once()
    {
        _reset.Invoke(_host, null);
        var started = Stopwatch.GetTimestamp();
        IDisposable completed;
        if (_asynchronous)
        {
            var pending = (Task)_runAsync.Invoke(_script, [_host])!;
            pending.GetAwaiter().GetResult();
            completed = (IDisposable)_asyncResult.GetValue(pending)!;
        }
        else completed = (IDisposable)_run.Invoke(_script, [_host])!;
        PhaseTicks += Stopwatch.GetTimestamp() - started;
        using (var result = completed)
        {
            RequireSuccess(result);
            if (_capturePeak)
            {
                PeakExecutionBytes = (long)result.GetType().GetProperty("PeakExecutionMemoryBytes")!.GetValue(result)!;
                PeakRootBytes = (long)_budget.GetType().GetProperty("PeakBytes")!.GetValue(_budget)!;
                _capturePeak = false;
            }
            if ((string)result.GetType().GetProperty("StandardOutput")!.GetValue(result)! != _stdout ||
                (string)result.GetType().GetProperty("StandardError")!.GetValue(result)! != "")
                throw new InvalidDataException("Complete output golden failed.");
            if ((string)_digest.Invoke(null, [_outputs.Invoke(_host, null)])! != _fileGolden)
                throw new InvalidDataException("Complete file golden failed.");
        }
        if (_expected >= 0 && Balance != _expected) throw new InvalidDataException("Execution ownership did not end.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try
        {
            (_script as IDisposable)?.Dispose();
            if (Balance != 0) throw new InvalidDataException("Compiled owner did not end.");
        }
        finally
        {
            _validate.Invoke(null, [_owned]);
            if (Directory.Exists(_owned)) Directory.Delete(_owned, recursive: true);
        }
    }
    private static void RequireValid(object script)
    {
        if (!(bool)script.GetType().GetProperty("IsValid")!.GetValue(script)!) throw new InvalidDataException("Invalid control program.");
    }
    private static void RequireSuccess(object result)
    {
        if (!(bool)result.GetType().GetProperty("Success")!.GetValue(result)!) throw new InvalidDataException("Control invocation failed.");
    }
}

sealed class ImageContext(string directory, string name) : AssemblyLoadContext(name, isCollectible: false)
{
    protected override Assembly? Load(AssemblyName name)
    {
        if (name.Name is "System" or "netstandard" || name.Name!.StartsWith("System.", StringComparison.Ordinal)) return null;
        var path = Path.Combine(directory, name.Name + ".dll");
        return File.Exists(path) ? LoadFromAssemblyPath(path) : null;
    }
}
