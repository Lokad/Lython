from pathlib import Path
import json
d=json.loads((Path(__file__).parent.parent/'lexical-cell-storage-r284/catalog.json').read_text(encoding='utf-8'))
for case in d['cases']:
    if 'csv-validated' in case['id'] or 'nonlocal-counter' in case['id']:
        print(case['id']);print(case['source'])
