from pathlib import Path
from collections import Counter
import json,sys
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
rows=[]
for i in range(3 if len(sys.argv)==1 else 1):
    data=json.loads((r/f'capture-{i}.speedscope.json').read_text(encoding='utf-8'))
    names=[f['name'] for f in data['shared']['frames']]
    threads=[]
    for profile in data['profiles']:
        assert profile['type']=='evented' and profile['unit']=='milliseconds'
        stack=[];last=profile['startValue'];all_leaves=Counter();guest_leaves=Counter();guest_managed_parents=Counter();inclusive=Counter();guest_ms=0;intervals=0
        for event in profile['events']:
            at=event['at'];dt=at-last
            assert dt>=-.001
            if stack and dt>0:
                leaf=names[stack[-1]];all_leaves[leaf]+=dt
                frames=[names[j] for j in stack]
                # Select only real execution stacks, not caller waits, host reset,
                # validation or background runtime threads. Keep the full rest.
                if any('LythonRuntime+ExecutionContext.ExecuteInstructionPrefix' in f or 'LythonRuntime.ExecuteInstructionPrefix' in f or 'LythonRuntime+ExecutionContext.RunInstruction' in f for f in frames):
                    guest_ms+=dt;guest_leaves[leaf]+=dt;intervals+=1
                    parent=next((f for f in reversed(frames) if 'Lokad.Lython!' in f),'<no managed runtime parent>')
                    guest_managed_parents[parent]+=dt
                    for f in set(frames): inclusive[f]+=dt
            if event['type']=='O':stack.append(event['frame'])
            else:
                assert stack and stack[-1]==event['frame'];stack.pop()
            last=at
        threads.append(dict(name=profile['name'],guestMilliseconds=guest_ms,guestIntervals=intervals,allMilliseconds=sum(all_leaves.values()),allTop=all_leaves.most_common(14),guestTop=guest_leaves.most_common(30),guestManagedParents=guest_managed_parents.most_common(30),guestInclusive=inclusive.most_common(22)))
    row=dict(case=json.loads((r/f'capture-{i}.json').read_text(encoding='utf-8'))['caseId'],threads=threads)
    rows.append(row)
    print(row['case'])
    for t in sorted(threads,key=lambda t:t['guestMilliseconds'],reverse=True)[:3]:
        print(t['name'],'guest',round(t['guestMilliseconds'],2),'all',round(t['allMilliseconds'],2))
        for name,weight in t['guestManagedParents'][:9]: print(round(weight,2),name[:190])
(r/'attribution.json').write_text(json.dumps(dict(boundary='EventPipe sampled .NET thread wall time; exclusive intervals with active executable prefix, plus all other threads. Not CPU samples or elapsed comparison; unmanaged leaves/selection/inlining limit attribution.',rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
