from pathlib import Path
import json
d=json.loads((Path(__file__).parent/'attribution.json').read_text(encoding='utf-8'))
for row in d['rows']:
    t=max(row['threads'],key=lambda t:t['guestMilliseconds'])
    print(row['case'])
    for name,weight in t['guestTop'][:15]:print(round(weight,1),name[:200])
