set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/fused-executable-finalization-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/fused-executable-finalization-20261122
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Frontend|FullyQualifiedName~Parser|FullyQualifiedName~Compiler|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~AssertionBoundary|FullyQualifiedName~ComparisonBranch)' --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -35 "$logs/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Compile|FullyQualifiedName~RuntimePath|FullyQualifiedName~Exception|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~Annotation|FullyQualifiedName~ControlFlow|FullyQualifiedName~ComparisonBranch|FullyQualifiedName~PatternMatching)' --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -35 "$logs/public-ubuntu.log"; exit 1; }
grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
