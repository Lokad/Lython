from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
base = lab.parent
work = lab.parents[3] / ".git/agent-worktrees/fused-executable-finalization-20261122"
reference = base / "sparse-lexical-work-20261122/frozen/candidate"
candidate = lab / "frozen-candidate-core.dll"
prior = base / "branch-prefix-linearization"
expected_reference = json.loads((reference.parent.parent / "identity.json").read_text(encoding="utf-8-sig"))["imageFiles"]["candidate"]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8", newline="\n")

assert len(expected_reference) == 32 and {name: sha(reference / name) for name in expected_reference} == expected_reference
catalog = lab / "inspect-catalog.json"
cases = read(prior / "catalog.json")["cases"] + read(prior / "assertion-tail.json")["cases"]
cases += [{
    "id": "dead-heavy-control",
    "source": "def verify(flag):\n    if flag:\n        return 12\n    else:\n        return 18\n" +
        "\n".join(f"    unused_{i} = {i}" for i in range(512)) + "\nprint(verify(False), verify(True))\n"
}]
cases += [
    {"id": "nested-definition-in-protected-suite", "source":
        "def outer():\n try:\n  pass\n finally:\n  if True:\n   def inner(value: int = 9): return value\n return inner\nf = outer()\nprint(f.__qualname__, f())\n"},
    {"id": "postponed-module-annotation", "source":
        "from __future__ import annotations\nif True:\n value: list[int] = []\nprint(__annotations__)\n"},
]
cases.extend([
    {"id": "ordinary-scopes-under-protection", "source":
        "from __future__ import annotations\nclass K:\n if True:\n  label: list[str] = []\n def f(self):\n  try:\n   for item in range(2):\n    def callback(v: list[int] = []): return item\n  finally:\n   pass\n  return callback\nprint(K().f().__qualname__)\n"},
    {"id": "complex-scopes-under-protection", "source":
        "class Base:\n def value(self): return 1\nclass Derived(Base):\n def value(self):\n  try:\n   if True:\n    y = [(n := item) for item in [1,2]]\n    p = lambda x: x + n\n   return super().value() + p(1)\n  finally:\n   pass\nprint(Derived().value())\n"},
])
cases += [
    {"id": "native-loop-back-edge", "source":
     "def count(words):\n counts = {}\n total = 0\n for word in words:\n  counts[word] = counts.get(word, 0) + 1\n  total += 1\n return counts, total\nprint(count(('red', 'blue', 'red')))\n"},
    {"id": "nested-finally-counter", "source":
     "def apply(items):\n total = 0\n for i in items:\n  try:\n   match i:\n    case 1: continue\n    case 2: break\n    case _: total += 2\n  finally:\n   total += 1\n return total\nprint(apply([0,1,2,3]))\n"},
]
write(catalog, {"cases": cases})
workers = {
    "inspect": base / "current-frontend-phases/inspect/bin/Release/net11.0",
    "compile": base / "compiler-layout-phase-boundary/bulk-runner/bin/Release/net11.0",
}
images = {}
for role, core in (("reference", reference / "Lokad.Lython.dll"), ("candidate", candidate)):
    images[role] = {}
    for name, template in workers.items():
        directory = lab / role / name
        directory.mkdir(parents=True, exist_ok=True)
        for path in template.iterdir():
            if path.is_file():
                shutil.copyfile(path, directory / path.name)
        shutil.copyfile(core, directory / "Lokad.Lython.dll")
        hashes = {p.name: sha(p) for p in directory.iterdir() if p.is_file()}
        assert hashes["Lokad.Lython.dll"] == sha(core)
        images[role][name] = hashes
    out = lab / f"{role}-inspection.json"
    subprocess.run([dotnet, lab / role / "inspect/Inspect.dll", catalog, out], env=env, check=True, timeout=30)
    assert read(out)["coreSHA256"] == sha(core)

a, b = [read(lab / f"{role}-inspection.json")["rows"] for role in ("reference", "candidate")]
assert a == b, [row["id"] for row, other in zip(a, b, strict=True) if row != other]
write(lab / "inspection-identity.json", {
    "reference": "8c81fb8d2", "referenceImage": "d5abc29d4",
    "candidateSourcePatchSha256": hashlib.sha256(subprocess.check_output(["git", "diff", "8c81fb8d2", "HEAD", "--", "src"], cwd=work)).hexdigest(),
    "fixtureSHA256": sha(catalog), "workerImages": images,
    "exactCodeObjects": sum(len(row["codes"]) for row in a), "cases": [row["id"] for row in a],
})
print("Exact executable metadata matches for", sum(len(row["codes"]) for row in a), "code objects.")
