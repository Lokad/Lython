from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
base=Path(".git/agent-notes/review-20261031")
lab=base/"fused-executable-finalization-20261122"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path,source):
    if path.suffix==".py":compile(source,str(path),"exec")
    path.write_text(source,encoding="utf-8",newline="\n")
def save(path,obj):write(path,json.dumps(obj,indent=2)+"\n")
def sha(data):return hashlib.sha256(data).hexdigest()

prior=base/"numeric-tuple-slots-20261122"
old=read(prior/"quiet/config.json")
old_root=Path(old["root"]).name
old_receipt=read(prior/"quiet/archive-receipt.json")
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
where="benchmarks/results/2026-11-22-numeric-tuple-slots/"
def published(name):
    return subprocess.check_output(["git","show","origin/master:"+where+name])
archive=published("observations.tgz")
digest=sha(archive)
assert digest==old_receipt["archiveSHA256"]
core=gzip.decompress(published("candidate-core.dll.gz"))
assert sha(core)==old["identity"]["coreSHA256"]["candidate"]
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    member=next(m for m in tar.getmembers() if m.name.removeprefix("./")=="representative.json")
    catalog=tar.extractfile(member).read()
assert sha(catalog)==old["catalogSHA256"] and catalog==(prior/"quiet/representative.json").read_bytes()
proof=[]
for filename,data in (("candidate/Lokad.Lython.dll",core),("representative.json",catalog)):
    proof.append(dict(paths=[old_root+"/"+filename],links=1,bytes=len(data),sha256=sha(data),
                      archives={old_root+"/observations.tgz":digest},optional=False))
save(lab/"retire-proof.json",dict(proof=proof,canonical=where))

donor=base/"sparse-lexical-work-20261122"
manifest=read(donor/"quiet/representative.json")
wanted=[
    "scripts.config-generated-guards.medium.bad-0.sparse-lexical",
    "scripts.annotated-rule-closures.nested-factories.postponed",
    "scripts.dataclass-inherited-configuration.generated",
]
cases={case["id"]:case for case in manifest["cases"]}
demo=dict(cases[wanted[2]])
demo["id"]="diagnostic.dead-heavy-validator"
check=next(c for c in read(lab/"inspect-catalog.json")["cases"] if c["id"]=="dead-heavy-control")
demo["source"]=check["source"]
demo["size"]=512
fixture=json.loads(demo["fixtureJson"])
fixture["size"]=demo["size"]
demo["fixtureJson"]=json.dumps(fixture,separators=(",",":"))
demo["fixtureSha256"]=sha(demo["fixtureJson"].encode("utf-8"))
demo["sourceUtf8Bytes"]=len(demo["source"].encode("utf-8"))
demo["sourceSha256"]=sha(demo["source"].encode("utf-8"))
python=Path("C:/Python313/python.exe")
output=subprocess.check_output([python,"-I","-X","utf8","-c",demo["source"]]).replace(b"\r\n",b"\n")
assert output==b"18 12\n"
demo["expectedOutput"]=output.decode("utf-8")
demo["expectedOutputUtf8Bytes"]=len(output)
demo["expectedOutputSha256"]=sha(output)
manifest["cases"]=[cases[case] for case in wanted]+[demo]
save(lab/"representative.json",manifest)

p=base/"sparse-lexical-work-20261122/generate-staging.py"
# Copy the entire existing worker image, changing exactly the candidate core.
from shutil import copyfile
baseline=read(donor/"quiet/identity.json")["imageFiles"]["candidate"]
assert len(baseline)==32
images={}
for role in ("reference","candidate"):
    dest=lab/"frozen"/role
    dest.mkdir(parents=True,exist_ok=False)
    for name,h in baseline.items():
        src=donor/"frozen/candidate"/name
        assert sha(src.read_bytes())==h
        if role=="candidate" and name=="Lokad.Lython.dll":
            src=lab/"frozen-candidate-core.dll"
        copyfile(src,dest/name)
    images[role]={name:sha((dest/name).read_bytes()) for name in baseline}
assert images["reference"]==baseline
assert [name for name in baseline if images["reference"][name]!=images["candidate"][name]]==["Lokad.Lython.dll"]
target=subprocess.check_output(["git","rev-parse","refs/lython/prototypes/fused-executable-finalization"],text=True).strip()
save(lab/"identity.json",dict(reference="8c81fb8d2",candidate=target,imageFiles=images))

source=(donor/"prepare-quiet.py").read_text(encoding="utf-8")
i=source.index("cases = ["); j=source.index("\ncatalog[",i)
source=source[:i]+"cases = "+repr(wanted+[demo["id"]])+source[j:]
for old,new in (
    ('prior = lab.parent / "csv-quoted-ranges-20261122"','prior = lab.parent / "sparse-lexical-work-20261122"'),
    ('reference.startswith("745f8833f") and candidate.startswith("d5abc29d4")','reference.startswith("8c81fb8d2") and candidate == '+repr(target)),
    ('("Lokad.Lython.Tests", 111), ("Lokad.Lython.PublicApi.Tests", 984)','("white", 410), ("public", 1256)'),
    ("Single suite walk and sparse lexical expression preparation","Fused physical branch and native segment preparation"),
    ('sparse-lexical-work-b1315-20261122','fused-executable-finalization-b1320-20261122'),
    ('lython-b1315-sparse-lexical-work-20261122','lython-b1320-fused-executable-finalization-20261122'),
    ('(cases[3], "compile-run")]','(cases[0], "compile-run")]'),
    ('lython-b1315-fixtures','lython-b1320-fixtures'),
    ("Sparse lexical preparation comparison","Fused executable finalization comparison"),
    ('"310"','"380"'),
):
    assert old in source,old
    source=source.replace(old,new)
marker='        original = (original[:start]'
start=source.index(marker)
end=source.index("\n    if name",start)
source=source[:end]+'''
        original = original.replace("warmupSeconds=8", "warmupSeconds=12")
        original = original.replace("min(warmed)<8","min(warmed)<12").replace("warmed[i]>=8","warmed[i]>=12")
        original = original.replace("accumulate 8 seconds", "accumulate 12 seconds")'''+source[end:]
write(lab/"prepare-quiet.py",source)
