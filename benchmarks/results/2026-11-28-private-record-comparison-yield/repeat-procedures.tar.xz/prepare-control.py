from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
first = lab / 'comparison/quiet'
repeat = lab / 'control/comparison/quiet'
repeat.mkdir(parents=True)
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


donor = read(first / 'upload.json')['root']
donor_receipt = read(first / 'archive-receipt.json')
assert donor_receipt['archiveSHA256'] == digest(first / 'observations.tar.xz')
assert donor_receipt['complete'] and donor_receipt['allWorkersJoined']
root = 'script-record-comparison-sum-b1973-repeat-20261128'
identity = read(first / 'identity.json')
for role, files in identity['imageFiles'].items():
    assert {p.name: digest(p) for p in (lab / 'comparison' / role).iterdir()} == files
    proof = read(first / f'{role}-remote-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 3
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']

for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    copy2(first / name, repeat / name)
assert b'\r' not in (repeat / 'run.sh').read_bytes()
collector = (first / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('len(jobs) == 3', 'len(jobs) == 2')
collector = collector.replace("labels=['reference','candidate-control','reference-control','candidate']",
                             "labels=['candidate','reference-control','candidate-control','reference']")
(repeat / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
save(repeat / 'jobs.json', [job for job in reversed(read(first / 'jobs.json')) if 'iterable' not in job[0]])
identity.update(donorArchiveSHA256=donor_receipt['archiveSHA256'],
                frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate',
                purpose='Repeat tuple and explicit loop with opposite worker and workload order.')
identity['catalogs']['jobs.json']['sha256'] = digest(repeat / 'jobs.json')
save(repeat / 'identity.json', identity)
files = {name: repeat / name for name in ('identity.json', 'representative.json', 'cpython-worker.py', 'collect.py', 'run.sh', 'jobs.json')}
payload = repeat / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
save(repeat / 'upload.json', dict(root=root, donor=donor, donorArchive=identity['donorArchiveSHA256'],
     donorFiles=identity['imageFiles']['candidate'], donorImages=identity['imageFiles'],
     minimumAfterStageBytes=5*1024*1024, expandedBytes=sum(p.stat().st_size for p in files.values()),
     caseCount=3, payloadSHA256=digest(payload),
     files={name: dict(sha256=digest(p), length=p.stat().st_size) for name, p in files.items()}))

runner = (lab / 'quiet-vm.py').read_text(encoding='utf-8')
runner = runner.replace('lython-b1973-record-comparison', 'lython-b1973-record-repeat')
start = runner.index("   if cfg['donorFiles'][name]==digest:")
end = runner.index('  assert {p.name:sha(p)', start)
runner = runner[:start] + """   previous=donor/role/name
   assert cfg['donorImages'][role][name]==digest and sha(previous)==digest
   os.link(previous,target/name)
   reused['donor']+=1
""" + runner[end:]
(lab / 'control/quiet-vm.py').write_text(runner, encoding='utf-8', newline='\n')
summarize = (lab / 'summarize-quiet.py').read_text(encoding='utf-8')
summarize = summarize.replace("receipt['warmJobs'] == 3", "receipt['warmJobs'] == 2")
summarize = summarize.replace("'donor':63", "'donor':64").replace('== 84','== 56').replace('verifiedTimedBatches=84','verifiedTimedBatches=56')
(lab / 'control/summarize.py').write_text(summarize, encoding='utf-8', newline='\n')