from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-private-record-comparison-yield'
first = lab.parent / 'record-comparison-sum-b1973-20261128'
pair = lab / 'comparison'
quiet = pair / 'quiet'
profile = lab / 'attribution/profile'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(quiet / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
assert identity['imageFiles'] == read(pair / 'identity.json')['imageFiles'] == read(profile / 'identity.json')['imageFiles']
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
    assert read(pair / f'{role}-verify.json')['caseCount'] == 3
summary = read(quiet / 'summary.json')
assert summary['verifiedTimedBatches'] == 84 and summary['quietGates']
receipt = read(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')

allocation = read(lab / 'allocation/summary.json')
admission = read(lab / 'admission/summary.json')
assert len(allocation) == len(admission) == 6
assert all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in allocation)
assert all(row['requests'][0] == row['requests'][1] and row['peak'][0] == row['peak'][1] for row in admission)
for target, public_count in (('windows-net10.0', 418), ('windows-net11.0', 418), ('ubuntu-net11.0', 412)):
    for suite, count in (('public', public_count), ('whitebox', 41)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

sampling = read(profile / 'run-summary.json')
assert sampling['allProcessesJoined'] and sampling['totalVerifiedBatches'] == 85
for role, case, lane in read(profile / 'identity.json')['profiles']:
    directory = profile / role
    record = read(directory / 'record.json')
    assert record['allProcessesJoined'] and record['workload'] == case and record['lane'] == lane
    assert record['nettraceSha'] == digest(directory / 'run.nettrace')
    assert record['coreSha'] == identity['imageFiles']['candidate']['Lokad.Lython.dll']

out.mkdir(exist_ok=True)
public = {name: quiet / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json')}
public.update({f'{name}-summary.json': lab / name / 'summary.json' for name in ('allocation', 'admission')})
public.update({f'profile-{name}': profile / name for name in ('managed-attribution.json', 'run-summary.json')})
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

def archive_verified(name, files):
    with tarfile.open(out / name, 'w:xz') as archive:
        for path_in_archive, path in files.items():
            archive.add(path, arcname=path_in_archive)
    with tarfile.open(out / name) as archive:
        assert all(sha256(archive.extractfile(path_in_archive).read()).hexdigest() == digest(path)
                   for path_in_archive, path in files.items())


procedures = {path.name: path for path in lab.iterdir() if path.is_file()}
for folder, tag in ((pair, 'local'), (quiet, 'quiet')):
    procedures.update({f'{tag}/{path.name}': path for path in folder.iterdir() if path.name.endswith('-verify.json')})
for kind in ('allocation', 'admission'):
    procedures.update({f'{kind}/{path.name}': path for path in (lab / kind).glob('*.json')})
for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log'):
    procedures[f'quiet/{name}'] = quiet / name
for name in ('candidate.patch', 'reference-layout.json', 'candidate-layout.json', 'allocation/summary.json', 'admission/summary.json'):
    procedures[f'closure-prototype/{name}'] = first / name
archive_verified('procedures.tar.xz', procedures)
attribution = lab / 'attribution'
archive_verified('profiles.tar.xz', {path.relative_to(attribution).as_posix(): path for path in attribution.rglob('*')
                                    if path.is_file() and path.suffix != '.pyc'})
print('Verified six focused suites, local profiles and 84 quiet timed batches.')