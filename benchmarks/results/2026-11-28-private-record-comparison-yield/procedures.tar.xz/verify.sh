#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/record-comparison-sum-direct-b1973-20261128/comparison
export DOTNET_ROOT="$HOME/.dotnet"
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
for role in reference candidate; do
  "$DOTNET_ROOT/dotnet" "$role/Lokad.Lython.Benchmarks.dll" --compare verify --catalog representative.json \
    --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker cpython-worker.py --out "$role-verify.json"
done