from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json

lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
attribution = lab / 'attribution'
profile = attribution / 'profile'
source = lab.parent / 'current-generator-profile-b1971-20261128/attribution/profile'
profile.mkdir(parents=True)
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / 'identity.json')
identity.update(inspectedHead=identity['sourceRevision'], profiles=read(source / 'identity.json')['profiles'])
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
proof = read(pair / 'candidate-verify.json')
assert proof['state'] == 'Completed' and proof['caseCount'] == 3
for name in ('representative.json', 'cpython-worker.py', 'candidate-verify.json'):
    copy2(pair / name, attribution / name)

(profile / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
copy2(source / 'run.sh', profile / 'run.sh')
assert b'\r' not in (profile/'run.sh').read_bytes()
collector = (source / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace("lab.parents[1]/'comparison/quiet/local-image'", "lab.parents[1]/'comparison/candidate'")
collector = collector.replace('verification["caseCount"]==2', 'verification["caseCount"]==3')
(profile / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
analysis = (source / 'analyze-managed.py').read_text(encoding='utf-8')
analysis = analysis.replace("'TryPrepareBorrowedGeneratorSum'", "'PreparePrivateGenerator'")
analysis = analysis.replace("'BorrowedGeneratorSum.RunPrefix'", "'RunPrivateGeneratorPrefix'")
analysis = analysis.replace("'BorrowedGeneratorSum'", "'ExecutePreparedGeneratorSum'")
analysis = analysis.replace("'record cell reads':", "'short yield accumulation': ('TryAddBorrowedInteger', 'TryAccumulateSumInteger'),\n    'record comparison forwarding': ('TryReduceRecordComparison',),\n    'record cell reads':")
(profile / 'analyze-managed.py').write_text(analysis, encoding='utf-8', newline='\n')