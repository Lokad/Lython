from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("current-definition-cpu-20261125")
donor = lab.with_name("retained-async-cpython-20261125")
external = donor / "external"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, contents):
    p.write_text(contents, encoding="utf-8", newline="\n")
def save(p, data):
    write(p, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

observed = read(external / "identity.json")
receipt = read(external / "terminal-status.json")["receipt"]
assert receipt["complete"] and sha(external / "observations.tar.xz") == receipt["archiveSHA256"]
source = observed["productionSource"]
assert subprocess.check_output(["git", "rev-parse", "f6cf9796c"], cwd=repo).decode().strip() == source
image = donor / "candidate"
files = observed["imageFiles"]["candidate"]
assert len(files) == 32 and {p.name: sha(p) for p in image.iterdir()} == files
shipment = "diagnostic.shipment-routing-callbacks"
rules = "scripts.rule-default-closures"
catalog = read(external / "representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in (shipment, rules)]
assert len(catalog["cases"]) == 2
save(lab / "catalog.json", catalog)
save(lab / "identity.json", dict(
    sourceRevision=source, measurementReference=source, imageFiles={"candidate": files},
    coreSHA256={"candidate": files["Lokad.Lython.dll"]},
    cpythonWorkerSHA256=observed["cpythonWorkerSHA256"],
    profiles=[["shipment-warm", shipment, "candidate"], ["shipment-async", shipment, "candidate"],
              ["defaulted-rules-through", rules, "candidate"]],
    purpose="Locate remaining shipment and defaulted-rule work after retained zip and async map changes",
    donorArchiveSHA256=receipt["archiveSHA256"], profileCatalogSHA256=sha(lab / "catalog.json"),
))
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == observed["cpythonWorkerSHA256"]
proof = lab / "candidate-verification.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
                lab / "catalog.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                "--python-worker", protocol, "--out", proof], env=env, cwd=repo, check=True, timeout=65)
checked = read(proof)
assert checked["state"] == "Completed" and checked["caseCount"] == 2
assert checked["catalogSha256"] == sha(lab / "catalog.json")
assert checked["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]

# Keep the existing profiler protocol and lease gates. The earlier two-profile
# archive consumed 1.3 MB including raw working files. Six MiB leave room for
# three profiles and for archive verification before any duplicate is removed.
collector = (prior / "collect.py").read_text(encoding="utf-8")
collector = collector.replace("shared-map-operands-refined-b1679-20261125",
                              "retained-async-cpython-b1694-20261125").replace("b1680-fixtures", "b1696-fixtures")
collector = collector.replace("32*1024*1024-256*1024", "6*1024*1024-256*1024")
ops = (prior / "ops-profile.py").read_text(encoding="utf-8")
ops = ops.replace('lane = "compile-run" if name.endswith("-through")',
                  'lane = "warm-async" if name.endswith("-async") else "compile-run" if name.endswith("-through")')
launcher = (prior / "quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("current-definition-cpu-b1680", "post-async-map-cpu-b1696")
launcher = launcher.replace("lython-b1680-current-definition-cpu", "lython-b1696-post-async-map-cpu")
launcher = launcher.replace("shared-map-operands-refined-20261125", "retained-async-cpython-20261125")
launcher = launcher.replace("32*1024*1024", "6*1024*1024").replace("Staged two profiles", "Staged three profiles")
launcher = launcher.replace("RuntimeMaxSec=125", "RuntimeMaxSec=175").replace("seconds=95", "seconds=120")
assert 'lane = "warm-async"' in ops and "retained-async-cpython-b1694" in collector
for name, contents in (("quiet.py", launcher), ("collect.py", collector), ("ops-profile.py", ops)):
    compile(contents, name, "exec")
    write(lab / name, contents)
shutil.copyfile(prior / "run.sh", lab / "run.sh")
assert b"\r" not in (lab / "run.sh").read_bytes()
if not (lab / "verified-raw-replicas.json").exists():
    save(lab / "verified-raw-replicas.json", [])
