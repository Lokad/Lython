set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/standalone-capture-cells-r622
export PATH="$HOME/.dotnet:$PATH"
out=/mnt/d/code/Lython/artifacts/r622-wsl
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --artifacts-path "$out"
probe="$out/tools/LythonProbe/bin/Release/net10.0"
mkdir -p "$probe"
cp -a "$out/bin/LythonProbe/release_net10.0/." "$probe/"
fixtures="$out/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Fixtures"
cp -a tests/Fixtures/Workflows "$fixtures/"
python_cli=$(command -v python3.13 || command -v python3)
mkdir -p "$out/bin/cli-path"
if [ ! -e "$out/bin/cli-path/python" ]; then ln -s "$python_cli" "$out/bin/cli-path/python"; fi
export PATH="$out/bin/cli-path:$PATH"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$out" --no-build --filter 'FullyQualifiedName~PythonComparisonPreservesMatchingFailures|FullyQualifiedName~FnmatchScenarioTests.FilterAndUppercaseFixture'
