from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
previous=lab.parent/'shared-lexical-names-r621'
qual=lab.parent/'prepared-definition-text-r611'
old_selector=lab.parent/'native-format-selectors-r615'
trial=repo/'.git/agent-worktrees/standalone-capture-cells-r622'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args])
ref=git('rev-parse','48309e4e3').decode().strip()
can=git('-C',str(trial),'rev-parse','HEAD').decode().strip()
manifest=load(previous/'frozen-identity.json')
assert not git('diff','--name-only',manifest['candidateCommit'],ref,'--','src','tests')
assert not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',ref,can,'--','benchmarks','src/Lokad.Lython.Utf8Regex')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',ref,can,'--','src','tests'))
catalog_path=lab/'catalog.json'
catalog=load(previous/'catalog.json')
python=Path('C:/Python313/python.exe')
capture=next(c.copy() for c in catalog['cases'] if c['id']=='scripts.rule-default-closures')
source='''def make_rules(index):
    offset = index % 7
    weight = index % 5 + 1
    enabled = index % 3 != 0
    def apply(base):
        return (base + offset) * weight if enabled else base
    def alternate():
        step = (index + 1) % 7
        return lambda base: (base - step) * 2
    return apply, alternate()

total = 0
for index in range(2048):
    apply, fallback = make_rules(index)
    total += apply(index) + fallback(index)
print(total)
'''
capture.update(id='scripts.captured-rule-closures',source=source)
capture['expectedOutput']=subprocess.check_output([python,'-I','-S','-X','utf8','-c',source]).decode().replace('\r\n','\n')
for field in ('source','expectedOutput'):
 data=capture[field].encode('utf-8')
 capture[field+'Utf8Bytes']=len(data)
 capture[field+'Sha256']=sha(data)
catalog['cases'].append(capture)
assert len(catalog['cases'])==7
write(catalog_path,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source=previous/'frozen/candidate'
files=manifest['images']['candidate']
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha((source/name).read_bytes()) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    expected=files.copy()
    for name in files:
        origin=source/name
        if role=='candidate' and name==core:
            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
            expected[name]=sha(origin.read_bytes())
        if not (image/name).exists():shutil.copyfile(origin,image/name)
    for extra in (old_selector/'frozen/candidate').glob('ValidatedAllocation.*'):
        if not (image/extra.name).exists():shutil.copyfile(extra,image/extra.name)
    if role=='candidate':assert expected[core]!=files[core]
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
            '--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',lab/(role+'-verify.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path.read_bytes())
    with (lab/(role+'-allocation.log')).open('wb') as log:
        subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,catalog_path,lab/(role+'-allocation.json')],
            env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    images[role]=expected
write(lab/'frozen-identity.json',dict(referenceCommit=ref,candidateCommit=can,casesSHA256=sha(catalog_path.read_bytes()),images=images))
for left,right in zip(*[load(lab/(role+'-allocation.json'))['rows'] for role in ('reference','candidate')],strict=True):
    assert left['id']==right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a,b=[statistics.median(r['allocatedBytesPerInvocation']) for r in (left,right)]
    print(left['id'],f'{a:,} to {b:,}',f'{100*(b/a-1):+.2f}%',left['peakExecutionMemoryBytes'],right['peakExecutionMemoryBytes'],flush=True)
print('Both complete images and all seven cases verified against CPython.')
