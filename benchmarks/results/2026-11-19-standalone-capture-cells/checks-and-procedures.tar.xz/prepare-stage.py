from pathlib import Path
import ast
p=Path(__file__).resolve().parent
previous=p.parent/'shared-lexical-names-r621'
s=(previous/'stage-quiet.py').read_text(encoding='utf-8-sig')
s=s.replace('lexical-definition-context-r619','shared-lexical-names-r621')
s=s.replace('R621 compiled qualified names and R620 module-owned leaf functions','R622 independently owned lexical capture cells')
s=s.replace('shared-lexical-names-b1051','standalone-capture-cells-b1053')
s=s.replace('lython-b1051-shared-lexical-names','lython-b1053-standalone-capture-cells').replace('lython-b1051-fixtures','lython-b1053-fixtures')
s=s.replace('225 * 1024 * 1024','218 * 1024 * 1024')
s=s.replace('str(232*1024*1024)','str(225*1024*1024)')
s=s.replace('old["identity"]["imageFiles"]["reference"]','old["identity"]["imageFiles"]["candidate"]').replace('sourceRole="reference"','sourceRole="candidate"')
a,b=s.index('        jobs = ['),s.index('        source=source[:a]')
s=s[:a]+'''        jobs = [
            ('scripts.captured-rule-closures','warm'),('scripts.captured-rule-closures','compile-run'),
            ('scripts.annotated-rule-closures','warm'),('scripts.report-forwarding.expanded','compile-run'),('calls.positional.large','warm')]
'''+s[b:]
s=s.replace('"len(jobs)==7","len(jobs)==8"','"len(jobs)==8","len(jobs)==5"').replace('"len(raw[\'jobs\'])==7","len(raw[\'jobs\'])==8"','"len(raw[\'jobs\'])==8","len(raw[\'jobs\'])==5"').replace('"jobs=7,","jobs=8,"','"jobs=8,","jobs=5,"').replace('"[\'jobs\']==7","[\'jobs\']==8"','"[\'jobs\']==8","[\'jobs\']==5"')
s=s.replace('"355","412"','"412","267"').replace('"==7","==8"','"==8","==5"')
s=s.replace('Shared lexical names and module-owned leaf functions','Independently owned lexical capture cells')
s=s.replace('six-case, eight-job','seven-case, five-job')
ast.parse(s)
(p/'stage-quiet.py').write_text(s,encoding='utf-8',newline='\n')
