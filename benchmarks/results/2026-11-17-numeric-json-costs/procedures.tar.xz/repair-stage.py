from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');c=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert not c['retireGroups']
for name in ['config.json','remote-launch.py','launch.log']:
 target=r/('floor-first-'+name);assert not target.exists();target.write_bytes((r/name).read_bytes())
canonical='benchmarks/results/2026-11-17-json-cpython-checkpoint/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:raw=archive.extractfile('confirmation/confirmation.json').read()
for member,data in [('confirmation/confirmation.json',raw),('whole-archive',blob)]:c['retireGroups'].append(dict(paths=['json-cpython-b908-20261117/'+('observations.tgz'if member=='whole-archive'else member)],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-shared-allowance-lock/catalog.json';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root)
digest=hashlib.sha256(blob).hexdigest()
code="""from pathlib import Path
import fcntl,hashlib,json,os,stat
b=Path('/home/lokad/lython-bench-checks');p=b/'shared-allowance-lock-b906-20261117/representative.json'
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m=p.lstat();assert p.resolve()==p and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_size==SIZE and hashlib.sha256(p.read_bytes()).hexdigest()==DIGEST
 aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   target=Path(base)/name;v=target.lstat()
   if(v.st_dev,v.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(target.relative_to(b)))
 assert len(aliases)==m.st_nlink
 print(json.dumps(dict(paths=aliases,bytes=m.st_size,links=m.st_nlink,sha256=DIGEST)))
""".replace('SIZE',str(len(blob))).replace('DIGEST',repr(digest))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);assert p.returncode==0,p.stdout+p.stderr
c['retireGroups'].append(json.loads(p.stdout)|dict(canonical=canonical,canonicalSHA256=digest,member='whole-file',committedBlobVerified=True))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
assert(r/'launch.log').read_bytes()==(r/'floor-first-launch.log').read_bytes();(r/'launch.log').unlink()
print('Pre-mutation floor refusal preserved; exact committed CPython raw/archive and old catalog eligible for fresh revalidation. Current images/primary catalog preserved.')
