from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;r.mkdir(exist_ok=True);notes=r.parent;old=notes/'record-pipeline-r484';main=notes/'call-cost-gate-r488';cp=notes/'json-cpython-checkpoint-r491'
receipt=json.loads((cp/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
f=json.loads((main/'main-frozen-identity.json').read_text(encoding='utf-8'));current=f['imageFiles'];prior=json.loads((cp/'quiet/config.json').read_text(encoding='utf-8'));remote='/home/lokad/lython-bench-checks/numeric-json-cost-b909-20261117'
identity=dict(sourceRevision='Committed runtime557381fe/frozend739132f; fullaf6 delivery44116196658 pending at preparation',purpose='One current complete floating JSON numeric report attribution. Distinguish JSON parsing/construction, arithmetic/operand execution and admission; no predicted speedup or removable share. Scalar headroom and compact16byte slots already exist. Select a coherent displaced stage or name uncertainty.',coreSHA256={'candidate':current['Lokad.Lython.dll']},auxiliaryFiles={n:h for n,h in current.items()if n!='Lokad.Lython.dll'},imageFiles={'candidate':current},catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/json-record-cost-b901-20261117',remote).replace('json-records','floating-records').replace('scripts.json-summary-helpers.large','scripts.numeric-squared-error.floating.large').replace('Committeddbdf8262/frozena95ff2a4; R484 JSON-lines record attribution','Committed557381fe/frozend739132f; R490 floating JSON attribution')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
s=(old/'analyze.py').read_text(encoding='utf-8').replace('json-records','floating-records')
s=s.replace("groups={'JSON decode/construction':","groups={'numeric arithmetic':['ApplyArithmetic','ApplyBinary','TryExecuteNumeric','TryGetDouble','ApplyNative','TryExecuteFloat','TryExecuteBinary'], 'native prefix work':['NativeExecution::','RunCore','ExecuteOrdinaryNativeFunctionPrefix'], 'JSON decode/construction':")
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
names=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(r/name,arcname=name)
c=dict(root=remote,unit='lython-b909-numeric-json-cost-20261117',source=prior['root'],sourceRole='candidate',sourceFiles=current,sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((r/name).stat().st_size for name in names))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace(' # Custom catalog passed verification with actual image before staging.'," os.link(source/'representative.json',root/'catalog.json')\n # Same five-case catalog and actual committed image already verified.")
s=s.replace('lython-b901-fixtures','lython-b909-fixtures');(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for name in ['launch.py','retrieve.py']:(r/name).write_text((old/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('One five-second current numerical workload attribution prepared; verified image/catalog hardlinks only, no retirement. Stop with stage selection or named uncertainty.')
