from pathlib import Path
import hashlib, json, shutil, tarfile

r = Path(__file__).parent
root = Path('D:/code/Lython')
dest = root / 'benchmarks/results/2026-11-17-numeric-json-costs'
dest.mkdir(exist_ok=False)
receipt = json.loads((r / 'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r / 'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
for name in ['attribution.json', 'archive-receipt.json', 'terminal-status.json', 'observations.tgz', 'identity.json']:
    shutil.copyfile(r / name, dest / name)
shutil.copyfile(r.parent / 'call-cost-gate-r488/checkpoint-catalog.json', dest / 'catalog.json')
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for p in sorted(r.rglob('*')):
        if not p.is_file(): continue
        n = p.relative_to(r)
        if 'retrieved' in n.parts or n.name in ['payload.tgz', 'observations.tgz']: continue
        archive.add(p, arcname=n.as_posix())
(dest / 'README.md').write_text('''# Floating JSON numerical report attribution

R490/B909, 2026-11-17 UTC. Runtime557381fe/frozend739132f, now
[fully qualified](../2026-11-17-shared-allowance-lock/delivery/README.md).
One existing complete script: parse two arrays of4096 floating values, aggregate
through a helper and generator sum, write a sorted JSON report. Same verified
five-case catalog/32-file image as the [CPython checkpoint](../2026-11-17-json-cpython-checkpoint/README.md).
This is sampled attribution, not a controlled performance comparison.

949 active execution-thread samples/81 unknown leaves; 4.856 guest seconds/4.78
active CPU seconds. Nearest Lython frames: instruction prefix152, JSON number
conversion87, stack transfer85, JSON construction74, sequence indexing56, generic
indexing54, input instruction38, native prefix35, managed stack admission34,
arithmetic28. JSON inclusive190, indexing110, call/frame182, admission1; groups
overlap useful/inlined work and are not removable percentages. The initial
arithmetic classifier omitted TryEvaluateBuiltinArithmetic; the corrected result
and original analysis are both preserved. No boxing-only or full-gap attribution.

Source gate: generator sum already consumes native slots; slots already contain
one managed reference and one long. Ordinary JSON numbers already use scalar
headroom, not per-number reservations. Input contains two flat arrays, not4096
nested row containers. No duplicate scalar format, sum transport, credit cache or
per-record capacity redesign is justified by those false premises.

Select R492: direct scalar parsing into iterative construction, removing default
ValueTask<object> then ValueTask<(object,int)> packaging. Only genuine callbacks
need pending work. Keep one parser/public document async boundary, exact grammar,
raw_decode positions, hooks/error/effect order, large integer admission, retained
aliases, current cancellation and joined cleanup. A bounded floating warm/fresh,
helper JSON and unchanged control comparison determines retention/regression debt;
no predicted magnitude or automatic threshold. Execution/index/stack work remains.

Eight-second warmup/two-second settle/five-second199Hz cpu-clock/frame-pointer
capture on quiet Azure F4as_v7/Ubuntu24.04.4/.NET11RC3, normal GC/tiering,
diagnostic PerfMap only. All actual-image/golden/quiet/Closed/exit/join gates pass.
RAM traces SHA-archived persistently under lease before unmount. Joined root-owned
perf data received ownership correction with unchanged bytes. The first staging
attempt refused below the disk floor before mutation/measurement; preserved with
the exact-committed-replica repair, not treated as a failed design. Protected
images/toolchains/canonical evidence and254/252MiB floors remain. Terminal cached.

[Attribution](attribution.json), [raw](observations.tgz), [catalog](catalog.json),
[identity](identity.json), [custody](archive-receipt.json), [procedures](procedures.tar.xz).
Publication remains held; this capture does not complete the performance objective.
''', encoding='utf-8', newline='\n')

p = root / 'docs/BENCHMARKS.md'
s = p.read_text(encoding='utf-8').replace('all measurement gates pass. Changed-source full delivery44116196658 is pending.',
    'all measurement gates pass. [Full changed-source delivery44116196658 passes](../benchmarks/results/2026-11-17-shared-allowance-lock/delivery/README.md).')
p.write_text(s, encoding='utf-8', newline='\n')
p = root / 'benchmarks/results/2026-11-17-json-cpython-checkpoint/README.md'
s = p.read_text(encoding='utf-8').replace('Windows/Ubuntu11/10/stress/installed-package delivery44116196658 is pending.',
    '[Windows/Ubuntu11/10/stress/installed-package delivery44116196658 passes](../2026-11-17-shared-allowance-lock/delivery/README.md).')
p.write_text(s, encoding='utf-8', newline='\n')
p = root / 'benchmarks/EXPERIMENTS.md'
with p.open('a', encoding='utf-8', newline='\n') as f:
    f.write('\nR488 full [delivery44116196658](results/2026-11-17-shared-allowance-lock/delivery/README.md) is GREEN/cached ataf6ccb4a/runtime557381fe: both platforms/actual11/10 ordinary, original stress and installed explicit Release consumers;16summaries/2382inputs/585production verified. Earlier adverse process remains unresolved, no universal speedup claim or unchanged qualification replay.\n\nR490/B909 [current numerical JSON attribution](results/2026-11-17-numeric-json-costs/README.md):949samples/81unknown, JSONinclusive190, indexing110, call/frame182, admission1; groups overlap useful work. Native sum/scalar headroom/compact slots already exist; two flat arrays do not establish per-record row capacity cost. Select direct scalar parsing into iterative JSON construction, pending work only for genuine hooks; bounded semantic/ownership/cancellation checks and complete-script pair before retention. Original classifier omission and pre-mutation disk-floor refusal preserved. All users joined/RAM archived before removal; no performance comparison or predicted gain. Broader objective active, publication held.\n')
print('Preserved current attribution and completed delivery; no new measurement or qualification.')
