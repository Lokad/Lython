from pathlib import Path
import subprocess

lab = Path(__file__).resolve().parent
repo = "/mnt/d/code/Lython"
worktree = repo + "/.git/agent-worktrees/borrowed-cased-words-20261123"
dotnet = "/home/vermorel/.dotnet/dotnet"
filters = {
    "white": ("Lokad.Lython.Tests", "FullyQualifiedName~CasedSplitOwnership|FullyQualifiedName~NativeText|FullyQualifiedName~DictionaryAccumulation"),
    "public": ("Lokad.Lython.PublicApi.Tests", "Category!=Stress&(FullyQualifiedName~NativeWordBinding|FullyQualifiedName~CasedWhitespacePipeline|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~DictionaryAccumulationLifetime)"),
}
for kind, (project, query) in filters.items():
    logfile = lab / f"ubuntu-{kind}.log"
    with logfile.open("wb") as log:
        result = subprocess.run(["wsl.exe", "--cd", worktree, "--exec", "env",
            "DOTNET_ROOT=/home/vermorel/.dotnet", "DOTNET_HOST_PATH=" + dotnet, dotnet, "test",
            "tests/" + project, "-c", "Release", "-f", "net10.0",
            "--artifacts-path", repo + "/" + lab.relative_to(lab.parents[3]).as_posix() + "/ubuntu",
            "--filter", query], stdout=log, stderr=subprocess.STDOUT, timeout=170)
    print(logfile.read_text(encoding="utf-8")[-4800:])
    result.check_returncode()
