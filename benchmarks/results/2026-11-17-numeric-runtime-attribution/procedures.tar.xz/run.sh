set -eu
root=/home/lokad/lython-bench-checks/numeric-pipeline-b882-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
