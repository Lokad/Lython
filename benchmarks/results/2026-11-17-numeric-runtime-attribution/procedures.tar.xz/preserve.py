from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;base=Path('D:/code/Lython');out=base/'benchmarks/results/2026-11-17-numeric-runtime-attribution';out.mkdir(exist_ok=False)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['attribution.json','observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz')as archive:
 for p in list(r.glob('*.py'))+list(r.glob('*.json'))+list(r.glob('*.sh'))+list(r.glob('*.log')):
  archive.add(p,arcname=p.name)
(out/'README.md').write_text('''# Current numeric-report CPU attribution

R472/B882,2026-11-17UTC. Committed dc480d38/frozen5ecb2599, same fixed
three-case catalog and current optional0.4adapter. Two complete4,096-record
numeric JSON/report scripts differ only in integer versus exact-fraction data.
Existing checked workers/perf protocol; two5s captures after8s guest warmup.
**Attribution, not an elapsed comparison or a removable-cost estimate.**

| Observation | Integer | Floating |
| --- | ---: | ---: |
| Active-thread samples | 971 | 983 |
| Unmapped leaves, retained | 63 | 59 |
| Nearest instruction-prefix frame | 150 | 127 |
| Nearest stack-transfer frame | 97 | 104 |
| Nearest direct-sequence-index frame | 38 | 108 |
| Nearest native-call selection | 29 | 31 |
| Nearest JSON construction | 62 | 51 |
| Nearest numeric JSON conversion | 33 | 91 |

JSON inclusive122/177samples overlaps useful decoding; call/frame216/157overlaps
useful native work. Generator inclusive922/943includes everything under sum,
including JSON loaded earlier: broad stacks are not exclusive/removable shares.
All raw stacks/threadCPU/unknowns remain. Managed stack checks stay; these samples
do not justify removing cancellation/admission or predict a speedup.

Current source rejects two stale proposals: JSON already has a single iterative
construction loop, admitted inline/grown frames and transfers only real pending
callbacks. Default numeric parsing is native UTF-8. PyList already funds metadata/
scalar headroom at capacity, not through per-number admissions. Do not rebuild
these delivered mechanisms. R469bulk raw-token scanning and R470argument staging
remain withdrawn; sampled dispatch alone does not vindicate their old designs.

One bounded next source gate: LoadGlobal still resolves the global context and
probes the active module's string→local/closure maps per read, despite immutable
compiler-owned module slot metadata. Assess preparing that binding fact once,
guarded by the actual module layout, without caching values. Rebinding/deletion,
builtin fallback, globals dictionaries, imports/class/lazy scopes, real suspension,
current tokens and funded aliases must remain. Determine current executable sites
before any prototype; no CPU forecast or broad compiler rewrite from this profile.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, natural workstationGC; only diagnostic
PerfMapEnabled=3 override. Whole batch CPU is wider than guest clocks: reset/I/O/
validation/protocol remain visible, unknown/native frames retained. Active guest
thread CPU4.89/4.95s; tieredJIT0.08/0.09s and other threads recorded separately.
All identities/goldens/pre-post quiet/Closed/exits/joins pass. Owned RAM raw/maps/
stacks archived and byte-verified persistently under lease before unmount. Terminal
cached; no repeated capture. Retire only committed B880workingraw395,964Bwith fresh
UID/path/hash/link/all-inode-alias proof. Current images/toolchains/canonicals and
254/252MiBstaging/final floors preserved. CI44022750002active independently;
no runtime/contract change or publication from attribution.

[Attribution](attribution.json),[raw/maps/stacks](observations.tgz),
[identity](identity.json),[procedures](procedures.tar.xz).
''',encoding='utf-8',newline='\n')
p=base/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as stream:stream.write('''
[R472/B882 current integer/floating report CPU](results/2026-11-17-numeric-runtime-attribution/README.md)
captures971/983active samples,63/59unmappedleaves; dispatch/indexing/calls distributed,
JSON useful work present. Inclusive generator/call stacks are not removable cost.
CurrentJSON alreadyiterative/defaultUTF8; PyList alreadycapacity-funded. No new
runtime prototype or repeated capture. Next sourcegate assesses immutable global
binding facts instead of repeated module name-map probes; semantics/ownership/
compile costs must qualify before retention. All gates/join/RAM-archive verified;
full44022750002continues independently,publicationheld.
''')
print('Current sampled evidence preserved; stale JSON/list-accounting proposals rejected against source, precise global-binding source gate remains.')
