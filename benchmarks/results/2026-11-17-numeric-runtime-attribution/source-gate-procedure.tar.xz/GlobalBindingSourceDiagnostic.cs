using System.Text;
using System.Text.Json;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Tests;

public sealed class GlobalBindingSourceDiagnostic
{
    [Fact]
    public void ObserveExistingGlobalReads()
    {
        const string notes = "D:/code/Lython/.git/agent-notes/review-20261031";
        using var catalog = JsonDocument.Parse(File.ReadAllText(notes + "/floating-transport-r471/catalog.json", Encoding.UTF8));
        var rows = new List<object>();
        foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
        {
            var id = item.GetProperty("id").GetString()!;
            if (id is not ("scripts.numeric-squared-error.floating.large" or "scripts.text-normalization.helper-list"
                or "scripts.report-render.helper-list" or "calls.positional.large")) continue;
            var frontend = LythonFrontend.Compile(item.GetProperty("source").GetString()!, regexProvider: Utf8RegexProvider.Instance);
            Assert.NotNull(frontend.Script);
            var executable = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script));
            var module = executable.EntryPoint;
            var pending = new Stack<ExecutableCodeObject>(); pending.Push(module);
            var visited = new HashSet<ExecutableCodeObject>();
            while (pending.TryPop(out var code))
            {
                if (!visited.Add(code)) continue;
                rows.Add(new
                {
                    workload = id, function = code.Name, code.IsFunctionScope, code.RequiresLocalVariableMirroring,
                    moduleLocals = module.LocalNames, moduleClosures = module.ClosureNames,
                    globalReads = code.Instructions.Where(i => i.OpCode == ExecutableOpCode.LoadGlobal)
                        .Select(i => new { name = code.Names[i.NameIndex], i.Span,
                            moduleSlot = module.LocalNameToSlot.TryGetValue(code.Names[i.NameIndex], out var slot) ? slot : -1 }).ToArray()
                });
                foreach (var function in code.Functions) pending.Push(function.CodeObject);
                foreach (var constant in code.Constants)
                {
                    if (constant is ExecutableCreateLambda lambda) pending.Push(lambda.CodeObject);
                    if (constant is ExecutableCreateGeneratorExpression generator) pending.Push(generator.CodeObject);
                }
            }
        }
        File.WriteAllText(notes + "/numeric-pipeline-r472/global-read-shapes.json",
            JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);
    }
}
