from pathlib import Path
import subprocess
root=Path('D:/code/Lython');work=root/'.git/agent-worktrees/call-operands-r470'
files=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Slot.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Arithmetic.cs','src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs','src/Lokad.Lython/Runtime/Protocols/IPyIterableValue.cs']
test='tests/Lokad.Lython.PublicApi.Tests/FloatArithmeticPipelineTests.cs'
for name in files+[test]:assert(work/name).read_text(encoding='utf-8')==(root/name).read_text(encoding='utf-8'),name
assert subprocess.check_output(['git','-C',str(work),'status','--porcelain'],text=True).count('\n')==5
subprocess.run(['git','-C',str(work),'restore','--']+files,check=True)
p=(work/test).resolve();assert p.is_relative_to(work.resolve());p.unlink()
subprocess.run(['git','-C',str(work),'switch','--detach','dc480d38'],check=True)
assert not subprocess.check_output(['git','-C',str(work),'status','--porcelain'],text=True).strip()
print('Reused private worktree at committeddc480d38; prior prototype removed, exact promoted test preserved in main.')
