from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
base=lab.parent
donor=base/'decoded-closed-defaults-20261124'
template=base/'shared-traversal-cpython-20261124'
out=lab/'external'
out.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
save=lambda path,data:path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
write=lambda path,script:path.write_text(script,encoding='utf-8',newline='\n')
revision=lambda ref:subprocess.check_output(['git','rev-parse',ref],cwd=root,text=True).strip()
meta=read(donor/'comparison/identity.json')
receipt=read(donor/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha((donor/'comparison/quiet/observations.tar.xz').read_bytes())==receipt['archiveSHA256']
source=revision('5313f9e71')
subprocess.run(['git','diff','--exit-code',meta['candidate'],source,'--','src','tests'],cwd=root,check=True)
files=meta['imageFiles']['candidate']
assert len(files)==32
frozen=lab/'candidate'
frozen.mkdir(exist_ok=True)
for name in files:shutil.copyfile(donor/'candidate'/name,frozen/name)
assert {p.name:sha(p.read_bytes()) for p in frozen.iterdir()}==files
location='annotated-factories-cpython-b1593-20261124'
original='decoded-closed-defaults-b1591-20261124'
identity=dict(sourceRevision=meta['candidate'],candidate=meta['candidate'],productionSource=source,
    imageFiles={'candidate':files},frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles={name:expected for name,expected in files.items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:meta['coreSHA256'][role] for role in ('candidate','candidate-control')},
    expectedCPythonSHA256=meta['expectedCPythonSHA256'],cpythonWorkerSHA256=meta['cpythonWorkerSHA256'])
catalog=read(donor/'comparison/representative.json')
captured='scripts.captured-rule-closures'
defaulted='scripts.rule-default-closures'
eager='scripts.annotated-rule-closures'
postponed='scripts.annotated-rule-closures.nested-factories.postponed'
ids=(eager,postponed,captured,defaulted)
catalog['cases']=[next(case for case in catalog['cases'] if case['id']==case_id) for case_id in ids]
save(out/'representative.json',catalog)
jobs=[(case,'warm') for case in ids]+[(case,lane) for case in ids[:2] for lane in ('compile','compile-run')]
save(out/'jobs.json',jobs)
identity['catalogs']={name:{'sha256':sha((out/name).read_bytes())} for name in ('representative.json','jobs.json')}
save(out/'identity.json',identity)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=root/'benchmarks/cpython-worker.py'
assert sha(protocol.read_bytes())==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',out/'candidate-verify.json'],
    env=env,cwd=root,check=True,timeout=85)
check=read(out/'candidate-verify.json')
assert check['state']=='Completed' and check['caseCount']==4
assert check['launched']['library']['sha256']==identity['coreSHA256']['candidate']
assert check['catalogSha256']==identity['catalogs']['representative.json']['sha256']

collector=(template/'external/collect.py').read_text(encoding='utf-8').replace('b1587-','b1593-')
collector=collector.replace('len(jobs) == 10','len(jobs) == 8').replace('started<535','started<450')
collector=collector.replace('CPython checkpoint for current JSON traversal and generated rule scripts',
    'CPython checkpoint for eager and postponed annotated rule factories')
compile(collector,'collect.py','exec')
write(out/'collect.py',collector)
summary=(template/'external/summarize.py').read_text(encoding='utf-8')
assert 'len(raw["jobs"])==10 and receipt["warmJobs"]==10' in summary
summary=summary.replace('len(raw["jobs"])==10 and receipt["warmJobs"]==10','len(raw["jobs"])==8 and receipt["warmJobs"]==8')
compile(summary,'summarize.py','exec')
write(out/'summarize.py',summary)
launcher=(template/'external.py').read_text(encoding='utf-8')
launcher=launcher.replace('json-traversal-20261124/comparison/quiet','decoded-closed-defaults-20261124/comparison/quiet').replace('json-traversal-b1586-20261124',original)
launcher=launcher.replace('shared-traversal-cpython-b1587-20261124',location).replace('lython-b1587-shared-traversal-cpython', 'lython-b1593-annotated-factories-cpython')
launcher=launcher.replace("    retired = json.loads((output/'verified-replicas.json').read_text(encoding='utf-8'))\n",'')
launcher=launcher.replace('; retired={retired!r}','')
start=launcher.index(' free=shutil.disk_usage(base).free\n')
end=launcher.index(' assert shutil.disk_usage(base).free>=minimum\n',start)
launcher=launcher[:start]+launcher[end:]
launcher=launcher.replace('RuntimeMaxSec=570','RuntimeMaxSec=495').replace('seconds=504','seconds=436')
remote,=(n.value for n in ast.walk(ast.parse(launcher)) if isinstance(n,ast.Constant) and isinstance(n.value,str) and 'staged=sum' in n.value)
compile(remote,'remote-stage','exec')
assert 'retired' not in remote and not '\r' in launcher
write(lab/'external.py',launcher)
print('Prepared eight short lanes with four verified CPython script goldens.')
