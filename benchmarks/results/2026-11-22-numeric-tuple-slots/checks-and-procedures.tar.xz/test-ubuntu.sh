set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/numeric-tuple-slots-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/numeric-tuple-slots-20261122
filter='Category!=Stress&(FullyQualifiedName~Tuple|FullyQualifiedName~FunctionDefault|FullyQualifiedName~CsvNumeric|FullyQualifiedName~Floating|FullyQualifiedName~NativeReturn)'
for kind in white public; do
    if [ "$kind" = white ]; then suite=Lokad.Lython.Tests; else suite=Lokad.Lython.PublicApi.Tests; fi
    dotnet test "tests/$suite" -c Release -f net10.0 --filter "$filter" > "$logs/$kind-ubuntu.log" 2>&1 || { tail -40 "$logs/$kind-ubuntu.log"; exit 1; }
    grep 'Passed!' "$logs/$kind-ubuntu.log"
done
