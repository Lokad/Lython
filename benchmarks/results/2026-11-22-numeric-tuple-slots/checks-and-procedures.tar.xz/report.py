from pathlib import Path
import json

lab=Path(__file__).resolve().parent
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
data=load(lab/"quiet/quiet-summary.json")
decision=load(lab/"decision.json")
rows=[
    "| Whole warm script | Elapsed change | Process CPU change | Reference / candidate elapsed spread |",
    "| --- | ---: | ---: | ---: |",
]
names={
    "scripts.csv-meter-report.typed-ascii":"Typed ASCII CSV meter report",
    "scripts.csv-meter-report.explicit-float":"CSV meter report with explicit float",
    "scripts.csv-invoice.large":"Plain integer invoice control",
}
def extent(values):
    lo=f"{min(values):+.2f}".replace("-","−")
    hi=f"{max(values):+.2f}".replace("-","−")
    return lo+"%" if lo==hi else lo+" to "+hi+"%"
for row in data["rows"]:
    rows.append(f"| {names[row['case']]} | {extent(row['elapsedChangePercent'])} | "
                f"{extent(row['cpuChangePercent'])} | {row['referenceSpreadPercent']:.2f} / "
                f"{row['candidateSpreadPercent']:.2f}% |")

report="""# B1319 Native number slots in retained tuples

Extend the existing unpublished integer slots to floating-point tuple
items. Numeric indexes borrow the funded tuple slot. Python object
observers still publish one stable box. A mixed tuple preserves
existing aliases and chooses the wider backing when fresh numbers
make up at least half of its inputs. The backing and eventual boxes
are admitted before construction.

Compared `8c81fb8d2` with `8bb572375` on November 22, 2026 UTC on
the quiet Azure F4as_v7 running Ubuntu 24.04.4 and .NET 11 RC3.
Two independently warmed processes per revision supplied seven
rotated batches each. Ranges cover all process-median pairings.
Elapsed includes mediated RAM-backed I/O and prior-result disposal.
Process CPU includes worker request handling. Negative changes
favor the candidate.

"""
report+="\n".join(rows)+"\n\n"
report+=decision["explanation"]+"\n\n"
report+=f"""The typed ASCII meter allocates 2.83% less locally and its accounted
peak rises by 229,376 bytes, from 4,142,729 to 4,372,105. The explicit
float meter has effectively flat allocation and increases its peak
by 458,752 bytes. The local invoice and formatted report have
effectively flat allocation and unchanged peaks. All four budgets
return to baseline.

Windows .NET 11 and Ubuntu .NET 10 each pass 109 white-box and
425 public focused Release checks. A retained mixed tuple preserves
negative zero, alias identity, deepcopy behavior and observation
after actual asynchronous input. Both full worker images pass the
timed CPython goldens. All 84 timed batches match. Workers join;
the persistent archive validates under the lease after fixture
cleanup in {data['elapsedSeconds']:.0f} seconds.

[Timing](summary.json) · [Allocation](allocation-summary.json) ·
[Raw observations](observations.tgz) · [Source and checks](checks-and-procedures.tar.xz) ·
[Reference core](../2026-11-22-sparse-lexical-preparation/candidate-core.dll.gz).
"""
(lab/"README.md").write_text(report,encoding="utf-8",newline="\n")
