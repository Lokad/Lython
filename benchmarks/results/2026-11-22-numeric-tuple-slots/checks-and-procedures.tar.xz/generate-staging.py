from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path(".git/agent-notes/review-20261031")
lab=base/"numeric-tuple-slots-20261122"
prior=base/"json-decoded-suffix-20261122"
root="benchmarks/results/2026-11-22-json-decoded-suffix/"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def published(name): return subprocess.check_output(["git","show","origin/master:"+root+name])
retire=[]
archives={}
for local,artifact in (("quiet","observations.tgz"),("confirmation","confirmation/observations.tgz")):
    path=prior/local
    proof=read(path/"archive-receipt.json")
    assert proof["complete"] and proof["archivedAndVerifiedUnderLease"]
    archived=published(artifact)
    assert sha(archived)==proof["archiveSHA256"]
    directory=Path(read(path/"config.json")["root"]).name
    retire.append(directory+"/candidate/Lokad.Lython.dll")
    archives[directory+"/observations.tgz"]=sha(archived)
dll=gzip.decompress(published("candidate-core.dll.gz"))
assert sha(dll)==read(prior/"identity.json")["imageFiles"]["candidate"]["Lokad.Lython.dll"]
proof=[dict(paths=retire,bytes=len(dll),links=len(retire),sha256=sha(dll),archives=archives,optional=False)]
(lab/"retire-proof.json").write_text(json.dumps(dict(proof=proof,canonical=root),indent=2)+"\n",encoding="utf-8",newline="\n")

src=(prior/"prepare-quiet.py").read_text(encoding="utf-8")
start=src.index("cases = [")
end=src.index("\ncatalog[",start)
cases=["scripts.csv-meter-report.typed-ascii","scripts.csv-meter-report.explicit-float","scripts.csv-invoice.large"]
src=src[:start]+"cases = "+repr(cases)+src[end:]
for a,b in (
    ('candidate.startswith("e5316a8de")','candidate.startswith("8bb572375")'),
    ('("white", 217), ("public", 906)','("white", 109), ("public", 425)'),
    ('proof["caseCount"] == 4','proof["caseCount"] == 3'),
    ("Bounded JSON text runs and short decoded suffix reuse","Native numeric tuple slots for retained arithmetic results"),
    ('json-decoded-suffix-b1317-20261122','numeric-tuple-slots-b1319-20261122'),
    ('lython-b1317-json-decoded-suffix-20261122','lython-b1319-numeric-tuple-slots-20261122'),
    ('"len(jobs)==4"','"len(jobs)==3"'),
    ('"jobs=4,"','"jobs=3,"'),
    ('==4"', '==3"'),
    ('lython-b1317-fixtures','lython-b1319-fixtures'),
    ('JSON decoded suffix comparison','Numeric tuple slot comparison'),
    ('"310"','"205"'),
    ('Prepared four lanes','Prepared three lanes'),
):
    assert a in src,a
    src=src.replace(a,b)
compile(src,"prepare-quiet.py","exec")
(lab/"prepare-quiet.py").write_text(src,encoding="utf-8",newline="\n")
