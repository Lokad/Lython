set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/pair-only-rollback-20261125"
worktree="$PWD/.git/agent-worktrees/pair-only-rollback-20261125"
log="$lab/pair-ubuntu10.log"
if dotnet test "$worktree/tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~ExecutableDefinitionPairTests|FullyQualifiedName~FunctionDefaultConstructionTests' > "$log" 2>&1; then
  tail -4 "$log"
else
  tail -35 "$log"
  exit 1
fi
