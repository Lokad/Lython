from pathlib import Path
import shutil

lab = Path(__file__).resolve().parent
prior = lab.with_name("callable-owned-rollback-20261125")
jobs = [
    ("diagnostic.shipment-routing-callbacks", "warm-async"),
    ("scripts.rule-default-closures", "warm"),
    ("scripts.annotated-rule-closures.nested-factories.postponed", "warm"),
    ("scripts.rule-default-closures", "compile-run"),
    ("scripts.annotated-rule-closures.nested-factories.postponed", "compile-run"),
]

def edit(name, substitutions):
    text = (prior / name).read_text(encoding="utf-8")
    for before, after in substitutions:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

freeze = (prior / "freeze.py").read_text(encoding="utf-8")
edit("freeze.py", [
    ("repo = lab.parents[3]", 'repo = lab.parents[3]\nworktree = repo / ".git/agent-worktrees/pair-only-rollback-20261125"'),
    ('''def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)''',
     '''def git(*args):
    return subprocess.check_output(["git", *args], cwd=worktree)'''),
    ('shutil.copyfile(repo / path, frozen / path)', 'shutil.copyfile(worktree / path, frozen / path)'),
    ('(repo / name).read_bytes() if role == "candidate"', '(worktree / name).read_bytes() if role == "candidate"'),
    ('patch.write_bytes(git("diff", "--binary", "--", "src"))',
     '''assert patch.read_bytes() == git("diff", "--binary", "--", "src")
assert sha(patch) == read(lab / "identity-source.json")["sourcePatchSHA256"]'''),
    (next(line for line in freeze.splitlines() if line.startswith("jobs =")), "jobs = " + repr(jobs)),
    ('== 5', '== 3'),
    ('Transfer rollback of completed private definitions to their callable owner',
     'Transfer rollback ownership for pairs, keeping single computed definitions unchanged'),
])
edit("prepare.py", [
    ('verified["caseCount"] == 5', 'verified["caseCount"] == 3'),
    ('collector.replace("b1711-fixtures", "b1717-fixtures")',
     'collector.replace("b1711-fixtures", "b1717c-fixtures").replace("len(jobs) == 8", "len(jobs) == 5")'),
    ('"started < 367"', '"started < 242"'),
    ('"targetBatchSeconds=.48"', '"targetBatchSeconds=.50"'),
    ('"lython-b1717-callable-owned-rollback"', '"lython-b1717c-pair-only-rollback"'),
    ('launcher.replace("b1716", "b1717")', 'launcher.replace("b1716", "b1717c")'),
    ('"RuntimeMaxSec=392"', '"RuntimeMaxSec=270"'),
    ('"seconds=310"', '"seconds=216"'),
    ('root="callable-owned-rollback-b1717-20261125"', 'root="pair-only-rollback-b1717c-20261125"'),
])
edit("package.py", [
    ('2026-11-25-callable-owned-rollback', '2026-11-25-pair-only-rollback'),
    ('\n)\n(lab / "archive.py")', '\n).replace(\'==receipt["warmJobs"]==8\', \'==receipt["warmJobs"]==5\').replace(\n'
     '    "timedBatches=224,lanes=8", "timedBatches=140,lanes=5"\n)\n(lab / "archive.py")'),
    ('"derive.py", "freeze.py", "prepare.py",', '"prepare-pair.py", "freeze.py", "prepare.py",'),
    ('"candidate.patch", "candidate-build.log",', '"candidate.patch", "test.patch", "identity-source.json", "candidate-build.log",'),
    ('    "probe-build.log", "wide-defaults.py", "probe-sync.json", "probe-async.json",\n'
     '    "Lokad.Lython.Tests-win11.log", "Lokad.Lython.PublicApi.Tests-win11.log",\n'
     '    "Lokad.Lython.Tests-ubuntu10.log", "Lokad.Lython.PublicApi.Tests-ubuntu10.log",',
     '    "pair-win11.log", "pair-ubuntu10.log", "quiet-vm-space-custody.json",'),
])
