from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("closed-default-store-links-20261125")
quiet = lab / "comparison/quiet"
out = repo / "benchmarks/results/2026-11-25-pair-only-rollback"
archive = (donor / "archive.py").read_text(encoding="utf-8").replace(
    "2026-11-25-closed-default-store-links", "2026-11-25-pair-only-rollback"
).replace('==receipt["warmJobs"]==8', '==receipt["warmJobs"]==5').replace(
    "timedBatches=224,lanes=8", "timedBatches=140,lanes=5"
)
(lab / "archive.py").write_text(archive, encoding="utf-8", newline="\n")
exec(compile(archive, "archive.py", "exec"))

procedures = out / "procedures.tar.xz"
names = (
    "prepare-pair.py", "freeze.py", "prepare.py", "quiet.py", "archive.py", "package.py", "test-ubuntu.sh",
    "candidate.patch", "test.patch", "identity-source.json", "candidate-build.log", "launch-console.log", "retrieve.log",
    "pair-win11.log", "pair-ubuntu10.log", "quiet-vm-space-custody.json",
    "reference-allocation-final.json", "candidate-allocation-final.json", "allocations.py",
    "reference-compiler-owner.json", "candidate-compiler-owner.json", "compile-allocation.py",
    "comparison/reference-verify.json", "comparison/candidate-verify.json",
    "comparison/quiet/representative.json", "comparison/quiet/jobs.json",
    "comparison/quiet/storage-custody.json",
)
with tarfile.open(procedures, "w:xz") as data:
    for name in names:
        data.add(lab / name, arcname=name)
with tarfile.open(procedures) as data:
    for name in names:
        member = data.getmember(name)
        assert member.isfile() and data.extractfile(member).read() == (lab / name).read_bytes()
for name in ("allocation-summary.json", "compile-allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
shutil.copyfile(quiet / "identity.json", out / "identity.json")
