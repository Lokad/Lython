export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/keyword-table-copy-r686
~/.dotnet/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter '(FullyQualifiedName~PrefixCallCompatibilityTests|FullyQualifiedName~BindingPlanConstructionTests|FullyQualifiedName~FrameIntegerLifetimeTests|FullyQualifiedName~CapturedScalarExecutionTests)&Category!=Stress' >"$lab/ubuntu.log" 2>&1
code=$?
tail -n 12 "$lab/ubuntu.log"
exit "$code"
