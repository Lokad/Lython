$lab = Split-Path -Parent $MyInvocation.MyCommand.Path
$dotnet = Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter = 'Category!=Stress&(FullyQualifiedName~Starmap|FullyQualifiedName~IterationWorkspaceLifetime|FullyQualifiedName~Generator|FullyQualifiedName~Itertools|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~Cancellation)'
foreach ($suite in @('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests')) {
    & $dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter $filter --nologo --verbosity minimal 2>&1 | Tee-Object -FilePath "$lab/windows-$suite-net10.0.log"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

