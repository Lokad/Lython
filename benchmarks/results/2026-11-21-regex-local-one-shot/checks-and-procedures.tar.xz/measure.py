from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = "d51891009"
candidate = "225575497"
worktree = repo / ".git/agent-worktrees/regex-shared-group-utf8-20261121"
donor = lab.parent / "packed-annotations-in-creation"
prior = lab.parent / "direct-regex-group-copy"
source_owner = lab.parent / "observed-regex-coordinates/frozen/reference"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree, text=True).startswith(candidate)
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=worktree)
catalog = load(lab.parent / "regex-shared-group-utf8/representative.json")
prototype = catalog["cases"][0]
header = """import re
rows = ['INFO|sensor-42|température stable', 'WARN|sensor-9|signal perdu', 'DEBUG|sensor-3|ignored'] * 320
"""
sources = [
  ("scripts.regex.single-match-records", header + r"""pattern = re.compile(r'(?P<level>INFO|WARN)\|(?P<sensor>[^|]+)\|(.+)')
total = 0
warn = 0
for row in rows:
    match = pattern.fullmatch(row)
    if match:
        total += len(match[2]) + len(match[3])
        warn += match['level'] == 'WARN'
print(total, warn)
"""),
  ("scripts.regex.cursor-records", header + r"""data = '\n'.join(rows)
pattern = re.compile(r'(?m)^(?P<level>INFO|WARN)\|(?P<sensor>[^|]+)\|([^\n]+)$')
total = 0
warn = 0
for match in pattern.finditer(data):
    total += len(match[2]) + len(match[3])
    warn += match['level'] == 'WARN'
print(total, warn)
"""),
  ("scripts.regex.wide-single-match", """import re
pattern = re.compile('(a)' * 12)
rows = ['a' * 12, 'a' * 11 + 'b'] * 480
total = 0
for row in rows:
    match = pattern.fullmatch(row)
    if match:
        total += match.end(12)
print(total)
"""),
  ("scripts.regex.wide-unicode-single-match", """import re
pattern = re.compile('(?<=(é))' + '(😀)' * 40 + '(z)?')
subject = 'é' + '😀' * 40 + 'tail'
total = 0
for index in range(960):
    match = pattern.match(subject, 1, 41)
    total += match.start(1) + match.end(1) + match.end(41) + match.start(42) + match.lastindex
print(total)
""")
]
catalog["cases"] = []
for case_id, code in sources:
    outcome = subprocess.run([python, "-X", "utf8", "-I", "-c", code], check=True, capture_output=True, timeout=15)
    stdout = outcome.stdout.replace(b"\r\n", b"\n")
    assert not outcome.stderr
    fixture = json.loads(prototype["fixtureJson"])
    fixture["size"] = 960
    fixture_json = json.dumps(fixture, separators=(",", ":"))
    catalog["cases"].append(dict(prototype, id=case_id, size=960, source=code, sourceSha256=sha(code.encode("utf-8")),
        expectedOutput=stdout.decode("utf-8"), expectedOutputSha256=sha(stdout),
        fixtureJson=fixture_json, fixtureSha256=sha(fixture_json.encode("utf-8"))))
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "quiet/identity.json")["imageFiles"]["reference"]
reference = donor / "quiet-workers/reference"
assert len(identity) == 32 and {name: sha((reference / name).read_bytes()) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role, root in (("reference", repo), ("candidate", worktree)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = reference / name
        if name == core:
            origin = (lab.parent / "native-only-method-lookup-20261121/frozen/candidate" / name if role == "reference"
                      else root / "src/Lokad.Lython/bin/Release/net11.0" / name)
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha((image / name).read_bytes()) for name in identity}
    for path in source_owner.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest.read_bytes())
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha((image / name).read_bytes()) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=baseline, candidate=candidate,
     catalogSHA256=sha(manifest.read_bytes()), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1])
save(lab / "allocation-summary.json", result)
