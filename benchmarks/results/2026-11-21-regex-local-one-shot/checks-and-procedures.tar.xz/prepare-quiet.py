from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "native-only-method-lookup-20261121"
donor = prior / "quiet"
out = lab / "quiet"
out.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

def tracked(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)

def recoverable(artifact, paths, links, expected_sha, archives):
    base = "benchmarks/results/"
    binary = gzip.decompress(tracked(base + artifact))
    assert sha_bytes(binary) == expected_sha
    checked = {}
    for remote, (published, digest) in archives.items():
        assert sha_bytes(tracked(base + published)) == digest
        checked[remote + "/observations.tgz"] = digest
    return dict(paths=paths, links=links, bytes=len(binary), sha256=expected_sha, archives=checked, optional=False)

csv="2026-11-21-csv-literal-record-ranges/"
csv_stage=lab.parent/"csv-literal-record-ranges-20261121/quiet"
csv_root="csv-literal-record-b1302-20261121"
csv_core=load(csv_stage/"identity.json")["imageFiles"]["candidate"]["Lokad.Lython.dll"]
retire=[recoverable(csv+"candidate-core.dll.gz",[csv_root+"/candidate/Lokad.Lython.dll"],1,csv_core,
    {csv_root:(csv+"observations.tgz",load(csv_stage/"archive-receipt.json")["archiveSHA256"])})]
prior_config = load(donor / "config.json")
prior_receipt = load(donor / "archive-receipt.json")
prior_identity = load(donor / "identity.json")
reference_donor = prior_identity["imageFiles"]["candidate"]
assert prior_receipt["complete"] and prior_receipt["archivedAndVerifiedUnderLease"]
assert len(reference_donor) == 32 and reference_donor == {name:sha(prior / "frozen/candidate" / name) for name in reference_donor}

manifest = out / "representative.json"
catalog = load(lab / "representative.json")
cases = ["scripts.regex.single-match-records", "scripts.regex.cursor-records", "scripts.regex.wide-single-match", "scripts.regex.wide-unicode-single-match"]
catalog["cases"] = [case for id in cases for case in catalog["cases"] if case["id"] == id]
assert [c["id"] for c in catalog["cases"]] == cases
save(manifest, catalog)
local = load(lab / "identity.json")
reference, candidate = (subprocess.check_output(["git", "rev-parse", local[key]], cwd=repo, text=True).strip()
                       for key in ("reference", "candidate"))
assert reference.startswith("d51891009") and candidate.startswith("225575497")
image_files = local["imageFiles"]
core = "Lokad.Lython.dll"
for role, hashes in image_files.items():
    image = lab / "frozen" / role
    assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
    assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    for suite, count in (("white", 67), ("public", 424)):
        log = (lab / f"{suite}-win.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
    sdk = Path.home() / ".dotnet11"
    dotnet = sdk / "dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
    receipt = lab / f"quiet-{role}-verify.json"
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == prior_config["protocolSHA256"]
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", receipt], check=True, env=env, timeout=95)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest)

identity = dict(sourceRevision=reference + " versus " + candidate, purpose="Remove the prepared-operation wrapper from all one-shot matches",
                imageFiles=image_files, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in image_files.items() for suffix in ("", "-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/regex-local-single-b1303-20261121"
unit = "lython-b1303-regex-local-single-20261121"
jobs = [(case, "warm") for case in cases]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    original = (donor / name).read_text(encoding="utf-8").replace(prior_config["root"], root).replace(prior_config["unit"], unit)
    if name == "collect.py":
        start, end = original.index("\njobs = "), original.index("\nassert len(jobs)")
        original = (original[:start] + "\njobs = " + repr(jobs) + original[end:]).replace("len(jobs)==3", "len(jobs)==4")
    if name == "archive-owned.py":
        original = original.replace("jobs=3,", "jobs=4,").replace("len(raw['jobs'])==3", "len(raw['jobs'])==4")
    if name == "retrieve.py":
        original = original.replace("['jobs']==3", "['jobs']==4")
    emit(out / name, original)
assert b"\r" not in (out / "run.sh").read_bytes()
for role in image_files:
    (out / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, out / role / core)
    assert sha(out / role / core) == image_files[role][core]
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json",
         "candidate/" + core)
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as file:
    for name in parts:
        file.add(out / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=prior_config["root"], sourceRole="candidate",
             sourceFiles=reference_donor, sourceCatalogSHA256=prior_config["catalogSHA256"],
             donorArchiveSHA256=prior_receipt["archiveSHA256"], protocolSource=prior_config["root"] + "/cpython-worker.py",
             protocolSHA256=prior_config["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=sha(manifest),
             unpackedBytes=sum((out / name).stat().st_size for name in parts))
save(out / "config.json", stage)
source = (donor / "remote-launch.py").read_text(encoding="utf-8")
start, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:start] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1297-fixtures", "lython-b1303-fixtures")
assert "c['unpackedBytes']+640*1024" in source
emit(out / "remote-launch.py", source)
emit(lab / "launch.py", (csv_stage.parent / "launch.py").read_text(encoding="utf-8")
     .replace("Native CSV record ranges comparison", "All-width single-match regex scratch comparison").replace("225","300"))
emit(lab / "summarize.py", (csv_stage.parent / "summarize.py").read_text(encoding="utf-8")
     .replace("len(raw['jobs'])==3", "len(raw['jobs'])==4"))
print(f"Prepared four lanes with {stage['unpackedBytes']} bytes of persistent working data.")
