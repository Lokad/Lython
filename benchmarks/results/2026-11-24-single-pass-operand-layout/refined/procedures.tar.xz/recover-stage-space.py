from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
published = lab.parents[3]/'benchmarks/results/2026-11-24-frontend-phase-profile'
archive = published/'observations.tar.xz'
receipt = json.loads((published/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
sha = lambda data: hashlib.sha256(data).hexdigest()
archive_sha = sha(archive.read_bytes())
assert archive_sha == receipt['archiveSHA256']
members = {}
with tarfile.open(archive) as bundle:
    for name in ('profiles/classifier-compile/perf.data', 'profiles/sparse-compile/perf.data'):
        member = bundle.getmember(name)
        assert member.isfile()
        members[name] = (member.size, sha(bundle.extractfile(member).read()))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
script = f'archive_sha={archive_sha!r}\nmembers={members!r}\n'+'''
from pathlib import Path
import fcntl, hashlib, json, shutil, stat, subprocess
base = Path('/home/lokad/lython-bench-checks').resolve()
root = base/'frontend-phase-profile-b1650-20261124'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    free_before=shutil.disk_usage(base).free
    removed=[]
    if free_before < 8000000:
        assert root.resolve()==root and not (root/'guest-fixtures').exists()
        state=subprocess.check_output(['systemctl','show','lython-b1650-frontend-phase-profile-20261124.service',
                                       '--property=ActiveState,MainPID'],text=True)
        assert 'ActiveState=inactive' in state and 'MainPID=0' in state
        status=json.loads((root/'archive-receipt.json').read_text())
        assert status['complete'] and status['allWorkersJoined'] and status['archivedAndVerifiedUnderLease']
        evidence=root/'observations.tar.xz'
        assert status['archiveSHA256']==archive_sha==sha(evidence)
        verified=[]
        for name,(size,hash_value) in members.items():
            path=root/name
            info=path.lstat()
            assert path.resolve()==path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
            assert info.st_nlink==1 and info.st_size==size and sha(path)==hash_value
            verified.append((path,dict(name=name,size=size,sha256=hash_value)))
        for path,member in verified:
            path.unlink()
            removed.append(member)
        assert sha(evidence)==archive_sha
    print(json.dumps(dict(freeBefore=free_before,freeAfter=shutil.disk_usage(base).free,
                          archiveSHA256=archive_sha,verifiedDuplicatesRetired=removed)))
'''
result=subprocess.run(ssh,input=script,encoding='utf-8',capture_output=True,timeout=35,check=True)
(lab/'retired-stage-custody.json').write_text(result.stdout,encoding='utf-8',newline='\n')
print(result.stdout,end='')
