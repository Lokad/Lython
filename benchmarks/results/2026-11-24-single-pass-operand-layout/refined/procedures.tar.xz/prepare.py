from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('shared-match-bindings-20261124')
previous = donor/'comparison/quiet'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')

base = read(previous/'identity.json')
reference_revision = subprocess.check_output(['git','rev-parse','4ae7dcc38'], cwd=repo,text=True).strip()
archived_patch = subprocess.check_output(['git','diff','--binary',base['sourceRevision'],reference_revision,
                                         '--','src','docs','tests'], cwd=repo)
assert hashlib.sha256(archived_patch).hexdigest() == base['sourcePatchSHA256']
source_file = 'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs'
assert not subprocess.check_output(['git','diff',reference_revision,'HEAD','--',source_file],cwd=repo)
patch = subprocess.check_output(['git','diff','--binary','--',source_file],cwd=repo)
assert b'depth -= beforeForwarding - kept;' in patch
(lab/'candidate.patch').write_bytes(patch)
frozen = lab/'frozen-source'
assert (frozen/source_file).read_bytes() == (repo/source_file).read_bytes()
with zipfile.ZipFile(lab/'frozen-source.zip') as archive:
    for name in archive.namelist():
        if name.endswith('/') or name == source_file: continue
        path = frozen/name
        assert path.read_bytes()==archive.read(name), name

core = 'Lokad.Lython.dll'
old_image = base['imageFiles']['candidate']
candidate_core = lab/'frozen-build/bin/Lokad.Lython/release_net11.0'/core
assert len(old_image) == 32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()} == old_image
images = {'reference': old_image, 'candidate': old_image | {core: sha(candidate_core)}}
assert images['candidate'][core] != old_image[core]
for role, files in images.items():
    image = lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(candidate_core if role=='candidate' and name==core else donor/'candidate'/name, image/name)
    assert {p.name:sha(p) for p in image.iterdir()} == files

catalog = previous/'representative.json'
expected = quiet/'representative.json'
shutil.copyfile(catalog, expected)
target, sparse, manifest = [row['id'] for row in read(catalog)['cases']]
assert target=='diagnostic.generated-record-classifier'
jobs = [[target,'compile-run'],[sparse,'compile'],[manifest,'compile-run'],[target,'compile']]
save(quiet/'jobs.json', {'warm':jobs})
identity = dict(sourceRevision=reference_revision, comparisonRevision=reference_revision, sourcePatchSHA256=sha(lab/'candidate.patch'),
    purpose='Combine operand forwarding and storage layout in one traversal of each reachable block', imageFiles=images,
    expectedCPythonSHA256=base['expectedCPythonSHA256'], cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    coreSHA256={role+suffix: files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json', identity)
collector = (previous/'collect.py').read_text(encoding='utf-8').replace('b1648-fixtures','b1652-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector, encoding='utf-8',newline='\n')
shutil.copyfile(previous/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
python = Path('C:/Python313/python.exe')
worker = repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role in images:
    output = lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',expected,
        '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',output],env=env,cwd=repo,check=True,timeout=60)
    checked = read(output)
    assert checked['state']=='Completed' and checked['caseCount']==3
    assert checked['catalogSha256']==sha(expected) and checked['launched']['library']['sha256']==images[role][core]

payload = quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        package.add(quiet/name,arcname=name)
    package.add(candidate_core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='single-pass-operand-layout-refined-b1652-20261124', reference='shared-match-bindings-b1648-20261124',
    payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
