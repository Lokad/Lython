from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.with_name('single-pass-operand-layout-20261124')
package = (old/'package-evidence.py').read_text(encoding='utf-8')
package = package.replace("/'benchmarks/results/2026-11-24-single-pass-operand-layout'", "/'benchmarks/results/2026-11-24-single-pass-operand-layout/refined'")
package = package.replace("'candidate.patch','make-prototype.py',", "'candidate.patch','recover-stage-space.py','retired-stage-custody.json',")
package = package.replace("'initial-windows-white.log','initial-ubuntu-public.log','initial-tape.log','tape.log',", "'tape.log',")
assert all(item not in package for item in ('make-prototype.py','initial-tape.log'))
exec(compile(package,__file__,'exec'))
