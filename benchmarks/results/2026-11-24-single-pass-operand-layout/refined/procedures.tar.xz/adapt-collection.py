from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
old = lab.with_name('single-pass-operand-layout-20261124')
match = lab.with_name('shared-match-bindings-20261124')
prepare = (old/'prepare.py').read_text(encoding='utf-8')
prepare = prepare.replace('single-pass-operand-layout-b1651','single-pass-operand-layout-refined-b1652').replace('b1651-fixtures','b1652-fixtures')
prepare = prepare.replace(".replace('len(jobs) == 4','len(jobs) == 6')", '')
prepare = prepare.replace("jobs = [[target,'compile'],[sparse,'compile'],[manifest,'compile-run'],[target,'compile-run'],[manifest,'compile'],[sparse,'compile-run']]",
                          "jobs = [[target,'compile-run'],[sparse,'compile'],[manifest,'compile-run'],[target,'compile']]")
quiet = (old/'quiet.py').read_text(encoding='utf-8').replace('b1651','b1652').replace('single-pass-operand-layout','single-pass-operand-layout-refined')
quiet = quiet.replace('RuntimeMaxSec=292','RuntimeMaxSec=228').replace('seconds=208','seconds=154')
archive = (match/'archive.py').read_text(encoding='utf-8').replace('2026-11-24-shared-match-bindings','2026-11-24-single-pass-operand-layout/refined')
archive = archive.replace('out.mkdir(exist_ok=True)', 'out.mkdir(parents=True, exist_ok=True)')
for name, source in (('prepare.py', prepare), ('quiet.py', quiet), ('archive.py', archive)):
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')
for name in ('allocations.py','compile-allocation.py','check-tape.py','verify-boundaries.py'):
    shutil.copyfile(old/name,lab/name)
(lab/'tape').mkdir(exist_ok=True)
for name in ('Tape.csproj','Program.cs'):
    shutil.copyfile(old/'tape'/name,lab/'tape'/name)
(lab/'verified-raw-replicas.json').write_text('[]\n',encoding='utf-8',newline='\n')
