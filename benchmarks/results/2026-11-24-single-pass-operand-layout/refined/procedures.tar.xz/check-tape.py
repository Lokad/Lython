from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
match = lab.with_name('shared-match-bindings-20261124')
definition = lab.with_name('shared-function-definition-descriptor-20261124')
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
catalog = read(match/'comparison/quiet/representative.json')
catalog['cases'] += [row for row in read(definition/'comparison/quiet/representative.json')['cases']
                     if row['id'] not in {c['id'] for c in catalog['cases']}]
scripts = {
    'protected-and-assert': '''
def compute(limit):
    seen = []
    for idx in range(limit):
        try:
            if idx == 2: continue
            assert idx != 3, (idx + 5, limit)
            if idx == 5: break
            seen.append(idx)
        except AssertionError as error:
            seen.append(error.args[0][0])
        finally:
            seen.append(-idx)
    return seen
print(compute(6))
''',
    'unexecuted-raise-suffix': '''
def check(condition):
    try:
        if condition:
            raise ValueError('expected')
            unused = [str(x) for x in range(3)]
            return unused
        return 12
    except ValueError:
        return 30
print(check(False), check(True))
''',
    'function-default-and-generator': '''
def helper(x): return x + 1
def make(offset):
    name = 'a'
    def lookup(entry=helper(offset)):
        return name, entry
    return lookup
def value(n):
    final = helper(n)
    return final
fn = make(10)
print(list(value(x) for x in range(4)), fn())
''',
    'rewritten-input-windows': '''
def add(a): return a+1
def check(item):
    total = add(item)
    total += add(item)
    if total == 12: return total, item
    result = ['A, B'.lower().split(','), item]
    result[1] = total
    return result
print(check(5), check(6))
''',
}
for name, source in scripts.items():
    catalog['cases'].append(dict(id=name, source=source.strip()+'\n'))
for source in sorted((repo/'benchmarks/scripts').glob('*.py')):
    catalog['cases'].append(dict(id=source.stem, source=source.read_text(encoding='utf-8')))
path = lab/'tape-catalog.json'
path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
reference = match/'candidate/Lokad.Lython.dll'
candidate = lab/'candidate/Lokad.Lython.dll'
roles = {'reference': reference, 'candidate': candidate}
assert sha(reference) == read(match/'comparison/quiet/identity.json')['imageFiles']['candidate']['Lokad.Lython.dll']
assert sha(reference) != sha(candidate)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet,'build',lab/'tape/Tape.csproj','-c','Release','-o',lab/'tape-output'],
               env=env,cwd=repo,check=True,timeout=40)
summary = {}
for role, core in roles.items():
    output = lab/f'tape-{role}'
    output.mkdir(exist_ok=True)
    for path in (lab/'tape-output').glob('Tape.*'):
        shutil.copyfile(path,output/path.name)
    shutil.copyfile(core,output/core.name)
    result = lab/f'tape-{role}.json'
    subprocess.run([dotnet,output/'Tape.dll',lab/'tape-catalog.json',result],env=env,check=True,timeout=40)
    summary[role]=read(result)
    assert summary[role]['coreSHA256']==sha(core)

a,b = (summary[role]['rows'] for role in roles)
for old,new in zip(a,b,strict=True):
    for i,(prior,after) in enumerate(zip(old['objects'],new['objects'],strict=True)):
        for name in prior:
            if prior[name] != after[name]:
                raise AssertionError((old['id'],i,prior['Name'],name,
                    next(((j,x,y) for j,(x,y) in enumerate(zip(prior[name],after[name])) if x!=y),None)
                    if isinstance(prior[name],list) and isinstance(after[name],list) else (prior[name],after[name])))
    assert old==new,(old['id'],old['retainedAdmission'],new['retainedAdmission'])
count=sum(len(row['objects']) for row in a)
instruction_count=sum(len(code['Instructions']) for row in a for code in row['objects'])
print(f'{len(a)} complete sources, {count} code objects, {instruction_count} instructions, identical spans and storage shape')
