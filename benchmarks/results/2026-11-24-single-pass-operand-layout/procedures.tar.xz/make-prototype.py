from pathlib import Path
import textwrap

source = Path('src/Lokad.Lython/Frontend/ExecutableStackLayout.cs')
contents = source.read_text(encoding='utf-8')
start = contents.index('            var instructions = blocks[blockIndex];')
end = contents.index('        } while (pending is not null', start)
old = contents[start:end]
shape = old[old.index('                var (pop, push, minimum)'):old.index('            // An unterminated executable block')]
shape = shape[:shape.rindex('            }\n')]
shape = shape.replace('instructions[instructionIndex] = prepared;', 'instructions[kept++] = prepared;')
shape = shape.replace('                maximum = Math.Max(maximum, depth);\n', '')
shape = shape.replace('goto CompleteBlock;', 'shaping = false;\n                        break;')
shape = shape.replace('                // Prepare the owned instruction array in this existing shape\n'
                      '                // pass; linearization preserves these facts while retargeting.\n','')
forward_start = contents.index('    // Forward adjacent pure leaf inputs')
forward_end = contents.index('    // A private lexical local remains', forward_start)
forward = contents[forward_start:forward_end]
body = forward[forward.index('            // Site facts'):forward.index('            instructions[kept++] = instruction;')]
body = body.replace('            for (var input = count - 1;', '            var beforeForwarding = kept;\n            for (var input = count - 1;')
body = body.replace('new(block, kept,','new(blockIndex, kept,')
body = textwrap.indent(textwrap.dedent(body), ' ' * 16)
replacement = '''            var instructions = blocks[blockIndex];
            positions[blockIndex].Offset = reads.Count;
            var kept = 0;
            var shaping = true;
            for (var index = 0; index < instructions.Count; index++)
            {
                PythonTokenization.CheckCancellation(token, index);
                var instruction = instructions[index];
''' + body + '''
                // Keep the unexecuted suffix as emitted, such as the structural
                // jump after an assertion failure. It contributes no live slots.
                if (!shaping)
                {
                    instructions[kept++] = instruction;
                    continue;
                }

                // Every removed leaf pushed one provisional operand. A run of
                // leaves monotonically increases depth, so record its peak only
                // after the next consumer has forwarded everything it can.
                depth -= beforeForwarding - kept;
                if (instruction.OpCode is ExecutableOpCode.LoadConst or ExecutableOpCode.LoadGlobal or
                    ExecutableOpCode.LoadClosure or ExecutableOpCode.LoadLocal)
                {
                    var slot = checked(firstTemporarySlot + depth++);
                    instructions[kept++] = instruction.WithStorageSlots(slot, slot, checked(slot + 1));
                    continue;
                }
                maximum = Math.Max(maximum, depth);
''' + shape + '''            }
            maximum = Math.Max(maximum, depth);
            if (kept != instructions.Count)
                instructions.RemoveRange(kept, instructions.Count - kept);
'''
assert 'ForwardBlock' not in replacement and 'goto CompleteBlock' not in replacement
result = contents[:start] + replacement + contents[end:forward_start] + contents[forward_end:]
source.write_text(result, encoding='utf-8', newline='\n')
