from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/'comparison/quiet'
out = lab.parents[3]/'benchmarks/results/2026-11-24-single-pass-operand-layout'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(quiet/'identity.json')
assert identity['sourcePatchSHA256']==sha(lab/'candidate.patch')
for role, files in identity['imageFiles'].items():
    assert {path.name:sha(path) for path in (lab/role).iterdir()} == files
    for suffix in ('compiler-owner','tape'):
        result = read(lab/f'{suffix}-{role}.json' if suffix=='tape' else lab/f'{role}-{suffix}.json')
        assert result['coreSHA256']==files['Lokad.Lython.dll']
assert read(lab/'tape-reference.json')['rows']==read(lab/'tape-candidate.json')['rows']
for name in ('compile-allocation-summary.json','allocation-summary.json'):
    shutil.copyfile(lab/name,out/name)
shutil.copyfile(quiet/'identity.json',out/'identity.json')

logs = [f'{system}-{lane}.log' for system in ('windows','ubuntu') for lane in ('white','public','net10')]
assert all('Passed!' in (lab/name).read_text(encoding='utf-8-sig') for name in logs)
files = ['candidate.patch','make-prototype.py','prepare.py','prepare.log','frozen-build.log','adapt-collection.py',
         'quiet.py','archive.py','allocations.py','compile-allocation.py','package-evidence.py',
         'initial-windows-white.log','initial-ubuntu-public.log','initial-tape.log','tape.log',
         'tape/Tape.csproj','tape/Program.cs','check-tape.py','tape-catalog.json','tape-reference.json','tape-candidate.json',
         'verify-boundaries.py','verify-boundaries.log','boundary-catalog.json',
         'reference-boundary-verification.json','candidate-boundary-verification.json',
         'reference-compiler-owner.json','candidate-compiler-owner.json','reference-allocation.json','candidate-allocation.json',
         'comparison/reference-verify.json','comparison/candidate-verify.json',
         'comparison/quiet/storage-custody.json','comparison/quiet/launch.log'] + logs
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in files:
        bundle.add(lab/name,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==sha(lab/name) for name in files)
