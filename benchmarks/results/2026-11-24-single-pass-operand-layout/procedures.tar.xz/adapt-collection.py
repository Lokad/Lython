from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
old = lab.with_name('shared-function-definition-descriptor-20261124')
match = lab.with_name('shared-match-bindings-20261124')
receipt = json.loads((match/'comparison/quiet/terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete']
quiet = (old/'quiet.py').read_text(encoding='utf-8')
quiet = quiet.replace('b1647', 'b1651').replace('shared-function-definition-descriptor', 'single-pass-operand-layout')
quiet = quiet.replace('a8edbf7d71eb5e7b3536469dde376f927415170b3b76ebc1de9ad619d2a3060e', receipt['archiveSHA256'])
archive = (old/'archive.py').read_text(encoding='utf-8')
archive = archive.replace('2026-11-24-shared-function-definition-descriptor', '2026-11-24-single-pass-operand-layout')
for name, source in (('quiet.py', quiet), ('archive.py', archive)):
    compile(source, name, 'exec')
    (lab/name).write_text(source, encoding='utf-8', newline='\n')
for name in ('allocations.py', 'compile-allocation.py'):
    shutil.copyfile(match/name, lab/name)
(lab/'verified-raw-replicas.json').write_text('[]\n', encoding='utf-8', newline='\n')
