; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 42
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       xor      eax, eax
       mov      qword ptr [rbp-0xBB8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0xB70
 
G_M000_IG253:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG253
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x664], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG234
 
G_M000_IG03:                ;; offset=0x009C
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x670], rax
       mov      rdx, gword ptr [rbp-0x670]
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0118
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0134
       jmp      G_M000_IG220
 
G_M000_IG07:                ;; offset=0x0139
       mov      rcx, 0x7FF9D77EA970
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG08:                ;; offset=0x0157
       mov      rcx, 0x7FF9D77EA974
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x678], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x678]
       mov      rdx, gword ptr [rbp-0x5F0]
       mov      r8d, dword ptr [rbp-0x5F4]
       mov      rcx, gword ptr [rbp-0x5E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x680], rax
       mov      r9, gword ptr [rbp-0x680]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG09:                ;; offset=0x01F4
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0244
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x640], rax
       mov      rcx, gword ptr [rbp-0x640]
       mov      rdx, 0x7FF9D77EA978
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x688], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x68C], eax
       mov      rcx, gword ptr [rbp-0x688]
       mov      edx, dword ptr [rbp-0x68C]
       mov      r11, 0x7FF9D7091A40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x208], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x698], rax
       mov      rdx, gword ptr [rbp-0x698]
       mov      rcx, gword ptr [rbp-0x208]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EB
       mov      rcx, 0x7FF9D77EAA80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG12:                ;; offset=0x02FF
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5D4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x69C], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x69C]
       mov      rdx, gword ptr [rbp-0x5D0]
       mov      r8d, dword ptr [rbp-0x5D4]
       mov      rcx, gword ptr [rbp-0x5C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77EAA84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E0], rax
       mov      rax, bword ptr [rbp-0x5E0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG224
 
G_M000_IG13:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D77EAA88
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03D0
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A8], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6A8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77EAA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG15:                ;; offset=0x0438
       mov      rcx, 0x7FF9D77EAA90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG16:                ;; offset=0x0462
       mov      rcx, 0x7FF9D77EAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG17:                ;; offset=0x048C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77EAA98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG18:                ;; offset=0x04C0
       mov      rcx, 0x7FF9D77EAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG19:                ;; offset=0x04D4
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG20:                ;; offset=0x04EA
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F6
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6C8], ymm0
 
G_M000_IG22:                ;; offset=0x0502
       lea      r8, [rbp-0x6C8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG23:                ;; offset=0x0545
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0549
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6E8], ymm0
 
G_M000_IG25:                ;; offset=0x0555
       lea      r8, [rbp-0x6E8]
       lea      rdx, [rbp-0x580]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0575
       vmovdqu  xmm0, xmmword ptr [rbp-0x580]
       vmovdqu  xmmword ptr [rbp-0x6F8], xmm0
 
G_M000_IG27:                ;; offset=0x0585
       lea      rdx, [rbp-0x6F8]
       lea      rcx, [rbp-0x590]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB30], rax
       mov      rcx, bword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp-0x590]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB30]
       mov      rcx, qword ptr [rbp-0x588]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77EAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x700], rax
       mov      rcx, gword ptr [rbp-0x700]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG28:                ;; offset=0x0613
       mov      rcx, 0x7FF9D77EAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG29:                ;; offset=0x0631
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2D0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2E0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2E8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77EAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG30:                ;; offset=0x067E
       mov      rcx, bword ptr [rbp-0x2D0]
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      r8, bword ptr [rbp-0x2E0]
       mov      r9, gword ptr [rbp-0x2E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77EAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG31:                ;; offset=0x06C9
       mov      rcx, 0x7FF9D77EAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG32:                ;; offset=0x06DD
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77EAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F8
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x720], ymm0
 
G_M000_IG34:                ;; offset=0x0704
       lea      r8, [rbp-0x720]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG35:                ;; offset=0x0747
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074B
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x740], ymm0
 
G_M000_IG37:                ;; offset=0x0757
       lea      r8, [rbp-0x740]
       lea      rdx, [rbp-0x2F8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0777
       vmovdqu  xmm0, xmmword ptr [rbp-0x2F8]
       vmovdqu  xmmword ptr [rbp-0x750], xmm0
 
G_M000_IG39:                ;; offset=0x0787
       lea      rdx, [rbp-0x750]
       lea      rcx, [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x308]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x300]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77EAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x758], rax
       mov      rcx, gword ptr [rbp-0x758]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG40:                ;; offset=0x0815
       mov      rcx, 0x7FF9D77EAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG41:                ;; offset=0x0833
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x760], rax
       mov      rdx, gword ptr [rbp-0x760]
       mov      rcx, 0x7FF9D758EAB0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x264], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x268], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x268]
       sub      ecx, eax
       mov      dword ptr [rbp-0x764], ecx
       mov      r9d, dword ptr [rbp-0x764]
       lea      rcx, [rbp-0x278]
       mov      rdx, gword ptr [rbp-0x260]
       mov      r8d, dword ptr [rbp-0x264]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x280], rax
 
G_M000_IG42:                ;; offset=0x0915
       vmovdqu  xmm0, xmmword ptr [rbp-0x278]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG43:                ;; offset=0x0925
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x294], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2A0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77EAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2A0], rax
 
G_M000_IG44:                ;; offset=0x0961
       mov      rcx, 0x7FF9D77EAAC4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x0970
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x778], xmm0
 
G_M000_IG46:                ;; offset=0x0980
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x780], rax
       mov      rax, gword ptr [rbp-0x780]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x778]
       mov      r8d, dword ptr [rbp-0x294]
       mov      r9, gword ptr [rbp-0x2A0]
       mov      rcx, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x784], eax
       mov      edx, dword ptr [rbp-0x784]
       mov      rcx, bword ptr [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG224
 
G_M000_IG47:                ;; offset=0x09FC
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x210], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x214], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x788], eax
       mov      r9d, dword ptr [rbp-0x788]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x214]
       mov      rcx, bword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x790], rax
       mov      rdx, gword ptr [rbp-0x790]
       lea      rcx, [rbp-0x228]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x230], rax
 
G_M000_IG48:                ;; offset=0x0A8A
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG49:                ;; offset=0x0A97
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x248], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77EAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x248], rax
 
G_M000_IG50:                ;; offset=0x0AC3
       mov      rcx, 0x7FF9D77EAACC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD2
       vmovdqu  xmm0, xmmword ptr [rbp-0x228]
       vmovdqu  xmmword ptr [rbp-0x7A0], xmm0
 
G_M000_IG52:                ;; offset=0x0AE2
       vmovdqu  xmm0, xmmword ptr [rbp-0x240]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG53:                ;; offset=0x0AF2
       mov      rcx, gword ptr [rbp-0x248]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7B8], rax
       mov      r9, gword ptr [rbp-0x7B8]
       lea      r8, [rbp-0x7B0]
       lea      rcx, [rbp-0x7A0]
       mov      rdx, bword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG224
 
G_M000_IG54:                ;; offset=0x0B2F
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77EAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG55:                ;; offset=0x0B78
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77EAAD4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG56:                ;; offset=0x0BB2
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7C8], xmm0
 
G_M000_IG57:                ;; offset=0x0BBF
       lea      rdx, [rbp-0x7C8]
       lea      rcx, [rbp-0x5A0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x5A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x598]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77EAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7D0], rax
       mov      rcx, gword ptr [rbp-0x7D0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG58:                ;; offset=0x0C4D
       mov      rcx, 0x7FF9D77EAADC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG59:                ;; offset=0x0C6B
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77EAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG60:                ;; offset=0x0C90
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x35C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7D4], eax
       mov      r9d, dword ptr [rbp-0x7D4]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x35C]
       mov      rcx, bword ptr [rbp-0x358]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77EAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x360], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7F
       mov      rcx, 0x7FF9D77EAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D90
       mov      rcx, 0x7FF9D77EAAEC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9F
       xor      eax, eax
       mov      dword ptr [rbp-0x360], eax
 
G_M000_IG64:                ;; offset=0x0DA7
       movzx    rax, byte  ptr [rbp-0x360]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCF
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7E8], xmm0
 
G_M000_IG66:                ;; offset=0x0DDF
       lea      r8, [rbp-0x7E8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F0], rax
       mov      rdx, gword ptr [rbp-0x7F0]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x370], rax
       mov      rax, gword ptr [rbp-0x370]
       mov      gword ptr [rbp-0x378], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E95
       mov      rcx, 0x7FF9D77EAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA9
       mov      rcx, 0x7FF9D77EAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBD
       mov      rcx, 0x7FF9D77EAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x388], rax
 
G_M000_IG70:                ;; offset=0x0EF8
       mov      rcx, 0x7FF9D77EAAFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x380]
       mov      rdx, gword ptr [rbp-0x388]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7F4], eax
       mov      edx, dword ptr [rbp-0x7F4]
       mov      rcx, bword ptr [rbp-0x390]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x398], rax
       mov      rax, bword ptr [rbp-0x398]
       add      dword ptr [rax], 2
       jmp      G_M000_IG234
 
G_M000_IG71:                ;; offset=0x0F96
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x808], xmm0
 
G_M000_IG72:                ;; offset=0x0FA6
       lea      rdx, [rbp-0x808]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x368], rax
       mov      rax, bword ptr [rbp-0x368]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77EAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG73:                ;; offset=0x1031
       mov      rcx, 0x7FF9D77EAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1042
       mov      rcx, 0x7FF9D77EAB08
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1051
       mov      rcx, 0x7FF9D77EAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG76:                ;; offset=0x106F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77EAB10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG77:                ;; offset=0x1094
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A4
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x828], ymm0
 
G_M000_IG79:                ;; offset=0x10B0
       lea      r8, [rbp-0x828]
       lea      rdx, [rbp-0x350]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x350]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x348]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77EAB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x830], rax
       mov      rcx, gword ptr [rbp-0x830]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG80:                ;; offset=0x1144
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1153
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77EAB18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x320], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x834], eax
       mov      r8d, dword ptr [rbp-0x834]
       mov      edx, dword ptr [rbp-0x324]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x330], rax
       mov      rcx, gword ptr [rbp-0x330]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     [CORINFO_HELP_ARRADDR_ST]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x840], rax
       mov      rdx, gword ptr [rbp-0x840]
       mov      rcx, gword ptr [rbp-0x330]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x338], rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x848], rax
       mov      r9, gword ptr [rbp-0x848]
       mov      rdx, gword ptr [rbp-0x338]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x340]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1282
       mov      rcx, 0x7FF9D77EAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x318]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B8
       vmovdqu  xmm0, xmmword ptr [rbp-0x318]
       vmovdqu  xmmword ptr [rbp-0x858], xmm0
 
G_M000_IG84:                ;; offset=0x12C8
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12CC
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x878], ymm0
 
G_M000_IG86:                ;; offset=0x12D8
       lea      rdx, [rbp-0x858]
       lea      r8, [rbp-0x878]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12F2
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77EAB20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG88:                ;; offset=0x1346
       mov      rcx, 0x7FF9D77EAB24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1357
       mov      rcx, 0x7FF9D77EAB28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG90:                ;; offset=0x136B
       mov      rcx, 0x7FF9D77EAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG91:                ;; offset=0x1389
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77EAB30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG92:                ;; offset=0x13AE
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77EAB38
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x880], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x884], eax
       mov      rcx, gword ptr [rbp-0x880]
       mov      edx, dword ptr [rbp-0x884]
       mov      r11, 0x7FF9D7091A50
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77EAC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG224
 
G_M000_IG93:                ;; offset=0x1463
       lea      rcx, [rbp-0x618]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x147B
       vmovdqu  xmm0, xmmword ptr [rbp-0x618]
       vmovdqu  xmmword ptr [rbp-0x898], xmm0
 
G_M000_IG95:                ;; offset=0x148B
       lea      rdx, [rbp-0x898]
       lea      rcx, [rbp-0x628]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x628]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x620]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77EAC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A0], rax
       mov      rcx, gword ptr [rbp-0x8A0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG96:                ;; offset=0x1519
       mov      rcx, 0x7FF9D77EAC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG97:                ;; offset=0x1537
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77EAC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG98:                ;; offset=0x1576
       mov      rcx, 0x7FF9D77EAC50
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG99:                ;; offset=0x158A
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77EAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG100:                ;; offset=0x15BC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15C0
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8C0], ymm0
 
G_M000_IG102:                ;; offset=0x15CC
       lea      r8, [rbp-0x8C0]
       lea      rdx, [rbp-0x570]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77EAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8C8], rax
       mov      rcx, gword ptr [rbp-0x8C8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG103:                ;; offset=0x1660
       mov      rcx, 0x7FF9D77EAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG104:                ;; offset=0x167E
       mov      rcx, 0x7FF9D77EAC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x600], rax
       mov      rax, gword ptr [rbp-0x600]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8D0], rax
       mov      r9, gword ptr [rbp-0x8D0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG105:                ;; offset=0x1700
       mov      rcx, 0x7FF9D77EAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5BC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D8], rax
       mov      r8, gword ptr [rbp-0x8D8]
       mov      edx, dword ptr [rbp-0x5BC]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r9, gword ptr [rbp-0x8E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG106:                ;; offset=0x1781
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77EAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG107:                ;; offset=0x17A6
       mov      rcx, 0x7FF9D77EAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E8], rax
       mov      rdx, gword ptr [rbp-0x8E8]
       mov      rcx, gword ptr [rbp-0x5B0]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG108:                ;; offset=0x1844
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77EAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG109:                ;; offset=0x1869
       mov      rcx, 0x7FF9D77EAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F8], rax
       mov      rdx, gword ptr [rbp-0x8F8]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG110:                ;; offset=0x189F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77EAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG111:                ;; offset=0x18C4
       mov      rcx, 0x7FF9D77EAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x540]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x548], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x550], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8FC], eax
       mov      r8d, dword ptr [rbp-0x8FC]
       mov      edx, dword ptr [rbp-0x554]
       mov      rcx, bword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x908], rax
       mov      r9, gword ptr [rbp-0x908]
       mov      rdx, gword ptr [rbp-0x560]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x548]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG112:                ;; offset=0x199F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77EAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG113:                ;; offset=0x19C4
       mov      rcx, 0x7FF9D77EAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x508], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x518], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x518]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x520], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x528], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x52C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x90C], eax
       mov      r8d, dword ptr [rbp-0x90C]
       mov      edx, dword ptr [rbp-0x52C]
       mov      rcx, bword ptr [rbp-0x528]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x538], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x918], rax
       mov      rax, gword ptr [rbp-0x918]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      r8, gword ptr [rbp-0x520]
       mov      r9, gword ptr [rbp-0x538]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG114:                ;; offset=0x1AD4
       mov      rcx, 0x7FF9D77EAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x500], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x91C], eax
       mov      edx, dword ptr [rbp-0x91C]
       mov      rcx, bword ptr [rbp-0x500]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x928], rax
       mov      r9, gword ptr [rbp-0x928]
       mov      edx, dword ptr [rbp-0x4F4]
       mov      r8d, dword ptr [rbp-0x4F8]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG224
 
G_M000_IG115:                ;; offset=0x1B7F
       mov      rcx, 0x7FF9D77EAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x92C], eax
       mov      edx, dword ptr [rbp-0x92C]
       mov      rcx, bword ptr [rbp-0x4E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x930], eax
       mov      edx, dword ptr [rbp-0x930]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG224
 
G_M000_IG116:                ;; offset=0x1C03
       mov      rcx, 0x7FF9D77EAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4D4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x938], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x938]
       mov      edx, dword ptr [rbp-0x4D4]
       mov      r8d, dword ptr [rbp-0x4D8]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x940], rax
       mov      r9, gword ptr [rbp-0x940]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG117:                ;; offset=0x1CA7
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77EAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG118:                ;; offset=0x1CE0
       mov      rcx, 0x7FF9D77EAC98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CEF
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77EAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D2A
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x950], xmm0
 
G_M000_IG121:                ;; offset=0x1D36
       lea      r9, [rbp-0x950]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG238
 
G_M000_IG122:                ;; offset=0x1D5E
       mov      rcx, 0x7FF9D77EACA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6D
       mov      rcx, 0x7FF9D77EACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x958], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x958]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x960], rax
       mov      r9, gword ptr [rbp-0x960]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG124:                ;; offset=0x1E11
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77EACA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG125:                ;; offset=0x1E36
       mov      rcx, 0x7FF9D77EACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG126:                ;; offset=0x1E5D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77EACB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG127:                ;; offset=0x1E82
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77EACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG128:                ;; offset=0x1EB1
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x980], ymm0
 
G_M000_IG130:                ;; offset=0x1EC1
       lea      r8, [rbp-0x980]
       lea      rdx, [rbp-0x4B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x4B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x4B0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77EACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x988], rax
       mov      rcx, gword ptr [rbp-0x988]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG131:                ;; offset=0x1F55
       mov      rcx, 0x7FF9D77EACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG132:                ;; offset=0x1F76
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77EACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG133:                ;; offset=0x1FD5
       mov      rcx, 0x7FF9D77EACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG134:                ;; offset=0x1FF6
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77EACC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG135:                ;; offset=0x2024
       mov      rcx, 0x7FF9D77EACCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2035
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2053
       mov      rcx, 0x7FF9D77EACD0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2062
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77EACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG139:                ;; offset=0x20CA
       mov      rcx, 0x7FF9D77EACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG140:                ;; offset=0x20DE
       mov      rcx, 0x7FF9D77EACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG141:                ;; offset=0x20F2
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77EACE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG142:                ;; offset=0x2127
       mov      rcx, 0x7FF9D77EACE4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x213B
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2AC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2AC]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x990], rax
       mov      rdx, gword ptr [rbp-0x990]
       mov      rcx, 0x7FF9D77E5D30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2249
       lea      rdx, [rbp-0x2C8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x2C8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x2C0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77EACE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rcx, gword ptr [rbp-0x998]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG145:                ;; offset=0x22E8
       mov      rcx, 0x7FF9D77EACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F9
       mov      rcx, 0x7FF9D77EACF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x230A
       mov      rcx, 0x7FF9D77EACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x231B
       mov      rcx, 0x7FF9D77EACF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x232C
       mov      rcx, 0x7FF9D77EACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x233D
       mov      rcx, 0x7FF9D77EAD00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG151:                ;; offset=0x235E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x458], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x99C], eax
       mov      edx, dword ptr [rbp-0x99C]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x458]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77EAD04
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C6
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9B0], xmm0
 
G_M000_IG153:                ;; offset=0x23D6
       lea      r9, [rbp-0x9B0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG154:                ;; offset=0x23F4
       mov      rcx, 0x7FF9D77EAD08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x470], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9B4], eax
       mov      edx, dword ptr [rbp-0x9B4]
       mov      rcx, bword ptr [rbp-0x470]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG155:                ;; offset=0x2458
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77EAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG156:                ;; offset=0x247D
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77EAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG157:                ;; offset=0x24AC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24B0
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9D8], ymm0
 
G_M000_IG159:                ;; offset=0x24BC
       lea      r8, [rbp-0x9D8]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x468]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x460]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77EAD14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E0], rax
       mov      rcx, gword ptr [rbp-0x9E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG160:                ;; offset=0x2550
       mov      rcx, 0x7FF9D77EAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG161:                ;; offset=0x2571
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77EAD20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x9E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9EC], eax
       mov      rcx, gword ptr [rbp-0x9E8]
       mov      edx, dword ptr [rbp-0x9EC]
       mov      r11, 0x7FF9D7091A48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG169
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0xC4]
       jne      G_M000_IG164
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x440], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x9F8], rax
       mov      rdx, gword ptr [rbp-0x9F8]
       lea      rcx, [rbp-0x450]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG162:                ;; offset=0x2669
       vmovdqu  xmm0, xmmword ptr [rbp-0x450]
       vmovdqu  xmmword ptr [rbp-0xA08], xmm0
 
G_M000_IG163:                ;; offset=0x2679
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x150]
       mov      qword ptr [rsp+0x30], rax
       lea      rdx, [rbp-0xA08]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x440]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedCall(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG168
       lea      rcx, [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77EAE28
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA10], rax
       mov      rdx, gword ptr [rbp-0xA10]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x158], rax
       cmp      gword ptr [rbp-0x158], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77EAF30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG164:                ;; offset=0x2744
       mov      rcx, 0x7FF9D77EAF34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG169
 
G_M000_IG165:                ;; offset=0x2755
       mov      rcx, 0x7FF9D77EAF38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x2764
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG167:                ;; offset=0x2774
       lea      r9, [rbp-0xA20]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG168:                ;; offset=0x2792
       mov      rcx, 0x7FF9D77EAF3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xC4]
       lea      edx, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG169:                ;; offset=0x27BE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3E8], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA24], eax
       mov      edx, dword ptr [rbp-0xA24]
       mov      rcx, bword ptr [rbp-0x3E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG172
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG170
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77EAF40
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA30], rax
       mov      rdx, gword ptr [rbp-0xA30]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x160], rax
       cmp      gword ptr [rbp-0x160], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG170:                ;; offset=0x28BF
       mov      rcx, 0x7FF9D77EB048
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG171:                ;; offset=0x28D3
       mov      rcx, 0x7FF9D77EB04C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       vmovdqu  xmmword ptr [rbp-0x430], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76A9D18
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0xA38], rax
       mov      r8, gword ptr [rbp-0xA38]
       lea      rcx, [rbp-0x438]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rax, bword ptr [rbp-0xB78]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x438]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG172:                ;; offset=0x298D
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG175
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x168]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77EB050
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG173:                ;; offset=0x29EE
       cmp      gword ptr [rbp-0x168], 0
       je       G_M000_IG174
       mov      rcx, 0x7FF9D77EB054
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x420], xmm0
       vmovdqu  xmmword ptr [rbp-0x418], xmm0
       lea      rcx, [rbp-0x420]
       mov      r8, gword ptr [rbp-0x168]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x420]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG174:                ;; offset=0x2A98
       mov      rcx, 0x7FF9D77EB058
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG175:                ;; offset=0x2AAC
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG179
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG177
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x2B18
       mov      rcx, 0x7FF9D77EB05C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG177:                ;; offset=0x2B27
       mov      rcx, 0x7FF9D77EB060
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG178:                ;; offset=0x2B60
       mov      rcx, 0x7FF9D77EB064
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG179:                ;; offset=0x2B8C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77EB068
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG180:                ;; offset=0x2BFC
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x3F8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG181:                ;; offset=0x2C31
       vmovdqu  xmm0, xmmword ptr [rbp-0x3F8]
       vmovdqu  xmmword ptr [rbp-0xA48], xmm0
 
G_M000_IG182:                ;; offset=0x2C41
       lea      rdx, [rbp-0xA48]
       lea      rcx, [rbp-0x408]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rdx, gword ptr [rbp-0x408]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB88]
       mov      rcx, qword ptr [rbp-0x400]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG183
       mov      rcx, 0x7FF9D77EB06C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA50], rax
       mov      rcx, gword ptr [rbp-0xA50]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG183:                ;; offset=0x2CCF
       mov      rcx, 0x7FF9D77EB070
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG184:                ;; offset=0x2CED
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA54], eax
       mov      edx, dword ptr [rbp-0xA54]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x484], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x488], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA60], rax
       mov      rax, gword ptr [rbp-0xA60]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      r8d, dword ptr [rbp-0x484]
       mov      r9d, dword ptr [rbp-0x488]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG186
       mov      rcx, 0x7FF9D77EB074
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG185:                ;; offset=0x2DB8
       mov      rcx, 0x7FF9D77EB078
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG186:                ;; offset=0x2DCC
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77EB07C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG187:                ;; offset=0x2DF8
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG188:                ;; offset=0x2DFC
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA80], ymm0
 
G_M000_IG189:                ;; offset=0x2E08
       lea      r8, [rbp-0xA80]
       lea      rdx, [rbp-0x498]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG190:                ;; offset=0x2E22
       vmovdqu  xmm0, xmmword ptr [rbp-0x498]
       vmovdqu  xmmword ptr [rbp-0xA90], xmm0
 
G_M000_IG191:                ;; offset=0x2E32
       lea      rdx, [rbp-0xA90]
       lea      rcx, [rbp-0x4A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x4A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x4A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG192
       mov      rcx, 0x7FF9D77EB080
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA98], rax
       mov      rcx, gword ptr [rbp-0xA98]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG192:                ;; offset=0x2EC0
       mov      rcx, 0x7FF9D77EB084
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG193:                ;; offset=0x2EDE
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG194
       mov      rcx, 0x7FF9D77EB088
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG194:                ;; offset=0x2F03
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77EB08C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG195:                ;; offset=0x2F2F
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG196:                ;; offset=0x2F33
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAB8], ymm0
 
G_M000_IG197:                ;; offset=0x2F3F
       lea      r8, [rbp-0xAB8]
       lea      rdx, [rbp-0x3C8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG198:                ;; offset=0x2F59
       vmovdqu  xmm0, xmmword ptr [rbp-0x3C8]
       vmovdqu  xmmword ptr [rbp-0xAC8], xmm0
 
G_M000_IG199:                ;; offset=0x2F69
       lea      rdx, [rbp-0xAC8]
       lea      rcx, [rbp-0x3D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x3D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x3D0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG200
       mov      rcx, 0x7FF9D77EB090
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD0], rax
       mov      rcx, gword ptr [rbp-0xAD0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG200:                ;; offset=0x2FF7
       mov      rcx, 0x7FF9D77EB094
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG201:                ;; offset=0x3015
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG202
       mov      rcx, 0x7FF9D77EB098
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG202:                ;; offset=0x303A
       mov      rcx, 0x7FF9D77EB09C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG203:                ;; offset=0x305E
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xAD4], eax
       mov      edx, dword ptr [rbp-0xAD4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG205
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77EB0A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG204:                ;; offset=0x30C2
       mov      rcx, 0x7FF9D77EB0A4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG205:                ;; offset=0x30D1
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG207
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77E9A80
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x30F5
       mov      rcx, 0x7FF9D77EB0A8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG207:                ;; offset=0x3104
       mov      rcx, 0x7FF9D77EB0AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG208:                ;; offset=0x3131
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG209:                ;; offset=0x3135
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAF8], ymm0
 
G_M000_IG210:                ;; offset=0x3141
       lea      r8, [rbp-0xAF8]
       lea      rdx, [rbp-0x3A8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG211
       mov      rcx, 0x7FF9D77EB0B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB00], rax
       mov      rcx, gword ptr [rbp-0xB00]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG211:                ;; offset=0x31D5
       mov      rcx, 0x7FF9D77EB0B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG212:                ;; offset=0x31F6
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG216
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 49
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x16C], 57
       je       SHORT G_M000_IG214
       cmp      dword ptr [rbp-0x16C], 58
       je       SHORT G_M000_IG213
       mov      rcx, 0x7FF9D77EB0B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG213:                ;; offset=0x3246
       mov      rcx, 0x7FF9D77EB0BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG214:                ;; offset=0x3257
       mov      rcx, 0x7FF9D77EB0C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x3268
       mov      rcx, 0x7FF9D77EB0C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG216:                ;; offset=0x3277
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG218
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG219
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG217
       mov      rcx, 0x7FF9D77EB0C8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3B8], xmm0
       lea      rcx, [rbp-0x3B8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3B0]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG238
 
G_M000_IG217:                ;; offset=0x333A
       mov      rcx, 0x7FF9D77EB0CC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x334B
       mov      rcx, 0x7FF9D77EB0D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG219:                ;; offset=0x335F
       mov      rcx, 0x7FF9D77EB0D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG220:                ;; offset=0x337D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1D0], ymm0
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
       lea      rcx, [rbp-0x1D0]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG221:                ;; offset=0x33A9
       vmovdqu  ymm0, ymmword ptr [rbp-0x1D0]
       vmovdqu  ymmword ptr [rbp-0x198], ymm0
       mov      rax, qword ptr [rbp-0x1B0]
       mov      qword ptr [rbp-0x178], rax
 
G_M000_IG222:                ;; offset=0x33C7
       lea      rcx, [rbp-0x198]
       mov      rdx, 0x23AEEE12A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB04], eax
       mov      edx, dword ptr [rbp-0xB04]
       lea      rcx, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1D8], rax
       lea      rcx, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB10], rax
       mov      rdx, gword ptr [rbp-0xB10]
       mov      rcx, gword ptr [rbp-0x1D8]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1D8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x344C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG224:                ;; offset=0x3452
       mov      eax, dword ptr [rbp-0x664]
       dec      eax
       mov      dword ptr [rbp-0x664], eax
       cmp      dword ptr [rbp-0x664], 0
       jg       SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x3469
       lea      rcx, [rbp-0x664]
       mov      edx, 0xFF1
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG226:                ;; offset=0x347C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG229
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG228
       mov      rcx, 0x7FF9D77EB0E4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1F8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x1F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x1F0]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG227:                ;; offset=0x34F4
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG228:                ;; offset=0x3500
       mov      rcx, 0x7FF9D77EB0E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG229:                ;; offset=0x350F
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG230
       mov      rcx, 0x7FF9D77EB0EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, bword ptr [rbp-0x1E8]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG234
 
G_M000_IG230:                ;; offset=0x3544
       mov      rcx, 0x7FF9D77EB0F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG234
 
G_M000_IG231:                ;; offset=0x3555
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x3583
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG233:                ;; offset=0x358D
       mov      rcx, 0x7FF9D77EB0F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG234:                ;; offset=0x35A8
       mov      eax, dword ptr [rbp-0x664]
       dec      eax
       mov      dword ptr [rbp-0x664], eax
       cmp      dword ptr [rbp-0x664], 0
       jg       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x35BF
       lea      rcx, [rbp-0x664]
       mov      edx, 0x1036
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG236:                ;; offset=0x35D2
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77EB0F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG237:                ;; offset=0x35FA
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG238:                ;; offset=0x3606
       mov      rcx, 0x7FF9D77EB0FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG239:                ;; offset=0x361B
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG240:                ;; offset=0x3627
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG241:                ;; offset=0x362D
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x3631
       mov      gword ptr [rbp-0x638], rcx
       mov      rax, gword ptr [rbp-0x638]
       mov      gword ptr [rbp-0x1A0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x364D
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x3653
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      r8, gword ptr [rbp-0xB18]
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG246
       mov      rcx, 0x7FF9D77EB0D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG238
 
G_M000_IG245:                ;; offset=0x36A2
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG246:                ;; offset=0x36AA
       mov      rcx, 0x7FF9D77EB0DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG247:                ;; offset=0x36C7
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG248:                ;; offset=0x36CF
       sub      rsp, 72
 
G_M000_IG249:                ;; offset=0x36D3
       mov      gword ptr [rbp-0x630], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r9, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x370B
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG251:                ;; offset=0x3711
       mov      rcx, 0x7FF9D77EB0E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG252:                ;; offset=0x372E
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001336h ; case G_M000_IG91
       	dd	0000162Bh ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ADh ; case G_M000_IG105
       	dd	0000172Eh ; case G_M000_IG106
       	dd	00000ADCh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Fh ; case G_M000_IG138
       	dd	0000200Fh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E4h ; case G_M000_IG97
       	dd	000014E4h ; case G_M000_IG97
       	dd	000017F1h ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ch ; case G_M000_IG110
       	dd	0000194Ch ; case G_M000_IG112
       	dd	00001A81h ; case G_M000_IG114
       	dd	00001B2Ch ; case G_M000_IG115
       	dd	00001BB0h ; case G_M000_IG116
       	dd	00001C54h ; case G_M000_IG117
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00002C9Ah ; case G_M000_IG184
       	dd	0000230Bh ; case G_M000_IG151
       	dd	0000251Eh ; case G_M000_IG161
       	dd	00001FE2h ; case G_M000_IG136
       	dd	00002E8Bh ; case G_M000_IG193
       	dd	00002FC2h ; case G_M000_IG201
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	000031A3h ; case G_M000_IG212
       	dd	0000300Bh ; case G_M000_IG203
       	dd	00001F23h ; case G_M000_IG132
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000031A3h ; case G_M000_IG212
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C18h ; case G_M000_IG59
       	dd	0000101Ch ; case G_M000_IG76
       	dd	000031A3h ; case G_M000_IG212
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Fh ; case G_M000_IG141
       	dd	000020E8h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A9h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 14134

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x420
       lea      rbp, [rsp+0x420]
       xor      eax, eax
       mov      qword ptr [rbp-0x3D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3D0], xmm4
       mov      rax, -960
 
G_M000_IG74:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG74
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x004E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x25C], eax
       mov      edx, dword ptr [rbp-0x25C]
       mov      rcx, gword ptr [rbp-0xE8]
       mov      r11, 0x7FF9D7091C28
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG12
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x278], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x00C5
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG04:                ;; offset=0x00D2
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x38]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp-0x278]
       lea      rdx, [rbp-0x270]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x38]
       mov      r9, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedCall(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG11
       lea      rcx, [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rdx, gword ptr [rbp-0x280]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rcx, gword ptr [rbp-0x288]
       mov      r11, 0x7FF9D7091C48
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0178
       mov      rcx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG06:                ;; offset=0x0182
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x0192
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x019E
       vmovdqu  xmm0, xmmword ptr [rbp-0x38]
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG09:                ;; offset=0x01AB
       lea      r8, [rbp-0x298]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG10:                ;; offset=0x01C5
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x01D1
       mov      eax, dword ptr [rbp-0x0C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], eax
 
G_M000_IG12:                ;; offset=0x01DE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rax, bword ptr [rbp-0xF0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xF4], eax
       jae      G_M000_IG63
       mov      rax, bword ptr [rbp-0xF0]
       mov      ecx, dword ptr [rbp-0xF4]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG13:                ;; offset=0x0263
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG61
 
G_M000_IG14:                ;; offset=0x02A4
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG18
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x218], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x21C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      r9d, dword ptr [rbp-0x2A4]
       lea      rdx, [rbp-0x230]
       mov      r8d, dword ptr [rbp-0x21C]
       mov      rcx, bword ptr [rbp-0x218]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG15:                ;; offset=0x0328
       vmovdqu  xmm0, xmmword ptr [rbp-0x230]
       vmovdqu  xmmword ptr [rbp-0x2B8], xmm0
 
G_M000_IG16:                ;; offset=0x0338
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdx, gword ptr [rbp-0x2C0]
       lea      rcx, [rbp-0x2B8]
       lea      r9, [rbp-0x50]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG17
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG61
 
G_M000_IG17:                ;; offset=0x0379
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG52
 
G_M000_IG18:                ;; offset=0x038C
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG45
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76A4690
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG45
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x120], rax
       mov      rax, bword ptr [rbp-0x120]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG49
       mov      rax, bword ptr [rbp-0x120]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG30
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, 0x7FF9D75B1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, 0x7FF9D76A31D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp-0x70]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG19:                ;; offset=0x0482
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG30
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG49
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG20:                ;; offset=0x04BA
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
 
G_M000_IG21:                ;; offset=0x04C6
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x198], rax
       lea      rcx, [rbp-0xA8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      edx, dword ptr [rbp-0x2CC]
       mov      rcx, gword ptr [rbp-0x198]
       mov      r11, 0x7FF9D7091C40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xB0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rcx, gword ptr [rbp-0x70]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG22:                ;; offset=0x054A
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1A8], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rcx, gword ptr [rbp-0xB0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG24
       mov      rax, bword ptr [rbp-0x1B0]
       mov      bword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x210]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, gword ptr [rbp-0xB0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0635
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x210]
       mov      gword ptr [rbp-0x1E8], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0677
       mov      rax, bword ptr [rbp-0x1B0]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x1E8], rax
       mov      dword ptr [rbp-0x1EC], 1
 
G_M000_IG25:                ;; offset=0x06B9
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      r8, gword ptr [rbp-0x1E8]
       mov      r9d, dword ptr [rbp-0x1EC]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x2E0], rax
       mov      rdx, gword ptr [rbp-0x2E0]
       mov      rcx, bword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG26:                ;; offset=0x06F7
       call     G_M000_IG64
       nop      
 
G_M000_IG27:                ;; offset=0x06FD
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG28:                ;; offset=0x0705
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG29:                ;; offset=0x0712
       lea      r8, [rbp-0x2F0]
       lea      rdx, [rbp-0xA8]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG61
 
G_M000_IG30:                ;; offset=0x0736
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rdx, gword ptr [rbp-0x2F8]
       mov      rcx, 0x7FF9D77F3330
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x78], rax
       cmp      gword ptr [rbp-0x78], 0
       je       G_M000_IG37
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG49
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG37
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG31:                ;; offset=0x07B3
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG32:                ;; offset=0x07C0
       lea      rdx, [rbp-0x308]
       lea      rcx, [rbp-0x168]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG33:                ;; offset=0x07D4
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0x318], xmm0
 
G_M000_IG34:                ;; offset=0x07E4
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x318]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG49
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x31C], eax
       mov      edx, dword ptr [rbp-0x31C]
       mov      rcx, gword ptr [rbp-0x170]
       mov      r11, 0x7FF9D7091C38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0x178], rax
       movzx    rax, byte  ptr [rbp-0x88]
       mov      dword ptr [rbp-0x17C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0xB8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x190], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG35:                ;; offset=0x08E8
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x330], xmm0
 
G_M000_IG36:                ;; offset=0x08F8
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x330]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x178]
       mov      r8d, dword ptr [rbp-0x17C]
       mov      r9, gword ptr [rbp-0x188]
       mov      rcx, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x338], rax
       mov      rdx, gword ptr [rbp-0x338]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG52
 
G_M000_IG37:                ;; offset=0x0955
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG38:                ;; offset=0x0968
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x348], xmm0
 
G_M000_IG39:                ;; offset=0x0975
       lea      rdx, [rbp-0x348]
       lea      rcx, [rbp-0x138]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG40:                ;; offset=0x0989
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x358], xmm0
 
G_M000_IG41:                ;; offset=0x0999
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x358]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x144], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x35C], eax
       mov      r9d, dword ptr [rbp-0x35C]
       lea      rdx, [rbp-0x158]
       mov      r8d, dword ptr [rbp-0x144]
       mov      rcx, bword ptr [rbp-0x140]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG42:                ;; offset=0x0A4B
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x370], xmm0
 
G_M000_IG43:                ;; offset=0x0A5B
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x378], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x378]
       lea      r8, [rbp-0x370]
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG44
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG61
 
G_M000_IG44:                ;; offset=0x0AB1
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x0AC7
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG46:                ;; offset=0x0ACB
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x388], xmm0
 
G_M000_IG47:                ;; offset=0x0AD8
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x388]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG51
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rdx, gword ptr [rbp-0x390]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0xD8], 0
       je       G_M000_IG52
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rcx, gword ptr [rbp-0x398]
       mov      r11, 0x7FF9D7091C30
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG50
 
G_M000_IG48:                ;; offset=0x0B81
       mov      rcx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG49:                ;; offset=0x0B8E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG50:                ;; offset=0x0B94
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG61
 
G_M000_IG51:                ;; offset=0x0BAF
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG52
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG61
 
G_M000_IG52:                ;; offset=0x0BDC
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG56
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG63
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG56
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x100], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG63
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rdx, gword ptr [rbp-0x3A8]
       mov      rcx, gword ptr [rbp-0x100]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x3AC], eax
       mov      edx, dword ptr [rbp-0x3AC]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
 
G_M000_IG53:                ;; offset=0x0CC7
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x3B0], eax
       mov      r9d, dword ptr [rbp-0x3B0]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0x108]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG54:                ;; offset=0x0CF8
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x3C0], xmm0
 
G_M000_IG55:                ;; offset=0x0D08
       lea      rcx, [rbp-0x3C0]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x0D17
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG63
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3D8], rax
 
G_M000_IG57:                ;; offset=0x0D45
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
 
G_M000_IG58:                ;; offset=0x0D52
       mov      rdx, bword ptr [rbp-0x3D8]
       lea      r8, [rbp-0x3D0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG59:                ;; offset=0x0D6A
       mov      eax, 1
 
G_M000_IG60:                ;; offset=0x0D6F
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG61:                ;; offset=0x0D7B
       mov      eax, dword ptr [rbp-0x44]
 
G_M000_IG62:                ;; offset=0x0D7E
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG63:                ;; offset=0x0D8A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG64:                ;; offset=0x0D90
       sub      rsp, 72
 
G_M000_IG65:                ;; offset=0x0D94
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG66:                ;; offset=0x0DA5
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG67:                ;; offset=0x0DAD
       sub      rsp, 72
 
G_M000_IG68:                ;; offset=0x0DB1
       mov      gword ptr [rbp-0x238], rcx
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, 0x7FF9D7192168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rbp-0x248], rax
       cmp      gword ptr [rbp-0x240], 0
       jne      SHORT G_M000_IG69
       xor      eax, eax
       mov      dword ptr [rbp-0x24C], eax
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0DF8
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       lea      r8, [rbp-0xE0]
       mov      rcx, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x24C], eax
 
G_M000_IG70:                ;; offset=0x0E34
       mov      eax, dword ptr [rbp-0x24C]
 
G_M000_IG71:                ;; offset=0x0E3A
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG72:                ;; offset=0x0E42
       sub      rsp, 72
 
G_M000_IG73:                ;; offset=0x0E46
       mov      gword ptr [rbp-0x258], rcx
       mov      rcx, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3674

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xff1
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 44 inlinees with PGO data; 265 single block inlinees; 57 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 880
       mov      qword ptr [rsp+0xF78], r15
       mov      qword ptr [rsp+0xF70], r14
       mov      qword ptr [rsp+0xF68], r13
       mov      qword ptr [rsp+0xF60], r12
       mov      qword ptr [rsp+0xF58], rdi
       mov      qword ptr [rsp+0xF50], rsi
       mov      qword ptr [rsp+0xF48], rbx
       lea      rbp, [rsp+0x370]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
 
G_M000_IG502:                ;; offset=0x005B
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG502
       mov      qword ptr [rbp-0x40], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x0092
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG482
 
G_M000_IG03:                ;; offset=0x009F
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00A8
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00B2
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      r8, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [r8+0x08]
       cmp      edx, ebx
       jge      G_M000_IG480
 
G_M000_IG06:                ;; offset=0x00CF
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG488
       mov      r8, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [r8+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x011F
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x012B
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x013D
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG10:                ;; offset=0x014A
       mov      r8, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG71
 
G_M000_IG11:                ;; offset=0x015E
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rcx, G_M000_IG02
       add      rdx, rcx
       jmp      rdx
 
G_M000_IG12:                ;; offset=0x0178
       mov      rdi, bword ptr [rbp+0xC20]
       mov      r14, gword ptr [rdi]
       mov      r15, gword ptr [rdi+0x08]
       mov      ecx, esi
       cmp      ecx, 2
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x018D
       cmp      ecx, 25
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0192
       cmp      ecx, 72
       jne      G_M000_IG322
 
G_M000_IG15:                ;; offset=0x019B
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x08]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r13, gword ptr [rdx]
       cmp      esi, dword ptr [r15+0x08]
       jae      G_M000_IG476
       mov      edx, esi
       shl      rdx, 4
       lea      r15, bword ptr [r15+rdx+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x21AC8401CE0
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG46
 
G_M000_IG16:                ;; offset=0x01DA
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x21AC8401CE8
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG45
 
G_M000_IG17:                ;; offset=0x01F0
       cmp      qword ptr [r15+0x08], 0
       jle      G_M000_IG29
 
G_M000_IG18:                ;; offset=0x01FB
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG29
 
G_M000_IG19:                ;; offset=0x021A
       mov      eax, dword ptr [r15+0x08]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdx, gword ptr [r12+0x08]
       mov      rcx, 0x7FF9D71528A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x0244
       mov      rax, gword ptr [r12+0x08]
       test     rax, rax
       je       SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x024E
       mov      rdx, 0x7FF9D77C2CB8
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x025D
       xor      rax, rax
 
G_M000_IG23:                ;; offset=0x025F
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG24:                ;; offset=0x0268
       cmp      dword ptr [rbp-0x1B4], 0
       jne      G_M000_IG323
       mov      r8, r12
       mov      rcx, 0x7FF9D78646E0
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG324
       lea      r12, bword ptr [r8+0x28]
 
G_M000_IG25:                ;; offset=0x028F
       mov      rdx, gword ptr [r12]
       mov      rcx, 0x21AC8401CE0
       cmp      rdx, gword ptr [rcx]
       jne      G_M000_IG43
 
G_M000_IG26:                ;; offset=0x02A6
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, qword ptr [r12+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
       lea      rcx, [rbp-0x1C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rax, gword ptr [rbp-0x2E8]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x1C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r8d, dword ptr [rbp-0x1C0]
       mov      rax, gword ptr [rbp-0x2E8]
       mov      dword ptr [rax+0x10], r8d
       mov      rdx, rax
       mov      gword ptr [rbp-0x2F0], rdx
       mov      r8, 0x21AC8401CE0
       mov      r8, gword ptr [r8]
       mov      rcx, r12
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, 0x21AC8401CE0
       cmp      rax, gword ptr [rcx]
       je       G_M000_IG42
 
G_M000_IG27:                ;; offset=0x0335
       test     rax, rax
       je       G_M000_IG326
       mov      rdx, rax
 
G_M000_IG28:                ;; offset=0x0341
       mov      rcx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
 
G_M000_IG29:                ;; offset=0x034F
       mov      r12, gword ptr [r15]
 
G_M000_IG30:                ;; offset=0x0352
       test     r12, r12
       jne      G_M000_IG47
 
G_M000_IG31:                ;; offset=0x035B
       mov      r15, r12
 
G_M000_IG32:                ;; offset=0x035E
       test     r15, r15
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0363
       mov      rcx, r14
       mov      edx, esi
       mov      r8, r13
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
 
G_M000_IG34:                ;; offset=0x037B
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG67
 
G_M000_IG35:                ;; offset=0x038C
       lea      rsi, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG66
 
G_M000_IG36:                ;; offset=0x03A3
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG66
 
G_M000_IG37:                ;; offset=0x03B7
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x18]
 
G_M000_IG38:                ;; offset=0x03C2
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rcx+0x18]
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03D3
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x03DF
       mov      rcx, gword ptr [rsi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG476
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG41:                ;; offset=0x0413
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG476
       mov      ecx, r12d
       shl      rcx, 4
       lea      r12, bword ptr [rax+rcx+0x10]
       jmp      G_M000_IG25
 
G_M000_IG42:                ;; offset=0x0435
       mov      r12, gword ptr [rbp-0x2F0]
       mov      rdx, r12
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x0444
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       jmp      G_M000_IG28
 
G_M000_IG44:                ;; offset=0x045C
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG476
       mov      edx, r12d
       mov      rdx, gword ptr [rax+8*rdx+0x10]
       jmp      G_M000_IG28
 
G_M000_IG45:                ;; offset=0x047A
       mov      rcx, 0x7FF9D7186D68
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       vmovsd   xmm0, qword ptr [r15+0x08]
       vmovsd   qword ptr [r12+0x08], xmm0
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x04AF
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [r15+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
       lea      rcx, [rbp-0x1B0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rbp-0x1B0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1A8]
       mov      dword ptr [r12+0x10], ecx
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG47:                ;; offset=0x0510
       mov      rcx, 0x7FF9D77E4838
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG31
 
G_M000_IG48:                ;; offset=0x0524
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x052E
       cmp      byte  ptr [rcx+0x101], 0
       jne      G_M000_IG57
 
G_M000_IG50:                ;; offset=0x053B
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0545
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       jne      SHORT G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0550
       cmp      byte  ptr [r12+0x28], 0
       je       SHORT G_M000_IG55
 
G_M000_IG53:                ;; offset=0x0558
       cmp      gword ptr [r12+0x08], 0
       jne      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0560
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdx, qword ptr [r12+0x20]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
       lea      rcx, [rbp-0x1E0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1D8]
       mov      dword ptr [r15+0x10], ecx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG55:                ;; offset=0x05B7
       mov      r15, gword ptr [r12+0x08]
 
G_M000_IG56:                ;; offset=0x05BC
       jmp      G_M000_IG32
 
G_M000_IG57:                ;; offset=0x05C1
       mov      r15, gword ptr [r12+0x10]
       mov      rcx, gword ptr [r15+0x08]
       test     rcx, rcx
       jne      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x05D3
       mov      rcx, 0x7FF9D719DDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rcx, rax
       mov      gword ptr [rbp-0x2F8], rcx
       mov      rdx, 0x21AC8400068
       mov      rdx, gword ptr [rdx]
       mov      rax, rdx
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rcx+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x328]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0621
       mov      rcx, gword ptr [rbp-0x2F8]
       lea      rcx, bword ptr [rcx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG60:                ;; offset=0x0634
       lea      rcx, bword ptr [r15+0x08]
       test     rcx, rcx
       je       G_M000_IG325
       mov      rdx, gword ptr [rbp-0x2F8]
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0658
       mov      r15, gword ptr [rbp-0x2F8]
       mov      rcx, r15
 
G_M000_IG62:                ;; offset=0x0662
       mov      rdx, gword ptr [r12+0x18]
       lea      r8, [rbp-0x1D0]
       mov      r11, 0x7FF9D7091D00
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,System.__Canon]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       jne      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x067F
       xor      r15, r15
 
G_M000_IG64:                ;; offset=0x0682
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D0], rcx
       jmp      G_M000_IG56
 
G_M000_IG65:                ;; offset=0x0690
       mov      r15, gword ptr [rbp-0x1D0]
       jmp      SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x0699
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x14]
       jmp      G_M000_IG38
 
G_M000_IG67:                ;; offset=0x06A9
       mov      gword ptr [rbp-0x2B0], r15
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A8], r9
       lea      r9, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG68:                ;; offset=0x06DD
       mov      rdi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rdi]
       mov      rax, gword ptr [rcx+0x30]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG476
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x2B0], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2A8], r9
       lea      r9, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG69:                ;; offset=0x0745
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG70:                ;; offset=0x0753
       mov      rdi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rdi]
       mov      rsi, gword ptr [rcx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x23AEEE146A8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091CF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG388
       jmp      G_M000_IG387
 
G_M000_IG71:                ;; offset=0x07A1
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG72:                ;; offset=0x07C4
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA78], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA98], rcx
 
G_M000_IG73:                ;; offset=0x07DC
       mov      ecx, dword ptr [rbp+0xA88]
       mov      edx, dword ptr [rbp+0xA98]
       cmp      ecx, edx
       ja       G_M000_IG346
       mov      rax, bword ptr [rbp+0xA90]
       mov      r8d, ecx
       lea      rax, bword ptr [rax+2*r8]
       sub      edx, ecx
       cmp      edx, 27
       jb       G_M000_IG477
 
G_M000_IG74:                ;; offset=0x0809
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rax], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rax+0x20], xmm0
       mov      dword ptr [rax+0x30], 0x3A0065
       mov      word  ptr [rax+0x34], 32
       mov      ecx, dword ptr [rbp+0xA88]
       add      ecx, 27
       mov      dword ptr [rbp+0xA88], ecx
 
G_M000_IG75:                ;; offset=0x083E
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA78]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp+0xA78]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:                ;; offset=0x0889
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG77:                ;; offset=0x0897
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG380
       jmp      G_M000_IG373
 
G_M000_IG78:                ;; offset=0x08A9
       mov      r8, gword ptr [rbp+0xC30]
       cmp      byte  ptr [r8+0xF9], 0
       je       G_M000_IG02
       jmp      G_M000_IG385
 
G_M000_IG79:                ;; offset=0x08C3
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG80:                ;; offset=0x08D1
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rdx+0x70]
       cmp      byte  ptr [rdx+0x101], 0
       jne      G_M000_IG360
       jmp      G_M000_IG357
 
G_M000_IG81:                ;; offset=0x0932
       test     r15d, r15d
       je       G_M000_IG370
       jmp      G_M000_IG361
 
G_M000_IG82:                ;; offset=0x0940
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG476
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       jmp      G_M000_IG327
 
G_M000_IG83:                ;; offset=0x0978
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG347
 
G_M000_IG84:                ;; offset=0x09C9
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG85:                ;; offset=0x09D1
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x09E0
       mov      r10, gword ptr [rbp+0xC28]
       mov      rax, r10
 
G_M000_IG87:                ;; offset=0x09EA
       mov      bword ptr [rbp-0x2A0], r9
       mov      dword ptr [rbp-0x298], r8d
 
G_M000_IG88:                ;; offset=0x09F8
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG89:                ;; offset=0x0A08
       lea      rcx, [rbp-0x2A0]
       lea      r8, [rbp-0x2B0]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG90:                ;; offset=0x0A2F
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG476
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A62
       mov      rcx, 0x7FF9D758EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG345
 
G_M000_IG92:                ;; offset=0x0A75
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0AB8
       or       edi, r14d
       jne      G_M000_IG346
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG94:                ;; offset=0x0AC5
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0AE8
       mov      r10, gword ptr [rbp+0xC28]
       mov      r9, r10
 
G_M000_IG96:                ;; offset=0x0AF2
       mov      bword ptr [rbp-0x2A0], rdx
       mov      dword ptr [rbp-0x298], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2A0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG97:                ;; offset=0x0B3A
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG346
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
       jmp      G_M000_IG94
 
G_M000_IG98:                ;; offset=0x0B60
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0B6A
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG411
 
G_M000_IG100:                ;; offset=0x0B89
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rdx, gword ptr [rbx]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG476
       mov      eax, esi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x21AC8401CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG143
 
G_M000_IG101:                ;; offset=0x0BCB
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x21AC8401CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG117
 
G_M000_IG102:                ;; offset=0x0BE1
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG107
 
G_M000_IG103:                ;; offset=0x0BE8
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0C03
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71528A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG116
 
G_M000_IG105:                ;; offset=0x0C27
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG106:                ;; offset=0x0C3C
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG107:                ;; offset=0x0C4D
       mov      r14, gword ptr [rdi]
 
G_M000_IG108:                ;; offset=0x0C50
       test     r14, r14
       je       G_M000_IG419
       mov      rdx, 0x7FF9D7838AB0
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG144
 
G_M000_IG109:                ;; offset=0x0C6C
       mov      rbx, r14
       mov      eax, dword ptr [rbx+0x34]
       cmp      eax, dword ptr [rbx+0x30]
       jne      G_M000_IG153
 
G_M000_IG110:                ;; offset=0x0C7B
       xor      rbx, rbx
 
G_M000_IG111:                ;; offset=0x0C7D
       xor      esi, esi
 
G_M000_IG112:                ;; offset=0x0C7F
       test     rbx, rbx
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       jne      G_M000_IG213
 
G_M000_IG113:                ;; offset=0x0C93
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG114:                ;; offset=0x0C98
       test     r9d, r9d
       je       G_M000_IG214
 
G_M000_IG115:                ;; offset=0x0CA1
       mov      gword ptr [rbp+0xB58], rdx
       mov      qword ptr [rbp+0xB60], r8
       lea      r9, [rbp+0xB58]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG116:                ;; offset=0x0CD6
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG476
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG106
 
G_M000_IG117:                ;; offset=0x0CED
       mov      rcx, 0x7FF9D7186D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG108
 
G_M000_IG118:                ;; offset=0x0D20
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG267
 
G_M000_IG119:                ;; offset=0x0D61
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG352
 
G_M000_IG120:                ;; offset=0x0D6E
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG121:                ;; offset=0x0D7E
       mov      rsi, gword ptr [rbp+0xB08]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG348
 
G_M000_IG122:                ;; offset=0x0D93
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG123:                ;; offset=0x0DA1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rsi, r12
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rsi+0x08]
       cmp      eax, r10d
       jae      G_M000_IG476
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x210]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG124:                ;; offset=0x0E27
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x200]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG125:                ;; offset=0x0E91
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0E9F
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r8d, dword ptr [rsi+0x10]
       mov      r9d, dword ptr [rsi+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG328
 
G_M000_IG127:                ;; offset=0x0ECF
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG329
       jmp      G_M000_IG267
 
G_M000_IG128:                ;; offset=0x0F16
       xor      r14, r14
       xor      r15d, r15d
       jmp      G_M000_IG217
 
G_M000_IG129:                ;; offset=0x0F21
       mov      rcx, r12
       jmp      G_M000_IG221
 
G_M000_IG130:                ;; offset=0x0F29
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG100
 
G_M000_IG131:                ;; offset=0x0F53
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG132:                ;; offset=0x0F62
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x0F71
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r9, rdx
 
G_M000_IG134:                ;; offset=0x0F7B
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG135:                ;; offset=0x0F9A
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG267
 
G_M000_IG136:                ;; offset=0x0FBF
       test     al, al
       jne      SHORT G_M000_IG140
 
G_M000_IG137:                ;; offset=0x0FC3
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG138:                ;; offset=0x0FCA
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG139:                ;; offset=0x0FD7
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp+0xB18]
       test     rbx, rbx
       je       G_M000_IG02
       jmp      G_M000_IG338
 
G_M000_IG140:                ;; offset=0x100A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG141:                ;; offset=0x1011
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG142:                ;; offset=0x101E
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG275
       jmp      G_M000_IG342
 
G_M000_IG143:                ;; offset=0x1089
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
       lea      rcx, [rbp-0x260]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x260]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x258]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG108
 
G_M000_IG144:                ;; offset=0x10E8
       mov      rdx, 0x7FF9D77EA4F0
       cmp      qword ptr [r14], rdx
       je       SHORT G_M000_IG151
 
G_M000_IG145:                ;; offset=0x10F7
       mov      rdx, r14
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x110F
       mov      rcx, 0x7FF9D7838D18
       cmp      qword ptr [r14], rcx
       je       SHORT G_M000_IG150
 
G_M000_IG147:                ;; offset=0x111E
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG148:                ;; offset=0x112C
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG425
 
G_M000_IG149:                ;; offset=0x1139
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG150:                ;; offset=0x1158
       mov      rcx, r14
       lea      rdx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x116A
       mov      r8, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r8+0x08]
       jae      G_M000_IG476
       mov      edx, esi
       lea      r8, bword ptr [r8+4*rdx+0x10]
       lea      rcx, [rbp-0x250]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
 
G_M000_IG152:                ;; offset=0x1192
       mov      rbx, gword ptr [rbp-0x250]
       mov      rsi, qword ptr [rbp-0x248]
       jmp      G_M000_IG112
 
G_M000_IG153:                ;; offset=0x11A5
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG420
 
G_M000_IG154:                ;; offset=0x11B2
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG155:                ;; offset=0x11B9
       lea      r8, bword ptr [rbx+0x34]
       mov      esi, dword ptr [r8]
       add      esi, 4
       mov      r10d, dword ptr [r8]
       cmp      r10d, eax
       ja       G_M000_IG346
       mov      r9d, r10d
       add      rdx, r9
       sub      eax, r10d
       cmp      eax, 4
       jl       G_M000_IG421
       mov      edi, dword ptr [rdx]
       lea      eax, [rsi+rdi]
       mov      dword ptr [r8], eax
       movsxd   r14, edi
       add      r14, 128
       cmp      r14, qword ptr [rbx+0x28]
       jg       G_M000_IG422
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG423
       lea      r15, bword ptr [rax+0x10]
       mov      r13d, dword ptr [rax+0x08]
 
G_M000_IG156:                ;; offset=0x1212
       mov      r12, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rbx+0x20]
       mov      gword ptr [rbp-0x308], rax
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x300], rdx
       test     edi, edi
       je       G_M000_IG212
 
G_M000_IG157:                ;; offset=0x1234
       mov      rcx, 0x7FF9D75B1030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x310], rax
       mov      dword ptr [rax+0x1C], -1
       test     edi, edi
       jl       G_M000_IG424
 
G_M000_IG158:                ;; offset=0x1259
       cmp      edi, 8
       jg       SHORT G_M000_IG163
 
G_M000_IG159:                ;; offset=0x125E
       mov      byte  ptr [rax+0x24], dil
 
G_M000_IG160:                ;; offset=0x1262
       mov      rax, gword ptr [rbp-0x310]
       mov      dword ptr [rax+0x18], edi
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0x310]
       lea      rdx, [rbp-0x270]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      r12d, dword ptr [rbp-0x268]
       mov      rax, bword ptr [rbp-0x270]
       mov      bword ptr [rbp-0x320], rax
       xor      edx, edx
       mov      dword ptr [rbp-0x274], edx
       test     r12d, r12d
       jg       G_M000_IG208
 
G_M000_IG161:                ;; offset=0x12B5
       mov      rcx, rdi
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
 
G_M000_IG162:                ;; offset=0x12C1
       sub      qword ptr [rbx+0x28], r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       jmp      G_M000_IG111
 
G_M000_IG163:                ;; offset=0x12D6
       mov      edx, edi
       mov      rcx, 0x7FF9D72700F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       mov      rax, gword ptr [rbp-0x310]
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG160
 
G_M000_IG164:                ;; offset=0x12FF
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x1330
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x290], rcx
       mov      ecx, 1
 
G_M000_IG166:                ;; offset=0x133F
       test     ecx, ecx
       jne      G_M000_IG234
       jmp      G_M000_IG454
 
G_M000_IG167:                ;; offset=0x134C
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
 
G_M000_IG168:                ;; offset=0x1355
       jmp      SHORT G_M000_IG166
 
G_M000_IG169:                ;; offset=0x1357
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG476
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG235
 
G_M000_IG170:                ;; offset=0x1375
       cmp      esi, r15d
       jae      G_M000_IG476
       mov      eax, esi
       shl      rax, 4
       add      rax, r14
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG182
 
G_M000_IG171:                ;; offset=0x139D
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE8
       cmp      rdx, gword ptr [r8]
       je       SHORT G_M000_IG181
 
G_M000_IG172:                ;; offset=0x13AF
       cmp      qword ptr [rax+0x08], 0
       je       SHORT G_M000_IG180
 
G_M000_IG173:                ;; offset=0x13B6
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
 
G_M000_IG174:                ;; offset=0x13BF
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG183
 
G_M000_IG175:                ;; offset=0x13CA
       test     rcx, rcx
       je       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x13CF
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG178
 
G_M000_IG177:                ;; offset=0x13DE
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG178:                ;; offset=0x13E7
       test     rcx, rcx
       jne      SHORT G_M000_IG183
 
G_M000_IG179:                ;; offset=0x13EC
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG235
 
G_M000_IG180:                ;; offset=0x1418
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG174
 
G_M000_IG181:                ;; offset=0x141D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      SHORT G_M000_IG174
 
G_M000_IG182:                ;; offset=0x1428
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      SHORT G_M000_IG174
 
G_M000_IG183:                ;; offset=0x1433
       test     rcx, rcx
       je       G_M000_IG455
       mov      rdx, rcx
       jmp      G_M000_IG235
 
G_M000_IG184:                ;; offset=0x1444
       not      r8d
       jmp      G_M000_IG238
 
G_M000_IG185:                ;; offset=0x144C
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x14]
       jmp      G_M000_IG238
 
G_M000_IG186:                ;; offset=0x145C
       mov      r9d, ecx
       not      r9d
       jmp      G_M000_IG240
 
G_M000_IG187:                ;; offset=0x1467
       cmp      esi, 58
       ja       G_M000_IG267
 
G_M000_IG188:                ;; offset=0x1470
       mov      rcx, 0x1FDFFFFFFFFFFFF
       bt       rcx, rsi
       jb       G_M000_IG267
       jmp      G_M000_IG283
 
G_M000_IG189:                ;; offset=0x1489
       not      esi
       jmp      G_M000_IG297
 
G_M000_IG190:                ;; offset=0x1490
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x14]
       jmp      G_M000_IG297
 
G_M000_IG191:                ;; offset=0x149F
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], esi
       jne      G_M000_IG298
 
G_M000_IG192:                ;; offset=0x14AF
       mov      r9, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       G_M000_IG197
 
G_M000_IG193:                ;; offset=0x14BF
       lea      r8, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
 
G_M000_IG194:                ;; offset=0x14C6
       mov      bword ptr [rbp-0x2A0], r8
       mov      dword ptr [rbp-0x298], edx
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp+0xAC0]
       mov      qword ptr [rsp+0x30], r8
       lea      rdx, [rbp-0x2A0]
       mov      r8d, dword ptr [rcx+0x10]
       mov      rcx, r9
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedCall(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG200
 
G_M000_IG195:                ;; offset=0x151F
       mov      rdx, gword ptr [rbp+0xAC0]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG198
 
G_M000_IG196:                ;; offset=0x153E
       jmp      G_M000_IG485
 
G_M000_IG197:                ;; offset=0x1543
       xor      r8, r8
       xor      edx, edx
       jmp      G_M000_IG194
 
G_M000_IG198:                ;; offset=0x154D
       vmovdqu  xmm0, xmmword ptr [rbp+0xAC0]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG199:                ;; offset=0x155D
       lea      r9, [rbp-0x2B0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG200:                ;; offset=0x1584
       lea      edx, [rsi+0x02]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], edx
       jmp      G_M000_IG298
 
G_M000_IG201:                ;; offset=0x1596
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG476
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG304
 
G_M000_IG202:                ;; offset=0x15AD
       mov      rcx, 0x7FF9D7186D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG306
 
G_M000_IG203:                ;; offset=0x15E0
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x288], xmm0
       lea      rcx, [rbp-0x288]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x288]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x280]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG306
 
G_M000_IG204:                ;; offset=0x163F
       mov      rcx, gword ptr [rbp-0x318]
       mov      rdx, gword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp-0x300]
 
G_M000_IG205:                ;; offset=0x165A
       mov      edx, dword ptr [rbp-0x274]
       mov      r10d, r12d
       sub      r10d, edx
       cmp      r10d, 0x1000
       jl       G_M000_IG211
 
G_M000_IG206:                ;; offset=0x1673
       mov      r9d, 0x1000
 
G_M000_IG207:                ;; offset=0x1679
       lea      ecx, [rsi+rdx]
       mov      r10d, ecx
       mov      r11d, r9d
       add      r10, r11
       mov      r11d, r13d
       cmp      r10, r11
       ja       G_M000_IG346
       add      rcx, r15
       mov      r10, rcx
       mov      ecx, edx
       mov      r11d, r9d
       add      rcx, r11
       mov      r11d, r12d
       cmp      rcx, r11
       ja       G_M000_IG346
       mov      dword ptr [rbp-0x274], edx
       mov      ecx, edx
       add      rcx, bword ptr [rbp-0x320]
       mov      dword ptr [rbp-0x278], r9d
       mov      r8d, r9d
       mov      rdx, r10
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      edx, dword ptr [rbp-0x278]
       add      edx, dword ptr [rbp-0x274]
       mov      ecx, edx
       cmp      ecx, r12d
       mov      dword ptr [rbp-0x274], ecx
       jge      G_M000_IG161
 
G_M000_IG208:                ;; offset=0x16EA
       mov      r8, gword ptr [rbp-0x300]
       test     r8, r8
       je       G_M000_IG205
 
G_M000_IG209:                ;; offset=0x16FA
       mov      r10, gword ptr [r8+0x98]
       mov      gword ptr [rbp-0x318], r10
       cmp      byte  ptr [r10], r10b
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG204
 
G_M000_IG210:                ;; offset=0x171C
       mov      r8, gword ptr [rbp-0x300]
       jmp      G_M000_IG205
 
G_M000_IG211:                ;; offset=0x1728
       mov      r9d, r10d
       jmp      G_M000_IG207
 
G_M000_IG212:                ;; offset=0x1730
       mov      rax, 0x21AC8400F78
       mov      rdi, gword ptr [rax]
       jmp      G_M000_IG162
 
G_M000_IG213:                ;; offset=0x1742
       mov      rdx, rbx
       mov      r8, rsi
       jmp      G_M000_IG114
 
G_M000_IG214:                ;; offset=0x174D
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG131
 
G_M000_IG215:                ;; offset=0x1784
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG128
 
G_M000_IG216:                ;; offset=0x17A9
       lea      r14, bword ptr [rax+0x10]
       mov      r15d, dword ptr [rax+0x08]
 
G_M000_IG217:                ;; offset=0x17B1
       mov      r13d, dword ptr [rcx+0x10]
       xor      rax, rax
       mov      gword ptr [rbp-0x290], rax
       test     esi, esi
       jge      G_M000_IG170
 
G_M000_IG218:                ;; offset=0x17C6
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG169
 
G_M000_IG219:                ;; offset=0x17D5
       mov      r12, gword ptr [rdi+0x38]
       mov      rdx, r12
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG476
       mov      r15, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       cmp      esi, r10d
       jae      G_M000_IG476
       mov      eax, esi
       mov      r14, gword ptr [r12+8*rax+0x10]
       mov      rcx, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       jne      G_M000_IG129
 
G_M000_IG220:                ;; offset=0x1827
       xor      rcx, rcx
 
G_M000_IG221:                ;; offset=0x1829
       test     rcx, rcx
       je       SHORT G_M000_IG227
 
G_M000_IG222:                ;; offset=0x182E
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      SHORT G_M000_IG226
 
G_M000_IG223:                ;; offset=0x183B
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG476
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jl       SHORT G_M000_IG227
 
G_M000_IG224:                ;; offset=0x1852
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       SHORT G_M000_IG227
 
G_M000_IG225:                ;; offset=0x1864
       mov      gword ptr [rbp-0x290], rax
       jmp      G_M000_IG234
 
G_M000_IG226:                ;; offset=0x1870
       lea      r8, [rbp-0x290]
       mov      rdx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG234
 
G_M000_IG227:                ;; offset=0x188A
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG232
 
G_M000_IG228:                ;; offset=0x1894
       mov      rcx, 0x7FF9D719DDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, 0x21AC8400068
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rsi+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x328]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG230
 
G_M000_IG229:                ;; offset=0x18D8
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG230:                ;; offset=0x18E4
       lea      rcx, bword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG325
       mov      rdx, rsi
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG232
 
G_M000_IG231:                ;; offset=0x1905
       mov      rcx, rsi
 
G_M000_IG232:                ;; offset=0x1908
       cmp      byte  ptr [rcx], cl
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       G_M000_IG164
 
G_M000_IG233:                ;; offset=0x191C
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x290], rcx
 
G_M000_IG234:                ;; offset=0x1926
       mov      rdx, gword ptr [rbp-0x290]
 
G_M000_IG235:                ;; offset=0x192D
       xor      rcx, rcx
       mov      gword ptr [rbp-0x290], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG185
 
G_M000_IG236:                ;; offset=0x1949
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       G_M000_IG185
 
G_M000_IG237:                ;; offset=0x195D
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [rcx+0x18]
       test     r8d, r8d
       jl       G_M000_IG184
 
G_M000_IG238:                ;; offset=0x1971
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jl       G_M000_IG186
 
G_M000_IG239:                ;; offset=0x1983
       mov      r9d, ecx
 
G_M000_IG240:                ;; offset=0x1986
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG241:                ;; offset=0x19A6
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG267
 
G_M000_IG242:                ;; offset=0x19CB
       test     al, al
       jne      G_M000_IG456
 
G_M000_IG243:                ;; offset=0x19D3
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, rdx
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG244:                ;; offset=0x19EF
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG245:                ;; offset=0x19FD
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG404
       jmp      SHORT G_M000_IG248
 
G_M000_IG246:                ;; offset=0x1A0C
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG247:                ;; offset=0x1A24
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG248:                ;; offset=0x1A32
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG249:                ;; offset=0x1A51
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG252
 
G_M000_IG250:                ;; offset=0x1A5B
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x1A73
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG478
 
G_M000_IG252:                ;; offset=0x1A82
       mov      rbx, bword ptr [rbp+0xC58]
       mov      r8d, dword ptr [rbx+0x08]
       test     r8d, r8d
       jne      G_M000_IG401
 
G_M000_IG253:                ;; offset=0x1A96
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x240]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG254:                ;; offset=0x1B13
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x230]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG255:                ;; offset=0x1B90
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG256:                ;; offset=0x1BD3
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x220]
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG257:                ;; offset=0x1C43
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG258:                ;; offset=0x1C51
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG476
       mov      ecx, eax
       mov      r14, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r15, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r13d
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, r14
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG259:                ;; offset=0x1CEC
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG260:                ;; offset=0x1CFA
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG476
       mov      ecx, eax
       mov      rsi, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r14d
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG261:                ;; offset=0x1D7E
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG267
 
G_M000_IG262:                ;; offset=0x1DA6
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG263:                ;; offset=0x1DCD
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG267
 
G_M000_IG264:                ;; offset=0x1DD7
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG265:                ;; offset=0x1DF3
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG392
 
G_M000_IG266:                ;; offset=0x1E22
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG268
 
G_M000_IG267:                ;; offset=0x1E2C
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG478
 
G_M000_IG268:                ;; offset=0x1E3B
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG272
 
G_M000_IG269:                ;; offset=0x1E44
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG270:                ;; offset=0x1E4B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG271:                ;; offset=0x1E58
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp+0xB18]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG330
 
G_M000_IG272:                ;; offset=0x1E8B
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG273:                ;; offset=0x1E92
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG274:                ;; offset=0x1E9F
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       jne      G_M000_IG334
 
G_M000_IG275:                ;; offset=0x1F0B
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG276:                ;; offset=0x1F1D
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG246
 
G_M000_IG277:                ;; offset=0x1F6A
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG478
 
G_M000_IG278:                ;; offset=0x1F75
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rbp+0xC28]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x1FA3
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG267
 
G_M000_IG280:                ;; offset=0x1FB4
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG468
 
G_M000_IG281:                ;; offset=0x1FC1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG282:                ;; offset=0x1FEE
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG187
 
G_M000_IG283:                ;; offset=0x1FFC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
 
G_M000_IG284:                ;; offset=0x2036
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     al, al
       je       G_M000_IG251
 
G_M000_IG285:                ;; offset=0x2053
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG251
 
G_M000_IG286:                ;; offset=0x205E
       xor      r8, r8
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], r8
       mov      word  ptr [r10+0x08], 0
       movzx    r8, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], r8b
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG478
 
G_M000_IG287:                ;; offset=0x2092
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG292
       jmp      G_M000_IG02
 
G_M000_IG288:                ;; offset=0x20C0
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG243
       jmp      G_M000_IG267
 
G_M000_IG289:                ;; offset=0x20D3
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG267
 
G_M000_IG290:                ;; offset=0x20E1
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG462
       jmp      G_M000_IG243
 
G_M000_IG291:                ;; offset=0x20F3
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG292:                ;; offset=0x211D
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG410
 
G_M000_IG293:                ;; offset=0x217B
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xB0]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG432
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG431
       mov      rbx, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG294:                ;; offset=0x21B7
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 51
       ja       G_M000_IG190
 
G_M000_IG295:                ;; offset=0x21CA
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rdx
       jb       G_M000_IG190
 
G_M000_IG296:                ;; offset=0x21DE
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x18]
       test     esi, esi
       jl       G_M000_IG189
 
G_M000_IG297:                ;; offset=0x21F0
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x10], 0
       jl       G_M000_IG191
 
G_M000_IG298:                ;; offset=0x2201
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      rdx, gword ptr [rdx]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, esi
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG476
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x21AC8401CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG203
 
G_M000_IG299:                ;; offset=0x2245
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x21AC8401CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG202
 
G_M000_IG300:                ;; offset=0x225B
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG305
 
G_M000_IG301:                ;; offset=0x2262
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG305
 
G_M000_IG302:                ;; offset=0x227D
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71528A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG201
 
G_M000_IG303:                ;; offset=0x22A1
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG304:                ;; offset=0x22B6
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG305:                ;; offset=0x22C7
       mov      r14, gword ptr [rdi]
 
G_M000_IG306:                ;; offset=0x22CA
       test     r14, r14
       je       G_M000_IG433
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], r14
       lea      rdx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG313
 
G_M000_IG307:                ;; offset=0x230E
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
 
G_M000_IG308:                ;; offset=0x231C
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG310
 
G_M000_IG309:                ;; offset=0x233B
       jmp      G_M000_IG485
 
G_M000_IG310:                ;; offset=0x2340
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0x234F
       mov      rcx, 0x7FF9D76A9D18
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG434
 
G_M000_IG312:                ;; offset=0x2362
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      SHORT G_M000_IG319
 
G_M000_IG313:                ;; offset=0x238F
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG435
 
G_M000_IG314:                ;; offset=0x239D
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG320
 
G_M000_IG315:                ;; offset=0x23CE
       mov      r8, bword ptr [rbp+0xC50]
       mov      r14, gword ptr [r8]
       test     r14, r14
       jne      G_M000_IG438
 
G_M000_IG316:                ;; offset=0x23E1
       mov      r8, bword ptr [rbp+0xC50]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG441
 
G_M000_IG317:                ;; offset=0x23F4
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG318:                ;; offset=0x23F8
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      rdi, rcx
       je       G_M000_IG445
 
G_M000_IG319:                ;; offset=0x2408
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG478
 
G_M000_IG320:                ;; offset=0x2427
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG450
 
G_M000_IG321:                ;; offset=0x2434
       mov      gword ptr [rsp+0x20], r14
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG446
 
G_M000_IG322:                ;; offset=0x246E
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x23AEEE0D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG323:                ;; offset=0x248E
       mov      rcx, 0x7FF9D72BE510
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       call     [System.IndexOutOfRangeException:.ctor():this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG324:                ;; offset=0x24B2
       mov      rdx, r12
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG325:                ;; offset=0x24BC
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG326:                ;; offset=0x24C3
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG327:                ;; offset=0x24F1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx]
       mov      rbx, gword ptr [r8+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091CE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG328:                ;; offset=0x253A
       add      dword ptr [rsi+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG329:                ;; offset=0x2543
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1F0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG330:                ;; offset=0x257E
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG333
 
G_M000_IG331:                ;; offset=0x2596
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG332:                ;; offset=0x25AB
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG333:                ;; offset=0x25BE
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG334:                ;; offset=0x25DB
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG335
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG336
 
G_M000_IG335:                ;; offset=0x2604
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG336:                ;; offset=0x262A
       test     edi, edi
       jne      G_M000_IG275
 
G_M000_IG337:                ;; offset=0x2632
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG478
 
G_M000_IG338:                ;; offset=0x2657
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG341
 
G_M000_IG339:                ;; offset=0x266F
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG340:                ;; offset=0x2684
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG341:                ;; offset=0x2697
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG342:                ;; offset=0x26B4
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG343
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG344
 
G_M000_IG343:                ;; offset=0x26DD
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG344:                ;; offset=0x2703
       test     esi, esi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG345:                ;; offset=0x2710
       mov      rax, rcx
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG346:                ;; offset=0x271A
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG347:                ;; offset=0x2721
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG85
 
G_M000_IG348:                ;; offset=0x272C
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG351
 
G_M000_IG349:                ;; offset=0x2744
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG350:                ;; offset=0x2759
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG351:                ;; offset=0x276C
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D7091D28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG352:                ;; offset=0x2789
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG353:                ;; offset=0x2799
       lea      rdx, [rbp-0x2E0]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG275
 
G_M000_IG354:                ;; offset=0x27E4
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x280D
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG356:                ;; offset=0x2833
       test     edi, edi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG357:                ;; offset=0x2840
       cmp      byte  ptr [rdx+0xFF], 0
       jne      SHORT G_M000_IG360
 
G_M000_IG358:                ;; offset=0x2849
       cmp      ebx, esi
       jle      SHORT G_M000_IG360
 
G_M000_IG359:                ;; offset=0x284D
       cmp      esi, ebx
       jae      G_M000_IG476
       mov      r8, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       cmp      dword ptr [r8+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       mov      rdx, gword ptr [rbp+0xC30]
       jmp      G_M000_IG81
 
G_M000_IG360:                ;; offset=0x287D
       mov      rdx, gword ptr [rbp+0xC30]
       xor      r15d, r15d
       jmp      G_M000_IG81
 
G_M000_IG361:                ;; offset=0x288C
       test     rdi, rdi
       je       G_M000_IG370
 
G_M000_IG362:                ;; offset=0x2895
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG363:                ;; offset=0x28A5
       lea      r8, [rbp-0x2B0]
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG370
 
G_M000_IG364:                ;; offset=0x28C4
       cmp      esi, ebx
       jae      G_M000_IG476
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       mov      r15, gword ptr [rcx+r14+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG366
 
G_M000_IG365:                ;; offset=0x28FD
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG366:                ;; offset=0x2909
       mov      r9, gword ptr [rbp+0xC28]
       mov      rsi, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG368
 
G_M000_IG367:                ;; offset=0x2928
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG369
 
G_M000_IG368:                ;; offset=0x2938
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG369:                ;; offset=0x294D
       lea      rcx, bword ptr [rsi+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       lea      rcx, bword ptr [rax+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG486
 
G_M000_IG370:                ;; offset=0x2991
       mov      rdx, gword ptr [rbp+0xC30]
       lea      rsi, bword ptr [rdx+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rsi+0x08], rcx
       mov      rdx, gword ptr [rbp+0xC30]
       mov      word  ptr [rdx+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       jne      G_M000_IG251
 
G_M000_IG371:                ;; offset=0x29DC
       test     rdi, rdi
       je       G_M000_IG251
 
G_M000_IG372:                ;; offset=0x29E5
       mov      rcx, rdx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG251
       jmp      G_M000_IG486
 
G_M000_IG373:                ;; offset=0x29FE
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG374:                ;; offset=0x2A05
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG375:                ;; offset=0x2A12
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG379
 
G_M000_IG376:                ;; offset=0x2A60
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG377
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG378
 
G_M000_IG377:                ;; offset=0x2A89
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG378:                ;; offset=0x2AAF
       test     edi, edi
       je       G_M000_IG337
 
G_M000_IG379:                ;; offset=0x2AB7
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG78
 
G_M000_IG380:                ;; offset=0x2AC9
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      gword ptr [rdx+0x68], 0
       jne      G_M000_IG382
 
G_M000_IG381:                ;; offset=0x2ADB
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [r8+0x68]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG382:                ;; offset=0x2B90
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rdx+0x68]
       mov      r8, gword ptr [rdx+0x58]
       mov      r9, gword ptr [rdx+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG383:                ;; offset=0x2BB9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG384:                ;; offset=0x2BC6
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG78
 
G_M000_IG385:                ;; offset=0x2BE6
       mov      rdx, r8
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rdx+0x70]
       test     r8, r8
       je       G_M000_IG251
 
G_M000_IG386:                ;; offset=0x2C0B
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG251
       jmp      G_M000_IG486
 
G_M000_IG387:                ;; offset=0x2C24
       mov      rcx, gword ptr [rdi]
       mov      r8, gword ptr [rdi+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG388:                ;; offset=0x2C40
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG275
 
G_M000_IG389:                ;; offset=0x2CA2
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG390
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG391
 
G_M000_IG390:                ;; offset=0x2CCB
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG391:                ;; offset=0x2CF1
       test     r14d, r14d
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG392:                ;; offset=0x2CFF
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG267
 
G_M000_IG393:                ;; offset=0x2D24
       test     al, al
       jne      SHORT G_M000_IG395
 
G_M000_IG394:                ;; offset=0x2D28
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG395:                ;; offset=0x2D44
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG396:                ;; offset=0x2D4B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG397:                ;; offset=0x2D58
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG275
 
G_M000_IG398:                ;; offset=0x2DAA
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG399
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG400
 
G_M000_IG399:                ;; offset=0x2DD3
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG400:                ;; offset=0x2DF9
       test     edi, edi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG401:                ;; offset=0x2E06
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG253
 
G_M000_IG402:                ;; offset=0x2E22
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG403:                ;; offset=0x2E2E
       lea      r9, [rbp-0x2A0]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG478
 
G_M000_IG404:                ;; offset=0x2E5F
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG405:                ;; offset=0x2E66
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG406:                ;; offset=0x2E73
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG246
 
G_M000_IG407:                ;; offset=0x2EC5
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG408
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG409
 
G_M000_IG408:                ;; offset=0x2EEE
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG409:                ;; offset=0x2F14
       test     esi, esi
       jne      G_M000_IG246
       jmp      G_M000_IG337
 
G_M000_IG410:                ;; offset=0x2F21
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG478
 
G_M000_IG411:                ;; offset=0x2F4C
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG476
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG100
 
G_M000_IG412:                ;; offset=0x2F7C
       mov      rax, 0x7FF9D77E5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG100
 
G_M000_IG413:                ;; offset=0x2F8F
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG100
 
G_M000_IG414:                ;; offset=0x2FA1
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG100
 
G_M000_IG415:                ;; offset=0x2FAC
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG246
 
G_M000_IG416:                ;; offset=0x300B
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG417
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG418
 
G_M000_IG417:                ;; offset=0x3034
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG418:                ;; offset=0x305A
       test     esi, esi
       jne      G_M000_IG246
       jmp      G_M000_IG337
 
G_M000_IG419:                ;; offset=0x3067
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG420:                ;; offset=0x3095
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG155
 
G_M000_IG421:                ;; offset=0x309E
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG422:                ;; offset=0x30AA
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE14020
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG423:                ;; offset=0x30D8
       xor      r15, r15
       xor      r13d, r13d
       jmp      G_M000_IG156
 
G_M000_IG424:                ;; offset=0x30E3
       mov      ecx, edi
       mov      rdx, 0x23AEEE06810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG425:                ;; offset=0x30F6
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG426:                ;; offset=0x30FD
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG427:                ;; offset=0x310A
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG246
 
G_M000_IG428:                ;; offset=0x315C
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG429
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG430
 
G_M000_IG429:                ;; offset=0x3185
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG430:                ;; offset=0x31AB
       test     esi, esi
       jne      G_M000_IG246
       jmp      G_M000_IG337
 
G_M000_IG431:                ;; offset=0x31B8
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG432:                ;; offset=0x31BF
       mov      rcx, rax
       mov      r11, 0x7FF9D7091CF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG294
 
G_M000_IG433:                ;; offset=0x31D7
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG434:                ;; offset=0x3205
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG435:                ;; offset=0x320C
       mov      gword ptr [rsp+0x20], r14
       lea      rcx, [rbp+0xAA8]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG267
 
G_M000_IG436:                ;; offset=0x323F
       cmp      gword ptr [rbp+0xAA8], 0
       je       G_M000_IG02
 
G_M000_IG437:                ;; offset=0x324D
       mov      r8, gword ptr [rbp+0xAA8]
       xor      r10, r10
       mov      r11, bword ptr [rbp+0xC50]
       mov      gword ptr [r11], r10
       lea      rcx, bword ptr [r11+0x08]
       mov      rdx, r8
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r11, bword ptr [rbp+0xC50]
       mov      word  ptr [r11+0x10], 0
       mov      byte  ptr [r11+0x12], 1
       jmp      G_M000_IG319
 
G_M000_IG438:                ;; offset=0x3285
       mov      rdx, r14
       mov      rcx, 0x7FF9D78859B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG439
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG440
 
G_M000_IG439:                ;; offset=0x32A8
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D7091D68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG440:                ;; offset=0x32CD
       test     eax, eax
       je       G_M000_IG319
       jmp      G_M000_IG316
 
G_M000_IG441:                ;; offset=0x32DA
       mov      rdx, rsi
       mov      rcx, 0x7FF9D78859B0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG444
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG443
 
G_M000_IG442:                ;; offset=0x3306
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG443:                ;; offset=0x3311
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG318
 
G_M000_IG444:                ;; offset=0x331A
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG318
 
G_M000_IG445:                ;; offset=0x333E
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG131
 
G_M000_IG446:                ;; offset=0x3357
       mov      rdx, r14
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG449
 
G_M000_IG447:                ;; offset=0x336F
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG448:                ;; offset=0x3384
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG449:                ;; offset=0x3397
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG450:                ;; offset=0x33B4
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG275
 
G_M000_IG451:                ;; offset=0x3426
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG452
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG453
 
G_M000_IG452:                ;; offset=0x344F
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D80
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG453:                ;; offset=0x3475
       test     esi, esi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG454:                ;; offset=0x3482
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG455:                ;; offset=0x34A6
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG456:                ;; offset=0x34D4
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG457:                ;; offset=0x34DB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG458:                ;; offset=0x34E8
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG275
 
G_M000_IG459:                ;; offset=0x354E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG460
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG461
 
G_M000_IG460:                ;; offset=0x3577
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG461:                ;; offset=0x359D
       test     esi, esi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG462:                ;; offset=0x35AA
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG463:                ;; offset=0x35B1
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG464:                ;; offset=0x35BE
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG275
 
G_M000_IG465:                ;; offset=0x3624
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG466
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG467
 
G_M000_IG466:                ;; offset=0x364D
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG467:                ;; offset=0x3673
       test     esi, esi
       jne      G_M000_IG275
       jmp      G_M000_IG337
 
G_M000_IG468:                ;; offset=0x3680
       test     rbx, rbx
       je       G_M000_IG281
 
G_M000_IG469:                ;; offset=0x3689
       mov      r8, 0x7FF9D77E9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG281
 
G_M000_IG470:                ;; offset=0x369C
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG471:                ;; offset=0x36A3
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2D0], ymm0
 
G_M000_IG472:                ;; offset=0x36B0
       lea      r8, [rbp-0x2D0]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG246
 
G_M000_IG473:                ;; offset=0x3704
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG474
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG475
 
G_M000_IG474:                ;; offset=0x372D
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG475:                ;; offset=0x3753
       test     esi, esi
       jne      G_M000_IG246
       jmp      G_M000_IG337
 
G_M000_IG476:                ;; offset=0x3760
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG477:                ;; offset=0x3766
       lea      rcx, [rbp+0xA78]
       mov      rdx, 0x23AEEE12A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG75
 
G_M000_IG478:                ;; offset=0x3782
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG479:                ;; offset=0x3788
       vzeroupper 
       add      rsp, 0xF48
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG480:                ;; offset=0x379F
       mov      eax, 1
 
G_M000_IG481:                ;; offset=0x37A4
       vzeroupper 
       add      rsp, 0xF48
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG482:                ;; offset=0x37BB
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
 
G_M000_IG483:                ;; offset=0x37CD
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG484:                ;; offset=0x37F2
       vzeroupper 
       add      rsp, 0xF48
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG485:                ;; offset=0x3809
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG487
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG486:                ;; offset=0x383D
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      G_M000_IG480
 
G_M000_IG487:                ;; offset=0x3852
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG488:                ;; offset=0x385B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG489:                ;; offset=0x3861
       sub      rsp, 72
 
G_M000_IG490:                ;; offset=0x3865
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG492
 
G_M000_IG491:                ;; offset=0x3872
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG492:                ;; offset=0x3878
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG495
 
G_M000_IG493:                ;; offset=0x389C
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG478
 
G_M000_IG494:                ;; offset=0x38AD
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG495:                ;; offset=0x38B5
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG496:                ;; offset=0x38C6
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG497:                ;; offset=0x38CE
       sub      rsp, 72
 
G_M000_IG498:                ;; offset=0x38D2
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG500
 
G_M000_IG499:                ;; offset=0x3900
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG500:                ;; offset=0x3906
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG501:                ;; offset=0x3917
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000006B3h ; case G_M000_IG69
       	dd	0000064Bh ; case G_M000_IG68
       	dd	000000E6h ; case G_M000_IG12
       	dd	00000DFFh ; case G_M000_IG125
       	dd	00000D95h ; case G_M000_IG124
       	dd	00000D01h ; case G_M000_IG122
       	dd	00000C8Eh ; case G_M000_IG118
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	0000208Bh ; case G_M000_IG292
       	dd	0000208Bh ; case G_M000_IG292
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D90h ; case G_M000_IG266
       	dd	00001D61h ; case G_M000_IG265
       	dd	00001D61h ; case G_M000_IG265
       	dd	00001D3Bh ; case G_M000_IG263
       	dd	00001D14h ; case G_M000_IG262
       	dd	00001CECh ; case G_M000_IG261
       	dd	00001C5Ah ; case G_M000_IG259
       	dd	00001BB1h ; case G_M000_IG257
       	dd	00001B41h ; case G_M000_IG256
       	dd	00001AFEh ; case G_M000_IG255
       	dd	00001A81h ; case G_M000_IG254
       	dd	000019BFh ; case G_M000_IG249
       	dd	00001992h ; case G_M000_IG247
       	dd	00001992h ; case G_M000_IG247
       	dd	00001992h ; case G_M000_IG247
       	dd	0000195Dh ; case G_M000_IG244
       	dd	0000195Dh ; case G_M000_IG244
       	dd	0000195Dh ; case G_M000_IG244
       	dd	00001992h ; case G_M000_IG247
       	dd	000016F2h ; case G_M000_IG215
       	dd	00000AF7h ; case G_M000_IG100
       	dd	000020E9h ; case G_M000_IG293
       	dd	00002061h ; case G_M000_IG291
       	dd	00002041h ; case G_M000_IG289
       	dd	0000202Eh ; case G_M000_IG288
       	dd	00002000h ; case G_M000_IG287
       	dd	00002000h ; case G_M000_IG287
       	dd	00002000h ; case G_M000_IG287
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001EE3h ; case G_M000_IG278
       	dd	00001E8Bh ; case G_M000_IG276
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	000019E1h ; case G_M000_IG251
       	dd	00000831h ; case G_M000_IG79
       	dd	000007F7h ; case G_M000_IG76
       	dd	00001F5Ch ; case G_M000_IG282
       	dd	00000ED0h ; case G_M000_IG132
       	dd	00000ED0h ; case G_M000_IG132
       	dd	00000ED0h ; case G_M000_IG132
       	dd	00000ED0h ; case G_M000_IG132
       	dd	00000ED0h ; case G_M000_IG132
       	dd	00000E97h ; case G_M000_IG130
       	dd	00000ACEh ; case G_M000_IG98
       	dd	0000099Dh ; case G_M000_IG90
       	dd	000008E6h ; case G_M000_IG83
       	dd	000008AEh ; case G_M000_IG82
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 14623

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x480
       lea      rbp, [rsp+0x480]
       xor      eax, eax
       mov      qword ptr [rbp-0x438], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x430], xmm4
       mov      rax, -0x420
 
G_M000_IG88:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG88
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x004E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      gword ptr [rbp-0x260], rax
       mov      rcx, gword ptr [rbp-0x260]
       mov      rdx, 0x7FF9D7A0C748
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x260]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2A4], eax
       mov      rcx, gword ptr [rbp-0x2A0]
       mov      edx, dword ptr [rbp-0x2A4]
       mov      r11, 0x7FF9D70920A0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x00F7
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2B8], xmm0
 
G_M000_IG04:                ;; offset=0x0104
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x38]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, gword ptr [rbp-0x2C0]
       lea      rdx, [rbp-0x2B8]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x38]
       mov      r9, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedCall(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG12
       lea      rcx, [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, gword ptr [rbp-0x268]
       mov      rdx, 0x7FF9D7A0C850
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdx, 0x7FF9D7A0C958
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rcx, gword ptr [rbp-0x2D0]
       mov      r11, 0x7FF9D70920C0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x01F6
       mov      rcx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG06:                ;; offset=0x0200
       mov      rcx, 0x7FF9D7A0CA60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x021F
       vzeroupper 
       add      rsp, 0x480
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x022B
       mov      rcx, 0x7FF9D7A0CA64
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x023A
       vmovdqu  xmm0, xmmword ptr [rbp-0x38]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG10:                ;; offset=0x0247
       lea      r8, [rbp-0x2E0]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG11:                ;; offset=0x0261
       vzeroupper 
       add      rsp, 0x480
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x026D
       mov      rcx, 0x7FF9D7A0CA68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x0C]
       add      eax, 2
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], eax
 
G_M000_IG13:                ;; offset=0x0289
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xF4], eax
       mov      rax, bword ptr [rbp-0xF0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xF4], eax
       jae      G_M000_IG77
       mov      rax, bword ptr [rbp-0xF0]
       mov      ecx, dword ptr [rbp-0xF4]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG14:                ;; offset=0x030E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG64
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG75
 
G_M000_IG15:                ;; offset=0x034F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x218], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x21C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2EC], eax
       mov      r9d, dword ptr [rbp-0x2EC]
       lea      rdx, [rbp-0x230]
       mov      r8d, dword ptr [rbp-0x21C]
       mov      rcx, bword ptr [rbp-0x218]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG16:                ;; offset=0x03D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x230]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG17:                ;; offset=0x03E3
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rdx, gword ptr [rbp-0x308]
       lea      rcx, [rbp-0x300]
       lea      r9, [rbp-0x50]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, 0x7FF9D7A0CA6C
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG75
 
G_M000_IG18:                ;; offset=0x0433
       mov      rcx, 0x7FF9D7A0CA70
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0444
       mov      rcx, 0x7FF9D7A0CA74
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG20:                ;; offset=0x0466
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG55
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76A4690
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x120], rax
       mov      rax, bword ptr [rbp-0x120]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG59
       mov      rax, bword ptr [rbp-0x120]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG36
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, 0x7FF9D75B1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x68], rax
       cmp      gword ptr [rbp-0x68], 0
       je       G_M000_IG31
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x310], rax
       mov      rdx, gword ptr [rbp-0x310]
       mov      rcx, 0x7FF9D76A31D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp-0x70]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG21:                ;; offset=0x055C
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG22:                ;; offset=0x0594
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
 
G_M000_IG23:                ;; offset=0x05A0
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, gword ptr [rbp-0x278]
       mov      rdx, 0x7FF9D7A0CA78
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x278]
       mov      gword ptr [rbp-0x318], rax
       lea      rcx, [rbp-0xA8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x31C], eax
       mov      rcx, gword ptr [rbp-0x318]
       mov      edx, dword ptr [rbp-0x31C]
       mov      r11, 0x7FF9D70920B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xB0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rcx, gword ptr [rbp-0x70]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, gword ptr [rbp-0x328]
       mov      rcx, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG24:                ;; offset=0x0656
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1A8], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rcx, gword ptr [rbp-0xB0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG26
       mov      rax, bword ptr [rbp-0x1B0]
       mov      bword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x210]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rcx, gword ptr [rbp-0xB0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0741
       mov      rcx, 0x7FF9D7A0CB80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x208]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x210]
       mov      gword ptr [rbp-0x1E8], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0792
       mov      rcx, 0x7FF9D7A0CB84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x1B0]
       mov      bword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x1B8]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rbp-0x1E8], rax
       mov      dword ptr [rbp-0x1EC], 1
 
G_M000_IG27:                ;; offset=0x07E3
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      r8, gword ptr [rbp-0x1E8]
       mov      r9d, dword ptr [rbp-0x1EC]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x330], rax
       mov      rdx, gword ptr [rbp-0x330]
       mov      rcx, bword ptr [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG28:                ;; offset=0x0821
       call     G_M000_IG78
       jmp      SHORT G_M000_IG33
 
G_M000_IG29:                ;; offset=0x0828
       mov      rcx, 0x7FF9D7A0CB88
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG36
 
G_M000_IG30:                ;; offset=0x083C
       mov      rcx, 0x7FF9D7A0CB8C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG31:                ;; offset=0x084D
       mov      rcx, 0x7FF9D7A0CB90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x085E
       mov      rcx, 0x7FF9D7A0CB94
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG55
 
G_M000_IG33:                ;; offset=0x0872
       mov      rcx, 0x7FF9D7A0CB9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG34:                ;; offset=0x0889
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG35:                ;; offset=0x0896
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0xA8]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG75
 
G_M000_IG36:                ;; offset=0x08BA
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      rcx, 0x7FF9D77F3330
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x78], rax
       cmp      gword ptr [rbp-0x78], 0
       je       G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG45
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG37:                ;; offset=0x0937
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x358], xmm0
 
G_M000_IG38:                ;; offset=0x0944
       lea      rdx, [rbp-0x358]
       lea      rcx, [rbp-0x168]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG39:                ;; offset=0x0958
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG40:                ;; offset=0x0968
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG44
       mov      rcx, 0x7FF9D7A0CBA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rax, gword ptr [rbp-0x170]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, gword ptr [rbp-0x280]
       mov      rdx, 0x7FF9D7A0CBA8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rbp-0x370], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rcx, gword ptr [rbp-0x370]
       mov      edx, dword ptr [rbp-0x374]
       mov      r11, 0x7FF9D70920B0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0x178], rax
       movzx    rax, byte  ptr [rbp-0x88]
       mov      dword ptr [rbp-0x17C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0xB8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
 
G_M000_IG41:                ;; offset=0x0A8E
       mov      gword ptr [rbp-0x190], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG42:                ;; offset=0x0AAD
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x388], xmm0
 
G_M000_IG43:                ;; offset=0x0ABD
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x388]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x178]
       mov      r8d, dword ptr [rbp-0x17C]
       mov      r9, gword ptr [rbp-0x188]
       mov      rcx, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x390], rax
       mov      rdx, gword ptr [rbp-0x390]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG64
 
G_M000_IG44:                ;; offset=0x0B1A
       mov      rcx, 0x7FF9D7A0CCB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0B2B
       mov      rcx, 0x7FF9D7A0CCB4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG46:                ;; offset=0x0B3A
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x128], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG47:                ;; offset=0x0B4D
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x3A0], xmm0
 
G_M000_IG48:                ;; offset=0x0B5A
       lea      rdx, [rbp-0x3A0]
       lea      rcx, [rbp-0x138]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG49:                ;; offset=0x0B6E
       vmovdqu  xmm0, xmmword ptr [rbp-0x138]
       vmovdqu  xmmword ptr [rbp-0x3B0], xmm0
 
G_M000_IG50:                ;; offset=0x0B7E
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x3B0]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG53
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x140], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x144], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      r9d, dword ptr [rbp-0x3B4]
       lea      rdx, [rbp-0x158]
       mov      r8d, dword ptr [rbp-0x144]
       mov      rcx, bword ptr [rbp-0x140]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG51:                ;; offset=0x0C30
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0x3C8], xmm0
 
G_M000_IG52:                ;; offset=0x0C40
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x3D0]
       lea      r8, [rbp-0x3C8]
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rcx, 0x7FF9D7A0CCB8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG75
 
G_M000_IG53:                ;; offset=0x0CA5
       mov      rcx, 0x7FF9D7A0CCBC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG64
 
G_M000_IG54:                ;; offset=0x0CB9
       mov      rcx, 0x7FF9D7A0CCC0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG55:                ;; offset=0x0CDE
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG56:                ;; offset=0x0CE2
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x3E0], xmm0
 
G_M000_IG57:                ;; offset=0x0CEF
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x3E0]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG62
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rcx, gword ptr [rbp-0x288]
       mov      rdx, 0x7FF9D7A0CCC8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x288]
       mov      gword ptr [rbp-0x3E8], rax
       mov      rdx, gword ptr [rbp-0x3E8]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xD8], rax
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG60
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x290], rax
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdx, 0x7FF9D7A0CDD0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x290]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rcx, gword ptr [rbp-0x3F0]
       mov      r11, 0x7FF9D70920A8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG61
 
G_M000_IG58:                ;; offset=0x0DDC
       mov      rcx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x0DE9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0DEF
       mov      rcx, 0x7FF9D7A0CED8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0E00
       mov      rcx, 0x7FF9D7A0CEDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xD8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG75
 
G_M000_IG62:                ;; offset=0x0E2A
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG63
       mov      rcx, 0x7FF9D7A0CEE0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG75
 
G_M000_IG63:                ;; offset=0x0E66
       mov      rcx, 0x7FF9D7A0CEE4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG64:                ;; offset=0x0E75
       nop      
 
G_M000_IG65:                ;; offset=0x0E76
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG70
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG69
       mov      rcx, 0x7FF9D7A0CFF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x100], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x408], rax
       mov      rdx, gword ptr [rbp-0x408]
       mov      rcx, gword ptr [rbp-0x100]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x40C], eax
       mov      edx, dword ptr [rbp-0x40C]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG66:                ;; offset=0x0F65
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x410], eax
       mov      r9d, dword ptr [rbp-0x410]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0x108]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG67:                ;; offset=0x0FA1
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x420], xmm0
 
G_M000_IG68:                ;; offset=0x0FB1
       lea      rcx, [rbp-0x420]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG73
 
G_M000_IG69:                ;; offset=0x0FC0
       mov      rcx, 0x7FF9D7A0CFFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x0FCF
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x438], rax
 
G_M000_IG71:                ;; offset=0x0FFD
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x430], xmm0
 
G_M000_IG72:                ;; offset=0x100A
       mov      rdx, bword ptr [rbp-0x438]
       lea      r8, [rbp-0x430]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG73:                ;; offset=0x1022
       mov      rcx, 0x7FF9D7A0D000
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG74:                ;; offset=0x1036
       vzeroupper 
       add      rsp, 0x480
       pop      rbp
       ret      
 
G_M000_IG75:                ;; offset=0x1042
       mov      rcx, 0x7FF9D7A0D004
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x44]
 
G_M000_IG76:                ;; offset=0x1054
       vzeroupper 
       add      rsp, 0x480
       pop      rbp
       ret      
 
G_M000_IG77:                ;; offset=0x1060
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG78:                ;; offset=0x1066
       sub      rsp, 72
 
G_M000_IG79:                ;; offset=0x106A
       mov      rcx, 0x7FF9D7A0CB98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG80:                ;; offset=0x108A
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG81:                ;; offset=0x1092
       sub      rsp, 72
 
G_M000_IG82:                ;; offset=0x1096
       mov      gword ptr [rbp-0x238], rcx
       mov      rax, gword ptr [rbp-0x238]
       mov      gword ptr [rbp-0x298], rax
       mov      rcx, gword ptr [rbp-0x298]
       mov      rdx, 0x7FF9D7A0CEE8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x298]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rdx, gword ptr [rbp-0x3F8]
       mov      rcx, 0x7FF9D7192168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x240], rax
       mov      rax, gword ptr [rbp-0x240]
       mov      gword ptr [rbp-0x248], rax
       cmp      gword ptr [rbp-0x240], 0
       jne      SHORT G_M000_IG83
       xor      eax, eax
       mov      dword ptr [rbp-0x24C], eax
       jmp      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x110F
       mov      rcx, 0x7FF9D7A0CFF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x400], rax
       mov      rdx, gword ptr [rbp-0x400]
       lea      r8, [rbp-0xE0]
       mov      rcx, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x24C], eax
 
G_M000_IG84:                ;; offset=0x115A
       mov      rcx, 0x7FF9D7A0CFF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x24C]
 
G_M000_IG85:                ;; offset=0x116F
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG86:                ;; offset=0x1177
       sub      rsp, 72
 
G_M000_IG87:                ;; offset=0x117B
       mov      gword ptr [rbp-0x258], rcx
       mov      rcx, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4495

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 213720
; 33 inlinees with PGO data; 132 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x180]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -192
 
G_M000_IG175:                ;; offset=0x0032
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG175
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbx+0x1C], 42
       jne      G_M000_IG140
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG142
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG141
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG03:                ;; offset=0x0092
       mov      gword ptr [rbp-0x110], rsi
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00A1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG143
 
G_M000_IG05:                ;; offset=0x00B5
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG06:                ;; offset=0x00B8
       cmp      dword ptr [rbx+0x10], 0
       jl       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x00BE
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x48]
       mov      rax, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, edi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG163
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x21AC8401CE0
       cmp      r14, gword ptr [rax]
       je       G_M000_IG157
 
G_M000_IG08:                ;; offset=0x00FB
       mov      rax, 0x21AC8401CE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG158
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG159
 
G_M000_IG09:                ;; offset=0x0119
       test     r14, r14
       je       G_M000_IG160
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       jmp      G_M000_IG36
 
G_M000_IG10:                ;; offset=0x0130
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x08]
       mov      r15, bword ptr [rcx+0x48]
       mov      r13d, dword ptr [rcx+0x50]
       mov      r12d, dword ptr [rcx+0x38]
       mov      rax, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x118], rax
       mov      edx, dword ptr [rbx+0x10]
       not      edx
       mov      r9, gword ptr [r14+0x30]
       cmp      dword ptr [r9+0x08], edx
       jg       G_M000_IG144
 
G_M000_IG11:                ;; offset=0x0162
       mov      r9, gword ptr [r14+0x38]
       mov      r8, gword ptr [r14+0x30]
       mov      r10d, edx
       sub      r10d, dword ptr [r8+0x08]
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG163
       mov      r8d, r10d
       mov      r10, gword ptr [r9+8*r8+0x10]
       mov      gword ptr [rbp-0x128], r10
       mov      r9, gword ptr [r14+0x30]
       sub      edx, dword ptr [r9+0x08]
       lea      r9, [rbp-0xC8]
       mov      rcx, r14
       mov      r8, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, gword ptr [rbp-0xC8]
 
G_M000_IG12:                ;; offset=0x01B4
       xor      rcx, rcx
       mov      gword ptr [rbp-0xC8], rcx
       mov      edx, dword ptr [rbx+0x0C]
       mov      dword ptr [rbp-0xCC], edx
       test     edx, edx
       jl       G_M000_IG30
 
G_M000_IG13:                ;; offset=0x01CE
       mov      gword ptr [rbp-0x120], rax
       cmp      edx, r13d
       jae      G_M000_IG163
       mov      ecx, edx
       shl      rcx, 4
       add      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rcx, rax
       mov      eax, dword ptr [rbp-0xCC]
       cmp      eax, dword ptr [r14+0xD8]
       jge      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x01FF
       test     rcx, rcx
       je       SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0204
       mov      rdx, 0x7FF9D77E4838
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0213
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG17:                ;; offset=0x021C
       test     rcx, rcx
       je       G_M000_IG148
 
G_M000_IG18:                ;; offset=0x0225
       test     rcx, rcx
       je       G_M000_IG149
       mov      r12, rcx
 
G_M000_IG19:                ;; offset=0x0231
       xor      rdx, rdx
       mov      gword ptr [rbp-0xD8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
       mov      r14, gword ptr [rbp-0x120]
       mov      rcx, r14
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0252
       mov      rdx, 0x7FF9D77E3D68
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG150
 
G_M000_IG21:                ;; offset=0x0265
       xor      rcx, rcx
 
G_M000_IG22:                ;; offset=0x0267
       test     rcx, rcx
       jne      G_M000_IG32
 
G_M000_IG23:                ;; offset=0x0270
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0278
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG152
 
G_M000_IG25:                ;; offset=0x028C
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG26:                ;; offset=0x028F
       cmp      eax, r13d
       jae      G_M000_IG163
       mov      eax, eax
       shl      rax, 4
       add      rax, r15
       mov      bword ptr [rbp-0x140], rax
       mov      rcx, rax
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      r14, bword ptr [rbp-0x140]
       mov      qword ptr [r14+0x08], rcx
       mov      ecx, dword ptr [rbx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02C8
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG153
 
G_M000_IG28:                ;; offset=0x02DC
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG29:                ;; offset=0x02DF
       inc      eax
       cmp      eax, r13d
       jae      G_M000_IG163
       mov      ebx, eax
       shl      rbx, 4
       add      rbx, r15
       mov      rcx, rbx
       mov      rdx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       lea      ecx, [rdi+0x02]
       mov      rbx, bword ptr [rbp+0x10]
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG07
 
G_M000_IG30:                ;; offset=0x0313
       not      edx
       mov      r10, gword ptr [r14+0x30]
       cmp      dword ptr [r10+0x08], edx
       jg       G_M000_IG146
 
G_M000_IG31:                ;; offset=0x0323
       mov      gword ptr [rbp-0x120], rax
       mov      r9, gword ptr [r14+0x38]
       mov      ecx, edx
       sub      ecx, dword ptr [r10+0x08]
       cmp      ecx, dword ptr [r9+0x08]
       jae      G_M000_IG163
       mov      r11, gword ptr [r9+8*rcx+0x10]
       mov      gword ptr [rbp-0x130], r11
       sub      edx, dword ptr [r10+0x08]
       lea      r9, [rbp-0xD8]
       mov      rcx, r14
       mov      r8, gword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG147
       mov      r12, gword ptr [rbp-0xD8]
       jmp      G_M000_IG19
 
G_M000_IG32:                ;; offset=0x0379
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0x138], rax
       mov      rdx, r12
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,bool):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       test     rax, rax
       je       G_M000_IG23
 
G_M000_IG33:                ;; offset=0x0398
       mov      r13, gword ptr [rbp-0x118]
       mov      gword ptr [rsp+0x20], r13
       lea      rcx, [rbp-0x58]
       mov      rdx, r12
       mov      r8, rax
       mov      r9, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime:InvokeSingleInput(System.Object,System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rdx, gword ptr [rbp-0x58]
       mov      r15, rdx
       test     r15, r15
       je       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x03C7
       mov      rcx, 0x7FF9D70847B0
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG151
       xor      r15, r15
 
G_M000_IG35:                ;; offset=0x03DD
       test     r15, r15
       jne      G_M000_IG154
       lea      r8, [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG138
 
G_M000_IG36:                ;; offset=0x03FC
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG99
 
G_M000_IG37:                ;; offset=0x0406
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG100
 
G_M000_IG38:                ;; offset=0x0410
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG96
 
G_M000_IG39:                ;; offset=0x041A
       mov      rax, 0x7FF9D76A4690
       cmp      qword ptr [r14], rax
       jne      G_M000_IG96
 
G_M000_IG40:                ;; offset=0x042D
       mov      rax, rbx
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG129
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      rax, gword ptr [rdx]
       mov      r8, 0x21AC8401CE0
       cmp      rax, gword ptr [r8]
       je       G_M000_IG104
 
G_M000_IG41:                ;; offset=0x0458
       mov      rax, gword ptr [rdx]
       mov      r8, 0x21AC8401CE8
       cmp      rax, gword ptr [r8]
       je       G_M000_IG105
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG106
       mov      r15, gword ptr [rdx]
 
G_M000_IG42:                ;; offset=0x047C
       cmp      dword ptr [rsi+0x28], 0
       jne      G_M000_IG82
       test     r15, r15
       je       G_M000_IG82
 
G_M000_IG43:                ;; offset=0x048F
       mov      rax, 0x7FF9D75B1030
       cmp      qword ptr [r15], rax
       jne      G_M000_IG82
 
G_M000_IG44:                ;; offset=0x04A2
       mov      r13, r15
       mov      r12, gword ptr [rsi+0x20]
       test     r12, r12
       je       G_M000_IG82
 
G_M000_IG45:                ;; offset=0x04B2
       mov      rax, 0x7FF9D76A31D0
       cmp      qword ptr [r12], rax
       jne      G_M000_IG82
 
G_M000_IG46:                ;; offset=0x04C6
       cmp      r14, gword ptr [r12+0x08]
       jne      G_M000_IG82
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       add      edx, 2
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG129
       shl      rdx, 5
 
G_M000_IG47:                ;; offset=0x04F3
       vmovdqu  ymm0, ymmword ptr [rax+rdx+0x10]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG48:                ;; offset=0x0501
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbp-0x74], 42
       jne      G_M000_IG107
       mov      edx, dword ptr [rbp-0x88]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG109
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG108
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG49:                ;; offset=0x0541
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rax, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG50:                ;; offset=0x0561
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rsi+0x31], 0
       jne      G_M000_IG62
       cmp      byte  ptr [r15+0x40], 0
       je       G_M000_IG61
       movzx    r14, byte  ptr [rsi+0x32]
 
G_M000_IG51:                ;; offset=0x0583
       mov      rdx, gword ptr [r12+0x10]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG64
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG63
 
G_M000_IG52:                ;; offset=0x05B1
       mov      rdx, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG66
 
G_M000_IG53:                ;; offset=0x05CF
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG65
 
G_M000_IG54:                ;; offset=0x05DF
       mov      rdx, gword ptr [r12+0x20]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG68
 
G_M000_IG55:                ;; offset=0x05FD
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG67
 
G_M000_IG56:                ;; offset=0x060D
       mov      rdx, gword ptr [r12+0x28]
       mov      rcx, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG70
 
G_M000_IG57:                ;; offset=0x062B
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG69
 
G_M000_IG58:                ;; offset=0x063B
       test     r14d, r14d
       je       G_M000_IG71
 
G_M000_IG59:                ;; offset=0x0644
       movzx    rdx, byte  ptr [r12+0x30]
       mov      r9, gword ptr [r12+0x28]
       mov      rcx, r13
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.Text.PyStringOps:PrepareCasedWhitespaceIteration(Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration]
 
G_M000_IG60:                ;; offset=0x065B
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
       jmp      G_M000_IG72
 
G_M000_IG61:                ;; offset=0x066A
       xor      r14d, r14d
       jmp      G_M000_IG51
 
G_M000_IG62:                ;; offset=0x0672
       mov      r14d, 1
       jmp      G_M000_IG51
 
G_M000_IG63:                ;; offset=0x067D
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG52
 
G_M000_IG64:                ;; offset=0x068F
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG52
 
G_M000_IG65:                ;; offset=0x069A
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG54
 
G_M000_IG66:                ;; offset=0x06AC
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG54
 
G_M000_IG67:                ;; offset=0x06B7
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG56
 
G_M000_IG68:                ;; offset=0x06C9
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG56
 
G_M000_IG69:                ;; offset=0x06D4
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG58
 
G_M000_IG70:                ;; offset=0x06E6
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG58
 
G_M000_IG71:                ;; offset=0x06F1
       movzx    rdx, byte  ptr [r12+0x30]
       mov      gword ptr [rsp+0x20], rdi
       mov      r8, gword ptr [rdi+0x98]
       mov      r8, gword ptr [r8+0x88]
       mov      r9, gword ptr [r12+0x28]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.Text.PyStringOps:SplitCasedWhitespace(Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       jmp      G_M000_IG60
 
G_M000_IG72:                ;; offset=0x071D
       mov      rsi, gword ptr [r15+0x10]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [rdi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0734
       dec      rcx
       mov      qword ptr [rdi+0x160], rcx
 
G_M000_IG74:                ;; offset=0x073E
       add      dword ptr [r15+0x38], 2
 
G_M000_IG75:                ;; offset=0x0743
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG76:                ;; offset=0x0750
       cmp      dword ptr [rbp-0x78], 0
       jl       G_M000_IG112
       mov      ecx, dword ptr [rbp-0x74]
       cmp      ecx, 51
       ja       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0762
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG110
 
G_M000_IG78:                ;; offset=0x0776
       mov      esi, dword ptr [rbp-0x7C]
 
G_M000_IG79:                ;; offset=0x0779
       mov      ecx, dword ptr [rbp-0x78]
       mov      edi, ecx
       not      edi
       test     ecx, ecx
       cmovge   edi, ecx
       mov      r14, gword ptr [rbp-0xE8]
       mov      r13, qword ptr [rbp-0xE0]
       cmp      edi, dword ptr [r15+0x3C]
       jl       G_M000_IG111
 
G_M000_IG80:                ;; offset=0x079D
       cmp      esi, dword ptr [rbx+0x08]
       jae      G_M000_IG129
       mov      esi, esi
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rcx, rsi
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r13
       mov      dword ptr [r15+0x3C], edi
 
G_M000_IG81:                ;; offset=0x07C2
       mov      eax, 1
       jmp      G_M000_IG130
 
G_M000_IG82:                ;; offset=0x07CC
       mov      rdx, gword ptr [rsi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x07D5
       mov      rax, 0x7FF9D77F3330
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG84:                ;; offset=0x07E9
       mov      r13, rdx
       test     r13, r13
       je       G_M000_IG90
 
G_M000_IG85:                ;; offset=0x07F5
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      eax, dword ptr [rcx+0x38]
       add      eax, 3
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG129
       shl      rax, 5
       cmp      dword ptr [rdx+rax+0x20], edi
       jne      G_M000_IG90
 
G_M000_IG86:                ;; offset=0x0821
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG87:                ;; offset=0x082D
       lea      rdx, [rbp-0xF8]
       lea      rcx, [rbp-0xC0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       lea      r8, [rbp-0x68]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x70]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xC0]
       mov      rcx, rsi
       mov      rdx, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG90
 
G_M000_IG88:                ;; offset=0x0871
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x08]
       mov      r14, gword ptr [rcx+0xB0]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [r15+0x38]
       add      edx, 3
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG129
       shl      rdx, 5
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      edx, 42
       mov      r8, 0x23AEEE0D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, r14
       mov      r11, 0x7FF9D70925F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, gword ptr [rbp-0x68]
       movzx    r8, byte  ptr [rbp-0x70]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rcx
       xor      rcx, rcx
       mov      bword ptr [rbp-0xF8], rcx
 
G_M000_IG89:                ;; offset=0x08E6
       mov      dword ptr [rbp-0xF0], ecx
       mov      rcx, gword ptr [r15+0x10]
       mov      gword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF8]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x48], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x40], rdx
       add      dword ptr [r15+0x38], 3
       jmp      G_M000_IG131
 
G_M000_IG90:                ;; offset=0x091E
       mov      rcx, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rcx+0x08]
 
G_M000_IG91:                ;; offset=0x0926
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG92:                ;; offset=0x0932
       lea      rdx, [rbp-0xF8]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], rsi
       mov      dword ptr [rsp+0x28], edi
       mov      r12, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], r9
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x38], r9
       lea      r9, bword ptr [r12+0x38]
       lea      r8, [rbp-0xB0]
       mov      rcx, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG131
 
G_M000_IG93:                ;; offset=0x0986
       mov      r8, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rdi+r9+0x01]
       mov      edx, dword ptr [rsi+0x28]
       mov      ecx, edx
       add      rcx, r9
       mov      eax, dword ptr [r8+0x08]
       cmp      rcx, rax
       ja       G_M000_IG102
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0xF8], r9
       mov      dword ptr [rbp-0xF0], edx
       mov      r8, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x98]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xF8]
       mov      r9, gword ptr [rsi+0x18]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG98
 
G_M000_IG94:                ;; offset=0x09F8
       mov      r8, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x48], r8
 
G_M000_IG95:                ;; offset=0x0A03
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG131
 
G_M000_IG96:                ;; offset=0x0A0E
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG97:                ;; offset=0x0A1A
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, r14
       mov      rcx, rsi
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG127
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG131
 
G_M000_IG98:                ;; offset=0x0A7A
       xor      eax, eax
       jmp      G_M000_IG130
 
G_M000_IG99:                ;; offset=0x0A81
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG131
       jmp      SHORT G_M000_IG98
 
G_M000_IG100:                ;; offset=0x0AA7
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG38
 
G_M000_IG101:                ;; offset=0x0AB8
       mov      rdx, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0AE2
       mov      r12, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG103:                ;; offset=0x0AED
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0xF8], r8
       mov      dword ptr [rbp-0xF0], r9d
       lea      rcx, [rbp-0xF8]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r15+0x10]
       lea      r9, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG98
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x48], rax
       mov      r12, r15
       jmp      G_M000_IG95
 
G_M000_IG104:                ;; offset=0x0B3A
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG42
 
G_M000_IG105:                ;; offset=0x0B4B
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG42
 
G_M000_IG106:                ;; offset=0x0B5C
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG42
 
G_M000_IG107:                ;; offset=0x0B6D
       lea      rcx, [rbp-0x90]
       mov      rdx, 0x23AEEE0D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG108:                ;; offset=0x0B8D
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG109:                ;; offset=0x0B94
       mov      rcx, rax
       mov      r11, 0x7FF9D70925F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG49
 
G_M000_IG110:                ;; offset=0x0BAC
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       jmp      G_M000_IG79
 
G_M000_IG111:                ;; offset=0x0BC0
       mov      rcx, r15
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG80
 
G_M000_IG112:                ;; offset=0x0BD0
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       cmp      eax, dword ptr [r15+0x3C]
       jge      SHORT G_M000_IG113
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG113:                ;; offset=0x0BFB
       mov      rcx, gword ptr [r15+0x10]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG116
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ebx, eax
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG114:                ;; offset=0x0C31
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG115:                ;; offset=0x0C41
       mov      edx, ebx
       lea      r9, [rbp-0x108]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      r15, bword ptr [rbp+0x10]
       jmp      G_M000_IG81
 
G_M000_IG116:                ;; offset=0x0C5C
       mov      rsi, rbx
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG129
       mov      rcx, bword ptr [rsi]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [r15+0x3C], eax
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r15+0x38]
       inc      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG129
       shl      rax, 5
       lea      rsi, bword ptr [rcx+rax+0x10]
       cmp      dword ptr [rsi+0x1C], 25
       jne      SHORT G_M000_IG120
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StoresCapturedLocal():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG117
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG129
       mov      esi, eax
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rdx, gword ptr [rbp-0xE8]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xE0]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG126
 
G_M000_IG117:                ;; offset=0x0D0A
       mov      rcx, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
 
G_M000_IG118:                ;; offset=0x0D15
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG119:                ;; offset=0x0D25
       lea      r8, [rbp-0x108]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreCapturedLocal(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG126
 
G_M000_IG120:                ;; offset=0x0D3A
       cmp      dword ptr [rsi+0x1C], 71
       jne      SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0D40
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG122:                ;; offset=0x0D4C
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG123:                ;; offset=0x0D5C
       lea      rcx, [rbp-0xF8]
       lea      r8, [rbp-0x108]
       mov      r9, gword ptr [r15+0x10]
       mov      r9, gword ptr [r9+0x98]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      SHORT G_M000_IG126
 
G_M000_IG124:                ;; offset=0x0D80
       cmp      dword ptr [rsi+0x1C], 30
       je       SHORT G_M000_IG125
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE12BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG125:                ;; offset=0x0DB4
       cmp      gword ptr [rbp-0xE8], 0
       jne      SHORT G_M000_IG126
       lea      rcx, [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG126:                ;; offset=0x0DDE
       inc      dword ptr [r15+0x38]
       jmp      G_M000_IG81
 
G_M000_IG127:                ;; offset=0x0DE7
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG131
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9D70925E8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG128:                ;; offset=0x0E2B
       mov      gword ptr [r15+0x28], r14
       jmp      G_M000_IG98
 
G_M000_IG129:                ;; offset=0x0E34
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG130:                ;; offset=0x0E3A
       vzeroupper 
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG131:                ;; offset=0x0E51
       cmp      dword ptr [rsi+0x2C], 0
       je       G_M000_IG135
 
G_M000_IG132:                ;; offset=0x0E5B
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r15+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG163
       shl      rax, 5
       cmp      dword ptr [rcx+rax+0x2C], 15
       jne      G_M000_IG135
 
G_M000_IG133:                ;; offset=0x0E86
       mov      rcx, gword ptr [r15+0x10]
       mov      rax, gword ptr [r15+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [r15+0x38]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG163
       shl      rdx, 5
       mov      r14, gword ptr [rax+rdx+0x10]
       mov      r13, gword ptr [rcx+0x98]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG161
 
G_M000_IG134:                ;; offset=0x0EC7
       mov      edx, edi
       add      edx, dword ptr [rsi+0x2C]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, rbx
       mov      eax, dword ptr [rsi+0x2C]
       mov      edx, edi
       mov      r8d, eax
       add      rdx, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rdx, r8
       ja       G_M000_IG162
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rbp-0xF8], rdx
       mov      dword ptr [rbp-0xF0], eax
       lea      rcx, [rbp-0xF8]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG138
 
G_M000_IG135:                ;; offset=0x0F15
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [r15+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG163
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG136:                ;; offset=0x0F3B
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG137:                ;; offset=0x0F48
       lea      r8, [rbp-0x108]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG138:                ;; offset=0x0F58
       mov      eax, 1
 
G_M000_IG139:                ;; offset=0x0F5D
       vzeroupper 
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG140:                ;; offset=0x0F74
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG141:                ;; offset=0x0F90
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG142:                ;; offset=0x0F97
       mov      rcx, rax
       mov      r11, 0x7FF9D70925E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG03
 
G_M000_IG143:                ;; offset=0x0FAF
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG06
 
G_M000_IG144:                ;; offset=0x0FBF
       mov      r8, gword ptr [r14+0x30]
       cmp      edx, dword ptr [r8+0x08]
       jae      G_M000_IG163
       mov      edx, edx
       mov      rcx, gword ptr [r8+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x120], rax
       mov      rax, gword ptr [rbp-0x120]
       jmp      G_M000_IG12
 
G_M000_IG145:                ;; offset=0x0FED
       mov      rcx, r14
       mov      edx, r12d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG146:                ;; offset=0x1015
       mov      gword ptr [rbp-0x120], rax
       cmp      edx, dword ptr [r10+0x08]
       jae      G_M000_IG163
       mov      ecx, edx
       mov      rcx, gword ptr [r10+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG19
 
G_M000_IG147:                ;; offset=0x103B
       mov      rcx, r14
       mov      edx, r12d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x130]
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x1066
       mov      rcx, r14
       mov      edx, r12d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, dword ptr [rbp-0xCC]
       mov      rcx, r14
       mov      r9, gword ptr [rbp-0x118]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       jmp      G_M000_IG19
 
G_M000_IG149:                ;; offset=0x1099
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG150:                ;; offset=0x10C7
       mov      rdx, r14
       mov      rcx, 0x7FF9D775AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG22
 
G_M000_IG151:                ;; offset=0x10E1
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       jmp      G_M000_IG35
 
G_M000_IG152:                ;; offset=0x10F8
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG26
 
G_M000_IG153:                ;; offset=0x1106
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG29
 
G_M000_IG154:                ;; offset=0x1114
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x08]
       mov      rcx, gword ptr [r11+0xA0]
       mov      r11, 0x7FF9D7092600
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG155
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG155:                ;; offset=0x113D
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], r15
       xor      eax, eax
 
G_M000_IG156:                ;; offset=0x1147
       vzeroupper 
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG157:                ;; offset=0x115E
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG158:                ;; offset=0x116F
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG159:                ;; offset=0x1180
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG160:                ;; offset=0x1191
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG161:                ;; offset=0x11BF
       mov      rcx, r13
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG134
 
G_M000_IG162:                ;; offset=0x11D0
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG163:                ;; offset=0x11D7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG164:                ;; offset=0x11DD
       sub      rsp, 72
 
G_M000_IG165:                ;; offset=0x11E1
       mov      r15, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r15+0x10]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [rdi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x11FC
       dec      rcx
       mov      qword ptr [rdi+0x160], rcx
 
G_M000_IG167:                ;; offset=0x1206
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG168:                ;; offset=0x120E
       sub      rsp, 72
 
G_M000_IG169:                ;; offset=0x1212
       mov      rdx, rcx
       mov      rcx, 0x7FF9D7192168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x122C
       xor      eax, eax
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x1230
       mov      rcx, gword ptr [rbp-0x110]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0xA0]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG172:                ;; offset=0x1258
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG173:                ;; offset=0x1260
       sub      rsp, 72
 
G_M000_IG174:                ;; offset=0x1264
       mov      rcx, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4721

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       xor      eax, eax
       mov      qword ptr [rbp-0xBB8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0xB70
 
G_M000_IG253:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG253
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x664], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG234
 
G_M000_IG03:                ;; offset=0x009C
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x670], rax
       mov      rdx, gword ptr [rbp-0x670]
       mov      rcx, gword ptr [rbp-0x1A8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0118
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0134
       jmp      G_M000_IG220
 
G_M000_IG07:                ;; offset=0x0139
       mov      rcx, 0x7FF9D77EA970
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG08:                ;; offset=0x0157
       mov      rcx, 0x7FF9D77EA974
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x678], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x678]
       mov      rdx, gword ptr [rbp-0x5F0]
       mov      r8d, dword ptr [rbp-0x5F4]
       mov      rcx, gword ptr [rbp-0x5E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x680], rax
       mov      r9, gword ptr [rbp-0x680]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG09:                ;; offset=0x01F4
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0244
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x200], rax
       mov      rax, gword ptr [rbp-0x200]
       mov      gword ptr [rbp-0x640], rax
       mov      rcx, gword ptr [rbp-0x640]
       mov      rdx, 0x7FF9D77EA978
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x688], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x68C], eax
       mov      rcx, gword ptr [rbp-0x688]
       mov      edx, dword ptr [rbp-0x68C]
       mov      r11, 0x7FF9D7092930
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x208], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x698], rax
       mov      rdx, gword ptr [rbp-0x698]
       mov      rcx, gword ptr [rbp-0x208]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EB
       mov      rcx, 0x7FF9D77EAA80
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG12:                ;; offset=0x02FF
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5D4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x69C], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x69C]
       mov      rdx, gword ptr [rbp-0x5D0]
       mov      r8d, dword ptr [rbp-0x5D4]
       mov      rcx, gword ptr [rbp-0x5C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77EAA84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E0], rax
       mov      rax, bword ptr [rbp-0x5E0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG224
 
G_M000_IG13:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D77EAA88
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03D0
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A8], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6A8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77EAA8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG15:                ;; offset=0x0438
       mov      rcx, 0x7FF9D77EAA90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG16:                ;; offset=0x0462
       mov      rcx, 0x7FF9D77EAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG17:                ;; offset=0x048C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77EAA98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG18:                ;; offset=0x04C0
       mov      rcx, 0x7FF9D77EAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG19:                ;; offset=0x04D4
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG20:                ;; offset=0x04EA
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F6
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6C8], ymm0
 
G_M000_IG22:                ;; offset=0x0502
       lea      r8, [rbp-0x6C8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG23:                ;; offset=0x0545
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0549
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6E8], ymm0
 
G_M000_IG25:                ;; offset=0x0555
       lea      r8, [rbp-0x6E8]
       lea      rdx, [rbp-0x580]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0575
       vmovdqu  xmm0, xmmword ptr [rbp-0x580]
       vmovdqu  xmmword ptr [rbp-0x6F8], xmm0
 
G_M000_IG27:                ;; offset=0x0585
       lea      rdx, [rbp-0x6F8]
       lea      rcx, [rbp-0x590]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB30], rax
       mov      rcx, bword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp-0x590]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB30]
       mov      rcx, qword ptr [rbp-0x588]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77EAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x700], rax
       mov      rcx, gword ptr [rbp-0x700]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG28:                ;; offset=0x0613
       mov      rcx, 0x7FF9D77EAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG29:                ;; offset=0x0631
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2D0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2E0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2E8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77EAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG30:                ;; offset=0x067E
       mov      rcx, bword ptr [rbp-0x2D0]
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      r8, bword ptr [rbp-0x2E0]
       mov      r9, gword ptr [rbp-0x2E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77EAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG31:                ;; offset=0x06C9
       mov      rcx, 0x7FF9D77EAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG32:                ;; offset=0x06DD
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77EAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F8
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x720], ymm0
 
G_M000_IG34:                ;; offset=0x0704
       lea      r8, [rbp-0x720]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG35:                ;; offset=0x0747
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074B
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x740], ymm0
 
G_M000_IG37:                ;; offset=0x0757
       lea      r8, [rbp-0x740]
       lea      rdx, [rbp-0x2F8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0777
       vmovdqu  xmm0, xmmword ptr [rbp-0x2F8]
       vmovdqu  xmmword ptr [rbp-0x750], xmm0
 
G_M000_IG39:                ;; offset=0x0787
       lea      rdx, [rbp-0x750]
       lea      rcx, [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x308]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x300]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77EAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x758], rax
       mov      rcx, gword ptr [rbp-0x758]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG40:                ;; offset=0x0815
       mov      rcx, 0x7FF9D77EAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG41:                ;; offset=0x0833
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x250]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x760], rax
       mov      rdx, gword ptr [rbp-0x760]
       mov      rcx, 0x7FF9D758EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x264], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x268], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x268]
       sub      ecx, eax
       mov      dword ptr [rbp-0x764], ecx
       mov      r9d, dword ptr [rbp-0x764]
       lea      rcx, [rbp-0x278]
       mov      rdx, gword ptr [rbp-0x260]
       mov      r8d, dword ptr [rbp-0x264]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x280], rax
 
G_M000_IG42:                ;; offset=0x0914
       vmovdqu  xmm0, xmmword ptr [rbp-0x278]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG43:                ;; offset=0x0924
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x294], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2A0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77EAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2A0], rax
 
G_M000_IG44:                ;; offset=0x0960
       mov      rcx, 0x7FF9D77EAAC4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x096F
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x778], xmm0
 
G_M000_IG46:                ;; offset=0x097F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x780], rax
       mov      rax, gword ptr [rbp-0x780]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x778]
       mov      r8d, dword ptr [rbp-0x294]
       mov      r9, gword ptr [rbp-0x2A0]
       mov      rcx, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x784], eax
       mov      edx, dword ptr [rbp-0x784]
       mov      rcx, bword ptr [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG224
 
G_M000_IG47:                ;; offset=0x09FB
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x210], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x214], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x788], eax
       mov      r9d, dword ptr [rbp-0x788]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x214]
       mov      rcx, bword ptr [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x790], rax
       mov      rdx, gword ptr [rbp-0x790]
       lea      rcx, [rbp-0x228]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x230], rax
 
G_M000_IG48:                ;; offset=0x0A89
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG49:                ;; offset=0x0A96
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x248], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77EAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x248], rax
 
G_M000_IG50:                ;; offset=0x0AC2
       mov      rcx, 0x7FF9D77EAACC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD1
       vmovdqu  xmm0, xmmword ptr [rbp-0x228]
       vmovdqu  xmmword ptr [rbp-0x7A0], xmm0
 
G_M000_IG52:                ;; offset=0x0AE1
       vmovdqu  xmm0, xmmword ptr [rbp-0x240]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG53:                ;; offset=0x0AF1
       mov      rcx, gword ptr [rbp-0x248]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7B8], rax
       mov      r9, gword ptr [rbp-0x7B8]
       lea      r8, [rbp-0x7B0]
       lea      rcx, [rbp-0x7A0]
       mov      rdx, bword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG224
 
G_M000_IG54:                ;; offset=0x0B2E
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77EAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG55:                ;; offset=0x0B77
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77EAAD4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG56:                ;; offset=0x0BB1
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7C8], xmm0
 
G_M000_IG57:                ;; offset=0x0BBE
       lea      rdx, [rbp-0x7C8]
       lea      rcx, [rbp-0x5A0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x5A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x598]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77EAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7D0], rax
       mov      rcx, gword ptr [rbp-0x7D0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG58:                ;; offset=0x0C4C
       mov      rcx, 0x7FF9D77EAADC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG59:                ;; offset=0x0C6A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77EAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG60:                ;; offset=0x0C8F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x35C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7D4], eax
       mov      r9d, dword ptr [rbp-0x7D4]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x35C]
       mov      rcx, bword ptr [rbp-0x358]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77EAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x360], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7E
       mov      rcx, 0x7FF9D77EAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D8F
       mov      rcx, 0x7FF9D77EAAEC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9E
       xor      eax, eax
       mov      dword ptr [rbp-0x360], eax
 
G_M000_IG64:                ;; offset=0x0DA6
       movzx    rax, byte  ptr [rbp-0x360]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7E8], xmm0
 
G_M000_IG66:                ;; offset=0x0DDE
       lea      r8, [rbp-0x7E8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F0], rax
       mov      rdx, gword ptr [rbp-0x7F0]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x370], rax
       mov      rax, gword ptr [rbp-0x370]
       mov      gword ptr [rbp-0x378], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x388], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E94
       mov      rcx, 0x7FF9D77EAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA8
       mov      rcx, 0x7FF9D77EAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBC
       mov      rcx, 0x7FF9D77EAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x378]
       mov      gword ptr [rbp-0x380], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x388], rax
 
G_M000_IG70:                ;; offset=0x0EF7
       mov      rcx, 0x7FF9D77EAAFC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x380]
       mov      rdx, gword ptr [rbp-0x388]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7F4], eax
       mov      edx, dword ptr [rbp-0x7F4]
       mov      rcx, bword ptr [rbp-0x390]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x398], rax
       mov      rax, bword ptr [rbp-0x398]
       add      dword ptr [rax], 2
       jmp      G_M000_IG234
 
G_M000_IG71:                ;; offset=0x0F95
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x808], xmm0
 
G_M000_IG72:                ;; offset=0x0FA5
       lea      rdx, [rbp-0x808]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x368], rax
       mov      rax, bword ptr [rbp-0x368]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77EAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG73:                ;; offset=0x1030
       mov      rcx, 0x7FF9D77EAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1041
       mov      rcx, 0x7FF9D77EAB08
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1050
       mov      rcx, 0x7FF9D77EAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG76:                ;; offset=0x106E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77EAB10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG77:                ;; offset=0x1093
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x828], ymm0
 
G_M000_IG79:                ;; offset=0x10AF
       lea      r8, [rbp-0x828]
       lea      rdx, [rbp-0x350]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x350]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x348]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77EAB14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x830], rax
       mov      rcx, gword ptr [rbp-0x830]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG80:                ;; offset=0x1143
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1152
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77EAB18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x320], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x834], eax
       mov      r8d, dword ptr [rbp-0x834]
       mov      edx, dword ptr [rbp-0x324]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x330], rax
       mov      rcx, gword ptr [rbp-0x330]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x840], rax
       mov      rdx, gword ptr [rbp-0x840]
       mov      rcx, gword ptr [rbp-0x330]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x338], rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x848], rax
       mov      r9, gword ptr [rbp-0x848]
       mov      rdx, gword ptr [rbp-0x338]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x340]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1280
       mov      rcx, 0x7FF9D77EAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x318]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B6
       vmovdqu  xmm0, xmmword ptr [rbp-0x318]
       vmovdqu  xmmword ptr [rbp-0x858], xmm0
 
G_M000_IG84:                ;; offset=0x12C6
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12CA
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x878], ymm0
 
G_M000_IG86:                ;; offset=0x12D6
       lea      rdx, [rbp-0x858]
       lea      r8, [rbp-0x878]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12F0
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77EAB20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG88:                ;; offset=0x1344
       mov      rcx, 0x7FF9D77EAB24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1355
       mov      rcx, 0x7FF9D77EAB28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG90:                ;; offset=0x1369
       mov      rcx, 0x7FF9D77EAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG91:                ;; offset=0x1387
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77EAB30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG92:                ;; offset=0x13AC
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77EAB38
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x880], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x884], eax
       mov      rcx, gword ptr [rbp-0x880]
       mov      edx, dword ptr [rbp-0x884]
       mov      r11, 0x7FF9D7092940
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77EAC40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG224
 
G_M000_IG93:                ;; offset=0x1461
       lea      rcx, [rbp-0x618]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x1479
       vmovdqu  xmm0, xmmword ptr [rbp-0x618]
       vmovdqu  xmmword ptr [rbp-0x898], xmm0
 
G_M000_IG95:                ;; offset=0x1489
       lea      rdx, [rbp-0x898]
       lea      rcx, [rbp-0x628]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x628]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x620]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77EAC44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A0], rax
       mov      rcx, gword ptr [rbp-0x8A0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG96:                ;; offset=0x1517
       mov      rcx, 0x7FF9D77EAC48
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG97:                ;; offset=0x1535
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77EAC4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG98:                ;; offset=0x1574
       mov      rcx, 0x7FF9D77EAC50
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG99:                ;; offset=0x1588
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77EAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG100:                ;; offset=0x15BA
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15BE
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8C0], ymm0
 
G_M000_IG102:                ;; offset=0x15CA
       lea      r8, [rbp-0x8C0]
       lea      rdx, [rbp-0x570]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77EAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8C8], rax
       mov      rcx, gword ptr [rbp-0x8C8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG103:                ;; offset=0x165E
       mov      rcx, 0x7FF9D77EAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG104:                ;; offset=0x167C
       mov      rcx, 0x7FF9D77EAC60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x600], rax
       mov      rax, gword ptr [rbp-0x600]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8D0], rax
       mov      r9, gword ptr [rbp-0x8D0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG105:                ;; offset=0x16FE
       mov      rcx, 0x7FF9D77EAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5BC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D8], rax
       mov      r8, gword ptr [rbp-0x8D8]
       mov      edx, dword ptr [rbp-0x5BC]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r9, gword ptr [rbp-0x8E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG106:                ;; offset=0x177F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77EAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG107:                ;; offset=0x17A4
       mov      rcx, 0x7FF9D77EAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E8], rax
       mov      rdx, gword ptr [rbp-0x8E8]
       mov      rcx, gword ptr [rbp-0x5B0]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG108:                ;; offset=0x1842
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77EAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG109:                ;; offset=0x1867
       mov      rcx, 0x7FF9D77EAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F8], rax
       mov      rdx, gword ptr [rbp-0x8F8]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG110:                ;; offset=0x189D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77EAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG111:                ;; offset=0x18C2
       mov      rcx, 0x7FF9D77EAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x540]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x548], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x550], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x8FC], eax
       mov      r8d, dword ptr [rbp-0x8FC]
       mov      edx, dword ptr [rbp-0x554]
       mov      rcx, bword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x908], rax
       mov      r9, gword ptr [rbp-0x908]
       mov      rdx, gword ptr [rbp-0x560]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x548]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG112:                ;; offset=0x199D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77EAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG113:                ;; offset=0x19C2
       mov      rcx, 0x7FF9D77EAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x508], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x518], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x518]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x520], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x528], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x52C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x90C], eax
       mov      r8d, dword ptr [rbp-0x90C]
       mov      edx, dword ptr [rbp-0x52C]
       mov      rcx, bword ptr [rbp-0x528]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x538], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x918], rax
       mov      rax, gword ptr [rbp-0x918]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      r8, gword ptr [rbp-0x520]
       mov      r9, gword ptr [rbp-0x538]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG114:                ;; offset=0x1AD2
       mov      rcx, 0x7FF9D77EAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x500], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x91C], eax
       mov      edx, dword ptr [rbp-0x91C]
       mov      rcx, bword ptr [rbp-0x500]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x928], rax
       mov      r9, gword ptr [rbp-0x928]
       mov      edx, dword ptr [rbp-0x4F4]
       mov      r8d, dword ptr [rbp-0x4F8]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG224
 
G_M000_IG115:                ;; offset=0x1B7D
       mov      rcx, 0x7FF9D77EAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x92C], eax
       mov      edx, dword ptr [rbp-0x92C]
       mov      rcx, bword ptr [rbp-0x4E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x930], eax
       mov      edx, dword ptr [rbp-0x930]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG224
 
G_M000_IG116:                ;; offset=0x1C01
       mov      rcx, 0x7FF9D77EAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4D4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x938], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x938]
       mov      edx, dword ptr [rbp-0x4D4]
       mov      r8d, dword ptr [rbp-0x4D8]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x940], rax
       mov      r9, gword ptr [rbp-0x940]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG117:                ;; offset=0x1CA5
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77EAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG118:                ;; offset=0x1CDE
       mov      rcx, 0x7FF9D77EAC98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CED
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77EAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D28
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x950], xmm0
 
G_M000_IG121:                ;; offset=0x1D34
       lea      r9, [rbp-0x950]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG238
 
G_M000_IG122:                ;; offset=0x1D5C
       mov      rcx, 0x7FF9D77EACA0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6B
       mov      rcx, 0x7FF9D77EACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x958], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x958]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x960], rax
       mov      r9, gword ptr [rbp-0x960]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG124:                ;; offset=0x1E0F
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77EACA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG125:                ;; offset=0x1E34
       mov      rcx, 0x7FF9D77EACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG126:                ;; offset=0x1E5B
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77EACB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG127:                ;; offset=0x1E80
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77EACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG128:                ;; offset=0x1EAF
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x980], ymm0
 
G_M000_IG130:                ;; offset=0x1EBF
       lea      r8, [rbp-0x980]
       lea      rdx, [rbp-0x4B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x4B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x4B0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77EACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x988], rax
       mov      rcx, gword ptr [rbp-0x988]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG131:                ;; offset=0x1F53
       mov      rcx, 0x7FF9D77EACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG132:                ;; offset=0x1F74
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77EACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG133:                ;; offset=0x1FD3
       mov      rcx, 0x7FF9D77EACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG134:                ;; offset=0x1FF4
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77EACC8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG135:                ;; offset=0x2022
       mov      rcx, 0x7FF9D77EACCC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2033
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2051
       mov      rcx, 0x7FF9D77EACD0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2060
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77EACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG139:                ;; offset=0x20C8
       mov      rcx, 0x7FF9D77EACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG140:                ;; offset=0x20DC
       mov      rcx, 0x7FF9D77EACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG141:                ;; offset=0x20F0
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77EACE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG142:                ;; offset=0x2125
       mov      rcx, 0x7FF9D77EACE4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x2139
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2AC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2AC]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBB8]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x990], rax
       mov      rdx, gword ptr [rbp-0x990]
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2246
       lea      rdx, [rbp-0x2C8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x2C8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x2C0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77EACE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rcx, gword ptr [rbp-0x998]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG145:                ;; offset=0x22E5
       mov      rcx, 0x7FF9D77EACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F6
       mov      rcx, 0x7FF9D77EACF0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2307
       mov      rcx, 0x7FF9D77EACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x2318
       mov      rcx, 0x7FF9D77EACF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x2329
       mov      rcx, 0x7FF9D77EACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x233A
       mov      rcx, 0x7FF9D77EAD00
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG151:                ;; offset=0x235B
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x458], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x99C], eax
       mov      edx, dword ptr [rbp-0x99C]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x458]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77EAD04
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C3
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9B0], xmm0
 
G_M000_IG153:                ;; offset=0x23D3
       lea      r9, [rbp-0x9B0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG154:                ;; offset=0x23F1
       mov      rcx, 0x7FF9D77EAD08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x470], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9B4], eax
       mov      edx, dword ptr [rbp-0x9B4]
       mov      rcx, bword ptr [rbp-0x470]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG155:                ;; offset=0x2455
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77EAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG156:                ;; offset=0x247A
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77EAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG157:                ;; offset=0x24A9
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24AD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9D8], ymm0
 
G_M000_IG159:                ;; offset=0x24B9
       lea      r8, [rbp-0x9D8]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x468]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x460]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77EAD14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E0], rax
       mov      rcx, gword ptr [rbp-0x9E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG160:                ;; offset=0x254D
       mov      rcx, 0x7FF9D77EAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG161:                ;; offset=0x256E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77EAD20
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x9E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9EC], eax
       mov      rcx, gword ptr [rbp-0x9E8]
       mov      edx, dword ptr [rbp-0x9EC]
       mov      r11, 0x7FF9D7092938
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG169
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0xC4]
       jne      G_M000_IG164
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x440], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x9F8], rax
       mov      rdx, gword ptr [rbp-0x9F8]
       lea      rcx, [rbp-0x450]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG162:                ;; offset=0x2666
       vmovdqu  xmm0, xmmword ptr [rbp-0x450]
       vmovdqu  xmmword ptr [rbp-0xA08], xmm0
 
G_M000_IG163:                ;; offset=0x2676
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x150]
       mov      qword ptr [rsp+0x30], rax
       lea      rdx, [rbp-0xA08]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x440]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedCall(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG168
       lea      rcx, [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77EAE28
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA10], rax
       mov      rdx, gword ptr [rbp-0xA10]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x158], rax
       cmp      gword ptr [rbp-0x158], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77EAF30
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG164:                ;; offset=0x2740
       mov      rcx, 0x7FF9D77EAF34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG169
 
G_M000_IG165:                ;; offset=0x2751
       mov      rcx, 0x7FF9D77EAF38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x2760
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG167:                ;; offset=0x2770
       lea      r9, [rbp-0xA20]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG168:                ;; offset=0x278E
       mov      rcx, 0x7FF9D77EAF3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xC4]
       lea      edx, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
 
G_M000_IG169:                ;; offset=0x27BA
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3E8], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA24], eax
       mov      edx, dword ptr [rbp-0xA24]
       mov      rcx, bword ptr [rbp-0x3E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG172
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG170
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77EAF40
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA30], rax
       mov      rdx, gword ptr [rbp-0xA30]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x160], rax
       cmp      gword ptr [rbp-0x160], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0x160]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG170:                ;; offset=0x28BA
       mov      rcx, 0x7FF9D77EB048
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG171:                ;; offset=0x28CE
       mov      rcx, 0x7FF9D77EB04C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       vmovdqu  xmmword ptr [rbp-0x430], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76A9D18
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0xA38], rax
       mov      r8, gword ptr [rbp-0xA38]
       lea      rcx, [rbp-0x438]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rax, bword ptr [rbp-0xB78]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x438]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG172:                ;; offset=0x2986
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG175
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x168]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77EB050
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG173:                ;; offset=0x29E7
       cmp      gword ptr [rbp-0x168], 0
       je       G_M000_IG174
       mov      rcx, 0x7FF9D77EB054
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x420], xmm0
       vmovdqu  xmmword ptr [rbp-0x418], xmm0
       lea      rcx, [rbp-0x420]
       mov      r8, gword ptr [rbp-0x168]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x420]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG174:                ;; offset=0x2A90
       mov      rcx, 0x7FF9D77EB058
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG175:                ;; offset=0x2AA4
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG179
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG177
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x2B10
       mov      rcx, 0x7FF9D77EB05C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG177:                ;; offset=0x2B1F
       mov      rcx, 0x7FF9D77EB060
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG178:                ;; offset=0x2B58
       mov      rcx, 0x7FF9D77EB064
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG179:                ;; offset=0x2B84
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77EB068
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG180:                ;; offset=0x2BF4
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x3F8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG181:                ;; offset=0x2C29
       vmovdqu  xmm0, xmmword ptr [rbp-0x3F8]
       vmovdqu  xmmword ptr [rbp-0xA48], xmm0
 
G_M000_IG182:                ;; offset=0x2C39
       lea      rdx, [rbp-0xA48]
       lea      rcx, [rbp-0x408]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rdx, gword ptr [rbp-0x408]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB88]
       mov      rcx, qword ptr [rbp-0x400]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG183
       mov      rcx, 0x7FF9D77EB06C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA50], rax
       mov      rcx, gword ptr [rbp-0xA50]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG183:                ;; offset=0x2CC7
       mov      rcx, 0x7FF9D77EB070
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG184:                ;; offset=0x2CE5
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA54], eax
       mov      edx, dword ptr [rbp-0xA54]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x484], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x488], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA60], rax
       mov      rax, gword ptr [rbp-0xA60]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      r8d, dword ptr [rbp-0x484]
       mov      r9d, dword ptr [rbp-0x488]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG186
       mov      rcx, 0x7FF9D77EB074
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG185:                ;; offset=0x2DB0
       mov      rcx, 0x7FF9D77EB078
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG186:                ;; offset=0x2DC4
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77EB07C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG187:                ;; offset=0x2DF0
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG188:                ;; offset=0x2DF4
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA80], ymm0
 
G_M000_IG189:                ;; offset=0x2E00
       lea      r8, [rbp-0xA80]
       lea      rdx, [rbp-0x498]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG190:                ;; offset=0x2E1A
       vmovdqu  xmm0, xmmword ptr [rbp-0x498]
       vmovdqu  xmmword ptr [rbp-0xA90], xmm0
 
G_M000_IG191:                ;; offset=0x2E2A
       lea      rdx, [rbp-0xA90]
       lea      rcx, [rbp-0x4A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x4A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x4A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG192
       mov      rcx, 0x7FF9D77EB080
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA98], rax
       mov      rcx, gword ptr [rbp-0xA98]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG192:                ;; offset=0x2EB8
       mov      rcx, 0x7FF9D77EB084
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG193:                ;; offset=0x2ED6
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG194
       mov      rcx, 0x7FF9D77EB088
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG194:                ;; offset=0x2EFB
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77EB08C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG195:                ;; offset=0x2F27
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG196:                ;; offset=0x2F2B
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAB8], ymm0
 
G_M000_IG197:                ;; offset=0x2F37
       lea      r8, [rbp-0xAB8]
       lea      rdx, [rbp-0x3C8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG198:                ;; offset=0x2F51
       vmovdqu  xmm0, xmmword ptr [rbp-0x3C8]
       vmovdqu  xmmword ptr [rbp-0xAC8], xmm0
 
G_M000_IG199:                ;; offset=0x2F61
       lea      rdx, [rbp-0xAC8]
       lea      rcx, [rbp-0x3D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x3D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x3D0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG200
       mov      rcx, 0x7FF9D77EB090
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD0], rax
       mov      rcx, gword ptr [rbp-0xAD0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG200:                ;; offset=0x2FEF
       mov      rcx, 0x7FF9D77EB094
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG201:                ;; offset=0x300D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG202
       mov      rcx, 0x7FF9D77EB098
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG202:                ;; offset=0x3032
       mov      rcx, 0x7FF9D77EB09C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG203:                ;; offset=0x3056
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xAD4], eax
       mov      edx, dword ptr [rbp-0xAD4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG205
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77EB0A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG204:                ;; offset=0x30BA
       mov      rcx, 0x7FF9D77EB0A4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG205:                ;; offset=0x30C9
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG207
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77E9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x30EC
       mov      rcx, 0x7FF9D77EB0A8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG207:                ;; offset=0x30FB
       mov      rcx, 0x7FF9D77EB0AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG208:                ;; offset=0x3128
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG209:                ;; offset=0x312C
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAF8], ymm0
 
G_M000_IG210:                ;; offset=0x3138
       lea      r8, [rbp-0xAF8]
       lea      rdx, [rbp-0x3A8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG211
       mov      rcx, 0x7FF9D77EB0B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB00], rax
       mov      rcx, gword ptr [rbp-0xB00]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG211:                ;; offset=0x31CC
       mov      rcx, 0x7FF9D77EB0B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG212:                ;; offset=0x31ED
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG216
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x16C], eax
       cmp      dword ptr [rbp-0x16C], 49
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x16C], 57
       je       SHORT G_M000_IG214
       cmp      dword ptr [rbp-0x16C], 58
       je       SHORT G_M000_IG213
       mov      rcx, 0x7FF9D77EB0B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG213:                ;; offset=0x323D
       mov      rcx, 0x7FF9D77EB0BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG214:                ;; offset=0x324E
       mov      rcx, 0x7FF9D77EB0C0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x325F
       mov      rcx, 0x7FF9D77EB0C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG216:                ;; offset=0x326E
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG218
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG219
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG217
       mov      rcx, 0x7FF9D77EB0C8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3B8], xmm0
       lea      rcx, [rbp-0x3B8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3B0]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG238
 
G_M000_IG217:                ;; offset=0x3331
       mov      rcx, 0x7FF9D77EB0CC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x3342
       mov      rcx, 0x7FF9D77EB0D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG219:                ;; offset=0x3356
       mov      rcx, 0x7FF9D77EB0D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG220:                ;; offset=0x3374
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1D0], ymm0
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
       lea      rcx, [rbp-0x1D0]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG221:                ;; offset=0x33A0
       vmovdqu  ymm0, ymmword ptr [rbp-0x1D0]
       vmovdqu  ymmword ptr [rbp-0x198], ymm0
       mov      rax, qword ptr [rbp-0x1B0]
       mov      qword ptr [rbp-0x178], rax
 
G_M000_IG222:                ;; offset=0x33BE
       lea      rcx, [rbp-0x198]
       mov      rdx, 0x23AEEE12A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB04], eax
       mov      edx, dword ptr [rbp-0xB04]
       lea      rcx, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1D8], rax
       lea      rcx, [rbp-0x198]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB10], rax
       mov      rdx, gword ptr [rbp-0xB10]
       mov      rcx, gword ptr [rbp-0x1D8]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1D8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x3443
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG224:                ;; offset=0x3449
       mov      eax, dword ptr [rbp-0x664]
       dec      eax
       mov      dword ptr [rbp-0x664], eax
       cmp      dword ptr [rbp-0x664], 0
       jg       SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x3460
       lea      rcx, [rbp-0x664]
       mov      edx, 0xFF1
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG226:                ;; offset=0x3473
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG229
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG228
       mov      rcx, 0x7FF9D77EB0E4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x1F8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x1F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x1F0]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG227:                ;; offset=0x34EB
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG228:                ;; offset=0x34F7
       mov      rcx, 0x7FF9D77EB0E8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG229:                ;; offset=0x3506
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG230
       mov      rcx, 0x7FF9D77EB0EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, bword ptr [rbp-0x1E8]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG234
 
G_M000_IG230:                ;; offset=0x353B
       mov      rcx, 0x7FF9D77EB0F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG234
 
G_M000_IG231:                ;; offset=0x354C
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x357A
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG233:                ;; offset=0x3584
       mov      rcx, 0x7FF9D77EB0F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG234:                ;; offset=0x359F
       mov      eax, dword ptr [rbp-0x664]
       dec      eax
       mov      dword ptr [rbp-0x664], eax
       cmp      dword ptr [rbp-0x664], 0
       jg       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x35B6
       lea      rcx, [rbp-0x664]
       mov      edx, 0x1036
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG236:                ;; offset=0x35C9
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77EB0F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG237:                ;; offset=0x35F1
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG238:                ;; offset=0x35FD
       mov      rcx, 0x7FF9D77EB0FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG239:                ;; offset=0x3612
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG240:                ;; offset=0x361E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG241:                ;; offset=0x3624
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x3628
       mov      gword ptr [rbp-0x638], rcx
       mov      rax, gword ptr [rbp-0x638]
       mov      gword ptr [rbp-0x1A0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x3644
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x364A
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      r8, gword ptr [rbp-0xB18]
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG246
       mov      rcx, 0x7FF9D77EB0D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG238
 
G_M000_IG245:                ;; offset=0x3699
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG246:                ;; offset=0x36A1
       mov      rcx, 0x7FF9D77EB0DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG247:                ;; offset=0x36BE
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG248:                ;; offset=0x36C6
       sub      rsp, 72
 
G_M000_IG249:                ;; offset=0x36CA
       mov      gword ptr [rbp-0x630], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r9, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x3702
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG251:                ;; offset=0x3708
       mov      rcx, 0x7FF9D77EB0E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG252:                ;; offset=0x3725
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001334h ; case G_M000_IG91
       	dd	00001629h ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ABh ; case G_M000_IG105
       	dd	0000172Ch ; case G_M000_IG106
       	dd	00000ADBh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Dh ; case G_M000_IG138
       	dd	0000200Dh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E2h ; case G_M000_IG97
       	dd	000014E2h ; case G_M000_IG97
       	dd	000017EFh ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ah ; case G_M000_IG110
       	dd	0000194Ah ; case G_M000_IG112
       	dd	00001A7Fh ; case G_M000_IG114
       	dd	00001B2Ah ; case G_M000_IG115
       	dd	00001BAEh ; case G_M000_IG116
       	dd	00001C52h ; case G_M000_IG117
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00002C92h ; case G_M000_IG184
       	dd	00002308h ; case G_M000_IG151
       	dd	0000251Bh ; case G_M000_IG161
       	dd	00001FE0h ; case G_M000_IG136
       	dd	00002E83h ; case G_M000_IG193
       	dd	00002FBAh ; case G_M000_IG201
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	0000319Ah ; case G_M000_IG212
       	dd	00003003h ; case G_M000_IG203
       	dd	00001F21h ; case G_M000_IG132
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	0000319Ah ; case G_M000_IG212
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C17h ; case G_M000_IG59
       	dd	0000101Bh ; case G_M000_IG76
       	dd	0000319Ah ; case G_M000_IG212
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Dh ; case G_M000_IG141
       	dd	000020E6h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A8h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 14125

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xff1
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 255
; 90 inlinees with PGO data; 294 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 736
       mov      qword ptr [rsp+0xEE8], r15
       mov      qword ptr [rsp+0xEE0], r14
       mov      qword ptr [rsp+0xED8], r13
       mov      qword ptr [rsp+0xED0], r12
       mov      qword ptr [rsp+0xEC8], rdi
       mov      qword ptr [rsp+0xEC0], rsi
       mov      qword ptr [rsp+0xEB8], rbx
       lea      rbp, [rsp+0x2E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x288], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -576
 
G_M000_IG525:                ;; offset=0x0064
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG525
       mov      qword ptr [rbp-0x40], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x0094
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x00A1
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00AA
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00B4
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rax, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [rax+0x08]
       cmp      edx, ebx
       jge      G_M000_IG504
 
G_M000_IG06:                ;; offset=0x00D0
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG511
       mov      rax, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      rax, gword ptr [rax]
       mov      r8, gword ptr [rdx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG508
       mov      r8, gword ptr [rdx+0x180]
       test     r8, r8
       je       SHORT G_M000_IG10
       jmp      G_M000_IG507
 
G_M000_IG07:                ;; offset=0x0135
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0147
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG09:                ;; offset=0x016C
       vzeroupper 
       add      rsp, 0xEB8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0183
       mov      r8, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG120
 
G_M000_IG11:                ;; offset=0x0197
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG12:                ;; offset=0x01B1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdi, gword ptr [rcx]
       mov      r14, gword ptr [rcx+0x08]
       mov      edx, esi
       cmp      edx, 2
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01C6
       cmp      edx, 25
       jne      G_M000_IG296
 
G_M000_IG14:                ;; offset=0x01CF
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15, gword ptr [rax]
       cmp      esi, dword ptr [r14+0x08]
       jae      G_M000_IG500
       mov      eax, esi
       shl      rax, 4
       lea      rax, bword ptr [r14+rax+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG297
 
G_M000_IG15:                ;; offset=0x020E
       mov      r8, 0x21AC8401CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG298
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG299
 
G_M000_IG16:                ;; offset=0x022C
       test     rdx, rdx
       je       SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x0231
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [rdx], rax
       jne      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0240
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x024B
       mov      rax, rdx
 
G_M000_IG20:                ;; offset=0x024E
       test     rax, rax
       je       G_M000_IG300
 
G_M000_IG21:                ;; offset=0x0257
       mov      rsi, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG48
 
G_M000_IG22:                ;; offset=0x026B
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0285
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG301
 
G_M000_IG24:                ;; offset=0x0299
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG25:                ;; offset=0x02A4
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rdx+0x18]
       test     r15d, r15d
       jl       G_M000_IG41
 
G_M000_IG26:                ;; offset=0x02B8
       cmp      r15d, dword ptr [rdi+0x40]
       jge      G_M000_IG40
 
G_M000_IG27:                ;; offset=0x02C2
       mov      r13d, dword ptr [rdi+0x40]
       dec      r13d
       mov      r12d, dword ptr [rdi+0x3C]
       cmp      r13d, r12d
       jle      G_M000_IG42
 
G_M000_IG28:                ;; offset=0x02D6
       cmp      r12d, r15d
       jl       SHORT G_M000_IG36
 
G_M000_IG29:                ;; offset=0x02DB
       cmp      byte  ptr [rdi+0x44], 0
       jne      G_M000_IG302
 
G_M000_IG30:                ;; offset=0x02E5
       mov      rdx, gword ptr [rdi]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      eax, r12d
       shl      rax, 4
       lea      r13, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi+0x18]
       mov      rax, gword ptr [rdx+0x88]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [r13]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x031C
       mov      r10, 0x7FF9D7838AB0
       cmp      qword ptr [r8], r10
       jne      G_M000_IG306
 
G_M000_IG32:                ;; offset=0x032F
       test     r8, r8
       jne      G_M000_IG43
 
G_M000_IG33:                ;; offset=0x0338
       cmp      qword ptr [r13+0x08], -1
       je       G_M000_IG311
 
G_M000_IG34:                ;; offset=0x0343
       cmp      qword ptr [r13+0x08], -2
       je       G_M000_IG314
 
G_M000_IG35:                ;; offset=0x034E
       dec      r12d
       cmp      r12d, r15d
       jge      SHORT G_M000_IG29
 
G_M000_IG36:                ;; offset=0x0356
       mov      rdx, gword ptr [rdi]
       mov      eax, dword ptr [rdi+0x40]
       sub      eax, r15d
       test     rdx, rdx
       je       G_M000_IG315
       lea      r8, bword ptr [rdx+0x10]
       xor      r10d, r10d
       mov      r11, qword ptr [rdx]
       cmp      dword ptr [r11+0x04], 24
       jne      G_M000_IG316
 
G_M000_IG37:                ;; offset=0x037D
       mov      r13d, r15d
       sub      r13d, r10d
       cmp      r15d, r10d
       jl       G_M000_IG317
 
G_M000_IG38:                ;; offset=0x038C
       mov      r10d, r13d
       or       r10d, eax
       jl       G_M000_IG317
       lea      r10d, [rax+r13]
       cmp      r10d, dword ptr [rdx+0x08]
       ja       G_M000_IG317
       movzx    rdx, word  ptr [r11]
       mov      r10d, r13d
       imul     r10, rdx
       add      r10, r8
       mov      eax, eax
       imul     rdx, rax
       test     dword ptr [r11], 0x1000000
       je       G_M000_IG318
       shr      rdx, 3
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG39:                ;; offset=0x03D4
       mov      dword ptr [rdi+0x40], r15d
 
G_M000_IG40:                ;; offset=0x03D8
       mov      rdx, gword ptr [rdi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG02
 
G_M000_IG41:                ;; offset=0x040B
       not      r15d
       jmp      G_M000_IG26
 
G_M000_IG42:                ;; offset=0x0413
       mov      r12d, r13d
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x041B
       xor      edx, edx
       mov      qword ptr [r13], rdx
       mov      qword ptr [r13+0x08], rdx
       mov      rdx, 0x7FF9D7838AB0
       cmp      qword ptr [r8], rdx
       jne      G_M000_IG310
       mov      rdx, gword ptr [r8+0x08]
       cmp      byte  ptr [rdx], dl
       cmp      byte  ptr [r8+0x38], 0
       je       G_M000_IG35
       mov      byte  ptr [r8+0x38], 0
       xor      rax, rax
       mov      gword ptr [r8+0x18], rax
 
G_M000_IG44:                ;; offset=0x0454
       mov      gword ptr [r8+0x20], rax
 
G_M000_IG45:                ;; offset=0x0458
       mov      qword ptr [r8+0x30], rax
       mov      r13, gword ptr [rdx+0x18]
       cmp      byte  ptr [rdx+0x48], 0
       jne      G_M000_IG309
 
G_M000_IG46:                ;; offset=0x046A
       test     r13, r13
       jne      G_M000_IG307
 
G_M000_IG47:                ;; offset=0x0473
       lea      rcx, bword ptr [rdx+0x18]
       mov      rdx, r8
       call     CORINFO_HELP_ASSIGN_REF
       test     r13, r13
       je       G_M000_IG35
       jmp      G_M000_IG308
 
G_M000_IG48:                ;; offset=0x048D
       mov      gword ptr [rbp-0x1B0], rax
       xor      eax, eax
       mov      qword ptr [rbp-0x1A8], rax
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       not      eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      eax, dword ptr [rcx+0x60]
       jl       G_M000_IG270
 
G_M000_IG49:                ;; offset=0x04B9
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG320
       mov      rax, gword ptr [rcx+0x38]
       mov      rdx, gword ptr [rax+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG320
       mov      rax, gword ptr [rax+0x180]
       test     rax, rax
       jne      G_M000_IG319
 
G_M000_IG50:                ;; offset=0x04EA
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x04FD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG323
 
G_M000_IG52:                ;; offset=0x0511
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG53:                ;; offset=0x051B
       mov      rdx, gword ptr [rsi]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      r8d, eax
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG54:                ;; offset=0x0539
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [rsi+0x40], eax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x10]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG500
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      esi, dword ptr [rdx+0x1C]
       cmp      esi, 25
       jne      G_M000_IG110
 
G_M000_IG55:                ;; offset=0x0574
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      r14d, dword ptr [rdx+0x08]
 
G_M000_IG56:                ;; offset=0x057F
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG57:                ;; offset=0x058F
       mov      rax, gword ptr [rsi+0x68]
       mov      rdx, 0x7FF9D722C7D0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG325
       cmp      dword ptr [rax+0x08], r14d
       jbe      G_M000_IG324
       mov      edx, r14d
       mov      r15, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG58:                ;; offset=0x05B8
       cmp      word  ptr [r15+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG271
 
G_M000_IG59:                ;; offset=0x05D4
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG60:                ;; offset=0x05E2
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG326
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG500
       mov      eax, r14d
       shl      rax, 4
       mov      r12, gword ptr [rdi+rax+0x10]
       test     r12, r12
       jne      G_M000_IG272
 
G_M000_IG61:                ;; offset=0x0613
       mov      eax, r14d
       shl      rax, 4
       lea      r12, bword ptr [rdi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1B8]
       mov      qword ptr [r12+0x08], rcx
       test     r13d, r13d
       je       SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x063F
       cmp      byte  ptr [rsi+0xF2], 0
       jne      G_M000_IG327
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG63
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx+0xFF], 0
       jne      G_M000_IG327
 
G_M000_IG63:                ;; offset=0x066A
       mov      r15, bword ptr [rbp+0xC20]
       inc      dword ptr [r15+0x10]
       jmp      G_M000_IG02
 
G_M000_IG64:                ;; offset=0x067A
       xor      rax, rax
       jmp      G_M000_IG192
 
G_M000_IG65:                ;; offset=0x0681
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r12], rax
       jne      G_M000_IG193
 
G_M000_IG66:                ;; offset=0x0695
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG63
 
G_M000_IG67:                ;; offset=0x06C3
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rdi, bword ptr [rbp+0xC20]
       lea      rcx, bword ptr [rdi+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rdi+0x10], eax
       jmp      G_M000_IG223
 
G_M000_IG68:                ;; offset=0x06F3
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG472
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG69:                ;; offset=0x071F
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x238], r8
       test     esi, esi
       jl       G_M000_IG219
 
G_M000_IG70:                ;; offset=0x0735
       cmp      esi, eax
       jae      G_M000_IG500
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG475
 
G_M000_IG71:                ;; offset=0x075C
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG476
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG477
       mov      r15, gword ptr [rax]
 
G_M000_IG72:                ;; offset=0x0780
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG77
 
G_M000_IG73:                ;; offset=0x0788
       test     r15, r15
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x078D
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x079C
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG76:                ;; offset=0x07A8
       test     r15, r15
       je       G_M000_IG478
 
G_M000_IG77:                ;; offset=0x07B1
       test     r15, r15
       je       G_M000_IG479
       mov      r13, r15
 
G_M000_IG78:                ;; offset=0x07BD
       xor      rax, rax
       mov      gword ptr [rbp-0x238], rax
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x07D5
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG480
 
G_M000_IG80:                ;; offset=0x07E9
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG81:                ;; offset=0x07F3
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG221
 
G_M000_IG82:                ;; offset=0x0804
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r10d, dword ptr [rdx+0x18]
 
G_M000_IG83:                ;; offset=0x080F
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, rbx
       mov      rdx, r13
       mov      r8d, eax
       mov      r9d, r10d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG84:                ;; offset=0x0838
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG85:                ;; offset=0x085B
       test     al, al
       jne      G_M000_IG481
 
G_M000_IG86:                ;; offset=0x0863
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG87:                ;; offset=0x087C
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG88:                ;; offset=0x088A
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG402
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0899
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG90:                ;; offset=0x08A7
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG91:                ;; offset=0x08C6
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x08D0
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG133
 
G_M000_IG93:                ;; offset=0x08EC
       mov      rbx, bword ptr [rbp+0xC58]
       mov      r8d, dword ptr [rbx+0x08]
       test     r8d, r8d
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x08FC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      G_M000_IG400
 
G_M000_IG95:                ;; offset=0x0918
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, edi
       mov      rcx, rsi
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x200]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG96:                ;; offset=0x0995
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, edi
       mov      rcx, rsi
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1F0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG97:                ;; offset=0x0A12
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdi, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG98:                ;; offset=0x0A55
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      r15, bword ptr [rbp+0xC20]
       lea      rcx, bword ptr [r15+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x258], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x250], r9
       lea      r9, [rbp-0x258]
       mov      edx, edi
       mov      r8d, r14d
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG99:                ;; offset=0x0AC6
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG100:                ;; offset=0x0ADB
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       mov      r14, gword ptr [r14+8*rcx+0x10]
       mov      r15, bword ptr [rbp+0xC20]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jl       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0B33
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      rdx, rdi
       mov      r8, r14
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG102:                ;; offset=0x0B6B
       not      r8d
       jmp      SHORT G_M000_IG101
 
G_M000_IG103:                ;; offset=0x0B70
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG104:                ;; offset=0x0B85
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       mov      rsi, gword ptr [rsi+8*rcx+0x10]
       mov      r15, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [r15+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r14d
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG105:                ;; offset=0x0C04
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG201
 
G_M000_IG106:                ;; offset=0x0C2C
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG107:                ;; offset=0x0C56
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG108:                ;; offset=0x0C6B
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG109:                ;; offset=0x0C87
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG391
 
G_M000_IG110:                ;; offset=0x0CB9
       cmp      esi, 71
       je       G_M000_IG328
       cmp      esi, 30
       jne      G_M000_IG333
       cmp      gword ptr [rbp-0x1B0], 0
       jne      G_M000_IG63
       jmp      G_M000_IG334
 
G_M000_IG111:                ;; offset=0x0CDE
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r8, gword ptr [rax+0x30]
       mov      rsi, r8
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       SHORT G_M000_IG117
 
G_M000_IG112:                ;; offset=0x0D22
       mov      r15, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [r15+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rcx+0x18]
       test     r13d, r13d
       jl       SHORT G_M000_IG116
 
G_M000_IG113:                ;; offset=0x0D4D
       cmp      r13d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0D53
       mov      rcx, rdi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG115:                ;; offset=0x0D5F
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG500
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rdi+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG116:                ;; offset=0x0D93
       not      r13d
       jmp      SHORT G_M000_IG113
 
G_M000_IG117:                ;; offset=0x0D98
       mov      r15, bword ptr [rbp+0xC20]
       mov      gword ptr [rbp-0x258], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x250], r9
       lea      r9, [rbp-0x258]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG118:                ;; offset=0x0DD3
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG119:                ;; offset=0x0DE1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rsi, gword ptr [rdx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x23AEEE146A8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9D7092978
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG387
       jmp      G_M000_IG386
 
G_M000_IG120:                ;; offset=0x0E2F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG121:                ;; offset=0x0E52
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA78], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA98], rcx
 
G_M000_IG122:                ;; offset=0x0E6A
       mov      ecx, dword ptr [rbp+0xA88]
       cmp      ecx, dword ptr [rbp+0xA98]
       ja       G_M000_IG349
       mov      rdx, bword ptr [rbp+0xA90]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp+0xA98]
       sub      eax, ecx
       cmp      eax, 27
       jb       G_M000_IG501
 
G_M000_IG123:                ;; offset=0x0E9A
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp+0xA88]
       add      ecx, 27
       mov      dword ptr [rbp+0xA88], ecx
 
G_M000_IG124:                ;; offset=0x0ECF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA78]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp+0xA78]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG125:                ;; offset=0x0F1A
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG126:                ;; offset=0x0F28
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG379
       jmp      G_M000_IG372
 
G_M000_IG127:                ;; offset=0x0F3A
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG02
       jmp      G_M000_IG384
 
G_M000_IG128:                ;; offset=0x0F53
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG129:                ;; offset=0x0F61
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       je       G_M000_IG358
 
G_M000_IG130:                ;; offset=0x0FBD
       xor      r15d, r15d
 
G_M000_IG131:                ;; offset=0x0FC0
       test     r15d, r15d
       jne      G_M000_IG361
 
G_M000_IG132:                ;; offset=0x0FC9
       mov      rax, gword ptr [rbp+0xC30]
       lea      rsi, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rsi+0x08], rcx
       mov      rax, gword ptr [rbp+0xC30]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       je       G_M000_IG370
 
G_M000_IG133:                ;; offset=0x1014
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG502
 
G_M000_IG134:                ;; offset=0x1023
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       jmp      G_M000_IG335
 
G_M000_IG135:                ;; offset=0x105B
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG350
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG136:                ;; offset=0x10B4
       mov      rax, gword ptr [rbp+0xC30]
       mov      rdx, rax
       test     rdx, rdx
       jne      SHORT G_M000_IG138
 
G_M000_IG137:                ;; offset=0x10C3
       mov      r10, gword ptr [rbp+0xC28]
       mov      rdx, r10
 
G_M000_IG138:                ;; offset=0x10CD
       mov      bword ptr [rbp-0x248], r9
       mov      dword ptr [rbp-0x240], r8d
 
G_M000_IG139:                ;; offset=0x10DB
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG140:                ;; offset=0x10EB
       lea      rcx, [rbp-0x248]
       lea      r8, [rbp-0x258]
       mov      r9, gword ptr [rdx+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG141:                ;; offset=0x1112
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x1145
       mov      rcx, 0x7FF9D758EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG348
 
G_M000_IG143:                ;; offset=0x1158
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      G_M000_IG148
 
G_M000_IG144:                ;; offset=0x119B
       or       edi, r14d
       jne      G_M000_IG349
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG145:                ;; offset=0x11A8
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x11CB
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
       mov      r9, r10
 
G_M000_IG147:                ;; offset=0x11D8
       mov      bword ptr [rbp-0x248], rdx
       mov      dword ptr [rbp-0x240], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x248]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG148:                ;; offset=0x1220
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG349
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
       jmp      G_M000_IG145
 
G_M000_IG149:                ;; offset=0x1246
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x1257
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG408
 
G_M000_IG151:                ;; offset=0x1276
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rax, gword ptr [rbx]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG500
       mov      edx, esi
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, gword ptr [rax]
       mov      rdx, 0x21AC8401CE0
       cmp      rdi, gword ptr [rdx]
       je       G_M000_IG416
 
G_M000_IG152:                ;; offset=0x12B8
       mov      rdx, 0x21AC8401CE8
       cmp      rdi, gword ptr [rdx]
       je       G_M000_IG417
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG418
 
G_M000_IG153:                ;; offset=0x12D6
       test     rdi, rdi
       je       G_M000_IG419
       mov      rdx, 0x7FF9D7838AB0
       cmp      qword ptr [rdi], rdx
       je       G_M000_IG166
 
G_M000_IG154:                ;; offset=0x12F2
       mov      rdx, 0x7FF9D77EA4F0
       cmp      qword ptr [rdi], rdx
       je       G_M000_IG165
 
G_M000_IG155:                ;; offset=0x1305
       mov      rax, rdi
       mov      rdx, 0x7FF9D77E5D30
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG420
       xor      rax, rax
 
G_M000_IG156:                ;; offset=0x131D
       test     rax, rax
       jne      G_M000_IG165
       mov      rdx, 0x7FF9D7838D18
       cmp      qword ptr [rdi], rdx
       je       G_M000_IG164
 
G_M000_IG157:                ;; offset=0x1339
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG158:                ;; offset=0x1347
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x1350
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG160:                ;; offset=0x136F
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG161:                ;; offset=0x1376
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG162:                ;; offset=0x1383
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       jne      G_M000_IG441
 
G_M000_IG163:                ;; offset=0x13D5
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG164:                ;; offset=0x13ED
       lea      rdx, [rbp-0x210]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x13FF
       mov      r8, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r8+0x08]
       jae      G_M000_IG500
       mov      edx, esi
       lea      r8, bword ptr [r8+4*rdx+0x10]
       lea      rcx, [rbp-0x210]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x1429
       mov      rax, rdi
       lea      rdx, [rbp-0x210]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG167:                ;; offset=0x143C
       cmp      gword ptr [rbp-0x210], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG178
 
G_M000_IG168:                ;; offset=0x1452
       xor      rbx, rbx
       xor      esi, esi
 
G_M000_IG169:                ;; offset=0x1456
       test     ecx, ecx
       je       G_M000_IG67
 
G_M000_IG170:                ;; offset=0x145E
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG180
 
G_M000_IG171:                ;; offset=0x146F
       mov      rdi, bword ptr [rbp+0xC20]
       lea      r14, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG173
 
G_M000_IG172:                ;; offset=0x1489
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG421
 
G_M000_IG173:                ;; offset=0x149D
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rcx+0x14]
 
G_M000_IG174:                ;; offset=0x14A8
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rcx+0x18]
       test     r13d, r13d
       jl       SHORT G_M000_IG179
 
G_M000_IG175:                ;; offset=0x14B8
       cmp      r13d, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x14BE
       mov      rcx, r14
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG177:                ;; offset=0x14CA
       mov      rcx, gword ptr [r14]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG500
       mov      edx, r15d
       shl      rdx, 4
       lea      r15, bword ptr [rcx+rdx+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rsi
       mov      dword ptr [r14+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG178:                ;; offset=0x14FB
       mov      rbx, gword ptr [rbp-0x210]
       mov      rsi, qword ptr [rbp-0x208]
       jmp      G_M000_IG169
 
G_M000_IG179:                ;; offset=0x150E
       not      r13d
       jmp      SHORT G_M000_IG175
 
G_M000_IG180:                ;; offset=0x1513
       mov      gword ptr [rbp-0x220], rbx
       mov      qword ptr [rbp-0x218], rsi
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       not      ecx
       mov      rdi, bword ptr [rbp+0xC20]
       cmp      ecx, dword ptr [rdi+0x60]
       jl       G_M000_IG422
 
G_M000_IG181:                ;; offset=0x153D
       cmp      gword ptr [rdi+0x40], 0
       jne      G_M000_IG424
       mov      rcx, gword ptr [rdi+0x38]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG424
       mov      rcx, gword ptr [rcx+0x180]
       test     rcx, rcx
       jne      G_M000_IG423
 
G_M000_IG182:                ;; offset=0x156E
       lea      rbx, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG184
 
G_M000_IG183:                ;; offset=0x1581
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG427
 
G_M000_IG184:                ;; offset=0x1595
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG185:                ;; offset=0x159F
       mov      rcx, gword ptr [rbx]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG500
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG186:                ;; offset=0x15BB
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [rbx+0x40], eax
       mov      rcx, gword ptr [rdi]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [rdi+0x10]
       inc      edx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG500
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       mov      ebx, dword ptr [rdx+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG431
 
G_M000_IG187:                ;; offset=0x15EF
       mov      rbx, gword ptr [rdi]
       mov      rsi, gword ptr [rdi+0x08]
       mov      r14d, dword ptr [rdx+0x08]
 
G_M000_IG188:                ;; offset=0x15FA
       vmovdqu  xmm0, xmmword ptr [rbp-0x220]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG189:                ;; offset=0x160A
       mov      rcx, gword ptr [rbx+0x68]
       mov      rdx, 0x7FF9D722C7D0
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG428
       cmp      dword ptr [rcx+0x08], r14d
       jbe      G_M000_IG324
       mov      edx, r14d
       mov      r15, gword ptr [rcx+8*rdx+0x10]
 
G_M000_IG190:                ;; offset=0x1633
       cmp      word  ptr [r15+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG64
 
G_M000_IG191:                ;; offset=0x164F
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rcx+0x88]
 
G_M000_IG192:                ;; offset=0x165D
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG429
       cmp      r14d, dword ptr [rsi+0x08]
       jae      G_M000_IG500
       mov      eax, r14d
       shl      rax, 4
       mov      r12, gword ptr [rsi+rax+0x10]
       test     r12, r12
       jne      G_M000_IG65
 
G_M000_IG193:                ;; offset=0x168E
       mov      edx, r14d
       shl      rdx, 4
       lea      r12, bword ptr [rsi+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x230]
       mov      rcx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x228]
       mov      qword ptr [r12+0x08], rcx
       test     r13d, r13d
       je       G_M000_IG63
 
G_M000_IG194:                ;; offset=0x16BE
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG430
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG63
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx+0xFF], 0
       je       G_M000_IG63
       jmp      G_M000_IG430
 
G_M000_IG195:                ;; offset=0x16F2
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG86
       jmp      SHORT G_M000_IG201
 
G_M000_IG196:                ;; offset=0x1709
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG201
 
G_M000_IG197:                ;; offset=0x171A
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG487
       jmp      G_M000_IG86
 
G_M000_IG198:                ;; offset=0x172C
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG249
 
G_M000_IG199:                ;; offset=0x175E
       cmp      esi, 58
       ja       SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x1763
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rsi
       jae      G_M000_IG244
 
G_M000_IG201:                ;; offset=0x1777
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG502
 
G_M000_IG202:                ;; offset=0x1786
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], ebx
       jne      G_M000_IG279
 
G_M000_IG203:                ;; offset=0x1796
       mov      rdi, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       G_M000_IG447
       lea      r14, bword ptr [rdx+0x10]
       mov      r15d, dword ptr [rdx+0x08]
 
G_M000_IG204:                ;; offset=0x17AE
       mov      r13d, dword ptr [rcx+0x10]
       mov      bword ptr [rbp-0x248], r14
       mov      dword ptr [rbp-0x240], r15d
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x28], r9
       lea      rdx, [rbp-0x248]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x10]
       mov      rcx, rdi
       mov      r9d, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       mov      bword ptr [rbp-0x248], r14
       mov      dword ptr [rbp-0x240], r15d
       mov      dword ptr [rsp+0x20], 1
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x28], r9
       lea      rdx, [rbp-0x248]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x0C]
       mov      rcx, rdi
       mov      r9d, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp+0xAC0], xmm0
       mov      rcx, r12
       test     rcx, rcx
       je       SHORT G_M000_IG206
 
G_M000_IG205:                ;; offset=0x184A
       mov      rdx, 0x7FF9D77E3D68
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG448
       xor      rcx, rcx
 
G_M000_IG206:                ;; offset=0x185F
       test     rcx, rcx
       jne      G_M000_IG214
 
G_M000_IG207:                ;; offset=0x1868
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x1877
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG449
 
G_M000_IG209:                ;; offset=0x188B
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG210:                ;; offset=0x1895
       cmp      eax, r15d
       jae      G_M000_IG500
       mov      r13d, eax
       shl      r13, 4
       add      r13, r14
       mov      rcx, r13
       mov      rdx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r13+0x08], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG212
 
G_M000_IG211:                ;; offset=0x18C8
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG450
 
G_M000_IG212:                ;; offset=0x18DC
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG213:                ;; offset=0x18E6
       inc      eax
       cmp      eax, r15d
       jae      G_M000_IG500
       mov      r15d, eax
       shl      r15, 4
       add      r14, r15
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       lea      ecx, [rbx+0x02]
       mov      rdi, bword ptr [rbp+0xC20]
       mov      dword ptr [rdi+0x60], ecx
       jmp      G_M000_IG279
 
G_M000_IG214:                ;; offset=0x191E
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp+0xAC0]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      rdx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG207
 
G_M000_IG215:                ;; offset=0x1961
       mov      rdx, gword ptr [rbp+0xAC0]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x197F
       jmp      G_M000_IG506
 
G_M000_IG217:                ;; offset=0x1984
       vmovdqu  xmm0, xmmword ptr [rbp+0xAC0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG218:                ;; offset=0x1994
       lea      r9, [rbp-0x258]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG219:                ;; offset=0x19BB
       mov      edx, esi
       not      edx
       mov      r8, gword ptr [rdi+0x30]
       cmp      dword ptr [r8+0x08], edx
       jg       G_M000_IG473
 
G_M000_IG220:                ;; offset=0x19CD
       mov      rax, gword ptr [rdi+0x38]
       mov      r10d, edx
       sub      r10d, dword ptr [r8+0x08]
       cmp      r10d, dword ptr [rax+0x08]
       jae      G_M000_IG500
       mov      rsi, gword ptr [rax+8*r10+0x10]
       sub      edx, dword ptr [r8+0x08]
       lea      r9, [rbp-0x238]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG474
       mov      r13, gword ptr [rbp-0x238]
       jmp      G_M000_IG78
 
G_M000_IG221:                ;; offset=0x1A16
       mov      r10, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [r10+0x18]
       mov      r10d, edx
       not      r10d
       jmp      G_M000_IG83
 
G_M000_IG222:                ;; offset=0x1A2C
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG223:                ;; offset=0x1A59
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG224:                ;; offset=0x1A68
       mov      rax, gword ptr [rbp+0xC30]
       mov      r10, rax
       test     r10, r10
       jne      SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x1A77
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
 
G_M000_IG226:                ;; offset=0x1A81
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG227:                ;; offset=0x1AA3
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG228:                ;; offset=0x1AC6
       test     al, al
       jne      SHORT G_M000_IG232
 
G_M000_IG229:                ;; offset=0x1ACA
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG230:                ;; offset=0x1AD1
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG231:                ;; offset=0x1ADE
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp+0xB18]
       test     rbx, rbx
       je       G_M000_IG02
       jmp      G_M000_IG343
 
G_M000_IG232:                ;; offset=0x1B11
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG233:                ;; offset=0x1B18
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG234:                ;; offset=0x1B25
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       jne      G_M000_IG345
 
G_M000_IG235:                ;; offset=0x1B8B
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG236:                ;; offset=0x1B9D
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG163
 
G_M000_IG237:                ;; offset=0x1BED
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG502
 
G_M000_IG238:                ;; offset=0x1BF8
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, r9
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG240
 
G_M000_IG239:                ;; offset=0x1C29
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG201
 
G_M000_IG240:                ;; offset=0x1C3A
       cmp      byte  ptr [rbp+0xC38], 0
       je       SHORT G_M000_IG242
 
G_M000_IG241:                ;; offset=0x1C43
       test     rbx, rbx
       jne      G_M000_IG493
 
G_M000_IG242:                ;; offset=0x1C4C
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG243:                ;; offset=0x1C79
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG199
 
G_M000_IG244:                ;; offset=0x1C8E
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
 
G_M000_IG245:                ;; offset=0x1CC4
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      r9, gword ptr [rbp+0xC28]
       test     al, al
       je       G_M000_IG133
 
G_M000_IG246:                ;; offset=0x1CDA
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG133
 
G_M000_IG247:                ;; offset=0x1CE5
       xor      rdx, rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], rdx
       mov      word  ptr [r10+0x08], 0
       movzx    rdx, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], dl
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG502
 
G_M000_IG248:                ;; offset=0x1D17
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG249:                ;; offset=0x1D44
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
 
G_M000_IG250:                ;; offset=0x1DA0
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG502
 
G_M000_IG251:                ;; offset=0x1DC4
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG252:                ;; offset=0x1DD9
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG256
 
G_M000_IG253:                ;; offset=0x1DE2
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG254:                ;; offset=0x1DE9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG255:                ;; offset=0x1DF6
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp+0xB18]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG337
 
G_M000_IG256:                ;; offset=0x1E29
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG257:                ;; offset=0x1E30
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG258:                ;; offset=0x1E3D
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rsi+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       je       G_M000_IG235
       jmp      G_M000_IG339
 
G_M000_IG259:                ;; offset=0x1EAE
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG201
 
G_M000_IG260:                ;; offset=0x1EF2
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG353
 
G_M000_IG261:                ;; offset=0x1EFF
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG262:                ;; offset=0x1F0F
       mov      rsi, gword ptr [rbp+0xB08]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG351
 
G_M000_IG263:                ;; offset=0x1F24
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG264:                ;; offset=0x1F32
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG500
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x1E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1E0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG265:                ;; offset=0x1FB1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x258], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x250], r9
       lea      r9, [rbp-0x258]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG266:                ;; offset=0x201C
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG268
 
G_M000_IG267:                ;; offset=0x202A
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      r15, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [r15+0x18]
       mov      r8d, dword ptr [r15+0x10]
       mov      r9d, dword ptr [r15+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG336
 
G_M000_IG268:                ;; offset=0x205A
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG201
 
G_M000_IG269:                ;; offset=0x209C
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1D0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG270:                ;; offset=0x20D7
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       jmp      G_M000_IG49
 
G_M000_IG271:                ;; offset=0x20FF
       xor      rax, rax
       jmp      G_M000_IG60
 
G_M000_IG272:                ;; offset=0x2106
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r12], rax
       jne      G_M000_IG61
 
G_M000_IG273:                ;; offset=0x211A
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG63
 
G_M000_IG274:                ;; offset=0x214B
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xB0]
       cmp      esi, 42
       jne      G_M000_IG444
       mov      r11, bword ptr [rbp+0xBB8]
       mov      r11d, dword ptr [r11+0x08]
       mov      rax, 0x7FF9D7638680
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG445
       cmp      dword ptr [rdx+0x08], r11d
       jbe      G_M000_IG324
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      rsi, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG275:                ;; offset=0x219C
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x21AB
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG446
 
G_M000_IG277:                ;; offset=0x21BF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      ebx, dword ptr [rdx+0x14]
 
G_M000_IG278:                ;; offset=0x21C9
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x10], 0
       jl       G_M000_IG202
 
G_M000_IG279:                ;; offset=0x21DA
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rax, bword ptr [rcx+0x20]
       cmp      byte  ptr [rsi], sil
       mov      rax, gword ptr [rax]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, ebx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG500
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG451
 
G_M000_IG280:                ;; offset=0x2226
       mov      rdx, gword ptr [rax]
       mov      r8, 0x21AC8401CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG452
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG453
       mov      rdi, gword ptr [rax]
 
G_M000_IG281:                ;; offset=0x224A
       test     rdi, rdi
       je       G_M000_IG454
       mov      dword ptr [rsp+0x20], ebx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG289
 
G_M000_IG282:                ;; offset=0x228A
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
 
G_M000_IG283:                ;; offset=0x2298
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x22B6
       jmp      G_M000_IG506
 
G_M000_IG285:                ;; offset=0x22BB
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x22CA
       mov      rcx, 0x7FF9D76A9D18
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG455
 
G_M000_IG287:                ;; offset=0x22DD
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
 
G_M000_IG288:                ;; offset=0x2308
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG502
 
G_M000_IG289:                ;; offset=0x2327
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG456
 
G_M000_IG290:                ;; offset=0x2335
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rsi
       mov      r8d, ebx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG293
 
G_M000_IG291:                ;; offset=0x2366
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG468
 
G_M000_IG292:                ;; offset=0x2373
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdi, gword ptr [rbp+0xB18]
       test     rdi, rdi
       je       G_M000_IG02
       jmp      G_M000_IG466
 
G_M000_IG293:                ;; offset=0x23AD
       mov      r8, bword ptr [rbp+0xC50]
       mov      r13, gword ptr [r8]
       test     r13, r13
       jne      G_M000_IG459
 
G_M000_IG294:                ;; offset=0x23C0
       mov      r8, bword ptr [rbp+0xC50]
       mov      rbx, gword ptr [r8]
       test     rbx, rbx
       jne      G_M000_IG462
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG295:                ;; offset=0x23D7
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      rdi, rcx
       je       G_M000_IG465
       jmp      G_M000_IG288
 
G_M000_IG296:                ;; offset=0x23EC
       cmp      edx, 72
       je       G_M000_IG14
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x23AEEE0D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG297:                ;; offset=0x2415
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG16
 
G_M000_IG298:                ;; offset=0x2429
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG16
 
G_M000_IG299:                ;; offset=0x243D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG16
 
G_M000_IG300:                ;; offset=0x2451
       mov      rcx, rdi
       mov      edx, esi
       mov      r8, r15
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG21
 
G_M000_IG301:                ;; offset=0x246B
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG25
 
G_M000_IG302:                ;; offset=0x2480
       mov      rdx, gword ptr [rdi]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      eax, r12d
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       G_M000_IG30
       cmp      gword ptr [rdi+0x28], 0
       jne      SHORT G_M000_IG303
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG304
 
G_M000_IG303:                ;; offset=0x24C9
       mov      rcx, gword ptr [rdi+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG304:                ;; offset=0x24D9
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [rdi]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG500
       mov      ecx, r12d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG305:                ;; offset=0x2503
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG35
 
G_M000_IG306:                ;; offset=0x250C
       mov      rcx, 0x7FF9D77CE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       mov      r8, rcx
       jmp      G_M000_IG32
 
G_M000_IG307:                ;; offset=0x2526
       mov      rax, gword ptr [r13+0x10]
       mov      eax, dword ptr [rax+0x08]
       mov      r10, gword ptr [r8+0x10]
       cmp      eax, dword ptr [r10+0x08]
       jge      SHORT G_M000_IG309
       jmp      G_M000_IG47
 
G_M000_IG308:                ;; offset=0x253C
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG35
 
G_M000_IG309:                ;; offset=0x254A
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG35
 
G_M000_IG310:                ;; offset=0x2558
       mov      rcx, r8
       mov      rax, qword ptr [r8]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG35
 
G_M000_IG311:                ;; offset=0x256A
       mov      r8, gword ptr [r13]
       mov      gword ptr [rbp-0x2A0], r8
       mov      rdx, r8
       mov      rcx, 0x7FF9D7753360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG312
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      SHORT G_M000_IG312
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, 0x7FF9D76608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG34
 
G_M000_IG312:                ;; offset=0x25CE
       mov      rax, gword ptr [r13]
       mov      gword ptr [rbp-0x298], rax
       xor      edx, edx
       mov      qword ptr [r13], rdx
       mov      qword ptr [r13+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG313
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x290]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG35
 
G_M000_IG313:                ;; offset=0x261A
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdx, gword ptr [rbp-0x298]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG35
 
G_M000_IG314:                ;; offset=0x2635
       mov      rdx, gword ptr [r13]
       mov      r8, 0x21AC8401CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG35
       mov      rdx, gword ptr [r13]
       mov      r8, 0x21AC8401CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG35
       xor      edx, edx
       mov      qword ptr [r13], rdx
       mov      qword ptr [r13+0x08], rdx
       mov      rcx, 0x7FF9D763E7B8
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d708b100)]
       mov      rcx, gword ptr [rbp-0x290]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG35
 
G_M000_IG315:                ;; offset=0x2698
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG316:                ;; offset=0x26A4
       mov      r10d, dword ptr [r11+0x04]
       add      r10d, -24
       shr      r10d, 3
       movsxd   r13, r10d
       mov      r13d, dword ptr [r8+4*r13]
       shl      r10d, 3
       movsxd   r10, r10d
       add      r8, r10
       mov      r10d, r13d
       jmp      G_M000_IG37
 
G_M000_IG317:                ;; offset=0x26C9
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG318:                ;; offset=0x26D0
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG39
 
G_M000_IG319:                ;; offset=0x26DE
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG50
 
G_M000_IG320:                ;; offset=0x26F0
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG321:                ;; offset=0x2713
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG322:                ;; offset=0x2723
       mov      edx, edi
       mov      rcx, rsi
       lea      r9, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG323:                ;; offset=0x273A
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG53
 
G_M000_IG324:                ;; offset=0x274C
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG325:                ;; offset=0x2753
       mov      rcx, rax
       mov      edx, r14d
       mov      r11, 0x7FF9D7092980
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG58
 
G_M000_IG326:                ;; offset=0x276E
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG63
 
G_M000_IG327:                ;; offset=0x27A6
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rsi, rax
       mov      ecx, r14d
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       mov      rdx, r15
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG63
 
G_M000_IG328:                ;; offset=0x27FD
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG329
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x280D
       lea      rax, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG330:                ;; offset=0x2815
       mov      bword ptr [rbp-0x248], rax
       mov      dword ptr [rbp-0x240], r8d
 
G_M000_IG331:                ;; offset=0x2823
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG332:                ;; offset=0x2833
       lea      rcx, [rbp-0x248]
       lea      r8, [rbp-0x258]
       mov      r15, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [r15+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG63
 
G_M000_IG333:                ;; offset=0x2857
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x23AEEE12BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG334:                ;; offset=0x2885
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG63
 
G_M000_IG335:                ;; offset=0x28AA
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092958
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG336:                ;; offset=0x28F3
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG337:                ;; offset=0x28FD
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG338
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rdx, rax
       mov      rcx, rdx
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG338:                ;; offset=0x293C
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7092988
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG339:                ;; offset=0x2959
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG340
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x2981
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7092990
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG341:                ;; offset=0x29A7
       test     edi, edi
       jne      G_M000_IG235
 
G_M000_IG342:                ;; offset=0x29AF
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG502
 
G_M000_IG343:                ;; offset=0x29D4
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG344
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rdx, rax
       mov      rcx, rdx
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG344:                ;; offset=0x2A13
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7092998
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG345:                ;; offset=0x2A30
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG346
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2A58
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG347:                ;; offset=0x2A7E
       test     esi, esi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG348:                ;; offset=0x2A8B
       mov      rax, rcx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG349:                ;; offset=0x2A94
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG350:                ;; offset=0x2A9B
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG136
 
G_M000_IG351:                ;; offset=0x2AA6
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG352
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rdx, rax
       mov      rcx, rdx
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG352:                ;; offset=0x2AE5
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70929A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG353:                ;; offset=0x2B02
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x288], xmm0
 
G_M000_IG354:                ;; offset=0x2B12
       lea      rdx, [rbp-0x288]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       je       G_M000_IG235
 
G_M000_IG355:                ;; offset=0x2B5D
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG356
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG357
 
G_M000_IG356:                ;; offset=0x2B85
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70929B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG357:                ;; offset=0x2BAB
       test     edi, edi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG358:                ;; offset=0x2BB8
       cmp      byte  ptr [rax+0xFF], 0
       jne      G_M000_IG130
 
G_M000_IG359:                ;; offset=0x2BC5
       cmp      ebx, esi
       jle      G_M000_IG130
 
G_M000_IG360:                ;; offset=0x2BCD
       cmp      esi, ebx
       jae      G_M000_IG500
       mov      r8, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       cmp      dword ptr [r8+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       jmp      G_M000_IG131
 
G_M000_IG361:                ;; offset=0x2BF6
       test     rdi, rdi
       je       G_M000_IG132
 
G_M000_IG362:                ;; offset=0x2BFF
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG363:                ;; offset=0x2C0F
       lea      r8, [rbp-0x258]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG132
 
G_M000_IG364:                ;; offset=0x2C2A
       cmp      esi, ebx
       jae      G_M000_IG500
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       mov      r15, gword ptr [rcx+r14+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG366
 
G_M000_IG365:                ;; offset=0x2C63
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG366:                ;; offset=0x2C6F
       mov      r9, gword ptr [rbp+0xC28]
       mov      rsi, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG368
 
G_M000_IG367:                ;; offset=0x2C8E
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG369
 
G_M000_IG368:                ;; offset=0x2C9E
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG369:                ;; offset=0x2CB3
       lea      rcx, bword ptr [rsi+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       lea      rcx, bword ptr [rax+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG509
 
G_M000_IG370:                ;; offset=0x2CF7
       test     rdi, rdi
       je       G_M000_IG133
 
G_M000_IG371:                ;; offset=0x2D00
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG133
       jmp      G_M000_IG509
 
G_M000_IG372:                ;; offset=0x2D19
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG373:                ;; offset=0x2D20
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG374:                ;; offset=0x2D2D
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG378
 
G_M000_IG375:                ;; offset=0x2D7B
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG376
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG377
 
G_M000_IG376:                ;; offset=0x2DA3
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70929B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG377:                ;; offset=0x2DC9
       test     edi, edi
       je       G_M000_IG342
 
G_M000_IG378:                ;; offset=0x2DD1
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG127
 
G_M000_IG379:                ;; offset=0x2DE3
       mov      rax, gword ptr [rbp+0xC30]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG381
 
G_M000_IG380:                ;; offset=0x2DF5
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG381:                ;; offset=0x2EAA
       mov      rax, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rax+0x68]
       mov      r8, gword ptr [rax+0x58]
       mov      r9, gword ptr [rax+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG382:                ;; offset=0x2ED3
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG383:                ;; offset=0x2EE0
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG127
 
G_M000_IG384:                ;; offset=0x2F00
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [r8+0x70]
       test     rdx, rdx
       je       G_M000_IG133
 
G_M000_IG385:                ;; offset=0x2F29
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG133
       jmp      G_M000_IG509
 
G_M000_IG386:                ;; offset=0x2F3F
       mov      r15, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [r15]
       mov      r8, gword ptr [r15+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG387:                ;; offset=0x2F62
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       je       G_M000_IG235
 
G_M000_IG388:                ;; offset=0x2FC4
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG389
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG390
 
G_M000_IG389:                ;; offset=0x2FEC
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70929C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG390:                ;; offset=0x3012
       test     edi, edi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG391:                ;; offset=0x301F
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG201
 
G_M000_IG392:                ;; offset=0x3042
       test     al, al
       jne      SHORT G_M000_IG394
 
G_M000_IG393:                ;; offset=0x3046
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG394:                ;; offset=0x3062
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG395:                ;; offset=0x3069
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG396:                ;; offset=0x3076
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG235
 
G_M000_IG397:                ;; offset=0x30C8
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG398
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG399
 
G_M000_IG398:                ;; offset=0x30F0
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70929C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG399:                ;; offset=0x3116
       test     edi, edi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG400:                ;; offset=0x3123
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x248], xmm0
 
G_M000_IG401:                ;; offset=0x312F
       lea      r9, [rbp-0x248]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG502
 
G_M000_IG402:                ;; offset=0x3160
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG403:                ;; offset=0x3167
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG404:                ;; offset=0x3174
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG163
 
G_M000_IG405:                ;; offset=0x31C6
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG406
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG407
 
G_M000_IG406:                ;; offset=0x31EE
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG407:                ;; offset=0x3214
       test     esi, esi
       jne      G_M000_IG163
       jmp      G_M000_IG342
 
G_M000_IG408:                ;; offset=0x3221
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG500
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG151
 
G_M000_IG409:                ;; offset=0x3251
       mov      rax, 0x7FF9D77E5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG151
 
G_M000_IG410:                ;; offset=0x3264
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG151
 
G_M000_IG411:                ;; offset=0x3276
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG151
 
G_M000_IG412:                ;; offset=0x3281
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG163
 
G_M000_IG413:                ;; offset=0x32E0
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG414
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG415
 
G_M000_IG414:                ;; offset=0x3308
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG415:                ;; offset=0x332E
       test     esi, esi
       jne      G_M000_IG163
       jmp      G_M000_IG342
 
G_M000_IG416:                ;; offset=0x333B
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG153
 
G_M000_IG417:                ;; offset=0x334C
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG153
 
G_M000_IG418:                ;; offset=0x335D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG153
 
G_M000_IG419:                ;; offset=0x336E
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG420:                ;; offset=0x339C
       mov      rdx, rdi
       mov      rcx, 0x7FF9D7753360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG156
 
G_M000_IG421:                ;; offset=0x33B3
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r15d, eax
       jmp      G_M000_IG174
 
G_M000_IG422:                ;; offset=0x33C8
       lea      rbx, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG181
 
G_M000_IG423:                ;; offset=0x33E9
       cmp      dword ptr [rcx+0x20], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG182
 
G_M000_IG424:                ;; offset=0x33FB
       lea      rbx, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG425:                ;; offset=0x341E
       vmovdqu  xmm0, xmmword ptr [rbp-0x220]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG426:                ;; offset=0x342E
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG427:                ;; offset=0x3445
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG185
 
G_M000_IG428:                ;; offset=0x3457
       mov      edx, r14d
       mov      r11, 0x7FF9D70929E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG190
 
G_M000_IG429:                ;; offset=0x346F
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG63
 
G_M000_IG430:                ;; offset=0x34A7
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx], cl
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, r14d
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r15
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG63
 
G_M000_IG431:                ;; offset=0x34FA
       cmp      ebx, 71
       jne      SHORT G_M000_IG437
 
G_M000_IG432:                ;; offset=0x34FF
       mov      rcx, gword ptr [rdi+0x20]
       test     rcx, rcx
       jne      SHORT G_M000_IG433
       xor      r8, r8
       xor      ecx, ecx
       jmp      SHORT G_M000_IG434
 
G_M000_IG433:                ;; offset=0x350F
       lea      r8, bword ptr [rcx+0x10]
       mov      ecx, dword ptr [rcx+0x08]
 
G_M000_IG434:                ;; offset=0x3516
       mov      bword ptr [rbp-0x248], r8
       mov      dword ptr [rbp-0x240], ecx
 
G_M000_IG435:                ;; offset=0x3523
       vmovdqu  xmm0, xmmword ptr [rbp-0x220]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG436:                ;; offset=0x3533
       lea      rcx, [rbp-0x248]
       lea      r8, [rbp-0x258]
       mov      r9, gword ptr [rdi+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG63
 
G_M000_IG437:                ;; offset=0x3550
       cmp      ebx, 30
       je       SHORT G_M000_IG439
 
G_M000_IG438:                ;; offset=0x3555
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE12BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG439:                ;; offset=0x3583
       cmp      gword ptr [rbp-0x220], 0
       jne      G_M000_IG63
 
G_M000_IG440:                ;; offset=0x3591
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F24F0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG63
 
G_M000_IG441:                ;; offset=0x35B6
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG442
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG443
 
G_M000_IG442:                ;; offset=0x35DE
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG443:                ;; offset=0x3604
       test     esi, esi
       jne      G_M000_IG163
       jmp      G_M000_IG342
 
G_M000_IG444:                ;; offset=0x3611
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x23AEEE0D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG445:                ;; offset=0x3631
       mov      rcx, rdx
       mov      edx, r11d
       mov      r11, 0x7FF9D7092960
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG275
 
G_M000_IG446:                ;; offset=0x364C
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      ebx, eax
       jmp      G_M000_IG278
 
G_M000_IG447:                ;; offset=0x3660
       xor      r14, r14
       xor      r15d, r15d
       jmp      G_M000_IG204
 
G_M000_IG448:                ;; offset=0x366B
       mov      rdx, r12
       mov      rcx, 0x7FF9D775AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG206
 
G_M000_IG449:                ;; offset=0x3685
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG210
 
G_M000_IG450:                ;; offset=0x3697
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG213
 
G_M000_IG451:                ;; offset=0x36A9
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG281
 
G_M000_IG452:                ;; offset=0x36C1
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG281
 
G_M000_IG453:                ;; offset=0x36D9
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG281
 
G_M000_IG454:                ;; offset=0x36F1
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG455:                ;; offset=0x371F
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG456:                ;; offset=0x3725
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp+0xAA8]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG201
 
G_M000_IG457:                ;; offset=0x3758
       cmp      gword ptr [rbp+0xAA8], 0
       je       G_M000_IG02
 
G_M000_IG458:                ;; offset=0x3766
       mov      rdx, gword ptr [rbp+0xAA8]
       xor      r8, r8
       mov      r10, bword ptr [rbp+0xC50]
       mov      gword ptr [r10], r8
       lea      rcx, bword ptr [r10+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r10, bword ptr [rbp+0xC50]
       mov      word  ptr [r10+0x10], 0
       mov      byte  ptr [r10+0x12], 1
       jmp      G_M000_IG288
 
G_M000_IG459:                ;; offset=0x379B
       mov      rdx, r13
       mov      rcx, 0x7FF9D78859B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG460
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG461
 
G_M000_IG460:                ;; offset=0x37BD
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r13
       mov      r11, 0x7FF9D70929F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG461:                ;; offset=0x37E2
       test     eax, eax
       je       G_M000_IG288
       jmp      G_M000_IG294
 
G_M000_IG462:                ;; offset=0x37EF
       mov      rdx, rbx
       mov      rcx, 0x7FF9D78859B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG464
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG463
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG463:                ;; offset=0x3825
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG295
 
G_M000_IG464:                ;; offset=0x382E
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG295
 
G_M000_IG465:                ;; offset=0x3852
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG223
 
G_M000_IG466:                ;; offset=0x386B
       mov      rdx, rdi
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG467
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rdx, rax
       mov      rcx, rdx
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG467:                ;; offset=0x38AA
       mov      rcx, rdi
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7092A08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG468:                ;; offset=0x38C7
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [r10]
       test     rsi, rsi
       je       G_M000_IG235
 
G_M000_IG469:                ;; offset=0x3939
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG470
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG471
 
G_M000_IG470:                ;; offset=0x395F
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7092A10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG471:                ;; offset=0x3983
       test     ebx, ebx
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG472:                ;; offset=0x3990
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG69
 
G_M000_IG473:                ;; offset=0x3999
       mov      rax, r8
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG500
       mov      edx, edx
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG78
 
G_M000_IG474:                ;; offset=0x39BA
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG475:                ;; offset=0x39DE
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG72
 
G_M000_IG476:                ;; offset=0x39EF
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG72
 
G_M000_IG477:                ;; offset=0x3A00
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG72
 
G_M000_IG478:                ;; offset=0x3A11
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       jmp      G_M000_IG78
 
G_M000_IG479:                ;; offset=0x3A3D
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x23AEEE0AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG480:                ;; offset=0x3A6B
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG81
 
G_M000_IG481:                ;; offset=0x3A7D
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG482:                ;; offset=0x3A84
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG483:                ;; offset=0x3A91
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG235
 
G_M000_IG484:                ;; offset=0x3AF7
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG485
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG486
 
G_M000_IG485:                ;; offset=0x3B1F
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG486:                ;; offset=0x3B45
       test     esi, esi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG487:                ;; offset=0x3B52
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG488:                ;; offset=0x3B59
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG489:                ;; offset=0x3B66
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG235
 
G_M000_IG490:                ;; offset=0x3BCC
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG491
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG492
 
G_M000_IG491:                ;; offset=0x3BF4
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG492:                ;; offset=0x3C1A
       test     esi, esi
       jne      G_M000_IG235
       jmp      G_M000_IG342
 
G_M000_IG493:                ;; offset=0x3C27
       mov      r8, 0x7FF9D77E9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG242
 
G_M000_IG494:                ;; offset=0x3C3A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG495:                ;; offset=0x3C41
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x278], ymm0
 
G_M000_IG496:                ;; offset=0x3C4E
       lea      r8, [rbp-0x278]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG163
 
G_M000_IG497:                ;; offset=0x3CA2
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG498
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG499
 
G_M000_IG498:                ;; offset=0x3CCA
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG499:                ;; offset=0x3CF0
       test     esi, esi
       jne      G_M000_IG163
       jmp      G_M000_IG342
 
G_M000_IG500:                ;; offset=0x3CFD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG501:                ;; offset=0x3D03
       lea      rcx, [rbp+0xA78]
       mov      rdx, 0x23AEEE12A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG124
 
G_M000_IG502:                ;; offset=0x3D1F
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG503:                ;; offset=0x3D25
       vzeroupper 
       add      rsp, 0xEB8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG504:                ;; offset=0x3D3C
       mov      eax, 1
 
G_M000_IG505:                ;; offset=0x3D41
       vzeroupper 
       add      rsp, 0xEB8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG506:                ;; offset=0x3D58
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, r13
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG510
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG507:                ;; offset=0x3D8C
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG10
 
G_M000_IG508:                ;; offset=0x3DA2
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG10
 
G_M000_IG509:                ;; offset=0x3DB3
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      G_M000_IG504
 
G_M000_IG510:                ;; offset=0x3DC8
       mov      rcx, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG511:                ;; offset=0x3DD1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG512:                ;; offset=0x3DD7
       sub      rsp, 72
 
G_M000_IG513:                ;; offset=0x3DDB
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG515
 
G_M000_IG514:                ;; offset=0x3DE8
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG515:                ;; offset=0x3DEE
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG518
 
G_M000_IG516:                ;; offset=0x3E12
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG502
 
G_M000_IG517:                ;; offset=0x3E23
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG518:                ;; offset=0x3E2B
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG519:                ;; offset=0x3E3C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG520:                ;; offset=0x3E44
       sub      rsp, 72
 
G_M000_IG521:                ;; offset=0x3E48
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG523
 
G_M000_IG522:                ;; offset=0x3E76
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG523:                ;; offset=0x3E7C
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG524:                ;; offset=0x3E8D
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00000D3Fh ; case G_M000_IG118
       	dd	00000C4Ah ; case G_M000_IG111
       	dd	0000011Dh ; case G_M000_IG12
       	dd	00001F88h ; case G_M000_IG266
       	dd	00001F1Dh ; case G_M000_IG265
       	dd	00001E90h ; case G_M000_IG263
       	dd	00001E1Ah ; case G_M000_IG259
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001CB0h ; case G_M000_IG249
       	dd	00001CB0h ; case G_M000_IG249
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00001D30h ; case G_M000_IG251
       	dd	00000BF3h ; case G_M000_IG109
       	dd	00000BF3h ; case G_M000_IG109
       	dd	00000BC2h ; case G_M000_IG107
       	dd	00000B98h ; case G_M000_IG106
       	dd	00000B70h ; case G_M000_IG105
       	dd	00000ADCh ; case G_M000_IG103
       	dd	00000A32h ; case G_M000_IG99
       	dd	000009C1h ; case G_M000_IG98
       	dd	0000097Eh ; case G_M000_IG97
       	dd	00000901h ; case G_M000_IG96
       	dd	00000832h ; case G_M000_IG91
       	dd	00000805h ; case G_M000_IG89
       	dd	00000805h ; case G_M000_IG89
       	dd	00000805h ; case G_M000_IG89
       	dd	000007E8h ; case G_M000_IG87
       	dd	000007E8h ; case G_M000_IG87
       	dd	000007E8h ; case G_M000_IG87
       	dd	00000805h ; case G_M000_IG89
       	dd	0000065Fh ; case G_M000_IG68
       	dd	000011E2h ; case G_M000_IG151
       	dd	000020B7h ; case G_M000_IG274
       	dd	00001698h ; case G_M000_IG198
       	dd	00001675h ; case G_M000_IG196
       	dd	0000165Eh ; case G_M000_IG195
       	dd	00001C83h ; case G_M000_IG248
       	dd	00001C83h ; case G_M000_IG248
       	dd	00001C83h ; case G_M000_IG248
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001B64h ; case G_M000_IG238
       	dd	00001B09h ; case G_M000_IG236
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00001BE5h ; case G_M000_IG243
       	dd	00000F80h ; case G_M000_IG133
       	dd	00000EBFh ; case G_M000_IG128
       	dd	00000E86h ; case G_M000_IG125
       	dd	00001BE5h ; case G_M000_IG243
       	dd	000019D4h ; case G_M000_IG224
       	dd	000019D4h ; case G_M000_IG224
       	dd	000019D4h ; case G_M000_IG224
       	dd	000019D4h ; case G_M000_IG224
       	dd	000019D4h ; case G_M000_IG224
       	dd	00001998h ; case G_M000_IG222
       	dd	000011B2h ; case G_M000_IG149
       	dd	0000107Eh ; case G_M000_IG141
       	dd	00000FC7h ; case G_M000_IG135
       	dd	00000F8Fh ; case G_M000_IG134
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 16021

