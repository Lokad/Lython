from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "forwarded-global-call-20261123"
identity = json.loads((prior / "comparison/identity.json").read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
tree=repo/".git/agent-worktrees/forwarded-global-call-20261123"
assert not subprocess.check_output(['git','-C',tree,'status','--porcelain'],encoding='utf-8')
revision=subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],encoding='utf-8').strip()
base=revision and subprocess.check_output(['git','-C',tree,'rev-parse','HEAD^'],encoding='utf-8').strip()
assert not subprocess.check_output(['git','diff','--name-only',base,'HEAD','--','src','tests'],cwd=repo)
assert not subprocess.check_output(['git','diff','--name-only',base,identity['candidate'],'--','src','tests'],cwd=repo)
comparison = lab / "comparison"
comparison.mkdir(exist_ok=True)
assert len(identity["imageFiles"]["candidate"]) == 32
for file in ("representative.json", "jobs.json"):
    shutil.copyfile(lab / file, comparison / file)
core = "Lokad.Lython.dll"
image_files = {}
for role in ("reference", "candidate"):
    images = lab / role
    images.mkdir(exist_ok=True)
    files = identity["imageFiles"]["candidate"]
    for name, digest in files.items():
        original=prior/'candidate'/name
        assert sha(original)==digest
        if name==core and role=='candidate':
            original=lab/'windows-frozen/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(original,images/name)
    for name in ("ValidatedAllocation.dll","ValidatedAllocation.deps.json","ValidatedAllocation.runtimeconfig.json"):
        shutil.copyfile(prior/'candidate'/name,images/name)
    image_files[role] = {name: sha(images / name) for name in files}
assert [name for name in files if image_files["reference"][name] != image_files["candidate"][name]] == [core]
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
catalog = comparison / "representative.json"
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == identity["cpythonWorkerSHA256"]
for role, files in image_files.items():
    receipt = comparison / (role + "-verify.json")
    worker = lab / role / "Lokad.Lython.Benchmarks.dll"
    subprocess.run([dotnet, worker, "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol, "--out", receipt],
        env=env, check=True, timeout=90)
    result = json.loads(receipt.read_text(encoding="utf-8"))
    assert result["state"] == "Completed" and result["caseCount"] == len(json.loads(catalog.read_text(encoding="utf-8"))["cases"]) and result["catalogSha256"] == sha(catalog)
    assert result["launched"]["library"]["sha256"] == files[core]
    assert all(sha(lab / role / n) == h for n, h in files.items())
new = dict(sourceRevision=base, sourceImageRevision=identity["candidate"], candidate=revision,
    purpose="B1492 share forwarded-call reads and staged fallback",
    imageFiles=image_files, coreSHA256={key: image_files[role][core] for role in image_files for key in (role, role + "-control")},
    cpythonWorkerSHA256=sha(protocol), expectedCPythonSHA256=identity["expectedCPythonSHA256"],
    catalogs={n: dict(sha256=sha(comparison / n)) for n in ("representative.json", "jobs.json")})
(comparison / "identity.json").write_text(json.dumps(new, indent=2) + "\n", encoding="utf-8", newline="\n")
print(revision, "five CPython goldens on both native call images")
