from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab/'comparison'
quiet = comparison/'quiet'
output = repo/'benchmarks/results/2026-11-23-forwarded-global-shared'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda blob: hashlib.sha256(blob).hexdigest()
identity = read(comparison/'identity.json')
terminal = read(quiet/'terminal-status.json')
assert not terminal['live'] and terminal['exitCode'] == '0' and not terminal['fixtures']
assert all(terminal['receipt'][key] for key in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((quiet/'observations.tar.xz').read_bytes()) == terminal['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches'] == 112
assert all(a['peakAdmission'][0] == a['peakAdmission'][1] for a in read(lab/'allocation-summary-six.json'))
identity['retainedRevision'] = (subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,encoding='utf-8').strip()
    if not subprocess.check_output(['git','diff','--name-only','HEAD',identity['candidate'],'--','src'],cwd=repo) else None)
patch = subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
(comparison/'production.patch').write_bytes(patch)
identity['productionPatchSHA256']=sha(patch)
output.mkdir(exist_ok=True)
(output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for role,files in identity['imageFiles'].items():
    assert len(files) == 32 and all(sha((lab/role/name).read_bytes()) == digest for name,digest in files.items())
    core=(lab/role/'Lokad.Lython.dll').read_bytes()
    if role=='reference':
        reused=output.parent/'2026-11-23-forwarded-global-call/candidate-core.dll.gz'
    else:
        reused=output/(role+'-core.dll.gz')
        reused.write_bytes(gzip.compress(core,mtime=0))
    assert sha(gzip.decompress(reused.read_bytes())) == files['Lokad.Lython.dll']
for name in ('observations.tar.xz','terminal-status.json','summary.json'):
    shutil.copyfile(quiet/name,output/name)
for name in ('allocation-summary-six.json','jit-summary.json'):
    shutil.copyfile(lab/name,output/name)
with tarfile.open(output/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','freeze.py','stage.py','quiet.py','summarize.py','inspect-jit.py','allocations.py',
                 'windows-frozen.log','windows-focused.log','ubuntu-focused.log','reference-native.asm','candidate-native.asm','jit.log',
                 'reference-allocation-six.json','candidate-allocation-six.json','allocation-summary-six.json','allocations.log',
                 'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/production.patch',
                 'launch.log','retrieval.log','comparison/quiet/observe-not-before'):
        archive.add(lab/name,arcname=name,recursive=False)
print(output,identity['retainedRevision'] or 'private')
