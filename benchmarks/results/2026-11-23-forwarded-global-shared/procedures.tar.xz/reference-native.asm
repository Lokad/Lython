; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 42
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xBC0], xmm4
       mov      rax, -0xB70
 
G_M000_IG253:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG253
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x66C], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG234
 
G_M000_IG03:                ;; offset=0x009B
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x678], rax
       mov      rdx, gword ptr [rbp-0x678]
       mov      rcx, gword ptr [rbp-0x1C0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FE
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0117
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0133
       jmp      G_M000_IG220
 
G_M000_IG07:                ;; offset=0x0138
       mov      rcx, 0x7FF9D77FA980
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG08:                ;; offset=0x0156
       mov      rcx, 0x7FF9D77FA984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x680], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x680]
       mov      rdx, gword ptr [rbp-0x5F0]
       mov      r8d, dword ptr [rbp-0x5F4]
       mov      rcx, gword ptr [rbp-0x5E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x688], rax
       mov      r9, gword ptr [rbp-0x688]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG09:                ;; offset=0x01F3
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0243
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x640], rax
       mov      rcx, gword ptr [rbp-0x640]
       mov      rdx, 0x7FF9D77FA988
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x690], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x694], eax
       mov      rcx, gword ptr [rbp-0x690]
       mov      edx, dword ptr [rbp-0x694]
       mov      r11, 0x7FF9D70A1A40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x220], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A0], rax
       mov      rdx, gword ptr [rbp-0x6A0]
       mov      rcx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EA
       mov      rcx, 0x7FF9D77FAA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG12:                ;; offset=0x02FE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5D4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x6A4], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x6A4]
       mov      rdx, gword ptr [rbp-0x5D0]
       mov      r8d, dword ptr [rbp-0x5D4]
       mov      rcx, gword ptr [rbp-0x5C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77FAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E0], rax
       mov      rax, bword ptr [rbp-0x5E0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG224
 
G_M000_IG13:                ;; offset=0x03C0
       mov      rcx, 0x7FF9D77FAA98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03CF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6B0], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6B0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77FAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG15:                ;; offset=0x0437
       mov      rcx, 0x7FF9D77FAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG16:                ;; offset=0x0461
       mov      rcx, 0x7FF9D77FAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG17:                ;; offset=0x048B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77FAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG18:                ;; offset=0x04BF
       mov      rcx, 0x7FF9D77FAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG19:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG20:                ;; offset=0x04E9
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6D0], ymm0
 
G_M000_IG22:                ;; offset=0x0501
       lea      r8, [rbp-0x6D0]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG23:                ;; offset=0x0544
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0548
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6F0], ymm0
 
G_M000_IG25:                ;; offset=0x0554
       lea      r8, [rbp-0x6F0]
       lea      rdx, [rbp-0x580]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0574
       vmovdqu  xmm0, xmmword ptr [rbp-0x580]
       vmovdqu  xmmword ptr [rbp-0x700], xmm0
 
G_M000_IG27:                ;; offset=0x0584
       lea      rdx, [rbp-0x700]
       lea      rcx, [rbp-0x590]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x590]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x588]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77FAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x708], rax
       mov      rcx, gword ptr [rbp-0x708]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG28:                ;; offset=0x0612
       mov      rcx, 0x7FF9D77FAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG29:                ;; offset=0x0630
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2E8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2F8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x300], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77FAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x300], rax
 
G_M000_IG30:                ;; offset=0x067D
       mov      rcx, bword ptr [rbp-0x2E8]
       mov      rdx, gword ptr [rbp-0x2F0]
       mov      r8, bword ptr [rbp-0x2F8]
       mov      r9, gword ptr [rbp-0x300]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77FAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG31:                ;; offset=0x06C8
       mov      rcx, 0x7FF9D77FAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG32:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77FAAC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x728], ymm0
 
G_M000_IG34:                ;; offset=0x0703
       lea      r8, [rbp-0x728]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG35:                ;; offset=0x0746
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074A
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x748], ymm0
 
G_M000_IG37:                ;; offset=0x0756
       lea      r8, [rbp-0x748]
       lea      rdx, [rbp-0x310]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0776
       vmovdqu  xmm0, xmmword ptr [rbp-0x310]
       vmovdqu  xmmword ptr [rbp-0x758], xmm0
 
G_M000_IG39:                ;; offset=0x0786
       lea      rdx, [rbp-0x758]
       lea      rcx, [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x320]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x318]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77FAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x760], rax
       mov      rcx, gword ptr [rbp-0x760]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG40:                ;; offset=0x0814
       mov      rcx, 0x7FF9D77FAACC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG41:                ;; offset=0x0832
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x268]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x768], rax
       mov      rdx, gword ptr [rbp-0x768]
       mov      rcx, 0x7FF9D759EAB0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x270], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x280], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x280]
       sub      ecx, eax
       mov      dword ptr [rbp-0x76C], ecx
       mov      r9d, dword ptr [rbp-0x76C]
       lea      rcx, [rbp-0x290]
       mov      rdx, gword ptr [rbp-0x278]
       mov      r8d, dword ptr [rbp-0x27C]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x298], rax
 
G_M000_IG42:                ;; offset=0x0914
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG43:                ;; offset=0x0924
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x2AC], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2B8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77FAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2B8], rax
 
G_M000_IG44:                ;; offset=0x0960
       mov      rcx, 0x7FF9D77FAAD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x096F
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x780], xmm0
 
G_M000_IG46:                ;; offset=0x097F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x788], rax
       mov      rax, gword ptr [rbp-0x788]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x780]
       mov      r8d, dword ptr [rbp-0x2AC]
       mov      r9, gword ptr [rbp-0x2B8]
       mov      rcx, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x78C], eax
       mov      edx, dword ptr [rbp-0x78C]
       mov      rcx, bword ptr [rbp-0x2C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG224
 
G_M000_IG47:                ;; offset=0x09FB
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x228], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x790], eax
       mov      r9d, dword ptr [rbp-0x790]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x22C]
       mov      rcx, bword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x798], rax
       mov      rdx, gword ptr [rbp-0x798]
       lea      rcx, [rbp-0x240]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x248], rax
 
G_M000_IG48:                ;; offset=0x0A89
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG49:                ;; offset=0x0A96
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77FAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG50:                ;; offset=0x0AC2
       mov      rcx, 0x7FF9D77FAADC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD1
       vmovdqu  xmm0, xmmword ptr [rbp-0x240]
       vmovdqu  xmmword ptr [rbp-0x7A8], xmm0
 
G_M000_IG52:                ;; offset=0x0AE1
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x7B8], xmm0
 
G_M000_IG53:                ;; offset=0x0AF1
       mov      rcx, gword ptr [rbp-0x260]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7C0], rax
       mov      r9, gword ptr [rbp-0x7C0]
       lea      r8, [rbp-0x7B8]
       lea      rcx, [rbp-0x7A8]
       mov      rdx, bword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG224
 
G_M000_IG54:                ;; offset=0x0B2E
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77FAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG55:                ;; offset=0x0B77
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77FAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG56:                ;; offset=0x0BB1
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7D0], xmm0
 
G_M000_IG57:                ;; offset=0x0BBE
       lea      rdx, [rbp-0x7D0]
       lea      rcx, [rbp-0x5A0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x5A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x598]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77FAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7D8], rax
       mov      rcx, gword ptr [rbp-0x7D8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG58:                ;; offset=0x0C4C
       mov      rcx, 0x7FF9D77FAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG59:                ;; offset=0x0C6A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77FAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG60:                ;; offset=0x0C8F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x370], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7DC], eax
       mov      r9d, dword ptr [rbp-0x7DC]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x374]
       mov      rcx, bword ptr [rbp-0x370]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77FAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x378], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7E
       mov      rcx, 0x7FF9D77FAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D8F
       mov      rcx, 0x7FF9D77FAAFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9E
       xor      eax, eax
       mov      dword ptr [rbp-0x378], eax
 
G_M000_IG64:                ;; offset=0x0DA6
       movzx    rax, byte  ptr [rbp-0x378]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7F0], xmm0
 
G_M000_IG66:                ;; offset=0x0DDE
       lea      r8, [rbp-0x7F0]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F8], rax
       mov      rdx, gword ptr [rbp-0x7F8]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x390], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x3A0], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E94
       mov      rcx, 0x7FF9D77FAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA8
       mov      rcx, 0x7FF9D77FAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBC
       mov      rcx, 0x7FF9D77FAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x3A0], rax
 
G_M000_IG70:                ;; offset=0x0EF7
       mov      rcx, 0x7FF9D77FAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x398]
       mov      rdx, gword ptr [rbp-0x3A0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7FC], eax
       mov      edx, dword ptr [rbp-0x7FC]
       mov      rcx, bword ptr [rbp-0x3A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x3B0], rax
       mov      rax, bword ptr [rbp-0x3B0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG234
 
G_M000_IG71:                ;; offset=0x0F95
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x810], xmm0
 
G_M000_IG72:                ;; offset=0x0FA5
       lea      rdx, [rbp-0x810]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x380], rax
       mov      rax, bword ptr [rbp-0x380]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77FAB10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG73:                ;; offset=0x1030
       mov      rcx, 0x7FF9D77FAB14
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1041
       mov      rcx, 0x7FF9D77FAB18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1050
       mov      rcx, 0x7FF9D77FAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG76:                ;; offset=0x106E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77FAB20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG77:                ;; offset=0x1093
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x830], ymm0
 
G_M000_IG79:                ;; offset=0x10AF
       lea      r8, [rbp-0x830]
       lea      rdx, [rbp-0x368]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x368]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x360]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77FAB24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x838], rax
       mov      rcx, gword ptr [rbp-0x838]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG80:                ;; offset=0x1143
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1152
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77FAB28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x338], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x33C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x83C], eax
       mov      r8d, dword ptr [rbp-0x83C]
       mov      edx, dword ptr [rbp-0x33C]
       mov      rcx, bword ptr [rbp-0x338]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x348], rax
       mov      rcx, gword ptr [rbp-0x348]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     [CORINFO_HELP_ARRADDR_ST]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x848], rax
       mov      rdx, gword ptr [rbp-0x848]
       mov      rcx, gword ptr [rbp-0x348]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x350], rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x850], rax
       mov      r9, gword ptr [rbp-0x850]
       mov      rdx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x358]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x358]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1281
       mov      rcx, 0x7FF9D77FAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x330]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B7
       vmovdqu  xmm0, xmmword ptr [rbp-0x330]
       vmovdqu  xmmword ptr [rbp-0x860], xmm0
 
G_M000_IG84:                ;; offset=0x12C7
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12CB
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x880], ymm0
 
G_M000_IG86:                ;; offset=0x12D7
       lea      rdx, [rbp-0x860]
       lea      r8, [rbp-0x880]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12F1
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77FAB30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG88:                ;; offset=0x1345
       mov      rcx, 0x7FF9D77FAB34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1356
       mov      rcx, 0x7FF9D77FAB38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG90:                ;; offset=0x136A
       mov      rcx, 0x7FF9D77FAB3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG91:                ;; offset=0x1388
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77FAB40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG92:                ;; offset=0x13AD
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77FAB48
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x888], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x88C], eax
       mov      rcx, gword ptr [rbp-0x888]
       mov      edx, dword ptr [rbp-0x88C]
       mov      r11, 0x7FF9D70A1A50
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77FAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG224
 
G_M000_IG93:                ;; offset=0x1462
       lea      rcx, [rbp-0x618]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x147A
       vmovdqu  xmm0, xmmword ptr [rbp-0x618]
       vmovdqu  xmmword ptr [rbp-0x8A0], xmm0
 
G_M000_IG95:                ;; offset=0x148A
       lea      rdx, [rbp-0x8A0]
       lea      rcx, [rbp-0x628]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x628]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x620]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77FAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A8], rax
       mov      rcx, gword ptr [rbp-0x8A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG96:                ;; offset=0x1518
       mov      rcx, 0x7FF9D77FAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG97:                ;; offset=0x1536
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77FAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG98:                ;; offset=0x1575
       mov      rcx, 0x7FF9D77FAC60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG99:                ;; offset=0x1589
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77FAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG100:                ;; offset=0x15BB
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15BF
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8C8], ymm0
 
G_M000_IG102:                ;; offset=0x15CB
       lea      r8, [rbp-0x8C8]
       lea      rdx, [rbp-0x570]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77FAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D0], rax
       mov      rcx, gword ptr [rbp-0x8D0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG103:                ;; offset=0x165F
       mov      rcx, 0x7FF9D77FAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG104:                ;; offset=0x167D
       mov      rcx, 0x7FF9D77FAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x600], rax
       mov      rax, gword ptr [rbp-0x600]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8D8], rax
       mov      r9, gword ptr [rbp-0x8D8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG105:                ;; offset=0x16FF
       mov      rcx, 0x7FF9D77FAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5BC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r8, gword ptr [rbp-0x8E0]
       mov      edx, dword ptr [rbp-0x5BC]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8E8], rax
       mov      r9, gword ptr [rbp-0x8E8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG106:                ;; offset=0x1780
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77FAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG107:                ;; offset=0x17A5
       mov      rcx, 0x7FF9D77FAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F0], rax
       mov      rdx, gword ptr [rbp-0x8F0]
       mov      rcx, gword ptr [rbp-0x5B0]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F8], rax
       mov      r9, gword ptr [rbp-0x8F8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG108:                ;; offset=0x1843
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77FAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG109:                ;; offset=0x1868
       mov      rcx, 0x7FF9D77FAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x900], rax
       mov      rdx, gword ptr [rbp-0x900]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG110:                ;; offset=0x189E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77FAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG111:                ;; offset=0x18C3
       mov      rcx, 0x7FF9D77FAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x540]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x548], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x550], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x904], eax
       mov      r8d, dword ptr [rbp-0x904]
       mov      edx, dword ptr [rbp-0x554]
       mov      rcx, bword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x910], rax
       mov      r9, gword ptr [rbp-0x910]
       mov      rdx, gword ptr [rbp-0x560]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x548]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG112:                ;; offset=0x199E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77FAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG113:                ;; offset=0x19C3
       mov      rcx, 0x7FF9D77FAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x508], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x518], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x518]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x520], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x528], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x52C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x914], eax
       mov      r8d, dword ptr [rbp-0x914]
       mov      edx, dword ptr [rbp-0x52C]
       mov      rcx, bword ptr [rbp-0x528]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x538], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x920], rax
       mov      rax, gword ptr [rbp-0x920]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      r8, gword ptr [rbp-0x520]
       mov      r9, gword ptr [rbp-0x538]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG114:                ;; offset=0x1AD3
       mov      rcx, 0x7FF9D77FAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x500], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x924], eax
       mov      edx, dword ptr [rbp-0x924]
       mov      rcx, bword ptr [rbp-0x500]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x930], rax
       mov      r9, gword ptr [rbp-0x930]
       mov      edx, dword ptr [rbp-0x4F4]
       mov      r8d, dword ptr [rbp-0x4F8]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG224
 
G_M000_IG115:                ;; offset=0x1B7E
       mov      rcx, 0x7FF9D77FAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x934], eax
       mov      edx, dword ptr [rbp-0x934]
       mov      rcx, bword ptr [rbp-0x4E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x938], eax
       mov      edx, dword ptr [rbp-0x938]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG224
 
G_M000_IG116:                ;; offset=0x1C02
       mov      rcx, 0x7FF9D77FACA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4D4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x940], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x940]
       mov      edx, dword ptr [rbp-0x4D4]
       mov      r8d, dword ptr [rbp-0x4D8]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x948], rax
       mov      r9, gword ptr [rbp-0x948]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG117:                ;; offset=0x1CA6
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77FACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG118:                ;; offset=0x1CDF
       mov      rcx, 0x7FF9D77FACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CEE
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77FACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D29
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x958], xmm0
 
G_M000_IG121:                ;; offset=0x1D35
       lea      r9, [rbp-0x958]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG238
 
G_M000_IG122:                ;; offset=0x1D5D
       mov      rcx, 0x7FF9D77FACB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6C
       mov      rcx, 0x7FF9D77FACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x960], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x960]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x968], rax
       mov      r9, gword ptr [rbp-0x968]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG124:                ;; offset=0x1E10
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77FACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG125:                ;; offset=0x1E35
       mov      rcx, 0x7FF9D77FACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG126:                ;; offset=0x1E5C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77FACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG127:                ;; offset=0x1E81
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77FACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG128:                ;; offset=0x1EB0
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB4
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x988], ymm0
 
G_M000_IG130:                ;; offset=0x1EC0
       lea      r8, [rbp-0x988]
       lea      rdx, [rbp-0x4B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x4B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x4B0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77FACC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x990], rax
       mov      rcx, gword ptr [rbp-0x990]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG131:                ;; offset=0x1F54
       mov      rcx, 0x7FF9D77FACCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG132:                ;; offset=0x1F75
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77FACD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG133:                ;; offset=0x1FD4
       mov      rcx, 0x7FF9D77FACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG134:                ;; offset=0x1FF5
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77FACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG135:                ;; offset=0x2023
       mov      rcx, 0x7FF9D77FACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2034
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2052
       mov      rcx, 0x7FF9D77FACE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2061
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77FACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG139:                ;; offset=0x20C9
       mov      rcx, 0x7FF9D77FACE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG140:                ;; offset=0x20DD
       mov      rcx, 0x7FF9D77FACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG141:                ;; offset=0x20F1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77FACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG142:                ;; offset=0x2126
       mov      rcx, 0x7FF9D77FACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x213A
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2C4]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rax, gword ptr [rbp-0x2D0]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rdx, gword ptr [rbp-0x998]
       mov      rcx, 0x7FF9D77F5D30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2248
       lea      rdx, [rbp-0x2E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x2E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x2D8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77FACF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A0], rax
       mov      rcx, gword ptr [rbp-0x9A0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG145:                ;; offset=0x22E7
       mov      rcx, 0x7FF9D77FACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F8
       mov      rcx, 0x7FF9D77FAD00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2309
       mov      rcx, 0x7FF9D77FAD04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x231A
       mov      rcx, 0x7FF9D77FAD08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x232B
       mov      rcx, 0x7FF9D77FAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x233C
       mov      rcx, 0x7FF9D77FAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG151:                ;; offset=0x235D
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x458], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9A4], eax
       mov      edx, dword ptr [rbp-0x9A4]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x458]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77FAD14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C5
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9B8], xmm0
 
G_M000_IG153:                ;; offset=0x23D5
       lea      r9, [rbp-0x9B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG154:                ;; offset=0x23F3
       mov      rcx, 0x7FF9D77FAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x470], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9BC], eax
       mov      edx, dword ptr [rbp-0x9BC]
       mov      rcx, bword ptr [rbp-0x470]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG155:                ;; offset=0x2457
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77FAD1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG156:                ;; offset=0x247C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77FAD20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG157:                ;; offset=0x24AB
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24AF
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9E0], ymm0
 
G_M000_IG159:                ;; offset=0x24BB
       lea      r8, [rbp-0x9E0]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rdx, gword ptr [rbp-0x468]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB78]
       mov      rcx, qword ptr [rbp-0x460]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77FAD24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E8], rax
       mov      rcx, gword ptr [rbp-0x9E8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG160:                ;; offset=0x254F
       mov      rcx, 0x7FF9D77FAD28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG161:                ;; offset=0x2570
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rax, gword ptr [rbp-0x3F8]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77FAD30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9F4], eax
       mov      rcx, gword ptr [rbp-0x9F0]
       mov      edx, dword ptr [rbp-0x9F4]
       mov      r11, 0x7FF9D70A1A48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG169
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0xC4]
       jne      G_M000_IG164
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9F8], eax
       mov      edx, dword ptr [rbp-0x9F8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x148], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x9FC], eax
       mov      edx, dword ptr [rbp-0x9FC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77FAE38
 
G_M000_IG162:                ;; offset=0x26A9
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA08], rax
       mov      rdx, gword ptr [rbp-0xA08]
       mov      rcx, 0x7FF9D776AC10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x158], rax
       cmp      gword ptr [rbp-0x158], 0
       je       G_M000_IG168
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA10], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x168]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0xA10]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x158]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG163
       lea      rcx, [rbp-0x168]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77FAF40
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA18], rax
       mov      rdx, gword ptr [rbp-0xA18]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0x170], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77FB048
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x170]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG163:                ;; offset=0x27BF
       mov      rcx, 0x7FF9D77FB04C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG168
 
G_M000_IG164:                ;; offset=0x27D0
       mov      rcx, 0x7FF9D77FB050
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG169
 
G_M000_IG165:                ;; offset=0x27E4
       mov      rcx, 0x7FF9D77FB054
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x27F3
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0xA28], xmm0
 
G_M000_IG167:                ;; offset=0x2803
       lea      r9, [rbp-0xA28]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG168:                ;; offset=0x2821
       mov      rcx, 0x7FF9D77FB058
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xC4]
       lea      r8d, [rax+0x01]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0xC4]
       lea      r8d, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      eax, dword ptr [rbp-0xC4]
       lea      edx, [rax+0x01]
       mov      r9, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
 
G_M000_IG169:                ;; offset=0x2889
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x400], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA2C], eax
       mov      edx, dword ptr [rbp-0xA2C]
       mov      rcx, bword ptr [rbp-0x400]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG172
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG170
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x668], rax
       mov      rcx, gword ptr [rbp-0x668]
       mov      rdx, 0x7FF9D77FB060
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x668]
       mov      gword ptr [rbp-0xA38], rax
       mov      rdx, gword ptr [rbp-0xA38]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x178], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG170:                ;; offset=0x298A
       mov      rcx, 0x7FF9D77FB168
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG171:                ;; offset=0x299E
       mov      rcx, 0x7FF9D77FB16C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x450], xmm0
       vmovdqu  xmmword ptr [rbp-0x448], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76B9D18
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0xA40], rax
       mov      r8, gword ptr [rbp-0xA40]
       lea      rcx, [rbp-0x450]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x450]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG172:                ;; offset=0x2A58
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG175
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x180]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77FB170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG173:                ;; offset=0x2AB9
       cmp      gword ptr [rbp-0x180], 0
       je       G_M000_IG174
       mov      rcx, 0x7FF9D77FB174
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       vmovdqu  xmmword ptr [rbp-0x430], xmm0
       lea      rcx, [rbp-0x438]
       mov      r8, gword ptr [rbp-0x180]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rax, bword ptr [rbp-0xB88]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x438]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG174:                ;; offset=0x2B63
       mov      rcx, 0x7FF9D77FB178
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG175:                ;; offset=0x2B77
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG179
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG177
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x2BE3
       mov      rcx, 0x7FF9D77FB17C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG177:                ;; offset=0x2BF2
       mov      rcx, 0x7FF9D77FB180
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG178:                ;; offset=0x2C2B
       mov      rcx, 0x7FF9D77FB184
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG179:                ;; offset=0x2C57
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77FB188
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG180:                ;; offset=0x2CC7
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x410]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG181:                ;; offset=0x2CFC
       vmovdqu  xmm0, xmmword ptr [rbp-0x410]
       vmovdqu  xmmword ptr [rbp-0xA50], xmm0
 
G_M000_IG182:                ;; offset=0x2D0C
       lea      rdx, [rbp-0xA50]
       lea      rcx, [rbp-0x420]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x420]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x418]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG183
       mov      rcx, 0x7FF9D77FB18C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA58], rax
       mov      rcx, gword ptr [rbp-0xA58]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG183:                ;; offset=0x2D9A
       mov      rcx, 0x7FF9D77FB190
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG184:                ;; offset=0x2DB8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA5C], eax
       mov      edx, dword ptr [rbp-0xA5C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x484], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x488], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA68], rax
       mov      rax, gword ptr [rbp-0xA68]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      r8d, dword ptr [rbp-0x484]
       mov      r9d, dword ptr [rbp-0x488]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG186
       mov      rcx, 0x7FF9D77FB194
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG185:                ;; offset=0x2E83
       mov      rcx, 0x7FF9D77FB198
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG186:                ;; offset=0x2E97
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77FB19C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG187:                ;; offset=0x2EC3
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG188:                ;; offset=0x2EC7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG189:                ;; offset=0x2ED3
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x498]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG190:                ;; offset=0x2EED
       vmovdqu  xmm0, xmmword ptr [rbp-0x498]
       vmovdqu  xmmword ptr [rbp-0xA98], xmm0
 
G_M000_IG191:                ;; offset=0x2EFD
       lea      rdx, [rbp-0xA98]
       lea      rcx, [rbp-0x4A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x4A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x4A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG192
       mov      rcx, 0x7FF9D77FB1A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rcx, gword ptr [rbp-0xAA0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG192:                ;; offset=0x2F8B
       mov      rcx, 0x7FF9D77FB1A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG193:                ;; offset=0x2FA9
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG194
       mov      rcx, 0x7FF9D77FB1A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG194:                ;; offset=0x2FCE
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77FB1AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG195:                ;; offset=0x2FFA
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG196:                ;; offset=0x2FFE
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAC0], ymm0
 
G_M000_IG197:                ;; offset=0x300A
       lea      r8, [rbp-0xAC0]
       lea      rdx, [rbp-0x3E0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG198:                ;; offset=0x3024
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E0]
       vmovdqu  xmmword ptr [rbp-0xAD0], xmm0
 
G_M000_IG199:                ;; offset=0x3034
       lea      rdx, [rbp-0xAD0]
       lea      rcx, [rbp-0x3F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG200
       mov      rcx, 0x7FF9D77FB1B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD8], rax
       mov      rcx, gword ptr [rbp-0xAD8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG200:                ;; offset=0x30C2
       mov      rcx, 0x7FF9D77FB1B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG201:                ;; offset=0x30E0
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG202
       mov      rcx, 0x7FF9D77FB1B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG202:                ;; offset=0x3105
       mov      rcx, 0x7FF9D77FB1BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG203:                ;; offset=0x3129
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xADC], eax
       mov      edx, dword ptr [rbp-0xADC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG205
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77FB1C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG204:                ;; offset=0x318D
       mov      rcx, 0x7FF9D77FB1C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG205:                ;; offset=0x319C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG207
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77F9A80
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x31C0
       mov      rcx, 0x7FF9D77FB1C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG207:                ;; offset=0x31CF
       mov      rcx, 0x7FF9D77FB1CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG208:                ;; offset=0x31FC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG209:                ;; offset=0x3200
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xB00], ymm0
 
G_M000_IG210:                ;; offset=0x320C
       lea      r8, [rbp-0xB00]
       lea      rdx, [rbp-0x3C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG211
       mov      rcx, 0x7FF9D77FB1D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB08], rax
       mov      rcx, gword ptr [rbp-0xB08]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG211:                ;; offset=0x32A0
       mov      rcx, 0x7FF9D77FB1D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG212:                ;; offset=0x32C1
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG216
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x184], eax
       cmp      dword ptr [rbp-0x184], 49
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x184], 57
       je       SHORT G_M000_IG214
       cmp      dword ptr [rbp-0x184], 58
       je       SHORT G_M000_IG213
       mov      rcx, 0x7FF9D77FB1D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG213:                ;; offset=0x3311
       mov      rcx, 0x7FF9D77FB1DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG214:                ;; offset=0x3322
       mov      rcx, 0x7FF9D77FB1E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x3333
       mov      rcx, 0x7FF9D77FB1E4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG216:                ;; offset=0x3342
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG218
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG219
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG217
       mov      rcx, 0x7FF9D77FB1E8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
       lea      rcx, [rbp-0x3D0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x3D0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x3C8]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG238
 
G_M000_IG217:                ;; offset=0x3405
       mov      rcx, 0x7FF9D77FB1EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x3416
       mov      rcx, 0x7FF9D77FB1F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG219:                ;; offset=0x342A
       mov      rcx, 0x7FF9D77FB1F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG220:                ;; offset=0x3448
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1E8], ymm0
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
       lea      rcx, [rbp-0x1E8]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG221:                ;; offset=0x3474
       vmovdqu  ymm0, ymmword ptr [rbp-0x1E8]
       vmovdqu  ymmword ptr [rbp-0x1B0], ymm0
       mov      rax, qword ptr [rbp-0x1C8]
       mov      qword ptr [rbp-0x190], rax
 
G_M000_IG222:                ;; offset=0x3492
       lea      rcx, [rbp-0x1B0]
       mov      rdx, 0x1CD40BE2A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB0C], eax
       mov      edx, dword ptr [rbp-0xB0C]
       lea      rcx, [rbp-0x1B0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       lea      rcx, [rbp-0x1B0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      rdx, gword ptr [rbp-0xB18]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x3517
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG224:                ;; offset=0x351D
       mov      eax, dword ptr [rbp-0x66C]
       dec      eax
       mov      dword ptr [rbp-0x66C], eax
       cmp      dword ptr [rbp-0x66C], 0
       jg       SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x3534
       lea      rcx, [rbp-0x66C]
       mov      edx, 0x102B
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG226:                ;; offset=0x3547
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG229
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG228
       mov      rcx, 0x7FF9D77FB204
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x210]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0xBB8]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB8]
       mov      rcx, qword ptr [rbp-0x208]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG227:                ;; offset=0x35BF
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG228:                ;; offset=0x35CB
       mov      rcx, 0x7FF9D77FB208
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG229:                ;; offset=0x35DA
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG230
       mov      rcx, 0x7FF9D77FB20C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x200]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG234
 
G_M000_IG230:                ;; offset=0x360F
       mov      rcx, 0x7FF9D77FB210
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG234
 
G_M000_IG231:                ;; offset=0x3620
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB30], rax
       mov      r9, gword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x364E
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG233:                ;; offset=0x3658
       mov      rcx, 0x7FF9D77FB214
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG234:                ;; offset=0x3673
       mov      eax, dword ptr [rbp-0x66C]
       dec      eax
       mov      dword ptr [rbp-0x66C], eax
       cmp      dword ptr [rbp-0x66C], 0
       jg       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x368A
       lea      rcx, [rbp-0x66C]
       mov      edx, 0x1070
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG236:                ;; offset=0x369D
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77FB218
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG237:                ;; offset=0x36C5
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG238:                ;; offset=0x36D1
       mov      rcx, 0x7FF9D77FB21C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG239:                ;; offset=0x36E6
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG240:                ;; offset=0x36F2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG241:                ;; offset=0x36F8
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x36FC
       mov      gword ptr [rbp-0x638], rcx
       mov      rax, gword ptr [rbp-0x638]
       mov      gword ptr [rbp-0x1B8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x3718
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x371E
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r8, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG246
       mov      rcx, 0x7FF9D77FB1F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG238
 
G_M000_IG245:                ;; offset=0x376D
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG246:                ;; offset=0x3775
       mov      rcx, 0x7FF9D77FB1FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG247:                ;; offset=0x3792
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG248:                ;; offset=0x379A
       sub      rsp, 72
 
G_M000_IG249:                ;; offset=0x379E
       mov      gword ptr [rbp-0x630], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x37D6
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG251:                ;; offset=0x37DC
       mov      rcx, 0x7FF9D77FB200
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG252:                ;; offset=0x37F9
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001336h ; case G_M000_IG91
       	dd	0000162Bh ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ADh ; case G_M000_IG105
       	dd	0000172Eh ; case G_M000_IG106
       	dd	00000ADCh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Fh ; case G_M000_IG138
       	dd	0000200Fh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E4h ; case G_M000_IG97
       	dd	000014E4h ; case G_M000_IG97
       	dd	000017F1h ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ch ; case G_M000_IG110
       	dd	0000194Ch ; case G_M000_IG112
       	dd	00001A81h ; case G_M000_IG114
       	dd	00001B2Ch ; case G_M000_IG115
       	dd	00001BB0h ; case G_M000_IG116
       	dd	00001C54h ; case G_M000_IG117
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00002D66h ; case G_M000_IG184
       	dd	0000230Bh ; case G_M000_IG151
       	dd	0000251Eh ; case G_M000_IG161
       	dd	00001FE2h ; case G_M000_IG136
       	dd	00002F57h ; case G_M000_IG193
       	dd	0000308Eh ; case G_M000_IG201
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	0000326Fh ; case G_M000_IG212
       	dd	000030D7h ; case G_M000_IG203
       	dd	00001F23h ; case G_M000_IG132
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	0000326Fh ; case G_M000_IG212
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C18h ; case G_M000_IG59
       	dd	0000101Ch ; case G_M000_IG76
       	dd	0000326Fh ; case G_M000_IG212
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Fh ; case G_M000_IG141
       	dd	000020E8h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A9h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 14337

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x430
       lea      rbp, [rsp+0x430]
       xor      eax, eax
       mov      qword ptr [rbp-0x3E8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3E0], xmm4
       vmovdqa  xmmword ptr [rbp-0x3D0], xmm4
       mov      rax, -960
 
G_M000_IG73:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG73
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x274], eax
       mov      edx, dword ptr [rbp-0x274]
       mov      rcx, gword ptr [rbp-0x100]
       mov      r11, 0x7FF9D70A1C28
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG11
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x278], eax
       mov      edx, dword ptr [rbp-0x278]
       mov      rcx, bword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      edx, dword ptr [rbp-0x27C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x38], rax
       mov      rdx, gword ptr [rbp-0x30]
       mov      rcx, 0x7FF9D776AC10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG10
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0x288]
       mov      rax, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x10]
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
 
G_M000_IG03:                ;; offset=0x016F
       je       G_M000_IG10
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [rbp-0x290]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x298], rax
       mov      rcx, gword ptr [rbp-0x298]
       mov      r11, 0x7FF9D70A1C48
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x01D7
       mov      rcx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG05:                ;; offset=0x01E1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
 
G_M000_IG06:                ;; offset=0x01F1
       vzeroupper 
       add      rsp, 0x430
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x01FD
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG08:                ;; offset=0x020A
       lea      r8, [rbp-0x2A8]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x0224
       vzeroupper 
       add      rsp, 0x430
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0230
       mov      eax, dword ptr [rbp-0x0C]
       lea      r8d, [rax+0x01]
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0x0C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x0C]
       lea      r8d, [rax+0x02]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
 
G_M000_IG11:                ;; offset=0x0263
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x10C], eax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x10C], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x10C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdx, gword ptr [rbp-0x2B0]
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG12:                ;; offset=0x02E8
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG51
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG60
 
G_M000_IG13:                ;; offset=0x0329
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG17
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x230], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x234], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2B4], eax
       mov      r9d, dword ptr [rbp-0x2B4]
       lea      rdx, [rbp-0x248]
       mov      r8d, dword ptr [rbp-0x234]
       mov      rcx, bword ptr [rbp-0x230]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG14:                ;; offset=0x03AD
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG15:                ;; offset=0x03BD
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       lea      rcx, [rbp-0x2C8]
       lea      r9, [rbp-0x68]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG16
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG60
 
G_M000_IG16:                ;; offset=0x03FE
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG51
 
G_M000_IG17:                ;; offset=0x0411
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG44
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76B4690
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG44
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x138]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG48
       mov      rax, bword ptr [rbp-0x138]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG29
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, 0x7FF9D75C1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       G_M000_IG29
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      rcx, 0x7FF9D76B31D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x88], rax
       cmp      gword ptr [rbp-0x88], 0
       je       G_M000_IG29
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG18:                ;; offset=0x0510
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG19:                ;; offset=0x0548
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
 
G_M000_IG20:                ;; offset=0x0554
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x1B0], rax
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2DC], eax
       mov      edx, dword ptr [rbp-0x2DC]
       mov      rcx, gword ptr [rbp-0x1B0]
       mov      r11, 0x7FF9D70A1C40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, gword ptr [rbp-0x1B8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG21:                ;; offset=0x05DB
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1C0], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rcx, gword ptr [rbp-0xC8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG23
       mov      rax, bword ptr [rbp-0x1C8]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG22
       mov      rax, bword ptr [rbp-0x210]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0xC8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x204], eax
       jmp      G_M000_IG24
 
G_M000_IG22:                ;; offset=0x06C9
       mov      rax, bword ptr [rbp-0x210]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x200], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x204], eax
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x070B
       mov      rax, bword ptr [rbp-0x1C8]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x200], rax
       mov      dword ptr [rbp-0x204], 1
 
G_M000_IG24:                ;; offset=0x074D
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [rbp-0x200]
       mov      r9d, dword ptr [rbp-0x204]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rdx, gword ptr [rbp-0x2F0]
       mov      rcx, bword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG25:                ;; offset=0x078B
       call     G_M000_IG63
       nop      
 
G_M000_IG26:                ;; offset=0x0791
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG27:                ;; offset=0x0799
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG28:                ;; offset=0x07A6
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0xC0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x5C], 1
       jmp      G_M000_IG60
 
G_M000_IG29:                ;; offset=0x07CA
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rdx, gword ptr [rbp-0x308]
       mov      rcx, 0x7FF9D7803450
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       G_M000_IG36
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG36
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG30:                ;; offset=0x084D
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x318], xmm0
 
G_M000_IG31:                ;; offset=0x085A
       lea      rdx, [rbp-0x318]
       lea      rcx, [rbp-0x180]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG32:                ;; offset=0x086E
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x328], xmm0
 
G_M000_IG33:                ;; offset=0x087E
       lea      rax, [rbp-0x98]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x328]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG36
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x32C], eax
       mov      edx, dword ptr [rbp-0x32C]
       mov      rcx, gword ptr [rbp-0x188]
       mov      r11, 0x7FF9D70A1C38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x190], rax
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rcx, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1A8], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG34:                ;; offset=0x0988
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG35:                ;; offset=0x0998
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x340]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x190]
       mov      r8d, dword ptr [rbp-0x194]
       mov      r9, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG51
 
G_M000_IG36:                ;; offset=0x09F8
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG37:                ;; offset=0x0A0B
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x358], xmm0
 
G_M000_IG38:                ;; offset=0x0A18
       lea      rdx, [rbp-0x358]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG39:                ;; offset=0x0A2C
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG40:                ;; offset=0x0A3C
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x368]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG51
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x158], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x15C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x36C], eax
       mov      r9d, dword ptr [rbp-0x36C]
       lea      rdx, [rbp-0x170]
       mov      r8d, dword ptr [rbp-0x15C]
       mov      rcx, bword ptr [rbp-0x158]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG41:                ;; offset=0x0AEE
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG42:                ;; offset=0x0AFE
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xE8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x388]
       lea      r8, [rbp-0x380]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG43
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG60
 
G_M000_IG43:                ;; offset=0x0B54
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG51
 
G_M000_IG44:                ;; offset=0x0B6A
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG45:                ;; offset=0x0B6E
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x398], xmm0
 
G_M000_IG46:                ;; offset=0x0B7B
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x398]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG50
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       G_M000_IG51
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rcx, gword ptr [rbp-0x3A8]
       mov      r11, 0x7FF9D70A1C30
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG47:                ;; offset=0x0C24
       mov      rcx, gword ptr [rbp-0xF0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG48:                ;; offset=0x0C31
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG49:                ;; offset=0x0C37
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG60
 
G_M000_IG50:                ;; offset=0x0C52
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG51
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG60
 
G_M000_IG51:                ;; offset=0x0C7F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG55
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG62
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG55
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG62
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3B8], rax
       mov      rdx, gword ptr [rbp-0x3B8]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x3BC], eax
       mov      edx, dword ptr [rbp-0x3BC]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x120], rax
 
G_M000_IG52:                ;; offset=0x0D6A
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x3C0], eax
       mov      r9d, dword ptr [rbp-0x3C0]
       lea      rdx, [rbp-0x130]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG53:                ;; offset=0x0D9B
       vmovdqu  xmm0, xmmword ptr [rbp-0x130]
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
 
G_M000_IG54:                ;; offset=0x0DAB
       lea      rcx, [rbp-0x3D0]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG58
 
G_M000_IG55:                ;; offset=0x0DBA
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG62
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3E8], rax
 
G_M000_IG56:                ;; offset=0x0DE8
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x3E0], xmm0
 
G_M000_IG57:                ;; offset=0x0DF5
       mov      rdx, bword ptr [rbp-0x3E8]
       lea      r8, [rbp-0x3E0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG58:                ;; offset=0x0E0D
       mov      eax, 1
 
G_M000_IG59:                ;; offset=0x0E12
       vzeroupper 
       add      rsp, 0x430
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x0E1E
       mov      eax, dword ptr [rbp-0x5C]
 
G_M000_IG61:                ;; offset=0x0E21
       vzeroupper 
       add      rsp, 0x430
       pop      rbp
       ret      
 
G_M000_IG62:                ;; offset=0x0E2D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG63:                ;; offset=0x0E33
       sub      rsp, 72
 
G_M000_IG64:                ;; offset=0x0E37
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG65:                ;; offset=0x0E48
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG66:                ;; offset=0x0E50
       sub      rsp, 72
 
G_M000_IG67:                ;; offset=0x0E54
       mov      gword ptr [rbp-0x250], rcx
       mov      rdx, gword ptr [rbp-0x250]
       mov      rcx, 0x7FF9D71A2168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp-0x258], 0
       jne      SHORT G_M000_IG68
       xor      eax, eax
       mov      dword ptr [rbp-0x264], eax
       jmp      SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x0E9B
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdx, gword ptr [rbp-0x3B0]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x264], eax
 
G_M000_IG69:                ;; offset=0x0ED7
       mov      eax, dword ptr [rbp-0x264]
 
G_M000_IG70:                ;; offset=0x0EDD
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG71:                ;; offset=0x0EE5
       sub      rsp, 72
 
G_M000_IG72:                ;; offset=0x0EE9
       mov      gword ptr [rbp-0x270], rcx
       mov      rcx, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3837

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x102b
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 45 inlinees with PGO data; 273 single block inlinees; 60 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 928
       mov      qword ptr [rsp+0xFA8], r15
       mov      qword ptr [rsp+0xFA0], r14
       mov      qword ptr [rsp+0xF98], r13
       mov      qword ptr [rsp+0xF90], r12
       mov      qword ptr [rsp+0xF88], rdi
       mov      qword ptr [rsp+0xF80], rsi
       mov      qword ptr [rsp+0xF78], rbx
       lea      rbp, [rsp+0x3A0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x320], xmm4
       mov      rax, -720
 
G_M000_IG513:                ;; offset=0x0063
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG513
       mov      qword ptr [rbp-0x40], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x009A
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG493
 
G_M000_IG03:                ;; offset=0x00A7
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B0
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00BA
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      r8, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [r8+0x08]
       cmp      edx, ebx
       jge      G_M000_IG491
 
G_M000_IG06:                ;; offset=0x00D7
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG499
       mov      r8, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [r8+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x0127
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0133
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0145
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG10:                ;; offset=0x0152
       mov      r8, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG71
 
G_M000_IG11:                ;; offset=0x0166
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rcx, G_M000_IG02
       add      rdx, rcx
       jmp      rdx
 
G_M000_IG12:                ;; offset=0x0180
       mov      rdi, bword ptr [rbp+0xC20]
       mov      r14, gword ptr [rdi]
       mov      r15, gword ptr [rdi+0x08]
       mov      ecx, esi
       cmp      ecx, 2
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0195
       cmp      ecx, 25
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x019A
       cmp      ecx, 72
       jne      G_M000_IG328
 
G_M000_IG15:                ;; offset=0x01A3
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x08]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r13, gword ptr [rdx]
       cmp      esi, dword ptr [r15+0x08]
       jae      G_M000_IG486
       mov      edx, esi
       shl      rdx, 4
       lea      r15, bword ptr [r15+rdx+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x1AD1A001CE0
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG46
 
G_M000_IG16:                ;; offset=0x01E2
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x1AD1A001CE8
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG45
 
G_M000_IG17:                ;; offset=0x01F8
       cmp      qword ptr [r15+0x08], 0
       jle      G_M000_IG29
 
G_M000_IG18:                ;; offset=0x0203
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG29
 
G_M000_IG19:                ;; offset=0x0222
       mov      eax, dword ptr [r15+0x08]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdx, gword ptr [r12+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x024C
       mov      rax, gword ptr [r12+0x08]
       test     rax, rax
       je       SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0256
       mov      rdx, 0x7FF9D77D2CB8
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0265
       xor      rax, rax
 
G_M000_IG23:                ;; offset=0x0267
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG24:                ;; offset=0x0270
       cmp      dword ptr [rbp-0x1B4], 0
       jne      G_M000_IG329
       mov      r8, r12
       mov      rcx, 0x7FF9D78746E0
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG330
       lea      r12, bword ptr [r8+0x28]
 
G_M000_IG25:                ;; offset=0x0297
       mov      rdx, gword ptr [r12]
       mov      rcx, 0x1AD1A001CE0
       cmp      rdx, gword ptr [rcx]
       jne      G_M000_IG43
 
G_M000_IG26:                ;; offset=0x02AE
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, qword ptr [r12+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
       lea      rcx, [rbp-0x1C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rax, gword ptr [rbp-0x328]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x1C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r8d, dword ptr [rbp-0x1C0]
       mov      rax, gword ptr [rbp-0x328]
       mov      dword ptr [rax+0x10], r8d
       mov      rdx, rax
       mov      gword ptr [rbp-0x330], rdx
       mov      r8, 0x1AD1A001CE0
       mov      r8, gword ptr [r8]
       mov      rcx, r12
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, 0x1AD1A001CE0
       cmp      rax, gword ptr [rcx]
       je       G_M000_IG42
 
G_M000_IG27:                ;; offset=0x033D
       test     rax, rax
       je       G_M000_IG332
       mov      rdx, rax
 
G_M000_IG28:                ;; offset=0x0349
       mov      rcx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
 
G_M000_IG29:                ;; offset=0x0357
       mov      r12, gword ptr [r15]
 
G_M000_IG30:                ;; offset=0x035A
       test     r12, r12
       jne      G_M000_IG47
 
G_M000_IG31:                ;; offset=0x0363
       mov      r15, r12
 
G_M000_IG32:                ;; offset=0x0366
       test     r15, r15
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x036B
       mov      rcx, r14
       mov      edx, esi
       mov      r8, r13
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
 
G_M000_IG34:                ;; offset=0x0383
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG67
 
G_M000_IG35:                ;; offset=0x0394
       lea      rsi, bword ptr [rdi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG66
 
G_M000_IG36:                ;; offset=0x03AB
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG66
 
G_M000_IG37:                ;; offset=0x03BF
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x18]
 
G_M000_IG38:                ;; offset=0x03CA
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rcx+0x18]
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03DB
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x03E7
       mov      rcx, gword ptr [rsi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG486
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG41:                ;; offset=0x041B
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG486
       mov      ecx, r12d
       shl      rcx, 4
       lea      r12, bword ptr [rax+rcx+0x10]
       jmp      G_M000_IG25
 
G_M000_IG42:                ;; offset=0x043D
       mov      r12, gword ptr [rbp-0x330]
       mov      rdx, r12
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x044C
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       jmp      G_M000_IG28
 
G_M000_IG44:                ;; offset=0x0464
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG486
       mov      edx, r12d
       mov      rdx, gword ptr [rax+8*rdx+0x10]
       jmp      G_M000_IG28
 
G_M000_IG45:                ;; offset=0x0482
       mov      rcx, 0x7FF9D7196D68
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       vmovsd   xmm0, qword ptr [r15+0x08]
       vmovsd   qword ptr [r12+0x08], xmm0
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x04B7
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [r15+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
       lea      rcx, [rbp-0x1B0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rbp-0x1B0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1A8]
       mov      dword ptr [r12+0x10], ecx
       mov      rcx, r15
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG47:                ;; offset=0x0518
       mov      rcx, 0x7FF9D77F4838
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG31
 
G_M000_IG48:                ;; offset=0x052C
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0536
       cmp      byte  ptr [rcx+0x101], 0
       jne      G_M000_IG57
 
G_M000_IG50:                ;; offset=0x0543
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x054D
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       jne      SHORT G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0558
       cmp      byte  ptr [r12+0x28], 0
       je       SHORT G_M000_IG55
 
G_M000_IG53:                ;; offset=0x0560
       cmp      gword ptr [r12+0x08], 0
       jne      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0568
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdx, qword ptr [r12+0x20]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
       lea      rcx, [rbp-0x1E0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1D8]
       mov      dword ptr [r15+0x10], ecx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG55:                ;; offset=0x05BF
       mov      r15, gword ptr [r12+0x08]
 
G_M000_IG56:                ;; offset=0x05C4
       jmp      G_M000_IG32
 
G_M000_IG57:                ;; offset=0x05C9
       mov      r15, gword ptr [r12+0x10]
       mov      rcx, gword ptr [r15+0x08]
       test     rcx, rcx
       jne      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x05DB
       mov      rcx, 0x7FF9D71ADDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rcx, rax
       mov      gword ptr [rbp-0x338], rcx
       mov      rdx, 0x1AD1A000068
       mov      rdx, gword ptr [rdx]
       mov      rax, rdx
       mov      gword ptr [rbp-0x360], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rcx+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x360]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0629
       mov      rcx, gword ptr [rbp-0x338]
       lea      rcx, bword ptr [rcx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG60:                ;; offset=0x063C
       lea      rcx, bword ptr [r15+0x08]
       test     rcx, rcx
       je       G_M000_IG331
       mov      rdx, gword ptr [rbp-0x338]
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0660
       mov      r15, gword ptr [rbp-0x338]
       mov      rcx, r15
 
G_M000_IG62:                ;; offset=0x066A
       mov      rdx, gword ptr [r12+0x18]
       lea      r8, [rbp-0x1D0]
       mov      r11, 0x7FF9D70A1D00
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,System.__Canon]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       jne      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0687
       xor      r15, r15
 
G_M000_IG64:                ;; offset=0x068A
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D0], rcx
       jmp      G_M000_IG56
 
G_M000_IG65:                ;; offset=0x0698
       mov      r15, gword ptr [rbp-0x1D0]
       jmp      SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x06A1
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x14]
       jmp      G_M000_IG38
 
G_M000_IG67:                ;; offset=0x06B1
       mov      gword ptr [rbp-0x2F0], r15
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2E8], r9
       lea      r9, [rbp-0x2F0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG68:                ;; offset=0x06E5
       mov      rdi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rdi]
       mov      rax, gword ptr [rcx+0x30]
       mov      rsi, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG486
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x200]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG69:                ;; offset=0x074C
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG70:                ;; offset=0x075A
       mov      rdi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rdi]
       mov      rsi, gword ptr [rcx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x1CD40BE4708
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1CF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG394
       jmp      G_M000_IG393
 
G_M000_IG71:                ;; offset=0x07A8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG72:                ;; offset=0x07CB
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA60], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA80], rcx
 
G_M000_IG73:                ;; offset=0x07E3
       mov      ecx, dword ptr [rbp+0xA70]
       mov      edx, dword ptr [rbp+0xA80]
       cmp      ecx, edx
       ja       G_M000_IG352
       mov      rax, bword ptr [rbp+0xA78]
       mov      r8d, ecx
       lea      rax, bword ptr [rax+2*r8]
       sub      edx, ecx
       cmp      edx, 27
       jb       G_M000_IG488
 
G_M000_IG74:                ;; offset=0x0810
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rax], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rax+0x20], xmm0
       mov      dword ptr [rax+0x30], 0x3A0065
       mov      word  ptr [rax+0x34], 32
       mov      ecx, dword ptr [rbp+0xA70]
       add      ecx, 27
       mov      dword ptr [rbp+0xA70], ecx
 
G_M000_IG75:                ;; offset=0x0845
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA60]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp+0xA60]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:                ;; offset=0x0890
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG77:                ;; offset=0x089E
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG386
       jmp      G_M000_IG379
 
G_M000_IG78:                ;; offset=0x08B0
       mov      r8, gword ptr [rbp+0xC30]
       cmp      byte  ptr [r8+0xF9], 0
       je       G_M000_IG02
       jmp      G_M000_IG391
 
G_M000_IG79:                ;; offset=0x08CA
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG80:                ;; offset=0x08D8
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rdx+0x70]
       cmp      byte  ptr [rdx+0x101], 0
       jne      G_M000_IG366
       jmp      G_M000_IG363
 
G_M000_IG81:                ;; offset=0x0939
       test     r15d, r15d
       je       G_M000_IG376
       jmp      G_M000_IG367
 
G_M000_IG82:                ;; offset=0x0947
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG486
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       jmp      G_M000_IG333
 
G_M000_IG83:                ;; offset=0x097F
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG353
 
G_M000_IG84:                ;; offset=0x09D0
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG85:                ;; offset=0x09D8
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x09E7
       mov      r10, gword ptr [rbp+0xC28]
       mov      rax, r10
 
G_M000_IG87:                ;; offset=0x09F1
       mov      bword ptr [rbp-0x2E0], r9
       mov      dword ptr [rbp-0x2D8], r8d
 
G_M000_IG88:                ;; offset=0x09FF
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG89:                ;; offset=0x0A0F
       lea      rcx, [rbp-0x2E0]
       lea      r8, [rbp-0x2F0]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG90:                ;; offset=0x0A36
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG486
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A69
       mov      rcx, 0x7FF9D759EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG351
 
G_M000_IG92:                ;; offset=0x0A7C
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0ABF
       or       edi, r14d
       jne      G_M000_IG352
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG94:                ;; offset=0x0ACC
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0AEF
       mov      r10, gword ptr [rbp+0xC28]
       mov      r9, r10
 
G_M000_IG96:                ;; offset=0x0AF9
       mov      bword ptr [rbp-0x2E0], rdx
       mov      dword ptr [rbp-0x2D8], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2E0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG97:                ;; offset=0x0B41
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG352
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
       jmp      G_M000_IG94
 
G_M000_IG98:                ;; offset=0x0B67
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0B71
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG417
 
G_M000_IG100:                ;; offset=0x0B90
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rdx, gword ptr [rbx]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG486
       mov      eax, esi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x1AD1A001CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG189
 
G_M000_IG101:                ;; offset=0x0BD2
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x1AD1A001CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG188
 
G_M000_IG102:                ;; offset=0x0BE8
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG107
 
G_M000_IG103:                ;; offset=0x0BEF
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0C0A
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG187
 
G_M000_IG105:                ;; offset=0x0C2E
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG106:                ;; offset=0x0C43
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG107:                ;; offset=0x0C54
       mov      r14, gword ptr [rdi]
 
G_M000_IG108:                ;; offset=0x0C57
       test     r14, r14
       je       G_M000_IG425
       mov      rdx, 0x7FF9D7848AB0
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG190
 
G_M000_IG109:                ;; offset=0x0C73
       mov      rbx, r14
       mov      eax, dword ptr [rbx+0x34]
       cmp      eax, dword ptr [rbx+0x30]
       jne      G_M000_IG207
 
G_M000_IG110:                ;; offset=0x0C82
       xor      rbx, rbx
 
G_M000_IG111:                ;; offset=0x0C84
       xor      esi, esi
 
G_M000_IG112:                ;; offset=0x0C86
       test     rbx, rbx
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       jne      G_M000_IG220
 
G_M000_IG113:                ;; offset=0x0C9A
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG114:                ;; offset=0x0C9F
       test     r9d, r9d
       je       G_M000_IG221
 
G_M000_IG115:                ;; offset=0x0CA8
       mov      gword ptr [rbp+0xB58], rdx
       mov      qword ptr [rbp+0xB60], r8
       lea      r9, [rbp+0xB58]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG116:                ;; offset=0x0CDD
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG117:                ;; offset=0x0D1E
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG358
 
G_M000_IG118:                ;; offset=0x0D2B
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG119:                ;; offset=0x0D3B
       mov      rsi, gword ptr [rbp+0xB08]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG354
 
G_M000_IG120:                ;; offset=0x0D50
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG121:                ;; offset=0x0D5E
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rsi, r12
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rsi+0x08]
       cmp      eax, r10d
       jae      G_M000_IG486
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x220]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG122:                ;; offset=0x0DE4
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x210]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG123:                ;; offset=0x0E4E
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0E5C
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r8d, dword ptr [rsi+0x10]
       mov      r9d, dword ptr [rsi+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG334
 
G_M000_IG125:                ;; offset=0x0E8C
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG335
       jmp      G_M000_IG151
 
G_M000_IG126:                ;; offset=0x0ED3
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       SHORT G_M000_IG129
 
G_M000_IG127:                ;; offset=0x0F04
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rcx
       mov      ecx, 1
 
G_M000_IG128:                ;; offset=0x0F13
       test     ecx, ecx
       jne      G_M000_IG241
       jmp      G_M000_IG464
 
G_M000_IG129:                ;; offset=0x0F20
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
 
G_M000_IG130:                ;; offset=0x0F29
       jmp      SHORT G_M000_IG128
 
G_M000_IG131:                ;; offset=0x0F2B
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG486
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG242
 
G_M000_IG132:                ;; offset=0x0F49
       cmp      esi, r15d
       jae      G_M000_IG486
       mov      eax, esi
       shl      rax, 4
       add      rax, r14
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG144
 
G_M000_IG133:                ;; offset=0x0F71
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       SHORT G_M000_IG143
 
G_M000_IG134:                ;; offset=0x0F83
       cmp      qword ptr [rax+0x08], 0
       je       SHORT G_M000_IG142
 
G_M000_IG135:                ;; offset=0x0F8A
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
 
G_M000_IG136:                ;; offset=0x0F93
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG145
 
G_M000_IG137:                ;; offset=0x0F9E
       test     rcx, rcx
       je       SHORT G_M000_IG140
 
G_M000_IG138:                ;; offset=0x0FA3
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG140
 
G_M000_IG139:                ;; offset=0x0FB2
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG140:                ;; offset=0x0FBB
       test     rcx, rcx
       jne      SHORT G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0FC0
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG242
 
G_M000_IG142:                ;; offset=0x0FEC
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG136
 
G_M000_IG143:                ;; offset=0x0FF1
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      SHORT G_M000_IG136
 
G_M000_IG144:                ;; offset=0x0FFC
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      SHORT G_M000_IG136
 
G_M000_IG145:                ;; offset=0x1007
       test     rcx, rcx
       je       G_M000_IG465
       mov      rdx, rcx
       jmp      G_M000_IG242
 
G_M000_IG146:                ;; offset=0x1018
       not      r8d
       jmp      G_M000_IG245
 
G_M000_IG147:                ;; offset=0x1020
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x14]
       jmp      G_M000_IG245
 
G_M000_IG148:                ;; offset=0x1030
       mov      r9d, ecx
       not      r9d
       jmp      G_M000_IG247
 
G_M000_IG149:                ;; offset=0x103B
       cmp      esi, 58
       ja       SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x1040
       mov      rcx, 0x1FDFFFFFFFFFFFF
       bt       rcx, rsi
       jae      G_M000_IG289
 
G_M000_IG151:                ;; offset=0x1054
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG489
 
G_M000_IG152:                ;; offset=0x1063
       not      esi
       jmp      G_M000_IG303
 
G_M000_IG153:                ;; offset=0x106A
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x14]
       jmp      G_M000_IG303
 
G_M000_IG154:                ;; offset=0x1079
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], esi
       jne      G_M000_IG304
 
G_M000_IG155:                ;; offset=0x1089
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, gword ptr [rbp+0xC28]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rdi, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x0C]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rbp+0xC28]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      r14, rax
       mov      rdx, rdi
       mov      rcx, 0x7FF9D776AC10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG158
 
G_M000_IG156:                ;; offset=0x10E5
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp+0xAA8]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rbx+0x18]
       mov      rcx, rax
       mov      rdx, r14
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x1121
       mov      rdx, gword ptr [rbp+0xAA8]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG441
       jmp      G_M000_IG440
 
G_M000_IG158:                ;; offset=0x1149
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r15, bword ptr [rcx+0x20]
       lea      rcx, [rbp-0x2A8]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r8d, [rsi+0x01]
       lea      r9, [rbp-0x2A8]
       mov      rcx, r15
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       lea      rcx, [rbp-0x2B8]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      edx, [rsi+0x01]
       lea      r8d, [rsi+0x02]
       lea      r9, [rbp-0x2B8]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG304
 
G_M000_IG159:                ;; offset=0x11B1
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG486
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG310
 
G_M000_IG160:                ;; offset=0x11C8
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG312
 
G_M000_IG161:                ;; offset=0x11D9
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
       lea      rcx, [rbp-0x2C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x2C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x2C0]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG312
 
G_M000_IG162:                ;; offset=0x1238
       mov      edx, edi
       mov      rcx, 0x7FF9D72800F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       mov      rax, gword ptr [rbp-0x350]
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG214
 
G_M000_IG163:                ;; offset=0x1261
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG217
 
G_M000_IG164:                ;; offset=0x1273
       mov      rdx, gword ptr [rbp-0x348]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10, gword ptr [rbp-0x340]
 
G_M000_IG165:                ;; offset=0x1287
       mov      r8d, dword ptr [rbp-0x284]
       mov      r9d, edi
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jl       G_M000_IG218
 
G_M000_IG166:                ;; offset=0x12A1
       mov      r11d, 0x1000
 
G_M000_IG167:                ;; offset=0x12A7
       lea      ecx, [rsi+r8]
       mov      edx, ecx
       mov      r9d, r11d
       add      rdx, r9
       mov      r9d, r13d
       cmp      rdx, r9
       ja       G_M000_IG352
       mov      edx, ecx
       add      rdx, r15
       mov      ecx, r8d
       mov      r9d, r11d
       add      rcx, r9
       mov      r9d, edi
       cmp      rcx, r9
       ja       G_M000_IG352
       mov      dword ptr [rbp-0x284], r8d
       mov      ecx, r8d
       add      rcx, bword ptr [rbp-0x358]
       mov      dword ptr [rbp-0x288], r11d
       mov      r8d, r11d
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      r8d, dword ptr [rbp-0x288]
       add      r8d, dword ptr [rbp-0x284]
       mov      ecx, r8d
       cmp      ecx, edi
       mov      dword ptr [rbp-0x284], ecx
       jge      G_M000_IG215
 
G_M000_IG168:                ;; offset=0x1319
       mov      r10, gword ptr [rbp-0x340]
       test     r10, r10
       je       G_M000_IG165
 
G_M000_IG169:                ;; offset=0x1329
       mov      rcx, gword ptr [r10+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG164
 
G_M000_IG170:                ;; offset=0x1342
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG163
 
G_M000_IG171:                ;; offset=0x1352
       mov      r10, gword ptr [rbp-0x340]
       jmp      G_M000_IG165
 
G_M000_IG172:                ;; offset=0x135E
       xor      r14, r14
       xor      r15d, r15d
       jmp      G_M000_IG224
 
G_M000_IG173:                ;; offset=0x1369
       mov      rcx, r12
       jmp      G_M000_IG228
 
G_M000_IG174:                ;; offset=0x1371
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG100
 
G_M000_IG175:                ;; offset=0x139B
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG176:                ;; offset=0x13AA
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG178
 
G_M000_IG177:                ;; offset=0x13B9
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r9, rdx
 
G_M000_IG178:                ;; offset=0x13C3
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG179:                ;; offset=0x13E2
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG180:                ;; offset=0x1407
       test     al, al
       jne      SHORT G_M000_IG184
 
G_M000_IG181:                ;; offset=0x140B
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG182:                ;; offset=0x1412
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG183:                ;; offset=0x141F
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp+0xB18]
       test     rbx, rbx
       je       G_M000_IG02
       jmp      G_M000_IG344
 
G_M000_IG184:                ;; offset=0x1452
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG185:                ;; offset=0x1459
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG186:                ;; offset=0x1466
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG281
       jmp      G_M000_IG348
 
G_M000_IG187:                ;; offset=0x14D1
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG486
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG106
 
G_M000_IG188:                ;; offset=0x14E8
       mov      rcx, 0x7FF9D7196D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG108
 
G_M000_IG189:                ;; offset=0x151B
       mov      rcx, 0x7FF9D754B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
       lea      rcx, [rbp-0x270]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x270]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x268]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG108
 
G_M000_IG190:                ;; offset=0x157A
       mov      rdx, 0x7FF9D77FA4F0
       cmp      qword ptr [r14], rdx
       je       G_M000_IG197
 
G_M000_IG191:                ;; offset=0x158D
       mov      rdx, r14
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG197
 
G_M000_IG192:                ;; offset=0x15A5
       mov      rcx, 0x7FF9D7848D18
       cmp      qword ptr [r14], rcx
       je       SHORT G_M000_IG196
 
G_M000_IG193:                ;; offset=0x15B4
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG194:                ;; offset=0x15C2
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG432
 
G_M000_IG195:                ;; offset=0x15CF
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG196:                ;; offset=0x15EE
       mov      rcx, r14
       lea      rdx, [rbp-0x260]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rbx, gword ptr [rbp-0x260]
       mov      rsi, qword ptr [rbp-0x258]
       jmp      G_M000_IG112
 
G_M000_IG197:                ;; offset=0x1611
       mov      rdx, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG486
       mov      eax, esi
       lea      rbx, bword ptr [rdx+4*rax+0x10]
       mov      rdx, 0x7FF9D77FA4F0
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG200
 
G_M000_IG198:                ;; offset=0x1637
       mov      rdx, r14
       mov      eax, dword ptr [rbx]
       cmp      eax, dword ptr [rdx+0x28]
       jge      SHORT G_M000_IG203
 
G_M000_IG199:                ;; offset=0x1641
       mov      rdx, gword ptr [rdx+0x08]
       mov      eax, dword ptr [rbx]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG486
       mov      rdx, gword ptr [rdx+8*rax+0x10]
       inc      dword ptr [rbx]
       lea      rcx, [rbp-0x298]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG204
 
G_M000_IG200:                ;; offset=0x1666
       mov      rdx, r14
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG431
       mov      edx, dword ptr [rbx]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG205
 
G_M000_IG201:                ;; offset=0x168D
       mov      r8d, 1
 
G_M000_IG202:                ;; offset=0x1693
       cmp      edx, r8d
       jl       SHORT G_M000_IG206
 
G_M000_IG203:                ;; offset=0x1698
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x298], xmm0
 
G_M000_IG204:                ;; offset=0x16A4
       mov      rbx, gword ptr [rbp-0x298]
       mov      rsi, qword ptr [rbp-0x290]
       jmp      G_M000_IG112
 
G_M000_IG205:                ;; offset=0x16B7
       mov      r8d, dword ptr [rcx+0x08]
       test     r8d, r8d
       jl       G_M000_IG487
       jmp      SHORT G_M000_IG202
 
G_M000_IG206:                ;; offset=0x16C6
       mov      edx, dword ptr [rbx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:get_Item(int):System.Object:this]
       mov      rdx, rax
       inc      dword ptr [rbx]
       lea      rcx, [rbp-0x298]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG204
 
G_M000_IG207:                ;; offset=0x16E5
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG426
 
G_M000_IG208:                ;; offset=0x16F2
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG209:                ;; offset=0x16F9
       lea      r8, bword ptr [rbx+0x34]
       mov      esi, dword ptr [r8]
       add      esi, 4
       mov      r10d, dword ptr [r8]
       cmp      r10d, eax
       ja       G_M000_IG352
       mov      r9d, r10d
       add      rdx, r9
       sub      eax, r10d
       cmp      eax, 4
       jl       G_M000_IG427
       mov      edi, dword ptr [rdx]
       lea      eax, [rsi+rdi]
       mov      dword ptr [r8], eax
       movsxd   r14, edi
       add      r14, 128
       cmp      r14, qword ptr [rbx+0x28]
       jg       G_M000_IG428
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG429
       lea      r15, bword ptr [rax+0x10]
       mov      r13d, dword ptr [rax+0x08]
 
G_M000_IG210:                ;; offset=0x1752
       mov      r12, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rbx+0x20]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x340], rdx
       test     edi, edi
       je       G_M000_IG219
 
G_M000_IG211:                ;; offset=0x1774
       mov      rcx, 0x7FF9D75C1030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x350], rax
       mov      dword ptr [rax+0x1C], -1
       test     edi, edi
       jl       G_M000_IG430
 
G_M000_IG212:                ;; offset=0x1799
       cmp      edi, 8
       jg       G_M000_IG162
 
G_M000_IG213:                ;; offset=0x17A2
       mov      byte  ptr [rax+0x24], dil
 
G_M000_IG214:                ;; offset=0x17A6
       mov      rax, gword ptr [rbp-0x350]
       mov      dword ptr [rax+0x18], edi
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, gword ptr [rbp-0x350]
       lea      rdx, [rbp-0x280]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      edi, dword ptr [rbp-0x278]
       mov      rax, bword ptr [rbp-0x280]
       mov      bword ptr [rbp-0x358], rax
       xor      r8d, r8d
       mov      dword ptr [rbp-0x284], r8d
       cmp      r8d, edi
       jl       G_M000_IG168
 
G_M000_IG215:                ;; offset=0x17FA
       mov      rcx, r12
       mov      edx, edi
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
 
G_M000_IG216:                ;; offset=0x1805
       sub      qword ptr [rbx+0x28], r14
       mov      rbx, r12
       jmp      G_M000_IG111
 
G_M000_IG217:                ;; offset=0x1811
       mov      r10, gword ptr [rbp-0x340]
       jmp      G_M000_IG165
 
G_M000_IG218:                ;; offset=0x181D
       mov      r11d, r9d
       jmp      G_M000_IG167
 
G_M000_IG219:                ;; offset=0x1825
       mov      r9, 0x1AD1A000F78
       mov      r12, gword ptr [r9]
       jmp      SHORT G_M000_IG216
 
G_M000_IG220:                ;; offset=0x1834
       mov      rdx, rbx
       mov      r8, rsi
       jmp      G_M000_IG114
 
G_M000_IG221:                ;; offset=0x183F
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG175
 
G_M000_IG222:                ;; offset=0x1876
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG172
 
G_M000_IG223:                ;; offset=0x189B
       lea      r14, bword ptr [rax+0x10]
       mov      r15d, dword ptr [rax+0x08]
 
G_M000_IG224:                ;; offset=0x18A3
       mov      r13d, dword ptr [rcx+0x10]
       xor      rax, rax
       mov      gword ptr [rbp-0x2D0], rax
       test     esi, esi
       jge      G_M000_IG132
 
G_M000_IG225:                ;; offset=0x18B8
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG131
 
G_M000_IG226:                ;; offset=0x18C7
       mov      r12, gword ptr [rdi+0x38]
       mov      rdx, r12
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG486
       mov      r15, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       cmp      esi, r10d
       jae      G_M000_IG486
       mov      eax, esi
       mov      r14, gword ptr [r12+8*rax+0x10]
       mov      rcx, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       jne      G_M000_IG173
 
G_M000_IG227:                ;; offset=0x1919
       xor      rcx, rcx
 
G_M000_IG228:                ;; offset=0x191B
       test     rcx, rcx
       je       SHORT G_M000_IG234
 
G_M000_IG229:                ;; offset=0x1920
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      SHORT G_M000_IG233
 
G_M000_IG230:                ;; offset=0x192D
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG486
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jl       SHORT G_M000_IG234
 
G_M000_IG231:                ;; offset=0x1944
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       SHORT G_M000_IG234
 
G_M000_IG232:                ;; offset=0x1956
       mov      gword ptr [rbp-0x2D0], rax
       jmp      G_M000_IG241
 
G_M000_IG233:                ;; offset=0x1962
       lea      r8, [rbp-0x2D0]
       mov      rdx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG241
 
G_M000_IG234:                ;; offset=0x197C
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG239
 
G_M000_IG235:                ;; offset=0x1986
       mov      rcx, 0x7FF9D71ADDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, 0x1AD1A000068
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x360], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rsi+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x360]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x19CA
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG237:                ;; offset=0x19D6
       lea      rcx, bword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG331
       mov      rdx, rsi
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG239
 
G_M000_IG238:                ;; offset=0x19F7
       mov      rcx, rsi
 
G_M000_IG239:                ;; offset=0x19FA
       cmp      byte  ptr [rcx], cl
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       G_M000_IG126
 
G_M000_IG240:                ;; offset=0x1A0E
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rcx
 
G_M000_IG241:                ;; offset=0x1A18
       mov      rdx, gword ptr [rbp-0x2D0]
 
G_M000_IG242:                ;; offset=0x1A1F
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG147
 
G_M000_IG243:                ;; offset=0x1A3B
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       G_M000_IG147
 
G_M000_IG244:                ;; offset=0x1A4F
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [rcx+0x18]
       test     r8d, r8d
       jl       G_M000_IG146
 
G_M000_IG245:                ;; offset=0x1A63
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jl       G_M000_IG148
 
G_M000_IG246:                ;; offset=0x1A75
       mov      r9d, ecx
 
G_M000_IG247:                ;; offset=0x1A78
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG248:                ;; offset=0x1A98
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG249:                ;; offset=0x1ABD
       test     al, al
       jne      G_M000_IG466
 
G_M000_IG250:                ;; offset=0x1AC5
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, rdx
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG251:                ;; offset=0x1AE1
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG252:                ;; offset=0x1AEF
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG410
       jmp      SHORT G_M000_IG255
 
G_M000_IG253:                ;; offset=0x1AFE
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG254:                ;; offset=0x1B16
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG255:                ;; offset=0x1B24
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG256:                ;; offset=0x1B43
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG259
 
G_M000_IG257:                ;; offset=0x1B4D
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1B65
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG489
 
G_M000_IG259:                ;; offset=0x1B74
       mov      rbx, bword ptr [rbp+0xC58]
       mov      r8d, dword ptr [rbx+0x08]
       test     r8d, r8d
       jne      G_M000_IG407
 
G_M000_IG260:                ;; offset=0x1B88
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x250]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG261:                ;; offset=0x1C05
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x240]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG262:                ;; offset=0x1C82
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG263:                ;; offset=0x1CC5
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x230]
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG264:                ;; offset=0x1D35
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG265:                ;; offset=0x1D43
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG486
       mov      ecx, eax
       mov      r14, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r15, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r13d
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, r14
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG266:                ;; offset=0x1DDE
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG267:                ;; offset=0x1DEC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG486
       mov      ecx, eax
       mov      rsi, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r14d
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG268:                ;; offset=0x1E70
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG151
 
G_M000_IG269:                ;; offset=0x1E98
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG270:                ;; offset=0x1EBF
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG271:                ;; offset=0x1ECD
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG272:                ;; offset=0x1EE9
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG398
 
G_M000_IG273:                ;; offset=0x1F18
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG274:                ;; offset=0x1F26
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG278
 
G_M000_IG275:                ;; offset=0x1F2F
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG276:                ;; offset=0x1F36
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG277:                ;; offset=0x1F43
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp+0xB18]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG336
 
G_M000_IG278:                ;; offset=0x1F76
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG279:                ;; offset=0x1F7D
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG280:                ;; offset=0x1F8A
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       jne      G_M000_IG340
 
G_M000_IG281:                ;; offset=0x1FF6
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG282:                ;; offset=0x2008
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG253
 
G_M000_IG283:                ;; offset=0x2055
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG489
 
G_M000_IG284:                ;; offset=0x2060
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rbp+0xC28]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG286
 
G_M000_IG285:                ;; offset=0x208E
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG286:                ;; offset=0x209F
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG478
 
G_M000_IG287:                ;; offset=0x20AC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG288:                ;; offset=0x20D9
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG149
 
G_M000_IG289:                ;; offset=0x20E7
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
 
G_M000_IG290:                ;; offset=0x2121
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     al, al
       je       G_M000_IG258
 
G_M000_IG291:                ;; offset=0x213E
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG258
 
G_M000_IG292:                ;; offset=0x2149
       xor      r8, r8
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], r8
       mov      word  ptr [r10+0x08], 0
       movzx    r8, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], r8b
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG489
 
G_M000_IG293:                ;; offset=0x217D
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG298
       jmp      G_M000_IG02
 
G_M000_IG294:                ;; offset=0x21AB
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG250
       jmp      G_M000_IG151
 
G_M000_IG295:                ;; offset=0x21BE
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG296:                ;; offset=0x21CC
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG472
       jmp      G_M000_IG250
 
G_M000_IG297:                ;; offset=0x21DE
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG298:                ;; offset=0x2208
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG416
 
G_M000_IG299:                ;; offset=0x2266
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0xB0]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FF9D7648680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG439
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG438
       mov      rbx, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG300:                ;; offset=0x22A2
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 51
       ja       G_M000_IG153
 
G_M000_IG301:                ;; offset=0x22B5
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rdx
       jb       G_M000_IG153
 
G_M000_IG302:                ;; offset=0x22C9
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x18]
       test     esi, esi
       jl       G_M000_IG152
 
G_M000_IG303:                ;; offset=0x22DB
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x10], 0
       jl       G_M000_IG154
 
G_M000_IG304:                ;; offset=0x22EC
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      rdx, gword ptr [rdx]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, esi
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG486
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x1AD1A001CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG161
 
G_M000_IG305:                ;; offset=0x2330
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x1AD1A001CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG160
 
G_M000_IG306:                ;; offset=0x2346
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG311
 
G_M000_IG307:                ;; offset=0x234D
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7763360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG311
 
G_M000_IG308:                ;; offset=0x2368
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG159
 
G_M000_IG309:                ;; offset=0x238C
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG310:                ;; offset=0x23A1
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG311:                ;; offset=0x23B2
       mov      r14, gword ptr [rdi]
 
G_M000_IG312:                ;; offset=0x23B5
       test     r14, r14
       je       G_M000_IG443
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], r14
       lea      rdx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG319
 
G_M000_IG313:                ;; offset=0x23F9
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
 
G_M000_IG314:                ;; offset=0x2407
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D7500AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG316
 
G_M000_IG315:                ;; offset=0x2426
       jmp      G_M000_IG496
 
G_M000_IG316:                ;; offset=0x242B
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x243A
       mov      rcx, 0x7FF9D76B9D18
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG444
 
G_M000_IG318:                ;; offset=0x244D
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      SHORT G_M000_IG325
 
G_M000_IG319:                ;; offset=0x247A
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG445
 
G_M000_IG320:                ;; offset=0x2488
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG326
 
G_M000_IG321:                ;; offset=0x24B9
       mov      r8, bword ptr [rbp+0xC50]
       mov      r14, gword ptr [r8]
       test     r14, r14
       jne      G_M000_IG448
 
G_M000_IG322:                ;; offset=0x24CC
       mov      r8, bword ptr [rbp+0xC50]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG451
 
G_M000_IG323:                ;; offset=0x24DF
       mov      r15, gword ptr [r8+0x08]
 
G_M000_IG324:                ;; offset=0x24E3
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      r15, rcx
       je       G_M000_IG455
 
G_M000_IG325:                ;; offset=0x24F3
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG489
 
G_M000_IG326:                ;; offset=0x2512
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG460
 
G_M000_IG327:                ;; offset=0x251F
       mov      gword ptr [rsp+0x20], r14
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG456
 
G_M000_IG328:                ;; offset=0x2559
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x1CD40BDD5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG329:                ;; offset=0x2579
       mov      rcx, 0x7FF9D72CE510
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       call     [System.IndexOutOfRangeException:.ctor():this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG330:                ;; offset=0x259D
       mov      rdx, r12
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG331:                ;; offset=0x25A7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG332:                ;; offset=0x25AE
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG333:                ;; offset=0x25DC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx]
       mov      rbx, gword ptr [r8+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1CE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG334:                ;; offset=0x2625
       add      dword ptr [rsi+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG335:                ;; offset=0x262E
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1F0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG336:                ;; offset=0x2669
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG339
 
G_M000_IG337:                ;; offset=0x2681
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG338:                ;; offset=0x2696
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG339:                ;; offset=0x26A9
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D70A1D08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG340:                ;; offset=0x26C6
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG341
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG342
 
G_M000_IG341:                ;; offset=0x26EF
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG342:                ;; offset=0x2715
       test     edi, edi
       jne      G_M000_IG281
 
G_M000_IG343:                ;; offset=0x271D
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG489
 
G_M000_IG344:                ;; offset=0x2742
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG347
 
G_M000_IG345:                ;; offset=0x275A
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG346:                ;; offset=0x276F
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG347:                ;; offset=0x2782
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D70A1D18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG348:                ;; offset=0x279F
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG349
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x27C8
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG350:                ;; offset=0x27EE
       test     esi, esi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG351:                ;; offset=0x27FB
       mov      rax, rcx
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG352:                ;; offset=0x2805
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG353:                ;; offset=0x280C
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG85
 
G_M000_IG354:                ;; offset=0x2817
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG357
 
G_M000_IG355:                ;; offset=0x282F
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG356:                ;; offset=0x2844
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG357:                ;; offset=0x2857
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70A1D28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG358:                ;; offset=0x2874
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG359:                ;; offset=0x2884
       lea      rdx, [rbp-0x320]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG281
 
G_M000_IG360:                ;; offset=0x28CF
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG361
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG362
 
G_M000_IG361:                ;; offset=0x28F8
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG362:                ;; offset=0x291E
       test     edi, edi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG363:                ;; offset=0x292B
       cmp      byte  ptr [rdx+0xFF], 0
       jne      SHORT G_M000_IG366
 
G_M000_IG364:                ;; offset=0x2934
       cmp      ebx, esi
       jle      SHORT G_M000_IG366
 
G_M000_IG365:                ;; offset=0x2938
       cmp      esi, ebx
       jae      G_M000_IG486
       mov      r8, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       cmp      dword ptr [r8+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       mov      rdx, gword ptr [rbp+0xC30]
       jmp      G_M000_IG81
 
G_M000_IG366:                ;; offset=0x2968
       mov      rdx, gword ptr [rbp+0xC30]
       xor      r15d, r15d
       jmp      G_M000_IG81
 
G_M000_IG367:                ;; offset=0x2977
       test     rdi, rdi
       je       G_M000_IG376
 
G_M000_IG368:                ;; offset=0x2980
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG369:                ;; offset=0x2990
       lea      r8, [rbp-0x2F0]
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG376
 
G_M000_IG370:                ;; offset=0x29AF
       cmp      esi, ebx
       jae      G_M000_IG486
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       mov      r15, gword ptr [rcx+r14+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG372
 
G_M000_IG371:                ;; offset=0x29E8
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG372:                ;; offset=0x29F4
       mov      r9, gword ptr [rbp+0xC28]
       mov      rsi, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG374
 
G_M000_IG373:                ;; offset=0x2A13
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG375
 
G_M000_IG374:                ;; offset=0x2A23
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG375:                ;; offset=0x2A38
       lea      rcx, bword ptr [rsi+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       lea      rcx, bword ptr [rax+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG497
 
G_M000_IG376:                ;; offset=0x2A7C
       mov      rdx, gword ptr [rbp+0xC30]
       lea      rsi, bword ptr [rdx+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rsi+0x08], rcx
       mov      rdx, gword ptr [rbp+0xC30]
       mov      word  ptr [rdx+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       jne      G_M000_IG258
 
G_M000_IG377:                ;; offset=0x2AC7
       test     rdi, rdi
       je       G_M000_IG258
 
G_M000_IG378:                ;; offset=0x2AD0
       mov      rcx, rdx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG258
       jmp      G_M000_IG497
 
G_M000_IG379:                ;; offset=0x2AE9
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG380:                ;; offset=0x2AF0
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG381:                ;; offset=0x2AFD
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG385
 
G_M000_IG382:                ;; offset=0x2B4B
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG383
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG384
 
G_M000_IG383:                ;; offset=0x2B74
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG384:                ;; offset=0x2B9A
       test     edi, edi
       je       G_M000_IG343
 
G_M000_IG385:                ;; offset=0x2BA2
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG78
 
G_M000_IG386:                ;; offset=0x2BB4
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      gword ptr [rdx+0x68], 0
       jne      G_M000_IG388
 
G_M000_IG387:                ;; offset=0x2BC6
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [r8+0x68]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG388:                ;; offset=0x2C7B
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rdx+0x68]
       mov      r8, gword ptr [rdx+0x58]
       mov      r9, gword ptr [rdx+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG389:                ;; offset=0x2CA4
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG390:                ;; offset=0x2CB1
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG78
 
G_M000_IG391:                ;; offset=0x2CD1
       mov      rdx, r8
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rdx+0x70]
       test     r8, r8
       je       G_M000_IG258
 
G_M000_IG392:                ;; offset=0x2CF6
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG258
       jmp      G_M000_IG497
 
G_M000_IG393:                ;; offset=0x2D0F
       mov      rcx, gword ptr [rdi]
       mov      r8, gword ptr [rdi+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG394:                ;; offset=0x2D2B
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG281
 
G_M000_IG395:                ;; offset=0x2D8D
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG396
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG397
 
G_M000_IG396:                ;; offset=0x2DB6
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG397:                ;; offset=0x2DDC
       test     r14d, r14d
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG398:                ;; offset=0x2DEA
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG151
 
G_M000_IG399:                ;; offset=0x2E0F
       test     al, al
       jne      SHORT G_M000_IG401
 
G_M000_IG400:                ;; offset=0x2E13
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG401:                ;; offset=0x2E2F
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG402:                ;; offset=0x2E36
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG403:                ;; offset=0x2E43
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG281
 
G_M000_IG404:                ;; offset=0x2E95
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG405
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG406
 
G_M000_IG405:                ;; offset=0x2EBE
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG406:                ;; offset=0x2EE4
       test     edi, edi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG407:                ;; offset=0x2EF1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG260
 
G_M000_IG408:                ;; offset=0x2F0D
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG409:                ;; offset=0x2F19
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG489
 
G_M000_IG410:                ;; offset=0x2F4A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG411:                ;; offset=0x2F51
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG412:                ;; offset=0x2F5E
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG253
 
G_M000_IG413:                ;; offset=0x2FB0
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG414
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG415
 
G_M000_IG414:                ;; offset=0x2FD9
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG415:                ;; offset=0x2FFF
       test     esi, esi
       jne      G_M000_IG253
       jmp      G_M000_IG343
 
G_M000_IG416:                ;; offset=0x300C
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG489
 
G_M000_IG417:                ;; offset=0x3037
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG486
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG100
 
G_M000_IG418:                ;; offset=0x3067
       mov      rax, 0x7FF9D77F5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG100
 
G_M000_IG419:                ;; offset=0x307A
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG100
 
G_M000_IG420:                ;; offset=0x308C
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG100
 
G_M000_IG421:                ;; offset=0x3097
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG253
 
G_M000_IG422:                ;; offset=0x30F6
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG423
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG424
 
G_M000_IG423:                ;; offset=0x311F
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG424:                ;; offset=0x3145
       test     esi, esi
       jne      G_M000_IG253
       jmp      G_M000_IG343
 
G_M000_IG425:                ;; offset=0x3152
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG426:                ;; offset=0x3180
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG209
 
G_M000_IG427:                ;; offset=0x3189
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG428:                ;; offset=0x3195
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BE4020
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG429:                ;; offset=0x31C3
       xor      r15, r15
       xor      r13d, r13d
       jmp      G_M000_IG210
 
G_M000_IG430:                ;; offset=0x31CE
       mov      ecx, edi
       mov      rdx, 0x1CD40BD6810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG431:                ;; offset=0x31E1
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0x1CD40BE46A8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG432:                ;; offset=0x320F
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG433:                ;; offset=0x3216
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG434:                ;; offset=0x3223
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG253
 
G_M000_IG435:                ;; offset=0x3275
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG436
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG437
 
G_M000_IG436:                ;; offset=0x329E
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG437:                ;; offset=0x32C4
       test     esi, esi
       jne      G_M000_IG253
       jmp      G_M000_IG343
 
G_M000_IG438:                ;; offset=0x32D1
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG439:                ;; offset=0x32D8
       mov      rcx, rax
       mov      r11, 0x7FF9D70A1CF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG300
 
G_M000_IG440:                ;; offset=0x32F0
       jmp      G_M000_IG496
 
G_M000_IG441:                ;; offset=0x32F5
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA8]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG442:                ;; offset=0x3305
       lea      r9, [rbp-0x2F0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG443:                ;; offset=0x332C
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG444:                ;; offset=0x335A
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG445:                ;; offset=0x3361
       mov      gword ptr [rsp+0x20], r14
       lea      rcx, [rbp+0xA90]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG446:                ;; offset=0x3394
       cmp      gword ptr [rbp+0xA90], 0
       je       G_M000_IG02
 
G_M000_IG447:                ;; offset=0x33A2
       mov      r8, gword ptr [rbp+0xA90]
       xor      r10, r10
       mov      r11, bword ptr [rbp+0xC50]
       mov      gword ptr [r11], r10
       lea      rcx, bword ptr [r11+0x08]
       mov      rdx, r8
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r11, bword ptr [rbp+0xC50]
       mov      word  ptr [r11+0x10], 0
       mov      byte  ptr [r11+0x12], 1
       jmp      G_M000_IG325
 
G_M000_IG448:                ;; offset=0x33DA
       mov      rdx, r14
       mov      rcx, 0x7FF9D7895AD0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG449
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG450
 
G_M000_IG449:                ;; offset=0x33FD
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D70A1D68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG450:                ;; offset=0x3422
       test     eax, eax
       je       G_M000_IG325
       jmp      G_M000_IG322
 
G_M000_IG451:                ;; offset=0x342F
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7895AD0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG454
       mov      ecx, dword ptr [r15+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG453
 
G_M000_IG452:                ;; offset=0x345C
       mov      rcx, r15
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG453:                ;; offset=0x3467
       mov      r15, gword ptr [r15+0x38]
       jmp      G_M000_IG324
 
G_M000_IG454:                ;; offset=0x3470
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A1D70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG324
 
G_M000_IG455:                ;; offset=0x3494
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG175
 
G_M000_IG456:                ;; offset=0x34AD
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG459
 
G_M000_IG457:                ;; offset=0x34C5
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG458:                ;; offset=0x34DA
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG459:                ;; offset=0x34ED
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D70A1D78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG460:                ;; offset=0x350A
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG281
 
G_M000_IG461:                ;; offset=0x357C
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG462
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG463
 
G_M000_IG462:                ;; offset=0x35A5
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D80
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG463:                ;; offset=0x35CB
       test     esi, esi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG464:                ;; offset=0x35D8
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG465:                ;; offset=0x35FC
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG466:                ;; offset=0x362A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG467:                ;; offset=0x3631
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG468:                ;; offset=0x363E
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG281
 
G_M000_IG469:                ;; offset=0x36A4
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG470
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG471
 
G_M000_IG470:                ;; offset=0x36CD
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG471:                ;; offset=0x36F3
       test     esi, esi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG472:                ;; offset=0x3700
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG473:                ;; offset=0x3707
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG474:                ;; offset=0x3714
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG281
 
G_M000_IG475:                ;; offset=0x377A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG476
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG477
 
G_M000_IG476:                ;; offset=0x37A3
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG477:                ;; offset=0x37C9
       test     esi, esi
       jne      G_M000_IG281
       jmp      G_M000_IG343
 
G_M000_IG478:                ;; offset=0x37D6
       test     rbx, rbx
       je       G_M000_IG287
 
G_M000_IG479:                ;; offset=0x37DF
       mov      r8, 0x7FF9D77F9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG287
 
G_M000_IG480:                ;; offset=0x37F2
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG481:                ;; offset=0x37F9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG482:                ;; offset=0x3806
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG253
 
G_M000_IG483:                ;; offset=0x385A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG484
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG485
 
G_M000_IG484:                ;; offset=0x3883
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A1D98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG485:                ;; offset=0x38A9
       test     esi, esi
       jne      G_M000_IG253
       jmp      G_M000_IG343
 
G_M000_IG486:                ;; offset=0x38B6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG487:                ;; offset=0x38BC
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG488:                ;; offset=0x38C2
       lea      rcx, [rbp+0xA60]
       mov      rdx, 0x1CD40BE2A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG75
 
G_M000_IG489:                ;; offset=0x38DE
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG490:                ;; offset=0x38E4
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG491:                ;; offset=0x38FB
       mov      eax, 1
 
G_M000_IG492:                ;; offset=0x3900
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG493:                ;; offset=0x3917
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
 
G_M000_IG494:                ;; offset=0x3929
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG495:                ;; offset=0x394E
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG496:                ;; offset=0x3965
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, r15
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG498
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG497:                ;; offset=0x3999
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      G_M000_IG491
 
G_M000_IG498:                ;; offset=0x39AE
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG499:                ;; offset=0x39B7
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG500:                ;; offset=0x39BD
       sub      rsp, 72
 
G_M000_IG501:                ;; offset=0x39C1
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG503
 
G_M000_IG502:                ;; offset=0x39CE
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG503:                ;; offset=0x39D4
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG506
 
G_M000_IG504:                ;; offset=0x39F8
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG489
 
G_M000_IG505:                ;; offset=0x3A09
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG506:                ;; offset=0x3A11
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG507:                ;; offset=0x3A22
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG508:                ;; offset=0x3A2A
       sub      rsp, 72
 
G_M000_IG509:                ;; offset=0x3A2E
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG511
 
G_M000_IG510:                ;; offset=0x3A5C
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG511:                ;; offset=0x3A62
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG512:                ;; offset=0x3A73
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000006B2h ; case G_M000_IG69
       	dd	0000064Bh ; case G_M000_IG68
       	dd	000000E6h ; case G_M000_IG12
       	dd	00000DB4h ; case G_M000_IG123
       	dd	00000D4Ah ; case G_M000_IG122
       	dd	00000CB6h ; case G_M000_IG120
       	dd	00000C43h ; case G_M000_IG116
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	0000216Eh ; case G_M000_IG298
       	dd	0000216Eh ; case G_M000_IG298
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E7Eh ; case G_M000_IG273
       	dd	00001E4Fh ; case G_M000_IG272
       	dd	00001E4Fh ; case G_M000_IG272
       	dd	00001E25h ; case G_M000_IG270
       	dd	00001DFEh ; case G_M000_IG269
       	dd	00001DD6h ; case G_M000_IG268
       	dd	00001D44h ; case G_M000_IG266
       	dd	00001C9Bh ; case G_M000_IG264
       	dd	00001C2Bh ; case G_M000_IG263
       	dd	00001BE8h ; case G_M000_IG262
       	dd	00001B6Bh ; case G_M000_IG261
       	dd	00001AA9h ; case G_M000_IG256
       	dd	00001A7Ch ; case G_M000_IG254
       	dd	00001A7Ch ; case G_M000_IG254
       	dd	00001A7Ch ; case G_M000_IG254
       	dd	00001A47h ; case G_M000_IG251
       	dd	00001A47h ; case G_M000_IG251
       	dd	00001A47h ; case G_M000_IG251
       	dd	00001A7Ch ; case G_M000_IG254
       	dd	000017DCh ; case G_M000_IG222
       	dd	00000AF6h ; case G_M000_IG100
       	dd	000021CCh ; case G_M000_IG299
       	dd	00002144h ; case G_M000_IG297
       	dd	00002124h ; case G_M000_IG295
       	dd	00002111h ; case G_M000_IG294
       	dd	000020E3h ; case G_M000_IG293
       	dd	000020E3h ; case G_M000_IG293
       	dd	000020E3h ; case G_M000_IG293
       	dd	0000203Fh ; case G_M000_IG288
       	dd	00001FC6h ; case G_M000_IG284
       	dd	00001F6Eh ; case G_M000_IG282
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	0000203Fh ; case G_M000_IG288
       	dd	00001ACBh ; case G_M000_IG258
       	dd	00000830h ; case G_M000_IG79
       	dd	000007F6h ; case G_M000_IG76
       	dd	0000203Fh ; case G_M000_IG288
       	dd	00001310h ; case G_M000_IG176
       	dd	00001310h ; case G_M000_IG176
       	dd	00001310h ; case G_M000_IG176
       	dd	00001310h ; case G_M000_IG176
       	dd	00001310h ; case G_M000_IG176
       	dd	000012D7h ; case G_M000_IG174
       	dd	00000ACDh ; case G_M000_IG98
       	dd	0000099Ch ; case G_M000_IG90
       	dd	000008E5h ; case G_M000_IG83
       	dd	000008ADh ; case G_M000_IG82
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 14971

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x4A0
       lea      rbp, [rsp+0x4A0]
       xor      eax, eax
       mov      qword ptr [rbp-0x458], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0x450
 
G_M000_IG88:                ;; offset=0x0027
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG88
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0046
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rax, gword ptr [rbp-0x100]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, gword ptr [rbp-0x278]
       mov      rdx, 0x7FF9D7A1CE50
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x278]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2C4], eax
       mov      rcx, gword ptr [rbp-0x2C0]
       mov      edx, dword ptr [rbp-0x2C4]
       mov      r11, 0x7FF9D70A20A0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2C8], eax
       mov      edx, dword ptr [rbp-0x2C8]
       mov      rcx, bword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      edx, dword ptr [rbp-0x2CC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, gword ptr [rbp-0x280]
       mov      rdx, 0x7FF9D7A1CF58
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x280]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      rcx, 0x7FF9D776AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0181
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2E0], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x50]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0x2E0]
       mov      rax, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rax+0x10]
       mov      rdx, gword ptr [rbp-0x38]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG05
       lea      rcx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rcx, gword ptr [rbp-0x288]
       mov      rdx, 0x7FF9D7A1D060
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x288]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x290], rax
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdx, 0x7FF9D7A1D168
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x290]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rcx, gword ptr [rbp-0x2F0]
       mov      r11, 0x7FF9D70A20C0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x0275
       mov      rcx, gword ptr [rbp-0x58]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG05:                ;; offset=0x027F
       mov      rcx, 0x7FF9D7A1D270
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG06:                ;; offset=0x0290
       mov      rcx, 0x7FF9D7A1D274
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
 
G_M000_IG07:                ;; offset=0x02AF
       vzeroupper 
       add      rsp, 0x4A0
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x02BB
       mov      rcx, 0x7FF9D7A1D278
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x02CA
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG10:                ;; offset=0x02D7
       lea      r8, [rbp-0x300]
       mov      rdx, bword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      eax, 1
 
G_M000_IG11:                ;; offset=0x02F1
       vzeroupper 
       add      rsp, 0x4A0
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x02FD
       mov      rcx, 0x7FF9D7A1D27C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x0C]
       lea      r8d, [rax+0x01]
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0x0C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x0C]
       lea      r8d, [rax+0x02]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
 
G_M000_IG13:                ;; offset=0x033F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x10C], eax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x10C], eax
       jae      G_M000_IG77
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x10C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x308], rax
       mov      rdx, gword ptr [rbp-0x308]
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG14:                ;; offset=0x03C4
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG15
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG64
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG75
 
G_M000_IG15:                ;; offset=0x0405
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x230], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x234], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x30C], eax
       mov      r9d, dword ptr [rbp-0x30C]
       lea      rdx, [rbp-0x248]
       mov      r8d, dword ptr [rbp-0x234]
       mov      rcx, bword ptr [rbp-0x230]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG16:                ;; offset=0x0489
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG17:                ;; offset=0x0499
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, gword ptr [rbp-0x328]
       lea      rcx, [rbp-0x320]
       lea      r9, [rbp-0x68]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, 0x7FF9D7A1D280
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG75
 
G_M000_IG18:                ;; offset=0x04E9
       mov      rcx, 0x7FF9D7A1D284
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x04FA
       mov      rcx, 0x7FF9D7A1D288
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG20:                ;; offset=0x051C
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG55
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76B4690
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x138], rax
       mov      rax, bword ptr [rbp-0x138]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG59
       mov      rax, bword ptr [rbp-0x138]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG36
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, 0x7FF9D75C1030
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       je       G_M000_IG31
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdx, gword ptr [rbp-0x330]
       mov      rcx, 0x7FF9D76B31D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x88], rax
       cmp      gword ptr [rbp-0x88], 0
       je       G_M000_IG30
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG21:                ;; offset=0x0618
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG29
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG22:                ;; offset=0x0650
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
 
G_M000_IG23:                ;; offset=0x065C
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x298], rax
       mov      rcx, gword ptr [rbp-0x298]
       mov      rdx, 0x7FF9D7A1D290
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x298]
       mov      gword ptr [rbp-0x338], rax
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x33C], eax
       mov      rcx, gword ptr [rbp-0x338]
       mov      edx, dword ptr [rbp-0x33C]
       mov      r11, 0x7FF9D70A20B8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1B8], rax
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      rcx, gword ptr [rbp-0x1B8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG24:                ;; offset=0x0715
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x1C0], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rcx, gword ptr [rbp-0xC8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG26
       mov      rax, bword ptr [rbp-0x1C8]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG25
       mov      rax, bword ptr [rbp-0x210]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0xC8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x204], eax
       jmp      G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0803
       mov      rcx, 0x7FF9D7A1D398
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x210]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x200], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x204], eax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0854
       mov      rcx, 0x7FF9D7A1D39C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x1C8]
       mov      bword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1D8]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x200], rax
       mov      dword ptr [rbp-0x204], 1
 
G_M000_IG27:                ;; offset=0x08A5
       mov      rcx, gword ptr [rbp-0x1F0]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      r8, gword ptr [rbp-0x200]
       mov      r9d, dword ptr [rbp-0x204]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x350], rax
       mov      rdx, gword ptr [rbp-0x350]
       mov      rcx, bword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG28:                ;; offset=0x08E3
       call     G_M000_IG78
       jmp      SHORT G_M000_IG33
 
G_M000_IG29:                ;; offset=0x08EA
       mov      rcx, 0x7FF9D7A1D3A0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG36
 
G_M000_IG30:                ;; offset=0x08FE
       mov      rcx, 0x7FF9D7A1D3A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG31:                ;; offset=0x090F
       mov      rcx, 0x7FF9D7A1D3A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x0920
       mov      rcx, 0x7FF9D7A1D3AC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG55
 
G_M000_IG33:                ;; offset=0x0934
       mov      rcx, 0x7FF9D7A1D3B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG34:                ;; offset=0x094B
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x360], xmm0
 
G_M000_IG35:                ;; offset=0x0958
       lea      r8, [rbp-0x360]
       lea      rdx, [rbp-0xC0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x5C], 1
       jmp      G_M000_IG75
 
G_M000_IG36:                ;; offset=0x097C
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x368], rax
       mov      rdx, gword ptr [rbp-0x368]
       mov      rcx, 0x7FF9D7803450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG45
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG37:                ;; offset=0x09FE
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x378], xmm0
 
G_M000_IG38:                ;; offset=0x0A0B
       lea      rdx, [rbp-0x378]
       lea      rcx, [rbp-0x180]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG39:                ;; offset=0x0A1F
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x388], xmm0
 
G_M000_IG40:                ;; offset=0x0A2F
       lea      rax, [rbp-0x98]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xA0]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x388]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG44
       mov      rcx, 0x7FF9D7A1D3B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rcx, gword ptr [rbp-0x2A0]
       mov      rdx, 0x7FF9D7A1D3C0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A0]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG59
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x394], eax
       mov      rcx, gword ptr [rbp-0x390]
       mov      edx, dword ptr [rbp-0x394]
       mov      r11, 0x7FF9D70A20B0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x190], rax
       movzx    rax, byte  ptr [rbp-0xA0]
       mov      dword ptr [rbp-0x194], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rcx, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
 
G_M000_IG41:                ;; offset=0x0B5B
       mov      gword ptr [rbp-0x1A8], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG42:                ;; offset=0x0B7A
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x3A8], xmm0
 
G_M000_IG43:                ;; offset=0x0B8A
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x3A8]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x190]
       mov      r8d, dword ptr [rbp-0x194]
       mov      r9, gword ptr [rbp-0x1A0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdx, gword ptr [rbp-0x3B0]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG64
 
G_M000_IG44:                ;; offset=0x0BEA
       mov      rcx, 0x7FF9D7A1D4C8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0BFB
       mov      rcx, 0x7FF9D7A1D4CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG46:                ;; offset=0x0C0A
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x140], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG47:                ;; offset=0x0C1D
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x3C0], xmm0
 
G_M000_IG48:                ;; offset=0x0C2A
       lea      rdx, [rbp-0x3C0]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG49:                ;; offset=0x0C3E
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
 
G_M000_IG50:                ;; offset=0x0C4E
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x3D0]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG53
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x158], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x15C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x3D4], eax
       mov      r9d, dword ptr [rbp-0x3D4]
       lea      rdx, [rbp-0x170]
       mov      r8d, dword ptr [rbp-0x15C]
       mov      rcx, bword ptr [rbp-0x158]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG51:                ;; offset=0x0D00
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x3E8], xmm0
 
G_M000_IG52:                ;; offset=0x0D10
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xE8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x3F0]
       lea      r8, [rbp-0x3E8]
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rcx, 0x7FF9D7A1D4D0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG75
 
G_M000_IG53:                ;; offset=0x0D75
       mov      rcx, 0x7FF9D7A1D4D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG64
 
G_M000_IG54:                ;; offset=0x0D89
       mov      rcx, 0x7FF9D7A1D4D8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG64
 
G_M000_IG55:                ;; offset=0x0DAE
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG56:                ;; offset=0x0DB2
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x400], xmm0
 
G_M000_IG57:                ;; offset=0x0DBF
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x400]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG62
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rcx, gword ptr [rbp-0x2A8]
       mov      rdx, 0x7FF9D7A1D4E0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdx, gword ptr [rbp-0x408]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0xF0], rax
       cmp      gword ptr [rbp-0xF0], 0
       je       SHORT G_M000_IG60
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rcx, gword ptr [rbp-0x2B0]
       mov      rdx, 0x7FF9D7A1D5E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B0]
       mov      gword ptr [rbp-0x410], rax
       mov      rcx, gword ptr [rbp-0x410]
       mov      r11, 0x7FF9D70A20A8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG61
 
G_M000_IG58:                ;; offset=0x0EAB
       mov      rcx, gword ptr [rbp-0xF0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x0EB8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG60:                ;; offset=0x0EBE
       mov      rcx, 0x7FF9D7A1D6F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0ECF
       mov      rcx, 0x7FF9D7A1D6F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG75
 
G_M000_IG62:                ;; offset=0x0EF9
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG63
       mov      rcx, 0x7FF9D7A1D6F8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG75
 
G_M000_IG63:                ;; offset=0x0F35
       mov      rcx, 0x7FF9D7A1D6FC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG64:                ;; offset=0x0F44
       nop      
 
G_M000_IG65:                ;; offset=0x0F45
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG70
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG69
       mov      rcx, 0x7FF9D7A1D810
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x118], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rcx, gword ptr [rbp-0x118]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x42C], eax
       mov      edx, dword ptr [rbp-0x42C]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG66:                ;; offset=0x1034
       add      rax, 72
       mov      bword ptr [rbp-0x120], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x430], eax
       mov      r9d, dword ptr [rbp-0x430]
       lea      rdx, [rbp-0x130]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG67:                ;; offset=0x1070
       vmovdqu  xmm0, xmmword ptr [rbp-0x130]
       vmovdqu  xmmword ptr [rbp-0x440], xmm0
 
G_M000_IG68:                ;; offset=0x1080
       lea      rcx, [rbp-0x440]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG73
 
G_M000_IG69:                ;; offset=0x108F
       mov      rcx, 0x7FF9D7A1D814
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG70:                ;; offset=0x109E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG77
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x458], rax
 
G_M000_IG71:                ;; offset=0x10CC
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x450], xmm0
 
G_M000_IG72:                ;; offset=0x10D9
       mov      rdx, bword ptr [rbp-0x458]
       lea      r8, [rbp-0x450]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG73:                ;; offset=0x10F1
       mov      rcx, 0x7FF9D7A1D818
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG74:                ;; offset=0x1105
       vzeroupper 
       add      rsp, 0x4A0
       pop      rbp
       ret      
 
G_M000_IG75:                ;; offset=0x1111
       mov      rcx, 0x7FF9D7A1D81C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
 
G_M000_IG76:                ;; offset=0x1123
       vzeroupper 
       add      rsp, 0x4A0
       pop      rbp
       ret      
 
G_M000_IG77:                ;; offset=0x112F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG78:                ;; offset=0x1135
       sub      rsp, 72
 
G_M000_IG79:                ;; offset=0x1139
       mov      rcx, 0x7FF9D7A1D3B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG80:                ;; offset=0x1159
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG81:                ;; offset=0x1161
       sub      rsp, 72
 
G_M000_IG82:                ;; offset=0x1165
       mov      gword ptr [rbp-0x250], rcx
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rcx, gword ptr [rbp-0x2B8]
       mov      rdx, 0x7FF9D7A1D700
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rcx, 0x7FF9D71A2168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x258], rax
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp-0x258], 0
       jne      SHORT G_M000_IG83
       xor      eax, eax
       mov      dword ptr [rbp-0x264], eax
       jmp      SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x11DD
       mov      rcx, 0x7FF9D7A1D808
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       lea      r8, [rbp-0xF8]
       mov      rcx, gword ptr [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x264], eax
 
G_M000_IG84:                ;; offset=0x1228
       mov      rcx, 0x7FF9D7A1D80C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x264]
 
G_M000_IG85:                ;; offset=0x123D
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG86:                ;; offset=0x1245
       sub      rsp, 72
 
G_M000_IG87:                ;; offset=0x1249
       mov      gword ptr [rbp-0x270], rcx
       mov      rcx, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4701

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 131896
; 20 inlinees with PGO data; 105 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       xor      eax, eax
       mov      qword ptr [rbp-0x128], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x120], xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG169:                ;; offset=0x0042
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG169
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x0065
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbx+0x1C], 42
       jne      G_M000_IG122
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9D7648680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG124
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG123
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG03:                ;; offset=0x00A2
       mov      gword ptr [rbp-0x130], rsi
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG125
 
G_M000_IG05:                ;; offset=0x00C5
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG06:                ;; offset=0x00C8
       cmp      dword ptr [rbx+0x10], 0
       jl       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x00CE
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x48]
       mov      rax, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, edi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG147
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x1AD1A001CE0
       cmp      r14, gword ptr [rax]
       je       G_M000_IG141
 
G_M000_IG08:                ;; offset=0x010B
       mov      rax, 0x1AD1A001CE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG142
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG143
 
G_M000_IG09:                ;; offset=0x0129
       test     r14, r14
       je       G_M000_IG144
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       jmp      G_M000_IG33
 
G_M000_IG10:                ;; offset=0x0140
       mov      edx, dword ptr [rbx+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r14, gword ptr [rcx+0x08]
       mov      r15d, dword ptr [rcx+0x38]
       mov      r8, gword ptr [rcx+0x10]
       not      edx
       mov      r13, gword ptr [r14+0x30]
       cmp      dword ptr [r13+0x08], edx
       jg       G_M000_IG126
 
G_M000_IG11:                ;; offset=0x0163
       mov      r9, gword ptr [r14+0x38]
       mov      eax, edx
       sub      eax, dword ptr [r13+0x08]
       cmp      eax, dword ptr [r9+0x08]
       jae      G_M000_IG147
       mov      r12, gword ptr [r9+8*rax+0x10]
       sub      edx, dword ptr [r13+0x08]
       lea      r9, [rbp-0xB8]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG127
       mov      r13, gword ptr [rbp-0xB8]
 
G_M000_IG12:                ;; offset=0x019F
       xor      rcx, rcx
       mov      gword ptr [rbp-0xB8], rcx
       mov      r14d, dword ptr [rbx+0x0C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rcx+0x08]
       mov      rax, bword ptr [rcx+0x48]
       mov      edx, dword ptr [rcx+0x50]
       mov      r12d, dword ptr [rcx+0x38]
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x138], r8
       test     r14d, r14d
       jl       G_M000_IG120
 
G_M000_IG13:                ;; offset=0x01D3
       cmp      r14d, edx
       jae      G_M000_IG147
       mov      edx, r14d
       shl      rdx, 4
       add      rdx, rax
       mov      rax, gword ptr [rdx]
       mov      r10, 0x1AD1A001CE0
       cmp      rax, gword ptr [r10]
       je       G_M000_IG130
 
G_M000_IG14:                ;; offset=0x01FC
       mov      r10, 0x1AD1A001CE8
       cmp      rax, gword ptr [r10]
       je       G_M000_IG131
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG132
 
G_M000_IG15:                ;; offset=0x021A
       cmp      r14d, dword ptr [r15+0xD8]
       jge      SHORT G_M000_IG20
 
G_M000_IG16:                ;; offset=0x0223
       test     rax, rax
       je       SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x0228
       mov      rdx, 0x7FF9D77F4838
       cmp      qword ptr [rax], rdx
       jne      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0237
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
 
G_M000_IG19:                ;; offset=0x0240
       test     rax, rax
       je       G_M000_IG133
 
G_M000_IG20:                ;; offset=0x0249
       test     rax, rax
       je       G_M000_IG134
       mov      r12, rax
 
G_M000_IG21:                ;; offset=0x0255
       xor      rdx, rdx
       mov      gword ptr [rbp-0xC0], rdx
       mov      rax, r13
       test     rax, rax
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0266
       mov      r8, 0x7FF9D776AC10
       cmp      qword ptr [rax], r8
       jne      G_M000_IG135
 
G_M000_IG23:                ;; offset=0x0279
       test     rax, rax
       je       G_M000_IG140
       mov      rdx, gword ptr [rsi+0x18]
       mov      gword ptr [rbp-0x148], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x150], rdx
       mov      rcx, rax
       mov      rdx, r12
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:SelectNativeUnaryOperation(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,bool):System.Func`4[System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG140
 
G_M000_IG24:                ;; offset=0x02B7
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, gword ptr [rbp-0x148]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG25:                ;; offset=0x02D5
       mov      rcx, 0x7FF9D766BBD0
       cmp      qword ptr [r14+0x18], rcx
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x02E5
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.PyRendering:ToInterpolatedPyString(System.Object,Lokad.Lython.Runtime.PyRenderingContext):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0xD0], rax
       xor      edx, edx
       mov      qword ptr [rbp-0xC8], rdx
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0307
       mov      rdx, gword ptr [rbp-0x150]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xD0]
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x148]
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`4[System.__Canon,System.__Canon,System.__Canon,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Invoke(System.__Canon,System.__Canon,System.__Canon):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this
       nop      
 
G_M000_IG28:                ;; offset=0x032D
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [rdx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      rdx, rdx
       mov      gword ptr [rbp-0xD8], rdx
       mov      r13, gword ptr [rbp-0xD0]
       mov      rdi, qword ptr [rbp-0xC8]
       mov      r12, r13
       test     r12, r12
       je       SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0362
       mov      rdx, 0x7FF9D70947B0
       cmp      qword ptr [r12], rdx
       jne      G_M000_IG136
       xor      r12, r12
 
G_M000_IG30:                ;; offset=0x0379
       test     r12, r12
       jne      G_M000_IG137
       mov      gword ptr [rbp-0x128], r13
       mov      qword ptr [rbp-0x120], rdi
       lea      r8, [rbp-0x128]
       mov      rdx, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG31:                ;; offset=0x03A4
       mov      eax, 1
 
G_M000_IG32:                ;; offset=0x03A9
       vzeroupper 
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG33:                ;; offset=0x03C0
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG79
 
G_M000_IG34:                ;; offset=0x03CA
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG80
 
G_M000_IG35:                ;; offset=0x03D4
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG76
 
G_M000_IG36:                ;; offset=0x03DE
       mov      rax, 0x7FF9D76B4690
       cmp      qword ptr [r14], rax
       jne      G_M000_IG76
 
G_M000_IG37:                ;; offset=0x03F1
       mov      rax, rbx
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG111
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r15, gword ptr [rdx]
       mov      rax, 0x1AD1A001CE0
       cmp      r15, gword ptr [rax]
       je       G_M000_IG84
 
G_M000_IG38:                ;; offset=0x041C
       mov      rax, 0x1AD1A001CE8
       cmp      r15, gword ptr [rax]
       je       G_M000_IG85
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG86
 
G_M000_IG39:                ;; offset=0x043A
       cmp      dword ptr [rsi+0x28], 0
       jne      G_M000_IG62
       test     r15, r15
       je       G_M000_IG62
 
G_M000_IG40:                ;; offset=0x044D
       mov      rax, 0x7FF9D75C1030
       cmp      qword ptr [r15], rax
       jne      G_M000_IG62
 
G_M000_IG41:                ;; offset=0x0460
       mov      r13, r15
       mov      r12, gword ptr [rsi+0x20]
       test     r12, r12
       je       G_M000_IG62
 
G_M000_IG42:                ;; offset=0x0470
       mov      rax, 0x7FF9D76B31D0
       cmp      qword ptr [r12], rax
       jne      G_M000_IG62
 
G_M000_IG43:                ;; offset=0x0484
       cmp      r14, gword ptr [r12+0x08]
       jne      G_M000_IG62
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       add      edx, 2
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG111
       shl      rdx, 5
 
G_M000_IG44:                ;; offset=0x04B1
       vmovdqu  ymm0, ymmword ptr [rax+rdx+0x10]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG45:                ;; offset=0x04BC
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       cmp      dword ptr [rbp-0x64], 42
       jne      G_M000_IG87
       mov      edx, dword ptr [rbp-0x78]
       mov      r8, 0x7FF9D7648680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG89
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG88
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG46:                ;; offset=0x04F9
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rax, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG47:                ;; offset=0x0519
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x10]
       cmp      byte  ptr [rsi+0x31], 0
       jne      SHORT G_M000_IG50
       cmp      byte  ptr [rcx+0x40], 0
       je       SHORT G_M000_IG49
       movzx    r9, byte  ptr [rsi+0x32]
 
G_M000_IG48:                ;; offset=0x0532
       mov      rcx, r12
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
       jmp      SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x054A
       xor      r9d, r9d
       jmp      SHORT G_M000_IG48
 
G_M000_IG50:                ;; offset=0x054F
       mov      r9d, 1
       jmp      SHORT G_M000_IG48
 
G_M000_IG51:                ;; offset=0x0557
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x10]
       mov      r13, gword ptr [rsi+0x98]
       mov      rax, qword ptr [r13+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0572
       dec      rax
       mov      qword ptr [r13+0x160], rax
 
G_M000_IG53:                ;; offset=0x057C
       add      dword ptr [rcx+0x38], 2
 
G_M000_IG54:                ;; offset=0x0580
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG55:                ;; offset=0x058D
       cmp      dword ptr [rbp-0x68], 0
       jl       G_M000_IG92
 
G_M000_IG56:                ;; offset=0x0597
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, 51
       ja       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x059F
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG90
 
G_M000_IG58:                ;; offset=0x05B3
       mov      edi, dword ptr [rbp-0x6C]
 
G_M000_IG59:                ;; offset=0x05B6
       mov      edx, dword ptr [rbp-0x68]
       mov      r14d, edx
       not      r14d
       test     edx, edx
       cmovge   r14d, edx
       mov      r15, gword ptr [rbp-0x108]
       mov      rsi, qword ptr [rbp-0x100]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      r14d, dword ptr [rcx+0x3C]
       jl       G_M000_IG91
 
G_M000_IG60:                ;; offset=0x05E1
       cmp      edi, dword ptr [rbx+0x08]
       jae      G_M000_IG111
       mov      r13d, edi
       shl      r13, 4
       add      r13, bword ptr [rbx]
       mov      rcx, r13
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r13+0x08], rsi
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], r14d
 
G_M000_IG61:                ;; offset=0x060B
       mov      eax, 1
       jmp      G_M000_IG112
 
G_M000_IG62:                ;; offset=0x0615
       mov      rdx, gword ptr [rsi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x061E
       mov      rax, 0x7FF9D7803450
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG64:                ;; offset=0x0632
       mov      r13, rdx
       test     r13, r13
       je       G_M000_IG70
 
G_M000_IG65:                ;; offset=0x063E
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      eax, dword ptr [rcx+0x38]
       add      eax, 3
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG111
       shl      rax, 5
       cmp      dword ptr [rdx+rax+0x20], edi
       jne      G_M000_IG70
 
G_M000_IG66:                ;; offset=0x066A
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG67:                ;; offset=0x0676
       lea      rdx, [rbp-0x118]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xB0]
       mov      rcx, rsi
       mov      rdx, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG70
 
G_M000_IG68:                ;; offset=0x06BA
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      r14, gword ptr [rcx+0xB0]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [r12+0x38]
       add      edx, 3
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG111
       shl      rdx, 5
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      edx, 42
       mov      r8, 0x1CD40BDD5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, r14
       mov      r11, 0x7FF9D70A25F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, gword ptr [rbp-0x58]
       movzx    r8, byte  ptr [rbp-0x60]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rcx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x118], rcx
 
G_M000_IG69:                ;; offset=0x0731
       mov      dword ptr [rbp-0x110], ecx
       mov      rcx, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x118]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x48], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x40], rdx
       add      dword ptr [r12+0x38], 3
       jmp      G_M000_IG113
 
G_M000_IG70:                ;; offset=0x076B
       mov      rcx, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rcx+0x08]
 
G_M000_IG71:                ;; offset=0x0773
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG72:                ;; offset=0x077F
       lea      rdx, [rbp-0x118]
       lea      rcx, [rbp-0xA0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], rsi
       mov      dword ptr [rsp+0x28], edi
       mov      r12, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], r9
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x38], r9
       lea      r9, bword ptr [r12+0x38]
       lea      r8, [rbp-0xA0]
       mov      rcx, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG113
 
G_M000_IG73:                ;; offset=0x07D3
       mov      r8, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rdi+r9+0x01]
       mov      edx, dword ptr [rsi+0x28]
       mov      ecx, edx
       add      rcx, r9
       mov      eax, dword ptr [r8+0x08]
       cmp      rcx, rax
       ja       G_M000_IG82
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0x118], r9
       mov      dword ptr [rbp-0x110], edx
       mov      r8, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x118]
       mov      r9, gword ptr [rsi+0x18]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG78
 
G_M000_IG74:                ;; offset=0x0845
       mov      r8, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x48], r8
 
G_M000_IG75:                ;; offset=0x0850
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG113
 
G_M000_IG76:                ;; offset=0x085B
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG77:                ;; offset=0x0867
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x118]
       mov      rdx, r14
       mov      rcx, rsi
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG109
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG113
 
G_M000_IG78:                ;; offset=0x08C7
       xor      eax, eax
       jmp      G_M000_IG112
 
G_M000_IG79:                ;; offset=0x08CE
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG113
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x08F4
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG35
 
G_M000_IG81:                ;; offset=0x0905
       mov      rdx, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x092F
       mov      r12, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG83:                ;; offset=0x093A
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0x118], r8
       mov      dword ptr [rbp-0x110], r9d
       lea      rcx, [rbp-0x118]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r12, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r12+0x10]
       lea      r9, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG78
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x48], rax
       jmp      G_M000_IG75
 
G_M000_IG84:                ;; offset=0x0985
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG39
 
G_M000_IG85:                ;; offset=0x0996
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG39
 
G_M000_IG86:                ;; offset=0x09A7
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG39
 
G_M000_IG87:                ;; offset=0x09B8
       lea      rcx, [rbp-0x80]
       mov      rdx, 0x1CD40BDD5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG88:                ;; offset=0x09D5
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG89:                ;; offset=0x09DC
       mov      rcx, rax
       mov      r11, 0x7FF9D70A25F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG46
 
G_M000_IG90:                ;; offset=0x09F4
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG59
 
G_M000_IG91:                ;; offset=0x0A05
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG60
 
G_M000_IG92:                ;; offset=0x0A13
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x3C]
       jge      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A26
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG94:                ;; offset=0x0A3C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [rax+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG98
 
G_M000_IG95:                ;; offset=0x0A57
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ebx, eax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG96:                ;; offset=0x0A70
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG97:                ;; offset=0x0A80
       mov      edx, ebx
       lea      r9, [rbp-0x128]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG61
 
G_M000_IG98:                ;; offset=0x0A98
       mov      rsi, rbx
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG111
       mov      rcx, bword ptr [rsi]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], eax
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG111
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       cmp      dword ptr [rdx+0x1C], 25
       jne      SHORT G_M000_IG102
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       jne      SHORT G_M000_IG99
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG111
       mov      esi, eax
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rdx, gword ptr [rbp-0x108]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x100]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG108
 
G_M000_IG99:                ;; offset=0x0B3E
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
 
G_M000_IG100:                ;; offset=0x0B49
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG101:                ;; offset=0x0B59
       lea      r8, [rbp-0x128]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreCapturedLocal(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG108
 
G_M000_IG102:                ;; offset=0x0B6F
       cmp      dword ptr [rdx+0x1C], 71
       jne      SHORT G_M000_IG106
 
G_M000_IG103:                ;; offset=0x0B75
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG104:                ;; offset=0x0B81
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG105:                ;; offset=0x0B91
       lea      rcx, [rbp-0x118]
       lea      r8, [rbp-0x128]
       mov      rsi, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rsi+0x10]
       mov      r9, gword ptr [r9+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0BB6
       cmp      dword ptr [rdx+0x1C], 30
       je       SHORT G_M000_IG107
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BE2BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG107:                ;; offset=0x0BEA
       cmp      gword ptr [rbp-0x108], 0
       jne      SHORT G_M000_IG108
       lea      rcx, [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG108:                ;; offset=0x0C14
       mov      rsi, bword ptr [rbp+0x10]
       inc      dword ptr [rsi+0x38]
       jmp      G_M000_IG61
 
G_M000_IG109:                ;; offset=0x0C20
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG113
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9D70A25E8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG110:                ;; offset=0x0C65
       mov      gword ptr [r12+0x28], r14
       jmp      G_M000_IG78
 
G_M000_IG111:                ;; offset=0x0C6F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG112:                ;; offset=0x0C75
       vzeroupper 
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG113:                ;; offset=0x0C8C
       cmp      dword ptr [rsi+0x2C], 0
       je       G_M000_IG117
 
G_M000_IG114:                ;; offset=0x0C96
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r12+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG147
       shl      rax, 5
       cmp      dword ptr [rcx+rax+0x2C], 15
       jne      G_M000_IG117
 
G_M000_IG115:                ;; offset=0x0CC3
       mov      rcx, gword ptr [r12+0x10]
       mov      rax, gword ptr [r12+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [r12+0x38]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG147
       shl      rdx, 5
       mov      r14, gword ptr [rax+rdx+0x10]
       mov      r15, gword ptr [rcx+0x98]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG145
 
G_M000_IG116:                ;; offset=0x0D06
       mov      edx, edi
       add      edx, dword ptr [rsi+0x2C]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, rbx
       mov      eax, dword ptr [rsi+0x2C]
       mov      edx, edi
       mov      r8d, eax
       add      rdx, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rdx, r8
       ja       G_M000_IG146
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rbp-0x118], rdx
       mov      dword ptr [rbp-0x110], eax
       lea      rcx, [rbp-0x118]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      G_M000_IG31
 
G_M000_IG117:                ;; offset=0x0D57
       mov      r12, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r12+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [r12+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG147
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG118:                ;; offset=0x0D7F
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG119:                ;; offset=0x0D8C
       lea      r8, [rbp-0x128]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG31
 
G_M000_IG120:                ;; offset=0x0DA1
       mov      edx, r14d
       not      edx
       mov      r14, gword ptr [r15+0x30]
       cmp      dword ptr [r14+0x08], edx
       jg       G_M000_IG128
 
G_M000_IG121:                ;; offset=0x0DB4
       mov      r9, gword ptr [r15+0x38]
       mov      eax, edx
       sub      eax, dword ptr [r14+0x08]
       cmp      eax, dword ptr [r9+0x08]
       jae      G_M000_IG147
       mov      rax, gword ptr [r9+8*rax+0x10]
       mov      gword ptr [rbp-0x140], rax
       sub      edx, dword ptr [r14+0x08]
       lea      r9, [rbp-0xC0]
       mov      rcx, r15
       mov      r8, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG129
       mov      r12, gword ptr [rbp-0xC0]
       jmp      G_M000_IG21
 
G_M000_IG122:                ;; offset=0x0E03
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDD5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG123:                ;; offset=0x0E1F
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG124:                ;; offset=0x0E26
       mov      rcx, rax
       mov      r11, 0x7FF9D70A25E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG03
 
G_M000_IG125:                ;; offset=0x0E3E
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG06
 
G_M000_IG126:                ;; offset=0x0E4E
       cmp      edx, dword ptr [r13+0x08]
       jae      G_M000_IG147
       mov      eax, edx
       mov      rcx, gword ptr [r13+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG12
 
G_M000_IG127:                ;; offset=0x0E6D
       mov      rcx, r14
       mov      edx, r15d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG128:                ;; offset=0x0E91
       cmp      edx, dword ptr [r14+0x08]
       jae      G_M000_IG147
       mov      eax, edx
       mov      rcx, gword ptr [r14+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG21
 
G_M000_IG129:                ;; offset=0x0EB0
       mov      rcx, r15
       mov      edx, r12d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG130:                ;; offset=0x0EDB
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      G_M000_IG15
 
G_M000_IG131:                ;; offset=0x0EE9
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      G_M000_IG15
 
G_M000_IG132:                ;; offset=0x0EF7
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       jmp      G_M000_IG15
 
G_M000_IG133:                ;; offset=0x0F05
       mov      rcx, r15
       mov      edx, r12d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, r14d
       mov      rcx, r15
       mov      r9, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       jmp      G_M000_IG21
 
G_M000_IG134:                ;; offset=0x0F35
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG135:                ;; offset=0x0F63
       mov      rdx, r13
       mov      rcx, r8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG23
 
G_M000_IG136:                ;; offset=0x0F73
       mov      rdx, r13
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       jmp      G_M000_IG30
 
G_M000_IG137:                ;; offset=0x0F8D
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x08]
       mov      rcx, gword ptr [r11+0xA0]
       mov      r11, 0x7FF9D70A2600
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG138
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG138:                ;; offset=0x0FB6
       mov      rcx, bword ptr [rbp+0x10]
       mov      gword ptr [rcx+0x28], r12
       xor      eax, eax
 
G_M000_IG139:                ;; offset=0x0FC0
       vzeroupper 
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG140:                ;; offset=0x0FD7
       lea      rcx, [rbp-0xE8]
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r8d, [rdi+0x01]
       lea      r9, [rbp-0xE8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       lea      rcx, [rbp-0xF8]
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      edx, [rdi+0x01]
       lea      r8d, [rdi+0x02]
       lea      r9, [rbp-0xF8]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG07
 
G_M000_IG141:                ;; offset=0x102B
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG142:                ;; offset=0x103C
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG143:                ;; offset=0x104D
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG144:                ;; offset=0x105E
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rcx, r12
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG145:                ;; offset=0x108C
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG116
 
G_M000_IG146:                ;; offset=0x109D
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG147:                ;; offset=0x10A4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG148:                ;; offset=0x10AA
       sub      rsp, 72
 
G_M000_IG149:                ;; offset=0x10AE
       mov      r12, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r12+0x10]
       mov      r13, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [r13+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x10CA
       dec      rcx
       mov      qword ptr [r13+0x160], rcx
 
G_M000_IG151:                ;; offset=0x10D4
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG152:                ;; offset=0x10DC
       sub      rsp, 72
 
G_M000_IG153:                ;; offset=0x10E0
       mov      rdx, rcx
       mov      rcx, 0x7FF9D71A2168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x10FA
       xor      eax, eax
       jmp      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x10FE
       mov      rcx, gword ptr [rbp-0x130]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG156:                ;; offset=0x1126
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG157:                ;; offset=0x112E
       sub      rsp, 72
 
G_M000_IG158:                ;; offset=0x1132
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG159:                ;; offset=0x113F
       sub      rsp, 72
 
G_M000_IG160:                ;; offset=0x1143
       mov      rdx, rcx
       mov      rcx, 0x7FF9D71A2168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x115A
       xor      eax, eax
       jmp      SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x115E
       lea      r8, [rbp-0xD8]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG163:                ;; offset=0x117D
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG164:                ;; offset=0x1185
       sub      rsp, 72
 
G_M000_IG165:                ;; offset=0x1189
       mov      rcx, gword ptr [rbp-0xD8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG166:                ;; offset=0x1196
       sub      rsp, 72
 
G_M000_IG167:                ;; offset=0x119A
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [rdx+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG168:                ;; offset=0x11B1
       vzeroupper 
       add      rsp, 72
       ret      
 
; Total bytes of code 4537

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xBC0], xmm4
       mov      rax, -0xB70
 
G_M000_IG253:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG253
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x66C], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG234
 
G_M000_IG03:                ;; offset=0x009B
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG240
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x678], rax
       mov      rdx, gword ptr [rbp-0x678]
       mov      rcx, gword ptr [rbp-0x1C0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FE
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 72
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0117
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0133
       jmp      G_M000_IG220
 
G_M000_IG07:                ;; offset=0x0138
       mov      rcx, 0x7FF9D77FA980
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG08:                ;; offset=0x0156
       mov      rcx, 0x7FF9D77FA984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x680], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x680]
       mov      rdx, gword ptr [rbp-0x5F0]
       mov      r8d, dword ptr [rbp-0x5F4]
       mov      rcx, gword ptr [rbp-0x5E8]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x688], rax
       mov      r9, gword ptr [rbp-0x688]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG09:                ;; offset=0x01F3
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0243
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0x640], rax
       mov      rcx, gword ptr [rbp-0x640]
       mov      rdx, 0x7FF9D77FA988
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x690], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x694], eax
       mov      rcx, gword ptr [rbp-0x690]
       mov      edx, dword ptr [rbp-0x694]
       mov      r11, 0x7FF9D70A2910
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x220], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A0], rax
       mov      rdx, gword ptr [rbp-0x6A0]
       mov      rcx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EA
       mov      rcx, 0x7FF9D77FAA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG12:                ;; offset=0x02FE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5D4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x6A4], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x6A4]
       mov      rdx, gword ptr [rbp-0x5D0]
       mov      r8d, dword ptr [rbp-0x5D4]
       mov      rcx, gword ptr [rbp-0x5C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77FAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E0], rax
       mov      rax, bword ptr [rbp-0x5E0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG224
 
G_M000_IG13:                ;; offset=0x03C0
       mov      rcx, 0x7FF9D77FAA98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03CF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6B0], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6B0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77FAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG15:                ;; offset=0x0437
       mov      rcx, 0x7FF9D77FAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG16:                ;; offset=0x0461
       mov      rcx, 0x7FF9D77FAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG17:                ;; offset=0x048B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77FAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG18:                ;; offset=0x04BF
       mov      rcx, 0x7FF9D77FAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG19:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG20:                ;; offset=0x04E9
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6D0], ymm0
 
G_M000_IG22:                ;; offset=0x0501
       lea      r8, [rbp-0x6D0]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG23:                ;; offset=0x0544
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0548
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6F0], ymm0
 
G_M000_IG25:                ;; offset=0x0554
       lea      r8, [rbp-0x6F0]
       lea      rdx, [rbp-0x580]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0574
       vmovdqu  xmm0, xmmword ptr [rbp-0x580]
       vmovdqu  xmmword ptr [rbp-0x700], xmm0
 
G_M000_IG27:                ;; offset=0x0584
       lea      rdx, [rbp-0x700]
       lea      rcx, [rbp-0x590]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x590]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x588]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77FAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x708], rax
       mov      rcx, gword ptr [rbp-0x708]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG28:                ;; offset=0x0612
       mov      rcx, 0x7FF9D77FAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG29:                ;; offset=0x0630
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2E8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x2F8], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x300], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77FAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x300], rax
 
G_M000_IG30:                ;; offset=0x067D
       mov      rcx, bword ptr [rbp-0x2E8]
       mov      rdx, gword ptr [rbp-0x2F0]
       mov      r8, bword ptr [rbp-0x2F8]
       mov      r9, gword ptr [rbp-0x300]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77FAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG31:                ;; offset=0x06C8
       mov      rcx, 0x7FF9D77FAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG32:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77FAAC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x728], ymm0
 
G_M000_IG34:                ;; offset=0x0703
       lea      r8, [rbp-0x728]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG35:                ;; offset=0x0746
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074A
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x748], ymm0
 
G_M000_IG37:                ;; offset=0x0756
       lea      r8, [rbp-0x748]
       lea      rdx, [rbp-0x310]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0776
       vmovdqu  xmm0, xmmword ptr [rbp-0x310]
       vmovdqu  xmmword ptr [rbp-0x758], xmm0
 
G_M000_IG39:                ;; offset=0x0786
       lea      rdx, [rbp-0x758]
       lea      rcx, [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x320]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x318]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77FAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x760], rax
       mov      rcx, gword ptr [rbp-0x760]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG40:                ;; offset=0x0814
       mov      rcx, 0x7FF9D77FAACC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG41:                ;; offset=0x0832
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x268]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x768], rax
       mov      rdx, gword ptr [rbp-0x768]
       mov      rcx, 0x7FF9D759EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x270], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x280], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x280]
       sub      ecx, eax
       mov      dword ptr [rbp-0x76C], ecx
       mov      r9d, dword ptr [rbp-0x76C]
       lea      rcx, [rbp-0x290]
       mov      rdx, gword ptr [rbp-0x278]
       mov      r8d, dword ptr [rbp-0x27C]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x298], rax
 
G_M000_IG42:                ;; offset=0x0913
       vmovdqu  xmm0, xmmword ptr [rbp-0x290]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG43:                ;; offset=0x0923
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x2AC], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2B8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77FAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2B8], rax
 
G_M000_IG44:                ;; offset=0x095F
       mov      rcx, 0x7FF9D77FAAD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x096E
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x780], xmm0
 
G_M000_IG46:                ;; offset=0x097E
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x788], rax
       mov      rax, gword ptr [rbp-0x788]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x780]
       mov      r8d, dword ptr [rbp-0x2AC]
       mov      r9, gword ptr [rbp-0x2B8]
       mov      rcx, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x78C], eax
       mov      edx, dword ptr [rbp-0x78C]
       mov      rcx, bword ptr [rbp-0x2C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG224
 
G_M000_IG47:                ;; offset=0x09FA
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x228], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x22C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x790], eax
       mov      r9d, dword ptr [rbp-0x790]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x22C]
       mov      rcx, bword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x798], rax
       mov      rdx, gword ptr [rbp-0x798]
       lea      rcx, [rbp-0x240]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x248], rax
 
G_M000_IG48:                ;; offset=0x0A88
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x258], xmm0
 
G_M000_IG49:                ;; offset=0x0A95
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x260], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77FAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG50:                ;; offset=0x0AC1
       mov      rcx, 0x7FF9D77FAADC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD0
       vmovdqu  xmm0, xmmword ptr [rbp-0x240]
       vmovdqu  xmmword ptr [rbp-0x7A8], xmm0
 
G_M000_IG52:                ;; offset=0x0AE0
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x7B8], xmm0
 
G_M000_IG53:                ;; offset=0x0AF0
       mov      rcx, gword ptr [rbp-0x260]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7C0], rax
       mov      r9, gword ptr [rbp-0x7C0]
       lea      r8, [rbp-0x7B8]
       lea      rcx, [rbp-0x7A8]
       mov      rdx, bword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG224
 
G_M000_IG54:                ;; offset=0x0B2D
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77FAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG55:                ;; offset=0x0B76
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77FAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG56:                ;; offset=0x0BB0
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7D0], xmm0
 
G_M000_IG57:                ;; offset=0x0BBD
       lea      rdx, [rbp-0x7D0]
       lea      rcx, [rbp-0x5A0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x5A0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x598]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77FAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7D8], rax
       mov      rcx, gword ptr [rbp-0x7D8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG58:                ;; offset=0x0C4B
       mov      rcx, 0x7FF9D77FAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG59:                ;; offset=0x0C69
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77FAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG60:                ;; offset=0x0C8E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x370], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7DC], eax
       mov      r9d, dword ptr [rbp-0x7DC]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x374]
       mov      rcx, bword ptr [rbp-0x370]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77FAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x378], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7D
       mov      rcx, 0x7FF9D77FAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D8E
       mov      rcx, 0x7FF9D77FAAFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9D
       xor      eax, eax
       mov      dword ptr [rbp-0x378], eax
 
G_M000_IG64:                ;; offset=0x0DA5
       movzx    rax, byte  ptr [rbp-0x378]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCD
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7F0], xmm0
 
G_M000_IG66:                ;; offset=0x0DDD
       lea      r8, [rbp-0x7F0]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7F8], rax
       mov      rdx, gword ptr [rbp-0x7F8]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rax, gword ptr [rbp-0x388]
       mov      gword ptr [rbp-0x390], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x3A0], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E93
       mov      rcx, 0x7FF9D77FAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA7
       mov      rcx, 0x7FF9D77FAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBB
       mov      rcx, 0x7FF9D77FAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x3A0], rax
 
G_M000_IG70:                ;; offset=0x0EF6
       mov      rcx, 0x7FF9D77FAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x398]
       mov      rdx, gword ptr [rbp-0x3A0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG223
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x7FC], eax
       mov      edx, dword ptr [rbp-0x7FC]
       mov      rcx, bword ptr [rbp-0x3A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x3B0], rax
       mov      rax, bword ptr [rbp-0x3B0]
       add      dword ptr [rax], 2
       jmp      G_M000_IG234
 
G_M000_IG71:                ;; offset=0x0F94
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x810], xmm0
 
G_M000_IG72:                ;; offset=0x0FA4
       lea      rdx, [rbp-0x810]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x380], rax
       mov      rax, bword ptr [rbp-0x380]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77FAB10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG73:                ;; offset=0x102F
       mov      rcx, 0x7FF9D77FAB14
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1040
       mov      rcx, 0x7FF9D77FAB18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x104F
       mov      rcx, 0x7FF9D77FAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG76:                ;; offset=0x106D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77FAB20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG77:                ;; offset=0x1092
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A2
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x830], ymm0
 
G_M000_IG79:                ;; offset=0x10AE
       lea      r8, [rbp-0x830]
       lea      rdx, [rbp-0x368]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x368]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x360]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77FAB24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x838], rax
       mov      rcx, gword ptr [rbp-0x838]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG80:                ;; offset=0x1142
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1151
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77FAB28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x338], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x33C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x83C], eax
       mov      r8d, dword ptr [rbp-0x83C]
       mov      edx, dword ptr [rbp-0x33C]
       mov      rcx, bword ptr [rbp-0x338]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x348], rax
       mov      rcx, gword ptr [rbp-0x348]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x848], rax
       mov      rdx, gword ptr [rbp-0x848]
       mov      rcx, gword ptr [rbp-0x348]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x350], rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x850], rax
       mov      r9, gword ptr [rbp-0x850]
       mov      rdx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x358]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x358]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x127F
       mov      rcx, 0x7FF9D77FAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x330]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B5
       vmovdqu  xmm0, xmmword ptr [rbp-0x330]
       vmovdqu  xmmword ptr [rbp-0x860], xmm0
 
G_M000_IG84:                ;; offset=0x12C5
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12C9
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x880], ymm0
 
G_M000_IG86:                ;; offset=0x12D5
       lea      rdx, [rbp-0x860]
       lea      r8, [rbp-0x880]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12EF
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77FAB30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG234
 
G_M000_IG88:                ;; offset=0x1343
       mov      rcx, 0x7FF9D77FAB34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1354
       mov      rcx, 0x7FF9D77FAB38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG90:                ;; offset=0x1368
       mov      rcx, 0x7FF9D77FAB3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG91:                ;; offset=0x1386
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77FAB40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG92:                ;; offset=0x13AB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77FAB48
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x888], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x88C], eax
       mov      rcx, gword ptr [rbp-0x888]
       mov      edx, dword ptr [rbp-0x88C]
       mov      r11, 0x7FF9D70A2920
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77FAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG224
 
G_M000_IG93:                ;; offset=0x1460
       lea      rcx, [rbp-0x618]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x1478
       vmovdqu  xmm0, xmmword ptr [rbp-0x618]
       vmovdqu  xmmword ptr [rbp-0x8A0], xmm0
 
G_M000_IG95:                ;; offset=0x1488
       lea      rdx, [rbp-0x8A0]
       lea      rcx, [rbp-0x628]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x628]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x620]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77FAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8A8], rax
       mov      rcx, gword ptr [rbp-0x8A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG96:                ;; offset=0x1516
       mov      rcx, 0x7FF9D77FAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG97:                ;; offset=0x1534
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77FAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG98:                ;; offset=0x1573
       mov      rcx, 0x7FF9D77FAC60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG99:                ;; offset=0x1587
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77FAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG224
 
G_M000_IG100:                ;; offset=0x15B9
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15BD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8C8], ymm0
 
G_M000_IG102:                ;; offset=0x15C9
       lea      r8, [rbp-0x8C8]
       lea      rdx, [rbp-0x570]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x570]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x568]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77FAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D0], rax
       mov      rcx, gword ptr [rbp-0x8D0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG103:                ;; offset=0x165D
       mov      rcx, 0x7FF9D77FAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG104:                ;; offset=0x167B
       mov      rcx, 0x7FF9D77FAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x600], rax
       mov      rax, gword ptr [rbp-0x600]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8D8], rax
       mov      r9, gword ptr [rbp-0x8D8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG105:                ;; offset=0x16FD
       mov      rcx, 0x7FF9D77FAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5BC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r8, gword ptr [rbp-0x8E0]
       mov      edx, dword ptr [rbp-0x5BC]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8E8], rax
       mov      r9, gword ptr [rbp-0x8E8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG106:                ;; offset=0x177E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77FAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG107:                ;; offset=0x17A3
       mov      rcx, 0x7FF9D77FAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5A8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5A8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F0], rax
       mov      rdx, gword ptr [rbp-0x8F0]
       mov      rcx, gword ptr [rbp-0x5B0]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F8], rax
       mov      r9, gword ptr [rbp-0x8F8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG108:                ;; offset=0x1841
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77FAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG109:                ;; offset=0x1866
       mov      rcx, 0x7FF9D77FAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x900], rax
       mov      rdx, gword ptr [rbp-0x900]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG110:                ;; offset=0x189C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77FAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG111:                ;; offset=0x18C1
       mov      rcx, 0x7FF9D77FAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x540]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x548], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x550], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x904], eax
       mov      r8d, dword ptr [rbp-0x904]
       mov      edx, dword ptr [rbp-0x554]
       mov      rcx, bword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x910], rax
       mov      r9, gword ptr [rbp-0x910]
       mov      rdx, gword ptr [rbp-0x560]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x548]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG112:                ;; offset=0x199C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77FAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG113:                ;; offset=0x19C1
       mov      rcx, 0x7FF9D77FAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x508], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x518], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x518]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG223
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x520], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x528], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x52C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x914], eax
       mov      r8d, dword ptr [rbp-0x914]
       mov      edx, dword ptr [rbp-0x52C]
       mov      rcx, bword ptr [rbp-0x528]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x538], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x920], rax
       mov      rax, gword ptr [rbp-0x920]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      r8, gword ptr [rbp-0x520]
       mov      r9, gword ptr [rbp-0x538]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG224
 
G_M000_IG114:                ;; offset=0x1AD1
       mov      rcx, 0x7FF9D77FAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4F4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F8], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x500], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x924], eax
       mov      edx, dword ptr [rbp-0x924]
       mov      rcx, bword ptr [rbp-0x500]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x930], rax
       mov      r9, gword ptr [rbp-0x930]
       mov      edx, dword ptr [rbp-0x4F4]
       mov      r8d, dword ptr [rbp-0x4F8]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG224
 
G_M000_IG115:                ;; offset=0x1B7C
       mov      rcx, 0x7FF9D77FAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x934], eax
       mov      edx, dword ptr [rbp-0x934]
       mov      rcx, bword ptr [rbp-0x4E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x938], eax
       mov      edx, dword ptr [rbp-0x938]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG224
 
G_M000_IG116:                ;; offset=0x1C00
       mov      rcx, 0x7FF9D77FACA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4D4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x940], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x940]
       mov      edx, dword ptr [rbp-0x4D4]
       mov      r8d, dword ptr [rbp-0x4D8]
       mov      rcx, bword ptr [rbp-0x4D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x948], rax
       mov      r9, gword ptr [rbp-0x948]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG117:                ;; offset=0x1CA4
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77FACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG118:                ;; offset=0x1CDD
       mov      rcx, 0x7FF9D77FACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CEC
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77FACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D27
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x958], xmm0
 
G_M000_IG121:                ;; offset=0x1D33
       lea      r9, [rbp-0x958]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG238
 
G_M000_IG122:                ;; offset=0x1D5B
       mov      rcx, 0x7FF9D77FACB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6A
       mov      rcx, 0x7FF9D77FACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x960], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x960]
       mov      edx, dword ptr [rbp-0x4C4]
       mov      r8d, dword ptr [rbp-0x4C8]
       mov      rcx, bword ptr [rbp-0x4C0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x968], rax
       mov      r9, gword ptr [rbp-0x968]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG224
 
G_M000_IG124:                ;; offset=0x1E0E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77FACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG125:                ;; offset=0x1E33
       mov      rcx, 0x7FF9D77FACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG126:                ;; offset=0x1E5A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77FACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG127:                ;; offset=0x1E7F
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77FACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG128:                ;; offset=0x1EAE
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB2
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x988], ymm0
 
G_M000_IG130:                ;; offset=0x1EBE
       lea      r8, [rbp-0x988]
       lea      rdx, [rbp-0x4B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x4B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x4B0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77FACC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x990], rax
       mov      rcx, gword ptr [rbp-0x990]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG131:                ;; offset=0x1F52
       mov      rcx, 0x7FF9D77FACCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG132:                ;; offset=0x1F73
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77FACD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG133:                ;; offset=0x1FD2
       mov      rcx, 0x7FF9D77FACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG134:                ;; offset=0x1FF3
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77FACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG135:                ;; offset=0x2021
       mov      rcx, 0x7FF9D77FACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2032
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2050
       mov      rcx, 0x7FF9D77FACE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x205F
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77FACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG139:                ;; offset=0x20C7
       mov      rcx, 0x7FF9D77FACE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG140:                ;; offset=0x20DB
       mov      rcx, 0x7FF9D77FACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG141:                ;; offset=0x20EF
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77FACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG142:                ;; offset=0x2124
       mov      rcx, 0x7FF9D77FACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x2138
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2C4]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rax, gword ptr [rbp-0x2D0]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG223
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rdx, gword ptr [rbp-0x998]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2245
       lea      rdx, [rbp-0x2E0]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x2E0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x2D8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77FACF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A0], rax
       mov      rcx, gword ptr [rbp-0x9A0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG145:                ;; offset=0x22E4
       mov      rcx, 0x7FF9D77FACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F5
       mov      rcx, 0x7FF9D77FAD00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2306
       mov      rcx, 0x7FF9D77FAD04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x2317
       mov      rcx, 0x7FF9D77FAD08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x2328
       mov      rcx, 0x7FF9D77FAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x2339
       mov      rcx, 0x7FF9D77FAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG151:                ;; offset=0x235A
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x458], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9A4], eax
       mov      edx, dword ptr [rbp-0x9A4]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x458]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77FAD14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C2
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9B8], xmm0
 
G_M000_IG153:                ;; offset=0x23D2
       lea      r9, [rbp-0x9B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG154:                ;; offset=0x23F0
       mov      rcx, 0x7FF9D77FAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x470], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9BC], eax
       mov      edx, dword ptr [rbp-0x9BC]
       mov      rcx, bword ptr [rbp-0x470]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG155:                ;; offset=0x2454
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77FAD1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG156:                ;; offset=0x2479
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77FAD20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG157:                ;; offset=0x24A8
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24AC
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9E0], ymm0
 
G_M000_IG159:                ;; offset=0x24B8
       lea      r8, [rbp-0x9E0]
       lea      rdx, [rbp-0x468]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rdx, gword ptr [rbp-0x468]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB78]
       mov      rcx, qword ptr [rbp-0x460]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77FAD24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9E8], rax
       mov      rcx, gword ptr [rbp-0x9E8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG160:                ;; offset=0x254C
       mov      rcx, 0x7FF9D77FAD28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG161:                ;; offset=0x256D
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x3F8], rax
       mov      rax, gword ptr [rbp-0x3F8]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77FAD30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x9F4], eax
       mov      rcx, gword ptr [rbp-0x9F0]
       mov      edx, dword ptr [rbp-0x9F4]
       mov      r11, 0x7FF9D70A2918
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       test     eax, eax
       jge      G_M000_IG169
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0xC4]
       jne      G_M000_IG164
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9F8], eax
       mov      edx, dword ptr [rbp-0x9F8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x148], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x9FC], eax
       mov      edx, dword ptr [rbp-0x9FC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x150], rax
       mov      rax, gword ptr [rbp-0x148]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77FAE38
 
G_M000_IG162:                ;; offset=0x26A6
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA08], rax
       mov      rdx, gword ptr [rbp-0xA08]
       mov      rcx, 0x7FF9D776AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x158], rax
       cmp      gword ptr [rbp-0x158], 0
       je       G_M000_IG168
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA10], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x168]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0xA10]
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, gword ptr [rbp-0x158]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG163
       lea      rcx, [rbp-0x168]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77FAF40
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA18], rax
       mov      rdx, gword ptr [rbp-0xA18]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x170], rax
       cmp      gword ptr [rbp-0x170], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77FB048
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x170]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG163:                ;; offset=0x27BA
       mov      rcx, 0x7FF9D77FB04C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG168
 
G_M000_IG164:                ;; offset=0x27CB
       mov      rcx, 0x7FF9D77FB050
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG169
 
G_M000_IG165:                ;; offset=0x27DF
       mov      rcx, 0x7FF9D77FB054
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x27EE
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0xA28], xmm0
 
G_M000_IG167:                ;; offset=0x27FE
       lea      r9, [rbp-0xA28]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG224
 
G_M000_IG168:                ;; offset=0x281C
       mov      rcx, 0x7FF9D77FB058
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xC4]
       lea      r8d, [rax+0x01]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0x148]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0xC4]
       lea      r8d, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      eax, dword ptr [rbp-0xC4]
       lea      edx, [rax+0x01]
       mov      r9, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
 
G_M000_IG169:                ;; offset=0x2884
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x400], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA2C], eax
       mov      edx, dword ptr [rbp-0xA2C]
       mov      rcx, bword ptr [rbp-0x400]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG172
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG170
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x668], rax
       mov      rcx, gword ptr [rbp-0x668]
       mov      rdx, 0x7FF9D77FB060
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x668]
       mov      gword ptr [rbp-0xA38], rax
       mov      rdx, gword ptr [rbp-0xA38]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x178], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG231
 
G_M000_IG170:                ;; offset=0x2984
       mov      rcx, 0x7FF9D77FB168
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG171:                ;; offset=0x2998
       mov      rcx, 0x7FF9D77FB16C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x450], xmm0
       vmovdqu  xmmword ptr [rbp-0x448], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76B9D18
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0xA40], rax
       mov      r8, gword ptr [rbp-0xA40]
       lea      rcx, [rbp-0x450]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x450]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG172:                ;; offset=0x2A50
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG175
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x180]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG173
       mov      rcx, 0x7FF9D77FB170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG173:                ;; offset=0x2AB1
       cmp      gword ptr [rbp-0x180], 0
       je       G_M000_IG174
       mov      rcx, 0x7FF9D77FB174
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       vmovdqu  xmmword ptr [rbp-0x430], xmm0
       lea      rcx, [rbp-0x438]
       mov      r8, gword ptr [rbp-0x180]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rax, bword ptr [rbp-0xB88]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x438]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG174:                ;; offset=0x2B5A
       mov      rcx, 0x7FF9D77FB178
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG175:                ;; offset=0x2B6E
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG179
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG177
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77F6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x2BDA
       mov      rcx, 0x7FF9D77FB17C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG177:                ;; offset=0x2BE9
       mov      rcx, 0x7FF9D77FB180
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG238
 
G_M000_IG178:                ;; offset=0x2C22
       mov      rcx, 0x7FF9D77FB184
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG179:                ;; offset=0x2C4E
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG180
       mov      rcx, 0x7FF9D77FB188
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG224
 
G_M000_IG180:                ;; offset=0x2CBE
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x410]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG181:                ;; offset=0x2CF3
       vmovdqu  xmm0, xmmword ptr [rbp-0x410]
       vmovdqu  xmmword ptr [rbp-0xA50], xmm0
 
G_M000_IG182:                ;; offset=0x2D03
       lea      rdx, [rbp-0xA50]
       lea      rcx, [rbp-0x420]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x420]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x418]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG183
       mov      rcx, 0x7FF9D77FB18C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA58], rax
       mov      rcx, gword ptr [rbp-0xA58]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG183:                ;; offset=0x2D91
       mov      rcx, 0x7FF9D77FB190
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG184:                ;; offset=0x2DAF
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA5C], eax
       mov      edx, dword ptr [rbp-0xA5C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x484], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x488], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA68], rax
       mov      rax, gword ptr [rbp-0xA68]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x480]
       mov      r8d, dword ptr [rbp-0x484]
       mov      r9d, dword ptr [rbp-0x488]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG185
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG186
       mov      rcx, 0x7FF9D77FB194
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG185:                ;; offset=0x2E7A
       mov      rcx, 0x7FF9D77FB198
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG186:                ;; offset=0x2E8E
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77FB19C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG187:                ;; offset=0x2EBA
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG188:                ;; offset=0x2EBE
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG189:                ;; offset=0x2ECA
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x498]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG190:                ;; offset=0x2EE4
       vmovdqu  xmm0, xmmword ptr [rbp-0x498]
       vmovdqu  xmmword ptr [rbp-0xA98], xmm0
 
G_M000_IG191:                ;; offset=0x2EF4
       lea      rdx, [rbp-0xA98]
       lea      rcx, [rbp-0x4A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x4A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x4A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG192
       mov      rcx, 0x7FF9D77FB1A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rcx, gword ptr [rbp-0xAA0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG192:                ;; offset=0x2F82
       mov      rcx, 0x7FF9D77FB1A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG193:                ;; offset=0x2FA0
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG194
       mov      rcx, 0x7FF9D77FB1A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG194:                ;; offset=0x2FC5
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77FB1AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG195:                ;; offset=0x2FF1
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG196:                ;; offset=0x2FF5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAC0], ymm0
 
G_M000_IG197:                ;; offset=0x3001
       lea      r8, [rbp-0xAC0]
       lea      rdx, [rbp-0x3E0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG198:                ;; offset=0x301B
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E0]
       vmovdqu  xmmword ptr [rbp-0xAD0], xmm0
 
G_M000_IG199:                ;; offset=0x302B
       lea      rdx, [rbp-0xAD0]
       lea      rcx, [rbp-0x3F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3F0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3E8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG200
       mov      rcx, 0x7FF9D77FB1B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD8], rax
       mov      rcx, gword ptr [rbp-0xAD8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG200:                ;; offset=0x30B9
       mov      rcx, 0x7FF9D77FB1B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG224
 
G_M000_IG201:                ;; offset=0x30D7
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG202
       mov      rcx, 0x7FF9D77FB1B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG202:                ;; offset=0x30FC
       mov      rcx, 0x7FF9D77FB1BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG224
 
G_M000_IG203:                ;; offset=0x3120
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xADC], eax
       mov      edx, dword ptr [rbp-0xADC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG205
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG204
       mov      rcx, 0x7FF9D77FB1C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG204:                ;; offset=0x3184
       mov      rcx, 0x7FF9D77FB1C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG205:                ;; offset=0x3193
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG207
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77F9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG208
 
G_M000_IG206:                ;; offset=0x31B6
       mov      rcx, 0x7FF9D77FB1C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG207:                ;; offset=0x31C5
       mov      rcx, 0x7FF9D77FB1CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG208:                ;; offset=0x31F2
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG209:                ;; offset=0x31F6
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xB00], ymm0
 
G_M000_IG210:                ;; offset=0x3202
       lea      r8, [rbp-0xB00]
       lea      rdx, [rbp-0x3C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG211
       mov      rcx, 0x7FF9D77FB1D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB08], rax
       mov      rcx, gword ptr [rbp-0xB08]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG238
 
G_M000_IG211:                ;; offset=0x3296
       mov      rcx, 0x7FF9D77FB1D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG224
 
G_M000_IG212:                ;; offset=0x32B7
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG216
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x184], eax
       cmp      dword ptr [rbp-0x184], 49
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x184], 57
       je       SHORT G_M000_IG214
       cmp      dword ptr [rbp-0x184], 58
       je       SHORT G_M000_IG213
       mov      rcx, 0x7FF9D77FB1D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG238
 
G_M000_IG213:                ;; offset=0x3307
       mov      rcx, 0x7FF9D77FB1DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG214:                ;; offset=0x3318
       mov      rcx, 0x7FF9D77FB1E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x3329
       mov      rcx, 0x7FF9D77FB1E4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG216:                ;; offset=0x3338
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG218
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG219
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG217
       mov      rcx, 0x7FF9D77FB1E8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
       lea      rcx, [rbp-0x3D0]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x3D0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x3C8]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG238
 
G_M000_IG217:                ;; offset=0x33FB
       mov      rcx, 0x7FF9D77FB1EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x340C
       mov      rcx, 0x7FF9D77FB1F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG224
 
G_M000_IG219:                ;; offset=0x3420
       mov      rcx, 0x7FF9D77FB1F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG238
 
G_M000_IG220:                ;; offset=0x343E
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1E8], ymm0
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
       lea      rcx, [rbp-0x1E8]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG221:                ;; offset=0x346A
       vmovdqu  ymm0, ymmword ptr [rbp-0x1E8]
       vmovdqu  ymmword ptr [rbp-0x1B0], ymm0
       mov      rax, qword ptr [rbp-0x1C8]
       mov      qword ptr [rbp-0x190], rax
 
G_M000_IG222:                ;; offset=0x3488
       lea      rcx, [rbp-0x1B0]
       mov      rdx, 0x1CD40BE2A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB0C], eax
       mov      edx, dword ptr [rbp-0xB0C]
       lea      rcx, [rbp-0x1B0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F0], rax
       lea      rcx, [rbp-0x1B0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      rdx, gword ptr [rbp-0xB18]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1F0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x350D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG224:                ;; offset=0x3513
       mov      eax, dword ptr [rbp-0x66C]
       dec      eax
       mov      dword ptr [rbp-0x66C], eax
       cmp      dword ptr [rbp-0x66C], 0
       jg       SHORT G_M000_IG226
 
G_M000_IG225:                ;; offset=0x352A
       lea      rcx, [rbp-0x66C]
       mov      edx, 0x102B
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG226:                ;; offset=0x353D
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG229
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG228
       mov      rcx, 0x7FF9D77FB204
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x210]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0xBB8]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB8]
       mov      rcx, qword ptr [rbp-0x208]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG227:                ;; offset=0x35B5
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG228:                ;; offset=0x35C1
       mov      rcx, 0x7FF9D77FB208
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG229:                ;; offset=0x35D0
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG230
       mov      rcx, 0x7FF9D77FB20C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x200]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG234
 
G_M000_IG230:                ;; offset=0x3605
       mov      rcx, 0x7FF9D77FB210
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG234
 
G_M000_IG231:                ;; offset=0x3616
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB30], rax
       mov      r9, gword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x3644
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG233:                ;; offset=0x364E
       mov      rcx, 0x7FF9D77FB214
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG224
 
G_M000_IG234:                ;; offset=0x3669
       mov      eax, dword ptr [rbp-0x66C]
       dec      eax
       mov      dword ptr [rbp-0x66C], eax
       cmp      dword ptr [rbp-0x66C], 0
       jg       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x3680
       lea      rcx, [rbp-0x66C]
       mov      edx, 0x1070
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG236:                ;; offset=0x3693
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77FB218
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG237:                ;; offset=0x36BB
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG238:                ;; offset=0x36C7
       mov      rcx, 0x7FF9D77FB21C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG239:                ;; offset=0x36DC
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG240:                ;; offset=0x36E8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG241:                ;; offset=0x36EE
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x36F2
       mov      gword ptr [rbp-0x638], rcx
       mov      rax, gword ptr [rbp-0x638]
       mov      gword ptr [rbp-0x1B8], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x370E
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG244:                ;; offset=0x3714
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r8, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG246
       mov      rcx, 0x7FF9D77FB1F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG238
 
G_M000_IG245:                ;; offset=0x3763
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG246:                ;; offset=0x376B
       mov      rcx, 0x7FF9D77FB1FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG247:                ;; offset=0x3788
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG248:                ;; offset=0x3790
       sub      rsp, 72
 
G_M000_IG249:                ;; offset=0x3794
       mov      gword ptr [rbp-0x630], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x37CC
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG251:                ;; offset=0x37D2
       mov      rcx, 0x7FF9D77FB200
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG224
 
G_M000_IG252:                ;; offset=0x37EF
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001334h ; case G_M000_IG91
       	dd	00001629h ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ABh ; case G_M000_IG105
       	dd	0000172Ch ; case G_M000_IG106
       	dd	00000ADBh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Dh ; case G_M000_IG138
       	dd	0000200Dh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E2h ; case G_M000_IG97
       	dd	000014E2h ; case G_M000_IG97
       	dd	000017EFh ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ah ; case G_M000_IG110
       	dd	0000194Ah ; case G_M000_IG112
       	dd	00001A7Fh ; case G_M000_IG114
       	dd	00001B2Ah ; case G_M000_IG115
       	dd	00001BAEh ; case G_M000_IG116
       	dd	00001C52h ; case G_M000_IG117
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00002D5Dh ; case G_M000_IG184
       	dd	00002308h ; case G_M000_IG151
       	dd	0000251Bh ; case G_M000_IG161
       	dd	00001FE0h ; case G_M000_IG136
       	dd	00002F4Eh ; case G_M000_IG193
       	dd	00003085h ; case G_M000_IG201
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00003265h ; case G_M000_IG212
       	dd	000030CEh ; case G_M000_IG203
       	dd	00001F21h ; case G_M000_IG132
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	00003265h ; case G_M000_IG212
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C17h ; case G_M000_IG59
       	dd	0000101Bh ; case G_M000_IG76
       	dd	00003265h ; case G_M000_IG212
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Dh ; case G_M000_IG141
       	dd	000020E6h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A8h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09

; Total bytes of code 14327

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x102b
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 256
; 129 inlinees with PGO data; 377 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 832
       mov      qword ptr [rsp+0xF48], r15
       mov      qword ptr [rsp+0xF40], r14
       mov      qword ptr [rsp+0xF38], r13
       mov      qword ptr [rsp+0xF30], r12
       mov      qword ptr [rsp+0xF28], rdi
       mov      qword ptr [rsp+0xF20], rsi
       mov      qword ptr [rsp+0xF18], rbx
       lea      rbp, [rsp+0x340]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x2C0], xmm4
       mov      rax, -624
 
G_M000_IG574:                ;; offset=0x0063
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG574
       mov      qword ptr [rbp-0x40], rax
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x0085
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG552
 
G_M000_IG03:                ;; offset=0x0092
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x009B
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00A5
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rax, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [rax+0x08]
       cmp      edx, ebx
       jge      G_M000_IG558
 
G_M000_IG06:                ;; offset=0x00C1
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG560
       mov      rax, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      rax, gword ptr [rax]
       mov      r8, gword ptr [rdx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG551
       mov      r8, gword ptr [rdx+0x180]
       test     r8, r8
       jne      G_M000_IG550
 
G_M000_IG07:                ;; offset=0x0125
       mov      r8, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [r8+0x1C]
       cmp      esi, 72
       ja       G_M000_IG285
       mov      r8d, esi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG08:                ;; offset=0x0153
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      edx, esi
       cmp      edx, 2
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0168
       cmp      edx, 25
       jne      G_M000_IG288
 
G_M000_IG10:                ;; offset=0x0171
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14, gword ptr [rax]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       shl      rax, 4
       lea      rax, bword ptr [rdi+rax+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG290
 
G_M000_IG11:                ;; offset=0x01AF
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG291
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG292
 
G_M000_IG12:                ;; offset=0x01CD
       test     rdx, rdx
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x01D2
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rdx], rax
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01E1
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01EC
       mov      rax, rdx
 
G_M000_IG16:                ;; offset=0x01EF
       test     rax, rax
       je       G_M000_IG293
 
G_M000_IG17:                ;; offset=0x01F8
       mov      rbx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG44
 
G_M000_IG18:                ;; offset=0x020C
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0226
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG294
 
G_M000_IG20:                ;; offset=0x023A
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG21:                ;; offset=0x0244
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       G_M000_IG30
 
G_M000_IG22:                ;; offset=0x0258
       cmp      r14d, dword ptr [rsi+0x40]
       jge      G_M000_IG29
 
G_M000_IG23:                ;; offset=0x0262
       mov      r15d, dword ptr [rsi+0x40]
       dec      r15d
       mov      r13d, dword ptr [rsi+0x3C]
       cmp      r15d, r13d
       jle      G_M000_IG31
 
G_M000_IG24:                ;; offset=0x0276
       cmp      r13d, r14d
       jge      G_M000_IG35
 
G_M000_IG25:                ;; offset=0x027F
       mov      rdx, gword ptr [rsi]
       mov      eax, dword ptr [rsi+0x40]
       sub      eax, r14d
       test     rdx, rdx
       je       G_M000_IG306
       lea      r8, bword ptr [rdx+0x10]
       xor      r10d, r10d
       mov      r11, qword ptr [rdx]
       cmp      dword ptr [r11+0x04], 24
       jne      G_M000_IG307
 
G_M000_IG26:                ;; offset=0x02A6
       mov      r15d, r14d
       sub      r15d, r10d
       cmp      r14d, r10d
       jl       G_M000_IG43
 
G_M000_IG27:                ;; offset=0x02B5
       mov      r10d, r15d
       or       r10d, eax
       jl       G_M000_IG43
       lea      r10d, [r15+rax]
       cmp      r10d, dword ptr [rdx+0x08]
       ja       G_M000_IG43
       movzx    rdx, word  ptr [r11]
       mov      r10d, r15d
       imul     r10, rdx
       add      r10, r8
       mov      eax, eax
       imul     rdx, rax
       test     dword ptr [r11], 0x1000000
       je       G_M000_IG308
       shr      rdx, 3
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG28:                ;; offset=0x02FD
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG29:                ;; offset=0x0301
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], r14d
       jmp      G_M000_IG02
 
G_M000_IG30:                ;; offset=0x0332
       not      r14d
       jmp      G_M000_IG22
 
G_M000_IG31:                ;; offset=0x033A
       mov      r13d, r15d
       jmp      G_M000_IG24
 
G_M000_IG32:                ;; offset=0x0342
       cmp      qword ptr [r15+0x08], -1
       je       G_M000_IG302
 
G_M000_IG33:                ;; offset=0x034D
       cmp      qword ptr [r15+0x08], -2
       je       G_M000_IG305
 
G_M000_IG34:                ;; offset=0x0358
       dec      r13d
       cmp      r13d, r14d
       jl       G_M000_IG25
 
G_M000_IG35:                ;; offset=0x0364
       cmp      byte  ptr [rsi+0x44], 0
       jne      G_M000_IG295
 
G_M000_IG36:                ;; offset=0x036E
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, r13d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r12, gword ptr [rdx+0x88]
       mov      rdx, gword ptr [r15]
       mov      rcx, 0x7FF9D77DE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG32
 
G_M000_IG37:                ;; offset=0x03A9
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       mov      rcx, 0x7FF9D7848AB0
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG301
       mov      rcx, gword ptr [rax+0x08]
       cmp      byte  ptr [rcx], cl
       cmp      byte  ptr [rax+0x38], 0
       je       SHORT G_M000_IG34
       mov      byte  ptr [rax+0x38], 0
       xor      rdx, rdx
       mov      gword ptr [rax+0x18], rdx
 
G_M000_IG38:                ;; offset=0x03DB
       mov      gword ptr [rax+0x20], rdx
 
G_M000_IG39:                ;; offset=0x03DF
       mov      qword ptr [rax+0x30], rdx
       mov      r15, gword ptr [rcx+0x18]
       cmp      byte  ptr [rcx+0x48], 0
       jne      SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x03ED
       test     r15, r15
       jne      G_M000_IG299
 
G_M000_IG41:                ;; offset=0x03F6
       lea      rcx, bword ptr [rcx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       test     r15, r15
       je       G_M000_IG34
       jmp      G_M000_IG300
 
G_M000_IG42:                ;; offset=0x0410
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG34
 
G_M000_IG43:                ;; offset=0x041E
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG44:                ;; offset=0x0425
       mov      gword ptr [rbp-0x1B0], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x1A8], rdx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x18]
       not      edx
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      edx, dword ptr [rcx+0x60]
       jl       G_M000_IG60
 
G_M000_IG45:                ;; offset=0x0451
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG310
       mov      rax, gword ptr [rcx+0x38]
       mov      rdx, gword ptr [rax+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG310
       mov      rax, gword ptr [rax+0x180]
       test     rax, rax
       jne      G_M000_IG309
 
G_M000_IG46:                ;; offset=0x0482
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x0495
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG313
 
G_M000_IG48:                ;; offset=0x04A9
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG49:                ;; offset=0x04B3
       mov      rdx, gword ptr [rbx]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      r8d, eax
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG50:                ;; offset=0x04D1
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [rbx+0x40], eax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x10]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG547
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      ebx, dword ptr [rdx+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG64
 
G_M000_IG51:                ;; offset=0x050C
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, dword ptr [rdx+0x08]
 
G_M000_IG52:                ;; offset=0x0516
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG53:                ;; offset=0x0526
       mov      rax, gword ptr [rbx+0x68]
       mov      rdx, 0x7FF9D723C7D0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG315
       cmp      dword ptr [rax+0x08], edi
       jbe      G_M000_IG314
       mov      edx, edi
       mov      r14, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG54:                ;; offset=0x054D
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0569
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG56:                ;; offset=0x0577
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG316
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG547
       mov      eax, edi
       shl      rax, 4
       mov      r13, gword ptr [rsi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG62
 
G_M000_IG57:                ;; offset=0x05A6
       mov      eax, edi
       shl      rax, 4
       lea      r13, bword ptr [rsi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1B8]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x05D0
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG317
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG59
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx+0xFF], 0
       jne      G_M000_IG317
 
G_M000_IG59:                ;; offset=0x05FB
       mov      rbx, bword ptr [rbp+0xC20]
       inc      dword ptr [rbx+0x10]
       jmp      G_M000_IG02
 
G_M000_IG60:                ;; offset=0x060A
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       not      eax
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       jmp      G_M000_IG45
 
G_M000_IG61:                ;; offset=0x0631
       xor      rax, rax
       jmp      G_M000_IG56
 
G_M000_IG62:                ;; offset=0x0638
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG57
 
G_M000_IG63:                ;; offset=0x064C
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG59
 
G_M000_IG64:                ;; offset=0x067A
       cmp      ebx, 71
       je       G_M000_IG318
       cmp      ebx, 30
       jne      G_M000_IG323
       cmp      gword ptr [rbp-0x1B0], 0
       jne      G_M000_IG59
       jmp      G_M000_IG324
 
G_M000_IG65:                ;; offset=0x069F
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rax, gword ptr [rdx+0x30]
       mov      rbx, rax
       mov      edx, esi
       cmp      edx, 35
       jg       G_M000_IG435
       cmp      edx, 35
       ja       G_M000_IG434
 
G_M000_IG66:                ;; offset=0x06C4
       mov      rax, 0x7FFFFFFBD
       bt       rax, rdx
       jb       G_M000_IG434
 
G_M000_IG67:                ;; offset=0x06D8
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG547
       mov      rcx, gword ptr [rbx+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG77
 
G_M000_IG68:                ;; offset=0x070A
       mov      rsi, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0724
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG436
 
G_M000_IG70:                ;; offset=0x0738
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG71:                ;; offset=0x0743
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       SHORT G_M000_IG76
 
G_M000_IG72:                ;; offset=0x0750
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rcx+0x18]
 
G_M000_IG73:                ;; offset=0x075B
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0761
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG75:                ;; offset=0x076D
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG547
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r14+0x08], r9
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG02
 
G_M000_IG76:                ;; offset=0x07A1
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       mov      r15d, ecx
       not      r15d
       jmp      SHORT G_M000_IG73
 
G_M000_IG77:                ;; offset=0x07B3
       mov      rsi, bword ptr [rbp+0xC20]
       mov      gword ptr [rbp-0x290], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x288], r9
       lea      r9, [rbp-0x290]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG78:                ;; offset=0x07EE
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG143
 
G_M000_IG79:                ;; offset=0x081B
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG80:                ;; offset=0x082A
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG542
 
G_M000_IG81:                ;; offset=0x083F
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
       jmp      G_M000_IG543
 
G_M000_IG82:                ;; offset=0x087A
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG268
       jmp      G_M000_IG02
 
G_M000_IG83:                ;; offset=0x08AC
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xB0]
       cmp      esi, 42
       jne      G_M000_IG474
       mov      r11, bword ptr [rbp+0xBB8]
       mov      r11d, dword ptr [r11+0x08]
       mov      rax, 0x7FF9D7648680
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG475
       cmp      dword ptr [rdx+0x08], r11d
       jbe      G_M000_IG314
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      rsi, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG84:                ;; offset=0x0904
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0913
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG476
 
G_M000_IG86:                ;; offset=0x0927
       mov      rax, bword ptr [rbp+0xBB8]
       mov      ebx, dword ptr [rax+0x14]
 
G_M000_IG87:                ;; offset=0x0931
       mov      rax, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rax+0x10], 0
       jl       G_M000_IG92
 
G_M000_IG88:                ;; offset=0x0942
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rax, bword ptr [rcx+0x20]
       cmp      byte  ptr [rsi], sil
       mov      rax, gword ptr [rax]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, ebx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG547
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG497
 
G_M000_IG89:                ;; offset=0x0987
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG498
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG499
       mov      rdi, gword ptr [rax]
 
G_M000_IG90:                ;; offset=0x09AB
       test     rdi, rdi
       je       G_M000_IG500
       mov      dword ptr [rsp+0x20], ebx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG135
 
G_M000_IG91:                ;; offset=0x09EB
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
       jmp      G_M000_IG501
 
G_M000_IG92:                ;; offset=0x09FE
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], ebx
       jne      G_M000_IG88
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG93
       mov      edx, dword ptr [rdx+0x08]
 
G_M000_IG93:                ;; offset=0x0A27
       mov      r14d, dword ptr [rcx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rbp-0x260], rdx
       mov      r15d, eax
       not      r15d
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], r15d
       jg       G_M000_IG122
 
G_M000_IG94:                ;; offset=0x0A48
       mov      rax, gword ptr [rdi+0x38]
       mov      rdx, gword ptr [rdi+0x30]
       mov      r8d, r15d
       sub      r8d, dword ptr [rdx+0x08]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r8d
       mov      r13, gword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rdi+0x30]
       sub      r15d, dword ptr [rax+0x08]
       mov      rax, gword ptr [rdi+0x38]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r15d
       mov      r12, gword ptr [rax+8*rdx+0x10]
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x2E8], rax
       cmp      byte  ptr [rax+0xFE], 0
       je       G_M000_IG477
       mov      rcx, rax
 
G_M000_IG95:                ;; offset=0x0AA7
       test     rcx, rcx
       je       SHORT G_M000_IG96
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG479
       mov      rdx, gword ptr [rdi+0x48]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      r8d, r15d
       mov      edx, dword ptr [rdx+4*r8+0x10]
       test     edx, edx
       jge      G_M000_IG478
 
G_M000_IG96:                ;; offset=0x0ADB
       mov      rax, gword ptr [rbp-0x2E8]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       je       G_M000_IG480
 
G_M000_IG97:                ;; offset=0x0AEF
       cmp      byte  ptr [rcx], cl
       mov      rdx, r12
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      G_M000_IG121
 
G_M000_IG98:                ;; offset=0x0B03
       xor      rcx, rcx
       mov      gword ptr [rbp-0x260], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r12
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      G_M000_IG120
 
G_M000_IG99:                ;; offset=0x0B38
       xor      rax, rax
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG100:                ;; offset=0x0B41
       test     eax, eax
       je       G_M000_IG481
 
G_M000_IG101:                ;; offset=0x0B49
       mov      r14, gword ptr [rbp-0x260]
 
G_M000_IG102:                ;; offset=0x0B50
       xor      rcx, rcx
       mov      gword ptr [rbp-0x260], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rcx+0x0C]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r15, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG482
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG103:                ;; offset=0x0B81
       mov      r13d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x268], r8
       test     edi, edi
       jl       G_M000_IG123
 
G_M000_IG104:                ;; offset=0x0B97
       cmp      edi, eax
       jae      G_M000_IG547
       mov      eax, edi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG488
 
G_M000_IG105:                ;; offset=0x0BBE
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG489
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG490
       mov      r12, gword ptr [rax]
 
G_M000_IG106:                ;; offset=0x0BE2
       cmp      edi, dword ptr [r15+0xD8]
       jge      SHORT G_M000_IG111
 
G_M000_IG107:                ;; offset=0x0BEB
       test     r12, r12
       je       SHORT G_M000_IG110
 
G_M000_IG108:                ;; offset=0x0BF0
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0C00
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r12, rax
 
G_M000_IG110:                ;; offset=0x0C0C
       test     r12, r12
       je       G_M000_IG491
 
G_M000_IG111:                ;; offset=0x0C15
       test     r12, r12
       je       G_M000_IG492
       mov      r13, r12
 
G_M000_IG112:                ;; offset=0x0C21
       xor      rdx, rdx
       mov      gword ptr [rbp-0x268], rdx
       mov      rax, r14
       test     rax, rax
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x0C32
       mov      rdx, 0x7FF9D77F3D68
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG493
       xor      rax, rax
 
G_M000_IG114:                ;; offset=0x0C47
       test     rax, rax
       jne      G_M000_IG494
 
G_M000_IG115:                ;; offset=0x0C50
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       lea      r15d, [rbx+0x01]
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0C65
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG117:                ;; offset=0x0C71
       mov      rdx, gword ptr [rdi]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, ebx
       shl      rax, 4
       lea      r12, bword ptr [rdx+rax+0x10]
       mov      rcx, r12
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r12+0x08], rcx
       mov      dword ptr [rdi+0x40], r15d
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       lea      r14d, [rbx+0x02]
       cmp      r14d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CB3
       mov      rcx, rdi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG119:                ;; offset=0x0CBF
       mov      rdx, gword ptr [rdi]
       lea      eax, [rbx+0x01]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       lea      eax, [rbx+0x01]
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      dword ptr [rdi+0x40], r14d
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG88
 
G_M000_IG120:                ;; offset=0x0CFB
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rcx
       mov      eax, 1
       jmp      G_M000_IG100
 
G_M000_IG121:                ;; offset=0x0D0F
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rcx
       jmp      G_M000_IG101
 
G_M000_IG122:                ;; offset=0x0D1E
       mov      rax, gword ptr [rdi+0x30]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r15d
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       jmp      G_M000_IG102
 
G_M000_IG123:                ;; offset=0x0D42
       not      edi
       mov      rax, gword ptr [r15+0x30]
       cmp      dword ptr [rax+0x08], edi
       jg       G_M000_IG134
 
G_M000_IG124:                ;; offset=0x0D51
       mov      rax, gword ptr [r15+0x38]
       mov      rdx, gword ptr [r15+0x30]
       mov      r8d, edi
       sub      r8d, dword ptr [rdx+0x08]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r8d
       mov      r12, gword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [r15+0x30]
       sub      edi, dword ptr [rax+0x08]
       mov      rax, gword ptr [r15+0x38]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, edi
       mov      rax, gword ptr [rax+8*rdx+0x10]
       mov      gword ptr [rbp-0x2F0], rax
       mov      rcx, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x2F8], rax
       cmp      byte  ptr [rax+0xFE], 0
       je       G_M000_IG483
       mov      rcx, rax
 
G_M000_IG125:                ;; offset=0x0DB8
       test     rcx, rcx
       je       SHORT G_M000_IG126
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [r15+0x40]
       jne      G_M000_IG485
       mov      rdx, gword ptr [r15+0x48]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      r8d, edi
       mov      edx, dword ptr [rdx+4*r8+0x10]
       test     edx, edx
       jge      G_M000_IG484
 
G_M000_IG126:                ;; offset=0x0DEB
       mov      rax, gword ptr [rbp-0x2F8]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       je       G_M000_IG486
 
G_M000_IG127:                ;; offset=0x0DFF
       cmp      byte  ptr [rcx], cl
       mov      rdx, gword ptr [rbp-0x2F0]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG133
 
G_M000_IG128:                ;; offset=0x0E13
       xor      rcx, rcx
       mov      gword ptr [rbp-0x268], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x2F0]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG132
 
G_M000_IG129:                ;; offset=0x0E48
       xor      rax, rax
       mov      gword ptr [rbp-0x268], rax
 
G_M000_IG130:                ;; offset=0x0E51
       test     eax, eax
       je       G_M000_IG487
 
G_M000_IG131:                ;; offset=0x0E59
       mov      r13, gword ptr [rbp-0x268]
       jmp      G_M000_IG112
 
G_M000_IG132:                ;; offset=0x0E65
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x268], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG130
 
G_M000_IG133:                ;; offset=0x0E76
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x268], rcx
       jmp      SHORT G_M000_IG131
 
G_M000_IG134:                ;; offset=0x0E82
       mov      rax, gword ptr [r15+0x30]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, edi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG112
 
G_M000_IG135:                ;; offset=0x0EA4
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG503
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rsi
       mov      r8d, ebx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG139
 
G_M000_IG136:                ;; offset=0x0EE3
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG513
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
 
G_M000_IG137:                ;; offset=0x0F1C
       vmovdqu  xmm0, xmmword ptr [rbp+0xB18]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG138:                ;; offset=0x0F2C
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG511
 
G_M000_IG139:                ;; offset=0x0F3A
       mov      r8, bword ptr [rbp+0xC50]
       mov      rbx, gword ptr [r8]
       test     rbx, rbx
       jne      G_M000_IG504
 
G_M000_IG140:                ;; offset=0x0F4D
       mov      r8, bword ptr [rbp+0xC50]
       mov      rbx, gword ptr [r8]
       test     rbx, rbx
       jne      G_M000_IG507
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG141:                ;; offset=0x0F64
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      rdi, rcx
       je       G_M000_IG510
 
G_M000_IG142:                ;; offset=0x0F74
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG548
 
G_M000_IG143:                ;; offset=0x0F93
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       lea      r8, [rbp+0xB68]
       lea      r9, [rbp+0xB58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG465
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG469
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG144:                ;; offset=0x0FFE
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG516
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG145:                ;; offset=0x102A
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x270], r8
       test     esi, esi
       jl       G_M000_IG278
 
G_M000_IG146:                ;; offset=0x1040
       cmp      esi, eax
       jae      G_M000_IG547
       mov      eax, esi
       shl      rax, 4
       lea      rcx, bword ptr [rdx+rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x1063
       test     rcx, rcx
       je       SHORT G_M000_IG150
 
G_M000_IG148:                ;; offset=0x1068
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG150
 
G_M000_IG149:                ;; offset=0x1077
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG150:                ;; offset=0x1080
       test     rcx, rcx
       je       G_M000_IG522
 
G_M000_IG151:                ;; offset=0x1089
       mov      rdx, rcx
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG152:                ;; offset=0x109F
       xor      rcx, rcx
       mov      gword ptr [rbp-0x270], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x20], r8
       mov      r8d, esi
       mov      rcx, rbx
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG153:                ;; offset=0x10ED
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       test     al, al
       jne      G_M000_IG523
 
G_M000_IG154:                ;; offset=0x110A
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG155:                ;; offset=0x1123
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG452
 
G_M000_IG156:                ;; offset=0x113E
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG157:                ;; offset=0x115D
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG156
       jmp      G_M000_IG328
 
G_M000_IG158:                ;; offset=0x116C
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG548
 
G_M000_IG159:                ;; offset=0x117B
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      eax, esi
       cmp      eax, 51
       ja       SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x118D
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG444
 
G_M000_IG161:                ;; offset=0x11A1
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG162:                ;; offset=0x11AB
       lea      esi, [rax+0x01]
       mov      rax, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG167
 
G_M000_IG163:                ;; offset=0x11BF
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x18]
 
G_M000_IG164:                ;; offset=0x11C9
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG547
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       cmp      edi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x1211
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG166:                ;; offset=0x121C
       mov      rcx, gword ptr [rbx]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG547
       mov      edx, esi
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], edi
       jmp      G_M000_IG02
 
G_M000_IG167:                ;; offset=0x124C
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       mov      edi, eax
       not      edi
       jmp      G_M000_IG164
 
G_M000_IG168:                ;; offset=0x125F
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r13d, dword ptr [rdi+0x08]
       cmp      eax, r13d
       jae      G_M000_IG547
       mov      ecx, eax
       mov      r13, gword ptr [rdi+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG174
 
G_M000_IG169:                ;; offset=0x12CA
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rax+0x18]
 
G_M000_IG170:                ;; offset=0x12D5
       mov      rax, gword ptr [rdi]
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r14d
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG440
 
G_M000_IG171:                ;; offset=0x1304
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG441
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG442
       mov      r9, gword ptr [rax]
 
G_M000_IG172:                ;; offset=0x1328
       test     r9, r9
       je       G_M000_IG443
       mov      rdx, gword ptr [rdi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      r8d, r14d
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       xor      r8, r8
       mov      gword ptr [rdx], r8
 
G_M000_IG173:                ;; offset=0x1350
       mov      qword ptr [rdx+0x08], r8
       mov      dword ptr [rdi+0x40], r15d
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG174:                ;; offset=0x1387
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       mov      r15d, eax
       not      r15d
       jmp      G_M000_IG170
 
G_M000_IG175:                ;; offset=0x139C
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      eax, esi
       cmp      eax, 2
       je       SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x13B1
       cmp      eax, 25
       jne      G_M000_IG330
 
G_M000_IG177:                ;; offset=0x13BA
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jl       G_M000_IG190
 
G_M000_IG178:                ;; offset=0x13DD
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x18]
       test     r13d, r13d
       jl       G_M000_IG189
 
G_M000_IG179:                ;; offset=0x1400
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r15d
       shl      rdx, 4
 
G_M000_IG180:                ;; offset=0x1420
       vmovdqu  xmm0, xmmword ptr [rax+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
 
G_M000_IG181:                ;; offset=0x142E
       cmp      gword ptr [rbp-0x1E8], 0
       je       G_M000_IG344
 
G_M000_IG182:                ;; offset=0x143C
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r15d
       shl      rdx, 4
       xor      r8d, r8d
       mov      qword ptr [rax+rdx+0x10], r8
       mov      qword ptr [rax+rdx+0x18], r8
       mov      dword ptr [r14+0x40], r13d
       mov      r14, gword ptr [rbp-0x1E8]
       mov      r15, qword ptr [rbp-0x1E0]
 
G_M000_IG183:                ;; offset=0x146F
       mov      gword ptr [rbp-0x1F8], r14
       mov      qword ptr [rbp-0x1F0], r15
       mov      rdx, gword ptr [rbx+0x68]
       mov      r11, 0x7FF9D723C7D0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG345
       cmp      dword ptr [rdx+0x08], esi
       jbe      G_M000_IG314
       mov      r11d, esi
       mov      r14, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG184:                ;; offset=0x14A5
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG346
 
G_M000_IG185:                ;; offset=0x14C1
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG186:                ;; offset=0x14CF
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG347
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       shl      rax, 4
       mov      r13, gword ptr [rdi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG215
 
G_M000_IG187:                ;; offset=0x14FE
       mov      eax, esi
       shl      rax, 4
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       G_M000_IG02
 
G_M000_IG188:                ;; offset=0x152C
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG348
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx+0xFF], 0
       je       G_M000_IG02
       jmp      G_M000_IG348
 
G_M000_IG189:                ;; offset=0x1567
       not      r13d
       jmp      G_M000_IG179
 
G_M000_IG190:                ;; offset=0x156F
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jge      G_M000_IG331
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      r15, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG332
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG191:                ;; offset=0x15AA
       mov      r13d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x1D8], r8
       test     r14d, r14d
       jl       G_M000_IG203
 
G_M000_IG192:                ;; offset=0x15C1
       cmp      r14d, eax
       jae      G_M000_IG547
       mov      eax, r14d
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG339
 
G_M000_IG193:                ;; offset=0x15EA
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG340
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG341
       mov      r12, gword ptr [rax]
 
G_M000_IG194:                ;; offset=0x160E
       cmp      r14d, dword ptr [r15+0xD8]
       jge      SHORT G_M000_IG199
 
G_M000_IG195:                ;; offset=0x1617
       test     r12, r12
       je       SHORT G_M000_IG198
 
G_M000_IG196:                ;; offset=0x161C
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG198
 
G_M000_IG197:                ;; offset=0x162C
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r12, rax
 
G_M000_IG198:                ;; offset=0x1638
       test     r12, r12
       je       G_M000_IG342
 
G_M000_IG199:                ;; offset=0x1641
       mov      r9, gword ptr [rbp+0xC28]
       test     r12, r12
       je       G_M000_IG343
       mov      r14, r12
 
G_M000_IG200:                ;; offset=0x1654
       xor      rdx, rdx
       mov      gword ptr [rbp-0x1D8], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jl       G_M000_IG214
 
G_M000_IG201:                ;; offset=0x167A
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG202:                ;; offset=0x1685
       xor      r15d, r15d
       jmp      G_M000_IG183
 
G_M000_IG203:                ;; offset=0x168D
       mov      r9, gword ptr [rbp+0xC28]
       not      r14d
       mov      rax, gword ptr [r15+0x30]
       cmp      dword ptr [rax+0x08], r14d
       jg       G_M000_IG333
 
G_M000_IG204:                ;; offset=0x16A5
       mov      rdx, gword ptr [r15+0x38]
       mov      r8d, r14d
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG547
       mov      r12, gword ptr [rdx+8*r8+0x10]
       sub      r14d, dword ptr [rax+0x08]
       mov      rax, gword ptr [r15+0x38]
       cmp      r14d, r10d
       jae      G_M000_IG547
       mov      edx, r14d
       mov      rax, gword ptr [rax+8*rdx+0x10]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x2E0], rax
       cmp      byte  ptr [rax+0xFE], 0
       je       G_M000_IG334
       mov      rcx, rax
 
G_M000_IG205:                ;; offset=0x1702
       test     rcx, rcx
       je       SHORT G_M000_IG206
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [r15+0x40]
       jne      G_M000_IG336
       mov      rdx, gword ptr [r15+0x48]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      r8d, r14d
       mov      edx, dword ptr [rdx+4*r8+0x10]
       test     edx, edx
       jge      G_M000_IG335
 
G_M000_IG206:                ;; offset=0x1736
       mov      rax, gword ptr [rbp-0x2E0]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       je       G_M000_IG337
 
G_M000_IG207:                ;; offset=0x174A
       cmp      byte  ptr [rcx], cl
       mov      rdx, gword ptr [rbp-0x2D8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG213
 
G_M000_IG208:                ;; offset=0x175E
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D8], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x2D8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG212
 
G_M000_IG209:                ;; offset=0x1793
       xor      rax, rax
       mov      gword ptr [rbp-0x1D8], rax
 
G_M000_IG210:                ;; offset=0x179C
       test     eax, eax
       je       G_M000_IG338
 
G_M000_IG211:                ;; offset=0x17A4
       mov      r14, gword ptr [rbp-0x1D8]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG200
 
G_M000_IG212:                ;; offset=0x17B7
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x1D8], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG210
 
G_M000_IG213:                ;; offset=0x17C8
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x1D8], rcx
       jmp      SHORT G_M000_IG211
 
G_M000_IG214:                ;; offset=0x17D4
       not      eax
       jmp      G_M000_IG201
 
G_M000_IG215:                ;; offset=0x17DB
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG187
 
G_M000_IG216:                ;; offset=0x17EF
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG02
 
G_M000_IG217:                ;; offset=0x1820
       xor      rax, rax
       mov      gword ptr [rbp-0x200], rax
       cmp      esi, 23
       jne      G_M000_IG411
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG547
       mov      ecx, eax
       mov      rbx, gword ptr [rsi+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG412
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG218:                ;; offset=0x1885
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x208], r8
       test     esi, esi
       jl       G_M000_IG249
 
G_M000_IG219:                ;; offset=0x189B
       cmp      esi, eax
       jae      G_M000_IG547
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG419
 
G_M000_IG220:                ;; offset=0x18C2
       mov      rdx, gword ptr [rax]
       mov      r8, 0x1AD1A001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG420
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG421
       mov      r15, gword ptr [rax]
 
G_M000_IG221:                ;; offset=0x18E6
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG226
 
G_M000_IG222:                ;; offset=0x18EE
       test     r15, r15
       je       SHORT G_M000_IG225
 
G_M000_IG223:                ;; offset=0x18F3
       mov      rax, 0x7FF9D77F4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG225
 
G_M000_IG224:                ;; offset=0x1902
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG225:                ;; offset=0x190E
       test     r15, r15
       je       G_M000_IG422
 
G_M000_IG226:                ;; offset=0x1917
       test     r15, r15
       je       G_M000_IG423
       mov      r13, r15
 
G_M000_IG227:                ;; offset=0x1923
       xor      r8, r8
       mov      gword ptr [rbp-0x208], r8
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG228
       test     r13, r13
       jne      G_M000_IG262
 
G_M000_IG228:                ;; offset=0x1940
       mov      rcx, r13
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG411
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG230
 
G_M000_IG229:                ;; offset=0x1971
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG424
 
G_M000_IG230:                ;; offset=0x1985
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG231:                ;; offset=0x198F
       cmp      esi, eax
       je       G_M000_IG240
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x19B1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG425
 
G_M000_IG233:                ;; offset=0x19C5
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x14]
 
G_M000_IG234:                ;; offset=0x19CF
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x19DE
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG426
 
G_M000_IG236:                ;; offset=0x19F2
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG237:                ;; offset=0x19FC
       lea      r14d, [rax+0x01]
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG239
 
G_M000_IG238:                ;; offset=0x1A06
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG239:                ;; offset=0x1A12
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG240:                ;; offset=0x1A3E
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG242
 
G_M000_IG241:                ;; offset=0x1A58
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG427
 
G_M000_IG242:                ;; offset=0x1A6C
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG243:                ;; offset=0x1A76
       lea      edi, [rax+0x01]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       G_M000_IG267
 
G_M000_IG244:                ;; offset=0x1A8D
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG246
 
G_M000_IG245:                ;; offset=0x1A93
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG246:                ;; offset=0x1A9F
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG247:                ;; offset=0x1ACB
       mov      ecx, 1
       mov      r9, gword ptr [rbp+0xC28]
 
G_M000_IG248:                ;; offset=0x1AD7
       xor      rdx, rdx
       mov      gword ptr [rbp-0x200], rdx
       test     ecx, ecx
       jne      G_M000_IG02
       jmp      G_M000_IG428
 
G_M000_IG249:                ;; offset=0x1AED
       not      esi
       mov      r15, gword ptr [rdi+0x30]
       cmp      dword ptr [r15+0x08], esi
       jg       G_M000_IG413
 
G_M000_IG250:                ;; offset=0x1AFD
       mov      rdx, gword ptr [rdi+0x38]
       mov      rax, rdx
       mov      r8d, esi
       sub      r8d, dword ptr [r15+0x08]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      r13, gword ptr [rax+8*r8+0x10]
       sub      esi, dword ptr [r15+0x08]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       mov      r15, gword ptr [rdx+8*rax+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      r12, r9
       mov      rdx, gword ptr [r12+0x10]
       mov      rcx, 0x7FF9D76B9D18
       call     CORINFO_HELP_CHKCASTCLASS
       test     rax, rax
       jne      G_M000_IG259
 
G_M000_IG251:                ;; offset=0x1B55
       cmp      byte  ptr [r12+0xFE], 0
       je       G_M000_IG414
       mov      rcx, r12
 
G_M000_IG252:                ;; offset=0x1B67
       test     rcx, rcx
       je       SHORT G_M000_IG253
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG416
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jge      G_M000_IG415
 
G_M000_IG253:                ;; offset=0x1B98
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG417
 
G_M000_IG254:                ;; offset=0x1BA6
       cmp      byte  ptr [rcx], cl
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      G_M000_IG261
 
G_M000_IG255:                ;; offset=0x1BBA
       xor      rcx, rcx
       mov      gword ptr [rbp-0x208], rcx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rcx+0xE8]
       cmp      byte  ptr [rcx], cl
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG260
 
G_M000_IG256:                ;; offset=0x1BE8
       xor      rax, rax
       mov      gword ptr [rbp-0x208], rax
 
G_M000_IG257:                ;; offset=0x1BF1
       test     eax, eax
       je       G_M000_IG418
 
G_M000_IG258:                ;; offset=0x1BF9
       mov      r13, gword ptr [rbp-0x208]
       jmp      G_M000_IG227
 
G_M000_IG259:                ;; offset=0x1C05
       mov      rdx, gword ptr [r12+0x10]
       mov      rcx, 0x7FF9D76B9D18
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r12, rax
       mov      rdx, gword ptr [r12+0x10]
       mov      rcx, 0x7FF9D76B9D18
       call     CORINFO_HELP_CHKCASTCLASS
       test     rax, rax
       jne      SHORT G_M000_IG259
       jmp      G_M000_IG251
 
G_M000_IG260:                ;; offset=0x1C3A
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x208], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG257
 
G_M000_IG261:                ;; offset=0x1C4B
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x208], rcx
       jmp      SHORT G_M000_IG258
 
G_M000_IG262:                ;; offset=0x1C57
       mov      r8, 0x7FF9D77F9A80
       cmp      qword ptr [r13], r8
       jne      G_M000_IG228
 
G_M000_IG263:                ;; offset=0x1C6B
       lea      r8, [rbp-0x200]
       mov      rcx, r13
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG228
 
G_M000_IG264:                ;; offset=0x1C86
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ebx, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       SHORT G_M000_IG266
 
G_M000_IG265:                ;; offset=0x1CA1
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       lea      rcx, [rbp-0x218]
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x218]
       mov      rcx, rbx
       mov      edx, esi
       mov      r8d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG266:                ;; offset=0x1CF0
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r13, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      ebx, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdx, gword ptr [rbp-0x200]
       lea      rcx, [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x228]
       mov      rcx, r13
       mov      edx, ebx
       mov      r8d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG247
 
G_M000_IG267:                ;; offset=0x1D48
       not      r14d
       jmp      G_M000_IG244
 
G_M000_IG268:                ;; offset=0x1D50
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG460
 
G_M000_IG269:                ;; offset=0x1DB1
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG352
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG270:                ;; offset=0x1DDA
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG271:                ;; offset=0x1DE7
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
 
G_M000_IG272:                ;; offset=0x1E0C
       vmovdqu  xmm0, xmmword ptr [rbp+0xB18]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG273:                ;; offset=0x1E1C
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG350
 
G_M000_IG274:                ;; offset=0x1E2A
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG383
       mov      r14, gword ptr [rbp+0xB90]
 
G_M000_IG275:                ;; offset=0x1E82
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG276:                ;; offset=0x1E92
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG381
 
G_M000_IG277:                ;; offset=0x1EA0
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x290], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x288], r9
       lea      r9, [rbp-0x290]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG278:                ;; offset=0x1F0B
       mov      r9, gword ptr [rbp+0xC28]
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG284
 
G_M000_IG279:                ;; offset=0x1F21
       mov      rdx, gword ptr [rdi+0x38]
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r13d, dword ptr [rdx+0x08]
       cmp      r8d, r13d
       jae      G_M000_IG547
       mov      r15, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       mov      rax, gword ptr [rdi+0x38]
       cmp      esi, r13d
       jae      G_M000_IG547
       mov      edx, esi
       mov      r13, gword ptr [rax+8*rdx+0x10]
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       je       G_M000_IG517
       mov      rcx, r12
 
G_M000_IG280:                ;; offset=0x1F73
       test     rcx, rcx
       je       SHORT G_M000_IG281
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG519
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jge      G_M000_IG518
 
G_M000_IG281:                ;; offset=0x1FA4
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG520
 
G_M000_IG282:                ;; offset=0x1FB2
       lea      r8, [rbp-0x270]
       mov      rdx, r13
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryGetValue(System.__Canon,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG283
       lea      r8, [rbp-0x270]
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryGetBuiltin(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG521
 
G_M000_IG283:                ;; offset=0x1FE7
       mov      r15, gword ptr [rbp-0x270]
       jmp      G_M000_IG152
 
G_M000_IG284:                ;; offset=0x1FF3
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r15, rax
       jmp      G_M000_IG152
 
G_M000_IG285:                ;; offset=0x2011
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG286:                ;; offset=0x2034
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA60], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA80], rcx
 
G_M000_IG287:                ;; offset=0x204C
       mov      ecx, dword ptr [rbp+0xA70]
       cmp      ecx, dword ptr [rbp+0xA80]
       jbe      G_M000_IG544
       jmp      G_M000_IG370
 
G_M000_IG288:                ;; offset=0x2063
       cmp      edx, 72
       je       G_M000_IG10
 
G_M000_IG289:                ;; offset=0x206C
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x1CD40BDD5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG290:                ;; offset=0x208C
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG291:                ;; offset=0x20A0
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG292:                ;; offset=0x20B4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG293:                ;; offset=0x20C8
       mov      rcx, rbx
       mov      edx, esi
       mov      r8, r14
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG17
 
G_M000_IG294:                ;; offset=0x20E2
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG21
 
G_M000_IG295:                ;; offset=0x20F6
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      eax, r13d
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG36
       cmp      gword ptr [rsi+0x28], 0
       jne      SHORT G_M000_IG296
       lea      rcx, bword ptr [rsi+0x20]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG297
 
G_M000_IG296:                ;; offset=0x213F
       mov      rcx, gword ptr [rsi+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG297:                ;; offset=0x214F
       lea      rcx, bword ptr [rsi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       mov      ecx, r13d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG298:                ;; offset=0x2179
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG34
 
G_M000_IG299:                ;; offset=0x2182
       mov      rdx, gword ptr [r15+0x10]
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, gword ptr [rax+0x10]
       cmp      edx, dword ptr [r8+0x08]
       jge      G_M000_IG42
       jmp      G_M000_IG41
 
G_M000_IG300:                ;; offset=0x219C
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG34
 
G_M000_IG301:                ;; offset=0x21AA
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG34
 
G_M000_IG302:                ;; offset=0x21BC
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D7763360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG303
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      SHORT G_M000_IG303
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, 0x7FF9D76708D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG33
 
G_M000_IG303:                ;; offset=0x2220
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2C8], rax
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71628A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       SHORT G_M000_IG304
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG34
 
G_M000_IG304:                ;; offset=0x2267
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x2C8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG34
 
G_M000_IG305:                ;; offset=0x227E
       mov      rcx, gword ptr [r15]
       mov      rax, 0x1AD1A001CE0
       cmp      rcx, gword ptr [rax]
       je       G_M000_IG34
       mov      rcx, gword ptr [r15]
       mov      rax, 0x1AD1A001CE8
       cmp      rcx, gword ptr [rax]
       je       G_M000_IG34
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       mov      rcx, 0x7FF9D764E7B8
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d709b100)]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG34
 
G_M000_IG306:                ;; offset=0x22DA
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG307:                ;; offset=0x22E6
       mov      r10d, dword ptr [r11+0x04]
       add      r10d, -24
       shr      r10d, 3
       movsxd   r15, r10d
       mov      r15d, dword ptr [r8+4*r15]
       shl      r10d, 3
       movsxd   r10, r10d
       add      r8, r10
       mov      r10d, r15d
       jmp      G_M000_IG26
 
G_M000_IG308:                ;; offset=0x230B
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG28
 
G_M000_IG309:                ;; offset=0x2319
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG46
 
G_M000_IG310:                ;; offset=0x232B
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG311:                ;; offset=0x234E
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG312:                ;; offset=0x235E
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x290]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG313:                ;; offset=0x2375
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG49
 
G_M000_IG314:                ;; offset=0x2387
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG315:                ;; offset=0x238E
       mov      rcx, rax
       mov      edx, edi
       mov      r11, 0x7FF9D70A2950
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG54
 
G_M000_IG316:                ;; offset=0x23A8
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG59
 
G_M000_IG317:                ;; offset=0x23E0
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG59
 
G_M000_IG318:                ;; offset=0x2435
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG319
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG320
 
G_M000_IG319:                ;; offset=0x2445
       lea      rax, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG320:                ;; offset=0x244D
       mov      bword ptr [rbp-0x280], rax
       mov      dword ptr [rbp-0x278], r8d
 
G_M000_IG321:                ;; offset=0x245B
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG322:                ;; offset=0x246B
       lea      rcx, [rbp-0x280]
       lea      r8, [rbp-0x290]
       mov      rbx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG59
 
G_M000_IG323:                ;; offset=0x248F
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BE2BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG324:                ;; offset=0x24BD
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG59
 
G_M000_IG325:                ;; offset=0x24E2
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG547
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2938
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG326:                ;; offset=0x255E
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG327
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rbx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbx+0x18]
       mov      r8d, dword ptr [rbx+0x10]
       mov      r9d, dword ptr [rbx+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG327
       add      dword ptr [rbx+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG327:                ;; offset=0x25A1
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0x25DF
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG548
 
G_M000_IG329:                ;; offset=0x25EE
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1D0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG330:                ;; offset=0x2629
       cmp      eax, 72
       je       G_M000_IG177
       jmp      G_M000_IG289
 
G_M000_IG331:                ;; offset=0x2637
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r15d
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG202
 
G_M000_IG332:                ;; offset=0x266A
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG191
 
G_M000_IG333:                ;; offset=0x2673
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG547
       mov      edx, r14d
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG200
 
G_M000_IG334:                ;; offset=0x269A
       xor      rcx, rcx
       jmp      G_M000_IG205
 
G_M000_IG335:                ;; offset=0x26A1
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG206
       mov      gword ptr [rbp-0x1D8], rax
       jmp      G_M000_IG211
 
G_M000_IG336:                ;; offset=0x26C3
       lea      r8, [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG206
       jmp      G_M000_IG211
 
G_M000_IG337:                ;; offset=0x26E4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG207
 
G_M000_IG338:                ;; offset=0x26F5
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG339:                ;; offset=0x2719
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG194
 
G_M000_IG340:                ;; offset=0x272A
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG194
 
G_M000_IG341:                ;; offset=0x273B
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG194
 
G_M000_IG342:                ;; offset=0x274C
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, r14d
       mov      rcx, r15
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG200
 
G_M000_IG343:                ;; offset=0x2780
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG344:                ;; offset=0x27AE
       lea      rcx, [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG182
 
G_M000_IG345:                ;; offset=0x27D3
       mov      rcx, rdx
       mov      edx, esi
       mov      r11, 0x7FF9D70A2958
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG184
 
G_M000_IG346:                ;; offset=0x27ED
       xor      rax, rax
       jmp      G_M000_IG186
 
G_M000_IG347:                ;; offset=0x27F4
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG02
 
G_M000_IG348:                ;; offset=0x282C
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, esi
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D7802610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG02
 
G_M000_IG349:                ;; offset=0x2881
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG328
 
G_M000_IG350:                ;; offset=0x28A9
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG351
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG351:                ;; offset=0x28E5
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70A2960
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG352:                ;; offset=0x2902
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG353:                ;; offset=0x2909
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG354:                ;; offset=0x2916
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       SHORT G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x29A6
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2968
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG356:                ;; offset=0x29CC
       test     esi, esi
       jne      SHORT G_M000_IG358
 
G_M000_IG357:                ;; offset=0x29D0
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG548
 
G_M000_IG358:                ;; offset=0x29F5
       mov      rax, bword ptr [rbp+0xC40]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG359:                ;; offset=0x2A0A
       mov      rax, gword ptr [rbp+0xC30]
       mov      r10, rax
       test     r10, r10
       jne      SHORT G_M000_IG360
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
 
G_M000_IG360:                ;; offset=0x2A23
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       test     al, al
       jne      G_M000_IG364
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG361:                ;; offset=0x2A69
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG362:                ;; offset=0x2A76
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp+0xB18]
       lea      rdx, [rbp+0xB08]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       mov      rbx, gword ptr [rbp+0xB08]
       test     rbx, rbx
       je       G_M000_IG02
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG363
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG363:                ;; offset=0x2AF4
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70A2970
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG364:                ;; offset=0x2B11
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG365:                ;; offset=0x2B18
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG366:                ;; offset=0x2B25
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG367
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG368
 
G_M000_IG367:                ;; offset=0x2BB3
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2978
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG368:                ;; offset=0x2BD9
       test     esi, esi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG369:                ;; offset=0x2BE6
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG547
       mov      edx, eax
       mov      rdx, gword ptr [rbx+8*rdx+0x10]
       mov      rcx, 0x7FF9D759EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      SHORT G_M000_IG372
       or       edi, r14d
       je       SHORT G_M000_IG371
 
G_M000_IG370:                ;; offset=0x2C67
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG371:                ;; offset=0x2C6E
       xor      rdx, rdx
       xor      ecx, ecx
       jmp      SHORT G_M000_IG373
 
G_M000_IG372:                ;; offset=0x2C74
       mov      edx, edi
       mov      ecx, r14d
       add      rdx, rcx
       mov      ecx, dword ptr [rsi+0x08]
       cmp      rdx, rcx
       ja       SHORT G_M000_IG370
       mov      edx, edi
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
 
G_M000_IG373:                ;; offset=0x2C92
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       mov      r10, r9
       jne      SHORT G_M000_IG374
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
 
G_M000_IG374:                ;; offset=0x2CC2
       mov      bword ptr [rbp-0x280], rdx
       mov      dword ptr [rbp-0x278], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x280]
       mov      rcx, rbx
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG375:                ;; offset=0x2D0D
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG376
       xor      r9, r9
       xor      r8d, r8d
       jmp      SHORT G_M000_IG377
 
G_M000_IG376:                ;; offset=0x2D62
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG377:                ;; offset=0x2D6A
       mov      rax, gword ptr [rbp+0xC30]
       mov      rdx, rax
       test     rdx, rdx
       jne      SHORT G_M000_IG378
       mov      r10, gword ptr [rbp+0xC28]
       mov      rdx, r10
 
G_M000_IG378:                ;; offset=0x2D83
       mov      bword ptr [rbp-0x280], r9
       mov      dword ptr [rbp-0x278], r8d
 
G_M000_IG379:                ;; offset=0x2D91
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG380:                ;; offset=0x2DA1
       lea      rcx, [rbp-0x280]
       lea      r8, [rbp-0x290]
       mov      r9, gword ptr [rdx+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG381:                ;; offset=0x2DC8
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG382
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG382:                ;; offset=0x2E04
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70A2980
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG383:                ;; offset=0x2E21
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG384:                ;; offset=0x2E31
       lea      rdx, [rbp-0x2C0]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG385
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG386
 
G_M000_IG385:                ;; offset=0x2EA4
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2988
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG386:                ;; offset=0x2ECA
       test     esi, esi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG387:                ;; offset=0x2ED7
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       jne      SHORT G_M000_IG388
       cmp      byte  ptr [rax+0xFF], 0
       jne      SHORT G_M000_IG388
       cmp      ebx, esi
       jle      SHORT G_M000_IG388
       cmp      esi, ebx
       jae      G_M000_IG547
       mov      r8, gword ptr [rbp+0xBD0]
       mov      edx, esi
       shl      rdx, 5
       cmp      dword ptr [r8+rdx+0x2C], 30
       sete     r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG389
 
G_M000_IG388:                ;; offset=0x2F6F
       xor      r14d, r14d
 
G_M000_IG389:                ;; offset=0x2F72
       test     r14d, r14d
       je       G_M000_IG395
       test     rdi, rdi
       je       G_M000_IG395
 
G_M000_IG390:                ;; offset=0x2F84
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG391:                ;; offset=0x2F94
       lea      r8, [rbp-0x290]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG395
       cmp      esi, ebx
       jae      G_M000_IG547
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      eax, esi
       shl      rax, 5
       mov      r14, gword ptr [rcx+rax+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG392
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG392:                ;; offset=0x2FF3
       mov      r9, gword ptr [rbp+0xC28]
       mov      rbx, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG393
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG394
 
G_M000_IG393:                ;; offset=0x3022
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG394:                ;; offset=0x3037
       lea      rcx, bword ptr [rbx+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       mov      edx, esi
       shl      rdx, 5
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG554
 
G_M000_IG395:                ;; offset=0x3081
       mov      rax, gword ptr [rbp+0xC30]
       lea      rbx, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rbx+0x08], rcx
       mov      rax, gword ptr [rbp+0xC30]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r14d, r14d
       jne      G_M000_IG158
       test     rdi, rdi
       je       G_M000_IG158
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG158
       jmp      G_M000_IG554
 
G_M000_IG396:                ;; offset=0x30EE
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG402
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG397:                ;; offset=0x3110
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG398:                ;; offset=0x311D
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG401
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG399
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG400
 
G_M000_IG399:                ;; offset=0x3191
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2990
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG400:                ;; offset=0x31B5
       test     ebx, ebx
       je       G_M000_IG357
 
G_M000_IG401:                ;; offset=0x31BD
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG406
 
G_M000_IG402:                ;; offset=0x31CF
       mov      rax, gword ptr [rbp+0xC30]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG403
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, 0x7FF9D71628A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, 0x7FF9D77F7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG403:                ;; offset=0x3296
       mov      rax, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rax+0x68]
       mov      r8, gword ptr [rax+0x58]
       mov      r9, gword ptr [rax+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG404:                ;; offset=0x32BF
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG405:                ;; offset=0x32CC
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG406:                ;; offset=0x32E7
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x70]
       test     rdx, rdx
       je       G_M000_IG158
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG158
       jmp      G_M000_IG554
 
G_M000_IG407:                ;; offset=0x3329
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x1CD40BE4708
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A2948
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG408
       mov      rbx, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rbx]
       mov      r8, gword ptr [rbx+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG408:                ;; offset=0x339F
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rsi+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       je       G_M000_IG358
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG409
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG410
 
G_M000_IG409:                ;; offset=0x3429
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A2998
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG410:                ;; offset=0x344F
       test     edi, edi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG411:                ;; offset=0x345C
       mov      r9, gword ptr [rbp+0xC28]
       xor      edx, edx
       mov      ecx, edx
       jmp      G_M000_IG248
 
G_M000_IG412:                ;; offset=0x346C
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG218
 
G_M000_IG413:                ;; offset=0x3475
       cmp      esi, dword ptr [r15+0x08]
       jae      G_M000_IG547
       mov      eax, esi
       mov      rcx, gword ptr [r15+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG227
 
G_M000_IG414:                ;; offset=0x3494
       xor      rcx, rcx
       jmp      G_M000_IG252
 
G_M000_IG415:                ;; offset=0x349B
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG253
       mov      gword ptr [rbp-0x208], rax
       jmp      G_M000_IG258
 
G_M000_IG416:                ;; offset=0x34BD
       lea      r8, [rbp-0x208]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG253
       jmp      G_M000_IG258
 
G_M000_IG417:                ;; offset=0x34DA
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG254
 
G_M000_IG418:                ;; offset=0x34EB
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG419:                ;; offset=0x350F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG221
 
G_M000_IG420:                ;; offset=0x3520
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG221
 
G_M000_IG421:                ;; offset=0x3531
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG221
 
G_M000_IG422:                ;; offset=0x3542
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       jmp      G_M000_IG227
 
G_M000_IG423:                ;; offset=0x356E
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG424:                ;; offset=0x359C
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG231
 
G_M000_IG425:                ;; offset=0x35AE
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG234
 
G_M000_IG426:                ;; offset=0x35C2
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG237
 
G_M000_IG427:                ;; offset=0x35D4
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG243
 
G_M000_IG428:                ;; offset=0x35E6
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       test     al, al
       jne      SHORT G_M000_IG429
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG429:                ;; offset=0x3622
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG430:                ;; offset=0x3629
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG431:                ;; offset=0x3636
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG432
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG433
 
G_M000_IG432:                ;; offset=0x36B0
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG433:                ;; offset=0x36D6
       test     esi, esi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG434:                ;; offset=0x36E3
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x1CD40BDD648
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG435:                ;; offset=0x3703
       cmp      edx, 64
       je       G_M000_IG67
       cmp      edx, 67
       je       G_M000_IG67
       cmp      edx, 70
       jne      SHORT G_M000_IG434
       jmp      G_M000_IG67
 
G_M000_IG436:                ;; offset=0x371F
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG71
 
G_M000_IG437:                ;; offset=0x3734
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rbx+0x08]
       cmp      eax, r10d
       jae      G_M000_IG547
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x238]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG438:                ;; offset=0x37C5
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG439:                ;; offset=0x37EF
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r13d, dword ptr [rbx+0x08]
       cmp      eax, r13d
       jae      G_M000_IG547
       mov      ecx, eax
       mov      r13, gword ptr [rbx+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, r13
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG440:                ;; offset=0x387E
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG172
 
G_M000_IG441:                ;; offset=0x388F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG172
 
G_M000_IG442:                ;; offset=0x38A0
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r9, rax
       jmp      G_M000_IG172
 
G_M000_IG443:                ;; offset=0x38B1
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG444:                ;; offset=0x38DF
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG162
 
G_M000_IG445:                ;; offset=0x38F1
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG446:                ;; offset=0x3934
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x248]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG447:                ;; offset=0x39B1
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG448
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG158
 
G_M000_IG448:                ;; offset=0x39D7
       mov      rax, bword ptr [rbp+0xC58]
       cmp      dword ptr [rax+0x08], 0
       je       SHORT G_M000_IG451
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG451
 
G_M000_IG449:                ;; offset=0x3A00
       mov      rax, bword ptr [rbp+0xC58]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x280], xmm0
 
G_M000_IG450:                ;; offset=0x3A13
       lea      r9, [rbp-0x280]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG548
 
G_M000_IG451:                ;; offset=0x3A44
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x258]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG452:                ;; offset=0x3AC1
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG453:                ;; offset=0x3AC8
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG454:                ;; offset=0x3AD5
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       SHORT G_M000_IG457
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG455
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG456
 
G_M000_IG455:                ;; offset=0x3B4B
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG456:                ;; offset=0x3B71
       test     esi, esi
       je       G_M000_IG357
 
G_M000_IG457:                ;; offset=0x3B79
       mov      r10, bword ptr [rbp+0xC40]
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG458:                ;; offset=0x3B94
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       SHORT G_M000_IG457
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG548
 
G_M000_IG459:                ;; offset=0x3BEB
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG268
 
G_M000_IG460:                ;; offset=0x3C1D
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG548
 
G_M000_IG461:                ;; offset=0x3C33
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG143
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       jne      G_M000_IG143
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG547
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77F5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG143
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG143
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG143
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG462:                ;; offset=0x3D0A
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG457
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG463
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG464
 
G_M000_IG463:                ;; offset=0x3D4D
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG464:                ;; offset=0x3D73
       test     esi, esi
       jne      G_M000_IG457
       jmp      G_M000_IG357
 
G_M000_IG465:                ;; offset=0x3D80
       cmp      byte  ptr [rbp+0xB68], 0
       je       SHORT G_M000_IG468
 
G_M000_IG466:                ;; offset=0x3D89
       vmovdqu  xmm0, xmmword ptr [rbp+0xB58]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG467:                ;; offset=0x3D99
       lea      r9, [rbp-0x290]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG468:                ;; offset=0x3DC0
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG79
 
G_M000_IG469:                ;; offset=0x3DF7
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG470:                ;; offset=0x3DFE
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG471:                ;; offset=0x3E0B
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG457
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG472
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG473
 
G_M000_IG472:                ;; offset=0x3E85
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG473:                ;; offset=0x3EAB
       test     esi, esi
       jne      G_M000_IG457
       jmp      G_M000_IG357
 
G_M000_IG474:                ;; offset=0x3EB8
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x1CD40BDD5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG475:                ;; offset=0x3ED8
       mov      rcx, rdx
       mov      edx, r11d
       mov      r11, 0x7FF9D70A2940
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG84
 
G_M000_IG476:                ;; offset=0x3EFA
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      ebx, eax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG87
 
G_M000_IG477:                ;; offset=0x3F15
       xor      rcx, rcx
       jmp      G_M000_IG95
 
G_M000_IG478:                ;; offset=0x3F1C
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG96
       mov      gword ptr [rbp-0x260], rax
       jmp      G_M000_IG101
 
G_M000_IG479:                ;; offset=0x3F3E
       lea      r8, [rbp-0x260]
       mov      rdx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG96
       jmp      G_M000_IG101
 
G_M000_IG480:                ;; offset=0x3F5D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG97
 
G_M000_IG481:                ;; offset=0x3F6E
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG482:                ;; offset=0x3F92
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG103
 
G_M000_IG483:                ;; offset=0x3F9B
       xor      rcx, rcx
       jmp      G_M000_IG125
 
G_M000_IG484:                ;; offset=0x3FA2
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG126
       mov      gword ptr [rbp-0x268], rax
       jmp      G_M000_IG131
 
G_M000_IG485:                ;; offset=0x3FC4
       lea      r8, [rbp-0x268]
       mov      rdx, gword ptr [rbp-0x2F0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG126
       jmp      G_M000_IG131
 
G_M000_IG486:                ;; offset=0x3FE7
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG127
 
G_M000_IG487:                ;; offset=0x3FF8
       mov      rcx, r15
       mov      edx, r13d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG488:                ;; offset=0x401F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG106
 
G_M000_IG489:                ;; offset=0x4030
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG106
 
G_M000_IG490:                ;; offset=0x4041
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG106
 
G_M000_IG491:                ;; offset=0x4052
       mov      rcx, r15
       mov      edx, r13d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, edi
       mov      rcx, r15
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       jmp      G_M000_IG112
 
G_M000_IG492:                ;; offset=0x4081
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      rcx, rdi
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG493:                ;; offset=0x40AF
       mov      rdx, r14
       mov      rcx, 0x7FF9D776AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      G_M000_IG114
 
G_M000_IG494:                ;; offset=0x40C6
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp+0xAA8]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rsi+0x18]
       mov      rcx, rax
       mov      rdx, r13
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG115
       mov      rdx, gword ptr [rbp+0xAA8]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG495
       jmp      G_M000_IG553
 
G_M000_IG495:                ;; offset=0x4129
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA8]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG496:                ;; offset=0x4139
       lea      r9, [rbp-0x290]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG497:                ;; offset=0x4160
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG90
 
G_M000_IG498:                ;; offset=0x4178
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG90
 
G_M000_IG499:                ;; offset=0x4190
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG90
 
G_M000_IG500:                ;; offset=0x41A8
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1CD40BDAC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG501:                ;; offset=0x41D6
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D7500AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG502
       jmp      G_M000_IG553
 
G_M000_IG502:                ;; offset=0x41F9
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D76B9D18
       call     CORINFO_HELP_CHKCASTCLASS
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG142
 
G_M000_IG503:                ;; offset=0x423F
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp+0xA90]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG328
       cmp      gword ptr [rbp+0xA90], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xA90]
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG142
 
G_M000_IG504:                ;; offset=0x42B4
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7895AD0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG505
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG506
 
G_M000_IG505:                ;; offset=0x42D6
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG506:                ;; offset=0x42FB
       test     eax, eax
       je       G_M000_IG142
       jmp      G_M000_IG140
 
G_M000_IG507:                ;; offset=0x4308
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7895AD0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG509
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG508
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG508:                ;; offset=0x433E
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG141
 
G_M000_IG509:                ;; offset=0x4347
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG141
 
G_M000_IG510:                ;; offset=0x436B
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG79
 
G_M000_IG511:                ;; offset=0x4384
       mov      rdx, r14
       mov      rcx, 0x7FF9D74947C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG512
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG512:                ;; offset=0x43C0
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70A29D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG513:                ;; offset=0x43DD
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rsi
       mov      r9d, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [r10]
       test     rsi, rsi
       je       G_M000_IG358
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG514
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG515
 
G_M000_IG514:                ;; offset=0x4475
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D70A29D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG515:                ;; offset=0x4499
       test     ebx, ebx
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG516:                ;; offset=0x44A6
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG145
 
G_M000_IG517:                ;; offset=0x44AF
       xor      rcx, rcx
       jmp      G_M000_IG280
 
G_M000_IG518:                ;; offset=0x44B6
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG281
       mov      gword ptr [rbp-0x270], rax
       jmp      G_M000_IG283
 
G_M000_IG519:                ;; offset=0x44D8
       lea      r8, [rbp-0x270]
       mov      rdx, r13
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG281
       jmp      G_M000_IG283
 
G_M000_IG520:                ;; offset=0x44F7
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG282
 
G_M000_IG521:                ;; offset=0x4508
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG522:                ;; offset=0x452C
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r15, rax
       jmp      G_M000_IG152
 
G_M000_IG523:                ;; offset=0x4558
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG524:                ;; offset=0x455F
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG525:                ;; offset=0x456C
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG526
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG527
 
G_M000_IG526:                ;; offset=0x45FA
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG527:                ;; offset=0x4620
       test     esi, esi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG528:                ;; offset=0x462D
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG328
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG154
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG529:                ;; offset=0x4656
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG530:                ;; offset=0x4663
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG358
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG531
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG532
 
G_M000_IG531:                ;; offset=0x46F1
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG532:                ;; offset=0x4717
       test     esi, esi
       jne      G_M000_IG358
       jmp      G_M000_IG357
 
G_M000_IG533:                ;; offset=0x4724
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG154
       jmp      G_M000_IG328
 
G_M000_IG534:                ;; offset=0x473E
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, r9
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG535
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG328
 
G_M000_IG535:                ;; offset=0x4780
       cmp      byte  ptr [rbp+0xC38], 0
       je       SHORT G_M000_IG536
       mov      rdx, rbx
       mov      rcx, 0x7FF9D77F9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG537
 
G_M000_IG536:                ;; offset=0x47A0
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG537:                ;; offset=0x47CD
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG538:                ;; offset=0x47D4
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2B0], ymm0
 
G_M000_IG539:                ;; offset=0x47E1
       lea      r8, [rbp-0x2B0]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG457
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7856388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG540
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG541
 
G_M000_IG540:                ;; offset=0x485D
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70A29F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG541:                ;; offset=0x4883
       test     esi, esi
       jne      G_M000_IG457
       jmp      G_M000_IG357
 
G_M000_IG542:                ;; offset=0x4890
       cmp      esi, 49
       je       G_M000_IG81
       cmp      esi, 57
       je       G_M000_IG81
       cmp      esi, 58
       je       G_M000_IG81
       jmp      G_M000_IG328
 
G_M000_IG543:                ;; offset=0x48B0
       movzx    rax, byte  ptr [rbp+0xC38]
       test     al, al
       je       G_M000_IG158
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG158
       xor      rdx, rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], rdx
       mov      word  ptr [r10+0x08], 0
       movzx    rdx, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], dl
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG548
 
G_M000_IG544:                ;; offset=0x4903
       mov      rdx, bword ptr [rbp+0xA78]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp+0xA80]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG545
       vmovups  ymm0, ymmword ptr [reloc @RWD292]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD324]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp+0xA70]
       add      ecx, 27
       mov      dword ptr [rbp+0xA70], ecx
       jmp      SHORT G_M000_IG546
 
G_M000_IG545:                ;; offset=0x4954
       lea      rcx, [rbp+0xA60]
       mov      rdx, 0x1CD40BE2A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG546:                ;; offset=0x496B
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA60]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72CA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, [rbp+0xA60]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG547:                ;; offset=0x49B6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG548:                ;; offset=0x49BC
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG549:                ;; offset=0x49C2
       vzeroupper 
       add      rsp, 0xF18
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG550:                ;; offset=0x49D9
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG07
 
G_M000_IG551:                ;; offset=0x49EF
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG07
 
G_M000_IG552:                ;; offset=0x4A00
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
       jmp      SHORT G_M000_IG555
 
G_M000_IG553:                ;; offset=0x4A14
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG557
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG554:                ;; offset=0x4A48
       mov      rax, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       jl       G_M000_IG06
       jmp      SHORT G_M000_IG558
 
G_M000_IG555:                ;; offset=0x4A64
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG556:                ;; offset=0x4A89
       vzeroupper 
       add      rsp, 0xF18
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG557:                ;; offset=0x4AA0
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG558:                ;; offset=0x4AA9
       mov      eax, 1
 
G_M000_IG559:                ;; offset=0x4AAE
       vzeroupper 
       add      rsp, 0xF18
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG560:                ;; offset=0x4AC5
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG561:                ;; offset=0x4ACB
       sub      rsp, 72
 
G_M000_IG562:                ;; offset=0x4ACF
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG564
 
G_M000_IG563:                ;; offset=0x4ADC
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG564:                ;; offset=0x4AE2
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG567
 
G_M000_IG565:                ;; offset=0x4B06
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG548
 
G_M000_IG566:                ;; offset=0x4B17
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG567:                ;; offset=0x4B1F
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG568:                ;; offset=0x4B30
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG569:                ;; offset=0x4B38
       sub      rsp, 72
 
G_M000_IG570:                ;; offset=0x4B3C
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG572
 
G_M000_IG571:                ;; offset=0x4B6A
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG572:                ;; offset=0x4B70
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG573:                ;; offset=0x4B81
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000032A4h ; case G_M000_IG407
       	dd	0000061Ah ; case G_M000_IG65
       	dd	000000CEh ; case G_M000_IG08
       	dd	000024D9h ; case G_M000_IG326
       	dd	00001E1Bh ; case G_M000_IG277
       	dd	000036AFh ; case G_M000_IG437
       	dd	00001DA5h ; case G_M000_IG274
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001CCBh ; case G_M000_IG268
       	dd	00001CCBh ; case G_M000_IG268
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	00001D2Ch ; case G_M000_IG269
       	dd	0000179Bh ; case G_M000_IG217
       	dd	0000179Bh ; case G_M000_IG217
       	dd	00003740h ; case G_M000_IG438
       	dd	00001317h ; case G_M000_IG175
       	dd	000027FCh ; case G_M000_IG349
       	dd	0000376Ah ; case G_M000_IG439
       	dd	000011DAh ; case G_M000_IG168
       	dd	000010F6h ; case G_M000_IG159
       	dd	0000386Ch ; case G_M000_IG445
       	dd	000038AFh ; case G_M000_IG446
       	dd	0000392Ch ; case G_M000_IG447
       	dd	000010D8h ; case G_M000_IG157
       	dd	000010D8h ; case G_M000_IG157
       	dd	000010D8h ; case G_M000_IG157
       	dd	0000109Eh ; case G_M000_IG155
       	dd	0000109Eh ; case G_M000_IG155
       	dd	0000109Eh ; case G_M000_IG155
       	dd	000010D8h ; case G_M000_IG157
       	dd	00000F79h ; case G_M000_IG144
       	dd	00000F0Eh ; case G_M000_IG143
       	dd	00000827h ; case G_M000_IG83
       	dd	00003B66h ; case G_M000_IG459
       	dd	000045A8h ; case G_M000_IG528
       	dd	0000469Fh ; case G_M000_IG533
       	dd	000007F5h ; case G_M000_IG82
       	dd	000007F5h ; case G_M000_IG82
       	dd	000007F5h ; case G_M000_IG82
       	dd	000007A5h ; case G_M000_IG80
       	dd	000046B9h ; case G_M000_IG534
       	dd	00003B0Fh ; case G_M000_IG458
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000007A5h ; case G_M000_IG80
       	dd	000010E7h ; case G_M000_IG158
       	dd	00002E52h ; case G_M000_IG387
       	dd	00003069h ; case G_M000_IG396
       	dd	000007A5h ; case G_M000_IG80
       	dd	00002985h ; case G_M000_IG359
       	dd	00002985h ; case G_M000_IG359
       	dd	00002985h ; case G_M000_IG359
       	dd	00002985h ; case G_M000_IG359
       	dd	00002985h ; case G_M000_IG359
       	dd	00000769h ; case G_M000_IG78
       	dd	00003BAEh ; case G_M000_IG461
       	dd	00002B61h ; case G_M000_IG369
       	dd	00002C88h ; case G_M000_IG375
       	dd	0000245Dh ; case G_M000_IG325
RWD292 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD324 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 19337

