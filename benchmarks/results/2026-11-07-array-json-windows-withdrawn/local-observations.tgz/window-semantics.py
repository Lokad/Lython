import json, re
p = json.loads(document)
v = p['text']
print(repr(v), len(v), len(v.encode('utf-8')))
print(repr(v[1]), repr(v[-1]), repr(v[::-1]))
print(repr(v.strip().lower()), repr(v.replace(p['piece'], 'X')), repr(v * 2))
print(hash(v) == hash('é😀Ab c  '), {v: 7}['é😀Ab c  '])
m = re.search(p['pattern'], v)
print(m.span(), m.groupdict())
print(repr(re.sub(p['pattern'], r'<\g<g>>', v)))
print(json.dumps(p, ensure_ascii=False))
