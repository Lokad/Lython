from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
import xml.etree.ElementTree as E
r=Path(__file__).parent;prior=r.parent/'compiler-graph-r58'
old='compiler-graph-b415-20261107';name='array-json-b416-20261107'
def adapt(s):return s.replace(old,name)
def save(filename,s):
    if filename.endswith('.py'):ast.parse(s)
    (r/filename).write_text(s,encoding='utf-8',newline='\n')
checks={}
for label in ['prototype-internal-net11','prototype-public-net11','prototype-internal-net10','prototype-public-net10']:
    c=E.parse(r/(label+'.trx')).find('.//{*}Counters').attrib
    assert int(c['failed'])==0;checks[label]=dict(c)
(r/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
local=json.loads((r/'comparison-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in local['productionSources'].items())
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest()==local['coreSHA256']['candidate']
shutil.copyfile(r/'candidate-core.dll',r/'current-core.dll')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
ids=['scripts.report-render.large','scripts.json-summary-helpers.large','scripts.csv-summary-functions.large','scripts.text-summary-helpers.large']
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==cid)for cid in ids]
(r/'representative.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
jobs=[(cid,'warm')for cid in ids]
s=adapt((prior/'collect.py').read_text(encoding='utf-8'))
a=s.index('jobs=');b=s.index('\nenv =',a)
s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
s=s.replace("labels=['reference','reference-control','candidate']","labels=['reference','reference-control','candidate','control']")
s=s.replace('targetBatchSeconds=.20, rounds=11','targetBatchSeconds=.15, rounds=7').replace('count*.20/max(seconds','count*.15/max(seconds').replace('for round in range(11):','for round in range(7):')
s=s.replace('R58 compiler graph source-pair confirmation, compile and fresh separate, warm text control','R60 complete JSON/report storage source pair with CSV/text controls; compilation excluded')
assert "'candidate','control'" in s
save('collect.py',s)
s=adapt((prior/'archive-owned.py').read_text(encoding='utf-8')).replace("len(r['jobs'])==5","len(r['jobs'])==4").replace('jobs=5','jobs=4').replace("'baseline-core.dll'","'reference/Lokad.Lython.dll'")
save('archive-owned.py',s);save('run.sh',adapt((prior/'run.sh').read_text(encoding='utf-8')))
identity=dict(sourceRevision='8937cf00 plus R60 array-window prototype',sourcePairBaseline='Fully qualified e66b8f72 runtime/8937cf00 receipt',
    coreSHA256={'reference':local['coreSHA256']['before'],'reference-control':local['coreSHA256']['before'],'candidate':local['coreSHA256']['candidate'],'control':local['coreSHA256']['candidate']},
    auxiliaryFiles=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=local['productionSources'],jobs=jobs,
    referenceVersion='Two independent unchanged R58 versus two independent R60 processes; no CPython refresh',
    included='Complete warm Run, mediated RAM-file I/O, full stdout/file validation and prior-result cleanup. Compilation/startup/staging/reset/transport/final cached teardown excluded. Normal0.4adapter.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
contract='''R60/B416 one bounded four-script confirmation after managed size and actual11/10 semantics/ownership/cancellation gates. Report/JSON affected, CSV/text controls; two independent baseline/two current normal-runtime processes. Unchanged maintained sources/fixtures/goldens/worker/optional0.4adapter.5s warmup/role/job,7rotated150ms rounds, normalGC/tiering; all adverse/process variation retained. No CPU prediction or fixed percentage veto. Complete warm invocation, mediated RAM I/O/full validation/prior-result cleanup; compile/startup/staging/reset/transport/final cached teardown excluded. Source/core/every auxiliary/actualReady identities, quiet endpoints, goldens/Closed/exit/join/emptyfixtures/unmount, persistent archive verified under lease and locally required. Guest fixtures only in owned separate128MiB tmpfs; at least256MiB persistent headroom after staging.180sowner+30sstop+30smargin; observe after240s, no early service query. Stop at retained/restored decision and debt; bounded refinement/correction only on stated new evidence. Original R54 failures/adverse data and R60 initial8test failures/desktop controls stay preserved.'''
(r/'contract.md').write_text(contract+'\n',encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,observeAfterSeconds=240),indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');t=p.read_text(encoding='utf-8').replace('actual net10 checks underway.','460internal/2496public pass per actual11/10; performance decision pending.')
t=t.replace('No active VM worker/mount presently.','B416 selected below; update only after its declared observation boundary.')
t += '\nB416 selected: report/JSON/CSV/text,2baseline/2current roles,5swarmup/role,\n7rotated150ms rounds.180sowner+30sstop+30smargin; observe240s. Persistent raw\nevidence, separately owned tmpfs fixtures,256MiB headroom and all declared gates.\n'
p.write_text(t,encoding='utf-8');shutil.copyfile(p,r/'pre-measurement-plan.md')
with tarfile.open(r/'payload.tgz','w:gz')as z:
    for filename in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','current-core.dll','focused.json','source.patch','contract.md','setup-contract.json','pre-measurement-plan.md']:z.add(r/filename,arcname=filename)
s=adapt((prior/'launch.py').read_text(encoding='utf-8'))
s=s.replace("reference=base/'invocation-setup-b414-20261107/candidate'","reference=base/'compiler-graph-b415-20261107/candidate'")
a=s.index(" for role,core in [");b=s.index(" (root/'cpython-worker.py')",a)
s=s[:a]+''' for role in ['reference','candidate']:
  target=root/role;shutil.copytree(reference,target,copy_function=os.link)
  if role=='candidate':
   (target/'Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',target/'Lokad.Lython.dll')
'''+s[b:]
s=s.replace('len(jobs)==5','len(jobs)==4').replace("len(r['jobs'])==5","len(r['jobs'])==4").replace('allFiveJobsValidated','allFourJobsValidated')
s=s.replace('lython-b415-compiler-graph-20261107','lython-b416-array-json-20261107').replace('compiler-graph-b415-launch.py','array-json-b416-launch.py').replace('lython-b415-fixtures','lython-b416-fixtures')
assert 'baseline-core.dll' not in s and "reference=base/'compiler-graph-b415-20261107/candidate'" in s
save('launch.py',s)
s=adapt((prior/'retrieve.py').read_text(encoding='utf-8')).replace('lython-b415-compiler-graph-20261107','lython-b416-array-json-20261107').replace("['jobs']==5","['jobs']==4")
save('retrieve.py',s)
print(json.dumps(dict(focused=checks,payloadBytes=(r/'payload.tgz').stat().st_size,cores=identity['coreSHA256'],jobs=jobs)))
