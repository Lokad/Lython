from pathlib import Path
import shutil
p=Path('PLAN.md');r=Path(__file__).parent
shutil.copyfile(p,r/'plan-before-condensation.md')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another experiment or completed qualification does not complete this objective.

## Actual delivery status

| Item | State / remaining work |
| --- | --- |
| Committed core through R58/e66b8f72 | FULLY QUALIFIED CI42404834827: Windows/Ubuntu Release actual.NET11/10, original Stress and installed consumers. Receipt8937cf00. Terminal/cached; never query again. Later HEAD8937cf00 adds evidence only. |
| R57/4885d9c0 | Product working admission held through result transfer; early-cancellation and integer/bool start fixes. Included in the completed core delivery. |
| R58/e66b8f72 | Dense executable graph construction replaces repeated jump walks/sets/sorting/map. Included in completed delivery. Modest compile elapsed/allocation benefit; warm/CPU uncertainty remains. |
| R59/6db4a268 | Immutable dev54 compatibility:86internal/514public per actual11/10. Normal optional0.4pin/core unchanged. Development evidence, not released-adapter/performance/safety certification. |
| R60 | ACTIVE UNCOMMITTED array-window prototype, two production files.460internal/2496public net11 pass; actual net10 checks underway. No retention decision/full delivery yet. |

[Current core receipt](benchmarks/results/2026-11-07-executable-graph/delivery-ci.json).
All earlier terminal receipts remain final; do not repeat unchanged qualification
or query old runs. Current local binaries may contain R60: never call them the
qualified e66b8f72 bits. Source inventories/frozen cores distinguish these states.

## Completed milestones and remaining measurement limits

- Shared compiler-fact correction removes exponential inferred-value traversal;
  direct UTF-8 formatting/storage and native helper-return work are fully qualified.
  Returns reduce allocation19.92/19.31%; earlier elapsed gains remain diagnostic.
  Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original adverse
  15.125ms remains unexplained/preserved. No unchanged qualification campaign.
- R20/R25 CSV shared keys/completed value transfer supersede the rigidly rejected
  bulk constructor. Allocation−7.31/6.55%, native warm−7.72–8.04%, mixed controls.
  No automatic revival of the old implementation. Current calls already use native
  helpers, direct operands/final slots, deferred contexts and reused workspaces.
- R49 namespace publication/shared binding facts, R50 native UInt128 text parsing,
  R51 UTF-8 wildcard translation and R53 admission-publication correctness remain.
  Their gains and adverse controls are in the linked history, not new tasks.
- R54 ROM input windows were entirely withdrawn: wrapper+8B, ordinary controls
  +3–4.5%, report allocation about−5%, no substantial CPU improvement established.
  R55 deletes the lexical nesting prepass and corrects valid f-strings; fully
  qualified, no CPU gain claimed. Neither result permanently prohibits new designs.
- R56 config attribution:551guest samples/2.91CPU seconds; builtin construction17,
  context29 inclusive versus substantial host open/path work. No new lazy-builtin
  subsystem justified; preserve run-owned type/descriptor identity and capability
  checks. The host-validation asymmetry is documented; no wall-I/O decomposition.
- R57 deletes the premature product guard/refund, second admission and unused
  counters. Matrix-product allocation−7.8/−7.2%, adverse/unstable desktop clocks.
  R58 compile allocation−3.9–5.9%, controlled compile elapsed−1.7–3.0%; fresh config
  −0.6–1.6%, warm text−2.84to+1.49%/4.26%old spread, externalCPU mixed/adverse.
  Retain coherent corrections/replacement; no CPU/warm gain or debt repayment claim.

Evidence: [current guide](docs/BENCHMARKS.md), [experimental history](benchmarks/EXPERIMENTS.md),
[R54](benchmarks/results/2026-11-07-json-input-windows/README.md),
[R56](benchmarks/results/2026-11-07-invocation-setup/README.md),
[R57](benchmarks/results/2026-11-07-product-admission/README.md),
[R58](benchmarks/results/2026-11-07-executable-graph/README.md).
Older details/pre-condensation plans stay with immutable evidence/private notes.

## Active R60 — shared JSON storage without a general wrapper penalty

Hypothesis: eliminate plain-token backing allocations without R54's eight-byte
cost on every string. Byte array + length + one storage-start state replaces ROM
windows/separate owned-byte count. Zero owns the backing,−1 retains it for the
batch, positive values locate a view. Remove the separate hash-ready flag: publish
one atomic hash; numeric zero stays zero and can recompute. No tagged guest values,
unsafe layout tricks, new owner/cache/ledger/collector or alternate parser.

Contract: share only input already owned by this execution governor. Retain the
complete backing/header through batch cleanup before callbacks can refund the
source shell; pre-admit every view header. Copy other-owner/unowned input and
escaped strings. A small view can retain a large document and reject earlier;
conservative retention is explicit, not arbitrary-withdrawal reclamation. Internal
FromOwnedUtf8 transfers its array; mutating it afterward violates that ownership.
Public/host input independence, result projection and escaping aliases remain.

Proven so far: managed empty/nonempty allocations80/88B, same as current versus
R54's88/96B.16hash-cancellation checks, then460internal/2496public net11 pass.
Initial8failures/203pass remain: unowned-input fixtures replace invalid mutation
after ownership transfer; denial gates now refuse actual output storage rather
than an obsolete copied-payload size. Preserve refusal/side-effect/cleanup checks.
Strengthen surviving-window funding to include both backing and surviving shell.
Independent CPython goldens cover Unicode/indexing/reverse/hash/replace/repeat,
JSON output and regex patterns/subjects stored at nonzero offsets, both APIs.

One unchanged-tool10job diagnostic passes goldens/isolation/funding/cleanup:
JSON allocation−5.049/−5.041%, report−6.972/−7.056%, controls within0.007%.
Admitted root peaks fall JSON145,482B/report243,823B; other peaks unchanged.
Desktop elapsed includes adverse text+22.10% and old spreads up to15.47%; no CPU
claim. Source/core inventories and original failed/adverse conditions are retained.

Next acceptance: actual10 focused checks, then one controlled complete-script
comparison: report/JSON affected, CSV/text controls, two baseline/two current
processes, normal0.4auxiliaries,5s warmup/role,7rotated150ms rounds on quiet VM.
180sowner+30sstop+30smargin; observe after240s. Require256MiB staging headroom,
actual source/core/Ready/goldens/quiet/Closed/exit/join/fixture cleanup, persistent
archive verified under lease and locally. Retain all process variation/adverse data.
Then decide retained/restored source and remaining regression debt. Bounded
confirmation/refinement is allowed when justified; no automatic percentage veto.
If retained, update current ownership docs and batch full platform/Stress/installed
consumers at this coherent representation boundary, while continuing other work.

## Following performance roadmap

Refresh representative CPython comparisons at the next retained coherent runtime
checkpoint, separating compile, warm and compile-to-result. B409 is already complete
on frozen55e510ff: seven scripts plus two labeled numeric-input warm cases, I/O/
validation/prior-result cleanup included, staging/startup excluded. Current guide
must keep that revision; do not relabel as HEAD. Startup, pending-I/O, RSS and
embedding-tail latency remain unmeasured. No primary refresh after every tweak.

Select one substantial removable phase using current source and phase evidence.
Each redesign must name eliminated work/storage, affected complete scripts,
semantic/token/admission acceptance, displaced code to remove, comparison and
regression-debt decision. A justified redesign can temporarily regress until its
explicit completion milestone; do not accumulate narrow special cases.

| Boundary | Decision / stopping condition |
| --- | --- |
| Complete call/frame construction | Ordinary CSV/report functions and text helpers. Existing native returns, borrowed operands/final slots, lazy namespaces/deferred contexts/workspace reuse are already delivered. R52 binding13self/rent3/frame3 do not establish dominant packaging; inclusive samples overlap. Select only a remaining material phase. Preserve defaults/keywords/variadics/closures/recursion/evaluation order/errors/suspension/retained borrows. |
| Scalars/remaining text | Exact public BigInteger results and ingress CLR round trips constrain casual boxed-long replacement. Scalar sum already uses native accumulation; casing/splitting/final formatting are already UTF-8. R42add41samples alone does not justify universal tagged slots. R60 is the selected token-storage redesign; retain Unicode/hash/identity and exact promotion before further conversion work. |
| Per-record construction | Shared CSV/JSON keys and CSV value transfer exist. Choose only a real remaining copy/capacity phase; preserve hooks/order/reentry/mutation/aliases/overlap. R46 CLR-versus-radix regressions and R54 wrapper lesson remain. |
| Frontend/operand transport | R55/R58 remove duplicate lexical/graph work. Parsing/static binding are material in historical attribution; LoweredScript alone2.6–3.0% does not establish a general compiler rewrite. Select actual repeated analysis/representation, preserve dead-scope diagnostics/annotations/imports/generators. R43 already reduces transport; further changes need new evidence, not replay of slower call-arena/call-control designs. |

After R60's decision, use existing current captures first. One focused current
text/report attribution is justified only where this representation materially
changes the cost boundary and old captures cannot select a design. Stop after a
specific removable phase is selected or uncertainty recorded; no broad sweep or
unmeasured saved-CPU prediction. General performance work continues independently.

## Independent regex track

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original
windows, flags/captures/replacements/errors, explicit cache ownership and current
tokens. No Utf8Regex runtime dependency. Optional nonpackable adapter stays0.4.0.
R59 exact unpublished0.5.0-dev.54/553acbdf with the existing dev bridge passes
86internal/514public per actual11/10; [evidence](benchmarks/results/2026-11-07-regex-dev54/README.md).
DetailedData still lacks distinct preparation/working-owner input; native UTF-8
name lookup lacks enumeration; cursor creation retains its token despite current-
move overloads. Keep adapter-local bridges/conservative funding, not core plumbing.
No new source redesign or backend speedup established merely by its version.
Qualify a supported immutable released input and managed safety separately; missing
publication/APIs defer only affected final adapter qualification. No sibling edits,
dialect fallback, quotas, new memory management or abandoned background matching.

## Iteration and delivery constraints

Timeouts/unstable unchanged controls/inconclusive clocks establish uncertainty,
not failed designs. Allow bounded confirmation/refinement/measurement correction
with explicit scope and retained original failed/adverse conditions. Percentages
inform decisions, not automatic vetoes. Distinguish simplification, allocation,
controlled elapsed and demonstrated CPU. Existing tools; no new benchmark framework.

Focused Release with explicit Category!=Stress during iteration, actual11 normally,
actual10 at coherent checkpoints; build matching probes before dependent checks.
No overlapping local builds/tests/measurements. Batch full Windows/Ubuntu, both
targets, original Stress and installed-package consumers; continue while CI runs,
status checks≥5minutes apart, cache terminal results. Never relax timeouts/assertions.
After restoring source timestamps, force a nonincremental build before --no-build.

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host capability
mediation, effective cooperative cancellation, borrowed shared allowance with
conservative preflights/overlap/retained aliases and deterministic awaited cleanup.
First refused admission terminates the command. No unsafe/Unsafe/PInvoke/native
probes, fuel/quotas/caps/hidden allowance, tracing/weak reclamation or forced GC.
Initial bounded streams use host-driven batches; XML depth remains. Explicit UTF-8.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B415 terminal/archived/
locally verified; never service-query again. No active VM worker/mount presently.
Declare owner/stop/margin before collecting; keep raw records/workers persistent,
guest fixtures separately owned in RAM, archive/verify under lease before removal,
join all users and verify locally. Retain adverse/missing evidence. PLAN stays
ignored; docs remain concise current guides, history belongs behind evidence links.
''',encoding='utf-8')
print('Condensed active plan to',len(p.read_text(encoding='utf-8').splitlines()),'lines; old plan preserved privately.')
