from pathlib import Path
import subprocess
r=Path(__file__).parent
document='{"text":"é😀Ab c  ","piece":"😀","pattern":"(?P<g>😀A)"}'
source=r'''import json, re
p = json.loads(document)
v = p['text']
print(repr(v), len(v), len(v.encode('utf-8')))
print(repr(v[1]), repr(v[-1]), repr(v[::-1]))
print(repr(v.strip().lower()), repr(v.replace(p['piece'], 'X')), repr(v * 2))
print(hash(v) == hash('é😀Ab c  '), {v: 7}['é😀Ab c  '])
m = re.search(p['pattern'], v)
print(m.span(), m.groupdict())
print(repr(re.sub(p['pattern'], r'<\g<g>>', v)))
print(json.dumps(p, ensure_ascii=False))
'''
(r/'window-semantics.py').write_text(source,encoding='utf-8')
(r/'python-window-semantics.py').write_text('document='+repr(document)+'\n'+source,encoding='utf-8')
p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(r/'python-window-semantics.py')],capture_output=True,check=True)
output=p.stdout.decode('utf-8').replace('\r\n','\n')
(r/'python-window-stdout.txt').write_text(output,encoding='utf-8')
print(ascii(output))
