from pathlib import Path
import hashlib,json,shutil,statistics,subprocess,tarfile
import xml.etree.ElementTree as E
r=Path(__file__).parent
dest=Path('benchmarks/results/2026-11-07-array-json-windows-withdrawn');dest.mkdir(exist_ok=True)
qualified=json.loads((r.parent/'compiler-graph-r58/identity.json').read_text(encoding='utf-8'))
raw=[];normalized=[]
for name,digest in qualified['productionSources'].items():
    p=Path(name)
    if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raw.append(name)
    tracked=subprocess.check_output(['git','show','e66b8f72:'+name])
    if p.read_bytes().replace(b'\r\n',b'\n')!=tracked.replace(b'\r\n',b'\n'):normalized.append(name)
assert not normalized
assert raw==['src/Lokad.Lython/Runtime/Text/PyString.cs']
assert Path('src/Lokad.Lython/Runtime/Text/PyString.cs').read_bytes().replace(b'\r\n',b'\n')==(r/'baseline-PyString.cs').read_bytes().replace(b'\r\n',b'\n')
checks={}
for label in ['restored-internal-net11','restored-public-net11','restored-internal-net10','restored-public-net10']:
    c=E.parse(r/(label+'.trx')).find('.//{*}Counters').attrib
    assert int(c['failed'])==0;checks[label]=dict(c)
restored=dict(qualifiedGitSource='e66b8f72',comparedSources=len(qualified['productionSources']),normalizedSourceDifferences=normalized,
    checkoutLineEndingDifferences=raw,nonincrementalCoreBuildsCompleted=True,checks=checks,cores={})
for framework in ['net11.0','net10.0']:
    p=Path('src/Lokad.Lython/bin/Release')/framework/'Lokad.Lython.dll'
    assert p.read_bytes()==(Path('tools/LythonProbe/bin/Release')/framework/'Lokad.Lython.dll').read_bytes()
    restored['cores'][framework]=hashlib.sha256(p.read_bytes()).hexdigest()
(r/'restoration.json').write_text(json.dumps(restored,indent=2)+'\n',encoding='utf-8')
local={}
for phase in ['warm-sync','warm-async']:
    data=json.loads((r/phase/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    rows=[]
    for o in data['observations']:
        roles={role:{k:statistics.median(s[k]/s['jobs']for s in o['samples']if s['image']==role)for k in ['elapsedMilliseconds','allocatedBytes']}for role in ['before','candidate','before-control']}
        a,c,b=[roles[k]for k in ['before','candidate','before-control']]
        rows.append(dict(case=o['caseId'],roles=roles,allocationPercent=100*(c['allocatedBytes']/a['allocatedBytes']-1),
            elapsedPercent=[100*(c['elapsedMilliseconds']/v['elapsedMilliseconds']-1)for v in [a,b]],
            oldElapsedSpreadPercent=100*(b['elapsedMilliseconds']/a['elapsedMilliseconds']-1),admittedPeaks=o['admittedPeaks']))
    local[phase]=rows
(r/'local-assessment.json').write_text(json.dumps(local,indent=2)+'\n',encoding='utf-8')
for variant,source in [('first',r),('refined',r/'b417')]:
    folder=dest/variant;folder.mkdir(exist_ok=True)
    for name in ['observations.tgz','archive-receipt.json','identity.json','contract.md','assessment.json','terminal-status.json']:
        shutil.copyfile(source/name,folder/name)
    receipt=json.loads((folder/'archive-receipt.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['decision.json','restoration.json','local-assessment.json','source-contract.md','refined-wrapper-allocations.json','plan-before-condensation.md']:
    shutil.copyfile(r/name,dest/name)
archive=dest/'local-observations.tgz'
with tarfile.open(archive,'w:gz')as t:
    for p in r.iterdir():
        if p.is_file() and (p.suffix in ['.py','.cs','.patch','.log','.trx','.json','.md','.txt'] or p.name in ['layout-core.dll','initial-full-core.dll']):t.add(p,arcname=p.name)
    for directory in ['source-refined','warm-sync','warm-async']:t.add(r/directory,arcname=directory)
    for name in ['refined-internal-net11.trx','refined-public-net11.trx','refined-internal-net10.trx','refined-public-net10.trx']:
        assert (r/name).exists()
(dest/'local-archive-receipt.json').write_text(json.dumps(dict(archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),allPrototypeAndRestorationLogsPreserved=True,productionRestored=True,publicationPostponed=True),indent=2)+'\n',encoding='utf-8')
(dest/'README.md').write_text('''# Array-backed JSON input windows — R60 withdrawn

2026-11-07. **Entire production prototype withdrawn.** Qualified core sourcee66b8f72
is restored; no view constructor/storage-start field/borrow method/hash-cache
replacement survives. Architecture-specific native tests are deleted and original
copy/denial assertions restored. Keep one independent public decoded-text/regex/
Unicode interoperability case with shared-budget reuse under both APIs.

R54's ROM design added8B to every string. This different layout combines an array,
length and storage-start state (owned/batch-retained/view), removing the separate
hash-ready flag. Atomic zero hashes remain zero and can recompute. Managed empty/
nonempty construction80/88B matches baseline, versus R54's88/96B. Full immutable
input backing/header remains funded through batch lifetime before source-shell
refunds; view metadata is admitted; other-owner/unowned input/escapes copy.
No tracing, ledger, new owner, unsafe code, quotas or forcedGC. Small views can
retain large input until batch end, allowing conservative earlier denial.

First8failures/203pass preserve old copy-size denial fixtures and mutation after
internal FromOwnedUtf8 ownership transfer. Revised unowned-input independence,
real output denial and source/view/nested-view/refusal/reentry checks preserve
funding; strengthen surviving-shell plus full-backing funding. First and refined
variants pass460internal/2496public per actual11/10. Independent CPython3.13.2
goldens combine JSON-decoded Unicode, indexing/reversal/hash/replace/repeat,
JSON output and runtime regex patterns/subjects/capture offsets. This does not
justify an API/ownership tradeoff without complete workload measurements.

## Allocation and first controlled comparison

Baseline frozenaa133dcb; first992f53fa; refined8ad25a95. Exact sources/cores are
in the archives; precommit informational versions are not a source-equivalence
proof by themselves. Normal optional0.4 adapter/worker/fixtures stay unchanged.
An existing10job desktop diagnostic, both APIs separately, passes all complete
goldens, image/hash isolation, root funding and owned-fixture cleanup. First-variant
allocation JSON−5.049/−5.041%, report−6.972/−7.056%; controls within0.007%.
Root admitted peaks decrease145,482BJSON/243,823Breport; controls unchanged.
Desktop clocks are mixed/adverse: text reaches+22.10%, old spread15.47%. No CPU gain.

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/tiering. Two independent baseline/
two current processes;5s warmup/role/job,7rotated150ms rounds. Full warm invocation,
mediated RAM-file I/O, complete validation and prior-result cleanup included;
compile/startup/staging/reset/transport/final cached teardown excluded. All new/old
process pairings retained; positive means slower.

| Complete script | First B416 elapsed | Refined B417 elapsed |
| --- | ---: | ---: |
| JSON-to-Markdown report |−3.28to−0.84%|−3.40to−0.87%|
| JSON-lines helper summary |+0.28to+2.63%|+1.56to+7.31%|
| CSV helper control |+2.65to+3.07%|−1.07to+0.32%|
| Text helper control |−1.32to+2.79%|+0.57to+1.98%|

B416CSV has stable old/new spreads0.17/0.24%, motivating one source refinement:
explicit zero-offset span/memory construction for owned strings restores the
baseline bounds shape. This is a source hypothesis, not JIT causal attribution.
Sharing/ownership/profile/inputs/worker stay unchanged. Refined wrapper allocation
still80/88B; full script allocation was measured only on the first variant.

B417JSON has5.18%current-role spread despite within-role IQR0.34/0.41%; retain
that process variation and adverse+7.31%, not a claim of an exact7.31%regression.
Even its best pairing is+1.56%; text is consistently+0.57to+1.98%. Report's original
roleIQR4.17% and current1.89–2.37% qualify the modest gains. External whole-worker
CPU additionally includes reset/protocol/background work and remains mixed/adverse:
refined report−0.96to+2.08%, JSON+1.80to+9.36%, text+1.32to+1.83%.
No substantial CPU improvement or broad runtime gain is established.

Withdraw the representation:5–7%first-variant allocation savings and modest report
elapsed benefit do not justify global accessor/ownership state with JSON/text
regression debt. The refinement largely removes the CSV penalty; all original
points remain. This is a measured complete-cost decision, not a fixed threshold,
permanent rejection of sharing or completion of the whole-script objective.

Both runs pass source/core/every auxiliary/actualReady, goldens, quiet endpoints,
Closed/exit0/join/emptyfixtures/unmount and persistent archive verification under
lease and locally. B416114.231s/B417114.322s;180sowner+30stop+30margin each.
All users ended, no mount remains. Terminal/cached; never service-query again.
[First raw/source](first/observations.tgz), [refined raw/source](refined/observations.tgz),
[first assessment](first/assessment.json), [refined assessment](refined/assessment.json).

## Restored implementation

All561production files match the qualified Git source. One checkout changes only
LF toCRLF versus the older working snapshot. Forced nonincremental core builds
precede456internal/2496public PASS per actual11/10; matching probe core bytes agree.
New hashes include build metadata/checkouts and are not relabeled as earlier bits.
No repeat of unchanged full platform/package qualification is needed: completed
CI42404834827 remains final for the restored runtime. Publication is postponed.
[Restoration proof](restoration.json), [decision](decision.json),
[local sources/cores/failures/probes/raw clocks](local-observations.tgz),
[archive receipt](local-archive-receipt.json), [contract](source-contract.md).
Experimental contracts describe the removed prototype, not current Lython behavior.
''',encoding='utf-8')
history=Path('benchmarks/EXPERIMENTS.md')
history.write_text(history.read_text(encoding='utf-8')+'''
## Array-backed JSON windows withdrawn (2026-11-07)

[R60](results/2026-11-07-array-json-windows-withdrawn/README.md) avoids R54's8B
wrapper tax; first JSON/report allocation−5%/−7%, controls flat. Both variants
pass460internal/2496public per actual11/10, full backing/shell funding and tokens.
B416114.231s/allgates shows stable CSV+2.65to+3.07%; explicit owned zero-offset
refinement B417114.322s/allgates removes most CSV debt. Report−3.40to−0.87%,
JSON+1.56to+7.31%/5.18%current spread and text+0.57to+1.98% remain, workerCPU
mixed/adverse. Withdraw whole representation/architecture-only tests; retain
independent decoded-text interoperability. Exact qualified Git production restored,
forced core builds and456internal/2496public per actual11/10 pass. No prototype,
hash flag change, owner state or view helper remains. Preserve initial8failures,
all first/refined raw/source/cores and adverse points; no permanent ban/CPU claim
or objective completion. Terminal archivesa5b030a1/f47c89fa locally verified.
''',encoding='utf-8')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
a=text.index('| R60 |');b=text.index('\n',a)
text=text[:a]+'| R60 | WITHDRAWN entirely. Qualified Git runtime restored; forced core rebuilds and456internal/2496public per actual11/10 pass. Independent public interop coverage retained; evidence awaiting commit. |'+text[b:]
text=text.replace('Current local binaries may contain R60: never call them the\nqualified e66b8f72 bits. Source inventories/frozen cores distinguish these states.', 'Local binaries are fresh rebuilds of restored production; new build hashes are\nnot the older frozen bits. Source inventories/checkouts distinguish these states.')
a=text.index('## Active R60');b=text.index('## Following performance roadmap',a)
text=text[:a]+'''## R60 complete — representation withdrawn

No runtime prototype survives. Array windows avoided R54's general wrapper tax
and first JSON/report allocations fell5%/7%, with controls flat. Initial8failed
fixtures, both complete variants, conservative backing retention and all adverse
data remain in [R60 evidence](benchmarks/results/2026-11-07-array-json-windows-withdrawn/README.md).
B416stable CSV+2.65to+3.07% justified explicit owned-accessor refinement. B417
largely removes CSV debt, but report−3.40to−0.87%, JSON+1.56to+7.31%/5.18%current
spread and text+0.57to+1.98% remain; whole-workerCPU mixed/adverse. Added general
access/ownership state is not justified here. Not a fixed veto or permanent ban.
Both archives/gates complete, all users/mounts ended; never query B416/B417 again.
Forced restored core builds and456internal/2496public per actual11/10 pass;
independent decoded-text/regex/Unicode coverage stays. No unchanged full rerun.

## Next R61 — native token/record construction source gate

R52's material JSON string/construction/ownership work motivates a bounded source
assessment, without a new global string representation. Inspect current native
record capacity and token construction to identify an actual intermediate buffer,
copy or repeated admission stage that can disappear with existing reservations.
Valid escaped tokens already use UTF-8 CopyString, but stage output before an
exact final copy; source alone does not establish material complete-script cost.
First census existing representative fixtures/profiles for affected payloads and
check whether current record capacity facts can fund construction coherently.
Preserve independent result storage, retained capacity/replacement peaks, scopes,
hook/error order, current tokens and first refusal. Any direct final capacity
must state its retained-spare tradeoff before code. Avoid duplicate JSON parsing,
new memory infrastructure, global allowance retention or per-object accounting.
Stop after a file-scoped source/cost decision selects one complete removable phase
or records no justified candidate; then pursue the remaining roadmap. No broad
ownership audit or immediate new measurement campaign. A selected redesign needs
semantic/ownership/cancellation gates and a bounded complete-script pair/control.

'''+text[b:]
a=text.find('\nB416 selected:')
if a>=0:text=text[:a]+'\n'
text=text.replace('After R60\'s decision, use existing current captures first.', 'After the restored R60 decision, use existing current captures first.')
text=text.replace('R60 is the selected token-storage redesign;', 'R60\'s global-access lesson is preserved;')
text=text.replace('B385–B415 terminal','B385–B417 terminal').replace('B416 selected below; update only after its declared observation boundary.', 'No active VM worker/mount.').replace('B416 terminal/archived/locally verified; no service query. Refinement pending below.', 'No active VM worker/mount.')
p.write_text(text,encoding='utf-8')
print(json.dumps(dict(artifacts=str(dest),productionRestored=True,normalizedDifferences=normalized,checks=checks)))
