from pathlib import Path
import shutil
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Runtime/Text/PyString.cs')
s=p.read_text(encoding='utf-8')
def replace(old,new):
    global s
    assert old in s,old
    s=s.replace(old,new)
replace('    private int _storageStart = 0;', '''    // Zero owns the backing; -1 retains that backing for the batch. Positive
    // values are a view's byte start plus one, funded by that retained backing.
    private int _storageStart;''')
replace('        _byteLength = byteLength;', '        _byteLength = byteLength;\n        _storageStart = 0;')
replace('internal long CommittedOwnedBytes => EstimateApproximateBytes(_utf8.Length)',
    'internal long CommittedOwnedBytes => 96L + (_storageStart == 0 ? 32L + _utf8.Length : 0)')
for old,new in [
    ('Buffer.BlockCopy(_utf8, 0, result, 0, _byteLength);','Utf8Span.CopyTo(result);'),
    ('Buffer.BlockCopy(other._utf8, 0, result, _byteLength, other._byteLength);','other.Utf8Span.CopyTo(result.AsSpan(_byteLength));'),
    ('Buffer.BlockCopy(_utf8, 0, result, i * _byteLength, _byteLength);','Utf8Span.CopyTo(result.AsSpan(i * _byteLength));'),
    ('Buffer.BlockCopy(_utf8, start, result, offset, length);','Utf8Span.Slice(start, length).CopyTo(result.AsSpan(offset));'),
    ('Buffer.BlockCopy(_utf8, start, bytes, 0, length);','Utf8Span.Slice(start, length).CopyTo(bytes);'),
    ('Buffer.BlockCopy(_utf8, byteIndex, bytes, 0, runeLength);','Utf8Span.Slice(byteIndex, runeLength).CopyTo(bytes);'),
    ('_utf8[start]','Utf8Span[start]'),('_utf8[byteIndex]','Utf8Span[byteIndex]'),
    ('Utf8.GetString(_utf8, start, length)','Utf8.GetString(Utf8Span.Slice(start, length))'),
    ('_utf8.AsSpan(byteIndex, runeLength)','Utf8Span.Slice(byteIndex, runeLength)'),
    ('_utf8.AsSpan(offset, found)','Utf8Span.Slice(offset, found)')]:replace(old,new)
needle='    public PyString Concat(PyString other)'
replace(needle,'''    // Plain JSON tokens can share immutable input within the same execution.
    // Keep its full backing charged to the batch before a callback can refund
    // the source shell. Other owners still receive an independent copy.
    internal PyString BorrowUtf8Window(int start, int length, MemoryGovernor governor, LythonSourceSpan? span)
    {
        var window = Utf8Span.Slice(start, length);
        if (length == 0) return Empty;
        if (!ReferenceEquals(_memoryGovernor, governor))
            return CopyFromUtf8(window, governor, span);
        var storageStart = checked(ByteStart + start + 1);
        if (_storageStart == 0) _storageStart = -1;
        const long metadata = 96;
        governor.Reserve(metadata, span);
        try
        {
            var result = new PyString(_utf8, storageStart, length, governor);
            governor.Commit(metadata);
            return result;
        }
        catch { governor.ReleaseReserved(metadata); throw; }
    }

    private PyString(byte[] utf8, int storageStart, int length, MemoryGovernor governor)
    {
        _utf8 = utf8;
        _storageStart = storageStart;
        _byteLength = length;
        _memoryGovernor = governor;
    }

'''+needle)
p.write_text(s,encoding='utf-8')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs')
s=p.read_text(encoding='utf-8')
old='var value = existing ?? PyString.CopyFromUtf8(token.Span[1..^1], context.MemoryGovernor, span);'
assert old in s
s=s.replace(old,'var value = existing ?? input.BorrowUtf8Window(position + 1, token.Length - 2, context.MemoryGovernor, span);')
p.write_text(s,encoding='utf-8')
for name in ['JsonInputStorageOwnershipTests.cs']:
    source=r.parent/'json-input-storage-r54'/name
    if not source.exists():source=r.parent/'json-input-storage-r54/source-prototype'/name
    if source.exists():shutil.copyfile(source,Path('tests/Lokad.Lython.Tests')/name)
print('Full bounded array-window prototype applied; hash flag removed, views/retained root share one storage-start field. No test threshold changed yet.')
