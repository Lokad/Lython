from pathlib import Path
import json,statistics
r=Path(__file__).parent
d=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['complete'] and receipt['complete'] and len(d['jobs'])==4
rows=[]
for job in d['jobs']:
    roles={}
    for role in ['reference','reference-control','candidate','control']:
        ss=[s for s in job['samples']if s['engine']==role]
        times=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in ss]
        q=statistics.quantiles(times,n=4,method='inclusive')
        roles[role]=dict(seconds=statistics.median(times),iqrPercent=100*(q[2]-q[0])/statistics.median(times),
            aggregateExternalCpuSecondsPerInvocation=sum(s['externalProcessCpuTicks']/s['externalCpuFrequency']for s in ss)/sum(s['response']['completedInvocations']for s in ss),
            minimumBatchSeconds=min(s['response']['elapsedTicks']/s['response']['clockFrequency']for s in ss))
    baseline=[roles[k]for k in ['reference','reference-control']];current=[roles[k]for k in ['candidate','control']]
    elapsed=[100*(c['seconds']/b['seconds']-1)for c in current for b in baseline]
    cpu=[100*(c['aggregateExternalCpuSecondsPerInvocation']/b['aggregateExternalCpuSecondsPerInvocation']-1)for c in current for b in baseline]
    row=dict(case=job['case'],lane=job['lane'],roles=roles,elapsedPercentAllPairings=elapsed,
        externalCpuPercentAllPairings=cpu,oldSpreadPercent=100*(max(v['seconds']for v in baseline)/min(v['seconds']for v in baseline)-1),
        newSpreadPercent=100*(max(v['seconds']for v in current)/min(v['seconds']for v in current)-1))
    rows.append(row)
    print(job['case'],'elapsed range%',round(min(elapsed),2),round(max(elapsed),2),'old/current spread%',round(row['oldSpreadPercent'],2),round(row['newSpreadPercent'],2),'externalCPU%',round(min(cpu),2),round(max(cpu),2),'IQR%',*[round(roles[k]['iqrPercent'],2)for k in roles])
(r/'assessment.json').write_text(json.dumps(dict(complete=True,ownedSeconds=d['elapsedSeconds'],jobs=rows,
    limits='Whole-worker externalCPU additionally includes reset/protocol and background runtime work, not a pure guest CPU measurement. No percent acceptance gate; all process pairings and adverse evidence retained.',
    receipt=receipt),indent=2)+'\n',encoding='utf-8')
