from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
import xml.etree.ElementTree as E
r=Path(__file__).parent;n=r/'b417';n.mkdir()
old='array-json-b416-20261107';new='array-json-b417-20261107'
for filename in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py']:
    s=(r/filename).read_text(encoding='utf-8').replace(old,new)
    s=s.replace('lython-b416-array-json-20261107','lython-b417-array-json-20261107').replace('array-json-b416-launch.py','array-json-b417-launch.py').replace('lython-b416-fixtures','lython-b417-fixtures')
    if filename=='collect.py':s=s.replace('R60 complete JSON/report storage source pair','R60 refined owned-zero-offset accessor, complete JSON/report source pair')
    if filename.endswith('.py'):ast.parse(s)
    (n/filename).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',n/'current-core.dll')
shutil.copyfile(r/'representative.json',n/'representative.json')
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
digest=hashlib.sha256((n/'current-core.dll').read_bytes()).hexdigest()
identity['coreSHA256'].update(candidate=digest,control=digest)
identity['sourceRevision']='8937cf00 plus R60 refined owned/view span/memory accessors'
identity['productionSources']={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(part in ['bin','obj']for part in p.parts)}
identity['refinement']='B416 original preserved: report−3.28to−0.84%, JSON+0.28to+2.63%, stable CSV+2.65to+3.07%, text variable. Explicit owned zero-offset construction restores original bounds shape; no ownership/API/policy/profile/input/worker changes. Cause is a source hypothesis, not established JIT attribution.'
(n/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
checks={}
for label in ['refined-internal-net11','refined-public-net11']:
    c=E.parse(r/(label+'.trx')).find('.//{*}Counters').attrib
    assert int(c['failed'])==0;checks[label]=dict(c)
(n/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
(n/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
contract=identity['refinement']+' Same bounded four jobs/two baseline/two current normal runtime roles,5s warmup/role,7rotated150ms rounds. Every original adverse point retained, no automatic promotion/percentage veto. Full source/core/Ready/every auxiliary/golden/quiet/Closed/exit/join/ownedfixture cleanup and persistent archive verified under lease/local gates. Guest fixtures separate128MiB tmpfs,256MiB staging headroom.180sowner+30sstop+30smargin; observe240s. Actual10 final focused checks run independently while collecting. Stop at a verified retained/restored source and debt decision; no broad unchanged retiming campaign.'
(n/'contract.md').write_text(contract+'\n',encoding='utf-8')
shutil.copyfile(r/'setup-contract.json',n/'setup-contract.json')
p=Path('PLAN.md');t=p.read_text(encoding='utf-8')
t += '\nB417 selected bounded source refinement after repeated460/2496net11 checks.\nSame4jobs/4roles/5swarmups/7rotated150ms rounds/normal0.4aux.180+30+30s,\nobserve240s; full identity/golden/quiet/join/fixture/archive-under-lease/local gates.\nB416 all adverse/raw points remain. Check actual10 independently; decide debt/source.\n'
p.write_text(t,encoding='utf-8');shutil.copyfile(p,n/'pre-measurement-plan.md')
with tarfile.open(n/'payload.tgz','w:gz')as z:
    for filename in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','current-core.dll','focused.json','source.patch','contract.md','setup-contract.json','pre-measurement-plan.md']:z.add(n/filename,arcname=filename)
print(json.dumps(dict(refinedCore=digest,payloadBytes=(n/'payload.tgz').stat().st_size,ownerSeconds=180,observeAfterSeconds=240)))
