using System.Text;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class JsonInputWindowOwnershipTests
{
    private static readonly LythonSourceSpan Span = new(12, 3, 2, 1);

    [Fact]
    public void SurvivingWindowsKeepTheCompleteBackingFundedAfterOtherShellsEnd()
    {
        const long limit = 16 * 1024;
        var budget = new LythonMemoryBudget(limit);
        using (var owner = budget.CreateScope())
        {
            var governor = new MemoryGovernor(owner);
            var input = "prefix:é😀:tail" + new string('x', 4096);
            var source = PyString.FromString(input, governor, Span);
            var view = source.BorrowUtf8Window(7, Encoding.UTF8.GetByteCount("é😀"), governor, Span);
            var nested = view.BorrowUtf8Window(2, 4, governor, Span);
            governor.RefundUnpublishedValue(source);
            governor.RefundUnpublishedValue(view);
            var backing = 32L + Encoding.UTF8.GetByteCount(input);
            Assert.True(budget.ReservedBytes >= backing + nested.CommittedOwnedBytes);
            Assert.False(budget.TryReserve(limit - backing + 1, out var overcommit));
            overcommit?.Dispose();
            Assert.Equal("😀", nested.AsString());
            Assert.Equal(1, nested.Length);
            Assert.Equal(2, nested.GetUtf16CodeUnitCount());
            Assert.Equal("😀😀", nested.Repeat(2).AsString());
            Assert.Equal("😀!", nested.Concat(PyString.FromString("!")).AsString());
            Assert.Equal("😀", nested.Index(0).AsString());
            Assert.Equal("😀", Assert.Single(nested.EnumerateRunes()).AsString());
            Assert.Equal(PyString.FromString("😀").GetPyHashCode(), nested.GetPyHashCode());
            Assert.Equal("x", nested.Replace(PyString.FromString("😀"), PyString.FromString("x")).AsString());
            Assert.Equal(0, governor.CurrentReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void AnotherOwnerReceivesAnIndependentCopyAndFunding()
    {
        var budget = new LythonMemoryBudget(16 * 1024);
        using (var resultOwner = budget.CreateScope())
        {
            var resultGovernor = new MemoryGovernor(resultOwner);
            PyString value;
            using (var sourceOwner = budget.CreateScope())
            {
                var sourceGovernor = new MemoryGovernor(sourceOwner);
                var source = PyString.FromString("prefix:é😀:suffix", sourceGovernor, Span);
                value = source.BorrowUtf8Window(7, 6, resultGovernor, Span);
                sourceGovernor.RefundUnpublishedValue(source);
            }
            Assert.Equal("é😀", value.AsString());
            Assert.True(budget.ReservedBytes >= value.Utf8Bytes.Length);
            resultGovernor.RefundUnpublishedValue(value);
            Assert.Equal(0, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void RefusedWindowDoesNotReturnInputBackingToOtherUsers()
    {
        const long limit = 16 * 1024;
        var budget = new LythonMemoryBudget(limit);
        using (var owner = budget.CreateScope())
        {
            var governor = new MemoryGovernor(owner);
            var source = PyString.FromString(new string('x', 4096), governor, Span);
            Assert.True(budget.TryReserve(limit - budget.ReservedBytes, out var blocker));
            using (blocker)
            {
                var error = Assert.Throws<LythonRuntimeException>(() => source.BorrowUtf8Window(1, 2, governor, Span));
                Assert.Same(error, governor.AdmissionFailure);
                Assert.Equal(LythonFailureReason.SharedMemoryAllowance, error.Attribution?.Reason);
                Assert.Same(Span, error.Span);
                Assert.Equal(new string('x', 4096), source.AsString());
                Assert.Equal(0, governor.CurrentReservedBytes);
            }
            governor.RefundUnpublishedValue(source);
            Assert.True(budget.ReservedBytes >= 4096 + 32);
        }
        Assert.Equal(0, budget.ReservedBytes);
        Assert.True(budget.TryReserve(limit, out var reused));
        reused.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void AdmissionCallbackCannotRefundBackingByDiscardingTheSourceShell()
    {
        var budget = new LythonMemoryBudget(16 * 1024);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var governor = new MemoryGovernor(hook);
            var source = PyString.FromString("prefix:é😀:suffix" + new string('x', 4096), governor, Span);
            var backing = source.Utf8Bytes.Length + 32;
            hook.AfterGrowth = _ =>
            {
                hook.AfterGrowth = null;
                governor.RefundUnpublishedValue(source);
            };
            var value = source.BorrowUtf8Window(7, 6, governor, Span);
            Assert.Equal("é😀", value.AsString());
            Assert.True(budget.ReservedBytes >= backing);
            Assert.Equal(0, governor.CurrentReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
