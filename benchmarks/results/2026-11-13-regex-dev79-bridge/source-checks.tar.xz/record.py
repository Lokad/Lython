from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-regex-dev79-bridge');out.mkdir()
q=json.loads((r/'qualification.json').read_text(encoding='utf-8'));isolation=json.loads((r/'isolation.json').read_text(encoding='utf-8'))
assert isolation['normalFilesUnchanged']==29 and isolation['coreSourcesUnchanged']==571 and isolation['loadedProducerAssembliesMatchPinnedPackages']
for target in ['net11.0','net10.0']:
 assert q['checks']['Lokad.Lython.Tests-'+target]['passed']==88 and q['checks']['Lokad.Lython.PublicApi.Tests-'+target]['passed']==534
for name in ['identity.json','qualification.json','isolation.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.cs','.props','.Config','.json','.log']:archive.add(p,arcname=p.name)
 archive.add(r.parent/'formatted-prefix-r296/prepare-dev79-bridge.py',arcname='prepare-dev79-bridge.py')
 for p in(r/'feed').iterdir():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==q['identity']['packages'][p.name]['sha256'];archive.add(p,arcname='immutable-feed/'+p.name)
(out/'README.md').write_text('''# Isolated dev.79 regex bridge — R299

Consumerd413392c, producer immutable0.5.0-dev.79 packages at891cabbf. Core SHA256
e2293dad0e496fa43c845e899b1f858d2752b72ba68d26d3c3e83aed4afa353c;
PythonRe1e48d685719879a7679043aeb61a2775b1789200832f48707f2291f95d1cb5cc.
Exact copies are preserved in the local feed archive. PythonRe API code is unchanged
from the prior bridge; the producer Core matching path changes. This independently
checks the new binary, not an unchanged dev.78 qualification replay.

**88 internal /534 public checks pass per actual.NET11/10**: Python regex semantics,
frontend/runtime/import/regex-backed helpers, cancellation forwarding, caller-funded
ownership, cursor admission and cleanup. Loaded producer assembly hashes match the
immutable packages.29 normal project/pin/output files and571 core sources remain
unchanged. Normal optional adapter stays0.4/nonpackable; core remains decoupled.

Reuse the exact previously qualified adapter-local native-cursor/current-token
bridge, with conservative compilation admission and AssumeValid through the working
unfunded compile overload. No new core contract, adapter abstraction, compatibility
switch or memory policy is introduced. Namespace/cursor conversions remain confined
to this bridge. This is development semantic/ownership/cancellation validation,
not final adapter qualification or a backend performance claim.

Still missing for the intended final native route: separate one-match work/result
owners, native UTF8 group-name enumeration, and token-independent cursor creation
with cancellable preparation. No correction to funded AssumeValid forwarding is
visible in the new source; this check exercises the working bridge overload, not
a new funded-overload capability probe. Missing producer APIs defer only affected
final qualification. Producer release qualification and publication remain separate;
Lython development continues independently.

[Qualification/loaded libraries](qualification.json), [package identity](identity.json),
[isolation](isolation.json), [exact bridge/scripts/logs/packages](source-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''

## R299 — immutable dev.79 adapter bridge

The existing isolated bridge independently qualifies new producer891cabbf/dev.79
on consumerd413392c:88internal/534public per actual.NET11/10, exact loaded package
identities,29 normal files/571 core sources unchanged. No normal pin/API/dependency
promotion or backend speed claim. Final single-match owners, nativeUTF8 names and
token-independent preparation remain separate; source unchanged funded forwarding
is not a new successful capability probe. [Exact copies and validation](results/2026-11-13-regex-dev79-bridge/README.md).
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('are now pinned for active R299 isolated bridge qualification on current\n     d413392c. Olderdev.78 checks do not qualify the new binary; development proceeds\n     independently. Normal adapter/core dependencies stay unchanged; no missing API\n     appeared. Validate loaded package identities and unchanged normal inputs.','''pass R299 isolated bridge qualification on d413392c:88internal/534public per
     actual target, loaded DLLs exact,29normal files/571sources unchanged.
     [Evidence](benchmarks/results/2026-11-13-regex-dev79-bridge/README.md).
     This is independent development semantics/ownership/cancellation validation,
     not backend performance/final qualification; normal dependencies remain0.4.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('R299 dev79 bridge qualification recorded; normal source/pins unchanged, precise final API gaps remain independent.',flush=True)
