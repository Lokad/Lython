from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
repo=Path.cwd();old=Path(__file__).parent.parent/'ordered-native-r289/dev78-bridge';r=Path(__file__).parent.parent/'regex-dev79-r299';r.mkdir()
baseline=json.loads((old/'normal-state-before.json').read_text(encoding='utf-8'))
(r/'normal-state-before.json').write_text(json.dumps({name:hashlib.sha256((repo/name).read_bytes()).hexdigest()for name in baseline},indent=2)+'\n',encoding='utf-8',newline='\n')
sources={p:hashlib.sha256((repo/p).read_bytes()).hexdigest()for p in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()};assert len(sources)==571
(r/'normal-core-sources-before.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['Directory.Build.props','Directory.Packages.props','NuGet.Config','CursorAdmissionTests.cs','workflow-fixture-manifest.json','qualify.py','Utf8RegexProvider.cs']:
 code=(old/name).read_text(encoding='utf-8').replace(old.resolve().as_posix(),r.resolve().as_posix()).replace('0.5.0-dev.78','0.5.0-dev.79')
 if name=='qualify.py':
  code=code.replace("[env['DOTNET_HOST_PATH'],*args,*props]","[env['DOTNET_HOST_PATH'],*args,'--disable-build-servers',*props]")
  code+='''
before=json.loads((root/'normal-state-before.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha for name,sha in before.items())
sources=json.loads((root/'normal-core-sources-before.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha for name,sha in sources.items())
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
for framework in ['net11.0','net10.0']:
 for package in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
  assert checks[framework+'-loadedFiles'][package]==identity['packages'][package+'.0.5.0-dev.79.nupkg']['assemblies'][framework]
(root/'isolation.json').write_text(json.dumps(dict(normalFilesUnchanged=len(before),coreSourcesUnchanged=len(sources),actualTargets=['net11.0','net10.0'],loadedProducerAssembliesMatchPinnedPackages=True,normalAdapterPin='0.4.0',coreDependencyChange=False,developmentOnly=True,backendPerformanceQualified=False),indent=2)+'\\n',encoding='utf-8')
print('dev79 isolated qualification complete;29 normal files/571 sources unchanged, loaded packages exact.',flush=True)
'''
 (r/name).write_text(code,encoding='utf-8',newline='\n')
(r/'feed').mkdir();packages={};observations=json.loads((Path(__file__).parent/'dev79-package-observation.json').read_text(encoding='utf-8'))
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 file=Path(f'D:/code/utf8regex/artifacts/nuget/{name}.0.5.0-dev.79.nupkg');data=file.read_bytes();expected=next(x for x in observations if x['name']==file.name)
 assert hashlib.sha256(data).hexdigest()==expected['sha256']
 with zipfile.ZipFile(file)as archive:
  xml=ET.fromstring(archive.read(next(p for p in archive.namelist()if p.endswith('.nuspec'))));commit=next(e.attrib['commit']for e in xml.iter()if e.tag.endswith('repository'));assert commit.startswith('891cabbf')
  assemblies={tfm:hashlib.sha256(archive.read(f'lib/{tfm}/{name}.dll')).hexdigest()for tfm in ['net11.0','net10.0']}
 shutil.copyfile(file,r/'feed'/file.name);packages[file.name]=dict(sha256=hashlib.sha256(data).hexdigest(),repositoryCommit=commit,assemblies=assemblies)
identity=dict(consumerRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),producerVersion='0.5.0-dev.79',packages=packages,bridge='Exact existing dev78 native-cursor/ownership/current-token bridge; PythonRe API unchanged, matching core changed. AssumeValid through working unfunded compile overload, conservative local compilation admission. No normal pin, core contract or source changes.',limitations='Independent development semantic/ownership/cancellation validation only. Producer final package qualification, separate single-match owners, UTF8 names and native token-independent preparation remain separate. No backend performance claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('     running. Olderdev.78 checks do not qualify that newer binary. Once an immutable\n     package is supplied, qualify its changed matching with the existing isolated\n     bridge; normal adapter/core dependencies stay unchanged. No missing API appeared.','''     running. Immutable local copies (Coree2293dad /PythonRe1e48d685, package commit
     891cabbf) are now pinned for active R299 isolated bridge qualification on current
     d413392c. Olderdev.78 checks do not qualify the new binary; development proceeds
     independently. Normal adapter/core dependencies stay unchanged; no missing API
     appeared. Validate loaded package identities and unchanged normal inputs.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Immutable dev79 copies pinned; exact dev78 bridge reused, normal29files/571sources snapshotted.',flush=True)
