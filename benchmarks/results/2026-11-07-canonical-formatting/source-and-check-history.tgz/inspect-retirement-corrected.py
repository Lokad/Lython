from pathlib import Path
import json,shutil
b=Path('/home/lokad/lython-bench-checks')
p=b/'current-cpu-b371-20261107/perf/report-warm/perf-stacks.txt'
print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,b371=dict(path=str(p),exists=p.exists(),symlink=p.is_symlink(),links=p.stat().st_nlink if p.exists() else None),b373=[str(p) for p in (b/'delivery-comparison-b373-20261107/confirmation').glob('*')]),indent=2))
