# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Individual experiments/checkpoints do not finish this objective.

## Actual delivery

- Fully qualified01aedc3b: R25 transfers complete funded CSV values into canonical
  shared-key dictionaries. Focused125internal/389public per actual.NET11/10,
  Release0warnings, short whole-job allocation and explicit installed consumers
  pass. Combined delivery42319704404 is GREEN/all eight Windows/Ubuntu ordinary
  actual11/10, original Stress and package gates. Terminal receipt is cached;
  never query again or repeat completed qualification.
- Fully qualified ec134e8c R23: GREEN42316074240/all eight delivery gates, cached
  regex-program-reuse/delivery-ci.json. R22 41c25958 GREEN42310347889 likewise
  cached under builtin-initialization. Never query terminal runs again.
- Committed/pushed14366ac7 records B373/current representative comparison and
  R25 terminal qualification. a48caba2 records the R24 source/CPU gate, no speedup.
- Active R26 correctness/deletion prototype: full formatted native bodies now use
  canonical executable instructions. Initial280internal/1186public checks pass
  per actual11/10, including true suspension/held cleanup. Context-free primitive
  formatting refinement is implemented but not yet checked/measured/committed.
- Primary docs/BENCHMARKS.md measures01aedc3b/B373, before R26. R22/R23/R25
  source pairs are separate. Unresolved: warm-text gap/possible R20 debt, mixed
  coarse CSV CPU, startup/suspended-I/O/RSS/embedding-tail impact and final adapter.

Current guides belong in docs/. Experimental history stays under
benchmarks/results/, indexed by benchmarks/EXPERIMENTS.md. Full earlier plans/
source gates remain in .git/agent-notes/review-20261031/ and immutable captures.
Current pre-condensation plan: csv-record-values-r25/PLAN-before-delivery-condense.md.
Do not repeat completed qualification merely to refresh its date.

## Completed milestones and evidence decisions

Preserve shared compiler-fact correction, UTF8 formatting/storage, final call/local
slots, native helper returns, executable imports/lambdas, genuine suspension,
shared builtin definitions and validated reusable sync/async startup workers.
Worker reuse and release on true I/O already exist; do not plan them as missing.
Keep K01/F02–F05/Q01/Q02/R02–R14 and qualified protection/ownership simplifications.

| Milestone | Established outcome | Remaining limits / evidence |
| --- | --- | --- |
| Native helper returns | Allocation−19.92/−19.31%; delivered | Elapsed diagnostic. Do not transfer percentages to HEAD. |
| UTF8 formatting | Allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms unexplained/preserved; completed question, no unchanged retiming scheduled without new evidence. |
| R20 record layout | Canonical shared keys/independent values, no coupled entries/sorted JSON hint/set values. JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8% | CSV modest/mixed CPU. Text confirmation−1.21% to+5.53%: possible regression accepted debt, not parity. Fully delivered; record-layout evidence retains every failure/adverse condition. |
| R21 frame resume | Delete per-instruction pending-error/return polling; preserve guards/spans/cleanup | Allocation flat, modest warm text; unchanged compile also moves. Fully delivered; no general CPU gain or closure of R20 debt. |
| R22 builtin setup | Fixed functions/signatures prepared once; per-run mutable type/exception/namespace isolation. Factory−2,688B | Whole scripts mostly<0.2%allocation, config~1.17%. Config warm−1.13–2.44%, fresh−1.43% to+0.13%. Fully delivered; text controls variable. |
| U04 capture ownership | Caller spans/retained ranges replace carriers/arrays. Direct cursor allocation−20.34%; complete extraction warm−3.62–5.17%/fresh−4.58–6.40% | Fully delivered; distinct from R23, no backend CPU attribution. |
| R23 validated programs | Eliminate duplicate frontend/runtime provider compilation; native UTF8 request keys, per-run wrappers/names/purge/current tokens | B36989s extraction warm−8.34–9.64%, fresh−6.47–6.53%. Probe compiled funding39,397→105,481B until script disposal: explicit retention/earlier-denial tradeoff. Fully delivered; moving controls limit CPU attribution. |
| R25 CSV values | Transfer final funded arrays for exact header identities; no second values allocation/per-field publication on that path | Allocation−7.31/−6.55%sync/async. B372109s native warm−7.72–8.04%, ordinary warm−4.13–4.78%; text spread2.52%, coarse CPU mixed. Fully delivered. |

R25 retains original row headroom and independently mutable values. Admit shell,
then revalidate header identity/width after callbacks; transfer before ending
private-row ownership. Dynamic/changed/short/rest headers keep existing semantics.
Clear retains backing and funding; execution/result-owner cleanup returns it.
Initial clear-refund test assumption was corrected, with failed logs/design kept.
No production clear/refund behavior changed. Case-specific admitted execution peak
3,737,138→3,671,314B is a conservative estimate, not heap/RSS. Other shapes may
deny earlier. Evidence2026-11-07-csv-record-values; no fresh/async elapsed or new
CPython ratio was measured in this source pair.

B373 primary comparison, all15jobs/312s: fresh CSV1.22–1.24x,text1.76–1.77x,
JSON1.07–1.11x,report1.34–1.42x,config1.20–1.21x CPython. Warm1.20–1.22/
1.81–1.83/1.08/1.33–1.35/1.25x. Compile44–72us separate; fresh JSON/report/config
variation remains explicit. Includes mediated RAM I/O, full validation and
prior-result cleanup; excludes startup/staging/final teardown. No subtraction
of independent medians to infer I/O/cleanup costs or causal per-change gain.

R25 delivery and representative checkpoint are closed. Terminal B373 archives,
commands, exact source/image identity, adverse/variable observations and all-eight
CI receipt are committed under2026-11-07-current-cpython. Preserve previous B367.

## Priority1 — R26 single-pass formatting/correctness milestone

**Correctness first:** a focused regression on01aedc3b demonstrates a raw CLR
InvalidCastException when substantial formatted-output admission changes a later
global method receiver after its earlier native type proof. Source/failed log in
native-single-pass-r26/. Correct this before further performance prototypes.

Hypothesis: retain measured native helper/UTF8 formatting wins while removing the
separate recursive runtime proof walk and whole-function restart on a dynamic
operation. Current R24 report has native guard7.1%/evaluation8.6% leaf samples;
those include necessary work, not a predicted16% saving. Target report rendering,
text/helper and CSV helpers with ordinary-call/dynamic controls.

Explore reuse of the existing executable frame/context-required handoff at the
actual operation, carrying completed operands instead of replaying prior work.
First inspect current provenance/liveness facts and resolve a precise mapping
from native producers to original instruction slots/spans. No new dispatcher,
expression backend, saved-call-control arena or generic framework. Do not simply
remove pre-effect guards or retry normal interpretation after admission/effects.

Source acceptance: exact evaluation/read/binding/error order, aliases/identity,
host admission mutation, captured locals/cells, dynamic protocols and true async
callbacks. Preserve current cancellation/terminal refusal/managed stack, all
completed native returns/formatting allocation benefits, funded operands and
awaited cleanup. Dynamic handoff must execute each effect once and preserve its
original span. Prove workspace/retention costs before a runtime prototype.

If coherent, displaced code must include the redundant proof traversal and
whole-function fallback selection; do not wrap both in a third engine. One
bounded whole-script before/after with ordinary/text/JSON controls, normal GC/
tiering, and separate allocation. Allow evidence-led refinement; decide remaining
regression debt at an explicit completion milestone. If handoff requires a broader
IR/ownership redesign, stop this bounded gate, document the actual tradeoff and
select the smallest missing proof rather than silently beginning a compiler rewrite.
The larger performance objective remains open after a source gate or experiment.

Gate decision: arbitrary replay-free native promotion needs retained forwarded
locals/operands and builder state beyond the existing recursive evaluator; do not
automatically introduce that wider journal/arena. Select a bounded deletion:
remove the duplicate full formatted-body native spine/proof/evaluator; use the
existing executable formatting path and its same direct-UTF8 kernels. Keep
primitive native returns and direct single-value format/conversion. In the
existing native preparation, decline mutable global/name/subscript reads after
earlier allocating operations, preserving captured parameters/constants and
intrinsic result types. No work is restarted after effects/refusal.

Compatibility: Python behavior is preserved/corrected; some formatted helpers may
require more frames/allocation. Measure report sync/async plus text/JSON controls,
keep meaningful native-return/formatter wins, record any remaining debt and choose
its completion milestone. No new dispatcher, policy, ownership system or public
option. Existing cancellation/refusal/alias/cleanup/source/locals checks plus
changed-receiver and actual suspended-callback regression coverage are required.

Refinement uses the existing context-free instruction prefix, ordinary slots and
ContextRequired handoff: move canonical builder start/text/finish there and execute
only closed primitive formatting immediately. Dynamic fields keep the current
async protocol route. Remove duplicated builder cases, not wrap them. No additional
evaluator, journal or owner. Check late mutable reads, exact-once effects, held
cleanup, terminal refusal and funding; measure complete report jobs sync/async and
text/JSON controls. Retain the proven correctness fix regardless of whether timing
justifies this refinement. Then batch full delivery and select the next coherent
design from remaining whole-script costs, rather than end the performance effort.

## Other roadmap decisions

R24 current source gate: about5guestCPU seconds/546text+451report samples. Calls
~2%, text prefix21%including useful inlining, report JSON~10%. This does not
justify another call arena or universal scalar migration; R16 exposes45 direct-
type assumptions. Canonical exact promotion/identity/hash/projection is required
before any scalar redesign. Existing final slots/borrowed args/workers already
remove major call/setup mechanisms.

R25 selectively reconsiders CSV after earlier6–8% rigid-threshold rejection: shared
key storage enables actual array transfer, a different eliminated-work model.
Do not automatically revive old bulk-copy, B61/B69 slower arenas/control or guarded
target variants. Remaining text conversions need a different final-storage model;
casing already writes UTF8 and plain JSON tokens bypass backend reparsing.
Shared windows add8B/object and measured slower. Shared lexical facts/precedence
are delivered; further frontend work must remove a real duplicate walk and use
compile-to-result controls. No narrow hint/fusion tweak series or broad audit.

R24 original export failure, prelaunch path error, unknowns and observer-delay
deviation remain explicit under2026-11-07-current-script-cpu. The corrected
capture's users/quiet/archive finish before observation, but no strict180s-delay
claim. Never manufacture missing proof or repeat unchanged profiling automatically.

## Independent regex track

Core Python semantics/native UTF8/byte ranges/scalar original windows, captures/
replacements/errors, ownership and current cancellation keep advancing without a
producer release. U04/R23 delivered. Normal adapter pin0.4/nonpackable; core has
zero backend dependency/type edges. Dev46 immutable source6957b35a compatibility
passed85internal/482public per actual target, same U04 bridge as44; evidence
2026-11-06-regex-dev46-compatibility. No production promotion/requalification replay.

Only affected final adapter qualification waits for missing producer capabilities:
DetailedData lacks independent Prepare working owner (conservative preflight);
native names cannot be enumerated (adapter-local conversion); native cursors mix
creation/per-operation tokens (qualified CTS bridge already provides current-token
semantics; removal is simplification, not a core blocker). Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges support
testing; qualify final released immutable package/managed safety separately.
No sibling edits, silent dialect fallback or work/time quotas.

## Working contract

Timeouts/unstable controls/inconclusive results establish uncertainty, not failed
design. Bounded confirmation/refinement/measurement correction is allowed when
justified; preserve original failed conditions/adverse data. Percentages inform
decisions, not automatic vetoes or permanent closures. Separate architecture,
allocation, elapsed and demonstrated CPU. Temporary debt needs a completion
milestone and decision on remaining regression, not indefinite acceptance.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/
native probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host cancellation, shared allowance/capacity/replacement/escaping aliases
and awaited cleanup. First admission refusal fails the command; never retry.
No fuel/quotas/hidden caps/default allowance/tracing/weak reclamation/forced GC.
Initial streaming uses bounded host executions; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch actual11/10/Windows/Ubuntu/original
Stress/installed consumers at coherent boundaries; no repeated terminal CI probes.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: exclusive owned lease,
Ready hashes, controls/quiet/goldens/funding/joins and verified persistent archives.
Observe only after owner+stop+margin; record conservative UTC bound after launch.
Disk near full: retire only exact redundant expanded files after independent
committed backup and all user/dependency checks. Keep raw evidence. Continue
after individual experiments/checkpoints; publication and tagging stay postponed.
