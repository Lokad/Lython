from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent;repo=Path('D:/code/Lython')
path='benchmarks/results/2026-11-07-current-cpython/observations.tgz'
data=(repo/path).read_bytes()
assert data==subprocess.check_output(['git','show','HEAD:'+path])
assert subprocess.check_output(['git','rev-parse','HEAD'])==subprocess.check_output(['git','rev-parse','origin/master'])
checks={}
with tarfile.open(repo/path) as a:
    for member in a.getmembers():
        if member.isfile() and member.name.startswith('confirmation/'):
            content=a.extractfile(member).read();checks[member.name]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
assert checks and sum(v['bytes'] for v in checks.values())<15*1024*1024
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'delivery-comparison-b373-20261107';checks=CHECKS
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()=='ARCHIVEHASH'
 targets=[]
 for relative,check in checks.items():
  p=root/relative
  assert p.resolve()==p and root/'confirmation' in p.parents and p.is_file() and p.stat().st_nlink==1
  assert p.stat().st_size==check['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==check['sha256']
  targets.append(p)
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve() in targets]
 # Retire exact expanded regular files only, after both independent archives,
 # every hash and all dependencies/users have been verified. Keep raw archive.
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=checks,independentCommittedArchive='ARCHIVEPATH',archiveSHA256='ARCHIVEHASH',allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
'''.replace('CHECKS',repr(checks)).replace('ARCHIVEHASH',hashlib.sha256(data).hexdigest()).replace('ARCHIVEPATH',path)
(root/'retire-expanded-command.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'retired-profile-receipt.json').write_text(p.stdout,encoding='utf-8');assert p.returncode==0,p.stderr+p.stdout
r=json.loads(p.stdout);print('Retired',len(r['retiredExpandedFiles']),'redundant expanded files; free',r['freeBytes'],'B; raw archives retained.')
