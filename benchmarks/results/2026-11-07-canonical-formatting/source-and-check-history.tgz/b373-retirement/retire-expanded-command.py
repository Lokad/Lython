from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'delivery-comparison-b373-20261107';checks={'confirmation/confirmation.json': {'bytes': 1624875, 'sha256': 'a841f3f2d2f1060758f5d470cb1756ae2cc9245726e8fd4677bb96b14814bfb8'}, 'confirmation/fixture-filesystem.txt': {'bytes': 78, 'sha256': 'f2007fcedaf0603f0b911e6574d2a8ca03d21e11df56f506e422238b2cc9fb04'}, 'confirmation/machine-after.json': {'bytes': 11109, 'sha256': 'fe02133524a6e00e9740da10b8cd3623dc2ee4b0518c85a277176edd7f098a66'}, 'confirmation/machine-before.json': {'bytes': 11127, 'sha256': 'b4c57efc61c9bf90642943578b8aac09032f5e150756d7dfbe237630aa31c99e'}}
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()=='f36ce9a8aa07112710fc9599a6f617f2af0991c773cc3d78dcf5737d5ae58326'
 targets=[]
 for relative,check in checks.items():
  p=root/relative
  assert p.resolve()==p and root/'confirmation' in p.parents and p.is_file() and p.stat().st_nlink==1
  assert p.stat().st_size==check['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==check['sha256']
  targets.append(p)
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve() in targets]
 # Retire exact expanded regular files only, after both independent archives,
 # every hash and all dependencies/users have been verified. Keep raw archive.
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=checks,independentCommittedArchive='benchmarks/results/2026-11-07-current-cpython/observations.tgz',archiveSHA256='f36ce9a8aa07112710fc9599a6f617f2af0991c773cc3d78dcf5737d5ae58326',allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
