from pathlib import Path
import subprocess
root=Path(__file__).parent
script="""from pathlib import Path
import json,shutil
b=Path('/home/lokad/lython-bench-checks')
p=b/'current-cpu-b371-20261107/perf/report-warm/perf-stacks.txt'
print(json.dumps(dict(freeBytes=shutil.disk_usage(b).free,b371=dict(path=str(p),exists=p.exists(),symlink=p.is_symlink(),links=p.stat().st_nlink if p.exists() else None),b373=[str(p) for p in (b/'delivery-comparison-b373-20261107/confirmation').glob('*')]),indent=2))
"""
compile(script,'remote-inspection','exec')
(root/'inspect-retirement-corrected.py').write_text(script,encoding='utf-8')
r=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'retirement-inspection-corrected.json').write_text(r.stdout,encoding='utf-8')
print(r.stdout,r.stderr);raise SystemExit(r.returncode)
