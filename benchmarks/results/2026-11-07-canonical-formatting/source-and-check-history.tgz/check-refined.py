from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'build-refined.log').open('w',encoding='utf-8') as output:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build','Lokad.Lython.slnx','-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=output,stderr=subprocess.STDOUT)
if p.returncode:
    print((root/'build-refined.log').read_text(encoding='utf-8')[-2000:],flush=True);raise SystemExit(p.returncode)
families=['NativeReturn','SimpleFunctionExecutionBoundary','Format','FunctionBinding','DeferredContext','GovernedMemory','SharedMemory','Cancellation']
selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in families)+')';checks={}
for tfm in ['net11.0','net10.0']:
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        key=suite+'-'+tfm;log=root/('focused-refined-'+key+'.log')
        with log.open('w',encoding='utf-8') as output:
            p=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{suite}/{suite}.csproj','-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off','--filter',selection],env=env,stdout=output,stderr=subprocess.STDOUT)
        text=log.read_text(encoding='utf-8');checks[key]=dict(exitCode=p.returncode,summaries=re.findall(r'(?:Passed!|Failed!)\s+[^\r\n]+',text))
        (root/'focused-refined.json').write_text(json.dumps(dict(checks=checks,selection=selection),indent=2)+'\n',encoding='utf-8')
        print(key,checks[key],flush=True)
        if p.returncode:
            print(text[-2500:],flush=True);raise SystemExit(p.returncode)
result=dict(checks=checks,selection=selection,coreSHA256={tfm:hashlib.sha256(Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll').read_bytes()).hexdigest() for tfm in ['net11.0','net10.0']})
(root/'focused-refined.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
