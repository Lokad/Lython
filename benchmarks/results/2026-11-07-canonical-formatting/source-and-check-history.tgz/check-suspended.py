from pathlib import Path
root=Path(__file__).parent
s=(root/'check.py').read_text(encoding='utf-8').replace('build-prototype.log','build-suspended.log').replace('focused-initial','focused-suspended')
(root/'focused-suspended.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'focused-suspended.py'),'exec'),{'__file__':str(root/'focused-suspended.py')})
