from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent/'b374'
old=(root/'payload.tgz').read_bytes()
with tarfile.open(root/'payload-shared-catalog.tgz','w:gz') as out:
    with tarfile.open(root/'payload.tgz') as source:
        for member in source.getmembers():
            if member.name!='representative.json':out.addfile(member,source.extractfile(member))
data=(root/'payload-shared-catalog.tgz').read_bytes()
script=(root/'launch.py').read_text(encoding='utf-8')
script=script.replace(str(len(old)),str(len(data))).replace(hashlib.sha256(old).hexdigest(),hashlib.sha256(data).hexdigest())
before="for name in ['cpython-worker.py']:(root/name).symlink_to(prior/name)"
after="for name in ['cpython-worker.py','representative.json']:(root/name).symlink_to(prior/name)\n assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()=='CATALOGHASH'"
after=after.replace('CATALOGHASH',hashlib.sha256((root/'representative.json').read_bytes()).hexdigest())
assert before in script;script=script.replace(before,after)
compile(script,'shared-catalog-launch','exec')
(root/'launch-shared-catalog.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch-shared-catalog.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b374-launch-shared.py'],capture_output=True);assert p.returncode==0,p.stderr
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b374-launch-shared.py'],input=data,capture_output=True)
(root/'launch-shared-catalog.log').write_bytes(p.stdout+p.stderr)
assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8')
print((p.stdout+p.stderr).decode('utf-8'),flush=True)
