from pathlib import Path
import ast
home=Path(__file__).parent
previous=home.parent/'csv-record-values-r25'
retire=home/'b373-retirement';retire.mkdir()
s=(previous/'retire-expanded-profile.py').read_text(encoding='utf-8')
s=s.replace('benchmarks/results/2026-11-07-current-script-cpu/observations.tgz','benchmarks/results/2026-11-07-current-cpython/observations.tgz').replace('current-cpu-b371-20261107','delivery-comparison-b373-20261107')
s=s.replace("member.name.startswith('perf/')","member.name.startswith('confirmation/')").replace("root/'perf' in p.parents","root/'confirmation' in p.parents")
ast.parse(s);(retire/'retire-expanded-profile.py').write_text(s,encoding='utf-8')

s=(previous/'prepare-comparison-expanded.py').read_text(encoding='utf-8')
s=s.replace("root=home/'b372'","root=home/'b374'")
s=s.replace("old=home.parent/'regex-program-artifacts-r23/b369';prior='/home/lokad/lython-bench-checks/regex-programs-b369-20261106';remote='/home/lokad/lython-bench-checks/csv-record-values-b372-20261107'", "old=home.parent/'delivery-comparison-b373';prior='/home/lokad/lython-bench-checks/delivery-comparison-b373-20261107';remote='/home/lokad/lython-bench-checks/canonical-formatting-b374-20261107'")
s=s.replace('a48caba2/ec134e8c runtime plus R25 completed CSV record-value adoption','14366ac7/01aedc3b runtime plus R26 canonical formatted-body execution and mutable-read correction')
s=s.replace('ec134e8c runtime, frozen B36923a0a257; all baseline production source hashes identical','01aedc3b runtime, frozen B3730933d540; all baseline production source hashes identical')
s=s.replace('R25 direct completed-record values: ordinary/native CSV, public reader, text and JSON compile controls; not a CPython refresh','R26 canonical formatting: report sync/async, text and JSON controls; not a CPython refresh')
start=s.index("write('contract.md'");end=s.index("shutil.copyfile(home/'comparison-catalog.json'",start)
s=s[:start]+'''write('contract.md','R26 deletes the separate formatted native-body evaluator/proof/spine. Existing executable slots/cleanup and immediate primitive formatting share the same direct UTF8 kernels; dynamic fields promote at the current instruction without replay. Native preparation excludes late mutable reads after potentially allocating effects. Existing source/worker/catalog/host/0.4 adapter; normal GC/tiering and reference/current/identical-current roles. Report warm sync and warm-async completed I/O, text warm control and JSON compilation control.5s warmups and seven rotated150ms rounds. All goldens, funding, Closed/joins, quiet gates and persistent under-lease archive required. Includes mediated RAM I/O, full validation and prior-result cleanup; startup/staging/final teardown excluded.150sowner+30sstop+10smargin; no VM observation before190s. Precise local process allocation is separate from VM elapsed/coarse CPU. Preserve adverse controls, original failures and unknowns. Disk preflight reserves2MiB after expanded payload: observed compressed15-job archive122KiB plus commands/JSON, bounded four-job capture and no perf trace. Retire only archived expanded B373 observations after all checks; keep all archives/binaries.\\n')
write('setup-contract.json',json.dumps(dict(reference=prior+'/candidate',roles=['candidate','reference','control'],ownerSeconds=150,stopSeconds=30,observeAfterSeconds=190,unaffectedControl='scripts.json-summary-helpers.large compile',diskHeadroomBytes=2*1024*1024),indent=2)+'\\n')
template=home.parent/'csv-record-values-r25/b372'
for name in ['collect.py','archive-owned.py','run.sh']:
    content=(template/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/csv-record-values-b372-20261107',remote)
    if name=='collect.py':
        lines=content.splitlines()
        jobline=next(line for line in lines if line.startswith('jobs=['))
        content=content.replace(jobline,"jobs=[('scripts.report-render.large','warm'),('scripts.report-render.large','warm-async'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','compile')]")
    content=content.replace('len(jobs)==5','len(jobs)==4').replace("len(r['jobs'])==5","len(r['jobs'])==4").replace('jobs=5','jobs=4')
    content=content.replace('R25 direct completed-record values: ordinary/native CSV, public reader, text and JSON compile controls; not a CPython refresh',identity['purpose'])
    write(name,content)
'''+s[end:]
s=s.replace("['scripts.csv-summary-helpers.large','scripts.csv-summary-functions.large','scripts.csv-summary-reader.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']","['scripts.report-render.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']")
s=s.replace('allFiveCatalogJobsValidated','allFourCatalogJobsValidated').replace('6*1024*1024','2*1024*1024')
s=s.replace('lython-b372-csv-record-values-20261107','lython-b374-canonical-formatting-20261107').replace('b372-launch.py','b374-launch.py')
ast.parse(s);(home/'prepare-comparison-expanded.py').write_text(s,encoding='utf-8')
(home/'comparison-catalog.json').write_bytes((home.parent/'delivery-comparison-b373/representative.json').read_bytes())
for name in ['retrieve-comparison.py','summarize-comparison.py','summarize-allocation.py']:
    s=(previous/name).read_text(encoding='utf-8')
    if name!='summarize-allocation.py':
        s=s.replace('csv-record-values-b372-20261107','canonical-formatting-b374-20261107').replace('b372','b374')
        s=s.replace('lython-b374-builtin-definitions-20261106.service','lython-b374-canonical-formatting-20261107.service')
        s=s.replace("['jobs']==5","['jobs']==4")
    ast.parse(s);(home/name).write_text(s,encoding='utf-8')
