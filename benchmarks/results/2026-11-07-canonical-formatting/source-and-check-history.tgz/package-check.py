from pathlib import Path
import os,subprocess
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'package-consumer.log').open('w',encoding='utf-8') as output:
    p=subprocess.run(['pwsh','-NoProfile','-File','tools/PackageSmokeTest/verify-package.ps1'],env=env,stdout=output,stderr=subprocess.STDOUT)
print('Installed Release consumers',p.returncode,flush=True)
if p.returncode:print((root/'package-consumer.log').read_text(encoding='utf-8')[-3000:],flush=True)
raise SystemExit(p.returncode)
