# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
One experiment, allocation reduction or delivery checkpoint does not complete it.

## Actual status

- **Committed/pushed:**41c25958 R22 fixed builtin initialization, with source,
  focused checks, allocation diagnostics and B368 source-pair evidence. R23 program-lifetime migration is an uncommitted prototype. The primary CPython guide measures4fad63c5, not future HEAD.
- **Fully qualified:**4fad63c5 runtime through correction/evidencea4a1c306,
  GREEN42306860444/all eight Windows/Ubuntu ordinary11/10, original Stress and
  installed-package gates. Cached current-cpython/delivery-ci-corrected.json;
  terminal, never query again. Original failed42302690579 remains preserved.
- **R22 local:**486internal/2,812public per actual11/10 pass; both-target Release
  build0warnings/errors. Explicit Release installed consumers pass both on41c25958;
  core has zero runtime dependencies and optional adapter remains nonpackable.
- **R22 fully qualified:**42310347889 on41c25958 is terminal GREEN, all eight
  Windows/Ubuntu actual11/10, original Stress and installed-package gates checked
  from cached delivery-ci-second.json. Never query this terminal run again.
- **R23 active prototype:**95internal/497public focused checks per actual11/10,
  plus cached-program in-flight cancellation/awaited-cleanup regression per target,
  pass. Release builds0warnings/errors. No elapsed comparison/delivery claim yet.
- Previous R20 f2ce53db/1fdca591 GREEN42294911136; U04 b542b601 GREEN42279409059;
  b6650f09 GREEN42258608463. Cached receipts are terminal; never re-query them.
- **Unresolved:** possible R20 text debt/coarse adverse CSV CPU, warm-text gap,
  startup/suspended-I/O/RSS/embedding-tail costs and final adapter capabilities.
  Neither producer publication nor qualification waiting stops core development.

Historical plans/snapshots/raw handoffs: .git/agent-notes/review-20261031/;
full pre-condensation plan in record-layout-r20/PLAN-before-delivery-condense.md.
Immutable evidence under benchmarks/results/; index benchmarks/EXPERIMENTS.md.
docs/ describes current implementation only, without experimental narratives.

## Completed milestones and measurement decisions

- Shared compiler facts, direct UTF8 formatting/storage, native helper returns,
  R13C/R14 provenance, R17 text provenance and P01 number formats are delivered.
  Preserve K01/F02–F05/Q01/Q02/R02–R14, final call/local slots, executable imports/
  lambdas, immutable builtin metadata, native functions and genuine suspension.
- Native returns: allocation−19.92/−19.31% established, elapsed diagnostic.
  Formatting: allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention.
  Original adverse15.125ms remains unexplained and preserved. Do not retime these
  completed questions or transfer their percentages to current HEAD.
- R17 retains allocation savings with measured text+1.6–2.2% debt. R18 shared
  targets withdrawn after two source pairs; mixed JSON/text/CSV results did not
  justify extra branches. B61/B69 call-arena/control slower designs remain lessons.
- U04 replaces match carriers/per-success arrays with caller spans; retained
  matches own ranges and copy groups on access, add regs. Direct cursor allocation
  −20.34% is separate from complete extraction warm−3.62–5.17%/fresh−4.58–6.40%.
  Fully qualified b542b601; no old API/stubs. Evidence2026-11-06-regex-capture-ownership.
- R19: current text/report CPU sample,14.41s guest. Prefix including inlined work
  20.64% text; ordinary calls/binding under2%; report JSON reading11.92%. These are
  leaf shares, not dispatch-only cost or predicted savings. No new capture planned.
- **R20 retained:** canonical keys/values split, shared JSON/CSV metadata, sets omit
  value storage. Delete coupled entries and separate sorted JSON hint/comparer/
  matched flags. Keep real protocol snapshots and namespace bridge. Existing owner
  funds frozen keys; rows fund independent actual values capacity. Delete/clear
  needs no metadata allocation; insert first admits private replacement. Preserve
  aliases, reentrant mutation and a real cancellation-after-admission correction.
  Conservative rejection/retained layouts/sparse scans are explicit tradeoffs.
  Complete-job allocation: CSV−12.73/−11.57%, JSON−14.99/−14.98%, report−9.43/−9.43%
  sync/async; text/scalar controls flat. Separate quiet B361: JSON warm−10.89–12.53%,
  report warm−5.36–8.80%/fresh−8.53–10.52%. CSV elapsed−1.22–2.46%, CPU adverse.
  Text B361+5.01/−0.53% with5.28% identical-build spread; B362 confirmation+0.90/
  −1.21%, then+2.73/+5.53%, CPU adverse in second block. **Possible text regression
  is accepted debt**, not parity or an all-workload speedup. Retain for coherent
  record/storage gains; prioritize text next. No more retiming scheduled for R20.
  Evidence2026-11-06-record-layout includes every failure/partial/adverse condition.
  B359–B362 terminal; never query their services again.

Primary external baseline is now B367/4fad63c5, complete312.23s/all gates:
fresh CSV1.25–1.26x,text1.77–1.79x,JSON1.08–1.11x,report1.50–1.53x,
config1.21–1.22x CPython. Warm:1.31–1.32/1.88–1.90/1.08–1.09/1.32–1.37/
1.28–1.29x. Compile44–73us separately. JSON fresh2.13%role spread/report warm
3.47%spread/3.95%IQR remain variable. Includes mediated RAM I/O, validation and
prior-result cleanup; excludes startup/staging/final teardown. No causal per-change
gain or inferred cost from subtracting medians. Earlier B352/b665 and adverse
source pairs remain linked; the primary guide does not claim HEAD qualification.
Evidence benchmarks/results/2026-11-06-current-cpython/. B367 terminal, never query.

## Priority 1 — current complete-script checkpoint, then evidenced redesign

**R21 retained/fully qualified:** route pending child/generator errors
at driver resumption after operand cleanup, retain delegate forwarding, derive
completed returns from nonnull ReturnValue and delete HasReturn/per-instruction
signal polling. Keep current instruction spans, disposal order and every guard.
No new dispatcher/option/cache. Full ordinary actual11/10 and installed consumers
pass; combined platform/Stress/package checkpoint above is GREEN. Evidence:
benchmarks/results/2026-11-06-frame-resume-boundaries/.

Controlled B366 completes108.57s/all gates: warm text−3.00–5.59%, fresh−0.79% to
+0.02%, report/CSV small; unchanged compilation also−1.47–2.23%, allocation flat.
Modest warm evidence, no general CPU gain or closure of R20 text debt. Source gate
reuses flat storage/call facts; thirteen executed word-loop instructions plus two
cleanup stores, native words helper already3nodes. All source/profile/preflight/
parser failure history is behind that evidence link. B363–B366 terminal; never
query their services again or automatically recapture the limited profile.

**B367 complete:** primary docs refreshed from the actual frozen source. All15
existing jobs/goldens, terminal balances, quiet endpoints, joined users, fixture
cleanup and under-lease archive SHA pass. No retiming scheduled without a new
question; report CPython fresh below warm is preserved as separate job evidence.

**R22 retained/committed:** fixed plain functions/signatures are application
metadata; mutable builtin types, exceptions and namespaces remain per-run.
Remove repeated wrapper/parameter-array construction and interning lookups from
invocation setup. Existing isolation scenarios now cover33plain functions,
sequential/suspended execution, current module identity, refusal and retained funds.
No new API/cache tier/owner/policy. Initial builtin namespace inventory order is
regrouped; user-dictionary insertion semantics stay unchanged.
Evidence benchmarks/results/2026-11-06-builtin-initialization/.

Factory allocation13,064→10,376B/table (−2,688B); desktop timing is diagnostic.
Eight complete-job allocation cases/both APIs pass all semantic/funding/isolation
gates; ordinary script allocation reductions under0.2%, large config about1.17%.
Quiet B36888.20s/all gates: small config warm−1.13–2.44%, fresh−1.43% to+0.13%;
unchanged compilation−1.20–1.63%, text identical-role spread4.10%. No broad CPU
gain or closure of text debt. Retain coherent metadata lifetimes; no unchanged
confirmation scheduled without a specific new question. B368 terminal; never query it.

Source gate also closes disproved proposals: CSV already uses bulk candidate scans,
in-place native input and row transfer/shared keys. Writer per-scalar work is real
but ordinary summary writes too few rows to prove dominance. Projection exports
only returned values/output, not globals. General windows still add8B/object as
the withdrawn designs did. Re-enter only with a distinct eliminated-work model.

**R23 active — reuse regex validation programs under their compilation owner.**
Source demonstrates frontend analysis compiles constant patterns, copies capture
metadata and closes every handle; execution then compiles the identical request
again. Core contract already requires immutable concurrent patterns without saved
caller tokens. Select a bounded artifact-lifetime migration, not a new regex engine
or global cache. Regex extraction is still about7xCPython in diagnostic evidence;
removing duplicate compilation is a hypothesis, not an attributed fraction.
The current public-API probe confirms1compilation/disposal during Compile and one
additional compilation/disposal per Run (3total for two runs), with successful
results and39,397B compiled baseline restored after each run/final0 after disposal.
Normal0.4 one-shot matching also succeeds after its compilation token is cancelled;
the remaining creation-token coupling is cursor-specific and already bridged.
Design and raw probes: .git/agent-notes/review-20261031/regex-program-artifacts-r23/.
Prototype removes analysis-only program retirement for valid public compilation
and duplicate provider compilation for the same native request. Verified normal0.4
probe:1compile/0disposals through two runs, then1disposal on script cleanup/root0;
baseline was3compiles/3disposals. Compiled reservation39,397→105,481B is the
explicit retention cost. This is a source/ownership result, not a CPU claim.
Analysis-only contexts/imports and invalid compilation retain immediate cleanup.
Guest-visible group-name strings remain execution-owned: sharing those mutable
caches would use the compile governor concurrently and is deliberately rejected.
Private probe initially selected a frozen old assembly through MSBuild candidate
search; preserve original output/hash, fixed explicit search and gate actual image
before use. No VM comparison ran with that image.

Design gate/implementation: retain successful analysis programs in one existing-
scope-backed compiled-program cache, keyed natively by UTF8 plus exact normalized
flags/verbose dispatch. Reuse immutable programs for matching runtime requests;
keep guest pattern wrappers and512-entry per-run cache identities/re.purge semantics.
Dynamic requests still compile normally. Borrow programs during runs; dispose only
owned handles after users finish. CompiledScript already requires awaiting runs
before disposal. Do not add tracing, reference ledgers, default budgets, fallback
after refusal or another provider dialect. Keep one provider across imports.

Displaced work: analysis-only handle retirement on valid compilation, repeated
runtime provider compilation for the same proven request; keep run-owned name copies. Invalid
compilation and exceptions still close all acquired handles. Compilation owners
will conservatively retain programs until script disposal; earlier denial/larger
resident compiled baselines are an explicit contract tradeoff, not uncharged cache.
Keep standalone frontend/import analysis cleanup correct; import artifact reuse
can be a separately scoped later extension, with no semantic regression.

Acceptance: exact flags including unusual flag protocols/effective inline flags,
UTF8/scalar windows/names, cache/purge identity, rebinding, independent current
tokens after compilation token cancellation; sequential/concurrent and suspended
runs, invalid compile/refusal cleanup, retained cache funding and root reuse.
Use cooperating provider contract tests and normal adapter semantic/concurrency
checks separately. No backend speed claim from contract tests. Prefer retaining
existing ownership fields/scopes; delete displaced analysis lifetime bookkeeping.
One bounded existing extraction warm/fresh source pair plus text/compile controls,
normal GC/tiering, two identical current roles; preserve adverse results. Stop
after a canonical lifetime migration and explicit retain/revise/withdraw decision.

Non-regex roadmap remains active after R23. Complete call/frame/operand storage
and native helpers are delivered; ordinary binding under2% is not a new arena case.
Machine-integer transport must use one exact-promotion/identity/hash/projection
convention; R16 exposes45direct-type assumptions, not proof of a CPU win. Frontend
already shares lexical facts. Require actual eliminated work before selecting a
next redesign; no broad profiling/ownership audit or guarded-fusion tweak series.

## Independent regex track

Core Python-specific UTF8/byte-range/scalar-window/flags/ownership/cancellation
work does not wait for a release. U04 works with normal0.4 and private immutable
dev44 bridge. The latter qualifies native high-water working admission and256KiB
bounded matching; prior peak32,880→2,064B, allocation+128B/cursor, diagnostic
elapsed+9.1% remain separate evidence. Normal0.4 pin remains unchanged.

**Development46 refresh:** immutable0.5.0-dev.46 inputs from package source
6957b35a independently copied/hash-verified. Existing U04/native-working bridge
source is byte-identical; documented member IDs unchanged from44 on both TFMs.
Private isolated builds and85internal/482public tests pass per actual11/10,
including cursor funding/refusal/reuse and actual cancellation. Normal source,
pin0.4, core dependency graph and adapter nonpackability hashes verified unchanged.
Evidence committed6b8748e6 at
benchmarks/results/2026-11-06-regex-dev46-compatibility/. No production promotion
or Lython performance claim from producer timings. Final released-package/safety
checks remain separate.

Final adapter capabilities still missing: DetailedData cannot choose Prepare's
independent working owner; keep conservative one-shot preflight. Native UTF8
lookup cannot enumerate names; keep adapter-local name conversion. Native cursors still combine creation/per-operation tokens; the already-qualified
adapter-local synthetic CTS/operation registrations provide current-token semantics.
A producer API with sole per-operation authority would remove that bridge; this is
a simplification opportunity, not a core compliance/development blocker. Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges are allowed;
qualify the final immutable released package and managed-safety compliance when
available. No core dependency/type edges, dialect fallback, quotas or sibling edits.

## Working/measurement contract

Unstable controls, timeouts and inconclusive data establish uncertainty, not a
failed design. Allow bounded justified confirmation/refinement/correction; retain
original conditions and adverse data. Percentages inform decisions, not automatic
vetoes/permanent closures. Distinguish simplification, allocation, elapsed and CPU.
Refresh representative CPython at coherent checkpoints, separating compile/warm/
fresh and explicit I/O/cleanup; no another framework or10min development lanes.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host CancellationToken and borrowed shared admission/capacity/replacement/
escaping aliases. First refusal fails the command, no retry/recovery. No fuel,
quotas, hidden caps/default allowance, tracing, weak reclamation or forced GC.
Await all users/cleanup. Initial streaming uses bounded host executions; XML depth
constraint remains. Never fund a still-retained alias by refunding its owner.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch platform/actual11/10/original Stress/
installed consumers at coherent boundaries; don't repeat completed qualification.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: owned lease, actual Ready
hashes, manifest IDs/quiet/goldens/funding/joins and verified persistent archives.
No SSH during capture. Disk near full: verify real headroom and retire only exact
redundant copies with independent backups, ended users and dependency checks.
Keep executing after a delivery/experiment; publication/tagging remain postponed.
