from pathlib import Path
import ast
home=Path(__file__).parent
s=(home.parent/'invocation-definitions-r22/prepare-comparison.py').read_text(encoding='utf-8')
s=s.replace("root=home/'b368'", "root=home/'b369'")
s=s.replace("old=home.parent/'text-operands-r21/b366';prior='/home/lokad/lython-bench-checks/resume-boundary-b366-20261106';remote='/home/lokad/lython-bench-checks/builtin-definitions-b368-20261106'", "old=home.parent/'invocation-definitions-r22/b368';prior='/home/lokad/lython-bench-checks/builtin-definitions-b368-20261106';remote='/home/lokad/lython-bench-checks/regex-programs-b369-20261106'")
s=s.replace("home/'focused-results.json'", "home/'focused-updated.json'")
s=s.replace("sourceRevision='a4a1c306 plus R22 canonical builtin initialization'", "sourceRevision='41c25958 plus R23 compiled provider-program lifetime migration'")
s=s.replace("referenceSourceRevision='4fad63c5 runtime, frozen c3e65ad3; all production source hashes match a4a1c306 baseline'", "referenceSourceRevision='41c25958 source, frozen B368 a87cd017; all baseline production source hashes identical'")
s=s.replace('R22 three-role complete config warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh', 'R23 program lifetime reuse: extraction warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh')
s=s.replace('R22 consolidates plain builtin definitions and immutable constructor signatures; every run retains fresh mutable type/exception graphs and namespace.', 'R23 borrows validated immutable provider programs from the funded compiled-script owner; per-run names, wrappers, module identity, purge, tokens and cleanup remain independent. Larger retained compilation baseline and earlier denial are deliberate tradeoffs.')
s=s.replace('config warm/fresh', 'regex extraction warm/fresh')
a=s.index('for name in [\'collect.py\'')
b=s.index("with tarfile.open(root/'payload.tgz'",a)
s=s[:a]+'''for name in ['collect.py','archive-owned.py','run.sh']:
    content=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    content=content.replace("('scripts.config-edit.small','warm'),('scripts.config-edit.small','compile-run')", "('scripts.regex-capture-summary.large','warm'),('scripts.regex-capture-summary.large','compile-run')")
    content=content.replace('R22 three-role complete config warm/fresh, text warm and unaffected JSON compilation; not a CPython refresh',identity['purpose'])
    write(name,content)
shutil.copyfile(home/'comparison-catalog.json',root/'representative.json')
'''+s[b:]
s=s.replace("['Lokad.Lython.dll','identity.json'", "['representative.json','Lokad.Lython.dll','identity.json'")
s=s.replace("for name in ['representative.json','cpython-worker.py']", "for name in ['cpython-worker.py']")
s=s.replace("['scripts.config-edit.small','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']", "['scripts.regex-capture-summary.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']")
s=s.replace('lython-b368-builtin-definitions-20261106','lython-b369-regex-programs-20261106').replace('b368-launch.py','b369-launch.py')
ast.parse(s)
(home/'prepare-comparison-expanded.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(home/'prepare-comparison-expanded.py'),'exec'))
