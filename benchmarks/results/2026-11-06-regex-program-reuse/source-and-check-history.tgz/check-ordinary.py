from pathlib import Path
import os,subprocess,json
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
results={}
for tfm in ['net11.0','net10.0']:
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        name=suite+'-'+tfm;log=root/('ordinary-'+name+'.log')
        with log.open('w',encoding='utf-8') as out:
            p=subprocess.run([env['DOTNET_HOST_PATH'],'test',f'tests/{suite}/{suite}.csproj','-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off'],env=env,stdout=out,stderr=subprocess.STDOUT)
        text=log.read_text(encoding='utf-8')
        results[name]=dict(exitCode=p.returncode,summaries=[s for s in text.splitlines() if 'Passed!' in s or 'Failed!' in s])
        (root/'ordinary-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(name,results[name],flush=True)
        if p.returncode:raise SystemExit(p.returncode)
