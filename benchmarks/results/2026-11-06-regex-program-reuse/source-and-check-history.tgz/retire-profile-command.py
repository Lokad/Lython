from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');folder=base/'architecture-20261031-07c150a6';target=folder/'perf/csv-warm/perf.data'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert target.resolve()==target and target.is_file() and target.stat().st_size==8275272 and target.stat().st_nlink==1
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve()==target]
 actual=subprocess.check_output(['sudo','-n','sha256sum',str(target)],text=True).split()[0]
 assert actual=='212cb053586dc04d60a9513b7f019f552c01bd58ed962f7c58e74bc588d7865d'
 # Independent committed/pushed local raw archive was verified before this call.
 # Keep all other source/metadata/maps and every binary/dependency path intact.
 subprocess.run(['sudo','-n','rm','--',str(target)],check=True)
 assert not target.exists()
 print(json.dumps(dict(retiredExactExpandedCopy=str(target),bytes=8275272,rawSHA256=actual,independentArchiveSHA256='930742071d9d1578cf61e9dc02a29adc2df1d53d6fc2498e0134238eb55190cd',freeBytes=shutil.disk_usage(base).free,allUsersEnded=True,noSymlinkDependencies=True),indent=2))
