from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent;repo=Path('D:/code/Lython')
archive=repo/'benchmarks/results/2026-10-31-architecture-profiles/profile-evidence.tar.gz'
gitpath=archive.relative_to(repo).as_posix();data=archive.read_bytes()
assert data==subprocess.check_output(['git','show','HEAD:'+gitpath]),'Require committed independent raw archive'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True)==subprocess.check_output(['git','rev-parse','origin/master'],text=True),'Require the already-pushed evidence head'
with tarfile.open(archive) as a:
    matches=[m for m in a.getmembers() if m.isfile() and m.name.endswith('perf/csv-warm/perf.data')]
    assert len(matches)==1,[m.name for m in matches]
    member=matches[0];raw=a.extractfile(member).read();assert len(raw)==8275272
digest=hashlib.sha256(raw).hexdigest();archivehash=hashlib.sha256(data).hexdigest()
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');folder=base/'architecture-20261031-07c150a6';target=folder/'perf/csv-warm/perf.data'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert target.resolve()==target and target.is_file() and target.stat().st_size==8275272 and target.stat().st_nlink==1
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve()==target]
 actual=subprocess.check_output(['sudo','-n','sha256sum',str(target)],text=True).split()[0]
 assert actual=='RAWHASH'
 # Independent committed/pushed local raw archive was verified before this call.
 # Keep all other source/metadata/maps and every binary/dependency path intact.
 subprocess.run(['sudo','-n','rm','--',str(target)],check=True)
 assert not target.exists()
 print(json.dumps(dict(retiredExactExpandedCopy=str(target),bytes=8275272,rawSHA256=actual,independentArchiveSHA256='ARCHIVEHASH',freeBytes=shutil.disk_usage(base).free,allUsersEnded=True,noSymlinkDependencies=True),indent=2))
'''.replace('RAWHASH',digest).replace('ARCHIVEHASH',archivehash)
(root/'retire-profile-command.py').write_text(script,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
r=subprocess.run([*ssh,'python3 -'],input=script,capture_output=True,text=True,encoding='utf-8')
(root/'retired-profile-receipt.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stdout+r.stderr
print(r.stdout,flush=True)
