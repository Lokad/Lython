from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-06-regex-program-reuse')
identity=json.loads((root/'b369/identity.json').read_text(encoding='utf-8'))
actual={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
assert actual==identity['sourceSHA256'],'Never transfer timing to a different production source'
r=json.loads((root/'ordinary-results.json').read_text(encoding='utf-8'))
assert len(r)==4 and all(x['exitCode']==0 for x in r.values())
assert (root/'package-consumer-refined.log').read_text(encoding='utf-8').count('Package consumer passed: 0.11.0')==2
for name in ['ordinary-results.json','package-consumer.log','package-consumer-refined.log']:
    shutil.copyfile(root/name,out/name)
with tarfile.open(out/'source-and-check-history.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file():a.add(p,arcname=p.name)
    for name in ['identity.json','source.patch','launch.py','launch.log','setup-contract.json','contract.md']:
        a.add(root/'b369'/name,arcname='b369/'+name)
shutil.copyfile('PLAN.md',root/'PLAN-before-checkpoint-condense.md')
print('Ordinary, installed consumers and exact measured production source verified; history archived.')
