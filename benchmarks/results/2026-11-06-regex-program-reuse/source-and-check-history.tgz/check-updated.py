from pathlib import Path
import os,subprocess
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'build-refined.log').open('w',encoding='utf-8') as out:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build','Lokad.Lython.slnx','-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=out,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/'build-refined.log').read_text(encoding='utf-8')[-2000:]
s=(root/'focused.py').read_text(encoding='utf-8').replace('focused-initial','focused-updated')
(root/'focused-updated.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'focused-updated.py'),'exec'),{'__file__':str(root/'focused-updated.py'),'__name__':'__main__'})
