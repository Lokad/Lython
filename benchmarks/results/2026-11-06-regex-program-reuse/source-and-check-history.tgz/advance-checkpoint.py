from pathlib import Path
import json
root=Path(__file__).parent
prior=root.parent/'invocation-definitions-r22'
ci=json.loads((prior/'delivery-ci-second.json').read_text(encoding='utf-8'))
assert ci['status']=='completed' and ci['conclusion']=='success'
assert ci['headSha']=='41c259588e028d2902ccd9338f3818f8f9c0ea6c'
expected={'Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales'}
assert len(ci['jobs'])==2
for job in ci['jobs']:
    assert job['conclusion']=='success'
    assert {s['name'] for s in job['steps'] if s['conclusion']=='success'}>=expected
for tfm in ['net11.0','net10.0']:
    text=(root/('cached-cancellation-'+tfm+'.log')).read_text(encoding='utf-8')
    assert 'Passed:     1' in text and 'Failed:     0' in text
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('Updated 2026-11-06.', 'Updated 2026-11-07.')
s=s.replace('No active\n  runtime prototype.', 'R23 program-lifetime migration is an uncommitted prototype.')
start=s.index('- **R22 delivery running:**')
end=s.index('- Previous R20',start)
s=s[:start]+'''- **R22 fully qualified:**42310347889 on41c25958 is terminal GREEN, all eight
  Windows/Ubuntu actual11/10, original Stress and installed-package gates checked
  from cached delivery-ci-second.json. Never query this terminal run again.
- **R23 active prototype:**95internal/497public focused checks per actual11/10,
  plus cached-program in-flight cancellation/awaited-cleanup regression per target,
  pass. Release builds0warnings/errors. No elapsed comparison/delivery claim yet.
'''+s[end:]
s=s.replace('**R23 next — reuse regex validation programs under their compilation owner.**','**R23 active — reuse regex validation programs under their compilation owner.**')
s=s.replace('No R23 runtime prototype yet; implement the selected lifetime migration next.', '''Prototype removes analysis-only program retirement for valid public compilation
and duplicate provider compilation for the same native request. Verified normal0.4
probe:1compile/0disposals through two runs, then1disposal on script cleanup/root0;
baseline was3compiles/3disposals. Compiled reservation39,397→105,481B is the
explicit retention cost. This is a source/ownership result, not a CPU claim.
Analysis-only contexts/imports and invalid compilation retain immediate cleanup.
Guest-visible group-name strings remain execution-owned: sharing those mutable
caches would use the compile governor concurrently and is deliberately rejected.
Private probe initially selected a frozen old assembly through MSBuild candidate
search; preserve original output/hash, fixed explicit search and gate actual image
before use. No VM comparison ran with that image.''')
s=s.replace('Reuse program/metadata for matching runtime requests;', 'Reuse immutable programs for matching runtime requests;')
s=s.replace('runtime provider compilation/metadata copies for the same proven request.', 'runtime provider compilation for the same proven request; keep run-owned name copies.')
s=s.replace('confirmation scheduled without a specific new question. B368 terminal, no SSH.', 'confirmation scheduled without a specific new question. B368 terminal; never query it.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Cached R22 all-eight delivery gates and R23 cancellation checked; active plan updated.')
