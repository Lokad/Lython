from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/regex-programs-b369-20261106');prior=Path('/home/lokad/lython-bench-checks/builtin-definitions-b368-20261106')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1927735+1);assert len(payload)==1927735 and hashlib.sha256(payload).hexdigest()=='16cb289107da8f5b707baf25d49cef4cdbf49cf158908e1a46cf6c35275712e2'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+6*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['cpython-worker.py']:(root/name).symlink_to(prior/name)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 folder=root/'candidate';folder.mkdir()
 for p in (prior/'candidate').iterdir():
  if p.suffix=='.pdb':continue
  if p.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:os.link(p,folder/p.name)
  else:(folder/p.name).symlink_to(root/p.name if p.name=='Lokad.Lython.dll' else p.resolve(),target_is_directory=p.is_dir())
 identity=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.regex-capture-summary.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>6*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allFourCatalogJobsValidated=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b369-regex-programs-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
