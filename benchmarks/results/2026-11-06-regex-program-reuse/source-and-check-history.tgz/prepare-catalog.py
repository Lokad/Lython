from pathlib import Path
import json,subprocess
root=Path(__file__).parent;old=root.parent/'regex-capture-u04/b357'
files=[p for p in old.glob('**/representative.json') if 'retrieved' not in p.parts]
if not files:files=list(old.glob('**/representative.json'))
assert files, 'Locate the existing extraction catalog before selecting jobs'
first=json.loads((root.parent/'invocation-definitions-r22/b368/retrieved/representative.json').read_text(encoding='utf-8'))
matches=[]
for file in files:
    data=json.loads(file.read_text(encoding='utf-8'))
    for case in data['cases']:
        if case['id']=='scripts.regex-capture-summary.large':matches.append((file,case))
assert matches and all(c==matches[0][1] for _,c in matches)
assert not any(c['id']=='scripts.regex-capture-summary.large' for c in first['cases'])
first['cases'].append(matches[0][1])
(root/'comparison-catalog.json').write_text(json.dumps(first,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Reused original extraction case from',matches[0][0],matches[0][1]['source'][:1200],flush=True)
s=(root.parent/'invocation-definitions-r22/retire-verified-profile.py').read_text(encoding='utf-8').replace('8954180','8275272').replace('json-warm','csv-warm')
(root/'retire-verified-profile.py').write_text(s,encoding='utf-8')
exec(compile(s,str(root/'retire-verified-profile.py'),'exec'),{'__file__':str(root/'retire-verified-profile.py'),'__name__':'__main__'})
