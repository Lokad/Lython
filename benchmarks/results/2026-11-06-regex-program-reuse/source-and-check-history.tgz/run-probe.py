from pathlib import Path
import hashlib,os,subprocess,sys
root=Path(__file__).parent;repo=Path('D:/code/Lython');env=os.environ.copy()
stem=sys.argv[1] if len(sys.argv)>1 else 'baseline'
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (root/(stem+'-build.log')).open('w',encoding='utf-8') as output:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(root/'ArtifactProbe.csproj'),'-c','Release','--nologo','--tl:off','-p:LythonCorePath='+str(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'),'-p:LythonAuxPath='+str(repo/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0')],env=env,stdout=output,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/(stem+'-build.log')).read_text(encoding='utf-8')[-2500:]
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert hashlib.sha256(core.read_bytes()).digest()==hashlib.sha256((root/'bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).digest(),'Require the selected current image before observing work counts'
p=subprocess.run([env['DOTNET_HOST_PATH'],str(root/'bin/Release/net11.0/ArtifactProbe.dll'),stem],env=env,capture_output=True,text=True,encoding='utf-8')
(root/(stem+'-probe.json')).write_text(p.stdout,encoding='utf-8');(root/(stem+'-probe.stderr')).write_text(p.stderr,encoding='utf-8');assert p.returncode==0,p.stderr
print(p.stdout,flush=True)
