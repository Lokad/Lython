from pathlib import Path
import re
p=Path('tests/Lokad.Lython.PublicApi.Tests/RegexProviderContractTests.cs');s=p.read_text(encoding='utf-8')
def edit(name,transform):
    global s
    pos=s.index('    public ',s.index(name)-40);end=pos+re.search(r'\n    \[(?:Theory|Fact)\]',s[pos:]).start()
    block=s[pos:end];updated=transform(block);assert updated!=block,name;s=s[:pos]+updated+s[end:]
def native(block):
    old='Assert.Equal(provider.Compilations, provider.ClosedPatterns);';assert block.count(old)==2
    block=block.replace(old,'var compilations = provider.Compilations;\n            Assert.Equal(0, provider.ClosedPatterns);',1)
    block=block.replace(old,'Assert.Equal(compilations, provider.Compilations);\n                Assert.Equal(0, provider.ClosedPatterns);',1)
    return close_after_scope(block)
def close_after_scope(block):
    old='        }\n        Assert.Equal(0, budget.ReservedBytes);';assert block.count(old)==1
    return block.replace(old,'        }\n        Assert.Equal(provider.Compilations, provider.ClosedPatterns);\n        Assert.Equal(0, budget.ReservedBytes);')
edit('NativeGroupNamesSurviveBorrowedMetadataDisposalAndUsePythonOrder',native)
edit('FrontendAndRuntimePassOriginalSubjectAndAbsoluteWindowCaptures',lambda b:close_after_scope(b.replace('Assert.Equal(provider.Compilations, provider.ClosedPatterns);','Assert.Equal(0, provider.ClosedPatterns);')))
edit('FrontendClosesPatternsAfterSuccessOrDiagnostic',lambda b:close_after_scope(b.replace('FrontendClosesPatternsAfterSuccessOrDiagnostic','FrontendProgramsCloseOnDiagnosticOrScriptDisposal').replace('Assert.Equal(provider.Compilations, provider.ClosedPatterns);','Assert.Equal(diagnostic ? provider.Compilations : 0, provider.ClosedPatterns);')))
p.write_text(s,encoding='utf-8')
