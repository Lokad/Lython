from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent;repo=Path('D:/code/Lython')
result=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sourceSHA256={},coreSHA256={})
with tarfile.open(root/'baseline-source.tgz','w:gz') as a:
    for p in (repo/'src/Lokad.Lython').rglob('*.cs'):
        if {'bin','obj'}.intersection(p.parts):continue
        name=p.relative_to(repo).as_posix();result['sourceSHA256'][name]=hashlib.sha256(p.read_bytes()).hexdigest();a.add(p,arcname=name)
for tfm in ['net11.0','net10.0']:
    folder=root/'baseline'/tfm;folder.mkdir(parents=True)
    p=repo/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll';shutil.copyfile(p,folder/p.name);result['coreSHA256'][tfm]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'baseline.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');shutil.copyfile('PLAN.md',root/'PLAN-before-implementation.md')
print(result['head'],result['coreSHA256'],flush=True)
