using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

var budget = new LythonMemoryBudget(2 * 1024 * 1024);
var provider = new ObservedProvider();
using var compilation = new CancellationTokenSource();
var script = new LythonEngine(provider).Compile("import re\nreturn re.search('(?P<value>a)', subject).group('value')", budget, compilation.Token);
if (!script.IsValid) throw new InvalidOperationException(string.Join(";", script.Diagnostics.Select(d => d.Message)));
var baseline = budget.ReservedBytes;
var afterCompilation = new { provider.Compilations, provider.Disposals, budget.ReservedBytes };
compilation.Cancel();
var runs = new List<object>();
for (var run = 0; run < 2; run++)
{
    using (var result = script.Run(new NoCapabilities(), new LythonRunOptions { MemoryBudget = budget,
        Globals = new Dictionary<string, object?> { ["subject"] = "a" } }))
    {
        if (!result.Success || !Equals(result.ReturnValue, "a")) throw new InvalidOperationException(result.Failure?.Message ?? "Wrong result");
    }
    if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Run ownership leaked");
    runs.Add(new { run, provider.Compilations, provider.Disposals, budget.ReservedBytes });
}
script.Dispose();
if (budget.ReservedBytes != 0 || provider.Compilations != provider.Disposals) throw new InvalidOperationException("Final ownership leaked");
var independentCompilationToken = false;
using (var owner = budget.CreateScope())
using (var earlier = new CancellationTokenSource())
using (var pattern = Utf8RegexProvider.Instance.Compile("(?P<value>a)"u8.ToArray(), new(32, false), owner, earlier.Token))
{
    earlier.Cancel();
    using var subject = pattern.Prepare("a"u8.ToArray(), new(0, 1, 0, 1), owner, default);
    independentCompilationToken = subject.TryMatch(LythonRegexMatchMode.Search,
        new LythonRegexCapture?[pattern.CaptureSlotCount], out _, default);
}
if (!independentCompilationToken || budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation token leaked into matching or ownership");
Console.WriteLine(JsonSerializer.Serialize(new { source = args.Length == 0 ? "41c25958" : args[0], afterCompilation, runs,
    independentCompilationToken,
    afterDisposal = new { provider.Compilations, provider.Disposals, budget.ReservedBytes },
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))) }, new JsonSerializerOptions { WriteIndented = true }));

sealed class ObservedProvider : ILythonRegexProvider
{
    internal int Compilations, Disposals;
    public ILythonRegexPattern Compile(ReadOnlyMemory<byte> pattern, LythonRegexOptions options, ILythonMemoryBudget owner, CancellationToken token)
    { Compilations++; return new ObservedPattern(Utf8RegexProvider.Instance.Compile(pattern, options, owner, token), this); }
    sealed class ObservedPattern(ILythonRegexPattern inner, ObservedProvider observer) : ILythonRegexPattern
    {
        private bool _disposed;
        public int Flags => inner.Flags;
        public int CaptureSlotCount => inner.CaptureSlotCount;
        public IReadOnlyList<LythonRegexNamedGroup> NamedGroups => inner.NamedGroups;
        public ILythonRegexSubject Prepare(ReadOnlyMemory<byte> subject, LythonRegexWindow window, ILythonMemoryBudget owner, CancellationToken token)
            => inner.Prepare(subject, window, owner, token);
        public void Dispose() { if (_disposed) return; _disposed = true; inner.Dispose(); observer.Disposals++; }
    }
}
sealed class NoCapabilities : ILythonHost, ILythonSynchronousHostCapability
{
    public bool CompletesSynchronously => true;
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest from, LythonPathRequest to, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
