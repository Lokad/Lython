# R23 design gate, 2026-11-06 UTC

Source41c25958 is committed; no R23 runtime edit yet. The private public-API probe
uses the normal0.4 adapter and actual core9e500940 (explicit Release package source).
It observes1provider compilation/disposal during Compile, then one more per Run,
even with the same constant request. Two successful runs return to39,397B compiled
baseline; script disposal returns0. This establishes duplicate work/lifetimes,
not a CPU fraction or performance result. Keep both original/direct-token JSONs.

The direct-token extension separately proves that a pattern compiled with an
earlier token can match after that token is cancelled. Normal0.4 does not retain
the compilation token for matching. Existing CursorUsesCurrentAdvanceToken also
qualifies its synthetic-CTS bridge. Producer creation-token coupling concerns
removing that cursor bridge, not a current core/adapter compliance blocker.

Selected coherent change: preserve provider programs already acquired by frontend
validation under the compiled script's existing owner, and borrow them for exact
runtime requests. Do not cache scripts, introduce a global program cache, new
allowances, reference ledgers or provider policies. This removes duplicate work
even for a newly generated script compiled once and run once.

Implementation map:

1. Small internal CompiledRegexPrograms owns the existing lazy child scope and
   acquired handle list currently held by StaticAnalysisContext. Add native keys
   (PyString/normalized flags/verbose) and immutable program/capture metadata.
   Only analysis writes before publication; runs read concurrently. Fund metadata,
   capacity and construction overlap before allocation (rough512B+encoded capacity
   per request, replacing old256B estimate). No hidden cache count allowance.
2. StaticAnalysisContext retains its ephemeral CLR-string/flag alias map for
   analysis, and borrows this artifact owner when supplied. Its standalone/import
   use creates and closes its own owner exactly as today. Remove its displaced
   _regexOwner/_regexHandles bookkeeping. Runtime lookup keys use exact requested
   LythonRegexOptions, never blindly reuse an effective-flag analysis alias when
   verbose dispatch differs through a guest flag protocol.
3. Public CompileCore creates the artifact owner, supplies it to frontend analysis,
   closes it on invalid compilation or any exception, and transfers it only on
   success to LythonCompiledScript. Dispose handles before ending compilation
   funding. Script already requires callers to await all runs before disposal;
   no new active-run/refcount machinery. Root regex cache may now remain resident
   until script disposal: document larger compiled baselines/earlier denial.
4. Pass the borrowed cache through LythonRuntime/root ExecutionContext/ExecutionState.
   Preserve current provider consistency across imports. RePatternObject wrappers
   and existing512-entry per-run cache/purge stay private per run. Cache misses
   compile/own handles as today; borrowed artifacts must never enter the run's
   TrackRegexPattern disposal list or be disposed on wrapper admission failure.
   Reuse immutable named-group metadata under the script owner; guest/public
   groupindex projections retain their existing result funding. Returning raw
   RePattern/ReMatch objects is already rejected by PublicProjection.
5. Native key hashing must honor the active compile/run token during large scans.
   Reuse PyString UTF8 hashing with an explicit-token cold overload and existing
   chunk checkpoints; cached hashes retain no token. Keep the current cheap cached
   GetHashCode fast path. Do not decode runtime patterns to CLR strings for keys.
6. Focused semantics/ownership/cancellation tests: exact flags/inline aliases,
   keyword/flag side effects before lookup, cache/purge identity, dynamic misses,
   invalid compile/failure cleanup, independent tokens, concurrent runs, retained
   cache funding, denied wrapper/working storage and sequential budget reuse.
   Provider compile/dispose observations are externally visible work/lifetime
   assertions, not tests of a discarded dispatch architecture. Normal adapter's
   actual shared-program concurrency must be qualified separately.
7. Use an existing extraction script for one bounded warm/fresh source pair plus
   text/compile controls (frozen R22/reference, current, identical current). No
   attribution from source counts or synthetic provider tests, no broad profile.
   Decide retention/debt after the coherent migration. Import-local artifact reuse
   is a separate later extension, not a general compiler rewrite.

Critical source locations: Public/LythonEngine.cs:CompileCore,
Public/LythonCompiledScript.cs:Dispose; Frontend/LythonFrontend.cs and
StaticAnalysisContext.cs; StaticRegexReturnResolver.cs:TryCompileRegex;
Runtime/LythonRuntime.RegexCompiler.cs:Compile; ExecutionState and root context
construction in LythonRuntime.cs/Executable.cs. Provider programs are immutable
and concurrent by contract; their disposal is synchronous/nonthrowing and caller
drained. No pattern/metadata borrows may outlive the compiled owner.
