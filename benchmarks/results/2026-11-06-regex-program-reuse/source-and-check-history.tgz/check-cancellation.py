from pathlib import Path
import os,subprocess
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
project='tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
with (root/'build-cached-cancellation.log').open('w',encoding='utf-8') as out:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build',project,'-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=out,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/'build-cached-cancellation.log').read_text(encoding='utf-8')[-2000:]
for tfm in ['net11.0','net10.0']:
    log=root/('cached-cancellation-'+tfm+'.log')
    with log.open('w',encoding='utf-8') as out:
        p=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',tfm,'--no-build','--no-restore','--nologo','--tl:off','--filter','FullyQualifiedName~CachedProgramCancellation'],env=env,stdout=out,stderr=subprocess.STDOUT)
    print(tfm,p.returncode,log.read_text(encoding='utf-8')[-1500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
