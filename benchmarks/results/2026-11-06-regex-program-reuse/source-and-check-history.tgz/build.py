from pathlib import Path
import os,subprocess
root=Path(__file__).parent;env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with (root/'build-prototype.log').open('w',encoding='utf-8') as out:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build','Lokad.Lython.slnx','-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=out,stderr=subprocess.STDOUT)
print(p.returncode,(root/'build-prototype.log').read_text(encoding='utf-8')[-2200:],flush=True)
raise SystemExit(p.returncode)
