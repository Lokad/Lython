from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
donor=lab.parent/'closure-result-consumer-20261123/candidate'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
identity=read(lab/'comparison/identity.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
catalog=lab/'comparison/representative.json'
data={}
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(sha(image/n)==h for n,h in files.items())
    for name in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'):
        shutil.copyfile(donor/name,image/name)
    output=lab/(role+'-tape.json')
    subprocess.run([dotnet,image/'Inspect.dll',catalog,output],env=env,check=True,timeout=35)
    proof=read(output)
    assert proof['coreSHA256']==identity['coreSHA256'][role]
    data[role]=proof['rows']

selected=[]
for old,new in zip(data['reference'],data['candidate'],strict=True):
    assert old['id']==new['id']
    for a,b in zip(old['codes'],new['codes'],strict=True):
        before=a.pop('directDefinitionReturn')
        after=b.pop('directDefinitionReturn')
        assert a==b
        if before!=after:
            assert after and b['name']=='compile_rule' and b['instructions']==7
            selected.append(dict(case=new['id'],function=b['name'],opcodes=b['opcodeCounts'],workspace=b['capacity']))
assert {r['case'] for r in selected}=={
    'scripts.annotated-rule-closures.nested-factories.postponed','scripts.factory-observed-defaults'}

image=lab/'candidate'
listing=lab/'computed-definition.asm'
result=lab/'candidate-jit-allocation.json'
subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,catalog,result],
    env=dict(env,DOTNET_TieredCompilation='0',DOTNET_JitDisasm='CreateClosedComputedDefinition',
             DOTNET_JitStdOutFile=str(listing)),check=True,timeout=45)
assert 'Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition' in listing.read_text(encoding='utf-8-sig')
assert all(row['sharedBudgetBaselineRestored'] for row in read(result)['rows'])
(lab/'selected-returns.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(selected))
