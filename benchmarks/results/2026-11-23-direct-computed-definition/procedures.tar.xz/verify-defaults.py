from pathlib import Path
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
dotnet=Path.home()/'.dotnet11/dotnet.exe'
python=Path('C:/Python313/python.exe')
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
write=lambda path,data:path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=read(lab/'comparison/identity.json')
catalog=read(lab/'comparison/representative.json')
template=catalog['cases'][0]
catalog['cases']=[]
inputs=[('add','+',2),('sub','-',-3),('mul','*',3),('floordiv-positive','//',3),
        ('floordiv-negative','//',-3),('floordiv-zero','//',0),('floordiv-unit','//',-1),
        ('mod-positive','%',3),('mod-negative','%',-3),('mod-zero','%',0),('mod-unit','%',-1),
        ('pow','**',2),('division','/',-3)]
for case,op,right in inputs:
    source=f'''from __future__ import annotations
def bind(weight):
    def create(seed):
        def value(record: int, /, base: int = seed {op} {right}, *, scale = weight):
            return base, scale
        return value
    return create

class Reflected:
    def __add__(self, other): return 109
    def __sub__(self, other): return 111
    def __mul__(self, other): return 113
    def __floordiv__(self, other): return 117
    def __mod__(self, other): return 123
    def __pow__(self, other): return 127
    def __truediv__(self, other): return 129

shared = [[]]
create = bind(shared)
values = (7, -7, -9223372036854775808, 9223372036854775807, 2**75, True, Reflected())
for seed in values:
    try:
        value = create(seed)
        other = create(seed)
        pair = value(0)
        print(pair[0], pair[1] is shared, pair[0] is value.__defaults__[0],
              value.__defaults__ is not other.__defaults__, list(value.__annotations__))
    except ZeroDivisionError:
        print('division by zero')
'''
    # Keep the local CPython as an output oracle. Timing uses the VM version.
    result=subprocess.run([python,'-I','-S','-X','utf8','-c',source],encoding='utf-8',capture_output=True,check=True,timeout=8)
    expected=result.stdout
    item=dict(template,id='diagnostic.computed-definition.'+case,size=7,source=source,
        fixtureJson='{"size":7,"text":null}',expectedOutput=expected,
        sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
        sourceSha256=sha(source.encode('utf-8')),fixtureSha256=sha(b'{"size":7,"text":null}'),
        expectedOutputSha256=sha(expected.encode('utf-8')))
    catalog['cases'].append(item)
path=lab/'default-semantics.json'
write(path,catalog)
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(sha((image/name).read_bytes())==h for name,h in files.items())
    proof=lab/(role+'-default-semantics.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',path,
        '--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py','--out',proof],
        env=env,check=True,timeout=90)
    data=read(proof)
    assert data['caseCount']==len(inputs) and data['state']=='Completed'
    assert data['catalogSha256']==sha(path.read_bytes())
    assert data['launched']['library']['sha256']==files['Lokad.Lython.dll']
