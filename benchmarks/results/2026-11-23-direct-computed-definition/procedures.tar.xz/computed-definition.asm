; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 35 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 240
       lea      rbp, [rsp+0x120]
       xor      eax, eax
       mov      qword ptr [rbp-0xA8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqa  xmmword ptr [rbp-0x40], xmm4
       mov      gword ptr [rbp+0x20], r8
       mov      rbx, rcx
       mov      rsi, r9
 
G_M000_IG02:                ;; offset=0x0047
       mov      rdi, gword ptr [rdx+0x98]
       lea      rcx, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0xB0], rcx
       mov      rcx, gword ptr [rbx+0x10]
       lea      rdx, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x78], rdx
       mov      dword ptr [rbp-0x70], 2
       mov      r14d, dword ptr [rdi+0x08]
       test     r14d, r14d
       je       G_M000_IG19
       mov      rdx, gword ptr [rdi+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x78]
       mov      r9, r8
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       nop      
 
G_M000_IG03:                ;; offset=0x0093
       cmp      r14d, 1
       jbe      G_M000_IG16
       mov      r15, gword ptr [rdi+0x30]
       mov      r9, gword ptr [rbp+0x20]
       mov      r13, gword ptr [r9+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00BD
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00C9
       mov      rdx, 0x1BB10001E40
       mov      rdx, gword ptr [rdx]
       cmp      r14d, 2
       jbe      G_M000_IG16
       lea      r8, bword ptr [rdi+0x50]
       mov      gword ptr [rbp-0x88], rdx
       mov      qword ptr [rbp-0x80], rsi
       mov      rdx, r8
       lea      r8, [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       mov      r9, gword ptr [r9+0xA0]
       lea      rcx, bword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r14d, 3
       jbe      G_M000_IG16
       mov      rsi, gword ptr [rdi+0x70]
       mov      r9, gword ptr [rbp+0x20]
       mov      r15, gword ptr [r9+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0137
       mov      rcx, r15
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x0143
       lea      rcx, bword ptr [rbp-0x40]
       cmp      r14d, 4
       jbe      G_M000_IG16
       lea      rdx, bword ptr [rdi+0x90]
       mov      rsi, gword ptr [rbp+0x30]
       mov      gword ptr [rbp-0x88], rsi
       xor      r8d, r8d
       mov      qword ptr [rbp-0x80], r8
       lea      r8, [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       mov      r9, gword ptr [r9+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r14d, 5
       jbe      G_M000_IG16
       mov      rsi, gword ptr [rdi+0xB0]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [r9+0xA0]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01AE
       mov      rcx, rdi
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG09:                ;; offset=0x01BA
       mov      rdi, gword ptr [rbx+0x10]
       mov      r14, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rbx+0x28]
       mov      rcx, rdi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      r15d, eax
       cmp      r15d, 2
       ja       G_M000_IG15
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r13, rax
       lea      r8, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x98], r8
       mov      dword ptr [rbp-0x90], r15d
       lea      r8, [rbp-0x98]
       lea      rcx, [rbp-0x68]
       mov      rdx, rdi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       lea      rcx, bword ptr [rbp-0x50]
       mov      edx, r15d
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r15d
       neg      edx
       add      edx, 2
       lea      r8, [rbp-0x68]
       mov      qword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       mov      r9, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rsi
       mov      bword ptr [rbp-0x98], rcx
       mov      dword ptr [rbp-0x90], edx
       mov      gword ptr [rsp+0x48], rbx
 
G_M000_IG10:                ;; offset=0x025B
       mov      gword ptr [rbp-0xA8], r8
 
G_M000_IG11:                ;; offset=0x0262
       mov      dword ptr [rbp-0xA0], r8d
       mov      byte  ptr [rbp-0x9C], 0
 
G_M000_IG12:                ;; offset=0x0270
       mov      dword ptr [rsp+0x58], r8d
 
G_M000_IG13:                ;; offset=0x0275
       mov      bword ptr [rbp-0x78], r8
 
G_M000_IG14:                ;; offset=0x0279
       mov      dword ptr [rbp-0x70], r8d
       lea      rcx, [rbp-0xA8]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0x98]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, rdi
       mov      rdx, r14
       mov      r8, r13
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      edx, r15d
       add      rdx, rdx
       lea      rcx, bword ptr [rbp-0x50]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       jmp      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x02C5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG16:                ;; offset=0x02CC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG17:                ;; offset=0x02D2
       lea      rcx, bword ptr [rbp-0x40]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, bword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      rax, rbx
 
G_M000_IG18:                ;; offset=0x030D
       add      rsp, 240
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x031F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x0325
       sub      rsp, 104
 
G_M000_IG21:                ;; offset=0x0329
       mov      rcx, bword ptr [rbp-0xB0]
       lea      rdx, bword ptr [rcx+0x10]
       mov      rax, rdx
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rcx, bword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG22:                ;; offset=0x0372
       add      rsp, 104
       ret      
 
; Total bytes of code 887

