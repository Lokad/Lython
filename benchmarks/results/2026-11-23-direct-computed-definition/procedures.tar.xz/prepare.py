from pathlib import Path
import json
import shutil

lab=Path(__file__).resolve().parent
prior=lab.parent/'closure-result-consumer-20261123'
factory=lab.parent/'closed-definition-return-20261123'
template=lab.parent/'csv-deferred-number-20261123'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
def install(origin,name,changes):
    text=(origin/name).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in text,(name,a)
        text=text.replace(a,b)
    compile(text,name,'exec')
    (lab/name).write_text(text,encoding='utf-8',newline='\n')

for name in ('representative.json','jobs.json'):
    shutil.copyfile(factory/'comparison'/name,lab/name)
assert len(read(lab/'representative.json')['cases'])==5
install(template,'freeze.py',[
    ('"forwarded-global-call-20261123"','"closure-result-consumer-20261123"'),
    ('".git/agent-worktrees/csv-combined-scan-20261123"','".git/agent-worktrees/direct-computed-definition-20261123"'),
    ("'138e91373'","'2ab453375'"),
    ("identity['candidate'],'--','src','tests'", "identity['candidate'],'--','src'"),
    ("lab/'windows/bin/Lokad.Lython/release_net11.0'/core", "lab.parent.parent/'direct-computed-b1500/windows/bin/Lokad.Lython/release_net11.0'/core"),
    ('B1495 defer non-short numbers through the buffered CSV line commit','B1500 return a definition with prepared numeric and capture defaults'),
    ('on both CSV images','on both factory images'),
])
install(template,'stage.py',[
    ('csv-deferred-number-b1495-20261123','direct-computed-definition-b1500-20261123'),
    ('forwarded-global-call-b1489-20261123','closure-result-consumer-b1497-20261123'),
    ('b1495','b1500'),
])
install(template,'quiet.py',[
    ('csv-deferred-number-20261123','direct-computed-definition-20261123'),
    ('b1495','b1500'),
])
shutil.copyfile(template/'summarize.py',lab/'summarize.py')
shutil.copyfile(prior/'allocations.py',lab/'allocations.py')
