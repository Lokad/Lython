from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r/'b652';out=r/'b654';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/report-external-b652-20261113';root='/home/lokad/lython-bench-checks/captured-external-b654-20261113'
state=json.loads((r.parent/'config-startup-r297/terminal-status.json').read_text(encoding='utf-8'));assert state['exitCode']=='0'and not state['remainingWorkers']and not state['remainingTrace']
info=json.loads((old/'identity.json').read_text(encoding='utf-8'));info['sourceRevision']='Qualified31d65e01/e34cacaf versus CPython3.13.16; largest remaining source-stale captured-text rows; later slot-owner correction excluded'
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large',lane]for lane in ['warm','compile','compile-run']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+collect[end:]
collect=collect.replace('< 420,','< 240,').replace('8 if lane!="compile" else 5','12 if lane!="compile" else 5').replace('warmupSeconds=8, compilationWarmupSeconds=5','warmupSeconds=12, compilationWarmupSeconds=5')
start=collect.index("purpose='");end=collect.index("',\n",start)
collect=collect[:start]+"purpose='Refresh three materially stale captured-text phases versus CPython on the same qualified report checkpoint; exact source/fixtures, current closures/private counters; later metadata correction excluded"+collect[end:]
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('complete=True,jobs=6','complete=True,jobs=3')
ast.parse(archive);(out/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8',newline='\n')
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','identity.json']}
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name,p in files.items():archive.add(p,arcname=name)
config=dict(root=root,unit='lython-b654-captured-external-20261113',sourceRoot=oldroot,identity=info,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(r/'launch-external.py').read_text(encoding='utf-8').replace("Path(__file__).parent/'b652'","Path(__file__).parent").replace('lython-b652-fixtures','lython-b654-fixtures').replace('RuntimeMaxSec=480','RuntimeMaxSec=300').replace('seconds=540','seconds=360').replace('ownerSeconds=480','ownerSeconds=300')
ast.parse(launch);(out/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace('report-external-b652-20261113','captured-external-b654-20261113').replace('lython-b652-report-external-20261113','lython-b654-captured-external-20261113').replace("['jobs']==6","['jobs']==3").replace("['elapsedSeconds']<540","['elapsedSeconds']<360").replace('B652 six-job','B654 three-job')
ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
analyze=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('complete=True,jobs=6','complete=True,jobs=3')
ast.parse(analyze);(out/'summarize.py').write_text(analyze,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='3. **D02c — continue substantial whole-pipeline redesigns.**\n'
s=s.replace(needle,needle+'''   - Active B654 closes the largest remaining stale external comparison: captured
     text/helper counter, warm/compile/compile-to-result, same qualified31d65e01/
     e34cacaf as the report checkpoint. Three jobs/four repeated roles using existing
     workers/catalog,12s warmups(5s compilation),7rotated500ms rounds,300s owner
     plus joined cleanup margin. No new binaries or unrelated timing replay. Later
     R298 metadata correction is excluded; no current-HEAD speed claim. Use this
     current gap to prioritize the next coherent lifecycle/construction redesign.
''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Three materially stale captured phases prepared on qualified31d65e01/e34cacaf;300s owner;no new runtime image.',flush=True)
