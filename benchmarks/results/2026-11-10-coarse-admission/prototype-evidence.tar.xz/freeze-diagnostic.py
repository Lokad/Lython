from pathlib import Path
import hashlib, json, os, shutil, subprocess

h=Path(__file__).parent;t=h/'tree';d=h/'diagnostic';d.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
dotnet=env['DOTNET_ROOT']+'/dotnet.exe';core=t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert 'Passed:' in (h/'enumerate-public-corrected-net11.0.log').read_text(encoding='utf-8')
assert 'Test Run Successful.' in (h/'enumerate-public-net10.0.log').read_text(encoding='utf-8')
assert 'Test Run Successful.' in (h/'enumerate-internal-net10.0.log').read_text(encoding='utf-8')
common=h.parent/'deferred-method-r198/diagnostic/images/candidate'
assert hashlib.sha256((common/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
for role in ['before','candidate']:shutil.copytree(common,d/'images'/role)
path='src/Lokad.Lython/Runtime/MemoryGovernor.cs';memory=t/path;saved=memory.read_bytes()
(h/'coarse-MemoryGovernor.cs').write_bytes(saved)
original=subprocess.check_output(['git','show','2cc36b45:'+path],cwd=t)
source={}
def build(role):
 with(h/('freeze-'+role+'.log')).open('w',encoding='utf-8')as log:
  run=subprocess.run([dotnet,'build',str(t/'src/Lokad.Lython/Lokad.Lython.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert run.returncode==0,role
 shutil.copyfile(core,d/'images'/role/'Lokad.Lython.dll')
 source[role]={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(t/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}
 print(role,hashlib.sha256(core.read_bytes()).hexdigest(),flush=True)
try:
 memory.write_bytes(original)
 build('before')
finally:memory.write_bytes(saved)
build('candidate')
differences=[name for name in source['before']if source['before'][name]!=source['candidate'][name]]
assert differences==[path],differences
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
old=h.parent/'json-string-scan-r201/diagnostic'
for name in ['catalog.json','hash-witness.json','script-goldens.json']:shutil.copyfile(old/name,d/name)
catalog=json.loads((d/'catalog.json').read_text(encoding='utf-8'));goldens=json.loads((d/'script-goldens.json').read_text(encoding='utf-8'))
assert len(catalog['cases'])==5 and all(any(g['case']==c['id']and g['sourceSHA256']==c['sourceSha256']and g['allGoldensPassed']for g in goldens['cases'])for c in catalog['cases'])
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision='2cc36b45; both source-pair roles include the same wide-enumerate preflight correction. Neither role is final platform-qualified.',
 cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},
 source=source,onlySourceDifference=differences,
 commonCorrectnessFix='Native enumerate: existing admitted wide addition, direct small increments, delete late old-index magnitude charge. Same in both roles.',
 candidate='Existing host reservation rounded4KiB with cached capacity. Logical preflight/rollback unchanged; actual grant can reject earlier. No new ownership infrastructure/options.',
 catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),
 goldens='Reused exact R201 five scripts/fixtures/CPython3.13.2 semantic goldens; not newCPython timings.',
 freeze='Sequential forced nonincremental NET11 builds after each source replacement. All auxiliary bytes identical. Baseline039 is auxiliary-image origin, not either corrected core.',
 status='Isolated source pair; no performance/promotion/full qualification claim.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h.parent/'json-string-scan-r201/measure.py',h/'measure.py')
print(json.dumps(dict(cores=identity['cores'],sourceFiles=len(source['before']),onlyDifference=differences,cases=[c['id']for c in catalog['cases']]),indent=2),flush=True)
