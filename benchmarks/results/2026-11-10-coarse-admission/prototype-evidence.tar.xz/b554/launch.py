from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess
r=Path(__file__).parent;payload=(r/'payload.tgz').read_bytes()
config=dict(payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),required=(240+12)*1024*1024+max(3*len(payload),12398592),copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8')),expectedCores={'before': 'ed5dbf70a423ec0c8239e382e76604b634aa757d55a775c364a0094d3d3c663e', 'candidate': 'fedd1de700cf229c9dd179bcc14488a27d0725884f161f1cecfdd56acc392830'})
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'coarse-admission-b554-20261110';source=base/'deferred-method-b548-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for copy in config['copies']:
   path=base/copy['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(copy,allocatedBytes=st.st_blocks*512))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualified039AndPriorE294Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:assert hashlib.sha256((root/name).read_bytes()).hexdigest()==config['expectedCores'][role]
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b554-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b554-coarse-admission-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b554-coarse-admission-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
'''.replace('CONFIG',repr(config))
ast.parse(script);(r/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/coarse-admission-b554-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
assert b'ActiveState=active'in done.stdout and b'MainPID=0'not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=240,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode('utf-8'),flush=True);print('Observe after',(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
