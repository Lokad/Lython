from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile

h=Path(__file__).parent;d=h/'diagnostic';p=h/'b554';p.mkdir();old=h.parent/'json-string-scan-r201/b552';repo=Path('D:/code/Lython')
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((h/'tree'/name).read_bytes()).hexdigest()==digest for name,digest in source['source']['candidate'].items())
assert all(json.loads((d/phase/'measurements.json').read_text(encoding='utf-8'))[key]for phase in ['warm','warm-async']for key in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
for a,b in [('catalog.json','representative.json'),('identity.json','source-identity.json'),('source.patch','source.patch'),('script-goldens.json','script-goldens.json')]:shutil.copyfile(d/a,p/b)
for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:shutil.copyfile(d/'images'/role/'Lokad.Lython.dll',p/name)
base=json.loads((h.parent/'deferred-method-r198/b548/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R202 isolated on2cc36b45. Both roles include the same enumerate correction and metric comments; only MemoryGovernor differs. Neither new source is final-qualified.',
 coreSHA256={role:source['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},
 auxiliaryFiles=base['auxiliaryFiles'],protocolSHA256=base['protocolSHA256'],catalogSHA256=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest(),performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[[c['id'],'warm']for c in json.loads((p/'representative.json').read_text(encoding='utf-8'))['cases']]+[['scripts.text-summary-helpers.large','warm-async']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('json-string-scan-b552-20261110','coarse-admission-b554-20261110').replace('lython-b552-json-string-scan-20261110','lython-b554-coarse-admission-20261110').replace('lython-b552-fixtures','lython-b554-fixtures').replace('B552','B554')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
  a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R202 existing host grants at4KiB capacity, common enumerate correctness fix in both source roles. Same complete scripts/controls; allocation, elapsed and widerCPU kept separate"+s[b:]
  s=s.replace('R201 bounded bulk JSON string classification, unchanged semantic/ownership paths.','R202 existing host reservation capacity, corrected source-pair baseline.')
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
copies=[]
for folder,remote in [('2026-11-10-json-string-scan/original','json-string-scan-b552-20261110'),('2026-11-10-cold-prefix/refined','cold-prefix-b551-20261110')]:
 canonical=repo/'benchmarks/results'/folder/'observations.tgz'
 subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
 with tarfile.open(canonical)as a:
  for name in ['representative.json','confirmation/confirmation.json']:
   member=a.getmember(name);copies.append(dict(path=remote+'/'+name,bytes=member.size,sha256=hashlib.sha256(a.extractfile(member).read()).hexdigest(),canonical=canonical.relative_to(repo).as_posix()+':'+name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R202 bounded host-capacity source pair

Both frozen cores include the same wide-enumerate correction/metric comments.
Only MemoryGovernor source differs: exact per-storage resize versus owned4KiB
capacity grants. No new owner/pool/counter/options. Both roles are focused-tested,
not full platform-qualified. Existing five complete report/JSON-lines/CSV/text/
config scripts plus async text. Four independent source/control processes,
5s warmup/role,7rotated400msrounds;240sowner/30stop/30margin; stockGC/tiering.
Same current worker, auxiliaries, fixtures and goldens. Clocks include mediated
RAM I/O, capture/projection and prior-result cleanup; exclude compilation/reset/
verification/protocol. Wider CPU is coarse and includes those surrounds. Retain
all adverse/control observations and make a bounded complexity/debt decision.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['baseline-core.dll','current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes()
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
s=(old/'launch.py').read_text(encoding='utf-8').replace('json-string-scan-b552-20261110','coarse-admission-b554-20261110').replace('lython-b552-json-string-scan-20261110','lython-b554-coarse-admission-20261110').replace('json-string-scan-b552-launch.py','coarse-admission-b554-launch.py').replace('lython-b552-fixtures','lython-b554-fixtures')
a=s.index('config=dict(');b=s.index('\nscript=',a)
s=s[:a]+f"config=dict(payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),required=(240+12)*1024*1024+max(3*len(payload),{footprint}),copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8')),expectedCores={source['cores']!r})"+s[b:]
needle="shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')";assert s.count(needle)==1
s=s.replace(needle,"shutil.copyfile(protocol,root/'cpython-worker.py')\n for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:assert hashlib.sha256((root/name).read_bytes()).hexdigest()==config['expectedCores'][role]")
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['coreSHA256'],jobs=jobs,payloadBytes=len(payload),footprint=footprint,requiredFreeBytes=(240+12)*1024*1024+max(3*len(payload),footprint),exactCanonicalRecoveryBytes=sum(c['bytes']for c in copies)),indent=2),flush=True)
