# R202 bounded host-capacity source pair

Both frozen cores include the same wide-enumerate correction/metric comments.
Only MemoryGovernor source differs: exact per-storage resize versus owned4KiB
capacity grants. No new owner/pool/counter/options. Both roles are focused-tested,
not full platform-qualified. Existing five complete report/JSON-lines/CSV/text/
config scripts plus async text. Four independent source/control processes,
5s warmup/role,7rotated400msrounds;240sowner/30stop/30margin; stockGC/tiering.
Same current worker, auxiliaries, fixtures and goldens. Clocks include mediated
RAM I/O, capture/projection and prior-result cleanup; exclude compilation/reset/
verification/protocol. Wider CPU is coarse and includes those surrounds. Retain
all adverse/control observations and make a bounded complexity/debt decision.
