from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,sys
base=Path('/home/lokad/lython-bench-checks')
config={'requiredFreeBytes': 270811136, 'candidates': [{'path': '/home/lokad/lython-bench-checks/call-inputs-b519-20261109/current-core.dll', 'size': 5657088, 'sha256': '03ba8d7c9194aac1a5c55f8110c131b09667cc71dcb249876bf6368c34561648', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-09-call-input-preparation\\original-observations.tgz', 'archiveSHA256': '6b910357fc12f0d48e7c0a4b991ff14941cae07d5cc67edc83fee660119dc0f5', 'archiveMember': 'current-core.dll', 'tracked': True, 'kind': 'core'}, {'path': '/home/lokad/lython-bench-checks/invocation-controls-b531-20261110/observations.tgz', 'size': 4038409, 'sha256': 'f78c1e226a169ea21165ff62511bc069776c7eefbd01a88f0f2f9ad01599c771', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-invocation-routing\\confirmation\\observations.tgz', 'tracked': True, 'kind': 'archive'}, {'path': '/home/lokad/lython-bench-checks/shared-binding-b532-20261110/observations.tgz', 'size': 4001834, 'sha256': '1872cb0e427010c43797ebfcc7bc4f6a6e246c2200b041472dd5acfd12c7a1ce', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-shared-call-binding\\observations.tgz', 'tracked': True, 'kind': 'archive'}]}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(base/'empty-local-b533-20261110').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free;required=config['requiredFreeBytes']
 if free>required:
  print(json.dumps(dict(skipped=True,freeBytes=free,requiredBytes=required)));sys.exit(0)
 rows=[];unavailable=[]
 for e in config['candidates']:
  p=Path(e['path'])
  if not p.exists():unavailable.append(e['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==e['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
  if e['kind']=='archive':
   r=json.loads((p.parent/'archive-receipt.json').read_text());assert r['complete']and r['allWorkersJoined']and r['archiveSHA256']==e['sha256']
  rows.append(dict(**e,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,allocatedBytes=info.st_blocks*512,allAliases=[]))
  if free+sum(r['allocatedBytes']for r in rows)>required:break
 assert free+sum(r['allocatedBytes']for r in rows)>required,('Insufficient exact copies; no mutation',free,required,unavailable)
 keys={(r['device'],r['inode']):r for r in rows}
 for folder,dirs,files in os.walk(base,followlinks=False):
  dirs[:]=[d for d in dirs if not(Path(folder)/d).is_symlink()]
  for name in files:
   p=Path(folder)/name;m=p.lstat();r=keys.get((m.st_dev,m.st_ino))
   if r is None:continue
   assert p.resolve(strict=True)==p and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()and m.st_gid==os.getgid()
   assert m.st_size==r['size']and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
   for parent in p.parents:assert not parent.is_symlink()and stat.S_ISDIR(parent.lstat().st_mode)
   r['allAliases'].append(str(p))
 for r in rows:assert len(r['allAliases'])==r['links'],('Unknown links; no mutation',r)
 plan=dict(requiredFreeBytes=required,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,freshIdleLease=True,files=rows,unavailable=unavailable,operation='Retire exact duplicate remote bytes only; immutable tracked archives retain all core/raw evidence; no active/reference core retired.')
 out=base/'empty-local-b533-space-plan.json'
 with out.open('x')as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for r in rows:
  for name in r['allAliases']:
   p=Path(name);m=p.lstat();assert(m.st_dev,m.st_ino)==(r['device'],r['inode'])and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free;assert plan['afterFreeBytes']>required
 (base/'empty-local-b533-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
