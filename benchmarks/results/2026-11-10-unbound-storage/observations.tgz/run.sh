set -eu
root=/home/lokad/lython-bench-checks/empty-local-b533-20261110
date -u +%FT%TZ > "$root/started.utc"
systemctl show lython-b533-empty-local-20261110.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
python3 "$root/collect.py"
