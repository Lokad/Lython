from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;q=r/'checkpoint';q.mkdir();old=r.parent/'cased-preparation-r408/checkpoint';root='/home/lokad/lython-bench-checks/stores-cpython-b807-20261115';unit='lython-b807-stores-cpython-20261115';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));image=json.loads((r/'corrected/config.json').read_text(encoding='utf-8'))['identity']['imageFiles']['candidate'];catalog=r.parent/'arithmetic-r405/checkpoint/checkpoint-catalog.json'
catalog=old/'retrieved/representative.json';additional=r/'quiet/representative.json'
identity=dict(sourceRevision=head+'/frozen55ba4c8a',runtimeCommit=head,purpose='Representative retained-store checkpoint: compilation, warm, compile-to-result; existing CSV/text/JSON/file/config scripts. Not a causal source comparison.',coreSHA256={k:image['Lokad.Lython.dll']for k in ['candidate','candidate-control']},auxiliaryFiles={n:h for n,h in image.items()if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256(catalog.read_bytes()).hexdigest(),additionalCatalogSHA256=hashlib.sha256(additional.read_bytes()).hexdigest(),qualification='Committed/pushed2865f619, focused actual11/10 passed, full43758540157 active',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.file-search.large','warm'],['scripts.config-manifest.small','compile'],['scripts.config-manifest.small','compile-run']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/n).read_text(encoding='utf-8').replace('cased-cpython-b797-20261115','stores-cpython-b807-20261115').replace('lython-b797-cased-cpython-20261115',unit).replace('B797','B807')
 s=s.replace('len(jobs)==3','len(jobs)==8').replace("len(raw['jobs'])==3","len(raw['jobs'])==8").replace("['jobs']==3","['jobs']==8").replace('jobs=3','jobs=8').replace("elapsedSeconds']<270","elapsedSeconds']<390").replace(' < 210,',' < 330,')
 if n=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==8 and all(case in cases for case,lane in jobs)\n"+s[b:]
  s=s.replace("catalog=root/('additional.json'if case_id=='scripts.text-summary.inline.large'else'representative.json')","catalog=root/('additional.json'if case_id.startswith('scripts.config-')else'representative.json')")
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:size=sum(m.size for m in t if m.isfile())
retire=[]
for name,canonical,member in [('prepared-stores-b806-20261115/observations.tgz','benchmarks/results/2026-11-15-prepared-store-targets/observations.tgz',None),('prepared-stores-b806-20261115/confirmation/confirmation.json','benchmarks/results/2026-11-15-prepared-store-targets/observations.tgz','confirmation/confirmation.json'),('prepared-stores-b805-20261115/confirmation/confirmation.json','benchmarks/results/2026-11-15-prepared-store-targets/failed-B805-observations.tgz','confirmation/confirmation.json')]:
 raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw))as t:raw=t.extractfile(member).read()
 retire.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=member))
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/prepared-stores-b806-20261115',catalog='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115/representative.json',additional='/home/lokad/lython-bench-checks/prepared-stores-b806-20261115/representative.json',identity=identity,retire=retire,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
c=CONFIG;b=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==source.parent==b and root.resolve()==root and source.resolve()==source and not root.exists()
with(b/'comparison-vm.lock').open('a')as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert json.loads((source/'archive-receipt.json').read_text())['allWorkersJoined']
 files=dict(c['identity']['auxiliaryFiles']);files['Lokad.Lython.dll']=c['identity']['coreSHA256']['candidate']
 for n,h in files.items():assert sha(source/'candidate'/n)==h,n
 assert sha(Path(c['catalog']))==c['identity']['catalogSHA256']and sha(Path(c['additional']))==c['identity']['additionalCatalogSHA256']
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 inodes={};paths=[]
 for v in c['retire']:
  p=b/v['path'];m=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==v['bytes']and sha(p)==v['sha256'];inodes[m.st_dev,m.st_ino]=[];paths.append(p)
 for base,dirs,names in os.walk(b):
  for n in names:
   p=Path(base)/n;m=p.lstat()
   if(m.st_dev,m.st_ino)in inodes:inodes[m.st_dev,m.st_ino].append(str(p.relative_to(b)))
 assert sorted(p for values in inodes.values()for p in values)==sorted(v['path']for v in c['retire'])
 before=shutil.disk_usage(b).free;assert before+sum(v['bytes']for v in c['retire'])>254*1024*1024+c['unpackedBytes']+65536
 for p in paths:p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for n,h in files.items():os.link(source/'candidate'/n,root/'candidate'/n);assert sha(root/'candidate'/n)==h
 os.link(c['catalog'],root/'representative.json');os.link(c['additional'],root/'additional.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=c['retire'],fullHashesPathsOwnershipLinksAllAliasesVerified=True,freshIdleLease=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(b).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b807-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=390','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],root=str(root),fullImagesAndCatalogVerified=True,freeBytes=shutil.disk_usage(b).free)))
'''.replace('CONFIG',repr(c))
ast.parse(code);(q/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=320)).isoformat(),ownerSeconds=390),indent=2)+'\n',encoding='utf-8',newline='\n');print(p.stdout.decode('utf-8'),flush=True)
