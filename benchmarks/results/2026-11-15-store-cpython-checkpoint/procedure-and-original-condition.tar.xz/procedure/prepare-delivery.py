from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;d=r/'delivery';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));proof=[]
with tarfile.open(r/'frozen/sources-and-checks.tar.xz')as t:
 for n,h in f['sources'].items():
  frozen=t.extractfile(n).read();assert hashlib.sha256(frozen).hexdigest()==h
  committed=subprocess.check_output(['git','show',head+':'+n]);normalize=lambda b:b.decode('utf-8-sig').replace('\r\n','\n').encode('utf-8')
  assert normalize(frozen)==normalize(committed),n
  proof.append(dict(path=n,frozenRawSHA256=h,committedRawSHA256=hashlib.sha256(committed).hexdigest(),normalizedSHA256=hashlib.sha256(normalize(frozen)).hexdigest()))
assert subprocess.run(['git','ls-files','--error-unmatch','src/Lokad.Lython/Frontend/ExecutableScript.SuspendingTargets.cs'],capture_output=True).returncode!=0
(d/'source-proof.json').write_text(json.dumps(dict(commit=head,frozenCore=f['images']['candidate']['Lokad.Lython.dll'],inputCount=len(proof),allInputsMatchAfterExplicitUTF8NewlineNormalization=True,deletedOldCompilerDispatcher=True,inputs=proof),indent=2)+'\n',encoding='utf-8',newline='\n')
now=datetime.datetime.now(datetime.timezone.utc);candidate=dict(runId='43758540157',head=head,runtimeCommit=head,frozenCore=f['images']['candidate']['Lokad.Lython.dll'],dispatchedUTC=now.isoformat(),stress=True,publicationHeld=True,fullQualificationPending=True,doNotQueryBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat())
(d/'delivery-candidate.json').write_text(json.dumps(candidate,indent=2)+'\n',encoding='utf-8',newline='\n');print('Dispatch recorded; all',len(proof),'source/build/test inputs match.')
