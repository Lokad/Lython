from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-22-csv-direct-slots")

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = load(quiet / "identity.json")
a, _, b = identity["sourceRevision"].split()
assert a.startswith("8c81fb8d2") and b.startswith("adf7a6aeb")
local = load(lab / "identity.json")
assert a.startswith(local["reference"]) and b.startswith(local["candidate"])
patch_paths = subprocess.check_output(["git", "diff", "--name-only", a, b], text=True).splitlines()
subprocess.run(["git", "diff", "--exit-code", local["candidate"], b, "--", *patch_paths], check=True)
for role, files in identity["imageFiles"].items():
    image = lab / "frozen" / role
    assert len(files) == 32 and {name: sha(image / name) for name in files} == files
    assert sha(quiet / role / "Lokad.Lython.dll") == files["Lokad.Lython.dll"]
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 3
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(quiet / "representative.json")
    files = local["imageFiles"][role]
    assert len(files) == 32 and {n:sha(lab/"frozen"/role/n) for n in files} == files
    proof = load(lab / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["catalogSha256"] == local["catalogSHA256"] == sha(lab / "representative.json")
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 120), ("public", 405)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
allocation = load(lab / "allocation-summary.json")
assert len(allocation) == 4 and all(row["allowanceRestored"] for row in allocation)
assert allocation[0]["allocationChangePercent"] < 0
assert allocation[0]["candidateAccountedPeak"] < allocation[0]["referenceAccountedPeak"]
assert allocation[1]["candidateAccountedPeak"] < allocation[1]["referenceAccountedPeak"]
assert "not enough values to unpack" in (lab / "fixed-unpack-cpython.txt").read_text(encoding="utf-8-sig")
receipt = load(quiet / "archive-receipt.json")
status = load(quiet / "terminal-status.json")
assert status["exitCode"] == "0" and status["receipt"] == receipt
assert not status["remainingTrace"] and not status["remainingWorkers"]
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 16 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(quiet / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 4 and len(cases) == 3
assert [job["lane"] for job in raw["jobs"]] == ["warm"]*3 + ["warm-async"]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        assert response["actualOutputSha256"] == case["expectedOutputSha256"]
        assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")
summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1322", sourceRevision=identity["sourceRevision"], verifiedTimedBatches=112,
    coreSHA256=identity["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
    retentionDecision=load(lab / "decision.json")["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
reference = Path("benchmarks/results/2026-11-22-sparse-lexical-preparation/candidate-core.dll.gz")
assert gzip.decompress(reference.read_bytes()) == (quiet / "reference/Lokad.Lython.dll").read_bytes()
core = (quiet / "candidate/Lokad.Lython.dll").read_bytes()
image = out / "candidate-core.dll.gz"
image.write_bytes(gzip.compress(core, mtime=0))
assert gzip.decompress(image.read_bytes()) == core
(lab / "measured-source.patch").write_bytes(subprocess.check_output(["git", "diff", a, b, "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll", ".tgz", ".xz"}:
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("All 112 timed batches, frozen images, output hashes and focused checks verified.")
