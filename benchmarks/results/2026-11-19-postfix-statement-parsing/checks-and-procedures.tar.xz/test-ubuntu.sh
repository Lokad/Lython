set -u
export DOTNET_ROOT=~/.dotnet
lab=$1
filter=$(cat "$lab/filter.txt")
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="$lab/$suite-ubuntu.log"
    ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" >"$log" 2>&1
    result=$?
    tail -n 9 "$log"
    if test "$result" -ne 0; then exit "$result"; fi
done

