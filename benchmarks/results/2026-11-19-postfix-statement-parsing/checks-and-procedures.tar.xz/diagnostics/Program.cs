using System.Text.Json;
using Lokad.Lython;

var sources = JsonSerializer.Deserialize<string[]>(File.ReadAllText(args[0]))!;
var engine = new LythonEngine();
var rows = new object[sources.Length];
for (var i = 0; i < sources.Length; i++)
{
    using var script = engine.Compile(sources[i]);
    rows[i] = new { source = sources[i], script.IsValid, script.Diagnostics };
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows));
