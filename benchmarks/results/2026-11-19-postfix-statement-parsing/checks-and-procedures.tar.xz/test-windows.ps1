param([string]$Lab,[string]$Filter)
$dotnet = Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
foreach ($suite in @('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests')) {
    & $dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$Lab/win" --filter "$Filter" *> "$Lab/$suite-windows.log"
    $code = $LASTEXITCODE
    Get-Content -Encoding utf8 "$Lab/$suite-windows.log" -Tail 9
    if ($code) { exit $code }
}
