from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys

lab = Path(__file__).resolve().parent
pair_lab = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else lab
allocation = lab.parent / 'child-declaration-preparation-r668' / 'compile-allocation' / 'candidate'
catalog = pair_lab / 'compile-catalog.json'
if not catalog.exists():
    catalog = pair_lab / 'catalog.json'
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ['PATH'])
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = load(pair_lab / 'frozen-identity.json')
rows = []
for role in ('reference', 'candidate'):
    diag = pair_lab / 'compile-allocation' / role
    diag.mkdir(parents=True, exist_ok=True)
    for name in ('CompileAllocation.dll', 'CompileAllocation.deps.json', 'CompileAllocation.runtimeconfig.json'):
        shutil.copyfile(allocation / name, diag / name)
    core = 'Lokad.Lython.dll'
    prefix = pair_lab / (role + '-compile-allocation')
    shutil.copyfile(pair_lab / 'frozen' / role / core, diag / core)
    with prefix.with_suffix('.json').open('wb') as output, prefix.with_suffix('.log').open('wb') as error:
        subprocess.run([sdk/'dotnet.exe', diag/'CompileAllocation.dll', catalog], env=env,
                       stdout=output, stderr=error, check=True, timeout=120)
    result = load(prefix.with_suffix('.json'))
    assert result['coreSha256'] == digest(diag / core) == identity['images'][role][core]
    rows.append(result['rows'])
for left, right in zip(*rows, strict=True):
    assert left['id'] == right['id'] and left['characters'] == right['characters']
    a,b = (statistics.median(row['bytes']) for row in (left, right))
    print(left['id'], f'{a:,.1f} to {b:,.1f}', f'{100*(b/a-1):+.2f}%')
