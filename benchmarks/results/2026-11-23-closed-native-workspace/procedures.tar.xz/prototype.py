from pathlib import Path
lab=Path(__file__).resolve().parent
tree=lab.parents[3]/'.git/agent-worktrees/closed-native-workspace-20261123'
p=tree/'src/Lokad.Lython/Runtime/PyExecutableFunction.cs'
t=p.read_text(encoding='utf-8')
a='''        // Both executable callers select eligibility before entry. Starting a
        // selected call completes or transfers its exact work; it never declines
        // after binding and asks the caller to try another execution route.
        NativeValues buffer = default;'''
b='''        StartNativeActivation(call, arguments, receiver, context, span, consumedByIteration, completePositional,
            unpackedReturn, out unpacked, out result, out frame);
    }

    // Keep the managed buffer out of the direct entry frame. The JIT can clear
    // its reference slots before executing the first instruction in this method.
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private void StartNativeActivation(ExecutableCallSite call, ReadOnlySpan<LythonRuntime.ExecutableSlot> arguments,
        object? receiver, LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool consumedByIteration,
        bool completePositional, Span<LythonRuntime.ExecutableSlot> unpackedReturn, out bool unpacked,
        out LythonRuntime.ExecutableSlot result, out LythonRuntime.ExecutionContext? frame)
    {
        // A selected call completes or transfers its exact work. It never
        // declines after binding and asks the caller to try another route.
        NativeValues buffer = default;'''
assert t.count(a)==1
p.write_text(t.replace(a,b),encoding='utf-8',newline='\n')
t=(lab.parent/'closed-definition-return-20261123/test-platform.py').read_text(encoding='utf-8')
(lab/'test-platform.py').write_text(t.replace('closed-definition-return-20261123','closed-native-workspace-20261123'),encoding='utf-8',newline='\n')
