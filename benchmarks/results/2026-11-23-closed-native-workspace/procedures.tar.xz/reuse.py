from pathlib import Path
import json,shutil
lab=Path(__file__).resolve().parent
root=lab.parent
old=root/'dictreader-ready-header-20261123'
fac=root/'closed-definition-return-20261123'
read=lambda p:p.read_text(encoding='utf-8-sig')
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
def patch(path,rep):
    t=read(path)
    for a,b in rep:
        assert a in t,a
        t=t.replace(a,b)
    compile(t,path.name,'exec')
    write(lab/path.name,t)
catalog=json.loads(read(fac/'representative.json'))
post,eager,observe,fully,quote=[row['id'] for row in catalog['cases']]
assert 'postponed' in post and 'invoice' in quote
text='diagnostic.text-summary.nonlocal-computed-width.large'
wide='calls.positional.wide-native-buffer'
docs={
    text:root/'closed-definition-cpython-20261123/representative.json',
    wide:root/'native-stack-initialization-20261123/comparison/representative.json',
}
for case,path in docs.items():
    catalog['cases'].append(next(row for row in json.loads(read(path))['cases'] if row['id']==case))
write(lab/'representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
jobs={'warm':[[case,phase] for case,phase in [
    (post,'warm'),(fully,'warm'),(eager,'warm'),(text,'warm'),(observe,'warm'),(wide,'warm'),
    (post,'compile-run'),(quote,'warm')]]}
write(lab/'jobs.json',json.dumps(jobs,indent=2)+'\n')
patch(old/'freeze.py',[
    ('agent-worktrees/dictreader-ready-header-20261123','agent-worktrees/closed-native-workspace-20261123'),
    ('B1485 return ready DictReader headers directly','B1486 exclude the managed activation buffer from direct native returns'),
    ('DictReader completion catalog goldens','direct native workspace catalog goldens'),
])
patch(old/'stage.py',[
    ('dictreader-ready-header-b1485-20261123','closed-native-workspace-b1486-20261123'),
    ('lython-b1485-fixtures','lython-b1486-fixtures'),('len(jobs) == 5','len(jobs) == 8'),
    ('started < 325','started < 392'),
])
patch(old/'quiet.py',[
    ('lython-b1485-dictreader-ready-header-20261123','lython-b1486-closed-native-workspace-20261123'),
    ('b1485-stage','b1486-stage'),('.+b1485-', '.+b1486-'),('RuntimeMaxSec=290','RuntimeMaxSec=430'),
    ('seconds=247','seconds=391'),('Five bounded lanes','Eight bounded lanes'),
])
patch(old/'summarize.py',[('== 5','== 8'),('==5','==8'),('timedBatches=140','timedBatches=224')])
shutil.copyfile(old/'allocations.py',lab/'allocations.py')
PY = 'inspect-jit.py'
patch(fac/PY,[
    ('"StartNativeCall ReturnDefinition CreateClosedFunctionDefinition"','"StartNativeCall StartNativeActivation ReturnDefinition CreateClosedFunctionDefinition"'),
    ("assert any(method['method']=='ReturnDefinition' for method in methods)==(role=='candidate'), role",
     "assert any(method['method']=='ReturnDefinition' for method in methods), role\n    assert any(method['method']=='StartNativeActivation' for method in methods)==(role=='candidate'), role"),
])
