#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython
lab="$root/.git/agent-notes/review-20261031/closed-native-workspace-20261123"
prior="$root/.git/agent-notes/review-20261031/closed-definition-return-20261123"
fixture="$lab/ubuntu-prefix/bin/Lokad.Lython.WorkerFixture/release_net10.0"
dotnet=/home/vermorel/.dotnet/dotnet
export DOTNET_ROOT=/home/vermorel/.dotnet
test -f "$fixture/Lokad.Lython.WorkerFixture.dll"
for role in reference candidate; do
  path="$lab/stack-prefix-$role"
  mkdir "$path"
  cp "$fixture/"* "$path/"
  if [[ "$role" == reference ]]; then
    cp "$prior/ubuntu/bin/Lokad.Lython/release_net10.0/Lokad.Lython.dll" "$path/Lokad.Lython.dll"
  fi
  sha256sum "$path/Lokad.Lython.dll" "$path/Lokad.Lython.WorkerFixture.dll"
done
status=0
for repeat in 1 2 3; do
  if (( repeat % 2 )); then roles=(reference candidate); else roles=(candidate reference); fi
  for role in "${roles[@]}"; do
    path="$lab/stack-prefix-$role"
    diagnostic="$lab/$role-stack-prefix-$repeat.log"
    code=0
    DOTNET_PROCESSOR_COUNT=1 timeout 24s "$dotnet" "$path/Lokad.Lython.WorkerFixture.dll" stack-guard "$path/Lokad.Lython.dll" native-call-continuation > "$diagnostic" 2>&1 || code=$?
    printf '%s %s exit=%s\n' "$role" "$repeat" "$code"
    cat "$diagnostic"
    if (( code != 0 )); then status=1; fi
  done
done
exit "$status"
