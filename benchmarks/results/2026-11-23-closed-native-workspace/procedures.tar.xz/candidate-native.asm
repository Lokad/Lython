; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0040
       movzx    rax, byte  ptr [rbp+0x48]
       cmp      gword ptr [rbp+0x28], 0
       sete     cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 1
       jne      G_M000_IG06
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DirectDefinitionReturn():Lokad.Lython.Frontend.ExecutableCreateFunction:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG06
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_IsTypeParameterScope():bool:this]
       test     eax, eax
       jne      G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG23
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
 
G_M000_IG03:                ;; offset=0x00BD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG04:                ;; offset=0x00C6
       lea      r8, [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rdx, gword ptr [rbp-0x48]
       lea      rcx, [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       mov      rdx, gword ptr [rbp-0x30]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x0128
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0131
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG17
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG09
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG07:                ;; offset=0x0165
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG08:                ;; offset=0x016E
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x58]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG09:                ;; offset=0x019B
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      SHORT G_M000_IG14
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x01C3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG11:                ;; offset=0x01CC
       lea      rdx, [rbp-0x68]
       lea      rcx, [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG12:                ;; offset=0x01DA
       vmovdqu  xmm0, xmmword ptr [rbp-0x20]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG13:                ;; offset=0x01E4
       lea      rdx, [rbp-0x78]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01FF
       xor      eax, eax
       mov      dword ptr [rbp-0x10], eax
 
G_M000_IG15:                ;; offset=0x0204
       cmp      dword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG17
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG16:                ;; offset=0x021A
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0223
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG18:                ;; offset=0x0227
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG19:                ;; offset=0x0233
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG20:                ;; offset=0x0259
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG21:                ;; offset=0x0265
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x88]
       lea      rax, [rbp-0x98]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG22:                ;; offset=0x02A6
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x02AF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 693

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 176
       lea      rbp, [rsp+0xB0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0040
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp-0x60]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x08], rax
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x30], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG04:                ;; offset=0x0094
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG05:                ;; offset=0x009D
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       xor      ecx, ecx
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x78], rax
       mov      r9, gword ptr [rbp-0x78]
       lea      r8, [rbp-0x70]
       mov      rdx, gword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      gword ptr [rbp-0x38], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, 1
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x80], rax
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x10], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x014E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG07:                ;; offset=0x0154
       call     G_M000_IG14
       nop      
 
G_M000_IG08:                ;; offset=0x015A
       mov      rax, gword ptr [rbp-0x10]
 
G_M000_IG09:                ;; offset=0x015E
       add      rsp, 176
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0167
       sub      rsp, 40
 
G_M000_IG11:                ;; offset=0x016B
       mov      gword ptr [rbp-0x48], rcx
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x017E
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x08]
       je       SHORT G_M000_IG13
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp-0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG13
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG13:                ;; offset=0x01C1
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG14:                ;; offset=0x01C7
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x01CB
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rcx, gword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveFunctionCall():this]
       nop      
 
G_M000_IG16:                ;; offset=0x0210
       add      rsp, 40
       ret      
 
G_M000_IG17:                ;; offset=0x0215
       sub      rsp, 40
 
G_M000_IG18:                ;; offset=0x0219
       mov      gword ptr [rbp-0x50], rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      gword ptr [rbp-0x90], rax
       mov      r8, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp-0x58]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 603

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG18:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x68], rax
       xor      eax, eax
       mov      gword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x70], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x009F
       vmovdqu  xmm0, xmmword ptr [rbp-0x30]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, qword ptr [rbp-0x20]
       mov      qword ptr [rbp-0x88], rax
 
G_M000_IG04:                ;; offset=0x00B7
       lea      rcx, [rbp-0x80]
       mov      rdx, bword ptr [rbp+0x20]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:.ctor(byref):this]
 
G_M000_IG05:                ;; offset=0x00C5
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x10], xmm0
 
G_M000_IG06:                ;; offset=0x00CF
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG07:                ;; offset=0x00D8
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x00E5
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG09:                ;; offset=0x00EE
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG10:                ;; offset=0x010C
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG11:                ;; offset=0x0124
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG12:                ;; offset=0x0134
       xor      rax, rax
       mov      gword ptr [rsp+0x48], rax
 
G_M000_IG13:                ;; offset=0x013B
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG14:                ;; offset=0x0148
       xor      eax, eax
       mov      dword ptr [rsp+0x58], eax
 
G_M000_IG15:                ;; offset=0x014E
       vmovdqu  xmm0, xmmword ptr [rbp-0x10]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG16:                ;; offset=0x015B
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x40], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x60], rax
       mov      rcx, gword ptr [rbp-0x58]
       mov      rdx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp-0x68]
       mov      r9, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       nop      
 
G_M000_IG17:                ;; offset=0x01A2
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 427

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x220], xmm4
       mov      rax, -528
 
G_M000_IG21:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x198], eax
       mov      r9d, dword ptr [rbp-0x198]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG03
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x013D
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x0158
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG05:                ;; offset=0x0168
       lea      rdx, [rbp-0x1A8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x017E
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      r9d, dword ptr [rbp-0x1AC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG07:                ;; offset=0x01B8
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG08:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG09:                ;; offset=0x01D8
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x01FD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG11:                ;; offset=0x0209
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       lea      rax, [rbp-0x1E0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x0231
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG13:                ;; offset=0x0241
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG14:                ;; offset=0x024D
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x1F0], xmm0
 
G_M000_IG15:                ;; offset=0x025D
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x210], ymm0
 
G_M000_IG16:                ;; offset=0x026D
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG17:                ;; offset=0x0279
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG18:                ;; offset=0x0285
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1F0]
       lea      r8, [rbp-0x210]
       lea      rax, [rbp-0x220]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x02D5
       vzeroupper 
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x02E1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 743

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 256
       lea      rbp, [rsp+0x100]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0040
       movzx    rax, byte  ptr [rbp+0x48]
       cmp      gword ptr [rbp+0x28], 0
       sete     cl
       movzx    rcx, cl
       and      eax, ecx
       test     eax, eax
       je       G_M000_IG09
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 1
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DirectDefinitionReturn():Lokad.Lython.Frontend.ExecutableCreateFunction:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_IsTypeParameterScope():bool:this]
       test     eax, eax
       jne      G_M000_IG06
       mov      rcx, 0x7FF9DB9F8E60
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG28
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
 
G_M000_IG03:                ;; offset=0x00CC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG04:                ;; offset=0x00D5
       lea      r8, [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rdx, gword ptr [rbp-0x48]
       lea      rcx, [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rbp-0xA0], rax
       mov      rcx, bword ptr [rbp-0xA0]
       mov      rdx, gword ptr [rbp-0x30]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG05:                ;; offset=0x0137
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0140
       mov      rcx, 0x7FF9DB9F8E64
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x0151
       mov      rcx, 0x7FF9DB9F8E68
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0162
       mov      rcx, 0x7FF9DB9F8E6C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0171
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG22
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x01A1
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG11:                ;; offset=0x01AA
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x58]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10], eax
       jmp      G_M000_IG19
 
G_M000_IG12:                ;; offset=0x01DA
       mov      rcx, 0x7FF9DB9F8E70
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG22
 
G_M000_IG13:                ;; offset=0x01EE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x0C], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9DB9F8E74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG14:                ;; offset=0x0225
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG15:                ;; offset=0x022E
       lea      rdx, [rbp-0x68]
       lea      rcx, [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG16:                ;; offset=0x023C
       vmovdqu  xmm0, xmmword ptr [rbp-0x20]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG17:                ;; offset=0x0246
       lea      rdx, [rbp-0x78]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x10], eax
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0261
       mov      rcx, 0x7FF9DB9F8E78
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10], eax
 
G_M000_IG19:                ;; offset=0x0275
       cmp      dword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG21
       mov      rcx, 0x7FF9DB9F8E7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG20:                ;; offset=0x029A
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x02A3
       mov      rcx, 0x7FF9DB9F8E80
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG22:                ;; offset=0x02B2
       mov      rcx, 0x7FF9DB9F8E84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG23:                ;; offset=0x02C5
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG24:                ;; offset=0x02D1
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], rax
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], eax
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rsp+0x38], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG25:                ;; offset=0x02F7
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG26:                ;; offset=0x0303
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x50], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], rax
       lea      r8, [rbp-0x88]
       lea      rax, [rbp-0x98]
       mov      qword ptr [rsp+0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x28]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG27:                ;; offset=0x0344
       add      rsp, 256
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x034D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 851

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 176
       lea      rbp, [rsp+0xB0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       vmovdqa  xmmword ptr [rbp-0x10], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0040
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp-0x60]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x08], rax
 
G_M000_IG03:                ;; offset=0x0082
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x30], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG04:                ;; offset=0x0094
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG05:                ;; offset=0x009D
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       xor      ecx, ecx
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x78], rax
       mov      r9, gword ptr [rbp-0x78]
       lea      r8, [rbp-0x70]
       mov      rdx, gword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      gword ptr [rbp-0x38], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, 1
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG06
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x80], rax
       mov      rdx, gword ptr [rbp-0x80]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x10], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x014E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG07:                ;; offset=0x0154
       call     G_M000_IG16
       nop      
 
G_M000_IG08:                ;; offset=0x015A
       mov      rcx, 0x7FF9DB9FA338
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x10]
 
G_M000_IG09:                ;; offset=0x016D
       add      rsp, 176
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0176
       sub      rsp, 40
 
G_M000_IG11:                ;; offset=0x017A
       mov      gword ptr [rbp-0x48], rcx
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x18], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x018D
       mov      rcx, gword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x08]
       je       SHORT G_M000_IG15
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp-0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG14
       mov      rcx, 0x7FF9DB9FA328
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG13:                ;; offset=0x01DF
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG14:                ;; offset=0x01E5
       mov      rcx, 0x7FF9DB9FA32C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG13
 
G_M000_IG15:                ;; offset=0x01F6
       mov      rcx, 0x7FF9DB9FA330
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG13
 
G_M000_IG16:                ;; offset=0x0207
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x020B
       mov      rcx, 0x7FF9DB9FA334
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rcx, gword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveFunctionCall():this]
       nop      
 
G_M000_IG18:                ;; offset=0x025F
       add      rsp, 40
       ret      
 
G_M000_IG19:                ;; offset=0x0264
       sub      rsp, 40
 
G_M000_IG20:                ;; offset=0x0268
       mov      gword ptr [rbp-0x50], rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      gword ptr [rbp-0x90], rax
       mov      r8, gword ptr [rbp-0x90]
       mov      rdx, gword ptr [rbp-0x58]
       mov      rcx, gword ptr [rbp-0x50]
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 682

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG18:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rcx, gword ptr [rbp+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rcx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x68], rax
       xor      eax, eax
       mov      gword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x70], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x009F
       vmovdqu  xmm0, xmmword ptr [rbp-0x30]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rax, qword ptr [rbp-0x20]
       mov      qword ptr [rbp-0x88], rax
 
G_M000_IG04:                ;; offset=0x00B7
       lea      rcx, [rbp-0x80]
       mov      rdx, bword ptr [rbp+0x20]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:.ctor(byref):this]
 
G_M000_IG05:                ;; offset=0x00C5
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x10], xmm0
 
G_M000_IG06:                ;; offset=0x00CF
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG07:                ;; offset=0x00D8
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG08:                ;; offset=0x00E5
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG09:                ;; offset=0x00EE
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG10:                ;; offset=0x010C
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x38], rax
 
G_M000_IG11:                ;; offset=0x0124
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG12:                ;; offset=0x0134
       xor      rax, rax
       mov      gword ptr [rsp+0x48], rax
 
G_M000_IG13:                ;; offset=0x013B
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG14:                ;; offset=0x0148
       xor      eax, eax
       mov      dword ptr [rsp+0x58], eax
 
G_M000_IG15:                ;; offset=0x014E
       vmovdqu  xmm0, xmmword ptr [rbp-0x10]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG16:                ;; offset=0x015B
       lea      rax, [rbp-0xC0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x50], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x40], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x60], rax
       mov      rcx, gword ptr [rbp-0x58]
       mov      rdx, gword ptr [rbp-0x60]
       mov      r8, gword ptr [rbp-0x68]
       mov      r9, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       nop      
 
G_M000_IG17:                ;; offset=0x01A2
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 427

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 624
       lea      rbp, [rsp+0x270]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x220], xmm4
       mov      rax, -528
 
G_M000_IG22:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x004D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x198], eax
       mov      r9d, dword ptr [rbp-0x198]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG03
       mov      rcx, 0x7FF9DB9FA378
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG21
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG03:                ;; offset=0x014C
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG04:                ;; offset=0x0167
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG05:                ;; offset=0x0177
       lea      rdx, [rbp-0x1A8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x018D
       mov      rcx, 0x7FF9DB9FA37C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1AC], eax
       mov      r9d, dword ptr [rbp-0x1AC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG07:                ;; offset=0x01D6
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG08:                ;; offset=0x01E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG09:                ;; offset=0x01F6
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG10:                ;; offset=0x021B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG11:                ;; offset=0x0227
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1D0]
       lea      rax, [rbp-0x1E0]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG12:                ;; offset=0x024F
       mov      rcx, 0x7FF9DB9FA380
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG13:                ;; offset=0x025E
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG14:                ;; offset=0x026E
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG15:                ;; offset=0x027A
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x1F0], xmm0
 
G_M000_IG16:                ;; offset=0x028A
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x210], ymm0
 
G_M000_IG17:                ;; offset=0x029A
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG18:                ;; offset=0x02A6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG19:                ;; offset=0x02B2
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x1F0]
       lea      r8, [rbp-0x210]
       lea      rax, [rbp-0x220]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG20:                ;; offset=0x0302
       vzeroupper 
       add      rsp, 624
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x030E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 788

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 212864
; 2 inlinees with PGO data; 18 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14d, dword ptr [rbp+0x48]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x0040
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       sete     r8b
       movzx    r8, r8b
       movzx    rdx, r14b
       test     r8d, edx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x005B
       cmp      r12d, 1
       jne      SHORT G_M000_IG04
       mov      r8, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [r8+0x58]
       test     rdx, rdx
       jne      SHORT G_M000_IG07
 
G_M000_IG04:                ;; offset=0x006E
       test     rsi, rsi
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0073
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xF5], 0
       jne      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x0084
       mov      bword ptr [rbp-0x70], r13
       mov      dword ptr [rbp-0x68], r12d
       mov      r13, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r13
       mov      r13, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x28], r13
       movzx    r8, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x30], r8d
       movzx    r8, r14b
       mov      dword ptr [rsp+0x38], r8d
       mov      r14, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x40], r14
       mov      r14, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x48], r14
       mov      bword ptr [rsp+0x50], r15
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x58], r14
       lea      r8, [rbp-0x70]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG11
 
G_M000_IG07:                ;; offset=0x00E6
       mov      r8, gword ptr [rbx+0x28]
       cmp      byte  ptr [r8+0xFC], 0
       jne      G_M000_IG04
 
G_M000_IG08:                ;; offset=0x00F8
       vmovdqu  xmm0, xmmword ptr [r13]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG09:                ;; offset=0x0103
       lea      r8, [rbp-0x80]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this]
       mov      rcx, r15
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
 
G_M000_IG10:                ;; offset=0x0125
       mov      r15, bword ptr [rbp+0x58]
       mov      byte  ptr [r15], 0
       xor      r8, r8
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], r8
 
G_M000_IG11:                ;; offset=0x0137
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x014B
       test     r14b, r14b
       jne      G_M000_IG17
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       SHORT G_M000_IG15
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG15
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x88], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x01AB
       mov      gword ptr [rbp-0x50], rbx
       mov      bword ptr [rbp-0x48], r13
       mov      dword ptr [rbp-0x40], r12d
       lea      rdx, [rbp-0x50]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG14:                ;; offset=0x01CB
       test     eax, eax
       je       G_M000_IG06
       jmp      G_M000_IG10
 
G_M000_IG15:                ;; offset=0x01D8
       xor      eax, eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x01DC
       mov      rcx, gword ptr [rbp-0x88]
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG13
 
G_M000_IG17:                ;; offset=0x01EF
       mov      rdx, gword ptr [rbx+0x40]
       cmp      r12d, dword ptr [rdx+0xD8]
       jne      G_M000_IG06
       mov      bword ptr [rbp-0x60], r13
       mov      dword ptr [rbp-0x58], r12d
       lea      rdx, [rbp-0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG14
 
; Total bytes of code 542

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:ReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 78928
; 8 inlinees with PGO data; 45 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 208
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x78], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqa  xmmword ptr [rbp-0x30], xmm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x003C
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, r9
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rdi+0x98]
       mov      rax, gword ptr [rdx+0x148]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG03:                ;; offset=0x006C
       mov      rax, gword ptr [rcx+0x40]
       mov      rax, gword ptr [rax+0x98]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG22
       add      rax, 16
 
G_M000_IG04:                ;; offset=0x0085
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG05:                ;; offset=0x008E
       mov      rbx, gword ptr [rax]
       mov      rax, gword ptr [rdx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG19
       mov      rax, gword ptr [rdx+0x180]
       test     rax, rax
       jne      G_M000_IG18
 
G_M000_IG06:                ;; offset=0x00B3
       mov      r14, gword ptr [rsi+0x10]
       mov      rsi, gword ptr [rsi+0x08]
       mov      r8, rdi
 
G_M000_IG07:                ;; offset=0x00BE
       mov      rdx, gword ptr [r8+0x10]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00CA
       mov      r10, 0x7FF9DB888F08
       cmp      qword ptr [rax], r10
       jne      G_M000_IG21
 
G_M000_IG09:                ;; offset=0x00DD
       test     rax, rax
       jne      G_M000_IG20
       xor      rdx, rdx
       mov      gword ptr [rbp-0x48], rdx
 
G_M000_IG10:                ;; offset=0x00EC
       mov      gword ptr [rbp-0x40], rdx
       mov      byte  ptr [rbp-0x38], 0
 
G_M000_IG11:                ;; offset=0x00F4
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rdi
       mov      gword ptr [rsp+0x38], rbx
 
G_M000_IG12:                ;; offset=0x0102
       mov      bword ptr [rbp-0x58], rdx
 
G_M000_IG13:                ;; offset=0x0106
       mov      dword ptr [rbp-0x50], edx
 
G_M000_IG14:                ;; offset=0x0109
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG15:                ;; offset=0x010E
       mov      gword ptr [rbp-0x68], rdx
 
G_M000_IG16:                ;; offset=0x0112
       mov      dword ptr [rbp-0x60], edx
       mov      byte  ptr [rbp-0x5C], 0
 
G_M000_IG17:                ;; offset=0x0119
       mov      dword ptr [rsp+0x58], edx
       lea      rdx, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x78], rdx
       mov      dword ptr [rbp-0x70], 1
       lea      rdx, [rbp-0x78]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x68]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rsi
       mov      rcx, r14
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rax, gword ptr [rcx+0x40]
       mov      rax, gword ptr [rax+0x98]
       cmp      dword ptr [rax+0x08], 1
       jbe      SHORT G_M000_IG22
       mov      rax, gword ptr [rax+0x30]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8, gword ptr [rdx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      SHORT G_M000_IG24
       mov      r8, gword ptr [rdx+0x180]
       test     r8, r8
       je       SHORT G_M000_IG25
       jmp      SHORT G_M000_IG23
 
G_M000_IG18:                ;; offset=0x01A2
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG06
 
G_M000_IG19:                ;; offset=0x01B4
       mov      rcx, rdx
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG06
 
G_M000_IG20:                ;; offset=0x01C5
       mov      rdx, gword ptr [r8+0x10]
       mov      rcx, 0x7FF9DB888F08
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r8, rax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x01E0
       mov      rcx, r10
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG22:                ;; offset=0x01E9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG23:                ;; offset=0x01EF
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0201
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG25:                ;; offset=0x020E
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0x98]
       mov      rax, rsi
       lea      rcx, bword ptr [rax+0x148]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, qword ptr [rsi+0x158]
       test     rax, rax
       jle      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x023C
       dec      rax
       mov      qword ptr [rsi+0x158], rax
 
G_M000_IG27:                ;; offset=0x0246
       mov      rax, rbx
 
G_M000_IG28:                ;; offset=0x0249
       add      rsp, 208
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG29:                ;; offset=0x0257
       sub      rsp, 104
 
G_M000_IG30:                ;; offset=0x025B
       mov      rsi, rcx
       cmp      gword ptr [rbp-0x80], 0
       je       SHORT G_M000_IG31
       mov      rcx, rsi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x80]
       je       SHORT G_M000_IG31
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG31
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG31:                ;; offset=0x0291
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG32:                ;; offset=0x0297
       sub      rsp, 104
 
G_M000_IG33:                ;; offset=0x029B
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0x98]
       mov      rax, rsi
       lea      rcx, bword ptr [rax+0x148]
       mov      rdx, gword ptr [rbp-0x80]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rsi+0x158]
       test     rcx, rcx
       jle      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x02C9
       dec      rcx
       mov      qword ptr [rsi+0x158], rcx
 
G_M000_IG35:                ;; offset=0x02D3
       add      rsp, 104
       ret      
 
G_M000_IG36:                ;; offset=0x02D8
       sub      rsp, 104
 
G_M000_IG37:                ;; offset=0x02DC
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 783

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 4 inlinees with PGO data; 13 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xE0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      rdi, rcx
       mov      rsi, rdx
       mov      rbx, r8
       mov      r14, r9
 
G_M000_IG02:                ;; offset=0x0037
       mov      rcx, gword ptr [rsi+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG17
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG16
 
G_M000_IG03:                ;; offset=0x0060
       mov      r15, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [rdi+0x08]
       mov      r8, rsi
 
G_M000_IG04:                ;; offset=0x006B
       mov      rdx, gword ptr [r8+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0077
       mov      rax, 0x7FF9DB888F08
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG19
 
G_M000_IG06:                ;; offset=0x008A
       test     rcx, rcx
       jne      G_M000_IG18
       xor      rdx, rdx
       mov      gword ptr [rbp-0x40], rdx
 
G_M000_IG07:                ;; offset=0x0099
       mov      gword ptr [rbp-0x38], rdx
       mov      byte  ptr [rbp-0x30], 0
 
G_M000_IG08:                ;; offset=0x00A1
       mov      dword ptr [rsp+0x28], edx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], r14
 
G_M000_IG09:                ;; offset=0x00AF
       mov      bword ptr [rbp-0x50], rdx
 
G_M000_IG10:                ;; offset=0x00B3
       mov      dword ptr [rbp-0x48], edx
 
G_M000_IG11:                ;; offset=0x00B6
       mov      gword ptr [rsp+0x48], rdx
 
G_M000_IG12:                ;; offset=0x00BB
       mov      gword ptr [rbp-0x60], rdx
 
G_M000_IG13:                ;; offset=0x00BF
       mov      dword ptr [rbp-0x58], edx
       mov      byte  ptr [rbp-0x54], 0
 
G_M000_IG14:                ;; offset=0x00C6
       mov      dword ptr [rsp+0x58], edx
       mov      bword ptr [rbp-0x70], rbx
       mov      dword ptr [rbp-0x68], 1
       lea      rdx, [rbp-0x70]
       mov      qword ptr [rsp+0x60], rdx
       lea      rdx, [rbp-0x40]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x50], rdx
       lea      rdx, [rbp-0x50]
       mov      qword ptr [rsp+0x40], rdx
       mov      rdx, rdi
       mov      rcx, r15
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       nop      
 
G_M000_IG15:                ;; offset=0x0109
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x0119
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG03
 
G_M000_IG17:                ;; offset=0x012B
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG03
 
G_M000_IG18:                ;; offset=0x0139
       mov      rdx, gword ptr [r8+0x10]
       mov      rcx, 0x7FF9DB888F08
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r8, rax
       jmp      G_M000_IG04
 
G_M000_IG19:                ;; offset=0x0154
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
; Total bytes of code 349

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeActivation(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 78512
; 5 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 448
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x188], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x180], xmm4
       mov      rax, -336
 
G_M000_IG14:                ;; offset=0x0034
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      rbx, rcx
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0052
       mov      rax, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r14d, dword ptr [rcx+0xE8]
       cmp      r14d, 16
       ja       G_M000_IG06
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG11
       xor      ecx, ecx
       test     r9, r9
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x0083
       cmp      ecx, r14d
       ja       G_M000_IG06
       lea      rdx, bword ptr [rbp-0x120]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r14d
       sub      edx, ecx
       cmp      edi, edx
       ja       G_M000_IG10
       mov      ecx, edi
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG09
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa3b1b2aa8)], 0
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00DB
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x158], ymm0
       lea      rdx, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], rdx
       mov      dword ptr [rbp-0x160], r14d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x138]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x168]
       lea      r8, [rbp-0x158]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG05:                ;; offset=0x014C
       add      rsp, 448
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x015A
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG07:                ;; offset=0x0161
       mov      ecx, 1
       test     r14d, r14d
       je       G_M000_IG13
       mov      gword ptr [rbp-0x120], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x118], rdx
       jmp      G_M000_IG03
 
G_M000_IG08:                ;; offset=0x0184
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x018E
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x01A2
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG11:                ;; offset=0x01A9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r14d
       ja       SHORT G_M000_IG06
       lea      r8, bword ptr [rbp-0x120]
       mov      bword ptr [rbp-0x168], r8
       mov      dword ptr [rbp-0x160], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x178], rcx
 
G_M000_IG12:                ;; offset=0x01D6
       mov      dword ptr [rbp-0x170], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x188], rax
       mov      dword ptr [rbp-0x180], edi
       lea      rcx, [rbp-0x168]
       lea      rdx, [rbp-0x178]
       lea      r9, [rbp-0x188]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG04
 
G_M000_IG13:                ;; offset=0x022E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 564

