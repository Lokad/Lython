from pathlib import Path
r=Path(__file__).parent;f=r/'profile-corrected'
s=(r.parent/'report-cost-r108/attribute.py').read_text(encoding='utf8').replace("r=Path(__file__).parent;folder=r/'retrieved/profiles/report-warm'","r=Path(__file__).parent;folder=r/'retrieved/profiles/integer-warm'").replace("sourceRevision='7265538c'","sourceRevision='05790317'")
s=s.replace("['CallBindingFrame','CallableInvocation','PrepareExecutableInvocation','ExecutableInvocationFrame']","['CallBindingFrame','CallableInvocation','PrepareExecutableInvocation','ExecutableInvocationFrame','BeginBoundCall','BeginPendingCall','AdvanceCallFrames','ExecuteOrdinaryCall','InvokeExecutableGeneralTargetAsync']")
s=s.replace("core=collections.Counter(n for s in samples for _,n in set(s) if '[Lokad.Lython]' in n)","core=collections.Counter(n for s in samples for n in {name for _,name in s if '[Lokad.Lython]' in name})")
needle="counts={tag:dict("
assert needle in s
s=s.replace(needle,"""patterns.update(
 operandTransport=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['ReadOperand','PublishInstructionResult','LoadLocal','StoreExecutableLocal','CompleteLocalResult','ExecutableValueStorage','StoreLocalValue']),
 numericWork=lambda n:any(t in n for t in ['System.Numerics.BigInteger::','AddExactIntegers','PyNumberOps::','EvaluateAdd','EvaluateBinaryOperator','EvaluateAugmentedOperator']),
 iterators=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['Iterator','ForAdvance','TryAdvance','MoveNext','PyRange::']),
 cancellationAndAdmission=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['CheckExecution','ThrowIfAdmissionFailed','CheckCancellation']),
 gcAndAllocation=lambda n:any(t in n for t in ['gc_heap::','garbage_collect','JIT_Box','JIT_New','AllocateObject','alloc_context','AllocLHeap']))
"""+needle)
(f/'attribute.py').write_text(s,encoding='utf8')
