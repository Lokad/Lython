from pathlib import Path
import json,subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import json,subprocess
r=Path('/home/lokad/lython-bench-checks/scalar-cost-b470-20261108')
data={}
for n in ['micro.log','micro.json','profiles/integer-warm/record.json','profiles/integer-warm/collector.log','profiles/integer-warm/worker.stderr']:
 p=r/n
 if p.exists():data[n]=p.read_text()[-10000:]
data['journal']=subprocess.run(['journalctl','--user','-u','lython-b470-scalar-cost-20261108.service','--no-pager','-n','12'],capture_output=True,text=True).stdout
data['fixtureEntries']=[str(p)for p in Path('/dev/shm/lython-b470').rglob('*')]
data['files']=[str(p.relative_to(r))for p in r.rglob('*')if p.is_file()and 'candidate'not in p.parts]
print(json.dumps(data))
'''
done=subprocess.run([*ssh,'python3 -'],input=code,text=True,encoding='utf8',capture_output=True);assert done.returncode==0,done.stderr
(r/'terminal-inspection.json').write_text(done.stdout,encoding='utf8')
d=json.loads(done.stdout)
for n in ['micro.log','profiles/integer-warm/collector.log','profiles/integer-warm/worker.stderr','fixtureEntries']:print(n,d.get(n))
if 'micro.json'in d:
 m=json.loads(d['micro.json'])if len(d['micro.json'])<10000 else None
 if m:print('micro',m.get('state'),m.get('error'),m.get('summaries'))
print('files',d['files'])
