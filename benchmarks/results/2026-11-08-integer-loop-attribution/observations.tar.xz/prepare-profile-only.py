from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'report-cost-r108';f=r/'profile-corrected';f.mkdir()
for n in ['catalog.json','identity.json','core-source.json','source.patch','sizing.json']:shutil.copyfile(r/n,f/n)
shutil.copyfile('PLAN.md',f/'pre-measurement-plan.md')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('report-cost-b466-20261108','corrected-scalar-profile-b471-20261108').replace('lython-b466-report-cost','lython-b471-corrected-scalar-profile').replace('report-cost-b466-launch.py','corrected-scalar-profile-b471-launch.py').replace('lython-b466','lython-b471').replace('report-warm','integer-warm')
 if name=='ops-profile.py':
  s=s.replace('scripts.report-render.large','loops.integer.large').replace('EvaluateNativeReturn FormatNativeReturnValue ExecuteInstructionPrefix','ExecuteInstructionPrefix EvaluateBinaryOperator')
  s=s.replace('response["actualFilesSha256"] == case["expectedFilesSha256"]','response.get("actualFilesSha256") == case.get("expectedFilesSha256")')
 if name=='launch.py':s=s.replace("source=(base/'refined-conditional-helpers-b465-20261108/candidate').resolve()","source=(base/'refined-record-capacity-b469-20261108/candidate').resolve()")
 if name=='archive.py':s=s.replace('verified immutable B465 archive','verified immutable B469 archive')
 (f/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
contract='''R111 correction of an evidenced collector defect, profile-only. Completed B470 normal15s micro is preserved and never repeated: source0579/core1310 median700.968us, old1aa713.390us, CPython3.13.16 596.612us, low sampleIQR; no quiet-after or qualification claim. Initial CPU capture failed before warmup because no-file WorkerResponse omits actualFilesSha256, which is legitimately null. Compare optional response/case values via.get; file fixtures keep the same golden check. Original source/error/aborted worker/maps/IPC metadata archived underlease and locallyverified, no users/RAM remain.
Same source/unchanged catalog16,384integeriterations/fullstdout134209536/worker7cf/optional0.4. Existing6guest-secondwarmup/2ssettle/6swall CPUclock/FP199Hz,64completeinvocations/request. PerfMap/JIT diagnostics only, no normalelapsed claim.120sowner+30stop+30margin, same allsource/core/aux/Ready/golden/quiet/Closed/exit/join/map/fixture/archive/local gates. Persistent raw/maps, owned128MiBRAM fixtures/temp CLR maps copied+verified before retirement/unmount. Reuse verified B469core/archive/aux,8MiBtrace/archiveheadroom above240MiBOSfloor; no new core upload/deletion/framework. One corrected capture then~20min sourceselection; no automatic taggedvalues/arenas/JIT or cancellation weakening. R110fullCI independent, regex/publication unchanged.\n'''
for n in ['contract.md','selection.md']:(f/n).write_text(contract,encoding='utf8')
with tarfile.open(f/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(f/n,arcname=n)
print('Corrected optional-file-field CPU capture only; completed micro unchanged, original failure archived.')
