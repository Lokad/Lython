set -eu
root=/home/lokad/lython-bench-checks/scalar-cost-b470-20261108
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm/lython-b470
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-before.json"
findmnt -T "/dev/shm/lython-b470" -o TARGET,SOURCE,FSTYPE,OPTIONS > "$root/fixture-filesystem.txt"
/usr/bin/timeout --signal=TERM --kill-after=5s 30s "$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare micro --catalog "$root/catalog.json" --dotnet "$dotnet" --baseline-worker /home/lokad/lython-bench-checks/refined-conditional-helpers-b465-20261108/candidate/Lokad.Lython.Benchmarks.dll --python /home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13 --python-worker /home/lokad/lython-bench-checks/prepared-call-layout-b384-20261107/cpython-worker.py --out "$root/micro.json" --case loops.integer.large --lane warm > "$root/micro.log" 2>&1
sleep 2
python3 "$root/ops-profile.py" "$root/profiles"
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-after.json"
for case in integer-warm; do
 python3 "$root/analyze-cpu-guest.py" "$root/profiles/$case"
done
# All sudo perf reads have ended before transferring these owned files.
sudo -n chown lokad:lokad "$root/profiles/integer-warm/perf.data"
python3 - <<'PY'
from pathlib import Path
import subprocess
p=Path('/dev/shm/lython-b470')
assert p.is_mount() and not list(p.iterdir())
subprocess.run(['sudo','-n','umount',str(p)],check=True);p.rmdir()
PY
python3 "$root/archive.py"
