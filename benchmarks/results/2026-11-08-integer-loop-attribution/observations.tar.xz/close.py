from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;f=r/'profile-corrected';i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
failed=json.loads((r/'failure-receipt.json').read_text(encoding='utf8'));assert failed['microCompleted']and not failed['profileCompleted']and failed['ownedRAMUnmounted']
assert hashlib.sha256((r/'failure-observations.tgz').read_bytes()).hexdigest()==failed['archiveSHA256']
receipt=json.loads((f/'archive-receipt.json').read_text(encoding='utf8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((f/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
micro=json.loads((r/'recovered/micro.json').read_text(encoding='utf8'));assert micro['state']=='Completed'
d=json.loads((f/'attribution.json').read_text(encoding='utf8'));assert d['guestSamples']==1170
out=Path('benchmarks/results/2026-11-08-integer-loop-attribution');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='recovered':continue
  if p.name=='profile-corrected':
   for q in sorted(p.iterdir()):
    if q.name not in ['retrieved','payload.tgz']:a.add(q,arcname='profile-corrected/'+q.name)
  elif p.name!='payload.tgz':a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as a:
 assert hashlib.sha256(a.extractfile('failure-observations.tgz').read()).hexdigest()==failed['archiveSHA256']
 assert hashlib.sha256(a.extractfile('profile-corrected/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for src,name in [(f/'attribution.json','attribution.json'),(r/'identity.json','identity.json'),(r/'recovered/micro.json','micro.json'),(f/'archive-receipt.json','profile-receipt.json')]:shutil.copyfile(src,out/name)
(out/'README.md').write_text('''# Current integer-loop diagnosis

2026-11-08, committed `05790317` / frozen core `13107e6b`; the old numeric control
is `7265538c` / core `1aa68ce9`. R110 record capacity does not predict a numeric-loop
gain. Source0579 is fully qualified in [cached CI42502610937](../2026-11-08-json-record-capacity/delivery-ci.json).
Same maintained `loops.integer.large`,16384iterations, complete stdout134209536;
independent CPython golden unchanged. No new fixture or framework.

Existing short warm micro: one-second warmup, seven rotated25msrounds, normal GC/
tiering, external30second deadline. .NET11 RC3 / CPython3.13.16 on quiet dedicated
F4as_v7/Ubuntu24.04.4/four EPYC9V45vCPUs/16GiB/no swap, same worker7cf/optional0.4.

| Engine | Median per complete invocation | IQR / median |
| --- | ---: | ---: |
| Old Lython control |713.390µs|0.92%|
| Current Lython |700.968µs|1.65%|
| CPython |596.612µs|0.14%|

Current Lython/CPython≈1.17x in this short diagnostic. It does not show the old large
basic-loop gap or establish a R110 numeric speedup, confidence interval or general
multiplier. Quiet-before passed; quiet-after was not recorded in the failed combined
collection. Keep that limitation. Warm reuses code, includes invocation/output
validation/prior-result cleanup, excludes compile/startup/protocol/staging. No file I/O.

The first CPU capture failed before warmup because the collector required
actualFilesSha256, which a no-file WorkerResponse legitimately omits. Completed
micro was preserved and never repeated. The stopped worker, raw/maps/IPC metadata
and failure journal were archived under lease and independently verified; owned
RAM was unmounted after users ended. One corrected **profile-only** capture compares
optional response/case file digests, retaining checks for actual file fixtures.
The original stage-helper name also refused before any new worker; sources remain.

Corrected capture: six-second guest warmup/two-second settle, six-second wall
CPU-clock/FP199Hz,64completeinvocations/request. PerfMap/JIT diagnostics enabled;
not normal-settings elapsed.6.012guest-clock seconds/5.92guest CPU seconds,
1170samples/63unknown leaves(5.38%). Both quiet endpoints/full stdout/Ready/core/
aux/Closed/exit/join/maps/fixture/archive/local gates pass; no users or RAM remain.

| Sampled work | Leaf samples | Interpretation |
| --- | ---: | --- |
| CompleteLocalResult |287(24.53%)|Publication, cleanup/checks and binding work; not all removable overhead |
| Instruction prefix |234(20.00%)|Includes useful inlined work/checks |
| Range iterator |146(12.48%)|Native iteration/value construction |
| AddExactIntegers |118(10.09%)|Exact arithmetic/result construction |
| Input instruction handling |108(9.23%)|Operand/protocol routing |
| Augmented assignment |48(4.10%)|Arithmetic dispatch |
| BigInteger(long) constructor |35(2.99%)|Value construction |

Inclusive groups overlap and inlining/unwind loss limits attribution. No standalone
cancellation sample is not proof that inlined checks cost nothing. The first
offline memory classifier incorrectly matched a governor type in numeric method
signatures; corrected to actual owner methods and retained the original classifier.
This profile does not justify universal tagged slots or a new frame/arena engine.

Source follow-up identifies bounded removable work: StoreLocalValue unconditionally
looks up and classifies its compiler name before discovering no namespace/mirroring
requires it. Moving that pure metadata work into the real namespace branches may
reduce the publication cost. Preserve cells, synthetic names, dynamic globals/
locals, cleanup order, lifetime fences, current cancellation and memory refusal.
Select and test that change before predicting a speedup; this capture alone does
not establish a particular saved percentage.

[Micro receipt](micro.json), [profile attribution](attribution.json), [identity](identity.json),
[profile receipt](profile-receipt.json), [all raw, sources, failures and corrections](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+'''
## Integer-loop transport evidence (2026-11-08)

[R111/B470–B471](results/2026-11-08-integer-loop-attribution/README.md) at05790317/
core1310. Existing16384iteration loop short normal micro700.968µs versusCPython
596.612µs≈1.17x; oldcontrol713.390µs, lowIQR. Diagnostic, no quiet-after/general
multiplier/R110numeric gain claim. Initial CPU collector rejected an omitted
no-file digest before warmup; completed micro never repeated. Failure/maps/IPC
metadata archived, users ended/RAM unmounted; one corrected profile-only capture
passes allgates/archive/local.1170samples/5.92CPU seconds/63unknown5.38%, publication
287leaf24.53%, prefix23420%, range14612.48%, exactaddition11810.09%, input1089.23%.
Groups overlap; not all publication removable. Source next: defer compiler-name
lookup/classification until actual namespace/mirroring needs it, preserving all
cleanup/cell/global/synthetic/ownership/cancellation behavior. No tagged-value/frame
redesign from boxing alone. Original classifiers and failed stage/capture retained.
''';p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('2. **R111');z=s.index('3. **Remaining substantial',a)
s=s[:a]+'''2. **R111 assessment closed; R112 selected: local result publication.**
   Existing16384iteration normal micro current0579/core1310≈700.968µs versus
   CPython596.612µs (1.17x), oldnumericcontrol713.390µs; lowIQR, diagnostic/no quiet-
   after, no R110numeric gain claim. Corrected six-second CPU capture1170samples/
   5.92CPU seconds/63unknown5.38%. CompleteLocalResult287leaf24.53%, prefix23420%,
   range14612.48%, exactaddition11810.09%, input1089.23%. Groups overlap; useful
   publication/check/cleanup work is not all removable. Initial missing optional
   file-digest capture failed beforewarmup; completedmicro not repeated, original
   worker/maps/IPC/archive preserved/cleaned; corrected profile-only allgates pass.
   R112 hypothesis: StoreLocalValue reads/classifies compiler names even for
   private slots needing no namespace synchronization. Move that pure metadata
   work into real GlobalNamespace/mirroring branches, retaining canonical writes.
   Remove unconditional LocalNames lookup/guest-name classification from private
   publication. No new flags/cache/arena/taggedvalue/dispatch/public option. Preserve
   cell writes, dynamic globals/locals, imports/module bindings, synthetic names,
   class namespaces/annotations, closures, cleanup order and existing lifetime
   fences. Keep all current cancellation/refusal/preflight/stack checks.
   Source gate~15min: verify no namespace/cell effect depends on earlier pure-name
   access; do not bypass required writes. Then smallest coherent source change,
   existing focused Release binding/namespace/function/generator/ownership/cancel
   regressions, one bounded source pair across loop and representative CSV/text/
   JSON scripts with unchanged controls. Report allocation and CPU separately;
   do not promise24% savings. Retain/correct/reject with explicit debt and bounded
   confirmation for real uncertainty. Full delivery at a coherent retained boundary.

'''+s[z:];p.write_text(s,encoding='utf8')
print('R111 completed diagnostic/failed and corrected profile archived; R112 source-backed publication milestone selected.')
