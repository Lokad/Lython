from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'report-cost-r108';runtime=r.parent/'json-record-capacity-r110/refinement';vm=runtime/'b469'
i=json.loads((runtime/'identity.json').read_text(encoding='utf8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
d=json.loads((r/'core-catalog.json').read_text(encoding='utf8'));d['cases']=[c for c in d['cases']if c['id']=='loops.integer.large'];assert len(d['cases'])==1
c=d['cases'][0];cp=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],capture_output=True,text=True,encoding='utf8',check=True);assert not cp.stderr and cp.stdout==c['expectedOutput'] and cp.stdout=='134209536\n'
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
receipt=json.loads((vm/'archive-receipt.json').read_text(encoding='utf8'));assert hashlib.sha256((vm/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(vm/'observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==i['coreSHA256']['candidate']
proof=dict(vmArchive='refined-record-capacity-b469-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-json-record-capacity/observations.tar.xz (nested B469)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
identity=dict(sourceRevision='057903171806a17933659fae29597aeb2fd25665',files={'Lokad.Lython.dll':i['coreSHA256']['candidate']},auxiliaryFiles=json.loads((vm/'identity.json').read_text(encoding='utf8'))['auxiliaryFiles'],productionSources=i['productionSources'],baselineCoreSHA256=i['coreSHA256']['before'],qualification='897public/193internal peractual11/10 plus controlled B469 pass; full source0579 CI active independently.',purpose='One existing short integer-loop micro with CPython context and one separate6s guest CPU profile; no representation change or normal CPU gain claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('report-cost-b466-20261108','scalar-cost-b470-20261108').replace('lython-b466-report-cost','lython-b470-scalar-cost').replace('lython-b466','lython-b470').replace('report-warm','integer-warm')
 if name=='ops-profile.py':s=s.replace('scripts.report-render.large','loops.integer.large').replace('EvaluateNativeReturn FormatNativeReturnValue ExecuteInstructionPrefix','ExecuteInstructionPrefix EvaluateBinaryOperator')
 if name=='launch.py':
  s=s.replace("source=(base/'refined-conditional-helpers-b465-20261108/candidate').resolve()","source=(base/'refined-record-capacity-b469-20261108/candidate').resolve()")
  s=s.replace('ownerSeconds=120','ownerSeconds=150').replace('RuntimeMaxSec=120','RuntimeMaxSec=150').replace('seconds=180','seconds=210')
 if name=='run.sh':
  needle='python3 "$root/ops-profile.py" "$root/profiles"'
  micro='''"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare micro --catalog "$root/catalog.json" --dotnet "$dotnet" --baseline-worker /home/lokad/lython-bench-checks/refined-conditional-helpers-b465-20261108/candidate/Lokad.Lython.Benchmarks.dll --python /home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13 --python-worker /home/lokad/lython-bench-checks/prepared-call-layout-b384-20261107/cpython-worker.py --out "$root/micro.json" --case loops.integer.large --lane warm > "$root/micro.log" 2>&1
sleep 2
'''+needle
  assert needle in s;s=s.replace(needle,micro)
 if name=='archive.py':
  s=s.replace('verified immutable B465 archive','verified immutable B469 archive')
  s=s.replace("record=json.loads", "micro=json.loads((root/'micro.json').read_text());assert micro['state']=='Completed'\nrecord=json.loads",1)
  s=s.replace('performanceQualified=False)','performanceQualified=False,microCompleted=True)')
 (r/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
shutil.copyfile(runtime/'source.patch',r/'source.patch');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
contract='''R111 one already-maintained loops.integer.large at16384iterations, source/export/golden unchanged; independent CPython output134209536. Current05790317/core13107e6b, old unchanged numeric control726/core1aa68ce9; record-capacity change does not predict loop improvement. Existing15s micro command1swarmup/7rotated25msrounds, CPython3.13.16 context, then separate existing6s guest CPU profile after6guest-secondwarmup/2ssettle,64invocations/request at199HzCPUclock/FP. Normal micro and PerfMap/JIT profile settings distinguished; no qualified multiplier/CPU gain claim. Source gate~20min then select named removable scalar/operator/iteration/checkpoint work only if evidence supports, preserve exact promotion/identity/aliases/cancellation/admission/ownership. No tagged-value/arena/engine/cache/JIT prototype from boxing alone.
150sowner+30stop+30margin, persistent raw/maps/catalog, owned128MiB RAM fixture/map temporary lifetime, all core/aux/Ready/golden/quiet/Closed/exit/join/fixture/map/archive/local gates. Verified B469core/archive/aux reused, no core upload/deletion/maintenance.8MiBtrace/archiveheadroom above240MiBfloor. Full R110 delivery independent; regex/publication unchanged.
'''
for n in ['contract.md','selection.md']:(r/n).write_text(contract,encoding='utf8')
(r/'sizing.json').write_text(json.dumps(dict(evidenceHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024,coreArchiveReused=True,noNewFramework=True),indent=2)+'\n',encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/n,arcname=n)
print('One existing integer-loop micro/profile prepared, source/golden current, no new runtime mechanism.')
