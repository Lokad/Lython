from pathlib import Path
import shutil,tarfile
r=Path(__file__).parent
shutil.copyfile(r/'launch.py',r/'launch-original-stage.py')
s=(r/'launch.py').read_text(encoding='utf8').replace('report-cost-b466-launch.py','scalar-cost-b470-launch.py')
s=s.replace(" assert not root.exists() and not Path", " assert Path('/usr/bin/timeout').is_file()\n assert not root.exists() and not Path")
(r/'launch-corrected.py').write_text(s,encoding='utf8')
p=r/'run.sh';s=p.read_text(encoding='utf8');needle='"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare micro';assert s.count(needle)==1;s=s.replace(needle,'/usr/bin/timeout --signal=TERM --kill-after=5s 30s '+needle);p.write_text(s,encoding='utf8',newline='\n')
(r/'original-stage-refusal.txt').write_text('Inherited launch helper still named the previous report-cost-b466 stage; its existing-file guard refused before creating a new root/service/worker. Original source preserved, corrected to unique scalar-cost-b470 stage. Micro command retains an external30second process-group deadline with5second kill grace within the combined150second owner. No timed collection was restarted.\n',encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/n,arcname=n)
