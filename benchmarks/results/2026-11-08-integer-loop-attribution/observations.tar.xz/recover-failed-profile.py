from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,stat,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'scalar-cost-b470-20261108';mount=Path('/dev/shm/lython-b470')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 journal=subprocess.run(['sudo','-n','journalctl','-u','lython-b470-scalar-cost-20261108.service','--no-pager','-n','30'],capture_output=True,text=True)
 (root/'failure-journal.txt').write_text(journal.stdout+journal.stderr)
 micro=json.loads((root/'micro.json').read_text());record=json.loads((root/'profiles/integer-warm/record.json').read_text())
 metadata=[];pids=set();saved=[]
 if mount.exists():
  assert mount.is_mount()
  for p in mount.rglob('*'):
   st=p.lstat();metadata.append(dict(name=str(p.relative_to(mount)),mode=st.st_mode,size=st.st_size,uid=st.st_uid))
   m=re.match(r'clr-debug-pipe-(\\d+)-',p.name)
   if m:pids.add(m[1])
   assert not p.is_symlink()
   if p.is_file():
    target=root/'failed-tmp'/p.relative_to(mount);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(target.read_bytes()).digest()
  for pid in pids:
   assert not Path('/proc',pid).exists()
   for prefix in ['perf','perfinfo']:
    p=Path('/tmp')/(prefix+'-'+pid+'.map')
    if p.exists():
     assert not p.is_symlink()and p.stat().st_uid==os.getuid()
     target=root/'profiles/integer-warm'/('failure-'+prefix+'.map');shutil.copyfile(p,target)
     assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(target.read_bytes()).digest()
     p.unlink();saved.append(dict(original=str(p),saved=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
  subprocess.run(['sudo','-n','umount',str(mount)],check=True);mount.rmdir()
 report=dict(microState=micro['state'],microSummaries=micro['summaries'],profileCompleted=False,profileRecord=record,transientMetadata=metadata,savedMaps=saved,allUsersEnded=True,ownedRAMUnmounted=True)
 (root/'failure-recovery.json').write_text(json.dumps(report,indent=2)+'\\n')
 with tarfile.open(root/'failure-observations.tgz','w:gz',dereference=True)as a:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p.name!='failure-observations.tgz'and'candidate'not in p.relative_to(root).parts:a.add(p,arcname=p.relative_to(root).as_posix())
 receipt=dict(microCompleted=micro['state']=='Completed',profileCompleted=False,allUsersEnded=True,ownedRAMUnmounted=True,archiveSHA256=hashlib.sha256((root/'failure-observations.tgz').read_bytes()).hexdigest())
 (root/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n')
 print(json.dumps(dict(receipt=receipt,microSummaries=micro['summaries'],journal=journal.stdout[-3500:])))
'''
done=subprocess.run([*ssh,'python3 -'],input=code,text=True,encoding='utf8',capture_output=True);assert done.returncode==0,done.stderr
(r/'failure-recovery-response.json').write_text(done.stdout,encoding='utf8');print(done.stdout,flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['failure-observations.tgz','failure-receipt.json']:
 p=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/scalar-cost-b470-20261108/'+n,str(r/n)],capture_output=True,text=True,encoding='utf8');assert p.returncode==0,p.stderr
receipt=json.loads((r/'failure-receipt.json').read_text(encoding='utf8'));assert hashlib.sha256((r/'failure-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'recovered';out.mkdir()
with tarfile.open(r/'failure-observations.tgz')as a:
 regular=[m for m in a.getmembers()if m.isfile()or m.isdir()];a.extractall(out,members=regular,filter='data')
print('Completed micro preserved; failed CPU capture/map evidence archived, locally verified, no users or RAM remain.')
