from pathlib import Path
import bisect,collections,json,re
r=Path(__file__).parent;folder=r/'retrieved/profiles/integer-warm'
record=json.loads((folder/'record.json').read_text(encoding='utf8'))
ranges=[]
for line in(folder/'perf.map').read_text(encoding='utf8').splitlines():
 a,size,name=line.split(' ',2);ranges.append((int(a,16),int(size,16),name))
ranges.sort();starts=[v[0] for v in ranges]
def resolve(address,name):
 i=bisect.bisect_right(starts,address)-1
 return ranges[i][2] if i>=0 and address<ranges[i][0]+ranges[i][1] else name
guest=set(record['guestTids']);samples=[];current=None
for line in(folder/'perf-stacks.txt').read_text(encoding='utf8').splitlines()+['']:
 head=re.match(r'^(\d+)/(\d+)\s*$',line)
 if head:
  if current is not None:samples.append(current)
  current=[] if head[2] in guest else None
 elif line.strip() and current is not None:
  m=re.match(r'\s*([0-9a-f]+)\s+(.*)',line)
  if m:current.append((int(m[1],16),resolve(int(m[1],16),m[2])))
 elif not line.strip() and current is not None:
  samples.append(current);current=None
leaf=json.loads((folder/'guest-cpu-leaves.json').read_text(encoding='utf8'));assert len(samples)==leaf['samples']
patterns=dict(
 instructionPrefix=lambda n:'ExecuteInstructionPrefix' in n,
 nativeReturn=lambda n:any(t in n for t in ['EvaluateNativeReturn','GuardNativeReturn','TryExecuteNativeFunction','TryExecuteNativeCall']),
 callAndBinding=lambda n:any(t in n for t in ['CallBindingFrame','CallableInvocation','PrepareExecutableInvocation','ExecutableInvocationFrame','BeginBoundCall','BeginPendingCall','AdvanceCallFrames','ExecuteOrdinaryCall','InvokeExecutableGeneralTargetAsync']),
 contexts=lambda n:'[Lokad.Lython]' in n and ('ExecutionContext' in n or 'ExecutionState' in n) and '::.ctor(' in n,
 formatting=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['Format','Interpolated','AsciiNumeric']),
 stringStorage=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['PyString::','GovernedByteBuilder::']),
 jsonParsing=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['ReadJson','JsonContainer','ParseJson','SkipJson','ConvertJson']),
 dictionary=lambda n:'[Lokad.Lython]' in n and ('PyDict' in n or 'PyObjectDictionary' in n),
 listStorage=lambda n:'[Lokad.Lython]' in n and ('PyList' in n or 'PyTuple' in n),
 memory=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['MemoryGovernor','LythonMemory','Reservation']),
 comparisonFileHost=lambda n:'ComparisonFileHost' in n)
patterns.update(
 operandTransport=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['ReadOperand','PublishInstructionResult','LoadLocal','StoreExecutableLocal','CompleteLocalResult','ExecutableValueStorage','StoreLocalValue']),
 numericWork=lambda n:any(t in n for t in ['System.Numerics.BigInteger::','AddExactIntegers','PyNumberOps::','EvaluateAdd','EvaluateBinaryOperator','EvaluateAugmentedOperator']),
 iterators=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['Iterator','ForAdvance','TryAdvance','MoveNext','PyRange::']),
 cancellationAndAdmission=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['CheckExecution','ThrowIfAdmissionFailed','CheckCancellation']),
 gcAndAllocation=lambda n:any(t in n for t in ['gc_heap::','garbage_collect','JIT_Box','JIT_New','AllocateObject','alloc_context','AllocLHeap']))
counts={tag:dict(inclusive=sum(any(test(n) for _,n in s) for s in samples),leaf=sum(bool(s) and test(s[0][1]) for s in samples)) for tag,test in patterns.items()}
core=collections.Counter(n for s in samples for n in {name for _,name in s if '[Lokad.Lython]' in name})
out=dict(sourceRevision='05790317',coreSHA256=json.loads((r/'identity.json').read_text(encoding='utf8'))['files']['Lokad.Lython.dll'],guestSamples=len(samples),guestCpuSeconds=leaf['cpuSeconds'],unknownLeaf=leaf['unknown'],kernelLeafSamples=sum(bool(s) and s[0][0]>=0xffff000000000000 for s in samples),groups=counts,topCoreInclusive=core.most_common(35),topLeaves=leaf['topLeafCpuSamples'],caveats='Inclusive groups overlap; never sum them as independent phases. Inlining/unwind loss and profiler overrides limit attribution. Guest sampling excludes worker fixture reset/validation/protocol and other threads; no normal elapsed or causal speed claim.')
(r/'attribution.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out,indent=2))
