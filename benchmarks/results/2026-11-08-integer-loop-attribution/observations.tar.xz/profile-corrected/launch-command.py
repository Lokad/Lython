from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'corrected-scalar-profile-b471-20261108'
source=(base/'refined-record-capacity-b469-20261108/candidate').resolve()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not Path('/dev/shm/lython-b471').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(42136+1)
 assert len(payload)==42136 and hashlib.sha256(payload).hexdigest()=='751da50f20c1c0f336af3043cedc1abefb2bf1329971247aa5b9d51565c8e8c7'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+8)*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 proof=json.loads((root/'core-source.json').read_text());archive=base/proof['vmArchive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(proof['member']).read()).hexdigest()==proof['coreSHA256']
 shutil.copytree(source,root/'candidate',copy_function=os.link)
 fixture=Path('/dev/shm/lython-b471');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b471-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],**identity['files']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=8)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b471-corrected-scalar-profile-20261108',
 '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120',
 '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
