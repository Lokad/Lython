from pathlib import Path
r=Path(__file__).parent;p=r/'profile-corrected/attribute.py';s=p.read_text(encoding='utf8');(r/'profile-corrected/attribute-original-groups.py').write_text(s,encoding='utf8')
s=s.replace("'EvaluateAugmentedOperator'","'EvaluateAugmentedOperator','EvaluateAugmentedAssignment'")
needle='counts={tag:dict('
s=s.replace(needle,"patterns['memory']=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['MemoryGovernor::','LythonMemoryBudget::','LythonMemoryScope::','LythonMemoryReservation::'])\n"+needle)
p.write_text(s,encoding='utf8')
