; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FF9B3CF05A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9B3B75BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FF9B3862230
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FF9B3862238
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B3862248
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FF9B3CED138
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2253F3C3668
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FF9B3862240
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B3862248
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 28 inlinees with PGO data; 313 single block inlinees; 93 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 984
       lea      rbp, [rsp+0x410]
       xor      eax, eax
       mov      qword ptr [rbp-0x308], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x300], xmm4
       vmovdqa  xmmword ptr [rbp-0x2F0], xmm4
       mov      rax, -672
 
G_M000_IG392:                ;; offset=0x0042
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG392
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rbx, bword ptr [rbp+0x30]
       mov      r8, bword ptr [rbp+0x38]
       mov      rax, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0076
       xor      r10d, r10d
       mov      qword ptr [rbx], r10
       mov      qword ptr [rbx+0x08], r10
 
G_M000_IG03:                ;; offset=0x0080
       mov      gword ptr [r8], r10
 
G_M000_IG04:                ;; offset=0x0083
       mov      qword ptr [rax], r10
       mov      qword ptr [rax+0x08], r10
       mov      qword ptr [rax+0x10], r10
       mov      r10, gword ptr [rcx]
       mov      r10, gword ptr [r10+0x98]
       mov      gword ptr [rbp-0x310], r10
       mov      esi, dword ptr [r10+0x08]
       cmp      dword ptr [rcx+0x10], esi
       jge      G_M000_IG373
 
G_M000_IG05:                ;; offset=0x00AC
       xor      r9d, r9d
       mov      dword ptr [rbp-0x3C], r9d
       mov      r9d, dword ptr [rcx+0x10]
       cmp      r9d, esi
       jae      G_M000_IG381
       shl      r9, 5
       lea      r9, bword ptr [r10+r9+0x10]
       mov      bword ptr [rbp-0x318], r9
       mov      rdi, gword ptr [rdx+0xA0]
       mov      r9, bword ptr [rbp-0x318]
       mov      r14, gword ptr [r9]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F1
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG07:                ;; offset=0x00FE
       mov      rcx, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rcx+0x1C]
       cmp      edi, 73
       ja       G_M000_IG302
 
G_M000_IG08:                ;; offset=0x0111
       mov      ecx, edi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0129
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG12
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG10:                ;; offset=0x014B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG11:                ;; offset=0x0158
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x1F8]
       mov      rcx, r12
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x208]
       lea      rdx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x200]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG308
 
G_M000_IG12:                ;; offset=0x01B7
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG13:                ;; offset=0x01BE
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG14:                ;; offset=0x01CB
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x90]
       mov      rcx, r12
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp-0x90]
       movsx    r13, word  ptr [rbp-0x88]
       test     rsi, rsi
       je       G_M000_IG370
 
G_M000_IG15:                ;; offset=0x01FD
       mov      rdx, rsi
       mov      rcx, 0x7FF9B3C5F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG306
 
G_M000_IG16:                ;; offset=0x0218
       mov      rcx, rsi
       mov      edx, r13d
       mov      r11, 0x7FF9B38623E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG370
 
G_M000_IG17:                ;; offset=0x0230
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0x58]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0271
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG19:                ;; offset=0x027E
       lea      rdx, [rbp-0x308]
       lea      rcx, [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x210]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG321
 
G_M000_IG20:                ;; offset=0x02C0
       mov      rsi, gword ptr [rbp-0x58]
       movsx    r13, word  ptr [rbp-0x50]
       test     rsi, rsi
       je       G_M000_IG370
 
G_M000_IG21:                ;; offset=0x02D2
       mov      rdx, rsi
       mov      rcx, 0x7FF9B3C5F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG319
 
G_M000_IG22:                ;; offset=0x02ED
       mov      rcx, rsi
       mov      edx, r13d
       mov      r11, 0x7FF9B3862408
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG370
 
G_M000_IG23:                ;; offset=0x0305
       mov      r15, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG369
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       mov      r8, r12
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG24
       mov      gword ptr [rbp-0x2D8], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG24:                ;; offset=0x0399
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x03AC
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03BC
       mov      eax, edi
       mov      dword ptr [rbp-0x29C], eax
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03C6
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x14]
       mov      dword ptr [rbp-0x29C], eax
 
G_M000_IG28:                ;; offset=0x03D6
       cmp      edi, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG29
       mov      rcx, r13
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG29:                ;; offset=0x03E7
       mov      rcx, gword ptr [r13]
       mov      eax, dword ptr [rbp-0x29C]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       shl      rdx, 4
       lea      rax, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x398], rax
       mov      rcx, rax
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x398]
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [r13+0x40], edi
       jmp      G_M000_IG370
 
G_M000_IG30:                ;; offset=0x042D
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp-0x318]
       mov      r8, gword ptr [r8]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x2D8], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG31:                ;; offset=0x04A3
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x04B6
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x04C6
       mov      eax, edi
       mov      dword ptr [rbp-0x298], eax
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x04D0
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x14]
       mov      dword ptr [rbp-0x298], eax
 
G_M000_IG35:                ;; offset=0x04E0
       cmp      edi, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG36
       mov      rcx, r13
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG36:                ;; offset=0x04F1
       mov      rcx, gword ptr [r13]
       mov      eax, dword ptr [rbp-0x298]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       shl      rdx, 4
       lea      rax, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x3A0], rax
       mov      rcx, rax
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x3A0]
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [r13+0x40], edi
       jmp      G_M000_IG370
 
G_M000_IG37:                ;; offset=0x0537
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG38
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r15
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x18]
       mov      r8d, dword ptr [r14+0x10]
       mov      r9d, dword ptr [r14+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG45
 
G_M000_IG38:                ;; offset=0x056C
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x318]
       mov      r9, gword ptr [r9]
       mov      rdx, r12
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG102
       mov      rsi, gword ptr [rbp-0x48]
       mov      r9, bword ptr [rbp-0x318]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG39
       mov      gword ptr [rbp-0x2D8], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG39:                ;; offset=0x05EA
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x05FD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x060D
       mov      eax, edi
       mov      dword ptr [rbp-0x240], eax
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0617
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x14]
       mov      dword ptr [rbp-0x240], eax
 
G_M000_IG43:                ;; offset=0x0627
       cmp      edi, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG44
       mov      rcx, r13
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG44:                ;; offset=0x0638
       mov      rcx, gword ptr [r13]
       mov      eax, dword ptr [rbp-0x240]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       shl      rdx, 4
       lea      rax, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x3A8], rax
       mov      rcx, rax
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x3A8]
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [r13+0x40], edi
       jmp      G_M000_IG370
 
G_M000_IG45:                ;; offset=0x067E
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG370
 
G_M000_IG46:                ;; offset=0x0688
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r13d, eax
       mov      rcx, bword ptr [rbp-0x318]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x328], rax
       mov      rcx, rdi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG47
       mov      rcx, rsi
       mov      edx, r13d
       mov      r8, gword ptr [rbp-0x328]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
 
G_M000_IG47:                ;; offset=0x06E9
       mov      r9, bword ptr [rbp-0x318]
       mov      esi, dword ptr [r9+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG48
       mov      gword ptr [rbp-0x2D8], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG48:                ;; offset=0x0728
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x073B
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x074B
       mov      eax, esi
       mov      dword ptr [rbp-0x23C], eax
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0755
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x14]
       mov      dword ptr [rbp-0x23C], eax
 
G_M000_IG52:                ;; offset=0x0765
       cmp      esi, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG53
       mov      rcx, r13
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG53:                ;; offset=0x0776
       mov      rcx, gword ptr [r13]
       mov      eax, dword ptr [rbp-0x23C]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       shl      rdx, 4
       lea      rax, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x3B0], rax
       mov      rcx, rax
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B0]
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [r13+0x40], esi
       jmp      G_M000_IG370
 
G_M000_IG54:                ;; offset=0x07BC
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x30]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG369
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG55
       mov      gword ptr [rbp-0x2D8], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG55:                ;; offset=0x0830
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0843
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0853
       mov      eax, edi
       mov      dword ptr [rbp-0x294], eax
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x085D
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x14]
       mov      dword ptr [rbp-0x294], eax
 
G_M000_IG59:                ;; offset=0x086D
       cmp      edi, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG60
       mov      rcx, r13
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG60:                ;; offset=0x087E
       mov      rcx, gword ptr [r13]
       mov      eax, dword ptr [rbp-0x294]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       shl      rdx, 4
       lea      rax, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x3B8], rax
       mov      rcx, rax
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      rsi, bword ptr [rbp-0x3B8]
       mov      qword ptr [rsi+0x08], rdx
       mov      dword ptr [r13+0x40], edi
       jmp      G_M000_IG370
 
G_M000_IG61:                ;; offset=0x08C4
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rdx+0xA8]
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B38623E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG63
       lea      rcx, [rbp-0x228]
       mov      rdx, rax
       mov      r8, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x238]
       lea      rdx, [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x230]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       jne      G_M000_IG328
 
G_M000_IG62:                ;; offset=0x094C
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG370
 
G_M000_IG63:                ;; offset=0x0962
       mov      rcx, gword ptr [r14]
       mov      r8, gword ptr [r14+0x08]
       mov      rdx, rax
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG370
 
G_M000_IG64:                ;; offset=0x097A
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG102
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      r13d, dword ptr [rcx+0x10]
       mov      ecx, edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x099F
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG69
 
G_M000_IG66:                ;; offset=0x09AF
       mov      rcx, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG67
       mov      edi, eax
       not      edi
       jmp      SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x09C3
       mov      edi, eax
 
G_M000_IG68:                ;; offset=0x09C5
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x09C7
       mov      rcx, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG70:                ;; offset=0x09D1
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
       mov      rcx, gword ptr [r15]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      eax, r13d
       shl      rax, 4
 
G_M000_IG71:                ;; offset=0x09F1
       vmovdqu  xmm0, xmmword ptr [rcx+rax+0x10]
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
 
G_M000_IG72:                ;; offset=0x09FF
       cmp      gword ptr [rbp-0x260], 0
       jne      SHORT G_M000_IG73
       lea      rcx, [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG73:                ;; offset=0x0A29
       mov      r8, gword ptr [r15]
       cmp      r13d, dword ptr [r8+0x08]
       jae      G_M000_IG369
       mov      edx, r13d
       shl      rdx, 4
       xor      ecx, ecx
       mov      qword ptr [r8+rdx+0x10], rcx
       mov      qword ptr [r8+rdx+0x18], rcx
       mov      dword ptr [r15+0x40], edi
       mov      rdi, gword ptr [rbp-0x260]
       mov      r15, qword ptr [rbp-0x258]
       mov      r13d, dword ptr [r14+0x10]
       inc      r13d
       mov      r12, gword ptr [rbp+0x20]
       mov      rax, gword ptr [r12+0x70]
       mov      gword ptr [rbp-0x320], rax
       cmp      byte  ptr [r12+0x109], 0
       jne      SHORT G_M000_IG74
       cmp      byte  ptr [r12+0x107], 0
       jne      SHORT G_M000_IG74
       cmp      esi, r13d
       jg       SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0A8D
       xor      r10d, r10d
       jmp      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0A92
       cmp      r13d, esi
       jae      G_M000_IG369
       mov      r10d, r13d
       shl      r10, 5
       mov      r9, gword ptr [rbp-0x310]
       cmp      dword ptr [r9+r10+0x2C], 30
       sete     r10b
       movzx    r10, r10b
 
G_M000_IG76:                ;; offset=0x0AB7
       mov      dword ptr [rbp-0x94], r10d
       test     r10d, r10d
       jne      SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0AC3
       jmp      SHORT G_M000_IG81
 
G_M000_IG78:                ;; offset=0x0AC5
       test     rax, rax
       jne      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0ACA
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0ACC
       mov      gword ptr [rbp-0x2D8], rdi
       mov      qword ptr [rbp-0x2D0], r15
       lea      r8, [rbp-0x2D8]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0AF1
       lea      rcx, bword ptr [r12+0x198]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x1A0], r15
       mov      word  ptr [r12+0x100], 257
       inc      dword ptr [r14+0x10]
       cmp      dword ptr [rbp-0x94], 0
       jne      G_M000_IG269
       mov      rsi, gword ptr [rbp-0x320]
       test     rsi, rsi
       je       G_M000_IG269
       mov      rcx, r12
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG269
       jmp      G_M000_IG372
 
G_M000_IG82:                ;; offset=0x0B4E
       cmp      r13d, esi
       jae      G_M000_IG369
       mov      ecx, r13d
       shl      rcx, 5
       mov      r9, gword ptr [rbp-0x310]
       mov      rsi, gword ptr [r9+rcx+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, gword ptr [rdi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG83
       mov      rcx, r15
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG83:                ;; offset=0x0B91
       mov      rcx, gword ptr [rdi+0xA0]
       mov      rdx, rcx
       mov      rax, gword ptr [r12+0x78]
       test     rax, rax
       je       SHORT G_M000_IG84
       cmp      dword ptr [rax+0x10], 0
       setg     al
       movzx    rax, al
       test     eax, eax
       je       SHORT G_M000_IG84
       mov      rax, gword ptr [rcx+0x148]
       jmp      SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0BBC
       mov      rax, gword ptr [r12+0x80]
 
G_M000_IG85:                ;; offset=0x0BC4
       lea      rcx, bword ptr [rdx+0x148]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, r13d
       shl      rdx, 5
       mov      r9, gword ptr [rbp-0x310]
       lea      rdx, bword ptr [r9+rdx+0x10]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG86
       not      edx
 
G_M000_IG86:                ;; offset=0x0BF3
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG372
 
G_M000_IG87:                ;; offset=0x0C03
       mov      rdi, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rbx
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r8
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG224
       mov      dword ptr [rbp-0x7C], eax
       jmp      G_M000_IG378
 
G_M000_IG88:                ;; offset=0x0C4B
       mov      rdx, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [rdx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG89
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x0C6F
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG90:                ;; offset=0x0C74
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x2C0], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp-0x2C8]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       jne      SHORT G_M000_IG91
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG102
 
G_M000_IG91:                ;; offset=0x0CBE
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG96
       test     rsi, rsi
       je       SHORT G_M000_IG96
 
G_M000_IG92:                ;; offset=0x0CC9
       mov      r8, 0x7FF9B401ADE8
       cmp      qword ptr [rsi], r8
       jne      SHORT G_M000_IG96
 
G_M000_IG93:                ;; offset=0x0CD8
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG94:                ;; offset=0x0CDF
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG95:                ;; offset=0x0CEC
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x158]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x158]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x150]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG224
       jmp      G_M000_IG363
 
G_M000_IG96:                ;; offset=0x0D33
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG370
 
G_M000_IG97:                ;; offset=0x0D51
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       jne      SHORT G_M000_IG99
       mov      ecx, edi
       cmp      ecx, 58
       ja       G_M000_IG102
 
G_M000_IG98:                ;; offset=0x0D69
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jb       G_M000_IG102
 
G_M000_IG99:                ;; offset=0x0D7D
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [r14+0x68], 0
       je       G_M000_IG370
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG269
       cmp      gword ptr [r14+0x40], 0
       je       G_M000_IG269
       xor      rcx, rcx
       mov      gword ptr [rbx], rcx
       mov      word  ptr [rbx+0x08], 0
       movzx    rcx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rbx+0x0A], cl
       mov      byte  ptr [rbx+0x0B], 1
       mov      dword ptr [rbp-0x7C], 5
       jmp      G_M000_IG378
 
G_M000_IG100:                ;; offset=0x0DD9
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG107
       jmp      G_M000_IG370
 
G_M000_IG101:                ;; offset=0x0E05
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       jne      G_M000_IG220
 
G_M000_IG102:                ;; offset=0x0E16
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x7C], 6
       jmp      G_M000_IG378
 
G_M000_IG103:                ;; offset=0x0E2E
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       SHORT G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG220
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG104:                ;; offset=0x0E4C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG105:                ;; offset=0x0E59
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x168]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x178]
       lea      rdx, [rbp-0x168]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x178]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x170]
       mov      qword ptr [rdi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG360
 
G_M000_IG106:                ;; offset=0x0EB2
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG370
 
G_M000_IG107:                ;; offset=0x0ED9
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rbx
       mov      rcx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG370
       mov      dword ptr [rbp-0x7C], eax
       jmp      G_M000_IG378
 
G_M000_IG108:                ;; offset=0x0F2A
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rdx+0xB0]
       cmp      edi, 42
       jne      G_M000_IG343
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B38623D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG112
 
G_M000_IG109:                ;; offset=0x0F6A
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG112
 
G_M000_IG110:                ;; offset=0x0F7A
       mov      rdx, bword ptr [rbp-0x318]
       mov      esi, dword ptr [rdx+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG111
       not      esi
 
G_M000_IG111:                ;; offset=0x0F8A
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0F8C
       mov      rdx, bword ptr [rbp-0x318]
       mov      esi, dword ptr [rdx+0x14]
 
G_M000_IG113:                ;; offset=0x0F96
       mov      rdx, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [rdx+0x10]
       test     r8d, r8d
       jge      G_M000_IG124
       cmp      dword ptr [r14+0x60], esi
       jne      G_M000_IG124
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG114
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0FC9
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG115:                ;; offset=0x0FCE
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x2C0], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rbp-0x2C8]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG116
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1013
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG117:                ;; offset=0x1018
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x2C0], edx
       mov      gword ptr [rsp+0x20], r13
       mov      rdx, gword ptr [rdi+0x18]
       mov      gword ptr [rsp+0x28], rdx
       mov      gword ptr [rsp+0x30], r15
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       setne    dl
       movzx    rdx, dl
       mov      dword ptr [rsp+0x38], edx
       lea      rdx, [rbp-0xA0]
       mov      qword ptr [rsp+0x40], rdx
       lea      rdx, [rbp-0xB0]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x2C8]
       mov      r9d, dword ptr [r14+0x10]
       mov      r8, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeForwardedUnaryBuiltin(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool]
       test     eax, eax
       jne      G_M000_IG139
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x358], rax
       lea      r8d, [rsi+0x01]
       mov      dword ptr [rbp-0x2B0], r8d
       cmp      r8d, dword ptr [rax+0x40]
       jl       SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x109D
       jmp      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x109F
       mov      rcx, rax
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x358]
 
G_M000_IG120:                ;; offset=0x10B2
       mov      rcx, gword ptr [rax]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, esi
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x368], rcx
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r13, bword ptr [rbp-0x368]
       mov      qword ptr [r13+0x08], rcx
       mov      r13, bword ptr [rbp-0x358]
       mov      ecx, dword ptr [rbp-0x2B0]
       mov      dword ptr [r13+0x40], ecx
       lea      r13, bword ptr [r14+0x20]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x360], rax
       lea      r8d, [rsi+0x02]
       mov      dword ptr [rbp-0x2B4], r8d
       cmp      r8d, dword ptr [r13+0x40]
       jl       SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x111C
       mov      rax, gword ptr [rbp-0x360]
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x1125
       mov      rcx, r13
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, gword ptr [rbp-0x360]
 
G_M000_IG123:                ;; offset=0x1138
       mov      rcx, gword ptr [r13]
       lea      edx, [rsi+0x01]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       lea      edx, [rsi+0x01]
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x370], rcx
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rax, bword ptr [rbp-0x370]
       mov      qword ptr [rax+0x08], rcx
       mov      ecx, dword ptr [rbp-0x2B4]
       mov      dword ptr [r13+0x40], ecx
 
G_M000_IG124:                ;; offset=0x117D
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       lea      rcx, bword ptr [r14+0x20]
       cmp      byte  ptr [rdi], dil
       mov      rcx, gword ptr [rcx]
       cmp      byte  ptr [rdi+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, esi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r13, rax
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], r13
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      G_M000_IG134
       test     r12, r12
       je       G_M000_IG133
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, r12
       mov      rdx, rdi
       mov      r8d, esi
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG129
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG126
       mov      gword ptr [rsp+0x20], r13
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x188]
       mov      rcx, r12
       mov      r8, rdi
 
G_M000_IG125:                ;; offset=0x1249
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x198]
       lea      rdx, [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r13, rbx
       mov      rdx, gword ptr [rbp-0x198]
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x190]
       mov      qword ptr [r13+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       je       G_M000_IG62
       jmp      G_M000_IG354
 
G_M000_IG126:                ;; offset=0x1294
       mov      gword ptr [rsp+0x20], r13
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x90]
       mov      rcx, r12
       mov      r8, rdi
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0x90]
       mov      rsi, rdx
       movsx    r13, word  ptr [rbp-0x88]
       test     rsi, rsi
       je       G_M000_IG370
 
G_M000_IG127:                ;; offset=0x12D0
       mov      rdx, rsi
       mov      rcx, 0x7FF9B3C5F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG352
 
G_M000_IG128:                ;; offset=0x12EB
       mov      rcx, rsi
       mov      edx, r13d
       mov      r11, 0x7FF9B3862460
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG370
 
G_M000_IG129:                ;; offset=0x1303
       mov      rax, bword ptr [rbp+0x40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       jne      G_M000_IG345
 
G_M000_IG130:                ;; offset=0x1313
       mov      rax, bword ptr [rbp+0x40]
       mov      rsi, gword ptr [rax]
       test     rsi, rsi
       jne      G_M000_IG348
 
G_M000_IG131:                ;; offset=0x1323
       mov      r13, gword ptr [rax+0x08]
 
G_M000_IG132:                ;; offset=0x1327
       cmp      r13, r12
       jne      G_M000_IG137
       xor      ecx, ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rsi, r12
       jmp      G_M000_IG200
 
G_M000_IG133:                ;; offset=0x1349
       mov      gword ptr [rsp+0x20], r13
       lea      rcx, [rbp-0xB8]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, rdi
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG102
       cmp      gword ptr [rbp-0xB8], 0
       je       G_M000_IG370
       mov      rdx, gword ptr [rbp-0xB8]
       xor      rcx, rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      gword ptr [rax], rcx
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x40]
       mov      word  ptr [rax+0x10], 0
       mov      byte  ptr [rax+0x12], 1
       jmp      SHORT G_M000_IG137
 
G_M000_IG134:                ;; offset=0x13AB
       cmp      gword ptr [rbp-0x78], 0
       je       G_M000_IG370
       mov      rdx, gword ptr [rbp-0x78]
       mov      rcx, 0x7FF9B3CE9370
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG138
       mov      rdx, gword ptr [rbp-0x78]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG136
 
G_M000_IG135:                ;; offset=0x13DD
       mov      rcx, 0x7FF9B3F88520
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG344
 
G_M000_IG136:                ;; offset=0x13F0
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0x40]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0x40]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
 
G_M000_IG137:                ;; offset=0x1415
       mov      rdx, gword ptr [rdi+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x7C], 3
       jmp      G_M000_IG378
 
G_M000_IG138:                ;; offset=0x142E
       jmp      G_M000_IG377
 
G_M000_IG139:                ;; offset=0x1433
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, 0x7FF9B3CE9370
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      G_M000_IG146
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, qword ptr [rbp-0xA8]
       mov      r9, bword ptr [rbp-0x318]
       mov      r13d, dword ptr [r9+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG140
       mov      gword ptr [rbp-0x2D8], rsi
       mov      qword ptr [rbp-0x2D0], rdi
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG140:                ;; offset=0x14A0
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x350], rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG143
 
G_M000_IG141:                ;; offset=0x14BA
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x14CA
       mov      r8d, r13d
       mov      dword ptr [rbp-0x2AC], r8d
       jmp      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x14D6
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2AC], r8d
 
G_M000_IG144:                ;; offset=0x14E8
       cmp      r13d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG145
       mov      rcx, rax
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x350]
 
G_M000_IG145:                ;; offset=0x1501
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2AC]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x378], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, bword ptr [rbp-0x378]
       mov      qword ptr [rsi+0x08], rdi
       mov      rsi, bword ptr [rbp-0x350]
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG370
 
G_M000_IG146:                ;; offset=0x154E
       jmp      G_M000_IG377
 
G_M000_IG147:                ;; offset=0x1553
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x10]
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG148
       mov      r10d, r8d
       mov      r9d, eax
       add      r10, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r10, r9
       ja       G_M000_IG318
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       jmp      SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x1596
       or       r8d, eax
       jne      G_M000_IG318
       xor      rdx, rdx
       xor      eax, eax
 
G_M000_IG149:                ;; offset=0x15A3
       mov      bword ptr [rbp-0x2C8], rdx
       mov      dword ptr [rbp-0x2C0], eax
       lea      rcx, [rbp-0x2C8]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, bword ptr [rbp-0x318]
       mov      r8, gword ptr [r8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG370
 
G_M000_IG150:                ;; offset=0x15D7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG369
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rdi+rcx+0x10], 0
       jne      G_M000_IG370
       jmp      G_M000_IG305
 
G_M000_IG151:                ;; offset=0x160C
       mov      rcx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rcx+0x20]
       cmp      edi, 51
       ja       SHORT G_M000_IG155
 
G_M000_IG152:                ;; offset=0x1619
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdi
       jb       SHORT G_M000_IG155
 
G_M000_IG153:                ;; offset=0x1629
       mov      rax, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rax+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG154
       not      edi
 
G_M000_IG154:                ;; offset=0x1639
       jmp      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x163B
       mov      rax, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rax+0x14]
 
G_M000_IG156:                ;; offset=0x1645
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG157
       mov      r14d, eax
       not      r14d
       jmp      SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x165B
       mov      r14d, eax
 
G_M000_IG158:                ;; offset=0x165E
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x250], xmm0
       mov      rax, gword ptr [rsi]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG369
       mov      edx, edi
       shl      rdx, 4
 
G_M000_IG159:                ;; offset=0x167C
       vmovdqu  xmm0, xmmword ptr [rax+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x250], xmm0
 
G_M000_IG160:                ;; offset=0x168A
       cmp      gword ptr [rbp-0x250], 0
       jne      SHORT G_M000_IG161
       lea      rcx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG161:                ;; offset=0x16B4
       mov      r8, gword ptr [rsi]
       cmp      edi, dword ptr [r8+0x08]
       jae      G_M000_IG369
       mov      edx, edi
       shl      rdx, 4
       xor      r9d, r9d
       mov      qword ptr [r8+rdx+0x10], r9
       mov      qword ptr [r8+rdx+0x18], r9
       mov      dword ptr [rsi+0x40], r14d
       mov      r8, gword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG162
       lea      rax, bword ptr [r9+0x10]
       mov      r9d, dword ptr [r9+0x08]
       jmp      SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x16FD
       xor      rax, rax
       xor      r9d, r9d
 
G_M000_IG163:                ;; offset=0x1702
       mov      rsi, gword ptr [rbp+0x20]
       mov      r10, rsi
       test     r10, r10
       jne      SHORT G_M000_IG164
       mov      rdi, gword ptr [rbp+0x18]
       mov      r10, rdi
 
G_M000_IG164:                ;; offset=0x1715
       mov      rdi, gword ptr [rbp+0x18]
       mov      r10, gword ptr [r10+0xA0]
       mov      r11, bword ptr [rbp-0x318]
       mov      r11d, dword ptr [r11+0x10]
       cmp      r11d, r9d
       jae      G_M000_IG369
       mov      r9d, r11d
       shl      r9, 4
       add      r9, rax
       mov      gword ptr [rbp-0x2D8], r8
       mov      qword ptr [rbp-0x2D0], rdx
       mov      rcx, r9
       lea      r8, [rbp-0x2D8]
       mov      rdx, bword ptr [rbp-0x318]
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG370
 
G_M000_IG165:                ;; offset=0x176B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG369
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x179C
       mov      rax, 0x7FF9B3D8FE90
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG317
 
G_M000_IG167:                ;; offset=0x17AF
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x20]
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG171
 
G_M000_IG168:                ;; offset=0x17CB
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG171
 
G_M000_IG169:                ;; offset=0x17DB
       mov      r9, bword ptr [rbp-0x318]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG170
       not      r9d
 
G_M000_IG170:                ;; offset=0x17EE
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x17F0
       mov      r9, bword ptr [rbp-0x318]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG172:                ;; offset=0x17FB
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG173
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x1811
       mov      r10d, eax
 
G_M000_IG174:                ;; offset=0x1814
       cmp      r8d, 51
       ja       SHORT G_M000_IG179
 
G_M000_IG175:                ;; offset=0x181A
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG179
 
G_M000_IG176:                ;; offset=0x182A
       test     eax, eax
       jge      SHORT G_M000_IG177
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG178
 
G_M000_IG177:                ;; offset=0x1836
       mov      r8d, eax
 
G_M000_IG178:                ;; offset=0x1839
       jmp      SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x183B
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG180:                ;; offset=0x1846
       sub      r10d, r8d
       test     rdx, rdx
       je       SHORT G_M000_IG181
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG318
       mov      r9d, r9d
       shl      r9, 4
       lea      rdx, bword ptr [rdx+r9+0x10]
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x1871
       or       r9d, r10d
       jne      G_M000_IG318
       xor      rdx, rdx
       xor      r10d, r10d
 
G_M000_IG182:                ;; offset=0x187F
       mov      r8, bword ptr [rbp-0x318]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rsi, gword ptr [rbp+0x20]
       mov      r9, rsi
       test     r9, r9
       jne      SHORT G_M000_IG183
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG183:                ;; offset=0x18A6
       mov      rdi, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x2C8], rdx
       mov      dword ptr [rbp-0x2C0], r10d
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       lea      rdx, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG184
       not      ecx
 
G_M000_IG184:                ;; offset=0x18E8
       mov      dword ptr [rdx+0x40], ecx
       jmp      G_M000_IG370
 
G_M000_IG185:                ;; offset=0x18F0
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG195
       mov      r14, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [r14+0x60]
       mov      eax, edi
       cmp      eax, 51
       ja       SHORT G_M000_IG190
 
G_M000_IG186:                ;; offset=0x190C
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jb       SHORT G_M000_IG190
 
G_M000_IG187:                ;; offset=0x191C
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG188
       mov      edx, eax
       not      edx
       jmp      SHORT G_M000_IG189
 
G_M000_IG188:                ;; offset=0x1930
       mov      edx, eax
 
G_M000_IG189:                ;; offset=0x1932
       jmp      SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x1934
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x14]
 
G_M000_IG191:                ;; offset=0x193E
       cmp      ecx, edx
       jne      G_M000_IG195
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       shl      rax, 4
       mov      rdi, gword ptr [rcx+rax+0x10]
       test     rdi, rdi
       je       G_M000_IG195
 
G_M000_IG192:                ;; offset=0x196F
       mov      rcx, 0x7FF9B4015088
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG195
 
G_M000_IG193:                ;; offset=0x1982
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG195
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG195
       mov      rdx, bword ptr [rbp-0x318]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x118]
       mov      rcx, rsi
       mov      r8, rax
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x118]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x110]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       je       G_M000_IG224
       jmp      G_M000_IG337
 
G_M000_IG194:                ;; offset=0x19F7
       mov      rsi, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG200
 
G_M000_IG195:                ;; offset=0x1A1E
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       lea      r8, [rbp-0x60]
       lea      r9, [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG199
       test     rsi, rsi
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG198
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG196:                ;; offset=0x1A60
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG197:                ;; offset=0x1A6D
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x1A8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1A0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       je       G_M000_IG224
       jmp      G_M000_IG340
 
G_M000_IG198:                ;; offset=0x1AB2
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG370
 
G_M000_IG199:                ;; offset=0x1ACA
       cmp      byte  ptr [rbp-0x60], 0
       jne      SHORT G_M000_IG201
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [r14+0x10], eax
 
G_M000_IG200:                ;; offset=0x1AF5
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG370
 
G_M000_IG201:                ;; offset=0x1B01
       mov      rdi, gword ptr [rbp-0x70]
       mov      r13, qword ptr [rbp-0x68]
       mov      r9, bword ptr [rbp-0x318]
       mov      r12d, dword ptr [r9+0x18]
       test     r12d, r12d
       jge      SHORT G_M000_IG202
       mov      gword ptr [rbp-0x2D8], rdi
       mov      qword ptr [rbp-0x2D0], r13
       lea      r9, [rbp-0x2D8]
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG202:                ;; offset=0x1B46
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x348], rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG205
 
G_M000_IG203:                ;; offset=0x1B60
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1B70
       mov      r8d, r12d
       mov      dword ptr [rbp-0x2A8], r8d
       jmp      SHORT G_M000_IG206
 
G_M000_IG205:                ;; offset=0x1B7C
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2A8], r8d
 
G_M000_IG206:                ;; offset=0x1B8E
       cmp      r12d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG207
       mov      rcx, rax
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x348]
 
G_M000_IG207:                ;; offset=0x1BA7
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2A8]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x380], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x380]
       mov      qword ptr [rdi+0x08], r13
       mov      rdi, bword ptr [rbp-0x348]
       mov      dword ptr [rdi+0x40], r12d
       jmp      G_M000_IG370
 
G_M000_IG208:                ;; offset=0x1BF4
       mov      r14, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG209
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x1C1C
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG210:                ;; offset=0x1C21
       mov      bword ptr [rbp-0x2C8], r9
       mov      dword ptr [rbp-0x2C0], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rbp-0x2C8]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG214
 
G_M000_IG211:                ;; offset=0x1C60
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       SHORT G_M000_IG214
 
G_M000_IG212:                ;; offset=0x1C70
       mov      rcx, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [rcx+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG213
       not      r8d
 
G_M000_IG213:                ;; offset=0x1C83
       jmp      SHORT G_M000_IG215
 
G_M000_IG214:                ;; offset=0x1C85
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG215:                ;; offset=0x1C90
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG216
       mov      r9d, ecx
       not      r9d
       jmp      SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x1CA6
       mov      r9d, ecx
 
G_M000_IG217:                ;; offset=0x1CA9
       mov      rcx, bword ptr [rbp-0x318]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG370
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG220
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG218:                ;; offset=0x1CE3
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG219:                ;; offset=0x1CF0
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x1B8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1C8]
       lea      rdx, [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       je       G_M000_IG62
       jmp      G_M000_IG357
 
G_M000_IG220:                ;; offset=0x1D49
       mov      rsi, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG370
 
G_M000_IG221:                ;; offset=0x1D66
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG226
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG222:                ;; offset=0x1D84
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG223:                ;; offset=0x1D91
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x1D8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1D0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       jne      G_M000_IG334
 
G_M000_IG224:                ;; offset=0x1DD1
       mov      rsi, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG370
 
G_M000_IG225:                ;; offset=0x1DE6
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG102
 
G_M000_IG226:                ;; offset=0x1DF7
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG370
 
G_M000_IG227:                ;; offset=0x1E0F
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       SHORT G_M000_IG228
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG269
 
G_M000_IG228:                ;; offset=0x1E34
       mov      rdi, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rdi+0x08]
       test     r8d, r8d
       je       SHORT G_M000_IG229
       mov      rcx, r14
       mov      rdx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      G_M000_IG236
 
G_M000_IG229:                ;; offset=0x1E59
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      r12d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r15
       mov      edx, r12d
       mov      rcx, r13
       mov      r9, bword ptr [rbp-0x318]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      r13, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      r12d, dword ptr [r9+0x18]
       test     r12d, r12d
       jge      SHORT G_M000_IG230
       mov      gword ptr [rbp-0x2D8], r13
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG230:                ;; offset=0x1EDA
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG233
 
G_M000_IG231:                ;; offset=0x1EF4
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x1F04
       mov      r8d, r12d
       mov      dword ptr [rbp-0x2A4], r8d
       jmp      SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x1F10
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2A4], r8d
 
G_M000_IG234:                ;; offset=0x1F22
       cmp      r12d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG235
       mov      rcx, rax
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x340]
 
G_M000_IG235:                ;; offset=0x1F3B
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2A4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x388], rcx
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      r13, bword ptr [rbp-0x388]
       mov      qword ptr [r13+0x08], r9
       mov      r13, bword ptr [rbp-0x340]
       mov      dword ptr [r13+0x40], r12d
       jmp      G_M000_IG370
 
G_M000_IG236:                ;; offset=0x1F8B
       mov      r15, gword ptr [rbp+0x18]
 
G_M000_IG237:                ;; offset=0x1F8F
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG238:                ;; offset=0x1F9B
       lea      r9, [rbp-0x2C8]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0x7C], 2
       jmp      G_M000_IG378
 
G_M000_IG239:                ;; offset=0x1FC1
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       mov      r9, rsi
       test     r9, r9
       jne      SHORT G_M000_IG240
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG240:                ;; offset=0x1FD8
       mov      rcx, r14
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG370
       test     rsi, rsi
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG243
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG241:                ;; offset=0x2009
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG242:                ;; offset=0x2016
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x128]
       mov      rcx, rsi
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x138]
       lea      rdx, [rbp-0x128]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x138]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x130]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG62
       jmp      G_M000_IG314
 
G_M000_IG243:                ;; offset=0x2075
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG244:                ;; offset=0x207C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG245:                ;; offset=0x2089
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x90]
       mov      rcx, rsi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r15, gword ptr [rbp-0x90]
       movsx    r13, word  ptr [rbp-0x88]
       test     r15, r15
       je       G_M000_IG370
 
G_M000_IG246:                ;; offset=0x20BB
       mov      rdx, r15
       mov      rcx, 0x7FF9B3C5F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG312
 
G_M000_IG247:                ;; offset=0x20D6
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9B38623F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG370
 
G_M000_IG248:                ;; offset=0x20EE
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG264
       cmp      gword ptr [rsi+0x68], 0
       jne      G_M000_IG256
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      r13d, dword ptr [rcx+0x10]
       mov      ecx, edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG253
 
G_M000_IG249:                ;; offset=0x212A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG253
 
G_M000_IG250:                ;; offset=0x213A
       mov      rcx, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG251
       mov      edi, eax
       not      edi
       jmp      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x214E
       mov      edi, eax
 
G_M000_IG252:                ;; offset=0x2150
       jmp      SHORT G_M000_IG254
 
G_M000_IG253:                ;; offset=0x2152
       mov      rcx, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG254:                ;; offset=0x215C
       mov      rcx, gword ptr [r15]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      eax, r13d
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      rcx, gword ptr [r15]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, r13d
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG255:                ;; offset=0x21AF
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [r15+0x40], edi
       mov      rcx, 0x7FF9B3922560
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      rcx, 0x7FF9B4019160
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      r13, gword ptr [rcx]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, 0x205188019C8
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [r15+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x68]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG256:                ;; offset=0x2255
       mov      rcx, gword ptr [rsi+0x68]
       mov      r8, gword ptr [rsi+0x58]
       mov      r9, gword ptr [rsi+0x60]
       cmp      byte  ptr [rcx], cl
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:AdvanceAsync(System.Object,Lokad.Lython.Runtime.LythonRuntimeException,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rdi, gword ptr [rbp-0x280]
       movsx    r15, word  ptr [rbp-0x278]
       test     rdi, rdi
       je       SHORT G_M000_IG260
       mov      rdx, rdi
       mov      rcx, 0x7FF9B40264B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       jne      SHORT G_M000_IG257
       lea      rdx, [rbp-0x290]
       mov      rcx, rdi
       mov      r8d, r15d
       mov      r11, 0x7FF9B3862420
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      SHORT G_M000_IG261
 
G_M000_IG257:                ;; offset=0x22C0
       mov      ecx, dword ptr [r13+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG327
 
G_M000_IG258:                ;; offset=0x22D6
       vmovdqu  xmm0, xmmword ptr [r13+0x38]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG259:                ;; offset=0x22E4
       jmp      SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x22E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x270]
       vmovdqu  xmmword ptr [rbp-0x290], xmm0
 
G_M000_IG261:                ;; offset=0x22F6
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG262:                ;; offset=0x22FD
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG263:                ;; offset=0x230A
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x290]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      SHORT G_M000_IG268
 
G_M000_IG264:                ;; offset=0x2323
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG265:                ;; offset=0x232A
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG266:                ;; offset=0x2337
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x148]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x148]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x140]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       jne      G_M000_IG324
 
G_M000_IG267:                ;; offset=0x2377
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
 
G_M000_IG268:                ;; offset=0x2380
       cmp      byte  ptr [rsi+0x101], 0
       je       G_M000_IG370
       mov      rdx, gword ptr [rsi+0x70]
       test     rdx, rdx
       je       SHORT G_M000_IG269
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       jne      G_M000_IG372
 
G_M000_IG269:                ;; offset=0x23A7
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x7C], 1
       jmp      G_M000_IG378
 
G_M000_IG270:                ;; offset=0x23BB
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x318]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r15, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r15
       mov      edx, r13d
       mov      rcx, rsi
       mov      r9, bword ptr [rbp-0x318]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      r13d, dword ptr [r9+0x18]
       test     r13d, r13d
       jge      SHORT G_M000_IG271
       mov      gword ptr [rbp-0x2D8], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D0], r9
       lea      r9, [rbp-0x2D8]
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG370
 
G_M000_IG271:                ;; offset=0x2444
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x338], rax
       mov      rcx, bword ptr [rbp-0x318]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG274
 
G_M000_IG272:                ;; offset=0x245E
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x246E
       mov      r8d, r13d
       mov      dword ptr [rbp-0x2A0], r8d
       jmp      SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x247A
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2A0], r8d
 
G_M000_IG275:                ;; offset=0x248C
       cmp      r13d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG276
       mov      rcx, rax
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x338]
 
G_M000_IG276:                ;; offset=0x24A5
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2A0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x390], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x390]
       mov      qword ptr [rsi+0x08], rcx
       mov      rsi, bword ptr [rbp-0x338]
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG370
 
G_M000_IG277:                ;; offset=0x24F4
       mov      r15, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG278
       not      edx
 
G_M000_IG278:                ;; offset=0x2549
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG370
 
G_M000_IG279:                ;; offset=0x2554
       mov      r15, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      ecx, edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG284
 
G_M000_IG280:                ;; offset=0x2567
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG284
 
G_M000_IG281:                ;; offset=0x2577
       mov      rcx, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG282
       mov      edi, eax
       not      edi
       jmp      SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x258B
       mov      edi, eax
 
G_M000_IG283:                ;; offset=0x258D
       jmp      SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x258F
       mov      rax, bword ptr [rbp-0x318]
       mov      edi, dword ptr [rax+0x14]
 
G_M000_IG285:                ;; offset=0x2599
       inc      edi
       mov      rcx, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rcx+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG286
       mov      r13d, eax
       not      r13d
       jmp      SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x25B1
       mov      r13d, eax
 
G_M000_IG287:                ;; offset=0x25B4
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x318]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x330], rax
       cmp      r13d, dword ptr [rsi+0x40]
       jl       SHORT G_M000_IG289
 
G_M000_IG288:                ;; offset=0x25FA
       mov      rax, gword ptr [rbp-0x330]
       jmp      SHORT G_M000_IG290
 
G_M000_IG289:                ;; offset=0x2603
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, gword ptr [rbp-0x330]
 
G_M000_IG290:                ;; offset=0x2616
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG369
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG370
 
G_M000_IG291:                ;; offset=0x2647
       mov      r15, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, gword ptr [r14]
       mov      r13, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG369
       mov      ecx, eax
       mov      r13, gword ptr [r13+8*rcx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG292
       not      r8d
 
G_M000_IG292:                ;; offset=0x26A9
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      gword ptr [rsp+0x20], r12
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, rdi
       mov      r8, r13
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG370
 
G_M000_IG293:                ;; offset=0x26DA
       mov      r15, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG369
       mov      ecx, eax
       mov      rsi, gword ptr [rsi+8*rcx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x318]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG294
       not      r8d
 
G_M000_IG294:                ;; offset=0x2734
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      r9, bword ptr [rbp-0x318]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      r8, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG370
 
G_M000_IG295:                ;; offset=0x2758
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, r14
       mov      rdx, r12
       mov      r8, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG370
       jmp      G_M000_IG102
 
G_M000_IG296:                ;; offset=0x2784
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG370
 
G_M000_IG297:                ;; offset=0x27AB
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       mov      r12, gword ptr [rbp+0x20]
       test     r12, r12
       je       G_M000_IG102
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG370
 
G_M000_IG298:                ;; offset=0x27D8
       mov      r12, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG370
       test     r12, r12
       je       G_M000_IG102
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG301
       mov      r8, bword ptr [rbp-0x318]
 
G_M000_IG299:                ;; offset=0x2818
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2F8], ymm0
 
G_M000_IG300:                ;; offset=0x2825
       lea      r8, [rbp-0x2F8]
       lea      rdx, [rbp-0x1E8]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1E0]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG331
 
G_M000_IG301:                ;; offset=0x286A
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, r12
       mov      r9, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG370
 
G_M000_IG302:                ;; offset=0x2885
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
       lea      rcx, [rbp-0x108]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG303:                ;; offset=0x28B1
       vmovdqu  ymm0, ymmword ptr [rbp-0x108]
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       mov      rcx, qword ptr [rbp-0xE8]
       mov      qword ptr [rbp-0xC0], rcx
 
G_M000_IG304:                ;; offset=0x28CF
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rbp-0xC0]
       jbe      G_M000_IG366
       jmp      G_M000_IG318
 
G_M000_IG305:                ;; offset=0x28E6
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9B38623D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG306:                ;; offset=0x292C
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG370
 
G_M000_IG307:                ;; offset=0x2941
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG370
 
G_M000_IG308:                ;; offset=0x2951
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG309
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG310
 
G_M000_IG309:                ;; offset=0x2979
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B38623F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG310:                ;; offset=0x2998
       test     edi, edi
       jne      G_M000_IG62
 
G_M000_IG311:                ;; offset=0x29A0
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       mov      r15, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x318]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x7C], 4
       jmp      G_M000_IG378
 
G_M000_IG312:                ;; offset=0x29CB
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG370
 
G_M000_IG313:                ;; offset=0x29E0
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG370
 
G_M000_IG314:                ;; offset=0x29F0
       mov      rdx, r15
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG315
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG316
 
G_M000_IG315:                ;; offset=0x2A18
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3862400
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG316:                ;; offset=0x2A37
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG317:                ;; offset=0x2A45
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG318:                ;; offset=0x2A4E
       mov      r14, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG319:                ;; offset=0x2A59
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG370
 
G_M000_IG320:                ;; offset=0x2A6E
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG370
 
G_M000_IG321:                ;; offset=0x2A7E
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG322
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG323
 
G_M000_IG322:                ;; offset=0x2AA6
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862410
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG323:                ;; offset=0x2AC5
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG324:                ;; offset=0x2AD2
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG325
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG326
 
G_M000_IG325:                ;; offset=0x2AFA
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862418
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG326:                ;; offset=0x2B19
       test     r15d, r15d
       jne      G_M000_IG267
       jmp      G_M000_IG311
 
G_M000_IG327:                ;; offset=0x2B27
       mov      rcx, r13
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG258
 
G_M000_IG328:                ;; offset=0x2B37
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x2B5F
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862428
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG330:                ;; offset=0x2B7E
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG331:                ;; offset=0x2B8B
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG332
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG333
 
G_M000_IG332:                ;; offset=0x2BB3
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862430
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG333:                ;; offset=0x2BD2
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG334:                ;; offset=0x2BDF
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG335
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG336
 
G_M000_IG335:                ;; offset=0x2C07
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862438
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG336:                ;; offset=0x2C26
       test     r13d, r13d
       jne      G_M000_IG224
       jmp      G_M000_IG311
 
G_M000_IG337:                ;; offset=0x2C34
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG338
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG339
 
G_M000_IG338:                ;; offset=0x2C5C
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862440
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG339:                ;; offset=0x2C7B
       test     r15d, r15d
       jne      G_M000_IG224
       jmp      G_M000_IG311
 
G_M000_IG340:                ;; offset=0x2C89
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG341
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG342
 
G_M000_IG341:                ;; offset=0x2CB1
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862448
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG342:                ;; offset=0x2CD0
       test     r13d, r13d
       jne      G_M000_IG224
       jmp      G_M000_IG311
 
G_M000_IG343:                ;; offset=0x2CDE
       mov      rcx, bword ptr [rbp-0x318]
       mov      rdx, 0x2253F3C2E60
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG344:                ;; offset=0x2CFE
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG345:                ;; offset=0x2D04
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4017088
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG346
       mov      edx, dword ptr [rax+0x34]
       and      edx, 0x1600000
       cmp      edx, 0x1000000
       sete     r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2D34
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862450
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG347:                ;; offset=0x2D58
       test     r13d, r13d
       je       G_M000_IG137
       jmp      G_M000_IG130
 
G_M000_IG348:                ;; offset=0x2D66
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4017088
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       je       SHORT G_M000_IG351
       mov      ecx, dword ptr [r13+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x2D92
       mov      rcx, r13
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG350:                ;; offset=0x2D9D
       mov      r13, gword ptr [r13+0x38]
       jmp      G_M000_IG132
 
G_M000_IG351:                ;; offset=0x2DA6
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862458
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r13, rax
       jmp      G_M000_IG132
 
G_M000_IG352:                ;; offset=0x2DC7
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG370
 
G_M000_IG353:                ;; offset=0x2DDC
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG370
 
G_M000_IG354:                ;; offset=0x2DEC
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x2E14
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862468
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG356:                ;; offset=0x2E33
       test     esi, esi
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG357:                ;; offset=0x2E40
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG358
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG359
 
G_M000_IG358:                ;; offset=0x2E68
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3862470
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG359:                ;; offset=0x2E87
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG360:                ;; offset=0x2E95
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG361
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG362
 
G_M000_IG361:                ;; offset=0x2EBD
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862478
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG362:                ;; offset=0x2EDC
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG311
 
G_M000_IG363:                ;; offset=0x2EE9
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4021080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG364
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG365
 
G_M000_IG364:                ;; offset=0x2F11
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3862480
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG365:                ;; offset=0x2F30
       test     r15d, r15d
       jne      G_M000_IG224
       jmp      G_M000_IG311
 
G_M000_IG366:                ;; offset=0x2F3E
       mov      rdx, bword ptr [rbp-0xC8]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xC0]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG367
       vmovups  ymm0, ymmword ptr [reloc @RWD296]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD328]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0xD0]
       add      ecx, 27
       mov      dword ptr [rbp-0xD0], ecx
       jmp      SHORT G_M000_IG368
 
G_M000_IG367:                ;; offset=0x2F8F
       lea      rcx, [rbp-0xE0]
       mov      rdx, 0x2253F3C4060
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG368:                ;; offset=0x2FA6
       mov      rdx, bword ptr [rbp-0x318]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0xE0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9B3A894A8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp-0xE0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG369:                ;; offset=0x2FF1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG370:                ;; offset=0x2FF7
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG371
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG375
 
G_M000_IG371:                ;; offset=0x3008
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG372
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG372:                ;; offset=0x3016
       mov      rbx, bword ptr [rbp+0x30]
       mov      r14, bword ptr [rbp+0x10]
       mov      r12, gword ptr [rbp+0x20]
       mov      ecx, dword ptr [r14+0x10]
       mov      r9, gword ptr [rbp-0x310]
       mov      esi, dword ptr [r9+0x08]
       cmp      ecx, esi
       mov      rcx, r14
       mov      r10, r9
       mov      rdx, gword ptr [rbp+0x18]
       jl       G_M000_IG05
 
G_M000_IG373:                ;; offset=0x3043
       mov      eax, 1
 
G_M000_IG374:                ;; offset=0x3048
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG375:                ;; offset=0x305F
       xor      rax, rax
       mov      rbx, bword ptr [rbp+0x30]
       mov      gword ptr [rbx], rax
       mov      word  ptr [rbx+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rbx+0x0A], al
       mov      byte  ptr [rbx+0x0B], 1
       mov      eax, 5
 
G_M000_IG376:                ;; offset=0x307E
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG377:                ;; offset=0x3095
       mov      r9, bword ptr [rbp-0x318]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, r15
       mov      r8, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG380
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG370
 
G_M000_IG378:                ;; offset=0x30BE
       mov      eax, dword ptr [rbp-0x7C]
 
G_M000_IG379:                ;; offset=0x30C1
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG380:                ;; offset=0x30D8
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG381:                ;; offset=0x30E1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG382:                ;; offset=0x30E7
       sub      rsp, 88
 
G_M000_IG383:                ;; offset=0x30EB
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG384
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG384:                ;; offset=0x30FB
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG386
       mov      dword ptr [rbp-0x7C], 1
       lea      rax, G_M000_IG378
 
G_M000_IG385:                ;; offset=0x312A
       vzeroupper 
       add      rsp, 88
       ret      
 
G_M000_IG386:                ;; offset=0x3132
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG370
 
G_M000_IG387:                ;; offset=0x3140
       vzeroupper 
       add      rsp, 88
       ret      
 
G_M000_IG388:                ;; offset=0x3148
       sub      rsp, 88
 
G_M000_IG389:                ;; offset=0x314C
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x318]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG390
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG390:                ;; offset=0x317A
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG370
 
G_M000_IG391:                ;; offset=0x3188
       vzeroupper 
       add      rsp, 88
       ret      
 
RWD00  	dd	0000084Eh ; case G_M000_IG61
       	dd	00000746h ; case G_M000_IG54
       	dd	00000612h ; case G_M000_IG46
       	dd	000004C1h ; case G_M000_IG37
       	dd	000003B7h ; case G_M000_IG30
       	dd	0000028Fh ; case G_M000_IG23
       	dd	000001BAh ; case G_M000_IG17
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	00000E63h ; case G_M000_IG107
       	dd	00000E63h ; case G_M000_IG107
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	00002762h ; case G_M000_IG298
       	dd	00002762h ; case G_M000_IG298
       	dd	00002735h ; case G_M000_IG297
       	dd	0000270Eh ; case G_M000_IG296
       	dd	000026E2h ; case G_M000_IG295
       	dd	00002664h ; case G_M000_IG293
       	dd	000025D1h ; case G_M000_IG291
       	dd	000024DEh ; case G_M000_IG279
       	dd	0000247Eh ; case G_M000_IG277
       	dd	00002345h ; case G_M000_IG270
       	dd	00001D99h ; case G_M000_IG227
       	dd	00001D70h ; case G_M000_IG225
       	dd	00001D70h ; case G_M000_IG225
       	dd	00001D70h ; case G_M000_IG225
       	dd	00001CF0h ; case G_M000_IG221
       	dd	00001CF0h ; case G_M000_IG221
       	dd	00001CF0h ; case G_M000_IG221
       	dd	00001D70h ; case G_M000_IG225
       	dd	00001B7Eh ; case G_M000_IG208
       	dd	000019A8h ; case G_M000_IG195
       	dd	00000EB4h ; case G_M000_IG108
       	dd	00000E3Ch ; case G_M000_IG106
       	dd	00000DB8h ; case G_M000_IG103
       	dd	00000D8Fh ; case G_M000_IG101
       	dd	00000D63h ; case G_M000_IG100
       	dd	00000D63h ; case G_M000_IG100
       	dd	00000D63h ; case G_M000_IG100
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000BD5h ; case G_M000_IG88
       	dd	00000B8Dh ; case G_M000_IG87
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00002331h ; case G_M000_IG269
       	dd	00000904h ; case G_M000_IG64
       	dd	00002078h ; case G_M000_IG248
       	dd	00000CDBh ; case G_M000_IG97
       	dd	00001F4Bh ; case G_M000_IG239
       	dd	00001F4Bh ; case G_M000_IG239
       	dd	00001F4Bh ; case G_M000_IG239
       	dd	00001F4Bh ; case G_M000_IG239
       	dd	00001F4Bh ; case G_M000_IG239
       	dd	00001981h ; case G_M000_IG194
       	dd	0000187Ah ; case G_M000_IG185
       	dd	000016F5h ; case G_M000_IG165
       	dd	00001596h ; case G_M000_IG151
       	dd	00001561h ; case G_M000_IG150
       	dd	000014DDh ; case G_M000_IG147
RWD296 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD328 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 12688

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 156 single block inlinees; 43 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 192
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqu  ymmword ptr [rsp+0x90], ymm4
       vmovdqa  xmmword ptr [rsp+0xB0], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x003F
       mov      rcx, 0x205188019C8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG149
 
G_M000_IG03:                ;; offset=0x006D
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00AC
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00B8
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 72
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00C3
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00DB
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00DD
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00EF
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG64
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG64
 
G_M000_IG10:                ;; offset=0x012D
       lea      r8, [rsp+0x68]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x014A
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG12:                ;; offset=0x0155
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x017E
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG14:                ;; offset=0x0189
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01BB
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01C4
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x68]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x01EB
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x01F4
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x0227
       cmp      byte  ptr [rsp+0x68], 0
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG20:                ;; offset=0x0237
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG21:                ;; offset=0x023B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG22:                ;; offset=0x0246
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG23:                ;; offset=0x02A5
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG147
 
G_M000_IG24:                ;; offset=0x02B6
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02BA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG26:                ;; offset=0x02C5
       lea      rdx, [rsp+0x98]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x02ED
       vmovdqu  xmm0, xmmword ptr [rsp+0x98]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG28:                ;; offset=0x02FC
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG29:                ;; offset=0x0312
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG30:                ;; offset=0x0316
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG31:                ;; offset=0x0321
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rsp+0x50], rdx
       test     r13d, r13d
       jge      SHORT G_M000_IG33
       mov      edx, r13d
       not      edx
       mov      r15, gword ptr [rcx+0x30]
       cmp      dword ptr [r15+0x08], edx
       jg       SHORT G_M000_IG32
       sub      edx, dword ptr [r15+0x08]
       lea      r9, [rsp+0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0x88]
       mov      rcx, gword ptr [rsp+0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x0399
       cmp      edx, dword ptr [r15+0x08]
       jae      G_M000_IG204
       mov      ecx, edx
       mov      rcx, gword ptr [r15+8*rcx+0x10]
       lea      rdx, [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03BA
       cmp      r13d, r15d
       jae      G_M000_IG204
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG34:                ;; offset=0x03DB
       xor      r9, r9
       mov      gword ptr [rsp+0x50], r9
       test     eax, eax
       je       SHORT G_M000_IG35
       mov      rdx, qword ptr [rsp+0x88]
       lea      r9, [rsp+0x78]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG48
 
G_M000_IG35:                ;; offset=0x0411
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG36:                ;; offset=0x0415
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG37:                ;; offset=0x0420
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG38:                ;; offset=0x0450
       mov      rcx, 0x7FF9B3DCDC88
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG39:                ;; offset=0x0464
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG40
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B3863C28
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0486
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x0490
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG42:                ;; offset=0x0499
       mov      rcx, 0x7FF9B3D74CD8
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x04AC
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG44
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG44
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG204
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x70]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG47
 
G_M000_IG44:                ;; offset=0x0516
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG45
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B3863C30
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0538
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG46:                ;; offset=0x0542
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG47:                ;; offset=0x0578
       mov      r8, gword ptr [rsp+0x70]
       mov      gword ptr [rsp+0x30], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG48:                ;; offset=0x05A0
       vmovdqu  xmm0, xmmword ptr [rsp+0x78]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG49:                ;; offset=0x05AC
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG50:                ;; offset=0x05C2
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG51:                ;; offset=0x05DB
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0616
       mov      rdx, 0x7FF9B40CEAB0
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0625
       lea      rdx, [rsp+0x58]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG54:                ;; offset=0x0632
       test     rcx, rcx
       je       SHORT G_M000_IG57
 
G_M000_IG55:                ;; offset=0x0637
       mov      rdx, 0x7FF9B40CED18
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0646
       lea      rdx, [rsp+0x58]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG57:                ;; offset=0x0653
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x065B
       mov      rax, 0x7FF9B4015088
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG200
 
G_M000_IG59:                ;; offset=0x066F
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x58]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG60:                ;; offset=0x068A
       cmp      gword ptr [rsp+0x58], 0
       je       SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x0692
       vmovdqu  xmm0, xmmword ptr [rsp+0x58]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG62:                ;; offset=0x069E
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG63:                ;; offset=0x06B4
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG64:                ;; offset=0x06C0
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG148
 
G_M000_IG65:                ;; offset=0x06D1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG66:                ;; offset=0x06D5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG67:                ;; offset=0x06E0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG72
 
G_M000_IG68:                ;; offset=0x070E
       mov      r8, 0x7FF9B40CEAB0
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x071E
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG70:                ;; offset=0x0741
       mov      rcx, 0x7FF9B40A55F0
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0751
       mov      rcx, 0x7FF9B40CED18
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x30], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG72:                ;; offset=0x0792
       test     rbp, rbp
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0797
       mov      rdx, 0x7FF9B401B858
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x07A7
       mov      rdx, rbp
       mov      rcx, 0x7FF9B3F98490
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG76
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG75:                ;; offset=0x07C7
       mov      r8, 0x7FF9B3F6F728
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B3D74CD8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B3DCDC88
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B4061200
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG76:                ;; offset=0x080B
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG77:                ;; offset=0x083E
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x0857
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG162
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG79
       mov      rcx, 0x20518801AB0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0887
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG203
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x40], rcx
       mov      dword ptr [rsp+0x48], eax
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG80:                ;; offset=0x08D5
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG81:                ;; offset=0x0904
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG203
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x40], rcx
       mov      dword ptr [rsp+0x48], eax
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG82:                ;; offset=0x0981
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG83:                ;; offset=0x0985
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG84:                ;; offset=0x0990
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG85
       not      edx
 
G_M000_IG85:                ;; offset=0x09BB
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG147
 
G_M000_IG86:                ;; offset=0x09C9
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG91
 
G_M000_IG87:                ;; offset=0x09D0
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x09E0
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG89
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x09EF
       mov      r14d, ebp
 
G_M000_IG90:                ;; offset=0x09F2
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x09F4
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG92:                ;; offset=0x09F8
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG93
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A0A
       mov      r15d, ebp
 
G_M000_IG94:                ;; offset=0x0A0D
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG95:                ;; offset=0x0A11
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG96:                ;; offset=0x0A1C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG97
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG97:                ;; offset=0x0A53
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG147
 
G_M000_IG98:                ;; offset=0x0A85
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG99
       cmp      edx, 26
       jne      G_M000_IG202
 
G_M000_IG99:                ;; offset=0x0A99
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG100
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG100:                ;; offset=0x0AD0
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG104
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG103
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG101:                ;; offset=0x0B01
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG102:                ;; offset=0x0B0C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG103:                ;; offset=0x0B2A
       jmp      SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0B2C
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG105:                ;; offset=0x0B30
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG106:                ;; offset=0x0B3B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG107:                ;; offset=0x0B5F
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG108
       not      edx
 
G_M000_IG108:                ;; offset=0x0B8A
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], r14
       mov      qword ptr [rsp+0x38], r15
       lea      rdx, [rsp+0x30]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG109:                ;; offset=0x0BB0
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG147
 
G_M000_IG110:                ;; offset=0x0BC1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG111:                ;; offset=0x0BC5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG112:                ;; offset=0x0BD0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG204
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       je       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0C1D
       mov      r8, 0x7FF9B401ADE8
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0C2D
       lea      r8, [rsp+0x90]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG115
       mov      r15, gword ptr [rsp+0x90]
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0C4F
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
 
G_M000_IG116:                ;; offset=0x0C5E
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG120
 
G_M000_IG117:                ;; offset=0x0C71
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG120
 
G_M000_IG118:                ;; offset=0x0C81
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG119
       not      r14d
 
G_M000_IG119:                ;; offset=0x0C8D
       jmp      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0C8F
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG121:                ;; offset=0x0C93
       cmp      ecx, 51
       ja       SHORT G_M000_IG126
 
G_M000_IG122:                ;; offset=0x0C98
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG126
 
G_M000_IG123:                ;; offset=0x0CA8
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG124
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0CB7
       mov      r13d, ecx
 
G_M000_IG125:                ;; offset=0x0CBA
       jmp      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0CBC
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG127:                ;; offset=0x0CC0
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG128
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG128:                ;; offset=0x0CD5
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG132
 
G_M000_IG129:                ;; offset=0x0D0A
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG132
 
G_M000_IG130:                ;; offset=0x0D1A
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG131
       not      ebp
 
G_M000_IG131:                ;; offset=0x0D23
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D25
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG133:                ;; offset=0x0D28
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG134
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0D37
       mov      edi, ecx
 
G_M000_IG135:                ;; offset=0x0D39
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG136
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG136:                ;; offset=0x0D49
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG147
 
G_M000_IG137:                ;; offset=0x0D78
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG138:                ;; offset=0x0D91
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG139:                ;; offset=0x0DAA
       mov      rbp, gword ptr [rbx+0x08]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG140:                ;; offset=0x0DEC
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG142
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG141
       cmp      edx, 26
       jne      G_M000_IG202
 
G_M000_IG141:                ;; offset=0x0E24
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xB8], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xB8]
       mov      gword ptr [rsp+0x30], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG142:                ;; offset=0x0E77
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG147
 
G_M000_IG143:                ;; offset=0x0E80
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG144:                ;; offset=0x0E90
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG145:                ;; offset=0x0E9B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x0ED9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rcx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG147:                ;; offset=0x0F1E
       inc      dword ptr [rbx+0x38]
 
G_M000_IG148:                ;; offset=0x0F21
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG149:                ;; offset=0x0F34
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG150:                ;; offset=0x0F4B
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG151:                ;; offset=0x0F5D
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG161
 
G_M000_IG152:                ;; offset=0x0F80
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG156
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      rbp, gword ptr [rdx]
       mov      r14, qword ptr [rdx+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG155
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG153:                ;; offset=0x0FCF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG154:                ;; offset=0x0FDA
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG155:                ;; offset=0x0FF8
       jmp      SHORT G_M000_IG159
 
G_M000_IG156:                ;; offset=0x0FFA
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG157:                ;; offset=0x0FFE
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG158:                ;; offset=0x1009
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG159:                ;; offset=0x102D
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG161
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG160:                ;; offset=0x1064
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG161:                ;; offset=0x1068
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG162:                ;; offset=0x107B
       mov      eax, 1
 
G_M000_IG163:                ;; offset=0x1080
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG164:                ;; offset=0x1092
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG203
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x40], rdx
       mov      dword ptr [rsp+0x48], r8d
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG147
 
G_M000_IG165:                ;; offset=0x10E1
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG147
       jmp      G_M000_IG201
 
G_M000_IG166:                ;; offset=0x1111
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG170
 
G_M000_IG167:                ;; offset=0x111A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG170
 
G_M000_IG168:                ;; offset=0x112A
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG169
       not      ebp
 
G_M000_IG169:                ;; offset=0x1133
       jmp      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x1135
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG171:                ;; offset=0x1138
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG172:                ;; offset=0x114A
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xA8], xmm0
 
G_M000_IG173:                ;; offset=0x1158
       cmp      gword ptr [rsp+0xA8], 0
       jne      SHORT G_M000_IG174
       lea      rcx, [rsp+0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40155B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG174:                ;; offset=0x1184
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG178
 
G_M000_IG175:                ;; offset=0x1190
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x11A0
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG177
       not      edx
 
G_M000_IG177:                ;; offset=0x11A9
       jmp      SHORT G_M000_IG179
 
G_M000_IG178:                ;; offset=0x11AB
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG179:                ;; offset=0x11AE
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG180
       not      edx
 
G_M000_IG180:                ;; offset=0x11D4
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xA8]
       mov      r9, qword ptr [rsp+0xB0]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG204
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x30], rdx
       mov      qword ptr [rsp+0x38], r9
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG147
 
G_M000_IG181:                ;; offset=0x1237
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rcx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x1260
       mov      rax, 0x7FF9B3D8FE90
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG199
 
G_M000_IG183:                ;; offset=0x1273
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG187
 
G_M000_IG184:                ;; offset=0x1284
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG187
 
G_M000_IG185:                ;; offset=0x1294
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG186
       not      r9d
 
G_M000_IG186:                ;; offset=0x12A0
       jmp      SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x12A2
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG188:                ;; offset=0x12A6
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG189
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG190
 
G_M000_IG189:                ;; offset=0x12B5
       mov      r10d, eax
 
G_M000_IG190:                ;; offset=0x12B8
       cmp      r8d, 51
       ja       SHORT G_M000_IG195
 
G_M000_IG191:                ;; offset=0x12BE
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x12CE
       test     eax, eax
       jge      SHORT G_M000_IG193
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG194
 
G_M000_IG193:                ;; offset=0x12DA
       mov      r8d, eax
 
G_M000_IG194:                ;; offset=0x12DD
       jmp      SHORT G_M000_IG196
 
G_M000_IG195:                ;; offset=0x12DF
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG196:                ;; offset=0x12E3
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG203
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x40], r8
       mov      dword ptr [rsp+0x48], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x40]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG197
       not      ecx
 
G_M000_IG197:                ;; offset=0x133B
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG147
 
G_M000_IG198:                ;; offset=0x1343
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG199:                ;; offset=0x135C
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG200:                ;; offset=0x1365
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG201:                ;; offset=0x1371
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9B3863C20
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG202:                ;; offset=0x13A9
       mov      rcx, rdi
       mov      rdx, 0x2253F3CA300
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG203:                ;; offset=0x13C5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG204:                ;; offset=0x13CC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000E9Ah ; case G_M000_IG146
       	dd	00000E41h ; case G_M000_IG143
       	dd	00000DADh ; case G_M000_IG140
       	dd	00000D6Bh ; case G_M000_IG139
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D52h ; case G_M000_IG138
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D39h ; case G_M000_IG137
       	dd	00000D39h ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B82h ; case G_M000_IG110
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B71h ; case G_M000_IG109
       	dd	00000A46h ; case G_M000_IG98
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000098Ah ; case G_M000_IG86
       	dd	00000942h ; case G_M000_IG82
       	dd	000008C5h ; case G_M000_IG81
       	dd	00000818h ; case G_M000_IG78
       	dd	000007FFh ; case G_M000_IG77
       	dd	000007FFh ; case G_M000_IG77
       	dd	000007FFh ; case G_M000_IG77
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000692h ; case G_M000_IG65
       	dd	0000059Ch ; case G_M000_IG51
       	dd	00000583h ; case G_M000_IG50
       	dd	000002D3h ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000266h ; case G_M000_IG23
       	dd	00000266h ; case G_M000_IG23
       	dd	00000277h ; case G_M000_IG24
       	dd	00000681h ; case G_M000_IG64
       	dd	000001F8h ; case G_M000_IG20
       	dd	000000EEh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F41h ; case G_M000_IG152
       	dd	00000F1Eh ; case G_M000_IG151
       	dd	00000F1Eh ; case G_M000_IG151
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000059Ch ; case G_M000_IG51
       	dd	000011F8h ; case G_M000_IG181
       	dd	000010D2h ; case G_M000_IG166
       	dd	000010A2h ; case G_M000_IG165
       	dd	00001053h ; case G_M000_IG164

; Total bytes of code 5074

