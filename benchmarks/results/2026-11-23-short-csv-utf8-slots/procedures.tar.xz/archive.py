from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
data = repo / 'benchmarks/results'
quiet = lab / 'comparison/quiet'
refined = lab / 'refined'
refined_quiet = refined / 'comparison/quiet'
typed_reader = lab / 'typed-reader'
typed_quiet = typed_reader / 'comparison/quiet'
dest = data / '2026-11-23-short-csv-utf8-slots'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
identity = read(lab / 'comparison/identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 168
later = read(refined / 'comparison/identity.json')
assert later['imageFiles']['reference'] == identity['imageFiles']['reference']
later_status = read(refined_quiet / 'terminal-status.json')
later_receipt = later_status['receipt']
assert not later_status['live'] and not later_status['fixtures'] and later_status['exitCode'] == '0'
assert all(later_receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(refined_quiet / 'observations.tar.xz') == later_receipt['archiveSHA256']
assert read(refined_quiet / 'summary.json')['timedBatches'] == 112
typed_identity = read(typed_reader / 'comparison/identity.json')
assert typed_identity['imageFiles']['reference'] == identity['imageFiles']['reference']
typed_status = read(typed_quiet / 'terminal-status.json')
typed_receipt = typed_status['receipt']
assert not typed_status['live'] and not typed_status['fixtures'] and typed_status['exitCode'] == '0'
assert all(typed_receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(typed_quiet / 'observations.tar.xz') == typed_receipt['archiveSHA256']
assert read(typed_quiet / 'summary.json')['timedBatches'] == 112
assert all(read(lab / (role + '-tape.json'))['rows'] == read(typed_reader / (role + '-tape.json'))['rows']
    for role in ('reference','candidate'))
typed_rows = read(typed_reader / 'allocation-summary-six.json')
assert all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in typed_rows)
assert all(row['allocatedBytes'][0] == row['allocatedBytes'][1] for row in typed_rows
    if row['case'].startswith('scripts.csv-meter-report.typed-'))
assert all(read(lab / (role + '-tape.json'))['rows'] == read(refined / (role + '-tape.json'))['rows']
    for role in ('reference','candidate'))
assert all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in read(refined / 'allocation-summary-six.json'))
assert read(lab / 'tape-summary.json')['callIndices'] == [33,34,35]
rows = read(lab / 'allocation-summary-six.json')
assert len(rows) == 5 and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in rows)
head = git('rev-parse', 'HEAD').decode().strip()
identity['retainedRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', 'src') else head
patch = git('diff', '--binary', identity['candidate'] + '^', identity['candidate'], '--', 'src', 'tests')
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
later['retainedRevision'] = None if git('diff', '--name-only', head, later['candidate'], '--', 'src') else head
patch = git('diff', '--binary', identity['candidate'], later['candidate'], '--', 'src')
(refined / 'comparison.patch').write_bytes(patch)
later['comparisonPatchSHA256'] = sha(patch)
typed_identity['retainedRevision'] = None if git('diff', '--name-only', head, typed_identity['candidate'], '--', 'src') else head
assert typed_identity['retainedRevision']
patch = git('diff', '--binary', later['candidate'], typed_identity['candidate'], '--', 'src')
(typed_reader / 'comparison.patch').write_bytes(patch)
typed_identity['comparisonPatchSHA256'] = sha(patch)
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == checksum for name, checksum in files.items())
    core = lab / role / 'Lokad.Lython.dll'
    stored = dest / 'candidate-core.dll.gz' if role == 'candidate' else data / '2026-11-23-parallel-assignment-operands/refined-core.dll.gz'
    if role == 'candidate':
        stored.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(stored.read_bytes())) == files[core.name]
for role, files in later['imageFiles'].items():
    assert len(files) == 32 and all(digest(refined / role / name) == checksum for name, checksum in files.items())
refined_core = (refined / 'candidate/Lokad.Lython.dll').read_bytes()
assert sha(refined_core) == later['imageFiles']['candidate']['Lokad.Lython.dll']
(dest / 'refined-core.dll.gz').write_bytes(gzip.compress(refined_core,mtime=0))
for role, files in typed_identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(typed_reader / role / name) == checksum for name, checksum in files.items())
typed_core = (typed_reader / 'candidate/Lokad.Lython.dll').read_bytes()
assert sha(typed_core) == typed_identity['imageFiles']['candidate']['Lokad.Lython.dll']
(dest / 'typed-reader-core.dll.gz').write_bytes(gzip.compress(typed_core,mtime=0))
(dest / 'typed-reader-identity.json').write_text(json.dumps(typed_identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(dest / 'typed-reader-allocation.json').write_text(json.dumps(typed_rows,indent=2)+'\n',encoding='utf-8',newline='\n')
(dest / 'refined-identity.json').write_text(json.dumps(later,indent=2)+'\n',encoding='utf-8',newline='\n')
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
    shutil.copyfile(refined_quiet / name, dest / ('refined-' + name))
    shutil.copyfile(typed_quiet / name, dest / ('typed-reader-' + name))
for name in ('allocation-summary-six.json','tape-summary.json','dispatch-code-sizes.json'):
    shutil.copyfile(lab / name, dest / name)
profile = lab / 'allocation-attribution'
sample = read(profile / 'run-summary.json')
assert sample['allProcessesJoined'] and sample['totalVerifiedBatches'] == 34 and sample['sourceRevision'] == identity['candidate']
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('archive.py','prepare.py','stage.py','quiet.py','comparison.patch','summarize.py','allocations.py','allocations.log',
        'reference-allocation-six.json','candidate-allocation-six.json','windows-frozen.log','windows-public.log',
        'windows-platform-public.log','windows-white.log','windows-short-fields.log','ubuntu-public.log',
        'ubuntu-white.log','test-ubuntu.sh','short-field-probe.json','prepare-first.log','prepare.log','stage.log',
        'launch.log','retrieval.log','comparison/reference-verify.json','comparison/candidate-verify.json',
        'comparison/quiet/observe-not-before','reference-tape.json','candidate-tape.json','dispatch-jit.py',
        'dispatch-jit.log','dispatch-code-sizes.json','reference-dispatch.asm','candidate-dispatch.asm'):
        archive.add(lab / name, arcname=name)
    for name in ('prepare-refinement.py','stage.py','stage-first.log','stage.log','quiet.py','launch.log','retrieval.log',
        'summarize.py','comparison.patch','test-ubuntu.sh','windows-frozen.log','windows-public.log','windows-white.log',
        'ubuntu-public.log','ubuntu-white.log','prepare.log','allocations.py','allocations.log','allocation-summary-six.json',
        'candidate-allocation-six.json','reference-allocation-six.json','dispatch-code-sizes.json','reference-dispatch.asm',
        'candidate-dispatch.asm','reference-dispatch-allocation.json','candidate-dispatch-allocation.json',
        'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before'):
        archive.add(refined / name, arcname='refined/' + name)
    for name in ('prepare-typed-reader.py','stage.py','stage.log','quiet.py','launch.log','retrieval.log',
        'summarize.py','comparison.patch','test-ubuntu.sh','windows-frozen.log','windows-public.log','windows-white.log',
        'ubuntu-public.log','ubuntu-white.log','prepare.log','allocations.log','allocation-summary-six.json',
        'candidate-allocation-six.json','reference-allocation-six.json','reference-tape.json','candidate-tape.json',
        'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before'):
        archive.add(typed_reader / name, arcname='typed-reader/' + name)
    for name in ('profile-allocation.py','profile.log','run-summary.json','verification.json','catalog.json'):
        archive.add(profile / name, arcname='allocation-attribution/'+name)
    for case in ('explicit-float','typed-ascii'):
        capture = profile / case
        assert read(capture / 'record.json')['nettraceSha'] == digest(capture / 'warm.nettrace')
        for name in ('warm.nettrace','record.json','capture.log','sampled-allocation.json','worker.stderr'):
            archive.add(capture / name, arcname=f'allocation-attribution/{case}/{name}')
print(dest, typed_identity['retainedRevision'])

