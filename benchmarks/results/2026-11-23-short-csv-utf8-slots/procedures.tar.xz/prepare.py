from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'parallel-assignment-operands-20261123/prepare.py'
source = template.read_text(encoding='utf-8')
start = source.index("explicit = 'scripts.csv-meter-report.explicit-float'")
stop = source.index("protocol = repo /", start)
source = source[:start] + """explicit = 'scripts.csv-meter-report.explicit-float'
typed = 'scripts.csv-meter-report.typed-ascii'
unicode = 'scripts.csv-meter-report.typed-unicode'
quoted = 'scripts.csv-invoice.method-policy.quoted-control'
short = 'diagnostic.text-summary.nonlocal-computed-width.large'
controls = (typed, unicode, quoted, short)
cases = set(controls) | {explicit}
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in cases]
assert {row['id'] for row in catalog['cases']} == cases
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', dict(warm=[[explicit, 'warm'], [explicit, 'compile-run'],
    *[[case, 'warm'] for case in controls]]))

""" + source[stop:]
start = source.index("assert all(tapes['reference'][control]")
stop = source.index("write(comparison / 'identity.json'", start)
source = source[:start] + """assert all(tapes['reference'][control] == tapes['candidate'][control] for control in controls)
old = tapes['reference'][explicit][0]['tape']
new = tapes['candidate'][explicit][0]['tape']
opcodes = (tree / 'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
enum = re.search(r'enum ExecutableOpCode\\s*\\{([^{}]+)\\}', opcodes).group(1)
names = re.findall(r'^\\s*(\\w+),\\s*$', enum, flags=re.M)
is_call = lambda item: names[item['<OpCode>k__BackingField']] == 'Call'
def forwarded(tape):
    return [i for i, item in enumerate(tape) if is_call(item) and item['_inputStart'] < 0]
assert len(old) == len(new) + 6
assert not forwarded(old)
assert len(forwarded(new)) == 3
write(lab / 'tape-summary.json', dict(referenceInstructions=len(old), candidateInstructions=len(new),
    callIndices=forwarded(new), unchangedControlCodeCount={case:len(tapes['reference'][case]) for case in controls}))
""" + source[stop:]
for old, new in (
    ("parallel-assignment-operands-20261123'", "csv-short-utf8-20261123'"),
    ("donor = lab.parent / 'direct-closed-defaults-20261123'", "donor = lab.parent / 'parallel-assignment-operands-20261123/refinement'"),
    ("benchmarks/results/2026-11-23-direct-closed-defaults/", "benchmarks/results/2026-11-23-parallel-assignment-operands/"),
    ("base = json.loads(pushed('identity.json'))", "base = json.loads(pushed('refined-identity.json'))"),
    ("pushed('terminal-status.json')", "pushed('refined-terminal-status.json')"),
    ("pushed('observations.tar.xz')", "pushed('refined-observations.tar.xz')"),
    ("verified['caseCount'] == 4", "verified['caseCount'] == 5"),
    ("B1517 exact-width tuple display parallel assignment", "B1520 short UTF-8 CSV slot materialization"),
):
    assert old in source, old
    source = source.replace(old, new)
# Keep the correct allocation/transport tooling templates; only the selected
# source image is the refinement.
start = source.index("adapt(donor / 'stage.py'")
source = source[:start] + """collector = lab.parent / 'parallel-assignment-operands-20261123'
adapt(collector / 'stage.py', lab / 'stage.py', [
    ('parallel-assignment-b1517-20261123', 'csv-short-utf8-b1520-20261123'),
    ('direct-closed-defaults-b1515-20261123','parallel-assignment-refined-b1517-20261123'),
    ('lython-b1517-fixtures','lython-b1520-fixtures'),
    ('len(jobs) == 5','len(jobs) == 6'),
    ('< 265,','< 320,')])
adapt(collector / 'quiet.py', lab / 'quiet.py', [
    ('lython-b1517-parallel-assignment-20261123','lython-b1520-short-csv-utf8-20261123'),
    ('.+b1517-','.+b1520-'), ('lython-b1517-stage-', 'lython-b1520-stage-'),
    ('# Five bounded lanes write under 1 MiB of receipts. A 98 MiB',
     '# Six bounded lanes write under 1 MiB of receipts. An 81 MiB'),
    ('98 * 1024 * 1024','81 * 1024 * 1024'), ('2 * 1024 * 1024', '1536 * 1024'),
    ('RuntimeMaxSec=315','RuntimeMaxSec=380'), ('seconds=247','seconds=298')])
adapt(collector / 'summarize.py', lab / 'summarize.py', [
    ('== 5\\nassert hashlib','== 6\\nassert hashlib'),
    ('len(warm["jobs"])==5','len(warm["jobs"])==6'),
    ('timedBatches=140','timedBatches=168')])
shutil.copyfile(collector / 'allocations.py', lab / 'allocations.py')
"""
exec(compile(source, str(template), 'exec'))

