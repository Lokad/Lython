from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'prepare.py'
source = template.read_text(encoding='utf-8')
for before,after in (
    ("template = lab.parent / 'parallel-assignment-operands-20261123/prepare.py'",
     "template = lab.parents[1] / 'parallel-assignment-operands-20261123/prepare.py'"),
    ("    *[[case, 'warm'] for case in controls]", "    [short, 'warm'], [unicode, 'warm']"),
    ("collector = lab.parent / 'parallel-assignment-operands-20261123'",
     "collector = lab.parents[1] / 'parallel-assignment-operands-20261123'"),
    ("'csv-short-utf8-b1520-20261123'", "'csv-short-utf8-refined-b1520-20261123'"),
    ("'lython-b1520-fixtures'", "'lython-b1520-refined-fixtures'"),
    ("'lython-b1520-short-csv-utf8-20261123'", "'lython-b1520-short-csv-utf8-refined-20261123'"),
    ("'.+b1520-'", "'.+b1520-refined-'"),
    ("'lython-b1520-stage-'", "'lython-b1520-refined-stage-'"),
    ("'len(jobs) == 6'", "'len(jobs) == 4'"),
    ("'< 320,'", "'< 220,'"),
    ("Six bounded lanes write under 1 MiB of receipts. An 81 MiB", "Four bounded lanes write under 1 MiB of receipts. A 75 MiB"),
    ("'81 * 1024 * 1024'", "'75 * 1024 * 1024'"),
    ("'RuntimeMaxSec=380'", "'RuntimeMaxSec=265'"),
    ("'seconds=298'", "'seconds=199'"),
    ("'== 6\\\\nassert hashlib'", "'== 4\\\\nassert hashlib'"),
    ("'len(warm[\"jobs\"])==6'", "'len(warm[\"jobs\"])==4'"),
    ("'timedBatches=168'", "'timedBatches=112'"),
):
    assert before in source, before
    source = source.replace(before,after)
before = "exec(compile(source, str(template), 'exec'))"
assert source.count(before)==1
source = source.replace(before, """for before,after in (
    ('repo = lab.parents[3]', 'repo = lab.parents[4]'),
    ("donor = lab.parent / 'parallel-assignment-operands-20261123/refinement'",
     "donor = lab.parents[1] / 'parallel-assignment-operands-20261123/refinement'"),
    ("catalog = read(lab.parent / 'csv-batched-markers-20261123", "catalog = read(lab.parents[1] / 'csv-batched-markers-20261123"),
    ("inspector = lab.parent / 'adjacent-integer-results-20261123", "inspector = lab.parents[1] / 'adjacent-integer-results-20261123"),
    ("reference, candidate + '^', '--', 'src')", "reference, 'bbc554798^', '--', 'src')"),
):
    assert before in source, before
    source = source.replace(before,after)
exec(compile(source, str(template), 'exec'))""")
exec(compile(source, str(template), 'exec'))

