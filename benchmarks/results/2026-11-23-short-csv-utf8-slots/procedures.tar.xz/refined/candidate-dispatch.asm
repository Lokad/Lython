; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FF9B3D205A8
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9B3BA5BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FF9B3892230
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FF9B3892238
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B3892248
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FF9B3D1D138
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x204473E3668
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FF9B3892240
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9B3892248
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 28 inlinees with PGO data; 289 single block inlinees; 66 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 936
       lea      rbp, [rsp+0x3E0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -720
 
G_M000_IG357:                ;; offset=0x0029
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG357
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rbx, bword ptr [rbp+0x30]
       mov      r8, bword ptr [rbp+0x38]
       mov      rax, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x005D
       xor      r10d, r10d
       mov      qword ptr [rbx], r10
       mov      qword ptr [rbx+0x08], r10
 
G_M000_IG03:                ;; offset=0x0067
       mov      gword ptr [r8], r10
 
G_M000_IG04:                ;; offset=0x006A
       mov      qword ptr [rax], r10
       mov      qword ptr [rax+0x08], r10
       mov      qword ptr [rax+0x10], r10
       mov      r10, gword ptr [rcx]
       mov      r10, gword ptr [r10+0x98]
       mov      gword ptr [rbp-0x318], r10
       mov      esi, dword ptr [r10+0x08]
       cmp      dword ptr [rcx+0x10], esi
       jge      G_M000_IG338
 
G_M000_IG05:                ;; offset=0x0093
       xor      r9d, r9d
       mov      dword ptr [rbp-0x3C], r9d
       mov      r9d, dword ptr [rcx+0x10]
       cmp      r9d, esi
       jae      G_M000_IG346
       shl      r9, 5
       lea      r9, bword ptr [r10+r9+0x10]
       mov      bword ptr [rbp-0x320], r9
       mov      rdi, gword ptr [rdx+0xA0]
       mov      r9, bword ptr [rbp-0x320]
       mov      r14, gword ptr [r9]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00D8
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG07:                ;; offset=0x00E5
       mov      rcx, bword ptr [rbp-0x320]
       mov      edi, dword ptr [rcx+0x1C]
       cmp      edi, 73
       ja       G_M000_IG268
 
G_M000_IG08:                ;; offset=0x00F8
       mov      ecx, edi
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0110
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG12
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG10:                ;; offset=0x0132
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG11:                ;; offset=0x013F
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x228]
       mov      rcx, r15
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x238]
       lea      rdx, [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x230]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG274
 
G_M000_IG12:                ;; offset=0x019E
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG13:                ;; offset=0x01A5
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG14:                ;; offset=0x01B2
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0xA0]
       mov      rcx, r15
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdi, gword ptr [rbp-0xA0]
       movsx    rsi, word  ptr [rbp-0x98]
       test     rdi, rdi
       je       G_M000_IG335
 
G_M000_IG15:                ;; offset=0x01E4
       mov      rdx, rdi
       mov      rcx, 0x7FF9B3C8F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG272
 
G_M000_IG16:                ;; offset=0x01FF
       mov      rcx, rdi
       mov      edx, esi
       mov      r11, 0x7FF9B38923E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG335
 
G_M000_IG17:                ;; offset=0x0216
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0x68]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0257
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG19:                ;; offset=0x0264
       lea      rdx, [rbp-0x310]
       lea      rcx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x240]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG287
 
G_M000_IG20:                ;; offset=0x02A6
       mov      rdi, gword ptr [rbp-0x68]
       movsx    rsi, word  ptr [rbp-0x60]
       test     rdi, rdi
       je       G_M000_IG335
 
G_M000_IG21:                ;; offset=0x02B8
       mov      rdx, rdi
       mov      rcx, 0x7FF9B3C8F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG285
 
G_M000_IG22:                ;; offset=0x02D3
       mov      rcx, rdi
       mov      edx, esi
       mov      r11, 0x7FF9B3892408
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG335
 
G_M000_IG23:                ;; offset=0x02EA
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      r8, r15
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG24
       mov      gword ptr [rbp-0x2E0], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG24:                ;; offset=0x037E
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0398
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03A8
       mov      r8d, edi
       mov      dword ptr [rbp-0x2B4], r8d
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03B4
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2B4], r8d
 
G_M000_IG28:                ;; offset=0x03C6
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG29
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x358]
 
G_M000_IG29:                ;; offset=0x03DD
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2B4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x378], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x378]
       mov      qword ptr [rsi+0x08], rcx
       mov      rsi, bword ptr [rbp-0x358]
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG335
 
G_M000_IG30:                ;; offset=0x042B
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp-0x320]
       mov      r8, gword ptr [r8]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x2E0], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG31:                ;; offset=0x04A1
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x350], rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x04BB
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x04CB
       mov      r8d, edi
       mov      dword ptr [rbp-0x2B0], r8d
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x04D7
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2B0], r8d
 
G_M000_IG35:                ;; offset=0x04E9
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG36
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x350]
 
G_M000_IG36:                ;; offset=0x0500
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2B0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x380], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x380]
       mov      qword ptr [rsi+0x08], rcx
       mov      rsi, bword ptr [rbp-0x350]
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG335
 
G_M000_IG37:                ;; offset=0x054E
       mov      r15, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG38
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r13
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x18]
       mov      r8d, dword ptr [r14+0x10]
       mov      r9d, dword ptr [r14+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG45
 
G_M000_IG38:                ;; offset=0x0583
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       mov      rsi, gword ptr [rbp-0x48]
       mov      r9, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG39
       mov      gword ptr [rbp-0x2E0], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG39:                ;; offset=0x0601
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x061B
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x062B
       mov      r8d, edi
       mov      dword ptr [rbp-0x278], r8d
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0637
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x278], r8d
 
G_M000_IG43:                ;; offset=0x0649
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG44
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x340]
 
G_M000_IG44:                ;; offset=0x0660
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x278]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x388], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rsi, bword ptr [rbp-0x388]
       mov      qword ptr [rsi+0x08], rcx
       mov      rsi, bword ptr [rbp-0x340]
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG335
 
G_M000_IG45:                ;; offset=0x06AE
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG335
 
G_M000_IG46:                ;; offset=0x06B8
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x24C], eax
       mov      rcx, bword ptr [rbp-0x320]
       mov      r8, gword ptr [rcx]
       mov      gword ptr [rbp-0x330], r8
       mov      rcx, rdi
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG47
       mov      rcx, rsi
       mov      edx, dword ptr [rbp-0x24C]
       mov      r8, gword ptr [rbp-0x330]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
 
G_M000_IG47:                ;; offset=0x071E
       mov      r9, bword ptr [rbp-0x320]
       mov      esi, dword ptr [r9+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG48
       mov      gword ptr [rbp-0x2E0], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG48:                ;; offset=0x075D
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x338], rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x0777
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x0787
       mov      r8d, esi
       mov      dword ptr [rbp-0x274], r8d
       jmp      SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0793
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x274], r8d
 
G_M000_IG52:                ;; offset=0x07A5
       cmp      esi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG53
       mov      rcx, rax
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x338]
 
G_M000_IG53:                ;; offset=0x07BC
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x274]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x390], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x390]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x338]
       mov      dword ptr [rdi+0x40], esi
       jmp      G_M000_IG335
 
G_M000_IG54:                ;; offset=0x080A
       mov      r15, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x30]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x320]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG55
       mov      gword ptr [rbp-0x2E0], rsi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG55:                ;; offset=0x087E
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x348], rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x0898
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x08A8
       mov      r8d, edi
       mov      dword ptr [rbp-0x2AC], r8d
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x08B4
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2AC], r8d
 
G_M000_IG59:                ;; offset=0x08C6
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG60
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x348]
 
G_M000_IG60:                ;; offset=0x08DD
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2AC]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x398], rcx
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      rsi, bword ptr [rbp-0x398]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, bword ptr [rbp-0x348]
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG335
 
G_M000_IG61:                ;; offset=0x092B
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rdx+0xA8]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B38923E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG63
       lea      rcx, [rbp-0x260]
       mov      rdx, rax
       mov      r8, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x270]
       lea      rdx, [rbp-0x260]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x270]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x268]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       jne      G_M000_IG294
 
G_M000_IG62:                ;; offset=0x09B3
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG335
 
G_M000_IG63:                ;; offset=0x09C9
       mov      rcx, gword ptr [r14]
       mov      r8, gword ptr [r14+0x08]
       mov      rdx, rax
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG335
 
G_M000_IG64:                ;; offset=0x09E1
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG97
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [rdx+0x10]
       mov      edx, edi
       cmp      edx, 51
       ja       SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x0A06
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG69
 
G_M000_IG66:                ;; offset=0x0A16
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG67
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x0A2C
       mov      r9d, edx
 
G_M000_IG68:                ;; offset=0x0A2F
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x0A31
       mov      r9, bword ptr [rbp-0x320]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG70:                ;; offset=0x0A3C
       lea      rdx, [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      edi, dword ptr [r14+0x10]
       inc      edi
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [r15+0x70]
       cmp      byte  ptr [r15+0x109], 0
       jne      SHORT G_M000_IG71
       cmp      byte  ptr [r15+0x107], 0
       jne      SHORT G_M000_IG71
       cmp      esi, edi
       jg       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0A6F
       xor      r12d, r12d
       jmp      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0A74
       cmp      edi, esi
       jae      G_M000_IG334
       mov      r8d, edi
       shl      r8, 5
       mov      r10, gword ptr [rbp-0x318]
       cmp      dword ptr [r10+r8+0x2C], 30
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG73:                ;; offset=0x0A98
       test     r12d, r12d
       je       SHORT G_M000_IG76
       test     r13, r13
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x0AA2
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG75:                ;; offset=0x0AB2
       lea      r8, [rbp-0x2E0]
       mov      rdx, r13
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0AC9
       lea      rsi, bword ptr [r15+0x198]
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rcx
       mov      word  ptr [r15+0x100], 257
       inc      dword ptr [r14+0x10]
       test     r12d, r12d
       jne      G_M000_IG240
       test     r13, r13
       je       G_M000_IG240
       mov      rcx, r15
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG240
       jmp      G_M000_IG337
 
G_M000_IG77:                ;; offset=0x0B23
       cmp      edi, esi
       jae      G_M000_IG334
       mov      ecx, edi
       shl      rcx, 5
       mov      r10, gword ptr [rbp-0x318]
       mov      rsi, gword ptr [r10+rcx+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      r12, gword ptr [r13+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG78
       mov      rcx, r12
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG78:                ;; offset=0x0B65
       mov      rcx, gword ptr [r13+0xA0]
       mov      rdx, rcx
       mov      rax, gword ptr [r15+0x78]
       test     rax, rax
       je       SHORT G_M000_IG79
       cmp      dword ptr [rax+0x10], 0
       setg     al
       movzx    rax, al
       test     eax, eax
       je       SHORT G_M000_IG79
       mov      rax, gword ptr [rcx+0x148]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0B8F
       mov      rax, gword ptr [r15+0x80]
 
G_M000_IG80:                ;; offset=0x0B96
       lea      rcx, bword ptr [rdx+0x148]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r14+0x20]
       mov      edx, edi
       shl      rdx, 5
       mov      r10, gword ptr [rbp-0x318]
       lea      rdx, bword ptr [r10+rdx+0x10]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG81
       not      edx
 
G_M000_IG81:                ;; offset=0x0BC4
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG337
 
G_M000_IG82:                ;; offset=0x0BD4
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rbx
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r8
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG201
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG343
 
G_M000_IG83:                ;; offset=0x0C1F
       mov      rdx, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [rdx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG84
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0C43
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG85:                ;; offset=0x0C48
       mov      bword ptr [rbp-0x2D0], r9
       mov      dword ptr [rbp-0x2C8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2D0]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG86
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG97
 
G_M000_IG86:                ;; offset=0x0C92
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG91
       test     rsi, rsi
       je       SHORT G_M000_IG91
 
G_M000_IG87:                ;; offset=0x0C9D
       mov      r8, 0x7FF9B404ADE8
       cmp      qword ptr [rsi], r8
       jne      SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x0CAC
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG89:                ;; offset=0x0CB3
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG90:                ;; offset=0x0CC0
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x180]
       mov      rcx, r15
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG201
       jmp      G_M000_IG328
 
G_M000_IG91:                ;; offset=0x0D07
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG335
 
G_M000_IG92:                ;; offset=0x0D25
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG94
       mov      ecx, edi
       cmp      ecx, 58
       ja       G_M000_IG97
 
G_M000_IG93:                ;; offset=0x0D41
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jb       G_M000_IG97
 
G_M000_IG94:                ;; offset=0x0D55
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [r14+0x68], 0
       je       G_M000_IG335
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG240
       cmp      gword ptr [r14+0x40], 0
       je       G_M000_IG240
       xor      rcx, rcx
       mov      gword ptr [rbx], rcx
       mov      word  ptr [rbx+0x08], 0
       movzx    rcx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rbx+0x0A], cl
       mov      byte  ptr [rbx+0x0B], 1
       mov      dword ptr [rbp-0x8C], 5
       jmp      G_M000_IG343
 
G_M000_IG95:                ;; offset=0x0DB3
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG102
       jmp      G_M000_IG335
 
G_M000_IG96:                ;; offset=0x0DE2
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       jne      G_M000_IG197
 
G_M000_IG97:                ;; offset=0x0DF7
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x8C], 6
       jmp      G_M000_IG343
 
G_M000_IG98:                ;; offset=0x0E12
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       SHORT G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG197
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG99:                ;; offset=0x0E34
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG100:                ;; offset=0x0E41
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x190]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rdi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG325
 
G_M000_IG101:                ;; offset=0x0E9A
       mov      r13, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG335
 
G_M000_IG102:                ;; offset=0x0EC4
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rbx
       mov      rcx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r12
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG335
       mov      dword ptr [rbp-0x8C], eax
       jmp      G_M000_IG343
 
G_M000_IG103:                ;; offset=0x0F18
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rdx+0xB0]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9B38923D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [rdx+0x10]
       test     r8d, r8d
       jge      G_M000_IG120
       cmp      dword ptr [r14+0x60], edi
       jne      G_M000_IG120
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG104
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0F82
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG105:                ;; offset=0x0F87
       mov      bword ptr [rbp-0x2D0], r9
       mov      dword ptr [rbp-0x2C8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2D0]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       mov      r8, bword ptr [rbp-0x320]
       mov      eax, dword ptr [r8+0x0C]
       mov      dword ptr [rbp-0xB4], eax
       test     eax, eax
       jl       SHORT G_M000_IG110
       mov      r8, gword ptr [r14+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       shl      rcx, 4
       lea      r8, bword ptr [r8+rcx+0x10]
       mov      rcx, qword ptr [r8+0x08]
       test     rcx, rcx
       mov      eax, dword ptr [rbp-0xB4]
       jle      SHORT G_M000_IG110
       mov      r8, gword ptr [r8]
       test     r8, r8
       je       SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0FFC
       mov      rdx, 0x7FF9B3D18358
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x100B
       mov      r8d, 1
       jmp      SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x1013
       xor      r8d, r8d
 
G_M000_IG109:                ;; offset=0x1016
       test     r8d, r8d
       je       SHORT G_M000_IG110
       lea      r8, [rbp-0xC8]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, gword ptr [rsi+0x18]
       mov      rdx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeShortUtf8Float(long,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xB4]
       jne      G_M000_IG139
 
G_M000_IG110:                ;; offset=0x1045
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG111
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x105A
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG112:                ;; offset=0x105F
       mov      bword ptr [rbp-0x2D0], r9
       mov      dword ptr [rbp-0x2C8], edx
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], r13
       lea      rdx, [rbp-0x2D0]
       mov      r9d, dword ptr [r14+0x10]
       mov      r8d, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, r12
       mov      rcx, 0x7FF9B3FCF578
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG113
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0xD8]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [rsi+0x18]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x328]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG135
 
G_M000_IG113:                ;; offset=0x10EA
       mov      r15, gword ptr [rbp+0x20]
       lea      rax, bword ptr [r14+0x20]
       mov      bword ptr [rbp-0x360], rax
       lea      r8d, [rdi+0x01]
       mov      dword ptr [rbp-0x2BC], r8d
       cmp      r8d, dword ptr [rax+0x40]
       jl       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x110A
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x110C
       mov      rcx, rax
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x360]
 
G_M000_IG116:                ;; offset=0x111F
       mov      rcx, gword ptr [rax]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, edi
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x368], rcx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r12, bword ptr [rbp-0x368]
       mov      qword ptr [r12+0x08], rcx
       mov      r12, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rbp-0x2BC]
       mov      dword ptr [r12+0x40], ecx
       lea      r12, bword ptr [r14+0x20]
       lea      eax, [rdi+0x02]
       mov      dword ptr [rbp-0x2C0], eax
       cmp      eax, dword ptr [r12+0x40]
       jl       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x117C
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x117E
       mov      rcx, r12
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG119:                ;; offset=0x1189
       mov      rcx, gword ptr [r12]
       lea      edx, [rdi+0x01]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       lea      edx, [rdi+0x01]
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x370], rcx
       mov      rdx, gword ptr [rbp-0x328]
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rax, bword ptr [rbp-0x370]
       mov      qword ptr [rax+0x08], rcx
       mov      ecx, dword ptr [rbp-0x2C0]
       mov      dword ptr [r12+0x40], ecx
 
G_M000_IG120:                ;; offset=0x11D3
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [rbp+0x18]
       lea      rcx, bword ptr [r14+0x20]
       cmp      byte  ptr [rsi], sil
       mov      rcx, gword ptr [rcx]
       cmp      byte  ptr [rsi+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, edi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      dword ptr [rsp+0x20], edi
       mov      gword ptr [rsp+0x28], r12
       lea      rcx, [rbp-0x88]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, r15
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      G_M000_IG130
       test     r15, r15
       je       G_M000_IG129
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, r15
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG125
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG122
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x1B0]
       mov      rcx, r15
       mov      r8, rsi
 
G_M000_IG121:                ;; offset=0x12A2
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1C0]
       lea      rdx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r12, rbx
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1B8]
       mov      qword ptr [r12+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG319
 
G_M000_IG122:                ;; offset=0x12EE
       mov      gword ptr [rsp+0x20], r12
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0xA0]
       mov      rcx, r15
       mov      r8, rsi
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rdi, rdx
       movsx    rdx, word  ptr [rbp-0x98]
       mov      esi, edx
       test     rdi, rdi
       je       G_M000_IG335
 
G_M000_IG123:                ;; offset=0x132C
       mov      rdx, rdi
       mov      rcx, 0x7FF9B3C8F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG317
 
G_M000_IG124:                ;; offset=0x1347
       mov      rcx, rdi
       mov      edx, esi
       mov      r11, 0x7FF9B3892460
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG335
 
G_M000_IG125:                ;; offset=0x135E
       mov      rax, bword ptr [rbp+0x40]
       mov      r12, gword ptr [rax]
       test     r12, r12
       jne      G_M000_IG310
 
G_M000_IG126:                ;; offset=0x136E
       mov      rax, bword ptr [rbp+0x40]
       mov      rdi, gword ptr [rax]
       test     rdi, rdi
       jne      G_M000_IG313
 
G_M000_IG127:                ;; offset=0x137E
       mov      r12, gword ptr [rax+0x08]
 
G_M000_IG128:                ;; offset=0x1382
       cmp      r12, r15
       jne      G_M000_IG133
       xor      ecx, ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rsi, r15
       mov      rdi, r13
       jmp      G_M000_IG188
 
G_M000_IG129:                ;; offset=0x13A7
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, [rbp-0xE0]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r14
       mov      rdx, r13
       mov      r8, rsi
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG97
       cmp      gword ptr [rbp-0xE0], 0
       je       G_M000_IG335
       mov      rdx, gword ptr [rbp-0xE0]
       xor      rcx, rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      gword ptr [rax], rcx
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x40]
       mov      word  ptr [rax+0x10], 0
       mov      byte  ptr [rax+0x12], 1
       jmp      SHORT G_M000_IG133
 
G_M000_IG130:                ;; offset=0x1409
       cmp      gword ptr [rbp-0x88], 0
       je       G_M000_IG335
       mov      rdx, gword ptr [rbp-0x88]
       mov      rcx, 0x7FF9B3D19370
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG134
       mov      rdx, gword ptr [rbp-0x88]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x1444
       mov      rcx, 0x7FF9B3FB8520
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG309
 
G_M000_IG132:                ;; offset=0x1457
       xor      rcx, rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      gword ptr [r12], rcx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      word  ptr [r12+0x10], 0
       mov      byte  ptr [r12+0x12], 1
 
G_M000_IG133:                ;; offset=0x147C
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x8C], 3
       jmp      G_M000_IG343
 
G_M000_IG134:                ;; offset=0x1498
       jmp      G_M000_IG342
 
G_M000_IG135:                ;; offset=0x149D
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9B3D19370
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x14BB
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG137:                ;; offset=0x14CB
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG138:                ;; offset=0x14EA
       jmp      G_M000_IG342
 
G_M000_IG139:                ;; offset=0x14EF
       mov      r15, gword ptr [rbp+0x20]
 
G_M000_IG140:                ;; offset=0x14F3
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG141:                ;; offset=0x1503
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG142:                ;; offset=0x1522
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x10]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG143
       mov      r10d, r8d
       mov      r9d, eax
       add      r10, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r10, r9
       ja       G_M000_IG284
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       jmp      SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x1565
       or       r8d, eax
       jne      G_M000_IG284
       xor      rdx, rdx
       xor      eax, eax
 
G_M000_IG144:                ;; offset=0x1572
       mov      bword ptr [rbp-0x2D0], rdx
       mov      dword ptr [rbp-0x2C8], eax
       lea      rcx, [rbp-0x2D0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, bword ptr [rbp-0x320]
       mov      r8, gword ptr [r8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG335
 
G_M000_IG145:                ;; offset=0x15A6
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rdi+rcx+0x10], 0
       jne      G_M000_IG335
       jmp      G_M000_IG271
 
G_M000_IG146:                ;; offset=0x15DB
       mov      rcx, bword ptr [rbp+0x10]
       lea      r8, bword ptr [rcx+0x20]
       cmp      edi, 51
       ja       SHORT G_M000_IG150
 
G_M000_IG147:                ;; offset=0x15E8
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rdi
       jb       SHORT G_M000_IG150
 
G_M000_IG148:                ;; offset=0x15F8
       mov      rdx, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rdx+0x18]
       test     esi, esi
       jge      SHORT G_M000_IG149
       not      esi
 
G_M000_IG149:                ;; offset=0x1608
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x160A
       mov      rdx, bword ptr [rbp-0x320]
       mov      esi, dword ptr [rdx+0x14]
 
G_M000_IG151:                ;; offset=0x1614
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG152
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x162A
       mov      r9d, edx
 
G_M000_IG153:                ;; offset=0x162D
       lea      rdx, [rbp-0x58]
       mov      rcx, r8
       mov      r8d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG154
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x1654
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG155:                ;; offset=0x1659
       mov      rsi, gword ptr [rbp+0x20]
       mov      r9, rsi
       test     r9, r9
       jne      SHORT G_M000_IG156
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG156:                ;; offset=0x166C
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, gword ptr [r9+0xA0]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, r8d
       jae      G_M000_IG334
       mov      r8d, eax
       shl      r8, 4
       add      r8, rdx
 
G_M000_IG157:                ;; offset=0x1694
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG158:                ;; offset=0x16A1
       mov      rcx, r8
       lea      r8, [rbp-0x2E0]
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG335
 
G_M000_IG159:                ;; offset=0x16BD
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG334
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x16EE
       mov      rax, 0x7FF9B3DBFE90
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG283
 
G_M000_IG161:                ;; offset=0x1701
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x20]
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG165
 
G_M000_IG162:                ;; offset=0x171D
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG165
 
G_M000_IG163:                ;; offset=0x172D
       mov      r9, bword ptr [rbp-0x320]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG164
       not      r9d
 
G_M000_IG164:                ;; offset=0x1740
       jmp      SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x1742
       mov      r9, bword ptr [rbp-0x320]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG166:                ;; offset=0x174D
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG167
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG168
 
G_M000_IG167:                ;; offset=0x1763
       mov      r10d, eax
 
G_M000_IG168:                ;; offset=0x1766
       cmp      r8d, 51
       ja       SHORT G_M000_IG173
 
G_M000_IG169:                ;; offset=0x176C
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG173
 
G_M000_IG170:                ;; offset=0x177C
       test     eax, eax
       jge      SHORT G_M000_IG171
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x1788
       mov      r8d, eax
 
G_M000_IG172:                ;; offset=0x178B
       jmp      SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x178D
       mov      r8, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG174:                ;; offset=0x1798
       sub      r10d, r8d
       test     rdx, rdx
       je       SHORT G_M000_IG175
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG284
       mov      r9d, r9d
       shl      r9, 4
       lea      rdx, bword ptr [rdx+r9+0x10]
       jmp      SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x17C3
       or       r9d, r10d
       jne      G_M000_IG284
       xor      rdx, rdx
       xor      r10d, r10d
 
G_M000_IG176:                ;; offset=0x17D1
       mov      r8, bword ptr [rbp-0x320]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rsi, gword ptr [rbp+0x20]
       mov      r9, rsi
       test     r9, r9
       jne      SHORT G_M000_IG177
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG177:                ;; offset=0x17F8
       mov      rdi, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x2D0], rdx
       mov      dword ptr [rbp-0x2C8], r10d
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       lea      rdx, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG178
       not      ecx
 
G_M000_IG178:                ;; offset=0x183A
       mov      dword ptr [rdx+0x40], ecx
       jmp      G_M000_IG335
 
G_M000_IG179:                ;; offset=0x1842
       mov      rdi, gword ptr [rbp+0x18]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG183
       mov      r14, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [r14+0x60]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      r15d, eax
       jne      G_M000_IG183
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       shl      rax, 4
       mov      r15, gword ptr [rcx+rax+0x10]
       test     r15, r15
       je       G_M000_IG183
 
G_M000_IG180:                ;; offset=0x189A
       mov      rcx, 0x7FF9B4045088
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG183
 
G_M000_IG181:                ;; offset=0x18AD
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG183
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG183
       mov      rdx, bword ptr [rbp-0x320]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x140]
       mov      rcx, rsi
       mov      r8, rax
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG201
       jmp      G_M000_IG303
 
G_M000_IG182:                ;; offset=0x1922
       mov      rsi, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, rsi
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG188
 
G_M000_IG183:                ;; offset=0x194C
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       lea      r8, [rbp-0x70]
       lea      r9, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG187
       test     rsi, rsi
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG186
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG184:                ;; offset=0x1992
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG185:                ;; offset=0x199F
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1D0]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x1D0]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG201
       jmp      G_M000_IG306
 
G_M000_IG186:                ;; offset=0x19E4
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG335
 
G_M000_IG187:                ;; offset=0x19FC
       cmp      byte  ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG189
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [r14+0x10], eax
 
G_M000_IG188:                ;; offset=0x1A27
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG335
 
G_M000_IG189:                ;; offset=0x1A33
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG190:                ;; offset=0x1A40
       lea      r9, [rbp-0x2E0]
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG191:                ;; offset=0x1A5F
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG192
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x1A87
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG193:                ;; offset=0x1A8C
       mov      bword ptr [rbp-0x2D0], r9
       mov      dword ptr [rbp-0x2C8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp-0x2D0]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      rcx, bword ptr [rbp-0x320]
       mov      r9d, dword ptr [rcx+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG194
       not      r9d
 
G_M000_IG194:                ;; offset=0x1ADF
       mov      rcx, bword ptr [rbp-0x320]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r15
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG335
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG197
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG195:                ;; offset=0x1B1C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG196:                ;; offset=0x1B29
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x1E0]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1F0]
       lea      rdx, [rbp-0x1E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1E8]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG62
       jmp      G_M000_IG322
 
G_M000_IG197:                ;; offset=0x1B82
       mov      rsi, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG335
 
G_M000_IG198:                ;; offset=0x1B9F
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG203
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG199:                ;; offset=0x1BBD
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG200:                ;; offset=0x1BCA
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x200]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x200]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       jne      G_M000_IG300
 
G_M000_IG201:                ;; offset=0x1C0A
       mov      rsi, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG335
 
G_M000_IG202:                ;; offset=0x1C1F
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG97
 
G_M000_IG203:                ;; offset=0x1C30
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG335
 
G_M000_IG204:                ;; offset=0x1C48
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       SHORT G_M000_IG205
       mov      rcx, rsi
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG240
 
G_M000_IG205:                ;; offset=0x1C6D
       mov      r15, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [r15+0x08]
       test     r8d, r8d
       je       SHORT G_M000_IG206
       mov      rcx, r14
       mov      rdx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x1C8E
       lea      r13, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      r12d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r12d
       mov      rcx, r13
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x2E0], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG207:                ;; offset=0x1CFC
       mov      rdi, gword ptr [rbp+0x18]
 
G_M000_IG208:                ;; offset=0x1D00
       vmovdqu  xmm0, xmmword ptr [r15]
       vmovdqu  xmmword ptr [rbp-0x2D0], xmm0
 
G_M000_IG209:                ;; offset=0x1D0D
       lea      r9, [rbp-0x2D0]
       mov      rdx, rdi
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0x8C], 2
       jmp      G_M000_IG343
 
G_M000_IG210:                ;; offset=0x1D36
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbp+0x20]
       mov      r9, rsi
       test     r9, r9
       jne      SHORT G_M000_IG211
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG211:                ;; offset=0x1D4D
       mov      rcx, r14
       mov      rdx, rsi
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG335
       test     rsi, rsi
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG214
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG212:                ;; offset=0x1D7E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG213:                ;; offset=0x1D8B
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x150]
       mov      rcx, rsi
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x160]
       lea      rdx, [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rbx
       mov      rdx, gword ptr [rbp-0x160]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x158]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG62
       jmp      G_M000_IG280
 
G_M000_IG214:                ;; offset=0x1DEA
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG215:                ;; offset=0x1DF1
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG216:                ;; offset=0x1DFE
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0xA0]
       mov      rcx, rsi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r15, gword ptr [rbp-0xA0]
       movsx    r13, word  ptr [rbp-0x98]
       test     r15, r15
       je       G_M000_IG335
 
G_M000_IG217:                ;; offset=0x1E30
       mov      rdx, r15
       mov      rcx, 0x7FF9B3C8F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG278
 
G_M000_IG218:                ;; offset=0x1E4B
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9B38923F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG335
 
G_M000_IG219:                ;; offset=0x1E63
       mov      rsi, gword ptr [rbp+0x20]
       test     rsi, rsi
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG235
       cmp      gword ptr [rsi+0x68], 0
       jne      G_M000_IG227
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      r13d, dword ptr [rcx+0x10]
       mov      ecx, edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG224
 
G_M000_IG220:                ;; offset=0x1E9F
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG224
 
G_M000_IG221:                ;; offset=0x1EAF
       mov      rcx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG222
       mov      edi, edx
       not      edi
       jmp      SHORT G_M000_IG223
 
G_M000_IG222:                ;; offset=0x1EC3
       mov      edi, edx
 
G_M000_IG223:                ;; offset=0x1EC5
       jmp      SHORT G_M000_IG225
 
G_M000_IG224:                ;; offset=0x1EC7
       mov      rcx, bword ptr [rbp-0x320]
       mov      edi, dword ptr [rcx+0x14]
 
G_M000_IG225:                ;; offset=0x1ED1
       mov      rcx, gword ptr [r15]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      eax, r13d
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      rcx, gword ptr [r15]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, r13d
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG226:                ;; offset=0x1F24
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [r15+0x40], edi
       mov      rcx, 0x7FF9B3952560
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      rcx, 0x7FF9B4049160
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, bword ptr [rbp-0x320]
       mov      r13, gword ptr [rcx]
       lea      rcx, bword ptr [r15+0x08]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, 0x1E4208019C8
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [r15+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rsi+0x68]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG227:                ;; offset=0x1FCA
       mov      rcx, gword ptr [rsi+0x68]
       mov      r8, gword ptr [rsi+0x58]
       mov      r9, gword ptr [rsi+0x60]
       cmp      byte  ptr [rcx], cl
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp-0x298]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:AdvanceAsync(System.Object,Lokad.Lython.Runtime.LythonRuntimeException,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      rdi, gword ptr [rbp-0x298]
       movsx    r15, word  ptr [rbp-0x290]
       test     rdi, rdi
       je       SHORT G_M000_IG231
       mov      rdx, rdi
       mov      rcx, 0x7FF9B40564B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r13, rax
       test     r13, r13
       jne      SHORT G_M000_IG228
       lea      rdx, [rbp-0x2A8]
       mov      rcx, rdi
       mov      r8d, r15d
       mov      r11, 0x7FF9B3892420
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      SHORT G_M000_IG232
 
G_M000_IG228:                ;; offset=0x2035
       mov      ecx, dword ptr [r13+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG293
 
G_M000_IG229:                ;; offset=0x204B
       vmovdqu  xmm0, xmmword ptr [r13+0x38]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG230:                ;; offset=0x2059
       jmp      SHORT G_M000_IG232
 
G_M000_IG231:                ;; offset=0x205B
       vmovdqu  xmm0, xmmword ptr [rbp-0x288]
       vmovdqu  xmmword ptr [rbp-0x2A8], xmm0
 
G_M000_IG232:                ;; offset=0x206B
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG233:                ;; offset=0x2072
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG234:                ;; offset=0x207F
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x2A8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      SHORT G_M000_IG239
 
G_M000_IG235:                ;; offset=0x2098
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG236:                ;; offset=0x209F
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG237:                ;; offset=0x20AC
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x170]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rbx
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rbx]
       test     rdi, rdi
       jne      G_M000_IG290
 
G_M000_IG238:                ;; offset=0x20EC
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
 
G_M000_IG239:                ;; offset=0x20F5
       cmp      byte  ptr [rsi+0x101], 0
       je       G_M000_IG335
       mov      rdx, gword ptr [rsi+0x70]
       test     rdx, rdx
       je       SHORT G_M000_IG240
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       jne      G_M000_IG337
 
G_M000_IG240:                ;; offset=0x211C
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      dword ptr [rbp-0x8C], 1
       jmp      G_M000_IG343
 
G_M000_IG241:                ;; offset=0x2133
       mov      r15, gword ptr [rbp+0x20]
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, rsi
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x2E0], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG335
 
G_M000_IG242:                ;; offset=0x21A9
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG243
       not      edx
 
G_M000_IG243:                ;; offset=0x21FA
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG335
 
G_M000_IG244:                ;; offset=0x2205
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      ecx, edi
       cmp      ecx, 51
       ja       SHORT G_M000_IG249
 
G_M000_IG245:                ;; offset=0x2214
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG249
 
G_M000_IG246:                ;; offset=0x2224
       mov      rcx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG247
       mov      edi, edx
       not      edi
       jmp      SHORT G_M000_IG248
 
G_M000_IG247:                ;; offset=0x2238
       mov      edi, edx
 
G_M000_IG248:                ;; offset=0x223A
       jmp      SHORT G_M000_IG250
 
G_M000_IG249:                ;; offset=0x223C
       mov      rdx, bword ptr [rbp-0x320]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG250:                ;; offset=0x2246
       inc      edi
       mov      rcx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG251
       mov      r13d, edx
       not      r13d
       jmp      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x225E
       mov      r13d, edx
 
G_M000_IG252:                ;; offset=0x2261
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       cmp      r13d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG253
       mov      rcx, rsi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG253:                ;; offset=0x22AF
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       mov      dword ptr [rsi+0x40], r13d
       jmp      G_M000_IG335
 
G_M000_IG254:                ;; offset=0x22E0
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       mov      r14, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r14]
       mov      rdi, gword ptr [r14+0x08]
       mov      rcx, gword ptr [r14]
       mov      r13, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       mov      r13, gword ptr [r13+8*rcx+0x10]
       lea      r12, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      eax, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x204], eax
       mov      rcx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG255
       mov      r8d, edx
       not      r8d
       mov      dword ptr [rbp-0x2B8], r8d
       jmp      SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x234E
       mov      dword ptr [rbp-0x2B8], edx
 
G_M000_IG256:                ;; offset=0x2354
       mov      rcx, gword ptr [r12]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r9, rax
       mov      rcx, gword ptr [r12]
       mov      edx, dword ptr [rbp-0x204]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG257:                ;; offset=0x23A9
       mov      qword ptr [rcx+0x08], rdx
       mov      ecx, dword ptr [rbp-0x2B8]
       mov      dword ptr [r12+0x40], ecx
       mov      gword ptr [rsp+0x20], r15
       mov      rcx, bword ptr [rbp-0x320]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, rsi
       mov      rdx, rdi
       mov      r8, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG335
 
G_M000_IG258:                ;; offset=0x23E0
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      rsi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG334
       mov      ecx, eax
       mov      rsi, gword ptr [rsi+8*rcx+0x10]
       lea      rdi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x320]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x320]
       mov      r12d, dword ptr [rcx+0x18]
       test     r12d, r12d
       jge      SHORT G_M000_IG259
       not      r12d
 
G_M000_IG259:                ;; offset=0x2437
       mov      rcx, gword ptr [rdi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG334
       mov      eax, r13d
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      r9, gword ptr [rdi]
       cmp      r13d, dword ptr [r9+0x08]
       jae      G_M000_IG334
       mov      ecx, r13d
       shl      rcx, 4
       lea      r9, bword ptr [r9+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [r9], rcx
 
G_M000_IG260:                ;; offset=0x248A
       mov      qword ptr [r9+0x08], rcx
       mov      dword ptr [rdi+0x40], r12d
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      r8, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG335
 
G_M000_IG261:                ;; offset=0x24AD
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      rcx, r14
       mov      rdx, r15
       mov      r8, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG335
       jmp      G_M000_IG97
 
G_M000_IG262:                ;; offset=0x24D5
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG335
 
G_M000_IG263:                ;; offset=0x24F9
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       test     r15, r15
       je       G_M000_IG97
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG335
 
G_M000_IG264:                ;; offset=0x2522
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG335
       test     r15, r15
       je       G_M000_IG97
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG267
       mov      r8, bword ptr [rbp-0x320]
 
G_M000_IG265:                ;; offset=0x255F
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x300], ymm0
 
G_M000_IG266:                ;; offset=0x256C
       lea      r8, [rbp-0x300]
       lea      rdx, [rbp-0x218]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rsi, rbx
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x210]
       mov      qword ptr [rsi+0x08], rdx
       mov      rsi, gword ptr [rbx]
       test     rsi, rsi
       je       G_M000_IG62
       jmp      G_M000_IG297
 
G_M000_IG267:                ;; offset=0x25B1
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, r15
       mov      r9, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG335
 
G_M000_IG268:                ;; offset=0x25CD
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
       lea      rcx, [rbp-0x130]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG269:                ;; offset=0x25F9
       vmovdqu  ymm0, ymmword ptr [rbp-0x130]
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       mov      rcx, qword ptr [rbp-0x110]
       mov      qword ptr [rbp-0xE8], rcx
 
G_M000_IG270:                ;; offset=0x2617
       mov      ecx, dword ptr [rbp-0xF8]
       cmp      ecx, dword ptr [rbp-0xE8]
       jbe      G_M000_IG331
       jmp      G_M000_IG284
 
G_M000_IG271:                ;; offset=0x262E
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rsi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r11, 0x7FF9B38923D0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG272:                ;; offset=0x2674
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG335
 
G_M000_IG273:                ;; offset=0x2689
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG335
 
G_M000_IG274:                ;; offset=0x2699
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG275
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x26C1
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B38923F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG276:                ;; offset=0x26E0
       test     edi, edi
       jne      G_M000_IG62
 
G_M000_IG277:                ;; offset=0x26E8
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x320]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x8C], 4
       jmp      G_M000_IG343
 
G_M000_IG278:                ;; offset=0x2716
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG335
 
G_M000_IG279:                ;; offset=0x272B
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG335
 
G_M000_IG280:                ;; offset=0x273B
       mov      rdx, r15
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG281
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG282
 
G_M000_IG281:                ;; offset=0x2763
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3892400
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG282:                ;; offset=0x2782
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG283:                ;; offset=0x2790
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG284:                ;; offset=0x279D
       mov      r14, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG285:                ;; offset=0x27A8
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG335
 
G_M000_IG286:                ;; offset=0x27BD
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG335
 
G_M000_IG287:                ;; offset=0x27CD
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG288
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG289
 
G_M000_IG288:                ;; offset=0x27F5
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892410
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG289:                ;; offset=0x2814
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG290:                ;; offset=0x2821
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG291
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG292
 
G_M000_IG291:                ;; offset=0x2849
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3892418
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG292:                ;; offset=0x2868
       test     r15d, r15d
       jne      G_M000_IG238
       jmp      G_M000_IG277
 
G_M000_IG293:                ;; offset=0x2876
       mov      rcx, r13
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG229
 
G_M000_IG294:                ;; offset=0x2886
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG295
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG296
 
G_M000_IG295:                ;; offset=0x28AE
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892428
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG296:                ;; offset=0x28CD
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG297:                ;; offset=0x28DA
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG298
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG299
 
G_M000_IG298:                ;; offset=0x2902
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892430
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG299:                ;; offset=0x2921
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG300:                ;; offset=0x292E
       mov      rdx, r15
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG301
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG302
 
G_M000_IG301:                ;; offset=0x2956
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3892438
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG302:                ;; offset=0x2975
       test     r13d, r13d
       jne      G_M000_IG201
       jmp      G_M000_IG277
 
G_M000_IG303:                ;; offset=0x2983
       mov      rdx, r15
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG304
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG305
 
G_M000_IG304:                ;; offset=0x29AB
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3892440
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG305:                ;; offset=0x29CA
       test     r13d, r13d
       jne      G_M000_IG201
       jmp      G_M000_IG277
 
G_M000_IG306:                ;; offset=0x29D8
       mov      rdx, r15
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG307
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG308
 
G_M000_IG307:                ;; offset=0x2A00
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3892448
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG308:                ;; offset=0x2A1F
       test     r13d, r13d
       jne      G_M000_IG201
       jmp      G_M000_IG277
 
G_M000_IG309:                ;; offset=0x2A2D
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG310:                ;; offset=0x2A33
       mov      rdx, r12
       mov      rcx, 0x7FF9B4047088
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG311
       mov      edx, dword ptr [rax+0x34]
       and      edx, 0x1600000
       cmp      edx, 0x1000000
       sete     dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0x2A63
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, r12
       mov      r11, 0x7FF9B3892450
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     dil
       movzx    rdi, dil
 
G_M000_IG312:                ;; offset=0x2A87
       test     edi, edi
       je       G_M000_IG133
       jmp      G_M000_IG126
 
G_M000_IG313:                ;; offset=0x2A94
       mov      rdx, rdi
       mov      rcx, 0x7FF9B4047088
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       SHORT G_M000_IG316
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG315
 
G_M000_IG314:                ;; offset=0x2AC1
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG315:                ;; offset=0x2ACC
       mov      r12, gword ptr [r12+0x38]
       jmp      G_M000_IG128
 
G_M000_IG316:                ;; offset=0x2AD6
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rdi
       mov      r11, 0x7FF9B3892458
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG128
 
G_M000_IG317:                ;; offset=0x2AF7
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG335
 
G_M000_IG318:                ;; offset=0x2B0C
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG335
 
G_M000_IG319:                ;; offset=0x2B1C
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG320
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x2B44
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892468
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG321:                ;; offset=0x2B63
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG322:                ;; offset=0x2B70
       mov      rdx, r15
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG323
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG324
 
G_M000_IG323:                ;; offset=0x2B98
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9B3892470
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG324:                ;; offset=0x2BB7
       test     r13d, r13d
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG325:                ;; offset=0x2BC5
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG326
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x2BED
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892478
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG327:                ;; offset=0x2C0C
       test     edi, edi
       jne      G_M000_IG62
       jmp      G_M000_IG277
 
G_M000_IG328:                ;; offset=0x2C19
       mov      rdx, rsi
       mov      rcx, 0x7FF9B4051080
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x2C41
       movsx    rdx, word  ptr [rbx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9B3892480
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG330:                ;; offset=0x2C60
       test     edi, edi
       jne      G_M000_IG201
       jmp      G_M000_IG277
 
G_M000_IG331:                ;; offset=0x2C6D
       mov      rdx, bword ptr [rbp-0xF0]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xE8]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG332
       vmovups  ymm0, ymmword ptr [reloc @RWD296]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD328]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0xF8]
       add      ecx, 27
       mov      dword ptr [rbp-0xF8], ecx
       jmp      SHORT G_M000_IG333
 
G_M000_IG332:                ;; offset=0x2CBE
       lea      rcx, [rbp-0x108]
       mov      rdx, 0x204473E4060
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG333:                ;; offset=0x2CD5
       mov      rdx, bword ptr [rbp-0x320]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9B3AB94A8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG334:                ;; offset=0x2D20
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG335:                ;; offset=0x2D26
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG336
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG340
 
G_M000_IG336:                ;; offset=0x2D37
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG337
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG337:                ;; offset=0x2D45
       mov      rbx, bword ptr [rbp+0x30]
       mov      r14, bword ptr [rbp+0x10]
       mov      r15, gword ptr [rbp+0x20]
       mov      ecx, dword ptr [r14+0x10]
       mov      r10, gword ptr [rbp-0x318]
       mov      esi, dword ptr [r10+0x08]
       cmp      ecx, esi
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       jl       G_M000_IG05
 
G_M000_IG338:                ;; offset=0x2D6F
       mov      eax, 1
 
G_M000_IG339:                ;; offset=0x2D74
       vzeroupper 
       add      rsp, 936
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG340:                ;; offset=0x2D8B
       xor      rax, rax
       mov      rbx, bword ptr [rbp+0x30]
       mov      gword ptr [rbx], rax
       mov      word  ptr [rbx+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rbx+0x0A], al
       mov      byte  ptr [rbx+0x0B], 1
       mov      eax, 5
 
G_M000_IG341:                ;; offset=0x2DAA
       vzeroupper 
       add      rsp, 936
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG342:                ;; offset=0x2DC1
       mov      r9, bword ptr [rbp-0x320]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, r13
       mov      r8, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG345
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG335
 
G_M000_IG343:                ;; offset=0x2DEA
       mov      eax, dword ptr [rbp-0x8C]
 
G_M000_IG344:                ;; offset=0x2DF0
       vzeroupper 
       add      rsp, 936
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG345:                ;; offset=0x2E07
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG346:                ;; offset=0x2E10
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG347:                ;; offset=0x2E16
       sub      rsp, 72
 
G_M000_IG348:                ;; offset=0x2E1A
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG349
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG349:                ;; offset=0x2E2A
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG351
       mov      dword ptr [rbp-0x8C], 1
       lea      rax, G_M000_IG343
 
G_M000_IG350:                ;; offset=0x2E5C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG351:                ;; offset=0x2E64
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG335
 
G_M000_IG352:                ;; offset=0x2E72
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG353:                ;; offset=0x2E7A
       sub      rsp, 72
 
G_M000_IG354:                ;; offset=0x2E7E
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x320]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG355
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG355:                ;; offset=0x2EAC
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG335
 
G_M000_IG356:                ;; offset=0x2EBA
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000008CEh ; case G_M000_IG61
       	dd	000007ADh ; case G_M000_IG54
       	dd	0000065Bh ; case G_M000_IG46
       	dd	000004F1h ; case G_M000_IG37
       	dd	000003CEh ; case G_M000_IG30
       	dd	0000028Dh ; case G_M000_IG23
       	dd	000001B9h ; case G_M000_IG17
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	00000E67h ; case G_M000_IG102
       	dd	00000E67h ; case G_M000_IG102
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000000B3h ; case G_M000_IG09
       	dd	000024C5h ; case G_M000_IG264
       	dd	000024C5h ; case G_M000_IG264
       	dd	0000249Ch ; case G_M000_IG263
       	dd	00002478h ; case G_M000_IG262
       	dd	00002450h ; case G_M000_IG261
       	dd	00002383h ; case G_M000_IG258
       	dd	00002283h ; case G_M000_IG254
       	dd	000021A8h ; case G_M000_IG244
       	dd	0000214Ch ; case G_M000_IG242
       	dd	000020D6h ; case G_M000_IG241
       	dd	00001BEBh ; case G_M000_IG204
       	dd	00001BC2h ; case G_M000_IG202
       	dd	00001BC2h ; case G_M000_IG202
       	dd	00001BC2h ; case G_M000_IG202
       	dd	00001B42h ; case G_M000_IG198
       	dd	00001B42h ; case G_M000_IG198
       	dd	00001B42h ; case G_M000_IG198
       	dd	00001BC2h ; case G_M000_IG202
       	dd	00001A02h ; case G_M000_IG191
       	dd	000018EFh ; case G_M000_IG183
       	dd	00000EBBh ; case G_M000_IG103
       	dd	00000E3Dh ; case G_M000_IG101
       	dd	00000DB5h ; case G_M000_IG98
       	dd	00000D85h ; case G_M000_IG96
       	dd	00000D56h ; case G_M000_IG95
       	dd	00000D56h ; case G_M000_IG95
       	dd	00000D56h ; case G_M000_IG95
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000BC2h ; case G_M000_IG83
       	dd	00000B77h ; case G_M000_IG82
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00000CC8h ; case G_M000_IG92
       	dd	000020BFh ; case G_M000_IG240
       	dd	00000984h ; case G_M000_IG64
       	dd	00001E06h ; case G_M000_IG219
       	dd	00000CC8h ; case G_M000_IG92
       	dd	00001CD9h ; case G_M000_IG210
       	dd	00001CD9h ; case G_M000_IG210
       	dd	00001CD9h ; case G_M000_IG210
       	dd	00001CD9h ; case G_M000_IG210
       	dd	00001CD9h ; case G_M000_IG210
       	dd	000018C5h ; case G_M000_IG182
       	dd	000017E5h ; case G_M000_IG179
       	dd	00001660h ; case G_M000_IG159
       	dd	0000157Eh ; case G_M000_IG146
       	dd	00001549h ; case G_M000_IG145
       	dd	000014C5h ; case G_M000_IG142
RWD296 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD328 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 11970

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 156 single block inlinees; 43 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 192
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqu  ymmword ptr [rsp+0x90], ymm4
       vmovdqa  xmmword ptr [rsp+0xB0], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x003F
       mov      rcx, 0x1E4208019C8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG149
 
G_M000_IG03:                ;; offset=0x006D
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00AC
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00B8
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 72
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00C3
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00DB
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00DD
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00EF
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG64
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG64
 
G_M000_IG10:                ;; offset=0x012D
       lea      r8, [rsp+0x68]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x014A
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG12:                ;; offset=0x0155
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x017E
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG14:                ;; offset=0x0189
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01BB
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01C4
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x68]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x01EB
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x01F4
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x0227
       cmp      byte  ptr [rsp+0x68], 0
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG20:                ;; offset=0x0237
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG21:                ;; offset=0x023B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG22:                ;; offset=0x0246
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG64
 
G_M000_IG23:                ;; offset=0x02A5
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG147
 
G_M000_IG24:                ;; offset=0x02B6
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02BA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG26:                ;; offset=0x02C5
       lea      rdx, [rsp+0x98]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x02ED
       vmovdqu  xmm0, xmmword ptr [rsp+0x98]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG28:                ;; offset=0x02FC
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG29:                ;; offset=0x0312
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG30:                ;; offset=0x0316
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG31:                ;; offset=0x0321
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rsp+0x50], rdx
       test     r13d, r13d
       jge      SHORT G_M000_IG33
       mov      edx, r13d
       not      edx
       mov      r15, gword ptr [rcx+0x30]
       cmp      dword ptr [r15+0x08], edx
       jg       SHORT G_M000_IG32
       sub      edx, dword ptr [r15+0x08]
       lea      r9, [rsp+0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0x88]
       mov      rcx, gword ptr [rsp+0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x0399
       cmp      edx, dword ptr [r15+0x08]
       jae      G_M000_IG204
       mov      ecx, edx
       mov      rcx, gword ptr [r15+8*rcx+0x10]
       lea      rdx, [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03BA
       cmp      r13d, r15d
       jae      G_M000_IG204
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG34:                ;; offset=0x03DB
       xor      r9, r9
       mov      gword ptr [rsp+0x50], r9
       test     eax, eax
       je       SHORT G_M000_IG35
       mov      rdx, qword ptr [rsp+0x88]
       lea      r9, [rsp+0x78]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG48
 
G_M000_IG35:                ;; offset=0x0411
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG36:                ;; offset=0x0415
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG37:                ;; offset=0x0420
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG38:                ;; offset=0x0450
       mov      rcx, 0x7FF9B3DFDC88
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG39:                ;; offset=0x0464
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG40
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B3893C28
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0486
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x0490
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG42:                ;; offset=0x0499
       mov      rcx, 0x7FF9B3DA4CD8
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x04AC
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG44
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG44
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG204
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x70]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG47
 
G_M000_IG44:                ;; offset=0x0516
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG45
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9B3893C30
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0538
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG46:                ;; offset=0x0542
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG47:                ;; offset=0x0578
       mov      r8, gword ptr [rsp+0x70]
       mov      gword ptr [rsp+0x30], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG48:                ;; offset=0x05A0
       vmovdqu  xmm0, xmmword ptr [rsp+0x78]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG49:                ;; offset=0x05AC
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG50:                ;; offset=0x05C2
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG51:                ;; offset=0x05DB
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0616
       mov      rdx, 0x7FF9B40FEAB0
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0625
       lea      rdx, [rsp+0x58]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG54:                ;; offset=0x0632
       test     rcx, rcx
       je       SHORT G_M000_IG57
 
G_M000_IG55:                ;; offset=0x0637
       mov      rdx, 0x7FF9B40FED18
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0646
       lea      rdx, [rsp+0x58]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG60
 
G_M000_IG57:                ;; offset=0x0653
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x065B
       mov      rax, 0x7FF9B4045088
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG200
 
G_M000_IG59:                ;; offset=0x066F
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x58]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG60:                ;; offset=0x068A
       cmp      gword ptr [rsp+0x58], 0
       je       SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x0692
       vmovdqu  xmm0, xmmword ptr [rsp+0x58]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG62:                ;; offset=0x069E
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG63:                ;; offset=0x06B4
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG64:                ;; offset=0x06C0
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG148
 
G_M000_IG65:                ;; offset=0x06D1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG66:                ;; offset=0x06D5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG67:                ;; offset=0x06E0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG72
 
G_M000_IG68:                ;; offset=0x070E
       mov      r8, 0x7FF9B40FEAB0
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x071E
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG70:                ;; offset=0x0741
       mov      rcx, 0x7FF9B40D57C8
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0751
       mov      rcx, 0x7FF9B40FED18
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x30], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG72:                ;; offset=0x0792
       test     rbp, rbp
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0797
       mov      rdx, 0x7FF9B404B858
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG76
 
G_M000_IG74:                ;; offset=0x07A7
       mov      rdx, rbp
       mov      rcx, 0x7FF9B3FC8490
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG76
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG75:                ;; offset=0x07C7
       mov      r8, 0x7FF9B3F9F728
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B3DA4CD8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B3DFDC88
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG76
       mov      r8, 0x7FF9B4091948
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG76:                ;; offset=0x080B
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG77:                ;; offset=0x083E
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x0857
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG162
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG79
       mov      rcx, 0x1E420801AB0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0887
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG203
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x40], rcx
       mov      dword ptr [rsp+0x48], eax
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG80:                ;; offset=0x08D5
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG81:                ;; offset=0x0904
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG203
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x40], rcx
       mov      dword ptr [rsp+0x48], eax
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG82:                ;; offset=0x0981
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG83:                ;; offset=0x0985
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG84:                ;; offset=0x0990
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG85
       not      edx
 
G_M000_IG85:                ;; offset=0x09BB
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG147
 
G_M000_IG86:                ;; offset=0x09C9
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG91
 
G_M000_IG87:                ;; offset=0x09D0
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG91
 
G_M000_IG88:                ;; offset=0x09E0
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG89
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x09EF
       mov      r14d, ebp
 
G_M000_IG90:                ;; offset=0x09F2
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x09F4
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG92:                ;; offset=0x09F8
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG93
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A0A
       mov      r15d, ebp
 
G_M000_IG94:                ;; offset=0x0A0D
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG95:                ;; offset=0x0A11
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG96:                ;; offset=0x0A1C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG97
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG97:                ;; offset=0x0A53
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG147
 
G_M000_IG98:                ;; offset=0x0A85
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG99
       cmp      edx, 26
       jne      G_M000_IG202
 
G_M000_IG99:                ;; offset=0x0A99
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG100
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG100:                ;; offset=0x0AD0
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG104
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG103
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG101:                ;; offset=0x0B01
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG102:                ;; offset=0x0B0C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG103:                ;; offset=0x0B2A
       jmp      SHORT G_M000_IG107
 
G_M000_IG104:                ;; offset=0x0B2C
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG105:                ;; offset=0x0B30
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG106:                ;; offset=0x0B3B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG107:                ;; offset=0x0B5F
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG108
       not      edx
 
G_M000_IG108:                ;; offset=0x0B8A
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x30], r14
       mov      qword ptr [rsp+0x38], r15
       lea      rdx, [rsp+0x30]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG109:                ;; offset=0x0BB0
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG147
 
G_M000_IG110:                ;; offset=0x0BC1
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG111:                ;; offset=0x0BC5
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG112:                ;; offset=0x0BD0
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG204
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       je       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0C1D
       mov      r8, 0x7FF9B404ADE8
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0C2D
       lea      r8, [rsp+0x90]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG115
       mov      r15, gword ptr [rsp+0x90]
       jmp      SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x0C4F
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
 
G_M000_IG116:                ;; offset=0x0C5E
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG120
 
G_M000_IG117:                ;; offset=0x0C71
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG120
 
G_M000_IG118:                ;; offset=0x0C81
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG119
       not      r14d
 
G_M000_IG119:                ;; offset=0x0C8D
       jmp      SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x0C8F
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG121:                ;; offset=0x0C93
       cmp      ecx, 51
       ja       SHORT G_M000_IG126
 
G_M000_IG122:                ;; offset=0x0C98
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG126
 
G_M000_IG123:                ;; offset=0x0CA8
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG124
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0CB7
       mov      r13d, ecx
 
G_M000_IG125:                ;; offset=0x0CBA
       jmp      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0CBC
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG127:                ;; offset=0x0CC0
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG128
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG128:                ;; offset=0x0CD5
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG132
 
G_M000_IG129:                ;; offset=0x0D0A
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG132
 
G_M000_IG130:                ;; offset=0x0D1A
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG131
       not      ebp
 
G_M000_IG131:                ;; offset=0x0D23
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D25
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG133:                ;; offset=0x0D28
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG134
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0D37
       mov      edi, ecx
 
G_M000_IG135:                ;; offset=0x0D39
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG136
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG136:                ;; offset=0x0D49
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG147
 
G_M000_IG137:                ;; offset=0x0D78
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG138:                ;; offset=0x0D91
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG139:                ;; offset=0x0DAA
       mov      rbp, gword ptr [rbx+0x08]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG140:                ;; offset=0x0DEC
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG142
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG141
       cmp      edx, 26
       jne      G_M000_IG202
 
G_M000_IG141:                ;; offset=0x0E24
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xB8], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xB8]
       mov      gword ptr [rsp+0x30], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG147
 
G_M000_IG142:                ;; offset=0x0E77
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG147
 
G_M000_IG143:                ;; offset=0x0E80
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG144:                ;; offset=0x0E90
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG145:                ;; offset=0x0E9B
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x0ED9
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rcx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x30], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG147:                ;; offset=0x0F1E
       inc      dword ptr [rbx+0x38]
 
G_M000_IG148:                ;; offset=0x0F21
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG149:                ;; offset=0x0F34
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG150:                ;; offset=0x0F4B
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG151:                ;; offset=0x0F5D
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG161
 
G_M000_IG152:                ;; offset=0x0F80
       mov      rcx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rcx+0xEC]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG156
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      rbp, gword ptr [rdx]
       mov      r14, qword ptr [rdx+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG155
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG153:                ;; offset=0x0FCF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG154:                ;; offset=0x0FDA
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
 
G_M000_IG155:                ;; offset=0x0FF8
       jmp      SHORT G_M000_IG159
 
G_M000_IG156:                ;; offset=0x0FFA
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG157:                ;; offset=0x0FFE
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG158:                ;; offset=0x1009
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x40]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG159:                ;; offset=0x102D
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG161
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG160:                ;; offset=0x1064
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG161:                ;; offset=0x1068
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG162:                ;; offset=0x107B
       mov      eax, 1
 
G_M000_IG163:                ;; offset=0x1080
       add      rsp, 192
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG164:                ;; offset=0x1092
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG203
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x40], rdx
       mov      dword ptr [rsp+0x48], r8d
       lea      rcx, [rsp+0x40]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG147
 
G_M000_IG165:                ;; offset=0x10E1
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG147
       jmp      G_M000_IG201
 
G_M000_IG166:                ;; offset=0x1111
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG170
 
G_M000_IG167:                ;; offset=0x111A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG170
 
G_M000_IG168:                ;; offset=0x112A
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG169
       not      ebp
 
G_M000_IG169:                ;; offset=0x1133
       jmp      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x1135
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG171:                ;; offset=0x1138
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG172:                ;; offset=0x114A
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xA8], xmm0
 
G_M000_IG173:                ;; offset=0x1158
       cmp      gword ptr [rsp+0xA8], 0
       jne      SHORT G_M000_IG174
       lea      rcx, [rsp+0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9B40455B0
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG174:                ;; offset=0x1184
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG178
 
G_M000_IG175:                ;; offset=0x1190
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG178
 
G_M000_IG176:                ;; offset=0x11A0
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG177
       not      edx
 
G_M000_IG177:                ;; offset=0x11A9
       jmp      SHORT G_M000_IG179
 
G_M000_IG178:                ;; offset=0x11AB
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG179:                ;; offset=0x11AE
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG204
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG180
       not      edx
 
G_M000_IG180:                ;; offset=0x11D4
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xA8]
       mov      r9, qword ptr [rsp+0xB0]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG204
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x30], rdx
       mov      qword ptr [rsp+0x38], r9
       lea      r8, [rsp+0x30]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG147
 
G_M000_IG181:                ;; offset=0x1237
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rcx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG204
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x1260
       mov      rax, 0x7FF9B3DBFE90
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG199
 
G_M000_IG183:                ;; offset=0x1273
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG187
 
G_M000_IG184:                ;; offset=0x1284
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG187
 
G_M000_IG185:                ;; offset=0x1294
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG186
       not      r9d
 
G_M000_IG186:                ;; offset=0x12A0
       jmp      SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x12A2
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG188:                ;; offset=0x12A6
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG189
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG190
 
G_M000_IG189:                ;; offset=0x12B5
       mov      r10d, eax
 
G_M000_IG190:                ;; offset=0x12B8
       cmp      r8d, 51
       ja       SHORT G_M000_IG195
 
G_M000_IG191:                ;; offset=0x12BE
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x12CE
       test     eax, eax
       jge      SHORT G_M000_IG193
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG194
 
G_M000_IG193:                ;; offset=0x12DA
       mov      r8d, eax
 
G_M000_IG194:                ;; offset=0x12DD
       jmp      SHORT G_M000_IG196
 
G_M000_IG195:                ;; offset=0x12DF
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG196:                ;; offset=0x12E3
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG203
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x40], r8
       mov      dword ptr [rsp+0x48], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x40]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG197
       not      ecx
 
G_M000_IG197:                ;; offset=0x133B
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG147
 
G_M000_IG198:                ;; offset=0x1343
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG147
       jmp      G_M000_IG07
 
G_M000_IG199:                ;; offset=0x135C
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG200:                ;; offset=0x1365
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG201:                ;; offset=0x1371
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9B3893C20
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG202:                ;; offset=0x13A9
       mov      rcx, rdi
       mov      rdx, 0x204473EA300
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG203:                ;; offset=0x13C5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG204:                ;; offset=0x13CC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000E9Ah ; case G_M000_IG146
       	dd	00000E41h ; case G_M000_IG143
       	dd	00000DADh ; case G_M000_IG140
       	dd	00000D6Bh ; case G_M000_IG139
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D52h ; case G_M000_IG138
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D39h ; case G_M000_IG137
       	dd	00000D39h ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B82h ; case G_M000_IG110
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000B71h ; case G_M000_IG109
       	dd	00000A46h ; case G_M000_IG98
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000098Ah ; case G_M000_IG86
       	dd	00000942h ; case G_M000_IG82
       	dd	000008C5h ; case G_M000_IG81
       	dd	00000818h ; case G_M000_IG78
       	dd	000007FFh ; case G_M000_IG77
       	dd	000007FFh ; case G_M000_IG77
       	dd	000007FFh ; case G_M000_IG77
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000692h ; case G_M000_IG65
       	dd	0000059Ch ; case G_M000_IG51
       	dd	00000583h ; case G_M000_IG50
       	dd	000002D3h ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000266h ; case G_M000_IG23
       	dd	00000266h ; case G_M000_IG23
       	dd	00000277h ; case G_M000_IG24
       	dd	00000681h ; case G_M000_IG64
       	dd	000001F8h ; case G_M000_IG20
       	dd	000000EEh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F41h ; case G_M000_IG152
       	dd	00000F1Eh ; case G_M000_IG151
       	dd	00000F1Eh ; case G_M000_IG151
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	00001304h ; case G_M000_IG198
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000059Ch ; case G_M000_IG51
       	dd	000011F8h ; case G_M000_IG181
       	dd	000010D2h ; case G_M000_IG166
       	dd	000010A2h ; case G_M000_IG165
       	dd	00001053h ; case G_M000_IG164

; Total bytes of code 5074

