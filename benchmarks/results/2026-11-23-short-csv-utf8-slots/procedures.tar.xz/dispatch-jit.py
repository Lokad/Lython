from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

lab = Path(__file__).resolve().parent
identity = json.loads((lab / 'comparison/identity.json').read_text(encoding='utf-8'))
dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
catalog = lab / 'comparison/representative.json'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(catalog) == identity['catalogs']['representative.json']['sha256']
summary = {}
for role, files in identity['imageFiles'].items():
    image = lab / role
    assert all(digest(image / name) == expected for name, expected in files.items())
    listing = lab / (role + '-dispatch.asm')
    result = lab / (role + '-dispatch-allocation.json')
    subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, catalog, result], env=dict(env,
        DOTNET_TieredCompilation='0', DOTNET_JitDisasm='ExecuteInstructionPrefix RunCore',
        DOTNET_JitStdOutFile=str(listing)), check=True, timeout=45)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(result.read_text(encoding='utf-8'))['rows'])
    data = listing.read_text(encoding='utf-8-sig')
    methods = {}
    for assembly in data.split('; Assembly listing for method ')[1:]:
        header = assembly.splitlines()[0]
        if 'Lokad.Lython.Runtime.LythonRuntime' not in header:
            continue
        match = re.search(r'Total bytes of code (\d+)', assembly)
        assert match
        methods[header] = int(match[1])
    assert any(':ExecuteInstructionPrefix(' in key for key in methods)
    assert any(':RunCore(' in key for key in methods)
    summary[role] = methods
    assert all(digest(image / name) == expected for name, expected in files.items())
(lab / 'dispatch-code-sizes.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
for role, data in summary.items():
    print(role, [(re.search(r':(\w+)\(', method).group(1), n) for method, n in data.items()])

