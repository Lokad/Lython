set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-short-utf8-20261123
public_filter='(FullyQualifiedName~Csv|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~NumericConversion|FullyQualifiedName~Globals|FullyQualifiedName~MemoryOwnership|FullyQualifiedName~Cancellation)&Category!=Stress'
white_filter='(FullyQualifiedName~ExecutableUnpacking|FullyQualifiedName~ExecutableLoopTarget|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~NativeCsv|FullyQualifiedName~ExecutableStack|FullyQualifiedName~Cancellation)&Category!=Stress'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$public_filter" > "$lab/ubuntu-public.log" 2>&1 || { tail -30 "$lab/ubuntu-public.log"; exit 1; }
tail -7 "$lab/ubuntu-public.log"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$white_filter" > "$lab/ubuntu-white.log" 2>&1 || { tail -30 "$lab/ubuntu-white.log"; exit 1; }
tail -7 "$lab/ubuntu-white.log"
