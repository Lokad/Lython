from pathlib import Path
import hashlib
root=Path('/home/lokad/lython-bench-checks/analysis-cache-b210-20261104/debt')
base=root.parent/'baseline';target=root/'baseline';target.mkdir()
for file in base.iterdir():
 if file.name in ('Lokad.Lython.dll','Lokad.Lython.pdb'):continue
 (target/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
old=Path('/home/lokad/lython-bench-checks/compact-fragments-b205-20261104/metadata/candidate/Lokad.Lython.dll')
assert hashlib.sha256(old.read_bytes()).hexdigest()=='454cd98c3a16d303290f08052089130574d5b914bffa8c07d8251b10f3e9b719'
(target/'Lokad.Lython.dll').symlink_to(old.resolve())
(root/'candidate').symlink_to(root.parent/'candidate',target_is_directory=True)
