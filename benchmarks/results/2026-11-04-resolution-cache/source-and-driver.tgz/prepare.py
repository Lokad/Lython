from pathlib import Path
import hashlib, json, shutil

root = Path('D:/code/Lython')
notes = Path(__file__).resolve().parent
prior = notes.parent / 'analysis-cache-b87'
catalog = json.loads((notes.parent / 'flat-operands-b207/checkpoint/representative.json').read_text(encoding='utf-8-sig'))
by_id = {case['id']: case for case in catalog['cases']}
pairs = [('scripts.csv-summary-helpers.large', 'compile'), ('scripts.text-summary-helpers.large', 'compile'),
         ('scripts.report-render.large', 'compile'), ('scripts.config-edit.large', 'fresh'),
         ('scripts.text-summary-helpers.large', 'fresh'), ('scripts.text-summary-helpers.large', 'warm')]
cases = [{**by_id[name], 'mode': mode} for name, mode in pairs]
(notes / 'catalog.json').write_text(json.dumps({'cases': cases}, ensure_ascii=False) + '\n', encoding='utf-8')
shutil.copyfile(prior / 'hash-witness.json', notes / 'hash-witness.json')
shutil.copyfile(prior / 'reference-check.py', notes / 'reference-check.py')
jobs = notes / 'jobs'; jobs.mkdir(exist_ok=True)
shutil.copyfile(prior / 'jobs/complete-jobs.csproj', jobs / 'complete-jobs.csproj')
source = (prior / 'jobs/Program.cs').read_text(encoding='utf-8-sig')
start = source.index('if (cases.Length != 4')
end = source.index('var observations =', start)
expected = ', '.join(json.dumps(name + '/' + mode) for name, mode in sorted(pairs))
source = source[:start] + f'''if (cases.Length != 6 || !cases.Select(x => x.GetProperty("id").GetString() + "/" + x.GetProperty("mode").GetString()).Order().SequenceEqual(
    new[] {{ {expected} }}))
    throw new InvalidDataException("Only the six frozen compile/fresh/warm cases are allowed.");
''' + source[end:]
source = source.replace('var observations = new List<object>();', 'var observations = new List<object>();\nvar caseNumber = 0;')
source = source.replace('var batch = mode == "compile" ? 2048 : mode == "fresh" ? 32 : 32;',
                        'var warmupBatch = mode == "compile" ? 512 : 16;\n    var batch = 0;')
old = '''    for (var i = 0; i < (mode == "compile" ? 1024 : 128); i++) foreach (var image in images) image.Once(mode);
    foreach (var image in images) image.FreezeBalance();'''
new = '''    var warmups = new List<object>();
    foreach (var image in caseNumber++ % 2 == 0 ? images : images.Reverse())
    {
        var warmupMs = 0.0;
        var warmupCount = 0;
        double lastMs;
        do
        {
            var resetBefore = image.ResetTicks;
            var started = Stopwatch.GetTimestamp();
            for (var i = 0; i < warmupBatch; i++) image.Once(mode);
            lastMs = (Stopwatch.GetTimestamp() - started - (image.ResetTicks - resetBefore)) * 1000.0 / Stopwatch.Frequency;
            warmupMs += lastMs;
            warmupCount += warmupBatch;
        } while (warmupMs < 6000);
        if (image.Label == "before") batch = Math.Clamp((int)Math.Ceiling(200.0 * warmupBatch / lastMs), 1, 1000000);
        warmups.Add(new { image = image.Label, warmupCount, warmupMs, lastMs });
    }
    foreach (var image in images) image.FreezeBalance();'''
assert old in source; source = source.replace(old, new)
source = source.replace('round < 7', 'round < 9')
source = source.replace('''            var clock = Stopwatch.StartNew();
            for (var i = 0; i < batch; i++) image.Once(mode);
            clock.Stop();
            samples.Add(new { round, image = image.Label, jobs = batch, elapsedMilliseconds = clock.Elapsed.TotalMilliseconds });''',
'''            var resetBefore = image.ResetTicks;
            var allocatedBefore = GC.GetTotalAllocatedBytes(precise: true);
            var started = Stopwatch.GetTimestamp();
            for (var i = 0; i < batch; i++) image.Once(mode);
            var elapsedTicks = Stopwatch.GetTimestamp() - started - (image.ResetTicks - resetBefore);
            var allocatedBytes = GC.GetTotalAllocatedBytes(precise: true) - allocatedBefore;
            samples.Add(new { round, image = image.Label, jobs = batch,
                elapsedMilliseconds = elapsedTicks * 1000.0 / Stopwatch.Frequency, allocatedBytes });''')
source = source.replace('caseId, mode, samples, hashWitness', 'caseId, mode, warmups, batch, samples, hashWitness')
source = source.replace('compileWarmupsPerImage = 1024, executionWarmupsPerImage = 128, settleSecondsPerCase = 2, rounds = 7, compileBatch = 2048, freshBatch = 32, warmBatch = 32, observations,',
                        'warmupGuestSecondsPerImage = 6, settleSecondsPerCase = 2, rounds = 9, targetBatchMilliseconds = 200, observations,')
source = source.replace('purpose = "One existing abstract-value cache consolidation; compile-only/fresh and warm controls, no external ratio"',
                        'purpose = "Current-source reassessment of identity-owned cache simplification; no fixed percentage veto or external ratio"')
source = source.replace('fixture reset/mediated I/O', 'mediated I/O')
source = source.replace('Startup excluded.', 'Fixture reset/staging and startup excluded. Full managed checks and per-job ownership cleanup included. Allocation counters include all process activity including fixture reset; no guest-only CPU claim.')
source = source.replace('    private bool _disposed;', '    private bool _disposed;\n    public long ResetTicks { get; private set; }')
source = source.replace('        _reset.Invoke(_host, null);', '        var resetStarted = Stopwatch.GetTimestamp();\n        try { _reset.Invoke(_host, null); }\n        finally { ResetTicks += Stopwatch.GetTimestamp() - resetStarted; }')
(jobs / 'Program.cs').write_text(source, encoding='utf-8', newline='\n')
(notes / 'catalog-witness.json').write_text(json.dumps([{
    'case': c['id'], 'mode': c['mode'], 'sourceSha256': c['sourceSha256'],
    'fixtureSha256': c['fixtureSha256'], 'outputSha256': c['expectedOutputSha256'],
    'filesSha256': c['expectedFilesSha256']} for c in cases], indent=2) + '\n', encoding='utf-8')
print('Prepared existing six-case driver; compile/fresh/warm controls and unchanged complete goldens.')
