from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'call-entry-cost-b402-20261107'
source=(base/'integer-parsing-b399-20261107/candidate').resolve()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not Path('/dev/shm/lython-call-entry-cost-b402').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(43863+1)
 assert len(payload)==43863 and hashlib.sha256(payload).hexdigest()=='495001c369ecd0799d0e4b7c50b74f7b68dfd9c30ffa1c8ad6a85997800d88a6'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+5*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 shutil.copytree(source,root/'candidate',symlinks=True,copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],**identity['files']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,
  ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b402-call-entry-cost-20261107',
 '--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120',
 '--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
