from pathlib import Path
import ast,json,tarfile
r=Path(__file__).parent;n=r/'b403';n.mkdir()
for name in ['identity.json','catalog.json']:(n/name).write_bytes((r/name).read_bytes())
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve.py','analyze-chains.py']:
 s=(r/name).read_text(encoding='utf-8').replace('-b402','-b403')
 if name=='ops-profile.py':
  old='request("batch", 512 if lane == "compile" else 64)';assert s.count(old)==1
  s=s.replace(old,'request("batch", 512 if lane == "compile" else 1024)')
 if name=='analyze-chains.py':s=s.replace("r.parent/'csv-cost-r39/b391/analyze-chains.py'","r.parent.parent/'csv-cost-r39/b391/analyze-chains.py'")
 if name.endswith('.py'):ast.parse(s)
 (n/name).write_text(s,encoding='utf-8',newline='\n')
correction=dict(originalWarmup=dict(maxRequests=64,jobsPerRequest=64,maxJobs=4096,minimumGuestSeconds=6),correctedWarmup=dict(maxRequests=64,jobsPerRequest=1024,maxJobs=65536,minimumGuestSeconds=6),sampledPhase='Unchanged6s wall capture, single complete job per request,199Hz cpu-clock/fp; same images/source/diagnostic overrides.',captionCorrection='Earlier failure caption mistakenly described4096 single-job requests and a proposed batch8. Exact inherited source has64batches*64jobs. Correction changes only warmup batch64→1024; count variable/sample request unchanged.',originalConditionsPreserved=True,noObservationTimeoutOrRestart=True)
(r/'warmup-correction.json').write_text(json.dumps(correction,indent=2)+'\n',encoding='utf-8',newline='\n');(n/'warmup-correction.json').write_text(json.dumps(correction,indent=2)+'\n',encoding='utf-8',newline='\n')
contract=(r/'source-contract.md').read_text(encoding='utf-8')+'\nB403 measurement correction: B402 failed before any sampler because its64*64 warmup job cap did not reach6guestseconds for this short workload. Exact original failure/source/raw archive retained. Warmup now permits64batches*1024completejobs, stops at the same6guestseconds. The sampled6s phase remains single-job requests, same199Hz/FP/PerfMap/JIT/source/images. Earlier single-job/batch8 caption was inaccurate; see warmup-correction.json.120s owner+30s stop+30s margin, observe after180s. No collection restarted after an observation timeout.\n'
(n/'source-contract.md').write_text(contract,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('cost gate active;120s owner+30s stop+30s margin. Observe after12:56:04UTC.','cost gate B402 failed before sampling:64warmup batches*64jobs do not reach6guest\nseconds. Failed archived04e53e3 verified locally; no users/fixtures/traces; never\nservice-query again. B403 corrected warmup planned:64batches*1024jobs stop at the\nsame6guestseconds; sampled6s/single-job requests/source/images unchanged.120s\nowner+30s stop+30s margin, observe after180s. Earlier single-job/batch8 caption\nwas inaccurate; exact source and correction are preserved. No runtime prototype.')
p.write_text(s,encoding='utf-8',newline='\n');(n/'pre-measurement-plan.md').write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(n/'payload.tgz','w:gz')as a:
 for name in ['identity.json','catalog.json','source-contract.md','pre-measurement-plan.md','warmup-correction.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:a.add(n/name,arcname=name)
print('Corrected warmup cap prepared; original sampling/source/images preserved. No new run started yet.')
