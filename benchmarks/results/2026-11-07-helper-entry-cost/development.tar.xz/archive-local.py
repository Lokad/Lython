from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b403';out=Path('benchmarks/results/2026-11-07-helper-entry-cost');out.mkdir()
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['archivedAndVerifiedUnderLease']
for folder,names in [(b,['observations.tgz','archive-receipt.json','terminal-status.json','extraction.json']),(r,['failed-observations.tgz','failed-archive-receipt.json','terminal-status.json','warmup-correction.json'])]:
 target=out/('b403'if folder==b else'b402');target.mkdir()
 for name in names:
  if name.endswith('.json'):(target/name).write_text((folder/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
  else:shutil.copy2(folder/name,target/name)
 raw='observations.tgz'if folder==b else'failed-observations.tgz';rec='archive-receipt.json'if folder==b else'failed-archive-receipt.json'
 assert hashlib.sha256((target/raw).read_bytes()).hexdigest()==json.loads((target/rec).read_text(encoding='utf-8'))['archiveSHA256']
for folder,name in [(b,'guest-call-chains.json'),(r,'source-invariants.json'),(r,'census.json')]:
 (out/name).write_text((folder/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.txt','.sh']:a.add(p,arcname=p.name)
 for p in b.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.sh']:a.add(p,arcname='b403/'+p.name)
 a.add(r.parent/'prepare-r48.py',arcname='prepare-r48.py')
 for name in ['Program.cs','census.csproj']:a.add(r.parent/'text-cost-r42/census'/name,arcname='reused-census/'+name)
chains=json.loads((b/'guest-call-chains.json').read_text(encoding='utf-8'))
leaves=json.loads((b/'retrieved/perf/search-warm/guest-cpu-leaves.json').read_text(encoding='utf-8'))
census=json.loads((r/'census.json').read_text(encoding='utf-8'));module=census['cases'][0]['codes'][0]
assert chains['samples']==645 and leaves['cpuSeconds']>3 and'wanted'not in module['locals']
selection=dict(noRuntimeChange=True,entryRedesignSelected=False,reason='Entry method leaves do not establish a dominant removable call-admission phase; inclusive helper totals include useful work, unknowns/inlining remain.',samples=645,unknownLeaves=34,guestCPUSeconds=leaves['cpuSeconds'],jobClockSeconds=receipt['capturedSeconds'],nextSourceFact='Module wanted binding is absent from existing local slots; its call target uses LoadName in the loop. Compile actual declaration binding metadata into existing slots while preserving dynamic namespace bridges; do not eagerly allocate dead module bindings.',moduleLoadNameLines=[o['line']for o in module['operations']if o['op']=='LoadName'],newProducerQualification=False)
(out/'decision.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# Complete protected-search call-entry cost gate — R48/B403

2026-11-07, qualified8c9fd0d7/frozen d3a6c778, precommit SourceLink3480aa55;
unchanged worker7cf37ca5/host/adapter27211dbe/normal0.4. Quiet F4as_v7 Ubuntu24.04.4,
.NET11RC3 normal GC/tiering with declared PerfMap3 and five JIT listings. One
maintained complete file-search.large,6s guest warmup/2s settle/6s wall199Hz
cpu-clock/frame-pointer capture. Job clocks3.66655s, actual guest CPU3.28s,
645guest samples/34unknown leaves; all threads/raw stacks/maps/inlining limits stay.
This is diagnostic CPU evidence, not a source-pair elapsed or speedup measurement.

| Work | Self | Inclusive | Interpretation |
| --- | ---: | ---: | --- |
| ExecuteInstructionPrefix |71|590|Dispatch, required checks and useful inlined work. |
| TryExecuteNativeCall |32|169|Includes actual native helper work. |
| GuardNativeReturn |29|Not a saved-CPU claim|Eligibility proof before effects. |
| EvaluateNativeReturn |38|66|Actual string/value execution plus routing. |
| ResolveName |29|Not a saved-CPU claim|Namespace resolution, not all binding overhead. |
| EnterInterpreterFrame |10|Overlaps callers|Managed nesting, cancellation and admission. |
| EnsureInterpreterStack |9|Overlaps callers|Supported managed stack policy. |
| EnterFunctionCall |6|Overlaps callers|Recursion, token and stack admission. |

The three named entry leaves total25/645samples (~3.88%); not all are removable,
and inlining/unknowns prevent treating this as an upper bound. Inclusive stacks
overlap and cannot be added. Repeated stack admission exists, but this capture
does not establish a dominant removable admission phase. Do not introduce a
native-only policy, split admission invariant, wider opcode hoisting, or a new
frame/dispatch backend to delete those checks. The single immediately duplicate
caller check is recorded, not promoted as a substantial redesign.

Source/census show a different actual duplication: module compiled locals contain
nine bindings but omit wanted; the loop reads its target through LoadName.
Function declarations publish with StoreName, which already updates any existing
executable local/closure slot. Ordinary assignment declarations use those slots.
Imports/classes similarly publish through prepared binding paths. Assess actual
declaration bindings using existing metadata; keep dynamic global/namespace bridges
and before-binding builtin fallback. Do not eagerly intern every dead module name
solely to force a slot, or add another scope walk/cache/framework. The source fact
justifies a bounded prototype; its CPU/allocation benefit remains unmeasured.

All core/aux/Ready/golden/funding/quiet/Closed/exit/join/fixture gates pass in B403.
Raw RAM evidence archived/verified under the collection lease, then removed and
independently verified locally.120s owner+30s stop+30s margin, observed after180s.
No active workers, fixtures or traces. Preserve the exact raw archive; Windows
extraction skips only zero-byte Linux FIFO metadata, recorded in extraction.json.

B402 first refuses setup because an inherited relative old-root guard remains;
no payload or worker starts. Corrected new-root launch then fails before sampling:
the inherited warmup permits64requests*64jobs=4096jobs, insufficient for6guest
seconds on this short script. Cleanup records owned worker exit−9, not Closed;
no sampler starts. Failed raw state is preserved under a fresh maintenance lease
after terminal failure, before removing RAM traces; original gates remain incomplete.
The initial caption mistakenly says4096single-job requests and proposes batch8.
Exact source and warmup-correction.json correct it. B403 changes only warmup to
64requests*1024jobs maximum, still stopping at6guestseconds; its sampled6s/single-job
requests, source, images and diagnostic overrides are unchanged. This is one
bounded collection-size correction, not a restart after an observation timeout
or repeated favorable retiming. Both original failed conditions remain archived.

[Decision](decision.json), [all guest chains](guest-call-chains.json),
[compile-only census](census.json), [source invariants](source-invariants.json),
[successful raw capture](b403/observations.tgz), [receipt](b403/archive-receipt.json),
[original failed capture](b402/failed-observations.tgz),
[caption/size correction](b402/warmup-correction.json),
[all commands and contracts](development.tar.xz). No runtime change, new producer,
repeated full qualification or publication. The whole-script objective stays open.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('## Priority 1 —');bpos=s.index('## Next redesign boundaries',a)
s=s[:a]+'''## Priority 1 — R49 actual declaration bindings in executable modules

R48 source/cost gate is complete: corrected B403 passes every gate, actual3.28s
guestCPU/645samples/34unknowns; raw e8be5f91 archived under lease and verified
locally. B402's original warmup failure/raw d04e53e3 and caption/size correction
remain. Named entry leaves25samples (~3.88%) do not prove dominant removable call
admission; inclusive/helper totals contain useful work. No stack/cancellation/
frame redesign or leaf-check change is selected. Do not repeat this cost gate.
Evidence: benchmarks/results/2026-11-07-helper-entry-cost/.

Demonstrated source fact: module wanted is absent from its existing local-slot
layout, so the per-line helper target uses LoadName; ResolveName has29selfsamples.
Function declarations already publish via StoreName, which updates existing frame
slots, while ordinary assignment declarations allocate slots. Assess imports and
class/type declarations through their existing binding metadata as one layout
correction. Preserve late dynamic/global namespace behavior; avoid a second walker
or new cache. Do not eagerly predeclare every dead module binding: modules need
no Python UnboundLocal rule and that would fund unused frame/map capacity.

- Hypothesis/work removed: register actual compiled declaration bindings in the
  existing slot layout; reuse ordinary load/store/frame and namespace-bridge code,
  eliminating repeated name search/hash work for common helpers/module aliases.
  Name the displaced special cases; no type/method-name-specific fast path.
- Acceptance: definitions/import aliases/classes/type parameters, decorators and
  failed definitions, before-binding builtin/global lookup, deletion/rebinding,
  globals/locals bridges, closures, annotations, dead code, actual suspension and
  error/effect order. Preserve current cancellation/first refusal and charged
  frame/program capacity, retained aliases and result cleanup. Keep measured
  native helper returns and managed stack policy unchanged.
- Validate using existing focused compiler/scope/import/namespace/cancellation/
  ownership tests. One short complete-job before/after diagnostic with search/text
  affected workloads and CSV/JSON/report controls; compile separately. Account for
  extra slot/capacity charges; static census is not a speedup. Retain/refine/withdraw
  with an explicit regression-debt decision; bounded corrections allowed when
  justified. Batch platform/stress/package checks at a retained delivery boundary.

R47/B401 closed missing file baselines: warm search1.74–1.80x (variable controls),
two-file manifest1.48–1.49x; compile-to-result both1.46–1.49x. The latter copies
only4107B/twofiles, not large-copy throughput. Current tables and evidence retain
boundaries/controls. R46 JSON kernel sharing remains withdrawn: allocation+10.5%
for40digits/~28.5times total for4096digits despite passing semantics. Source fully
restored/rebuilt; no speculative parser branch or new ownership mechanism remains.

''' +s[bpos:]
start=s.index('VM: lokad@');s=s[:start]+'''VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B403 terminal and
archived; never service-query again. B402 failed before sampling, preserved under
fresh maintenance lease; B403 corrected warmup passes all gates, raw e8be5f91
verified under collection lease and locally. No active VM users/fixtures/traces.
CI42371564043 and earlier terminal runs are cached GREEN; no active CI. Record
future owner/stop/margin before observation; never restart on observation timeout.
Retain persistent evidence and verify RAM archives before removing raw state.
Retired duplicate images have exact committed backups; restore incomplete inputs
before reuse. Producer6032b928/dev51 still has the named missing semantics above;
no new package qualification or core-development blocker inferred.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## Protected-search helper-entry cost gate (2026-11-07)\n\nR48/B403 observes645guest samples/3.28CPU seconds; entry-method leaves do not\nestablish dominant removable admission work. B402 failed warmup and exact\nbatch-size/caption correction are preserved. No runtime change; source/census\ninstead identifies missing executable module declaration slots for a bounded\ncompiler-layout investigation. [Evidence and limits](results/2026-11-07-helper-entry-cost/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R48 archived; no admission redesign selected. R49 declaration-layout milestone recorded before implementation.')
