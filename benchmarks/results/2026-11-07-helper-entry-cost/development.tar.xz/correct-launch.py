from pathlib import Path
import ast,json,shutil
r=Path(__file__).parent
assert not(r/'observe-not-before.json').exists()
shutil.copy2(r/'launch.py',r/'initial-launch.py');shutil.copy2(r/'launch.log',r/'initial-launch.log')
p=r/'launch.py';s=p.read_text(encoding='utf-8').replace("root=base/'text-cost-b396-20261107'","root=base/'call-entry-cost-b402-20261107'").replace('call-entry-cost-b402-launch.py','call-entry-cost-b402-launch-v2.py')
assert "root=base/'call-entry-cost-b402-20261107'"in s and "root=base/'text-cost-b396-20261107'"not in s
ast.parse(s);p.write_text(s,encoding='utf-8',newline='\n')
(r/'setup-correction.json').write_text(json.dumps(dict(initialCondition='Inherited launcher kept a relative old B396 directory. Its existing-root guard refused before payload extraction, worker creation or service launch.',correction='Use the new relative B402 root and a separately named immutable staged launcher. Source/images/workload/capture unchanged.',noCollectionRestarted=True),indent=2)+'\n',encoding='utf-8',newline='\n')
