from pathlib import Path
import json
r=Path(__file__).parent
s=(r.parent.parent/'csv-cost-r39/b391/analyze-chains.py').read_text(encoding='utf-8').replace('perf/csv-warm/','perf/search-warm/')
a=s.index(' print(json.dumps(');s=s[:a]
exec(compile(s,str(r/'reused-chain-analysis.py'),'exec'),{'__file__':str(r/'reused-chain-analysis.py')})
data=json.loads((r/'guest-call-chains.json').read_text(encoding='utf-8'))
short=lambda name:name.split('::')[-1].split('(')[0]
print(json.dumps(dict(samples=data['samples'],empty=data['emptyChains'],single=data['singleFrameChains'],malformed=len(data['malformedMapLines']),
    self=[(short(name),count) for name,count in data['topLeaf'][:20]],inclusive=[(short(name),count) for name,count in data['topInclusive'][:16]]),indent=2))
