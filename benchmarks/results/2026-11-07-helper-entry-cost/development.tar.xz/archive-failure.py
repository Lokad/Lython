from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/call-entry-cost-b402-20261107')
trace=Path('/dev/shm/lython-call-entry-cost-b402')
with (root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert trace.is_dir()and not trace.is_symlink()and trace.resolve()==trace and trace.parent==Path('/dev/shm')
 record=(trace/'search-warm/record.json').read_bytes();data=json.loads(record)
 assert data['exitCode']==-9 and data['verificationBefore']['status']=='Equivalent'
 with tarfile.open(root/'failed-observations.tgz','w:gz',dereference=True)as a:
  a.add(trace,arcname='perf')
  for p in root.iterdir():
   if p.is_file()and p.name!='failed-observations.tgz':a.add(p,arcname=p.name)
 with tarfile.open(root/'failed-observations.tgz')as a:assert a.extractfile('perf/search-warm/record.json').read()==record
 receipt=dict(complete=False,failure='4096 single-job warmup requests finish before the declared6second window; no sampler started.',preservation='Fresh maintenance lease after terminal collection failure; original raw RAM state archived/verified before removal. Original collection gates not complete.',workersEnded=True,fixtureDirectoriesRemoved=True,recordedWorkerExit=-9,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest())
 (root/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n')
 shutil.rmtree(trace)
 print(json.dumps(receipt),flush=True)
'''
done=subprocess.run(ssh+['timeout 45s python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'failure-preservation.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr;print(done.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-observations.tgz','failed-archive-receipt.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/call-entry-cost-b402-20261107/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads((r/'failed-archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print('B402 failed warmup preserved independently; no workers, fixtures or raw RAM traces remain. Never service-query again.')
