from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/call-entry-cost-b403-20261107')
assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
records=[]
for case in ['search-warm']:
 record=json.loads((Path('/dev/shm/lython-call-entry-cost-b403')/case/'record.json').read_text())
 assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert (Path('/dev/shm/lython-call-entry-cost-b403')/case/'worker.stderr').stat().st_size==0
 assert record['verificationBefore']['status']=='Equivalent' and record['verificationAfter']['status']=='Equivalent'
 records.append(record)
assert sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records)<8
with tarfile.open(root/'observations.tgz','w:gz',dereference=True) as a:
 a.add('/dev/shm/lython-call-entry-cost-b403',arcname='perf')
 for p in root.rglob('*'):
  if p.is_file() and p.name!='observations.tgz' and 'candidate' not in p.relative_to(root).parts:a.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(root/'observations.tgz') as a:
 for case in ['search-warm']:assert json.loads(a.extractfile('perf/'+case+'/record.json').read())['exitCode']==0
receipt=dict(complete=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,
 capturedSeconds=sum(r['response']['elapsedTicks']/r['response']['clockFrequency'] for r in records),
 archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),performanceQualified=False)
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
