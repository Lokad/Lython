from pathlib import Path
import hashlib, json, os, statistics, subprocess

lab=Path(__file__).resolve().parent
prior=lab.with_name('starmap-known-row-capacity-20261126')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,obj:p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=read(lab/'representative.json')
for row in catalog['cases']:
    row['runAsync']=True
path=lab/'async-allocation-catalog.json'
write(path,catalog)
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
roles={}
for role,folder,image_role in [('production',lab,'reference'),('capacity',prior,'candidate'),('direct',lab,'candidate')]:
    image=folder/(image_role+'-allocated')
    identity=read(folder/'local/identity.json')['imageFiles'][image_role]
    assert all(hashlib.sha256((image/file).read_bytes()).hexdigest()==digest for file,digest in identity.items())
    output=lab/(role+'-async-allocation.json')
    subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,path,output],
                   env=env,timeout=90,check=True)
    roles[role]=read(output)['rows']
summary=[]
for aligned in zip(*roles.values(),strict=True):
    assert len({r['id'] for r in aligned})==1
    assert all(r['asynchronous'] and r['sharedBudgetBaselineRestored'] for r in aligned)
    summary.append(dict(case=aligned[0]['id'],
        **{role:dict(bytes=statistics.median(row['allocatedBytesPerInvocation']),
                      admittedPeak=row['peakExecutionMemoryBytes'])
           for role,row in zip(roles,aligned,strict=True)}))
write(lab/'async-allocation-summary.json',summary)
print(json.dumps(summary))
