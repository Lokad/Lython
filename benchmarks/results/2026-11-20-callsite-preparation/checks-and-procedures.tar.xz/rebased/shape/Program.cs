using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags Fields = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var sources = catalog.RootElement.GetProperty("cases").EnumerateArray()
    .Select(row => (Id: row.GetProperty("id").GetString()!, Source: row.GetProperty("source").GetString()!))
    .Append(("specialized-adjacency", """
        def words(text):
            return text.upper().split()
        def trim(text):
            first, second = text.rstrip('\n').split('|')
            return first, second
        def consume(text):
            return [value for value in text.lower().rsplit()]
        print(words('one two'), trim('x|y\n'), consume('A B'))
        """));
var rows = new List<object>();
var engine = new LythonEngine();
foreach (var (id, source) in sources)
{
    using var compiled = engine.Compile(source);
    if (!compiled.IsValid) throw new InvalidOperationException(string.Join("; ", compiled.Diagnostics));
    var runner = (Delegate)typeof(LythonCompiledScript).GetField("_runner", Fields)!.GetValue(compiled)!;
    var executable = runner.Target!.GetType().GetFields(Fields)
        .Single(f => f.FieldType.Name == "ExecutableScript").GetValue(runner.Target)!;
    rows.Add(new { id, shape = Describe(Property(executable, "EntryPoint")!) });
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    rows
}));

static object? Property(object value, string name)
    => value.GetType().GetProperty(name, Fields)?.GetValue(value);

static object Describe(object code)
{
    var instructions = ((IEnumerable)Property(code, "Instructions")!).Cast<object>();
    var sites = ((IEnumerable)Property(code, "CallSites")!).Cast<object>();
    var constants = ((IEnumerable)Property(code, "Constants")!).Cast<object?>();
    return new
    {
        name = Property(code, "Name"),
        instructions = instructions.Select(instruction => instruction.GetType().GetFields(Fields)
            .Select(field => field.GetValue(instruction)?.ToString()).ToArray()).ToArray(),
        sites = sites.Select(site => new
        {
            kind = site.GetType().Name,
            arguments = ((IEnumerable)Property(site, "Arguments")!).Cast<object>()
                .Select(argument => argument.GetType().GetFields(Fields)
                    .Select(field => field.GetValue(argument)?.ToString()).ToArray()).ToArray(),
            timing = new[] { "TargetSpan", "CallSpan", "ArgumentCount", "HasReceiver", "IsPositionalOnly",
                "ConsumedByIteration", "ReturnedDirectly", "UnpackedReturnCount", "AccumulatesDictionary", "SplitPrefix" }
                .Select(name => Property(site, name)?.ToString()).ToArray()
        }).ToArray(),
        children = constants.OfType<object>().Select(value => Property(value, "CodeObject") ?? Property(value, "Body"))
            .OfType<object>().Where(value => value.GetType().Name == "ExecutableCodeObject").Select(Describe).ToArray()
    };
}
