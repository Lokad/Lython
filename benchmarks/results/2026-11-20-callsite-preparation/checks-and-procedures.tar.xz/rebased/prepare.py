from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[4]
previous = lab.parents[1] / "private-compiled-annotation-payload"
template = previous / "quiet"
donor = lab.parents[1] / "postponed-annotation-cpython/quiet"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(value):
    return hashlib.sha256(value).hexdigest()


def file_sha(p):
    return sha(p.read_bytes())


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def retirement():
    local = "benchmarks/results/2026-11-20-compiled-annotation-payload/"
    tree = "785640f8e:" + local
    names = ("compiled-annotation-payload-b1238-20261120", "compiled-annotation-payload-confirm-b1239-20261120")
    archives = {}
    for remote, subdir in zip(names, ("","confirmation/"), strict=True):
        archive = git("cat-file", "blob", tree + subdir + "observations.tgz")
        receipt = json.loads(git("cat-file", "blob", tree + subdir + "archive-receipt.json"))
        assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
        assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(archive)
        archives[f"{remote}/observations.tgz"] = sha(archive)
    canonical = local + "measured-candidate-core.dll.gz"
    image = gzip.decompress(git("cat-file", "blob", "785640f8e:" + canonical))
    assert sha(image) == load(template/"identity.json")["coreSHA256"]["candidate"]
    return dict(archives=archives, paths=[f"{r}/candidate/{core}" for r in names], bytes=len(image), links=2,
                sha256=sha(image), verifiedCanonicalGitImage=canonical)


index = load(lab / "identity.json")
assert index["reference"].startswith("785640f8e") and index["candidate"].startswith("0addc9a9c")
old = load(template / "config.json")
donor_config = load(donor / "config.json")
old_receipt = load(donor / "archive-receipt.json")
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
assert old_receipt["archiveSHA256"] == file_sha(donor / "observations.tgz")
reference_donor = donor_config["identity"]["imageFiles"]["candidate"]
protocol_sha = donor_config["cpythonWorkerSHA256"]
assert index["pythonWorkerSHA256"] == protocol_sha
manifest = lab / "representative.json"
manifest_hash = file_sha(manifest)
assert manifest_hash == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(reference_donor) == 32
    assert {name: file_sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == manifest_hash
    assert set(files) == set(reference_donor)
    assert [n for n in files if files[n] != reference_donor[n]] == ([core] if role == "candidate" else [])
jobs = [("scripts.config-generated-guards.medium","compile"),
        ("scripts.config-generated-guards.medium","compile-run"),
        ("scripts.config-manifest.helper-guards","compile-run"),
        ("scripts.report-forwarding.expanded","warm")]
assert {case for case, _ in jobs} <= {row["id"] for row in load(manifest)["cases"]}

root = "/home/lokad/lython-bench-checks/callsite-preparation-b1241-20261120"
unit = "lython-b1241-callsite-preparation-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Consolidate call-site metadata into the operand-forwarding traversal",
                catalogSHA256=manifest_hash, imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    text = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = text.index("\njobs = ")
        end = text.index("\nassert len(jobs)", start)
        text = text[:start] + "\njobs = " + repr(jobs) + text[end:]
        text = text.replace("accumulate 15 seconds","accumulate 12 seconds").replace("warmupSeconds=15","warmupSeconds=12")
        text = text.replace("min(warmed)<15","min(warmed)<12").replace("warmed[i]>=15","warmed[i]>=12")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
(q / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, q / "candidate" / core)
shutil.copyfile(manifest, q / "representative.json")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh",
         "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for part in parts:
        archive.add(q / part, arcname=part)
retirements = [retirement()]
config = dict(root=root, unit=unit, source=donor_config["root"], sourceRole="candidate", sourceFiles=reference_donor,
              sourceCatalogSHA256=donor_config["catalogSHA256"], protocolSHA256=protocol_sha, catalogSHA256=manifest_hash,
              identity=identity, retireGroups=retirements, donorArchiveSHA256=old_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1238-fixtures", "lython-b1241-fixtures")
content = content.replace("  assert sha(b/proof['archivePath'])==proof['canonicalArchiveSHA256']",
                          "  for name,h in proof['archives'].items():assert sha(b/name)==h,name")
assert "+64*1024*1024" in content and "proof['archives']" in content
emit(q / "remote-launch.py", content)
emit(lab / "launch.py", read(previous / "launch.py").replace("seconds=370", "seconds=328")
     .replace("Annotation payload comparison", "Call-site preparation comparison").replace("370 seconds", "328 seconds"))
emit(lab / "summarize.py", read(previous / "summarize.py"))
print("Prepared compile, compile-to-result and warm lanes for the exact call-site images.")
