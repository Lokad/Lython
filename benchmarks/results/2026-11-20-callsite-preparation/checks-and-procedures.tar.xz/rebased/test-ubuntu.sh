set -eu
root=$PWD
lab=$root/.git/agent-notes/review-20261031/private-callsite-preparation/rebased
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd "$root/.git/agent-worktrees/private-callsite-preparation"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 -p:RestoreLockedMode=true --filter 'Category!=Stress&(FullyQualifiedName~Split|FullyQualifiedName~Operand|FullyQualifiedName~Unpack|FullyQualifiedName~NativeReturn|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~ReturnedIteration|FullyQualifiedName~CompilerCancellation)' >"$log" 2>&1 || { tail -n 50 "$log"; exit 1; }
    tail -n 6 "$log"
done
