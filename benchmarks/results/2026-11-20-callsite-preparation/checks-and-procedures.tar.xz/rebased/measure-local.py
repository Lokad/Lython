from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
initial = lab.parent
notes = initial.parent
repo = lab.parents[4]
trial = repo / ".git/agent-worktrees/private-callsite-preparation"
prior = notes / "postponed-annotation-cpython"
core = "Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])


def load(p):
    return json.loads(p.read_text(encoding="utf-8"))


def save(p, v):
    p.write_text(json.dumps(v, indent=2) + "\n", encoding="utf-8", newline="\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def h(p):
    return sha(p.read_bytes())


def git(*args, directory=repo):
    return subprocess.check_output(["git", *args], cwd=directory)


reference = git("rev-parse", "HEAD^", directory=trial).decode().strip()
candidate = git("rev-parse", "HEAD", directory=trial).decode().strip()
assert reference.startswith("785640f8e") and candidate.startswith("0addc9a9c")
assert not git("status", "--porcelain", directory=trial)
identity = load(prior / "quiet/identity.json")
assert identity["sourceRevision"] == reference
reference_image = prior / "frozen/candidate"
old = identity["imageFiles"]["candidate"]
assert len(old) == 32 and {n: h(reference_image / n) for n in old} == old
manifest = lab / "representative.json"
shutil.copyfile(initial/"representative.json",manifest)

protocol = repo / "benchmarks/cpython-worker.py"
probe = notes / "borrow-lexical-builder-r625/compile-allocation/bin/Release/net11.0"
frozen = {}
for role in ("reference","candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True)
    for name in old:
        origin = trial / "src/Lokad.Lython/bin/Release/net11.0" / name if role=="candidate" and name==core else reference_image/name
        shutil.copyfile(origin,image/name)
    files = {n:h(image/n) for n in old}
    verified = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
        "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol, "--out", verified],
        check=True, env=env, timeout=100)
    assert load(verified)["state"] == "Completed" and load(verified)["catalogSha256"] == h(manifest)
    for file in probe.glob("CompileAllocation.*"):
        shutil.copyfile(file,image/file.name)
    result=subprocess.check_output([dotnet,image/"CompileAllocation.dll",manifest],env=env,timeout=100)
    (lab/f"{role}-compile-allocation.json").write_bytes(result)
    assert json.loads(result)["coreSha256"]==files[core] and {n:h(image/n) for n in old}==files
    frozen[role]=files
assert [n for n in old if frozen["reference"][n]!=frozen["candidate"][n]]==[core]
save(lab/"identity.json",dict(reference=reference,candidate=candidate,catalogSHA256=h(manifest),
    imageFiles=frozen,pythonWorkerSHA256=h(protocol)))
left,right=(load(lab/f"{role}-compile-allocation.json")["rows"] for role in ("reference","candidate"))
rows=[]
for a,b in zip(left,right,strict=True):
    assert a["id"]==b["id"]
    x,y=(statistics.median(item["bytes"]) for item in (a,b))
    rows.append(dict(case=a["id"],previousAllocatedBytes=x,candidateAllocatedBytes=y,allocationChangePercent=100*(y/x-1)))
    print(a["id"], x, y, round(100*(y/x-1),3))
save(lab/"compile-allocation-summary.json",rows)
