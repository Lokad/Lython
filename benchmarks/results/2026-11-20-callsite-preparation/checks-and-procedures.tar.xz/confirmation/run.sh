set -eu
root=/home/lokad/lython-bench-checks/callsite-preparation-confirm-b1242-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
