from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-inline-private-generator-slots'
initial = lab.parent / 'inline-private-generator-b1975-20261128'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

for root, count in ((initial, 84), (lab, 56)):
    pair = root / 'comparison'
    quiet = pair / 'quiet'
    identity = read(quiet / 'identity.json')
    assert identity['sourcePatchSHA256'] == digest(root / 'candidate.patch')
    assert identity['imageFiles'] == read(pair / 'identity.json')['imageFiles']
    for role, files in identity['imageFiles'].items():
        assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
        assert read(pair / f'{role}-verify.json')['caseCount'] == 6
    summary = read(quiet / 'summary.json')
    assert summary['verifiedTimedBatches'] == count and summary['quietGates']
    receipt = read(quiet / 'archive-receipt.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
    allocation = read(root / 'allocation/summary.json')
    admission = read(root / 'admission/summary.json')
    assert len(allocation) == len(admission) == 12
    assert all(row['compiled'][0] == row['compiled'][1] and row['admittedPeak'][0] == row['admittedPeak'][1] for row in allocation)
    assert all(row['requests'][0] == row['requests'][1] and row['peak'][0] == row['peak'][1] for row in admission)
    for row in allocation:
        difference = row['clr'][0] - row['clr'][1]
        if row['case'] in ('diagnostic.shipment-row-generator-reduction', 'diagnostic.shipment-row-list-generator-reduction'):
            assert 278_000 < difference < 279_000
        elif 'aliases' in row['case']:
            assert difference == 0
        else:
            assert abs(difference) < 256

for target in ('windows-net10.0', 'windows-net11.0', 'ubuntu-net11.0'):
    for suite, count in (('public', 415), ('whitebox', 41)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')
assert 'Failed:     0, Passed:     4' in (lab / 'power-reference.log').read_text(encoding='utf-8')
assert 'Failed:     2, Passed:     2' in (lab / 'power-candidate.log').read_text(encoding='utf-8')
assert 'Failed:     0, Passed:    23' in (lab / 'final-native-tests.log').read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
public = {}
procedures = {}
for root, tag in ((initial, 'initial-'), (lab, '')):
    pair = root / 'comparison'
    quiet = pair / 'quiet'
    for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
        public[tag + name] = quiet / name
    for category in ('allocation', 'admission'):
        public[f'{tag}{category}-summary.json'] = root / category / 'summary.json'
        procedures.update({f'{tag}{category}/{path.name}': path for path in (root / category).glob('*.json')})
    procedures.update({tag + path.name: path for path in root.iterdir()
                       if path.is_file() and path.suffix in ('.log', '.py', '.patch', '.sh', '.json', '.txt')})
    for folder, location in ((pair, 'local'), (quiet, 'quiet')):
        procedures.update({f'{tag}{location}/{path.name}': path for path in folder.iterdir() if path.name.endswith('-verify.json')})
    for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log'):
        procedures[f'{tag}quiet/{name}'] = quiet / name
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
               for name, path in procedures.items())
print('Verified six focused suites, continued reduction regression and 140 quiet timed batches.')