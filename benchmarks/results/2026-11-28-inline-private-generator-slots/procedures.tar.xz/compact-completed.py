from hashlib import sha256
from pathlib import Path
import json
import shlex
import subprocess

lab = Path(__file__).resolve().parent
root = lab.parent
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
upload = read(lab / 'comparison/quiet/upload.json')
minimum = upload['expandedBytes'] + upload['minimumAfterStageBytes'] + 400_000
initial = root / 'inline-private-generator-b1975-20261128/comparison/quiet'
receipt = read(initial / 'archive-receipt.json')
terminal = read(initial / 'terminal-status.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[k] for k in ('complete', 'allWorkersJoined', 'archivedAndVerifiedUnderLease'))
assert digest(initial / 'observations.tar.xz') == receipt['archiveSHA256']
identity = read(initial / 'identity.json')
request = [[dict(root=read(initial / 'upload.json')['root'], unit='lython-b1975-inline-generator',
   role='candidate', archiveSHA256=receipt['archiveSHA256'],
   coreSHA256=identity['imageFiles']['candidate']['Lokad.Lython.dll'])]]

remote = f'groups={request!r}\nminimum={minimum}\n' + r'''
from hashlib import sha256
from pathlib import Path
import fcntl, gzip, json, os, shutil, subprocess

base = Path('/home/lokad/lython-bench-checks')
digest = lambda path: sha256(path.read_bytes()).hexdigest()
assert base.resolve() == base
with (base / 'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    initial = shutil.disk_usage(base).free
    packed = []
    assert not any(path.is_mount() for path in base.glob('*/guest-fixtures'))
    for rows in groups:
        if shutil.disk_usage(base).free >= minimum:
            break
        locations = []
        for row in rows:
            root = base / row['root']
            origin = root / row['role'] / 'Lokad.Lython.dll'
            assert root.parent == base and root.resolve() == root and origin.resolve() == origin
            assert (root / 'exit-code.txt').read_text().strip() == '0' and not (root / 'guest-fixtures').exists()
            state = subprocess.check_output(['systemctl', 'show', row['unit'] + '.service',
                '--property=ActiveState,Result'], text=True).splitlines()
            assert 'ActiveState=inactive' in state and 'Result=success' in state
            receipt = json.loads((root / 'archive-receipt.json').read_bytes())
            assert receipt['complete'] and receipt['allWorkersJoined']
            assert digest(root / 'observations.tar.xz') == receipt['archiveSHA256'] == row['archiveSHA256']
            assert digest(origin) == row['coreSHA256']
            locations.append(origin)
        first = locations[0]
        assert first.stat().st_nlink == len(locations)
        assert all(p.samefile(first) for p in locations)
        backup = first.parent.parent / ('packed-' + rows[0]['role'] + '-core.dll.gz')
        length = first.stat().st_size
        with first.open('rb') as source, backup.open('xb') as target:
            with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as compressed:
                shutil.copyfileobj(source, compressed)
            target.flush()
            os.fsync(target.fileno())
        with gzip.open(backup, 'rb') as stored:
            assert sha256(stored.read()).hexdigest() == rows[0]['coreSHA256']
        assert backup.stat().st_size < length
        record = dict(rows=rows, path=str(backup.relative_to(base)), originalBytes=length,
                      compressedBytes=backup.stat().st_size, compressedSHA256=digest(backup))
        for row, origin in zip(rows, locations, strict=True):
            root = origin.parent.parent
            with (root / (row['role'] + '-compaction.json')).open('x', encoding='utf-8') as report:
                json.dump(record, report, indent=2)
                report.write('\n')
                report.flush()
                os.fsync(report.fileno())
            directory = os.open(root, os.O_DIRECTORY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        for origin in locations:
            origin.unlink()
        packed.append(record)
    print(json.dumps(dict(before=initial, after=shutil.disk_usage(base).free, required=minimum, packed=packed)))
'''
compile(remote, '<completed VM storage compaction>', 'exec')
result = subprocess.check_output(['ssh', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'ConnectTimeout=12',
    '-o', 'StrictHostKeyChecking=yes', 'lokad@20.166.121.73', 'python3 -c ' + shlex.quote(remote)], timeout=45)
record = json.loads(result)
(lab / 'compaction.json').write_bytes(result)
assert record['after'] >= minimum, record
print({key: value for key, value in record.items() if key != 'packed'}, len(record['packed']))