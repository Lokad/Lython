#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/inline-private-generator-continue-b1975-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~GeneratorExecution|FullyQualifiedName~Iteration|FullyQualifiedName~StackProtection|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11.0-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~ExecutableIteratorCleanup|FullyQualifiedName~IterationCancellation|FullyQualifiedName~RangeIterationState|FullyQualifiedName~IteratorValueAccounting)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1
