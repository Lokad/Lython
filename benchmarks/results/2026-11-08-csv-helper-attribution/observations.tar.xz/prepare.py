from pathlib import Path
import ast,hashlib,json,math,shutil,tarfile

r=Path(__file__).resolve().parent
old=r.parent/'ordinary-helper-r84';delivery=r.parent/'receiver-contract-r85'
source=json.loads((delivery/'fixed-arity/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
head=__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='02c76e52d1dc3e5222b67ab74bba5b27d46c80ed'
d=json.loads((delivery/'fixed-arity/catalog.json').read_text(encoding='utf-8'))
d['cases']=[c for c in d['cases']if c['id']=='scripts.csv-summary-functions.large'];assert len(d['cases'])==1
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=json.loads((delivery/'b448/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((delivery/'b448/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(delivery/'b448/observations.tgz')as a:
 assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==source['coreSHA256']['candidate']
proof=dict(vmArchive='receiver-contract-b448-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=source['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-receiver-contract/observations.tar.xz (nested VM archive)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
prioridentity=json.loads((delivery/'b448/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=head,files={'Lokad.Lython.dll':proof['coreSHA256']},auxiliaryFiles=prioridentity['auxiliaryFiles'],productionSources=source['productionSources'],qualification='373internal/2046public Release per actual.NET11/10 pass; full delivery CI42457767068 running independently.',purpose='One bounded complete CSV-helper CPU attribution; diagnostic settings, no normal-settings timing or source-pair speedup claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_text('Committed production02c76e52; exact inventory matches measured coreaa4acebe.\n',encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
contract='''R86: complete CSV-helper construction/call/operand attribution.
One existing six-second199Hz CPU-clock/FP profile of committed02c76e52/coreaa4acebe,
synchronous complete CSV helper workload, six guest-second warmup and two-second
settle. PerfMap/JIT listings are diagnostic only; no normal-settings timing or
causal/source-pair improvement claim. Preserve exact sources/auxiliary/Ready,
full stdout/files goldens, actual guest denominator, unknowns, raw stacks/maps,
quiet snapshots, Closed/exit/join/fixture/archive proofs.120s owner+30stop+30margin.
Reuse immutable B448 core/archive; no duplicate core or deletion of old evidence.
Persistent working data, owned128MiB RAM fixtures/maps copied and verified before
unmount.240MiB OSfloor and8MiB trace/archive headroom, historical size check first.
Stop at a demonstrated complete removable phase or explicit insufficient evidence.
No new binder arena/control carrier/value representation/memory subsystem or
text-fusion dispatch route from speculation. Keep cancellation, admission, aliases
and cleanup intact. Publication remains postponed; CI runs independently.
'''
for name in ['selection.md','contract.md']:(r/name).write_text(contract,encoding='utf-8')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('ordinary-helper-cost-b447','csv-cost-b449').replace('lython-b447-ordinary-helper-cost','lython-b449-csv-cost').replace('lython-b447','lython-b449')
 s=s.replace('scripts.text-summary-rsplit-helpers.large','scripts.csv-summary-functions.large')
 if name=='launch.py':s=s.replace('combined-cpython-b446-20261108/candidate','receiver-contract-b448-20261108/candidate')
 if name=='archive.py':s=s.replace('immutable B446','immutable B448')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
raw=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved').rglob('*')if p.is_file())
estimate=math.ceil((raw-(old/'catalog.json').stat().st_size+(r/'catalog.json').stat().st_size+(old/'observations.tgz').stat().st_size)*1.25)
assert estimate<8*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,newCatalogBytes=(r/'catalog.json').stat().st_size,conservativeTraceArchiveEstimateBytes=estimate,reservedHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024,noEvidenceDeleted=True,archivedCoreReused=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/name,arcname=name)
print('R86 prepared: committed exact source/core; one complete CSV helper capture; historical trace/archive headroom verified; immutable B448 core reused.')
