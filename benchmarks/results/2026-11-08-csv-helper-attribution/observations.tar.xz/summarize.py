from pathlib import Path
import bisect,collections,hashlib,json,re
r=Path(__file__).resolve().parent;f=r/'retrieved/profiles/text-warm'
record=json.loads((f/'record.json').read_text(encoding='utf-8'))
known=json.loads((f/'guest-cpu-leaves.json').read_text(encoding='utf-8'))
guest=set(record['guestTids']);ranges=[]
for line in (f/'perf.map').read_text(encoding='utf-8').splitlines():
 start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))
ranges.sort();starts=[a for a,b,c in ranges]
leaves=collections.Counter();inclusive=collections.Counter();stacks=[]
for block in (f/'perf-stacks.txt').read_text(encoding='utf-8').strip().split('\n\n'):
 lines=block.splitlines();m=re.match(r'\s*(\d+)/(\d+)',lines[0])
 if not m or m[2]not in guest:continue
 stack=[]
 for line in lines[1:]:
  m=re.match(r'\s*([0-9a-f]+)\s+(.*)',line)
  if not m:continue
  address=int(m[1],16);i=bisect.bisect_right(starts,address)-1;symbol=m[2]
  if i>=0 and address<ranges[i][0]+ranges[i][1]:symbol=ranges[i][2]
  stack.append(symbol)
 if stack:
  leaves[stack[0]]+=1;inclusive.update(set(stack));stacks.append(stack)
assert leaves.total()==known['samples'],(leaves.total(),known['samples'])
phasePatterns={
 'csv-parser':r'CsvRecordParser::',
 'record-adoption':r'RecordKeys::TryAdoptRecord',
 'binding-and-work-construction':r'::BindPositionalFunctionArguments|::CreateExecutableWorkState|::RentFunctionArgumentStorage',
 'numeric-normalization-and-comparison':r'PyNumberOps::TryAsNumber|::EvaluateRichComparison|::AreEqualWithProtocols',
 'integer-parsing':r'::ParseIntegerUtf8',
 'memory-governor':r'MemoryGovernor::',
}
phases={name:dict(selfSamples=sum(n for name2,n in leaves.items()if re.search(pattern,name2)),inclusiveSamples=sum(any(re.search(pattern,n)for n in s)for s in stacks))for name,pattern in phasePatterns.items()}
d=dict(sourceRevision='02c76e52',coreSHA256=json.loads((r/'core-source.json').read_text(encoding='utf-8'))['coreSHA256'],samples=len(stacks),cpuSeconds=known['cpuSeconds'],unknown=known['unknown'],phases=phases,leafSamples=leaves.most_common(),inclusiveSamples=inclusive.most_common(),limitations='Diagnostic settings only. Self shares exclude callees; inclusive shares overlap and include inlined work. No source-pair attribution or normal-settings speedup claim.')
(r/'derived-attribution.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:d[k]for k in ['sourceRevision','samples','cpuSeconds','unknown','phases','limitations']},indent=2))
