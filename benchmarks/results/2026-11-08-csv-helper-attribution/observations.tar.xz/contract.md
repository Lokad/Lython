R86: complete CSV-helper construction/call/operand attribution.
One existing six-second199Hz CPU-clock/FP profile of committed02c76e52/coreaa4acebe,
synchronous complete CSV helper workload, six guest-second warmup and two-second
settle. PerfMap/JIT listings are diagnostic only; no normal-settings timing or
causal/source-pair improvement claim. Preserve exact sources/auxiliary/Ready,
full stdout/files goldens, actual guest denominator, unknowns, raw stacks/maps,
quiet snapshots, Closed/exit/join/fixture/archive proofs.120s owner+30stop+30margin.
Reuse immutable B448 core/archive; no duplicate core or deletion of old evidence.
Persistent working data, owned128MiB RAM fixtures/maps copied and verified before
unmount.240MiB OSfloor and8MiB trace/archive headroom, historical size check first.
Stop at a demonstrated complete removable phase or explicit insufficient evidence.
No new binder arena/control carrier/value representation/memory subsystem or
text-fusion dispatch route from speculation. Keep cancellation, admission, aliases
and cleanup intact. Publication remains postponed; CI runs independently.
