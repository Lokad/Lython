from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
start=s.index('| Milestone | Delivery / measurement status |')
end=s.index('Latest fully qualified runtime',start)
s=s[:start]+'''| Milestone | Actual status |
| --- | --- |
| Compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed/fully qualified. Native returns allocation−19.92/−19.31%, original elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original15.125ms adverse remains unexplained/preserved. No unchanged qualification replay. |
| Retained R62–R76 | Fully qualified; history preserves70267889,824fc6bb,7a81a629,f88191f7+a34f56b5,68d5bffe,33b6c191,79657355+c384956f,38f53c33/06651b11. Compiler facts/native calls/sequence/tuple storage, JSON floats, inline/final UTF-8 storage remain. R71 slower arenas/control/wide carriers, R72 coarseCPU+6.67%, R74 drift and all failed/adverse conditions remain evidence, not current performance claims. |
| R78/R79 | Fully qualified af481194+5b9d569a and913ea550: shared receiver declarations, callback/signature correctness fixes, native workstate before lexical contexts. Existing measured function optimizations preserved. Cached full-delivery receipts; details in EXPERIMENTS/results. |
| R80/R81 attribution; R82 prepared consumers | Attribution/source gates completed71445454; no unsupported namespace/value/accounting redesign selected. R82 production91f15a3e fully qualified CI42451722109; source consistency retained, allocation neutral, modest/mixed elapsed. |
| R77/R83 CPython checkpoints | Guides accurately identify measured38f53c33 and latest91f15a3e, not today's HEAD. Latest B446:26jobs539.117s; compile/warm/compile-to-result and I/O/validation/prior cleanup separated. Ordinary helper warm2.12–2.23×CPython remains a substantial gap. Original failures/uncertainty preserved. |
| R84/R85 | Attribution complete; canonical receiver consolidation committed/pushed02c76e52, exact measured coreaa4acebe.373internal/2046public per actual11/10 pass. B448 affected allocation45–52%lower/elapsed22–24%lower; controls/debt explicit below. Full delivery CI42457767068 running; not yet fully qualified. |
| Regex R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only. Normal optional0.4 pin/core unchanged; affected final released adapter qualification pending, independent implementation continues. |

Completed milestones and original evidence remain in benchmarks/EXPERIMENTS.md
and linked results; the table is delivery status, not a replay queue.
''' + s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('PLAN condensed around actual delivery status, active source attribution, coherent redesign boundaries and independent regex; completed evidence retained by explicit references.')
