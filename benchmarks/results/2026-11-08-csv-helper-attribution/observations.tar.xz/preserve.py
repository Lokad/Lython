from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-08-csv-helper-attribution');out.mkdir(exist_ok=True)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
shutil.copyfile(r/'derived-attribution.json',out/'assessment.json')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name!='payload.tgz':a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256((r/m.name).read_bytes()).digest()
print('R86 full original trace/raw/JIT/map/unknown evidence and locally verified receipt preserved:',(out/'observations.tar.xz').stat().st_size)
