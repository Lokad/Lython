from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys
r=Path(__file__).parent;out=r/(sys.argv[1]if len(sys.argv)>1 else'attempt1');out.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
selection='Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Scope|FullyQualifiedName~Closure|FullyQualifiedName~Namespace|FullyQualifiedName~Global|FullyQualifiedName~Import|FullyQualifiedName~Declaration|FullyQualifiedName~Function|FullyQualifiedName~Cancellation|FullyQualifiedName~Refusal|FullyQualifiedName~SharedMemory|FullyQualifiedName~TerminalAdmission)'
jobs=[('Lokad.Lython.PublicApi.Tests','net11.0','FullyQualifiedName~DeclarationNamespaceTests')]+[(p,t,selection)for t in ['net11.0','net10.0']for p in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']]
checks={}
for index,(project,target,chosen)in enumerate(jobs):
 name=str(index)+'-'+project+'-'+target+'.log'
 with(out/name).open('w',encoding='utf-8')as log:
  d=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',target,'--nologo','--filter',chosen,'--logger','console;verbosity=normal','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/name).read_text(encoding='utf-8');checks[name]=dict(exitCode=d.returncode,selection=chosen,tail=text[-3500:])
 print(name,'exit',d.returncode,'\n'+'\n'.join(text.splitlines()[-7:]),flush=True)
 if d.returncode:
  (out/'failed-focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n');raise SystemExit(d.returncode)
 if index in [2,4]:
  folder=out/target;folder.mkdir();shutil.copy2('src/Lokad.Lython/bin/Release/'+target+'/Lokad.Lython.dll',folder/'Lokad.Lython.dll')
identity=dict(checks=checks,coreSHA256={t:hashlib.sha256((out/t/'Lokad.Lython.dll').read_bytes()).hexdigest()for t in ['net11.0','net10.0']},productionSources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(s in p.parts for s in ['bin','obj'])},fullDeliveryPending=True)
(out/'focused.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');print('Focused current source/images frozen; no full/platform/package claim.',flush=True)
