from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).parent;records=json.loads((r/'semantic-goldens.json').read_text(encoding='utf-8'))
before=[json.loads(s)for s in(r/'baseline-probes.ndjson').read_text(encoding='utf-8').splitlines()]
assert len(before)==len(records)and all(x['Lython']['Success']and x['Lython']['StandardOutput']==c['stdout']for x,c in zip(before,records))
extra="def chosen(): return 1\nview=globals()\nit=None\nit=iter(view)\ndef chosen(): return 2\nprint(chosen(),len(list(it))>0)\n"
done=subprocess.run([sys.executable,'-I','-S','-X','utf8','-c',extra],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0 and not done.stderr,done.stderr
records.append(dict(name='replacement_preserves_key_iterator',source=extra,stdout=done.stdout,cpython=sys.version))
(r/'semantic-goldens.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll')
restored=json.loads(Path('benchmarks/results/2026-11-07-json-integer-source-gate/restored-build.json').read_text(encoding='utf-8'))
assert hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest()==restored['cores']['net11.0']
done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json'],input=json.dumps([c['source']for c in records]),env=env,capture_output=True,text=True,encoding='utf-8')
(r/'baseline-final-probes.ndjson').write_text(done.stdout,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
before=[json.loads(s)for s in done.stdout.splitlines()];assert len(before)==7 and all(x['Lython']['Success']and x['Lython']['StandardOutput']==c['stdout']for x,c in zip(before,records))
s='using Lokad.Lython.Tests.Harness;\n\nnamespace Lokad.Lython.PublicApi.Tests;\n\npublic sealed class DeclarationNamespaceTests\n{\n    // Frozen isolated CPython 3.13 output; each case also passes the preceding runtime.\n    public static IEnumerable<object[]> Cases()\n    {\n'
for case in records:s+='        yield return ['+json.dumps(case['name'])+', """\n'+case['source']+'""", '+json.dumps(case['stdout'])+'];\n'
s+='''    }

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task DeclarationsKeepTheLivePythonNamespace(string name, string source, string expected)
    {
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, name + ": " + string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true, false })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, name + ": " + result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''
Path('tests/Lokad.Lython.PublicApi.Tests/DeclarationNamespaceTests.cs').write_text(s,encoding='utf-8',newline='\n')
print('Seven CPython/baseline-checked semantic cases generated; both APIs and owner reuse covered.')
