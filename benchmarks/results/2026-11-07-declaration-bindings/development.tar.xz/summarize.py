from pathlib import Path
r=Path(__file__).parent;s=(r.parent/'integer-utf8-r45/summarize-local.py').read_text(encoding='utf-8')
exec(compile(s,str(r/'summarize-local.py'),'exec'),{'__file__':str(r/'summarize-local.py')})
