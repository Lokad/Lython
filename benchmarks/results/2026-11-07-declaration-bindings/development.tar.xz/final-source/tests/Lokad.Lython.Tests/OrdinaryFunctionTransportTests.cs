using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;

namespace Lokad.Lython.Tests;

public sealed class OrdinaryFunctionTransportTests
{
    public static TheoryData<int, bool> Calls => new()
    { { 0, false }, { 0, true }, { 1, false }, { 1, true }, { 2, false }, { 2, true }, { 3, false }, { 3, true } };

    [Theory]
    [MemberData(nameof(Calls))]
    public async Task OrdinaryCallsPreserveBodyEffectsAndUnwind(int shape, bool asynchronous)
    {
        var (definitionSource, callSource) = shape switch
        {
            0 => ("def f(value,offset=1):\n stamp(value)\n return value", "return f(value,offset=2)"),
            1 => ("def f(value,*,offset=1):\n stamp(value)\n return value", "return f(value)"),
            2 => ("class Box:\n def f(self,value,*,offset=1):\n  stamp(value)\n  return value\nf=Box().f", "return f(value,offset=2)"),
            _ => ("def f(value,*args,offset=1,**kwargs):\n stamp(value)\n return value", "return f(value,3,tag=4)")
        };
        var definition = Compile(definitionSource);
        var call = Compile(callSource);
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        string[] effects;
        using (var owner = budget.CreateScope())
        {
            var (context, value, tape) = await Prepare(owner);
            Assert.Same(value, await Run(call, context));
            effects = tape.Events.ToArray();
            Assert.Single(effects);
            Check(context);
        }
        Assert.Equal(0, budget.ReservedBytes);
        async ValueTask<(Context, PyString, Effects)> Prepare(ILythonMemoryBudget owner)
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions
            { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
            var value = PyString.FromString("owned", context.MemoryGovernor, null);
            var tape = new Effects(value);
            context.Variables["value"] = value;
            context.Variables["stamp"] = tape;
            await Run(definition, context);
            return (context, value, tape);
        }
        async ValueTask<object?> Run(ExecutableCodeObject code, Context context) => asynchronous
            ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
            : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
    }

    private static ExecutableCodeObject Compile(string source)
        => ExecutableScript.Compile(LoweredScript.Lower(LythonFrontend.Compile(source,regexProvider:Utf8RegexProvider.Instance).Script!)).EntryPoint;

    [Theory]
    [InlineData(false, "success")]
    [InlineData(true, "success")]
    [InlineData(false, "cancel")]
    [InlineData(true, "cancel")]
    [InlineData(false, "admission")]
    [InlineData(true, "admission")]
    public async Task KeywordDefaultProtocolsKeepOwnedInputsUntilCompletion(bool bound, string route)
    {
        const string key = "class Key:\n def __hash__(self):return hash('value')\n def __eq__(self,other):\n  tap()\n  return other=='value'\n";
        var definitionSource = key + (bound
            ? "class Box:\n def method(self,arg,*,value):\n  first=value\n  second=first\n  third=second\n  body()\n  return third\nBox.method.__kwdefaults__={Key():payload}\nf=Box().method"
            : "def f(arg,*,value):\n first=value\n second=first\n third=second\n body()\n return third\nf.__kwdefaults__={Key():payload}");
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        using var cancellation = new CancellationTokenSource();
        var context = new Context(new MockLythonHost(), new LythonRunOptions
        { MemoryBudget = owner, CancellationToken = cancellation.Token },regexProvider:Utf8RegexProvider.Instance);
        var argument = PyString.FromString("argument", context.MemoryGovernor, null);
        var payload = PyString.FromString("payload", context.MemoryGovernor, null);
        var tap = new SuspendedDefault();
        var effects = new List<string>();
        context.Variables["argument"] = argument;
        context.Variables["payload"] = payload;
        context.Variables["tap"] = tap;
        context.Variables["body"] = new Body(effects);
        await LythonRuntime.ExecuteExecutableCodeObjectAsync(Compile(definitionSource), context);
        var baseline = budget.ReservedBytes;
        var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(Compile("return f(arg=argument)"), context).AsTask();
        var origin = new LythonSourceSpan(1000, 5, 50, 1);
        try
        {
            var first = await Task.WhenAny(tap.Entered.Task, pending).WaitAsync(TimeSpan.FromSeconds(5));
            Assert.Same(tap.Entered.Task, first);
            Assert.False(pending.IsCompleted);
            Assert.False(tap.Finished);
            Assert.Empty(effects);
            Assert.True(budget.ReservedBytes >= baseline);
            if (route == "cancel") cancellation.Cancel();
            if (route == "admission")
            {
                var governor = context.MemoryGovernor;
                _ = Assert.Throws<LythonRuntimeException>(() => governor.Reserve(
                    budget.LimitBytes!.Value - governor.CurrentAccountedBytes + 1, origin));
            }
        }
        finally
        {
            tap.Release.TrySetResult();
            try { await pending.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch (LythonRuntimeException) when (route != "success") { }
        }
        if (route == "success")
        {
            Assert.Same(payload, await pending);
            Assert.Single(effects);
        }
        else
        {
            var failure = await Assert.ThrowsAsync<LythonRuntimeException>(() => pending);
            Assert.Equal(route == "cancel" ? LythonFailureReason.Cancelled : LythonFailureReason.SharedMemoryAllowance,
                failure.Attribution?.Reason);
            if (route == "admission")
            {
                Assert.Same(context.MemoryGovernor.AdmissionFailure, failure);
                Assert.Same(origin, failure.Span);
            }
            Assert.Empty(effects);
        }
        Assert.True(tap.Finished);
        Assert.Equal(1, tap.Calls);
        Assert.Equal("argument", argument.AsString());
        Assert.Equal("payload", payload.AsString());
        Check(context);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    private sealed class Body(List<string> events) : LythonRuntime.ICallable
    {
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        { events.Add("body"); return PyNone.Instance; }
    }

    private sealed class SuspendedDefault : LythonRuntime.ICallable
    {
        internal int Calls;
        internal bool Finished;
        internal TaskCompletionSource Entered = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource Release = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
            => throw new InvalidOperationException("Expected an asynchronous default-key protocol.");
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            Calls++;
            Entered.TrySetResult();
            try { await Release.Task.ConfigureAwait(false); return PyNone.Instance; }
            finally { Finished = true; }
        }
    }

    private static void Check(Context context)
    {
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private sealed class Effects(object expected) : LythonRuntime.ICallable
    {
        internal List<string> Events { get; } = [];
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            Assert.Same(expected, Assert.Single(arguments).Value);
            Events.Add($"body:{context.State.CurrentInterpreterDepth},{context.State.CurrentRecursionDepth},{context.MemoryGovernor.CurrentReservedBytes}");
            return PyNone.Instance;
        }
    }
}
