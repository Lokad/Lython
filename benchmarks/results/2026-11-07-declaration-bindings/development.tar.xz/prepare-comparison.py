from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;home=r.parent;old=home/'integer-utf8-r45'
focused=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'))
for name,digest in focused['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
baseline=json.loads((r/'before.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'before-core.dll').read_bytes()).hexdigest()==baseline['coreSHA256']
for role,core in [('before',r/'before-core.dll'),('candidate',r/'attempt2/net11.0/Lokad.Lython.dll')]:
 target=r/'images'/role;shutil.copytree(old/'images/before',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink();shutil.copy2(core,target/'Lokad.Lython.dll')
catalog=json.loads((home/'delivery-comparison-b400/representative.json').read_text(encoding='utf-8'))
search=json.loads((home/'file-workflows-r47/representative.json').read_text(encoding='utf-8'))['cases'][0]
ids=['scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large','scripts.report-render.large']
catalog['cases']=[search,*[next(c for c in catalog['cases']if c['id']==i)for i in ids]]
assert len(catalog['cases'])==5 and search['id']=='scripts.file-search.large'
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=dict(baseline=baseline['head']+' documentation / production8c9fd0d7',baselineCore=baseline['coreSHA256'],candidateCore=focused['coreSHA256'],productionSources=focused['productionSources'],workerSHA256=hashlib.sha256((r/'images/before/Lokad.Lython.Benchmarks.dll').read_bytes()).hexdigest(),driverSHA256=hashlib.sha256((old/'tool/out/complete-jobs.dll').read_bytes()).hexdigest(),purpose='R49 actual declaration bindings. Reuse unchanged five-case R45 reflection driver, whose internal purpose label remains historical. Shared ALCs/CoreLib/hash witness/process GC; normal GC/tiering,32warmups/image,5rotated rounds*4complete jobs, before/current/identical-before. Separate warm sync/async and compile. Complete original goldens/funding/isolation/reset/disposal. Desktop elapsed diagnostic, precise allocation; no CPU/VM/startup/RSS/tail claim.',fullDeliveryPending=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Five unchanged maintained scripts frozen for the existing diagnostic; no timing collected.')
