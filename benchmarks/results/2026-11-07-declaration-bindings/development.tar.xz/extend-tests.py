from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
r=Path(__file__).parent;records=json.loads((r/'semantic-goldens.json').read_text(encoding='utf-8'))
source="def chosen(value): return 'old'\ndef newer(value): return 'new'\ndef mutate():\n global chosen\n chosen=newer\n return 7\nprint(chosen(mutate()),chosen(8))\n"
assert not any(c['name']=='argument_rebind_preserves_target'for c in records)
done=subprocess.run([sys.executable,'-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0 and not done.stderr,done.stderr
records.append(dict(name='argument_rebind_preserves_target',source=source,stdout=done.stdout,cpython=sys.version))
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll')
restored=json.loads(Path('benchmarks/results/2026-11-07-json-integer-source-gate/restored-build.json').read_text(encoding='utf-8'))
assert hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest()==restored['cores']['net11.0']
done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json'],input=json.dumps([source]),env=env,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
answer=json.loads(done.stdout);assert answer['Lython']['Success']and answer['Lython']['StandardOutput']==records[-1]['stdout']
(r/'baseline-target-snapshot.ndjson').write_text(done.stdout,encoding='utf-8',newline='\n')
(r/'semantic-goldens.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'make-tests.py').read_text(encoding='utf-8');a=s.index("s='using Lokad");b=s.index("print('Seven CPython")
exec(compile(s[a:b],str(r/'regenerate-tests.py'),'exec'),dict(Path=Path,json=json,records=records))
p=Path('tests/Lokad.Lython.Tests/OrdinaryFunctionTransportTests.cs');s=p.read_text(encoding='utf-8');shutil.copy2(p,r/'initial-OrdinaryFunctionTransportTests.cs')
a=s.index('        string[] expected = shape switch');b=s.index('        async ValueTask<(Context, PyString, Effects)> Prepare',a)
assert 'Assert.'not in s[a:b]and s.count('string[] expected')==1
s=s[:a]+s[b:];s=s.replace('OrdinaryCallsKeepEveryGuardAndBodyEffect','OrdinaryCallsPreserveBodyEffectsAndUnwind');p.write_text(s,encoding='utf-8',newline='\n')
print('Added independently checked argument snapshot case; removed unused obsolete checkpoint vectors, keeping every semantic/ownership assertion.')
