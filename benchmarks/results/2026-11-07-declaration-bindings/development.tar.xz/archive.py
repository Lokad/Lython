from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;b=r/'b404';out=Path('benchmarks/results/2026-11-07-declaration-bindings');out.mkdir()
checks=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in checks['productionSources'].items())
for name in ['before.json','identity.json','semantic-goldens.json','census.json','dead-census.json','local-summary.json']:(out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(out/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
target=out/'b404';target.mkdir()
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','comparison-summary.json']:
 if name.endswith('.json'):(target/name).write_text((b/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
 else:shutil.copy2(b/name,target/name)
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==3
assert hashlib.sha256((target/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--binary','--','src','tests','docs','CHANGELOG.md']))
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.patch','.ndjson','.dll','.cs']:a.add(p,arcname=p.name)
 for folder in ['attempt1','attempt2','warm-sync','warm-async','compile-sync']:
  for p in(r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 for p in b.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.sh']:a.add(p,arcname=p.relative_to(r))
 for p in ['src/Lokad.Lython/Frontend/ExecutableScript.Infrastructure.cs','src/Lokad.Lython/Frontend/ImportSyntaxFacts.cs','src/Lokad.Lython/Frontend/ScopeDirectiveFacts.cs','src/Lokad.Lython/Frontend/StaticNameBindingDiagnostics.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs','tests/Lokad.Lython.PublicApi.Tests/DeclarationNamespaceTests.cs','tests/Lokad.Lython.Tests/OrdinaryFunctionTransportTests.cs']:a.add(p,arcname='final-source/'+p)
readme='''# Actual executable declaration bindings — R49

2026-11-07, baseline qualified8c9fd0d7/frozen d3a6c778; candidate b18758e7 plus
the preserved five-production-file patch, precommit metadata b18758e7. Exact
checked source/core/worker identities are retained. No new dependency/backend,
execution route, opcode, value cache, owner framework or resource policy.

The executable compiler registers actual module function/import/class/type-alias
declarations in its existing slot layout. Ordinary loads then use those slots;
live namespace writes and deletion keep the existing bridge. Function scopes
already have complete lexical layouts. Module declarations remain published to
their backing namespace after frame cleanup. Shared import binding-name facts
replace duplicated ordinary/from-import branches. The compiler does not eagerly
predeclare every dead module binding: a return followed by unused declarations
creates no slots in the compile-only census. Existing dynamic name/global and
builtin-before-binding behavior remains.

Eight new cases have isolated CPython3.13.2 and preceding-runtime goldens: failed
function/class declarations, namespace rebinding/deletion, global replacement,
import aliases, lazy aliases, stable key iteration and call-target snapshots
through argument effects. Both APIs and repeated shared-budget cleanup pass.
Focused1008internal/2819public checks per actual.NET11/10 pass, including genuine
suspension, cancellation, first refusal, imports, closures and namespace lifetimes.
The initial prototype passes its seven new cases but fails29existing cross-frame
tests: AssignExecutableBoundName switched declarations to slots without retaining
their namespace values. The runtime publication condition is corrected, not the
independent assertions. This also corrects R48's earlier StoreName source-caption
assumption. Exact failures/initial source and corrected snapshots remain.
Unused quota-era checkpoint vectors in OrdinaryFunctionTransportTests are deleted;
they had no consumers/assertions. All body, input identity and unwind checks stay.

The existing five-case reflection driver runs unchanged: search/text affected and
ordinary CSV/JSON/report checks,32warmups/image, five rotated rounds*4jobs,
before/current/identical-before in separate ALCs sharing CoreLib/hash witness/
process GC. Warm sync/async allocation is within0.015%; compile−0.335to+0.029%.
Admitted root peaks rise48B for search/text and96B for the other three scripts,
funding extra slot/metadata capacity. Identical tiny-budget thresholds are not a
contract. No RSS/live-heap/tail claim. Desktop text clocks show misleading30–50%
gains while other controls move up to36%; preserve them as diagnostic, not ordinary
CPU improvement. The reused driver's R45 purpose label is historical; R49's
identity/catalog/source patch define these jobs.

## Controlled quiet-VM comparison — B404

Same worker7cf37ca5/host/adapter27211dbe/normal PythonRe0.4 in four processes:
two qualified baseline and two identical current roles. Quiet AzureF4as_v7,
Ubuntu24.04.4/four EPYC9V45vCPUs/16GiB/no swap, .NET11RC3 normal GC/tiering.
Five-second warmup/role/job, seven rotated150ms rounds. Three existing warm jobs
complete87.49s.120s owner+30s stop+30s margin, observed after180s. All core/aux/
source/Ready/golden/funding/quiet/Closed/exit/join/fixture gates pass. Raw archive
9813698d verified under the collection lease and independently after retrieval;
no active VM workers/fixtures. No unchanged CPython remeasurement or full lane.

| Warm script | Baseline ms | Current ms | All current/baseline pairings | Current / baseline role spread |
| --- | ---: | ---: | ---: | ---: |
| Protected search |0.230179–0.230806|0.219034–0.220320|−5.10to−4.28%|0.59%/0.27%|
| Text/helper |2.009074–2.019131|1.904750–1.966849|−5.66to−2.10%|3.26%/0.50%|
| Ordinary JSON/helper |4.194609–4.283139|3.954709–3.964283|−7.67to−5.49%|0.24%/2.07%|

Ranges span role medians, not confidence intervals. Text/current spread and JSON/
baseline spread limit magnitudes. JSON is a representative control whose import/
helper bindings also change, not a promised zero-effect workload. Coarse external
process CPU moves consistently but is not isolated-method CPU or a latency proof.
Retain the coherent layout/publication correction and bounded elapsed improvement;
do not transfer desktop percentages, claim async elapsed improvement, repay older
regression debt or infer a universal speedup. The broader objective remains open.

Warm includes mediated RAM-file I/O, complete stdout/file validation and prior-result
cleanup. Compilation/startup/fixture staging/reset/transport/final cached teardown
are excluded. Compilation and async allocation diagnostics are separate. Primary
CPython tables still identify fully qualified source8c9fd0d7; no cross-run ratio
is constructed from those medians. Full platform/Stress/installed-package delivery
for this later source is pending, to be batched at this retained checkpoint.
Publication remains postponed.

[Controlled raw observations](b404/observations.tgz), [four-role summary](b404/comparison-summary.json),
[receipt](b404/archive-receipt.json), [precise allocation/adverse desktop results](local-summary.json),
[focused checks](focused.json), [semantic goldens](semantic-goldens.json),
[source/image identity](identity.json), [census](census.json), [unemitted declarations](dead-census.json),
[all development/failure/source/image evidence](development.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## Actual executable declaration bindings (2026-11-07)\n\nR49 reuses module slots and shared import facts, retaining namespace publication\nafter frame cleanup. Initial29cross-frame failures and their correction remain;\n1008internal/2819public per actual11/10 pass. Allocation effectively flat, root\ncapacity+48–96B; B404 observes search−4.28–5.10%, text−2.10–5.66% with3.26%\ncurrent spread, JSON−5.49–7.67%. Desktop30–50%text gains are diagnostic and not\ntransferred. [Evidence and qualification status](results/2026-11-07-declaration-bindings/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R49 retained evidence archived; development SHA256',hashlib.sha256((out/'development.tar.xz').read_bytes()).hexdigest())
