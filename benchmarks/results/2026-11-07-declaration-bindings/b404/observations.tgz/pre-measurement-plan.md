# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification checkpoint does not complete this objective.

## Delivery status

- **Fully qualified production8c9fd0d7:** CI42371564043 terminal GREEN on
  Windows/Ubuntu Release actual11/10, original Stress both targets and installed
  core consumers. Includes R44's twelve immediate duplicate checks and R45's
  admitted/cancellable UTF-8 integer parser. Receipt beside integer-parsing
  evidence. Earlier R43/R41 receipts remain cached; never query terminal runs again.
- **Committed/pushed documentationad74fa41:** B400 CPython refresh, exact8c9fd0d7
  production/frozen d3a6c778.21jobs/all gates,434.37s, raw archive601c0fe8 verified
  under lease and locally. Warm CSV1.22–1.23x, text1.73–1.77x, JSON1.03x,
  report1.50x, config1.25–1.29x; explicit affected CSV1.06–1.07x, numeric-string
  JSON1.69–1.70x. Separate compile/compile-to-result and included I/O/cleanup are
  in docs/BENCHMARKS.md; variable controls stay visible. No startup/RSS/tail claim.
- **R46 prototype withdrawn:** JSON sharing the general int kernel materially
  regresses allocation. Exact source restored and Release solution rebuilt
  nonincrementally, zero warnings/errors. No prototype/runtime branch survives.
  Evidence and initial failed test assertions remain outside docs/.
- **Independent regex:** core decoupled, optional nonpackable normal adapter0.4.0.
  Earlier immutable dev48/f6b2175e focused qualification is historical, not final
  current-source safety/performance certification. Publication/tagging postponed.

## Established evidence and unresolved debt

| Work | Established result | Limits / decision |
| --- | --- | --- |
| Shared compiler facts | Corrected shared inferred-value traversal eliminates exponential analysis; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation −19.92/−19.31%; fully qualified | Earlier elapsed gains remain diagnostic. No unchanged requalification. |
| Direct UTF-8 formatting/storage | Allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention | Original adverse 15.125 ms remains unexplained and preserved. |
| R20/R25 records | Shared keys, independent values, completed CSV storage transfer; allocation −7.31/−6.55%, native warm −7.72–8.04% | Selectively replaces the old rigidly rejected 6–8% bulk-record attempt; controls mixed. |
| R35/R38 | Dynamic report allocation ~−15.35%, quiet warm −10–13%; compile allocation −4.38–8.94% | CSV possible debt +0.13–2.36%; R38 required full regex analysis preserved after three initial failures. |
| R40/R41 | Unicode cursor scaling −31–79%; shared receiver methods remove ten markers/guards and closures, regex allocation ~−29.47%, warm −8.64–10.80% | Not broad CPU/parity claims; ASCII and original CSV adverse controls remain possible debt. Fully qualified. |
| R42 cost gate | Text: 1,089 CPU samples, 44 unknown; prefix 229 self / 1,056 inclusive; scalar add 41 self | Self includes inlined work; inclusive totals overlap. No universal scalar rewrite or saved-CPU forecast. |
| R43 ordinary operands | Fewer instructions/smaller immutable payload; compile allocation +0.20–0.87%; full delivery green | Text warm −1.37 to +1.11%, fresh −2.23 to −0.15%; CSV variable, JSON −2.37 to +6.81%/6.66% identical-current spread, report −2.19 to −0.73%/3.92% IQR. No substantial CPU claim; debt stays. |

History, original failed conditions, rejected designs and complete qualification
live in benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. R43 development
evidence stays outside docs/. Do not repeat unchanged completed qualification.

## Completed R44/R45 delivery checkpoint

R45 removes decoded copies/UTF-16 general int parsing, uses native accumulation
then admitted radix chunks, and corrects Unicode decimal semantics. B399 shows
affected padded CSV warm−12.49–13.41% and numeric-string JSON−41.43–41.98%.
Initial allocation−14.70/13.35% and−62.99/62.98% sync/async; ordinary controls
mixed. Final refinement removes one check; allocation was not replayed. Tiny
thresholds change; three conservative magnitudes fund promotion/replacement, with
existing small-scalar headroom. Individual BCL magnitude operations are atomic.
Focused, actual in-flight cancellation and full delivery pass. B400 closes the
external comparison gap. History: benchmarks/results/2026-11-07-integer-parsing/
and integer-cpython/. Do not repeat unchanged qualification or timing.

## Priority 1 — R49 actual declaration bindings in executable modules

R48 source/cost gate is complete: corrected B403 passes every gate, actual3.28s
guestCPU/645samples/34unknowns; raw e8be5f91 archived under lease and verified
locally. B402's original warmup failure/raw d04e53e3 and caption/size correction
remain. Named entry leaves25samples (~3.88%) do not prove dominant removable call
admission; inclusive/helper totals contain useful work. No stack/cancellation/
frame redesign or leaf-check change is selected. Do not repeat this cost gate.
Evidence: benchmarks/results/2026-11-07-helper-entry-cost/.

Demonstrated source fact: module wanted is absent from its existing local-slot
layout, so the per-line helper target uses LoadName; ResolveName has29selfsamples.
Function declarations already publish via StoreName, which updates existing frame
slots, while ordinary assignment declarations allocate slots. Assess imports and
class/type declarations through their existing binding metadata as one layout
correction. Preserve late dynamic/global namespace behavior; avoid a second walker
or new cache. Do not eagerly predeclare every dead module binding: modules need
no Python UnboundLocal rule and that would fund unused frame/map capacity.

- Hypothesis/work removed: register actual compiled declaration bindings in the
  existing slot layout; reuse ordinary load/store/frame and namespace-bridge code,
  eliminating repeated name search/hash work for common helpers/module aliases.
  Name the displaced special cases; no type/method-name-specific fast path.
- Acceptance: definitions/import aliases/classes/type parameters, decorators and
  failed definitions, before-binding builtin/global lookup, deletion/rebinding,
  globals/locals bridges, closures, annotations, dead code, actual suspension and
  error/effect order. Preserve current cancellation/first refusal and charged
  frame/program capacity, retained aliases and result cleanup. Keep measured
  native helper returns and managed stack policy unchanged.
Active R49 prototype: declarations use actual compiled slots and keep module
namespace publication beyond frame cleanup. Initial29white-box failures expose
that lifetime requirement; fixed without weakening assertions. Eight independently
CPython/baseline-frozen namespace/snapshot cases pass;1008internal/2819public per
actual11/10 pass. Removed unused quota-era checkpoint vectors, all useful assertions
kept. Census confirms wanted and imports now use slots; no whole-module dead-name
predeclaration. Warm allocation within0.015%; compilation−0.335to+0.029%. Desktop
text strongly favorable, but search/control variability up to36% prohibits CPU
claims. B404 planned:three warm source-pair jobs, two old/two current roles;
120s owner+30s stop+30s margin, observe after180s. No full qualification repeated.

- Validate using existing focused compiler/scope/import/namespace/cancellation/
  ownership tests. One short complete-job before/after diagnostic with search/text
  affected workloads and CSV/JSON/report controls; compile separately. Account for
  extra slot/capacity charges; static census is not a speedup. Retain/refine/withdraw
  with an explicit regression-debt decision; bounded corrections allowed when
  justified. Batch platform/stress/package checks at a retained delivery boundary.

R47/B401 closed missing file baselines: warm search1.74–1.80x (variable controls),
two-file manifest1.48–1.49x; compile-to-result both1.46–1.49x. The latter copies
only4107B/twofiles, not large-copy throughput. Current tables and evidence retain
boundaries/controls. R46 JSON kernel sharing remains withdrawn: allocation+10.5%
for40digits/~28.5times total for4096digits despite passing semantics. Source fully
restored/rebuilt; no speculative parser branch or new ownership mechanism remains.

## Next redesign boundaries

Select a real dominant phase from current evidence; do not accumulate narrow cases.
For each selected milestone record the hypothesis, eliminated work/storage and
displaced code, affected scripts, semantic gates, bounded comparison and controls.

| Boundary | Evidence / acceptance / stopping criterion |
| --- | --- |
| Complete calls/frames | R39 CSV helper-inclusive totals are useful work, not proof of binding dominance. Existing borrowed operands/final slots/lazy contexts/native helpers stay. Select only a real removable phase; preserve binding, defaults, closures, exceptions, genuine I/O and owners. Slower call-arena/control designs require new evidence, not automatic retry. |
| Operand transport | R43 retained smaller code and fewer instructions, with CPU improvement unproved. No further leaf-specific rewrite without materially new evidence. |
| Completed-instruction guards | R44 completes twelve provably immediate duplicates. Wider opcode hoisting lacks a complete cancellation/refusal/error-order proof and is not selected. R42 prefix self is not guard CPU. Keep meaningful checkpoints; no replacement counters/quotas or weaker containment. |
| Per-record collections | Shared keys/R25 transfer and synchronous JSON already exist. Reassess bulk construction only where an actual extra copy/capacity phase remains; preserve hook/order/reentry/alias/overlap semantics. Original control regressions remain evidence. |
| Scalars and text | R42 scalar add alone is insufficient for universal tagged values. Bulk UTF-8 and prepared helpers already exist. R28 already tested newly owned packed split storage: allocation −6.94%, text variable, report +0.91–4.97% after refinement; withdrawn. Do not rediscover it as a new design or indiscriminately share refundable input windows. Select materially different remaining work; preserve promotion, identity, Unicode, hashes and cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts, R38 demand pruning, shared builtins and executable imports already exist. Remove actual repeated analysis/storage; preserve dead-scope diagnostics, fresh mutable state and regex analysis. Compile separately, and include compile-to-result for config/new scripts. |

A justified redesign may temporarily regress. Its completion milestone must state
whether remaining debt is accepted, corrected or withdrawn. A source simplification,
an allocation reduction and a CPU improvement are distinct results.

## Independent regex track

Continue Lython-owned Python/native UTF-8 semantics: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. Development producers and adapter-local bridges may
support contract/semantic work; missing released capabilities defer only affected
final adapter qualification. They do not stop core or independent performance work.

Current precise producer gaps: DetailedData lacks a separate Prepare working owner;
native names lack enumeration; cursors mix creation/current token authority. Exact
dev48 supplies no documented removal of these limits. Keep conservative preflight,
adapter-local conversion and the qualified cancellation bridge where needed.
Qualify immutable released inputs and managed safety separately. No silent dialect
fallback, work/time quotas, sibling edits, abandoned matching or publication gate
on Lython development. Existing R40/R41 work needs no new producer release.

## Experimental and delivery policy

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty, not permanent design rejection. Permit bounded justified confirmation,
refinement or measurement correction; never repeat until favorable. Size observations
for the quiet VM, preserve original conditions/adverse results and source/binary
provenance. Percentages inform decisions rather than automatically vetoing useful
simplification. Use focused correctness/cancellation/ownership checks while iterating;
batch full actual11/10 Windows/Ubuntu, original Stress and installed consumers at
meaningful retained delivery checkpoints. Publication remains postponed.

## Constraints / resources

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host mediation,
current cancellation, borrowed shared allowance/preflights/overlap/escaping aliases
and awaited cleanup. First refused admission terminates the command. No unsafe,
tracing, weak reclamation, forced GC, fuel/quotas/caps or hidden allowance. Bounded
host-driven batches; XML depth constraint retained. No overlapping local tests,
builds or measurements. PLAN stays ignored; docs describe only current releases.

VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B403 terminal and
archived; never service-query again. B402 failed before sampling, preserved under
fresh maintenance lease; B403 corrected warmup passes all gates, raw e8be5f91
verified under collection lease and locally. No active VM users/fixtures/traces.
CI42371564043 and earlier terminal runs are cached GREEN; no active CI. Record
future owner/stop/margin before observation; never restart on observation timeout.
Retain persistent evidence and verify RAM archives before removing raw state.
Retired duplicate images have exact committed backups; restore incomplete inputs
before reuse. Producer6032b928/dev51 still has the named missing semantics above;
no new package qualification or core-development blocker inferred.
