def make_rules(index):
    def apply(base, offset=index % 7, /, *, weight=index % 5 + 1, enabled=index % 3 != 0):
        return (base + offset) * weight if enabled else base
    fallback = lambda base, offset=(index + 1) % 7, /, *, scale=2: (base - offset) * scale
    return apply, fallback

total = 0
for index in range(3):
    apply, fallback = make_rules(index)
    total += apply(index) + fallback(index)
first = globals()['apply']
defaults = first.__kwdefaults__
defaults['weight'] = 8
print(total, first is apply, defaults is apply.__kwdefaults__, apply(2), fallback(2))
