from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-accounted-memory-total"
quiet = lab / "comparison/quiet"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet / "identity.json")
assert sha(lab / "candidate.patch") == identity["sourcePatchSHA256"]
assert (lab / "candidate.patch").read_bytes() == subprocess.check_output(
    ["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
for role, manifest in identity["imageFiles"].items():
    assert len(manifest) == 32 and {p.name: sha(p) for p in (lab / role).iterdir()} == manifest
    assert sha(lab / ("probe-" + role) / "Lokad.Lython.dll") == manifest["Lokad.Lython.dll"]
    proof = read(lab / "comparison" / (role + "-verify.json"))
    assert proof["caseCount"] == 3 and proof["state"] == "Completed"
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
    for mode in ("sync", "async"):
        oracle = read(lab / f"observer-{role}-{mode}.json")
        assert oracle["Matches"] and oracle["Options"]["Async"] == (mode == "async")
        assert oracle["Lython"]["StandardOutput"] == "10 True True 32 -2\n"
for row in read(lab / "allocation-summary.json"):
    assert row["peakAdmission"][0] == row["peakAdmission"][1]
    assert abs(row["allocationBytes"][0] - row["allocationBytes"][1]) <= 8

out.mkdir(exist_ok=True)
for path in (quiet / "identity.json", lab / "allocation-summary.json"):
    shutil.copyfile(path, out / path.name)
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in ["archive.py", "archive-quiet.py", "prepare.py", "module-observer.py",
                 "observer.py", "allocations.py", "quiet.py", "candidate.patch",
                 "reference-allocation.json", "candidate-allocation.json",
                 "comparison/candidate-verify.json", "comparison/reference-verify.json",
                 "comparison/quiet/jobs.json", "comparison/quiet/representative.json",
                 "comparison/quiet/storage-custody.json"] + [
                     f"observer-{role}-{mode}.json" for role in ("reference", "candidate") for mode in ("sync", "async")]:
        archive.add(lab / name, arcname=name, recursive=False)
