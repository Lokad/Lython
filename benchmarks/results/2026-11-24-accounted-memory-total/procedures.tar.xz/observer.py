from pathlib import Path
import json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
data = json.loads((lab / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
for role in ("reference", "candidate"):
    probe = lab / ("probe-" + role)
    source = lab.with_name("regex-operation-dispatch-20261124") / "probe-candidate"
    shutil.copytree(source, probe, dirs_exist_ok=True)
    shutil.copyfile(lab / role / "Lokad.Lython.dll", probe / "Lokad.Lython.dll")
    for mode in ("sync", "async"):
        args = [sdk / "dotnet.exe", probe / "LythonProbe.dll", lab / "module-observer.py",
                "--compare-python", "--python", "C:/Python313/python.exe", "--json"]
        if mode == "async": args.append("--async")
        raw = subprocess.check_output(args, env=env, encoding="utf-8", timeout=30)
        report = json.loads(raw)
        assert report["Matches"] and report["Lython"]["StandardOutput"] == "10 True True 32 -2\n", raw
        (lab / f"observer-{role}-{mode}.json").write_text(raw, encoding="utf-8")
        print(role, mode, report["Lython"]["StandardOutput"].strip())

