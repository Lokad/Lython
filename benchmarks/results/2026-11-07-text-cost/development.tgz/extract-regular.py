from pathlib import Path
import collections,hashlib,json,tarfile
r=Path(__file__).parent
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'retrieved-regular';out.mkdir()
with tarfile.open(r/'observations.tgz') as t:
    members=t.getmembers();kept=[];pipes=[]
    for member in members:
        if member.isfile() or member.isdir():kept.append(member)
        elif member.isfifo():pipes.append(dict(name=member.name,type='fifo',bytes=member.size))
        else:raise ValueError(('Unexpected archive member',member.name,member.type))
    assert all(p['bytes']==0 for p in pipes)
    t.extractall(out,members=kept,filter='data')
(r/'extraction.json').write_text(json.dumps(dict(archiveSHA256=receipt['archiveSHA256'],originalFailure='tarfile data_filter rejects Linux FIFO perf/text-warm/ack on Windows; terminal collection and archive already successful. No service query/restart/runtime change.',skippedMetadataOnlyPipes=pipes,allRegularEvidenceExtracted=True,originalArchiveUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Extracted regular evidence; original archive/FIFO metadata preserved unchanged. No VM query.')
