from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;project=r/'census';project.mkdir()
old=r.parent/'call-operands-r37/census'
shutil.copy2(old/'census.csproj',project/'census.csproj')
s=(old/'Program.cs').read_text(encoding='utf-8')
s=s.replace('instructionCount = counts.Values.Sum(), operandCapacity', 'constantTypes = Items(code, "Constants").Select(value => value?.GetType().FullName),\n            instructionCount = counts.Values.Sum(), operandCapacity')
(project/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
core=r.parent/'builtin-methods-r41/images/refined/Lokad.Lython.dll'
assert hashlib.sha256(core.read_bytes()).hexdigest()=='5d2ca8e13483c95863e7eb68a667ddbe81f649442aaa91331a6af1419061ec48'
with (r/'census-build.log').open('w',encoding='utf-8') as log:
    done=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(project/'census.csproj'),'-c','Release','--nologo','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'census-build.log').read_text(encoding='utf-8')[-3000:]
done=subprocess.run([env['DOTNET_HOST_PATH'],str(project/'bin/Release/net11.0/census.dll'),str(core),str(r/'catalog.json'),str(r/'census.json')],env=env,capture_output=True,text=True,encoding='utf-8')
(r/'census.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
data=json.loads((r/'census.json').read_text(encoding='utf-8'))
for case in data['cases']:
    for code in case['codes']:
        print(json.dumps({key:code[key] for key in ['name','requiresMirroring','native','instructionCount','operandCapacity','constantTypes','counts']}))
