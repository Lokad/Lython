from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/window-capacity-rough-allocation-b679-20261113', 'unit': 'lython-b679-window-rough-allocation-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/window-capacity-rough-b678-20261113', 'identity': {'purpose': 'R314 eight existing complete-script allocation diagnostics, unchanged original ALC tool; clocks diagnostic, exact91 versuscf source pair', 'coreSHA256': {'reference': '91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78', 'candidate': 'cf762db110633b45d329da0ff7cf548b6264e92880f00dae7daa2a31e91abb26'}, 'catalogSHA256': 'e4fa68ee8743e9014caeffe5ad15a1871fb60a1ab81e119758819144de94b6c6', 'sourceIdentitySHA256': 'e225dc641d6ee8cb0d7ed4248b685ed0e99b6bab4e1fa8a9666bb84447049983', 'driverSHA256': '8dcae4e7e63f46337392f73a6cf56d57d3c58b03c28f9e3c44b44c1eb4feb65e', 'driverSourceSHA256': 'ebeca5ef73b6ba46e624683622f3cbb694a521644676393732f45f73e1c286db'}, 'payloadBytes': 20069, 'payloadSHA256': '4e96e3b474474f321f66e194d243f8ede7acec7f915167b9edd835d8170fcb51', 'unpackedBytes': 46611}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 for role in ['reference','candidate']:assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(source/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 before=shutil.disk_usage(base).free
 assert before>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 prior=base/'tuple-allocation-b670-20261113'
 os.link(source/'representative.json',root/'catalog.json')
 os.link(prior/'witness.json',root/'witness.json')
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 assert digest(root/'complete-jobs.dll')==config['identity']['driverSHA256']
 for name in ['collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=[]),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b679-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
