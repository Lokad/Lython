from pathlib import Path
import json
r=Path(__file__).parent
d=json.loads((r/'retrieved/stdout.json').read_text(encoding='utf-8'));rows=[]
for x in d['observations']:
 p=x['admittedPeaks'];a=p['before'];b=p['candidate'];c=p['before-control']
 row=dict(case=x['caseId'],reference=a,candidate=b,referenceControl=c,executionChangePercent=100*(b['PeakExecutionBytes']/a['PeakExecutionBytes']-1),rootChangePercent=100*(b['PeakRootBytes']/a['PeakRootBytes']-1))
 rows.append(row);print(x['caseId'],'execution',a['PeakExecutionBytes'],'->',b['PeakExecutionBytes'],'root',a['PeakRootBytes'],'->',b['PeakRootBytes'],round(row['rootChangePercent'],1),'%',flush=True)
(r/'admitted-peaks.json').write_text(json.dumps(dict(accountedEstimatesNotClrHeapOrRss=True,capturedOutsideAllocationSamples=True,rows=rows),indent=2)+'\n',encoding='utf-8')
