from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile,time
root=Path('/home/lokad/lython-bench-checks/window-capacity-rough-allocation-b679-20261113')
source=Path('/home/lokad/lython-bench-checks/window-capacity-rough-b678-20261113')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(root.parent/'comparison-vm.lock').open('a')as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148';env['TMPDIR']=str(root/'guest-fixtures')
    assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
    dotnet=env['DOTNET_ROOT']+'/dotnet';started=time.monotonic();error=None;complete=False
    try:
        for phase in ['before']:
            time.sleep(3)
            subprocess.run([dotnet,str(source/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/('machine-'+phase+'.json'))],env=env,check=True)
            assert json.loads((root/('machine-'+phase+'.json')).read_text())['gate']['quiet']
        args=[dotnet,str(root/'complete-jobs.dll'),str(source/'reference/Lokad.Lython.Benchmarks.dll'),str(source/'candidate/Lokad.Lython.Benchmarks.dll'),str(root/'catalog.json'),str(root/'witness.json'),'forward','warm']
        with(root/'stdout.json').open('w')as stdout,(root/'stderr.log').open('w')as stderr:
            subprocess.run(args,env=env,stdout=stdout,stderr=stderr,check=True,timeout=90)
        data=json.loads((root/'stdout.json').read_text());identity=json.loads((root/'identity.json').read_text())
        assert data['allGoldensPassed']and data['allBalancesZero']and data['ownedFixturesRemoved']and len(data['observations'])==8
        for row in data['observations']:
            assert row['identities']['before']['Lokad.Lython.dll'].lower()==identity['coreSHA256']['reference']
            assert row['identities']['candidate']['Lokad.Lython.dll'].lower()==identity['coreSHA256']['candidate']
        time.sleep(3)
        subprocess.run([dotnet,str(source/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
        assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
        assert not list((root/'guest-fixtures').iterdir())
        complete=True
    except BaseException as e:error=type(e).__name__+': '+str(e)
    joined=subprocess.run(['pgrep','-af','[d]otnet.*complete-jobs.dll|[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
    assert joined
    status=dict(complete=complete,error=error,allWorkersJoined=joined,elapsedSeconds=time.monotonic()-started,performanceQualified=False,allocationOnly=True)
    (root/'collection-status.json').write_text(json.dumps(status,indent=2)+'\n')
    ram=root/'guest-fixtures';raw={p.relative_to(ram).as_posix():sha(p)for p in ram.rglob('*')if p.is_file()}
    with tarfile.open(root/'observations.tgz','w:gz')as a:
        for p in sorted(root.iterdir()):
            if p.is_file()and p.name!='observations.tgz':a.add(p,arcname=p.name)
        for name in raw:a.add(ram/name,arcname='partial-fixtures/'+name)
    with tarfile.open(root/'observations.tgz')as a:
        for name,h in raw.items():assert hashlib.sha256(a.extractfile('partial-fixtures/'+name).read()).hexdigest()==h
        assert json.loads(a.extractfile('collection-status.json').read())==status
    subprocess.run(['sudo','-n','umount',str(ram)],check=True);ram.rmdir()
    assert shutil.disk_usage(root).free>252*1024*1024
    receipt=dict(status,archiveSHA256=sha(root/'observations.tgz'),archivedAndVerifiedUnderLease=True,ramArchivedBeforeUnmount=True,guestFixturesRemoved=True,freeBytes=shutil.disk_usage(root).free)
    (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
    if not complete:raise SystemExit(1)
