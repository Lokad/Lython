from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'integer-chain-r311'
for kind,count in [('internal',198),('public',42)]:
 text=(r/('cancellable-'+kind+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in text and f'Total tests: {count}'in text
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in baseline['sources']}
changed=[p for p in sources if sources[p]!=baseline['sources'][p]];assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs'],changed
for role in ['reference','candidate']:
 shutil.copytree(old/'candidate',r/role,copy_function=os.link)
 if role=='candidate':
  (r/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/role/'Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R314 decoded-window long-line header capacity under existing execution owner; one cancellable bounded scan/window marker, no scalar credits; sized/accumulated reads retain independent funding',coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=baseline['coreSHA256'],sources=sources,changed=changed)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
shutil.copyfile(old/'catalog.json',r/'catalog.json')
code=(r.parent/'invoice-current-r309/tuple-r310/inspect-vm.py').read_text(encoding='utf-8');a=code.index('specs=');b=code.index('\nproofs=',a)
code=code[:a]+"specs=[('integer-chain-b672-20261113/reference/Lokad.Lython.dll','benchmarks/results/2026-11-13-native-tuple-return/final/source-checks.tar.xz',r.parent/'integer-chain-r311/reference/Lokad.Lython.dll')]"+code[b:]
code=code.replace('len(aliases)==info.st_nlink==2','len(aliases)==info.st_nlink and info.st_nlink>=1').replace('canonically preserved superseded/unqualified bytes','canonically preserved prior8f working bytes; current91 remains')
ast.parse(code);(r/'inspect-retirement.py').write_text(code,encoding='utf-8')
catalog=json.loads((r.parent/'arithmetic-source-r305/b661/retrieved/representative.json').read_text(encoding='utf-8'))
print(identity['coreSHA256'],len(sources),'inputs;198internal/42public final checks pass; one production input; VM fixed catalog cases',len(catalog['cases']),flush=True)
