from pathlib import Path
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');r=Path(__file__).parent
(r/'PLAN-before-safe-checkpoint.md').write_text(s,encoding='utf-8')
s=s.replace(next(x for x in s.splitlines()if x.startswith('| Fully qualified committed runtime |')),'| Fully qualified committed runtime |40d92aef/frozen91d0540d, GREEN43417375221: Windows/Ubuntu actual.NET11/10 ordinary, original stress and installed Release consumers.573source inputs match; terminal/logs/16step counts cached. [Delivery](benchmarks/results/2026-11-13-native-integer-chains/delivery/README.md). Prior85c/8f and14dd/93 delivery retained; no unchanged replay. |')
s=s.replace(next(x for x in s.splitlines()if x.startswith('| Committed; delivery running |')),'| Active prototype, not promoted |R314 text-window header capacity on40d/91. One production file changes; focused tests building, no timing/allocation result or full qualification claim. Existing live owner retains all aliases and unused capacity. |')
a=s.index('1. **R311');b=s.index('2. **R314',a);s=s[:a]+s[b:]
s=s.replace('2. **R314','1. **R314').replace('3. **Frontend','2. **Frontend').replace('4. **Independent','3. **Independent')
s=s.replace('R311 CI continues independently.','R311 full delivery is complete; do not repeat unchanged.')
marker='History, rejected forms and raw receipts live in'
s=s.replace(marker,'''- R311/40d92aef/91d is fully qualified. One same-stream accumulator removes16384
  intermediate boxes/524288B per4096invoice records; allocation−8.46..−8.48%(rich
  −6.55%), warm−6.55..−2.91%/fresh−6.03..−3.78% with supporting widerCPU. Report
  remains unresolved debt: initial adverse range and longer-warmup moving controls
  are separate, not averaged or called a fix. [All evidence/debt](benchmarks/results/2026-11-13-native-integer-chains/README.md).

'''+marker)
s=s.replace('nativeUTF8 group\n    names','nativeUTF8 group-name\n    enumeration/copy (lookup is already available)')
p.write_text(s,encoding='utf-8');print('PLAN current:40d fully qualified, B671 external source fixed, R314 active; completed R311 condensed, original plan archived privately.')
