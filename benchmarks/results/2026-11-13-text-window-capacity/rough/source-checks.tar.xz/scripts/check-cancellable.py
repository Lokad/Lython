from pathlib import Path
import subprocess
r=Path(__file__).parent
code=(r/'check.py').read_text(encoding='utf-8').replace('focused-','cancellable-')
(r/'current-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'current-check.py')],check=True)
