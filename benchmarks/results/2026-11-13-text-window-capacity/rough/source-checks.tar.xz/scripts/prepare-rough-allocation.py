from pathlib import Path
import ast,hashlib,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk)
tool=r.parent/'composed-native-r303/tool';source=tool/'Program.cs';before=hashlib.sha256(source.read_bytes()).hexdigest()
with(r/'allocation-driver-nonincremental-build.log').open('w',encoding='utf-8')as log:
 subprocess.run([str(sdk/'dotnet.exe'),'build',str(tool/'complete-jobs.csproj'),'-c','Release','--no-restore','--no-incremental','--disable-build-servers'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==before
code=(r/'prepare-allocation.py').read_text(encoding='utf-8')
for prefix in ['integer-chain-r311','arithmetic-source-r305','composed-native-r303']:
 code=code.replace("r.parent/'"+prefix,"r.parent.parent/'"+prefix)
code=code.replace("out=r/'allocation-b677'","out=r/'allocation-b679'")
code=code.replace('window-capacity-allocation-b677-20261113','window-capacity-rough-allocation-b679-20261113').replace('window-capacity-b676-20261113','window-capacity-rough-b678-20261113').replace('lython-b677-window-allocation-20261113','lython-b679-window-rough-allocation-20261113')
code=code.replace("replace('b673','b677')","replace('b673','b679')").replace('B677','B679').replace('91 versusfd','91 versuscf')
ast.parse(code);(r/'rough/prepare-allocation.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'rough/prepare-allocation.py')],check=True)
