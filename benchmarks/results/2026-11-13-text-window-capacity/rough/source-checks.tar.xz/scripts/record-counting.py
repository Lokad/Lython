from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-text-window-capacity/counting');out.mkdir(parents=True,exist_ok=True)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
receipt=json.loads((r/'b676/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and hashlib.sha256((r/'b676/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','summary.json']:shutil.copyfile(r/'b676'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','retirement-canonical.json','retirement-inspection.json']:a.add(r/name,arcname=name)
 for p in sorted(r.glob('*.log')):a.add(p,arcname='checks/'+p.name)
 for p in sorted(r.glob('*.py')):a.add(p,arcname='scripts/'+p.name)
 for p in sorted((r/'b676').iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='b676/'+p.name)
 for p in [Path('tests/Lokad.Lython.Tests/TextWindowCapacityAdmissionTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/MixedTextWindowReadsTests.cs')]:a.add(p,arcname='tests/'+p.name)
print('Counting phasefd258a65 preserved;198internal/106public pass, all five complete observations/controls, no allocation/gain claim. No production promotion.',flush=True)
