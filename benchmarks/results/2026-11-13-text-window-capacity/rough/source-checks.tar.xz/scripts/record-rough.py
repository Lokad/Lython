from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;src=r/'rough';out=Path('benchmarks/results/2026-11-13-text-window-capacity/rough');out.mkdir(parents=True,exist_ok=True)
identity=json.loads((src/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
for folder,dest in [(src/'b678',out),(src/'allocation-b679',out/'allocation')]:
 dest.mkdir(exist_ok=True);receipt=json.loads((folder/'archive-receipt.json').read_text(encoding='utf-8'))
 assert receipt['complete']and receipt['allWorkersJoined']and hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(folder/name,dest/name)
 shutil.copyfile(folder/'summary.json'if folder.name=='b678'else folder/'retrieved/summary.json',dest/'summary.json')
 if folder.name=='allocation-b679':shutil.copyfile(folder/'admitted-peaks.json',dest/'admitted-peaks.json')
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','retirement-canonical.json','retirement-inspection.json']:a.add(src/name,arcname=name)
 for p in sorted(r.glob('*.log')):a.add(p,arcname='checks/'+p.name)
 for p in sorted(r.glob('*.py')):a.add(p,arcname='scripts/'+p.name)
 for phase in ['b678','allocation-b679']:
  for p in sorted((src/phase).iterdir()):
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname=phase+'/'+p.name)
 for p in [Path('tests/Lokad.Lython.Tests/TextWindowCapacityAdmissionTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/MixedTextWindowReadsTests.cs')]:a.add(p,arcname='tests/'+p.name)
print('cf762db1 exact source, all controls/allocation/charged peaks/checks preserved; withdraw prototype, retain external regressions.',flush=True)
