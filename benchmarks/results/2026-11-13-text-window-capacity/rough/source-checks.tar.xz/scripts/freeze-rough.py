from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'rough';out.mkdir()
for name,count in [('rough-internal-test.log',198),('rough-public-test.log',42),('rough-compressed-public-test.log',64)]:
 s=(r/name).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and f'Total tests: {count}'in s
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in old['sources']}
changed=[p for p in sources if sources[p]!=old['sources'][p]];assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs']
for role in ['reference','candidate']:
 shutil.copytree(r/'reference',out/role,copy_function=os.link)
 if role=='candidate':
  (out/role/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/role/'Lokad.Lython.dll')
shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(old,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R314 constant-time remaining-byte bound for long line-view header capacity; counted scan removed; conservative unused headroom retained by execution owner',coreSHA256=sha(out/'candidate-core.dll'),sources=sources)
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as a:
 for p in sources:a.add(p,arcname=p)
shutil.copyfile(r/'catalog.json',out/'catalog.json')
code=(r/'inspect-retirement.py').read_text(encoding='utf-8');a=code.index('specs=');b=code.index('\nproofs=',a)
code=code[:a]+"specs=[('window-capacity-b676-20261113/candidate/Lokad.Lython.dll','benchmarks/results/2026-11-13-text-window-capacity/counting/source-checks.tar.xz','fd258a65c96f54b0f6a9d70f4af300c7ad3121e633cc9dd9f9de7fc811bea470'),('invoice-external-b660-20261113/candidate/Lokad.Lython.dll','benchmarks/results/2026-11-13-native-call-stack-handoff/source-checks.tar.xz','2e74ef4fd844a4940f4e7800d0d801e6353babf124f35a720ebc2aa025b0c1ae')]"+code[b:]
code=code.replace('expected=hashlib.sha256(core.read_bytes()).hexdigest()','expected=str(core)').replace("m.name.endswith('candidate-core.dll')","m.name.endswith('.dll')").replace('prior8f','superseded fd/2e')
ast.parse(code);(out/'inspect-retirement.py').write_text(code,encoding='utf-8')
print(identity['coreSHA256'],'573inputs,198internal/106public pass; one production input, counting scan removed.',flush=True)
