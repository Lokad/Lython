from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'invoice-current-r309/tuple-r310/final/b669';out=r/'b676';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(p)==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/window-capacity-b676-20261113';oldroot='/home/lokad/lython-bench-checks/tuple-return-final-b669-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified40d92aef/91d0540d versus uncommitted'+source['coreSHA256'][:8]+' decoded-window header capacity',purpose='Complete file-search/captured-text/JSON warm, invoice/report controls; no new CPython ratio',coreSHA256={k:source['referenceSHA256']if k.startswith('reference')else source['coreSHA256']for k in identity['coreSHA256']},referenceSourceIdentitySHA256=sha(r.parent/'integer-chain-r311/candidate-identity.json'),sourceIdentitySHA256=sha(r/'candidate-identity.json'),productionSourceArchiveSHA256=sha(r/'candidate-sources.tar.xz'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.file-search.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.csv-invoice.large','warm'],['scripts.report-render.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b669-tuple-return-final-20261113','lython-b676-window-capacity-20261113').replace('B668','B676')
 if name=='collect.py':
  a=code.index('jobs=');b=code.index('\nenv =',a);code=code[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+code[b:]
  code=code.replace("< 240, 'Reserve60seconds","< 300, 'Reserve60seconds")
  code=code.replace('CSV shared long fields; text-rich invoice warm/fresh, original invoice/captured controls; exact source-pair, no external ratio','Window header capacity; search/captured text/JSON warm with invoice/report controls; exact source pair, no external ratio')
 elif name in ['archive-owned.py','summarize.py']:code=code.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
 elif name=='retrieve.py':code=code.replace("status['receipt']['jobs']==4","status['receipt']['jobs']==5").replace('elapsedSeconds\']<300','elapsedSeconds\']<360').replace('four-job','five-job')
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']};files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
retire=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))['groups'];assert len(retire)==1 and retire[0]['sha256']=='8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2'
config=dict(json.loads((old/'config.json').read_text(encoding='utf-8')),root=root,unit='lython-b676-window-capacity-20261113',sourceRoot='/home/lokad/lython-bench-checks/integer-chain-b672-20261113',sourceCoreSHA256=source['referenceSHA256'],identity=identity,retire=retire,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
config['retireArchives']=[]
for remote,canonical in [('native-return-external-b671-20261113/observations.tgz','benchmarks/results/2026-11-13-native-return-cpython-checkpoint/observations.tgz'),('file-search-source-b675-20261113/observations.tgz','benchmarks/results/2026-11-13-file-search-source-gate/observations.tgz')]:
 data=Path(canonical).read_bytes();assert subprocess.check_output(['git','show','HEAD:'+canonical])==data
 config['retireArchives'].append(dict(path=remote,canonical=canonical,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b669','b676')
code=code.replace("source/'reference'","source/'candidate'").replace("source/'reference/","source/'candidate/").replace("source/'reference-source-identity.json'","source/'source-identity.json'")
code=code.replace('current93 and external2e stay','current91 and canonical older snapshots stay').replace('RuntimeMaxSec=300','RuntimeMaxSec=360').replace('ownerSeconds=300','ownerSeconds=360').replace('timedelta(seconds=180)','timedelta(seconds=240)').replace('observationSeconds=180','observationSeconds=240')
needle=' before=shutil.disk_usage(base).free'
insert=''' for row in config['retireArchives']:
  p=base/row['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==row['bytes']and digest(p)==row['sha256']
 for row in config['retireArchives']:
  p=base/row['path'];assert digest(p)==row['sha256'];p.unlink()
'''
assert needle in code;code=code.replace(needle,insert+needle).replace("retired=config['retire']","retired=config['retire']+config['retireArchives']")
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B676 five complete warm jobs; exact91 baseline; canonical prior8f aliases retired under fresh lease, all evidence/qualification retained; staged',config['unpackedBytes'],'bytes.',flush=True)
