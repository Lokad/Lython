from pathlib import Path
import subprocess
r=Path(__file__).parent
code=(r/'check.py').read_text(encoding='utf-8').replace('focused-','rough-').replace("['-m:1']if phase=='build'","['-m:1','--no-restore']if phase=='build'")
(r/'rough-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'rough-check.py')],check=True)
code=(r/'check-compressed.py').read_text(encoding='utf-8').replace('compressed-public-test.log','rough-compressed-public-test.log')
(r/'rough-compressed-check.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'rough-compressed-check.py')],check=True)
