from pathlib import Path
import hashlib,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');sha=hashlib.sha256(core.read_bytes()).hexdigest()
names=['GzipFileCompatibilityTests','GzipFileProtocolCompatibilityTests','GzipCallbackScopeLifetimeTests']
filter='Category!=Stress&('+ '|'.join('FullyQualifiedName~'+name for name in names)+')'
p=r/'compressed-public-test.log';assert not p.exists()
with p.open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'vstest','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.PublicApi.Tests.dll','--TestCaseFilter:'+filter,'--logger:console;verbosity=normal'],env=env,stdout=log,stderr=subprocess.STDOUT)
text=p.read_text(encoding='utf-8');print(done.returncode,text[-2000:],flush=True)
assert done.returncode==0 and 'No test matches'not in text and 'Test Run Successful.'in text
assert hashlib.sha256(core.read_bytes()).hexdigest()==sha
