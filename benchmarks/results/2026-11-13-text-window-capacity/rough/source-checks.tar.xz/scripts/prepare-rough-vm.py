from pathlib import Path
import ast,subprocess
r=Path(__file__).parent
code=(r/'prepare-vm.py').read_text(encoding='utf-8')
code=code.replace("old=r.parent/'invoice-current-r309/tuple-r310/final/b669'","old=r.parent.parent/'invoice-current-r309/tuple-r310/final/b669'")
code=code.replace("r.parent/'integer-chain-r311/candidate-identity.json'","r.parent.parent/'integer-chain-r311/candidate-identity.json'")
code=code.replace("out=r/'b676'","out=r/'b678'").replace('window-capacity-b676-20261113','window-capacity-rough-b678-20261113').replace('lython-b676-window-capacity-20261113','lython-b678-window-capacity-rough-20261113').replace("replace('b669','b676')","replace('b669','b678')")
old="assert len(retire)==1 and retire[0]['sha256']=='8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2'"
assert old in code
code=code.replace(old,"assert len(retire)==2 and {x['sha256']for x in retire}=={'fd258a65c96f54b0f6a9d70f4af300c7ad3121e633cc9dd9f9de7fc811bea470','2e74ef4fd844a4940f4e7800d0d801e6353babf124f35a720ebc2aa025b0c1ae'}")
a=code.index("config['retireArchives']=[]");b=code.index("(out/'config.json')",a)
code=code[:a]+"config['retireArchives']=[]\n"+code[b:]
code=code.replace('B676','B678').replace('prior8f','superseded fd/2e').replace("replace('B668','B676')","replace('B668','B678')")
ast.parse(code);(r/'rough/prepare-vm.py').write_text(code,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(r/'rough/prepare-vm.py')],check=True)
