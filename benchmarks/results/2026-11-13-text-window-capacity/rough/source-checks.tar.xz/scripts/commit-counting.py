import subprocess
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
for args in [['add','--','benchmarks/results/2026-11-13-text-window-capacity/counting','benchmarks/EXPERIMENTS.md'],['diff','--cached','--check'],['commit','-m','Preserve counted-window admission evidence before simplification [skip ci]'],['push','origin','master']]:subprocess.run(['git',*args],check=True)
