from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'integer-chain-r311/allocation-b673';out=r/'allocation-b677';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
catalog=r.parent/'arithmetic-source-r305/b661/retrieved/representative.json'
cases=json.loads(catalog.read_text(encoding='utf-8'))['cases'];assert len(cases)==8 and all('fixtureJson'in c for c in cases)
driver=r.parent/'composed-native-r303/tool/bin/Release/net11.0'
identity=dict(purpose='R314 eight existing complete-script allocation diagnostics, unchanged original ALC tool; clocks diagnostic, exact91 versusfd source pair',coreSHA256={'reference':source['referenceSHA256'],'candidate':source['coreSHA256']},catalogSHA256=sha(catalog),sourceIdentitySHA256=sha(r/'candidate-identity.json'),driverSHA256=sha(driver/'complete-jobs.dll'),driverSourceSHA256=sha(r.parent/'composed-native-r303/tool/Program.cs'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
root='/home/lokad/lython-bench-checks/window-capacity-allocation-b677-20261113';oldroot='/home/lokad/lython-bench-checks/integer-chain-allocation-b673-20261113'
for name in ['collect.py','run.sh','retrieve.py','summarize.py']:
 code=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('/home/lokad/lython-bench-checks/integer-chain-b672-20261113','/home/lokad/lython-bench-checks/window-capacity-b676-20261113').replace('lython-b673-integer-allocation-20261113','lython-b677-window-allocation-20261113').replace('B673','B677')
 if name=='collect.py':code=code.replace("len(data['observations'])==2","len(data['observations'])==8")
 if name.endswith('.py'):ast.parse(code)
 (out/name).write_text(code,encoding='utf-8',newline='\n')
files={n:out/n for n in ['collect.py','run.sh','identity.json']}
for suffix in ['dll','deps.json','runtimeconfig.json']:files['complete-jobs.'+suffix]=driver/('complete-jobs.'+suffix)
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
config=dict(root=root,unit='lython-b677-window-allocation-20261113',sourceRoot='/home/lokad/lython-bench-checks/window-capacity-b676-20261113',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b673','b677')
needle=" for name in ['catalog.json','witness.json','complete-jobs.dll','complete-jobs.deps.json','complete-jobs.runtimeconfig.json']:os.link(prior/name,root/name)"
assert needle in code
code=code.replace(needle," os.link(source/'representative.json',root/'catalog.json')\n os.link(prior/'witness.json',root/'witness.json')")
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
print('B677 prepared: original unchanged8-case ALC driver, original VM catalog, no producer/runtime/tool rewrite; payload',config['unpackedBytes'],'bytes.',flush=True)
