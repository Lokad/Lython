from pathlib import Path
import os, subprocess
r=Path(__file__).parent
sdk=Path('C:/Users/JoannesVermorel/.dotnet11')
env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
names=['BufferedLineAdmission','TextWindow','TextReaderStorageOwnership','ChunkedRead','ChunkedFileRead','MixedTextWindowReads','Utf16CodecWindow','CsvReaderInputHandling','JsonReaderReentrancy','ReaderAbandonment']
for kind in ['internal','public']:
    project='tests/'+('Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' if kind=='internal' else 'Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj')
    for phase in ['build','test']:
        p=r/('restored-'+kind+'-'+phase+'.log'); assert not p.exists()
        args=[str(sdk/'dotnet.exe'),phase,project,'-c','Release','-f','net11.0','--disable-build-servers']
        args+=['-m:1','--no-restore','--no-incremental'] if phase=='build' else ['--no-build','--filter','Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names)+')','--logger','console;verbosity=normal']
        with p.open('w',encoding='utf-8') as log: done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        txt=p.read_text(encoding='utf-8');print(p.name,done.returncode,txt[-1600:],flush=True)
        assert done.returncode == 0 and 'No test matches' not in txt
    if kind=='public':
        p=r/'restored-compressed-public-test.log';assert not p.exists()
        names2=['GzipFileCompatibilityTests','GzipFileProtocolCompatibilityTests','GzipCallbackScopeLifetimeTests']
        args=[str(sdk/'dotnet.exe'),'vstest','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.PublicApi.Tests.dll','--TestCaseFilter:Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in names2)+')','--logger:console;verbosity=normal']
        with p.open('w',encoding='utf-8') as log: done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        txt=p.read_text(encoding='utf-8');print(p.name,done.returncode,txt[-1600:],flush=True)
        assert done.returncode == 0 and 'Test Run Successful.' in txt
