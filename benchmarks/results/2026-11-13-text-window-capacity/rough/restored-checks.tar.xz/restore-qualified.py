from pathlib import Path
import hashlib, json, subprocess, tarfile

r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-13-text-window-capacity/rough')
identity = json.loads((r/'rough/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p,h in identity['sources'].items())
for folder in [out, out/'allocation']:
    receipt = json.loads((folder/'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['allWorkersJoined']
    assert hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
with tarfile.open(out/'source-checks.tar.xz') as a:
    assert a.extractfile('candidate-identity.json').read() == (r/'rough/candidate-identity.json').read_bytes()
    assert a.extractfile('candidate-core.dll').read() == (r/'rough/candidate-core.dll').read_bytes()
    for name in ['TextWindowCapacityAdmissionTests.cs', 'MixedTextWindowReadsTests.cs']:
        assert a.getmember('tests/'+name).size > 0
target = 'src/Lokad.Lython/Runtime/LythonRuntime.TextFileHandle.Read.cs'
Path(target).write_bytes(subprocess.check_output(['git','show','40d92aef:'+target]))
old = Path('tests/Lokad.Lython.Tests/TextWindowCapacityAdmissionTests.cs')
new = old.with_name('BufferedLineAdmissionTests.cs')
assert not new.exists()
new.write_text(old.read_text(encoding='utf-8').replace('TextWindowCapacityAdmissionTests','BufferedLineAdmissionTests'),encoding='utf-8')
old.unlink()
tracked = subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
for p in tracked:
    expected = subprocess.check_output(['git','show','40d92aef:'+p]).replace(b'\r\n',b'\n')
    assert Path(p).read_bytes().replace(b'\r\n',b'\n') == expected, p
print('Canonical rough evidence verified; restored qualified production; retained observable regressions.', flush=True)
