from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-13-text-window-capacity/rough')
for name,count in [('internal',198),('public',42),('compressed-public',64)]:
    p=r/('restored-'+name+'-test.log')
    text=p.read_text(encoding='utf-8');assert 'Test Run Successful.' in text and f'Passed: {count}'in text
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
proof={}
for p in paths:
    expected=subprocess.check_output(['git','show','40d92aef:'+p]).replace(b'\r\n',b'\n')
    actual=Path(p).read_bytes().replace(b'\r\n',b'\n');assert actual==expected,p
    proof[p]=hashlib.sha256(actual).hexdigest()
(r/'restored-source-proof.json').write_text(json.dumps({'reference':'40d92aef','normalization':'CRLF to LF','sources':proof},indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'restored-checks.tar.xz','w:xz')as a:
    for p in sorted(r.glob('restored-*.log')):a.add(p,arcname=p.name)
    for name in ['restored-source-proof.json','record-restored.py','restore-qualified.py','check-restored.py']:a.add(r/name,arcname=name)
    for p in [Path('tests/Lokad.Lython.Tests/BufferedLineAdmissionTests.cs'),Path('tests/Lokad.Lython.PublicApi.Tests/MixedTextWindowReadsTests.cs')]:a.add(p,arcname=p.name)
print(f'{len(proof)} restored production inputs match qualified40;198 internal/106 public pass.',flush=True)
