from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config={'root': '/home/lokad/lython-bench-checks/window-capacity-b676-20261113', 'unit': 'lython-b676-window-capacity-20261113', 'sourceRoot': '/home/lokad/lython-bench-checks/integer-chain-b672-20261113', 'catalogRoot': '/home/lokad/lython-bench-checks/integer-b661-20261113', 'sourceCoreSHA256': '91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78', 'identity': {'auxiliaryFiles': {'Azure.Core.dll': '1d6df436afdc73c30d476be938f6513c90ef8fc884a7bae280091a9bed0a5490', 'Azure.Identity.dll': '31574a3d35ffeb0e25a00ebb317937222fe5283b91af608613f2e3bf0f26c50a', 'BenchmarkDotNet.Annotations.dll': '97974c60500f53a3c7d142088b22d815aae7aac729de69f4b497132cc436594f', 'BenchmarkDotNet.dll': '599ded314fe77dbc17318557e787cf660c1fcb0d69be39994ea462ca95745896', 'CommandLine.dll': '8a55501cd1a1590a4bd93a17c6fdd2c01a0ed5bff1aea9036bdc78d98c9a3fad', 'deniszykov.WebSocketListener.dll': 'c86cfb93e32192ae12fb1a132b4ae785a7d2f325e8583c03c99abf8e832d25d6', 'Dia2Lib.dll': '6c4cac68010fe032218efe5e9fcf46eef9f77bfaa5f3bd33f03c5ff77d5a8fac', 'Gee.External.Capstone.dll': '6dfda67784598de9677173b89d0692593935f1a4024d36040c95dea48c1b5965', 'Iced.dll': 'f058c01321b4cdfc9b9151879e88e59571c8d0ba176fbcf95bc936a8f3d073ed', 'Lokad.Lython.Benchmarks.deps.json': 'b47f293f779ce46eefa92c6eb775842efe363be212c35bf7d155d0b89734d450', 'Lokad.Lython.Benchmarks.dll': 'fec79afdb8425f18aa962d5ff9a3e51ae52f519072ea9d9db8ab69a0c52b69a6', 'Lokad.Lython.Benchmarks.runtimeconfig.json': 'c2ecf2430d6785354d9099b35eef9d6ac3d72f2089dc3dc9fd723558265b83d0', 'Lokad.Lython.Utf8Regex.dll': '9f7282ade883f103956efaf7e46182f7705fb7675f1f46963b9c42ae5aae7f94', 'Lokad.Utf8Regex.dll': 'af5fb1e550cf23559bc7e26ef3d895b45e5ef98d57bcf46b414785a6e24cc857', 'Lokad.Utf8Regex.PythonRe.dll': '96e45b20c1db361a9b3b94bd557405b413510801bdb1488ae5b15d6aae7aedfe', 'Microsoft.Bcl.AsyncInterfaces.dll': 'bf58b47923b2f520c766ca905f68a1a65d217c4d828f05db538c41129cacf9d9', 'Microsoft.CodeAnalysis.CSharp.dll': '1af1de8a162d2312eb2f6b781f5edbe8cec7d5cd268c7e4de24396225e54260f', 'Microsoft.CodeAnalysis.dll': '42c9ce7891470f430267e2dc02d03571f9d046a7e7e121107754bee58d344613', 'Microsoft.Diagnostics.FastSerialization.dll': 'e5bdad179ce97180646f37f357cb7b449f5baaf76f185eb09510eeafc5b773e1', 'Microsoft.Diagnostics.NETCore.Client.dll': 'e2cc9e1f6c97b3c4ee45ebabaa92408eb9b2fc81cb08ceeb342fe48bf79db15f', 'Microsoft.Diagnostics.Runtime.dll': '52d5f113180bb0f70b1a9b10608aef93b187364ac689885d2d3c734102d850a2', 'Microsoft.Diagnostics.Tracing.TraceEvent.dll': '92401392ce1887c3483a3c0085e6cc3656ee39da1be539943096ebabbad6ea21', 'Microsoft.Identity.Client.dll': '5795027e9ae95eececb310a4fed3c502bb368039d186ab0884f64b7792b84717', 'Microsoft.Identity.Client.Extensions.Msal.dll': '07109a2f30df782300077a567ade47cbd0a0502c75cd7c8a62192f7d64bb004e', 'Microsoft.IdentityModel.Abstractions.dll': '24e97b54b6b5c234a124a336757e3116617ac6c30b655cdae74517dc2ecb5746', 'Perfolizer.dll': '4a5508174e2b90a651a29e1de0d2ad88236daaaae01070cd6fc8ca3c36beaa36', 'Pragmastat.dll': '7217e206e47de8a0335f58513019d5805a6e52ca2e8f127e2cc3944f1742bb2e', 'System.ClientModel.dll': 'dec5e22b71a1685c5e6e97cd28b629f0aa6703fb87b6950df28e79fc1804290c', 'System.Memory.Data.dll': '2c1035b0106dbb2de7913d151e06071ed617bb58bbb3d6cd46a2dd0f6a03617b', 'System.Security.Cryptography.ProtectedData.dll': '80566f0839ece5946e66bf9f00d723e59e371ba1341a18e00c7c7a7c49298e1d', 'TraceReloggerLib.dll': '6830c0f1d3f3c17719181e73dd5cfa8ccbb3f3c575329d2120576545103467b5'}, 'referenceSourceIdentitySHA256': '74425344d27a0ee2b0c355e8699670f49a039eced6b6f647a334e9455072b99d', 'sourceRevision': 'Qualified40d92aef/91d0540d versus uncommittedfd258a65 decoded-window header capacity', 'purpose': 'Complete file-search/captured-text/JSON warm, invoice/report controls; no new CPython ratio', 'coreSHA256': {'reference': '91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78', 'candidate': 'fd258a65c96f54b0f6a9d70f4af300c7ad3121e633cc9dd9f9de7fc811bea470', 'reference-control': '91d0540d439109dd35f3246c4c6234a69a2bc2b698012c83859e9d425d14cc78', 'candidate-control': 'fd258a65c96f54b0f6a9d70f4af300c7ad3121e633cc9dd9f9de7fc811bea470'}, 'catalogSHA256': 'e4fa68ee8743e9014caeffe5ad15a1871fb60a1ab81e119758819144de94b6c6', 'sourceIdentitySHA256': '7c644abe52f8fe2021cefd99c39b11a2432765c399379071f2bc0f8faa8f8d23', 'productionSourceArchiveSHA256': '8ca19a33ac276b68f81a9f6c0d9f175adc970ad3950075dc03b70e95571111a7'}, 'retire': [{'path': 'integer-chain-b672-20261113/reference/Lokad.Lython.dll', 'canonical': {'canonical': 'benchmarks/results/2026-11-13-native-tuple-return/final/source-checks.tar.xz', 'member': 'candidate-core.dll', 'bytes': 5679104, 'sha256': '8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2'}, 'sha256': '8f69261d79a3e32a563bb374d1ad9bc49b980b1b9884fbf697fea02996068aa2', 'device': 66305, 'inode': 845934, 'links': 6, 'bytes': 5679104, 'allocatedBytes': 5685248, 'allAliasesInBase': True, 'aliases': ['integer-report-b674-20261113/reference/Lokad.Lython.dll', 'native-return-external-b671-20261113/candidate/Lokad.Lython.dll', 'native-return-external-b671-20261113/reference/Lokad.Lython.dll', 'integer-chain-b672-20261113/reference/Lokad.Lython.dll', 'tuple-return-final-b669-20261113/current-core.dll', 'tuple-return-final-b669-20261113/candidate/Lokad.Lython.dll']}], 'payloadBytes': 1924105, 'payloadSHA256': '5e862f40c6a73da73b517859f93130f6c0bc44bfe58c4a2331e3984e75cc38fd', 'unpackedBytes': 5772054, 'retireArchives': [{'path': 'native-return-external-b671-20261113/observations.tgz', 'canonical': 'benchmarks/results/2026-11-13-native-return-cpython-checkpoint/observations.tgz', 'bytes': 131428, 'sha256': 'd1a1f2a3c3baac3cf6f905593f323e616fb6be2461b2fde9f441bfd9ffe90a00'}, {'path': 'file-search-source-b675-20261113/observations.tgz', 'canonical': 'benchmarks/results/2026-11-13-file-search-source-gate/observations.tgz', 'bytes': 265819, 'sha256': '1ee7691eef86b70f3f25992bc9866e3b49f87b9ffff9756228db54ca731eccea'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True)
 assert users.returncode==1,users.stdout
 assert digest(source/'candidate/Lokad.Lython.dll')==config['sourceCoreSHA256']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 for row in config['retireArchives']:
  p=base/row['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==row['bytes']and digest(p)==row['sha256']
 for row in config['retireArchives']:
  p=base/row['path'];assert digest(p)==row['sha256'];p.unlink()
 before=shutil.disk_usage(base).free
 assert before+sum(p['allocatedBytes']for p in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 # Retire only exact, obsolete VM working copies whose bytes are already
 # independently verified in tracked canonical archives; current91 and canonical older snapshots stay.
 for row in config['retire']:
  actual=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    p=Path(folder)/name;s=p.lstat()
    if(s.st_dev,s.st_ino)==(row['device'],row['inode']):actual.append(str(p.relative_to(base)))
  assert sorted(actual)==sorted(row['aliases'])and len(actual)==row['links'] and row['links'] >= 1
  for p in [base/a for a in row['aliases']]:
   s=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and s.st_uid==os.getuid()
   assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links'],row['bytes'])and digest(p)==row['sha256']==row['canonical']['sha256']
 for row in config['retire']:
  for i,a in enumerate(row['aliases']):
   p=base/a;s=p.lstat();assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(row['device'],row['inode'],row['links']-i,row['bytes'])and digest(p)==row['sha256'];p.unlink()
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 for name in ['reference-source-identity.json','cpython-worker.py']:os.link(source/name,root/name)
 catalogSource=Path(config['catalogRoot']);assert catalogSource.parent==base
 os.link(catalogSource/'representative.json',root/'representative.json')
 assert digest(root/'current-core.dll')==config['identity']['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  shutil.copytree(source/'candidate',root/role,copy_function=os.link,ignore=shutil.ignore_patterns('Lokad.Lython.dll'))
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'current-core.dll',root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(root/role/name)==sha
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retired=config['retire']+config['retireArchives']),indent=2)+'\n')
 assert shutil.disk_usage(base).free>252*1024*1024+2*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b676-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
