using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var sources = JsonSerializer.Deserialize<string[]>(File.ReadAllText(args[0]))!;
var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
var rows = new object[sources.Length];
for (var i = 0; i < sources.Length; i++)
{
    using (var script = engine.Compile(sources[i], budget))
        rows[i] = new { source = sources[i], script.IsValid, script.Diagnostics };
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation allowance did not return to baseline.");
}
File.WriteAllText(args[1], JsonSerializer.Serialize(new { core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))), rows }));
