# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication and tagging postponed.
Objective: coherent design simplification and substantial complete-script performance.
An isolated experiment does not complete that objective. Historical narratives,
original failed conditions and raw measurements remain in benchmarks/EXPERIMENTS.md
and results; docs describe the current implementation.

## Delivery status

| Work | Actual status |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native-return allocation −19.92%/−19.31%; original elapsed diagnostic. Formatting allocation −8.67%; controlled B102 elapsed/CPU −5–8%, original adverse 15.125 ms preserved and unexplained. Do not repeat unchanged qualification. |
| R62 / 70267889 | Fully qualified CI42412531882, cached terminal green. |
| R65/R66 / 824fc6bb | Fully qualified CI42418518578: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed core consumers. |
| R67 / 5076359c | Current CPython guide measures 824fc6bb/core15c04e2a, 23 jobs/478.32 s. Compile, warm and compile-to-result separate; I/O/validation/cleanup boundaries explicit. Original failed B406 and historical 55e510ff preserved. Not today's HEAD. |
| R68 / 5076359c | Exact immutable dev55/d6067925: 86 internal/514 public per actual 11/10, unchanged adapter bridge. Normal optional 0.4 pin/core unchanged. Development compatibility only. |
| R69 / fd5ab1c1 | Complete returned-record CSV script, independent goldens/CPython checks and current attribution committed; production unchanged. |
| R70 / 7a81a629 | Fully qualified CI42422556519: Windows/Ubuntu Release actual 11/10, original Stress and installed consumers. Cached terminal receipt; never requery. Immutable tuple unpacking removes iterator/list/copy/reservation work. Allocation −13.57% sync/−14.40% async; controlled affected elapsed −6.45–7.45% sync/−7.01–9.34% async. |
| R71 / f88191f7 + a34f56b5 | f88191f7 fully qualified CI42426106105, cached terminal green. Subsequent readonly transport correction: 1,366 internal/244 public per actual11/10, B427 complete; fully qualified with R72 by CI42428096630. B424/B425 adverse originals retained. |
| R72 / 68d5bffe | Committed/pushed. 1,729 internal/597 public per actual11/10, matching probes, 20 baseline cases. B428 complete/archived/verified: allocation −23.48% sync/−21.69% async; affected controlled elapsed −1.92–4.79% sync/−2.76–6.49% async. FULLY QUALIFIED CI42428096630: Windows/Ubuntu actual11/10, original Stress and installed core consumers; terminal cached, never requery. |
| R73 /21b0bc72 | Targeted current returned-record CPython baseline committed; source68/corea0, five jobs107.44s. Guide revision boundaries explicit; no wholesale replay. |
| R74 /33b6c191 | Fully qualified CI42431587731; controlled complete float report benefit, neutral allocation, original adverse controls retained. |
| R75 /79657355+c384956f | Text storage gate, missing current allocation capture; raw failures consolidated/verified, no storage prototype or timing claim. |
| R76 prerequisite /06651b11 | Unicode cache cancellation correction committed; reproduced failure,67internal/135public per actual11/10 pass. Full qualification batches with next retained milestone. |

## Fully qualified retained checkpoint

Latest fully qualified runtime33b6c191: cached green CI42431587731 includes
Windows/Ubuntu Release actual11/10, original Stress both targets and installed
core consumers. Earlier R71/R72 baseline receipts remain cached; never repeat
unchanged qualification. This does not qualify later06651b11 cache cancellation.
Publication/tagging remain postponed; the complete-script objective remains open.

B429/R73 is complete: five jobs/107.441s, source68d5bffe/corea0aef9ef, exact
source/Ready/reference/runtime/golden/quiet/join/fixture/archive gates pass.
Returned-record CSV compile1.07–1.10×, warm1.32–1.35×, compile-to-result1.31–1.34×
CPython3.13.16 (variable control/compilation IQR). Current ordinary CSV warm
1.16–1.19× variable, text1.67–1.68× diagnostic. Authoritative docs/BENCHMARKS.md
marks new revision/date, separates all three boundaries, and preserves valid older
source824fc6bb rows. No inferred source-pair ratio, wholesale replay or general CPU
gain. Histories/raw evidence stay under benchmarks/results and EXPERIMENTS.

R71/B425's large ordinary-CSV adverse observation is not reproduced after concrete
Linux transport correction; its full cause is unproven. R72 retains text mixed/
adverse coarse CPU up to+6.67%. Original conditions/results stay visible; no debt
repayment by unrelated improvements. Further release acceptance must decide any
remaining regression debt. The complete-script performance objective is still open.

## Retained R74 / completed R75 gate

R74 committed/pushed33b6c191 replaces the lexer-validated JSON float entry with
native UTF-8 conversion, removing general culture/format entry and no fallback.
2,191 CPython bit/consumption cases and257internal/1,160public pass per actual11/10.
Allocation neutral; B430 terminal/archived/verified: complete float report elapsed
−11.40–12.03% sync/−10.05–14.08% async, integer/text controls near baseline.
Original36.7% unchanged-control drift/new desktop integer+7.75–12.57% retained.
FULLY QUALIFIED CI42431587731: Windows/Ubuntu actual11/10, original Stress both
targets and installed core consumers PASS. Terminal receipt cached; never requery.
This qualifies33b6c191, not the subsequent Unicode-cache cancellation correction.

R75 closes with missing current attribution, no runtime prototype or timing result.
Original B431/B434 staging-floor failures, B432 Ready assumption and B433 Linux
socket-path failure are preserved in results/2026-11-08-text-storage-gate. All
started users joined/owned fixtures unmounted; failure archives locally verified.
No further capture launched. Correcting setup later is permitted, not a failed or
permanently closed design. Do not promote historical type percentages to current.

## R76 retained / next delivery boundary

Completed source903eb346: managed inline8 storage for copied text, native span/
byte-length readers and one prepaid stable memory view. Casing/split/CSV write
directly into reserved final capacity and publish after completion. Adopted buffers
keep full capacity; existing scopes/reservations/metadata headroom fund all storage.
Remove short payload arrays, added stack-copy phase and caller storage branches;
no new owner/ledger/pool/configuration/unsafe code or memory policy. Pure data
views preserve native cleanup after refusal; current execution/provider boundaries
retain cancellation/refusal authority. Commit before publication. Python values
remain immutable after factory completion.

162internal/415public per actual11/10 pass. Two original post-refusal inspection
failures preserved; the fixture now retains a memory view before denial. New small
regressions preserve concurrent stable borrows, cancellation/refusal, retained
capacity and allowance reuse. B435/B436 terminal/archived/verified; never query.
Complete-job allocation text−9.4%, CSV−8–9%, report~−1%. B436 async text elapsed
−2.3–3.3%, report modest improvement, CSV near baseline. Sync text inconclusive
(old spread11.59%). Float async+0.9–2.7% is accepted debt. CPU mixed/quantized;
no universal CPU, CPython or embedding-latency claim. All original092/7eb/5b/
903 sources/adverse results stay behind results/2026-11-08-inline-utf8 links.

Next actions, without waiting for CI:
1. Commit/push this coherent runtime and evidence. Dispatch one full Windows/
   Ubuntu Release actual11/10, original Stress and installed-consumer boundary;
   no duplicate local full suite. Keep cached terminal receipts separate.
2. Refresh representative CPython at this combined checkpoint: compile, warm and
   compile-to-result separate, exact source/controls/goldens, I/O/cleanup explicit.
   Reuse established tooling; one bounded meaningful checkpoint, no new framework.
   Preserve inconclusive/adverse cases; publication remains postponed.
3. Assess complete remaining builtin-method binding/calling paths against current
   source before selecting another redesign. Existing native paths already cover
   common calls; no speculative selector expansion. Require a complete packaging/
   activation phase to disappear and representative complete scripts demonstrating
   the cost. Stop at a concrete phase or insufficient evidence, preserving prior
   call-arena/control and wide-carrier regressions. Do not reopen heap tracing.

## Following substantial redesign boundaries

| Boundary | Evidence / eliminated work / acceptance |
| --- | --- |
| Complete calls/frames and operand transport | Indexed operands/native returns/final slots/deferred contexts already exist. R63 text attribution includes useful arithmetic/dispatch; inclusive calls are not removable CPU. Select a complete remaining transport/activation phase, remove its displaced path. Preserve callbacks, exception state, exact integer promotion/identity, aliases and public projection. No universal tagged-value or arena rewrite without dominant-cost evidence. |
| Per-record storage | R20/R25 shared CSV keys/array transfer/direct JSON slots and R70 tuple borrow supersede the rigidly rejected bulk-CSV attempt. Its 6–8% benefit and adverse control remain historical. Reassess a real remaining construction/copy/capacity phase; no automatic revival. Preserve row mutation/reentry/hooks/order/retained aliases. |
| Bulk text/JSON | Direct UTF-8 casing/lower-split/formatting/native parsing, completed JSON loop and shared line scanner delivered. R61 measured ordinary JSON has no escaped tokens. Select a demonstrated whole conversion/storage phase, preserve Unicode/context/hooks/async I/O; no succession of narrow special cases. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining class/function demands have distinct scope/annotation rules. Require concrete repeated-walk deletion with exact diagnostics; no speculative visitor/cache/parser migration. |

For each selected milestone record the hypothesis, work/storage eliminated, affected
complete scripts, semantic/cancellation/admission acceptance and old implementation
removed. One bounded source/generated-code assessment; focused attribution only if
existing evidence cannot select. Stop at a concrete phase or insufficient evidence,
then choose another boundary. Prior call-arena/call-control slowdowns remain lessons,
not dormant alternatives. Architectural simplification, allocation reduction, elapsed
and CPU are distinct. Fixed improvement percentages inform judgment, never automatic
vetoes. A timeout or unstable unchanged control establishes uncertainty. Allow bounded
confirmation/refinement/measurement correction when justified, retaining all original
adverse and failed conditions. No blanket one-attempt/no-retiming/permanent closure.

At the next combined retained checkpoint refresh representative CPython comparisons:
compilation, warm execution and compile-to-result separately; identical full scripts/
goldens, explicit I/O/validation/cleanup and startup boundaries. Current R67 guide
remains accurate for its named source; do not rerun unchanged qualification after
every experiment or imply that its tables describe today's HEAD.

## Independent regex track

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original-subject
windows, flags/captures/replacements/errors, cache ownership/current tokens and one
provider through frontend/runtime/imports. No Utf8Regex core dependency. Optional
adapter stays nonpackable, normal 0.4 pin. Contract tests, semantic compatibility and
actual backend performance are separate. Development producers/adapter-local bridges
support implementation; missing publication defers only affected final qualification.

Precise dev55 gaps: DetailedData has no separate preparation/working-owner input;
native name lookup lacks enumeration; cursor creation retains its token despite
current-move overloads. Existing bridges remain justified. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.
Released-package/managed-safety/backend-performance qualification remains outstanding;
it must not stop independent core development or performance work.

## Lasting validation and ownership constraints

AGENTS.md governs fully managed/memory-safe code and managed stack admission: no
unsafe/Unsafe/PInvoke/raw pointers/native probes. Preserve host capabilities, effective
cancellation, checked representation bounds, XML depth and bounded I/O chunks.
Borrow the shared allowance for coarse preflights, capacity/replacement overlap,
retained aliases and escaping caches/results. Scope creation reserves nothing; no
hidden allowances/caps/fuel/quotas/tracing/weak reclamation/forced GC. Initial long
streams use bounded host-driven executions. First structured refusal is terminal
through guest suppression/finally returns; native refunds/cleanup remain awaited.
Never retry admission or skip optional storage to recover.

Focused Release checks during iteration; build matching probes, exclude Stress
explicitly when a custom filter is supplied. No overlapping local builds/tests/
measurements. Force nonincremental builds after timestamp-preserving source restores.
Batch full Windows/Ubuntu actual 11/10, original Stress and installed core consumers
at coherent retained boundaries. Use explicit UTF-8. Only core Release pack via
tools/pack.ps1 into artifacts/nuget; no adapter packages/publication/tag promotion.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B436 terminal,
archived/locally verified; never requery. B431–B434 failed setups preserved; no active
collector or owned fixture mount. Persistent storage is near its256MiB staging
floor. B435 normal source-pair comparison complete; no allocation collector/socket needed. Its setup reserves staged bytes plus12MiB evidence headroom and240MiB OSfree floor; earlier256MiB failures remain unchanged. Reclaim only
archive-verified redundant extracts/core links, retaining immutable VM/local proof.
Keep workers/records separate from RAM fixtures; join/unmount/archive under lease
and verify locally. No sole RAM evidence. GitHub observations at least5minutes
apart; cached terminal runs never requeried or duplicate-dispatched. Continue
independent implementation while CI runs. Publication/tagging remain postponed.
