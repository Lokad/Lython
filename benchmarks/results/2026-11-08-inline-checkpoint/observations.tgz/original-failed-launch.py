from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'inline-cpython-b437-20261108';reference=base/'inline-text-b436-20261108/candidate'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(92310+1);assert len(payload)==92310 and hashlib.sha256(payload).hexdigest()=='5bb93e848ae980ce7149c69c5978523b415e42f87dd4dfa3fe090977fb50114d'
 expected='3efc089505566b425dccc2efa18484432b907d757fc4a489f9955f4186fad933'
 archives=[('inline-text-b435-20261108','3667e5951fa22141fd4d01fc0866c74318e4b362910dae8da4f08a1838b50c9e'),('inline-text-b436-20261108','e212d90052b63d5fd73db84df1ea550ccd8b3ed8ace5f733a2846414c34927c0')]
 targets=[]
 for name,digest in archives:
  prior=base/name;receipt=json.loads((prior/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['archiveSHA256']==digest and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==digest
  with tarfile.open(prior/'observations.tgz')as a:assert hashlib.sha256(a.extractfile('baseline-core.dll').read()).hexdigest()==expected
  targets.extend([prior/'baseline-core.dll',prior/'reference/Lokad.Lython.dll'])
 for p in targets:assert p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(base.resolve())and hashlib.sha256(p.read_bytes()).hexdigest()==expected
 before=shutil.disk_usage(base).free
 for p in targets:p.unlink()
 retired=dict(paths=[str(p)for p in targets],coreSHA256=expected,archives=archives,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,allOriginalBytesRetainedInImmutableVmAndVerifiedLocalArchives=True)
 note=base/'inline-cpython-b437-retired-baseline.json';assert not note.exists();note.write_text(json.dumps(retired,indent=2)+'\n')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+8)*1024*1024
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 shutil.copyfile(note,root/'retired-baseline-core.json')
 shutil.copytree(reference,root/'candidate',copy_function=os.link);os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b437-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text());assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for n,h in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==h
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert 'assert len(jobs)==26 'in(root/'collect.py').read_text()and"len(r['jobs'])==26"in(root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerified=True,all26JobsValidated=True,ownerSeconds=570,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=8)
 assert setup['freeBytes']>(240+8)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b437-inline-cpython-20261108','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=570','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
