from pathlib import Path
import datetime,hashlib,json,shlex,subprocess
r=Path(__file__).resolve().parent;payload=(r/'payload.tgz').read_bytes()
remote=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'inline-cpython-b440-20261108';reference=base/'inline-text-b436-20261108/candidate'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(SIZE+1);assert len(payload)==SIZE and hashlib.sha256(payload).hexdigest()=='DIGEST'
 note=base/'inline-cpython-b437-retired-baseline.json';retired=json.loads(note.read_text())
 for name,digest in retired['archives']:
  prior=base/name;receipt=json.loads((prior/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['archiveSHA256']==digest and hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==digest
 for name in retired['paths']:assert not Path(name).exists()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+7)*1024*1024
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 for name in ['identity.json', 'representative.json', 'pre-measurement-plan.md', 'setup-contract.json', 'source.patch', 'focused.json', 'contract.md', 'sizing-correction.json', 'original-failed-launch.py', 'original-failed-launch.log']:os.link(base/'inline-cpython-b438-20261108'/name,root/name)
 shutil.copyfile(note,root/'retired-baseline-core.json')
 shutil.copytree(reference,root/'candidate',copy_function=os.link);os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b440-fixtures',str(fixture)],check=True)
 identity=json.loads((root/'identity.json').read_text());assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for n,h in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==h
 assert set(identity['coreSHA256'])=={'candidate','candidate-control'}
 assert "labels=['CPython','candidate','candidate-control']"in(root/'collect.py').read_text()
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert 'assert len(jobs)==26 'in(root/'collect.py').read_text()and"len(r['jobs'])==26"in(root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerified=True,all26JobsValidated=True,ownerSeconds=570,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7)
 assert setup['freeBytes']>(240+7)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b440-inline-cpython-20261108','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=570','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('SIZE',str(len(payload))).replace('DIGEST',hashlib.sha256(payload).hexdigest())
(r/'launch-command.py').write_text(remote,encoding='utf-8',newline='\n');compile(remote,'launch','exec')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/inline-cpython-b440-launch.py';code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=remote.encode(),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True);(r/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=630)).isoformat(),ownerSeconds=570,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8');print('Observe after '+(now+datetime.timedelta(seconds=630)).isoformat(),flush=True)
