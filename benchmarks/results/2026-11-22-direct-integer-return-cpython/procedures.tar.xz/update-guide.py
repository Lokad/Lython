from pathlib import Path
import json
out=Path("benchmarks/results/2026-11-22-direct-integer-return-cpython")
summary=json.loads((out/"summary.json").read_text(encoding="utf-8"))
rows={(r["case"],r["lane"]):r for r in summary["rows"]}
invoice="scripts.csv-invoice.helper-accumulation"
helper="diagnostic.helper-placement.function-call"
policy="scripts.csv-invoice.method-policy.quoted-control"
factory="scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
def extent(values,digits,unit):
    lo,hi=(f"{n:.{digits}f}" for n in values)
    return f"{lo}{unit}" if lo==hi else f"{lo}–{hi}{unit}"
def row(label,input_or_phase,case,lane,digits):
    data=rows[(case,lane)]
    control=data["lythonControlPercent"]
    other=data["cpythonControlPercent"]
    limit=control if control>=other else other
    engine="Lython" if control>=other else "CPython"
    output=[label,input_or_phase,extent(data["lythonMs"],digits," ms"),extent(data["cpythonMs"],digits," ms"),
            extent(data["ratio"],3,"×"),f"Diagnostic. {engine} worker spread {limit:.2f}%. [B1373]."]
    return "| "+" | ".join(output)+" |"
p=Path("docs/BENCHMARKS.md")
guide=p.read_text(encoding="utf-8")
def replace_row(start,new):
    global guide
    old=next(line for line in guide.splitlines() if line.startswith(start))
    guide=guide.replace(old,new)
replace_row("| Nested-helper CSV invoice |",row("Nested-helper CSV invoice","4,096 records / 127,031 B",invoice,"warm",3))
replace_row("| Fully supplied arithmetic helper, function scope |",
    row("Fully supplied arithmetic helper, function scope","2,048 calls",helper,"warm",4))
replace_row("| Mixed literal-default factory | Compilation only |",row("Mixed literal-default factory","Compilation only",factory,"compile",5))
replace_row("| Mixed literal-default factory | Compile-to-result |",row("Mixed literal-default factory","Compile-to-result",factory,"compile-run",3))
guide=guide.replace("The helper row calls from module scope. In a matched placement","The helper rows call from module and function scope and use different Lython revisions. In a matched placement")
anchor="| [B1369] |"
line=f"| [B1373] | `{summary['source'][:9]}` | 2026-11-22 UTC |"
guide=guide.replace(anchor,line+"\n"+anchor)
anchor="[B1369]:"
guide=guide.replace(anchor,"[B1373]: ../"+out.as_posix()+"/README.md\n"+anchor)
p.write_text(guide,encoding="utf-8",newline="\n")
