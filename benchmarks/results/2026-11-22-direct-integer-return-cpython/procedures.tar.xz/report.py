from pathlib import Path
import json


out = Path("benchmarks/results/2026-11-22-direct-integer-return-cpython")
summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
names = {
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword": "Mixed literal-default factory",
    "scripts.csv-invoice.helper-accumulation": "Nested-helper CSV invoice",
    "diagnostic.helper-placement.function-call": "Function-scoped arithmetic helper",
}
boundaries = {"warm": "Warm", "compile": "Compilation", "compile-run": "Compile to result"}


def extent(values, digits):
    first, last = (f"{value:.{digits}f}" for value in values)
    return first if first == last else f"{first}–{last}"


rows = [
    "| Complete script | Boundary | Lython | CPython | Lython / CPython | Controls L/C | Maximum IQR |",
    "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    digits = {"compile": 5, "warm": 4, "compile-run": 3}[row["lane"]]
    controls = f"{row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.3f}%"
    rows.append(f"| {names[row['case']]} | {boundaries[row['lane']]} | "
                f"{extent(row['lythonMs'], digits)} ms | {extent(row['cpythonMs'], digits)} ms | "
                f"{extent(row['ratio'], 3)}× | {controls} | {row['maxIQRPercent']:.2f}% |")
report = f"""# B1373 Direct integer returns against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu
24.04.4 and .NET 11 RC3. The frozen Lython image from
`{summary['builtImageSource'][:9]}` matches the production runtime at
`{summary['source'][:9]}`.
The external baseline is stock CPython 3.13.16. The nested-helper
invoice reads 4,096 records from 127,031 input bytes. The
function-scoped helper has 2,048 calls. The mixed factory creates
4,096 functions for 2,048 inputs.

"""
report += "\n".join(rows)
report += f"""

Ratios divide Lython elapsed by CPython elapsed and span all pairings
of two process medians per engine. Above one means Lython takes longer.
Two workers per engine and phase warmed for at least eight seconds
and supplied seven rotated timed batches each. Controls show the spread
of the two process medians for each engine.

Warm execution includes RAM-backed input and output where applicable,
captured stdout, golden verification and prior-result disposal. Lython
uses host mediation for file operations. Time to result combines
compilation, execution and their cleanup. Process startup and final
teardown have separate boundaries.

All 112 timed batches and both quiet gates passed in
{summary['elapsedSeconds']:.0f} seconds. Stdout and output files matched
their CPython goldens. The 32-file Lython image and both CPython worker
identities verified. Every worker joined and the persistent archive
was checked before releasing the VM lease.

The mixed factory has no eligible direct return. Its wider CPU debt
in the paired source comparison stays open. This checkpoint measures
both compilation and time to result against CPython on the retained
runtime. It leaves the earlier source-pair comparison independent.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Previous call checkpoint](../2026-11-22-retained-call-transport-cpython/README.md) ·
[Direct return source pair](../2026-11-22-native-direct-integer-return-refined/README.md) ·
[Image verification and procedures](procedures.tar.xz).
"""
(out / "README.md").write_text(report, encoding="utf-8", newline="\n")
