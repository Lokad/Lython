from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/"native-direct-integer-return-refined-20261122"
template=lab.parent/"machine-arithmetic-cpython-20261122"
quiet=lab/"quiet"
core="Lokad.Lython.dll"
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,content):
    if path.suffix==".py":
        compile(content,str(path),"exec")
    path.write_text(content,encoding="utf-8",newline="\n")
def save(path,value):
    write(path,json.dumps(value,indent=2)+"\n")

staged=read(donor/"quiet/config.json")
terminal=read(donor/"quiet/terminal-status.json")
receipt=read(donor/"quiet/archive-receipt.json")
assert terminal["receipt"]==receipt and terminal["exitCode"]=="0"
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease","quietBeforeAndAfter"))
assert sha(donor/"quiet/observations.tgz")==receipt["archiveSHA256"]

assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
rev=subprocess.check_output(["git","rev-parse","e152d1ceb"],cwd=repo,text=True).strip()
subprocess.run(["git","merge-base","--is-ancestor",rev,"origin/master"],cwd=repo,check=True)
prefer="candidate" if read(donor/"decision.json")["decision"]=="Retain" else "reference"
ident=read(donor/"identity.json")
expected=ident[prefer] if prefer=="candidate" else ident["deliveryReference"]
assert not subprocess.check_output(["git","diff",expected,rev,"--","src","tests","benchmarks/Lokad.Lython.Benchmarks","global.json","Directory.Build.props","Directory.Packages.props"],cwd=repo)
files=ident["imageFiles"][prefer]
image=donor/"frozen"/prefer
assert len(files)==32 and {n:sha(image/n) for n in files}==files
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==staged["protocolSHA256"]
verify=donor/f"{prefer}-verify.json"
proof=read(verify)
assert proof["state"]=="Completed" and proof["caseCount"]==8 and proof["catalogSha256"]==staged["catalogSHA256"]==sha(donor/"representative.json")
quiet.mkdir()
shutil.copyfile(verify,lab/"verify.json")
shutil.copyfile(donor/"representative.json",quiet/"representative.json")
current=dict(sourceRevision=rev,imageSource=ident[prefer],productionEquivalent=expected,
    purpose="Complete integer return transport against CPython",
    imageFiles=dict(candidate=files),catalogSHA256=ident["catalogSHA256"],cpythonWorkerSHA256=sha(protocol),
    auxiliaryFiles={n:h for n,h in files.items() if n!=core},
    coreSHA256={label:files[core] for label in ("candidate","candidate-control")})
save(quiet/"identity.json",current)
old=read(template/"quiet/config.json")
root="/home/lokad/lython-bench-checks/direct-integer-return-cpython-b1373-20261122"
unit="lython-b1373-direct-integer-return-cpython-20261122"
invoice="scripts.csv-invoice.helper-accumulation"
helper="diagnostic.helper-placement.function-call"
policy="scripts.csv-invoice.method-policy.quoted-control"
factory="scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
jobs=[(invoice,"warm"),(helper,"warm"),(factory,"compile"),(factory,"compile-run")]
assert set(case for case,lane in jobs)<={c["id"] for c in read(quiet/"representative.json")["cases"]}
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(template/"quiet"/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        begin=source.index("    for case_id,lane in ")
        end=source.index("        assert time.monotonic()",begin)
        source=source[:begin]+f"    for case_id,lane in {jobs!r}:\n"+source[end:]
    if name=="collect.py":
        source=source.replace("time.monotonic()-started<280","time.monotonic()-started<230")
    elif name=="archive-owned.py":
        source=source.replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace("jobs=5,","jobs=4,")
    elif name=="retrieve.py":
        source=source.replace("['jobs']==5","['jobs']==4")
    write(quiet/name,source.replace("B1361","B1373"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as a:
    for name in parts:a.add(quiet/name,arcname=name)
stage=dict(root=root,unit=unit,identity=current,source=staged["root"],sourceRole=prefer,
    sourceFiles=files,sourceCatalogSHA256=staged["catalogSHA256"],donorArchiveSHA256=receipt["archiveSHA256"],
    catalogSHA256=current["catalogSHA256"],retireGroups=[],cpythonWorkerSHA256=sha(protocol),
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/"config.json",stage)
source=(template/"quiet/remote-launch.py").read_text(encoding="utf-8")
begin,end=source.index("\nc=")+1,source.index("\nb=Path(")
source=source[:begin]+"c="+repr(stage)+source[end:]
write(quiet/"remote-launch.py",source.replace("lython-b1361-fixtures","lython-b1373-fixtures").replace("RuntimeMaxSec=340","RuntimeMaxSec=295"))
source=(template/"launch.py").read_text(encoding="utf-8")
write(lab/"launch.py",source.replace("B1361 arithmetic and CSV against CPython","B1373 direct integer returns against CPython").replace("315","265"))
save(lab/"provided-image.json",dict(donor=str(image.relative_to(repo)),role=prefer,revision=rev,files=files))
print("Prepared four external comparison phases using the already-verified frozen image and unchanged catalog.")
