from pathlib import Path
import json
r=Path(__file__).resolve().parent;d=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'direct-global-r509/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44221878836',str(d['run'])).replace('cf052bd5e69253393e73b1579139c5d300d7df93',d['head']).replace('18046','18048')
s=s.replace('all586ProductionInputsMatchMeasuredAbab8760','all586ProductionInputsMatchMeasured1bce52ad')
s=s.replace('benchmarks/results/2026-11-18-direct-global-operands/refined/delivery','benchmarks/results/2026-11-18-buffered-yield-transport/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared16-summary/2388-input/586-production verifier; actual GREEN still required.')
