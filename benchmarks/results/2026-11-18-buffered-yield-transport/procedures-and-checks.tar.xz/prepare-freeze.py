from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'direct-global-r509'
s=(prior/'freeze.py').read_text(encoding='utf-8')
s=s.replace("work=repo/'.git/agent-worktrees/direct-global-r509';prior=r.parent/'bulk-trim-r506'","work=repo/'.git/agent-worktrees/buffered-yield-r510';prior=r.parent/'direct-global-r509'")
a=s.index('names=list(');b=s.index('\nhashes=',a)
s=s[:a]+"names=list(inputs['inputs']);assert len(names)==2388"+s[b:]
s=s.replace('assert len(production)==11,production','assert len(production)==3,production')
s=s.replace("referenceSource='Qualified0691d64f production/frozen65fcf7d0; shared bulk trim'","referenceSource='Committedcf052bd5 production/frozenabab8760; full qualification independently pending, no inherited qualification'")
a=s.index("candidateSource='");b=s.index("',imageFiles=",a)
s=s[:a]+"candidateSource='PrivateR510 oncf052bd5: discarded same-command buffered yields stay inside the existing prefix, eliminating suspension/send result/PopTop transport and completed-yield driver reentry. Existing admitted destinations; external/mirrored/delegated/pending cleanup semantics remain. No opcode/cache/owner/policy. Only core DLL changes in measured image"+s[b:]
s=s.replace("source='R499 candidatecf847936'","source='R509 candidateabab8760; all32 hashes and unchanged catalog verified'")
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared32-file image/source freeze and actual-worker goldens/reuse; run only after corrected nonincremental build/checks finish.')
