from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-buffered-yield-transport'
assert not out.exists();out.mkdir()
decision=dict(retain=True,reference='Fully qualifiedcf052bd5/abab8760',candidate='PrivateR510/1bce52ad',
 reason='Complete ordinary private buffered yield transport in the existing executable prefix; remove suspension/sendNone/PopTop publication and driver reentry. Named complete text warm/fresh benefits with supporting CPU; unchanged ownership and semantics.',
 allocation='Effectively flat; all six accounted peaks unchanged. No memory-capacity or allocation improvement claim.',
 debt='Positional elapsed-1.31..+2.03percent/CPU-0.77..+3.59 with2.26/1.11percent reference/candidate spreads remains inconclusive; possible CPU regression retained. No universal gain, causal attribution to individual removed steps, source-condition subtraction or new CPython ratio.',
 qualification='Focused both actual11/10 each422internal/479public, six goldens/allocation/reuse; full retained delivery separately pending.',
 originalCondition='Initial untimed two-file source and passing checks preserved; source review removed duplicate declined-sum probe. No demonstrated semantic failure or elapsed result for that initial condition.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for name in ['source-gate.json','decision.json','summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','checks.json','candidate-sources.tar.xz','prototype.patch.gz','initial-untimed-source.tar.xz','initial-untimed.patch']:
 shutil.copyfile(r/name,out/name)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or any(x in p.relative_to(r).parts for x in ['frozen','retrieved','bin','obj']):continue
  if p.suffix not in ['.py','.json','.log','.sh','.cs','.csproj']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Buffered yield transport

R510/B935, 2026-11-18 UTC. Private **1bce52ad** oncf052bd5 versus fully
qualified **cf052bd5 / abab8760**. Retain the complete same-command buffered yield
handoff inside the existing executable prefix. An immediately discarded send result
needs no suspended YieldValue/waiting state, prefix return/reentry, send(None)
publication or PopTop dispatch. Duplicate completed-yield driver probes disappear.
No new opcode, framework, owner, cache or resource policy.

Existing admitted List/PyList/sum destinations keep their capacity/pull rules.
Generic join still drains before item validation. Unbuffered send/throw/close,
mirrored namespaces and genuinely suspended I/O retain their boundaries; delegation
uses the same existing resume semantics and pending disposal finishes before work.
A declined sum reaches ordinary addition once, outside its running generator.

Both actual .NET11/.NET10 pass422internal/479public focused cases, including real
delayed I/O, cancellation/awaited close, terminal refusal, aliases and budget reuse.
Two new integer-promotion/reentrant-consumer programs independently pass CPython3.13.2.
Six actual-worker goldens/allocation/reuse pass; every32-file copied image hash and
the catalog were verified before staging. Allocation is effectively flat and all
six accounted peaks are unchanged. No memory improvement claim.

Quiet Azure F4as_v7/Ubuntu/.NET11RC3, default GC/tiering; four jobs154.99seconds,
six-second warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Wider process CPU change | Reference/candidate spread |
| --- | ---: | ---: | ---: |
| Text normalization warm |−10.90..−7.68%|−12.05..−8.38%|1.59/2.00%|
| Text normalization compile-to-result |−10.57..−8.31%|−11.08..−6.41%|1.07/1.44%|
| Floating warm |−2.00..−0.61%|−1.09..−0.43%|1.21/0.20%|
| Positional calls warm |−1.31..+2.03%|−0.77..+3.59%|2.26/1.11%|

Keep the named whole-text benefit and coherent removed transport. Positional-call
uncertainty and possible CPU regression remain explicit debt; textwarm maximum
IQR4.31% also limits precision. No universal gain, new CPython ratio, causal split
between removed steps or subtraction of source conditions. Full platform/original
stress/installed Release qualification is separate, not inherited from the reference.

Warm includes Run, mediated RAM I/O, goldens and prior-result cleanup. Fresh adds
compilation and compiled-owner disposal. Startup/reset/protocol/final cache teardown
are excluded; process CPU includes wider worker costs. Quiet before/after, joined
workers, persistent/local SHA archive and RAM teardown all pass. Only exact committed
old65fc working aliases retire after currentabab full qualification and fresh idle
path/UID/hash/link/all-alias proof; currentabab/catalogs/toolchains/unmatched evidence
remain,254/252MiB floors unchanged. An earlier read-only bfef replica proof found it
absent and retired nothing; original condition retained.

Initial untimed two-file source/passing checks remain preserved. Source review
identified repeated declined-sum probing; no observable failure was demonstrated.
The measured three-production-file refinement consolidates completed yields before
timing. No repeated measurement of an unchanged condition.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw observations](observations.tgz),[identity](identity.json),
[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[source gate](source-gate.json),[checks/procedures](procedures-and-checks.tar.xz).
Publication postponed; broader whole-script performance work continues.
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as a:a.write('''

R510/B935 [buffered yield transport](results/2026-11-18-buffered-yield-transport/README.md), private1bce52ad versus qualifiedabab: completed discarded yields stay inside existing prefix, removing suspension/sendNone/PopTop transport and duplicate driver probes. Both targets422internal/479public/sixgoldens/reuse pass; allocation/peaksflat. Fourjobs154.99s: textwarm7.68–10.90%lower elapsed/8.38–12.05%lowerCPU; textfresh8.31–10.57%lower elapsed/supportingCPU; floating modest benefit. Calls−1.31..+2.03%elapsed/CPU−0.77..+3.59 remain uncertain/debt. Retain coherent transport/named whole-text benefit; full delivery separate. Initial untimed two-file source/repeated-probe review and absent oldbfef proof preserved; all gates/join/SHAarchive/floors pass,currentabab retained. No CPython/universal gain/publication; broader roadmap active.
''')
print('Archived retained R510 source, measurements, controls and all original conditions.')
