from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/buffered-yield-r510';prior=r.parent/'direct-global-r509'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build succeeded.'in(r/'build.log').read_text(encoding='utf-8-sig')
base=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8'));frozen=r/'frozen'
if frozen.exists():assert not(frozen/'identity.json').exists(),'Frozen measured identity already exists.'
frozen.mkdir(exist_ok=True);images={}
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir(exist_ok=True)
 for n,h in base['imageFiles']['candidate'].items():
  assert sha(prior/'frozen/candidate'/n)==h,n
  shutil.copyfile(prior/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 images[role]={n:sha(image/n)for n in base['imageFiles']['candidate']}
 for p in(prior/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
inputs=json.loads((prior/'delivery/inputs.json').read_text(encoding='utf-8'))
names=list(inputs['inputs']);assert len(names)==2388
hashes={n:sha(work/n)for n in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in names:a.add(work/n,arcname=n)
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=work,text=True).splitlines();production=[n for n in changed if n.startswith('src/Lokad.Lython/')]
assert len(production)==3,production
(r/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','HEAD','--']+changed,cwd=work),mtime=0))
identity=dict(referenceSource='Committedcf052bd5 production/frozenabab8760; full qualification independently pending, no inherited qualification',candidateSource='PrivateR510 oncf052bd5: discarded same-command buffered yields stay inside the existing prefix, eliminating suspension/send result/PopTop transport and completed-yield driver reentry. Existing admitted destinations; external/mirrored/delegated/pending cleanup semantics remain. No opcode/cache/owner/policy. Only core DLL changes in measured image',imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=586,changedProductionFiles=production,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
# Reference image/catalog are exact unchanged copies of R499 diagnostics.
for kind in ['preflight','allocation']:
 shutil.copyfile(prior/('candidate-'+kind+'.json'),r/('reference-'+kind+'.json'))
(r/'reference-reuse.json').write_text(json.dumps(dict(all32ImageHashesVerified=True,catalogSHA256=sha(r/'catalog.json'),source='R509 candidateabab8760; all32 hashes and unchanged catalog verified'),indent=2)+'\n',encoding='utf-8')
image=frozen/'candidate'
commands=[
 ('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify',
  '--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe',
  '--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')]),
 ('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),
  str(r/'candidate-allocation.json')])
]
for label,cmd in commands:
 with(r/('candidate-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0,(label,(r/('candidate-'+label+'.log')).read_text(encoding='utf-8'));print('candidate',label,'passes',flush=True)
print('Frozen changed core',images['candidate']['Lokad.Lython.dll'],flush=True)
