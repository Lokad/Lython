from pathlib import Path
import json
r=Path(__file__).resolve().parent;prior=r.parent/'direct-global-r509'
q=json.loads((prior/'delivery/qualification.json').read_text(encoding='utf-8'))
assert q['conclusion']=='success' and q['all586ProductionInputsMatchMeasuredAbab8760']
s=(r.parent/'current-cpu-r508/prove-old-core.py').read_text(encoding='utf-8')
a=s.index('for suffix in ');b=s.index('current=json.loads',a)
s=s[:a]+'''canonical='benchmarks/results/2026-11-18-bulk-trim/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='65fcf7d0d4aff91f3466ac924e87a3c7b4759c3cf9eed4bf130ea4fa0034b6f5'
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
'''+s[b:]
# The old proof template conservatively protects both R506 images. R509 is now
# fully qualified; its measured candidate is current, its old reference may retire.
s=s.replace("current=json.loads((r.parent/'bulk-trim-r506/frozen/identity.json').read_text(encoding='utf-8'));","current={'imageFiles':{'candidate':json.loads((r.parent/'direct-global-r509/frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']}};")
s=s.replace('current65fcAnd5aeImagesPreserved=True','currentAbabImagesPreserved=True').replace("r/'old-core-proof.log'","r/'qualified-retirement-proof.log'").replace("r/'old-core-proof.json'","r/'retirement-candidates.json'")
exec(compile(s,str(r/'prove-qualified-space.py'),'exec'),dict(__file__=str(r/'prove-qualified-space.py')))
