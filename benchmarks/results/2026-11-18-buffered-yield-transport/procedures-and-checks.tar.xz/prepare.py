from pathlib import Path
import json,subprocess
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('cf052bd5')
work=repo/'.git/agent-worktrees/buffered-yield-r510'
assert not work.exists()
subprocess.run(['git','worktree','add','--detach','--no-checkout',str(work),head],cwd=repo,check=True)
patterns=subprocess.check_output(['git','sparse-checkout','list'],cwd=repo/'.git/agent-worktrees/direct-global-r509',text=True)
subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=work,check=True)
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=work,input=patterns,text=True,check=True)
subprocess.run(['git','checkout','--detach',head],cwd=work,check=True)
v=dict(base=head,state='source gate selected; private prototype only',hypothesis='Same-command buffered ordinary yields still publish a suspended value, leave the executable prefix, restore send state and dispatch a PopTop for a result the compiler immediately discards. Complete that private transport inside the existing instruction loop instead.',
 removedWork=['YieldValue/HasYield/waitingForSend staging for a buffered discarded yield','prefix return/reentry for each buffered discarded yield','Resume namespace/send publication when no namespace is mirrored and no callback can run','publication and PopTop dispatch of the unused None send result'],
 unchanged=['generic join drains before validation','all outputs admitted before allocation; existing drain capacity and sum state','unbuffered send/throw/close and yield-from','mirrored namespaces use existing resume semantics','pending async cleanup completes before continuation','no new opcode, framework, owner, cache or policy'],
 scripts=['scripts.text-normalization.large','scripts.float-pairs.large','calls.positional'],
 acceptance=['ordering, aliases, nested yield expressions and retained generators','real delayed host I/O, cancellation and awaited cleanup','terminal refusal, shared-budget cleanup and reuse','actual worker goldens/allocation; one bounded whole-script/control comparison'],
 stopping='Retain only after source/correctness and controlled named benefit or justified simplification/debt decision; refine on concrete evidence, preserve all adversity. Do not infer performance from instruction counts.',publicationHeld=True)
(r/'source-gate.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print('Private R510 source gate prepared at',head)
