from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'direct-global-r509'
terminal=__import__('json').loads((prior/'delivery/terminal.json').read_text(encoding='utf-8'))
assert terminal['conclusion']=='success'
assert __import__('json').loads((prior/'delivery/qualification.json').read_text(encoding='utf-8'))['all586ProductionInputsMatchMeasuredAbab8760']
s=(prior/'prepare-quiet.py').read_text(encoding='utf-8')
s=s.replace("prior=r.parent/'bulk-trim-r506'","prior=r.parent/'direct-global-r509'")
s=s.replace('direct-globals-b933-20261118','buffered-yield-b935-20261118').replace('lython-b933-direct-globals-20261118','lython-b935-buffered-yield-20261118').replace('lython-b933-fixtures','lython-b935-fixtures').replace('B933','B935')
s=s.replace("['scripts.numeric-squared-error.floating.large','compile-run']","['scripts.text-normalization.large','compile-run']")
s=s.replace('Qualified0691d64f production/65fcf7d0 versus privateR509/','Qualifiedcf052bd5 production/abab8760 versus privateR510/')
s=s.replace('Direct adjacent global operands eliminate producer instructions/temp publication; current live lookup and native/resumable paths remain. Complete floating warm/fresh, text/call controls. Untimed cbfe source condition retained; no predicted gain.',
 'Buffered discarded yields complete within the existing instruction prefix without suspension/sendNone/PopTop transport or driver reentry. Complete text warm/fresh, floating and positional controls. Initial two-file untimed condition retained; no predicted gain.')
s=s.replace('Four-job direct-global source pair','Four-job buffered-yield source pair').replace('current65fcPreserved=True','currentAbabPreserved=True')
exec(compile(s,str(r/'prepare-quiet.py'),'exec'),dict(__file__=str(r/'prepare-quiet.py')))
