from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
text_read = lab.with_name('decoded-ascii-file-values-20261124')
flag_calls = lab.with_name('regex-flag-continuations-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)
core = 'Lokad.Lython.dll'
remote_reference = 'decoded-ascii-file-values-b1580-20261124'
remote_root = 'regex-wrapper-cache-b1581-20261124'


def save(path, body):
    path.write_text(body, encoding='utf-8', newline='\n')


def emit_script(name, body):
    compile(body, name, 'exec')
    save(lab / name, body)


prepare = (flag_calls/'prepare.py').read_text(encoding='utf-8')
prepare = prepare.replace('regex-flag-continuations-20261124', 'regex-wrapper-cache-20261124')
prepare = prepare.replace('external-arithmetic-operands-20261124', text_read.name)
prepare = prepare.replace("assert reference.startswith('531499f09')", "assert reference.startswith('36520e2c0')")
prepare = prepare.replace("'bfa9c6ba6'", "'169e13894'")
prepare = prepare.replace('regex-module-index-20261124', flag_calls.name)
prepare = prepare.replace('B1576 await guest flag protocols before regex provider work',
                          'B1581 key regex wrappers by original requested flags')
emit_script('prepare.py', prepare)

collector = (text_read/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector = collector.replace('b1580-', 'b1581-').replace('len(jobs) == 5', 'len(jobs) == 4')
collector = collector.replace('time.monotonic()-started < 315', 'time.monotonic()-started < 265')
assert 'len(jobs) == 4' in collector
compile(collector, 'collect.py', 'exec')
save(quiet/'collect.py', collector)
shutil.copyfile(text_read/'comparison/quiet/run.sh', quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()

launch = (text_read/'quiet.py').read_text(encoding='utf-8')
launch = launch.replace('b1580-decoded-ascii-file-values', 'b1581-regex-wrapper-cache').replace('b1580-', 'b1581-')
launch = launch.replace('RuntimeMaxSec=345', 'RuntimeMaxSec=290').replace('seconds=280', 'seconds=235')
launch = launch.replace('minimum_active = 10 * 1024 * 1024', 'minimum_active = 8 * 1024 * 1024')
launch = launch.replace('A 10 MiB', 'An 8 MiB')
start = launch.index('  retired=[]')
end = launch.index('  root.mkdir()', start)
launch = launch[:start] + "  assert free>=minimum,(free,'needs one candidate core and working room')\n" + launch[end:]
launch = launch.replace("configuration[\"duplicates\"]=json.loads((lab/\"verified-replicas.json\").read_text(encoding=\"utf-8\"))\n", '')
launch = launch.replace("'candidate-core.dll','reference-core.dll'", "'candidate-core.dll'")
launch = launch.replace("   if name=='Lokad.Lython.dll':", "   if role=='candidate' and name=='Lokad.Lython.dll':")
launch = launch.replace('verifiedDuplicateRetired=retired,', '')
remote_stage, = (node.value for node in ast.walk(ast.parse(launch))
                 if isinstance(node, ast.Constant) and isinstance(node.value, str)
                 and node.value.startswith('digest=lambda path:'))
compile(remote_stage, 'remote-stage', 'exec')
emit_script('quiet.py', launch)

summary = (text_read/'summarize.py').read_text(encoding='utf-8')
summary = summary.replace('receipt["warmJobs"] == 5', 'receipt["warmJobs"] == 4')
summary = summary.replace('len(warm["jobs"])==5', 'len(warm["jobs"])==4').replace('timedBatches=140', 'timedBatches=112')
emit_script('summarize.py', summary)

if (comparison/'identity.json').exists():
    payload = quiet/'payload.tar.gz'
    with tarfile.open(payload, 'w:gz') as bundle:
        for name in ('identity.json', 'representative.json', 'jobs.json'):
            bundle.add(comparison/name, arcname=name)
        for name in ('collect.py', 'run.sh'):
            bundle.add(quiet/name, arcname=name)
        bundle.add(lab/'candidate'/core, arcname='candidate-core.dll')
    digest = hashlib.sha256(payload.read_bytes()).hexdigest()
    save(quiet/'upload.json', json.dumps(dict(root=remote_root, reference=remote_reference,
        payloadSHA256=digest, payloadBytes=payload.stat().st_size), indent=2) + '\n')
