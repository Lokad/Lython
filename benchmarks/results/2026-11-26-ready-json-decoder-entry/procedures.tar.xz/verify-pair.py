from pathlib import Path
import json, subprocess, sys

lab=Path(__file__).resolve().parent
root=lab.parents[3]
source=lab.with_name('post-update-arithmetic-routes-20261126')/'prepare-frozen.py'
script=source.read_text(encoding='utf-8')
for old,new in (
 ('converted-dictionary-update-20261126','post-update-arithmetic-routes-20261126'),
 ('"7f7c4ed59"','"df71fc295"'),
 ('catalog=parent/"comparison/quiet/representative.json"','''catalog=lab/"representative.json"
original=read(lab.with_name("post-update-json-attribution-20261126")/"comparison/quiet/catalog.json")
prior_catalog=read(parent/"comparison/quiet/representative.json")
controls=[case for case in prior_catalog["cases"] if case["id"]=="diagnostic.text-summary.nonlocal-computed-width.large"]
assert len(controls)==1
original["cases"]+=controls
catalog.write_text(json.dumps(original,ensure_ascii=False),encoding='utf-8',newline='\\n')'''),
 ('proof["caseCount"]==5','proof["caseCount"]==3')):
    assert old in script,old
    script=script.replace(old,new)
target=lab/'prepare-frozen.py'
target.write_text(script,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',target],check=True)
