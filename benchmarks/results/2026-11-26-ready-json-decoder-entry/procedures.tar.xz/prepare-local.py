from pathlib import Path
import hashlib, json, shutil

lab=Path(__file__).resolve().parent
prior=lab.with_name('arithmetic-operand-outlining-20261126')
comparison=lab/'local'
comparison.mkdir()
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
identity=json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))
for role,files in identity['imageFiles'].items():
    original=lab/'frozen'/role
    assert len(files)==32 and {p.name:digest(p) for p in original.iterdir()}==files
    shutil.copytree(original,comparison/role)
    assert {p.name:digest(p) for p in (comparison/role).iterdir()}==files
shutil.copyfile(lab/'representative.json',comparison/'representative.json')
shutil.copyfile(prior/'local/cpython-worker.py',comparison/'cpython-worker.py')
assert digest(comparison/'cpython-worker.py')==identity['cpythonWorkerSHA256']
save(comparison/'jobs.json',{'warm':[
    ['scripts.json-summary-helpers.large','warm'],
    ['diagnostic.text-summary.nonlocal-computed-width.large','warm'],
    ['scripts.json-summary-helpers.large','warm-async'],
    ['diagnostic.json-service-quantity-totals','warm'],
]})
identity['catalogs']={name:{'sha256':digest(comparison/name)} for name in ('representative.json','jobs.json')}
identity['purpose']='Local diagnostic of the complete JSON decoder entry and two controls.'
save(comparison/'identity.json',identity)
collector=(prior/'local/collect.py').read_text(encoding='utf-8').replace(
    'len(jobs) == 3','len(jobs) == 4').replace('lython-arithmetic-fixture-','lython-json-ready-fixture-')
compile(collector,'collect.py','exec')
write(comparison/'collect.py',collector)
shutil.copyfile(prior/'local/run.sh',comparison/'run.sh')
runner=(prior/'run-local.sh').read_text(encoding='utf-8').replace(prior.name,lab.name)
write(lab/'run-local.sh',runner)
assert all(b'\r' not in p.read_bytes() for p in (lab/'run-local.sh',comparison/'run.sh'))
summarizer=(prior/'summarize.py').read_text(encoding='utf-8').replace('== 3','== 4').replace('timedBatches=84','timedBatches=112')
compile(summarizer,'summarize.py','exec')
write(lab/'summarize.py',summarizer)
