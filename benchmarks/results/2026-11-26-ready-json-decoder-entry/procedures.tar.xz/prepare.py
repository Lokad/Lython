from pathlib import Path
from difflib import unified_diff
import subprocess, zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab/'candidate-source'
source.mkdir()
snapshot=lab/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',snapshot,'df71fc295','--',
                'src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts',
                'tools/LythonProbe','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
                'Directory.Packages.props','global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)

name='src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'
path=source/name
before=path.read_text(encoding='utf-8')
start=before.index('        private async ValueTask<object> ParseJsonTextCoreAsync(')
stop=before.index('        // Reads exactly one value',start)
after=before[:start]+'''        private ValueTask<object> ParseJsonTextCoreAsync(PyString text, JsonLoadOptions options, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            try
            {
                if (options.Prepared) return ParsePreparedJsonText(text, options, context, span, asynchronous);
                var preparation = options.PrepareAsync(context, span, asynchronous);
                return preparation.IsCompleted
                    ? ParsePreparedJsonText(text, preparation.GetAwaiter().GetResult(), context, span, asynchronous)
                    : ResumeJsonTextPreparationAsync(text, preparation, context, span, asynchronous);
            }
            catch (Exception error) { return ValueTask.FromException<object>(error); }
        }

        private async ValueTask<object> ResumeJsonTextPreparationAsync(PyString text, ValueTask<JsonLoadOptions> preparation,
            ExecutionContext context, LythonSourceSpan span, bool asynchronous)
            => await ParsePreparedJsonText(text, await preparation.ConfigureAwait(false), context, span, asynchronous).ConfigureAwait(false);

        private ValueTask<object> ParsePreparedJsonText(PyString text, JsonLoadOptions options,
            ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            context.EnterInterpreterFrame(span);
            var transferred = false;
            try
            {
                var read = ReadJsonValueAsync(text, options, context, span, 0, asynchronous);
                if (read.IsCompleted) return new(FinishJsonText(text, read.GetAwaiter().GetResult(), context, span));
                var continuation = ResumeJsonTextAsync(text, read, context, span);
                transferred = true;
                return continuation;
            }
            finally { if (!transferred) context.LeaveInterpreterFrame(); }
        }

        private static async ValueTask<object> ResumeJsonTextAsync(PyString text, ValueTask<(object Value, int End)> pending,
            ExecutionContext context, LythonSourceSpan span)
        {
            try { return FinishJsonText(text, await pending.ConfigureAwait(false), context, span); }
            finally { context.LeaveInterpreterFrame(); }
        }

        private static object FinishJsonText(PyString text, (object Value, int End) decoded, ExecutionContext context, LythonSourceSpan span)
        {
            context.CheckExecution(span);
            ExecutionState.EnsureInterpreterStack(span);
            var end = SkipJsonWhitespace(text.Utf8Span, decoded.End, context, span);
            if (end < text.ByteLength) throw CreateJsonTrailingDataError(text, end, span, context);
            return decoded.Value;
        }

'''+before[stop:]
path.write_text(after,encoding='utf-8',newline='\n')
diff=unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+name,'b/'+name)
(lab/'candidate.patch').write_text(''.join(diff),encoding='utf-8',newline='\n')
