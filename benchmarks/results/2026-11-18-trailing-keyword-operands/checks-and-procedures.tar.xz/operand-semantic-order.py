events = []
class Fields:
    def keys(self):
        events.append('keys')
        return ['extra']
    def __getitem__(self, key):
        events.append(key)
        return 4
def positional():
    events.append('positional')
    return 3
def mapping(value):
    events.append('mapping')
    return value
def report(record, /, **fields):
    fields['seen'] = record
    return fields
class Reporter:
    def run(self, record, **fields):
        fields['seen'] = record
        return fields
original = {'extra': []}
a = report(positional(), **mapping(original))
b = Reporter().run(positional(), **mapping(Fields()))
print(a['extra'] is original['extra'], list(original), a['seen'], list(b.items()), events)
try:
    report(positional(), **mapping({42: 'invalid'}))
except TypeError as e:
    print(type(e).__name__, str(e))
try:
    Reporter().run(positional(), **mapping({'record': 9}))
except TypeError as e:
    print(type(e).__name__, "multiple values for argument 'record'" in str(e))
target = 17
try:
    target(positional(), **mapping(Fields()))
except TypeError as e:
    print(type(e).__name__, events[-4:])

