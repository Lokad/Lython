from pathlib import Path
import gzip, hashlib, json, subprocess

lab = Path(__file__).resolve().parent
donor = lab.parent / "function-annotation-inputs-r581"
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
manifest = load(donor/"frozen-identity.json")["images"]["candidate"]
image = donor/"frozen/candidate"
assert len(manifest)==32 and all(sha((image/n).read_bytes())==h for n,h in manifest.items())
core = (image/"Lokad.Lython.dll").read_bytes()
assert manifest["Lokad.Lython.dll"].startswith("62665014")
canonical = Path("benchmarks/results/2026-11-18-function-annotation-inputs/candidate-core.dll.gz")
blob = gzip.compress(core, 6, mtime=0)
assert gzip.decompress(blob)==core
canonical.write_bytes(blob)
remote = r"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
assert root == Path('/home/lokad/lython-bench-checks')
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    source = root/'function-annotation-inputs-b1007-20261118/candidate/Lokad.Lython.dll'
    source_stat = source.lstat()
    assert source.resolve()==source and stat.S_ISREG(source_stat.st_mode)
    paths=[]
    for path in root.glob('*/*/Lokad.Lython.dll'):
        info=path.lstat()
        if (info.st_dev,info.st_ino)!=(source_stat.st_dev,source_stat.st_ino): continue
        assert path.resolve()==path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
        assert info.st_uid==os.getuid() and info.st_size==CORE_LENGTH
        assert hashlib.sha256(path.read_bytes()).hexdigest()==CORE_DIGEST
        paths.append(path.relative_to(root).as_posix())
    assert len(paths)==source_stat.st_nlink
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,paths=sorted(paths), links=source_stat.st_nlink)))
""".replace('CORE_LENGTH',str(len(core))).replace('CORE_DIGEST',repr(sha(core)))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
space = json.loads(subprocess.check_output(ssh+['python3 -'],input=remote.encode(),timeout=30))
assert all("function-annotation-inputs-b1007" in p or "retained-closure-profile-b1008" in p or "function-annotation-storage-b1009" in p for p in space['paths'])
proof=dict(paths=space['paths'],bytes=len(core),links=space['links'],sha256=sha(core),canonical=canonical.as_posix(),
           canonicalSHA256=sha(blob),committedBlobVerified=False,kind='exact archived measured replica')
(lab/'quiet-space-pending.json').write_text(json.dumps(dict(freeBytes=space['freeBytes'],replicas=[proof]),indent=2)+'\n',encoding='utf-8')
print(space)
