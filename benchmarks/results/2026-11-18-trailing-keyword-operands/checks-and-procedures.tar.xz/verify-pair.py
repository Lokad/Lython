from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
previous = lab.parent / 'function-metadata-slots-r584'
work = repo / '.git/agent-worktrees/trailing-keyword-operands-r587'
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ['PATH'])
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old_build = previous / 'frozen/candidate'
old_manifest = load(previous / 'frozen-identity.json')['images']['candidate']
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
assert len(old_manifest) == 32 and old_manifest[core].startswith('d1b9f71b')
assert all(sha(old_build / name) == digest for name, digest in old_manifest.items())
catalog = lab / 'catalog.json'


def run(args, output):
    with (lab / output).open('wb') as log:
        subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=75, check=True)

identities = {}
for role in ['reference','candidate']:
    image = lab / 'frozen' / role
    image.mkdir(parents=True, exist_ok=False)
    for name in old_manifest:
        path = work / 'src/Lokad.Lython/bin/Release/net11.0' / core if name == core and role == 'candidate' else old_build / name
        shutil.copyfile(path, image / name)
    for path in old_build.glob('ValidatedAllocation.*'):
        shutil.copyfile(path, image / path.name)
    identities[role] = {name: sha(image / name) for name in old_manifest}
    assert all(value == old_manifest[name] for name, value in identities[role].items() if name != core)
    assert (identities[role][core] == old_manifest[core]) == (role == 'reference')
    run([dotnet, image / worker, '--compare', 'verify', '--catalog', catalog, '--dotnet', dotnet,
         '--python', 'C:/Python313/python.exe', '--python-worker', repo / 'benchmarks/cpython-worker.py',
         '--out', lab / (role + '-verify.json')], role + '-verify.log')
    assert load(lab / (role + '-verify.json'))['state'] == 'Completed'
    run([dotnet, image / 'ValidatedAllocation.dll', image, catalog, lab / (role + '-allocation.json')], role + '-allocation.log')
    assert all(sha(image / name) == digest for name, digest in identities[role].items())
identity = dict(referenceCommit='2215ec040', candidateBase='568ffc248',
                casesSHA256=sha(catalog), images=identities)
(lab / 'frozen-identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
print('Both frozen 32-file images passed the catalogue and allocation diagnostics.')
