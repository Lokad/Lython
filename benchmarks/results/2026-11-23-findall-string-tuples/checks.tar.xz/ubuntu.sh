set -eu
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-findall-references-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-public" --filter 'FullyQualifiedName~Regex|FullyQualifiedName~Glob|FullyQualifiedName~Fnmatch'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-white" --filter 'FullyQualifiedName~Regex|FullyQualifiedName~Tuple|FullyQualifiedName~Admission'
