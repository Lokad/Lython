from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.with_name('module-failure-bindings-20261123')
candidate = repo / '.git/agent-worktrees/regex-findall-references-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text_hash(text):
    return sha(text.encode('utf-8'))


catalog = read(lab.with_name('early-cased-split-20261123') / 'comparison/representative.json')
shape = next(case for case in catalog['cases'] if case['id'].endswith('local-function'))
python = Path('C:/Python313/python.exe')
cases = []
for name, pattern, subject, count in (
    ('two-ascii-groups', '(a)(b)', 'ab ', 4096),
    ('optional-unicode-groups', '(α)?(β)', 'β αβ ', 2048),
    ('wide-groups', '(a)(b)(c)(d)(e)(f)(g)(h)', 'abcdefgh ', 1024),
    ('one-group-control', '(a)', 'ab ', 4096),
):
    source = f'import re\ntext = {subject!r} * {count}\nrows = re.findall({pattern!r}, text)\nprint(len(rows), rows[0], rows[-1])\n'
    answer = subprocess.check_output([python, '-I', '-S', '-X', 'utf8', '-c', source]).decode('utf-8').replace('\r\n', '\n')
    fixture = dict(json.loads(shape['fixtureJson']), size=count)
    fixture_json = json.dumps(fixture, separators=(',', ':'))
    cases.append(dict(shape, id='diagnostic.regex.findall.' + name, source=source, expectedOutput=answer,
        size=count, sourceUtf8Bytes=len(source.encode('utf-8')), expectedOutputUtf8Bytes=len(answer.encode('utf-8')),
        sourceSha256=text_hash(source), expectedOutputSha256=text_hash(answer), fixtureJson=fixture_json,
        fixtureSha256=text_hash(fixture_json)))
catalog['cases'] = cases
write(comparison / 'regex.json', catalog)
proof = read(base / 'comparison/identity.json')
core = 'Lokad.Lython.dll'
runtime = Path.home() / '.dotnet11'
dotnet = runtime / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(runtime), DOTNET_ROOT_X64=str(runtime))
protocol = repo / 'benchmarks/cpython-worker.py'
assert sha(protocol.read_bytes()) == proof['cpythonWorkerSHA256']
roles = {}
images = {}
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name, expected in proof['imageFiles']['candidate'].items():
        source = base / 'candidate' / name
        assert sha(source.read_bytes()) == expected
        if role == 'candidate' and name == core:
            source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core
        shutil.copyfile(source, image / name)
    for extension in ('.dll', '.deps.json', '.runtimeconfig.json'):
        name = 'ValidatedAllocation' + extension
        shutil.copyfile(base / 'candidate' / name, image / name)
    actual = {name: sha((image / name).read_bytes()) for name in proof['imageFiles']['candidate']}
    images[role] = actual
    verify = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog', comparison / 'regex.json',
                    '--dotnet', dotnet, '--python', python, '--python-worker', protocol, '--out', verify],
                   env=env, check=True, timeout=70)
    receipt = read(verify)
    assert receipt['state'] == 'Completed' and receipt['caseCount'] == len(cases)
    assert receipt['launched']['library']['sha256'] == actual[core]
    observations = comparison / (role + '-allocation.json')
    subprocess.run([dotnet, image / 'ValidatedAllocation.dll', image, comparison / 'regex.json', observations],
                   env=env, check=True, timeout=50)
    roles[role] = read(observations)['rows']
    assert all(row['sharedBudgetBaselineRestored'] for row in roles[role])
    assert all(sha((image / name).read_bytes()) == h for name, h in actual.items())

assert [name for name in images['reference'] if images['reference'][name] != images['candidate'][name]] == [core]
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=candidate).decode().strip()
write(comparison / 'identity.json', dict(sourceRevision=proof['candidate'], candidate=revision, imageFiles=images,
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'], catalogSHA256=sha((comparison / 'regex.json').read_bytes())))
summary = []
for reference, current in zip(roles['reference'], roles['candidate'], strict=True):
    assert reference['id'] == current['id']
    allocated = [statistics.median(row['allocatedBytesPerInvocation']) for row in (reference, current)]
    admitted = [row['peakExecutionMemoryBytes'] for row in (reference, current)]
    summary.append(dict(case=reference['id'], allocatedBytes=allocated, peakAdmission=admitted))
    print(reference['id'], allocated, admitted)
write(comparison / 'summary.json', summary)
