from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / 'benchmarks/results/2026-11-23-findall-string-tuples'
comparison = lab / 'comparison'
identity = json.loads((comparison / 'identity.json').read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


retained = git('rev-parse', 'e05aae21c').decode().strip()
assert not git('diff', '--name-only', retained, identity['candidate'], '--', 'src', 'tests')
assert all(sha((lab / role / name).read_bytes()) == h for role, files in identity['imageFiles'].items() for name, h in files.items())
summaries = json.loads((comparison / 'summary.json').read_text(encoding='utf-8'))
assert len(summaries) == 4 and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in summaries)
assert all('Passed:' in (lab / name).read_text(encoding='utf-8') for name in ('windows-public.log', 'windows-white.log'))
assert (lab / 'ubuntu.log').read_text(encoding='utf-8').count('Passed!') == 2
patch = git('diff', '--binary', identity['sourceRevision'], identity['candidate'], '--', 'src', 'tests')
(lab / 'comparison.patch').write_bytes(patch)
identity['retainedRevision'] = retained
identity['comparisonPatchSHA256'] = sha(patch)
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(comparison / 'summary.json', dest / 'allocation-summary.json')
(dest / 'candidate-core.dll.gz').write_bytes(gzip.compress((lab / 'candidate/Lokad.Lython.dll').read_bytes(), mtime=0))
with tarfile.open(dest / 'checks.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'diagnose.py', 'comparison.patch', 'ubuntu.sh', 'windows-build.log',
                 'windows-public.log', 'windows-white.log', 'ubuntu.log', 'comparison/regex.json',
                 'comparison/reference-verify.json', 'comparison/candidate-verify.json',
                 'comparison/reference-allocation.json', 'comparison/candidate-allocation.json'):
        bundle.add(lab / name, arcname=name)
print(dest)
