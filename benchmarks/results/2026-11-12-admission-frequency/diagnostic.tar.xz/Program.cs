using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var evidence = Path.GetFullPath(args[0]);
var image = Path.GetFullPath(args[1]);
var coreHash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
if (coreHash != "e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529") throw new InvalidDataException("Core changed.");
var benchmark = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
var fixtureType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var validate = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.OwnedWorkerProcess", true)!.GetMethod("ValidateFixtureDirectory", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
var reset = hostType.GetMethod("Reset")!;
var outputs = hostType.GetMethod("ReadOutputs")!;
var digest = fixtureType.GetMethod("Digest")!;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[2], System.Text.Encoding.UTF8));
var rows = new List<object>();
var selected = new HashSet<string> { "scripts.csv-validated-records.large", "scripts.text-summary-helpers.nonlocal-counter.large", "scripts.report-render.large" };
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    if (!selected.Contains(id)) continue;
    var fixture = fixtureType.GetMethod("Parse")!.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;
    var owned = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    validate.Invoke(null, [owned]);
    var host = (ILythonHost)Activator.CreateInstance(hostType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null, [fixture, owned], null)!;
    var root = new LythonMemoryBudget();
    var counts = new Counts();
    var budget = new Budget(root, counts);
    try
    {
        using (var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget))
        {
            if (!script.IsValid) throw new InvalidDataException(string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = root.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                reset.Invoke(host, null);
                counts.Reset();
                using (var result = asynchronous ? await script.RunAsync(host) : script.Run(host))
                {
                    if (!result.Success || result.StandardOutput != item.GetProperty("expectedOutput").GetString() || result.StandardError != "") throw new InvalidDataException(result.Failure?.Message ?? "Output differs.");
                    if ((string)digest.Invoke(null, [outputs.Invoke(host, null)])! != item.GetProperty("expectedFilesSha256").GetString()) throw new InvalidDataException("Files differ.");
                }
                if (root.ReservedBytes != baseline) throw new InvalidDataException("Execution owners remain.");
                rows.Add(new { id, asynchronous, counts = counts.Snapshot(), baselineBytes = baseline, finalBytes = root.ReservedBytes });
            }
        }
        if (root.ReservedBytes != 0) throw new InvalidDataException("Compilation owner remains.");
    }
    finally
    {
        // Verify the exact absolute owned temporary directory before recursion.
        validate.Invoke(null, [owned]);
        if (Path.GetFullPath(owned) != owned || Path.GetDirectoryName(owned) != Path.TrimEndingDirectorySeparator(Path.GetFullPath(Path.GetTempPath()))) throw new InvalidDataException("Cleanup target changed.");
        if (Directory.Exists(owned)) Directory.Delete(owned, recursive: true);
    }
}
if (rows.Count != 6) throw new InvalidDataException("Expected three scripts through both APIs.");
File.WriteAllText(Path.Combine(evidence, "observations.json"), JsonSerializer.Serialize(new { revision = "9bca1337", coreHash, diagnosticOnly = true, performanceQualified = false, allGoldensAndBalancesPassed = true, rows }, new JsonSerializerOptions { WriteIndented = true }), new System.Text.UTF8Encoding(false));
Console.WriteLine("Six complete commands: outputs/files/balances pass. Counts only; no timing conclusion.");

sealed class Counts
{
    internal long ReserveCalls, ScopeCreates, ScopeDisposals, ResizeCalls, BytesReads, GrowthCalls, RefundCalls, UnchangedCalls, ReservationDisposals;
    internal long[] GrowthSizes = new long[5];
    internal void Reset() { ReserveCalls = ScopeCreates = ScopeDisposals = ResizeCalls = BytesReads = GrowthCalls = RefundCalls = UnchangedCalls = ReservationDisposals = 0; Array.Clear(GrowthSizes); }
    internal object Snapshot() => new { ReserveCalls, ScopeCreates, ScopeDisposals, ResizeCalls, BytesReads, GrowthCalls, RefundCalls, UnchangedCalls, ReservationDisposals, growthDeltaBuckets = new { atMost64 = GrowthSizes[0], atMost256 = GrowthSizes[1], atMost4096 = GrowthSizes[2], atMost65536 = GrowthSizes[3], larger = GrowthSizes[4] } };
}
class Budget(ILythonMemoryBudget inner, Counts counts) : ILythonMemoryBudget
{
    protected ILythonMemoryBudget Inner => inner;
    protected Counts Counter => counts;
    public ILythonMemoryScope CreateScope() { counts.ScopeCreates++; return new Scope(inner.CreateScope(), counts); }
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        counts.ReserveCalls++;
        if (!inner.TryReserve(bytes, out var owned)) { reservation = null; return false; }
        reservation = new Reservation(owned, counts); return true;
    }
}
sealed class Scope(ILythonMemoryScope inner, Counts counts) : Budget(inner, counts), ILythonMemoryScope
{
    public void Dispose() { Counter.ScopeDisposals++; ((ILythonMemoryScope)Inner).Dispose(); }
}
sealed class Reservation(ILythonMemoryReservation inner, Counts counts) : ILythonMemoryReservation
{
    public long Bytes { get { counts.BytesReads++; return inner.Bytes; } }
    public bool TryResize(long bytes)
    {
        counts.ResizeCalls++;
        var delta = bytes - inner.Bytes; // Diagnostic observation only, outside timing.
        if (delta > 0)
        {
            counts.GrowthCalls++;
            counts.GrowthSizes[delta <= 64 ? 0 : delta <= 256 ? 1 : delta <= 4096 ? 2 : delta <= 65536 ? 3 : 4]++;
        }
        else if (delta < 0) counts.RefundCalls++;
        else counts.UnchangedCalls++;
        return inner.TryResize(bytes);
    }
    public void Dispose() { counts.ReservationDisposals++; inner.Dispose(); }
}
