from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;data=json.loads((r/'observations.json').read_text(encoding='utf-8'));assert data['allGoldensAndBalancesPassed']and len(data['rows'])==6
out=Path('benchmarks/results/2026-11-12-admission-frequency');out.mkdir(exist_ok=True)
shutil.copyfile(r/'observations.json',out/'observations.json')
with tarfile.open(out/'diagnostic.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in('.cs','.csproj','.py','.log'):t.add(p,arcname=p.name)
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in('README.md','manifest.json')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');start=s.index('   R283 source gate:');end=s.index('\n\n3.',start)
s=s[:start]+'''   R283 source gate complete: one pass verifies6229captured-text/13398CSV/
   14425report shared-reservation resizes per command, identical across APIs;
   outputs/files and all ownership baselines pass. These counts and prior monitor
   samples do not establish removable CPU or duplicate funding. Existing per-record
   preflights already combine CSV fields and split words. A governor-wide capacity
   cache would add another balance, prepublication/reentry rules, headroom retention
   and changed refusal thresholds; it is not selected from counts alone. No new
   funding cache, allocator, policy or prototype. [Bounded evidence](benchmarks/results/2026-11-12-admission-frequency/README.md).
'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('R283 bounded source gate archived; no automatic ownership redesign.')
