from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
args=[str(sdk/'dotnet.exe'),'run','--project',str(r/'diagnostic.csproj'),'-c','Release','-f','net11.0','--',str(r),str(r.parent/'captured-slot-ownership-r281/candidate'),str(r.parent/'captured-slot-ownership-r281/catalog.json')]
if (r/'diagnostic.log').exists():
 target=r/('attempt-'+str(len(list(r.glob('attempt-*.log')))+1)+'.log');assert not target.exists();(r/'diagnostic.log').rename(target)
with(r/'diagnostic.log').open('w',encoding='utf-8',newline='\n')as output:done=subprocess.run(args,env=env,stdout=output,stderr=subprocess.STDOUT)
print((r/'diagnostic.log').read_text(encoding='utf-8'),flush=True);assert done.returncode==0
