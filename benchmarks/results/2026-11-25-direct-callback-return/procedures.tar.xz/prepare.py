from pathlib import Path
import hashlib, json, re

lab=Path(__file__).resolve().parent
prior=lab.with_name('direct-operand-return-20261124')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
before=read(prior/'comparison/quiet/identity.json')
receipt=read(prior/'comparison/quiet/terminal-status.json')['receipt']
ref=read(prior.with_name('pair-owned-defaults-20261124')/'comparison/quiet/terminal-status.json')['receipt']
script=(prior/'prepare.py').read_text(encoding='utf-8')
start=script.index("donor=lab.with_name")
end=script.index("core='Lokad.Lython.dll'")
script=script[:start]+'''donor=lab.with_name('direct-operand-return-20261124')
prior=donor/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('e32e2817b')
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch.read_bytes()
old=read(prior/'identity.json')
base=old['sourceRevision']
assert old['sourcePatchSHA256']==sha(donor/'candidate.patch')
'''+script[end:]
start=script.index("source='''import csv")
end=script.index("with tempfile.TemporaryDirectory(",start)
script=script[:start]+'''source=\'''import csv
from itertools import repeat

def choose(flag, preferred, alternative):
    return preferred if flag else alternative

def tally(rows, totals, policies):
    priority, normal, review = policies
    late = [row['late'] == 'yes' for row in rows]
    held = [row['hold'] == 'yes' for row in rows]
    primary = map(choose, late, repeat(priority), repeat(normal))
    results = map(choose, held, repeat(review), primary)
    reviewed = 0
    for row, policy in zip(rows, results):
        reviewed += policy is review
        service = policy['shipping']
        totals[service] = totals.get(service, 0) + int(row['quantity'])
    return reviewed

def report_shipments():
    policies = ({'shipping': 'priority', 'description': 'Retard'},
                {'shipping': 'standard', 'description': 'Prêt'},
                {'shipping': 'review', 'description': 'À vérifier'})
    totals = {}
    reviewed = 0
    rows = []
    with open('shipments.csv', encoding='utf-8', newline='') as input_file:
        for row in csv.DictReader(input_file):
            rows.append(row)
            if len(rows) == 128:
                reviewed += tally(rows, totals, policies)
                rows = []
        if rows:
            reviewed += tally(rows, totals, policies)
    print(reviewed)
    for name in sorted(totals):
        print(name, totals[name])

report_shipments()
\'''
'''.replace("\\'''","'''")+script[end:]
script=script.replace('diagnostic.shipment-routing-report','diagnostic.shipment-routing-callbacks')
start=script.index('manifest=')
end=script.index('shutil.copyfile',start)
script=script[:start]+'''catalog=read(prior/'representative.json')
cases={r['id']:r for r in catalog['cases']}
cases[report]=row
catalog['cases']=[cases[key] for key in (report,rule,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':[[report,'warm'],[invoice,'warm'],[report,'warm-async'],[rule,'compile-run'],[report,'compile-run']]})
'''+script[end:]
script=script.replace('comparisonRevision=base,sourcePatchSHA256=sha(patch)',
    "comparisonRevision=base,referencePatchSHA256=old['sourcePatchSHA256'],sourcePatchSHA256=sha(patch)")
script=script.replace('Return stable existing operands, literals and admitted aliases without native workspace construction',
    'Borrow existing operands for complete short positional callbacks that satisfy the direct operand-return proof')
script=script.replace(".replace('b1658-fixtures','b1659-fixtures')", ".replace('b1659-fixtures','b1661-fixtures').replace('len(jobs) == 6','len(jobs) == 5').replace('targetBatchSeconds=.52','targetBatchSeconds=.60')")
script=script.replace("checked['caseCount']==4", "checked['caseCount']==3")
script=script.replace('direct-operand-return-b1659-20261124', 'direct-callback-return-b1661-20261125').replace('pair-owned-defaults-b1658-20261124', 'direct-operand-return-b1659-20261124')
start=script.index('anchor=')
script=script[:start] + "print('Verified three complete workload goldens on each exact image.')\n"
generated=lab/'verify-and-stage.py'
generated.write_text(script,encoding='utf-8',newline='\n')
compile(script,str(generated),'exec')

launcher=(prior/'quiet.py').read_text(encoding='utf-8').replace(ref['archiveSHA256'],receipt['archiveSHA256'])
launcher=launcher.replace('b1659-','b1661-').replace('direct-operand-return-20261124','direct-callback-return-20261125')
launcher=launcher.replace('seconds=246','seconds=232').replace('RuntimeMaxSec=325','RuntimeMaxSec=295')
assert receipt['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
(lab/'quiet.py').write_text(launcher,encoding='utf-8',newline='\n')
report=(prior/'archive.py').read_text(encoding='utf-8').replace('2026-11-24-direct-operand-return','2026-11-25-direct-callback-return').replace('receipt["warmJobs"]==6','receipt["warmJobs"]==5').replace('timedBatches=168,lanes=6','timedBatches=140,lanes=5')
compile(report,'archive.py','exec')
(lab/'archive.py').write_text(report,encoding='utf-8',newline='\n')
