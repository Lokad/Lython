from pathlib import Path
import json

lab=Path(__file__).resolve().parent
prior=lab.with_name('direct-operand-return-20261124')
script=(prior/'verified-space.py').read_text(encoding='utf-8')
start=script.index("old=lab.with_name")
end=script.index('backup=', start)
script=script[:start]+'''pair=lab.with_name('pair-owned-defaults-20261124')
operand=lab.with_name('direct-operand-return-20261124')
split=lab.with_name('defaulted-rule-phase-split-20261125')
core='Lokad.Lython.dll'
source=pair/'candidate'/core
'''+script[end:]
script=script.replace('verified-b1655-candidate.dll','verified-b1658-candidate.dll')
start=script.index('copies=[]')
end=script.index("payload=quiet/",start)
script=script[:start]+'''stages=(
    ('pair-owned-defaults-b1658-20261124','b1658-pair-owned-defaults-20261124','candidate',pair/'comparison/quiet'),
    ('pair-owned-confirmation-b1658-20261124','b1658-pair-owned-confirmation-20261124','candidate',pair/'confirmation'),
    ('direct-operand-return-b1659-20261124','b1659-direct-operand-return-20261124','reference',operand/'comparison/quiet'),
    ('direct-operand-confirmation-b1659-20261124','b1659-direct-operand-confirmation-20261124','reference',operand/'confirmation'),
    ('defaulted-rule-phase-split-b1660-20261125','b1660-defaulted-rule-phase-split-20261125','reference',split/'confirmation'),
)
copies=[]
for stage,label,role,folder in stages:
    assert read(folder/'identity.json')['imageFiles'][role][core]==sha(backup)
    copies.append(dict(stage=stage,unit='lython-'+label,archive=archive_info(folder),member=role+'/'+core,role=role))
raw=[]
for stage,label,_,folder in stages[2:]:
    checksum=archive_info(folder)
    name='confirmation/confirmation.json'
    with tarfile.open(folder/'observations.tar.xz') as archive:
        member=archive.getmember(name)
        assert member.isfile()
        raw.append(dict(stage=stage,unit='lython-'+label,archive=checksum,member=name,
             bytes=member.size,sha=digest(archive.extractfile(member).read())))

'''+script[end:]
file=lab/'verify-and-free-space.py'
file.write_text(script,encoding='utf-8',newline='\n')
compile(script,str(file),'exec')
