from pathlib import Path
import base64,hashlib,importlib.util,json,os,shutil,subprocess,tarfile,tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('direct-operand-return-20261124')
prior=donor/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('e32e2817b')
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch.read_bytes()
old=read(prior/'identity.json')
base=old['sourceRevision']
assert old['sourcePatchSHA256']==sha(donor/'candidate.patch')
core='Lokad.Lython.dll'
reference=old['imageFiles']['candidate']
assert len(reference)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==reference
candidate=lab/'candidate-build/bin/Lokad.Lython/release_net11.0'/core
images={'reference':reference,'candidate':reference | {core:sha(candidate)}}
assert images['candidate'][core]!=reference[core]
for role,files in images.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(candidate if role=='candidate' and name==core else donor/'candidate'/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==files

path=repo/'benchmarks/cpython-worker.py'
assert sha(path)==old['cpythonWorkerSHA256']
spec=importlib.util.spec_from_file_location('protocol',path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
python=Path('C:/Python313/python.exe')
rows=2048
raw='id,quantity,late,hold\n'+''.join(f'{idx},{idx%23+1},{"yes" if idx%5==0 else "no"},{"yes" if idx%13==0 else "no"}\n' for idx in range(rows))
source='''import csv
from itertools import repeat

def choose(flag, preferred, alternative):
    return preferred if flag else alternative

def tally(rows, totals, policies):
    priority, normal, review = policies
    late = [row['late'] == 'yes' for row in rows]
    held = [row['hold'] == 'yes' for row in rows]
    primary = map(choose, late, repeat(priority), repeat(normal))
    results = map(choose, held, repeat(review), primary)
    reviewed = 0
    for row, policy in zip(rows, results):
        reviewed += policy is review
        service = policy['shipping']
        totals[service] = totals.get(service, 0) + int(row['quantity'])
    return reviewed

def report_shipments():
    policies = ({'shipping': 'priority', 'description': 'Retard'},
                {'shipping': 'standard', 'description': 'Prêt'},
                {'shipping': 'review', 'description': 'À vérifier'})
    totals = {}
    reviewed = 0
    rows = []
    with open('shipments.csv', encoding='utf-8', newline='') as input_file:
        for row in csv.DictReader(input_file):
            rows.append(row)
            if len(rows) == 128:
                reviewed += tally(rows, totals, policies)
                rows = []
        if rows:
            reviewed += tally(rows, totals, policies)
    print(reviewed)
    for name in sorted(totals):
        print(name, totals[name])

report_shipments()
'''
with tempfile.TemporaryDirectory(prefix='lython-routing-golden-') as name:
    Path(name,'shipments.csv').write_text(raw,encoding='utf-8',newline='\n')
    golden=subprocess.run([python,'-I','-S','-X','utf8','-'],cwd=name,input=source,text=True,encoding='utf-8',capture_output=True,check=True,timeout=25)
assert not golden.stderr
file_set={'shipments.csv':base64.b64encode(raw.encode('utf-8')).decode('ascii')}
fixture=json.dumps(dict(size=rows,text=None,inputFiles=file_set,outputFiles={}),ensure_ascii=False,separators=(',',':'))
files_sha=protocol.file_digest(protocol.file_fixture(json.loads(fixture))[1])
report='diagnostic.shipment-routing-callbacks'
row=dict(id=report,family='scripts',category='whole-script',scale='small',size=rows,source=source,fixtureJson=fixture,
    expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(golden.stdout.encode('utf-8')),
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),
    expectedOutputSha256=digest(golden.stdout),expectedFilesSha256=files_sha)
rule='scripts.rule-default-closures'
invoice='scripts.csv-invoice.method-policy.quoted-control'
catalog=read(prior/'representative.json')
cases={r['id']:r for r in catalog['cases']}
cases[report]=row
catalog['cases']=[cases[key] for key in (report,rule,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':[[report,'warm'],[invoice,'warm'],[report,'warm-async'],[rule,'compile-run'],[report,'compile-run']]})
shutil.copyfile(prior/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=base,validationSourceRevision=head,comparisonRevision=base,referencePatchSHA256=old['sourcePatchSHA256'],sourcePatchSHA256=sha(patch),
    purpose='Borrow existing operands for complete short positional callbacks that satisfy the direct operand-return proof',
    imageFiles=images,expectedCPythonSHA256=old['expectedCPythonSHA256'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',identity)
collector=(prior/'collect.py').read_text(encoding='utf-8').replace('b1659-fixtures','b1661-fixtures').replace('len(jobs) == 6','len(jobs) == 5').replace('targetBatchSeconds=.52','targetBatchSeconds=.60')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
sdk=Path.home()/'.dotnet11'
for role,files in images.items():
    output=lab/f'comparison/{role}-verify.json'
    subprocess.run([sdk/'dotnet.exe',lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',sdk/'dotnet.exe','--python',python,'--python-worker',path,'--out',output],cwd=repo,
        env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=75)
    checked=read(output)
    assert checked['state']=='Completed' and checked['caseCount']==3 and checked['launched']['library']['sha256']==files[core]
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(candidate,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='direct-callback-return-b1661-20261125',reference='direct-operand-return-b1659-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
print('Verified three complete workload goldens on each exact image.')
