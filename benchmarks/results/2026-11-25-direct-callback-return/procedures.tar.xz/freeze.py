from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('direct-operand-return-20261124')
identity = json.loads((prior/'comparison/quiet/identity.json').read_text(encoding='utf-8'))
git = lambda args, root=repo: subprocess.check_output(['git', *args], cwd=root)
sha = lambda data: hashlib.sha256(data).hexdigest()
head = git(['rev-parse','e32e2817b']).decode().strip()
assert git(['rev-parse','HEAD']).decode().strip()==head
assert sha((prior/'candidate.patch').read_bytes())==identity['sourcePatchSHA256']
changed=git(['diff','--name-only','--','src']).decode().splitlines()
assert len(changed)==2 and all(path.startswith('src/Lokad.Lython/Runtime/') for path in changed),changed
patch=lab/'candidate.patch'
patch.write_bytes(git(['diff','--binary','--','src']))
(lab/'test.patch').write_bytes(git(['diff','--binary','--','tests']))
frozen=lab/'frozen-candidate'
shutil.copytree(prior/'frozen-candidate', frozen)
files={path.relative_to(frozen).as_posix(): sha(path.read_bytes()) for path in frozen.rglob('*') if path.is_file() and 'obj' not in path.parts}
assert len(files)>300 and all(name in files for name in changed)
git(['init','-q'],frozen)
git(['apply','--check',str(patch)],frozen)
git(['apply',str(patch)],frozen)
for name,before in files.items():
    observed=(frozen/name).read_bytes()
    if name in changed:
        assert sha(observed)!=before,name
    else:
        assert sha(observed)==before,name
(lab/'reference-source-files.json').write_text(json.dumps(files,sort_keys=True,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
with (lab/'candidate-build.log').open('wb') as log:
    subprocess.run([sdk/'dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
        '--no-incremental','--artifacts-path',lab/'candidate-build'],cwd=frozen,env=dict(os.environ,DOTNET_ROOT=str(sdk),
        DOTNET_ROOT_X64=str(sdk)),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
assert git(['diff','--binary','--','src'])==patch.read_bytes()
print('Built the candidate from B1659 candidate source with the isolated callback patch.')
