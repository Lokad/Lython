from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;old=r.parent/'native-consumers-r450/refined/quiet';q=r/'quiet'
q.mkdir(exist_ok=True);assert not list(q.iterdir())
root='/home/lokad/lython-bench-checks/scalar-index-b856-20261116';unit='lython-b856-scalar-index-20261116'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((old/'config.json').read_text(encoding='utf-8'));baseimage=frozen['imageFiles']['reference']
proofs=[];inventory=json.loads((r/'vm-working-replicas.json').read_text(encoding='utf-8'))['workingReplicas']
mappings=[('checkpoint-cpython-b421-20261107/confirmation/confirmation.json','benchmarks/results/2026-11-07-buffered-checkpoint/observations.tgz'),('runtime-cpython-b290-20261105/confirmation/confirmation.json','benchmarks/results/2026-11-05-runtime-cpython-refresh/observations.tgz'),('native-read-checkpoint-b338-20261106/confirmation/confirmation.json','benchmarks/results/2026-11-06-native-read-cpython/observations.tgz')]
for path,canonical in mappings:
 known=next(x for x in inventory if x['path']==path);assert known['links']==1
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as a:
  matches=[m for m in a.getmembers()if m.isfile()and m.size==known['bytes']and hashlib.sha256(a.extractfile(m).read()).hexdigest()==known['sha256']];assert len(matches)==1,(canonical,[m.name for m in matches]);member=matches[0].name
 proofs.append(dict(paths=[path],bytes=known['bytes'],links=1,sha256=known['sha256'],canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='Qualified81f60210/a44f reference; privateR453 af5e6149+archived scalar-index migration/642f5115',purpose='R453 shared scalar-index builtin sequence read: complete numeric warm/fresh with normalization and ordinary-call controls; allocation distinct from CPU.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in baseimage.items()if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),normalAdapterPin='0.4.0')
c.update(root=root,unit=unit,source='/home/lokad/lython-bench-checks/native-consumers-b853-20261116',sourceRole='candidate',sourceFiles=baseimage,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.numeric-squared-error.large','warm'],['scripts.numeric-squared-error.large','compile-run'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/native-consumers-b853-20261116',root)
 if name=='collect.py':
  lines=s.splitlines();i=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==7','len(jobs)==4')
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==4").replace('jobs=7','jobs=4')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','identity.json']:a.add(q/name,arcname=name)
 a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:c['unpackedBytes']=sum(m.size for m in a.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b853-fixtures','lython-b856-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==4").replace('B853','B856');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'native-consumers-r450/launch.py').read_text(encoding='utf-8').replace('seconds=240','seconds=150').replace('240seconds','150seconds').replace('B852','B856');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'native-consumers-r450/summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==4");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=jobs,retiredBytesProved=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],payloadBytes=c['payloadBytes'],onlyCoreChanges=True)))
