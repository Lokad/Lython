from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
prior = lab.with_name('current-cpython-20261126-retry')
template = prior / 'comparison/quiet'
donor = lab.with_name('fixed-row-local-bindings-20261126')
source = donor / 'comparison/quiet'
image = donor / 'local/candidate'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2) + '\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == '0172ed7cfb585264609cf1dde118d68521996a0d'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--', 'src'], cwd=repo)
baseline = read(source / 'identity.json')
patch = subprocess.check_output(['git', 'diff', '--binary', baseline['sourceRevision'], head, '--', 'src'], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == baseline['sourcePatchSHA256'] == sha(donor / 'candidate.patch')
receipt = read(source / 'terminal-status.json')['receipt']
assert all(receipt[k] for k in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(source / 'observations.tar.xz')
files = baseline['imageFiles']['candidate']
assert len(files) == 32 and {p.name: sha(p) for p in image.iterdir()} == files
old = read(template / 'identity.json')
remote_root = 'post-fixed-row-cpython-b1784-20261126'
for name in ('representative.json', 'jobs.json', 'cpython-worker.py', 'summarize.py', 'run.sh'):
    shutil.copyfile(template / name, quiet / name)
for name, meta in old['catalogs'].items():
    assert sha(quiet / name) == meta['sha256']
assert sha(quiet / 'cpython-worker.py') == sha(repo / 'benchmarks/cpython-worker.py') == baseline['cpythonWorkerSHA256']
assert old['expectedCPythonSHA256'] == baseline['expectedCPythonSHA256']
identity = dict(sourceRevision=head, productionSource=head, candidate=head,
    frozenImage=f'/home/lokad/lython-bench-checks/{remote_root}/candidate',
    auxiliaryFiles={name: digest for name, digest in files.items() if name != 'Lokad.Lython.dll'},
    imageFiles={'candidate': files}, coreSHA256={role: files['Lokad.Lython.dll'] for role in ('candidate', 'candidate-control')},
    donorArchiveSHA256=receipt['archiveSHA256'], sourcePatchSHA256=baseline['sourcePatchSHA256'],
    cpythonWorkerSHA256=baseline['cpythonWorkerSHA256'], expectedCPythonSHA256=baseline['expectedCPythonSHA256'],
    catalogs=old['catalogs'], priorExternalSource=old['sourceRevision'],
    purpose='Refresh the representative CPython comparison after the executable loop and fixed-row changes.')
save(quiet / 'identity.json', identity)

def substitute(script, replacements):
    for previous, current in replacements:
        assert script.count(previous) == 1, previous
        script = script.replace(previous, current)
    return script

collect = substitute((template / 'collect.py').read_text(encoding='utf-8'), [
    ('lython-b1774c-fixtures', 'lython-b1784-fixtures'),
    ("purpose='Compare the retained compiled-defaults and integer-constant checkpoint against CPython.'", "purpose=identity['purpose']"),
])
compile(collect, 'collect.py', 'exec')
write(quiet / 'collect.py', collect)
assert b'\r' not in (quiet / 'run.sh').read_bytes()

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
worker = image / 'Lokad.Lython.Benchmarks.dll'
verify = quiet / 'candidate-verify.json'
subprocess.run([dotnet, worker, '--compare', 'verify', '--catalog', quiet / 'representative.json',
    '--dotnet', dotnet, '--python', 'C:/Python313/python.exe', '--python-worker', quiet / 'cpython-worker.py',
    '--out', verify], cwd=repo, env=dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk)), check=True, timeout=85)
proof = read(verify)
assert proof['state'] == 'Completed' and proof['caseCount'] == 5
assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert proof['launched']['library']['sha256'] == files['Lokad.Lython.dll']

payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=6) as package:
    for name in ('identity.json', 'jobs.json', 'representative.json', 'collect.py', 'run.sh', 'cpython-worker.py'):
        package.add(quiet / name, arcname=name, recursive=False)
save(quiet / 'upload.json', dict(root=remote_root, payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
launch = substitute((prior / 'quiet.py').read_text(encoding='utf-8'), [
    ('lython-b1774c-callable-checkpoint-cpython-20261126', 'lython-b1784-post-fixed-row-cpython-20261126'),
    ("base/'compiled-default-operands-b1773-20261126'", "base/'fixed-row-local-bindings-b1783-20261126'"),
    ("cfg['payloadBytes']+6*1024*1024", "cfg['payloadBytes']+5*1024*1024"),
    (" archive.unlink()\n print(json.dumps(dict(freeBeforeLaunchBytes", """ archive.unlink()
 dotnet=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 verification=root/'remote-verify.json'
 subprocess.run([dotnet,origin/'Lokad.Lython.Benchmarks.dll','--compare','verify',
  '--catalog',root/'representative.json','--dotnet',dotnet,'--python',python,
  '--python-worker',root/'cpython-worker.py','--out',verification],
  env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=28)
 proof=json.loads(verification.read_text())
 assert proof['state']=='Completed' and proof['caseCount']==5
 assert proof['catalogSha256']==image['catalogs']['representative.json']['sha256']
 assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
 print(json.dumps(dict(freeBeforeLaunchBytes"""),
])
compile(launch, 'quiet.py', 'exec')
write(lab / 'quiet.py', launch)
