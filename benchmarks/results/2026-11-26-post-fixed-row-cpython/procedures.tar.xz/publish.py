from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
root = repo / 'benchmarks/results/2026-11-26-post-fixed-row-cpython'
prior = lab.with_name('current-cpython-20261126-retry') / 'comparison/quiet'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

terminal = read(quiet / 'terminal-status.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
receipt = terminal['receipt']
assert all(receipt[k] for k in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == sha(quiet / 'observations.tar.xz')
assert receipt['warmJobs'] == 10
identity = read(quiet / 'identity.json')
summary = read(quiet / 'summary.json')
assert identity['sourceRevision'] == summary['source'] and summary['timedBatches'] == 280
prior_identity = read(prior / 'identity.json')
assert identity['catalogs'] == prior_identity['catalogs']
assert identity['expectedCPythonSHA256'] == prior_identity['expectedCPythonSHA256']
assert identity['cpythonWorkerSHA256'] == prior_identity['cpythonWorkerSHA256']
for file in ('jobs.json', 'representative.json', 'cpython-worker.py'):
    assert sha(quiet / file) == sha(prior / file)

record = read(quiet / 'remote-verify.json')
assert record['state'] == 'Completed' and record['caseCount'] == 5
assert record['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
assert record['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
root.mkdir(exist_ok=True)
for file in ('identity.json', 'observations.tar.xz', 'terminal-status.json', 'summary.json'):
    shutil.copyfile(quiet / file, root / file)
with tarfile.open(root / 'procedures.tar.xz', 'w:xz') as bundle:
    for folder, files in (
        (lab, ('prepare.py', 'quiet.py', 'prepare.log', 'launch-console.log', 'retrieve.log',
                'publish.py')),
        (quiet, ('upload.json', 'launch.log', 'candidate-verify.json', 'remote-verify.json',
                  'summarize.py')),
    ):
        for file in files:
            bundle.add(folder / file, arcname=file, recursive=False)

names = {
    'diagnostic.shipment-routing-callbacks': ('Shipment callback report', '2,048 records / 27,350 B'),
    'diagnostic.generated-ordinary-definitions': ('Generated ordinary definitions', '96 definitions, built 16 times'),
    'diagnostic.json-service-quantity-totals': ('JSON service quantity totals', '2,048 records / 78,755 B'),
    'diagnostic.text-summary.nonlocal-computed-width.large': ('Short Unicode word-count report with a nonlocal helper', '3,072 lines / 35,840 B'),
    'scripts.rule-default-closures': ('Generated rules with defaults', '2,048 rule groups'),
}
phases = {'warm': 'Warm sync', 'warm-async': 'Warm `RunAsync`', 'compile': 'Compilation only',
          'compile-run': 'Compile-to-result'}
index = {(row['case'], row['lane']): row for row in summary['rows']}

def span(values, digits, unit):
    return '–'.join(f'{value:.{digits}f}' for value in values) + unit

def metric_cells(row):
    return ' | '.join((span(row['lythonMs'], 5, ' ms'), span(row['cpythonMs'], 5, ' ms'),
        span(row['ratio'], 3, '×')))

def status(row):
    low, high = row['ratio']
    parts = ['Inconclusive around parity.' if low <= 1 <= high else 'Diagnostic.']
    for field, engine in (('lythonControlPercent', 'Lython'), ('cpythonControlPercent', 'CPython')):
        if row[field] > 5:
            parts.append(f'{engine} worker spread is {row[field]:.2f}%.')
    return ' '.join(parts)

ordered = [(case, lane) for case in names for lane in ('warm', 'warm-async') if (case, lane) in index]
ordered += [(case, lane) for lane in ('compile', 'compile-run') for case in names if (case, lane) in index]
assert len(ordered) == 10

guide = repo / 'docs/BENCHMARKS.md'
text = guide.read_text(encoding='utf-8')
marker = 'two workers per engine. B1774c measures'
assert text.count(marker) == 1
text = text.replace(marker, 'two workers per engine. B1784 measures `0172ed7cf` on November 26, 2026 UTC.\nB1774c measures')
text = text.replace('[B1774c]:', '[B1784]: ../benchmarks/results/2026-11-26-post-fixed-row-cpython/README.md\n[B1774c]:', 1)
text = text.replace('Those comparisons ran on November 26, 2026 UTC. [B1774c]',
                    'Those comparisons ran on November 26, 2026 UTC. [B1784] · [B1774c]', 1)
table = [
    '# B1784 Representative checkpoint against CPython', '',
    'Lython `0172ed7cf` and stock CPython 3.13.16 ran on the quiet Azure F4as_v7',
    'with Ubuntu 24.04.4 and .NET 11 RC3 on November 26, 2026 UTC. Each phase',
    'uses two processes per engine, five seconds of warmup per process and',
    'seven rotated batches targeting 460 ms per request. The elapsed ratio',
    'divides Lython by CPython and spans the four pairs of process medians.',
    'Above 1× means Lython took longer. [Per-worker spreads and CPU](summary.json)', '',
    '| Workload | Input or source | Phase | Lython | CPython | Elapsed ratio | Status |',
    '| --- | --- | --- | ---: | ---: | ---: | --- |',
]
for case, lane in ordered:
    row = index[case, lane]
    name, size = names[case]
    if lane == 'compile':
        size = f"{row['sourceUtf8Bytes']:,} B of source"
    table.append(f'| {name} | {size} | {phases[lane]} | {metric_cells(row)} | {status(row)} |')
    guide_name = name + (', Lython `RunAsync`' if lane == 'warm-async' else '')
    if lane == 'compile':
        guide_name += f', {size}'
    dimension = size if lane.startswith('warm') else phases[lane]
    prefix = f'| {guide_name} | {dimension} |'
    original = [line for line in text.splitlines() if line.startswith(prefix)]
    assert len(original) == 1 and '[B1774c]' in original[0], (case, lane, original)
    text = text.replace(original[0], f'{prefix} {metric_cells(row)} | {status(row)} [B1784]. |')
table += [
    '',
    'Warm execution reuses compiled code in a running process. Its clock includes',
    'applicable RAM-backed guest I/O, output and file verification, and disposal',
    'of the previous result. Lython uses the mediated comparison host with shared',
    'memory admission. CPython uses native file I/O and ordinary cyclic GC. Async',
    'rows compare Lython `RunAsync` with the same synchronous CPython script.',
    'Compile-only includes disposal of the compiled owner. Compile-to-result includes',
    'compilation, synchronous execution, and both owner cleanups. Fixture reset,',
    'request framing and startup sit outside elapsed. Process CPU covers the',
    'wider request. Fresh-process timings remain a separate historical measurement.',
    '',
    'This checkpoint reuses the exact source, fixture and lane catalog from',
    '[B1774c](../2026-11-26-callable-checkpoint-cpython/README.md). The two checkpoints',
    'ran separately. The [paired Lython-only trial](../2026-11-26-fixed-row-local-bindings/README.md)',
    'isolates the fixed-row change. All five independent CPython goldens and the',
    'full 32-file Lython image verify. All 280 batches complete. Both quiet gates',
    'pass, workers join, and the persistent archive verifies after fixture cleanup.',
    '',
    '[Image identity](identity.json) · [Observations](observations.tar.xz) ·',
    '[Terminal receipt](terminal-status.json) · [Procedures](procedures.tar.xz)',
    '',
]
(root / 'README.md').write_text('\n'.join(table), encoding='utf-8', newline='\n')
guide.write_text(text, encoding='utf-8', newline='\n')
