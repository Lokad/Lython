from pathlib import Path
import ast,gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'current-script-costs-r476';unary=r.parent/'unary-slot-results-r477';binding=r.parent/'instruction-global-slots-r479'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((r.parent/'generator-sum-r475/catalog.json').read_text(encoding='utf-8'));names=['scripts.text-normalization.large','scripts.text-normalization.helper-list'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==n)for n in names]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
current=json.loads((unary/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'];image=unary/'frozen/candidate';assert all(sha(image/n)==h for n,h in current.items())
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'actual-worker-preflight.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'actual-worker-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'actual-worker-preflight.log').read_text(encoding='utf-8')
canonical='benchmarks/results/2026-11-17-instruction-global-slots/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);digest=hashlib.sha256(data).hexdigest()
code='''from pathlib import Path
import fcntl,hashlib,json,os,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 paths=[p for p in b.glob('*/*/Lokad.Lython.dll')if hashlib.sha256(p.read_bytes()).hexdigest()==SHA]
 assert paths;m=paths[0].lstat();key=(m.st_dev,m.st_ino);aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;v=p.lstat()
   if(v.st_dev,v.st_ino)==key:aliases.append(str(p.relative_to(b)))
 assert len(aliases)==m.st_nlink and m.st_uid==os.getuid()
 print(json.dumps(dict(paths=aliases,links=m.st_nlink,bytes=m.st_size,sha256=SHA)))
'''.replace('SHA',repr(digest))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
proof=json.loads(p.stdout)|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,supersededQualifiedSource='Withdrawn R479; qualified current0315 preserved');assert proof['bytes']==len(data)
(r/'withdrawn-core-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
remote='/home/lokad/lython-bench-checks/private-text-costs-b894-20261117';previous='/home/lokad/lython-bench-checks/current-script-costs-b888-20261117'
identity=dict(sourceRevision='Qualifiedd8611c85/frozen0315de0a; metadata cdede4a1',purpose='R480 one current-source original/helper text attribution before any shared private-construction redesign. Identify complete removable stages; useful work overlaps, no CPU speedup or timing ratio claim.',coreSHA256={'candidate':current['Lokad.Lython.dll']},auxiliaryFiles={n:h for n,h in current.items()if n!='Lokad.Lython.dll'},imageFiles={'candidate':current},catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['ops-profile.py','collect.py','run.sh']:
    s=(old/name).read_text(encoding='utf-8').replace(previous,remote).replace('numeric-floating','text-original').replace('csv-invoice','text-helper').replace('scripts.numeric-squared-error.floating.large',names[0]).replace('scripts.text-helper.large',names[1])
    s=s.replace('Committedabcbd9fd/frozenca1a8239; R476 complete floating report/CSV attribution, delivery44041981387active','Qualifiedd8611c85/frozen0315de0a; R480 current text private-construction attribution')
    if name=='ops-profile.py':
        s=s.replace('count = 128 # Current complete integer/floating reports; bounded warmup and12s capture guard unchanged.','count = 128 # Complete original/helper text; bounded warmup and12s capture guard.')
    (r/name).write_text(s,encoding='utf-8',newline='\n')
s=(old/'analyze.py').read_text(encoding='utf-8').replace('numeric-floating','text-original').replace('csv-invoice','text-helper');(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
stage=['ops-profile.py','collect.py','run.sh','identity.json','catalog.json']
with tarfile.open(r/'payload.tgz','w:gz')as archive:
    for n in stage:archive.add(r/n,arcname=n)
parent=json.loads((binding/'quiet/config.json').read_text(encoding='utf-8'))
c=dict(root=remote,unit='lython-b894-private-text-costs-20261117',source=parent['root'],sourceRole='reference',sourceFiles=current,sourceCatalogSHA256=parent['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[proof],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in stage))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(binding/'quiet/remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace("for role in ['reference','candidate']:","for role in ['candidate']:").replace("root/'representative.json'","root/'catalog.json'").replace("for n in ['collect.py','archive-owned.py']:","for n in ['collect.py','ops-profile.py']:").replace('lython-b892-fixtures','lython-b894-fixtures');(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=75','seconds=80');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'retrieve.py',r/'retrieve.py')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Actual frozen2case goldens pass; prepare one short source-attribution gate, no runtime changes. Fresh withdrawn-core proof',proof['links'],'aliases, current0315 preserved.')
