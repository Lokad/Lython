from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-text-construction-gate';out.mkdir(exist_ok=False)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','attribution.json','source-gate.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in list(r.glob('*.py'))+list(r.glob('*.json'))+list(r.glob('*.log')):
        if p.name not in ['attribution.json','source-gate.json','identity.json','archive-receipt.json','terminal-status.json']:a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Current text construction and invocation source gate

R480/B894, 2026-11-17 UTC. Qualified **d8611c85 / frozen0315de0a**;
no production change or new runtime prototype. Actual copied 32-file worker passes
both custom catalog/independent CPython goldens before staging.

| Complete workload | Active samples | Unknown leaves | Nearest private drain / join frames |
| --- | ---: | ---: | ---: |
| Original text normalization, generator trim/join | 951 | 174 | 1 / 27 |
| Same task through a helper and list | 939 | 128 | 6 / 17 |

Private materialization still owns a List<object>, grows capacity repeatedly and
keeps a funded snapshot through join validation/output admission. Its cursor's
known count is unused there. But the capture does **not establish this growth as
a dominant cost**, so it does not justify a buffer framework or a growth-only
optimization. Invocation/dispatch and native UTF-8 operations remain prominent.
The inclusive call/frame group has 356/542 samples, overlapping useful operations;
it is not a removable CPU fraction. Nearest frames, all leaves and unknowns are
preserved. No speedup, allocation saving or timing ratio is inferred.

Source checks preserve completed work: eligible native helpers already borrow
short arguments and defer contexts; bound values already become locals. Generator
drains already batch. Trimming already uses UTF-8; sufficiently large same-owner
slices share funded immutable arrays. Public lists already own their final storage.
Join deliberately drains arbitrary iterables before validating string items,
preserving later effects/errors. Mutable sources cannot simply be borrowed across
host admission reentry. Do not propose any of those completed changes again.

The bounded gate is complete: no further unchanged capture, buffer prototype or
internal architecture test is started. Continue the complete call lifecycle and
operand-transport design from concrete source/stack evidence, naming a removable
handoff and semantic contract before implementation. This is uncertainty about
the next design, not a permanent rejection of construction improvements or the
completion of the broader performance objective.

Quiet Azure F4as_v7 / Ubuntu24.04.4 / .NET11 RC3. Existing perf cpu-clock 199 Hz,
frame-pointer protocol; DOTNET_PerfMapEnabled=3, eight seconds of guest-clock
warmup, about five seconds active capture per case. All thread CPU/raw stacks
are retained. Captured whole-worker batches include reset/protocol/validation
beyond execution clocks. No default-runtime elapsed, CPython ratio, startup,
asynchronous-I/O, RSS or embedding-tail comparison is made.

All goldens/Closed/exit/join/quiet gates pass. Persistent archive SHA and every RAM
trace are verified before unmount; terminal cached. Fresh path/UID/hash/link/
all-alias proof retires only the committed withdrawn be7497de core's two working
aliases; qualified current0315, toolchains, canonical evidence and 254/252 MiB
floors remain intact. A local early retrieval guard rejected an observation before
its deadline without contacting the VM; the same completed collection was then
retrieved. No timing repeated or runtime qualification replayed. Publication held.

[Source gate](source-gate.json), [full attribution](attribution.json),
[raw stacks/maps](observations.tgz), [identity](identity.json),
[custody](archive-receipt.json), [procedures](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''

R480/B894: [current original/helper text construction gate](results/2026-11-17-text-construction-gate/README.md), qualifiedd8611c85/frozen0315de0a, no runtime change. 951/939 active samples, 174/128 unknown leaves; nearest private drain1/6 and join27/17. Private growth exists but is not established as dominant; no buffer framework or growth-only prototype. Native helpers already borrow/defer frames, drains already batch and UTF-8 slices already share funded backing. Call/dispatch and actual text work remain prominent, inclusive groups overlap useful work. One bounded capture complete, all users joined/RAM verified then removed; no repeated qualification or speedup claim. Broader call/frame/operand design continues, publication held.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('## Next: R480');b=s.index('## Measurement and remaining uncertainty',a)
s=s[:a]+'''## Next: R481 complete call lifecycle / operand transport design

R480's bounded current-source gate is complete. Original/helper text captures have
951/939 active samples, including 174/128 unknown leaves. Private drain growth
exists but is not established as dominant; do not start a buffer framework or a
growth-only patch. Native helper argument borrowing, deferred frames, batched
generator drains and shared UTF-8 slices already exist. Invocation/dispatch and
actual text work remain prominent; inclusive groups are not removable fractions.
[Full gate and evidence](benchmarks/results/2026-11-17-text-construction-gate/README.md).

Hypothesis to assess: ordinary helper and receiver calls still cross redundant
classification, operation and completion stages despite eliminating argument
arrays/frames. Inspect the complete current handoff for numeric reports, text
normalization and file search. Name the concrete work/storage to eliminate and
the displaced implementation before a new prototype. Use R472/R476/R480 evidence;
no more unchanged capture absent a specific unresolved design question. Stop this
design gate with one coherent implementable proposal or explicit uncertainty.
Do not rename earlier slower call-arena, call-control or shared-kernel designs.

If justified, implement through a named completion milestone that removes old
carriers/preparation/dispatch rather than layering another route. A temporary
regression must have a final debt decision. Preserve live target/default changes,
descriptors, Python error/evaluation order, closures, canonical aliases, actual
suspension without replay, managed recursion, cancellation, terminal refusal,
replacement overlap and awaited cleanup. Join's late iteration/type-error order
and mutation during admission remain acceptance conditions for construction work.

Focused Release actual .NET 11/10 checks first. One bounded representative warm/
fresh comparison with controls and separate compilation/allocation/wider CPU;
justified refinement or confirmation is allowed. Batch platform/stress/installed
package checks only if a coherent runtime change is retained. R479's eight source
edits are fully removed; there is no active prototype or unfinished qualification.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('R480 source gate/evidence preserved; ignored plan resumes R481 complete call lifecycle design, no runtime or qualification claims.')
