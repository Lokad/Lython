from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-completed-call-cpython');out.mkdir()
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'));identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert summary['complete'] and receipt['complete'] and receipt['jobs']==15
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
# Recover the measured source, rather than inspecting the active R30 prototype.
with tarfile.open(root.parent/'utf8-result-storage-r28/baseline-source.tgz') as archive:
    source={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive.getmembers() if m.isfile()}
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs']:
    source[name]=hashlib.sha256(subprocess.check_output(['git','show','81036f25:'+name])).hexdigest()
assert source==identity['sourceSHA256'],'Measured source must equal preserved R26 plus committed R29, excluding R30.'
ci=json.loads((root.parent/'execution-transport-r29/delivery-ci-green.json').read_text(encoding='utf-8'))
assert ci['status']=='completed' and ci['conclusion']=='success' and ci['headSha']=='81036f256a5539e41c38d9fbfb2f6913c2fc702d'
names={'Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales'}
assert len(ci['jobs'])==2 and all(j['conclusion']=='success' and {s['name'] for s in j['steps'] if s['conclusion']=='success'}>=names for j in ci['jobs'])
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copy2(root/name,out/name)
(out/'delivery-ci.json').write_text(json.dumps(ci,indent=2)+'\n',encoding='utf-8')
calls=Path('benchmarks/results/2026-11-07-execution-transport')
shutil.copy2(out/'delivery-ci.json',calls/'delivery-ci.json')
p=calls/'implementation.md';text=p.read_text(encoding='utf-8')
text=text.replace('Retained 2026-11-07; full delivery qualification pending.',
                  'Retained and fully qualified 2026-11-07, source81036f25.')
text=text.replace('the final cross-platform/original Stress checkpoint remains pending.',
                  'delivery42333421800 on81036f25 is GREEN/all eight Windows/Ubuntu ordinary\nactual11/10/original Stress/installed-package gates. The terminal\n[receipt](delivery-ci.json) is cached; never query again. Later class-fact work\nis outside this qualification.')
text=text.replace('refresh\nthe representative CPython checkpoint with combined changes at delivery.',
                  'the refreshed\n[representative CPython checkpoint](../2026-11-07-completed-call-cpython/README.md)\nrecords the combined source separately.')
p.write_text(text,encoding='utf-8',newline='\n')
failed=root.parent/'delivery-comparison-b379'
for name in ['failed-startup.tgz','failed-startup-receipt.json']:
    shutil.copy2(failed/name,out/('b379-'+name))
shutil.copy2(root.parent/'execution-transport-r29/foundation-trace-retirement.json',out/'foundation-trace-retirement.json')
with tarfile.open(out/'collection-commands.tgz','w:gz') as archive:
    for file in root.iterdir():
        if file.is_file() and file.suffix in ['.py','.md','.json','.log']:archive.add(file,arcname=file.name)
    for name in ['preserve-failed-startup.py','preserve-failed-startup-command.py','failed-startup-preservation.log']:
        archive.add(failed/name,arcname='b379-failed/'+name)
(out/'README.md').write_text('''# Completed-call CPython checkpoint

2026-11-07UTC; source81036f25, measured frozen32dcf141. Exact source recovered
from the preserved R26 snapshot plus the two committed R29 files; every production
hash matches the capture. Unchanged b94fa98c worker/host and optional0.4 adapter.
Later R30 class-fact prototype is excluded. No causal per-change CPU attribution.

Existing five complete scripts, separate compilation/program disposal, warm
execution and compile-to-result. CPython3.13.16, ordinary GIL/GC/noJIT/debug;
.NET11RC3 ordinary GC/tiering, quiet AzureF4as_v7/Ubuntu24.04.4. Two identical
Lython processes and CPython,5s warmup per role/job, seven rotated150ms rounds.
All15jobs complete312.37s. Ready hashes, complete output/file goldens, terminal
funding, quiet endpoints, Closed/exit/joins, fixture removal and persistent
under-lease archive verification pass. Full420s owner+30s stop+10s margin honored;
observation03:40:56UTC follows the03:40:35 bound. No subsequent service queries.

Warm CSV1.22x,text1.71–1.75x,JSON1.05–1.06x,report1.38–1.42x,config1.24x
CPython. Compile-to-result1.21–1.24/1.62–1.66/1.04–1.07/1.35–1.37/1.20–1.22x
respectively. Warm text2.50%role spread, report3.21%/3.12%IQR; fresh CSV/text/
JSON and report remain variable. Compile44–72us remains separate. Keep all
observations/ranges; no subtraction of independent medians, exact speedup for
HEAD, compounded source-pair percentages or resolution of earlier debt by algebra.

Boundary includes mediated RAM I/O, full validation and prior-result cleanup;
fresh adds compilation/program disposal. Startup/staging/reset, transport and
final cached process/program/result teardown excluded. CPython retains imported
modules; Lython isolates execution imports. Startup, truly suspended-I/O latency,
heap/RSS and embedding tails remain unmeasured. Coarse process CPU is separate.

Source81036f25 is fully qualified: focused439internal/1,958public per actual
target, installed consumers, plus terminal GREEN42333421800/all eight Windows/
Ubuntu ordinary.NET11/10, original Stress and installed-package gates. Receipt
cached; never query it again. Publication/tagging remain postponed and the larger
performance objective stays active. Regex final producer qualification is separate.

## Preserved setup failures and provenance

B379 copied templates retain B373 roots. The collector refuses the existing
confirmation directory before worker startup; no new timings exist. Its verified
failed archive/journal/source/condition are retained. That failed launcher
overwrites expanded B373 started/stopped/exit markers. They no longer describe
B373 and are not qualification evidence. Original B373 observations.tgz and
receipt are independently verified unchanged against committed originals; those
remain authoritative. B380 corrects/validates all generated Python/shell roots
before staging, then completes the unchanged runtime once. This is a measurement
setup correction, not a failed runtime design or discarded adverse sample.

Disk inspection finds old R24 expanded files already absent; retirement preflight
aborts before mutation. Read-only capacity inspection identifies a retained
8,566,176B foundation-net11 trace whose exact bytes exist in the committed
2026-10-29-foundation archive. Initial ordinary hash read lacks permission and
also deletes nothing. Read its hash through sudo sha256sum; validate path/kind/
single-link/hash, ended users and no dependencies under the lease, then retire
only that expanded duplicate. No archive/binary evidence or filesystem policy
is removed. [Retirement receipt](foundation-trace-retirement.json).

[Summary](summary.json), [all raw/source/gates](observations.tgz),
[qualification](delivery-ci.json), [collection commands](collection-commands.tgz),
[failed B379](b379-failed-startup.tgz).
''',encoding='utf-8',newline='\n')
# Reuse the existing maintained table renderer, with the new immutable summary.
oldscript=(root.parent/'delivery-comparison-b373/record.py').read_text(encoding='utf-8')
formatting=oldscript[oldscript.index('labels='):oldscript.index("head='# Performance")]
scope={'summary':summary};exec(compile(formatting,'existing-table-renderer','exec'),scope)
table=scope['table'];p=Path('docs/BENCHMARKS.md');old=p.read_text(encoding='utf-8')
tail=old[old.index('## Improvements within Lython'):]
tail=tail.replace('The following were not refreshed to `01aedc3b`','The following were not refreshed to `81036f25`')
tail=tail.replace('It is outside the primary CPython tables above.', 'It and R29 are included in the primary checkpoint above; individual source-pair limits remain.')
tail=tail.replace('claimed. It is outside the primary CPython tables above.', 'claimed. It and R29 are included in the primary checkpoint above; individual source-pair limits remain.')
tail=tail.replace('Coarse CPU supports no broad claim.', 'Coarse CPU is diagnostic.')
machine=old[old.index('## Machine, included work and fairness'):old.index('## Improvements within Lython')]
machine=machine.replace('completed312.40s','completed312.37s')
head='# Performance against CPython\n\n'+table('compile-run')+'''

**2026-11-07; 0.11 development source `81036f25`; CPython3.13.16; .NET11RC3.**
These are **compilation plus one execution in an already-running host**, including
mediated RAM-file I/O, complete validation and prior-result cleanup. Startup and
fixture staging/reset are excluded. **Ratio=Lython elapsed/CPython elapsed; above
one means slower.**

Ranges are medians from two independent identical-build processes, not confidence
intervals. Control is their absolute difference relative to candidate; IQR is the
larger Lython-role interquartile range/median. Several cases remain variable: keep
their status/control columns. These timings describe the recorded source, not
future HEAD. Frozen core `32dcf141` has that exact production source, including
R26/R29. Source81036f25 passed Windows/Ubuntu, actual.NET11/10, original Stress
and installed-package consumers. Later class-fact work and private development
regex adapters are outside this comparison.
[Identity, observations and qualification](../benchmarks/results/2026-11-07-completed-call-cpython/README.md).

## Warm execution, compilation and startup

Same source/input and execution/I/O/validation/cleanup boundary, reusing compiled code:

'''+table('warm')+'''

Compilation/program disposal alone; execution and I/O excluded. Do not subtract
warm and fresh medians to infer compilation: these are independent job blocks.

'''+table('compile')+'''

**Startup, genuinely suspended-I/O latency, heap/RSS and embedding latency remain
unmeasured.** This refresh measures combined changes; it does not isolate each
change's CPU benefit or explain earlier adverse/unstable source-pair results.
[Previous primary comparison, source01aedc3b](../benchmarks/results/2026-11-07-current-cpython/README.md).

'''
p.write_text(head+machine+tail,encoding='utf-8',newline='\n')
history=Path('benchmarks/EXPERIMENTS.md')
with history.open('a',encoding='utf-8',newline='\n') as output:
    output.write('''
## Completed-call delivery / CPython checkpoint (2026-11-07)

[B380](results/2026-11-07-completed-call-cpython/README.md) records exact81036f25/
frozen32dcf141, all15jobs/312s/all gates. Warm text1.71–1.75xCPython/fresh
1.62–1.66x remain variable; CSV warm1.22x/JSON1.05–1.06x, report1.38–1.42x
and variable. Compilation is separate; no source-pair compounding/debt-parity claim.
R29 delivery42333421800 is terminal GREEN/all eight gates, cached; excludes R30.
B379 fails before workers due stale generated roots, preserving journal/source
and unchanged original B373 archive. Its overwritten expanded lifecycle markers
are explicitly disqualified; immutable archived observations remain authoritative.
''')
print('Recorded fully qualified R29 and all15 CPython jobs; R30 remains separate.')
