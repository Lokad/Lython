from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-current-cpython');out.mkdir()
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'));identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert summary['complete'] and receipt['complete'] and receipt['jobs']==15
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(root.parent/'native-single-pass-r26/baseline-source.tgz') as a:
    source={m.name:hashlib.sha256(a.extractfile(m).read()).hexdigest() for m in a.getmembers() if m.isfile()}
assert source==identity['sourceSHA256'],'Use the preserved source, not the later runtime prototype'
ci=json.loads((root.parent/'csv-record-values-r25/delivery-ci-fourth.json').read_text(encoding='utf-8-sig'))
assert ci['status']=='completed' and ci['conclusion']=='success' and ci['headSha']=='01aedc3b144ac26f56aae1ee1a3fc9be987f6d8f'
names={'Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales'}
assert len(ci['jobs'])==2 and all(j['conclusion']=='success' and {s['name'] for s in j['steps'] if s['conclusion']=='success'}>=names for j in ci['jobs'])
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(root/name,out/name)
(out/'delivery-ci.json').write_text(json.dumps(ci,indent=2)+'\n',encoding='utf-8')
csv=Path('benchmarks/results/2026-11-07-csv-record-values')
shutil.copyfile(out/'delivery-ci.json',csv/'delivery-ci.json')
p=csv/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('Full platform/Stress/package delivery remains a separate upcoming checkpoint.', 'Delivery42319704404 on01aedc3b is terminal GREEN, all eight Windows/Ubuntu\nactual11/10/original Stress/installed-package gates verified in\n[delivery-ci.json](delivery-ci.json). Later native-body prototypes are separate.')
p.write_text(s,encoding='utf-8')
with tarfile.open(out/'collection-commands.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.suffix in ['.py','.md','.json']:a.add(p,arcname=p.name)
    for folder in ['b370-retirement','b372-retirement']:
        for p in sorted((root/folder).iterdir()):
            if p.is_file():a.add(p,arcname=folder+'/'+p.name)
(out/'README.md').write_text('''# Current CPython comparison — R25 checkpoint

2026-11-07UTC, runtime/source01aedc3b, measured frozen core0933d540, unchanged
b94fa98c worker/host and optional0.4 adapter/producer. R22/R23/R25 source pairs
remain separate; this is an aggregate revision comparison, not causal per-change
CPU attribution. Exact production hashes match the preserved pre-R26 snapshot.
Later native-body admission-mutation correction is outside these measurements.

Existing five complete scripts, separate compilation/disposal, warm execution
and compile-to-result, CPython3.13.16/current/identical current.5s warmups per
role/job, seven rotated150ms rounds, normal GC/tiering. All15jobs complete312.40s;
actual images, full output/file goldens, terminal funding, quiet endpoints,
Closed/joins, removed fixtures and persistent under-lease archive verification
pass.420sowner+30sstop+10smargin honored; no SSH before the recorded bound.

Fresh Lython/CPython: CSV1.22–1.24x,text1.76–1.77x,JSON1.07–1.11x,
report1.34–1.42x,config1.20–1.21x. Warm:1.20–1.22/1.81–1.83/1.08/
1.33–1.35/1.25x. Compile44–72us separately. Fresh JSON3.35%role spread,
report5.79%role spread/8.45%IQR and config3.39%IQR remain variable; keep ranges,
not a precise gain claim. No subtraction of independent medians or inference
that later absolute timings explain earlier adverse source pairs.

Boundary includes mediated RAM I/O, complete validation and prior-result cleanup;
fresh adds compilation/program disposal. Startup/staging/reset, transport and
final cached teardown excluded. CPython retains imported modules; Lython isolates
execution imports. Startup, truly suspended I/O, heap/RSS and embedding-tail
latency remain unmeasured. Process CPU ticks are a separate coarse diagnostic.

Source01aedc3b passes focused actual11/10 and explicit installed consumers locally;
full delivery42319704404 is GREEN/all eight Windows/Ubuntu ordinary11/10,
original Stress and installed-package gates. Cached receipt is terminal; never
query it again. This does not qualify the subsequent native-body prototype.
Publication/tagging postponed; the text gap/performance objective remain open.

Disk preparation first finds old R19 expanded files already absent, before any
deletion. Preserve that failed precondition and read-only inspection. Retire
only exact B370 perf and B372 confirmation copies after independently committed/
pushed archives, all hashes, ended users, lease and link checks. All archives/
binaries remain. No runtime quotas, new tooling framework or producer campaign.
''',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');old=p.read_text(encoding='utf-8');tail=old[old.index('## Improvements within Lython'):]
labels={'csv-summary-functions':'CSV summary/ordinary helper','text-summary-helpers':'Text summary/helpers','json-summary-helpers':'JSON-lines/helpers','report-render':'JSON-to-Markdown report','config-edit':'Configuration read/edit/write'}
inputs=['4,096 records /57,361B','3,072 lines /35,840B','4,096 records /110,592B','3,072 records /189,441B','16 paths /181B']
def table(lane):
    rows=[r for r in summary['timing'] if r['lane']==lane];assert len(rows)==5
    if lane=='compile-run':lines=['| Workload | Input | Lython | CPython | Lython / CPython | Measurement status |','| --- | --- | ---: | ---: | ---: | --- |']
    else:lines=[f"| {'Warm workload' if lane=='warm' else 'Compile-only script'} | Lython | CPython | Ratio | Status; control / Lython IQR |",'| --- | ---: | ---: | ---: | --- |']
    for index,r in enumerate(rows):
        scale=1000 if lane=='compile' or 'config-edit' in r['case'] else 1;unit='µs' if scale==1000 else 'ms'
        lo,hi=[v*scale for v in r['timeRangeMilliseconds']];py=r['medianMilliseconds']['CPython']*scale;ratio=r['ratioRange'];spread=max(r['iqrPercent'][k] for k in ['candidate','control'])
        values=[labels[r['case'].split('.')[1]]]+([inputs[index]] if lane=='compile-run' else [])+[f'{lo:.3f}–{hi:.3f} {unit}',f'{py:.3f} {unit}',f'{ratio[0]:.2f}–{ratio[1]:.2f}×',f"{r['status']}; {r['controlPercent']:.2f}% / {spread:.2f}%"]
        lines.append('| '+' | '.join(values)+' |')
    return '\n'.join(lines)
head='# Performance against CPython\n\n'+table('compile-run')+'''

**2026-11-07; 0.11 development source `01aedc3b`; CPython3.13.16; .NET11RC3.**
These are **compilation plus one execution in an already-running host**, including
mediated RAM-file I/O, complete validation and prior-result cleanup. Startup and
fixture staging/reset are excluded. **Ratio=Lython elapsed/CPython elapsed; above
one means slower.**

Ranges are medians from two independent identical-build processes, not confidence
intervals. Control is their absolute difference relative to candidate; IQR is the
larger Lython-role interquartile range/median. Fresh JSON, report and configuration
remain variable. These timings describe the recorded source, not future HEAD.
Frozen core `0933d540` has that exact recorded production source. Source01aedc3b
passed Windows/Ubuntu, actual.NET11/10, original Stress and installed-package
consumers. Subsequent native-body changes and private development regex adapters
are outside this comparison.
[Identity, observations and qualification](../benchmarks/results/2026-11-07-current-cpython/README.md).

## Warm execution, compilation and startup

Same source/input and execution/I/O/validation/cleanup boundary, reusing compiled code:

'''+table('warm')+'''

Compilation/program disposal alone; execution and I/O excluded. Do not subtract
warm and fresh medians to infer compilation: these are independent job blocks.

'''+table('compile')+'''

**Startup, genuinely suspended-I/O latency, heap/RSS and embedding latency remain
unmeasured.** This refresh measures combined changes; it does not isolate each
change's CPU benefit or explain earlier adverse/unstable source-pair results.
[Previous primary comparison, source4fad63c5](../benchmarks/results/2026-11-06-current-cpython/README.md).

'''
machine=old[old.index('## Machine, included work and fairness'):old.index('## Improvements within Lython')].replace('Fifteen jobs completed312.23s','Fifteen jobs completed312.40s')
p.write_text(head+machine+tail,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');at=s.index('\n\n')+2
s=s[:at]+'''The [R25 CPython checkpoint](results/2026-11-07-current-cpython/README.md)
records exact01aedc3b/current frozen0933d540, all15jobs/312s/all gates. Warm CSV
1.20–1.22x,text1.81–1.83x,JSON1.08x CPython; fresh JSON/report/config remain
variable. Full R25 delivery42319704404 is GREEN/all eight gates, cached. This
refresh does not qualify or time later native-body corrections, explain prior
adverse source pairs or establish startup/RSS/suspended-I/O latency.

'''+s[at:];p.write_text(s,encoding='utf-8')
print('Recorded all15 current CPython jobs and terminal R25 all-eight delivery proof.')
