from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
prior=json.loads((root.parent/'delivery-comparison-b373/archive-receipt.json').read_text(encoding='utf-8'))
script=r'''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'delivery-comparison-b379-20261107';prior=base/'delivery-comparison-b373-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert not (root/'confirmation').exists()
 journal=subprocess.run(['journalctl','-u','lython-b379-delivery-comparison-20261107.service','--no-pager','-n','45'],text=True,capture_output=True).stdout
 assert 'FileExistsError' in journal and 'confirmation' in journal
 assert hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()=='PRIORHASH'
 original=json.loads((prior/'archive-receipt.json').read_text());assert original['complete'] and original['jobs']==15 and original['archiveSHA256']=='PRIORHASH'
 record=dict(complete=False,stage='before worker startup',cause='Copied run/collector/archive templates retain B373 root; existing confirmation directory refuses creation.',
  noNewWorkersOrMeasurements=True,priorArchiveAndReceiptVerifiedUnchanged=True,
  priorExpandedMarkersOverwritten={name:(prior/name).read_text() for name in ['started.utc','stopped.utc','exit-code.txt']},
  limitation='Expanded B373 lifecycle markers were overwritten by failed launcher; they no longer describe B373. Original committed B373 archive/receipt remain authoritative and unchanged. Do not use these expanded markers as qualification evidence.')
 (root/'failed-startup.json').write_text(json.dumps(record,indent=2)+'\n');(root/'journal.txt').write_text(journal)
 with tarfile.open(root/'failed-startup.tgz','w:gz',dereference=True) as saved:
  for file in root.iterdir():
   if file.is_file() and file.name!='failed-startup.tgz':saved.add(file,arcname=file.name)
 with tarfile.open(root/'failed-startup.tgz') as saved:assert not json.loads(saved.extractfile('failed-startup.json').read())['complete']
 receipt=dict(complete=False,noActiveWorkersOrFixtures=True,priorArchiveAndReceiptVerifiedUnchanged=True,archiveSHA256=hashlib.sha256((root/'failed-startup.tgz').read_bytes()).hexdigest())
 (root/'failed-startup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('PRIORHASH',prior['archiveSHA256'])
compile(script,'remote','exec')
(root/'preserve-failed-startup-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
r=subprocess.run([*ssh,'lokad@20.166.121.73','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'failed-startup-preservation.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
scp=['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:]]
for name in ['failed-startup.tgz','failed-startup-receipt.json']:
    r=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/delivery-comparison-b379-20261107/'+name,str(root/name)],capture_output=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'failed-startup-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'failed-startup.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(receipt)
