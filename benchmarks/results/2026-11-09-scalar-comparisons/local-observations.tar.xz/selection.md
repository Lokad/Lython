# R163 one exact scalar comparison entry

R162 shows repeated equality/protocol dispatch on ordinary exact-string predicates.
Extend the existing numeric funnel to exact strings, six operators, native UTF-8,
bounded current-token checks. Delete executable string detour through general
operator dispatch/truth coercion. Preserve custom/subclass/raw/reflected protocols,
numeric/NaN semantics, chained order, genuine suspension, refusal and retained owners.
No new cache/engine/representation/policy. Source-pair baselineb59 fresh nonincremental.
Use existing five maintained scripts and existing isolated-ALC allocation driver;
compile/warm sync/async separate, two unchanged baselines, all golden/balance gates.
Desktop elapsed diagnostic. If material, one quiet3job comparison with independent
controls; no universal gain claim or percentage veto. Finish by deleting displaced
path and deciding debt. Entire performance objective remains open.
