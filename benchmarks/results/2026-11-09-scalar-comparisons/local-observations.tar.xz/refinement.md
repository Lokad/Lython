Keep original desktop image/results/adversity. Controls spread up to27.87%,
CSV mixed; async search+8.79–9.86% and report+2.99–4.59% remain unexplained.
No elapsed/CPU attribution from that diagnostic. Source refinement before quiet
confirmation: keep original numeric classification order and move bounded bulk
text loop out of common scalar dispatch. This is a source design hypothesis, not
demonstrated inlining or CPU benefit. Same contract/no new cache/backend/options.
Qualify focused paths, freeze final nonincremental image separately, one bounded
quiet comparison of affected CSV sync/async and adverse search/report async controls.
Do not relabel original allocation/timing as the refinement or erase adversity.
