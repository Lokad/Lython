using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static bool IsScalarComparison(BinaryOperatorSyntax op)
        => op is BinaryOperatorSyntax.Equal or BinaryOperatorSyntax.NotEqual or BinaryOperatorSyntax.Less
            or BinaryOperatorSyntax.LessEqual or BinaryOperatorSyntax.Greater or BinaryOperatorSyntax.GreaterEqual;

    // Exact numbers and strings have no guest slots. Expressions and branches
    // share this entry before structural/protocol setup.
    private static bool TryEvaluateScalarComparison(BinaryOperatorSyntax op, object left, object right,
        ExecutionContext context, LythonSourceSpan span, out bool result)
    {
        result = false;
        if (!IsScalarComparison(op)) return false;
        if (left is PyString leftText && right is PyString rightText)
        {
            context.CheckExecution(span);
            if (ReferenceEquals(leftText, rightText))
            {
                result = CompareOrderedResult(op, 0);
                return true;
            }
            var lhsText = leftText.Utf8Span;
            var rhsText = rightText.Utf8Span;
            if (op is BinaryOperatorSyntax.Equal or BinaryOperatorSyntax.NotEqual && lhsText.Length != rhsText.Length)
            {
                result = op == BinaryOperatorSyntax.NotEqual;
                return true;
            }
            var textComparison = 0;
            var length = Math.Min(lhsText.Length, rhsText.Length);
            for (var offset = 0; offset < length;)
            {
                context.CheckExecution(span);
                var count = Math.Min(4096, length - offset);
                textComparison = lhsText.Slice(offset, count).SequenceCompareTo(rhsText.Slice(offset, count));
                if (textComparison != 0) break;
                offset += count;
            }
            context.CheckExecution(span);
            result = CompareOrderedResult(op, textComparison == 0 ? lhsText.Length.CompareTo(rhsText.Length) : textComparison);
            return true;
        }
        if (!PyNumberOps.TryAsNumber(left, out var lhs)
            || !PyNumberOps.TryAsNumber(right, out var rhs)) return false;
        context.CheckExecution(span);
        result = PyNumberOps.TryCompare(lhs, rhs, out var comparison)
            ? CompareOrderedResult(op, comparison) : op == BinaryOperatorSyntax.NotEqual;
        return true;
    }

    private static bool CompareOrderedResult(BinaryOperatorSyntax op, int comparison) => op switch
    {
        BinaryOperatorSyntax.Equal => comparison == 0,
        BinaryOperatorSyntax.NotEqual => comparison != 0,
        BinaryOperatorSyntax.Less => comparison < 0,
        BinaryOperatorSyntax.LessEqual => comparison <= 0,
        BinaryOperatorSyntax.Greater => comparison > 0,
        BinaryOperatorSyntax.GreaterEqual => comparison >= 0,
        _ => throw new InvalidOperationException("Unexpected numeric comparison."),
    };

    private static BinarySpecialMethodPair OrderedComparisonMethods(BinaryOperatorSyntax op) => op switch
    {
        BinaryOperatorSyntax.Less => new("__lt__", "__gt__"),
        BinaryOperatorSyntax.LessEqual => new("__le__", "__ge__"),
        BinaryOperatorSyntax.Greater => new("__gt__", "__lt__"),
        BinaryOperatorSyntax.GreaterEqual => new("__ge__", "__le__"),
        _ => throw new InvalidOperationException("Unexpected ordered comparison."),
    };

    private static string ComparisonSymbol(BinaryOperatorSyntax op) => op switch
    {
        BinaryOperatorSyntax.Less => "<",
        BinaryOperatorSyntax.LessEqual => "<=",
        BinaryOperatorSyntax.Greater => ">",
        BinaryOperatorSyntax.GreaterEqual => ">=",
        _ => throw new InvalidOperationException("Unexpected ordered comparison."),
    };
}
