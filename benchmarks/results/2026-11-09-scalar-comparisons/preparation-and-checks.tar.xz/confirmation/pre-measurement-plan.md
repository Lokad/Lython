# R163 one exact scalar comparison entry

R162 shows repeated equality/protocol dispatch on ordinary exact-string predicates.
Extend the existing numeric funnel to exact strings, six operators, native UTF-8,
bounded current-token checks. Delete executable string detour through general
operator dispatch/truth coercion. Preserve custom/subclass/raw/reflected protocols,
numeric/NaN semantics, chained order, genuine suspension, refusal and retained owners.
No new cache/engine/representation/policy. Source-pair baselineb59 fresh nonincremental.
Use existing five maintained scripts and existing isolated-ALC allocation driver;
compile/warm sync/async separate, two unchanged baselines, all golden/balance gates.
Desktop elapsed diagnostic. If material, one quiet3job comparison with independent
controls; no universal gain claim or percentage veto. Finish by deleting displaced
path and deciding debt. Entire performance objective remains open.

Keep original desktop image/results/adversity. Controls spread up to27.87%,
CSV mixed; async search+8.79–9.86% and report+2.99–4.59% remain unexplained.
No elapsed/CPU attribution from that diagnostic. Source refinement before quiet
confirmation: keep original numeric classification order and move bounded bulk
text loop out of common scalar dispatch. This is a source design hypothesis, not
demonstrated inlining or CPU benefit. Same contract/no new cache/backend/options.
Qualify focused paths, freeze final nonincremental image separately, one bounded
quiet comparison of affected CSV sync/async and adverse search/report async controls.
Do not relabel original allocation/timing as the refinement or erase adversity.
