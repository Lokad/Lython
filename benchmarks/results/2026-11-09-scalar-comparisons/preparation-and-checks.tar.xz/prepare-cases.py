from pathlib import Path
import json,subprocess
r=Path(__file__).parent
source=r'''pairs=[('', ''),('', 'a'),('a',''),('a','b'),('abcdefg','abcdefgh'),('abcdefgh','abcdefg'),('é','ê'),('\ue000','\U00010000'),('a\0b','a\0c'),('a'*4095+'é','a'*4095+'ê'),('a'*4096+'😀','a'*4096+'😀'),('a'*4097+'😀','a'*4097+'😁')]
for left,right in pairs:
    values=[left==right,left!=right,left<right,left<=right,left>right,left>=right]
    branches=[]
    if left==right:branches.append('eq')
    if left!=right:branches.append('ne')
    if left<right:branches.append('lt')
    if left<=right:branches.append('le')
    if left>right:branches.append('gt')
    if left>=right:branches.append('ge')
    print(values,branches)
'''
# Raw source keeps Python Unicode escapes literal; actual accented/astral text is UTF-8.
(r/'scalar-strings.py').write_text(source,encoding='utf-8')
x=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8');assert x.returncode==0,x.stderr
(r/'scalar-strings-cpython.json').write_text(json.dumps(dict(source=source,stdout=x.stdout,stderr=x.stderr,reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip()),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=Path('tests/Lokad.Lython.PublicApi.Tests/ComparisonValueTests.cs');s=p.read_text(encoding='utf-8')
entry='''        { "native_utf8_boundaries", """
'''+''.join('            '+line+'\n'for line in source.splitlines())+'''            """, """
'''+''.join('            '+line+'\n'for line in x.stdout.splitlines())+'''            """+"\\n" },
'''
assert 'native_utf8_boundaries'not in s;s=s.replace('    public static TheoryData<string, string, string> Programs => new()\n    {','    public static TheoryData<string, string, string> Programs => new()\n    {\n'+entry.rstrip())
p.write_text(s,encoding='utf-8',newline='\n');print(x.stdout)
