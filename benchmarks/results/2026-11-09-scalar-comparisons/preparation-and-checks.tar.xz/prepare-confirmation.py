from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;v=r/'b513';v.mkdir(exist_ok=False);old=r.parent/'borrowed-call-entry-r151/b506'
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],['scripts.file-search.large','warm-async'],['scripts.report-render.large','warm-async']]
for n in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
    s=(old/n).read_text(encoding='utf-8').replace('borrowed-call-entry-b506-20261109','scalar-comparison-b513-20261109').replace('lython-b506-borrowed-call-entry-20261109','lython-b513-scalar-comparison-20261109').replace('borrowed-call-entry-b506-launch.py','scalar-comparison-b513-launch.py').replace('lython-b506-fixtures','lython-b513-fixtures').replace('closed-nested-b497-20261109/candidate','config-boundary-b509-20261109/candidate')
    if n=='collect.py':
        a=s.index('jobs=[');z=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[z:]
        a=s.index("purpose='");z=s.index('\n                  warmupSeconds=',a);s=s[:a]+"purpose='R163 one exact scalar comparison entry; affected CSV sync/async and original adverse search/report async controls. No CPU claim from diagnostic desktop variation.',"+s[z:]
        s=s.replace('started < 180','started < 150')
    if n in ['archive-owned.py','retrieve.py']:
        s=s.replace('==5','==4').replace('== 5','== 4').replace('jobs=5','jobs=4').replace('<180','<150').replace('Five-job','Four-job')
    if n=='launch.py':
        s=s.replace("'assert len(jobs)==5 '","'assert len(jobs)==4 '").replace('allFiveJobsValidated=True','allConfiguredJobsValidated=True').replace('RuntimeMaxSec=210','RuntimeMaxSec=180').replace('ownerSeconds=210','ownerSeconds=180').replace('seconds=270','seconds=240')
    if n.endswith('.py'):compile(s,n,'exec')
    (v/n).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',v/'current-core.dll');shutil.copyfile(r/'images/before/Lokad.Lython.dll',v/'baseline-core.dll')
shutil.copyfile(v/'current-core.dll',r/'images/candidate/Lokad.Lython.dll')
proof=dict(baselineRevision=(r/'baseline-revision.txt').read_text(encoding='utf-8').strip(),productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},candidateCoreSHA256=hashlib.sha256((v/'current-core.dll').read_bytes()).hexdigest(),refinement='Small common numeric prefix, bounded UTF-8 comparison in separate kernel; original desktop image/adverse evidence retained. Fresh nonincremental final-source freeze, not a postcommit binary.')
(r/'final-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
for a,b in [('representative.json',r/'catalog.json'),('baseline-source.json',r/'baseline-proof.json')]:shutil.copyfile(b,v/a)
(v/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
# The new file is untracked until delivery; include its exact bytes separately.
shutil.copyfile('src/Lokad.Lython/Runtime/LythonRuntime.ScalarComparison.cs',v/'ScalarComparison.cs')
for target,n in [('common-worker.dll','Lokad.Lython.Benchmarks.dll'),('common-adapter.dll','Lokad.Lython.Utf8Regex.dll'),('common-worker.deps.json','Lokad.Lython.Benchmarks.deps.json'),('common-worker.runtimeconfig.json','Lokad.Lython.Benchmarks.runtimeconfig.json')]:shutil.copyfile(r/'images/before'/n,v/target)
i=dict(sourceRevision='b59c2be3 versus final R163 source; two fresh nonincremental freezes, common frozen worker/adapter. Not postcommit timing.',coreSHA256={role:hashlib.sha256((v/n).read_bytes()).hexdigest()for role,n in [('reference','baseline-core.dll'),('reference-control','baseline-core.dll'),('candidate','current-core.dll'),('candidate-control','current-core.dll')]},auxiliaryFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/'images/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((v/'representative.json').read_bytes()).hexdigest())
(v/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
(v/'focused.json').write_text(json.dumps(dict(status='Original prototype65internal including new active-cancellationStress and107public actualnet11 pass. Final refinement qualification proceeds independently; no final claim yet.'),indent=2)+'\n',encoding='utf-8')
(v/'setup-contract.json').write_text(json.dumps(dict(jobs=4,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12),indent=2)+'\n',encoding='utf-8')
(v/'sizing.json').write_text(json.dumps(dict(jobs=4,warmupSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=115,ownerSeconds=180),indent=2)+'\n',encoding='utf-8')
for n in ['contract.md','pre-measurement-plan.md']:(v/n).write_text((r/'selection.md').read_text(encoding='utf-8')+'\n'+(r/'refinement.md').read_text(encoding='utf-8'),encoding='utf-8')
for n in ['final-source.json']:shutil.copyfile(r/n,v/n)
# Ensure exact final new source/proof survives inside the owned archive.
p=v/'archive-owned.py';s=p.read_text(encoding='utf-8').replace("'common-worker.runtimeconfig.json']", "'common-worker.runtimeconfig.json','ScalarComparison.cs','final-source.json']");compile(s,'archive','exec');p.write_text(s,encoding='utf-8')
with tarfile.open(v/'payload.tgz','w:gz')as t:
    for p in v.iterdir():
        if p.name!='payload.tgz':t.add(p,arcname=p.name)
with tarfile.open(v/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096for m in t.getmembers())+(240+12)*1024*1024
(v/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(v/'payload.tgz').stat().st_size,floorsUnchanged=True),indent=2)+'\n',encoding='utf-8')
print('Final source pair frozen; four jobs expected115s; required free bytes',required)
