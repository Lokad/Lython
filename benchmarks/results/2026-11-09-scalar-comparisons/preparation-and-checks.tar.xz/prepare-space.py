from pathlib import Path
import json
r=Path(__file__).parent;v=r/'b513'
s=(r.parent/'borrowed-call-entry-r151/recover-space.py').read_text(encoding='utf-8')
s=s.replace("[('callback-transport-b504-20261109','2026-11-09-callback-arguments'),('json-runtime-b505-20261109','2026-11-09-json-runtime-attribution')]", "[('config-runtime-b510-20261109','2026-11-09-config-runtime-attribution'),('config-boundary-b509-20261109','2026-11-09-config-boundary')]")
s=s.replace('borrowed-call-entry-b506','scalar-comparison-b513').replace('/dev/shm/lython-b505','/dev/shm/lython-b512')
required=json.loads((v/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']
s=s.replace(' rows=[]',f" if free>{required}:\n  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes={required},reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)\n rows=[]")
s=s.replace(' plan=dict(',f" assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>{required}, 'Exact copies cannot fund unchanged payload/floors; no mutation'\n plan=dict(requiredFreeBytes={required},")
compile(s,'recover-space','exec');(v/'recover-space.py').write_text(s,encoding='utf-8')
# Resume the already-staged exact launcher. Do not stage/overwrite it again.
p=v/'launch.py';s=p.read_text(encoding='utf-8');a=s.index("code='from pathlib");z=s.index("done=subprocess.run(ssh+['python3 '+stage]",a);s=s[:a]+s[z:];compile(s,'resume','exec');(v/'resume-launch.py').write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')+f'''\nR163 quiet launch refused before extraction/work:273772544B free versus{required}B\nrequired by original payload+240MiB OS/12MiB evidence floors. Recover only exact\ntracked duplicate B510/B509 compressed archives,4.12MB total, after fresh deficit,\nsingle-alias/SHA/owner/group/mode/parents and persisted pre-mutation proof. Skip all\nmutation if fresh free space suffices. Preserve raw/receipts/workers and canonical\nGit archives; same staged payload then resumes, no lowered floor or timed restart.\n''';p.write_text(s,encoding='utf-8',newline='\n')
print('Two exact tracked copies selected for proven3.17MB deficit; fresh no-op guard included.')
