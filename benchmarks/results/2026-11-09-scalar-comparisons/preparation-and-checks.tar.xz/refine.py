from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('src/Lokad.Lython/Runtime/LythonRuntime.ScalarComparison.cs')
shutil.copyfile(p,r/'scalar-original.cs');shutil.copytree(r/'images/candidate',r/'images/candidate-original')
s=p.read_text(encoding='utf-8');start=s.index('        if (left is PyString');end=s.index('\n    private static bool CompareOrderedResult',start)
replacement='''        // Keep the existing numeric prefix small; the bulk text kernel does
        // not belong in every numeric comparison's dispatch body.
        if (PyNumberOps.TryAsNumber(left, out var lhs) && PyNumberOps.TryAsNumber(right, out var rhs))
        {
            context.CheckExecution(span);
            result = PyNumberOps.TryCompare(lhs, rhs, out var comparison)
                ? CompareOrderedResult(op, comparison) : op == BinaryOperatorSyntax.NotEqual;
            return true;
        }
        if (left is not PyString leftText || right is not PyString rightText) return false;
        result = CompareStringScalars(op, leftText, rightText, context, span);
        return true;
    }

    private static bool CompareStringScalars(BinaryOperatorSyntax op, PyString left, PyString right,
        ExecutionContext context, LythonSourceSpan span)
    {
        context.CheckExecution(span);
        if (ReferenceEquals(left, right)) return CompareOrderedResult(op, 0);
        var lhs = left.Utf8Span;
        var rhs = right.Utf8Span;
        if (op is BinaryOperatorSyntax.Equal or BinaryOperatorSyntax.NotEqual && lhs.Length != rhs.Length)
            return op == BinaryOperatorSyntax.NotEqual;
        var comparison = 0;
        var length = Math.Min(lhs.Length, rhs.Length);
        for (var offset = 0; offset < length;)
        {
            context.CheckExecution(span);
            var count = Math.Min(4096, length - offset);
            comparison = lhs.Slice(offset, count).SequenceCompareTo(rhs.Slice(offset, count));
            if (comparison != 0) break;
            offset += count;
        }
        context.CheckExecution(span);
        return CompareOrderedResult(op, comparison == 0 ? lhs.Length.CompareTo(rhs.Length) : comparison);
    }
'''
s=s[:start]+replacement+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
(r/'refinement.md').write_text('''Keep original desktop image/results/adversity. Controls spread up to27.87%,
CSV mixed; async search+8.79–9.86% and report+2.99–4.59% remain unexplained.
No elapsed/CPU attribution from that diagnostic. Source refinement before quiet
confirmation: keep original numeric classification order and move bounded bulk
text loop out of common scalar dispatch. This is a source design hypothesis, not
demonstrated inlining or CPU benefit. Same contract/no new cache/backend/options.
Qualify focused paths, freeze final nonincremental image separately, one bounded
quiet comparison of affected CSV sync/async and adverse search/report async controls.
Do not relabel original allocation/timing as the refinement or erase adversity.
''',encoding='utf-8');print('Original image preserved; common numeric prefix separated from bulk text kernel.')
