set -eu
root=/home/lokad/lython-bench-checks/direct-methods-allocation-b318-20261106
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
sleep 5
"$dotnet" /home/lokad/lython-bench-checks/direct-methods-b317-20261106/candidate/Lokad.Lython.Benchmarks.dll --compare check-machine --out "$root/machine-before.json"
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$root/machine-before.json"
"$dotnet" "$root/driver/complete-jobs.dll" /home/lokad/lython-bench-checks/direct-methods-b317-20261106/reference/Lokad.Lython.Benchmarks.dll /home/lokad/lython-bench-checks/direct-methods-b317-20261106/candidate/Lokad.Lython.Benchmarks.dll "$root/catalog.json" "$root/hash-witness.json" > "$root/result.json"
sleep 5
"$dotnet" /home/lokad/lython-bench-checks/direct-methods-b317-20261106/candidate/Lokad.Lython.Benchmarks.dll --compare check-machine --out "$root/machine-after.json"
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$root/machine-after.json"
