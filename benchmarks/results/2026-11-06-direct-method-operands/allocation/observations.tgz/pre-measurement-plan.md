# F05 separate allocation diagnostic, before collection

Reuse the unchanged D54 complete-job driver, source/binary preserved here.
One unchanged4096-record method CSVwarm job, same-process sharedCoreLib/hash
witness, three isolated typed native budget images (candidate/two originals).
Six guest warmup seconds/image,2ssettle,nine rotating200ms rounds, normalGC/tiering.
45s owned bound with quiet endpoints/exclusive lease. Start only after verified
B317 terminal completion; all output/files, per-job/final zero funding, actual
users joined and fixtures removed required. No forced collection or profiler.
Allocation includes fixture reset/reflection/background work, not guest-only bytes.
Elapsed includes current-result cleanup, unlike B317 prior-result cleanup; keep
these boundaries and claims separate. No CPython ratio or causalCPU claim from
this block. Preserve every adverse/inconclusive observation. The initial combined
plan estimates <=200s actual collection; record actual durations, with independent
150s and45s owned supervisors, no automatic followup campaign.

B318 stopped before observations: copied driver had a case-id guard. B319 changes only that guard/purpose label, rebuilds before settling; original failure/source/binary preserved. Metrics/qualification unchanged.
