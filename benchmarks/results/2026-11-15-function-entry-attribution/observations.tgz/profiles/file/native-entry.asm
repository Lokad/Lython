; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 528
       lea      rbp, [rsp+0x210]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x1D0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x1C0], xmm8
       mov      rax, -384
 
G_M000_IG13:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG13
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu32 zmmword ptr [rbp-0x130], zmm0
       vmovdqu32 zmmword ptr [rbp-0xF0], zmm0
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm0
       vmovdqu32 zmmword ptr [rbp-0x70], zmm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x180], rax
       mov      qword ptr [rbp-0x178], rdx
 
G_M000_IG03:                ;; offset=0x00A9
       vmovdqu32 xmm0, xmmword ptr [rbp-0x180]
       vmovdqu32 xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG04:                ;; offset=0x00B7
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      edx, dword ptr [rbp-0x1C4]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x190], rax
       mov      qword ptr [rbp-0x188], rdx
 
G_M000_IG05:                ;; offset=0x00F0
       vmovdqu32 xmm0, xmmword ptr [rbp-0x190]
       vmovdqu32 xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG06:                ;; offset=0x00FE
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rsi, bword ptr [rbp-0x140]
       mov      rdx, qword ptr [rbp-0x138]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0123
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1C8], eax
       mov      edx, dword ptr [rbp-0x1C8]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG08:                ;; offset=0x016C
       vmovdqu32 xmm0, xmmword ptr [rbp-0x150]
       vmovdqu32 xmmword ptr [rbp-0x1B0], xmm0
 
G_M000_IG09:                ;; offset=0x017A
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r9, gword ptr [rbp-0x1D0]
       mov      rdi, bword ptr [rbp-0x1A0]
       mov      rsi, qword ptr [rbp-0x198]
       mov      rdx, bword ptr [rbp-0x1B0]
       mov      rcx, qword ptr [rbp-0x1A8]
       mov      r8, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
 
G_M000_IG10:                ;; offset=0x01F3
       vmovdqu32 xmm0, xmmword ptr [rbp-0x140]
       vmovdqu32 xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG11:                ;; offset=0x0201
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x170]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1C0]
       mov      rdx, qword ptr [rbp-0x1B8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG12:                ;; offset=0x028F
       add      rsp, 528
       pop      rbp
       ret      
 
; Total bytes of code 664

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 528
       lea      rbp, [rsp+0x210]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x1D0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x1C0], xmm8
       mov      rax, -384
 
G_M000_IG14:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG14
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu32 zmmword ptr [rbp-0x130], zmm0
       vmovdqu32 zmmword ptr [rbp-0xF0], zmm0
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm0
       vmovdqu32 zmmword ptr [rbp-0x70], zmm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x180], rax
       mov      qword ptr [rbp-0x178], rdx
 
G_M000_IG03:                ;; offset=0x00A9
       vmovdqu32 xmm0, xmmword ptr [rbp-0x180]
       vmovdqu32 xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG04:                ;; offset=0x00B7
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1C4], eax
       mov      edx, dword ptr [rbp-0x1C4]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x190], rax
       mov      qword ptr [rbp-0x188], rdx
 
G_M000_IG05:                ;; offset=0x00F0
       vmovdqu32 xmm0, xmmword ptr [rbp-0x190]
       vmovdqu32 xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG06:                ;; offset=0x00FE
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       SHORT G_M000_IG07
       mov      rsi, bword ptr [rbp-0x140]
       mov      rdx, qword ptr [rbp-0x138]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0123
       mov      rdi, 0x7EC3E0DF37C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1C8], eax
       mov      edx, dword ptr [rbp-0x1C8]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x150], xmm0
 
G_M000_IG08:                ;; offset=0x017B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x150]
       vmovdqu32 xmmword ptr [rbp-0x1B0], xmm0
 
G_M000_IG09:                ;; offset=0x0189
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r9, gword ptr [rbp-0x1D0]
       mov      rdi, bword ptr [rbp-0x1A0]
       mov      rsi, qword ptr [rbp-0x198]
       mov      rdx, bword ptr [rbp-0x1B0]
       mov      rcx, qword ptr [rbp-0x1A8]
       mov      r8, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
 
G_M000_IG10:                ;; offset=0x0202
       mov      rdi, 0x7EC3E0DF37CC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0211
       vmovdqu32 xmm0, xmmword ptr [rbp-0x140]
       vmovdqu32 xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG12:                ;; offset=0x021F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x170]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1C0]
       mov      rdx, qword ptr [rbp-0x1B8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG13:                ;; offset=0x02AD
       add      rsp, 528
       pop      rbp
       ret      
 
; Total bytes of code 694

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1903360
; 15 inlinees with PGO data; 72 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 808
       lea      rbp, [rsp+0x350]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x200], xmm8
       vmovdqa32 xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG104:                ;; offset=0x0036
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG104
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      rax, rdx
       mov      r15, r9
       mov      r14, gword ptr [rbp+0x10]
 
G_M000_IG02:                ;; offset=0x005F
       mov      rdi, gword ptr [rbx+0x68]
       mov      r13d, dword ptr [rdi+0x9C]
       mov      edx, dword ptr [rdi+0x98]
       mov      r12d, 4
       cmp      edx, 4
       cmovg    r12d, edx
       add      r13d, r12d
       jo       G_M000_IG97
       add      r13d, dword ptr [rdi+0xA4]
       jo       G_M000_IG97
       cmp      r13d, 16
       ja       G_M000_IG72
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG73
 
G_M000_IG03:                ;; offset=0x00A7
       mov      r12, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdx, gword ptr [rdi+0x08]
       mov      edx, dword ptr [rdx+0x08]
       cmp      edx, r13d
       ja       G_M000_IG72
       mov      dword ptr [rbp-0x204], edx
       mov      bword ptr [rbp-0x2D8], rax
       mov      r9, rax
       mov      bword ptr [rbp-0x2E0], r9
       mov      r10d, ecx
       xor      r11, r11
       mov      gword ptr [rbp-0x150], r11
 
G_M000_IG04:                ;; offset=0x00E4
       mov      gword ptr [rbp-0x158], r11
 
G_M000_IG05:                ;; offset=0x00EB
       cmp      dword ptr [rdi+0x28], 0
       jge      G_M000_IG75
       test     rsi, rsi
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00FA
       movzx    rax, byte  ptr [rsi+0x34]
       test     eax, eax
       je       G_M000_IG75
 
G_M000_IG07:                ;; offset=0x0106
       mov      edi, dword ptr [rdi+0x18]
       test     r8, r8
       setne    al
       movzx    rax, al
       sub      edi, eax
       cmp      edi, r10d
       jl       G_M000_IG76
       test     r8, r8
       jne      G_M000_IG77
 
G_M000_IG08:                ;; offset=0x0126
       test     r10d, r10d
       je       G_M000_IG13
 
G_M000_IG09:                ;; offset=0x012F
       xor      eax, eax
       mov      dword ptr [rbp-0x214], r10d
 
G_M000_IG10:                ;; offset=0x0138
       cmp      gword ptr [r9+rax], 0
       je       G_M000_IG78
 
G_M000_IG11:                ;; offset=0x0143
       lea      edi, [r11+0x01]
       mov      dword ptr [rbp-0x15C], edi
       cmp      r11d, edx
       jae      G_M000_IG98
       lea      r10, bword ptr [rbp-0x128]
       mov      r11d, r11d
       shl      r11, 4
       add      r10, r11
       mov      rdi, r10
       mov      bword ptr [rbp-0x308], rdi
       mov      qword ptr [rbp-0x210], rax
       lea      r10, bword ptr [r9+rax]
       mov      bword ptr [rbp-0x310], r10
       mov      rsi, gword ptr [r10]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x310]
       mov      rdi, qword ptr [rdi+0x08]
       mov      rsi, bword ptr [rbp-0x308]
       mov      qword ptr [rsi+0x08], rdi
       mov      rax, qword ptr [rbp-0x210]
       add      rax, 16
       mov      ecx, dword ptr [rbp-0x214]
       dec      ecx
       mov      dword ptr [rbp-0x214], ecx
       mov      r9, bword ptr [rbp-0x2E0]
       mov      r11d, dword ptr [rbp-0x15C]
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01CA
       mov      edx, dword ptr [rbp-0x204]
       jmp      G_M000_IG10
 
G_M000_IG13:                ;; offset=0x01D5
       xor      eax, eax
       mov      rdx, gword ptr [r12+0x08]
       cmp      dword ptr [rdx+0x18], 0
       jle      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x01E2
       cmp      eax, dword ptr [rbp-0x204]
       jae      G_M000_IG98
       lea      rdx, bword ptr [rbp-0x128]
       mov      rdi, rax
       shl      rdi, 4
       cmp      gword ptr [rdx+rdi], 0
       je       G_M000_IG81
 
G_M000_IG15:                ;; offset=0x0207
       inc      eax
       mov      rdi, rax
       mov      rsi, gword ptr [r12+0x08]
       cmp      edi, dword ptr [rsi+0x18]
       mov      rax, rdi
       jl       SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0219
       xor      eax, eax
 
G_M000_IG17:                ;; offset=0x021B
       mov      rdx, gword ptr [r12+0x08]
       mov      gword ptr [rbp-0x300], rdx
       cmp      eax, dword ptr [rdx+0x1C]
       jge      G_M000_IG64
 
G_M000_IG18:                ;; offset=0x0230
       mov      qword ptr [rbp-0x228], rax
       mov      edi, eax
       add      edi, dword ptr [rdx+0x18]
       mov      esi, edi
       mov      dword ptr [rbp-0x16C], esi
       cmp      esi, dword ptr [rbp-0x204]
       jae      G_M000_IG98
       lea      r8, bword ptr [rbp-0x128]
       mov      r9d, esi
       shl      r9, 4
       cmp      gword ptr [r8+r9], 0
       jne      G_M000_IG63
 
G_M000_IG19:                ;; offset=0x0269
       mov      rdx, gword ptr [rdx+0x08]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG98
       mov      edi, edi
       mov      rdx, gword ptr [rdx+8*rdi+0x10]
       mov      gword ptr [rbp-0x238], rdx
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x240], rax
       test     rax, rax
       je       G_M000_IG87
       mov      rdi, gword ptr [r12+0x28]
       mov      rcx, qword ptr [rbp-0x228]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG98
       mov      qword ptr [rbp-0x228], rcx
       mov      r8, gword ptr [rdi+8*rcx+0x10]
       mov      gword ptr [rbp-0x278], r8
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG83
       test     r8, r8
       je       G_M000_IG85
       mov      r8, gword ptr [rbp-0x278]
       cmp      dword ptr [rax+0x50], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      G_M000_IG84
 
G_M000_IG20:                ;; offset=0x02F4
       mov      rax, gword ptr [rbp-0x240]
       xor      r9, r9
       xor      r10, r10
       xor      r11d, r11d
 
G_M000_IG21:                ;; offset=0x0304
       mov      gword ptr [rbp-0x2F0], r9
       mov      gword ptr [rbp-0x2F8], r10
       mov      byte  ptr [rbp-0x208], r11b
 
G_M000_IG22:                ;; offset=0x0319
       mov      rdi, rax
       mov      rsi, r8
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0x1D8], rax
       mov      eax, dword ptr [rbp-0x1D8]
       mov      dword ptr [rbp-0x1DC], eax
       movzx    rcx, byte  ptr [rbp-0x1D4]
       mov      dword ptr [rbp-0x1E0], ecx
       mov      rdx, gword ptr [rbp-0x240]
       cmp      gword ptr [rdx+0x28], 0
       je       G_M000_IG35
       cmp      dword ptr [rdx+0x50], 0
       jne      G_M000_IG34
 
G_M000_IG23:                ;; offset=0x0367
       mov      ecx, dword ptr [rbp-0x1E0]
       test     ecx, ecx
       jne      G_M000_IG52
       mov      rcx, gword ptr [rdx+0x28]
       mov      gword ptr [rbp-0x280], rcx
       cmp      dword ptr [rdx+0x4C], 0
       je       G_M000_IG36
 
G_M000_IG24:                ;; offset=0x038A
       mov      edi, dword ptr [rcx+0x08]
       blsr     esi, edi
       jne      G_M000_IG37
       dec      edi
       and      edi, dword ptr [rbp-0x1D8]
 
G_M000_IG25:                ;; offset=0x03A0
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      esi, dword ptr [rcx+8*rdi+0x30]
       dec      esi
       js       G_M000_IG40
 
G_M000_IG26:                ;; offset=0x03BB
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      edi, esi
       lea      rdi, [rdi+4*rdi]
       lea      r8, bword ptr [rcx+8*rdi+0x10]
       mov      bword ptr [rbp-0x288], r8
       mov      rdx, gword ptr [rbp-0x240]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG39
 
G_M000_IG27:                ;; offset=0x03E8
       mov      eax, dword ptr [rbp-0x1DC]
       cmp      dword ptr [r8+0x18], eax
       jne      G_M000_IG41
       mov      rdi, 0x7EBC018017E8
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rbp-0x290], r9
       mov      r10, gword ptr [r8]
       mov      gword ptr [rbp-0x298], r10
       mov      r11, r15
       test     r11, r11
       je       G_M000_IG42
 
G_M000_IG28:                ;; offset=0x0422
       mov      rdi, r14
       test     rdi, rdi
       je       G_M000_IG43
 
G_M000_IG29:                ;; offset=0x042E
       mov      r10, gword ptr [rbp-0x298]
       mov      r9, gword ptr [rbp-0x278]
       cmp      r10, r9
       jne      G_M000_IG44
       test     r9, r9
       mov      r8, bword ptr [rbp-0x288]
       je       G_M000_IG41
 
G_M000_IG30:                ;; offset=0x0455
       mov      eax, esi
 
G_M000_IG31:                ;; offset=0x0457
       test     eax, eax
       jl       G_M000_IG59
       mov      rcx, gword ptr [rdx+0x30]
       test     rcx, rcx
       je       G_M000_IG58
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG56
       mov      gword ptr [rbp-0x2B0], rcx
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG57
       mov      esi, eax
       mov      r8, gword ptr [rcx+8*rsi+0x10]
       test     r8, r8
       je       G_M000_IG55
 
G_M000_IG32:                ;; offset=0x0497
       mov      rdi, r8
 
G_M000_IG33:                ;; offset=0x049A
       mov      gword ptr [rbp-0x178], rdi
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0x1E4], eax
       jmp      G_M000_IG60
 
G_M000_IG34:                ;; offset=0x04B1
       mov      ecx, dword ptr [rbp-0x1E0]
       jmp      G_M000_IG52
 
G_M000_IG35:                ;; offset=0x04BC
       mov      rdi, gword ptr [rdx+0x08]
       mov      r11, 0x7EC3DE273018
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      rdx, gword ptr [rbp-0x240]
       jne      SHORT G_M000_IG38
       jmp      G_M000_IG23
 
G_M000_IG36:                ;; offset=0x04DD
       mov      rdx, gword ptr [rbp-0x240]
       jmp      G_M000_IG51
 
G_M000_IG37:                ;; offset=0x04E9
       mov      eax, dword ptr [rbp-0x1D8]
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       jmp      G_M000_IG25
 
G_M000_IG38:                ;; offset=0x04FA
       mov      ecx, dword ptr [rbp-0x1E0]
       jmp      G_M000_IG52
 
G_M000_IG39:                ;; offset=0x0505
       mov      rdi, gword ptr [rdx+0x30]
       cmp      dword ptr [rdi+0x08], esi
       jbe      SHORT G_M000_IG41
       mov      rdi, gword ptr [rdx+0x30]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG57
       mov      dword ptr [rbp-0x1EC], esi
       mov      r9d, esi
       cmp      gword ptr [rdi+8*r9+0x10], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       mov      rdx, gword ptr [rbp-0x240]
       mov      esi, dword ptr [rbp-0x1EC]
       je       SHORT G_M000_IG41
       jmp      G_M000_IG27
 
G_M000_IG40:                ;; offset=0x0548
       mov      rdx, gword ptr [rbp-0x240]
       jmp      G_M000_IG51
 
G_M000_IG41:                ;; offset=0x0554
       mov      rsi, r14
       test     rsi, rsi
       je       G_M000_IG49
       jmp      G_M000_IG50
 
G_M000_IG42:                ;; offset=0x0565
       mov      dword ptr [rbp-0x1EC], esi
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      r11, gword ptr [rax+0x18]
       mov      rax, r11
       mov      r11, rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      esi, dword ptr [rbp-0x1EC]
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x0592
       mov      rdi, gword ptr [rdx+0x18]
       mov      gword ptr [rbp-0x2A8], rdi
       mov      rdx, gword ptr [rbp-0x240]
       mov      rdi, gword ptr [rbp-0x2A8]
       jmp      G_M000_IG29
 
G_M000_IG44:                ;; offset=0x05B0
       mov      gword ptr [rbp-0x2A0], r11
       test     r11, r11
       mov      dword ptr [rbp-0x1EC], esi
       mov      gword ptr [rbp-0x2A8], rdi
       je       SHORT G_M000_IG45
       mov      rsi, r10
       mov      rdi, 0x7EC3E0A458C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG46
       mov      r8, gword ptr [rbp-0x278]
       mov      rsi, r8
       test     rsi, rsi
       mov      r10, gword ptr [rbp-0x298]
       jne      SHORT G_M000_IG47
       mov      r9, gword ptr [rbp-0x278]
 
G_M000_IG45:                ;; offset=0x05FD
       mov      rdi, gword ptr [rbp-0x290]
       mov      rsi, r10
       mov      rdx, r9
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x0612
       mov      r9, gword ptr [rbp-0x278]
       mov      r10, gword ptr [rbp-0x298]
       jmp      SHORT G_M000_IG45
 
G_M000_IG47:                ;; offset=0x0622
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, gword ptr [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG48:                ;; offset=0x0639
       test     eax, eax
       mov      rdx, gword ptr [rbp-0x240]
       mov      esi, dword ptr [rbp-0x1EC]
       mov      r8, bword ptr [rbp-0x288]
       je       G_M000_IG41
       jmp      G_M000_IG30
 
G_M000_IG49:                ;; offset=0x065A
       mov      rsi, gword ptr [rdx+0x18]
 
G_M000_IG50:                ;; offset=0x065E
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rdi, bword ptr [rbp-0x288]
       mov      esi, dword ptr [rdi+0x1C]
       dec      esi
       mov      eax, esi
       test     eax, eax
       mov      esi, eax
       mov      rcx, gword ptr [rbp-0x280]
       jge      G_M000_IG26
       mov      rdx, gword ptr [rbp-0x240]
 
G_M000_IG51:                ;; offset=0x068D
       mov      eax, -1
       jmp      G_M000_IG31
 
G_M000_IG52:                ;; offset=0x0697
       test     r15, r15
       jne      SHORT G_M000_IG54
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x278]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG53
       mov      rdi, gword ptr [rbp-0x240]
       mov      rsi, gword ptr [rbp-0x278]
       mov      edx, dword ptr [rbp-0x1D8]
       xor      rcx, rcx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      rdx, gword ptr [rbp-0x240]
       jmp      G_M000_IG31
 
G_M000_IG53:                ;; offset=0x06DB
       mov      rdx, gword ptr [rbp-0x240]
       jmp      G_M000_IG31
 
G_M000_IG54:                ;; offset=0x06E7
       xor      edi, edi
       mov      dword ptr [rsp], edi
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x278]
       mov      edx, dword ptr [rbp-0x1D8]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      rdx, gword ptr [rbp-0x240]
       jmp      G_M000_IG31
 
G_M000_IG55:                ;; offset=0x0714
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x200], xmm0
       mov      rsi, gword ptr [rdx+0x28]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG57
       mov      dword ptr [rbp-0x1E8], eax
       mov      edi, eax
       lea      rdi, [rdi+4*rdi]
       mov      rsi, qword ptr [rsi+8*rdi+0x20]
       lea      rdi, [rbp-0x200]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7EC3E0A41F78
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2B8], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x200]
       call     CORINFO_HELP_ASSIGN_REF
       mov      esi, dword ptr [rbp-0x1F8]
       mov      rax, gword ptr [rbp-0x2B8]
       mov      dword ptr [rax+0x10], esi
       mov      gword ptr [rbp-0x2C0], rax
       mov      esi, dword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rbp-0x2B0]
       mov      rdx, rax
       call     [CORINFO_HELP_ARRADDR_ST]
       mov      rdi, gword ptr [rbp-0x2C0]
       mov      eax, dword ptr [rbp-0x1E8]
       jmp      G_M000_IG33
 
G_M000_IG56:                ;; offset=0x07AF
       mov      rdi, rcx
       cmp      eax, dword ptr [rdi+0x08]
       jae      SHORT G_M000_IG57
       mov      ecx, eax
       mov      rdi, gword ptr [rdi+8*rcx+0x10]
       jmp      G_M000_IG33
 
G_M000_IG57:                ;; offset=0x07C3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG58:                ;; offset=0x07C9
       mov      rdi, 0x7EBC01801720
       mov      r8, gword ptr [rdi]
       jmp      G_M000_IG32
 
G_M000_IG59:                ;; offset=0x07DB
       mov      rdi, 0x7EBC01801720
       mov      rdi, gword ptr [rdi]
       jmp      G_M000_IG33
 
G_M000_IG60:                ;; offset=0x07ED
       cmp      byte  ptr [rbp-0x208], 0
       jne      G_M000_IG86
 
G_M000_IG61:                ;; offset=0x07FA
       mov      eax, dword ptr [rbp-0x1E4]
 
G_M000_IG62:                ;; offset=0x0800
       test     eax, eax
       je       G_M000_IG87
       lea      rdi, bword ptr [rbp-0x128]
       mov      esi, dword ptr [rbp-0x16C]
       shl      rsi, 4
       add      rdi, rsi
       mov      rsi, gword ptr [rbp-0x178]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG63:                ;; offset=0x0828
       mov      rax, qword ptr [rbp-0x228]
       inc      eax
       mov      rdi, rax
       jmp      G_M000_IG17
 
G_M000_IG64:                ;; offset=0x0839
       cmp      dword ptr [rdx+0x28], 0
       jge      G_M000_IG88
 
G_M000_IG65:                ;; offset=0x0843
       mov      rdi, gword ptr [r12+0x08]
       cmp      dword ptr [rdi+0x2C], 0
       jge      G_M000_IG92
 
G_M000_IG66:                ;; offset=0x0852
       xor      rdx, rdx
       mov      gword ptr [rbp-0x150], rdx
 
G_M000_IG67:                ;; offset=0x085B
       mov      gword ptr [rbp-0x158], rdx
 
G_M000_IG68:                ;; offset=0x0862
       mov      gword ptr [rbp-0x168], rdx
 
G_M000_IG69:                ;; offset=0x0869
       mov      gword ptr [rbp-0x178], rdx
 
G_M000_IG70:                ;; offset=0x0870
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x148], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x148]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      r12d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r12d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r15
       mov      r15, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r15
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, r13d
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, r14
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       nop      
 
G_M000_IG71:                ;; offset=0x08EF
       add      rsp, 808
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG72:                ;; offset=0x0901
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG73:                ;; offset=0x0908
       cmp      ecx, r13d
       ja       SHORT G_M000_IG74
       mov      edx, ecx
       shl      rdx, 4
       lea      rdi, bword ptr [rbp-0x128]
       mov      rsi, rax
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       jmp      G_M000_IG70
 
G_M000_IG74:                ;; offset=0x0928
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG75:                ;; offset=0x092F
       mov      gword ptr [rsp], r15
       mov      gword ptr [rsp+0x08], r8
       mov      gword ptr [rsp+0x10], rsi
       mov      rax, bword ptr [rbp-0x2D8]
       mov      bword ptr [rsp+0x18], rax
       mov      dword ptr [rsp+0x20], ecx
       lea      rdi, [rbp-0x150]
       mov      qword ptr [rsp+0x28], rdi
       lea      rdi, [rbp-0x158]
       mov      qword ptr [rsp+0x30], rdi
       lea      rdi, bword ptr [rbp-0x128]
       mov      esi, edx
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, r14
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref)]
       jmp      G_M000_IG13
 
G_M000_IG76:                ;; offset=0x0983
       mov      edi, dword ptr [r12+0x30]
       mov      rsi, gword ptr [r12+0x10]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG77:                ;; offset=0x099F
       mov      dword ptr [rbp-0x15C], 1
       test     edx, edx
       je       G_M000_IG98
       mov      gword ptr [rbp-0x128], r8
       mov      edx, dword ptr [rbp-0x204]
       mov      r11d, dword ptr [rbp-0x15C]
       jmp      G_M000_IG08
 
G_M000_IG78:                ;; offset=0x09CA
       mov      dword ptr [rbp-0x15C], r11d
 
G_M000_IG79:                ;; offset=0x09D1
       mov      qword ptr [rbp-0x210], rax
       vmovdqu  xmm0, xmmword ptr [r9+rax]
       vmovdqu  xmmword ptr [rbp-0x1B8], xmm0
 
G_M000_IG80:                ;; offset=0x09E6
       lea      rdi, [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, 0x7EC3E0C47780
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rax, qword ptr [rbp-0x210]
       mov      edx, dword ptr [rbp-0x204]
       mov      r9, bword ptr [rbp-0x2E0]
       mov      r11d, dword ptr [rbp-0x15C]
       jmp      G_M000_IG11
 
G_M000_IG81:                ;; offset=0x0A26
       mov      rdx, gword ptr [r12+0x08]
       mov      rdx, gword ptr [rdx+0x08]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG98
       mov      r8, gword ptr [rdx+8*rax+0x10]
       mov      gword ptr [rbp-0x230], r8
       lea      rdx, [rbp-0x168]
       mov      rdi, r12
       mov      qword ptr [rbp-0x220], rax
       mov      esi, eax
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG82
       lea      rdi, bword ptr [rbp-0x128]
       mov      rax, qword ptr [rbp-0x220]
       mov      rsi, rax
       shl      rsi, 4
       add      rdi, rsi
       mov      rsi, gword ptr [rbp-0x168]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, qword ptr [rbp-0x220]
       jmp      G_M000_IG15
 
G_M000_IG82:                ;; offset=0x0A91
       mov      edi, dword ptr [r12+0x30]
       mov      rsi, gword ptr [r12+0x10]
       mov      rdx, gword ptr [rbp-0x230]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG83:                ;; offset=0x0AB4
       lea      r8, [rbp-0x178]
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG62
 
G_M000_IG84:                ;; offset=0x0AD6
       lea      rdi, [rbp-0x1D0]
       mov      rsi, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0x1D0]
       mov      r10, gword ptr [rbp-0x1C8]
       movzx    r11, byte  ptr [rbp-0x1C0]
       mov      rax, gword ptr [rbp-0x240]
       mov      r8, gword ptr [rbp-0x278]
       jmp      G_M000_IG21
 
G_M000_IG85:                ;; offset=0x0B12
       jmp      SHORT G_M000_IG84
 
G_M000_IG86:                ;; offset=0x0B14
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x2F0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x20]
       mov      rsi, gword ptr [rbp-0x2F8]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG61
 
G_M000_IG87:                ;; offset=0x0B4F
       mov      edi, dword ptr [r12+0x30]
       mov      rsi, gword ptr [r12+0x10]
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG88:                ;; offset=0x0B72
       mov      rdi, 0x7EC3E0C80738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x258], rax
       mov      rdi, gword ptr [rbp-0x300]
       mov      ecx, dword ptr [rdi+0x28]
       mov      dword ptr [rbp-0x1A4], ecx
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x150]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x258]
       cmp      gword ptr [rax+0x08], 0
       je       SHORT G_M000_IG89
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi+0x28], 0
       jne      G_M000_IG91
 
G_M000_IG89:                ;; offset=0x0BC4
       mov      edi, dword ptr [rbp-0x1A4]
       cmp      edi, dword ptr [rbp-0x204]
       jae      G_M000_IG98
       lea      rcx, bword ptr [rbp-0x128]
       mov      edx, edi
       shl      rdx, 4
       add      rcx, rdx
       mov      bword ptr [rbp-0x260], rcx
       mov      rdi, 0x7EBC018035D8
       mov      rsi, gword ptr [rdi]
       test     rsi, rsi
       jne      SHORT G_M000_IG90
       mov      rdi, 0x7EC3E0C26BC8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x268], rax
       mov      rdi, 0x7EBC018035B0
       mov      rsi, gword ptr [rdi]
       mov      rdi, gword ptr [rbp-0x268]
       mov      rdx, 0x7EC3E0C1B258
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdi, 0x7EBC018035D8
       mov      rsi, gword ptr [rbp-0x268]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x268]
 
G_M000_IG90:                ;; offset=0x0C56
       mov      rcx, r14
       mov      rdx, r15
       xor      edi, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x260]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG65
 
G_M000_IG91:                ;; offset=0x0C78
       mov      rcx, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x2C8], rcx
       mov      rdi, 0x7EC3E0C26BC8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, gword ptr [rbp-0x2C8]
       mov      ecx, dword ptr [rdi+0x28]
       mov      dword ptr [rbp-0x1A8], ecx
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x258]
       mov      rdx, 0x7EC3E0C1B270
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      edi, dword ptr [rbp-0x1A8]
       mov      rsi, gword ptr [rbp-0x270]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      ecx, dword ptr [rbp-0x1A4]
       cmp      ecx, dword ptr [rbp-0x204]
       jae      G_M000_IG98
       lea      rdi, bword ptr [rbp-0x128]
       mov      esi, ecx
       shl      rsi, 4
       lea      rdi, bword ptr [rdi+rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG65
 
G_M000_IG92:                ;; offset=0x0D0C
       mov      rax, gword ptr [r15+0x98]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdi, 0x7EC3E0C060A0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x248], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rdx, gword ptr [rdx+0x88]
       mov      rdi, rax
       mov      rcx, r14
       xor      esi, esi
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       mov      rax, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x250], rax
       cmp      gword ptr [rbp-0x158], 0
       je       SHORT G_M000_IG93
       lea      rsi, [rbp-0x1A0]
       mov      rdi, gword ptr [rbp-0x158]
       cmp      dword ptr [rdi], edi
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x0D7F
       mov      rax, gword ptr [rbp-0x250]
       jmp      SHORT G_M000_IG96
 
G_M000_IG94:                ;; offset=0x0D88
       mov      rdi, gword ptr [rbp-0x188]
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rsi, gword ptr [r15+0x98]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x250]
       mov      rdx, gword ptr [rbp-0x2E8]
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG95:                ;; offset=0x0DCB
       lea      rdi, [rbp-0x1A0]
       mov      rsi, 0x7EC3E0BFF9E0
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG94
       mov      rax, gword ptr [rbp-0x250]
 
G_M000_IG96:                ;; offset=0x0DED
       mov      rdi, gword ptr [r12+0x08]
       mov      edi, dword ptr [rdi+0x2C]
       cmp      edi, dword ptr [rbp-0x204]
       jae      SHORT G_M000_IG98
       lea      rsi, bword ptr [rbp-0x128]
       shl      rdi, 4
       lea      rdi, bword ptr [rsi+rdi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG66
 
G_M000_IG97:                ;; offset=0x0E19
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG98:                ;; offset=0x0E1F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG99:                ;; offset=0x0E25
       sub      rsp, 72
 
G_M000_IG100:                ;; offset=0x0E29
       cmp      byte  ptr [rbp-0x208], 0
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0E32
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x2F0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x20]
       mov      rsi, gword ptr [rbp-0x2F8]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG102:                ;; offset=0x0E68
       nop      
 
G_M000_IG103:                ;; offset=0x0E69
       add      rsp, 72
       ret      
 
; Total bytes of code 3694

