from pathlib import Path
import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/json-encoding-settings-20261124'
donor=lab.with_name('json-encoding-flags-20261124')
original=lab.with_name('json-encoding-settings-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda file:sha(file.read_bytes())
save=lambda path,obj:path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()
assert candidate.startswith('c9746215b')
metadata=read(donor/'comparison/identity.json')
reference=metadata['candidate']
assert reference.startswith('eabbf02ed')
assert subprocess.check_output(['git','diff','--name-only',reference,candidate,'--','src'],cwd=tree).decode().splitlines()==[
    'src/Lokad.Lython/Runtime/LythonRuntime.Json.Serialize.cs']

catalog=read(donor/'comparison/representative.json')
expanded,default,_,positional=catalog['cases']
escaped=dict(expanded,id='scripts.json-lines-shipment.escaped-options.large')
replacement=repr('\n€"\\')+' * 4'
escaped['source']=expanded['source'].replace('row["name"].strip()',f'row["name"].strip() + {replacement}')
assert escaped['source']!=expanded['source']
fixture=json.loads(escaped['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-json-escaped-golden-') as name:
    path=Path(name)
    (path/'records.json').write_bytes(base64.b64decode(fixture['inputFiles']['records.json']))
    stdout=io.StringIO()
    with contextlib.chdir(path),contextlib.redirect_stdout(stdout):
        exec(compile(escaped['source'],'escaped_json.py','exec'),{'__name__':'__main__'})
    result=(path/'shipments.jsonl').read_bytes()
assert stdout.getvalue()==escaped['expectedOutput']
fixture['outputFiles']['shipments.jsonl']=base64.b64encode(result).decode('ascii')
escaped['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
escaped['fixtureSha256']=sha(escaped['fixtureJson'].encode('utf-8'))
escaped['sourceUtf8Bytes']=len(escaped['source'].encode('utf-8'))
escaped['sourceSha256']=sha(escaped['source'].encode('utf-8'))
protocol=repo/'benchmarks/cpython-worker.py'
loader=importlib.util.spec_from_file_location('comparison_protocol',protocol)
commands=importlib.util.module_from_spec(loader)
loader.loader.exec_module(commands)
escaped['expectedFilesSha256']=commands.file_digest({'shipments.jsonl':result})
catalog['cases']=[expanded,default,escaped,positional]
save(comparison/'representative.json',catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})

assembly=(donor/'prepare.py').read_text(encoding='utf-8')
assembly=assembly[assembly.index('runtime=Path.home()'):]
assembly=assembly.replace('B1553 share canonical JSON flags and retain the compact default iterator',
    'B1554 quote clean JSON scalar output in one admitted window')
assembly=assembly.replace("(donor/'allocations.py').read_bytes()", "(original/'allocations.py').read_bytes()")
exec(assembly)
