from io import BytesIO
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/'comparison'
record=repo/'benchmarks/results/2026-11-24-json-scalar-windows'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
identity=read(comparison/'identity.json')
assert identity['candidate'].startswith('c9746215b') and identity['sourceRevision'].startswith('eabbf02ed')
cases=read(comparison/'representative.json')['cases']
assert len(cases)==4
assert digest(comparison/'representative.json')==identity['catalogs']['representative.json']['sha256']
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and all(digest(lab/role/name)==expected for name,expected in files.items())
    verify=read(comparison/(role+'-verify.json'))
    assert verify['state']=='Completed' and verify['caseCount']==len(cases)
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']
    rows=read(lab/(role+'-allocation-six.json'))['rows']
    assert len(rows)==4 and all(row['sharedBudgetBaselineRestored'] for row in rows)
allocation=read(lab/'allocation-summary-six.json')
assert [row['case'] for row in allocation]==[case['id'] for case in cases]
assert allocation[0]['peakAdmission']==[6157312,6169600]
assert all(row['peakAdmission'][0]==row['peakAdmission'][1] for row in allocation[1:])
record.mkdir(exist_ok=True)
shutil.copyfile(lab/'allocation-summary-six.json',record/'allocation-summary.json')
shutil.copyfile(comparison/'identity.json', record/'identity.json')
inputs=('prepare.py','allocations.py','archive.py','comparison/representative.json','comparison/jobs.json',
    'comparison/reference-verify.json','comparison/candidate-verify.json',
    'reference-allocation-six.json','candidate-allocation-six.json')
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src'],cwd=repo)
with tarfile.open(record/'observations.tar.xz','w:xz') as archive:
    for name in inputs:
        archive.add(lab/name,arcname=name)
    entry=tarfile.TarInfo('changes.patch')
    entry.size=len(patch)
    archive.addfile(entry,BytesIO(patch))
with tarfile.open(record/'observations.tar.xz') as archive:
    assert set(archive.getnames())==set(inputs)|{'changes.patch'}
    assert archive.extractfile('changes.patch').read()==patch
    assert all(archive.extractfile(name).read()==(lab/name).read_bytes() for name in inputs)
