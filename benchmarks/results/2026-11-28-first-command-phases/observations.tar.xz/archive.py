from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from statistics import median
import io
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
report=repo/'benchmarks/results/2026-11-28-first-command-phases'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
images=read(lab/'summary.json')
setup=read(lab/'setup.json')
proof=read(lab/'trace-receipt.json')
assert images['productionSource']==setup['productionSource']
observations=read(lab/'observations.json')
assert observations['completedRounds']==12 and len(observations['rows'])==images['verifiedInvocations']==36
assert all(v['frame']['response']['status']=='Equivalent' for v in [*observations['warm'],*observations['rows']])
for role in ('reference','instrumented'):
    assert {p.name:digest(p) for p in (lab/role).iterdir()}==images[role]
assert {name for name in images['reference'] if images['reference'][name]!=images['instrumented'][name]}=={'Lokad.Lython.Benchmarks.dll'}
assert digest(lab/'config.json')==setup['payloadSHA256']==images['payloadSHA256']
assert len(proof)==2 and all(digest(lab/row['trace'])==row['traceSha256'] and row['workerAndTracerJoined'] for row in proof)
assert not subprocess.check_output(['git','diff','--name-only',setup['productionSource'],'HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
intervals=[json.loads(line) for line in (lab/'jit-intervals.jsonl').read_text(encoding='utf-8-sig').splitlines()]
assert len(intervals)==2
assert all(t['starts']==t['completed']==len(t['intervals']) and not t['unmatched'] and t['overwritten']==0 for t in intervals)
report.mkdir(exist_ok=True)
for name in ('summary.json',): copyfile(lab/name,report/name)

def namespace(ns):
    for group in ['Lokad.Lython.Benchmarks','Lokad.Lython.Frontend','Lokad.Lython.Runtime','Lokad.Lython']:
        if ns.startswith(group): return group
    return 'Other'

details=[]
for trace in intervals:
    counts=defaultdict(int)
    millis=defaultdict(float)
    for method in trace['intervals']:
        group=namespace(method['Namespace'])
        counts[group]+=1
        millis[group]+=method['End']-method['Start']
    top=sorted(trace['intervals'],key=lambda row:row['End']-row['Start'],reverse=True)[:18]
    details.append(dict(trace=trace['trace'],counts=dict(counts),milliseconds=dict(millis),longest=top))
(report/'jit-summary.json').write_text(json.dumps(details,indent=2)+'\n',encoding='utf-8',newline='\n')
files=[lab/n for n in (
    'prepare.py','collect.py','collect-trace.py','setup.json','config.json','cpython-worker.py','observations.json',
    'build.log','collection.log','initial-fixture-rejection.log','initial-corelib-path.log','trace-receipt.json','trace-collection.log',
    'jit-intervals.jsonl','trace-reader/TraceReader.csproj','trace-reader/Program.cs','trace-reader/build.log',
    'trace-reader/initial-allowlist.log','archive.py')]
files.extend(lab/n for n in ('worker-source/FreshPhaseClock.cs','worker-source/Program.cs','worker-source/Lokad.Lython.Benchmarks.csproj',
    'worker-source/Comparison/ComparisonCatalogCommand.cs','worker-source/Comparison/LythonOnceWorker.cs'))
for row in proof:
    base=row['trace'].removesuffix('.nettrace')
    files.extend(lab/f'{base}{suffix}' for suffix in ('.nettrace','.log','.frame','.stderr'))
with tarfile.open(report/'observations.tar.xz','w:xz') as output:
    for file in files: output.add(file,arcname=file.relative_to(lab))
with tarfile.open(report/'observations.tar.xz') as output:
    assert all(output.extractfile(p.relative_to(lab).as_posix()).read()==p.read_bytes() for p in files)
print(len(files),'archived evidence files')
