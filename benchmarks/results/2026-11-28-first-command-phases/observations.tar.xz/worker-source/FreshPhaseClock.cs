using System.Diagnostics;

namespace Lokad.Lython.Benchmarks.Comparison;

internal static class FreshPhaseClock
{
    private static readonly long[] Ticks = new long[12];

    internal static void Mark(int phase) => Ticks[phase] = Stopwatch.GetTimestamp();

    internal static void Report()
        => Console.Error.WriteLine("LYTHON_PHASES " + Stopwatch.Frequency + " " + string.Join(' ', Ticks));
}
