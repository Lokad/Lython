from pathlib import Path
import json
from hashlib import sha256
from shutil import copyfile, copytree
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.parent/'compiler-checkpoint-b1926-20261128'
quiet=previous/'comparison/quiet'
source=lab/'worker-source'
reference=lab/'reference'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
manifest=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
revision=git('rev-parse','HEAD').decode().strip()
identity=read(quiet/'identity.json')
assert not git('diff','--name-only',identity['sourceRevision'],revision,'--','src','benchmarks/Lokad.Lython.Benchmarks')
assert manifest(quiet/'local-image')==identity['imageFiles']['candidate']
smoke=read(previous/'fresh-startup/receipt.json')
payload,={row['payloadSha256'] for row in smoke['rows']}
payload_file,=list((previous/'fresh-startup').glob('receipt.json.inputs-*/0000.json'))
assert digest(payload_file)==payload
copyfile(payload_file,lab/'config.json')
copyfile(quiet/'cpython-worker.py',lab/'cpython-worker.py')
copytree(quiet/'local-image',reference)
assert manifest(reference)==identity['imageFiles']['candidate']
assert smoke['state']=='Completed' and smoke['launched']['pythonWorker']['sha256']==digest(lab/'cpython-worker.py')
def write(path,text):
    path.write_text(text,encoding='utf-8',newline='\n')
prefix='benchmarks/Lokad.Lython.Benchmarks/'
original_files={}
for name in git('ls-files','-z',prefix).decode('utf-8').strip('\0').split('\0'):
    if name.endswith('packages.lock.json'): continue
    target=source/name.removeprefix(prefix)
    target.parent.mkdir(exist_ok=True,parents=True)
    target.write_bytes(git('show',f'{revision}:{name}'))
    original_files[target.relative_to(source).as_posix()]=digest(target)

def edit(name, replacements):
    path=source/name
    text=path.read_text(encoding='utf-8')
    for old,new in replacements:
        assert text.count(old)==1,(name,old)
        text=text.replace(old,new)
    write(path,text)

edit('Lokad.Lython.Benchmarks.csproj',[
    ('<ProjectReference Include="../../src/Lokad.Lython.Utf8Regex/Lokad.Lython.Utf8Regex.csproj" />',
     '<Reference Include="Lokad.Lython.Utf8Regex" HintPath="../reference/Lokad.Lython.Utf8Regex.dll" />'),
    ('<ProjectReference Include="..\\..\\src\\Lokad.Lython\\Lokad.Lython.csproj" />',
     '<Reference Include="Lokad.Lython" HintPath="../reference/Lokad.Lython.dll" />')])
edit('Program.cs',[
    ('if (args.Length > 0 && args[0] == "--compare")','FreshPhaseClock.Mark(0);\nif (args.Length > 0 && args[0] == "--compare")')])
edit('Comparison/ComparisonCatalogCommand.cs',[
    ('            Console.OutputEncoding = new UTF8Encoding(false);','            FreshPhaseClock.Mark(1);\n            Console.OutputEncoding = new UTF8Encoding(false);'),
    ('                var manifest = ComparisonManifest.Load(arguments[2]);\n                if (arguments[0] == "once") LythonOnceWorker.RunAsync(manifest, Console.OpenStandardOutput()).GetAwaiter().GetResult();',
     '''                FreshPhaseClock.Mark(2);
                var manifest = ComparisonManifest.Load(arguments[2]);
                FreshPhaseClock.Mark(3);
                if (arguments[0] == "once")
                {
                    LythonOnceWorker.RunAsync(manifest, Console.OpenStandardOutput()).GetAwaiter().GetResult();
                    FreshPhaseClock.Mark(11);
                    FreshPhaseClock.Report();
                }''')])
edit('Comparison/LythonOnceWorker.cs',[
    ('        if (manifest.Cases.Count != 1)', '        FreshPhaseClock.Mark(4);\n        if (manifest.Cases.Count != 1)'),
    ('        using var script =','        FreshPhaseClock.Mark(5);\n        using var script ='),
    ('        if (script.IsValid) files?.Reset();','        FreshPhaseClock.Mark(6);\n        if (script.IsValid) files?.Reset();\n        FreshPhaseClock.Mark(7);'),
    ('        if (!script.IsValid) reason =','        FreshPhaseClock.Mark(8);\n        if (!script.IsValid) reason ='),
    ('        await ComparisonProtocol.WriteAsync(output, new','        FreshPhaseClock.Mark(9);\n        await ComparisonProtocol.WriteAsync(output, new'),
    ('        }, cancellationToken).ConfigureAwait(false);','        }, cancellationToken).ConfigureAwait(false);\n        FreshPhaseClock.Mark(10);')])
write(source/'FreshPhaseClock.cs','''using System.Diagnostics;

namespace Lokad.Lython.Benchmarks.Comparison;

internal static class FreshPhaseClock
{
    private static readonly long[] Ticks = new long[12];

    internal static void Mark(int phase) => Ticks[phase] = Stopwatch.GetTimestamp();

    internal static void Report()
        => Console.Error.WriteLine("LYTHON_PHASES " + Stopwatch.Frequency + " " + string.Join(' ', Ticks));
}
''')
write(lab/'setup.json',json.dumps(dict(repositoryRevision=revision,productionSource=identity['sourceRevision'],
                reference=identity['imageFiles']['candidate'],payloadSHA256=payload,originalSources=original_files,
                pythonSHA256=smoke['launched']['python']['sha256'],
                pythonWorkerSHA256=smoke['launched']['pythonWorker']['sha256'],
                dotnetSHA256=smoke['launched']['dotnet']['sha256']),indent=2)+'\n')
