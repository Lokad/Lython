
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
checkpoint=lab.parent/"cpython-checkpoint-20261123"
suite=lab.parent/"direct-suite-bindings-20261123"
inspection=lab.parent/"demanded-jump-targets-20261122"
out=lab/"comparison"
out.mkdir()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def hashes(p):return {v.name:h(v)for v in sorted(p.iterdir())if v.is_file()}
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
python=Path("C:/Python313/python.exe")
identity=read(checkpoint/"comparison/quiet/identity.json")
files=identity["imageFiles"]["candidate"]
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==identity["protocolSHA256"] and files==hashes(checkpoint/"frozen")
core="Lokad.Lython.dll"
known=read(suite/"comparison/catalog.json")
sources={
    "nested-assignment-bindings":"""def layer():
    bundle = (left := (nested := 3), (other := 4))
    return left, nested, other, bundle[0]
print(*layer())
""",
    "lambda-default-binding-and-body-isolation":"""def build():
    one = lambda p=(outside := 5): (separate := p + 1)
    two = lambda p=(held := (lambda q=(further := 7): (inner := q))): p()
    return outside, one(), two(), further, held()
print(*build())
""",
    "comprehension-and-format-bindings":"""def make():
    current = 0
    values = [(current := number * 3) for number in range(4)]
    summary = f"{(head := current)}"
    return values, summary, head
print(*make())
""",
}
for id,source in sources.items():
    result=subprocess.run([python,"-I","-S","-X","utf8","-c",source],check=True,capture_output=True,timeout=15)
    assert not result.stderr
    expected=result.stdout.decode("utf-8").replace("\r\n","\n")
    fixture='{"size":1,"text":null}'
    template=known["cases"][0]
    known["cases"].append(dict(id="scripts."+id,family=template["family"],category=template["category"],scale="small",size=1,source=source,
        fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(source.encode("utf-8")),expectedOutputUtf8Bytes=len(expected.encode("utf-8")),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source.encode("utf-8")),fixtureSha256=sha(fixture.encode("utf-8")),
        expectedOutputSha256=sha(expected.encode("utf-8"))))
catalog=out/"representative.json"
save(catalog,known)
probe_input=out/"inspection-catalog.json"
probe_catalog=read(inspection/"inspect-catalog.json")
probe_catalog["cases"]+=known["cases"][-len(sources):]
save(probe_input,probe_catalog)
probes=inspection/"reference/inspect"
probe_hashes=read(inspection/"inspection-identity.json")["workerImages"]["reference"]["inspect"]
assert probe_hashes==hashes(probes)
alloc=suite/"comparison/frozen-reference"
results={}
for role in ("reference","candidate"):
    image=out/f"frozen-{role}"
    image.mkdir()
    binary=lab/"windows/bin/Lokad.Lython/release_net11.0"/core if role=="candidate" else checkpoint/"frozen"/core
    expected_files={**files,core:h(binary)}
    for n in files:shutil.copyfile(binary if n==core else checkpoint/"frozen"/n,image/n)
    assert expected_files==hashes(image)
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",proof],env=env,cwd=repo,check=True,timeout=95)
    receipt=read(proof)
    assert receipt["state"]=="Completed" and receipt["caseCount"]==len(known["cases"]) and receipt["catalogSha256"]==h(catalog)
    for ext in (".dll",".deps.json",".runtimeconfig.json"):
        n="CompileAllocation"+ext
        shutil.copyfile(alloc/n,image/n)
    with (out/f"{role}-compile-allocation.json").open("wb")as sink:
        subprocess.run([dotnet,image/"CompileAllocation.dll",catalog],env=env,check=True,timeout=90,stdout=sink)
    assert read(out/f"{role}-compile-allocation.json")["coreSha256"]==h(binary)
    p=out/f"{role}-inspect"
    shutil.copytree(probes,p)
    shutil.copyfile(binary,p/core)
    assert {**probe_hashes,core:h(binary)}==hashes(p)
    result=out/f"{role}-inspect.json"
    subprocess.run([dotnet,p/"Inspect.dll",probe_input,result],env=env,check=True,timeout=45)
    inspected=read(result)
    assert inspected["coreSHA256"]==h(binary)
    assert all(h(image/n)==digest for n,digest in expected_files.items())
    results[role]=dict(image=expected_files,tape=inspected["rows"])
assert results["reference"]["tape"]==results["candidate"]["tape"]
save(out/"identity.json",dict(reference=identity["candidate"],catalogSHA256=h(catalog),
    inspectionCatalogSHA256=h(probe_input),tapeCases=len(results["reference"]["tape"]),
    images={k:v["image"]for k,v in results.items()}))
print(len(results["reference"]["tape"]),"identical tape fixtures and",len(known["cases"]),"verified CPython outputs and compilation allocation cases")

