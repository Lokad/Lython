using System.Text.Json;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var script = LythonFrontend.Compile(source).Script ?? throw new InvalidOperationException("Expected a parsed script.");
    var diagnostics = SyntaxValidityDiagnostics.Analyze(script, out _, out _, out var facts, out _, out _, default);
    if (diagnostics.Count != 0) throw new InvalidOperationException(string.Join("\n", diagnostics));
    var examined = 0;
    var skippedStatements = 0;
    var oldRoots = 0;
    var skippedRoots = 0;
    var skippedNodes = 0;
    var pending = new Stack<StatementSyntax>(script.Statements);
    while (pending.TryPop(out var statement))
    {
        examined++;
        foreach (var body in StatementSyntaxTraversal.EnumerateChildBodies(statement))
            foreach (var child in body) pending.Push(child);
        var flags = facts?.GetValueOrDefault(statement) ?? default;
        if (!flags.NeedsLexicalExpressions && statement is not MatchStatementSyntax) continue;
        var skipped = false;
        foreach (var expression in StatementSyntaxTraversal.EnumerateDirectExpressions(statement))
        {
            oldRoots++;
            if (flags.HasExpressionBindings) continue;
            skipped = true;
            skippedRoots++;
            skippedNodes += CountBindingsWalk(expression);
        }
        if (skipped) skippedStatements++;
    }
    rows.Add(new { id = item.GetProperty("id").GetString(), examined, oldRoots, skippedStatements, skippedRoots, skippedNodes });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));

static int CountBindingsWalk(ExpressionSyntax expression)
{
    var nodes = 1;
    if (expression is LambdaExpressionSyntax lambda)
    {
        foreach (var parameter in lambda.Parameters)
            if (parameter.DefaultValue is { } value) nodes += CountBindingsWalk(value);
        return nodes;
    }
    foreach (var child in ExpressionSyntaxTraversal.EnumerateChildren(expression)) nodes += CountBindingsWalk(child);
    return nodes;
}

