#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/syntax-binding-presence-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/syntax-binding-presence-20261123
mkdir -p "$lab/cli-tools" "$lab/ubuntu/tools/LythonProbe/bin/Release/net10.0"
test -x "$HOME/.local/bin/python3.13"
ln -s "$HOME/.local/bin/python3.13" "$lab/cli-tools/python"
export PATH="$DOTNET_ROOT:$lab/cli-tools:$PATH"
export LYTHON_DIFFTEST_PYTHON="$(command -v python)"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" > "$lab/probe-ubuntu.log" 2>&1 || { tail -35 "$lab/probe-ubuntu.log"; exit 1; }
cp -a "$lab/ubuntu/bin/LythonProbe/release_net10.0/." "$lab/ubuntu/tools/LythonProbe/bin/Release/net10.0/"
filter='Category!=Stress&(FullyQualifiedName~Lexical|FullyQualifiedName~ScopeDirective|FullyQualifiedName~NameBinding|FullyQualifiedName~Declaration|FullyQualifiedName~Comprehension|FullyQualifiedName~Walrus|FullyQualifiedName~AssignmentExpression|FullyQualifiedName~AugmentedAssignment|FullyQualifiedName~TypeAlias|FullyQualifiedName~Match|FullyQualifiedName~DefaultMetadata|FullyQualifiedName~Postponed)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/white-ubuntu.log" 2>&1 || { tail -45 "$lab/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -45 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"

