using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

// One private adaptation of the complete-job driver, not a new benchmark API.
var overrides = new[] { "DOTNET_gcServer", "COMPlus_gcServer", "DOTNET_GCHeapCount", "COMPlus_GCHeapCount",
    "DOTNET_GCHeapHardLimit", "COMPlus_GCHeapHardLimit", "DOTNET_GCHeapHardLimitPercent", "COMPlus_GCHeapHardLimitPercent",
    "DOTNET_TieredCompilation", "COMPlus_TieredCompilation", "DOTNET_TieredPGO", "COMPlus_TieredPGO",
    "DOTNET_TC_QuickJit", "COMPlus_TC_QuickJit", "DOTNET_TC_QuickJitForLoops", "COMPlus_TC_QuickJitForLoops",
    "DOTNET_ReadyToRun", "COMPlus_ReadyToRun", "DOTNET_PROCESSOR_COUNT" }.ToDictionary(n => n, Environment.GetEnvironmentVariable);
if (overrides.Values.Any(v => v is not null) || System.Runtime.GCSettings.IsServerGC)
    throw new InvalidDataException("Require the ordinary worker GC/tiering profile.");
var path = Path.GetFullPath(args[0]);
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
using var witness = JsonDocument.Parse(File.ReadAllBytes(args[2]));
var item = catalog.RootElement.GetProperty("cases").EnumerateArray().Single();
if (item.GetProperty("id").GetString() != "scripts.csv-summary-helpers.large")
    throw new InvalidDataException("Only the frozen CSV control is allowed.");
var hashSource = witness.RootElement.GetProperty("source").GetString()!;
using var first = new Image(path, item, hashSource, "first");
using var second = new Image(path, item, hashSource, "second");
if (first.Core == second.Core || first.EngineType == second.EngineType ||
    first.EngineType.BaseType!.Assembly != typeof(object).Assembly ||
    second.EngineType.BaseType!.Assembly != typeof(object).Assembly ||
    !first.Hashes.SequenceEqual(second.Hashes) ||
    JsonSerializer.Serialize(first.Files) != JsonSerializer.Serialize(second.Files))
    throw new InvalidDataException("Image isolation, shared CoreLib, hashes or input bits differ.");
first.Once(); second.Once();
for (var i = 0; i < 128; i++) { first.Once(); second.Once(); }
first.FreezeBalance(); second.FreezeBalance();
Thread.Sleep(TimeSpan.FromSeconds(2));
var samples = new List<object>();
for (var round = 0; round < 7; round++)
{
    foreach (var image in round % 2 == 0 ? new[] { first, second } : new[] { second, first })
    {
        var clock = Stopwatch.StartNew();
        for (var i = 0; i < 32; i++) image.Once();
        clock.Stop();
        samples.Add(new { round, image = image.Label, jobs = 32, elapsedMilliseconds = clock.Elapsed.TotalMilliseconds });
    }
}
first.Once(); second.Once();
first.Dispose(); second.Dispose();
Console.WriteLine(JsonSerializer.Serialize(new {
    performanceQualified = false, purpose = "One same-process identical-image control; no external ratio or causal claim",
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    processId = Environment.ProcessId, processors = Environment.ProcessorCount,
    catalogSHA256 = Hash(args[1]), witnessSHA256 = Hash(args[2]),
    sharedCoreLib = typeof(object).Assembly.Location, sharedCoreLibSHA256 = Hash(typeof(object).Assembly.Location),
    identicalFiles = first.Files, imageIsolationVerified = true, hashWitness = first.Hashes,
    warmupsPerImage = 128, settleSeconds = 2, rounds = 7, batch = 32, samples,
    normalGcAndTiering = true, runtimeOverrides = overrides, serverGc = System.Runtime.GCSettings.IsServerGC, allGoldensPassed = true, bothBalancesZero = true, ownedFixturesRemoved = true,
    boundary = "Complete public Run/fixture reset/mediated I/O/full goldens/result disposal; startup/compilation excluded. Two isolated Lython images share CoreLib/process GC and hashing. No context-unload guarantee."
}));

static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

sealed class Image : IDisposable
{
    private readonly object _budget;
    private readonly PropertyInfo _balance;
    private readonly object _host;
    private readonly MethodInfo _reset, _outputs, _digest, _validate;
    private readonly object _script;
    private readonly MethodInfo _run;
    private readonly string _owned, _stdout, _fileGolden;
    private long _expected = -1;
    private bool _disposed;
    public string Label { get; }
    public Assembly Core { get; }
    public Type EngineType { get; }
    public string[] Hashes { get; }
    public Dictionary<string, string> Files { get; }

    public Image(string path, JsonElement item, string hashSource, string label)
    {
        Label = label;
        var directory = Path.GetDirectoryName(path)!;
        var context = new ImageContext(directory, label);
        var benchmark = context.LoadFromAssemblyPath(path);
        Core = context.LoadFromAssemblyPath(Path.Combine(directory, "Lokad.Lython.dll"));
        EngineType = Core.GetType("Lokad.Lython.LythonEngine", true)!;
        var engine = Activator.CreateInstance(EngineType)!;
        var budgetType = Core.GetType("Lokad.Lython.LythonMemoryBudget", true)!;
        _budget = Activator.CreateInstance(budgetType, [null])!;
        _balance = budgetType.GetProperty("ReservedBytes")!;
        var compile = EngineType.GetMethod("Compile", [typeof(string), Core.GetType("Lokad.Lython.ILythonMemoryBudget", true)!])!;
        var fixtureType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
        var fixture = fixtureType.GetMethod("Parse")!.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;
        var hostType = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
        _validate = benchmark.GetType("Lokad.Lython.Benchmarks.Comparison.OwnedWorkerProcess", true)!
            .GetMethod("ValidateFixtureDirectory", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
        _owned = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
        _host = Activator.CreateInstance(hostType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
            null, [fixture, _owned], null)!;
        _reset = hostType.GetMethod("Reset")!; _outputs = hostType.GetMethod("ReadOutputs")!;
        _digest = fixtureType.GetMethod("Digest")!;
        try
        {
            using (var hashProgram = (IDisposable)compile.Invoke(engine, [hashSource, _budget])!)
            {
                RequireValid(hashProgram);
                var run = hashProgram.GetType().GetMethods().Single(m => m.Name == "Run" && m.GetParameters().Length == 1);
                using var result = (IDisposable)run.Invoke(hashProgram, [_host])!;
                RequireSuccess(result);
                var values = (IEnumerable)result.GetType().GetProperty("ReturnValue")!.GetValue(result)!;
                Hashes = values.Cast<object>().Select(v => ((IFormattable)v).ToString(null, CultureInfo.InvariantCulture)).ToArray();
            }
            if (Balance != 0) throw new InvalidDataException("Witness ownership did not end.");
            _script = compile.Invoke(engine, [item.GetProperty("source").GetString(), _budget])!;
            RequireValid(_script);
            _run = _script.GetType().GetMethods().Single(m => m.Name == "Run" && m.GetParameters().Length == 1);
            _stdout = item.GetProperty("expectedOutput").GetString()!;
            _fileGolden = item.GetProperty("expectedFilesSha256").GetString()!;
            Files = Directory.EnumerateFiles(directory, "Lokad.*.dll").Order().ToDictionary(p => Path.GetFileName(p),
                p => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))));
        }
        catch { Dispose(); throw; }
    }

    private long Balance => (long)_balance.GetValue(_budget)!;
    public void FreezeBalance() => _expected = Balance;
    public void Once()
    {
        _reset.Invoke(_host, null);
        using (var result = (IDisposable)_run.Invoke(_script, [_host])!)
        {
            RequireSuccess(result);
            if ((string)result.GetType().GetProperty("StandardOutput")!.GetValue(result)! != _stdout ||
                (string)result.GetType().GetProperty("StandardError")!.GetValue(result)! != "")
                throw new InvalidDataException("Complete output golden failed.");
            if ((string)_digest.Invoke(null, [_outputs.Invoke(_host, null)])! != _fileGolden)
                throw new InvalidDataException("Complete file golden failed.");
        }
        if (_expected >= 0 && Balance != _expected) throw new InvalidDataException("Execution ownership did not end.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try
        {
            (_script as IDisposable)?.Dispose();
            if (Balance != 0) throw new InvalidDataException("Compiled owner did not end.");
        }
        finally
        {
            _validate.Invoke(null, [_owned]);
            if (Directory.Exists(_owned)) Directory.Delete(_owned, recursive: true);
        }
    }
    private static void RequireValid(object script)
    {
        if (!(bool)script.GetType().GetProperty("IsValid")!.GetValue(script)!) throw new InvalidDataException("Invalid control program.");
    }
    private static void RequireSuccess(object result)
    {
        if (!(bool)result.GetType().GetProperty("Success")!.GetValue(result)!) throw new InvalidDataException("Control invocation failed.");
    }
}

sealed class ImageContext(string directory, string name) : AssemblyLoadContext(name, isCollectible: false)
{
    protected override Assembly? Load(AssemblyName name)
    {
        if (name.Name is "System" or "netstandard" || name.Name!.StartsWith("System.", StringComparison.Ordinal)) return null;
        var path = Path.Combine(directory, name.Name + ".dll");
        return File.Exists(path) ? LoadFromAssemblyPath(path) : null;
    }
}
