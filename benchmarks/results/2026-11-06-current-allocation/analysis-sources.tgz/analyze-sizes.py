from pathlib import Path
import hashlib,json,os,subprocess,tarfile
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/current-allocation-r12'
r=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((root/'raw-capture.tgz').read_bytes()).hexdigest()==r['archiveSHA256']
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
reader=root/'reader/bin/Release/net11.0/Diagnostics.dll'
for case in ['text-warm','csv-warm']:
 record=json.loads((root/f'retrieved/observations/{case}/record.json').read_text(encoding='utf-8'))
 trace=root/f'retrieved/eventpipe/{case}/profile.nettrace'
 for tid in record['guestTids']:
  data=dict(record,guestTid=tid);derived=root/f'{case}-{tid}-reader-record.json';derived.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
  output=root/f'{case}-{tid}-allocation-origins-sizes.json'
  with (root/f'{case}-{tid}-reader-sizes.log').open('w',encoding='utf-8') as log:r=subprocess.run([env['DOTNET_HOST_PATH'],str(reader),str(trace),str(derived),str(output)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  print(case,tid,r.returncode,flush=True)
  if r.returncode:print((root/f'{case}-{tid}-reader-sizes.log').read_text(encoding='utf-8')[-9000:]);raise SystemExit(r.returncode)
  v=json.loads(output.read_text(encoding='utf-8'));print('ticks',v['ticks'],'top',[(x['type'],x['approximateBytes']) for x in v['allocations'][:8]],flush=True)
