from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / 'comparison'
quiet = pair / 'quiet'
out = repo / 'benchmarks/results/2026-11-28-direct-member-return-lookup'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


identity = read(pair / 'identity.json')
roles = ('reference', 'candidate')
for role in roles:
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == identity['imageFiles'][role]
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
facts = [lab / f'{role}-member-facts.json' for role in roles]
assert digest(facts[0]) == digest(facts[1])
queries = read(facts[0])
assert queries['total'] == 52608 and queries['foundCount'] == 450 and queries['unknownCount'] == 46
logs = ['windows-public-net10.0.log', 'windows-public-net11.0.log', 'ubuntu-public-net11.0.log']
assert all('Passed:   304' in (lab / name).read_text(encoding='utf-8') for name in logs)

allocation = read(lab / 'allocation.json')
assert allocation['verifiedCompilations'] == 42
assert [row['allocated'][0] - row['allocated'][1] for row in allocation['summary']] == [22192, 22192, 0]
assert all(row['admitted'][0] == row['admitted'][1] and row['after'] == [0, 0] for row in allocation['summary'])
assert read(lab / 'cold-summary.json')['verifiedInvocations'] == 48
traces = read(lab / 'compile-traces.json')
for role in roles:
    assert digest(lab / f'compile-{role}.nettrace') == traces[role]['sha256']
    assert traces[role]['allocationAndAdmission']['after'] == 0
    assert read(pair / f'{role}-verify.json')['caseCount'] == 4
removed = {'CreateMemberReturnShapes', 'CreateCoreMemberReturnContracts', 'CreateExtendedMemberReturnContracts'}
assert removed <= {entry['Method'] for entry in traces['reference']['memberReturnMethods']}
assert removed.isdisjoint({entry['Method'] for entry in traces['candidate']['memberReturnMethods']})
summary = read(pair / 'summary.json')
assert summary['verifiedTimedBatches'] == 140 and summary['candidatePatchSHA256'] == identity['sourcePatchSHA256']
receipt = read(pair / 'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(pair / 'observations.tar.xz')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
quiet_summary = read(quiet / 'summary.json')
assert quiet_summary['verifiedTimedBatches'] == 112 and quiet_summary['quietGates']
assert quiet_summary['candidatePatchSHA256'] == identity['sourcePatchSHA256']
terminal = read(quiet / 'terminal-status.json')
assert terminal['exitCode'] == '0' and not terminal['live'] and not terminal['fixtures']
assert terminal['receipt']['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
assert all(terminal['receipt'][key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))

local_files = ['candidate.patch', 'prepare.py', 'create-direct-lookup.py', 'old-keys.json', 'reference-member-facts.json',
    'probe/Program.cs', 'probe/ModuleProbe.csproj', 'measure-allocations.py', 'trace-compile-only.py',
    'compile-reference.nettrace', 'compile-candidate.nettrace', 'cold-observations.json', 'collect-cold.py',
    'summarize-warm.py', 'warm-collection-retry.log', 'windows-build.log', 'ubuntu-build.log', 'ubuntu-build-retry.log',
    *logs, 'first-warm-setup/warm-collection.log', 'first-warm-setup/exit-code.txt',
    'first-warm-setup/reference-verify.json', 'first-warm-setup/candidate-verify.json', 'prepare-quiet.py', 'quiet-vm.py',
    'summarize-quiet.py', 'migrate-dictionary.py', 'migrate-literal.py', 'dictionary-vm-storage-migration.json',
    'literal-vm-storage-migration.json', 'publish.py']
procedures = {name: lab / name for name in local_files}
procedures.update({name: pair / name for name in ('reference-verify.json', 'candidate-verify.json', 'archive-receipt.json', 'exit-code.txt')})
for name in ('launch.log', 'upload.json', 'stage-custody.json', 'reference-remote-verify.json', 'candidate-remote-verify.json', 'archive-receipt.json'):
    procedures[f'quiet/{name}'] = quiet / name
assert all(path.is_file() for path in procedures.values())
out.mkdir(exist_ok=True)
for name in ('allocation.json', 'compile-traces.json', 'cold-summary.json'):
    copy2(lab / name, out / name)
    assert digest(lab / name) == digest(out / name)
for name in ('identity.json', 'summary.json', 'observations.tar.xz'):
    copy2(pair / name, out / name)
    assert digest(pair / name) == digest(out / name)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    copy2(quiet / name, out / f'quiet-{name}')
    assert digest(quiet / name) == digest(out / f'quiet-{name}')
write(out / 'validation.json', dict(lookup={key: queries[key] for key in ('total', 'foundCount', 'unknownCount')},
    lookupHashes={role: digest(path) for role, path in zip(roles, facts, strict=True)}, focusedChecksPerTarget=304,
    targets=['Windows net10.0', 'Windows net11.0', 'Ubuntu WSL net11.0'], independentGoldensPerImage=4,
    collector=receipt, quietCollector=terminal['receipt']))
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified both worker images, lookup and platform checks, goldens, and 140 local and 112 quiet timed batches.')
