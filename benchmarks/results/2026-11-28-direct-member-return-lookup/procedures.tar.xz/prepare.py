from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
old = lab.parent / 'owner-type-new-slots-b1990-20261128'
donor = lab.parent / 'landed-runtime-cpython-b1994-20261128/comparison/quiet'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def image(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')


def git(*args):
    return check_output(['git', *args], cwd=repo)


identity = json.loads((donor / 'identity.json').read_bytes())
revision = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--name-only', identity['sourceRevision'], revision, '--', 'src', 'tests')
assert image(donor / 'local-image') == identity['imageFiles']['candidate']
for role in ('reference', 'candidate'):
    if not (pair / role).exists():
        copytree(donor / 'local-image', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
images = {role: image(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == identity['imageFiles']['candidate']
assert len(images['reference']) == len(images['candidate']) == 32
assert {name for name, sha in images['reference'].items() if images['candidate'][name] != sha} == {'Lokad.Lython.dll'}
assert not build.samefile(pair / 'candidate/Lokad.Lython.dll')

patch = git('diff', '--binary', 'HEAD', '--', 'src', 'tests')
assert patch.count(b'diff --git ') == 5
(lab / 'candidate.patch').write_bytes(patch)
catalogs = ('representative.json', 'jobs.json', 'config.json', 'xml.json', 'generated.json')
for name in (*catalogs, 'collect.py', 'run.sh', 'cpython-worker.py'):
    copy2(old / 'comparison' / name, pair / name)
assert b'\r' not in (pair / 'run.sh').read_bytes()
write(pair / 'identity.json', json.dumps(dict(sourceRevision=revision, referenceRuntimeRevision=identity['sourceRevision'],
    sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={role + suffix: hashes['Lokad.Lython.dll'] for role, hashes in images.items() for suffix in ('', '-control')},
    cpythonWorkerSHA256=digest(pair / 'cpython-worker.py'), expectedCPythonSHA256=identity['expectedCPythonSHA256'],
    purpose='Remove fallback member-return table construction from frontend lookup.',
    catalogs={name: {'sha256': digest(pair / name)} for name in catalogs}), indent=2) + '\n')

for name in ('collect-cold.py', 'measure-allocations.py', 'summarize-warm.py'):
    write(lab / name, (old / name).read_text(encoding='utf-8').replace(old.name, lab.name))

probe = lab / 'probe'
probe.mkdir(exist_ok=True)
copy2(old / 'probe/ModuleProbe.csproj', probe / 'ModuleProbe.csproj')
content = (old / 'probe/Program.cs').read_text(encoding='utf-8')
anchor = 'var contracts = assembly.GetType("Lokad.Lython.Frontend.StaticContracts", throwOnError: true)!;\n'
assert content.count(anchor) == 1
write(probe / 'Program.cs', content.replace(anchor, anchor + '''if (args[1] == "--member-facts")
{
    var kindType = assembly.GetType("Lokad.Lython.Frontend.AbstractValueKind", throwOnError: true)!;
    var lookupMember = contracts.GetMethod("TryGetMemberReturnShape", BindingFlags.NonPublic | BindingFlags.Static)!;
    var oldKeys = JsonSerializer.Deserialize<string[]>(File.ReadAllBytes(args[2]))!;
    var names = oldKeys.Concat(oldKeys.Select(static name => name.ToUpperInvariant()))
        .Concat(["", "__absent_member__", "café", "𐐀"])
        .Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray();
    var results = new List<string>();
    var foundCount = 0;
    var unknownCount = 0;
    foreach (var kind in Enum.GetValues(kindType))
    foreach (var name in names)
    {
        object?[] query = [kind, name, null];
        var found = (bool)lookupMember.Invoke(null, query)!;
        foundCount += found ? 1 : 0;
        unknownCount += found && query[2]?.ToString() == "Unknown" ? 1 : 0;
        results.Add($"{kind}/{name}/{found}/{query[2]}");
    }
    Console.WriteLine(JsonSerializer.Serialize(new { total = results.Count, foundCount, unknownCount, results }));
    return;
}
'''))
