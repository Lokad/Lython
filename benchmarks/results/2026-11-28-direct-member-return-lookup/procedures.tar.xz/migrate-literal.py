from hashlib import sha256
import gzip
import json
from pathlib import Path
import shlex
from subprocess import check_output


lab = Path(__file__).resolve().parent
old = lab.parent / 'shared-literal-decoding-20261124/comparison/quiet'
base = '/home/lokad/lython-bench-checks'
status = json.loads((old / 'terminal-status.json').read_bytes())
receipt = status['receipt']
assert not status['live'] and str(status['exitCode']) == '0' and not status['fixtures']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert sha256((old / 'observations.tar.xz').read_bytes()).hexdigest() == receipt['archiveSHA256']
root = json.loads((old / 'upload.json').read_bytes())['root']
identity = json.loads((old / 'identity.json').read_bytes())
role = 'candidate'
core_hash = identity['imageFiles'][role]['Lokad.Lython.dll']
remote_path = f'{base}/{root}/{role}/Lokad.Lython.dll'
ssh = ['ssh', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'ConnectTimeout=12', '-o', 'StrictHostKeyChecking=yes',
       'lokad@20.166.121.73']
packed = old / f'migrated-{role}-core.dll.gz'
if not packed.exists():
    content = check_output([*ssh, 'cat -- ' + shlex.quote(remote_path)], timeout=40)
    assert sha256(content).hexdigest() == core_hash
    with packed.open('xb') as output:
        output.write(gzip.compress(content, mtime=0))
assert sha256(gzip.decompress(packed.read_bytes())).hexdigest() == core_hash
configuration = dict(base=base, root=root, role=role, unit='lython-b1638-shared-literal-decoding-20261124',
    archive=receipt['archiveSHA256'], core=core_hash, packed=sha256(packed.read_bytes()).hexdigest())
remote = f'cfg={configuration!r}\n' + r'''
from hashlib import sha256
from pathlib import Path
import fcntl, json, shutil, subprocess

base = Path(cfg['base'])
root = base / cfg['root']
core = root / cfg['role'] / 'Lokad.Lython.dll'
assert base.resolve() == base and root.resolve() == root and core.resolve() == core and root.parent == base
def digest(path): return sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    state = subprocess.run(['systemctl','is-active',cfg['unit']+'.service'], capture_output=True, text=True).stdout.strip()
    assert state == 'inactive' and not (root/'guest-fixtures').exists()
    assert (root/'exit-code.txt').read_text().strip() == '0'
    assert digest(root/'observations.tar.xz') == cfg['archive']
    assert digest(core) == cfg['core'] and core.stat().st_nlink == 1
    record = dict(completedImage=cfg['root'], role=cfg['role'], coreSHA256=cfg['core'], packedSHA256=cfg['packed'],
                  migratedBytes=core.stat().st_size, freeBefore=shutil.disk_usage(base).free)
    with (root/(cfg['role']+'-core-migration.json')).open('x', encoding='utf-8') as report:
        json.dump(record, report, indent=2)
    core.unlink()
    record['freeAfter'] = shutil.disk_usage(base).free
    print(json.dumps(record), flush=True)
'''
compile(remote, '<migrate one completed immutable image>', 'exec')
result = check_output([*ssh, 'python3 -c ' + shlex.quote(remote)], timeout=30)
(lab / 'literal-vm-storage-migration.json').write_bytes(result)
print(result.decode('utf-8'))
