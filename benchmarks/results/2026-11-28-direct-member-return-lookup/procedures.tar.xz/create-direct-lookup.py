from collections import defaultdict
import json
from pathlib import Path
import re

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
frontend = repo / 'src/Lokad.Lython/Frontend'
old_paths = [frontend / f'StaticContracts.MemberReturns.{name}.cs' for name in ('Core', 'Extended')]
row_pattern = r'new\(AbstractValueKind\.(\w+), ("[^"\n]+"), StaticReturnShape\.(\w+)\)'
rows = [match.groups() for path in old_paths for match in re.finditer(row_pattern, path.read_text(encoding='utf-8'))]
assert len(rows) == len({row[:2] for row in rows}) == 406
by_kind = defaultdict(dict)
for kind, name, shape in rows:
    by_kind[kind][name] = shape


def write(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')


def get_method(kind):
    return f'Get{kind}MemberReturn'


def shape_expression(member_shapes, indent):
    by_shape = defaultdict(list)
    for name, shape in member_shapes.items():
        by_shape[shape].append(name)
    for shape, names in by_shape.items():
        pattern = ' or '.join(names)
        result = f' => StaticReturnShape.{shape},'
        if indent + len(pattern) + len(result) <= 116:
            yield ' ' * indent + pattern + result
            continue
        line = ' ' * indent + names[0]
        for name in names[1:]:
            if len(line) + len(name) + 4 > 105:
                yield line + ' or'
                line = ' ' * (indent + 4) + name
            else:
                line += ' or ' + name
        yield line
        yield ' ' * (indent + 4) + result.lstrip()


write(lab / 'old-keys.json', json.dumps(sorted({name[1:-1] for _, name, _ in rows}), indent=2) + '\n')
catalog = [
    'namespace Lokad.Lython.Frontend;', '', 'internal static partial class StaticContracts', '{',
    '    private static StaticReturnShape? LookupFallbackMemberReturn(AbstractValueKind kind, string name) => kind switch',
    '    {',
]
for kind, shape_by_name in sorted(by_kind.items()):
    if len(shape_by_name) == 1:
        (name, shape), = shape_by_name.items()
        catalog.append(f'        AbstractValueKind.{kind} when name == {name} => StaticReturnShape.{shape},')
    else:
        catalog.append(f'        AbstractValueKind.{kind} => {get_method(kind)}(name),')
catalog.extend(['        _ => null,', '    };'])
for kind, shape_by_name in sorted(by_kind.items()):
    if len(shape_by_name) == 1:
        continue
    catalog.extend(['', f'    private static StaticReturnShape? {get_method(kind)}(string name) => name switch', '    {'])
    catalog.extend(shape_expression(shape_by_name, 8))
    catalog.extend(['        _ => null,', '    };'])
catalog.extend(['}', ''])
write(frontend / 'StaticContracts.MemberReturns.Lookup.cs', '\n'.join(catalog))
