from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('current-text-helper-cpu-20261124')
donor = lab.with_name('direct-match-expand-20261124')
comparison = donor/'comparison'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, source):
    (lab/name).write_text(source,encoding='utf-8',newline='\n')


def save(name, data):
    write(name,json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def adapt(name, edits):
    source=(prior/name).read_text(encoding='utf-8')
    for old,new in edits:
        assert source.count(old)==1,(name,old)
        source=source.replace(old,new)
    compile(source,name,'exec')
    write(name,source)


identity = read(comparison/'identity.json')
runtime = identity['candidate']
assert runtime.startswith('83ae1e2fa')
subprocess.run(['git','diff','--exit-code',runtime,'HEAD','--','src','tests'],cwd=repo,check=True)
raw = comparison/'quiet'
receipt = read(raw/'terminal-status.json')['receipt']
assert all(receipt[k] for k in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved'))
assert digest(raw/'observations.tar.xz') == receipt['archiveSHA256']
files = identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(donor/'candidate'/name)==checksum for name,checksum in files.items())
archive = repo/'benchmarks/results/2026-11-24-typed-csv-text/observations.tar.xz'
with tarfile.open(archive) as frozen:
    catalog = json.load(frozen.extractfile('representative.json'))
jobs = [
    ('explicit-warm','scripts.csv-meter-report.explicit-float','warm'),
    ('typed-warm','scripts.csv-meter-report.typed-unicode','warm'),
    ('observer-warm','scripts.csv-meter-report.typed-unicode.observed','warm'),
]
cases = {case['id']:case for case in catalog['cases']}
catalog['cases'] = [cases[case_id] for _,case_id,_ in jobs]
save('catalog.json',catalog)
identity=dict(sourceRevision=runtime, candidate=runtime, purpose='B1559 attribute current short tuple construction and numeric transport in CSV scripts',
    imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']},
    cpythonWorkerSHA256=identity['cpythonWorkerSHA256'], donorArchiveSHA256=receipt['archiveSHA256'],
    profileCatalogSHA256=digest(lab/'catalog.json'), comparedCatalogArchiveSHA256=digest(archive),
    productionSource=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip())
save('identity.json',identity)
adapt('collect.py',(
    ('json-encoding-flags-b1553-20261124/candidate','direct-match-expand-b1558-20261124/candidate'),
    ('b1556-fixtures','b1559-fixtures'),
))
adapt('quiet.py',(
    ('current-text-helper-cpu-b1556-20261124','current-meter-tuple-cpu-b1559-20261124'),
    ('lython-b1556-current-text-helper-cpu-20261124','lython-b1559-current-meter-tuple-cpu-20261124'),
    ('json-encoding-flags-20261124/candidate','direct-match-expand-20261124/candidate'),
    ('the three short text source shapes','the explicit and typed meters and the typed observer'),
))
adapt('ops-profile.py',(
    ("[('nonlocal-warm', 'diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('width-in-caller-warm', 'diagnostic.text-summary.computed-width-in-caller', 'warm'), ('inline-warm', 'diagnostic.text-summary.without-per-line-helper', 'warm')]",repr(jobs)),
))
adapt('analyze.py',(
    ("['nonlocal-warm', 'width-in-caller-warm', 'inline-warm']",repr([job[0] for job in jobs])),
    ("     'entry and operand movement':",'''     'tuple construction': ('PyTuple::FromSlots','EstimateObjectSlotStorage','BuildTuple','CreateAdmittedDefaultStorage'),
     'sequence reads and scalar access': ('PyTuple::get_Item','TryReadStoredSlot','ReadValueSlot','TryExecuteSequenceIndex','TryReadInteger','TryConsumeNumeric','PublishSharedInteger','ExecutableSlot::get_Object','PyIndexing::'),
     'CSV field and record handling': ('Csv','RowField','CSV','AppendField','FinishLiteralFields','FloatNonnumeric'),
     'entry and operand movement':'''),
))
shutil.copyfile(prior/'run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()
