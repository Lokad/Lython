from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
cases=json.loads((lab/'probe-cases.json').read_text(encoding='utf-8'))
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probe=lab.parent/'format-continuation-scratch/probe/candidate'
pair=load(lab/'quiet/identity.json')
body=json.dumps(list(cases.values())).encode('utf-8')
for role,files in pair['imageFiles'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {n:sha(source/n) for n in files}==files
    image=lab/'probe'/role
    shutil.copytree(probe,image,dirs_exist_ok=True)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    assert sha(image/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json','--compare-python','--python','C:/Python313/python.exe']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=55,env=env)
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
        assert process.returncode==0,(role,async_mode,process.stderr.decode(),process.stdout.decode())
        reports=[json.loads(line) for line in process.stdout.splitlines()]
        assert len(reports)==len(cases) and all(row['Matches'] and row['Compared'] for row in reports)
print(f'{len(cases)} CPython semantic probes pass in sync and async modes for both source images.')
