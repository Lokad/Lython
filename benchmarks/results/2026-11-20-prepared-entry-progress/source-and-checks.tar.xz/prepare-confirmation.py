import hashlib,json,shutil,tarfile
from pathlib import Path
lab=Path(__file__).resolve().parent
prev=lab/'quiet'
repeat=lab/'confirmation'
quiet=repeat/'quiet'
quiet.mkdir(parents=True)
def read(p):return p.read_text(encoding='utf8')
def load(p):return json.loads(read(p))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):
    if p.suffix=='.py':compile(s,str(p),'exec')
    p.write_text(s,encoding='utf8',newline='\n')
def save(p,obj):write(p,json.dumps(obj,indent=2)+'\n')
base=load(prev/'config.json')
archive=load(prev/'archive-receipt.json')
assert archive['complete'] and archive['archivedAndVerifiedUnderLease']
assert archive['archiveSHA256']==sha(prev/'observations.tgz')
assert archive['guestFixturesRemoved'] and archive['allWorkersJoined']
assert (load(prev/'identity.json')==base['identity']) and sha(prev/'representative.json')==base['catalogSHA256']
for role,files in base['identity']['imageFiles'].items():
    assert {name:sha(lab/'frozen'/role/name) for name in files}==files
    result=load(lab/f'{role}-comparison-verify.json')
    assert result['state']=='Completed' and result['catalogSha256']==base['catalogSHA256']
purpose='Resolve factory async and invoice control variation'
location='/home/lokad/lython-bench-checks/prepared-entry-confirmation-b1226-20261120'
unit='lython-b1226-prepared-entry-confirmation-20261120'
identity=dict(base['identity'],purpose=purpose)
save(quiet/'identity.json',identity)
for name in ('representative.json','cpython-worker.py'):shutil.copyfile(prev/name,quiet/name)
jobs=[('scripts.annotated-rule-closures.nested-factories','warm-async'),('scripts.csv-invoice.large','warm')]
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    text=read(prev/name).replace(base['root'],location).replace(base['unit'],unit).replace(base['identity']['purpose'],purpose)
    for old,new in [('len(jobs)==5','len(jobs)==2'),("['jobs']==5","['jobs']==2"),("len(raw['jobs'])==5","len(raw['jobs'])==2"),('jobs=5,','jobs=2,')]:text=text.replace(old,new)
    if name=='collect.py':
        i=text.index('\njobs = ');j=text.index('\nassert len(jobs)',i)
        text=text[:i]+'\njobs = '+repr(jobs)+text[j:]
        for old,new in [('accumulate 7 seconds','accumulate 12 seconds'),('warmupSeconds=7','warmupSeconds=12'),('min(warmed)<7','min(warmed)<12'),('warmed[i]>=7','warmed[i]>=12'),('targetBatchSeconds=.4','targetBatchSeconds=.8'),('rounds=5','rounds=7'),('counts[i]*.4','counts[i]*.8'),('range(5)','range(7)')]:text=text.replace(old,new)
    write(quiet/name,text)
assert b'\r' not in (quiet/'run.sh').read_bytes()
parts=['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh']
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as f:
    for name in parts:f.add(quiet/name,arcname=name)
config=dict(root=location,unit=unit,source=base['root'],sourceFiles=identity['imageFiles'],
    sourceCatalogSHA256=base['catalogSHA256'],protocolSHA256=base['protocolSHA256'],catalogSHA256=base['catalogSHA256'],identity=identity,
    retireGroups=[],donorArchiveSHA256=archive['archiveSHA256'],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/'config.json',config)
text=read(prev/'remote-launch.py')
i=text.index('\nc=')+1;j=text.index('\nb=Path(',i);text=text[:i]+'c='+repr(config)+text[j:]
needle=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
assert text.count(needle)==1
text=text.replace(needle," for role,files in c['sourceFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
text=text.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
text=text.replace('lython-b1225-fixtures','lython-b1226-fixtures')
assert 'sourceRole' not in text and '+64*1024*1024' in text
write(quiet/'remote-launch.py',text)
for n in ('launch-quiet.py','summarize-quiet.py'):
    text=read(lab/n).replace('seconds=237','seconds=179').replace('before 237','before 179').replace(base['identity']['purpose'],purpose).replace("len(raw['jobs'])==5","len(raw['jobs'])==2")
    write(repeat/n,text)
print('Both complete previously verified images and unchanged catalog staged for two confirmation lanes.')
