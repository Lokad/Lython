from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent/'b585'
for p in [*r.glob('*.py'),r/'run.sh']:
 t=p.read_text(encoding='utf-8');t=t.replace('lython-b585-current-phases-profile-20261111-20261111','lython-b585-current-phases-profile-20261111')
 t=t.replace("canonicalStorage='Pre-existing independently verified persistent local source.tar; exact path/bytes/SHA recorded in files'","canonicalStorage='Exact canonical committed Git evidence independently verified locally; exact path/bytes/SHA recorded in files'")
 if p.name!='remote-launch.py' and p.suffix=='.py':ast.parse(t)
 p.write_text(t,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for n in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:t.add(r/n,arcname=n)
c=json.loads((r/'config.json').read_text(encoding='utf-8'))
c.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest())
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
assert not(r/'inventory.json').exists()
print('Prelaunch unit names and canonical archive provenance corrected; no VM work yet.')
