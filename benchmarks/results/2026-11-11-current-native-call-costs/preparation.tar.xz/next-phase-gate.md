# Current source gate after R243

Retained6904093e, 2026-11-11. No new production prototype or timing attribution.
The six-script external checkpoint is owned by B584; no profile runs concurrently.

The call/frame consolidation already has a real completion milestone: R241 binds
the final compiler-sized storage for every function and deletes the second array,
copy and ArgumentsAreLocals selection. Actual presence during default/protocol
suspension remains meaningful. R243 removes the whole binding/work/VM phase for
proven captured helper sequences. Neither a renamed binding descriptor nor another
call arena/controller proves more work eliminated. The original slower designs
and R243's initial shared-parameter adversity remain lessons.

Current source candidates, not predicted speedups:

* Remaining general call/operand work: inspect current captured-text and keyword-
  default search CPU, after R243 changed that execution path. Distinguish full
  binding/work construction from useful native arithmetic, actual reads, host
  checks and final string creation. The existing profiling driver can capture two
  six-second CPU windows with actual loaded identities/maps. No old offsets or
  removable percentages may transfer. Stop this source selection after those two
  usable captures and a concrete displaced-work/lifetime inventory.
* Scalar publication: ordinary dictionary values stay boxed immutable BigInteger;
  retained aliases must never become a mutable counter. Native totals already use
  private machine arithmetic between required publication points. In the actual
  two-word fixtures, flushing two dictionary keys every line can erase a supposed
  box-saving opportunity. Do not introduce a shadow dictionary, per-object ledger
  or universal value conversion solely because boxing exists. Select a coherent
  representation change only if current evidence identifies that phase as material.
* Text/record construction: casing and JSON already target UTF-8 final storage;
  CSV owns/adopts rows and shares keys. Cased-word preflight scans before effects,
  then materializes fragments during private iteration. This is duplicate work,
  but replacing it with an unbounded worst-case charge or a heap range vector
  changes admission/allocation costs. Existing two-word input already fits inline.
  Preserve full pre-effect admission, Unicode expansion/sigma, final-word identity,
  retained keys, dynamic fallback and cancellation. A proposal must remove a whole
  scanner/materialization/transport phase, not add a two-word special case.
* Frontend: prepared lexical/binding facts are already shared. Separate compile
  medians remain required, but 40–70us compilation cannot explain a millisecond
  warm gap. Do not combine passes merely because there are several; preserve
  diagnostics, source locations, scopes, annotations/generators and executable
  imports. Investigate only a repeated traversal with demonstrated cost.

Any selected redesign must name the complete duplicated work/storage and code to
delete, representative scripts, semantic/cancellation/refusal/alias acceptance,
one bounded source pair with unchanged controls and separate compilation, and a
completion decision on regression debt. A temporary setback needs a defined
completion milestone. An inconclusive control is uncertainty, not permanent
closure; retain original failed conditions and use bounded justified correction.
No new abstraction/cache/option/backend is a deliverable by itself.

Regex development is independent. The core UTF-8/window/capture/current-token/
owner contract is implemented and validated with cooperating providers. The
existing immutable development producer and adapter-local bridge proof remain
usable. Only the three precisely recorded producer capabilities defer final
adapter qualification; do not rerun unchanged producer checks or reopen core
dependency edges. Publication remains postponed.
