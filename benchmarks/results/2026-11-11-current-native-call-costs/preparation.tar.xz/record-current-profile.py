from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path(__file__).parent;r=p/'b585'
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
with tarfile.open(r/'observations.tgz')as t:
 assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
rows={}
for name in ['text-warm','file-search']:
 q=r/'retrieved/profiles'/name;v=json.loads((q/'guest-cpu-leaves.json').read_text(encoding='utf-8'));record=json.loads((q/'record.json').read_text(encoding='utf-8'))
 assert record['exitCode']==0 and record['closed']['status']=='Closed' and not v['malformedMapLines']
 assert next(v['sha256']for v in record['identity']['libraries']if Path(v['path']).name=='Lokad.Lython.dll').lower()==identity['coreSHA256']['candidate']
 rows[name]=v
out=Path('benchmarks/results/2026-11-11-current-native-call-costs');out.mkdir(exist_ok=False)
for n in ['identity.json','source-identity.json','archive-receipt.json','observations.tgz','terminal-status.json','config.json','inventory.json','observe-not-before.json','launch.log']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for f in [*r.glob('*.py'),r/'run.sh',p/'prepare-current-profile.py',p/'fix-profile-unit.py',p/'add-profile-disk-proof.py',p/'record-current-profile.py',p/'next-phase-gate.md']:t.add(f,arcname=f.name)
assessment=dict(source='6904093e',core=identity['coreSHA256']['candidate'],profiles=rows,
 observation='Current captured1139leaves/5.74CPU seconds/65unknown; search872/4.42/48unknown. Guard/evaluator and per-call keyword/default binding remain visible after R243. Useful/inlined work overlaps; no removable percentage, elapsed pair or allocation attribution.',
 selected='Next bounded source gate: share compiler-known argument layout with existing native and owned destination binding. Reuse prepared immutable FunctionParameterLayout identity; live defaults stay runtime reads, dynamic/mismatched/protocol signatures keep general binder before effects. Eliminate repeated argument-form normalization/keyword-to-slot matching/presence discovery for proven calls. No runtime call cache, arena/controller/new dispatch or owner. Do not predict speedup.',
 acceptance='Known signature rebind/alias/decorator/different defaults, positional-only/named/receiver/order/duplicates/missing/default replacement, wider and variadic dynamic calls, true suspended defaults, cancellation/refusal and retained aliases. Shared storage/refunds unchanged. Compilation and whole search/CSV helper jobs plus ordinary/captured/report/JSON controls, both APIs. Stop source gate on inability to reuse stable facts without a broader framework; otherwise one complete prototype with focused correctness and bounded before/after before retention.',
 notSelected='No blind function descriptor merge, raw-word scratch or mutable dictionary counter wrapper. Full pre-effect type proof is still necessary; deleting it or observing only root types is unsound. Fresh profiles replace old-offset assumptions, not original evidence.',
 limits='File-search actual guest CPU4.42seconds is less than6s collection due to host/reset/protocol/validation work on other threads; retain all thread data. Perf/JIT diagnostic overrides, normal GC, same-process maps/listings; no ordinary benchmark clock or CPython comparison. Both quiet gates and archive/join/RAM cleanup pass. Terminal cached, no VM users remain. Only exact canonical-verified B577/B582 raw duplicate archives retired after fresh path/UID/inode/all-alias proofs; cores and original data retained.')
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
manifest={f.relative_to(out).as_posix():dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in out.rglob('*')if f.is_file()}
(out/'archive-identity.json').write_text(json.dumps(dict(files=manifest,allIdentitiesVerified=True,allUsersJoined=True),indent=2)+'\n',encoding='utf-8')
print('Current native call costs and exact code/maps/unknowns archived; selected source gate has no timing or removableCPU claim.')
