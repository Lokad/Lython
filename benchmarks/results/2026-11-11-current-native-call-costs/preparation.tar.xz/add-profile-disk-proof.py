from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent/'b585';p=r/'config.json'
c=json.loads(p.read_text(encoding='utf-8'));assert not(r/'inventory.json').exists()
canonical=Path('benchmarks/results/2026-11-11-native-loops-cpython-checkpoint/observations.tgz')
b=canonical.read_bytes();assert b==subprocess.run(['git','show','HEAD:'+canonical.as_posix()],capture_output=True,check=True).stdout
c['retire'].append(dict(kind='exact',knownPath='native-loops-cpython-b577-20261111/observations.tgz',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=canonical.as_posix(),canonicalCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reason='Terminal historical external-checkpoint duplicate; exact committed canonical Git bytes verified. Keep every original result and protected source cores. Fresh path/UID/inode/all-alias proof required.'))
p.write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
print('Added exact committed B577 duplicate-archive proof; no VM mutations. New inventory required.')
