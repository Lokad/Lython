from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
p=Path(__file__).parent; q=p/'b585';q.mkdir(exist_ok=False)
old=p.parent/'call-preparation-r242/b582'
name='current-phases-profile-b585-20261111';unit='lython-b585-current-phases-profile-20261111'
def replace(t):
 return t.replace('call-preparation-profile-b582-20261111',name).replace('call-preparation-profile-b582',name.removesuffix('-20261111')).replace('lython-b582-call-preparation-profile-20261111',unit).replace('lython-b582-call-preparation-profile',unit).replace('lython-b582-fixtures','lython-b585-fixtures')
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
identity=json.loads((p/'b584/identity.json').read_text(encoding='utf-8'))
identity['coreSHA256'].pop('candidate-control')
identity['sourceRevision']='Retained6904093e exact frozen ccdd source; two6s current-phase CPU captures for captured text and keyword-default file search. Profiles select remaining full phase after R243; no source-pair timing, allocation attribution or removable-CPU forecast. Full43058223560 tracked separately.'
(q/'catalog.json').write_bytes((p/'b584/representative.json').read_bytes())
(q/'source-identity.json').write_bytes((p/'b584/source-identity.json').read_bytes())
identity['catalogSHA256']=sha(q/'catalog.json')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','launch.py','retrieve-original.py','remote-launch.py']:
 t=replace((old/n).read_text(encoding='utf-8'))
 t=t.replace('text-ordinary','file-search').replace('scripts.text-summary-helpers.large','scripts.file-search.large')
 t=t.replace('else 2048 if "config" in name else 64','else 1024 if "search" in name else 64')
 t=t.replace('source=base/\'mirrored-storage-b581-20261111/candidate\'','source=base/\'captured-sequence-b583-20261111/candidate\'')
 if n=='ops-profile.py':t=t.replace('env["DOTNET_JitDisasm"]="TryExecuteDictionaryLoop"','env["DOTNET_JitDisasm"]="TryExecuteDictionaryLoop EvaluateNativeReturn GuardNativeReturn"')
 if n.endswith('.py')and n!='remote-launch.py':ast.parse(t)
 (q/n).write_text(t,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['catalog.json','identity.json','source-identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
canonical=Path('benchmarks/results/2026-11-11-current-call-costs/observations.tgz')
data=canonical.read_bytes();assert data==subprocess.run(['git','show','HEAD:'+canonical.as_posix()],capture_output=True,check=True).stdout
retire=[dict(kind='exact',knownPath='call-preparation-profile-b582-20261111/observations.tgz',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalStorage=canonical.as_posix(),canonicalCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reason='Historical terminal raw profile duplicate, exact committed Git evidence verified; current cores/maps remain. Fresh absolute path/UID/inode/all-alias proof required.')]
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
print('Two6s profiles prepared; no VM interaction until B584 terminal/cached. Need new fresh lease/disk proof before launch.')
