from datetime import datetime, timedelta, timezone
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
quiet = lab/'comparison/quiet'
failure = lab/'first-launch'
failure.mkdir(exist_ok=True)
for name in ('terminal-status.json','identity.json','launch.log','upload.json','observe-not-before'):
    shutil.copyfile(quiet/name,failure/name)
shutil.copyfile(lab/'quiet.py',failure/'quiet.py')
status=json.loads((failure/'terminal-status.json').read_text(encoding='utf-8'))
assert not status['live'] and not status['fixtures'] and status['receipt'] is None and status['exitCode']=='1'
assert "KeyError: 'frozenImage'" in status['journal']

path=quiet/'identity.json'
before=hashlib.sha256(path.read_bytes()).hexdigest()
identity=json.loads(path.read_text(encoding='utf-8'))
identity['frozenImage']='/home/lokad/lython-bench-checks/short-path-cpython-b1750-20261126/candidate'
identity['auxiliaryFiles']={name:sha for name,sha in identity['imageFiles']['candidate'].items()
                            if name!='Lokad.Lython.dll'}
tree=ast.parse((quiet/'collect.py').read_text(encoding='utf-8'))
required={node.slice.value for node in ast.walk(tree) if isinstance(node,ast.Subscript)
          and isinstance(node.value,ast.Name) and node.value.id=='identity' and isinstance(node.slice,ast.Constant)}
assert required<=identity.keys(),required-identity.keys()
data=json.dumps(identity,ensure_ascii=False,indent=2)+'\n'
unit='lython-b1750b-short-path-cpython-20261126'
configuration={'before':before,'identity':data,'unit':unit}
remote='cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,json,subprocess
base=Path.home()/'lython-bench-checks'
root=base/'short-path-cpython-b1750-20261126'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.resolve()==root and root.is_dir()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 old=subprocess.run(['systemctl','show','lython-b1750-short-path-cpython-20261126.service',
  '--property=ActiveState,MainPID,ExecMainStatus'],check=True,capture_output=True,text=True).stdout
 assert 'ActiveState=failed' in old and 'MainPID=0' in old and 'ExecMainStatus=1' in old
 assert not any((root/name).exists() for name in ('guest-fixtures','confirmation','archive-receipt.json'))
 assert (root/'exit-code.txt').read_text().strip()=='1'
 identity=json.loads(cfg['identity'])
 bootstrap=root/'identity.json'
 assert sha(bootstrap)==cfg['before']
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==identity['expectedCPythonSHA256']
 frozen=Path(identity['frozenImage'])
 files=identity['imageFiles']['candidate']
 assert frozen==root/'candidate' and frozen.resolve()==frozen
 assert len(files)==32 and {p.name:sha(p) for p in frozen.iterdir()}==files
 for name,details in identity['catalogs'].items(): assert sha(root/name)==details['sha256']
 assert sha(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 aborted=root/'aborted-before-fixtures'
 assert not aborted.exists()
 aborted.mkdir()
 for name in ('exit-code.txt','identity.json'):
  (root/name).rename(aborted/name)
 bootstrap.write_text(cfg['identity'],encoding='utf-8')
subprocess.run(['sudo','-n','systemd-run','--unit='+cfg['unit'],'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=290','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
subprocess.run(['ssh','-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12',
                os.environ['LYTHON_BENCH_HOST'],'python3 -'],input=remote,encoding='utf-8',check=True,timeout=40)
path.write_text(data,encoding='utf-8',newline='\n')
retrieve=(failure/'quiet.py').read_text(encoding='utf-8').replace('lython-b1750-short-path-cpython-20261126',unit)
(lab/'quiet.py').write_text(retrieve,encoding='utf-8',newline='\n')
(quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=225)).isoformat(),encoding='utf-8')
(quiet/'terminal-status.json').rename(failure/'initial-terminal-copy.json')
