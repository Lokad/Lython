from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
prior = lab.parent / 'file-processing-cpython-20261126'
zip_trial = lab.parent / 'direct-zip-starmap-20261126'
regex_trial = lab.parent / 'regex-analysis-route-20261126'
prior_quiet = prior / 'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)

def write(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')

def save(path, data):
    write(path, json.dumps(data, ensure_ascii=False, indent=2) + '\n')

head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('0a0e32c16') and not git('status', '--porcelain', '--', 'src', 'Directory.Build.props')
assert git('diff', '--binary', 'eee178f71', head, '--', 'src') == (regex_trial / 'candidate.patch').read_bytes()
donor = read(zip_trial / 'comparison/quiet/identity.json')['imageFiles']['candidate']
assert len(donor) == 32 and {p.name: sha(p) for p in (zip_trial / 'candidate').iterdir()} == donor
donor_receipt = read(zip_trial / 'comparison/quiet/terminal-status.json')['receipt']
assert donor_receipt['complete'] and sha(zip_trial / 'comparison/quiet/observations.tar.xz') == donor_receipt['archiveSHA256']

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
with (lab / 'build.log').open('wb') as log:
    subprocess.run([dotnet, 'build', 'src/Lokad.Lython/Lokad.Lython.csproj', '-c', 'Release', '-f', 'net11.0',
                    '--no-incremental', '--artifacts-path', lab/'core-build'], cwd=repo, env=env, stdout=log,
                   stderr=subprocess.STDOUT, check=True, timeout=180)
assert head == git('rev-parse', 'HEAD').decode().strip() and not git('status', '--porcelain', '--', 'src', 'Directory.Build.props')
core = lab / 'core-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
files = donor | {core.name: sha(core)}
assert files[core.name] != donor[core.name]
image = lab / 'candidate'
image.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(core if name == core.name else zip_trial/'candidate'/name, image/name)
assert {p.name: sha(p) for p in image.iterdir()} == files

catalog = read(zip_trial / 'comparison/quiet/representative.json')
starmap = next(row for row in catalog['cases'] if row['id'] == 'diagnostic.shipment-bound-starmap')
search, = read(prior / 'file-search-confirmation/comparison/quiet/representative.json')['cases']
regex, = read(regex_trial / 'generated-trace-catalog.json')['cases']
digest_text = lambda text: hashlib.sha256(text.encode('utf-8')).hexdigest()
fixture = '{"size":48,"text":null}'
regex |= dict(family='scripts', category='whole-script', scale='large', size=48, fixtureJson=fixture,
              sourceUtf8Bytes=len(regex['source'].encode('utf-8')), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
              expectedOutputUtf8Bytes=len(regex['expectedOutput'].encode('utf-8')),
              sourceSha256=digest_text(regex['source']), fixtureSha256=digest_text(fixture),
              expectedOutputSha256=digest_text(regex['expectedOutput']))
catalog['cases'] = [starmap, search, regex]
jobs = [(starmap['id'], 'warm-async'), (search['id'], 'compile-run'), (regex['id'], 'compile'),
        (search['id'], 'warm'), (regex['id'], 'compile-run')]
save(quiet/'representative.json', catalog)
save(quiet/'jobs.json', jobs)
template = read(prior_quiet/'identity.json')
identity = {key: template[key] for key in ('cpythonWorkerSHA256', 'expectedCPythonSHA256')}
identity |= dict(sourceRevision=head, productionSource=head, candidate=head,
                 imageFiles={'candidate':files}, coreSHA256={role:files[core.name] for role in ('candidate','candidate-control')},
                 donorFiles=donor, donorArchiveSHA256=donor_receipt['archiveSHA256'],
                 catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
                 purpose='Protected file search, bound shipment and literal regex analysis against CPython.')
save(quiet/'identity.json', identity)
for name in ('collect.py', 'summarize.py', 'run.sh'):
    body = (prior_quiet/name).read_text(encoding='utf-8').replace('lython-b1744-fixtures','lython-b1750-fixtures')
    body = body.replace('Current file-processing checkpoint against CPython', identity['purpose'])
    if name.endswith('.py'):
        compile(body, name, 'exec')
    write(quiet/name, body)
assert b'\r' not in (quiet/'run.sh').read_bytes()
worker = repo/'benchmarks/cpython-worker.py'
assert sha(worker) == identity['cpythonWorkerSHA256']
shutil.copyfile(worker, quiet/worker.name)
verified = quiet/'candidate-verify.json'
subprocess.run([dotnet, image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
                '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',verified],
               cwd=repo, env=env, check=True, timeout=75)
proof = read(verified)
assert proof['state'] == 'Completed' and proof['caseCount'] == 3
assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
assert proof['launched']['library']['sha256'] == files[core.name]
payload = quiet/'stage.tar.gz'
with tarfile.open(payload, 'w:gz', compresslevel=6) as archive:
    for name in ('identity.json', 'jobs.json', 'representative.json', 'collect.py', 'run.sh', worker.name):
        archive.add(quiet/name, arcname=name, recursive=False)
    archive.add(core, arcname='core.dll', recursive=False)
save(quiet/'upload.json', dict(root='short-path-cpython-b1750-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))

source = (prior/'quiet.py').read_text(encoding='utf-8-sig')
source = source.replace('lython-b1744-file-processing-cpython-20261126','lython-b1750-short-path-cpython-20261126')
source = source.replace('len(frames)==6 and len(set(f.name for f in frames))==6',
                        'len(frames)==7 and len(set(f.name for f in frames))==7')
start = source.index(" donor=base/'native-cursor-stack-b1743-20261126'")
end = source.index(' for name,metadata in image', start)
source = source[:start] + ''' donor=base/'direct-zip-starmap-b1749-20261126'
 receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==image['donorArchiveSHA256']
 assert sha(donor/'observations.tar.xz')==receipt['archiveSHA256']
 origin=donor/'candidate'
 assert origin.resolve()==origin and {p.name:sha(p) for p in origin.iterdir()}==image['donorFiles']
 frozen=root/'candidate'
 frozen.mkdir()
 for p in origin.iterdir():
  if p.name=='Lokad.Lython.dll': continue
  if p.name.startswith('Lokad.Lython.Benchmarks.'):
   shutil.copyfile(p,frozen/p.name)
  else:
   (frozen/p.name).symlink_to(p.resolve())
 (root/'core.dll').rename(frozen/'Lokad.Lython.dll')
 files=image['imageFiles']['candidate']
 assert len(files)==32 and {p.name:sha(p) for p in frozen.iterdir()}==files
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==image['expectedCPythonSHA256']
''' + source[end:]
source = source.replace("assert bytes>cfg['payloadBytes']+3*1024*1024", "assert bytes>cfg['payloadBytes']+12*1024*1024")
compile(source,'quiet.py','exec')
write(lab/'quiet.py',source)
