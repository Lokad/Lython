from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470'
shutil.copyfile(notes/'numeric-pipeline-r472/global-bindings-public10.log',r/'global-bindings-public10.log')
p=r/'state.json';d=json.loads(p.read_text(encoding='utf-8'));d.update(focusedNet11Public=157,focusedNet10Public=157,net11FiltersDisjoint=True,next='Freeze copied workers after nonincremental build; verify13casegoldens/allocation. One numeric warm/fresh+compile source comparison, integer second affected shape/text control. Preserve compile cost and all adverse results; retain/refine/withdraw. No private diagnostic test remains.')
p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not(work/'tests/Lokad.Lython.Tests/GlobalBindingSourceDiagnostic.cs').exists()
assert not subprocess.check_output(['git','diff','dc480d38','--','src','tests'],cwd=repo,text=True).strip()
assert (notes/'floating-transport-r471/delivery/terminal.json').exists()
print('Safe checkpoint: current production/tests match qualifieddc480d38; private R473passes157checks each actual target, six Python controls, no timing/qualification claim.')
