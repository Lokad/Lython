from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess
r=Path(__file__).parent/'quiet';c=json.loads((r/'config.json').read_text(encoding='utf-8'));assert(r/'launch.log').exists()and not(r/'observe-not-before.json').exists()
shutil.copyfile(r/'launch.log',r/'initial-staging-failure.log')
bridge=Path('D:/code/Lython/benchmarks/cpython-worker.py');expected=hashlib.sha256(bridge.read_bytes()).hexdigest()
code=r'''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,stat,subprocess
c=CONFIG
b=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);assert root.parent==b and root.resolve()==root
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert not(root/'guest-fixtures').exists()and not(root/'exit-code.txt').exists()
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 for role,files in c['identity']['imageFiles'].items():
  for name,h in files.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==h
 assert all(not(b/path).exists()for proof in c['retireGroups']for path in proof['paths'])
 protocol=b/'float-cpython-b881-20261117/cpython-worker.py';s=protocol.lstat();assert protocol.resolve()==protocol and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and hashlib.sha256(protocol.read_bytes()).hexdigest()==BRIDGEHASH
 assert not(root/'cpython-worker.py').exists();os.link(protocol,root/'cpython-worker.py')
 assert not(root/'representative.json').exists();catalog=Path(c['source'])/'catalog.json';assert hashlib.sha256(catalog.read_bytes()).hexdigest()==c['catalogSHA256'];os.link(catalog,root/'representative.json')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=c['retireGroups'],initialLauncherVerifiedAllOwnershipPathsHashesLinksAliasesBeforeDeletion=True,initialStagingFailedAfterRetirementAndImageStaging=True,allRetiredPathsAbsentAtFreshIdleRepair=True,freeBeforeBytes=None,freeBeforeNotRecorded='Initial verified launcher failed linking protocol before persisting receipt; do not fabricate original free-space observation.',freeAfterBytes=shutil.disk_usage(b).free,currentImagesToolchainsAndCanonicalEvidencePreserved=True),indent=2)+'\n')
 (root/'staging-repair.json').write_text(json.dumps(dict(reason='Source parent is a profile collection without cpython-worker.py. Link identical committed protocol fromB881, link already verified3case catalog; no worker/service/measurement existed before repair.',bridgeSHA256=BRIDGEHASH,freshIdleLease=True,all32fileImagesVerifiedAgain=True,originalFailurePreservedLocally=True),indent=2)+'\n')
 assert shutil.disk_usage(b).free>254*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b883-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],root=str(root),freeBytes=shutil.disk_usage(b).free,metadataOnlyStagingRepair=True)))
'''.replace('CONFIG',repr(c)).replace('BRIDGEHASH',repr(expected))
(r/'staging-repair.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'staging-repair.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=230)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout);print('Only collection launched after verified metadata repair; do not observe before',now+datetime.timedelta(seconds=230))
