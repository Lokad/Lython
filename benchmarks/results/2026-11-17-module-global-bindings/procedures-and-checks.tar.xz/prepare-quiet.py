from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'floating-transport-r471/refined';q=r/'quiet';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/global-bindings-b883-20261117';f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.numeric-squared-error.large','warm'],['scripts.text-normalization.helper-list','warm'],['scripts.numeric-squared-error.floating.large','compile']]
collect=(old/'quiet/collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a);collect=collect[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)"+collect[b:]
collect=collect.replace('accumulate8seconds','accumulate6seconds').replace('warmupSeconds=8','warmupSeconds=6').replace('min(warmed)<8','min(warmed)<6').replace('warmed[i]>=8','warmed[i]>=6').replace('preserve original B876sequential4second condition','same-source controls retained; bounded R473sourcepair, no preferred-sign retiming')
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'quiet/archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/float-refined-b880-20261117',remote),encoding='utf-8',newline='\n')
ref=f['imageFiles']['reference']['Lokad.Lython.dll'];candidate=f['imageFiles']['candidate']['Lokad.Lython.dll'];cataloghash=f['diagnosticCatalogSHA256']
identity=dict(sourceRevision='Qualifieddc480d38/frozen5ecb2599 versus privateR473/frozen'+candidate,purpose='Immutable module binding facts replace per-read string map discovery; complete floating report warm/fresh/compile, integer second affected shape, helper-text unchanged control. No cached values/new owner/backend.',coreSHA256={'reference':ref,'reference-control':ref,'candidate':candidate,'candidate-control':candidate},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=585,catalogSHA256=cataloghash,catalogInitialization='Same verified fixed3case catalog fromR471, actual frozen images checked locally againstCPython before staging. Interleaved6s full-request warmups perprocess;5rotated samples.',normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll')
groups=[json.loads((r/'retirement-core-proof.json').read_text(encoding='utf-8'))]
for folder,remoteFolder in [('first-pair','call-operands-b876-20261117'),('confirmation','call-operands-b877-20261117')]:
 canonical='benchmarks/results/2026-11-17-call-operand-forwarding/'+folder+'/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
 groups.append(dict(paths=[remoteFolder+'/confirmation/confirmation.json'],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b883-global-bindings-20261117',source='/home/lokad/lython-bench-checks/numeric-pipeline-b882-20261117',sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=cataloghash,catalogSHA256=cataloghash,identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("source/'representative.json'","source/'catalog.json'").replace('lython-b880-fixtures','lython-b883-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('Four-job float transport source pair launched; do not observe before230seconds.','Five-job module-binding source comparison launched; no observation before230seconds.'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==5").replace('B880','B883'),encoding='utf-8',newline='\n')
summary=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace("r/'baseline-allocation.json'","r/'reference-allocation.json'")
summary=summary.replace("archivalOnlyRecovery='Inherited5job receipt corrected offline to4 after all work/gates/cleanup completed; originalserviceexit1 preserved. Timings not repeated.'","archivalOnlyRecovery=None")
(r/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
assert "len(raw['jobs'])==5"in(q/'archive-owned.py').read_text(encoding='utf-8')
print('Prepared5jobs/6s request warmups; current reference',ref,'candidate',candidate,'stage',c['unpackedBytes'],'retired replicas',sum(g['bytes']for g in groups))
