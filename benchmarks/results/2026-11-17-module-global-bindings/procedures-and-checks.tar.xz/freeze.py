from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');work=root/'.git/agent-worktrees/call-operands-r470';old=r.parent/'floating-transport-r471';frozen=r/'frozen';frozen.mkdir(exist_ok=False)
prior=json.loads((old/'refined/frozen-identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for name,expected in prior.items():
  source=old/'refined/candidate'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,name
  shutil.copyfile(source,image/name)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 for p in(old/'refined/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
images={role:{name:hashlib.sha256((frozen/role/name).read_bytes()).hexdigest()for name in prior}for role in ['reference','candidate']}
assert [name for name in prior if images['reference'][name]!=images['candidate'][name]]==['Lokad.Lython.dll']
names=list(json.loads((old/'delivery/inputs.json').read_text(encoding='utf-8'))['inputs'])+['tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs']
inputs={name:hashlib.sha256((work/name).read_bytes()).hexdigest()for name in names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for name in inputs:archive.add(work/name,arcname=name)
production=[name for name in inputs if name.startswith('src/Lokad.Lython/')]
different=[name for name in production if(work/name).read_text(encoding='utf-8-sig')!=(root/name).read_text(encoding='utf-8-sig')]
expected=['Frontend/ExecutableScript.Builder.cs','Frontend/ExecutableScript.cs','Public/LythonEngine.cs','Runtime/LythonRuntime.Executable.Binding.cs','Runtime/LythonRuntime.Executable.Interpreter.cs','Runtime/LythonRuntime.Executable.NativePrefix.cs','Runtime/LythonRuntime.Executable.cs']
assert sorted(different)==sorted('src/Lokad.Lython/'+name for name in expected),different
for name in ['catalog.json','diagnostic-catalog.json']:shutil.copyfile(old/name,r/name)
identity=dict(referenceSource='Qualifieddc480d38/frozen5ecb2599, GREEN44022750002',candidateSource='PrivateR473 ondc480d38, seven production files: immutable module slot facts and shared guarded resolution; no cached values',imageFiles=images,sourceInputs=inputs,productionFiles=len(production),changedProductionFiles=different,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),diagnosticCatalogSHA256=hashlib.sha256((r/'diagnostic-catalog.json').read_bytes()).hexdigest(),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role,catalog,label in [('reference','diagnostic-catalog.json','reference-three'),('candidate','diagnostic-catalog.json','candidate-three'),('candidate','catalog.json','candidate-thirteen')]:
 image=frozen/role
 with(r/(label+'-preflight.log')).open('w',encoding='utf-8')as log:
  p=subprocess.run([str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/catalog),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(root/'benchmarks/cpython-worker.py'),'--out',str(r/(label+'-preflight.json'))],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,(r/(label+'-preflight.log')).read_text(encoding='utf-8')
 print(label,'actual worker/CPython goldens pass',flush=True)
for role in ['reference','candidate']:
 image=frozen/role
 with(r/(role+'-allocation.log')).open('w',encoding='utf-8')as log:
  p=subprocess.run([str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'diagnostic-catalog.json'),str(r/(role+'-allocation.json'))],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,(r/(role+'-allocation.log')).read_text(encoding='utf-8')
 for row in json.loads((r/(role+'-allocation.json')).read_text(encoding='utf-8'))['rows']:
  assert row['sharedBudgetBaselineRestored'];print(role,row['id'],row['allocatedBytesPerInvocation'],row['compilationAllocatedBytesDiagnostic'],flush=True)
print('Frozen32file copied images,585production sources; only core differs.',images['candidate']['Lokad.Lython.dll'])
