from pathlib import Path
import json,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470'
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));files=identity['changedProductionFiles'];assert len(files)==7
subprocess.run(['git','-C',str(work),'restore','--']+files,check=True)
assert not subprocess.check_output(['git','-C',str(work),'diff','--','src'],text=True).strip()
p=work/'tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs';text=p.read_text(encoding='utf-8');start=text.index('        yield return [');end=text.index('\n    }',start)
cases=text[start:end].split('        yield return [');assert len(cases)==7
retained='        yield return ['+cases[3];assert 'values=(read(index)'in retained
text=text[:start]+retained.rstrip()+text[end:]
text=text.replace('public static IEnumerable<object[]> Programs()','public static IEnumerable<object[]> Programs()')
p.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['git','-C',str(work),'diff','--check'],check=True)
d=json.loads((r/'state.json').read_text(encoding='utf-8'));d.update(stage='Withdrawn: all7production edits removed; no compiler metadata/pass/token-argument extension or guarded resolver remains. Main production unchanged qualifieddc480d38.',decision='Warm integer3–5%benefit confirmed, floating warm favorable with moving reference; no established fresh elapsed gain and confirmation widerCPU+0.42..5.19%. Allocation flat, additional phase/metadata. Do not retain this shape for compile-once/run-once priority. Not a permanent design ban.',retainedPublicCases=3,next='Run3independent retained cases on unchanged runtime each actual target; preserve all first/confirmation/staging/source evidence. Continue source gate on duplicate input/subscript reads, not another global retiming.')
(r/'state.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Removed all7prototype production edits; retained generator rebinding and2real-I/O/ownership/cancellation cases only.')
