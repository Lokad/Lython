from pathlib import Path
import gzip,hashlib,json,shlex,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');canonical='benchmarks/results/2026-11-17-call-operand-forwarding/reference-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob);expected=hashlib.sha256(data).hexdigest();assert expected=='7a5993475d8851c184f6de935cee023f19324fdbeda0517964d51be833a4ef56'
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks').resolve()
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 p=b/'float-refined-b880-20261117/reference/Lokad.Lython.dll';s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and hashlib.sha256(p.read_bytes()).hexdigest()==EXPECTED
 aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   candidate=Path(base)/name;v=candidate.lstat()
   if(v.st_dev,v.st_ino)==(s.st_dev,s.st_ino):
    assert candidate.resolve()==candidate and v.st_uid==os.getuid()and stat.S_ISREG(v.st_mode)
    aliases.append(str(candidate.relative_to(b)))
 assert len(aliases)==s.st_nlink
 print(json.dumps(dict(paths=sorted(aliases),bytes=s.st_size,links=s.st_nlink,uid=s.st_uid,sha256=EXPECTED,freshIdleLease=True,allInodeAliasesFound=True,supersededPreviousSourceOnly=True)))
'''.replace('EXPECTED',repr(expected))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert p.returncode==0,p.stdout+p.stderr
d=json.loads(p.stdout);d.update(canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,reason='Previousccf20ba3working core superseded by fully qualifieddc480d38/current5ecb2599. Current5ecb2599/newcandidate and31fixedassets/toolchains/canonicals preserved; no worker active.')
(r/'retirement-core-proof.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Read-only retirement inventory: prior core',d['bytes'],'bytes/',d['links'],'aliases; all paths/inodes/hash/ownership verified. No files removed.')
