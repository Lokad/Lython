from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile,io
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r/'quiet';q=r/'confirmation';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/global-binding-control-b884-20261117'
collect=(old/'collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a);collect=collect[:a]+"jobs=[['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.numeric-squared-error.large','warm']]\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)"+collect[b:]
collect=collect.replace('accumulate6seconds','accumulate8seconds').replace('warmupSeconds=6','warmupSeconds=8').replace('min(warmed)<6','min(warmed)<8').replace('warmed[i]>=6','warmed[i]>=8').replace('bounded R473sourcepair, no preferred-sign retiming','bounded unchanged-source confirmation of B883moving fresh/integer controls; original conditions preserved')
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/global-bindings-b883-20261117',remote),encoding='utf-8',newline='\n')
c=json.loads((old/'config.json').read_text(encoding='utf-8'));c.update(root=remote,unit='lython-b884-global-binding-control-20261117',source='/home/lokad/lython-bench-checks/global-bindings-b883-20261117',sourceRole='reference')
c['identity']['purpose']='One unchanged-source confirmation after B883fresh candidate8.81%/integer reference11.99%control movement. Same source/image/catalog; floating fresh and integer warm only, no old condition erased.'
(q/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
groups=[]
canonical='benchmarks/results/2026-11-17-numeric-runtime-attribution/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
groups.append(dict(paths=['numeric-pipeline-b882-20261117/observations.tgz'],bytes=len(blob),links=1,sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='complete-file',committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-float-transport/cpython/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('confirmation/confirmation.json').read()
groups.append(dict(paths=['float-cpython-b881-20261117/confirmation/confirmation.json'],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
 for name in names:archive.add(q/name,arcname=name)
c.update(retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace("source/'catalog.json'","source/'representative.json'").replace('lython-b883-fixtures','lython-b884-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
(r/'launch-confirmation.py').write_text((r/'launch.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'confirmation'").replace('timedelta(seconds=230)','timedelta(seconds=125)').replace('Five-job module-binding source comparison launched; no observation before230seconds.','Two-job unchanged-source confirmation launched; no observation before125seconds.'),encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace("__file__).parent","__file__).parent/'confirmation'").replace("['jobs']==5","['jobs']==2").replace('B883','B884')
(r/'retrieve-confirmation.py').write_text(retrieve,encoding='utf-8',newline='\n')
summary=(r/'summarize.py').read_text(encoding='utf-8').split('reference=json.loads')[0].replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'confirmation/retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace("r/'summary.json'","r/'confirmation-summary.json'")
(r/'summarize-confirmation.py').write_text(summary,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch-confirmation.py',r/'retrieve-confirmation.py',r/'summarize-confirmation.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared2unchanged-source jobs; reuse all images/catalog, retire only committed working evidence replicas',sum(g['bytes']for g in groups))
