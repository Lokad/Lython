from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/call-operands-r470';out=repo/'benchmarks/results/2026-11-17-module-global-bindings';out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','-C',str(work),'diff','--','src'],text=True).strip()
decision='Withdraw this shape: warm benefits exist, but compile-once/run-once elapsed remains inconclusive with adverse wider CPU and flat allocation. Added compiler pass/metadata/guard not justified for current priority. No permanent ban or fixed-percentage veto.'
for name in ['summary.json','confirmation-summary.json']:
 d=json.loads((r/name).read_text(encoding='utf-8'));d.update(retentionDecisionPending=False,decision=decision);(out/name).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['allocation-summary.json','candidate-sources.tar.xz','prototype.patch','cpython-semantic-goldens.json','state.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
for folder in ['quiet','confirmation']:
 target=out/('first-pair'if folder=='quiet'else'confirmation');target.mkdir()
 receipt=json.loads((r/folder/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']
 assert hashlib.sha256((r/folder/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/folder/name,target/name)
with gzip.open(out/'candidate-core.dll.gz','wb')as stream:stream.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
with gzip.open(out/'candidate-core.dll.gz','rb')as stream:assert stream.read()==(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as archive:
 for p in list(r.glob('*.py'))+list(r.glob('*.json'))+list(r.glob('*.log')):
  archive.add(p,arcname=p.name)
 for folder in ['quiet','confirmation']:
  for p in(r/folder).iterdir():
   if p.is_file()and p.name not in ['payload.tgz','observations.tgz']:archive.add(p,arcname=folder+'/'+p.name)
validation=dict(withdrawnProductionFiles=7,retainedPublicCases=3,prototypeEachActualWindowsTargetPublic=157,independentCPythonPrograms=6,unchangedRuntimeEachActualWindowsTargetRetainedCases=3,actualFrozenReferenceAndCandidateCatalogChecks=3,candidateFullCatalogGoldens=13,productionUnchanged='Qualifieddc480d38/GREEN44022750002; no replay',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Module-global binding facts: withdrawn

R473/B883–B884,2026-11-17UTC. Qualified dc480d38/frozen5ecb2599 versus private
seven-file prototype/frozen46b7f3de. **Withdraw this shape.** All production edits
are removed; three independent generator/I/O/ownership cases remain. No permanent
design ban, preferred-sign retiming or automatic percentage veto.

Preparation mapped global name indexes to module slots once. Runtime guarded the
actual immutable module layout and read live values; general independent namespace
resolution remained. No value cache/new owner/backend/unsafe code. Three reads per
numeric-generator iteration removed12,288module string-map probes/run. This extends
c599dac6lexical global opcodes, rather than repeating their original selection.

| First complete script | Phase | Elapsed change | Wider CPU change | Reference / candidate control spread |
| --- | --- | ---: | ---: | ---: |
| Floating JSON numeric report | Warm | −10.13..−3.57% | −11.03..−2.73% | 7.15 / 0.14% |
| Same | Compile and execute once | −5.97..+2.44% | −7.12..+1.51% | 0.11 / 8.81% |
| Integer numeric report | Warm | −11.83..+1.83% | −11.11..+1.41% | 11.99 / 3.12% |
| Unchanged helper text | Warm | −1.50..+1.89% | −1.58..+0.52% | 2.79 / 0.64% |
| Floating report | Compilation | −0.54..+2.93% | −0.95..+3.05% | 1.72 / 1.74% |

First five jobs192.12s, interleaved6s full-request warmups/process. Moving fresh
and integer controls justify one unchanged-source confirmation: same images/catalog,
interleaved8s warmups, two jobs96.02s:

| Confirmation | Elapsed change | Wider CPU change | Reference / candidate controls |
| --- | ---: | ---: | ---: |
| Floating report, compile and execute once | −1.34..+3.62% | **+0.42..+5.19%** | 3.54 / 1.44% |
| Integer report, warm | **−5.26..−3.41%** | **−4.35..−2.39%** | 1.08 / 0.86% |

Warm benefit is real evidence, not erased by withdrawal. Fresh elapsed remains
uncertain; confirmation's wider CPU is adverse. Flat runtime allocation/peaks and
an extra compiler pass, two metadata fields and guarded lookup do not justify
retaining this shape for the compile-once/run-once priority. No causal explanation
of all process movement or claim that the prior R471integer debt is resolved.
No further unchanged retiming. A different coherent design may reconsider these facts.

Natural-GC local allocation is flat for all3scripts; numeric accountedpeak906,718B
unchanged, all shared budgets restore baseline. Later diagnostic compilations add
184Btext/264Bfloating; first integer compilation includes cold/JIT cost, not a clean
metadata comparison. Controlled compilation timing above is separate. Each actual
Windows.NET11/10 passes157public checks; six independent CPython3.13.2programs
agree. Actual copied32file workers pass the3case catalog for both sources plus13
candidate goldens. Nonincremental build/full585production snapshot preserved.
After removing all7edits, the3retained cases pass both actual targets. Temporary
architecture diagnostic removed; no dormant binding fields/pass/token overload/
resolver hooks remain. Full unchanged production qualification is not replayed.

Both collections use the same fixed3case catalog, four independent processes,
five rotated roughly0.5s samples. Ranges are all process-median pairings, not
confidence intervals. Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3 natural workstation
GC/normal tiering. Warm includes synchronous Run, mediated RAM I/O, complete
stdout/file goldens and prior-result cleanup; excludes compilation/startup/reset/
protocol/final cache teardown. Fresh adds compile/compiled-owner disposal; external
CPU is wider. No async/CPython ratio/RSS/embedding-tail gain is inferred.

All identity/golden/quiet/Closed/exit/join/archive checks pass; RAM removed and
terminals cached. Initial staging failed before any worker because the profile
parent lacked cpython-worker.py. Idle-lease repair verified all images again and
linked the identical committed protocol/catalog. Original failure retained; no
timing was rerun to repair staging. Exact initial free-before value was not saved
before that failure: receipt leaves it unknown, not fabricated. Initial verified
launcher retired only superseded7a599347core13aliases plus committed old raw,
6,279,714B; confirmation retires785,273Bof committed working evidence replicas.
Fresh UID/path/hash/link/all-alias proofs preserve current5ecb2599/new images,
toolchains/canonicals and254/252MiBstaging/final floors. Source/current
[reference core](../2026-11-17-float-transport/refined/candidate-core.dll.gz)
remains archived independently. Publication held; broader roadmap continues.

[First summary](summary.json),[confirmation](confirmation-summary.json),
[allocation](allocation-summary.json),[validation](validation.json),
[first raw](first-pair/observations.tgz),[confirmation raw](confirmation/observations.tgz),
[exact sources](candidate-sources.tar.xz),[prototype](prototype.patch),
[core](candidate-core.dll.gz),[identity](identity.json),
[procedures/failures/checks](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
shutil.copyfile(work/'tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs',repo/'tests/Lokad.Lython.PublicApi.Tests/GlobalBindingPipelineTests.cs')
p=repo/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as stream:stream.write('''
[R473/B883–B884 module binding facts](results/2026-11-17-module-global-bindings/README.md):
withdraw46b7f3de after one bounded confirmation. Warm integer−5.26..−3.41%withCPU
confirmed; floating warm favorable/moving reference, but fresh confirmation elapsed
−1.34..+3.62%/widerCPU+0.42..+5.19%. Runtime allocation/peaks flat; extra phase/
metadata not justified for run-once priority. All7production edits removed,3useful
external cases retained/passing each actual target; no dormant compiler hooks or
permanent ban. First/confirmation/missing-protocol staging failure and exact
sources/cores preserved, all users joined/RAM removed. Source remains qualifiedDC;
no unchanged full qualification/CPython refresh. Continue coherent input-transport
assessment; no claimed completion or publication.
''')
print('Both conditions/evidence preserved, all7production edits removed,3independent public cases promoted; qualified runtime unchanged.')
