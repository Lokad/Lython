from pathlib import Path
import hashlib, json, shutil, tarfile
lab = Path(__file__).resolve().parent
repo=lab.parents[3]
prior = lab.with_name("csv-record-pull-sync-20261125")
quiet = lab / "comparison/quiet"
donor = prior / "comparison/quiet"
confirmation = prior.with_name("csv-record-pull-sync-confirm-20261125") / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")
def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

jobs = {"warm": [
    ["scripts.rule-default-closures", "warm"],
    ["scripts.annotated-rule-closures", "warm"],
    ["scripts.annotated-rule-closures.nested-factories.postponed", "warm"],
    ["scripts.rule-default-closures", "compile-run"],
    ["diagnostic.generated-ordinary-definitions", "compile-run"],
    ["diagnostic.generated-live-definitions", "warm"],
    ["diagnostic.shipment-routing-callbacks", "warm-async"],
    ["scripts.rule-default-closures", "compile"],
]}
save(quiet / "jobs.json", jobs)
identity = read(quiet / "identity.json")
assert identity["imageFiles"]["reference"] == read(donor / "identity.json")["imageFiles"]["candidate"]
for role, files in identity["imageFiles"].items():
    assert {p.name: digest(p) for p in (lab / role).iterdir()} == files
    verification = read(lab / "comparison" / (role + "-verify.json"))
    assert verification["caseCount"] == 7 and verification["state"] == "Completed"
identity["catalogs"]["jobs.json"] = {"sha256": digest(quiet / "jobs.json")}
save(quiet / "identity.json", identity)
collector = (donor / "collect.py").read_text(encoding="utf-8").replace("b1706b-fixtures", "b1707-fixtures").replace("len(jobs) == 3", "len(jobs) == 8")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(donor / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
launcher = (prior / "quiet.py").read_text(encoding="utf-8").replace("b1706b", "b1707").replace(
    "lython-b1707-csv-record-pull-sync", "lython-b1707-shared-default-owners").replace(
    "seconds=138", "seconds=350").replace("RuntimeMaxSec=210", "RuntimeMaxSec=420")
anchor=read(confirmation/"terminal-status.json")["receipt"]
assert anchor["complete"] and digest(confirmation/"observations.tar.xz")==anchor["archiveSHA256"]
a=launcher.index("assert donor['archiveSHA256']=='")
b=launcher.index("\n",a)
launcher=launcher[:a]+"assert donor['archiveSHA256']=="+repr(anchor["archiveSHA256"])+launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
retire=[]
for plan in read(lab / "archived-duplicates.json"):
    archive=repo/plan["path"]
    assert archive.is_file() and digest(archive)==plan["sha"] and archive.is_relative_to(repo/"benchmarks/results")
    with tarfile.open(archive) as data:
        member=data.getmember("confirmation/confirmation.json")
        assert member.isfile() and member.size==plan["rawBytes"]
        raw=data.extractfile(member).read()
        assert json.loads(raw)["complete"]
    retire.append(dict(location=plan["run"],archiveSHA256=plan["sha"],bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest()))
save(lab / "verified-raw-replicas.json", retire)
archive = (prior / "archive.py").read_text(encoding="utf-8").replace(
    "2026-11-25-csv-record-pull/sync", "2026-11-25-shared-default-owners").replace(
    '==receipt["warmJobs"]==3', '==receipt["warmJobs"]==8').replace("timedBatches=84,lanes=3", "timedBatches=224,lanes=8")
compile(archive, "archive.py", "exec")
write(lab / "archive.py", archive)
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="shared-default-owners-b1707-20261125",
    reference="csv-record-pull-sync-b1706bc-20261125",
    payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
