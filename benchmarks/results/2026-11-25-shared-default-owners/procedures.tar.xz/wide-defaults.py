def make_pair(seed):
    def left(value=(seed * seed - 17) // 3, /, *, weight=(seed * 3) % 11, enabled=(seed + 2) % 3 != 0):
        return (value, weight, enabled)
    right = lambda value=(seed * seed + 13) % 17, /, *, tag=7: (value, tag)
    return left, right

def capture_factory(marker):
    def build(seed):
        def rule(value=(seed * seed - 5) // 3, /, *, tag=marker):
            return value, tag
        return rule
    return build

marker = ["shared"]
build = capture_factory(marker)
for seed in (0, -7, 4611686018427387904, -4611686018427387904):
    left, right = make_pair(seed)
    captured = build(seed)
    same = captured()[1] is marker and captured.__kwdefaults__["tag"] is marker
    print(left(), right(), captured()[0], same)
    print(left.__defaults__, left.__kwdefaults__, right.__defaults__, right.__kwdefaults__)
