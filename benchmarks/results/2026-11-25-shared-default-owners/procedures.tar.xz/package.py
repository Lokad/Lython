from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/shared-default-owners-20261125"
out = repo / "benchmarks/results/2026-11-25-shared-default-owners"
quiet = lab / "comparison/quiet"
identity = json.loads((quiet/"identity.json").read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert (lab/"candidate.patch").read_bytes()==subprocess.check_output(["git","-C",tree,"diff","--binary","--","src"])
for role,files in identity["imageFiles"].items():
    assert {p.name:digest(p) for p in (lab/role).iterdir()}==files
status = json.loads((quiet/"terminal-status.json").read_text(encoding="utf-8"))
assert not status["live"] and not status["fixtures"]
assert digest(quiet/"observations.tar.xz")==status["receipt"]["archiveSHA256"]
assert digest(out/"quiet-observations.tar.xz")==status["receipt"]["archiveSHA256"]
for prefix in ("probe","windows-Lokad.Lython.Tests","windows-public","ubuntu-net10-Lokad.Lython.Tests","ubuntu-net10-Lokad.Lython.PublicApi.Tests"):
    assert (lab/(prefix+".log")).is_file()
for name,count in [("windows-Lokad.Lython.Tests.log",477),("windows-public.log",1745),("ubuntu-net10-Lokad.Lython.Tests.log",477),("ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",1745)]:
    assert f"Passed:   {count}" in (lab/name).read_text(encoding="utf-8-sig") or f"Passed:  {count}" in (lab/name).read_text(encoding="utf-8-sig")
for name in ("allocation-summary.json","compile-allocation-summary.json","wide-default-routes.json"):
    shutil.copyfile(lab/name,out/name)
shutil.copyfile(quiet/"identity.json",out/"identity.json")
names = [
    "package.py","freeze.py","prepare.py","quiet.py","archive.py","find-archived-duplicates.py","test-ubuntu.sh",
    "archived-duplicates.json","verified-raw-replicas.json","candidate.patch","candidate-build.log","probe.log",
    "windows-Lokad.Lython.Tests.log","windows-public.log","ubuntu-net10-Lokad.Lython.Tests.log",
    "ubuntu-net10-Lokad.Lython.PublicApi.Tests.log","windows-Lokad.Lython.PublicApi.Tests.log",
    "windows-public-corrected.log","ubuntu-public-missing-scripts.log","wide-defaults.py",
    "wide-defaults-sync.json","wide-defaults-async.json","wide-default-routes.json","tape/Program.cs",
    "tape/Tape.csproj","tape/build.log","tape/cases.json","tape/tapes.json","allocations.py","compile-allocation.py",
    "reference-allocation-final.json","candidate-allocation-final.json","reference-compiler-owner.json",
    "candidate-compiler-owner.json","comparison/reference-verify.json","comparison/candidate-verify.json",
    "comparison/quiet/upload.json","comparison/quiet/storage-custody.json","comparison/quiet/launch.log",
]
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in names: archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==names
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest(lab/name) for name in names)
print("Archived test, allocation, custody and source evidence.")
