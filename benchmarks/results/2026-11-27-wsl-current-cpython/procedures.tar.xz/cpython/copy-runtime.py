from pathlib import Path, PurePosixPath
from hashlib import sha256
import json,os,re,shlex,subprocess,tarfile

lab=Path(__file__).resolve().parent
anchor=lab.parent/'csv-dictwriter-native-validation-20261127/comparison/quiet-cpython/remote-verify.json'
python=json.loads(anchor.read_bytes())['launched']['python']
root='/home/lokad/lython-bench-toolchains/cpython/3.13.16'
assert python['path']==root+'/bin/python3.13'
expected=python['sha256']
archive=lab/'runtime.tar.gz'
unpack=lab/'runtime'
assert not archive.exists() and not unpack.exists()
args=['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73']
cmd=f"""set -eu
exec 9</home/lokad/lython-bench-checks/comparison-vm.lock
flock -sn 9
cd {shlex.quote(root)}
printf '%s  bin/python3.13\n' {shlex.quote(expected)} | sha256sum -c >&2
tar --exclude=lib/python3.13/test --exclude=lib/python3.13/config-3.13-x86_64-linux-gnu -czf - bin/python3.13 lib/python3.13
printf '%s  bin/python3.13\n' {shlex.quote(expected)} | sha256sum -c >&2
"""
with archive.open('xb') as stream, (lab/'transfer.log').open('wb') as log:
    subprocess.run(args+['sh -c '+shlex.quote(cmd)],stdout=stream,stderr=log,check=True,timeout=70)
files={}
with tarfile.open(archive) as source:
    for m in source:
        p=PurePosixPath(m.name)
        assert p==PurePosixPath('bin/python3.13') or p.is_relative_to('lib/python3.13'), m.name
        assert all(part not in ('.','..') for part in p.parts)
        assert m.isfile() or m.isdir(), m.name
        if m.isfile():
            assert m.name not in files
            files[m.name]=sha256(source.extractfile(m).read()).hexdigest()
assert files['bin/python3.13']==expected
def wsl(p):
    p=p.resolve()
    return '/mnt/'+p.drive[0].lower()+'/'+p.relative_to(p.anchor).as_posix()
unpack.mkdir()
subprocess.run(['wsl.exe','-d','Ubuntu','--','tar','-xzf',wsl(archive),'-C',wsl(unpack)],check=True, timeout=45)
assert {p.relative_to(unpack).as_posix():sha256(p.read_bytes()).hexdigest() for p in unpack.rglob('*') if p.is_file()}==files
code='import csv, json, re, sys, platform; print(json.dumps(dict(version=platform.python_version(), debug=hasattr(sys, "gettotalrefcount"), prefix=sys.prefix, csv=csv.__file__, json=json.__file__, regex=re.__file__)))'
probe=subprocess.check_output(['wsl.exe','-d','Ubuntu','--',wsl(unpack/'bin/python3.13'),'-IB','-c',code],timeout=10,text=True)
d=json.loads(probe)
assert d['version']=='3.13.16' and not d['debug'] and d['prefix']==wsl(unpack)
assert all(d[k].startswith(wsl(unpack)+'/lib/python3.13/') for k in ('csv','json','regex'))
identity=dict(source=python,archiveSha256=sha256(archive.read_bytes()).hexdigest(),archiveBytes=archive.stat().st_size,files=files,
              exclusions=['lib/python3.13/test','lib/python3.13/config-3.13-x86_64-linux-gnu'],local=d)
(lab/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('SHA matched the quiet baseline',expected, 'files',len(files),'archive bytes',archive.stat().st_size)
