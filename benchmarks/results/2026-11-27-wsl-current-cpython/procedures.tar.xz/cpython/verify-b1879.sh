#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
lab="$root/../executable-positional-forms-20261127/comparison/local"
export DOTNET_ROOT="$HOME/.dotnet"
exec "$DOTNET_ROOT/dotnet" "$lab/candidate/Lokad.Lython.Benchmarks.dll" --compare verify \
    --catalog "$lab/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$root/runtime/bin/python3.13" \
    --python-worker "$lab/cpython-worker.py" --out "$root/b1879-verify.json"
