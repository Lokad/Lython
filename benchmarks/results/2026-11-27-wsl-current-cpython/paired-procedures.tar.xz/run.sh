#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export DOTNET_ROOT="$HOME/.dotnet"
"$DOTNET_ROOT/dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare verify \
  --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" \
  --python "/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13" --python-worker "$root/cpython-worker.py" --out "$root/verification.json"
trap 'status=$?; printf "%s\n" "$status" > "$root/exit-code.txt"' EXIT
timeout --signal=TERM 300s taskset -c 27 python3 "$root/collect.py"
