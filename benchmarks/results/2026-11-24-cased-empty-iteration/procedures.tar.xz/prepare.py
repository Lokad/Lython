from pathlib import Path
import base64
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/cased-empty-iteration-20261124'
donor = lab.with_name('json-encoding-flags-20261124')
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
quiet.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(file, source):
    file.write_text(source, encoding='utf-8', newline='\n')


def save(file, data):
    write(file, json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def from_archive(stem):
    path = repo / 'benchmarks/results' / stem / 'observations.tar.xz'
    with tarfile.open(path) as bundle:
        return json.load(bundle.extractfile('representative.json'))


def revision(workspace):
    return subprocess.check_output(['git','rev-parse','HEAD'], cwd=workspace, text=True).strip()


metadata = read(donor/'comparison/identity.json')
reference = metadata['candidate']
assert reference.startswith('eabbf02ed')
subprocess.run(['git','diff','--exit-code',reference,'HEAD','--','src','tests'],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate = revision(tree)
assert candidate != revision(repo)

catalog = read(lab.with_name('current-text-helper-cpu-20261124')/'catalog.json')
short = catalog['cases'][0]
assert short['id'] == 'diagnostic.text-summary.nonlocal-computed-width.large'
mixed = from_archive('2026-11-23-combined-cased-split-cpython')['cases'][1]
assert mixed['id'] == 'diagnostic.text-summary.borrowed-cased-words.mixed-width'
invoice, = [case for case in from_archive('2026-11-24-typed-csv-text')['cases'] if case['id'].endswith('quoted-control')]
nonblank = short.copy()
nonblank['id'] = 'diagnostic.text-summary.nonlocal-computed-width.no-blank-lines'
assert 'latest_width == 3' in short['source']
nonblank['source'] = short['source'].replace('latest_width == 3','latest_width == 5')
fixtures = json.loads(short['fixtureJson'])
original = base64.b64decode(fixtures['inputFiles']['input.txt'])
lines = original.splitlines(keepends=True)
assert len(lines)==3072 and lines.count(b'\n')==1024
data = b''.join(b'A\n' if line==b'\n' else line for line in lines)
fixtures['inputFiles']['input.txt'] = base64.b64encode(data).decode('ascii')
with tempfile.TemporaryDirectory(prefix='lython-text-golden-') as temp:
    folder = Path(temp)
    (folder/'input.txt').write_bytes(data)
    stdout = io.StringIO()
    with contextlib.chdir(folder), contextlib.redirect_stdout(stdout):
        exec(compile(nonblank['source'],'nonblank.py','exec'),{'__name__':'__main__'})
    report = (folder/'report.txt').read_bytes()
assert stdout.getvalue() == '7168\n'
fixtures['outputFiles']['report.txt'] = base64.b64encode(report).decode('ascii')
nonblank['fixtureJson'] = json.dumps(fixtures,ensure_ascii=False,separators=(',',':'))
nonblank['expectedOutput'] = stdout.getvalue()
for key, field in [('source','source'),('expectedOutput','expectedOutput'),('fixture','fixtureJson')]:
    raw = nonblank[field].encode('utf-8')
    nonblank[key+'Sha256'] = sha(raw)
    if key != 'fixture':
        nonblank[key+'Utf8Bytes'] = len(raw)

protocol = repo/'benchmarks/cpython-worker.py'
provider = importlib.util.spec_from_file_location('comparison_protocol',protocol)
commands = importlib.util.module_from_spec(provider)
provider.loader.exec_module(commands)
nonblank['expectedFilesSha256'] = commands.file_digest({'report.txt':report})
catalog['cases'] = [short,nonblank,mixed,invoice]
save(comparison/'representative.json',catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})

runtime = Path.home()/'.dotnet11'
dotnet = runtime/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert digest(protocol) == metadata['cpythonWorkerSHA256']
files = metadata['imageFiles']['candidate']
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core = 'Lokad.Lython.dll'
images = {}
helpers = {}
for role in ('reference','candidate'):
    image = lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        path = lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(path,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper = 'ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper] = digest(donor/'candidate'/helper)
    observed = {name:digest(image/name) for name in files}
    result = comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        comparison/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',protocol,'--out',result],env=env,check=True,timeout=90)
    receipt = read(result)
    assert receipt['state']=='Completed' and receipt['caseCount']==4 and receipt['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role] = observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1557 skip empty cased iteration ownership and start at the first word',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
