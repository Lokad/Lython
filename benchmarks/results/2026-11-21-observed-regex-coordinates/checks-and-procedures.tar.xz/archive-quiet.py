from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'shared/quiet'
out=Path('benchmarks/results/2026-11-21-observed-regex-coordinates')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease','quietBeforeAndAfter'))
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
local=load(out/'summary.json')
identity=load(quiet/'identity.json')
refined=load(lab/'shared/identity.json')
assert identity['imageFiles']==refined['imageFiles'] and identity['catalogSHA256']==refined['catalogSHA256']
assert local['candidates'][1]['coreSHA256']==identity['coreSHA256']['candidate']
raw=load(quiet/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs'])==receipt['jobs']==5
catalog={row['id']:row for row in load(lab/'representative.json')['cases']}
for job in raw['jobs']:
    case=catalog[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and job['lane']=='warm' and len(job['samples'])==28
    for row in job['samples']:
        response=row['response']
        assert response['completedInvocations']>0 and response['status']=='Completed'
        assert response['sourceSha256']==case['sourceSha256'] and response['fixtureSha256']==case['fixtureSha256']
        assert response['actualOutputSha256']==case['expectedOutputSha256'] and response.get('actualFilesSha256')==case.get('expectedFilesSha256')
summary=load(quiet/'quiet-summary.json')
summary.update(collection='B1275',candidate=refined['candidate'],reference=refined['reference'], verifiedTimedBatches=140,
               coreSHA256=identity['coreSHA256']['candidate'],archiveSHA256=receipt['archiveSHA256'])
(out/'quiet-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for n in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/n,out/n)
with tarfile.open(out/'quiet-procedures.tar.xz','w:xz',preset=6) as tar:
    for file in sorted(quiet.iterdir()):
        if file.suffix in {'.json','.py','.sh','.log'}:tar.add(file,arcname='quiet/'+file.name)
    for file in ('prepare-quiet.py','prepare-reclaim.py','reclaim-proof.json','launch.py','summarize.py'):
        path=lab/'shared'/file
        tar.add(path,arcname=file)
print('140 verified warm observations, both quiet gates and complete source identity.')
