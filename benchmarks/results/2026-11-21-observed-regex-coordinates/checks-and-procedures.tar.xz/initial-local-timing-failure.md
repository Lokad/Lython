Before sampling, the initial local driver expected one completed invocation from verify. The worker always verifies twice. It joined before rerunning with the protocol-correct count.
