from pathlib import Path
import hashlib,json,subprocess,tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-21-observed-regex-coordinates')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
refinement=lab/'shared'
rows=[]
for stage,d in [('inline-window',lab),('shared-window',refinement)]:
    identity=load(d/'identity.json')
    execution=load(d/'local-timing.json')
    assert execution['identity']==identity
    manifest=load(d/'representative.json')
    assert sha(d/'representative.json')==identity['catalogSHA256']
    for role, files in identity['imageFiles'].items():
        assert len(files)==32 and {n:sha(d/'frozen'/role/n) for n in files}==files
        assert load(d/f'{role}-verify.json')['state']=='Completed'
    cases={c['id']:c for c in manifest['cases']}
    assert len(cases)==len(execution['rows'])==6
    timings=[]
    for row in execution['rows']:
        case=cases[row['case']]
        assert len(row['samples'])==4 and all(len(samples)==5 for samples in row['samples'].values())
        verified=0
        for samples in row['samples'].values():
            for sample in samples:
                assert sample['completedInvocations']==16 and sample['status']=='Completed'
                assert sample['sourceSha256']==case['sourceSha256'] and sample['fixtureSha256']==case['fixtureSha256']
                assert sample['actualOutputSha256']==case['expectedOutputSha256']
                verified+=1
        timings.append({k:v for k,v in row.items() if k!='samples'})
    allocation=load(d/'allocation-summary.json')
    assert len(allocation)==6 and all(r['budgetReturnedToBaseline'] for r in allocation)
    rows.append(dict(stage=stage, measuredSource=identity['candidate'], reference=identity['reference'],
        coreSHA256=identity['imageFiles']['candidate']['Lokad.Lython.dll'],
        completeImageFiles=32, verifiedTimedBatches=6*4*5, timing=timings,allocation=allocation))
    (d/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','a877f095e',identity['candidate'],'--','src','tests']))
out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(dict(method='Windows .NET 11 RC3 local process elapsed diagnostic, current optional adapter 0.4.0, no quiet CPU or CPython timing comparison',candidates=rows),indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as tar:
 for parent in (lab,refinement):
  for file in sorted(parent.iterdir()):
   if file.is_file():tar.add(file,arcname=file.relative_to(lab).as_posix())
print('240 batches, LPython and CPython goldens, source identities and complete images verified.')
