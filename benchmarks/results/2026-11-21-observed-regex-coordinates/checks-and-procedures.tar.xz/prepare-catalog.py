from pathlib import Path
import hashlib,json,subprocess
lab=Path(__file__).resolve().parent
old=json.loads((lab.parent/'regex-capture-projection-r626/catalog.json').read_text(encoding='utf-8-sig'))
original={c['id']:c for c in old['cases']}
groups=original['scripts.regex-unicode-groups']
sha=lambda b:hashlib.sha256(b).hexdigest()
def variant(name,source):
    stdout=subprocess.check_output(['C:/Python313/python.exe','-X','utf8','-I','-c',source],timeout=20).replace(b'\r\n',b'\n')
    return dict(groups,id='scripts.regex-'+name,source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=sha(source.encode()),
                expectedOutput=stdout.decode(),expectedOutputUtf8Bytes=len(stdout),expectedOutputSha256=sha(stdout))
header=groups['source'].split('\ntotal = ',1)[0]
callback=variant('unicode-callback-text',header+"\nfinished=pattern.sub(lambda m:m.group('id') + m.group('zone'),text)\nprint(len(finished), finished.count('β'))\n")
ascii_control=variant('ascii-groups',groups['source'].replace('équipe','equipe').replace('☁','@').replace('λ','X').replace('β','Y'))
wide=variant('unicode-wide-registers',"""import re
text = ('α' + 'é😀' * 20 + 'z!') * 128
pattern = re.compile(r'(?<=(α))' + '(é)(😀)' * 20 + r'(?=(z))')
total = 0
for match in pattern.finditer(text):
    regs = match.regs
    total += regs[0][0] + regs[-1][1] - regs[1][0] + match.end(42)
print(total)
""")
whole=variant('unicode-whole-offsets',header+"\ntotal=0\nfor m in pattern.finditer(text):\n left,right=m.span()\n total+=left+right\nprint(total)\n")
old['cases']=[groups,callback,original['scripts.regex-unicode-spans'],whole,ascii_control,wide]
(lab/'representative.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(*(c['id'] for c in old['cases']),sep='\n')
