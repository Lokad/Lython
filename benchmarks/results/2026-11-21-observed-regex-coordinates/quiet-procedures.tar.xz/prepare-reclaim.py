from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

repo=Path.cwd()
lab=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()

def canonical(path):
    return subprocess.check_output(['git','show','HEAD:'+path],cwd=repo)

def archive(relative, root):
    name=relative+'/observations.tgz'
    raw=canonical(name)
    receipt=json.loads(canonical(relative+'/archive-receipt.json'))
    assert receipt['archiveSHA256']==sha(raw) and all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    return root+'/observations.tgz',name,raw

parser='benchmarks/results/2026-11-21-parser-endpoint-spans'
parser_core=parser+'/candidate-core.dll.gz'
image=gzip.decompress(canonical(parser_core))
roots=[(parser,'parser-endpoint-spans-b1268-20261121'),
       ('benchmarks/results/2026-11-21-abstract-binding-map','abstract-binding-map-b1269-20261121'),
       ('benchmarks/results/2026-11-21-sparse-abstract-invalidation','sparse-abstract-invalidation-b1270-20261121')]
verified={}
for relative,root in roots:
    remote,_,raw=archive(relative,root)
    verified[remote]=sha(raw)
proofs=[dict(archives=verified,paths=[root+'/'+role+'/Lokad.Lython.dll' for (_,root),role in zip(roots,('candidate','reference','reference'),strict=True)],
    bytes=len(image),links=3,sha256=sha(image),verifiedCanonicalGitImage=parser_core)]
for relative,root in [roots[2],('benchmarks/results/2026-11-21-cpython-compiler-checkpoint','compiler-checkpoint-cpython-b1271-20261121')]:
    remote,name,raw=archive(relative,root)
    member='confirmation/confirmation.json'
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
        observed=tar.extractfile(member).read()
    proofs.append(dict(archives={remote:sha(raw)},paths=[root+'/'+member],bytes=len(observed),links=1,
                       sha256=sha(observed),verifiedCanonicalGitArchive=name))
(lab/'reclaim-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
print(sum(p['bytes'] for p in proofs))
