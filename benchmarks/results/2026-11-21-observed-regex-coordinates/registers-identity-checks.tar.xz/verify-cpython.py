from pathlib import Path
import hashlib,json,os,shutil,subprocess
notes=Path('.git/agent-notes/review-20261031')
prior=notes/'observed-regex-coordinates'
lab=notes/'regex-regs-identity'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reference=load(prior/'identity.json')['imageFiles']['reference']
assert len(reference)==32
ref=prior/'frozen/reference'
image=lab/'candidate'
image.mkdir()
for name,digest in reference.items():
    assert sha(ref/name)==digest
    source=Path('.git/agent-worktrees/pinned-unicode-casing-20261121/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll') if name=='Lokad.Lython.dll' else ref/name
    shutil.copyfile(source,image/name)
actual={name:sha(image/name) for name in reference}
assert [name for name in reference if reference[name]!=actual[name]]==['Lokad.Lython.dll']
(lab/'candidate-image.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
receipt=lab/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',prior/'identity-probe.json','--dotnet',dotnet,
 '--python','C:/Python313/python.exe','--python-worker','benchmarks/cpython-worker.py','--out',receipt],check=True,timeout=50,env=env)
assert load(receipt)['state']=='Completed'
assert {name:sha(image/name) for name in reference}==actual
