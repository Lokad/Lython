from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=[{'commit': 'ec6c041672a5e6edf85676bfe2442cd62abe1b76', 'canonicalArchive': 'benchmarks/results/2026-11-15-closed-word-segment/completed-layout/observations.tgz', 'remoteRoot': 'word-segment-b767-20261115', 'archiveSHA256': '1b59f26e7b894e1bff24ffd1a04525ea6b172dd11f4f60be83900751f6ff1e01', 'member': 'confirmation/confirmation.json', 'bytes': 566657, 'sha256': '435d7ed53f1f3edfa716bc0ac6be871f81e0dc7f91fe1fd34162a37b13f0233d'}]
required=17057
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b768-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
