from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / "comparison"
quiet = comparison / "quiet"
dest = repo / "benchmarks/results/2026-11-23-exact-short-decimal"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = read(comparison / "identity.json")
terminal = read(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((quiet / "observations.tar.xz").read_bytes()) == terminal["receipt"]["archiveSHA256"]
assert read(quiet / "summary.json")["timedBatches"] == 168
assert read(lab / "corpus-check.json")["Matches"]
suffix = lab / "exponent-control"
exponent = read(suffix / "terminal-status.json")
assert exponent["exitCode"] == "0" and exponent["receipt"]["archivedAndVerifiedUnderLease"]
assert sha((suffix / "observations.tar.xz").read_bytes()) == exponent["receipt"]["archiveSHA256"]
assert read(suffix / "summary.json")["timedBatches"] == 56
assert read(suffix / "identity.json")["imageFiles"] == identity["imageFiles"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32
    for name, digest in files.items():
        assert sha((lab / role / name).read_bytes()) == digest
core = (lab / "candidate/Lokad.Lython.dll").read_bytes()
dest.mkdir(exist_ok=True)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, encoding="utf-8").strip()
present = not subprocess.check_output(["git", "diff", "--name-only", head, identity["candidate"], "--", "src"], cwd=repo)
source = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"],
    identity["candidate"], "--", "src", "tests"], cwd=repo)
(lab / "comparison/production.patch").write_bytes(source)
(dest / "identity.json").write_text(json.dumps(dict(identity, retainedRevision=head if present else None,
    productionPatchSHA256=sha(source)),
    indent=2) + "\n", encoding="utf-8", newline="\n")
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(quiet / file, dest / file)
shutil.copyfile(lab / "allocation-summary-six.json", dest / "allocation-summary.json")
for file in ("terminal-status.json", "observations.tar.xz", "summary.json"):
    shutil.copyfile(suffix / file, dest / ("exponent-" + file))
shutil.copyfile(lab / "fixture-numeric-coverage.json", dest / "fixture-numeric-coverage.json")
(dest / "candidate-core.dll.gz").write_bytes(gzip.compress(core, mtime=0))
with tarfile.open(dest / "procedures.tar.xz", "w:xz") as archive:
    for file in ("archive.py", "freeze.py", "stage.py", "quiet.py", "summarize.py", "allocations.py",
            "test-platform.py", "rounding-golden.py", "expected-rounding.txt", "corpus.py", "corpus-check.json",
            "probe-build.log", "freeze-build.log", "failure-inventory.log",
            "windows-white.log", "windows-public.log", "ubuntu-white.log", "ubuntu-public.log",
            "reference-allocation-six.json", "candidate-allocation-six.json",
            "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/production.patch",
            "comparison/quiet/launch.log", "comparison/quiet/observe-not-before",
            "comparison/quiet/staging.log", "comparison/quiet/staging-first.log",
            "exponent-control/reference-verify.json", "exponent-control/candidate-verify.json",
            "exponent-control/verify.py", "exponent-control/quiet.py", "exponent-control/summarize.py",
            "exponent-control/launch.log", "exponent-control/observe-not-before"):
        archive.add(lab / file, arcname=file, recursive=False)
assert sha(gzip.decompress((dest / "candidate-core.dll.gz").read_bytes())) == identity["coreSHA256"]["candidate"]
print(dest, "retained" if present else "private")
