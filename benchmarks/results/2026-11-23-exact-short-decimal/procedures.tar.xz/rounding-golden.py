import csv
import struct
text = '+.5,-0.,0.1,1.23456789012345,9007199254740992,9007199254740993,0.0000000000000001'
builtin = [struct.pack('>d', float(value)).hex() for value in text.split(',')]
row = next(csv.reader([text], quoting=csv.QUOTE_NONNUMERIC))
parsed = [struct.pack('>d', value).hex() for value in row]
print(*builtin)
print(*parsed)
