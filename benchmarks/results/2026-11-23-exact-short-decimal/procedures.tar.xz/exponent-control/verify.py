from pathlib import Path
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[4]
base=lab.parent
identity=json.loads((base/"comparison/identity.json").read_text(encoding="utf-8"))
dotnet=Path.home()/".dotnet11/dotnet.exe"
python=Path("C:/Python313/python.exe")
protocol=repo/"benchmarks/cpython-worker.py"
digest=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
catalog=lab/"representative.json"
identity["catalogs"]={name:dict(sha256=digest(lab/name)) for name in ("representative.json","jobs.json")}
(lab/"identity.json").write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8",newline="\n")
assert digest(protocol)==identity["cpythonWorkerSHA256"]
for role, files in identity["imageFiles"].items():
    image=base/role
    assert {name:digest(image/name) for name in files}==files
    receipt=lab/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",receipt],
        env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent)),check=True,timeout=65)
    info=json.loads(receipt.read_text(encoding="utf-8"))
    assert info["state"]=="Completed" and info["caseCount"]==2 and info["catalogSha256"]==digest(catalog)
    assert info["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
    assert {name:digest(image/name) for name in files}==files
