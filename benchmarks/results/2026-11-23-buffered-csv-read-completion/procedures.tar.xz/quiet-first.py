from pathlib import Path
import datetime
import gzip
import hashlib
import io
import tarfile
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
quiet=lab/"comparison/quiet"
configuration=json.loads((quiet/"upload.json").read_text(encoding="utf-8"))
remote="/home/lokad/lython-bench-checks"
unit="lython-b1479-buffered-csv-read-completion-20261123"
host="lokad@20.166.121.73"
key=Path.home()/".ssh/id_lython-bench.pem"
common=["-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=15"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*common,host,"python3 -"]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*common]
configuration["retire"] = []
for directory, root in (
    ("inline-aggregate-tuples", "inline-aggregate-tuples-b1475-20261123"),
):
    archive_path = f"benchmarks/results/2026-11-23-{directory}/"
    def git_archive(name):
        return subprocess.check_output(["git", "show", "origin/master:" + archive_path + name], cwd=lab.parents[3])

    recorded_source = json.loads(git_archive("identity.json"))
    recorded_status = json.loads(git_archive("terminal-status.json"))
    reference_core = gzip.decompress(git_archive("candidate-core.dll.gz"))
    archived_observations = git_archive("observations.tar.xz")
    core_sha = hashlib.sha256(reference_core).hexdigest()
    observations_sha = hashlib.sha256(archived_observations).hexdigest()
    assert core_sha == recorded_source["coreSHA256"]["candidate"]
    assert observations_sha == recorded_status["receipt"]["archiveSHA256"]
    configuration["retire"].append(dict(root=root, coreSHA256=core_sha, coreBytes=len(reference_core),
                                         archiveSHA256=observations_sha))
# These working profile files already exist in the retained verified archive.
profile_path = "benchmarks/results/2026-11-23-retained-csv-text-cpu/"
git_profile = lambda name: subprocess.check_output(["git","show","origin/master:"+profile_path+name],cwd=lab.parents[3])
profile_archive = git_profile("observations.tar.xz")
profile_status = json.loads(git_profile("terminal-status.json"))
profile_sha = hashlib.sha256(profile_archive).hexdigest()
assert profile_status["exitCode"] == "0" and profile_status["receipt"]["archiveSHA256"] == profile_sha
with tarfile.open(fileobj=io.BytesIO(profile_archive)) as archived:
    profile_members = {m.name: hashlib.sha256(archived.extractfile(m).read()).hexdigest() for m in archived
                       if m.isfile() and m.name.startswith("profiles/") and m.size >= 32 * 1024}
assert len(profile_members) >= 6
configuration["retireProfiles"] = dict(root="retained-csv-text-cpu-b1473-20261123",
    unit="lython-b1473-retained-csv-text-cpu-20261123.service", archiveSHA256=profile_sha,
    members=profile_members)
configuration["unit"]=unit
configuration["remote"]=remote
prefix="from pathlib import Path\nimport fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile,tempfile\nconfiguration="+repr(configuration)+"\nbase=Path(configuration['remote']).resolve()\nroot=base/configuration['root']\nunit=configuration['unit']\n"
now=lambda:datetime.datetime.now(datetime.timezone.utc)

def invoke(script):
    result=subprocess.run(ssh,input=prefix+script,encoding="utf-8",capture_output=True,timeout=35)
    assert result.returncode==0,(result.stdout,result.stderr)
    return result.stdout

if sys.argv[1]=="launch":
    payload=quiet/"payload.tar.gz"
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration["payloadSHA256"]
    uploaded=remote+"/.+b1479-"+configuration["payloadSHA256"][:12]+".tar.gz"
    if sys.argv[2:] != ["already-uploaded"]:
        subprocess.run(scp+[payload,host+":"+uploaded],check=True,timeout=35)
    receipt=invoke("payload=Path("+repr(uploaded)+")\n"+"""digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
reference=base/configuration['reference']
marker=reference/'archive-receipt.json'
donor=json.loads(marker.read_text())
assert donor['complete'] and digest(reference/'observations.tar.xz')==donor['archiveSHA256']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 free=shutil.disk_usage(base).free
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 with tempfile.TemporaryDirectory(prefix='lython-b1479-stage-', dir='/dev/shm') as spool_folder:
  spool=Path(spool_folder)/'upload.tar.gz'
  shutil.copyfile(payload,spool)
  assert digest(spool)==configuration['payloadSHA256']
  payload.unlink()
  free=shutil.disk_usage(base).free
  # Five bounded lanes write under 1 MiB of receipts. A 120 MiB
  # workspace margin covers that and keeps the frozen images.
  minimum_active = 120 * 1024 * 1024
  block = os.statvfs(base).f_frsize
  with tarfile.open(spool) as package:
   assert all(member.isfile() for member in package.getmembers())
   staged_bytes = sum(((member.size+block-1)//block)*block for member in package.getmembers())
  minimum = minimum_active + staged_bytes + 1024 * 1024
  if free < minimum:
   retire=[]
   for archived in configuration['retire']:
    obsolete=base/archived['root']
    assert obsolete != reference and obsolete.is_relative_to(base)
    assert digest(obsolete/'observations.tar.xz')==archived['archiveSHA256']
    duplicate=obsolete/'candidate/Lokad.Lython.dll'
    observation=duplicate.lstat()
    assert duplicate.resolve()==duplicate and duplicate.is_relative_to(obsolete) and stat.S_ISREG(observation.st_mode)
    assert observation.st_uid==os.getuid() and observation.st_nlink==1 and observation.st_size==archived['coreBytes']
    assert digest(duplicate)==archived['coreSHA256']
    retire.append((duplicate, observation.st_blocks*512))
    if free+sum(byte_count for _,byte_count in retire)>=minimum:
     break
   if free+sum(byte_count for _,byte_count in retire)<minimum:
    archived=configuration['retireProfiles']
    obsolete=base/archived['root']
    assert obsolete.is_relative_to(base) and obsolete != reference
    assert digest(obsolete/'observations.tar.xz')==archived['archiveSHA256']
    status=subprocess.check_output(['systemctl','show',archived['unit'],'--property=ActiveState,MainPID'])
    assert b'ActiveState=inactive' in status and b'MainPID=0' in status
    for member,sha in archived['members'].items():
     duplicate=obsolete/member
     if not duplicate.exists(): continue
     observation=duplicate.lstat()
     assert duplicate.resolve()==duplicate and duplicate.is_relative_to(obsolete/'profiles')
     assert stat.S_ISREG(observation.st_mode) and observation.st_uid==os.getuid() and observation.st_nlink==1
     assert digest(duplicate)==sha
     retire.append((duplicate, observation.st_blocks*512))
     if free+sum(byte_count for _,byte_count in retire)>=minimum:
      break
   assert free+sum(byte_count for _,byte_count in retire)>=minimum
   for duplicate,_ in retire:
    duplicate.unlink()
    print('Retired verified archived working copy '+str(duplicate),flush=True)
   free=shutil.disk_usage(base).free
  assert free >= minimum,(free,'needs one core, publication archive and working-room floor')
  root.mkdir()
  with tarfile.open(spool) as archive:
   assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll'}
   archive.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text())
 assert {label:list(files) for label,files in identity['imageFiles'].items()} == {
   'reference':list(identity['imageFiles']['reference']), 'candidate':list(identity['imageFiles']['reference'])}
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 image=root/'candidate';image.mkdir()
 for name,sha in identity['imageFiles']['reference'].items():
  src=reference/'candidate'/name
  assert digest(src)==sha, name
  if name!='Lokad.Lython.dll':
   assert sha==identity['imageFiles']['candidate'][name]
   os.link(src,image/name)
 core=image/'Lokad.Lython.dll'
 (root/'candidate-core.dll').rename(core)
 assert identity['imageFiles']['candidate'][core.name]==digest(core)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 assert shutil.disk_usage(base).free >= minimum_active + 1024 * 1024
 print(json.dumps(dict(freeBefore=free,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=290','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
""")
    (quiet/"launch.log").write_text(receipt,encoding="utf-8")
    started=now()
    (quiet/"observe-not-before").write_text((started+datetime.timedelta(seconds=247)).isoformat(),encoding="utf-8")
    print(receipt, unit)
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((quiet/"observe-not-before").read_text(encoding="utf-8"))
    state=invoke("""
service=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  outcome=(root/'exit-code.txt')
  receipt=(root/'archive-receipt.json')
  print(json.dumps(dict(live=False,service=service,exitCode=outcome.read_text().strip() if outcome.exists() else None,
  receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
  journal=subprocess.run(['journalctl','-u',unit+'.service','-n','36','--no-pager'],capture_output=True,text=True).stdout)))
""")
    result=json.loads(state)
    (quiet/("status-"+now().strftime("%H%M%S")+".json")).write_text(state,encoding="utf-8")
    if not result["live"] and result["receipt"] is not None:
        name="observations.tar.xz"
        archive=quiet/name
        subprocess.run(scp+[host+":"+remote+"/"+configuration["root"]+"/"+name,archive],check=True,timeout=35)
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==result["receipt"]["archiveSHA256"]
        (quiet/"terminal-status.json").write_text(state,encoding="utf-8")
        assert not result["fixtures"] and result["exitCode"]=="0" and result["receipt"]["complete"],state
    print(state)
