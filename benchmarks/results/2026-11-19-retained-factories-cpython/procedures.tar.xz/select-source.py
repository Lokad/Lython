from pathlib import Path
import ast
import sys

lab=Path(__file__).resolve().parent
prior=lab.parent/'token-source-cpython-b1106'
keep_trim=sys.argv[1]=='trim'
assert keep_trim or sys.argv[1]=='capture'
source=(prior/'prepare.py').read_text(encoding='utf-8-sig')
source=source.replace("prior = lab.parent / 'retained-defaults-cpython-b1102'","prior = lab.parent / 'token-source-cpython-b1106'")
source=source.replace("donor = lab.parent / 'token-source-transport-r673'","donor = lab.parent / '"+("trim-range-split-r676" if keep_trim else "standalone-capture-prefix-r675")+"'")
source=source.replace("'27f68744b'","'"+("3e67fd010" if keep_trim else "9407f4fb7")+"'")
a=source.index("catalog = load(donor/'catalog.json')")
b=source.index("save('representative.json', catalog)",a)
source=source[:a]+"""catalog = load(lab.parent/'standalone-capture-prefix-r675/catalog.json')
selected = {'scripts.captured-rule-closures','scripts.retained-nonlocal-factories',
            'scripts.rule-default-closures','scripts.report-forwarding.expanded'}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in selected]
assert {case['id'] for case in catalog['cases']} == selected
"""+source[b:]
source=source.replace('B1106 validator and manifest after token-source preparation against CPython','B1109 retained factory workloads and forwarding against CPython')
source=source.replace('token-source-cpython-b1106-20261119','retained-factories-cpython-b1109-20261119')
source=source.replace('b1106-token-source-cpython','b1109-retained-factories-cpython')
source=source.replace("replace('B1102','B1106')","replace('B1106','B1109')")
source=source.replace("'        lanes = [\"compile-run\", \"compile\"]'","'        lanes = [\"warm\", \"compile-run\", \"compile\"]'")
source=source.replace('"len(raw[\'jobs\'])==7","len(raw[\'jobs\'])==2"','"len(raw[\'jobs\'])==2","len(raw[\'jobs\'])==4"')
source=source.replace("'jobs=7,','jobs=2,'","'jobs=2,','jobs=4,'")
source=source.replace("assert \"len(raw['jobs'])==2\" in source and 'jobs=2,' in source",
                      "assert \"len(raw['jobs'])==4\" in source and 'jobs=4,' in source")
source=source.replace('"[\'jobs\']==7","[\'jobs\']==2"','"[\'jobs\']==2","[\'jobs\']==4"').replace("assert \"['jobs']==2\"","assert \"['jobs']==4\"")
source=source.replace("source.replace('520','115')","source.replace('115','300')").replace('timedelta(seconds=115)','timedelta(seconds=300)')
source=source.replace("assert receipt['freeBytesAfterArchive'] >","assert load(lab.parent/'trim-range-split-r676/quiet/archive-receipt.json')['freeBytesAfterArchive'] >")
source=source.replace("launcher.replace('lython-b1102-fixtures','lython-b1106-fixtures')","launcher.replace('lython-b1106-fixtures','lython-b1109-fixtures')")
source=source.replace('two CPython goldens and both compile boundaries','four CPython goldens and three execution boundaries')
ast.parse(source)
(lab/'prepare.py').write_text(source,encoding='utf-8',newline='\n')
