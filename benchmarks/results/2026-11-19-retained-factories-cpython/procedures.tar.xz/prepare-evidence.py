from pathlib import Path
import ast

lab=Path(__file__).resolve().parent
original=(lab.parent/'token-source-cpython-b1106/collect-evidence.py').read_text(encoding='utf-8')
source=original.replace('2026-11-19-token-source-cpython','2026-11-19-retained-factories-cpython')
source=source.replace('receipt["jobs"] == 2','receipt["jobs"] == 4').replace('len(cases) == 2','len(cases) == 4')
source=source.replace('tuple(lanes) == ("compile-run", "compile")','tuple(lanes) == ("warm", "compile-run", "compile")')
source=source.replace('assert len(rows) == 4','assert len(rows) == 12')
source=source.replace('B1106','B1109').replace('verifiedBatches=80','verifiedBatches=240')
ast.parse(source)
(lab/'collect-evidence.py').write_text(source,encoding='utf-8',newline='\n')
