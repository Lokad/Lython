set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/packed-eager-annotation-reads
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Annotation|FullyQualifiedName~Operand|FullyQualifiedName~Closure)' > "$logs/rebased-white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Annotation|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Closure|FullyQualifiedName~Decorator|FullyQualifiedName~GovernedMemoryContract)' > "$logs/rebased-public-ubuntu.log" 2>&1
if command -v rg >/dev/null; then
    rg 'Passed!' "$logs/rebased-white-ubuntu.log" "$logs/rebased-public-ubuntu.log"
else
    grep 'Passed!' "$logs/rebased-white-ubuntu.log" "$logs/rebased-public-ubuntu.log"
fi
