from pathlib import Path
import json

lab = Path(__file__).resolve().parent
data = json.loads((lab / "quiet/quiet-summary.json").read_text(encoding="utf-8"))
decision = json.loads((lab / "decision.json").read_text(encoding="utf-8"))["decision"]
names = ["Eager rules", "Eager nested factories", "Postponed nested factories",
         "Fully supplied helper", "Read every annotation dictionary", "Eager rules"]

def bounds(values):
    return " to ".join(f"{value:+.2f}%".replace("-", "−") for value in (min(values), max(values)))

intro = """# B1290 packed eager annotation reads

The prototype replaces a group of constant and global annotation loads
with one operation that writes into the final annotation record. The
group admits that record and the callable together after decorators and
defaults, before the first annotation read. This can refuse earlier.
The defining operands own the unpublished record until the callable
takes it. General expressions keep their original suspension route.

The three eager fixtures each replace four read instructions with one,
and the defining helper's workspace drops from eight to six slots.
The postponed and fully supplied controls keep the same tape shape.
Local warm CLR allocation is effectively flat. All accounted peaks
match, and the shared allowance returns to baseline in every case.

Reference `256c5e651` and prototype `abf417f58` ran on the quiet Azure
F4as_v7 with Ubuntu 24.04.4 and .NET 11 RC3 on November 21, 2026 UTC.
Each lane uses two independently warmed processes per source and seven
rotated batches per process. Ranges cover the four pairings of process
medians. Warm elapsed includes execution and prior-result disposal.
Time to result includes compilation and code-owner disposal as well.
Process CPU covers the wider request. Startup and final teardown are
outside these clocks.

| Complete script | Boundary | Elapsed change | Process CPU change | Reference / candidate elapsed spread |
| --- | --- | ---: | ---: | ---: |
"""
table = "\n".join(f"| {name} | {row['lane']} | {bounds(row['elapsedChangePercent'])} | "
                  f"{bounds(row['cpuChangePercent'])} | {row['referenceSpreadPercent']:.2f}% / "
                  f"{row['candidateSpreadPercent']:.2f}% |"
                  for name, row in zip(names, data["rows"], strict=True))
end = """
""" + decision + """

Windows .NET 11 and Ubuntu .NET 10 each pass 363 white-box and 455
public Release checks. The new failed-read regression preserves the
name-error span and refunds the unpublished definition. Its first
local fixture set the alias on the wrong namespace. The next corrected
the namespace and exposed a CRLF offset mismatch in the test assertion.
The final fixture uses the defining namespace and normalized line
endings. The original test output is preserved.
Both complete frozen images match five CPython goldens. All 168 timed
batches and both quiet gates pass. Workers join and the persistent
archive verifies under the lease after guest fixtures are removed.

[Timing summary](summary.json) · [Compiler shape](annotation-shape.json) ·
[Local warm allocation](local-allocations.json) · [Raw observations](observations.tgz) ·
[Source, tests and procedures](checks-and-procedures.tar.xz).
"""
(lab/"README.md").write_text(intro + table + "\n" + end,
                            encoding="utf-8", newline="\n")
