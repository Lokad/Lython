from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / "abstract-fork-sharing"
prior = donor / "quiet"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

rebased = repo / ".git/agent-worktrees/pinned-unicode-casing-20261121"
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=rebased, text=True).strip()
assert revision.startswith("abf417f58")
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=rebased)
production = subprocess.check_output(["git", "rev-parse", revision + "^"], cwd=rebased, text=True).strip()
assert production.startswith("256c5e651")
candidate = rebased / "src/Lokad.Lython/bin/Release/net11.0" / core
for suite, count in (("white", 363), ("public", 455)):
    log = (lab / f"rebased-{suite}-win.log").read_text(encoding="utf-8-sig")
    assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log

config = load(prior / "config.json")
receipt = load(prior / "archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
reference = config["identity"]["imageFiles"]["reference"]
assert len(reference) == 32 and {name: sha(donor / "quiet-workers/reference" / name) for name in reference} == reference
library = reference[core]
assert hashlib.sha256(gzip.decompress((repo / "benchmarks/results/2026-11-21-cpython-current-factories/measured-core.dll.gz").read_bytes())).hexdigest() == library
# Only this single recoverable B1289 worker file may be retired under the lease.
archive = "benchmarks/results/2026-11-21-abstract-fork-sharing"
known_core = subprocess.check_output(["git", "show", "c67b28f80:" + archive + "/candidate-core.dll.gz"], cwd=repo)
known_raw = subprocess.check_output(["git", "show", "c67b28f80:" + archive + "/observations.tgz"], cwd=repo)
removed = gzip.decompress(known_core)
removed_hash = hashlib.sha256(removed).hexdigest()
raw_hash = hashlib.sha256(known_raw).hexdigest()
assert raw_hash == receipt["archiveSHA256"] == sha(prior / "observations.tgz")
assert removed_hash == config["identity"]["imageFiles"]["candidate"][core]
retire = [dict(paths=[Path(config["root"]).name + "/candidate/" + core], links=1, bytes=len(removed),
               sha256=removed_hash, archives={Path(config["root"]).name + "/observations.tgz": raw_hash},
               optional=False)]

quiet.mkdir()
manifest = quiet / "representative.json"
shutil.copyfile(lab / "representative.json", manifest)
cases = load(manifest)["cases"]
jobs = [('scripts.annotated-rule-closures', 'warm'), ('scripts.annotated-rule-closures.nested-factories', 'warm'), ('scripts.annotated-rule-closures.nested-factories.postponed', 'warm'), ('scripts.ordinary-fully-supplied-helper', 'warm'), ('scripts.annotated-rule-closures.observed', 'warm'), ('scripts.annotated-rule-closures', 'compile-run')]
assert len(jobs) == 6
images = {"reference": reference, "candidate": reference | {core: sha(candidate)}}
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == config["protocolSHA256"]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
python = Path(shutil.which("python.exe")).resolve()
for role, expected in images.items():
    destination = lab / "quiet-workers" / role
    destination.mkdir(parents=True)
    for name in reference:
        path = candidate if role == "candidate" and name == core else donor / "quiet-workers/reference" / name
        shutil.copyfile(path, destination / name)
    proof = lab / f"quiet-{role}-verify.json"
    subprocess.run([dotnet, destination / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", manifest, "--dotnet", dotnet, "--python", python, "--python-worker", protocol,
                    "--out", proof], env=env, check=True)
    assert {f.name: sha(f) for f in destination.iterdir()} == expected
    assert load(proof)["state"] == "Completed" and load(proof)["caseCount"] == 5
    assert load(proof)["catalogSha256"] == sha(manifest)

root = "/home/lokad/lython-bench-checks/packed-eager-annotation-reads-b1290-20261121"
unit = "lython-b1290-packed-annotation-reads-20261121"
identity = dict(sourceRevision=production + " versus " + revision, purpose="Pack eager annotation reads into the admitted record",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    src = (prior / name).read_text(encoding="utf-8").replace(config["root"], root).replace(config["unit"], unit)
    if name == "collect.py":
        begin = src.index("\njobs = ")
        end = src.index("\nassert len(jobs)", begin)
        src = src[:begin] + "\njobs = " + repr(jobs) + src[end:]
    if name == "collect.py":
        src = src.replace("len(jobs)==5", "len(jobs)==6")
    if name == "archive-owned.py":
        src = src.replace("len(raw['jobs'])==5", "len(raw['jobs'])==6").replace("jobs=5,", "jobs=6,")
    if name == "retrieve.py":
        src = src.replace("['jobs']==5", "['jobs']==6")
    emit(quiet / name, src)
assert b"\r" not in (quiet / "run.sh").read_bytes()

# The post-staging archive has used less than one MiB in prior runs.
# Keep two MiB for trial overhead in addition to the existing floor.
payload = quiet / "payload.tgz"
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
(quiet / "candidate").mkdir()
shutil.copyfile(candidate, quiet / "candidate" / core)
assert sha(quiet / "candidate" / core) == images["candidate"][core]
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=config["root"], sourceRole="reference", sourceFiles=reference,
             sourceCatalogSHA256=config["catalogSHA256"], donorArchiveSHA256=raw_hash,
             protocolSource=config["root"] + "/cpython-worker.py", protocolSHA256=sha(protocol),
             payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), retireGroups=retire,
             catalogSHA256=sha(manifest), unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", stage)
src = (prior / "remote-launch.py").read_text(encoding="utf-8")
begin, end = src.index("\nc=") + 1, src.index("\nb=Path(")
src = src[:begin] + "c=" + repr(stage) + src[end:]
src = src.replace("lython-b1289-fixtures", "lython-b1290-fixtures")
assert "c['unpackedBytes']+3*1024*1024" in src
src = src.replace("c['unpackedBytes']+3*1024*1024", "c['unpackedBytes']+2*1024*1024")
emit(quiet / "remote-launch.py", src)
emit(lab / "launch.py", (donor / "launch.py").read_text(encoding="utf-8")
     .replace("Abstract branch sharing comparison", "Packed annotation read comparison")
     .replace("355", "410"))
emit(lab / "summarize.py", (donor / "summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==5", "len(raw['jobs'])==6"))
print(f"Prepared verified images and six lanes with {stage['unpackedBytes']} bytes to stage.")
