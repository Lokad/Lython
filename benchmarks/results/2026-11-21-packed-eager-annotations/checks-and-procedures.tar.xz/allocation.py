from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path('.git/agent-notes/review-20261031/packed-eager-annotation-reads').resolve()
donor=lab.parent/"joint-lexical-admission-on-current/frozen/reference"
ident=json.loads((lab/"quiet/identity.json").read_bytes())
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
catalog=lab/"representative.json"
assert hashlib.sha256(catalog.read_bytes()).hexdigest()==ident["catalogSHA256"]
summaries=[]
for role in ("reference","candidate"):
    worker=lab/"quiet-workers"/role
    probe_image=lab/"allocation-workers"/role
    probe_image.mkdir(parents=True)
    for name,h in ident["imageFiles"][role].items():
        shutil.copyfile(worker/name,probe_image/name)
        assert hashlib.sha256((probe_image/name).read_bytes()).hexdigest()==h
    for path in donor.glob("ValidatedAllocation.*"):
        shutil.copyfile(path,probe_image/path.name)
    out=lab/f"{role}-allocation.json"
    subprocess.run([sdk/"dotnet.exe",probe_image/"ValidatedAllocation.dll",probe_image,catalog,out],
                   check=True,env=env,timeout=120)
    rows=json.loads(out.read_bytes())["rows"]
    assert all(row["sharedBudgetBaselineRestored"] for row in rows)
    summaries.append(rows)
rows=[]
for left,right in zip(*summaries,strict=True):
    assert left["id"]==right["id"]
    before,after=(statistics.median(r["allocatedBytesPerInvocation"]) for r in (left,right))
    rows.append(dict(case=left["id"],referenceAllocation=before,candidateAllocation=after,
                     allocationChangePercent=100*(after/before-1),referenceAccountedPeak=left["peakExecutionMemoryBytes"],
                     candidateAccountedPeak=right["peakExecutionMemoryBytes"],budgetReturnedToBaseline=True))
    print(rows[-1])
(lab/"allocation-summary.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
