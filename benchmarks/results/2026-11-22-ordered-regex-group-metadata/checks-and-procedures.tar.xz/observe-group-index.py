import re
count=0
metadata=0
rule=re.compile(r'T00:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T00:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T01:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T01:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T02:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T02:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T03:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T03:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T04:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T04:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T05:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T05:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T06:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T06:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T07:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T07:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T08:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T08:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T09:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T09:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T10:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T10:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T11:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T11:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T12:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T12:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T13:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T13:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T14:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T14:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T15:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T15:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T16:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T16:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T17:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T17:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T18:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T18:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T19:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T19:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T20:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T20:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T21:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T21:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T22:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T22:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T23:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T23:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T24:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T24:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T25:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T25:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T26:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T26:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T27:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T27:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T28:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T28:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T29:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T29:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T30:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T30:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T31:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T31:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T32:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T32:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T33:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T33:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T34:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T34:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T35:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T35:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T36:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T36:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T37:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T37:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T38:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T38:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T39:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T39:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T40:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T40:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T41:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T41:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T42:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T42:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T43:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T43:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T44:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T44:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T45:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T45:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T46:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T46:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T47:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T47:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T48:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T48:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T49:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T49:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T50:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T50:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T51:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T51:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T52:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T52:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T53:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T53:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T54:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T54:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T55:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T55:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T56:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T56:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T57:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T57:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T58:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T58:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T59:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T59:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T60:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T60:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T61:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T61:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T62:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T62:équipe:ready').group('state') == 'ready': count += 1
rule=re.compile(r'T63:(?P<équipe>[a-zé]+):(?P<state>[a-z]+)')
metadata += rule.groupindex['équipe'] + rule.groupindex['state']
if rule.fullmatch('T63:équipe:ready').group('state') == 'ready': count += 1
print(count)
print(metadata)
