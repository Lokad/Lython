#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/ordered-regex-group-metadata-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/ordered-regex-group-metadata-20261122
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)' --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -40 "$logs/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)' --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -40 "$logs/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
