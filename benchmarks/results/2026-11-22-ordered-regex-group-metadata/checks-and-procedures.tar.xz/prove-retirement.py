from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('.git/agent-notes/review-20261031/ordered-regex-group-metadata-20261122').resolve()
repo=r.parents[3]
config=json.loads((r.parent/'compiled-value-captures-20261122/quiet/config.json').read_text(encoding='utf-8'))
receipt=json.loads((r.parent/'compiled-value-captures-20261122/quiet/archive-receipt.json').read_text(encoding='utf-8'))
prefix='benchmarks/results/2026-11-22-compiled-value-captures/'
core=gzip.decompress(subprocess.check_output(['git','show','origin/master:'+prefix+'candidate-core.dll.gz'],cwd=repo))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(core)==config['identity']['imageFiles']['candidate']['Lokad.Lython.dll']
name=Path(config['root']).name
proof=dict(paths=[name+'/candidate/Lokad.Lython.dll'],bytes=len(core),links=1,sha256=sha(core),
           archives={name+'/observations.tgz':receipt['archiveSHA256']},optional=False)
remote=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
p=PROOF
base=Path('/home/lokad/lython-bench-checks')
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    core=base/p['paths'][0]
    info=core.lstat()
    assert core.resolve()==core and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid()
    assert info.st_nlink==p['links'] and info.st_size==p['bytes']
    assert hashlib.sha256(core.read_bytes()).hexdigest()==p['sha256']
    assert all(hashlib.sha256((base/name).read_bytes()).hexdigest()==sha for name,sha in p['archives'].items())
    assert not (core.parents[1]/'guest-fixtures').exists()
    print(json.dumps(dict(free=shutil.disk_usage(base).free,verified=[p])))
""".replace('PROOF',repr(proof))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
actual=subprocess.check_output(ssh,input=remote,encoding='utf-8',timeout=35)
(r/'retire-inventory.json').write_text(actual,encoding='utf-8',newline='\n')
print(actual)

