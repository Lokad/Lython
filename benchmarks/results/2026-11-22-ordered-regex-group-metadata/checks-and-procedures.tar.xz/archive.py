from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
out=Path('benchmarks/results/2026-11-22-ordered-regex-group-metadata')
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
identity=load(quiet/'identity.json')
a,_,b=identity['sourceRevision'].split()
assert a.startswith('2d4fb517b') and b.startswith('72a458bc1')
for role,files in identity['imageFiles'].items():
    image=lab/'frozen'/role
    assert len(files)==32 and {n:sha(image/n) for n in files}==files
    assert sha(quiet/role/'Lokad.Lython.dll')==files['Lokad.Lython.dll']
    for prefix in ('','quiet-'):
        proof=load(lab/f'{prefix}{role}-verify.json')
        manifest=quiet/'representative.json' if prefix else lab/'representative.json'
        assert proof['state']=='Completed' and proof['caseCount']==5 and proof['catalogSha256']==sha(manifest)
for platform in ('win','ubuntu'):
    for suite,count in (('white',91),('public',608)):
        text=(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig')
        assert 'Passed!' in text and f'Passed: {count:5d}, Skipped:' in text
allocation=load(lab/'allocation-summary.json')
assert len(allocation)==5 and all(row['allowanceRestored'] for row in allocation)
desk=load(lab/'local-timing.json')
assert desk['identity']['imageFiles']==identity['imageFiles'] and len(desk['rows'])==3
for desktop in desk['rows']:
    assert all(len(samples)==5 for samples in desktop['samples'].values())
receipt=load(quiet/'archive-receipt.json')
terminal=load(quiet/'terminal-status.json')
assert receipt==terminal['receipt'] and terminal['exitCode']=='0'
assert not terminal['remainingTrace'] and not terminal['remainingWorkers']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease','quietBeforeAndAfter'))
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
raw=load(quiet/'retrieved/confirmation/confirmation.json')
assert raw['warmupSeconds']==12 and raw['targetBatchSeconds']==.65 and raw['rounds']==7
cases={c['id']:c for c in load(quiet/'representative.json')['cases']}
assert raw['complete'] and len(raw['jobs'])==receipt['jobs']==6 and len(cases)==5
assert [(job['case'],job['lane']) for job in raw['jobs']]==[(k,'warm') for k in cases]+[(list(cases)[0],'compile-run')]
for job in raw['jobs']:
    case=cases[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==28
    for sample in job['samples']:
        response=sample['response']
        assert response['completedInvocations']>0 and response['status']=='Completed'
        assert response['sourceSha256']==case['sourceSha256'] and response['fixtureSha256']==case['fixtureSha256']
        assert response['actualOutputSha256']==case['expectedOutputSha256']
        assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
summary=load(quiet/'quiet-summary.json')
del summary['retentionDecisionPending']
summary.update(collection='B1342',sourceRevision=identity['sourceRevision'],verifiedTimedBatches=168,
    coreSHA256=identity['coreSHA256'],archiveSHA256=receipt['archiveSHA256'],
    retentionDecision=load(lab/'decision.json')['decision'])
out.mkdir(exist_ok=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('README.md','allocation-summary.json','local-timing.json'):
    shutil.copyfile(lab/name,out/name)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
reference=Path('benchmarks/results/2026-11-22-complete-decimal-ascii/candidate-core.dll.gz')
assert gzip.decompress(reference.read_bytes())==(quiet/'reference/Lokad.Lython.dll').read_bytes()
core=(quiet/'candidate/Lokad.Lython.dll').read_bytes()
(out/'candidate-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
assert gzip.decompress((out/'candidate-core.dll.gz').read_bytes())==core
(lab/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff',a,b,'--','src','tests']))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for folder in (lab,quiet):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {'.dll','.tgz'}:
                archive.add(path,arcname=path.relative_to(lab).as_posix())
print('168 batches, frozen files, independent goldens and platform checks verified.')

