from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / 'benchmarks/results/2026-11-24-short-text-helper-cpu'


def read(name):
    return json.loads((lab / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = read('terminal-status.json')
receipt = report['receipt']
assert report['exitCode'] == '0' and not report['live'] and not report['fixtures']
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert sha(lab / 'observations.tar.xz') == receipt['archiveSHA256']
assert sha(lab / 'catalog.json') == read('identity.json')['profileCatalogSHA256']
rows = read('attribution.json')['rows']
assert [row['label'] for row in rows] == ['nonlocal-warm', 'width-in-caller-warm', 'inline-warm']
assert [row['invocations'] for row in rows] == [4736, 4864, 6144]
assert [row['exclusiveNearestRuntimeGroups']['entry and operand movement'] for row in rows] == [93, 83, 1]
dest.mkdir(exist_ok=True)
for name in ('observations.tar.xz', 'identity.json', 'terminal-status.json', 'attribution.json', 'verification.json'):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'prepare.py', 'analyze.py', 'quiet.py', 'collect.py', 'ops-profile.py',
                 'run.sh', 'inspect.py', 'inspector-identity.json', 'tapes.json', 'catalog.json',
                 'analysis.log', 'launch.log'):
        bundle.add(lab / name, arcname=name)
print(dest)
