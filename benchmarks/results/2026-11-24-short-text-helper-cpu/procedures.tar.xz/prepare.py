from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('current-short-text-cpu-20261123')
donor=lab.with_name('json-encoding-flags-20261124')
comparison=lab.with_name('json-text-cpython-20261124')/'external'
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, source):
    (lab/name).write_text(source,encoding='utf-8',newline='\n')


def save(name, data):
    write(name,json.dumps(data,indent=2,ensure_ascii=False)+'\n')


def adapt(name, edits):
    source=(prior/name).read_text(encoding='utf-8')
    for old,new in edits:
        assert source.count(old)==1,(name,old)
        source=source.replace(old,new)
    compile(source,name,'exec')
    write(name,source)


identity=read(comparison/'identity.json')
assert identity['sourceRevision'].startswith('eabbf02ed')
subprocess.run(['git','diff','--exit-code',identity['sourceRevision'],'HEAD','--','src','tests'],cwd=repo,check=True)
raw=donor/'comparison/quiet'
receipt=read(raw/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert digest(raw/'observations.tar.xz')==receipt['archiveSHA256']
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==checksum for name,checksum in identity['imageFiles']['candidate'].items())

catalog=read(lab.with_name('short-text-boundaries-20261123')/'catalog.json')
short,width,inline,*_=catalog['cases']
assert short['id']=='diagnostic.text-summary.nonlocal-computed-width.large'
assert width['id']=='diagnostic.text-summary.computed-width-in-caller'
assert inline['id']=='diagnostic.text-summary.without-per-line-helper'
for key in ('fixtureSha256','expectedOutputSha256','expectedFilesSha256'):
    assert short[key]==width[key]==inline[key]
identity['referenceTimingSHA256']=digest(comparison/'observations.tar.xz')
assert short==read(comparison/'representative.json')['cases'][1]
catalog['cases']=[short,width,inline]
save('catalog.json',catalog)
identity.update(purpose='B1556 attribute per-line helper execution with its nonlocal update isolated',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=digest(lab/'catalog.json'))
save('identity.json',identity)

adapt('collect.py',(
    ('combined-cased-split-cpython-b1539-20261123/candidate','json-encoding-flags-b1553-20261124/candidate'),
    ('b1540-fixtures','b1556-fixtures'),
    ('        time.sleep(3)\n        before', '        time.sleep(8)\n        before'),
    ('            time.sleep(3)\n            after', '            time.sleep(12)\n            after'),
))
adapt('quiet.py',(
    ('current-short-text-cpu-b1540-20261123','current-text-helper-cpu-b1556-20261124'),
    ('lython-b1540-current-short-text-cpu-20261123','lython-b1556-current-text-helper-cpu-20261124'),
    ('combined-cased-split-cpython-20261123/candidate','json-encoding-flags-20261124/candidate'),
    ('checked["caseCount"]==2','checked["caseCount"]==3'),
    ('RuntimeMaxSec=100','RuntimeMaxSec=125'),
    ('seconds=63','seconds=78'),
    ('the two exact short text source shapes','the three short text source shapes'),
))
adapt('ops-profile.py',(
    ("('inline-warm', 'diagnostic.text-summary.without-per-line-helper', 'warm')",
     "('width-in-caller-warm', 'diagnostic.text-summary.computed-width-in-caller', 'warm'), ('inline-warm', 'diagnostic.text-summary.without-per-line-helper', 'warm')"),
))
adapt('analyze.py',(
    ("['nonlocal-warm', 'inline-warm']","['nonlocal-warm', 'width-in-caller-warm', 'inline-warm']"),
))
shutil.copyfile(prior/'run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()
