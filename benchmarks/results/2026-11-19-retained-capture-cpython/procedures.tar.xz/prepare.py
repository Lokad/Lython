from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
lab=Path(__file__).resolve().parent
donor=lab.parent/'prepared-capture-slots-r624'
prior=lab.parent/'retained-selectors-cpython-r618'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
role, retained=sys.argv[1:]
assert role in ('candidate','reference')
frozen=donor/'frozen'/role
manifest=load(donor/'frozen-identity.json')
files=manifest['images'][role]
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
subprocess.run(['git','diff','--exit-code',manifest[role+'Commit'],retained,'--','src'],check=True)
catalog=lab/'representative.json'
data=load(prior/'representative.json')
capture_cases=[case for case in load(donor/'catalog.json')['cases'] if case['id'] in ('scripts.captured-rule-closures','scripts.mutable-rule-counters')]
assert len(capture_cases)==2
data['cases'].extend(capture_cases)
assert len({case['id'] for case in data['cases']})==7
catalog.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(lab/'runtime.json').write_text(json.dumps(dict(retained=retained,role=role),indent=2)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
print('Verified the retained runtime, complete worker image and seven external cases.')