from pathlib import Path
import ast,hashlib,json,re,tarfile
lab=Path(__file__).resolve().parent
donor=lab.parent/'prepared-capture-slots-r624'
phase=lab.parent/'retained-selectors-cpython-r618'
previous=donor/'quiet'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda value:hashlib.sha256(value).hexdigest()
def write(path,data):
    if path.suffix=='.py':ast.parse(data)
    path.write_text(data,encoding='utf-8',newline='\n')
def save(path,data):write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')

catalog=lab/'representative.json'
catalog_hash=sha(catalog.read_bytes())
cases=load(catalog)['cases']
assert len(cases)==7 and len({case['id'] for case in cases})==7
by_id={case['id']:case for case in cases}
assert all(by_id[case['id']]==case for case in load(phase/'representative.json')['cases'])
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash
old=load(previous/'config.json')
receipt=load(previous/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
runtime=load(lab/'runtime.json')
role=runtime['role']
files=old['identity']['imageFiles'][role]
assert len(files)==32
assert {name:sha((donor/'frozen'/role/name).read_bytes()) for name in files}==files

root='/home/lokad/lython-bench-checks/retained-capture-cpython-b1057-20261119'
unit='lython-b1057-retained-capture-cpython-20261119'
script_hash=sha(Path('benchmarks/cpython-worker.py').read_bytes())
assert script_hash==load(phase/'identity.json')['cpythonWorkerSHA256']
identity=dict(sourceRevision=runtime['retained'],
    purpose='Retained runtime and representative rule, forwarding, shipment and CSV workloads',
    imageFiles={'candidate':files},auxiliaryFiles={k:v for k,v in files.items() if k!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogSHA256=catalog_hash,cpythonWorkerSHA256=script_hash,normalAdapterPin='0.4.0')
save(lab/'identity.json',identity)
old_root=load(phase/'config.json')['root']
for name in ['collect.py','archive-owned.py','launch.py','retrieve.py','run.sh']:
    source=read(phase/name).replace(old_root,root).replace('B1047','B1057')
    if name=='collect.py':
        a=source.index('    for case_id,diagnostic in ')
        b=source.index('\n',a)
        source=source[:a]+f'    for case_id,diagnostic in {[(case["id"],False) for case in cases]!r}:'+source[b:]
        source=source.replace('started<350','started<485')
    elif name=='archive-owned.py':
        source=source.replace("len(raw['jobs'])==5","len(raw['jobs'])==7").replace('jobs=5,','jobs=7,').replace('252*1024*1024','208*1024*1024')
    elif name=='launch.py':
        source=source.replace('355','485')
    elif name=='retrieve.py':
        source=source.replace("['jobs']==5","['jobs']==7")
    write(lab/name,source)
headroom=208*1024*1024
space=load(lab/'quiet-space.json')
payload=lab/'payload.tgz'
names=['representative.json','identity.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(lab/name,arcname=name)
unpacked=sum((lab/name).stat().st_size for name in names)
needed=headroom+unpacked+2*1024*1024
available=space['freeBytes']
retire=[]
for proof in sorted(space['replicas'],key=lambda p:-p['bytes']):
    if available>=needed+49152:break
    if Path(old['root']).name + '/observations.tgz' in proof['paths']: continue
    retire.append(proof)
    available+=proof['bytes']
save(lab/'preflight.json',dict(available=available,required=needed,retired=retire))
assert available>=needed,(available,needed)
config=dict(root=root,unit=unit,source=old['root'],sourceRole=role,sourceFiles=files,
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,
    retireGroups=retire,donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
    unpackedBytes=unpacked,cpythonWorkerSHA256=script_hash)
save(lab/'config.json',config)
launcher=read(previous/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=re.sub(r'lython-b[0-9]+-fixtures','lython-b1057-fixtures',launcher)
launcher=launcher.replace("['reference','candidate']","['candidate']")
launcher=launcher.replace('222298112',str(headroom)).replace('+524288,','+2097152,')
launcher=launcher.replace(" payload=sys.stdin"," assert sha(source/'cpython-worker.py')==c['cpythonWorkerSHA256']\n payload=sys.stdin")
write(lab/'remote-launch.py',launcher)
print('Verified B1057 with',available-needed,'bytes of staging headroom.')
