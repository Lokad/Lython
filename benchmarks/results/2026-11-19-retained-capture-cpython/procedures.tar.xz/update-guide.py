from pathlib import Path
import json

target=Path("benchmarks/results/2026-11-19-retained-capture-cpython")
status=json.loads((target/"summary.json").read_text(encoding="utf-8"))
values={(r["case"],r["lane"]):r for r in status["rows"]}
cases=[
    ("Shipment report with format selectors","scripts.report-render.format-selectors.large","3,072 records / 189,441 B"),
    ("Expanded forwarding report","scripts.report-forwarding.expanded","1,024 records / 26,112 B"),
    ("Unannotated rule closures","scripts.rule-default-closures","2,048 inputs / 4,096 definitions"),
    ("Annotated rule closures","scripts.annotated-rule-closures","2,048 inputs / 2,048 definitions"),
    ("Captured rule closures","scripts.captured-rule-closures","2,048 inputs / 4,096 returned closures"),
    ("Mutable rule counters","scripts.mutable-rule-counters","2,048 counters / 4,096 calls"),
    ("CSV invoice","scripts.csv-invoice.large","4,096 data records / 127,031 B"),
]
def fmt_range(bounds, precision):
    return "–".join(dict.fromkeys(f"{value:.{precision}f}" for value in bounds))

def ratio(case, lane):
    return fmt_range(values[case, lane]["ratio"], 2)+"×"

def fmt(title, label, case, lane):
    r=values[case,lane]
    precision=5 if lane=="compile" else 3
    note=(f"B1057 diagnostic. Controls L/C {r['lythonControlPercent']:.2f} / "
          f"{r['cpythonControlPercent']:.2f}%. IQR ≤{r['maxIQRPercent']:.2f}%.")
    cols=(title,label,fmt_range(r["lythonMs"],precision)+" ms",
          fmt_range(r["cpythonMs"],precision)+" ms",ratio(case,lane),note)
    return "| "+" | ".join(cols)+" |"

guide=Path("docs/BENCHMARKS.md")
text=guide.read_text(encoding="utf-8")
warm, marker, other = text.partition("\n## Compilation and compile-to-result\n")
assert marker
for title,case,size in cases:
    prefix="| "+title+" | "
    row=[line for line in warm.splitlines() if line.startswith(prefix) and "B1047 diagnostic" in line]
    if row:
        assert len(row)==1
        warm=warm.replace(row[0],fmt(title,size,case,"warm"))
    else:
        at=warm.index("| CSV invoice |")
        warm=warm[:at]+fmt(title,size,case,"warm")+"\n"+warm[at:]
    for phase,lane in (("Compilation only","compile"),("Compile-to-result","compile-run")):
        prior=[line for line in other.splitlines() if line.startswith(prefix+phase+" |") and "B1047 diagnostic" in line]
        if prior:
            assert len(prior)==1
            other=other.replace(prior[0],fmt(title,phase,case,lane))
        else:
            at=other.index("| CSV invoice |")
            other=other[:at]+fmt(title,phase,case,lane)+"\n"+other[at:]

pa=warm.index("Rule closures have the largest")
pb=warm.index("\nB1006 measured",pa)
warm_range=max(row["lythonControlPercent"] for row in status["rows"] if row["lane"]=="warm")
ordinary=ratio("scripts.rule-default-closures","warm")
annotated=ratio("scripts.annotated-rule-closures","warm")
capture=ratio("scripts.captured-rule-closures","warm")
mutable=ratio("scripts.mutable-rule-counters","warm")
intro=f"""Rule closures have the largest execution gaps in B1057. Ordinary rules take
{ordinary} CPython time, annotated rules take {annotated}, captured rules take
{capture} and mutable counters take {mutable}. Rows with other labels describe
earlier revisions.

B1057 measured **{status['source']} / frozen {status['coreSHA256'][:8]}** on
**2026-11-19 UTC** against stock **CPython 3.13.16** on the quiet **Azure
F4as_v7**, with Ubuntu 24.04.4 and .NET 11 RC3. Each process ran all three
phases. Lython's warm controls differ by at most {warm_range:.2f}% on the seven
inputs. Use the paired B1055 comparison to attribute the capture improvement.
[B1057 observations](../benchmarks/results/2026-11-19-retained-capture-cpython/README.md) ·
[Earlier B1047](../benchmarks/results/2026-11-19-retained-selectors-cpython/README.md) ·
[B1055 capture comparison](../benchmarks/results/2026-11-19-prepared-capture-slots/README.md).
"""
warm=warm[:pa]+intro+warm[pb:]
other=other.replace("B1047 excludes cold startup.","B1057 excludes cold startup.")
guide.write_text(warm+marker+other,encoding="utf-8",newline="\n")
