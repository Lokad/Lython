from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name("forwarded-integers-cpython-20261124")
previous = lab.with_name("shared-comprehension-facts-20261124")
prepare = (template / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('lab.with_name("borrow-forwarded-integers-20261124")', 'lab.with_name("shared-comprehension-facts-20261124")')
prepare = prepare.replace('"git", "rev-parse", "d6a168491"', '"git", "rev-parse", "HEAD"')
prepare = prepare.replace('forwarded-integers-cpython-b1633-20261124', 'frontend-cpython-b1643-20261124')
prepare = prepare.replace('borrow-forwarded-integers-b1631-20261124', 'shared-comprehension-facts-b1642-20261124')
first = prepare.index('catalog = read(sealed / "representative.json")')
last = prepare.index('assert len(jobs) == 9', first)
prepare = prepare[:first] + '''catalog = read(sealed / "representative.json")
rules = "scripts.rule-default-closures"
manifest = "scripts.config-manifest.small"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
invoice = "scripts.csv-invoice.method-policy.quoted-control"
comprehensions = "diagnostic.prepared-comprehension-rules"
order = [rules, manifest, text, invoice, comprehensions]
selected = {row["id"]: row for row in catalog["cases"] if row["id"] in order}
for name, key in (("forwarded-integers-cpython-20261124/external", rules),
                  ("raw-expression-retirement-20261124/comparison/quiet", text),
                  ("regex-cursor-original-20261124/comparison/quiet", invoice)):
    earlier = read(lab.with_name(name.split("/", 1)[0]) / name.split("/", 1)[1] / "representative.json")
    selected[key] = next(row for row in earlier["cases"] if row["id"] == key)
assert set(selected) == set(order)
catalog["cases"] = [selected[key] for key in order]
catalog["fixtureEncoding"] = "Canonical base64 file maps for the manifest, report and invoice. The rules use no file fixture."
jobs = [(rules, "warm"), (manifest, "compile-run"), (comprehensions, "compile"),
        (text, "warm"), (invoice, "warm"), (rules, "compile"),
        (text, "compile-run"), (manifest, "warm"), (rules, "compile-run")]
''' + prepare[last:]
launcher_start = prepare.index('shutil.copyfile(template / "external/run.sh"')
prepare = prepare[:launcher_start] + '''template = lab.with_name("forwarded-integers-cpython-20261124")
shutil.copyfile(template / "external/run.sh", output / "run.sh")
assert b"\\r" not in (output / "run.sh").read_bytes()
collector = (template / "external/collect.py").read_text(encoding="utf-8").replace("b1633-fixtures", "b1643-fixtures")
collector = collector.replace("CPython checkpoint for shared defaults and forwarded integer operands", "CPython checkpoint for prepared comprehensions and representative scripts")
launcher = (template / "external.py").read_text(encoding="utf-8")
launcher = launcher.replace("borrow-forwarded-integers-20261124/comparison/quiet", "shared-comprehension-facts-20261124/comparison/quiet")
launcher = launcher.replace("borrow-forwarded-integers-b1631-20261124", "shared-comprehension-facts-b1642-20261124")
launcher = launcher.replace("forwarded-integers-cpython-b1633-20261124", "frontend-cpython-b1643-20261124")
launcher = launcher.replace("lython-b1633-forwarded-integers-cpython", "lython-b1643-frontend-cpython")
summarizer = (template / "external/summarize.py").read_text(encoding="utf-8")
for name, content in (("external.py", launcher), ("external/collect.py", collector), ("external/summarize.py", summarizer)):
    compile(content, name, "exec")
    write(lab / name, content)
save(lab / "verified-raw-replicas.json", [])
print("Prepared nine short quiet lanes and verified five complete CPython goldens.")
'''
archive = (template / "archive.py").read_text(encoding="utf-8")
archive = archive.replace("2026-11-24-forwarded-integers-cpython", "2026-11-24-frontend-cpython")
archive = archive.replace('identity["productionSource"].startswith("d6a168491")', 'identity["productionSource"] == identity["sourceRevision"]')
archive = archive.replace('verification["caseCount"] == 3', 'verification["caseCount"] == 5').replace('"write-prepare.py"', '"make-trial.py"').replace('B1633 with', 'B1643 with')
for name, contents in (("prepare.py", prepare), ("archive.py", archive)):
    compile(contents, name, "exec")
    (lab / name).write_text(contents, encoding="utf-8", newline="\n")
