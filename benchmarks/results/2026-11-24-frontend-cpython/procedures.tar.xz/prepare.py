from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("shared-comprehension-facts-20261124")
template = lab.with_name("closed-pairs-cpython-20261124")
output = lab / "external"
output.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, s: p.write_text(s, encoding="utf-8", newline="\n")
save = lambda p, v: write(p, json.dumps(v, indent=2, ensure_ascii=False) + "\n")
sealed = donor / "comparison/quiet"
receipt = read(sealed / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert digest(sealed / "observations.tar.xz") == receipt["archiveSHA256"]
source = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
meta = read(sealed / "identity.json")
patch = subprocess.check_output(["git", "diff", "--binary", meta["sourceRevision"], source, "--", "src", "tests"], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == meta["sourcePatchSHA256"]
assert patch == (donor / "candidate.patch").read_bytes()
assert not subprocess.check_output(["git", "diff", source, "--", "src", "tests"], cwd=repo)
files = meta["imageFiles"]["candidate"]
frozen = lab / "candidate"
frozen.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(donor / "candidate" / name, frozen / name)
assert len(files) == 32 and {p.name: digest(p) for p in frozen.iterdir()} == files

remote_name = "frontend-cpython-b1643-20261124"
remote_donor = "shared-comprehension-facts-b1642-20261124"
identity = dict(sourceRevision=source, candidate=source, productionSource=source,
    frozenFromPatch=meta["sourcePatchSHA256"], sourceImageArchiveSHA256=receipt["archiveSHA256"],
    imageFiles={"candidate": files}, frozenImage="/home/lokad/lython-bench-checks/" + remote_name + "/candidate",
    auxiliaryFiles={name: value for name, value in files.items() if name != "Lokad.Lython.dll"},
    coreSHA256={key: meta["coreSHA256"][key] for key in ("candidate", "candidate-control")},
    expectedCPythonSHA256=meta["expectedCPythonSHA256"], cpythonWorkerSHA256=meta["cpythonWorkerSHA256"])
catalog = read(sealed / "representative.json")
rules = "scripts.rule-default-closures"
manifest = "scripts.config-manifest.small"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
invoice = "scripts.csv-invoice.method-policy.quoted-control"
comprehensions = "diagnostic.prepared-comprehension-rules"
order = [rules, manifest, text, invoice, comprehensions]
selected = {row["id"]: row for row in catalog["cases"] if row["id"] in order}
for name, key in (("forwarded-integers-cpython-20261124/external", rules),
                  ("raw-expression-retirement-20261124/comparison/quiet", text),
                  ("regex-cursor-original-20261124/comparison/quiet", invoice)):
    earlier = read(lab.with_name(name.split("/", 1)[0]) / name.split("/", 1)[1] / "representative.json")
    selected[key] = next(row for row in earlier["cases"] if row["id"] == key)
assert set(selected) == set(order)
catalog["cases"] = [selected[key] for key in order]
catalog["fixtureEncoding"] = "Canonical base64 file maps for the manifest, report and invoice. The rules use no file fixture."
jobs = [(rules, "warm"), (manifest, "compile-run"), (comprehensions, "compile"),
        (text, "warm"), (invoice, "warm"), (rules, "compile"),
        (text, "compile-run"), (manifest, "warm"), (rules, "compile-run")]
assert len(jobs) == 9
save(output / "representative.json", catalog)
save(output / "jobs.json", jobs)
identity["catalogs"] = {name: {"sha256": digest(output / name)} for name in ("representative.json", "jobs.json")}
save(output / "identity.json", identity)
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == identity["cpythonWorkerSHA256"]
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
subprocess.run([dotnet, frozen / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
    "--catalog", output / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
    "--python-worker", protocol, "--out", output / "candidate-verify.json"], cwd=repo, env=env, check=True, timeout=80)
proof = read(output / "candidate-verify.json")
assert proof["state"] == "Completed" and proof["caseCount"] == len(order)
assert proof["launched"]["library"]["sha256"] == identity["coreSHA256"]["candidate"]
assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]

template = lab.with_name("forwarded-integers-cpython-20261124")
shutil.copyfile(template / "external/run.sh", output / "run.sh")
assert b"\r" not in (output / "run.sh").read_bytes()
collector = (template / "external/collect.py").read_text(encoding="utf-8").replace("b1633-fixtures", "b1643-fixtures")
collector = collector.replace("CPython checkpoint for shared defaults and forwarded integer operands", "CPython checkpoint for prepared comprehensions and representative scripts")
launcher = (template / "external.py").read_text(encoding="utf-8")
launcher = launcher.replace("borrow-forwarded-integers-20261124/comparison/quiet", "shared-comprehension-facts-20261124/comparison/quiet")
launcher = launcher.replace("borrow-forwarded-integers-b1631-20261124", "shared-comprehension-facts-b1642-20261124")
launcher = launcher.replace("forwarded-integers-cpython-b1633-20261124", "frontend-cpython-b1643-20261124")
launcher = launcher.replace("lython-b1633-forwarded-integers-cpython", "lython-b1643-frontend-cpython")
summarizer = (template / "external/summarize.py").read_text(encoding="utf-8")
for name, content in (("external.py", launcher), ("external/collect.py", collector), ("external/summarize.py", summarizer)):
    compile(content, name, "exec")
    write(lab / name, content)
save(lab / "verified-raw-replicas.json", [])
print("Prepared nine short quiet lanes and verified five complete CPython goldens.")
