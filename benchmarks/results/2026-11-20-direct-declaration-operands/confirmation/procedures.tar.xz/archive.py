from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'quiet'
base=lab.with_name('site-owned-compiler-operands')
out=Path('benchmarks/results/2026-11-20-direct-declaration-operands/confirmation')
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
terminal=load(quiet/'terminal-status.json')
receipt=load(quiet/'archive-receipt.json')
config=load(quiet/'config.json')
first=load(base/'quiet/config.json')
assert terminal['exitCode']=='0' and terminal['receipt']==receipt and receipt['jobs']==2
assert config['identity']['imageFiles']==first['identity']['imageFiles']
assert config['catalogSHA256']==first['catalogSHA256']==sha(base/'catalog.json')
assert all(receipt[name] for name in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert sha(quiet/'observations.tgz')==receipt['archiveSHA256']
data=load(quiet/'retrieved/confirmation/confirmation.json')
assert data['rounds']==7 and data['warmupSeconds']==12 and data['targetBatchSeconds']==.8
assert len(data['jobs'])==2 and all(len(job['samples'])==28 for job in data['jobs'])
assert [job['case'] for job in data['jobs']]==['scripts.config-manifest.small'] * 2
assert [job['lane'] for job in data['jobs']]==['compile-run','warm']
catalog={case['id']:case for case in load(base/'catalog.json')['cases']}
for job in data['jobs']:
    assert job['workersJoinedAndFixturesRemoved']
    case=catalog[job['case']]
    for row in job['samples']:
        response=row['response']
        assert response['status']=='Completed' and response['completedInvocations']>0
        assert response['sourceSha256']==case['sourceSha256'] and response['fixtureSha256']==case['fixtureSha256']
        assert response['actualOutputSha256']==case['expectedOutputSha256']
        assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
out.mkdir(exist_ok=False)
for name in ('terminal-status.json','archive-receipt.json','observations.tgz'):
    shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'quiet-summary.json',out/'summary.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for path in [lab/'prepare.py',lab/'archive.py',lab/'launch-quiet.py',lab/'summarize-quiet.py',quiet/'config.json',
                 quiet/'collect.py',quiet/'archive-owned.py',quiet/'retrieve.py',quiet/'remote-launch.py',quiet/'run.sh',
                 quiet/'launch.log',quiet/'observe-not-before.json']:
        archive.add(path,arcname=path.relative_to(lab).as_posix())
print('Verified all 56 confirmation batches, unchanged images/catalog and raw archive.')
