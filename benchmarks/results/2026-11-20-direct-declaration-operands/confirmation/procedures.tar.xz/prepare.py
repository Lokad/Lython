from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
previous = lab.parent / 'site-owned-compiler-operands'
donor_dir = previous / 'quiet'
quiet = lab / 'quiet'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(path, body):
    if path.suffix == '.py':
        compile(body, str(path), 'exec')
    path.write_text(body, encoding='utf-8', newline='\n')

pair = load(previous / 'frozen-identity.json')
donor = load(donor_dir / 'config.json')
receipt = load(donor_dir / 'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(donor_dir / 'observations.tgz') == receipt['archiveSHA256']
assert donor['identity']['imageFiles'] == pair['images']
assert sha(previous/'catalog.json') == pair['casesSHA256']
manifest = previous/'catalog.json'
order = tuple(row['id'] for row in load(manifest)['cases'])
assert len(order) == 3
catalog_hash = sha(manifest)
for role,files in pair['images'].items():
    image = previous/'frozen'/role
    assert len(files) == 32 and {name:sha(image/name) for name in files} == files
    verified = previous / f'{role}-comparison-verify.json'
    assert load(verified)['state']=='Completed' and load(verified)['catalogSha256']==catalog_hash

root = '/home/lokad/lython-bench-checks/declaration-operands-manifest-confirmation-b1221-20261120'
unit = 'lython-b1221-declaration-operands-manifest-confirmation-20261120'
core = 'Lokad.Lython.dll'
purpose = 'Confirm manifest compile-to-result and warm timing with longer batches'
jobs = [(order[1], 'compile-run'), (order[1], 'warm')]
identity = dict(sourceRevision=pair['referenceCommit']+' versus '+pair['candidateCommit'],purpose=purpose,
                imageFiles=pair['images'],catalogSHA256=catalog_hash,normalAdapterPin='0.4.0',
                coreSHA256={label:files[core] for role,files in pair['images'].items() for label in (role,role+'-control')})
quiet.mkdir(exist_ok=False)
write(quiet/'identity.json',json.dumps(identity,indent=2)+'\n')
(quiet/'representative.json').write_bytes(manifest.read_bytes())
(quiet/'cpython-worker.py').write_bytes(Path('benchmarks/cpython-worker.py').read_bytes())
assert sha(quiet/'cpython-worker.py') == donor['protocolSHA256']
(quiet/'candidate').mkdir()
(quiet/'candidate'/core).write_bytes((previous/'frozen/candidate'/core).read_bytes())
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    body = read(donor_dir/name).replace(donor['root'],root).replace(donor['unit'],unit)
    for old,new in [('len(jobs)==6','len(jobs)==2'),("['jobs']==6","['jobs']==2"),
                    ("len(raw['jobs'])==6","len(raw['jobs'])==2"),('jobs=6,','jobs=2,')]:
        body=body.replace(old,new)
    if name=='collect.py':
        start = body.index('\njobs = ')
        end = body.index('\nassert len(jobs)',start)
        body = body[:start]+'\njobs = '+repr(jobs)+body[end:]
        body = body.replace('accumulate8seconds','accumulate12seconds').replace('warmupSeconds=8','warmupSeconds=12')
        body = body.replace('targetBatchSeconds=.4','targetBatchSeconds=.8').replace('rounds=5','rounds=7')
        body = body.replace('min(warmed)<8','min(warmed)<12').replace('warmed[i]>=8','warmed[i]>=12')
        body = body.replace('counts[i]*.4','counts[i]*.8').replace('range(5)','range(7)')
    write(quiet/name,body)
assert b'\r' not in (quiet/'run.sh').read_bytes()
parts = ['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core]
payload = quiet/'payload.tgz'
with tarfile.open(payload,mode='w:gz') as archive:
    for name in parts:
        archive.add(quiet/name,arcname=name)
config = dict(root=root,unit=unit,source=donor['root'],sourceRole='reference',sourceFiles=pair['images']['reference'],
              sourceCatalogSHA256=donor['catalogSHA256'],protocolSHA256=donor['protocolSHA256'],catalogSHA256=catalog_hash,
              identity=identity,retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
              payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
write(quiet/'config.json',json.dumps(config,indent=2)+'\n')
body=read(donor_dir/'remote-launch.py')
start=body.index('\nc=')+1
end=body.index('\nb=Path(',start)
body=body[:start]+'c='+repr(config)+body[end:]
body=body.replace('lython-b1220-fixtures','lython-b1221-fixtures')
assert '+64*1024*1024' in body
write(quiet/'remote-launch.py',body)
body=read(previous/'launch-quiet.py').replace(donor['identity']['purpose'],purpose)
write(lab/'launch-quiet.py',body.replace('seconds=286','seconds=176').replace('before 286','before 176'))
write(lab/'summarize-quiet.py',read(previous/'summarize-quiet.py').replace("len(raw['jobs'])==6","len(raw['jobs'])==2"))
print('Exact B1220 images and unchanged catalog verified, two manifest confirmation lanes staged.')
