set -eu
root=/home/lokad/lython-bench-checks/declaration-operands-manifest-confirmation-b1221-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
