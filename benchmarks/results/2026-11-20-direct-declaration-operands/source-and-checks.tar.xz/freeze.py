from pathlib import Path
import hashlib, json, shutil, subprocess

lab=Path(__file__).resolve().parent
parent=lab.parent
prior=parent/'executable-default-storage'
trial=Path('.git/agent-worktrees/site-owned-compiler-operands')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],encoding='utf-8').strip()
reference=git('rev-parse','cbec0f2eb')
candidate=git('-C',str(trial),'rev-parse','HEAD')
assert not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',reference,'9741634b1','--','src','benchmarks/Lokad.Lython.Benchmarks',
               'benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
donor=read(prior/'frozen-identity.json')
assert donor['candidateCommit'].startswith('9741634b1')
catalog=read(parent/'current-annotation-demand-attribution/catalog.json')
by_id={case['id']:case for case in catalog['cases']}
cases=('scripts.dataclass-inherited-configuration.generated','scripts.config-manifest.small','scripts.annotated-rule-closures')
catalog['cases']=[by_id[case] for case in cases]
(lab/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
pair=dict(referenceCommit=reference,candidateCommit=candidate,referenceBuiltFrom=donor['candidateCommit'],
          casesSHA256=sha(lab/'catalog.json'),images={})
with (lab/'measured-source.patch').open('wb') as stream:
    subprocess.run(['git','-C',trial,'diff','--binary',reference,candidate,'--','src','tests'],stdout=stream,check=True)
files=donor['images']['candidate']
origin=prior/'frozen/candidate'
assert len(files)==32 and all(sha(origin/name)==digest for name,digest in files.items())
for role in ('reference','candidate'):
    dest=lab/'frozen'/role
    dest.mkdir(parents=True,exist_ok=False)
    for name in files:
        original=origin/name
        if role=='candidate' and name=='Lokad.Lython.dll':
            original=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
        shutil.copyfile(original,dest/name)
    for location,pattern in ((origin,'ValidatedAllocation.*'),(parent/'direct-statement-emission/frozen/reference','CompileAllocation.*')):
        for helper in location.glob(pattern):
            shutil.copyfile(helper,dest/helper.name)
    assert all((dest/name).is_file() for name in ('ValidatedAllocation.dll','CompileAllocation.dll'))
    pair['images'][role]={name:sha(dest/name) for name in files}
assert [name for name in files if pair['images']['candidate'][name]!=files[name]]==['Lokad.Lython.dll']
(lab/'frozen-identity.json').write_text(json.dumps(pair,indent=2)+'\n',encoding='utf-8',newline='\n')
