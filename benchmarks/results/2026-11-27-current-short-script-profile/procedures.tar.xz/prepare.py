from pathlib import Path
from hashlib import sha256
import json
import os
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('current-wide-shipment-profile-20261126')
source=lab.with_name('compiled-prefix-search-20261126')
old=previous/'comparison/quiet'
proof=source/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def write(p,o): save(p,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def sha(p):return sha256(p.read_bytes()).hexdigest()
def alter(s,pairs):
    for a,b in pairs:
        assert a in s,a
        s=s.replace(a,b)
    return s
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
pinned=read(proof/'identity.json')
revision=pinned['sourceRevision']
assert not subprocess.check_output(['git','diff',revision,'--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],cwd=repo)
image=source/'corrected/candidate'
files=pinned['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
receipt=read(proof/'terminal-status.json')['receipt']
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(proof/'observations.tar.xz')

catalog=read(proof/'representative.json')
search,=[row for row in catalog['cases'] if row['id']=='diagnostic.file-search-first-line']
old_config=read(lab.with_name('config-runtime-r160')/'catalog.json')
config,=old_config['cases']
assert config['id']=='scripts.config-edit.small' and config['sourceUtf8Bytes']==357
catalog['cases']=[search,config]
write(quiet/'catalog.json',catalog)
profiles=[['first-line-sync',search['id'],'candidate'],['config-edit-sync',config['id'],'candidate'],['first-line-async',search['id'],'candidate']]
remote_donor='compiled-prefix-cpython-b1815-20261127'
remote='short-script-profile-b1816-20261127'
identity=dict(sourceRevision=revision,inspectedHead=head,profileCatalogSHA256=sha(quiet/'catalog.json'),
              imageFiles={'candidate':files},coreSHA256={'candidate':files['Lokad.Lython.dll']}, profiles=profiles,donorArchiveSHA256=receipt['archiveSHA256'],
              purpose='Distinguish runtime setup, scheduler CPU and mediated host operations in the first-line search and a short configuration edit.')
write(quiet/'identity.json',identity)
for name, replacements in (
    ('collect.py',[('starmap-frame-inputs-b1804-20261126',remote_donor),('b1807-fixtures','b1816-fixtures')]),
    ('ops-profile.py',[('count = 512','count = 1536')]),
    ('run.sh',[]),('analyze.py',[])):
    updated=alter((old/name).read_text(encoding='utf-8'),replacements)
    if name.endswith('.py'):compile(updated,name,'exec')
    save(quiet/name,updated)
assert b'\r' not in (quiet/'run.sh').read_bytes()
runner=alter((previous/'quiet.py').read_text(encoding='utf-8'),[
    ('lython-b1807-current-wide-shipment-profile-20261126','lython-b1816-short-script-profile-20261127'),
    ('starmap-frame-inputs-b1804-20261126',remote_donor),
    ('RuntimeMaxSec=125','RuntimeMaxSec=155'),('seconds=85','seconds=90')])
compile(runner,'quiet.py','exec');save(lab/'quiet.py',runner)
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
worker=proof/'cpython-worker.py'
assert sha(worker)==pinned['cpythonWorkerSHA256']
verification=quiet/'verification.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json','--dotnet',dotnet,
                '--python','C:/Python313/python.exe','--python-worker',worker,'--out',verification],
               cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=40)
result=read(verification)
assert result['state']=='Completed' and result['caseCount']==2 and result['catalogSha256']==identity['profileCatalogSHA256']
assert result['launched']['library']['sha256']==files['Lokad.Lython.dll']
paths=('identity.json','catalog.json','collect.py','ops-profile.py','run.sh')
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as tar:
    for name in paths:tar.add(quiet/name,arcname=name,recursive=False)
write(quiet/'upload.json',dict(root=remote,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expandedBytes=sum((quiet/name).stat().st_size for name in paths),expectedDonorArchiveSHA256=receipt['archiveSHA256']))
