from difflib import unified_diff
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
identity = json.loads((lab/'identity.json').read_text(encoding='utf-8'))
patch = subprocess.check_output(['git','diff','--binary','--','src'], cwd=repo)
assert patch == (lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity['sourcePatchSHA256']
names = subprocess.check_output(['git','diff','--name-only','--','src'],cwd=repo).decode().splitlines()
work = lab / 'boxing'
work.mkdir()
program = (lab/'Program.cs').read_text(encoding='utf-8')
program = program.replace('["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',
                          '["DirectIntegerStores", "LazyIntegerReads"]')
program = program.replace('Lokad.Lython.Runtime.LythonRuntime+ExecutionContext', 'Lokad.Lython.Runtime.PyDict')
relative = 'src/Lokad.Lython/Runtime/PyDict.Storage.cs'
old = '''    private object ReadNativeValue(int index)
        => _nativeValues is null ? PyNone.Instance
            : _recordKeys is not null ? _nativeValues[index]!
            : _nativeValues[index] ??= new BigInteger(_nativeItems![index].Integer);'''
new = '''    internal static int DiagnosticDirectIntegerStores;
    internal static int DiagnosticLazyIntegerReads;

    private object ReadNativeValue(int index)
    {
        if (_nativeValues is null) return PyNone.Instance;
        if (_recordKeys is not null) return _nativeValues[index]!;
        if (_nativeValues[index] is { } value) return value;
        Interlocked.Increment(ref DiagnosticLazyIntegerReads);
        return _nativeValues[index] = new BigInteger(_nativeItems![index].Integer);
    }'''
for role in ('reference','candidate'):
    variant = work / role
    variant.mkdir()
    source = variant / 'source'
    source.mkdir()
    with zipfile.ZipFile(lab/'source.zip') as archive:
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
        archive.extractall(source)
    if role == 'candidate':
        for name in names:
            shutil.copyfile(repo/name, source/name)
    target = source / relative
    current = target.read_text(encoding='utf-8')
    assert current.count(old) == 1
    replaced = current.replace(old, new)
    if role == 'candidate':
        needle = '        StoreUnpublishedNativeInteger(index, value);\n        return true;\n    }'
        start = replaced.index('    internal bool TryReplaceNativeInteger(')
        end = replaced.index('\n    // Native-format', start)
        row = replaced[start:end]
        assert row.count(needle) == 1
        replaced = replaced[:start] + row.replace(needle,
            '        Interlocked.Increment(ref DiagnosticDirectIntegerStores);\n'+needle) + replaced[end:]
    target.write_text(replaced, encoding='utf-8',newline='\n')
    with (variant/'diagnostic.patch').open('w',encoding='utf-8',newline='\n') as file:
        file.writelines(unified_diff(current.splitlines(keepends=True),replaced.splitlines(keepends=True),'a/'+relative,'b/'+relative))
    image = variant/'image'
    image.mkdir()
    frozen = identity['imageFiles'][role]
    for name, sha in frozen.items():
        origin = lab/role/name
        assert hashlib.sha256(origin.read_bytes()).hexdigest() == sha
        shutil.copyfile(origin,image/name)
    (variant/'Program.cs').write_text(program, encoding='utf-8',newline='\n')
    shutil.copyfile(lab/'RouteProbe.csproj',variant/'RouteProbe.csproj')
    sdk = Path.home()/'.dotnet11'
    dotnet = sdk/'dotnet.exe'
    env = dict(os.environ,DOTNET_ROOT=str(sdk))
    def run(args,name):
        with (variant/name).open('wb') as log:
            subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=120)
    run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-o',variant/'core'], 'core.log')
    shutil.copyfile(variant/'core/Lokad.Lython.dll', image/'Lokad.Lython.dll')
    run(['build',variant/'RouteProbe.csproj','-c','Release','-o',variant/'probe'], 'probe.log')
    for artifact in (variant/'probe').glob('RouteProbe*'):
        shutil.copyfile(artifact,image/artifact.name)
    run([image/'RouteProbe.dll',image,lab/'cases.json',variant/'routes.json'],'verification.log')
    print(role, [(row['id'],row['asynchronous'],row['routes']) for row in json.loads((variant/'routes.json').read_text(encoding='utf-8'))['rows']],flush=True)