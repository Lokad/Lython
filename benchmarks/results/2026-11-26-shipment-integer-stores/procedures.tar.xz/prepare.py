from difflib import unified_diff
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
prior = lab.with_name('shipment-comprehension-routes-20261125')
benchmark = lab.with_name('ready-shipment-rows-20261126')
wide = lab.with_name('json-magnitude-utf8-20261126')
repo = lab.parents[3]
source = lab / 'source'
source.mkdir()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
base = git('rev-parse', 'HEAD').decode().strip()
identity = read(wide / 'identity.json')
assert git('diff', '--binary', identity['sourceRevision'], base, '--', 'src') == (wide/'candidate.patch').read_bytes()
archive = lab / 'source.zip'
git('archive', '--format=zip', '--output', str(archive), base, '--', 'src', 'Directory.Build.props',
    'Directory.Build.targets', 'Directory.Build.rsp', 'Directory.Packages.props', 'global.json', 'NuGet.Config')
with zipfile.ZipFile(archive) as z:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
    z.extractall(source)

runtime = source / 'src/Lokad.Lython/Runtime'
files = {}
def patch(name, left, right):
    path = runtime / name
    files.setdefault(name, path.read_text(encoding='utf-8'))
    current = path.read_text(encoding='utf-8')
    assert current.count(left) == 1, (name, current.count(left))
    write(path, current.replace(left, right))

name = 'LythonRuntime.Executable.Inputs.cs'
patch(name, '        [MethodImpl(MethodImplOptions.NoInlining)]\n        private static InstructionPause ExecuteSubscriptStore',
'''        internal static int DiagnosticIntegerStoreCandidates;
        internal static int DiagnosticIntegerStoreExisting;
        internal static int DiagnosticIntegerStoreNativePrefix;
        internal static int DiagnosticIntegerStorePackedKeys;

        internal static bool IsDiagnosticTemporaryInteger(ExecutableCodeObject code, Span<ExecutableSlot> values,
            in ExecutableInstruction instruction)
        {
            var value = instruction.ValueLast ? instruction.ThirdInput : instruction.InputStart;
            return value >= code.FirstTemporarySlot && values[value].IsUnpublishedInteger;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private static InstructionPause ExecuteSubscriptStore''')
patch(name, '            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);\n            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);',
'''            var candidate = IsDiagnosticTemporaryInteger(execution.Code, execution.Stack.Values, instruction);
            if (candidate) Interlocked.Increment(ref DiagnosticIntegerStoreCandidates);
            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);
            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);''')
patch(name, '                        try { scope.CheckExecution(span); }\n                        finally { execution.Stack.RetireTo(instruction.LiveExtent); }',
'''                        if (candidate)
                        {
                            Interlocked.Increment(ref DiagnosticIntegerStorePackedKeys);
                            Interlocked.Increment(ref DiagnosticIntegerStoreExisting);
                        }
                        try { scope.CheckExecution(span); }
                        finally { execution.Stack.RetireTo(instruction.LiveExtent); }''')
patch(name, '            var value = instruction.ValueLast ? third : first;\n            try',
'''            var value = instruction.ValueLast ? third : first;
            if (candidate && receiver is PyDict plain && key is PyString text &&
                plain.DiagnosticOwnsExistingStringKey(text, invocation ?? scope, span))
                Interlocked.Increment(ref DiagnosticIntegerStoreExisting);
            try''')

name = 'LythonRuntime.Executable.NativePrefix.cs'
patch(name, '''            // Resolve the physical inputs in their existing evaluation order.
            // Growth and protocol keys transfer before the dictionary is changed.
            var first''',
'''            // Resolve the physical inputs in their existing evaluation order.
            // Growth and protocol keys transfer before the dictionary is changed.
            var candidate = ExecutionContext.IsDiagnosticTemporaryInteger(Code, Values, instruction);
            if (candidate) Interlocked.Increment(ref ExecutionContext.DiagnosticIntegerStoreCandidates);
            var first''')
patch(name, '            if (!dictionary.TryWriteKeyWithoutAdmission(key, value, _scope, span)) return false;',
'''            var eligible = candidate && key is PyString text && dictionary.DiagnosticOwnsExistingStringKey(text, _scope, span);
            if (!dictionary.TryWriteKeyWithoutAdmission(key, value, _scope, span)) return false;
            if (eligible)
            {
                Interlocked.Increment(ref ExecutionContext.DiagnosticIntegerStoreNativePrefix);
                Interlocked.Increment(ref ExecutionContext.DiagnosticIntegerStoreExisting);
            }''')
patch('PyDict.Storage.cs', '    internal bool SupportsBorrowedTextKeys =>',
'''    internal bool DiagnosticOwnsExistingStringKey(PyString key, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => SupportsBorrowedTextKeys && ReferenceEquals(_memoryGovernor, context.MemoryGovernor) &&
            FindNativeIndex(key, HashNativeString(key, context, span), context, span) >= 0;

    internal bool SupportsBorrowedTextKeys =>''')
parts = []
for name, old in files.items():
    relative = 'src/Lokad.Lython/Runtime/' + name
    new = (runtime / name).read_text(encoding='utf-8')
    parts.extend(unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), 'a/' + relative, 'b/' + relative))
write(lab/'diagnostic.patch', ''.join(parts))
frozen = identity['imageFiles']['candidate']
assert len(frozen)==32 and {p.name: sha(p) for p in (wide/'candidate').iterdir()} == frozen
image = lab / 'image'
image.mkdir()
for name in frozen:
    shutil.copyfile(wide/'candidate'/name, image/name)

shutil.copyfile(prior/'RouteProbe.csproj', lab/'RouteProbe.csproj')
program = (prior/'Program.cs').read_text(encoding='utf-8')
a = program.index('string[] names')
b = program.index('foreach (var item', a)
program = program[:a] + '''string[] names = ["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"];
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
''' + program[b:]
program = program.replace('        transfers.Clear();\n', '').replace('            transfers = transfers.OrderBy(pair => pair.Key).ToDictionary(), ', '            ')
write(lab/'Program.cs', program)
catalog = read(benchmark/'representative.json')
catalog['cases'] = [case | {'runAsync':mode} for case in catalog['cases'] for mode in (False, True)]
write(lab/'cases.json', json.dumps(catalog, ensure_ascii=False))
write(lab/'identity.json', json.dumps(dict(source=base, referenceFiles=frozen, patchSHA256=sha(lab/'diagnostic.patch'),
    catalogSHA256=sha(lab/'cases.json')), indent=2)+'\n')