from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
result = repo / 'benchmarks/results/2026-11-26-shipment-integer-stores'
result.mkdir()
identity = json.loads((lab/'identity.json').read_text(encoding='utf-8'))
patch = subprocess.check_output(['git','diff','--binary','--','src'], cwd=repo)
assert patch == (lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity['sourcePatchSHA256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip() == identity['sourceRevision']
(lab/'focused-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','tests'],cwd=repo))
for name in ('identity.json', 'allocation-summary.json'):
    shutil.copyfile(lab/name,result/name)
for name, source in {
    'baseline-routes.json': lab/'routes.json',
    'reference-boxing.json': lab/'boxing/reference/routes.json',
    'candidate-boxing.json': lab/'boxing/candidate/routes.json',
}.items():
    shutil.copyfile(source,result/name)
top = ('archive.py','prepare.py','prepare-candidate.py','check-boxing.py','Program.cs','RouteProbe.csproj','cases.json',
       'diagnostic.patch','candidate.patch','focused-tests.patch','reference-allocation.json','candidate-allocation.json',
       'reference-verify.json','candidate-verify.json','public-win.log','test-ubuntu.sh',
       'Lokad.Lython.PublicApi.Tests-ubuntu10.log','Lokad.Lython.Tests-ubuntu10.log',
       'core-build.log','probe-build.log','frozen-build.log')
with tarfile.open(result/'procedures.tar.xz','w:xz') as out:
    for name in top:
        out.add(lab/name,arcname=name)
    for role in ('reference','candidate'):
        for name in ('diagnostic.patch','core.log','probe.log','verification.log'):
            path = f'boxing/{role}/{name}'
            out.add(lab/path,arcname=path)
    out.add(lab.parent/'json-magnitude-utf8-20261126/prepare.py',arcname='template/prepare.py')
with tarfile.open(result/'procedures.tar.xz') as out:
    assert out.extractfile('candidate.patch').read() == patch
    assert len(out.getnames()) == len(top)+9