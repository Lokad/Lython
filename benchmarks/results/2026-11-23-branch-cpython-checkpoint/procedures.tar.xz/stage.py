from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"cpython-integrated-checkpoint-20261123/comparison"
donor=lab.parent/"abstract-state-snapshots-20261123/comparison"
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(parents=True)
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def get(path,name):return git("show",f"origin/master:benchmarks/results/{path}/{name}")
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
accepted="2026-11-23-abstract-state-snapshots"
source=json.loads(get(accepted,"source.json"))
receipt=json.loads(get(accepted,"archive-receipt.json"))
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(get(accepted,"observations.tgz"))==receipt["archiveSHA256"]
proof=read(lab/"verify.json")
catalog=quiet/"representative.json"
shutil.copyfile(lab/"representative.json",catalog)
files=source["imageFiles"]["candidate"]
assert len(files)==32 and {n:h(donor/"frozen-candidate"/n)for n in files}==files
assert not git("diff","--name-only",source["retainedRevision"],"HEAD","--","src","tests")
assert proof["state"]=="Completed" and proof["caseCount"]==9 and proof["catalogSha256"]==h(catalog)
assert proof["launched"]["library"]["sha256"]==files[core]
prev=read(prior/"quiet/config.json")
old=read(prior/"quiet/retrieved/confirmation/confirmation.json")
assert old["complete"] and len(old["jobs"])==9
python,={meta["executableSha256"] for j in old["jobs"] for name,meta in j["identities"].items() if name.startswith("CPython")}
original={(j["case"],j["lanes"][0]) for j in old["jobs"]}
branch="compiler.generated-read-only-branches"
sparse="scripts.config-generated-guards.medium.bad-0.sparse-lexical"
factory="scripts.annotated-rule-closures.nested-factories.postponed"
jobs=[
    (branch,"compile"), (factory,"warm"), (branch,"compile-run"),
    ("scripts.csv-invoice.method-policy.quoted-control","warm"),
    (sparse,"compile-run"),
    ("scripts.csv-meter-report.typed-ascii","warm"),
    ("diagnostic.text-summary.nonlocal-computed-width.large","warm"),
    (factory,"compile-run"),
    ("scripts.json-lines-shipment.expanded-options.large","warm"),
    ("diagnostic.text-summary.materialized-wide","warm"),
]
assert len(jobs)==10 and len(set(jobs)&original)==7
save(comparison/"jobs.json",jobs)
root="/home/lokad/lython-bench-checks/branch-checkpoint-cpython-b1443-20261123"
unit="lython-b1443-branch-checkpoint-cpython-20261123"
identity={**prev["identity"],"sourceRevision":source["retainedRevision"],"candidate":source["retainedRevision"],
    "purpose":"Refresh representative CPython comparisons after branch snapshots, nested calls and CSV storage.",
    "imageFiles":{"candidate":files},"coreSHA256":{role:files[core]for role in ("candidate","candidate-control")},
    "auxiliaryFiles":{n:x for n,x in files.items()if n!=core},
    "catalogs":{"representative.json":{"sha256":h(catalog)}},
    "B1438CatalogSHA256":prev["identity"]["catalogs"]["representative.json"]["sha256"],
    "expectedCPythonSHA256":python}
save(quiet/"identity.json",identity)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(prior/"quiet"/name).read_text(encoding="utf-8").replace(prev["root"],root).replace(prev["unit"],unit).replace("B1438","B1443")
    if name=="collect.py":
        a,b=s.index("    for case_id,lane in ["),s.index("        assert time.monotonic()-started<525")
        s=s[:a]+"    for case_id,lane in "+repr(jobs)+":\n"+s[b:]
        s=s.replace("started<525","started<595")
        s=s.replace("['candidate','CPython','candidate-control','CPython-control']",
                    "['CPython-control','candidate-control','CPython','candidate']")
    if name=="archive-owned.py":
        s=s.replace("len(raw['jobs'])==9","len(raw['jobs'])==10").replace("jobs=9,elapsed","jobs=10,elapsed")
    if name=="retrieve.py":
        s=s.replace("status['receipt']['jobs']==9","status['receipt']['jobs']==10")
    write(quiet/name,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as tar:
    for n in parts:tar.add(quiet/n,arcname=n)
inventory=read(lab/"quiet-inventory.json")
earlier="2026-11-23-borrowed-csv-record"
old_root="borrowed-csv-record-b1440-20261123"
path=old_root+"/representative.json"
earlier_src=json.loads(get(earlier,"source.json"))
earlier_rec=json.loads(get(earlier,"archive-receipt.json"))
earlier_raw=get(earlier,"observations.tgz")
assert earlier_rec["complete"] and earlier_rec["archivedAndVerifiedUnderLease"] and sha(earlier_raw)==earlier_rec["archiveSHA256"]
with tarfile.open(fileobj=io.BytesIO(earlier_raw)) as a:old_catalog=a.extractfile("representative.json").read()
assert sha(old_catalog)==earlier_src["catalogs"]["representative.json"]["sha256"]
assert inventory["files"][path]["bytes"]==len(old_catalog) and inventory["files"][path]["links"]==1
retire=[dict(paths=[path],bytes=len(old_catalog),sha256=sha(old_catalog),links=1,
    archives={old_root+"/observations.tgz":earlier_rec["archiveSHA256"]})]
donor_config=read(donor/"quiet/config.json")
cfg={**prev,"root":root,"unit":unit,"identity":identity,"source":donor_config["root"],
    "sourceRole":"candidate","sourceFiles":files,"sourceCatalogSHA256":source["catalogs"]["representative.json"]["sha256"],
    "donorArchiveSHA256":receipt["archiveSHA256"],"retireGroups":retire,"payloadBytes":payload.stat().st_size,
    "payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(prior/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
s=(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1438-fixtures","b1443-fixtures").replace("RuntimeMaxSec=555","RuntimeMaxSec=615")
s=s.replace("640*1024","2*1024*1024")
write(quiet/"remote-launch.py",s)
launch=(prior/"launch.py").read_text(encoding="utf-8")
write(comparison/"launch.py",launch.replace("seconds=525","seconds=580").replace("before 525 seconds","before 580 seconds").replace("B1438","B1443"))
print(root,cfg["unpackedBytes"],source["retainedRevision"])
