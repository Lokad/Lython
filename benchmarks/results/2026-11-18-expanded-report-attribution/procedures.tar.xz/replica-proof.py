
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
found=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    for proof in [{'paths': ['fixed-list-unpack-b994-20261118/confirmation/confirmation.json'], 'canonical': 'benchmarks/results/2026-11-18-fixed-list-unpack/observations.tgz', 'canonicalSHA256': '0240644fd0c9ef4c68984e46b06cbb505807522e17f1e209700c2f0ffb82f027', 'member': 'confirmation/confirmation.json', 'sha256': '374d7bc0bf6909539dab75b150e481924ffc787db4d46f87fea0bdbe81c273a6', 'bytes': 184335, 'links': 1, 'kind': 'exact archived observation replica', 'committedBlobVerified': True}, {'paths': ['retained-cpython-b993-20261118/observations.tgz'], 'canonical': 'benchmarks/results/2026-11-18-retained-cpython-checkpoint/observations.tgz', 'canonicalSHA256': '6a2ac93d1981a91b8c87cb98765bf1abcebb944458a4057975f30061808599bf', 'member': None, 'sha256': '6a2ac93d1981a91b8c87cb98765bf1abcebb944458a4057975f30061808599bf', 'bytes': 71105, 'links': 1, 'kind': 'exact archived observation replica', 'committedBlobVerified': True}]:
        p=root/proof['paths'][0]
        if not p.exists():continue
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_nlink==proof['links'] and v.st_size==proof['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        found.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=found)))
