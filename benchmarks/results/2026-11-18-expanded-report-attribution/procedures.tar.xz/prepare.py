from pathlib import Path
import ast
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
donor = lab.parent / "list-unpack-r568"
previous = lab.parent / "helper-search-profile-r561/quiet"
read = lambda p: p.read_text(encoding="utf-8-sig")
load = lambda p: json.loads(read(p))
sha = lambda data: hashlib.sha256(data).hexdigest()
def write(name, data):
    if name.endswith(".py"):
        ast.parse(data)
    (lab/name).write_text(data,encoding="utf-8",newline="\n")
def save(name, value):
    write(name,json.dumps(value,indent=2)+"\n")

source = subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
assert subprocess.check_output(["git","diff","--binary","d63004a6f",source,"--","src","tests"]) == (donor/"source.patch").read_bytes()
prior = load(donor/"quiet/config.json")
measured = donor/"frozen/candidate"
manifest = prior["identity"]["imageFiles"]["candidate"]
assert len(manifest) == 32 and all(sha((measured/name).read_bytes()) == h for name,h in manifest.items())
catalog = donor/"catalog.json"
assert load(donor/"candidate-verify.json")["catalogSha256"] == sha(catalog.read_bytes())
assert load(donor/"candidate-verify.json")["state"] == "Completed"
shutil.copyfile(catalog,lab/"catalog.json")
root="/home/lokad/lython-bench-checks/expanded-report-cpu-b995-20261118"
unit="lython-b995-expanded-report-cpu-20261118"
old = load(previous/"config.json")
identity=dict(sourceRevision=source,purpose="Expanded forwarding report CPU attribution",
    coreSHA256={"candidate":manifest["Lokad.Lython.dll"]},imageFiles={"candidate":manifest},
    catalogSHA256=sha(catalog.read_bytes()),diagnosticOnly=True,publicationHeld=True)
save("identity.json",identity)
case="scripts.report-forwarding.expanded"
ops=read(previous/"ops-profile.py").replace(old["root"],root)
ops=ops.replace("[('helper', 'scripts.text-normalization.helper-list', 'warm'), ('protected', 'scripts.file-search.large.protected', 'warm')]",
                repr([("report",case,"warm")]))
ops=ops.replace('count = 256 if name == "helper" else 512','count = 128')
assert f"('report', '{case}', 'warm')" in ops and "count = 128" in ops
write("ops-profile.py",ops)
collection=read(previous/"collect.py").replace(old["root"],root).replace("['helper','protected']","['report']").replace("len(records)==2","len(records)==1")
collection=collection.replace("R561/B987 bfe0761104bcd010535e6b14141dde63742a3f5d/frozen610d403d; helper and protected-search attribution",
                              f"R569/B995 {source}/b62bfd52 expanded forwarding CPU attribution")
write("collect.py",collection)
write("run.sh",read(previous/"run.sh").replace(old["root"],root))
assert b"\r" not in (lab/"run.sh").read_bytes()

proofs=[]
for canonical,path,member in [
    ("benchmarks/results/2026-11-18-fixed-list-unpack/observations.tgz",
     "fixed-list-unpack-b994-20261118/confirmation/confirmation.json","confirmation/confirmation.json"),
    ("benchmarks/results/2026-11-18-retained-cpython-checkpoint/observations.tgz",
     "retained-cpython-b993-20261118/observations.tgz",None),
]:
    exact = subprocess.check_output(["git","show",f"origin/master:{canonical}"])
    assert exact == (repo/canonical).read_bytes()
    if member is None: raw=exact
    else:
        with tarfile.open(fileobj=io.BytesIO(exact),mode="r:gz") as archive:
            raw=archive.extractfile(member).read()
        assert json.loads(raw)["complete"]
    proofs.append(dict(paths=[path],canonical=canonical,canonicalSHA256=sha(exact),member=member,
                       sha256=sha(raw),bytes=len(raw),links=1,kind="exact archived observation replica",
                       committedBlobVerified=True))
inspect = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
found=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    for proof in PROOFS:
        p=root/proof['paths'][0]
        if not p.exists():continue
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_nlink==proof['links'] and v.st_size==proof['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        found.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=found)))
'''.replace("PROOFS",repr(proofs))
write("replica-proof.py",inspect)
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
space=json.loads(subprocess.check_output(ssh+["python3 -"],input=inspect.encode("utf-8"),timeout=45))
save("space.json",space)
payload=lab/"payload.tgz"
names=["identity.json","catalog.json","ops-profile.py","collect.py","run.sh"]
with tarfile.open(payload,"w:gz") as archive:
    for name in names:archive.add(lab/name,arcname=name)
unpacked=sum((lab/name).stat().st_size for name in names)
available=space["freeBytes"]; selected=[]
for proof in sorted(space["replicas"],key=lambda v:v["bytes"]):
    if available>254*1024*1024+unpacked+155648:break
    selected.append(proof); available+=proof["bytes"]
assert available>254*1024*1024+unpacked+155648,(available,unpacked)
cfg=dict(root=root,unit=unit,source=prior["root"],sourceFiles=manifest,sourceCatalogSHA256=prior["catalogSHA256"],
        catalogSHA256=identity["catalogSHA256"],identity=identity,retireGroups=selected,
        payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
save("config.json",cfg)
launcher=read(previous/"remote-launch.py")
left,right=launcher.index("\nc=")+1,launcher.index("\nb=Path(")
write("remote-launch.py",(launcher[:left]+"c="+repr(cfg)+launcher[right:]).replace("lython-b987-fixtures","lython-b995-fixtures"))
write("launch.py",read(previous/"launch.py").replace("Helper and protected-search CPU attribution","Expanded-report CPU attribution"))
write("retrieve.py",read(previous/"retrieve.py"))
analysis=read(previous/"analyze.py").replace("['helper','protected']","['report']")
analysis=analysis.replace("     'split construction':",'''     'formatting':('StringMembers::Format','FormatTemplate','FormatField','FormatValue','PyFormat','FormatSpan','FormatString','AppendField','ReadNextField'),
     'expanded argument construction and binding':('CallExpansion','CallArgumentAccumulator','BindFunctionArguments','CreateVariadicPositionalTuple','TryAddNativeString'),
     'staged text output':('TextFileWriteState','TextFileHandle::Write','WriteUtf8','WriteEncodedText','EncodedTextByteCount'),
     'dictionary field lookup':('NativeTextIndex','ReadSubscriptValue','TryGetNativeKey','TryGetValue','FindNativeIndex'),
     'unpack publication':('PublishUnpackedTarget','UnpackValues','MaterializeUnpackingSequence'),
     'split construction':''')
write("analyze.py",analysis)
print("Prepared one bounded report profile with",len(selected),"exact archived replicas selected.")
