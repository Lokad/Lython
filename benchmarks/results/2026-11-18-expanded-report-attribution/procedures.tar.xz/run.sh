set -eu
root=/home/lokad/lython-bench-checks/expanded-report-cpu-b995-20261118
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
