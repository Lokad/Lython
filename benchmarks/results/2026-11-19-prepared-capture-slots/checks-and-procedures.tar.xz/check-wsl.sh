set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-capture-slots-r624
export PATH="$HOME/.dotnet:$PATH"
out=/mnt/d/code/Lython/artifacts/r624-wsl
filter='FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Comprehension|FullyQualifiedName~Generator|FullyQualifiedName~ImplicitClassCell|FullyQualifiedName~ScopeDirective|FullyQualifiedName~Imported|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~MatchGuardScope|FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~LambdaExecutionTests'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$out" --filter "$filter"
