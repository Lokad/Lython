from hashlib import sha256
from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
prior = lab.with_name("trim-truth-without-result-20261126")
local = lab / "local"
local.mkdir()

def read(path):
    return path.read_text(encoding="utf-8-sig")

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = json.loads(read(lab / "identity.json"))
for role, files in identity["imageFiles"].items():
    source = lab / role
    assert len(files) == 32 and {path.name: digest(path) for path in source.iterdir()} == files
    target = local / role
    shutil.copytree(source, target)
    assert {path.name: digest(path) for path in target.iterdir()} == files
for name in ("representative.json", "cpython-worker.py"):
    shutil.copyfile(lab / name, local / name)
assert identity["catalogSHA256"] == digest(local / "representative.json")
assert identity["cpythonWorkerSHA256"] == digest(local / "cpython-worker.py")
jobs = {"warm": [
    ["diagnostic.shipment-starmap-wide-lists", "warm-async"],
    ["diagnostic.shipment-bound-starmap", "warm-async"],
    ["diagnostic.shipment-starmap-wide-lists", "warm"],
    ["diagnostic.shipment-starmap-short-lists", "warm"],
]}
write(local / "jobs.json", json.dumps(jobs, indent=2) + "\n")
identity["coreSHA256"] = {role + suffix: files["Lokad.Lython.dll"]
                          for role, files in identity["imageFiles"].items() for suffix in ("", "-control")}
identity["catalogs"] = {name: {"sha256": digest(local / name)} for name in ("representative.json", "jobs.json")}
identity["purpose"] = "Fill wider exact starmap rows directly into the existing native callback frame."
write(local / "identity.json", json.dumps(identity, indent=2) + "\n")
collector = read(prior / "local/collect.py")
collector = collector.replace("assert len(jobs) == 5 and", "assert len(jobs) == 4 and")
collector = collector.replace("lython-trim-truth-without-result-fixture-", "lython-starmap-frame-inputs-fixture-")
assert collector != read(prior / "local/collect.py")
compile(collector, "collect.py", "exec")
write(local / "collect.py", collector)
shutil.copyfile(prior / "local/run.sh", local / "run.sh")
assert b"\r" not in (local / "run.sh").read_bytes()
summary = read(prior / "summarize.py")
for before, after in (("receipt['warmJobs'] == 5", "receipt['warmJobs'] == 4"),
                      ("len(raw['jobs']) == 5", "len(raw['jobs']) == 4"), ("timedBatches=140", "timedBatches=112")):
    assert summary.count(before) == 1
    summary = summary.replace(before, after)
compile(summary, "summarize.py", "exec")
write(lab / "summarize.py", summary)
