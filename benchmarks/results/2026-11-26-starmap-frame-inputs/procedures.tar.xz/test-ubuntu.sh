set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/starmap-frame-inputs-20261126"
snapshot=$(mktemp -d "$HOME/lython-starmap-frame-XXXXXX")
tar -xf "$lab/source.tar" -C "$snapshot"
for file in src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs src/Lokad.Lython/Runtime/PyExecutableFunction.cs src/Lokad.Lython/Runtime/PyItertools.Transforms.cs tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs; do
    cp "$lab/source/$file" "$snapshot/$file"
    cmp "$lab/source/$file" "$snapshot/$file"
done
printf '%s\n' "$snapshot" > "$lab/ubuntu-source.txt"
cd "$snapshot"
filter='Category!=Stress&(FullyQualifiedName~CallablePacketOwnership|FullyQualifiedName~Starmap|FullyQualifiedName~IteratorAdapter|FullyQualifiedName~NativeCallback|FullyQualifiedName~ManagedStack|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~ZipOperand|FullyQualifiedName~NativeReceiverPipeline)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then
        tail -8 "$log"
    else
        tail -45 "$log"
        exit 1
    fi
done
