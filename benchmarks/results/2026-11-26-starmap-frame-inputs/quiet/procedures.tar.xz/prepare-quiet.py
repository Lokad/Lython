from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
local = lab / "local"
previous = lab.with_name("trim-truth-without-result-20261126") / "comparison/quiet"
donor = lab.with_name("starmap-direct-sequence-packet-20261126") / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

identity = read(local / "identity.json")
assert identity["sourcePatchSHA256"] == digest(lab / "candidate.patch")
published = subprocess.check_output(["git", "show",
    "origin/master:benchmarks/results/2026-11-26-starmap-frame-inputs/identity.json"], cwd=repo)
assert json.loads(published) == identity
cores = {}
for role, files in identity["imageFiles"].items():
    image = local / role
    assert len(files) == 32 and {item.name: digest(item) for item in image.iterdir()} == files
    verification = read(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 4
    assert verification["catalogSha256"] == identity["catalogSHA256"]
    assert verification["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    cores[role] = dict(bytes=(image / "Lokad.Lython.dll").stat().st_size, sha256=files["Lokad.Lython.dll"])
for name in ("representative.json", "cpython-worker.py"):
    shutil.copyfile(local / name, quiet / name)
assert identity["catalogSHA256"] == digest(quiet / "representative.json")
assert identity["cpythonWorkerSHA256"] == digest(quiet / "cpython-worker.py")

donor_identity = read(donor / "identity.json")
reference_files = identity["imageFiles"]["reference"]
for role in identity["imageFiles"]:
    assert {key for key, sha in donor_identity["imageFiles"]["candidate"].items()
            if identity["imageFiles"][role][key] != sha} == {"Lokad.Lython.dll"}
receipt = read(donor / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["archiveSHA256"] == digest(donor / "observations.tar.xz")
identity["expectedCPythonSHA256"] = donor_identity["expectedCPythonSHA256"]
jobs = read(local / "jobs.json")["warm"]
write(quiet / "jobs.json", {"warm": [jobs[index] for index in (3, 2, 1, 0)]})
identity["catalogs"]["jobs.json"]["sha256"] = digest(quiet / "jobs.json")
write(quiet / "identity.json", identity)

collector = (previous / "collect.py").read_text(encoding="utf-8")
assert collector.count("lython-b1802-fixtures") == 1
collector = collector.replace("lython-b1802-fixtures", "lython-b1804-fixtures")
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
shutil.copyfile(previous / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()

names = ("identity.json", "jobs.json", "representative.json", "cpython-worker.py", "collect.py", "run.sh")
package = quiet / "stage.tar.gz"
with tarfile.open(package, "w:gz") as archive:
    for name in names:
        archive.add(quiet / name, arcname=name, recursive=False)
expanded = sum((quiet / name).stat().st_size for name in names)
min_free = 6_000_000
info = dict(root="starmap-frame-inputs-b1804-20261126", unit="lython-b1804-starmap-frame-inputs-20261126",
            donor=read(donor / "upload.json")["root"], donorFiles=donor_identity["imageFiles"]["candidate"],
            donorArchiveSHA256=receipt["archiveSHA256"], payloadSHA256=digest(package),
            payloadBytes=package.stat().st_size, expandedBytes=expanded, cores=cores,
            minimumAfterStageBytes=min_free,
            minimumBeforeUploadBytes=sum(core["bytes"] for core in cores.values()) + expanded + package.stat().st_size + min_free + 350_000)
write(quiet / "upload.json", info)
print({key: value for key, value in info.items() if key != "donorFiles"})

summary = (previous.parent.parent / "summarize-quiet.py").read_text(encoding="utf-8")
(lab / "summarize-quiet.py").write_text(summary, encoding="utf-8", newline="\n")
