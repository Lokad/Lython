using System.Collections;
using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
var cases = new List<object>();
foreach (var path in args[1..])
{
    using var catalog = JsonDocument.Parse(File.ReadAllText(path));
    foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
    {
        var id = item.GetProperty("id").GetString()!;
        var budget = new LythonMemoryBudget();
        using var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!, budget);
        if (!script.IsValid) throw new InvalidDataException(id + " " + string.Join(" | ", script.Diagnostics));
        var executable = script.GetType().GetField("_executable", Flags)!.GetValue(script)!;
        var codes = new List<object>();
        var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
        Visit(Get(executable, "EntryPoint")!);
        cases.Add(new { id, compileAdmissionBytes = budget.ReservedBytes, codes });
        script.Dispose();
        if (budget.ReservedBytes != 0) throw new InvalidDataException("Compile ownership did not return.");

        void Visit(object code)
        {
            if (!seen.Add(code)) return;
            var instructions = Items(code, "Instructions").ToArray();
            var callSites = Items(code, "CallSites").ToArray();
            var regions = Items(code, "ExceptionRegions").ToArray();
            codes.Add(new
            {
                name = Get(code, "Name"), hasClosedOperandReturn = Get(code, "HasDirectOperandReturn"), firstTemporarySlot = Get(code, "FirstTemporarySlot"),
                entryIndex = Get(code, "EntryIndex"),
                capacity = Get(code, "ValueStorageCapacity"),
                nativePrefixEnd = Get(code, "NativePrefixEnd"),
                closureArithmetic = instructions.Count(op => (bool)Get(op, "HasClosureArithmetic")!),
                dictionaryLoops = instructions.Count(op => Get(op, "OpCode")!.ToString() == "ForNextDictionaryAccumulation"),
                dictionaryCalls = callSites.Count(site => (bool)Get(site, "AccumulatesDictionary")!),
                instructions = instructions.Select(Raw),
                regions = regions.Select(Raw),
                callSites = callSites.Select(site => new
                {
                    argumentCount = Get(site, "ArgumentCount"),
                    hasReceiver = Get(site, "HasReceiver"),
                    targetSpan = Get(site, "TargetSpan"),
                    span = Get(site, "CallSpan"),
                    consumedByIteration = Get(site, "ConsumedByIteration"),
                    returnedDirectly = Get(site, "ReturnedDirectly"),
                    unpackedReturnCount = Get(site, "UnpackedReturnCount"),
                    accumulatesDictionary = Get(site, "AccumulatesDictionary")
                }),
                operandReadSpans = ((IEnumerable)code.GetType().GetField("_operandReadSpans", Flags)!.GetValue(code)!)
                    .Cast<object>().Select(Raw)
            });

            foreach (var value in (object?[])Get(code, "Constants")!)
                if (value is not null)
                    foreach (var property in value.GetType().GetProperties(Flags))
                        if (property.PropertyType == code.GetType() && property.GetValue(value) is { } child)
                            Visit(child);
        }
    }
}
File.WriteAllText(args[0], JsonSerializer.Serialize(cases));

static object? Get(object value, string name) => value.GetType().GetProperty(name, Flags)!.GetValue(value);
static IEnumerable<object> Items(object value, string name) => ((IEnumerable)Get(value, name)!).Cast<object>();
static Dictionary<string, object?> Raw(object value)
    => value.GetType().GetFields(Flags).OrderBy(field => field.Name)
        .ToDictionary(field => field.Name, field => field.GetValue(value));

