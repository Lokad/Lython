from hashlib import sha256
from pathlib import Path
import gzip
import io
import json
import os
import re
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
mode, = sys.argv[1:]
assert mode in ("preview", "retire")

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def claim(stage, artifact, archive_name, root, *, partial=False):
    terminal = read(stage / "terminal-status.json")
    receipt = terminal["receipt"]
    assert not terminal["live"] and not terminal["fixtures"]
    assert (terminal["exitCode"] == "0") == (not partial)
    assert receipt["complete"] == (not partial)
    assert all(receipt[key] for key in ("allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
    published = subprocess.check_output(
        ["git", "show", f"origin/master:benchmarks/results/{artifact}/{archive_name}"], cwd=repo)
    if partial:
        with tarfile.open(fileobj=io.BytesIO(published)) as bundle:
            published = bundle.extractfile("initial/observations.tar.xz").read()
    assert sha256(published).hexdigest() == receipt["archiveSHA256"] == digest(stage / "observations.tar.xz")
    unit, = set(re.findall(r"lython-b[a-z0-9-]+\.service", terminal["journal"]))
    return dict(root=root, unit=unit, fingerprint=receipt["archiveSHA256"], partial=partial)

backup_dir = lab / "preserved-cores"
backup_dir.mkdir(exist_ok=True)
cores = []
for directory in ("native-map-sources-20261125", "closed-default-store-links-20261125"):
    original = lab.with_name(directory)
    stage = original / "comparison/quiet"
    stem, _, date = directory.rpartition("-")
    info = claim(stage, f"{date[:4]}-{date[4:6]}-{date[6:]}-{stem}", "quiet-observations.tar.xz",
                 read(stage / "upload.json")["root"])
    image = original / "candidate"
    files = read(stage / "identity.json")["imageFiles"]["candidate"]
    assert len(files) == 32 and {p.name: digest(p) for p in image.iterdir()} == files
    data = (image / "Lokad.Lython.dll").read_bytes()
    backup = backup_dir / (directory + ".dll.gz")
    if not backup.exists():
        assert mode == "preview"
        backup.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(backup.read_bytes()) == data
    cores.append(dict(info, files=files, bytes=len(data), localImage=str(image), backup=str(backup)))

profile = claim(lab.with_name("retained-call-attribution-20261123") / "initial",
    "2026-11-23-retained-call-attribution", "procedures.tar.xz", "retained-call-attribution-b1512-20261123", partial=True)
proof = dict(cores=cores, profile=profile,
             minimum=read(quiet / "upload.json")["minimumBeforeUploadBytes"])
if mode == "retire":
    assert read(quiet / "custody-preview.json")["proof"] == proof

remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess, tarfile

base = Path("/home/lokad/lython-bench-checks")
assert base.resolve() == base
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def check(claim):
    root = base / claim["root"]
    assert root.resolve() == root and root.parent == base
    state = subprocess.check_output(["systemctl", "show", claim["unit"], "--property=ActiveState,MainPID"], text=True)
    allowed_terminal = "ActiveState=failed" if claim["partial"] else "ActiveState=inactive"
    assert allowed_terminal in state and "MainPID=0" in state, state
    archive = root / "observations.tar.xz"
    receipt = json.loads((root / "archive-receipt.json").read_text())
    assert receipt["archiveSHA256"] == digest(archive) == claim["fingerprint"]
    assert receipt["complete"] == (not claim["partial"])
    assert all(receipt[key] for key in ("allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
    return root, archive

with (base / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob("*/guest-fixtures"))
    selected = []
    verified = []
    proofs = []
    for claim in cfg["cores"]:
        root, archive = check(claim)
        image = root / "candidate"
        assert image.resolve() == image and {p.name: digest(p) for p in image.iterdir()} == claim["files"]
        core = image / "Lokad.Lython.dll"
        aliases = [p for role in ("candidate", "reference") for p in base.glob("*/" + role + "/Lokad.Lython.dll")
                   if p.resolve() == core]
        assert aliases == [core], aliases
        info = core.lstat()
        assert core.resolve() == core and stat.S_ISREG(info.st_mode) and info.st_nlink == 1
        assert info.st_uid == os.getuid() and info.st_size == claim["bytes"]
        selected.append((core, info.st_blocks * 512))
        verified.append((archive, claim["fingerprint"]))
        proofs.append(dict(path=str(core.relative_to(base)), bytes=info.st_blocks * 512, imageFiles=len(claim["files"])))

    before = shutil.disk_usage(base).free
    if before + sum(size for _, size in selected) < cfg["minimum"]:
        root, archive = check(cfg["profile"])
        profile = root / "profiles"
        assert profile.resolve() == profile and profile.is_dir() and not profile.is_mount()
        with tarfile.open(archive) as bundle:
            peers = {item.name: hashlib.sha256(bundle.extractfile(item).read()).hexdigest()
                     for item in bundle if item.isfile() and item.name.startswith("profiles/")}
        matched = []
        for path in profile.rglob("*"):
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode):
                continue
            assert path.resolve() == path and info.st_nlink == 1 and info.st_uid == os.getuid()
            assert peers.get(str(path.relative_to(root))) == digest(path)
            matched.append((path, info.st_blocks * 512))
        assert matched
        selected.extend(matched)
        verified.append((archive, cfg["profile"]["fingerprint"]))
        proofs.append(dict(path=str(profile.relative_to(base)), bytes=sum(size for _, size in matched), files=len(matched)))

    recoverable = sum(size for _, size in selected)
    assert before + recoverable >= cfg["minimum"], (before, recoverable, cfg["minimum"])
    if mode == "retire":
        assert proofs == expected, (proofs, expected)
        for path, _ in selected:
            path.unlink()
        for archive, fingerprint in verified:
            assert digest(archive) == fingerprint
    print(json.dumps(dict(mode=mode, before=before, after=shutil.disk_usage(base).free,
                          recoverable=recoverable, minimum=cfg["minimum"], proofs=proofs)))
'''
expected = read(quiet / "custody-preview.json")["result"]["proofs"] if mode == "retire" else []
data = f"cfg={proof!r}\nmode={mode!r}\nexpected={expected!r}\n" + remote
result = subprocess.run(["ssh", "-i", os.environ["LYTHON_BENCH_IDENTITY"], "-o", "BatchMode=yes",
    "-o", "ConnectTimeout=10", os.environ["LYTHON_BENCH_HOST"], "python3 -"], input=data,
    encoding="utf-8", capture_output=True, timeout=55)
if result.returncode:
    print(result.stderr)
    result.check_returncode()
report = json.loads(result.stdout)
(quiet / f"custody-{mode}.json").write_text(json.dumps(dict(proof=proof, result=report), indent=2) + "\n",
                                          encoding="utf-8", newline="\n")
print(result.stdout)
