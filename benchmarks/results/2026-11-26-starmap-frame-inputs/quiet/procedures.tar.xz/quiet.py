from datetime import datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
base = "/home/lokad/lython-bench-checks"
host = os.environ["LYTHON_BENCH_HOST"]
common = ["-i", os.environ["LYTHON_BENCH_IDENTITY"], "-o", "BatchMode=yes", "-o", "ConnectTimeout=10"]
config = json.loads((quiet / "upload.json").read_text(encoding="utf-8"))
config["base"] = base
mode, = sys.argv[1:]
assert mode in ("launch", "retrieve")
assert len(config["cores"]) == 2
prefix = f"cfg={config!r}\n" + '''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, tarfile
base = Path(cfg["base"])
root = base / cfg["root"]
assert base.resolve() == base and root.resolve() == root and root.parent == base
payload = base / (root.name + ".tar.gz")
incoming = {role: base / (root.name + "." + role + ".dll") for role in cfg["cores"]}
unit = cfg["unit"] + ".service"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
'''

def invoke(source):
    result = subprocess.run(["ssh", *common, host, "python3 -"], input=prefix + source,
                            capture_output=True, encoding="utf-8", timeout=55)
    return result

def transfer(source, target):
    subprocess.run(["scp", *common, source, target], check=True, timeout=48)

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

if mode == "launch":
    before = invoke('''
assert not root.exists() and not payload.exists() and not any(path.exists() for path in incoming.values())
available = shutil.disk_usage(base).free
assert available >= cfg["minimumBeforeUploadBytes"], (available, cfg["minimumBeforeUploadBytes"])
print(json.dumps(dict(freeBeforeUploadBytes=available)))
''')
    before.check_returncode()
    for role, metadata in config["cores"].items():
        source = lab / "local" / role / "Lokad.Lython.dll"
        assert digest(source) == metadata["sha256"] and source.stat().st_size == metadata["bytes"]
        transfer(source, f"{host}:{base}/{config['root']}.{role}.dll")
    stage = quiet / "stage.tar.gz"
    assert digest(stage) == config["payloadSHA256"]
    transfer(stage, f"{host}:{base}/{config['root']}.tar.gz")
    launched = invoke('''
with (base / "comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not any(path.is_mount() for path in base.glob("*/guest-fixtures"))
    assert not root.exists() and payload.resolve() == payload
    assert digest(payload) == cfg["payloadSHA256"]
    for role, path in incoming.items():
        expected = cfg["cores"][role]
        assert path.resolve() == path and digest(path) == expected["sha256"] and path.stat().st_size == expected["bytes"]
    with tarfile.open(payload) as package:
        names = {"identity.json", "jobs.json", "representative.json", "cpython-worker.py", "collect.py", "run.sh"}
        frames = package.getmembers()
        assert len(frames) == len(names) and {item.name for item in frames} == names and all(item.isfile() for item in frames)
        expanded = sum(item.size for item in frames)
        assert expanded == cfg["expandedBytes"]
        assert shutil.disk_usage(base).free >= expanded + cfg["minimumAfterStageBytes"]
        root.mkdir()
        package.extractall(root, filter="data")
    payload.unlink()

    image = json.loads((root / "identity.json").read_text())
    donor = base / cfg["donor"] / "candidate"
    assert donor.resolve() == donor and {path.name: digest(path) for path in donor.iterdir()} == cfg["donorFiles"]
    donor_receipt = json.loads((donor.parent / "archive-receipt.json").read_text())
    assert donor_receipt["complete"] and donor_receipt["allWorkersJoined"]
    assert donor_receipt["archiveSHA256"] == cfg["donorArchiveSHA256"] == digest(donor.parent / "observations.tar.xz")
    for role, core in incoming.items():
        target = root / role
        target.mkdir()
        for path in donor.iterdir():
            if path.name == "Lokad.Lython.dll":
                continue
            if path.name.startswith("Lokad.Lython.Benchmarks."):
                assert path.resolve() == path and path.is_file()
                os.link(path, target / path.name)
            else:
                (target / path.name).symlink_to(path)
        core.rename(target / "Lokad.Lython.dll")
        assert len(image["imageFiles"][role]) == 32
        assert {path.name: digest(path) for path in target.iterdir()} == image["imageFiles"][role]
    for name, status in image["catalogs"].items():
        assert digest(root / name) == status["sha256"]
    assert digest(root / "cpython-worker.py") == image["cpythonWorkerSHA256"]
    sdk = Path.home() / "lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148"
    python = Path.home() / "lython-bench-toolchains/cpython/3.13.16/bin/python3.13"
    assert digest(python) == image["expectedCPythonSHA256"]
    for role in incoming:
        verifier = root / (role + "-verify.json")
        result = subprocess.run([sdk / "dotnet", root / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
            "--catalog", root / "representative.json", "--dotnet", sdk / "dotnet", "--python", python,
            "--python-worker", root / "cpython-worker.py", "--out", verifier],
            cwd=root, env=dict(os.environ, DOTNET_ROOT=str(sdk)), capture_output=True, text=True, timeout=20)
        print(role, result.stdout, result.stderr, flush=True)
        result.check_returncode()
        checks = json.loads(verifier.read_text())
        assert checks["state"] == "Completed" and checks["caseCount"] == 4
        assert checks["catalogSha256"] == image["catalogs"]["representative.json"]["sha256"]
        assert checks["launched"]["library"]["sha256"].lower() == image["coreSHA256"][role]
    available = shutil.disk_usage(base).free
    assert available >= cfg["minimumAfterStageBytes"], (available, cfg["minimumAfterStageBytes"])
    print(json.dumps(dict(freeBeforeLaunchBytes=available, expandedBytes=expanded)), flush=True)
subprocess.run(["sudo", "-n", "systemd-run", "--unit=" + cfg["unit"], "--property=User=lokad",
    "--property=WorkingDirectory=" + str(root), "--property=RuntimeMaxSec=255", "--property=TimeoutStopSec=20",
    "--property=KillMode=control-group", "/bin/sh", str(root / "run.sh")], check=True)
''')
    log = before.stdout + launched.stdout + launched.stderr
    (quiet / "launch.log").write_text(log, encoding="utf-8")
    print(log)
    launched.check_returncode()
    (quiet / "observe-not-before").write_text((datetime.now(timezone.utc) + timedelta(seconds=178)).isoformat(),
                                             encoding="utf-8")
else:
    marker = (quiet / "observe-not-before").read_text(encoding="utf-8")
    assert datetime.now(timezone.utc) >= datetime.fromisoformat(marker)
    status = invoke('''
service = subprocess.check_output(["systemctl", "show", unit, "--property=ActiveState,SubState,MainPID,Result,ExecMainStatus"],
                                  text=True)
if "ActiveState=active" in service or "ActiveState=activating" in service:
    print(json.dumps(dict(live=True, service=service)))
else:
    assert "MainPID=0" in service, service
    with (base / "comparison-vm.lock").open("a") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        receipt = root / "archive-receipt.json"
        exit_code = root / "exit-code.txt"
        print(json.dumps(dict(live=False, service=service, fixtures=(root / "guest-fixtures").exists(),
              exitCode=exit_code.read_text().strip() if exit_code.exists() else None,
              receipt=json.loads(receipt.read_text()) if receipt.exists() else None,
              journal=subprocess.run(["journalctl", "-u", unit, "-n", "32", "--no-pager"],
                                     capture_output=True, text=True).stdout)))
''')
    status.check_returncode()
    result = json.loads(status.stdout)
    (quiet / f"status-{datetime.now(timezone.utc):%H%M%S}.json").write_text(status.stdout, encoding="utf-8")
    if not result["live"]:
        (quiet / "terminal-status.json").write_text(status.stdout, encoding="utf-8")
        if result["receipt"]:
            archive = quiet / "observations.tar.xz"
            transfer(f"{host}:{base}/{config['root']}/{archive.name}", archive)
            assert digest(archive) == result["receipt"]["archiveSHA256"]
    print(status.stdout)
