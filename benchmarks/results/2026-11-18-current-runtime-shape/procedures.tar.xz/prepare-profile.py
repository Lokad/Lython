from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

repo = Path('D:/code/Lython')
lab = Path(__file__).resolve().parent
profile = lab / 'profile'
old = lab.parent / 'runtime-deletion-r529'
source = lab / 'quiet'
source_config = json.loads((source / 'config.json').read_text(encoding='utf-8'))
base = json.loads((old / 'config.json').read_text(encoding='utf-8'))['root']
root = '/home/lokad/lython-bench-checks/runtime-shape-b969-20261118'
unit = 'lython-b969-runtime-shape-20261118'
sha = lambda data: hashlib.sha256(data).hexdigest()
identity = json.loads((source / 'identity.json').read_text(encoding='utf-8'))
identity.update(
    sourceRevision='R536 frozen candidate 9eed03c9, production carried by f7b1c056d',
    purpose='Current whole-script floating and helper-text CPU attribution after R534/R536')
for name, digest in identity['imageFiles']['candidate'].items():
    assert sha((lab / 'frozen/candidate' / name).read_bytes()) == digest
assert sha((lab / 'representative.json').read_bytes()) == identity['catalogSHA256']
assert (lab / 'candidate-verification.json').is_file()


def read(name):
    return (old / name).read_text(encoding='utf-8')


def write(name, text):
    if name.endswith('.py'):
        ast.parse(text)
    (profile / name).write_text(text, encoding='utf-8', newline='\n')


# The existing stage guard checks this exact read-only archive proof and all
# remote aliases under its idle lease before unlinking the working replica.
canonical = 'benchmarks/results/2026-11-18-native-sequence-bounds/observations.tgz'
blob = (repo / canonical).read_bytes()
assert blob == subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
member = 'confirmation/confirmation.json'
with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
    exact = archive.extractfile(member).read()
proof = dict(kind='committed observation working replica', canonical=canonical,
             canonicalSHA256=sha(blob), member=member, sha256=sha(exact), bytes=len(exact),
             paths=['native-index-bounds-b967-20261118/' + member], links=1,
             committedBlobVerified=True)
profile.mkdir()
write('identity.json', json.dumps(identity, indent=2) + '\n')
write('run.sh', read('run.sh').replace(base, root))
assert b'\r' not in (profile / 'run.sh').read_bytes()
write('collect.py', read('collect.py').replace(base, root).replace(
    'R529/B958 committed925397f65/frozen2c6b304b', 'R537/B969 retained production f7b1c056d/frozen9eed03c9'))
write('ops-profile.py', read('ops-profile.py').replace(base, root))
names = ('identity.json', 'run.sh', 'collect.py', 'ops-profile.py')
payload = profile / 'payload.tgz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in names:
        archive.add(profile / name, arcname=name)
config = dict(root=root, unit=unit, source=source_config['root'],
              sourceFiles=identity['imageFiles']['candidate'],
              sourceCatalogSHA256=identity['catalogSHA256'],
              catalogSHA256=identity['catalogSHA256'], identity=identity,
              retireGroups=[proof], payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload.read_bytes()),
              unpackedBytes=sum((profile / name).stat().st_size for name in names))
write('config.json', json.dumps(config, indent=2) + '\n')
launch = read('remote-launch.py')
start, end = launch.index('\nc=') + 1, launch.index('\nb=Path(')
launch = launch[:start] + 'c=' + repr(config) + launch[end:]
launch = launch.replace(" assert sha(root/'catalog.json')",
                        " os.link(source/'representative.json',root/'catalog.json')\n assert sha(root/'catalog.json')")
write('remote-launch.py', launch.replace('lython-b958-fixtures', 'lython-b969-fixtures'))
for name in ('launch.py', 'retrieve.py', 'analyze.py'):
    write(name, read(name))
