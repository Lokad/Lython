from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-owned-class-cpython'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
identity = read(quiet / 'identity.json')
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined',
                                   'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert sha((quiet / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 84
for revision in (identity['candidate'], identity['deliveryRevision']):
    assert not subprocess.check_output(['git', 'diff', '--name-only', identity['sourceRevision'], revision,
                                        '--', 'src', 'tests'], cwd=repo)
files = identity['imageFiles']['candidate']
image = lab.parent / 'plain-class-fixed-20261123/candidate'
assert len(files) == 32 and all(sha((image / name).read_bytes()) == value for name, value in files.items())
core = dest.parent / '2026-11-23-owned-class-module-slots/candidate-core.dll.gz'
assert sha(gzip.decompress(core.read_bytes())) == files['Lokad.Lython.dll']
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for name in ('observations.tar.xz', 'identity.json', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'configure.py', 'prepare.py', 'quiet.py', 'comparison/quiet/launch.log',
                 'comparison/quiet/observe-not-before', 'comparison/quiet/candidate-verify.json',
                 'comparison/quiet/summarize.py'):
        bundle.add(lab / name, arcname=name)
print(dest)
