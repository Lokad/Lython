from pathlib import Path
from statistics import median, quantiles
import hashlib,json,tarfile

quiet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
terminal=read(quiet/"terminal-status.json")
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
receipt=terminal["receipt"]
archive=quiet/"observations.tar.xz"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archiveSHA256"]
image=read(quiet/"identity.json")
case_by_id={r["id"]:r for r in read(quiet/"representative.json")["cases"]}
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile("confirmation/confirmation.json"))
    identity=json.load(bundle.extractfile("identity.json"))
    jobs=json.load(bundle.extractfile("jobs.json"))
assert raw["complete"] and len(raw["jobs"])==3 and receipt["warmJobs"]==3
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
assert identity==image and jobs==read(quiet/"jobs.json")
assert [(job["case"], job["lanes"][0]) for job in raw["jobs"]]==[tuple(j) for j in jobs]
rows=[]
pinned=set()
for job in raw["jobs"]:
    case=case_by_id[job["case"]]
    lane,=job["lanes"]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    med={};cpu={};iqr={}
    for label,worker in job["identities"].items():
        assert worker["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
        if label.startswith("CPython"):
            assert worker["version"].startswith("3.13.16")
            pinned.add(worker["executableSha256"])
        else:
            assert worker["runtimeVersion"]=="11.0.0"
        samples=[s for s in job["samples"]if s["engine"]==label]
        assert len(samples)==7
        times=[];wider=[]
        for sample in samples:
            r=sample["response"]
            assert r["status"]=="Completed" and r["completedInvocations"]>0 and all(r[k]==case[k] for k in ["sourceSha256","fixtureSha256","expectedOutputSha256"])
            assert r["actualOutputSha256"]==(None if lane=="compile" else case["expectedOutputSha256"])
            assert r.get("actualFilesSha256")== (None if lane=="compile" else case.get("expectedFilesSha256"))
            times.append(r["elapsedTicks"]*1000/r["clockFrequency"]/r["completedInvocations"])
            wider.append(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/r["completedInvocations"])
        med[label]=median(times)
        cpu[label]=median(wider)
        q=quantiles(times,n=4,method="inclusive")
        iqr[label]=(q[2]-q[0])*100/med[label]
    span=lambda v,l:[min(v[l],v[l+"-control"]),max(v[l],v[l+"-control"])]
    div=lambda v:sorted(a/b for a in span(v,"candidate") for b in span(v,"CPython"))
    spreads=lambda l:(max(span(med,l))/min(span(med,l))-1)*100
    row=dict(case=case["id"],lane=lane,lythonMs=span(med,"candidate"),cpythonMs=span(med,"CPython"),ratio=[min(div(med)),max(div(med))],widerCpuRatio=[min(div(cpu)),max(div(cpu))],lythonControlPercent=spreads("candidate"),cpythonControlPercent=spreads("CPython"),maxIQRPercent=max(iqr.values()),sourceUtf8Bytes=case["sourceUtf8Bytes"],fixtureSha256=case["fixtureSha256"])
    rows.append(row)
    print(case["id"],lane,"L [",*map(lambda n:f"{n:.5f}",row["lythonMs"]),"] C [",*map(lambda n:f"{n:.5f}",row["cpythonMs"]),"]",*[f"{n:.4f}" for n in row["ratio"]],"spread",*[f"{row[k]:.2f}%" for k in ["lythonControlPercent","cpythonControlPercent"]])
assert pinned == {image["expectedCPythonSHA256"]}
(quiet/"summary.json").write_text(json.dumps(dict(source=image["sourceRevision"],cpythonVersion="3.13.16",cpythonExecutableSHA256=next(iter(pinned)),elapsedSeconds=raw["elapsedSeconds"],timedBatches=sum(len(job["samples"]) for job in raw["jobs"]),performanceQualified=False,rows=rows),indent=2)+"\n",encoding="utf-8",newline="\n")
