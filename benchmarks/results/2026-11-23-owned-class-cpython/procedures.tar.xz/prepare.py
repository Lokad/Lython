from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
donor=lab.parent/'plain-class-fixed-20261123'
collection=lab.parent/'short-csv-utf8-cpython-20261123'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda p:sha(p.read_bytes())
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def adapt(source,target,pairs):
    code=source.read_text(encoding='utf-8')
    for a,b in pairs:
        assert code.count(a)==1,(source,a)
        code=code.replace(a,b)
    compile(code,str(target),'exec')
    target.write_text(code,encoding='utf-8',newline='\n')
tracked='benchmarks/results/2026-11-23-owned-class-module-slots/'
pushed=lambda name:git('show','origin/master:'+tracked+name)
proof=json.loads(pushed('identity.json'))
status=json.loads(pushed('terminal-status.json'))['receipt']
assert status['complete'] and status['allWorkersJoined'] and status['archivedAndVerifiedUnderLease']
assert sha(pushed('observations.tar.xz'))==status['archiveSHA256']
head=git('rev-parse','origin/master').decode().strip()
retained=proof['retainedRevision']
assert not git('diff','--name-only',retained,head,'--','src')
assert not git('diff','--name-only',retained,proof['candidate'],'--','src')
files=proof['imageFiles']['candidate']
image=donor/'candidate'
assert len(files)==32 and all(digest(image/name)==value for name,value in files.items())
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==proof['cpythonWorkerSHA256']
catalog=read(donor/'comparison/representative.json')
quote=next(case for case in catalog['cases'] if case['id']=='scripts.csv-invoice.method-policy.quoted-control')
catalog['cases']=[quote]
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',[[quote['id'],'warm'],[quote['id'],'compile-run'],[quote['id'],'compile']])
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
verified=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verified],
    env=env,check=True,timeout=85)
verification=read(verified)
assert verification['state']=='Completed' and verification['caseCount']==1
assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert all(digest(image/name)==value for name,value in files.items())
remote='/home/lokad/lython-bench-checks'
run='owned-class-cpython-b1534-20261123'
base='terminal-tuple-reads-b1531-20261123'
write(quiet/'identity.json',dict(sourceRevision=retained,candidate=proof['candidate'],retainedRevision=retained,deliveryRevision=head,
    frozenImage=remote+'/'+run+'/candidate',imageFiles=proof['imageFiles'],
    auxiliaryFiles={name:value for name,value in files.items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(quiet/name)) for name in ('representative.json','jobs.json')}))
past=collection/'comparison/quiet'
adapt(past/'collect.py',quiet/'collect.py',(('lython-b1521-fixtures','lython-b1534-fixtures'),
     ('CPython checkpoint after deferred CSV fields','CPython checkpoint for the retained quote-heavy invoice')))
adapt(past/'summarize.py',quiet/'summarize.py',())
shutil.copyfile(past/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in ('identity.json','representative.json','jobs.json','run.sh','collect.py'):
        archive.add(quiet/name,arcname=name)
write(quiet/'upload.json',dict(root=run,reference=base,original='plain-class-namespace-b1533-20261123',originalArchive=status['archiveSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=digest(payload)))
adapt(collection/'quiet.py',lab/'quiet.py',(
    ('lython-b1521-short-csv-utf8-cpython-20261123','lython-b1534-owned-class-20261123'),
    ('.+b1521-','.+b1534-'),('lython-b1521-stage-','lython-b1534-stage-'),
    ('A 65 MiB','A 20 MiB'),('65 * 1024 * 1024','20 * 1024 * 1024'),
    ("digest(reference/'candidate'/name)","digest(reference/'candidate'/name)"),
    
))

