from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.with_name('closed-factory-cpython-20261123')
source = (prior / 'prepare.py').read_text(encoding='utf-8')
edits = (
    ("donor=lab.parent/'closed-factory-operand-20261123'", "donor=lab.parent/'plain-class-fixed-20261123'"),
    ('2026-11-23-closed-factory-operand/', '2026-11-23-owned-class-module-slots/'),
    ('''postponed,eager,*_=catalog['cases']
assert 'postponed' in postponed['id'] and 'nested-factories' in eager['id']
catalog['cases']=[postponed,eager]''', '''quote=next(case for case in catalog['cases'] if case['id']=='scripts.csv-invoice.method-policy.quoted-control')
catalog['cases']=[quote]'''),
    ('''write(quiet/'jobs.json',[[postponed['id'],'warm'],[postponed['id'],'compile-run'],
    [postponed['id'],'compile'],[eager['id'],'warm']])''',
     '''write(quiet/'jobs.json',[[quote['id'],'warm'],[quote['id'],'compile-run'],[quote['id'],'compile']])'''),
    ("verification['caseCount']==2", "verification['caseCount']==1"),
    ('closed-factory-cpython-b1530-20261123', 'owned-class-cpython-b1534-20261123'),
    ('supplied-lexical-call-b1526-20261123', 'terminal-tuple-reads-b1531-20261123'),
    ('''(('len(jobs) == 3','len(jobs) == 4'),('<175,','<220,'),
    ('lython-b1521-fixtures','lython-b1530-fixtures'),('CPython checkpoint after deferred CSV fields','CPython checkpoint for retained closed factory operands'))''',
     '''(('lython-b1521-fixtures','lython-b1534-fixtures'),
     ('CPython checkpoint after deferred CSV fields','CPython checkpoint for the retained quote-heavy invoice'))'''),
    ('''(('len(raw["jobs"])==3','len(raw["jobs"])==4'),
    ('receipt["warmJobs"]==3','receipt["warmJobs"]==4'))''', '()'),
    ("original='closed-factory-operand-b1529-20261123'", "original='plain-class-namespace-b1533-20261123'"),
    ('lython-b1530-closed-factory-20261123', 'lython-b1534-owned-class-20261123'),
    ('.+b1530-', '.+b1534-'),
    ('lython-b1530-stage-', 'lython-b1534-stage-'),
    ("('Three bounded lanes','Two bounded lanes'),('A 65 MiB','A 32 MiB'),('65 * 1024 * 1024','32 * 1024 * 1024')",
     "('A 65 MiB','A 20 MiB'),('65 * 1024 * 1024','20 * 1024 * 1024')"),
    ("('RuntimeMaxSec=210','RuntimeMaxSec=260'),('seconds=157','seconds=206'),", ''),
)
for old, new in edits:
    assert source.count(old) == 1, old
    source = source.replace(old, new)
compile(source, 'prepare.py', 'exec')
(lab / 'prepare.py').write_text(source, encoding='utf-8', newline='\n')
