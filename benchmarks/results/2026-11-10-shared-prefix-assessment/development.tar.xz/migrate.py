from pathlib import Path
home=Path(__file__).parent;runtime=home/'tree/src/Lokad.Lython/Runtime'
changed=[]
for p in runtime.glob('*Executable*.cs'):
    if p.name=='LythonRuntime.Executable.Operands.cs':continue
    s=p.read_text();old=s
    s=s.replace('ref ExecutableWorkState execution','ref ExecutableWorkView execution').replace('in ExecutableWorkState execution','in ExecutableWorkView execution')
    s=s.replace('AdoptExecutableExecution(ref ExecutableWorkView execution','AdoptExecutableExecution(ref ExecutableWorkState execution')
    if p.name=='LythonRuntime.Executable.Binding.cs':s=s.replace('object[] locals, int slot','ReadOnlySpan<object> locals, int slot')
    if p.name=='LythonRuntime.Executable.Interpreter.Dispatch.cs':
        marker='        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkView execution'
        wrapper='''        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState state, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            return ExecuteInstructionPrefix(ref view, scope, invocation, asynchronous, out pending, out pendingSpan);
        }

'''
        assert marker in s;s=s.replace(marker,wrapper+marker)
    if s!=old:p.write_text(s,newline='\n');changed.append(p.name)
(home/'migration-files.txt').write_text('\n'.join(changed)+'\n')
print('Prototype shared-prefix signatures migrated:',len(changed),'files; compile errors identify remaining array-specific consumers.')
