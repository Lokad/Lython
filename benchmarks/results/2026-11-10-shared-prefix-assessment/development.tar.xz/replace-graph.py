from pathlib import Path
home=Path(__file__).parent;core=home/'tree/src/Lokad.Lython';front=core/'Frontend';runtime=core/'Runtime'
p=front/'ExecutableScript.cs';s=p.read_text();s=s.replace('        NativeInput = int.MaxValue;\n','').replace('    public int NativeInput { get; init; }\n','')
s=s.replace('// Executable argument forms retain direct native sources for eligible bodies;\n// ordinary binding uses the same existing form array.','// Calls retain the original argument forms for ordinary binding.')
s=s.replace('    public int NativeArgumentSource(int index) => (uint)index < (uint)Arguments.Length\n        ? Arguments[index].NativeInput : int.MaxValue;\n','')
s=s.replace('        NativeBody = PrepareNativeBody(blocks, entryBlockIndex, exceptionRegions.Count, callSites);\n','')
s=s.replace('// Assign physical positions after forwarding. Native proof metadata is\n        // independent of these positions, including when a runtime guard fails.','// Assign the physical positions consumed by execution and closed-call proofs.')
marker='''        }).ToArray();
    }

    public string Name''';assert marker in s
s=s.replace(marker,'''        }).ToArray();
        SupportsClosedPrefix = PrepareClosedPrefix(out var branches);
        HasClosedPrefixBranches = SupportsClosedPrefix && branches;
    }

    public string Name''')
s=s.replace('    public ExecutableNativeBody? NativeBody { get; }','    internal const int ClosedOperandCapacity = 64;\n    public bool SupportsClosedPrefix { get; }\n    public bool HasClosedPrefixBranches { get; }')
p.write_text(s)
(front/'ExecutableScript.NativeReturns.cs').unlink();(front/'ExecutableNativeBody.cs').unlink()
(front/'ExecutableScript.ClosedPrefix.cs').write_text('''namespace Lokad.Lython.Frontend;

internal sealed partial class ExecutableCodeObject
{
    // Reuse the finished instruction stream. There is no second expression
    // representation or native argument-source domain to construct or retain.
    private bool PrepareClosedPrefix(out bool hasBranches)
    {
        hasBranches = false;
        if (!IsFunctionScope || RequiresLocalVariableMirroring || CapturedLocalSlots.Count != 0
            || ClosureNames.Count != 0 || ExceptionRegions.Count != 0 || ValueStorageCapacity > ClosedOperandCapacity)
            return false;
        var visited = new bool[Instructions.Length];
        var branches = false;
        var eligible = Visit(EntryIndex, false, 0);
        hasBranches = branches;
        return eligible;

        bool Visit(int position, bool hasEffects, int depth)
        {
            // An optimization bound, preserving the existing managed proof depth.
            // Wider/control-heavy functions continue through ordinary execution.
            if (depth > 16) return false;
            while ((uint)position < (uint)Instructions.Length)
            {
                if (visited[position]) return false; // cycles or shared joins
                visited[position] = true;
                var instruction = Instructions[position];
                switch (instruction.OpCode)
                {
                    case ExecutableOpCode.Jump:
                        position = instruction.TargetIndex;
                        continue;
                    case ExecutableOpCode.JumpIfFalse:
                        branches = true;
                        return Visit(position + 1, hasEffects, depth + 1)
                            && Visit(instruction.TargetIndex, hasEffects, depth + 1);
                    case ExecutableOpCode.Return or ExecutableOpCode.ReturnNone:
                        return true;
                    case ExecutableOpCode.LoadLocal or ExecutableOpCode.LoadConst or ExecutableOpCode.StoreLocal
                        or ExecutableOpCode.LoadCallMember:
                        break;
                    case ExecutableOpCode.LoadGlobal or ExecutableOpCode.Subscript:
                        // Admission can change a later mutable lookup. A proof
                        // cannot authorize that lookup before earlier work runs.
                        if (hasEffects) return false;
                        break;
                    case ExecutableOpCode.Call:
                        var call = CallSites[instruction.CallSiteIndex];
                        if (!call.IsPositionalOnly || call.ArgumentCount > 3) return false;
                        hasEffects = true;
                        break;
                    case ExecutableOpCode.Binary or ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple
                        or ExecutableOpCode.ConvertFormattedValue:
                        hasEffects = true;
                        break;
                    case ExecutableOpCode.FormatField:
                        if (Constants[instruction.ConstantIndex] is not ExecutableFormatField { DynamicSpecifier: false, Append: false })
                            return false;
                        hasEffects = true;
                        break;
                    default:
                        return false;
                }
                position++;
            }
            return false;
        }
    }
}
''',newline='\n')
p=runtime/'PyExecutableFunction.cs';s=p.read_text().replace('_codeObject.NativeBody is null','!_codeObject.SupportsClosedPrefix');p.write_text(s)
p=runtime/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text().replace('function.CodeObject.NativeBody is not null','function.CodeObject.SupportsClosedPrefix');p.write_text(s)
p=runtime/'LythonRuntime.Executable.Operands.cs';s=p.read_text().replace('        internal readonly ExecutableCodeObject Code => _state.Code;','        internal readonly ExecutableCodeObject Code;').replace('            _state = ref state;','            _state = ref state;\n            Code = state.Code;');p.write_text(s)
p=runtime/'LythonRuntime.Executable.NativeReturn.cs';old=p.read_text()
shape=old[old.index('    internal enum NativeReturnShape'):old.index('    private static bool TryReadNativeInput')]
shape=shape.replace('NativeReturnShape { Other,','NativeReturnShape { Uninitialized, Other,')
body=old[old.index('    [System.Runtime.CompilerServices.InlineArray(64)]'):old.index('    internal enum NativeReturnShape')]
body=body.replace('[System.Runtime.CompilerServices.InlineArray(64)]','[System.Runtime.CompilerServices.InlineArray(ExecutableCodeObject.ClosedOperandCapacity)]').replace('ExecutableCodeObject code, ExecutableNativeBody body,','ExecutableCodeObject code,').replace('Code = code, Stack = new(code, context)','Code = code, Stack = new(code, context), InstructionIndex = code.EntryIndex')
entry='''using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static bool TryExecuteNativeReturn(ExecutableCodeObject codeObject, ExecutionContext context,
        ReadOnlySpan<object?> arguments, LythonSourceSpan entrySpan, out object result)
    {
        result = PyNone.Instance;
        if (!codeObject.SupportsClosedPrefix || context.MirrorLocalStores || context.CurrentExecutableFrame is not null
            || context.ActiveHandlerVariables is { Count: > 0 }) return false;
        if (!GuardClosedPrefix(codeObject, arguments, context)) return false;
        result = ExecuteNativeBody(codeObject, context, arguments, entrySpan);
        return true;
    }

    internal static bool TryExecuteNativeFunction(ExecutableCodeObject code, ExecutionContext context,
        ReadOnlySpan<object?> arguments, string name, LythonSourceSpan span, out object result)
    {
        result = PyNone.Instance;
        if (!code.SupportsClosedPrefix || !GuardClosedPrefix(code, arguments, context)) return false;
        context.EnterFunctionCall(span);
        try { result = ExecuteNativeBody(code, context, arguments, span); return true; }
        catch (LythonRuntimeException error)
        {
            PyFunctionBinding.AnnotateException(error, context, name, span);
            throw;
        }
        finally { context.LeaveFunctionCall(); }
    }

'''
p.write_text(entry+body+shape+'}\n',newline='\n')
p=runtime/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text();start=s.index('    private static bool TryGetClosedStringCallShape(')
s=s[:start]+'''    private static bool TryGetClosedStringCallShape(ReceiverMethod method, int count,
        NativeReturnShape second, NativeReturnShape third, NativeReturnShape fourth, out NativeReturnShape shape)
    {
        shape = NativeReturnShape.Other;
        if (ReferenceEquals(method, ReceiverMethods.StringSplit) && count is 1 or 2)
        {
            shape = NativeReturnShape.Sized;
            return second is NativeReturnShape.None or NativeReturnShape.String
                && third is NativeReturnShape.None or NativeReturnShape.Integer or NativeReturnShape.Boolean;
        }
        if (ReferenceEquals(method, ReceiverMethods.StringReplace) && count is 2 or 3)
        {
            shape = NativeReturnShape.String;
            return second == NativeReturnShape.String && third == NativeReturnShape.String
                && fourth is NativeReturnShape.None or NativeReturnShape.Integer or NativeReturnShape.Boolean;
        }
        if ((ReferenceEquals(method, ReceiverMethods.StringStartsWith) || ReferenceEquals(method, ReceiverMethods.StringEndsWith)) && count == 1)
        {
            shape = NativeReturnShape.Boolean;
            return second == NativeReturnShape.String;
        }
        return false;
    }

    private static bool TrySelectClosedStringCall(object target, ReadOnlySpan<object?> arguments, out ReceiverMethod method)
    {
        method = target as ReceiverMethod ?? null!;
        return method is not null && TryGetClosedStringCallShape(method, arguments.Length,
            arguments.Length > 0 ? ReturnShape(arguments[0]) : NativeReturnShape.None,
            arguments.Length > 1 ? ReturnShape(arguments[1]) : NativeReturnShape.None,
            arguments.Length > 2 ? ReturnShape(arguments[2]) : NativeReturnShape.None, out _);
    }

    private static object InvokeClosedStringCall(ReceiverMethod method, PyString receiver,
        ReadOnlySpan<object?> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        try
        {
            if (ReferenceEquals(method, ReceiverMethods.StringSplit))
                return InvokeStringSplit(receiver, arguments[0], arguments.Length > 1 ? arguments[1] : null, span, context);
            if (ReferenceEquals(method, ReceiverMethods.StringReplace))
                return InvokeStringReplace(receiver, arguments[0]!, arguments[1]!, arguments.Length > 2 ? arguments[2] : null, span, context);
            return InvokeStringAffix(receiver, arguments[0]!, span, context, ReferenceEquals(method, ReceiverMethods.StringStartsWith));
        }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
    }
}
''';p.write_text(s,newline='\n')
p=home/'tree/tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs';s=p.read_text().replace('Assert.NotNull(code.NativeBody);','Assert.True(code.SupportsClosedPrefix);').replace('Assert.Null(code.NativeBody);','Assert.False(code.SupportsClosedPrefix);');p.write_text(s)
print('Removed native body/value graph, expression preparation and native argument-source metadata. Finished-IR eligibility and runtime proof remain to compile/qualify.')
