from pathlib import Path
r=Path(__file__).parent/'tree/src/Lokad.Lython/Runtime'
p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text();idx=s.rfind('\n}')
new='''
    private static bool TryGetClosedStringCallShape(Frontend.NativeReturnOperation operation,
        NativeReturnShape second, NativeReturnShape third, NativeReturnShape fourth, out NativeReturnShape shape)
    {
        shape = operation switch
        {
            Frontend.NativeReturnOperation.Split => NativeReturnShape.Sized,
            Frontend.NativeReturnOperation.Replace => NativeReturnShape.String,
            _ => NativeReturnShape.Boolean,
        };
        return operation switch
        {
            Frontend.NativeReturnOperation.Split => second is NativeReturnShape.None or NativeReturnShape.String
                && third is NativeReturnShape.None or NativeReturnShape.Integer or NativeReturnShape.Boolean,
            Frontend.NativeReturnOperation.Replace => second == NativeReturnShape.String && third == NativeReturnShape.String
                && fourth is NativeReturnShape.None or NativeReturnShape.Integer or NativeReturnShape.Boolean,
            Frontend.NativeReturnOperation.StartsWith or Frontend.NativeReturnOperation.EndsWith => second == NativeReturnShape.String,
            _ => false,
        };
    }

    private static bool TrySelectClosedStringCall(object target, ReadOnlySpan<object?> arguments,
        out Frontend.NativeReturnOperation operation)
    {
        operation = ReferenceEquals(target, ReceiverMethods.StringSplit) && arguments.Length is 1 or 2 ? Frontend.NativeReturnOperation.Split
            : ReferenceEquals(target, ReceiverMethods.StringReplace) && arguments.Length is 2 or 3 ? Frontend.NativeReturnOperation.Replace
            : ReferenceEquals(target, ReceiverMethods.StringStartsWith) && arguments.Length == 1 ? Frontend.NativeReturnOperation.StartsWith
            : ReferenceEquals(target, ReceiverMethods.StringEndsWith) && arguments.Length == 1 ? Frontend.NativeReturnOperation.EndsWith
            : Frontend.NativeReturnOperation.None;
        return operation != Frontend.NativeReturnOperation.None && TryGetClosedStringCallShape(operation,
            arguments.Length > 0 ? ReturnShape(arguments[0]) : NativeReturnShape.None,
            arguments.Length > 1 ? ReturnShape(arguments[1]) : NativeReturnShape.None,
            arguments.Length > 2 ? ReturnShape(arguments[2]) : NativeReturnShape.None, out _);
    }

    private static object InvokeClosedStringCall(Frontend.NativeReturnOperation operation, PyString receiver,
        ReadOnlySpan<object?> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        try
        {
            return operation switch
            {
                Frontend.NativeReturnOperation.Split => InvokeStringSplit(receiver, arguments[0], arguments.Length > 1 ? arguments[1] : null, span, context),
                Frontend.NativeReturnOperation.Replace => InvokeStringReplace(receiver, arguments[0]!, arguments[1]!, arguments.Length > 2 ? arguments[2] : null, span, context),
                Frontend.NativeReturnOperation.StartsWith or Frontend.NativeReturnOperation.EndsWith => InvokeStringAffix(receiver, arguments[0]!, span, context, operation == Frontend.NativeReturnOperation.StartsWith),
                _ => throw new InvalidOperationException("Unknown closed string operation."),
            };
        }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
    }
'''
s=s[:idx]+new+s[idx:];p.write_text(s)
p=r/'LythonRuntime.Executable.NativeReturn.cs';s=p.read_text();start=s.index('        switch (value.Operation)',s.index('        if (first != NativeReturnShape.String) return false;'));end=s.index('\n    private static bool GuardNativeFormattedValue',start)
s=s[:start]+'''        return TryGetClosedStringCallShape(value.Operation, second, third, fourth, out shape);
    }
'''+s[end:];p.write_text(s)
p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text();marker='            var argument = call.ArgumentCount == 0 ? null : execution.Stack[start + call.ArgumentOffset];'
new='''            if (call.HasReceiver && call.IsPositionalOnly && execution.Stack[start] is PyString text)
            {
                var inputs = execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount);
                if (TrySelectClosedStringCall(target, inputs, out var operation))
                {
                    try
                    {
                        var value = InvokeClosedStringCall(operation, text, inputs, call.CallSpan, scope);
                        PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[execution.InstructionIndex], value);
                        return true;
                    }
                    catch { execution.Stack.RetireTo(start); throw; }
                }
            }

''';assert marker in s;s=s.replace(marker,new+marker);p.write_text(s)
