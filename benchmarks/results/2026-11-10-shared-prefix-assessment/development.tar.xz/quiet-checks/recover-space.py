from pathlib import Path
import hashlib, json, subprocess

home=Path(__file__).parent
script=(home/'space-recovery-command.py').read_text(encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(home/'space-recovery.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
data=json.loads(done.stdout)
(home/'space-recovery.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Exact idle-space proof:', data.get('beforeFreeBytes'), 'to',data.get('afterFreeBytes'),'; removed copies',len(data.get('files',[])),'unavailable',data.get('unavailable',[]))
