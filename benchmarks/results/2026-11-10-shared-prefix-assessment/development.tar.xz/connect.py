from pathlib import Path
home=Path(__file__).parent;runtime=home/'tree/src/Lokad.Lython/Runtime'
p=runtime/'LythonRuntime.Executable.Operands.cs';s=p.read_text().replace('internal int InstructionIndex { readonly get => _state.InstructionIndex; set => _state.InstructionIndex = value; }','internal ref int InstructionIndex => ref _state.InstructionIndex;');p.write_text(s)
p=runtime/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text().replace('execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount).Span','execution.Stack.Slice(start + call.ArgumentOffset, call.ArgumentCount)');p.write_text(s)
for name,method in [('LythonRuntime.Executable.Interpreter.cs','StoreLocalValue'),('LythonRuntime.Executable.Binding.cs','AssignExecutableBoundName')]:
 p=runtime/name;s=p.read_text();start=s.index('private static void '+method);end=s.index('\n        }'if name.endswith('Interpreter.cs')else'\n    }',start)
 chunk=s[start:end].replace('object[] locals','Span<object> locals');s=s[:start]+chunk+s[end:];p.write_text(s)
p=runtime/'LythonRuntime.Executable.Operations.cs';s=p.read_text().replace('ref ExecutableValueStorage stack','ref ExecutableValueStorage.Window stack').replace('in ExecutableValueStorage storage, int first','in ExecutableValueStorage.Window storage, int first').replace('in ExecutableValueStorage storage, ExecutableSliceParts parts','ReadOnlySpan<object> storage, ExecutableSliceParts parts');p.write_text(s)
for p in runtime.glob('*Executable*.cs'):
 s=p.read_text();old=s
 for expr in ['storage','_execution.Stack']:s=s.replace('ReadExecutableSliceBounds(in '+expr+',','ReadExecutableSliceBounds('+expr+'.Values,')
 if s!=old:p.write_text(s)
p=runtime/'LythonRuntime.Executable.Operands.cs';s=p.read_text();marker='    internal partial struct ExecutableValueStorage'
wrappers='''    internal sealed partial class ExecutionContext
    {
        private static object ReadOperand(ref ExecutableWorkState state, int source, ExecutionContext scope, int input)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            return ReadOperand(ref view, source, scope, input);
        }
        private static object TakeOperand(ref ExecutableWorkState state, in ExecutableInstruction instruction, ExecutionContext scope)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            return TakeOperand(ref view, instruction, scope);
        }
        private static bool CompleteComparisonBranch(ref ExecutableWorkState state, ExecutionContext context, in ExecutableInstruction instruction, bool truth)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            return CompleteComparisonBranch(ref view, context, instruction, truth);
        }
        private static void ExecuteStackTransfer(ref ExecutableWorkState state, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            ExecuteStackTransfer(ref view, scope, invocation, instruction);
        }
        private static void ExecuteSliceValueOperation(ref ExecutableWorkState state, ExecutionContext scope, ExecutionContext? invocation, in ExecutableInstruction instruction)
        {
            var view = new ExecutableWorkView(ref state, state.Stack.Values);
            ExecuteSliceValueOperation(ref view, scope, invocation, instruction);
        }
    }

'''
assert marker in s;s=s.replace(marker,wrappers+marker);p.write_text(s)
p=runtime/'LythonRuntime.Executable.Results.cs';s=p.read_text().replace('''            => PublishInstructionResult(ref _execution, this, instruction, value);''','''        {
            var view = new ExecutableWorkView(ref _execution, _execution.Stack.Values);
            PublishInstructionResult(ref view, this, instruction, value);
        }''');p.write_text(s)
