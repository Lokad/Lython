from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;out=root/'benchmarks/results/2026-11-10-shared-prefix-assessment';out.mkdir()
for source,target in [('phase2-identity.json','original-identity.json'),('phase2-desktop.json','original-desktop.json'),('refined/identity.json','identity.json'),('refined/summary.json','refined-desktop.json'),('record-comparison/summary.json','record-desktop.json'),('record-comparison/golden.json','record-golden.json'),('record-python-goldens.json','record-python-goldens.json')]:shutil.copyfile(home/source,out/target)
for name in ['summary.json','observations.tgz','archive-receipt.json','terminal-status.json','space-recovery.json','identity.json','contract.md','payload-sizing.json']:
 p=home/'b526'/name;dst=out/'quiet'/name;dst.parent.mkdir(exist_ok=True)
 if p.exists():shutil.copyfile(p,dst)
with tarfile.open(out/'development.tar.xz','w:xz')as t:
 for p in home.iterdir():
  if p.is_file():t.add(p,arcname=p.name)
 for directory in ['compare-warm-sync','compare-compile-sync','record-comparison']:
  t.add(home/directory,arcname=directory)
 for p in(home/'refined').iterdir():
  if p.is_file():t.add(p,arcname='refined/'+p.name)
 for p in(home/'b526').iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz','current-core.dll']:t.add(p,arcname='quiet-checks/'+p.name)
 t.add(home/'images/candidate/Lokad.Lython.dll',arcname='original-core.dll')
(out/'status.json').write_text(json.dumps(dict(status='Active isolated prototype, not promoted. Quiet text CPU regression requires attribution/refinement or an explicit debt/withdrawal decision.',baseline='Qualified ee448715-equivalent core; main b3ddd6df remains unchanged',focused=dict(publicEachTarget=3625,internalReentryEachTarget=39,stackAdmissionInternalEachTargetBeforeCacheFix=69,stackPublicEachTarget=60),removed=['NativeReturnValue/ExecutableNativeBody','native expression preparation','native argument-source metadata/mutation','recursive native evaluator'],originalFailure='Shared record lookup cache admission invalidated entry proof; recorded failing regression. Native inline windows now cannot allocate persistent lookup storage.',quiet=dict(jobs=5,seconds=141.4014337430708,terminalCached=True,remainingWorkersAndFixtures=False,archiveSHA256=hashlib.sha256((out/'quiet/observations.tgz').read_bytes()).hexdigest()),publication='Postponed'),indent=2)+'\n')
# Preserve the independent semantic coverage on the delivered runtime too.
p=root/'tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs';s=p.read_text();candidate=(home/'tree/tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs').read_text()
start=candidate.index('        { "record-locals-and-retained-aliases"');end=candidate.index('        { "captured-read-before-and-after-binding"',start)
assert 'record-locals-and-retained-aliases'not in s
marker='    public static TheoryData<string, string, string> Cases => new()\n    {\n';assert marker in s
p.write_text(s.replace(marker,marker+candidate[start:end]))
print('All original/refined adverse data, failing reentry source, frozen cores and owned quiet evidence retained. Two independent record semantic cases added to main, no runtime source promotion.')
