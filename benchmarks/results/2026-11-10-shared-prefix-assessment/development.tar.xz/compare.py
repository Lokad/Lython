from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
home=Path(__file__).parent;tree=home/'tree';env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
with(home/'freeze11.log').open('w',encoding='utf-8')as out:
 done=subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'],cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(home/'freeze11.log').read_text()[-3000:]
print('Fresh nonincremental prototype freeze complete.',flush=True)
shutil.copytree(home.parent/'handler-native-entry-r179/images/candidate',home/'images/before')
shutil.copytree(home/'images/before',home/'images/candidate')
shutil.copyfile(tree/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',home/'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes()==(home/'images/candidate'/p.relative_to(home/'images/before')).read_bytes()
 for p in(home/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
shutil.copyfile(home.parent/'json-terminal-storage-r178/catalog.json',home/'catalog.json')
(home/'phase2.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=tree,stderr=subprocess.DEVNULL))
(home/'phase2-identity.json').write_text(json.dumps(dict(base='ee448715-equivalent qualified production',prototype='R180 shared span prefix; no native value graph/preparation or recursive evaluator; no public APIs or budget policies changed',
 cores={role:hashlib.sha256((home/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},
 source={p.relative_to(tree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(tree/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},
 catalogSHA256=hashlib.sha256((home/'catalog.json').read_bytes()).hexdigest(),checks=dict(public11=3623,public10=3625,newRecordAndCalls11=81,internalEachTarget=69,stackPublicEachTarget=60,pythonRecordGoldens=2),
 qualification='Focused only; full delivery pending. Same existing frozen worker/auxiliary files; desktop elapsed diagnostic, allocation separate.'),indent=2)+'\n')
summary={}
for phase,api in [('warm','sync'),('compile','sync')]:
 folder=home/('compare-'+phase+'-'+api);folder.mkdir()
 witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
 with(folder/'measurements.json').open('w',encoding='utf-8')as out,(folder/'stderr.txt').open('w',encoding='utf-8')as err:
  done=subprocess.run([dotnet,str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(home/'images/before/Lokad.Lython.Benchmarks.dll'),str(home/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(home/'catalog.json'),str(witness),'reverse',phase,api],env=env,stdout=out,stderr=err,timeout=120)
 assert done.returncode==0,(folder/'stderr.txt').read_text()[-3000:]
 raw=json.loads((folder/'measurements.json').read_text())
 assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for case in raw['observations']:
  roles={role:{key:statistics.median(s[field]/s['jobs']for s in case['samples']if s['image']==role)for key,field in [('bytes','allocatedBytes'),('elapsedMs','elapsedMilliseconds'if phase=='compile'else'executionMilliseconds')]}for role in ['before','before-control','candidate']}
  row=dict(case=case['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});rows.append(row)
  print(phase,row['case'],row['changes'],flush=True)
 summary[phase+'-'+api]=rows
 (home/'phase2-desktop.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Five complete-script outputs/balances/isolation/cleanup pass. Desktop timings remain diagnostic.',flush=True)
