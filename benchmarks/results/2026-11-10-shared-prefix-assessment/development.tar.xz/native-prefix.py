from pathlib import Path
home=Path(__file__).parent;r=home/'tree/src/Lokad.Lython/Runtime'
p=r/'LythonRuntime.Executable.Operands.cs';s=p.read_text().replace('    internal partial struct ExecutableValueStorage\n    {','''    internal partial struct ExecutableValueStorage
    {
        internal ExecutableValueStorage(ExecutableCodeObject code, ExecutionContext scope)
        {
            this = default;
            _items = [];
            _state = scope.State;
            _firstTemporarySlot = code.FirstTemporarySlot;
            _lastOwnedTemporarySlot = code.LastOwnedTemporarySlot;
            LiveExtent = code.FirstTemporarySlot;
        }
''');p.write_text(s)
p=r/'LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text();marker='        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState state'
new='''        internal static void ExecuteClosedInstructionPrefix(ref ExecutableWorkView execution, ExecutionContext scope)
        {
            if (ExecuteInstructionPrefix(ref execution, scope, null, false, out _, out _) != InstructionPause.Boundary)
                throw new InvalidOperationException("Closed helper proof requires unsupported instruction work.");
        }

''';assert marker in s;s=s.replace(marker,new+marker);p.write_text(s)
p=r/'LythonRuntime.Executable.NativeReturn.cs';s=p.read_text();s=s.replace('if (body is null || context.MirrorLocalStores','if (body is null || codeObject.ValueStorageCapacity > 64 || context.MirrorLocalStores')
s=s.replace('''        var body = code.NativeBody!;
        if (!GuardNativeBody''','''        var body = code.NativeBody!;
        if (code.ValueStorageCapacity > 64) return false;
        if (!GuardNativeBody''')
start=s.index('    private static object ExecuteNativeBody(');end=s.index('    private static void CheckNativeReturnExit',start)
new='''    [System.Runtime.CompilerServices.InlineArray(64)]
    private struct ClosedOperandBuffer { private object _first; }

    private static object ExecuteNativeBody(ExecutableCodeObject code, ExecutableNativeBody body,
        ExecutionContext context, ReadOnlySpan<object?> arguments, LythonSourceSpan entrySpan)
    {
        context.EnterInterpreterFrame(entrySpan);
        try
        {
            ClosedOperandBuffer buffer = default;
            Span<object> values = buffer;
            values = values[..code.ValueStorageCapacity];
            values[..code.FirstTemporarySlot].Fill(UninitializedLocal);
            for (var i = 0; i < arguments.Length; i++) values[i] = RuntimeValue(arguments[i]);
            var work = new ExecutableWorkState { Code = code, Stack = new(code, context) };
            var view = new ExecutableWorkView(ref work, values);
            var entryException = context.State.CurrentException;
            try
            {
                ExecutionContext.ExecuteClosedInstructionPrefix(ref view, context);
                return work.ReturnValue ?? PyNone.Instance;
            }
            finally
            {
                try { view.Stack.RetireTo(0); }
                finally { values.Clear(); context.State.SetCurrentException(entryException); }
            }
        }
        finally { context.LeaveInterpreterFrame(); }
    }

''';s=s[:start]+new+s[end:];p.write_text(s)
print('Native calls use shared prefix with bounded managed scratch. Old guard graph remains active pending replacement; recursive evaluator still present only until semantic census.')
