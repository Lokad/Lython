from pathlib import Path
import base64,hashlib,json,os,statistics,subprocess
home=Path(__file__).parent;folder=home/'record-comparison';folder.mkdir()
catalog=json.loads((home/'catalog.json').read_text());case=next(c for c in catalog['cases']if c['id']=='scripts.csv-validated-records.large')
old=case['source'];assert old.count("amount = int(record['amount'])")==1
source=old.replace('\n\ndef validated_record',"\n\ndef parse_amount(record):\n    return int(record['amount'])\n\n\ndef validated_record").replace("amount = int(record['amount'])","amount = parse_amount(record)")
assert source.count('def parse_amount(')==1 and source.count('amount = parse_amount(record)')==1
case.update(source=source,sourceUtf8Bytes=len(source.encode('utf-8')),sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest())
(folder/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
fixture=json.loads(case['fixtureJson']);reference=folder/'python-reference';reference.mkdir()
for name,encoded in fixture['inputFiles'].items():
 p=reference/name;assert p.resolve().is_relative_to(reference.resolve());p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded))
(reference/'workload.py').write_text(source,encoding='utf-8')
r=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','workload.py'],cwd=reference,capture_output=True,encoding='utf-8',timeout=15)
assert r.returncode==0 and r.stdout==case['expectedOutput'],(r.stdout,r.stderr)
for name,encoded in fixture['outputFiles'].items():assert(reference/name).read_bytes()==base64.b64decode(encoded),name
(folder/'golden.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated; output only, not timing',sourceSHA256=case['sourceSha256'],fixtureSHA256=case['fixtureSha256'],stdout=r.stdout,description='Complete validated CSV script with one ordinary conversion helper. Same input/files/stdout as maintained catalog; canonical ID required by reused diagnostic driver. Not the published source.'),indent=2)+'\n')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
with(folder/'measurements.json').open('w',encoding='utf-8')as out,(folder/'stderr.txt').open('w',encoding='utf-8')as err:
 r=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(home/'images/before/Lokad.Lython.Benchmarks.dll'),str(home/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(folder/'catalog.json'),str(witness),'reverse','warm','sync'],env=env,stdout=out,stderr=err,timeout=120)
assert r.returncode==0,(folder/'stderr.txt').read_text()[-3000:]
raw=json.loads((folder/'measurements.json').read_text());assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
summary=[]
for c in raw['observations']:
 roles={role:{key:statistics.median(s[field]/s['jobs']for s in c['samples']if s['image']==role)for key,field in [('bytes','allocatedBytes'),('elapsedMs','executionMilliseconds')]}for role in ['before','before-control','candidate']}
 row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});summary.append(row);print(row['case'],row['changes'],flush=True)
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
