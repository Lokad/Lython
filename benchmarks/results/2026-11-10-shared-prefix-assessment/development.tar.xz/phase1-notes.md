# R180 continuation
+
+Main is clean and pushed b3ddd6df, runtime ee448715 fully qualified by cached
+GREEN42727417102. Never requery that run. B521/B522/B524/B525 terminal, SHA-verified,
+no workers/fixtures. B523 shell CRLF failure cleaned before guest work. No VM active.
+
+Isolated sparse worktree tree is detached at ee448715; 16 changed production files,
+including intent-to-add Operands.cs. phase1.patch captures the full source change.
+3623focused public and37reentry/ownership/refusal/exception white-box tests pass
+eachactual11/10. No active local processes. No timing/full prototype qualification.
+
+One span window replaces array-specific prefix operand transport. Persistent state
+still owns capacity/caches/disposal. Ordinary owner publication/retirement delegates
+to the same window methods. Native entry uses safe managed InlineArray64 scratch,
+existing guard before effects, same prefix, no recursive evaluator. Wider helpers
+decline before work, preserving supported ordinary execution. No Unsafe source,
+project unsafe flag, new budget, per-object ledger, pool or runtime limit.
+
+Original compiler rejects non-positional calls, >3 method arguments, late global/
+subscript reads after effects, captured/mirrored/protected functions and speculative
+formatted subscript reads in conditionals. Preserve these before broadening.
+Shared selector facts cover existing split/replace/affix shapes; custom operands
+still use the owned, suspendable ordinary route. No actual work may fall back.
+
+Next remove the remaining guard graph/compiler preparation. Inspect actual
+ExecutableScript.NativeReturns.cs and ExecutableNativeBody.cs plus native argument
+source metadata consumers before deletion. Compact proof facts should use existing
+IR/shared primitive contracts, not rename the whole graph or add an execution
+backend. The current bool/out shortcut remains synchronous; changing it to start
+async work requires owned promotion first. Existing graph is active temporary proof,
+not a completed simplification. Tests with real semantic coverage survive removal.
+
+The source census already disproved proposed duplicate work: JSON containers use a
+completed-value loop, escapes CopyString with bounded stack scratch, ordinary record
+prefixes fill directly/shared keys, CSV adopts funded arrays, compiled runners retain
+only real lowered consumers. Do not spend another pass proposing these as new work.
+
+No CPU claims until coherent replacement comparison. Temporary debt is allowed
+through completion, then explicitly decide. Main source remains separate/qualified.
+