from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;tree=home/'tree';old=home.parent/'handler-native-entry-r179/b522';dest=home/'b526';dest.mkdir()
local=json.loads((home/'refined/identity.json').read_text())
for name,digest in local['source'].items():assert hashlib.sha256((tree/name).read_bytes()).hexdigest()==digest,name
identity=json.loads((old/'identity.json').read_text())
identity['sourceRevision']='R180 uncommitted shared-prefix/finished-IR-proof prototype above ee448715; corrected shared-record cache reentry. Full source hashes/patch explicit. Compare qualified ee448715-equivalent core b49e50a6, not the older R173 image.'
identity['coreSHA256']={role:local['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']}
identity['catalogSHA256']=local['catalogSHA256']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for target,source in [('current-core.dll',home/'refined/images/candidate/Lokad.Lython.dll'),('representative.json',home/'refined/catalog.json'),('final-source.json',home/'refined/identity.json'),('source.patch',home/'refined/source.patch'),('golden.json',home/'record-comparison/golden.json')]:shutil.copyfile(source,dest/target)
baseline=json.loads((home.parent/'handler-native-entry-r179/identity.json').read_text())
(dest/'baseline-source.json').write_text(json.dumps(baseline,indent=2)+'\n')
with tarfile.open(dest/'source-checks.tar.xz','w:xz')as t:
 names=subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=tree,text=True).splitlines()
 for name in names:
  before=root/name;after=tree/name
  if after.exists():t.add(after,arcname='candidate/'+name)
  if before.exists():
   if name.startswith('src/Lokad.Lython/'):assert hashlib.sha256(before.read_bytes()).hexdigest()==baseline['productionSources'][before.as_posix()],name
   t.add(before,arcname='before/'+name)
 for p in home.glob('*.py'):t.add(p,arcname='commands/'+p.name)
 for p in home.glob('*.log'):t.add(p,arcname='qualification/'+p.name)
def adapt(text):return text.replace('handler-native-entry-b522-20261110','shared-operand-b526-20261110').replace('lython-b522-handler-native-entry-20261110','lython-b526-shared-operand-20261110').replace('lython-b522-fixtures','lython-b526-fixtures').replace('handler-native-entry-b522-launch','shared-operand-b526-launch').replace('R179 closed native calls under active handlers','R180 shared prefix and finished-IR proof')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 text=adapt((old/name).read_text())
 text=text.replace("'FramedFunctionExecutionTests.cs','LythonRuntime.Json.Serialize.cs','LythonRuntime.Json.Options.cs','PyExecutableFunction.cs',","'source-checks.tar.xz','golden.json',")
 (dest/name).write_text(text,newline='\n')
for name in ['setup-contract.json','sizing.json']:shutil.copyfile(old/name,dest/name)
(dest/'focused.json').write_text(json.dumps(dict(public11=3625,public10PriorCacheCorrection=3625,internalBoundaryEachTarget=39,internalPriorStackAdmissionEachTarget=69,publicPriorStackEachTarget=60,fullDeliveryPending=True),indent=2)+'\n')
contract='''R180 coherent shared instruction prefix, no native expression graph/evaluator,
separate expression lowering or native argument-source metadata. Managed span views,
existing ownership/cleanup, current cancellation. Shared-record reentry cache fix
included; original failing source/diagnostics retained. Not released/fully qualified.
CSV uses one ordinary parse_amount(record) helper in maintained validation script:
same fixtures/files/stdout, newSourceSHA, canonicalID required by existing driver.
Text/report/Unicode sources unchanged. Five existing jobs/four processes,
two/source,5srolewarmups,7rotated150msrounds, ordinary GC/tiering. Includes mediated
RAM I/O/full validation/prior-result cleanup, excludes startup/reset/protocol/final
caches. Wider processCPU separate; compilation desktop separate. Keep adversity.
Finite210s owner/30sstop/30smargin; owned join/unmount/archive/localSHA. No10minlane.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract,newline='\n')
assert b'\r'not in(dest/'run.sh').read_bytes()
with tarfile.open(dest/'payload.tgz','w:gz')as t:
 for p in sorted(dest.iterdir()):
  if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
payload=(dest/'payload.tgz').read_bytes()
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+65536+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),baselineAndAuxiliariesReused=True),indent=2)+'\n')
spec=[]
for remote,folder in [('ordinary-controls-b524-20261110','2026-11-10-handler-native-call-controls'),('cpython-checkpoint-b525-20261110','2026-11-10-current-cpython-checkpoint')]:
 p=root/'benchmarks/results'/folder/'observations.tgz';assert subprocess.check_output(['git','ls-files','--',p.relative_to(root).as_posix()],cwd=root,text=True).strip()==p.relative_to(root).as_posix()
 spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=p.as_posix(),tracked=True))
p=root/'benchmarks/results/2026-11-08-native-method-facts/observations.tar.xz'
assert subprocess.check_output(['git','ls-files','--',p.relative_to(root).as_posix()],cwd=root,text=True).strip()==p.relative_to(root).as_posix()
with tarfile.open(p)as t:data=t.extractfile('b450/observations.tgz').read()
spec.append(dict(path='/home/lokad/lython-bench-checks/native-method-facts-b450-20261108/observations.tgz',size=len(data),sha256=hashlib.sha256(data).hexdigest(),preservedLocal=p.as_posix(),preservedMember='b450/observations.tgz',outerSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),tracked=True))
script=adapt((old/'space-recovery-command.py').read_text()).replace('handler-native-entry-b522','shared-operand-b526').replace(str(json.loads((old/'payload-sizing.json').read_text())['requiredFreeBytes']),str(required))
script='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in script.splitlines())+'\n';(dest/'space-recovery-command.py').write_text(script)
(dest/'recover-space.py').write_text(adapt((old/'recover-space.py').read_text()))
script=adapt((old/'launch-command.py').read_text()).replace("reference=base/'string-index-storage-b518-20261109/candidate'","reference=base/'handler-native-entry-b522-20261110/candidate'")
script=script.replace("os.link(base/'string-index-storage-b518-20261109/current-core.dll'","os.link(base/'handler-native-entry-b522-20261110/current-core.dll'")
script='\n'.join(' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())if line.startswith(' payload=')else line for line in script.splitlines())+'\n'
(dest/'launch-command.py').write_text(script,newline='\n')
(dest/'launch.py').write_text(adapt((old/'launch.py').read_text()).replace('B522','B526'))
print('Finite five-job shared-prefix payload prepared:',required,'free bytes required;',len(payload),'compressed. Exact copies only, no remote action yet.')
