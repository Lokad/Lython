from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
home=Path(__file__).parent;tree=home/'tree';dest=home/'fixed-facts';assert dest.exists();env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';dotnet=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
for name,args in [
 ('public11',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--filter','FullyQualifiedName~FramedFunctionExecutionTests|FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~CallInputLifetimeTests']),
 ('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'])]:
 with(dest/(name+'.log')).open('w',encoding='utf-8')as out:r=subprocess.run([dotnet,*args],cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
 assert r.returncode==0,(dest/(name+'.log')).read_text()[-3000:]
 print(name,'passed',flush=True)
shutil.copytree(home/'images/before',dest/'images/before');shutil.copytree(home/'images/before',dest/'images/candidate')
shutil.copyfile(tree/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',dest/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(home/'record-comparison/catalog.json',dest/'catalog.json')
assert all(p.read_bytes()==(dest/'images/candidate'/p.relative_to(dest/'images/before')).read_bytes()for p in(dest/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
(dest/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=tree,stderr=subprocess.DEVNULL))
(dest/'identity.json').write_text(json.dumps(dict(cores={role:hashlib.sha256((dest/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},source={p.relative_to(tree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(tree/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},catalogSHA256=hashlib.sha256((dest/'catalog.json').read_bytes()).hexdigest(),refinement='After B526 adverse text and B527 profile, move fixed member/signature facts to compilation and isolate branch-only proof copies. Preserve runtime proof, cache-admission reentry fix and all original adverse evidence.',qualification='Current39internal.NET11; focused public below. Earlier source qualification is historical; prototype is not delivered.'),indent=2)+'\n')
witness=dest/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-Ã©ðŸ˜€'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
with(dest/'measurements.json').open('w',encoding='utf-8')as out,(dest/'stderr.txt').open('w',encoding='utf-8')as err:
 r=subprocess.run([dotnet,str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(dest/'images/before/Lokad.Lython.Benchmarks.dll'),str(dest/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(dest/'catalog.json'),str(witness),'reverse','warm','sync'],env=env,stdout=out,stderr=err,timeout=120)
assert r.returncode==0,(dest/'stderr.txt').read_text()[-3000:]
raw=json.loads((dest/'measurements.json').read_text());assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
rows=[]
for c in raw['observations']:
 roles={role:{key:statistics.median(s[field]/s['jobs']for s in c['samples']if s['image']==role)for key,field in [('bytes','allocatedBytes'),('elapsedMs','executionMilliseconds')]}for role in ['before','before-control','candidate']}
 row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});rows.append(row);print(row['case'],row['changes'],flush=True)
(dest/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
