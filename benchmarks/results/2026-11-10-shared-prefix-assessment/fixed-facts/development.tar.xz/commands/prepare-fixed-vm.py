from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;tree=home/'tree';old=home.parent/'handler-native-entry-r179/b522';dest=home/'b528';dest.mkdir()
local=json.loads((home/'fixed-facts/identity.json').read_text())
for name,digest in local['source'].items():assert hashlib.sha256((tree/name).read_bytes()).hexdigest()==digest,name
identity=json.loads((old/'identity.json').read_text())
identity['sourceRevision']='R180 fixed-method-facts and branch-only proof-storage refinement after B526/B527; shared-record reentry correction retained. Full source hashes/patch explicit. Compare qualified ee448715-equivalent core b49e50a6, not the older R173 image.'
identity['coreSHA256']={role:local['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']}
identity['catalogSHA256']=local['catalogSHA256']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for target,source in [('current-core.dll',home/'fixed-facts/images/candidate/Lokad.Lython.dll'),('representative.json',home/'fixed-facts/catalog.json'),('final-source.json',home/'fixed-facts/identity.json'),('source.patch',home/'fixed-facts/source.patch'),('golden.json',home/'record-comparison/golden.json')]:shutil.copyfile(source,dest/target)
baseline=json.loads((home.parent/'handler-native-entry-r179/identity.json').read_text())
(dest/'baseline-source.json').write_text(json.dumps(baseline,indent=2)+'\n')
with tarfile.open(dest/'source-checks.tar.xz','w:xz')as t:
 names=subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=tree,text=True).splitlines()
 for name in names:
  before=root/name;after=tree/name
  if after.exists():t.add(after,arcname='candidate/'+name)
  if before.exists():
   if name.startswith('src/Lokad.Lython/'):assert hashlib.sha256(before.read_bytes()).hexdigest()==baseline['productionSources'][before.as_posix()],name
   t.add(before,arcname='before/'+name)
 for p in home.glob('*.py'):t.add(p,arcname='commands/'+p.name)
 for p in home.glob('*.log'):t.add(p,arcname='qualification/'+p.name)
def adapt(text):return text.replace('handler-native-entry-b522-20261110','shared-operand-b528-20261110').replace('lython-b522-handler-native-entry-20261110','lython-b528-shared-operand-20261110').replace('lython-b522-fixtures','lython-b528-fixtures').replace('handler-native-entry-b522-launch','shared-operand-b528-launch').replace('R179 closed native calls under active handlers','R180 shared prefix and finished-IR proof')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 text=adapt((old/name).read_text())
 text=text.replace("'FramedFunctionExecutionTests.cs','LythonRuntime.Json.Serialize.cs','LythonRuntime.Json.Options.cs','PyExecutableFunction.cs',","'source-checks.tar.xz','golden.json',")
 text=text.replace('R177A post-frame native entry deletion; text source wrapped in active handler with original input/goldens, canonical ID required by reused driver; CSV/report/Unicode source controls unchanged. Both text APIs. Not published CPython comparison.', 'R180 fixed string-method facts/branch-storage refinement; CSV uses parse_amount helper with preserved goldens, original text sync/async, report/Unicode controls. B526 adversity retained. Not published CPython timing.')
 (dest/name).write_text(text,newline='\n')
for name in ['setup-contract.json','sizing.json']:shutil.copyfile(old/name,dest/name)
(dest/'focused.json').write_text(json.dumps(dict(public11=3625,public10PriorCacheCorrection=3625,internalBoundaryEachTarget=39,internalPriorStackAdmissionEachTarget=69,publicPriorStackEachTarget=60,fullDeliveryPending=True),indent=2)+'\n')
contract='''R180 coherent shared instruction prefix, no native expression graph/evaluator,
separate expression lowering or native argument-source metadata. Managed span views,
existing ownership/cleanup, current cancellation. Shared-record reentry cache fix
included; original failing source/diagnostics retained. Not released/fully qualified.
CSV uses one ordinary parse_amount(record) helper in maintained validation script:
same fixtures/files/stdout, newSourceSHA, canonicalID required by existing driver.
Text/report/Unicode sources unchanged. Five existing jobs/four processes,
two/source,5srolewarmups,7rotated150msrounds, ordinary GC/tiering. Includes mediated
RAM I/O/full validation/prior-result cleanup, excludes startup/reset/protocol/final
caches. Wider processCPU separate; compilation desktop separate. Keep adversity.
Finite210s owner/30sstop/30smargin; owned join/unmount/archive/localSHA. No10minlane.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract,newline='\n')
assert b'\r'not in(dest/'run.sh').read_bytes()
with tarfile.open(dest/'payload.tgz','w:gz')as t:
 for p in sorted(dest.iterdir()):
  if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
payload=(dest/'payload.tgz').read_bytes()
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+65536+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),baselineAndAuxiliariesReused=True),indent=2)+'\n')
script=adapt((old/'launch-command.py').read_text()).replace("reference=base/'string-index-storage-b518-20261109/candidate'","reference=base/'handler-native-entry-b522-20261110/candidate'")
script=script.replace("os.link(base/'string-index-storage-b518-20261109/current-core.dll'","os.link(base/'handler-native-entry-b522-20261110/current-core.dll'")
script='\n'.join(' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())if line.startswith(' payload=')else line for line in script.splitlines())+'\n'
(dest/'launch-command.py').write_text(script,newline='\n')
(dest/'launch.py').write_text(adapt((old/'launch.py').read_text()).replace('B522','B528'))
print('Finite five-job fixed-fact refinement payload prepared:',required,'free bytes required;',len(payload),'compressed. Exact copies only, no remote action yet.')

(dest/'recover-space.py').write_text((home/'b526/recover-space.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
