from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/bound-native-entry-b521-20261110/current-core.dll', 'size': 5655040, 'sha256': '5733cb87ed742bd7df97bfd60fb18d1ef60de5574039fc3de9c02e9f9ff7c0e9', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-framed-native-entry\\quiet\\observations.tgz', 'preservedMember': 'current-core.dll', 'archiveSHA256': '82b084b6b0a815eca609fc21a4fc4124c0eacf4d596910218f08118b855714a0', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/shared-operand-b526-20261110/current-core.dll', 'size': 5649920, 'sha256': 'b8efbea5e00b0154190342af30e97e51f2abf93641c0059c615148201d45ab74', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-shared-prefix-assessment\\quiet\\observations.tgz', 'preservedMember': 'current-core.dll', 'archiveSHA256': '201aa4e4a5dd74483dcb1549194d3515d0bc9238a1285687cba5f6d192a4ea33', 'tracked': True}]
archive={'path': '/home/lokad/lython-bench-checks/text-proof-b527-20261110/observations.tgz', 'size': 2174406, 'sha256': '7be3ed6fd4081d904535635b8433afbd985a7fe8c4be489b34f84d8e59fe7b81', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-shared-prefix-assessment\\profile\\observations.tgz', 'tracked': True}
required=271261696
allowed=[base/'bound-native-entry-b521-20261110',base/'shared-operand-b526-20261110',base/'text-proof-b527-20261110']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'shared-operand-b528-20261110').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 free=shutil.disk_usage(base).free
 if free>required:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=required)));raise SystemExit
 rows=[]
 for entry in spec:
  p=Path(entry['path']);info=p.lstat()
  assert stat.S_ISREG(info.st_mode) and not p.is_symlink() and p.resolve()==p
  assert info.st_size==entry['size'] and info.st_uid==os.getuid() and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  aliases=[]
  for top in allowed:
   assert top.resolve()==top and top.parent==base
   for current,dirs,files in os.walk(top,followlinks=False):
    dirs[:]=[name for name in dirs if not (Path(current)/name).is_symlink()]
    for name in files:
     q=Path(current)/name;meta=q.lstat()
     if (meta.st_dev,meta.st_ino)!=(info.st_dev,info.st_ino):continue
     assert stat.S_ISREG(meta.st_mode) and q.resolve()==q and meta.st_uid==os.getuid()
     assert hashlib.sha256(q.read_bytes()).hexdigest()==entry['sha256'];aliases.append(str(q))
  assert len(aliases)==info.st_nlink,(p,aliases,info.st_nlink)
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,allocatedBytes=info.st_blocks*512,allAliases=aliases))
 p=Path(archive['path']);info=p.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and p.resolve()==p and info.st_uid==os.getuid()
 assert info.st_size==archive['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==archive['sha256']
 receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==archive['sha256']
 rows.append(dict(**archive,device=info.st_dev,inode=info.st_ino,links=1,allocatedBytes=info.st_blocks*512,allAliases=[str(p)]))
 assert free+sum(row['allocatedBytes'] for row in rows)>required,(free,required)
 plan=dict(beforeFreeBytes=free,requiredFreeBytes=required,freshIdleLease=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Retire exact redundant remote copies of two superseded prototype cores and one compressed archive. Every original frozen core/raw observation survives byte-for-byte in tracked immutable canonical evidence; all source/raw trees/receipts and current production baseline remain. No sole evidence or active image removed.')
 with (base/'shared-operand-b528-space-plan.json').open('x') as f:
  f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for row in rows:
  for name in row['allAliases']:
   q=Path(name);info=q.lstat();assert (info.st_dev,info.st_ino)==(row['device'],row['inode']) and q.resolve()==q
   assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'];q.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free;assert plan['afterFreeBytes']>required
 (base/'shared-operand-b528-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
