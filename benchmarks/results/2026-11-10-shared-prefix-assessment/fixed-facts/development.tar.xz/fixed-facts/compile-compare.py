from pathlib import Path
import os,json,subprocess,statistics
h=Path('.git/agent-notes/review-20261031/shared-operand-r180').resolve();d=h/'fixed-facts';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];o=d/'compile';o.mkdir()
with (o/'measurements.json').open('w',encoding='utf-8') as out,(o/'stderr.txt').open('w',encoding='utf-8') as err:
 r=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(h.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(d/'images/before/Lokad.Lython.Benchmarks.dll'),str(d/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(d/'catalog.json'),str(d/'hash-witness.json'),'reverse','compile','sync'],env=env,stdout=out,stderr=err,timeout=120)
assert r.returncode==0,(o/'stderr.txt').read_text(encoding='utf-8')[-1500:]
raw=json.loads((o/'measurements.json').read_text(encoding='utf-8'));assert all(raw[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified']);rows=[]
for c in raw['observations']:
 roles={role:{key:statistics.median(s[field]/s['jobs']for s in c['samples']if s['image']==role)for key,field in [('bytes','allocatedBytes'),('elapsedMs','executionMilliseconds')]}for role in ['before','before-control','candidate']}
 row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});rows.append(row);print(row['case'],row['changes'],flush=True)
(o/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
