from pathlib import Path
import datetime, hashlib, json, shlex, subprocess
root=Path(__file__).parent
payload=(root/'payload.tgz').read_bytes()
remote=(root/'launch-command.py').read_text()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
 '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
# Keep source text out of process arguments: the existing idle guard otherwise
# matches the launcher's literal collector name. The initial refusal is retained.
stage='/home/lokad/lython-bench-checks/text-proof-b527-launch.py'
stage_code="from pathlib import Path; import sys; p=Path("+repr(stage)+"); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())"
staged=subprocess.run(ssh+['python3 -c '+shlex.quote(stage_code)],input=remote.encode('utf-8'),capture_output=True)
assert staged.returncode==0,staged.stderr.decode('utf-8')
r=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(root/'launch.log').write_bytes(r.stdout+b'\n'+r.stderr)
print((r.stdout+r.stderr).decode('utf-8'),flush=True)
if r.returncode:raise SystemExit(r.returncode)
now=datetime.datetime.now(datetime.timezone.utc)
(root/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),
 doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),
 ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('Observation after '+(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
