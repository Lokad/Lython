from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;old=home.parent/'text-runtime-r166';dest=home/'b527';dest.mkdir()
def adapt(s):return s.replace('text-runtime-b515-20261109','text-proof-b527-20261110').replace('lython-b515-text-runtime-20261109','lython-b527-text-proof-20261110').replace('lython-b515','lython-b527').replace('text-runtime-b515-launch','text-proof-b527-launch').replace('B515','B527')
identity=json.loads((old/'identity.json').read_text());current=json.loads((home/'b526/identity.json').read_text())
identity['coreSHA256']=current['coreSHA256']['candidate'];identity['auxiliaryFiles']=current['auxiliaryFiles'];identity['sourceRevision']=current['sourceRevision']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copyfile(home/'refined/identity.json',dest/'current-source-delta.json')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py','finish.py','attribute.py']:
 (dest/name).write_text(adapt((old/name).read_text()),newline='\n')
contract='''R180 one existing6CPU-second original-text profile after adverse B526.
No new runtime flags beyond existing perf symbol mapping. No timing qualification.
Reuse exact B526 frozen candidate/core/auxiliaries/catalog; same goldens/current
budget/cancellation. Attribute type-proof replay versus shared prefix/primitive work;
do not interpret innermost phases as removable-work bounds. Existing bounded warmup,
capture/worker stop,120s owner/30sstop/30smargin, join/maps/RAMarchive/localSHA.
Persistent evidence separate from owned tmpfs. Keep failures and original conditions.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract,newline='\n')
assert b'\r'not in(dest/'run.sh').read_bytes()
with tarfile.open(dest/'payload.tgz','w:gz')as t:
 for p in sorted(dest.iterdir()):
  if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
payload=(dest/'payload.tgz').read_bytes()
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),frozenCoreReused=True),indent=2)+'\n')
script=adapt((old/'launch-command.py').read_text()).replace("source=(base/'shared-comparison-b514-20261109/candidate').resolve()","source=(base/'shared-operand-b526-20261110/candidate').resolve()")
script=script.replace("proof['candidateCoreSHA256']","proof['cores']['candidate']")
lines=[]
for line in script.splitlines():
 if line.startswith(' payload=sys.stdin.buffer.read('):line=' payload=sys.stdin.buffer.read('+str(len(payload))+'+1)'
 elif line.startswith(' assert len(payload)=='):line=' assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())
 lines.append(line)
script='\n'.join(lines)+'\n';(dest/'launch-command.py').write_text(script,newline='\n')
launch=adapt((old/'launch.py').read_text());start=launch.index("remote=r'''");end=launch.index('ssh=[',start)
launch=launch[:start]+"remote=(root/'launch-command.py').read_text()\n"+launch[end:]
(dest/'launch.py').write_text(launch)
root=Path('D:/code/Lython');p=root/'benchmarks/results/2026-11-10-shared-prefix-assessment/quiet/observations.tgz'
assert subprocess.check_output(['git','ls-files','--',p.relative_to(root).as_posix()],cwd=root,text=True).strip()==p.relative_to(root).as_posix()
spec=[dict(path='/home/lokad/lython-bench-checks/shared-operand-b526-20261110/observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=p.as_posix(),tracked=True)]
script=(home/'b526/space-recovery-command.py').read_text().replace('shared-operand-b526-20261110','text-proof-b527-20261110').replace('shared-operand-b526','text-proof-b527').replace(str(json.loads((home/'b526/payload-sizing.json').read_text())['requiredFreeBytes']),str(required))
script='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in script.splitlines())+'\n'
(dest/'space-recovery-command.py').write_text(script)
(dest/'recover-space.py').write_text((home/'b526/recover-space.py').read_text())
print('Prepared existing one-text profile with frozen core; required free bytes',required,'payload',len(payload))
