R180 one existing6CPU-second original-text profile after adverse B526.
No new runtime flags beyond existing perf symbol mapping. No timing qualification.
Reuse exact B526 frozen candidate/core/auxiliaries/catalog; same goldens/current
budget/cancellation. Attribute type-proof replay versus shared prefix/primitive work;
do not interpret innermost phases as removable-work bounds. Existing bounded warmup,
capture/worker stop,120s owner/30sstop/30smargin, join/maps/RAMarchive/localSHA.
Persistent evidence separate from owned tmpfs. Keep failures and original conditions.
