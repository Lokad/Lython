from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;o=Path('benchmarks/results/2026-11-09-current-text-runtime');o.mkdir(exist_ok=False)
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['archivedAndVerifiedUnderLease']and receipt['capturedSeconds']<10
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
source=json.loads((r/'retrieved/core-source.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
data=json.loads((r/'attribution.json').read_text(encoding='utf-8'))[0];g=data['groups']['guest'];assert g['samples']==1147
summary=dict(case=data['case'],guestSamples=g['samples'],unknownGuestSamples=g['unknownLeaf'],activeGuestCpuSeconds=5.77,capturedSeconds=receipt['capturedSeconds'],phases=[dict(name=n,samples=c,percent=100*c/g['samples'])for n,c in g['observedPhase']],limits='Diagnostic CPU attribution of complete warm batches, wider than execution clocks. No elapsed comparison, removed-work or speedup estimate. Inlining/truncation/unknown IPs remain explicit.')
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for n in ['attribution.json','identity.json','source-gate.json','observations.tgz','archive-receipt.json','terminal-status.json','space-recovery.json','current-source-delta.json']:shutil.copyfile(r/n,o/n)
shutil.copyfile(r/'retrieved/core-source.json',o/'core-source.json')
with tarfile.open(o/'preparation.tar.xz','w:xz',preset=3)as t:
 for n in ['ops-profile.py','analyze-cpu-guest.py','attribute.py','archive.py','run.sh','retrieve.py','launch.py','launch-command.py','launch.log','selection.md','sizing.json','recover-space.py','space-recovery-command.py','space-refusal.log','space-recovery.log','observe-not-before.json','payload-sizing.json']:t.add(r/n,arcname=n)
 t.add(r.parent/'prepare-text-r166.py',arcname='prepare.py')
(o/'README.md').write_text('''# Current whole-text runtime attribution (R166)

One checked full word-count/report script, 2026-11-09, quiet F4as_v7 Ubuntu24.04.4,
.NET11RC3, ordinary GC/tiering plus explicit perf-map diagnostic setting. Reuse
the R164/R165 final precommit freeze (core80a3540d), production-source equivalent
to committed96e534f9, with unchanged persistent worker/adapter/catalog. Exact code
and source identities are retained; not a fresh postcommit build or CPython timing.

Existing perf/worker protocol:128-job warmup requests/64-job capture requests,
six-second target, unchanged20s frame guard, finite120s owner plus30s stop/margin.
One usable **5.856 execution-clock seconds,5.77 guest CPU seconds,1147 guest samples**.
All1222 samples include34 tiering and41 caller/other;70 guest leaf IPs unknown(6.10%).
Whole batches include reset/protocol/validation; guest/caller groups stay separate.
This is CPU attribution, not an elapsed before/after or a removable-work estimate.

| Innermost observed guest phase | Samples | Share |
| --- | ---: | ---: |
| VM prefix, including useful inlined work |444|38.71%|
| Text kernels/construction |268|23.37%|
| Dictionary operations |96|8.37%|
| Scalar operators |73|6.36%|
| Native call preparation/body |71|6.19%|
| Memory admission |62|5.41%|
| Operand/result publication |27|2.35%|

Text leaves include51 whitespace collection,33 UTF-8 casing writer,26 split-core
and16 managed ASCII casing samples. These counts include useful work and do not
imply all23.37% can disappear. Ordinary binding/frame construction has no separately
observed phase here: the existing native helper-return route handles this helper;
that does not establish universal zero call cost. Dictionary samples include34
native get and30 contextual hash preparation; cached string hashing already exists.

Current source rejects several obsolete premises: ASCII case already uses managed
bulk intrinsics; lower/split writes final independently owned words; UTF-8 completion
does not recount scalars; CSV parser bulk-scans and transfers funded row arrays;
binding targets final slots with inline presence/reused workspace/deferred contexts.
Reservation commits update local balances; they do not resize the host per fragment.
The standalone allowance already shares one gate, not a lock chain per scope.

Next bounded design phase considers complete native text construction and dictionary
query/update pipelines. A prototype must identify actual work/storage displaced,
preserve Python Unicode/context, identity/alias ownership, mutable protocol/evaluation
order, cancellation/refusal and cleanup, and compare complete text with CSV/config
controls. No new frame arena, repeated-hash cache, universal tagged-value commitment
or narrow counting idiom is selected from this capture. Larger redesigns remain
possible; original slower call-arena/control evidence is not a permanent veto.

Initial space checks refused before mutation (53,248B short including payload).
One additional exact tracked B501 archive joined the existing B514/B507 selection.
Fresh idle lease, exact SHA/single aliases/metadata/parents/receipts precede removing
only those redundant remote compressed copies. Their canonical Git copies, raw
trees, receipts and frozen workers survive;240MiB OS/12MiB evidence floors unchanged.
Raw/maps archived under the owner; full golden/quiet/Closed/join/map-retirement/
RAM-unmount/localSHA gates pass. No VM users remain; terminal state cached.
No runtime change or repeated unchanged correctness qualification in this milestone.
Full R164/R165 delivery is tracked separately; publication postponed.

[Summary](summary.json), [full leaf/phase attribution](attribution.json),
[source gate](source-gate.json), [identities](identity.json), [source](core-source.json),
[raw/core/maps](observations.tgz), [preparation/refusal](preparation.tar.xz),
[space proof](space-recovery.json), [terminal](terminal-status.json).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');i=s.index('The [R165');s=s[:i]+'''The [R166 current whole-text attribution](results/2026-11-09-current-text-runtime/README.md)
reuses the96e-equivalent freeze, one5.856s capture/5.77guestCPU/1147guest samples.
Text23.37%, dictionary8.37%, scalar6.36%; VM prefix38.71% contains useful inlining.
Existing native helper returns remove ordinary binding/frame phases from this script.
No assumed per-character string conversion, duplicate hash or row copy remains.
Select a bounded complete text-construction/dictionary pipeline design phase;
no elapsed/speedup claim, new arena/cache/tagged-value commitment or permanent veto.
All gates/raw/maps/source and initial space refusal survive; no VM users remain.

'''+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('**R166 — select the next substantial whole-script redesign from actual costs.**','**R167 — select one coherent text-construction/dictionary redesign.**')
s=s.replace('   R162 CSV samples:', '   R166 current text capture complete:1147guest samples/5.77CPU seconds, text23.37%,\n   dictionary8.37%, scalar6.36%, native calls6.19%, memory5.41%. Prefix38.71% includes\n   useful inlining; ordinary binding/frame has no separately observed phase in this\n   native-helper script. Not a universal zero-call-cost or removable-share claim.\n   Current kernels already bulk-case ASCII/write final words, cached hashes exist,\n   commits are local and standalone scopes share one gate. Do not recreate them.\n\n   Prioritize complete text-construction and dictionary query/update dataflow. Name\n   which representation/validation/copy/storage is actually redundant before selecting\n   a prototype; do not merely add another special-case dispatch or word-count idiom.\n   Preserve independent word owners, Unicode/final-sigma/expansions, mutable protocols,\n   evaluation order, terminal refusal, current cancellation, aliases and cleanup.\n   Compare complete text plus CSV/config controls with two unchanged baselines.\n   Bounded source phase about20min: if no coherent removal is justified, state the\n   exact uncertainty and choose another family; no automatic permanent design veto.\n\n   R162 CSV samples:')
s+='\nR166 complete evidence: benchmarks/results/2026-11-09-current-text-runtime/README.md.\nB527 terminal cached, all golden/quiet/owner/join/maps/RAM/archive/localSHA gates pass;\nno users. B514/B507/B501 redundant compressed copies now removed with exact proofs;\ncanonical archives/raw/workers survive. Do not probe absent copies as candidates.\nR167 source design active; CI42651978111 independent. No publication.\n'
p.write_text(s,encoding='utf-8',newline='\n');print('R166 diagnostic/source gate archived; next coherent design phase recorded, no speedup claim.')
