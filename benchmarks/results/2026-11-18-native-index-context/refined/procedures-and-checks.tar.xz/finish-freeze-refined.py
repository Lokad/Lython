from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');frozen=r/'frozen'
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for kind,cmd in [('preflight',[str(d),str(frozen/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')]),('allocation',[str(d),str(frozen/'candidate/ValidatedAllocation.dll'),str(frozen/'candidate'),str(r/'catalog.json'),str(r/'candidate-allocation.json')]),('measurement-preflight',[str(d),str(frozen/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'measurement-catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-measurement-preflight.json')])]:
 if kind=='preflight':continue
 with(r/('candidate-'+kind+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert p.returncode==0,(r/('candidate-'+kind+'.log')).read_text(encoding='utf-8');print(kind,'passed',flush=True)
print('Refined allocation/reuse and timed catalog checks pass; initial output/failure preserved.',flush=True)
