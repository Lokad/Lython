from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
evidence=repo/'benchmarks/results/2026-11-28-current-script-profile'
archive_path=evidence/'observations.tar.xz'
with tarfile.open(archive_path) as archive:
    profile=json.load(archive.extractfile('profile/compiled-log-sync/run.speedscope.json'))
    measured=json.load(archive.extractfile('profile/compiled-log-sync/record.json'))
    catalog=json.load(archive.extractfile('representative.json'))
workload=next(c for c in catalog['cases'] if c['id']==measured['workload'])
frames=[f['name'].split('(',1)[0].split('!',1)[-1] for f in profile['shared']['frames']]
waits=('WaitSubsystem+ThreadWaitInfo.Wait','LowLevelThreadBlocker.TimedWait','PollGCWorker','SynchronousWorkItem.Wait')
prefix=('Lokad.Lython.Runtime.','Lokad.Lython.Frontend.','Lokad.Lython.LythonEngine','Lokad.Lython.Utf8Regex.','Lokad.Utf8Regex.')
groups={
    'adapter':('Lokad.Lython.Utf8Regex.',),
    'producer':('Lokad.Utf8Regex.',),
    'match projection':('CreateMatchObject','ProjectSingleMatch','ProjectScalarBounds'),
    'match key validation':('ResolveGroupIndex','GetBoundsCoreAsync','ResolveIndexedGroup'),
    'group API':('ReMatchMembers','ReMatchObject.MaterializeGroup'),
    'window creation':('RegexMatcher.Window','RegexCompiler.CreateWindow'),
    'allocation and ownership':('MemoryGovernor.Reserve','MemoryGovernor.Release'),
    'string input materialization':('PyString.get_Utf8Bytes','MaterializeInlineMemory'),
    'runtime regex':('RegexMatcher','RegexCompiler','RePatternObject','ReModule'),
}
rows=[]
for mode in ('wait-filtered','managed-leaf'):
    inclusive=Counter()
    nearest=Counter()
    total=0.0
    for process in profile['profiles']:
        stack=[]
        previous=process['startValue']
        for item in process['events']:
            event=item['at']
            dt=event-previous
            active=[name for name in stack if name.startswith(prefix)]
            if dt>0 and active and not any(marker in frame for marker in waits for frame in stack) and (
                mode=='wait-filtered' or 'UNMANAGED_CODE_TIME' not in stack[-1]):
                total+=dt
                nearest[active[-1]]+=dt
                for group,markers in groups.items():
                    if any(marker in frame for marker in markers for frame in active): inclusive[group]+=dt
            if item['type']=='O': stack.append(frames[item['frame']])
            else: assert stack.pop()==frames[item['frame']]
            previous=event
        assert not stack
    assert total>0
    rows.append(dict(view=mode,threadMilliseconds=total,regionsPercent={key:100*value/total for key,value in inclusive.most_common()},
                     nearestMethodsPercent=[(name,100*count/total) for name,count in nearest.most_common(35)]))
record=dict(source='24218276c',evidenceSHA256=sha256(archive_path.read_bytes()).hexdigest(),
            workload=workload['id'],sourceSHA256=workload['sourceSha256'],rows=rows)
(lab/'group-costs.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:
    print(row['view'],row['regionsPercent'])
