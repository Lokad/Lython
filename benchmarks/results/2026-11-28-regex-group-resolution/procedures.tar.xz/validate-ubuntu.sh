#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/regex-group-costs-b1931-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
~/.dotnet/dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~ReceiverMethodSemanticsTests)' > "$lab/corrected-ubuntu-public-net11.0.log" 2>&1 || { tail -n 30 "$lab/corrected-ubuntu-public-net11.0.log"; exit 1; }
tail -n 3 "$lab/corrected-ubuntu-public-net11.0.log"
~/.dotnet/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Admission)' > "$lab/corrected-ubuntu-white-net11.0.log" 2>&1 || { tail -n 30 "$lab/corrected-ubuntu-white-net11.0.log"; exit 1; }
tail -n 3 "$lab/corrected-ubuntu-white-net11.0.log"
