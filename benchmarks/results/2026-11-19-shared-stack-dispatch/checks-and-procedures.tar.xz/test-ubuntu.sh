export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/shared-stack-dispatch-r696
filter='(FullyQualifiedName~NamedFunctionBinding|FullyQualifiedName~OrdinaryFunction|FullyQualifiedName~Global|FullyQualifiedName~Member|FullyQualifiedName~MethodInvocation|FullyQualifiedName~Annotation|FullyQualifiedName~Lexical|FullyQualifiedName~AsyncIteratorCleanup|FullyQualifiedName~GeneratorCleanup|FullyQualifiedName~HelperLocalLifetime)&Category!=Stress'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    log="$lab/$suite-ubuntu.log"
    ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" >"$log" 2>&1
    result=$?
    tail -n 9 "$log"
    if test "$result" -ne 0; then exit "$result"; fi
done