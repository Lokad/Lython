; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xD0], ymm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      dword ptr [rbp-0x1C], ecx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004E
       lea      rdi, [rbp+0x28]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x38], 0
       jne      SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x40], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006A
       mov      rdi, gword ptr [rbp-0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [rbp-0xD0]
       mov      rdi, 0x7EFB9C6221A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x78], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x009A
       xor      rax, rax
       mov      gword ptr [rbp-0x78], rax
 
G_M000_IG05:                ;; offset=0x00A0
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B6
       mov      rdi, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x7C], eax
 
G_M000_IG07:                ;; offset=0x00C3
       mov      eax, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG08
       mov      edi, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00E2
       mov      qword ptr [rbp-0x88], 160
 
G_M000_IG09:                ;; offset=0x00ED
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0x48], rax
       movzx    rax, byte  ptr [rbp+0x50]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rdi, 0x7EFB9C14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7efb9a41b0c0)]
       add      rax, qword ptr [rbp-0x48]
       jo       G_M000_IG23
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG10:                ;; offset=0x0125
       lea      rdi, [rbp+0x58]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rax, qword ptr [rbp-0x48]
       add      rax, 96
       jo       G_M000_IG23
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG11:                ;; offset=0x0145
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG12
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x0170
       nop      
 
G_M000_IG13:                ;; offset=0x0171
       mov      rdi, gword ptr [rbp-0x28]
       mov      rsi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rbp+0x58]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7EFB9C5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xC0], rax
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG15
       mov      rax, bword ptr [rbp+0x58]
       mov      rsi, gword ptr [rax]
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG15
       mov      rax, bword ptr [rbp+0x58]
       mov      rdx, qword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG14:                ;; offset=0x01F1
       movzx    rax, byte  ptr [rbp-0x1C]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rdi, 0x7EFB9C5FCF30
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB8], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x98], rax
       jmp      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0261
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG16:                ;; offset=0x0267
       mov      rdi, 0x7EFB9C6222F8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG17:                ;; offset=0x02CD
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x10]
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdx, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG19
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0xA8], rax
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG18
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG18
       mov      rsi, bword ptr [rbp+0x28]
       mov      rdx, qword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG18:                ;; offset=0x0363
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x28]
       movzx    rcx, byte  ptr [rbp+0x4C]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG19:                ;; offset=0x0381
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG20
       mov      rax, gword ptr [rbp-0x58]
       mov      byte  ptr [rax+0x29], 1
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG15
       mov      rdi, bword ptr [rbp+0x58]
       mov      rsi, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG20:                ;; offset=0x03B8
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG21:                ;; offset=0x03C0
       mov      rax, gword ptr [rbp-0x70]
 
G_M000_IG22:                ;; offset=0x03C4
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x03CD
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG24:                ;; offset=0x03D3
       sub      rsp, 24
 
G_M000_IG25:                ;; offset=0x03D7
       mov      gword ptr [rbp-0xC8], rdi
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03E5
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG27:                ;; offset=0x03F5
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1019

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp-0x20]
       mov      byte  ptr [rax], 0
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0040
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0046
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      bword ptr [rbp-0x40], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x48], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      esi, dword ptr [rbp-0x54]
       mov      rdi, gword ptr [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(Lokad.Lython.Frontend.FunctionParameterLayout,int,System.Object):bool]
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00A4
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG06:                ;; offset=0x00B1
       mov      rax, bword ptr [rbp-0x48]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp-0x20]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00CA
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00D0
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG13
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG13
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG09
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdi, 0x7EFB9C4608E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x0137
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG10
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x50], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0165
       xor      eax, eax
       mov      dword ptr [rbp-0x50], eax
 
G_M000_IG11:                ;; offset=0x016A
       cmp      dword ptr [rbp-0x50], 0
       sete     al
       movzx    rax, al
 
G_M000_IG12:                ;; offset=0x0174
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x017A
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x017C
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 386

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG18:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG07
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG04
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0120
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG05:                ;; offset=0x0128
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG06:                ;; offset=0x0141
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x014A
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG08:                ;; offset=0x01A8
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG09:                ;; offset=0x01B8
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG10:                ;; offset=0x01F6
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0206
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG13
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG12
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG17
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG12:                ;; offset=0x026B
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A9
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG14:                ;; offset=0x034D
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG15:                ;; offset=0x035D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG16:                ;; offset=0x03F7
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0400
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1030

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(Lokad.Lython.Frontend.FunctionParameterLayout,int):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
 
G_M000_IG02:                ;; offset=0x002A
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x08]
       mov      rdi, 0x7EFB9B6427A0
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0067
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x40], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x40]
       sub      ecx, eax
       mov      dword ptr [rbp-0x44], ecx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x44]
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00A2
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jl       G_M000_IG08
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x18], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdi, 0x7EFB9C4608E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x20], 0
       jne      SHORT G_M000_IG05
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x28]
       mov      dword ptr [rbp-0x38], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x011A
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x28]
       mov      dword ptr [rbp-0x38], eax
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG06:                ;; offset=0x0133
       mov      eax, dword ptr [rbp-0x38]
       sub      eax, dword ptr [rbp-0x3C]
       cmp      dword ptr [rbp-0x34], eax
       setge    al
       movzx    rax, al
 
G_M000_IG07:                ;; offset=0x0142
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0148
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x014A
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 336

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(Lokad.Lython.Frontend.FunctionParameterLayout,int,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x0033
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jg       G_M000_IG10
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp-0x14]
       sub      ecx, eax
       mov      dword ptr [rbp-0x84], ecx
       mov      esi, dword ptr [rbp-0x84]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG03:                ;; offset=0x0079
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG04:                ;; offset=0x0083
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x34], eax
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x08]
       mov      rdi, 0x7EFB9B6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x34]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG14
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00D0
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x00DC
       mov      rdi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x80], rax
       mov      qword ptr [rbp-0x78], rdx
 
G_M000_IG07:                ;; offset=0x00EE
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG08:                ;; offset=0x00F8
       lea      rdi, [rbp-0x58]
       mov      rsi, bword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0107
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0110
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x88], eax
       mov      edx, dword ptr [rbp-0x88]
       lea      rcx, [rbp-0x30]
       mov      esi, dword ptr [rbp-0x14]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       lea      rdi, [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x014C
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x0155
       mov      rax, bword ptr [rbp-0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x0160
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x0169
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x002F
       mov      rax, bword ptr [rbp-0x20]
       mov      byte  ptr [rax], 0
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rdi, 0x7EFB9C9D8310
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0055
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x005B
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ParameterLayout():Lokad.Lython.Frontend.FunctionParameterLayout:this]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, bword ptr [rbp-0x20]
       mov      bword ptr [rbp-0x40], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x48], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x5C], eax
       mov      esi, dword ptr [rbp-0x5C]
       mov      rdi, gword ptr [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(Lokad.Lython.Frontend.FunctionParameterLayout,int,System.Object):bool]
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00B9
       mov      rdi, 0x7EFB9C9D8314
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x48], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG06:                ;; offset=0x00D5
       mov      rax, bword ptr [rbp-0x48]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp-0x20]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rdi, 0x7EFB9C9D8318
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00FD
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0103
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG17
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      G_M000_IG12
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, 0x7EFB9C9D8320
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x68], rax
       mov      rsi, gword ptr [rbp-0x68]
       mov      rdi, 0x7EFB9C4608E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0191
       mov      rdi, 0x7EFB9C9D8428
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG10:                ;; offset=0x01A0
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG14
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x50], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01CE
       mov      rdi, 0x7EFB9C9D842C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x01DF
       mov      rdi, 0x7EFB9C9D8430
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x01F0
       mov      rdi, 0x7EFB9C9D8434
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG14:                ;; offset=0x0201
       mov      rdi, 0x7EFB9C9D8438
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x50], eax
 
G_M000_IG15:                ;; offset=0x0215
       mov      rdi, 0x7EFB9C9D843C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      dword ptr [rbp-0x50], 0
       sete     al
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x022E
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0234
       mov      rdi, 0x7EFB9C9D8440
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x0245
       add      rsp, 112
       pop      rbp
       ret      
 
; Total bytes of code 587

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG21:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG09
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rdi, 0x7EFB9C9D8798
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00D0
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7EFB9C9D879C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0142
       mov      rdi, 0x7EFB9C9D87A0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG06:                ;; offset=0x0159
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG08
       mov      rdi, 0x7EFB9C9D87A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG07:                ;; offset=0x0181
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x018A
       mov      rdi, 0x7EFB9C9D87A8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0199
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG10:                ;; offset=0x01F7
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0207
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG12:                ;; offset=0x0245
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG13:                ;; offset=0x0255
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG15
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG14
       mov      rdi, 0x7EFB9C9D87AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x02C9
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0307
       mov      rdi, 0x7EFB9C9D87B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG16:                ;; offset=0x03BA
       mov      rdi, 0x7EFB9C9D87B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x03C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG18:                ;; offset=0x03D9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x0473
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x047C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1154

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(Lokad.Lython.Frontend.FunctionParameterLayout,int,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 160
       lea      rbp, [rsp+0xA0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x0044
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jg       G_M000_IG10
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp-0x14]
       sub      ecx, eax
       mov      dword ptr [rbp-0x8C], ecx
       mov      esi, dword ptr [rbp-0x8C]
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG03:                ;; offset=0x008A
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG04:                ;; offset=0x0094
       lea      rdi, [rbp-0x48]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x34], eax
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x88], rax
       mov      rdi, gword ptr [rbp-0x88]
       mov      rsi, 0x7EFB9C9DAA80
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, 0x7EFB9B6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x34]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG14
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0113
       mov      rdi, 0x7EFB9C9DAB88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x012E
       mov      rdi, 0x7EFB9C9DAB8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x80], rax
       mov      qword ptr [rbp-0x78], rdx
 
G_M000_IG07:                ;; offset=0x014F
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG08:                ;; offset=0x0159
       lea      rdi, [rbp-0x58]
       mov      rsi, bword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0168
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0171
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x9C], eax
       mov      edx, dword ptr [rbp-0x9C]
       lea      rcx, [rbp-0x30]
       mov      esi, dword ptr [rbp-0x14]
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rdi, 0x7EFB9C9DAB90
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x01BC
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01C5
       mov      rdi, 0x7EFB9C9DAB94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x01DF
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01E8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 494

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xD0], ymm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      dword ptr [rbp-0x1C], ecx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004E
       lea      rdi, [rbp+0x28]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x38], 0
       jne      SHORT G_M000_IG05
       cmp      gword ptr [rbp+0x40], 0
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x006A
       mov      rdi, 0x7EFB9C9DACB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0079
       mov      rdi, gword ptr [rbp-0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [rbp-0xD0]
       mov      rdi, 0x7EFB9C6221A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x78], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00A9
       mov      rdi, 0x7EFB9C9DACB4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG04
 
G_M000_IG06:                ;; offset=0x00BA
       mov      rdi, 0x7EFB9C9DACB8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x78], rax
 
G_M000_IG07:                ;; offset=0x00CF
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00E5
       mov      rdi, 0x7EFB9C9DACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x7C], eax
 
G_M000_IG09:                ;; offset=0x0101
       mov      eax, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG10
       mov      edi, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0120
       mov      rdi, 0x7EFB9C9DACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      qword ptr [rbp-0x88], 160
 
G_M000_IG11:                ;; offset=0x013A
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0x48], rax
       movzx    rax, byte  ptr [rbp+0x50]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rdi, 0x7EFB9C9DACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7EFB9C14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7efb9a41b0c0)]
       add      rax, qword ptr [rbp-0x48]
       jo       G_M000_IG26
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG12:                ;; offset=0x0181
       lea      rdi, [rbp+0x58]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rdi, 0x7EFB9C9DACC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x48]
       add      rax, 96
       jo       G_M000_IG26
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG13:                ;; offset=0x01B0
       mov      rdi, gword ptr [rbp-0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7EFB9C9DACCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x01EA
       nop      
 
G_M000_IG15:                ;; offset=0x01EB
       mov      rdi, gword ptr [rbp-0x28]
       mov      rsi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rbp+0x58]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rdi, 0x7EFB9C9DACD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7EFB9C5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xC0], rax
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG23
       mov      rax, bword ptr [rbp+0x58]
       mov      rsi, gword ptr [rax]
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG23
       mov      rax, bword ptr [rbp+0x58]
       mov      rdx, qword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG16:                ;; offset=0x027A
       movzx    rax, byte  ptr [rbp-0x1C]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rdi, 0x7EFB9C5FCF30
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB8], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x98], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02EA
       mov      rdi, 0x7EFB9C9DACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7EFB9C6222F8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG18:                ;; offset=0x035F
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x10]
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdx, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG20
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0xA8], rax
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG19
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      G_M000_IG22
       mov      rdi, 0x7EFB9C9DACD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp+0x28]
       mov      rdx, qword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, gword ptr [rbp-0x28]
       mov      r9, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG19:                ;; offset=0x0408
       mov      rdi, 0x7EFB9C9DACDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x28]
       movzx    rcx, byte  ptr [rbp+0x4C]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG20:                ;; offset=0x0435
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG21
       mov      rdi, 0x7EFB9C9DACE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      byte  ptr [rax+0x29], 1
       cmp      dword ptr [rbp+0x60], 0
       jbe      SHORT G_M000_IG23
       mov      rdi, bword ptr [rbp+0x58]
       mov      rsi, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG21:                ;; offset=0x0477
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0481
       mov      rdi, 0x7EFB9C9DACE4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG19
 
G_M000_IG23:                ;; offset=0x0495
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG24:                ;; offset=0x049B
       mov      rdi, 0x7EFB9C9DACEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x70]
 
G_M000_IG25:                ;; offset=0x04AE
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x04B7
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG27:                ;; offset=0x04BD
       sub      rsp, 24
 
G_M000_IG28:                ;; offset=0x04C1
       mov      gword ptr [rbp-0xC8], rdi
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04CF
       mov      rdi, 0x7EFB9C9DACE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG30:                ;; offset=0x04EE
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1268

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(Lokad.Lython.Frontend.FunctionParameterLayout,int):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      dword ptr [rbp-0x14], edx
 
G_M000_IG02:                ;; offset=0x002E
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x18]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x50], rax
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, 0x7EFB9C9DBB38
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x60], rax
       mov      rsi, gword ptr [rbp-0x60]
       mov      rdi, 0x7EFB9B6427A0
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0092
       mov      rdi, 0x7EFB9C9DBC40
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A1
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x40], eax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x40]
       sub      ecx, eax
       mov      dword ptr [rbp-0x44], ecx
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x44]
       jne      G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00DC
       mov      rdi, 0x7EFB9C9DBC44
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x00EB
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x14]
       jl       G_M000_IG12
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x18], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, 0x7EFB9C9DBC48
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x68], rax
       mov      rsi, gword ptr [rbp-0x68]
       mov      rdi, 0x7EFB9C4608E8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x20], rax
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x20], 0
       jne      SHORT G_M000_IG09
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x28]
       mov      dword ptr [rbp-0x38], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x017E
       mov      rdi, 0x7EFB9C9DBD50
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x018F
       mov      rdi, 0x7EFB9C9DBD54
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x01A0
       mov      rdi, 0x7EFB9C9DBD58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x34], eax
       mov      eax, dword ptr [rbp-0x28]
       mov      dword ptr [rbp-0x38], eax
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG10:                ;; offset=0x01C8
       mov      rdi, 0x7EFB9C9DBD5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x38]
       sub      eax, dword ptr [rbp-0x3C]
       cmp      dword ptr [rbp-0x34], eax
       setge    al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x01E6
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01EC
       mov      rdi, 0x7EFB9C9DBD60
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x01FD
       add      rsp, 112
       pop      rbp
       ret      
 
; Total bytes of code 515

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rbp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 24268
; 3 inlinees with PGO data; 22 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       push     rax
       lea      rbp, [rsp+0x10]
       mov      rbx, rdi
 
G_M000_IG02:                ;; offset=0x000B
       mov      byte  ptr [rcx], 0
       mov      rdi, gword ptr [rbx+0x38]
       cmp      byte  ptr [rdi+0xE6], 0
       je       G_M000_IG11
       mov      rax, gword ptr [rbx+0x20]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG11
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG11
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG11
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG11
       cmp      dword ptr [rdi+0xDC], 16
       jg       G_M000_IG11
       mov      rdi, gword ptr [rdi+0xB0]
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG13
       mov      esi, dword ptr [rsi+0x28]
       cmp      byte  ptr [rdi+0x54], 0
       je       SHORT G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007F
       mov      eax, dword ptr [rdi+0x3C]
       test     rdx, rdx
       setne    dl
       movzx    rdx, dl
       sub      eax, edx
       cmp      eax, esi
       sete     sil
       movzx    rsi, sil
 
G_M000_IG04:                ;; offset=0x0097
       mov      byte  ptr [rcx], sil
       cmp      byte  ptr [rcx], 0
       je       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x009F
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x00A4
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00AB
       xor      esi, esi
       jmp      SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x00AF
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], 16
       jg       SHORT G_M000_IG11
       cmp      dword ptr [rdi+0x4C], 0
       jge      SHORT G_M000_IG11
       cmp      dword ptr [rdi+0x50], 0
       jge      SHORT G_M000_IG11
       mov      rsi, gword ptr [rbx+0x10]
       test     rsi, rsi
       je       SHORT G_M000_IG10
       mov      rax, rsi
       mov      rdi, 0x7EFB9C644408
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x00E0
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E5
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       je       SHORT G_M000_IG05
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x00F5
       xor      eax, eax
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x00FE
       xor      esi, esi
       jmp      SHORT G_M000_IG04
 
G_M000_IG14:                ;; offset=0x0102
       mov      rdi, 0x7EFB9C4608E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x0113
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       jne      G_M000_IG05
       jmp      SHORT G_M000_IG11
 
; Total bytes of code 294

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 27408
; 7 inlinees with PGO data; 28 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 456
       lea      rbp, [rsp+0x1F0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -336
 
G_M000_IG27:                ;; offset=0x0028
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x1A0], rdx
       mov      rbx, rdi
       mov      r13, rsi
       mov      r14d, ecx
       mov      r15, r8
       mov      r12, r9
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x005E
       test     r15, r15
       jne      G_M000_IG15
 
G_M000_IG03:                ;; offset=0x0067
       mov      rdi, gword ptr [rbx+0x38]
       cmp      byte  ptr [rdi+0xE7], 0
       jne      G_M000_IG10
 
G_M000_IG04:                ;; offset=0x0078
       mov      rax, bword ptr [rbp-0x1A0]
 
G_M000_IG05:                ;; offset=0x007F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       vmovdqu  ymmword ptr [rbp-0x88], ymm0
       vmovdqu  ymmword ptr [rbp-0x68], ymm0
       vmovdqu  ymmword ptr [rbp-0x48], ymm0
       mov      rdi, gword ptr [rbx+0x38]
       mov      r8d, dword ptr [rdi+0xDC]
       mov      dword ptr [rbp-0x184], r8d
       cmp      r8d, 16
       ja       G_M000_IG20
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG25
       xor      edi, edi
       test     r15, r15
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x00EE
       cmp      edi, r8d
       ja       G_M000_IG20
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r8d
       sub      esi, edi
       cmp      r14d, esi
       ja       G_M000_IG24
       mov      edi, r14d
       shl      rdi, 4
       mov      r9, rdi
       cmp      r9, 0x4000
       ja       G_M000_IG23
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7efc198e8818)], 0
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x014B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x160]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      r14d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r14d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r15
       mov      r13, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r13
       lea      rsi, [rbp-0x140]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, dword ptr [rbp-0x184]
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG08:                ;; offset=0x01D9
       nop      
 
G_M000_IG09:                ;; offset=0x01DA
       add      rsp, 456
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x01EC
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG19
       xor      edi, edi
       mov      bword ptr [rbp+0x40], rcx
       mov      qword ptr [rcx], rdi
       mov      qword ptr [rcx+0x08], rdi
       cmp      byte  ptr [r13+0x34], 0
       je       G_M000_IG13
       mov      rdi, gword ptr [rbx+0x38]
       mov      r9, gword ptr [rdi+0xB0]
       mov      gword ptr [rbp-0x190], r9
       mov      rsi, gword ptr [r9+0x08]
       mov      esi, dword ptr [rsi+0x08]
       cmp      esi, dword ptr [rdi+0xCC]
       jne      G_M000_IG17
       mov      rdi, rbx
       mov      rsi, r9
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(Lokad.Lython.Frontend.FunctionParameterLayout,int):bool:this]
       test     eax, eax
       je       G_M000_IG16
       mov      rax, gword ptr [r12+0x98]
       mov      gword ptr [rbp-0x198], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG18
 
G_M000_IG11:                ;; offset=0x026C
       mov      gword ptr [rbp-0x180], rbx
       mov      rcx, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x178], rcx
       mov      rax, bword ptr [rbp-0x1A0]
       mov      bword ptr [rbp-0x170], rax
       mov      dword ptr [rbp-0x168], r14d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x180]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG12:                ;; offset=0x02E3
       test     eax, eax
       mov      rax, bword ptr [rbp-0x1A0]
       mov      rcx, bword ptr [rbp+0x40]
       je       G_M000_IG05
       mov      r13, bword ptr [rbp+0x38]
       mov      byte  ptr [r13], 0
       xor      r8, r8
       mov      r13, bword ptr [rbp+0x48]
       mov      gword ptr [r13], r8
       jmp      G_M000_IG08
 
G_M000_IG13:                ;; offset=0x030F
       mov      rax, bword ptr [rbp-0x1A0]
 
G_M000_IG14:                ;; offset=0x0316
       xor      esi, esi
       mov      bword ptr [rbp-0x1A0], rax
       mov      eax, esi
       jmp      SHORT G_M000_IG12
 
G_M000_IG15:                ;; offset=0x0323
       mov      rax, bword ptr [rbp-0x1A0]
       jmp      G_M000_IG05
 
G_M000_IG16:                ;; offset=0x032F
       mov      rax, bword ptr [rbp-0x1A0]
       jmp      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x0338
       mov      rax, bword ptr [rbp-0x1A0]
       jmp      SHORT G_M000_IG14
 
G_M000_IG18:                ;; offset=0x0341
       mov      rdi, gword ptr [rbp-0x198]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG11
 
G_M000_IG19:                ;; offset=0x0357
       mov      rax, bword ptr [rbp-0x1A0]
       mov      rsi, gword ptr [rbx+0x38]
       cmp      r14d, dword ptr [rsi+0xCC]
       jne      G_M000_IG05
       mov      bword ptr [rbp+0x40], rcx
       mov      bword ptr [rbp-0x1A0], rax
       mov      rsi, rax
       mov      edx, r14d
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0396
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x039D
       mov      edi, 1
       test     r8d, r8d
       je       G_M000_IG26
       mov      gword ptr [rbp-0x128], r15
       xor      esi, esi
       mov      qword ptr [rbp-0x120], rsi
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x03C0
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x03CA
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG07
 
G_M000_IG24:                ;; offset=0x03E2
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG25:                ;; offset=0x03E9
       mov      rdi, gword ptr [rbx+0x38]
       mov      rdi, gword ptr [rdi+0xB0]
       mov      rdi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rdi+0x08]
       cmp      esi, r8d
       mov      bword ptr [rbp+0x40], rcx
       ja       SHORT G_M000_IG20
       mov      gword ptr [rsp], r12
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r15
       mov      gword ptr [rsp+0x18], r13
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], r14d
       lea      rdi, bword ptr [rbp-0x128]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG07
 
G_M000_IG26:                ;; offset=0x043F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1093

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(Lokad.Lython.Frontend.FunctionParameterLayout,int,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 10400
; 6 inlinees with PGO data; 11 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       push     rax
       lea      rbp, [rsp+0x30]
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      ebx, edx
       mov      r15, rcx
 
G_M000_IG02:                ;; offset=0x001B
       mov      r14d, dword ptr [rsi+0x3C]
       cmp      ebx, r14d
       jge      G_M000_IG16
 
G_M000_IG03:                ;; offset=0x0028
       mov      r13, gword ptr [rdi+0x10]
       mov      r12, r13
       test     r12, r12
       je       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0034
       mov      rsi, 0x7EFB9C644408
       cmp      qword ptr [r12], rsi
       jne      G_M000_IG23
 
G_M000_IG05:                ;; offset=0x0048
       test     r12, r12
       je       G_M000_IG28
       mov      rsi, gword ptr [r12+0x08]
       mov      rdi, rsi
       test     rdi, rdi
       jne      G_M000_IG24
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x0067
       sub      r14d, ebx
       mov      r13d, eax
       sub      r13d, r14d
       cmp      r13d, eax
       jae      G_M000_IG25
       mov      rdi, 0x7EFB9B6427A0
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      G_M000_IG27
       mov      rdi, r12
       mov      esi, r13d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rdi, gword ptr [rax]
       mov      rcx, 0x7EEBF1801308
       cmp      rdi, gword ptr [rcx]
       jne      G_M000_IG26
       movsxd   r14, r13d
       inc      r14
 
G_M000_IG07:                ;; offset=0x00B9
       mov      r13d, 1
 
G_M000_IG08:                ;; offset=0x00BF
       xor      rsi, rsi
       mov      gword ptr [rbp-0x30], rsi
       test     r13d, r13d
       je       G_M000_IG31
       mov      rsi, 0x7EEBF1801308
       cmp      r12, gword ptr [rsi]
       je       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x00DD
       test     r14, r14
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E2
       mov      rdi, r12
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x00F0
       mov      rdi, r12
       test     rdi, rdi
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x00F8
       mov      rsi, 0x7EFB9C644408
       cmp      qword ptr [rdi], rsi
       jne      G_M000_IG30
 
G_M000_IG13:                ;; offset=0x010B
       test     rdi, rdi
       je       SHORT G_M000_IG10
       lea      esi, [r14-0x01]
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x011F
       mov      qword ptr [r15], r14
       mov      eax, 1
 
G_M000_IG15:                ;; offset=0x0127
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x0136
       mov      rsi, gword ptr [rsi+0x18]
       mov      eax, ebx
       sub      eax, r14d
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG33
       shl      rax, 4
       mov      ebx, dword ptr [rsi+rax+0x18]
       cmp      byte  ptr [rdi+0x18], 0
       je       SHORT G_M000_IG22
       mov      rdi, gword ptr [rdi+0x08]
 
G_M000_IG17:                ;; offset=0x015A
       mov      rsi, 0x7EEBF1801308
       cmp      rdi, gword ptr [rsi]
       je       SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0169
       mov      rsi, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG19:                ;; offset=0x0172
       nop      
 
G_M000_IG20:                ;; offset=0x0173
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0182
       xor      eax, eax
       mov      qword ptr [r15], rax
       mov      eax, 1
       jmp      SHORT G_M000_IG19
 
G_M000_IG22:                ;; offset=0x018E
       mov      rsi, gword ptr [rdi+0x08]
       mov      rdi, 0x7EFB9B6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       cmp      ebx, dword ptr [rax+0x08]
       jae      G_M000_IG33
       mov      edi, ebx
       mov      rdi, gword ptr [rax+8*rdi+0x10]
       jmp      SHORT G_M000_IG17
 
G_M000_IG23:                ;; offset=0x01B4
       mov      rsi, r13
       mov      rdi, 0x7EFB9C4608E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       jmp      G_M000_IG05
 
G_M000_IG24:                ;; offset=0x01CE
       mov      eax, dword ptr [rdi+0x08]
       test     eax, eax
       jl       G_M000_IG34
       jmp      G_M000_IG06
 
G_M000_IG25:                ;; offset=0x01DE
       xor      r12, r12
       xor      r14d, r14d
       xor      r13d, r13d
       jmp      G_M000_IG08
 
G_M000_IG26:                ;; offset=0x01EC
       mov      rdi, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r12, rax
       mov      r14, rdx
       jmp      G_M000_IG07
 
G_M000_IG27:                ;; offset=0x0200
       cmp      r13d, dword ptr [rax+0x08]
       jae      G_M000_IG33
       mov      edi, r13d
       mov      rdi, gword ptr [rax+8*rdi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r12, rax
       mov      r14, rdx
       jmp      G_M000_IG07
 
G_M000_IG28:                ;; offset=0x0223
       test     r13, r13
       je       SHORT G_M000_IG29
       lea      rsi, [rbp-0x30]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyTupleLike:TryGetItems(System.Object,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG29
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7EFB9A421AC8
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       mov      edi, r14d
       sub      edi, eax
       sub      ebx, edi
       js       SHORT G_M000_IG29
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7EFB9A421AD0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       cmp      eax, ebx
       jle      SHORT G_M000_IG29
       mov      rdi, gword ptr [rbp-0x30]
       mov      esi, ebx
       mov      r11, 0x7EFB9A421AD8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r12, rax
       mov      r14, rdx
       mov      r13d, 1
       jmp      G_M000_IG08
 
G_M000_IG29:                ;; offset=0x0295
       xor      r12, r12
       xor      r14d, r14d
       xor      r13d, r13d
       jmp      G_M000_IG08
 
G_M000_IG30:                ;; offset=0x02A3
       mov      rsi, r12
       mov      rdi, 0x7EFB9C4608E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG13
 
G_M000_IG31:                ;; offset=0x02BD
       xor      eax, eax
       mov      qword ptr [r15], rax
 
G_M000_IG32:                ;; offset=0x02C2
       add      rsp, 8
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG33:                ;; offset=0x02D1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG34:                ;; offset=0x02D7
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 733

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 27824
; 8 inlinees with PGO data; 36 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x60], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x50], rax
       mov      dword ptr [rbp-0x2C], ecx
       mov      r12, rdi
       mov      rbx, rsi
       mov      r13, rdx
       mov      r15, r8
       mov      r14, r9
       mov      rsi, gword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x003F
       mov      rdi, gword ptr [rbp+0x40]
       mov      gword ptr [rbp-0xA0], rdi
       cmp      dword ptr [rbp+0x30], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0050
       mov      gword ptr [rbp+0x38], rsi
       mov      r9, rsi
       or       r9, rdi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x005C
       xor      r9, r9
       mov      rsi, gword ptr [rbp+0x38]
       mov      rdi, gword ptr [rbp-0xA0]
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x006C
       mov      rsi, gword ptr [rbp+0x38]
       mov      rdi, gword ptr [rbp-0xA0]
 
G_M000_IG06:                ;; offset=0x0077
       mov      r9, gword ptr [r12+0x08]
       test     r9, r9
       je       G_M000_IG42
 
G_M000_IG07:                ;; offset=0x0085
       test     r9, r9
       je       G_M000_IG41
 
G_M000_IG08:                ;; offset=0x008E
       mov      gword ptr [rbp+0x38], rsi
       mov      gword ptr [rbp-0x80], r9
       mov      edi, dword ptr [r9+0x20]
       call     [Lokad.Lython.Runtime.PyDict:NativeCapacity(int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       add      rax, 160
       jo       G_M000_IG44
 
G_M000_IG09:                ;; offset=0x00B7
       mov      qword ptr [rbp-0x48], rax
       mov      qword ptr [rbp-0x38], rax
       cmp      byte  ptr [rbp+0x50], 0
       jne      G_M000_IG43
 
G_M000_IG10:                ;; offset=0x00C9
       cmp      dword ptr [rbp+0x60], 0
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00CF
       mov      rax, qword ptr [rbp-0x38]
       add      rax, 96
       jo       G_M000_IG44
       mov      qword ptr [rbp-0x38], rax
 
G_M000_IG12:                ;; offset=0x00E1
       mov      rax, gword ptr [r15+0x98]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x00FD
       mov      rdi, gword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x38]
       mov      rdx, r14
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG14:                ;; offset=0x0111
       mov      rax, gword ptr [r15+0x98]
       mov      r11, gword ptr [rax+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG31
       mov      r11, gword ptr [rax+0x180]
       test     r11, r11
       jne      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x013A
       xor      rax, rax
       cmp      dword ptr [rbp+0x60], 0
       je       SHORT G_M000_IG22
 
G_M000_IG16:                ;; offset=0x0142
       mov      rdi, 0x7EFB9C5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
 
G_M000_IG17:                ;; offset=0x0154
       mov      rax, bword ptr [rbp+0x58]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG18:                ;; offset=0x0161
       mov      rdi, gword ptr [rbp-0x58]
       mov      rcx, 0x7EEBF1801308
       cmp      rdi, gword ptr [rcx]
       jne      G_M000_IG34
       mov      rdi, gword ptr [r13+0x10]
       mov      rcx, rdi
       test     rcx, rcx
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x0188
       test     rdi, rdi
       jne      G_M000_IG33
 
G_M000_IG20:                ;; offset=0x0191
       mov      rdi, qword ptr [rbp-0x50]
       mov      qword ptr [rbp-0x60], rdi
       mov      qword ptr [r13+0x20], rdi
       mov      byte  ptr [r13+0x28], 1
       xor      rdi, rdi
       mov      gword ptr [r13+0x08], rdi
 
G_M000_IG21:                ;; offset=0x01A8
       mov      gword ptr [rbp-0x78], r13
       mov      rcx, r13
       mov      r13, rcx
       mov      rax, gword ptr [rbp-0x78]
 
G_M000_IG22:                ;; offset=0x01B6
       cmp      byte  ptr [rbp-0x2C], 0
       jne      G_M000_IG37
       mov      gword ptr [rbp-0x78], rax
       mov      rdi, 0x7EFB9C5FCF30
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rsi, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x98], rcx
       movzx    rdx, byte  ptr [rbp+0x20]
       mov      byte  ptr [rbp-0x64], dl
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x90]
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x98]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x90]
       movzx    rdi, byte  ptr [rbp-0x64]
       mov      byte  ptr [rax+0x18], dil
       lea      rdi, bword ptr [rax+0x38]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, gword ptr [rbp-0x90]
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x48]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG23:                ;; offset=0x024D
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       mov      rbx, gword ptr [rbp-0x80]
       test     rbx, rbx
       je       SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x0266
       mov      rdi, gword ptr [rbp-0xA0]
       mov      rsi, rdi
       test     rsi, rsi
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0275
       mov      r13, gword ptr [rbp+0x38]
       mov      rsi, r13
       test     rsi, rsi
       je       G_M000_IG38
 
G_M000_IG26:                ;; offset=0x0285
       lea      rdi, bword ptr [r12+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbp+0x4C]
       mov      byte  ptr [r12+0x1B], dil
 
G_M000_IG27:                ;; offset=0x0299
       mov      rsi, gword ptr [rbp-0x70]
       cmp      byte  ptr [rsi], sil
       cmp      qword ptr [rbp-0x38], 0
       jle      SHORT G_M000_IG28
       mov      rdi, qword ptr [rsi+0x28]
       mov      rax, rdi
       cmp      qword ptr [rbp-0x38], rax
       cmovle   rax, qword ptr [rbp-0x38]
       sub      rdi, rax
       mov      qword ptr [rsi+0x28], rdi
       add      rax, qword ptr [rsi+0x30]
       jo       G_M000_IG35
       mov      qword ptr [rsi+0x30], rax
       mov      rsi, gword ptr [rbp-0x70]
 
G_M000_IG28:                ;; offset=0x02D0
       mov      r13, gword ptr [rbp-0x78]
       test     r13, r13
       je       G_M000_IG39
 
G_M000_IG29:                ;; offset=0x02DD
       mov      byte  ptr [r13+0x29], 1
       cmp      dword ptr [rbp+0x60], 0
       jbe      G_M000_IG36
       mov      rdi, bword ptr [rbp+0x58]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      rbx, bword ptr [rbp+0x58]
       mov      qword ptr [rbx+0x08], rdi
       jmp      G_M000_IG39
 
G_M000_IG30:                ;; offset=0x0307
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG15
 
G_M000_IG31:                ;; offset=0x031D
       mov      rdi, rax
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG15
 
G_M000_IG32:                ;; offset=0x032E
       cmp      byte  ptr [rcx+0x101], 0
       jne      SHORT G_M000_IG34
       jmp      G_M000_IG19
 
G_M000_IG33:                ;; offset=0x033C
       movzx    rdi, byte  ptr [rdi+0xFF]
       test     edi, edi
       je       G_M000_IG20
 
G_M000_IG34:                ;; offset=0x034C
       lea      rdi, [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG21
 
G_M000_IG35:                ;; offset=0x0367
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG36:                ;; offset=0x036D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG37:                ;; offset=0x0373
       mov      gword ptr [rbp-0x78], rax
       mov      rdi, 0x7EFB9C6222F8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rax
       mov      rsi, r12
       mov      rdx, rbx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      r12, gword ptr [rbp-0x88]
       jmp      G_M000_IG23
 
G_M000_IG38:                ;; offset=0x03D4
       mov      rsi, bword ptr [rbp+0x28]
       mov      edx, dword ptr [rbp+0x30]
       mov      rdi, rbx
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      rsi, rax
       jmp      G_M000_IG26
 
G_M000_IG39:                ;; offset=0x03F5
       mov      rax, r12
 
G_M000_IG40:                ;; offset=0x03F8
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG41:                ;; offset=0x040A
       xor      r10d, r10d
       mov      dword ptr [rbp-0x3C], r10d
       mov      r11d, 160
       mov      gword ptr [rbp-0x80], r9
       mov      gword ptr [rbp+0x38], rsi
       mov      rax, r11
       jmp      G_M000_IG09
 
G_M000_IG42:                ;; offset=0x0427
       mov      rdi, 0x7EFB9BA5C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7EFC15DBC7A8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG43:                ;; offset=0x0455
       mov      rdi, 0x7EFB9C14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdi, qword ptr [rbp-0x48]
       add      rdi, qword ptr [(reloc 0x7efb9a41b0c0)]
       jo       SHORT G_M000_IG44
       mov      qword ptr [rbp-0x38], rdi
       jmp      G_M000_IG10
 
G_M000_IG44:                ;; offset=0x047B
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG45:                ;; offset=0x0481
       sub      rsp, 24
 
G_M000_IG46:                ;; offset=0x0485
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG47
       mov      rdi, gword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG47:                ;; offset=0x049F
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1189

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(Lokad.Lython.Frontend.FunctionParameterLayout,int):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rbp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 27464
; 1 inlinees with PGO data; 8 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       lea      rbp, [rsp+0x20]
       mov      r14, rdi
       mov      rbx, rsi
       mov      r15d, edx
 
G_M000_IG02:                ;; offset=0x0016
       mov      r13d, dword ptr [rbx+0x40]
       test     r13d, r13d
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x001F
       cmp      byte  ptr [r14+0x18], 0
       je       SHORT G_M000_IG11
 
G_M000_IG04:                ;; offset=0x0026
       mov      rsi, gword ptr [rbx+0x28]
       mov      esi, dword ptr [rsi+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, r13d
       jne      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x0039
       mov      ebx, dword ptr [rbx+0x3C]
       cmp      r15d, ebx
       jg       G_M000_IG15
       mov      rsi, gword ptr [r14+0x10]
       mov      r14, rsi
       test     r14, r14
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0051
       mov      rdi, 0x7EFB9C644408
       cmp      qword ptr [r14], rdi
       jne      SHORT G_M000_IG12
 
G_M000_IG07:                ;; offset=0x0060
       test     r14, r14
       je       SHORT G_M000_IG13
 
G_M000_IG08:                ;; offset=0x0065
       mov      rax, gword ptr [r14+0x08]
       test     rax, rax
       jne      SHORT G_M000_IG14
       mov      ecx, 1
 
G_M000_IG09:                ;; offset=0x0073
       sub      ebx, ecx
       cmp      ebx, r15d
       setle    al
       movzx    rax, al
 
G_M000_IG10:                ;; offset=0x007E
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x0087
       mov      rsi, gword ptr [r14+0x08]
       mov      rdi, 0x7EFB9B6427A0
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG15
       jmp      SHORT G_M000_IG04
 
G_M000_IG12:                ;; offset=0x00A1
       mov      rdi, 0x7EFB9C4608E8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG13:                ;; offset=0x00B5
       xor      ecx, ecx
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x00B9
       mov      ecx, dword ptr [rax+0x08]
       test     ecx, ecx
       jl       SHORT G_M000_IG17
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x00C2
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x00C4
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x00CD
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 211

