; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xD0], ymm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004F
       lea      rdi, [rbp+0x30]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006B
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [rbp-0xD0]
       mov      rdi, 0x7F91EB622090
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x78], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x009B
       xor      rax, rax
       mov      gword ptr [rbp-0x78], rax
 
G_M000_IG05:                ;; offset=0x00A1
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B7
       mov      rdi, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x7C], eax
 
G_M000_IG07:                ;; offset=0x00C4
       mov      eax, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG08
       mov      edi, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00E3
       mov      qword ptr [rbp-0x88], 160
 
G_M000_IG09:                ;; offset=0x00EE
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0x48], rax
       movzx    rax, byte  ptr [rbp+0x58]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rdi, 0x7F91EB14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7f91e941b0c0)]
       add      rax, qword ptr [rbp-0x48]
       jo       G_M000_IG23
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG10:                ;; offset=0x0126
       lea      rdi, [rbp+0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rax, qword ptr [rbp-0x48]
       add      rax, 96
       jo       G_M000_IG23
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG11:                ;; offset=0x0146
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp+0x48], 0
       jne      SHORT G_M000_IG12
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x0171
       nop      
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rbp+0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F91EB5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xC0], rax
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG15
       mov      rax, bword ptr [rbp+0x60]
       mov      rsi, gword ptr [rax]
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG15
       mov      rax, bword ptr [rbp+0x60]
       mov      rdx, qword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x20], rax
 
G_M000_IG14:                ;; offset=0x01F2
       movzx    rax, byte  ptr [rbp-0x24]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rdi, 0x7F91EB5FCE90
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB8], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x98], rax
       jmp      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0266
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG16:                ;; offset=0x026C
       mov      rdi, 0x7F91EB6221E0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG17:                ;; offset=0x02D6
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG19
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0xA8], rax
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG18
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG18
       mov      rsi, bword ptr [rbp+0x30]
       mov      rdx, qword ptr [rbp+0x38]
       mov      rdi, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG18:                ;; offset=0x036C
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x30]
       movzx    rcx, byte  ptr [rbp+0x54]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG19:                ;; offset=0x038A
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG20
       mov      rax, gword ptr [rbp-0x58]
       mov      byte  ptr [rax+0x29], 1
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG15
       mov      rdi, bword ptr [rbp+0x60]
       mov      rsi, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG20:                ;; offset=0x03C1
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG21:                ;; offset=0x03C9
       mov      rax, gword ptr [rbp-0x70]
 
G_M000_IG22:                ;; offset=0x03CD
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x03D6
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG24:                ;; offset=0x03DC
       sub      rsp, 24
 
G_M000_IG25:                ;; offset=0x03E0
       mov      gword ptr [rbp-0xC8], rdi
       cmp      gword ptr [rbp+0x48], 0
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03EE
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG27:                ;; offset=0x03FE
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1028

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, bword ptr [rbp-0x20]
       mov      byte  ptr [rax], 0
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0041
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0047
       mov      rax, bword ptr [rbp-0x20]
       mov      bword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x40], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x4C], eax
       mov      esi, dword ptr [rbp-0x4C]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008C
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x40], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG06:                ;; offset=0x0099
       mov      rax, bword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x44]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp-0x20]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00B2
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00B8
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG13
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG13
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG09
       mov      rsi, gword ptr [rbp-0x28]
       mov      rdi, 0x7F91EB4608D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x0119
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG10
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0147
       xor      eax, eax
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG11:                ;; offset=0x014C
       cmp      dword ptr [rbp-0x48], 0
       sete     al
       movzx    rax, al
 
G_M000_IG12:                ;; offset=0x0156
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x015C
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x015E
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 356

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG18:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG18
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG07
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG07
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG04
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0120
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG05:                ;; offset=0x0128
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG07
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG06:                ;; offset=0x0141
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x014A
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG08:                ;; offset=0x01A8
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG09:                ;; offset=0x01B8
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG10:                ;; offset=0x01F6
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0206
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG13
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG12
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG17
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG12:                ;; offset=0x026B
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A9
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG14:                ;; offset=0x034D
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG15:                ;; offset=0x035D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG16:                ;; offset=0x03F7
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0400
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1030

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       vmovdqa  xmmword ptr [rbp-0x20], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      dword ptr [rbp-0x0C], esi
 
G_M000_IG02:                ;; offset=0x0026
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x10]
       mov      rdi, 0x7F91EA6427A0
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0061
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x38], eax
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x38]
       sub      ecx, eax
       mov      dword ptr [rbp-0x3C], ecx
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00A2
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jl       G_M000_IG08
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x10], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rsi, gword ptr [rbp-0x48]
       mov      rdi, 0x7F91EB4608D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x10]
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0116
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       mov      rdi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x34], eax
 
G_M000_IG06:                ;; offset=0x012F
       mov      eax, dword ptr [rbp-0x30]
       sub      eax, dword ptr [rbp-0x34]
       cmp      dword ptr [rbp-0x2C], eax
       setge    al
       movzx    rax, al
 
G_M000_IG07:                ;; offset=0x013E
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0144
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0146
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 332

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 144
       lea      rbp, [rsp+0x90]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       xor      eax, eax
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      dword ptr [rbp-0x0C], esi
       mov      bword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0035
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jg       G_M000_IG10
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp-0x0C]
       sub      ecx, eax
       mov      dword ptr [rbp-0x84], ecx
       mov      esi, dword ptr [rbp-0x84]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG03:                ;; offset=0x0083
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG04:                ;; offset=0x008D
       lea      rdi, [rbp-0x40]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rax+0x10]
       mov      rdi, 0x7F91EA6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x2C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG14
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00DA
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x80], rax
       mov      qword ptr [rbp-0x78], rdx
 
G_M000_IG07:                ;; offset=0x00F8
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG08:                ;; offset=0x0102
       lea      rdi, [rbp-0x50]
       mov      rsi, bword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0111
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x011A
       lea      rdx, [rbp-0x28]
       mov      rdi, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       lea      rdi, [rbp-0x28]
       mov      rsi, bword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x013E
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x0147
       mov      rax, bword ptr [rbp-0x18]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x0152
       add      rsp, 144
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x015B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 353

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      bword ptr [rbp-0x20], rcx
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp-0x20]
       mov      byte  ptr [rax], 0
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rdi, 0x7F91EB9D86B0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x004F
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0055
       mov      rax, bword ptr [rbp-0x20]
       mov      bword ptr [rbp-0x38], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x40], rax
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      esi, dword ptr [rbp-0x54]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x009A
       mov      rdi, 0x7F91EB9D86B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x38]
       mov      bword ptr [rbp-0x40], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG06:                ;; offset=0x00B6
       mov      rax, bword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x44]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp-0x20]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rdi, 0x7F91EB9D86B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00DE
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00E4
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG17
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      G_M000_IG12
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x50], rax
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, 0x7F91EB9D86C0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x60], rax
       mov      rsi, gword ptr [rbp-0x60]
       mov      rdi, 0x7F91EB4608D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x016C
       mov      rdi, 0x7F91EB9D87C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG10:                ;; offset=0x017B
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x30], rax
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG14
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01A9
       mov      rdi, 0x7F91EB9D87CC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x01BA
       mov      rdi, 0x7F91EB9D87D0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x01CB
       mov      rdi, 0x7F91EB9D87D4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG14:                ;; offset=0x01DC
       mov      rdi, 0x7F91EB9D87D8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG15:                ;; offset=0x01F0
       mov      rdi, 0x7F91EB9D87DC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      dword ptr [rbp-0x48], 0
       sete     al
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x0209
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x020F
       mov      rdi, 0x7F91EB9D87E0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x0220
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 550

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 592
       lea      rbp, [rsp+0x250]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x200], xmm8
       vmovdqa  xmmword ptr [rbp-0x1F0], xmm8
       mov      rax, -432
 
G_M000_IG21:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG21
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      bword ptr [rbp-0x20], rdx
       mov      qword ptr [rbp-0x18], rcx
       mov      gword ptr [rbp-0x28], r8
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x005F
       cmp      gword ptr [rbp-0x28], 0
       jne      G_M000_IG09
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp], rax
       mov      rdx, bword ptr [rbp-0x20]
       mov      rcx, qword ptr [rbp-0x18]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rsi, gword ptr [rbp-0x10]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rdi, 0x7F91EB9D8B38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x00D0
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x1E8], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1E8]
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7F91EB9D8B3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       lea      rdi, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       mov      rsi, bword ptr [rbp-0x200]
       mov      rdx, qword ptr [rbp-0x1F8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x1EC], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0142
       mov      rdi, 0x7F91EB9D8B40
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x1EC], eax
 
G_M000_IG06:                ;; offset=0x0159
       cmp      dword ptr [rbp-0x1EC], 0
       je       SHORT G_M000_IG08
       mov      rdi, 0x7F91EB9D8B44
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x38]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x48]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG07:                ;; offset=0x0181
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x018A
       mov      rdi, 0x7F91EB9D8B48
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG09:                ;; offset=0x0199
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       vmovdqu  ymmword ptr [rbp-0xB0], ymm0
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
       vmovdqu  ymmword ptr [rbp-0x70], ymm0
       vmovdqu  ymmword ptr [rbp-0x50], ymm0
       lea      rdi, [rbp-0x130]
       mov      esi, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      bword ptr [rbp-0x1A0], rax
       mov      qword ptr [rbp-0x198], rdx
 
G_M000_IG10:                ;; offset=0x01F7
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG11:                ;; offset=0x0207
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x204], eax
       mov      edx, dword ptr [rbp-0x204]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1B0], rax
       mov      qword ptr [rbp-0x1A8], rdx
 
G_M000_IG12:                ;; offset=0x0245
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
 
G_M000_IG13:                ;; offset=0x0255
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG15
       xor      eax, eax
       mov      dword ptr [rbp-0x144], eax
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG14
       mov      rdi, 0x7F91EB9D8B4C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       mov      dword ptr [rbp-0x1E4], eax
       mov      eax, dword ptr [rbp-0x144]
       inc      eax
       mov      dword ptr [rbp-0x144], eax
       mov      eax, dword ptr [rbp-0x138]
       cmp      dword ptr [rbp-0x1E4], eax
       jae      G_M000_IG20
       mov      eax, dword ptr [rbp-0x1E4]
       shl      rax, 4
       mov      rdi, rax
       add      rdi, bword ptr [rbp-0x140]
       mov      rsi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x02C9
       lea      rdi, [rbp-0x140]
       mov      esi, dword ptr [rbp-0x144]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       mov      rsi, bword ptr [rbp-0x1E0]
       mov      rdx, qword ptr [rbp-0x1D8]
       lea      rdi, [rbp-0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0307
       mov      rdi, 0x7F91EB9D8B50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x208], eax
       mov      edx, dword ptr [rbp-0x208]
       lea      rdi, [rbp-0x140]
       xor      esi, esi
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       mov      bword ptr [rbp-0x1C0], rax
       mov      qword ptr [rbp-0x1B8], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x158], xmm0
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rsp], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x08], eax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rsp+0x10], rax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rsp+0x18], rax
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp-0x20]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, bword ptr [rbp-0x1C0]
       mov      rsi, qword ptr [rbp-0x1B8]
       mov      rdx, bword ptr [rbp-0x158]
       mov      rcx, qword ptr [rbp-0x150]
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG16:                ;; offset=0x03BA
       mov      rdi, 0x7F91EB9D8B54
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x03C9
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG18:                ;; offset=0x03D9
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x190], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x190]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       lea      rdi, [rsp+0x20]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], rax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x40], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x1D0]
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rbp-0x08]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG19:                ;; offset=0x0473
       add      rsp, 592
       pop      rbp
       ret      
 
G_M000_IG20:                ;; offset=0x047C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1154

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 160
       lea      rbp, [rsp+0xA0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      dword ptr [rbp-0x0C], esi
       mov      bword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0044
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jg       G_M000_IG10
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp-0x0C]
       sub      ecx, eax
       mov      dword ptr [rbp-0x8C], ecx
       mov      esi, dword ptr [rbp-0x8C]
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG03:                ;; offset=0x0092
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG04:                ;; offset=0x009C
       lea      rdi, [rbp-0x40]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x2C], eax
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x88], rax
       mov      rdi, gword ptr [rbp-0x88]
       mov      rsi, 0x7F91EB9DAE08
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, 0x7F91EA6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x2C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG14
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x011B
       mov      rdi, 0x7F91EB9DAF10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x0136
       mov      rdi, 0x7F91EB9DAF14
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      gword ptr [rbp-0x80], rax
       mov      qword ptr [rbp-0x78], rdx
 
G_M000_IG07:                ;; offset=0x0157
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG08:                ;; offset=0x0161
       lea      rdi, [rbp-0x50]
       mov      rsi, bword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG09:                ;; offset=0x0170
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0179
       lea      rdx, [rbp-0x28]
       mov      rdi, gword ptr [rbp-0x08]
       mov      esi, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rdi, 0x7F91EB9DAF18
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x28]
       mov      rsi, bword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG11:                ;; offset=0x01AC
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01B5
       mov      rdi, 0x7F91EB9DAF1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x18]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x01CF
       add      rsp, 160
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01D8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 478

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 240
       lea      rbp, [rsp+0xF0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0xD0], ymm8
       vmovdqu  ymmword ptr [rbp-0xB0], ymm8
       vmovdqu  ymmword ptr [rbp-0x90], ymm8
       vmovdqu  ymmword ptr [rbp-0x70], ymm8
       vmovdqu  ymmword ptr [rbp-0x50], ymm8
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
       mov      gword ptr [rbp-0x20], rcx
       mov      dword ptr [rbp-0x24], r8d
       mov      gword ptr [rbp-0x30], r9
 
G_M000_IG02:                ;; offset=0x004F
       lea      rdi, [rbp+0x30]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x40], 0
       jne      SHORT G_M000_IG05
       cmp      gword ptr [rbp+0x48], 0
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x006B
       mov      rdi, 0x7F91EB9DB038
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x007A
       mov      rdi, gword ptr [rbp-0x10]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [rbp-0xD0]
       mov      rdi, 0x7F91EB622090
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x78], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00AA
       mov      rdi, 0x7F91EB9DB03C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG04
 
G_M000_IG06:                ;; offset=0x00BB
       mov      rdi, 0x7F91EB9DB040
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x78], rax
 
G_M000_IG07:                ;; offset=0x00D0
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x38], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x7C], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00E6
       mov      rdi, 0x7F91EB9DB044
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x7C], eax
 
G_M000_IG09:                ;; offset=0x0102
       mov      eax, dword ptr [rbp-0x7C]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [rbp-0x38], 0
       je       SHORT G_M000_IG10
       mov      edi, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x88], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0121
       mov      rdi, 0x7F91EB9DB048
       call     CORINFO_HELP_COUNTPROFILE32
       mov      qword ptr [rbp-0x88], 160
 
G_M000_IG11:                ;; offset=0x013B
       mov      rax, qword ptr [rbp-0x88]
       mov      qword ptr [rbp-0x48], rax
       movzx    rax, byte  ptr [rbp+0x58]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rdi, 0x7F91EB9DB04C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7F91EB14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7f91e941b0c0)]
       add      rax, qword ptr [rbp-0x48]
       jo       G_M000_IG26
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG12:                ;; offset=0x0182
       lea      rdi, [rbp+0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rdi, 0x7F91EB9DB050
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x48]
       add      rax, 96
       jo       G_M000_IG26
       mov      qword ptr [rbp-0x48], rax
 
G_M000_IG13:                ;; offset=0x01B1
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp+0x48], 0
       jne      SHORT G_M000_IG14
       mov      rdi, 0x7F91EB9DB054
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x01EB
       nop      
 
G_M000_IG15:                ;; offset=0x01EC
       mov      rdi, gword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x58], rax
       lea      rdi, [rbp+0x60]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rdi, 0x7F91EB9DB058
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7F91EB5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xC0], rax
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG23
       mov      rax, bword ptr [rbp+0x60]
       mov      rsi, gword ptr [rax]
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG23
       mov      rax, bword ptr [rbp+0x60]
       mov      rdx, qword ptr [rax+0x08]
       mov      rdi, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0x20], rax
 
G_M000_IG16:                ;; offset=0x027B
       movzx    rax, byte  ptr [rbp-0x24]
       test     eax, eax
       jne      SHORT G_M000_IG17
       mov      rdi, 0x7F91EB5FCE90
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB8], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0x98], rax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02EF
       mov      rdi, 0x7F91EB9DB05C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7F91EB6221E0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, gword ptr [rbp-0x90]
       mov      rsi, gword ptr [rbp-0x08]
       mov      rdx, gword ptr [rbp-0x10]
       mov      rcx, gword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG18:                ;; offset=0x0368
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x50]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x38], 0
       je       G_M000_IG20
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0xA8], rax
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG19
       mov      rax, gword ptr [rbp+0x40]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0xB0], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      G_M000_IG22
       mov      rdi, 0x7F91EB9DB060
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, bword ptr [rbp+0x30]
       mov      rdx, qword ptr [rbp+0x38]
       mov      rdi, gword ptr [rbp-0x38]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, gword ptr [rbp-0x30]
       mov      r9, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0xB0], rax
 
G_M000_IG19:                ;; offset=0x0411
       mov      rdi, 0x7F91EB9DB064
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x30]
       movzx    rcx, byte  ptr [rbp+0x54]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG20:                ;; offset=0x043E
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x58], 0
       je       SHORT G_M000_IG21
       mov      rdi, 0x7F91EB9DB068
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x58]
       mov      byte  ptr [rax+0x29], 1
       cmp      dword ptr [rbp+0x68], 0
       jbe      SHORT G_M000_IG23
       mov      rdi, bword ptr [rbp+0x60]
       mov      rsi, gword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG21:                ;; offset=0x0480
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x70], rax
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x048A
       mov      rdi, 0x7F91EB9DB06C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG19
 
G_M000_IG23:                ;; offset=0x049E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG24:                ;; offset=0x04A4
       mov      rdi, 0x7F91EB9DB074
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x70]
 
G_M000_IG25:                ;; offset=0x04B7
       add      rsp, 240
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x04C0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG27:                ;; offset=0x04C6
       sub      rsp, 24
 
G_M000_IG28:                ;; offset=0x04CA
       mov      gword ptr [rbp-0xC8], rdi
       cmp      gword ptr [rbp+0x48], 0
       jne      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04D8
       mov      rdi, 0x7F91EB9DB070
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, qword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG30:                ;; offset=0x04F7
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1277

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       vmovdqa  xmmword ptr [rbp-0x20], xmm8
       mov      gword ptr [rbp-0x08], rdi
       mov      dword ptr [rbp-0x0C], esi
 
G_M000_IG02:                ;; offset=0x0025
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x48], rax
       mov      rdi, gword ptr [rbp-0x48]
       mov      rsi, 0x7F91EB9DBEC0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x58], rax
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, 0x7F91EA6427A0
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0087
       mov      rdi, 0x7F91EB9DBFC8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0096
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x38], eax
       mov      rax, gword ptr [rbp-0x08]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x38]
       sub      ecx, eax
       mov      dword ptr [rbp-0x3C], ecx
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x3C]
       jne      G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00D7
       mov      rdi, 0x7F91EB9DBFCC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x00E6
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jl       G_M000_IG12
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x10], eax
       mov      rdi, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       mov      rdi, gword ptr [rbp-0x50]
       mov      rsi, 0x7F91EB9DBFD0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x60], rax
       mov      rsi, gword ptr [rbp-0x60]
       mov      rdi, 0x7F91EB4608D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x18], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x1C], eax
       mov      eax, dword ptr [rbp-0x10]
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp-0x18]
       mov      gword ptr [rbp-0x28], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG09
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x34], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0175
       mov      rdi, 0x7F91EB9DC0D8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x0186
       mov      rdi, 0x7F91EB9DC0DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x0197
       mov      rdi, 0x7F91EB9DC0E0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x1C]
       mov      dword ptr [rbp-0x2C], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x30], eax
       mov      rdi, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x34], eax
 
G_M000_IG10:                ;; offset=0x01BF
       mov      rdi, 0x7F91EB9DC0E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x30]
       sub      eax, dword ptr [rbp-0x34]
       cmp      dword ptr [rbp-0x2C], eax
       setge    al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x01DD
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01E3
       mov      rdi, 0x7F91EB9DC0E8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x01F4
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 506

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 25266
; 3 inlinees with PGO data; 25 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       push     rax
       lea      rbp, [rsp+0x10]
       mov      rbx, rdi
 
G_M000_IG02:                ;; offset=0x000B
       mov      byte  ptr [rcx], 0
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xDF], 0
       je       G_M000_IG12
       mov      rax, gword ptr [rbx+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG12
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG12
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG12
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG12
       cmp      dword ptr [rdi+0xD4], 16
       jg       G_M000_IG12
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG14
       mov      esi, dword ptr [rsi+0x28]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      byte  ptr [rdi+0x54], 0
       je       SHORT G_M000_IG11
 
G_M000_IG03:                ;; offset=0x007C
       mov      edi, dword ptr [rdi+0x3C]
       test     rdx, rdx
       setne    al
       movzx    rax, al
       sub      edi, eax
       cmp      edi, esi
       sete     sil
       movzx    rsi, sil
 
G_M000_IG04:                ;; offset=0x0094
       mov      byte  ptr [rcx], sil
       cmp      byte  ptr [rcx], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x009C
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rsi+0x08]
       cmp      dword ptr [rdi+0x08], 16
       jg       SHORT G_M000_IG12
       cmp      dword ptr [rsi+0x4C], 0
       jge      SHORT G_M000_IG12
       cmp      dword ptr [rsi+0x50], 0
       jge      SHORT G_M000_IG12
       mov      rsi, gword ptr [rbx+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x00BF
       mov      rax, rsi
       mov      rdi, 0x7F91EB644450
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG15
 
G_M000_IG07:                ;; offset=0x00D1
       test     rax, rax
       je       SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x00D6
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      SHORT G_M000_IG16
 
G_M000_IG09:                ;; offset=0x00E4
       mov      eax, 1
 
G_M000_IG10:                ;; offset=0x00E9
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x00F0
       xor      esi, esi
       jmp      SHORT G_M000_IG04
 
G_M000_IG12:                ;; offset=0x00F4
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x00F6
       add      rsp, 8
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x00FD
       xor      esi, esi
       jmp      SHORT G_M000_IG04
 
G_M000_IG15:                ;; offset=0x0101
       mov      rdi, 0x7F91EB4608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      SHORT G_M000_IG07
 
G_M000_IG16:                ;; offset=0x0112
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
       jmp      SHORT G_M000_IG12
 
; Total bytes of code 289

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 24862
; 7 inlinees with PGO data; 24 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       xor      eax, eax
       mov      qword ptr [rbp-0x178], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x170], xmm8
       vmovdqa  xmmword ptr [rbp-0x160], xmm8
       mov      rax, -288
 
G_M000_IG27:                ;; offset=0x0041
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG27
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x190], rdx
       mov      rbx, rdi
       mov      r13, rsi
       mov      r14d, ecx
       mov      r15, r8
       mov      r12, r9
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0077
       test     r15, r15
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x0080
       mov      rdi, gword ptr [rbx+0x40]
       cmp      byte  ptr [rdi+0xE0], 0
       jne      G_M000_IG10
 
G_M000_IG04:                ;; offset=0x0091
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG05:                ;; offset=0x0098
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x128], ymm0
       vmovdqu  ymmword ptr [rbp-0x108], ymm0
       vmovdqu  ymmword ptr [rbp-0xE8], ymm0
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       vmovdqu  ymmword ptr [rbp-0xA8], ymm0
       vmovdqu  ymmword ptr [rbp-0x88], ymm0
       vmovdqu  ymmword ptr [rbp-0x68], ymm0
       vmovdqu  ymmword ptr [rbp-0x48], ymm0
       mov      rdi, gword ptr [rbx+0x40]
       mov      r8d, dword ptr [rdi+0xD4]
       mov      dword ptr [rbp-0x17C], r8d
       cmp      r8d, 16
       ja       G_M000_IG20
       cmp      byte  ptr [rbp+0x20], 0
       je       G_M000_IG25
       xor      edi, edi
       test     r15, r15
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x0107
       cmp      edi, r8d
       ja       G_M000_IG20
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, edi
       shl      rdx, 4
       add      rdx, rsi
       mov      esi, r8d
       sub      esi, edi
       cmp      r14d, esi
       ja       G_M000_IG24
       mov      edi, r14d
       shl      rdi, 4
       mov      r9, rdi
       cmp      r9, 0x4000
       ja       G_M000_IG23
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7f92688d3818)], 0
       jne      G_M000_IG22
 
G_M000_IG07:                ;; offset=0x0164
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x160]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x20], r15
       mov      r14d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r14d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x30], r15
       mov      r13, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x38], r13
       lea      rsi, [rbp-0x140]
       mov      qword ptr [rsp+0x40], rsi
       lea      rsi, bword ptr [rbp-0x128]
       mov      edx, dword ptr [rbp-0x17C]
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG08:                ;; offset=0x01F2
       nop      
 
G_M000_IG09:                ;; offset=0x01F3
       add      rsp, 440
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0205
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG19
       xor      edi, edi
       mov      bword ptr [rbp+0x40], rcx
       mov      qword ptr [rcx], rdi
       mov      qword ptr [rcx+0x08], rdi
       cmp      byte  ptr [r13+0x34], 0
       je       G_M000_IG16
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      edi, dword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      edi, dword ptr [rsi+0xC4]
       jne      G_M000_IG15
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       G_M000_IG13
       mov      rax, gword ptr [r12+0x98]
       mov      gword ptr [rbp-0x188], rax
       cmp      byte  ptr [rax], al
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG18
 
G_M000_IG11:                ;; offset=0x0278
       mov      gword ptr [rbp-0x178], rbx
       mov      rax, bword ptr [rbp-0x190]
       mov      bword ptr [rbp-0x170], rax
       mov      dword ptr [rbp-0x168], r14d
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x178]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG12:                ;; offset=0x02D1
       test     eax, eax
       mov      rax, bword ptr [rbp-0x190]
       mov      rcx, bword ptr [rbp+0x40]
       je       G_M000_IG05
       mov      r13, bword ptr [rbp+0x38]
       mov      byte  ptr [r13], 0
       xor      rdx, rdx
       mov      r13, bword ptr [rbp+0x48]
       mov      gword ptr [r13], rdx
       jmp      G_M000_IG08
 
G_M000_IG13:                ;; offset=0x02FC
       mov      rax, bword ptr [rbp-0x190]
 
G_M000_IG14:                ;; offset=0x0303
       xor      esi, esi
       mov      bword ptr [rbp-0x190], rax
       mov      eax, esi
       jmp      SHORT G_M000_IG12
 
G_M000_IG15:                ;; offset=0x0310
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG16:                ;; offset=0x0319
       mov      rax, bword ptr [rbp-0x190]
       jmp      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x0322
       mov      rax, bword ptr [rbp-0x190]
       jmp      G_M000_IG05
 
G_M000_IG18:                ;; offset=0x032E
       mov      rdi, gword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG11
 
G_M000_IG19:                ;; offset=0x0344
       mov      rax, bword ptr [rbp-0x190]
       mov      rsi, gword ptr [rbx+0x40]
       cmp      r14d, dword ptr [rsi+0xC4]
       jne      G_M000_IG05
       mov      bword ptr [rbp+0x40], rcx
       mov      bword ptr [rbp-0x190], rax
       mov      rsi, rax
       mov      edx, r14d
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, bword ptr [rbp+0x40]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0383
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x038A
       mov      edi, 1
       test     r8d, r8d
       je       G_M000_IG26
       mov      gword ptr [rbp-0x128], r15
       xor      esi, esi
       mov      qword ptr [rbp-0x120], rsi
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x03AD
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x03B7
       mov      bword ptr [rbp+0x40], rcx
       mov      rdi, rdx
       mov      rsi, rax
       mov      rdx, r9
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG07
 
G_M000_IG24:                ;; offset=0x03CF
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG25:                ;; offset=0x03D6
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rdi+0x08]
       cmp      esi, r8d
       mov      bword ptr [rbp+0x40], rcx
       ja       SHORT G_M000_IG20
       mov      gword ptr [rsp], r12
       xor      edi, edi
       mov      dword ptr [rsp+0x08], edi
       mov      gword ptr [rsp+0x10], r15
       mov      gword ptr [rsp+0x18], r13
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], r14d
       lea      rdi, bword ptr [rbp-0x128]
       xor      rdx, rdx
       xor      ecx, ecx
       mov      r8, gword ptr [rbp+0x10]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG07
 
G_M000_IG26:                ;; offset=0x0425
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1067

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 11802
; 2 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       sub      rsp, 24
       lea      rbp, [rsp+0x30]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       mov      qword ptr [rbp-0x20], rax
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x001C
       mov      r15, gword ptr [rdi+0x08]
       mov      r14d, dword ptr [r15+0x3C]
       cmp      esi, r14d
       jge      G_M000_IG11
 
G_M000_IG03:                ;; offset=0x002D
       lea      rdx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG19
       mov      rsi, gword ptr [rbp-0x28]
       mov      rdi, 0x7F8241801308
       cmp      rsi, gword ptr [rdi]
       je       SHORT G_M000_IG09
 
G_M000_IG04:                ;; offset=0x0052
       cmp      qword ptr [rbp-0x20], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0059
       mov      rdi, gword ptr [rbp-0x28]
       mov      rsi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x0068
       mov      rsi, gword ptr [rbp-0x28]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0074
       mov      rax, 0x7F91EB644450
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG18
 
G_M000_IG08:                ;; offset=0x0087
       test     rdi, rdi
       je       SHORT G_M000_IG05
       mov      esi, dword ptr [rbp-0x20]
       dec      esi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x009C
       mov      rax, qword ptr [rbp-0x20]
       mov      qword ptr [rbx], rax
       mov      eax, 1
 
G_M000_IG10:                ;; offset=0x00A8
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x00B3
       mov      rax, gword ptr [r15+0x18]
       sub      esi, r14d
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG21
       shl      rsi, 4
       mov      r15d, dword ptr [rax+rsi+0x18]
       cmp      byte  ptr [rdi+0x20], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rdi+0x10]
 
G_M000_IG12:                ;; offset=0x00D6
       mov      rsi, 0x7F8241801308
       cmp      rdi, gword ptr [rsi]
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x00E5
       mov      rsi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG14:                ;; offset=0x00EE
       nop      
 
G_M000_IG15:                ;; offset=0x00EF
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG16:                ;; offset=0x00FA
       xor      eax, eax
       mov      qword ptr [rbx], rax
       mov      eax, 1
       jmp      SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x0106
       mov      rsi, gword ptr [rdi+0x10]
       mov      rdi, 0x7F91EA6427A0
       call     [CORINFO_HELP_CHKCASTARRAY]
       cmp      r15d, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG21
       mov      edi, r15d
       mov      rdi, gword ptr [rax+8*rdi+0x10]
       jmp      SHORT G_M000_IG12
 
G_M000_IG18:                ;; offset=0x012A
       mov      rdi, 0x7F91EB4608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG08
 
G_M000_IG19:                ;; offset=0x0141
       xor      eax, eax
       mov      qword ptr [rbx], rax
 
G_M000_IG20:                ;; offset=0x0146
       add      rsp, 24
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG21:                ;; offset=0x0151
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 343

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 266688
; 8 inlinees with PGO data; 36 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 152
       lea      rbp, [rsp+0xC0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x60], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x50], rax
       mov      dword ptr [rbp-0x2C], r8d
       mov      r12, rdi
       mov      r14, rsi
       mov      rbx, rdx
       mov      r13, rcx
       mov      r15, r9
       mov      r8, gword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0040
       mov      rdi, gword ptr [rbp+0x48]
       mov      gword ptr [rbp-0xA8], rdi
       cmp      dword ptr [rbp+0x38], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0051
       mov      gword ptr [rbp+0x40], r8
       mov      r10, r8
       or       r10, rdi
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x005D
       xor      r10, r10
       mov      rdi, gword ptr [rbp-0xA8]
       mov      r8, gword ptr [rbp+0x40]
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x006D
       mov      rdi, gword ptr [rbp-0xA8]
       mov      r8, gword ptr [rbp+0x40]
 
G_M000_IG06:                ;; offset=0x0078
       mov      r10, gword ptr [r14+0x08]
       test     r10, r10
       je       G_M000_IG43
 
G_M000_IG07:                ;; offset=0x0085
       test     r10, r10
       jne      G_M000_IG42
 
G_M000_IG08:                ;; offset=0x008E
       xor      r11d, r11d
       mov      r9d, 160
 
G_M000_IG09:                ;; offset=0x0097
       mov      qword ptr [rbp-0x48], r9
       mov      qword ptr [rbp-0x38], r9
       cmp      byte  ptr [rbp+0x58], 0
       jne      G_M000_IG44
 
G_M000_IG10:                ;; offset=0x00A9
       cmp      dword ptr [rbp+0x68], 0
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x00AF
       mov      r9, qword ptr [rbp-0x38]
       add      r9, 96
       jo       G_M000_IG46
       mov      qword ptr [rbp-0x38], r9
 
G_M000_IG12:                ;; offset=0x00C1
       mov      r9, gword ptr [r15+0x98]
       mov      r9, gword ptr [r9+0x88]
       mov      gword ptr [rbp-0x70], r9
       test     rdi, rdi
       mov      dword ptr [rbp-0x3C], r11d
       jne      G_M000_IG45
 
G_M000_IG13:                ;; offset=0x00E0
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x40], r8
       mov      rdi, gword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x38]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x40]
       mov      r10, gword ptr [rbp-0x80]
 
G_M000_IG14:                ;; offset=0x0108
       mov      r9, gword ptr [r15+0x98]
       mov      r11, gword ptr [r9+0x88]
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG31
       mov      r11, gword ptr [r9+0x180]
       test     r11, r11
       jne      G_M000_IG30
 
G_M000_IG15:                ;; offset=0x0131
       xor      r9, r9
       cmp      dword ptr [rbp+0x68], 0
       je       G_M000_IG22
 
G_M000_IG16:                ;; offset=0x013E
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x28], rdx
       mov      gword ptr [rbp+0x40], r8
       mov      rdi, 0x7F91EB5DDAB0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
 
G_M000_IG17:                ;; offset=0x015C
       mov      rax, bword ptr [rbp+0x60]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x58], xmm0
 
G_M000_IG18:                ;; offset=0x0169
       mov      rdi, gword ptr [rbp-0x58]
       mov      rcx, 0x7F8241801308
       cmp      rdi, gword ptr [rcx]
       jne      G_M000_IG35
       mov      rdi, gword ptr [r13+0x10]
       mov      rcx, rdi
       test     rcx, rcx
       jne      G_M000_IG33
 
G_M000_IG19:                ;; offset=0x0190
       test     rdi, rdi
       jne      G_M000_IG34
 
G_M000_IG20:                ;; offset=0x0199
       mov      rdi, qword ptr [rbp-0x50]
       mov      qword ptr [rbp-0x60], rdi
       mov      qword ptr [r13+0x20], rdi
       mov      byte  ptr [r13+0x28], 1
       xor      rdi, rdi
       mov      gword ptr [r13+0x08], rdi
 
G_M000_IG21:                ;; offset=0x01B0
       mov      gword ptr [rbp-0x78], r13
       mov      rcx, r13
       mov      r13, rcx
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x40]
       mov      r9, gword ptr [rbp-0x78]
       mov      r10, gword ptr [rbp-0x80]
 
G_M000_IG22:                ;; offset=0x01CA
       cmp      byte  ptr [rbp-0x2C], 0
       jne      G_M000_IG38
       mov      gword ptr [rbp-0x78], r9
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x28], rdx
       mov      gword ptr [rbp+0x40], r8
       mov      rdi, 0x7F91EB5FCE90
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rcx, gword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x98], rcx
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0xA0], rdx
       movzx    r8, byte  ptr [rbp+0x20]
       mov      byte  ptr [rbp-0x64], r8b
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, gword ptr [rbp-0x90]
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbp-0x64]
       mov      byte  ptr [r12+0x20], dil
       lea      rdi, bword ptr [r12+0x40]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x28]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG23:                ;; offset=0x027F
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       mov      rbx, gword ptr [rbp-0x80]
       test     rbx, rbx
       je       SHORT G_M000_IG27
 
G_M000_IG24:                ;; offset=0x0299
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, rdi
       test     rsi, rsi
       jne      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02A8
       mov      r14, gword ptr [rbp+0x40]
       mov      rsi, r14
       test     rsi, rsi
       je       G_M000_IG39
 
G_M000_IG26:                ;; offset=0x02B8
       lea      rdi, bword ptr [r12+0x38]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbp+0x54]
       mov      byte  ptr [r12+0x23], dil
 
G_M000_IG27:                ;; offset=0x02CC
       mov      rsi, gword ptr [rbp-0x70]
       cmp      byte  ptr [rsi], sil
       cmp      qword ptr [rbp-0x38], 0
       jle      SHORT G_M000_IG28
       mov      rdi, qword ptr [rsi+0x28]
       mov      rax, rdi
       cmp      qword ptr [rbp-0x38], rax
       cmovle   rax, qword ptr [rbp-0x38]
       sub      rdi, rax
       mov      qword ptr [rsi+0x28], rdi
       add      rax, qword ptr [rsi+0x30]
       jo       G_M000_IG36
       mov      qword ptr [rsi+0x30], rax
       mov      rsi, gword ptr [rbp-0x70]
 
G_M000_IG28:                ;; offset=0x0303
       mov      r13, gword ptr [rbp-0x78]
       test     r13, r13
       je       G_M000_IG40
 
G_M000_IG29:                ;; offset=0x0310
       mov      byte  ptr [r13+0x29], 1
       cmp      dword ptr [rbp+0x68], 0
       jbe      G_M000_IG37
       mov      rdi, bword ptr [rbp+0x60]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edi, edi
       mov      rbx, bword ptr [rbp+0x60]
       mov      qword ptr [rbx+0x08], rdi
       jmp      G_M000_IG40
 
G_M000_IG30:                ;; offset=0x033A
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x40], r8
       jmp      SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x035A
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x40], r8
 
G_M000_IG32:                ;; offset=0x0362
       mov      rdi, r9
       mov      gword ptr [rbp+0x28], rdx
       mov      rsi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, gword ptr [rbp+0x40]
       mov      r10, gword ptr [rbp-0x80]
       jmp      G_M000_IG15
 
G_M000_IG33:                ;; offset=0x0383
       cmp      byte  ptr [rcx+0x101], 0
       jne      SHORT G_M000_IG35
       jmp      G_M000_IG19
 
G_M000_IG34:                ;; offset=0x0391
       movzx    rdi, byte  ptr [rdi+0xFF]
       test     edi, edi
       je       G_M000_IG20
 
G_M000_IG35:                ;; offset=0x03A1
       lea      rdi, [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rsi, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG21
 
G_M000_IG36:                ;; offset=0x03BC
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG37:                ;; offset=0x03C2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG38:                ;; offset=0x03C8
       mov      gword ptr [rbp-0x78], r9
       mov      gword ptr [rbp-0x80], r10
       mov      gword ptr [rbp+0x28], rdx
       mov      gword ptr [rbp+0x40], r8
       mov      rdi, 0x7F91EB6221E0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       lea      rdi, [rsp]
       lea      rsi, [rbp+0x10]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x08], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rdi, rax
       mov      rsi, r12
       mov      rdx, r14
       mov      rcx, rbx
       mov      r8, r13
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      r12, gword ptr [rbp-0x88]
       jmp      G_M000_IG23
 
G_M000_IG39:                ;; offset=0x0438
       mov      rsi, bword ptr [rbp+0x30]
       mov      edx, dword ptr [rbp+0x38]
       mov      rdi, rbx
       mov      ecx, dword ptr [rbp-0x3C]
       mov      r8, r15
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      rsi, rax
       jmp      G_M000_IG26
 
G_M000_IG40:                ;; offset=0x045A
       mov      rax, r12
 
G_M000_IG41:                ;; offset=0x045D
       add      rsp, 152
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x046F
       mov      gword ptr [rbp+0x40], r8
       mov      gword ptr [rbp-0x80], r10
       mov      edi, dword ptr [r10+0x20]
       call     [Lokad.Lython.Runtime.PyDict:NativeCapacity(int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      r9, rax
       add      r9, 160
       jo       G_M000_IG46
       mov      rax, r9
       mov      rdi, gword ptr [rbp-0xA8]
       mov      r8, gword ptr [rbp+0x40]
       mov      r10, gword ptr [rbp-0x80]
       mov      r11d, dword ptr [rbp-0x3C]
       jmp      G_M000_IG09
 
G_M000_IG43:                ;; offset=0x04B7
       mov      rdi, 0x7F91EAA5C0C0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7F9264DA47A8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG44:                ;; offset=0x04E5
       mov      gword ptr [rbp-0x80], r10
       mov      dword ptr [rbp-0x3C], r11d
       mov      gword ptr [rbp+0x40], r8
       mov      rdi, 0x7F91EB14C988
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdi, qword ptr [rbp-0x48]
       add      rdi, qword ptr [(reloc 0x7f91e941b0c0)]
       jo       SHORT G_M000_IG46
       mov      qword ptr [rbp-0x38], rdi
       mov      rdi, gword ptr [rbp-0xA8]
       mov      r8, gword ptr [rbp+0x40]
       mov      r10, gword ptr [rbp-0x80]
       mov      r11d, dword ptr [rbp-0x3C]
       jmp      G_M000_IG10
 
G_M000_IG45:                ;; offset=0x052A
       mov      rdx, gword ptr [rbp+0x28]
       jmp      G_M000_IG14
 
G_M000_IG46:                ;; offset=0x0533
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG47:                ;; offset=0x0539
       sub      rsp, 24
 
G_M000_IG48:                ;; offset=0x053D
       cmp      gword ptr [rbp-0xA8], 0
       jne      SHORT G_M000_IG49
       mov      rdi, gword ptr [rbp-0x70]
       mov      rsi, qword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG49:                ;; offset=0x0557
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1373

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rbp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 131616
; 1 inlinees with PGO data; 12 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       lea      rbp, [rsp+0x20]
       mov      rbx, rdi
       mov      r15d, esi
 
G_M000_IG02:                ;; offset=0x0013
       mov      r14, gword ptr [rbx+0x08]
       mov      r13d, dword ptr [r14+0x40]
       test     r13d, r13d
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0020
       cmp      byte  ptr [rbx+0x20], 0
       je       SHORT G_M000_IG11
 
G_M000_IG04:                ;; offset=0x0026
       mov      rsi, gword ptr [r14+0x28]
       mov      esi, dword ptr [rsi+0x08]
       sub      esi, dword ptr [r14+0x38]
       cmp      esi, r13d
       jne      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x003A
       mov      r14d, dword ptr [r14+0x3C]
       cmp      r15d, r14d
       jg       G_M000_IG15
       mov      rsi, gword ptr [rbx+0x18]
       mov      rbx, rsi
       test     rbx, rbx
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0053
       mov      rdi, 0x7F91EB644450
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG12
 
G_M000_IG07:                ;; offset=0x0062
       test     rbx, rbx
       je       SHORT G_M000_IG13
 
G_M000_IG08:                ;; offset=0x0067
       mov      rax, gword ptr [rbx+0x08]
       test     rax, rax
       jne      SHORT G_M000_IG14
       mov      ecx, 1
 
G_M000_IG09:                ;; offset=0x0075
       sub      r14d, ecx
       cmp      r14d, r15d
       setle    al
       movzx    rax, al
 
G_M000_IG10:                ;; offset=0x0081
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG11:                ;; offset=0x008A
       mov      rsi, gword ptr [rbx+0x10]
       mov      rdi, 0x7F91EA6427A0
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG15
       jmp      SHORT G_M000_IG04
 
G_M000_IG12:                ;; offset=0x00A4
       mov      rdi, 0x7F91EB4608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG13:                ;; offset=0x00B8
       xor      ecx, ecx
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x00BC
       mov      ecx, dword ptr [rax+0x08]
       test     ecx, ecx
       jl       SHORT G_M000_IG17
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x00C5
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x00C7
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x00D0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 214

