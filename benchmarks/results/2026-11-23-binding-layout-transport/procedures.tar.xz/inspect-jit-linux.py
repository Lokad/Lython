from pathlib import Path
import subprocess

lab=Path(__file__).resolve().parent
ln="/mnt/d/"+lab.relative_to(lab.anchor).as_posix()
dotnet="/home/vermorel/.dotnet/dotnet"
for role in ("reference","candidate"):
    image=ln+"/"+role
    suffix=ln+"/"+role
    with (lab/(role+"-linux-binding.log")).open("wb") as output:
        subprocess.run(["wsl.exe","--exec","env","DOTNET_ROOT=/home/vermorel/.dotnet",
            "DOTNET_JitDisasm=StartNativeCall TrySelectNativeCall HasPreparedOmittedArguments TryReadPreparedDefaultInteger CreateFunctionValue",
            "DOTNET_JitStdOutFile="+suffix+"-linux-binding.asm",dotnet,
            image+"/ValidatedAllocation.dll",image,ln+"/comparison/representative.json",suffix+"-linux-allocation.json"],
            check=True,stdout=output,stderr=subprocess.STDOUT,timeout=65)
