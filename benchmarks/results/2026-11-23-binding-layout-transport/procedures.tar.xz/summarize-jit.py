from pathlib import Path
import re,json
lab=Path(Path(__file__).resolve().parent)
roles={}
for role in ("reference","candidate"):
    stats=[]
    for entry in (lab/(role+"-binding.asm")).read_text(encoding="utf-8-sig").split("; Assembly listing for method ")[1:]:
        signature,body=entry.split("\n",1)
        if not signature.endswith(" (Tier1)"): continue
        name=signature.split(":",1)[1].split("(",1)[0]
        size=re.search(r"Total bytes of code (\d+)",body)
        stack=re.search(r"\bsub\s+rsp,\s*(0x[\da-fA-F]+|\d+)",body)
        getter=len(re.findall(r"(?:call|jmp).*get_ParameterLayout",body))
        indirect=len(re.findall(r"(?:call|jmp)\s+\[(?:r\w+)[^\]]*\]",body))
        stats.append(dict(name=name,codeBytes=int(size[1]),stackSubtraction=int(stack[1],0) if stack else 0,
            namedLayoutCalls=getter,indirectCalls=indirect))
    roles[role]=stats
    print(role,stats)
(lab/"jit-summary.json").write_text(json.dumps(roles,indent=2)+"\n",encoding="utf-8",newline="\n")
