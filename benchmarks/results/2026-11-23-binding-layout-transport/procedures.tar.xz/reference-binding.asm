; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG36:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG36
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, bword ptr [rbp+0x50]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG03
       cmp      gword ptr [rbp+0x58], 0
       jne      SHORT G_M000_IG03
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0064
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FFA02CDC4F8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0094
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG05:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       jne      SHORT G_M000_IG06
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00B0
       mov      rcx, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG07:                ;; offset=0x00BD
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x0C], eax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG08
       mov      ecx, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00D9
       mov      qword ptr [rbp-0x58], 160
 
G_M000_IG09:                ;; offset=0x00E1
       mov      rax, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x18], rax
       movzx    rax, byte  ptr [rbp+0x68]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7ffa0253b0d8)]
       add      rax, qword ptr [rbp-0x18]
       jo       G_M000_IG31
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG10:                ;; offset=0x0116
       mov      rcx, bword ptr [rbp+0x70]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG11
       mov      rax, qword ptr [rbp-0x18]
       add      rax, 96
       jo       G_M000_IG31
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG11:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG12
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG12:                ;; offset=0x0164
       nop      
 
G_M000_IG13:                ;; offset=0x0165
       mov      rcx, gword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, bword ptr [rbp+0x70]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG16
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rax, bword ptr [rbp+0x70]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG19
       mov      rax, bword ptr [rbp+0x70]
       mov      rax, bword ptr [rax]
 
G_M000_IG14:                ;; offset=0x01B4
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG15:                ;; offset=0x01C0
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp+0x28], rax
 
G_M000_IG16:                ;; offset=0x01EA
       movzx    rax, byte  ptr [rbp+0x38]
       test     eax, eax
       jne      SHORT G_M000_IG20
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG17:                ;; offset=0x0215
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xB8], rcx
 
G_M000_IG18:                ;; offset=0x022C
       lea      rax, [rbp-0xC8]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x68], rax
       jmp      SHORT G_M000_IG23
 
G_M000_IG19:                ;; offset=0x025E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x0264
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG21:                ;; offset=0x027B
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xD0], rcx
 
G_M000_IG22:                ;; offset=0x0292
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x68], rax
 
G_M000_IG23:                ;; offset=0x02C5
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x60]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG26
       mov      rax, gword ptr [rbp+0x58]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      SHORT G_M000_IG26
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG24:                ;; offset=0x0327
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG25:                ;; offset=0x0333
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG26:                ;; offset=0x035B
       mov      rax, bword ptr [rbp+0x60]
       movzx    r9, byte  ptr [rax+0x0C]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r8, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG27:                ;; offset=0x0378
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG28
       mov      rax, gword ptr [rbp-0x28]
       mov      byte  ptr [rax+0x29], 1
       mov      rax, bword ptr [rbp+0x70]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG19
       mov      rax, bword ptr [rbp+0x70]
       mov      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG28:                ;; offset=0x03B6
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG29:                ;; offset=0x03BE
       mov      rax, gword ptr [rbp-0x40]
 
G_M000_IG30:                ;; offset=0x03C2
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03CB
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG32:                ;; offset=0x03D1
       sub      rsp, 56
 
G_M000_IG33:                ;; offset=0x03D5
       mov      gword ptr [rbp-0x98], rcx
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x03E6
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG35:                ;; offset=0x03F6
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1020

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 80
       lea      rbp, [rsp+0x50]
       xor      eax, eax
       mov      qword ptr [rbp-0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0029
       mov      rax, bword ptr [rbp+0x28]
       mov      byte  ptr [rax], 0
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x0040
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0046
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x18], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x2C], eax
       mov      edx, dword ptr [rbp-0x2C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x24], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008B
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x24], eax
 
G_M000_IG06:                ;; offset=0x0098
       mov      rax, bword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp+0x28]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00B1
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00B7
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      SHORT G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG09
       mov      rdx, gword ptr [rbp-0x08]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG09:                ;; offset=0x0118
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x10], rax
       cmp      gword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG10
       mov      rcx, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x28], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0146
       xor      eax, eax
       mov      dword ptr [rbp-0x28], eax
 
G_M000_IG11:                ;; offset=0x014B
       cmp      dword ptr [rbp-0x28], 0
       sete     al
       movzx    rax, al
 
G_M000_IG12:                ;; offset=0x0155
       add      rsp, 80
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x015B
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x015D
       add      rsp, 80
       pop      rbp
       ret      
 
; Total bytes of code 355

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG32:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG32
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       G_M000_IG13
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0079
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0085
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG11
 
G_M000_IG05:                ;; offset=0x00BB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG10
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG06:                ;; offset=0x00E9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG07:                ;; offset=0x00F5
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG08:                ;; offset=0x0109
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG09:                ;; offset=0x0119
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x013A
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG11:                ;; offset=0x0142
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG12:                ;; offset=0x015B
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0167
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG17
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG14
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG31
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG14:                ;; offset=0x0257
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG15:                ;; offset=0x0272
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG16:                ;; offset=0x0282
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG23
 
G_M000_IG17:                ;; offset=0x0298
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG18:                ;; offset=0x02D2
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG19:                ;; offset=0x02E2
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG20:                ;; offset=0x02F2
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG21:                ;; offset=0x0317
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG22:                ;; offset=0x0323
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG23:                ;; offset=0x034B
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG24:                ;; offset=0x035B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG25:                ;; offset=0x0367
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG26:                ;; offset=0x0377
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG27:                ;; offset=0x0387
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG28:                ;; offset=0x0393
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG29:                ;; offset=0x039F
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG30:                ;; offset=0x03EF
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03FB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1025

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqa  xmmword ptr [rbp-0x20], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
 
G_M000_IG02:                ;; offset=0x0025
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x10]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0060
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x30]
       sub      ecx, eax
       mov      dword ptr [rbp-0x34], ecx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      G_M000_IG08
 
G_M000_IG04:                ;; offset=0x00A1
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG08
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x40], rax
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x10], rax
       mov      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x14], eax
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x18], eax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x10], 0
       jne      SHORT G_M000_IG05
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0115
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       mov      rcx, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG06:                ;; offset=0x012E
       mov      eax, dword ptr [rbp-0x28]
       sub      eax, dword ptr [rbp-0x2C]
       cmp      dword ptr [rbp-0x24], eax
       setge    al
       movzx    rax, al
 
G_M000_IG07:                ;; offset=0x013D
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0143
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0145
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 331

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 112
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x0029
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jg       G_M000_IG06
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp+0x18]
       sub      ecx, eax
       mov      dword ptr [rbp-0x4C], ecx
       mov      r8d, dword ptr [rbp-0x4C]
       lea      rdx, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x14], eax
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x10]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x14]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG10
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00B7
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG04:                ;; offset=0x00C3
       lea      rcx, [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      rcx, [rbp-0x38]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x00E0
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00E6
       lea      r8, [rbp-0x10]
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       lea      rcx, [rbp-0x10]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x010A
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0110
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x011B
       add      rsp, 112
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0121
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 295

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0028
       mov      rax, bword ptr [rbp+0x28]
       mov      byte  ptr [rax], 0
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_CanStartInline():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FFA02D86B50
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x004E
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0054
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x18], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x34], eax
       mov      edx, dword ptr [rbp-0x34]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.PyFunctionBase:HasCompletePositionalSupply(int,System.Object):bool:this]
       mov      dword ptr [rbp-0x24], eax
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0099
       mov      rcx, 0x7FFA02D86B54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x18]
       mov      bword ptr [rbp-0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x24], eax
 
G_M000_IG06:                ;; offset=0x00B5
       mov      rax, bword ptr [rbp-0x20]
       mov      ecx, dword ptr [rbp-0x24]
       mov      byte  ptr [rax], cl
       mov      rax, bword ptr [rbp+0x28]
       movzx    rax, byte  ptr [rax]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rcx, 0x7FFA02D86B58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG07:                ;; offset=0x00DD
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       cmp      eax, 16
       jg       G_M000_IG17
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicListIndex():int:this]
       test     eax, eax
       jge      G_M000_IG13
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_VariadicDictionaryIndex():int:this]
       test     eax, eax
       jge      G_M000_IG12
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG10
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp-0x30]
       mov      rdx, 0x7FFA02D86B60
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
       mov      rdx, gword ptr [rbp-0x40]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x016B
       mov      rcx, 0x7FFA02D86C68
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG10:                ;; offset=0x017A
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x10], rax
       cmp      gword ptr [rbp-0x10], 0
       je       SHORT G_M000_IG14
       mov      rcx, gword ptr [rbp-0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x28], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x01A8
       mov      rcx, 0x7FFA02D86C6C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x01B9
       mov      rcx, 0x7FFA02D86C70
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG13:                ;; offset=0x01CA
       mov      rcx, 0x7FFA02D86C74
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG14:                ;; offset=0x01DB
       mov      rcx, 0x7FFA02D86C78
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x28], eax
 
G_M000_IG15:                ;; offset=0x01EF
       mov      rcx, 0x7FFA02D86C7C
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      dword ptr [rbp-0x28], 0
       sete     al
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x0208
       add      rsp, 96
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x020E
       mov      rcx, 0x7FFA02D86C80
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x021F
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 704
       lea      rbp, [rsp+0x2C0]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG35:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG35
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       cmp      gword ptr [rbp+0x28], 0
       jne      G_M000_IG15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_HasDirectIntegerReturn():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG03:                ;; offset=0x0075
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG04:                ;; offset=0x0081
       mov      rax, gword ptr [rbp+0x38]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x1C0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, gword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartPreparedIntegerReturn(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      G_M000_IG12
 
G_M000_IG05:                ;; offset=0x00B7
       mov      rcx, 0x7FFA02D86FD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00CB
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x198], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x198]
       jne      SHORT G_M000_IG11
       mov      rcx, 0x7FFA02D86FDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG07:                ;; offset=0x0108
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1D0], xmm0
 
G_M000_IG08:                ;; offset=0x0114
       lea      rdx, [rbp-0x1D0]
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands:.ctor(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
 
G_M000_IG09:                ;; offset=0x0128
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
 
G_M000_IG10:                ;; offset=0x0138
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, bword ptr [rbp+0x60]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      dword ptr [rbp-0x19C], eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0159
       mov      rcx, 0x7FFA02D86FE0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x19C], eax
 
G_M000_IG12:                ;; offset=0x0170
       cmp      dword ptr [rbp-0x19C], 0
       je       SHORT G_M000_IG14
       mov      rcx, 0x7FFA02D86FE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x58]
       mov      byte  ptr [rax], 0
       mov      rax, bword ptr [rbp+0x68]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
 
G_M000_IG13:                ;; offset=0x0198
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x01A4
       mov      rcx, 0x7FFA02D86FE8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x01B3
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  ymmword ptr [rbp-0xE0], ymm0
       vmovdqu  ymmword ptr [rbp-0xC0], ymm0
       vmovdqu  ymmword ptr [rbp-0xA0], ymm0
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  ymmword ptr [rbp-0x40], ymm0
       vmovdqu  ymmword ptr [rbp-0x20], ymm0
       lea      rdx, [rbp-0x100]
       lea      rcx, [rbp-0x110]
       mov      r8d, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](byref,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_CodeObject():Lokad.Lython.Frontend.ExecutableCodeObject:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       mov      r9d, dword ptr [rbp-0x1E4]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x110]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       movzx    rax, byte  ptr [rbp+0x48]
       test     eax, eax
       je       G_M000_IG19
       xor      eax, eax
       mov      dword ptr [rbp-0x114], eax
       cmp      gword ptr [rbp+0x28], 0
       je       SHORT G_M000_IG16
       mov      rcx, 0x7FFA02D86FEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x114]
       mov      dword ptr [rbp-0x194], eax
       mov      eax, dword ptr [rbp-0x114]
       inc      eax
       mov      dword ptr [rbp-0x114], eax
       mov      eax, dword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x194], eax
       jae      G_M000_IG34
       mov      eax, dword ptr [rbp-0x194]
       shl      rax, 4
       mov      rcx, rax
       add      rcx, bword ptr [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG16:                ;; offset=0x02B2
       lea      rdx, [rbp-0x190]
       lea      rcx, [rbp-0x110]
       mov      r8d, dword ptr [rbp-0x114]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG17:                ;; offset=0x02CD
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x1F8], xmm0
 
G_M000_IG18:                ;; offset=0x02DD
       lea      rdx, [rbp-0x1F8]
       mov      rcx, bword ptr [rbp+0x20]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:CopyTo(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):this]
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x02F3
       mov      rcx, 0x7FFA02D86FF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      r9d, dword ptr [rbp-0x1FC]
       lea      rcx, [rbp-0x110]
       lea      rdx, [rbp-0x170]
       xor      r8d, r8d
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG20:                ;; offset=0x033C
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0x210], xmm0
 
G_M000_IG21:                ;; offset=0x034C
       vmovdqu  xmm0, xmmword ptr [rbp-0x128]
       vmovdqu  xmmword ptr [rbp-0x220], xmm0
 
G_M000_IG22:                ;; offset=0x035C
       mov      rax, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x30], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG23:                ;; offset=0x0381
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x230], xmm0
 
G_M000_IG24:                ;; offset=0x038D
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x220]
       lea      rax, [rbp-0x230]
       mov      qword ptr [rsp+0x40], rax
       mov      r9, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG25:                ;; offset=0x03B5
       mov      rcx, 0x7FFA02D86FF4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG26:                ;; offset=0x03C4
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x180], xmm0
 
G_M000_IG27:                ;; offset=0x03D4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
 
G_M000_IG28:                ;; offset=0x03E0
       vmovdqu  xmm0, xmmword ptr [rbp-0x180]
       vmovdqu  xmmword ptr [rbp-0x240], xmm0
 
G_M000_IG29:                ;; offset=0x03F0
       vmovdqu  ymm0, ymmword ptr [rbp-0x160]
       vmovdqu  ymmword ptr [rbp-0x260], ymm0
 
G_M000_IG30:                ;; offset=0x0400
       movzx    rax, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG31:                ;; offset=0x040C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG32:                ;; offset=0x0418
       mov      rax, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rax
       mov      rax, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rax
       lea      rax, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rax
       lea      rdx, [rbp-0x240]
       lea      r8, [rbp-0x260]
       lea      rax, [rbp-0x270]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp+0x38]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG33:                ;; offset=0x0468
       vzeroupper 
       add      rsp, 704
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x0474
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1146

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 288
       lea      rbp, [rsp+0x120]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG39:                ;; offset=0x001E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG39
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      gword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0045
       mov      rcx, bword ptr [rbp+0x50]
       call     [System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG04
       cmp      gword ptr [rbp+0x58], 0
       jne      SHORT G_M000_IG05
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0064
       mov      rcx, 0x7FFA02D87AA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x0073
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_DefinitionAnnotationKeys():Lokad.Lython.Runtime.PyDict+RecordKeys:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FFA02CDC4F8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00A3
       mov      rcx, 0x7FFA02D87AAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG04
 
G_M000_IG06:                ;; offset=0x00B4
       mov      rcx, 0x7FFA02D87AB0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG07:                ;; offset=0x00C9
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x08], rax
       cmp      gword ptr [rbp-0x08], 0
       jne      SHORT G_M000_IG08
       xor      eax, eax
       mov      dword ptr [rbp-0x4C], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00DF
       mov      rcx, 0x7FFA02D87AB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:get_PreparedValueCapacity():int:this]
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG09:                ;; offset=0x00FB
       mov      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x0C], eax
       cmp      gword ptr [rbp-0x08], 0
       je       SHORT G_M000_IG10
       mov      ecx, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:FunctionAndAnnotationBytes(int):long]
       mov      qword ptr [rbp-0x58], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0117
       mov      rcx, 0x7FFA02D87AB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      qword ptr [rbp-0x58], 160
 
G_M000_IG11:                ;; offset=0x012E
       mov      rax, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x18], rax
       movzx    rax, byte  ptr [rbp+0x68]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rcx, 0x7FFA02D87ABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rax, qword ptr [(reloc 0x7ffa0253b0d8)]
       add      rax, qword ptr [rbp-0x18]
       jo       G_M000_IG34
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG12:                ;; offset=0x0172
       mov      rcx, bword ptr [rbp+0x70]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rcx, 0x7FFA02D87AC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x18]
       add      rax, 96
       jo       G_M000_IG34
       mov      qword ptr [rbp-0x18], rax
 
G_M000_IG13:                ;; offset=0x01A1
       mov      rcx, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x20], rax
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG14
       mov      rcx, 0x7FFA02D87AC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       mov      r8, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG14:                ;; offset=0x01DE
       nop      
 
G_M000_IG15:                ;; offset=0x01DF
       mov      rcx, gword ptr [rbp+0x40]
       mov      rdx, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       xor      rax, rax
       mov      gword ptr [rbp-0x28], rax
       mov      rcx, bword ptr [rbp+0x70]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FFA02D87AC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      rax, bword ptr [rbp+0x70]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG31
       mov      rax, bword ptr [rbp+0x70]
       mov      rax, bword ptr [rax]
 
G_M000_IG16:                ;; offset=0x023D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG17:                ;; offset=0x0249
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:.ctor(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp+0x28], rax
 
G_M000_IG18:                ;; offset=0x0273
       movzx    rax, byte  ptr [rbp+0x38]
       test     eax, eax
       jne      SHORT G_M000_IG21
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x88], rax
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x20], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG19:                ;; offset=0x029E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xB8], rcx
 
G_M000_IG20:                ;; offset=0x02B5
       lea      rax, [rbp-0xC8]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults):this]
       mov      rax, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x68], rax
       jmp      SHORT G_M000_IG24
 
G_M000_IG21:                ;; offset=0x02E7
       mov      rcx, 0x7FFA02D87ACC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG22:                ;; offset=0x030D
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0xD0], rcx
 
G_M000_IG23:                ;; offset=0x0324
       mov      rax, gword ptr [rbp+0x28]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xE0]
       mov      qword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x68], rax
 
G_M000_IG24:                ;; offset=0x0357
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x30], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x20]
       mov      r8, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       cmp      gword ptr [rbp-0x08], 0
       je       G_M000_IG28
       mov      rax, bword ptr [rbp+0x60]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG27
       mov      rax, gword ptr [rbp+0x58]
       mov      gword ptr [rbp-0x38], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x38], 0
       jne      G_M000_IG30
       mov      rcx, 0x7FFA02D87AD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x50]
 
G_M000_IG25:                ;; offset=0x03CC
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG26:                ;; offset=0x03D8
       mov      rax, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG27:                ;; offset=0x0400
       mov      rcx, 0x7FFA02D87AD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x60]
       movzx    r9, byte  ptr [rax+0x0C]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, gword ptr [rbp-0x80]
       mov      r8, gword ptr [rbp+0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyFunctionBase:AttachAdmittedAnnotations(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):this]
 
G_M000_IG28:                ;; offset=0x042C
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Commit(long):this]
       cmp      gword ptr [rbp-0x28], 0
       je       SHORT G_M000_IG29
       mov      rcx, 0x7FFA02D87AD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      byte  ptr [rax+0x29], 1
       mov      rax, bword ptr [rbp+0x70]
       cmp      dword ptr [rax+0x08], 0
       jbe      SHORT G_M000_IG31
       mov      rax, bword ptr [rbp+0x70]
       mov      rcx, bword ptr [rax]
       mov      rdx, gword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
 
G_M000_IG29:                ;; offset=0x0475
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0x40], rax
       jmp      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x047F
       mov      rcx, 0x7FFA02D87ADC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG27
 
G_M000_IG31:                ;; offset=0x0493
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x0499
       mov      rcx, 0x7FFA02D87AE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
 
G_M000_IG33:                ;; offset=0x04AC
       add      rsp, 288
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x04B5
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG35:                ;; offset=0x04BB
       sub      rsp, 56
 
G_M000_IG36:                ;; offset=0x04BF
       mov      gword ptr [rbp-0x98], rcx
       mov      rax, bword ptr [rbp+0x60]
       cmp      gword ptr [rax], 0
       jne      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x04D0
       mov      rcx, 0x7FFA02D87AE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x20]
       mov      rdx, qword ptr [rbp-0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG38:                ;; offset=0x04EF
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1269

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       vmovdqu  ymmword ptr [rbp-0x40], ymm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      bword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x002E
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jg       G_M000_IG06
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      ecx, dword ptr [rbp+0x18]
       sub      ecx, eax
       mov      dword ptr [rbp-0x54], ecx
       mov      r8d, dword ptr [rbp-0x54]
       lea      rdx, [rbp-0x28]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:KeywordDefaultAt(int):Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:this]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Frontend.FunctionParameterLayout+KeywordDefault:get_RecordPosition():int:this]
       mov      dword ptr [rbp-0x14], eax
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG03
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x50], rax
       mov      rcx, gword ptr [rbp-0x50]
       mov      rdx, 0x7FFA02D88528
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x60], rax
       mov      rdx, gword ptr [rbp-0x60]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      ecx, dword ptr [rbp-0x14]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG10
       mov      edx, ecx
       lea      rax, bword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x48], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00E3
       mov      rcx, 0x7FFA02D88630
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x48], rax
 
G_M000_IG04:                ;; offset=0x00FE
       mov      rcx, 0x7FFA02D88634
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x38]
       mov      rdx, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      rcx, [rbp-0x38]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG05:                ;; offset=0x012A
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0133
       lea      r8, [rbp-0x10]
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rcx, 0x7FFA02D88638
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x10]
       mov      rdx, bword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
       nop      
 
G_M000_IG07:                ;; offset=0x0166
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x016F
       mov      rcx, 0x7FFA02D8863C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0189
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x0192
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 408

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 128
       lea      rbp, [rsp+0x80]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       mov      qword ptr [rbp-0x10], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
 
G_M000_IG02:                ;; offset=0x002F
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       test     eax, eax
       je       G_M000_IG06
       mov      rax, gword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x20]
       test     eax, eax
       jne      SHORT G_M000_IG04
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x40], rax
       mov      rcx, gword ptr [rbp-0x40]
       mov      rdx, 0x7FFA02D895D8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x50], rax
       mov      rdx, gword ptr [rbp-0x50]
       mov      rcx, 0x7FFA026028A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0091
       mov      rcx, 0x7FFA02D896E0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00A0
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_Defaults():Lokad.Lython.Frontend.FunctionParameterLayout+DefaultSlot[]:this]
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_PositionalDefaultCount():int:this]
       mov      ecx, dword ptr [rbp-0x30]
       sub      ecx, eax
       mov      dword ptr [rbp-0x34], ecx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordOnlyCount():int:this]
       cmp      eax, dword ptr [rbp-0x34]
       jne      G_M000_IG07
 
G_M000_IG05:                ;; offset=0x00E1
       mov      rcx, 0x7FFA02D896E4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x00F0
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       cmp      eax, dword ptr [rbp+0x18]
       jl       G_M000_IG12
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalCount():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_PositionalDefaults():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x48]
       mov      rdx, 0x7FFA02D896E8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x58], rax
       mov      rdx, gword ptr [rbp-0x58]
       mov      rcx, 0x7FFA02C41128
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x10], rax
       mov      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x14], eax
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x18], eax
       mov      rax, gword ptr [rbp-0x10]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x10], 0
       jne      SHORT G_M000_IG09
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x017F
       mov      rcx, 0x7FFA02D897F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x0190
       mov      rcx, 0x7FFA02D897F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x01A1
       mov      rcx, 0x7FFA02D897F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x14]
       mov      dword ptr [rbp-0x24], eax
       mov      eax, dword ptr [rbp-0x18]
       mov      dword ptr [rbp-0x28], eax
       mov      rcx, gword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.PyTuple:get_Count():int:this]
       mov      dword ptr [rbp-0x2C], eax
 
G_M000_IG10:                ;; offset=0x01C9
       mov      rcx, 0x7FFA02D897FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x28]
       sub      eax, dword ptr [rbp-0x2C]
       cmp      dword ptr [rbp-0x24], eax
       setge    al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x01E7
       add      rsp, 128
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x01F0
       mov      rcx, 0x7FFA02D89800
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x0201
       add      rsp, 128
       pop      rbp
       ret      
 
; Total bytes of code 522

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rsp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 26076
; 3 inlinees with PGO data; 25 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbx
       sub      rsp, 32
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0008
       mov      byte  ptr [r9], 0
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xDF], 0
       je       G_M000_IG12
       mov      rax, gword ptr [rbx+0x28]
       cmp      byte  ptr [rax+0xFA], 0
       jne      G_M000_IG12
       cmp      byte  ptr [rax+0xFB], 0
       jne      G_M000_IG12
       cmp      byte  ptr [rax+0xFC], 0
       jne      G_M000_IG12
       cmp      gword ptr [rax+0xC0], 0
       jne      G_M000_IG12
       cmp      dword ptr [rcx+0xD4], 16
       jg       G_M000_IG12
       cmp      byte  ptr [rdx+0x34], 0
       je       G_M000_IG14
       mov      edx, dword ptr [rdx+0x28]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      byte  ptr [rcx+0x54], 0
       je       SHORT G_M000_IG11
 
G_M000_IG03:                ;; offset=0x007A
       mov      ecx, dword ptr [rcx+0x3C]
       test     r8, r8
       setne    al
       movzx    rax, al
       sub      ecx, eax
       cmp      ecx, edx
       sete     dl
       movzx    rdx, dl
 
G_M000_IG04:                ;; offset=0x0090
       mov      byte  ptr [r9], dl
       cmp      byte  ptr [r9], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x0099
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rdx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jg       SHORT G_M000_IG12
       cmp      dword ptr [rdx+0x4C], 0
       jge      SHORT G_M000_IG12
       cmp      dword ptr [rdx+0x50], 0
       jge      SHORT G_M000_IG12
       mov      rdx, gword ptr [rbx+0x18]
       test     rdx, rdx
       je       SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x00BC
       mov      rax, rdx
       mov      rcx, 0x7FFA02CEEAC0
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG15
 
G_M000_IG07:                ;; offset=0x00CE
       test     rax, rax
       je       SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x00D3
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       test     rax, rax
       jne      SHORT G_M000_IG16
 
G_M000_IG09:                ;; offset=0x00E1
       mov      eax, 1
 
G_M000_IG10:                ;; offset=0x00E6
       add      rsp, 32
       pop      rbx
       ret      
 
G_M000_IG11:                ;; offset=0x00EC
       xor      edx, edx
       jmp      SHORT G_M000_IG04
 
G_M000_IG12:                ;; offset=0x00F0
       xor      eax, eax
 
G_M000_IG13:                ;; offset=0x00F2
       add      rsp, 32
       pop      rbx
       ret      
 
G_M000_IG14:                ;; offset=0x00F8
       xor      edx, edx
       jmp      SHORT G_M000_IG04
 
G_M000_IG15:                ;; offset=0x00FC
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      SHORT G_M000_IG07
 
G_M000_IG16:                ;; offset=0x010D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyDict:get_SupportsNativeStringReads():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG09
       jmp      SHORT G_M000_IG12
 
; Total bytes of code 284

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 27880
; 7 inlinees with PGO data; 24 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 504
       lea      rbp, [rsp+0x230]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG23:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG23
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r15, bword ptr [rbp+0x50]
       mov      r14, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x005E
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x006A
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xE0], 0
       jne      G_M000_IG09
 
G_M000_IG04:                ;; offset=0x007B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      eax, dword ptr [rcx+0xD4]
       mov      dword ptr [rbp-0x18C], eax
       cmp      eax, 16
       ja       G_M000_IG15
       cmp      byte  ptr [rbp+0x48], 0
       je       G_M000_IG20
       xor      ecx, ecx
       test     rsi, rsi
       jne      G_M000_IG16
 
G_M000_IG05:                ;; offset=0x00E7
       cmp      ecx, eax
       ja       G_M000_IG15
       lea      rdx, bword ptr [rbp-0x138]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, eax
       sub      edx, ecx
       cmp      r12d, edx
       ja       G_M000_IG19
       mov      ecx, r12d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       G_M000_IG18
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa62542aa8)], 0
       jne      G_M000_IG17
 
G_M000_IG06:                ;; offset=0x013F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      esi, dword ptr [rbp-0x18C]
       mov      dword ptr [rbp-0x1A8], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], r15
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r14
       mov      r14, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], r14
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B0]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
 
G_M000_IG07:                ;; offset=0x01B0
       nop      
 
G_M000_IG08:                ;; offset=0x01B1
       add      rsp, 504
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x01C5
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG14
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG12
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xC4]
       jne      SHORT G_M000_IG12
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG12
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0x98]
       mov      gword ptr [rbp-0x1D8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x022A
       mov      gword ptr [rbp-0x188], rbx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG11:                ;; offset=0x0256
       test     eax, eax
       je       G_M000_IG04
       mov      r14, bword ptr [rbp+0x58]
       mov      byte  ptr [r14], 0
       xor      rcx, rcx
       mov      r14, bword ptr [rbp+0x68]
       mov      gword ptr [r14], rcx
       jmp      G_M000_IG07
 
G_M000_IG12:                ;; offset=0x0274
       xor      edx, edx
       mov      eax, edx
       jmp      SHORT G_M000_IG11
 
G_M000_IG13:                ;; offset=0x027A
       mov      rcx, gword ptr [rbp-0x1D8]
       mov      rdx, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      SHORT G_M000_IG10
 
G_M000_IG14:                ;; offset=0x028D
       mov      rdx, gword ptr [rbx+0x40]
       cmp      r12d, dword ptr [rdx+0xC4]
       jne      G_M000_IG04
       mov      bword ptr [rbp-0x1A0], r13
       mov      dword ptr [rbp-0x198], r12d
       lea      rdx, [rbp-0x1A0]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp+0x38]
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG11
 
G_M000_IG15:                ;; offset=0x02C5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG16:                ;; offset=0x02CC
       mov      ecx, 1
       test     eax, eax
       je       G_M000_IG22
       mov      gword ptr [rbp-0x138], rsi
       xor      edx, edx
       mov      qword ptr [rbp-0x130], rdx
       jmp      G_M000_IG05
 
G_M000_IG17:                ;; offset=0x02EE
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG06
 
G_M000_IG18:                ;; offset=0x02F8
       mov      rcx, r8
       mov      rdx, r13
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG06
 
G_M000_IG19:                ;; offset=0x030C
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG20:                ;; offset=0x0313
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, eax
       ja       SHORT G_M000_IG15
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B0], rdx
       mov      dword ptr [rbp-0x1A8], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C0], rcx
 
G_M000_IG21:                ;; offset=0x033F
       mov      dword ptr [rbp-0x1B8], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D0], r13
       mov      dword ptr [rbp-0x1C8], r12d
       lea      rcx, [rbp-0x1B0]
       lea      rdx, [rbp-0x1C0]
       lea      r9, [rbp-0x1D0]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, gword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x0398
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 926

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 36280
; 8 inlinees with PGO data; 36 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  xmmword ptr [rbp-0x68], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       mov      r15, rcx
       mov      rdi, rdx
       mov      rbx, r8
       mov      r14, r9
       mov      rsi, bword ptr [rbp+0x30]
       mov      r13, gword ptr [rbp+0x40]
       mov      r12, bword ptr [rbp+0x50]
       mov      r8, gword ptr [rbp+0x58]
       mov      rcx, bword ptr [rbp+0x60]
       mov      rax, bword ptr [rbp+0x70]
 
G_M000_IG02:                ;; offset=0x004E
       mov      r9, bword ptr [rax]
       mov      bword ptr [rbp-0xA8], r9
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x70], eax
       mov      r11, gword ptr [rcx]
       mov      gword ptr [rbp-0xA0], r11
       movzx    rcx, byte  ptr [rcx+0x0C]
       mov      byte  ptr [rbp-0x6C], cl
       cmp      dword ptr [r12+0x08], 0
       jne      G_M000_IG40
 
G_M000_IG03:                ;; offset=0x007B
       mov      gword ptr [rbp+0x58], r8
       mov      r10, r8
       or       r10, r11
       jne      G_M000_IG39
 
G_M000_IG04:                ;; offset=0x008B
       xor      r10, r10
 
G_M000_IG05:                ;; offset=0x008E
       test     r10, r10
       je       G_M000_IG41
 
G_M000_IG06:                ;; offset=0x0097
       mov      gword ptr [rbp-0x88], r10
       mov      ecx, dword ptr [r10+0x20]
       call     [Lokad.Lython.Runtime.PyDict:NativeCapacity(int):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       add      rax, 160
       jo       G_M000_IG44
 
G_M000_IG07:                ;; offset=0x00BF
       mov      qword ptr [rbp-0x50], rax
       mov      qword ptr [rbp-0x40], rax
       cmp      byte  ptr [rbp+0x68], 0
       jne      G_M000_IG43
 
G_M000_IG08:                ;; offset=0x00D1
       cmp      dword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00D7
       mov      r8, qword ptr [rbp-0x40]
       add      r8, 96
       jo       G_M000_IG44
       mov      qword ptr [rbp-0x40], r8
 
G_M000_IG10:                ;; offset=0x00E9
       mov      r8, gword ptr [r13+0x98]
       mov      r8, gword ptr [r8+0x88]
       mov      gword ptr [rbp-0x78], r8
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0105
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, qword ptr [rbp-0x40]
       mov      r8, gword ptr [rbp+0x48]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Reserve(long,Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG12:                ;; offset=0x011A
       mov      r8, gword ptr [r13+0x98]
       mov      rcx, gword ptr [r8+0x88]
       cmp      gword ptr [rcx+0x20], 0
       jne      G_M000_IG29
       mov      rcx, gword ptr [r8+0x180]
       test     rcx, rcx
       jne      G_M000_IG28
 
G_M000_IG13:                ;; offset=0x0143
       xor      r8, r8
       cmp      dword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG20
 
G_M000_IG14:                ;; offset=0x014C
       mov      rcx, 0x7FFA02C97DA0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
 
G_M000_IG15:                ;; offset=0x015E
       mov      rax, bword ptr [rbp-0xA8]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG16:                ;; offset=0x016E
       mov      rcx, gword ptr [rbp-0x60]
       mov      rdx, 0x1C447001C18
       cmp      rcx, gword ptr [rdx]
       jne      G_M000_IG32
       mov      rcx, gword ptr [r14+0x10]
       mov      rdx, rcx
       test     rdx, rdx
       jne      G_M000_IG30
 
G_M000_IG17:                ;; offset=0x0195
       test     rcx, rcx
       jne      G_M000_IG31
 
G_M000_IG18:                ;; offset=0x019E
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rbp-0x68], rcx
       mov      qword ptr [r14+0x20], rcx
       mov      byte  ptr [r14+0x28], 1
       xor      rcx, rcx
       mov      gword ptr [r14+0x08], rcx
 
G_M000_IG19:                ;; offset=0x01B5
       mov      gword ptr [rbp-0x80], r14
       mov      rdx, r14
       mov      r14, rdx
       mov      r8, gword ptr [rbp-0x80]
 
G_M000_IG20:                ;; offset=0x01C3
       cmp      byte  ptr [rbp+0x38], 0
       jne      G_M000_IG35
       mov      gword ptr [rbp-0x80], r8
       mov      rcx, 0x7FFA02CB7368
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      r8, gword ptr [rsi]
       mov      gword ptr [rbp-0xB0], r8
       mov      r10, gword ptr [rsi+0x08]
       mov      gword ptr [rbp-0xB8], r10
       movzx    rsi, byte  ptr [rsi+0x10]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      r15, gword ptr [rbp-0x98]
       lea      rcx, bword ptr [r15+0x18]
       mov      rdx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x10]
       mov      rdx, gword ptr [rbp-0xB8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      byte  ptr [r15+0x20], sil
       lea      rcx, bword ptr [r15+0x40]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x28]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x50]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG21:                ;; offset=0x025C
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x78]
       mov      r8, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:ChargeClosureRetention(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan)]
       mov      rbx, gword ptr [rbp-0x88]
       test     rbx, rbx
       je       SHORT G_M000_IG25
 
G_M000_IG22:                ;; offset=0x0279
       mov      r11, gword ptr [rbp-0xA0]
       mov      rdx, r11
       test     rdx, rdx
       jne      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0288
       mov      rsi, gword ptr [rbp+0x58]
       mov      rdx, rsi
       test     rdx, rdx
       je       G_M000_IG36
 
G_M000_IG24:                ;; offset=0x0298
       lea      rcx, bword ptr [r15+0x38]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rbx, byte  ptr [rbp-0x6C]
       mov      byte  ptr [r15+0x23], bl
 
G_M000_IG25:                ;; offset=0x02A9
       mov      rdx, gword ptr [rbp-0x78]
       cmp      byte  ptr [rdx], dl
       cmp      qword ptr [rbp-0x40], 0
       jle      SHORT G_M000_IG26
       mov      rcx, qword ptr [rdx+0x28]
       mov      rax, rcx
       cmp      qword ptr [rbp-0x40], rax
       cmovle   rax, qword ptr [rbp-0x40]
       sub      rcx, rax
       mov      qword ptr [rdx+0x28], rcx
       add      rax, qword ptr [rdx+0x30]
       jo       G_M000_IG33
       mov      qword ptr [rdx+0x30], rax
       mov      rdx, gword ptr [rbp-0x78]
 
G_M000_IG26:                ;; offset=0x02DF
       mov      r14, gword ptr [rbp-0x80]
       test     r14, r14
       je       G_M000_IG37
 
G_M000_IG27:                ;; offset=0x02EC
       mov      byte  ptr [r14+0x29], 1
       cmp      dword ptr [rbp-0x70], 0
       jbe      G_M000_IG34
       mov      rcx, bword ptr [rbp-0xA8]
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      rbx, bword ptr [rbp-0xA8]
       mov      qword ptr [rbx+0x08], rcx
       jmp      G_M000_IG37
 
G_M000_IG28:                ;; offset=0x031C
       cmp      dword ptr [rcx+0x20], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG13
 
G_M000_IG29:                ;; offset=0x032E
       mov      rcx, r8
       mov      rdx, gword ptr [rbp+0x48]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG13
 
G_M000_IG30:                ;; offset=0x0340
       cmp      byte  ptr [rdx+0x101], 0
       jne      SHORT G_M000_IG32
       jmp      G_M000_IG17
 
G_M000_IG31:                ;; offset=0x034E
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       je       G_M000_IG18
 
G_M000_IG32:                ;; offset=0x035D
       lea      rcx, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG19
 
G_M000_IG33:                ;; offset=0x0378
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG34:                ;; offset=0x037E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG35:                ;; offset=0x0384
       mov      gword ptr [rbp-0x80], r8
       mov      rcx, 0x7FFA02CDC648
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x90], rax
       mov      bword ptr [rsp+0x20], rsi
       mov      gword ptr [rsp+0x28], r14
       mov      rcx, rax
       mov      rdx, r15
       mov      r8, rdi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.PyGeneratorFunction:.ctor(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.FunctionDefaults,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell]):this]
       mov      r15, gword ptr [rbp-0x90]
       jmp      G_M000_IG21
 
G_M000_IG36:                ;; offset=0x03C6
       mov      rsi, gword ptr [rbp+0x48]
       mov      gword ptr [rsp+0x20], rsi
       mov      rcx, rbx
       mov      rdx, r12
       mov      r8d, dword ptr [rbp-0x44]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:CopyAnnotationValues(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object[]:this]
       mov      rdx, rax
       jmp      G_M000_IG24
 
G_M000_IG37:                ;; offset=0x03EA
       mov      rax, r15
 
G_M000_IG38:                ;; offset=0x03ED
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG39:                ;; offset=0x0401
       mov      r8, gword ptr [rbp+0x58]
       mov      r11, gword ptr [rbp-0xA0]
 
G_M000_IG40:                ;; offset=0x040C
       mov      r10, gword ptr [rdi+0x08]
       test     r10, r10
       je       SHORT G_M000_IG42
       mov      gword ptr [rbp+0x58], r8
       jmp      G_M000_IG05
 
G_M000_IG41:                ;; offset=0x041E
       xor      r8d, r8d
       mov      dword ptr [rbp-0x44], r8d
       mov      r8d, 160
       mov      gword ptr [rbp-0x88], r10
       mov      rax, r8
       jmp      G_M000_IG07
 
G_M000_IG42:                ;; offset=0x043A
       mov      rcx, 0x7FFA0276A220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1E46DEC9E98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG43:                ;; offset=0x0468
       mov      rcx, 0x7FFA02A75928
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rcx, qword ptr [rbp-0x50]
       add      rcx, qword ptr [(reloc 0x7ffa0253b0d8)]
       jo       SHORT G_M000_IG44
       mov      qword ptr [rbp-0x40], rcx
       jmp      G_M000_IG08
 
G_M000_IG44:                ;; offset=0x048E
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG45:                ;; offset=0x0494
       sub      rsp, 56
 
G_M000_IG46:                ;; offset=0x0498
       cmp      gword ptr [rbp-0xA0], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [rbp-0x78]
       mov      rdx, qword ptr [rbp-0x40]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
 
G_M000_IG47:                ;; offset=0x04B2
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 1208

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:TryReadPreparedDefaultInteger(int,byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 18108
; 6 inlinees with PGO data; 16 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 88
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x20], ymm4
       vmovdqa  xmmword ptr [rsp+0x40], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x50], rax
       mov      rbx, rcx
       mov      esi, edx
       mov      rdi, r8
 
G_M000_IG02:                ;; offset=0x002B
       mov      rdx, gword ptr [rbx+0x08]
       mov      ebp, dword ptr [rdx+0x3C]
       cmp      esi, ebp
       jge      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x003A
       mov      r14, gword ptr [rbx+0x18]
       mov      r15, r14
       test     r15, r15
       je       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0046
       mov      rdx, 0x7FFA02CEEAC0
       cmp      qword ptr [r15], rdx
       jne      G_M000_IG28
 
G_M000_IG05:                ;; offset=0x0059
       test     r15, r15
       je       G_M000_IG33
       sub      ebp, esi
       mov      rdx, gword ptr [r15+0x08]
       mov      rcx, rdx
       test     rcx, rcx
       jne      G_M000_IG29
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x0079
       mov      r14d, eax
       sub      r14d, ebp
       cmp      r14d, eax
       jae      G_M000_IG30
       mov      rcx, 0x7FFA026028A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      G_M000_IG32
       mov      rcx, r15
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rdx, gword ptr [rax]
       mov      rcx, 0x1C447001C18
       cmp      rdx, gword ptr [rcx]
       jne      G_M000_IG31
       movsxd   r8, r14d
       inc      r8
 
G_M000_IG07:                ;; offset=0x00C8
       mov      gword ptr [rsp+0x48], r15
       mov      qword ptr [rsp+0x50], r8
       mov      ebp, 1
 
G_M000_IG08:                ;; offset=0x00D7
       xor      rdx, rdx
       mov      gword ptr [rsp+0x40], rdx
       test     ebp, ebp
       je       G_M000_IG36
       mov      rdx, gword ptr [rsp+0x48]
       mov      rcx, 0x1C447001C18
       cmp      rdx, gword ptr [rcx]
       je       SHORT G_M000_IG15
 
G_M000_IG09:                ;; offset=0x00FA
       cmp      qword ptr [rsp+0x50], 0
       jg       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0102
       mov      rcx, gword ptr [rsp+0x48]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x0112
       mov      rdx, gword ptr [rsp+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x011F
       mov      rax, 0x7FFA02CEEAC0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG13:                ;; offset=0x0132
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG14:                ;; offset=0x0137
       mov      edx, dword ptr [rsp+0x50]
       dec      edx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0148
       mov      rax, qword ptr [rsp+0x50]
       mov      qword ptr [rdi], rax
       mov      eax, 1
 
G_M000_IG16:                ;; offset=0x0155
       add      rsp, 88
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG17:                ;; offset=0x0162
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x18]
       mov      ecx, esi
       sub      ecx, ebp
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG38
       shl      rcx, 4
       mov      esi, dword ptr [rdx+rcx+0x18]
       cmp      byte  ptr [rbx+0x20], 0
       je       SHORT G_M000_IG24
 
G_M000_IG18:                ;; offset=0x0185
       mov      rcx, gword ptr [rbx+0x10]
 
G_M000_IG19:                ;; offset=0x0189
       mov      rdx, 0x1C447001C18
       cmp      rcx, gword ptr [rdx]
       je       SHORT G_M000_IG23
 
G_M000_IG20:                ;; offset=0x0198
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
 
G_M000_IG21:                ;; offset=0x01A1
       nop      
 
G_M000_IG22:                ;; offset=0x01A2
       add      rsp, 88
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG23:                ;; offset=0x01AF
       xor      eax, eax
       mov      qword ptr [rdi], rax
       mov      eax, 1
       jmp      SHORT G_M000_IG21
 
G_M000_IG24:                ;; offset=0x01BB
       mov      rdx, gword ptr [rbx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x01C7
       mov      rcx, 0x7FFA026028A8
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x01D6
       call     [CORINFO_HELP_CHKCASTARRAY]
       mov      rbx, rax
 
G_M000_IG27:                ;; offset=0x01DF
       cmp      esi, dword ptr [rbx+0x08]
       jae      G_M000_IG38
       mov      ecx, esi
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       jmp      SHORT G_M000_IG19
 
G_M000_IG28:                ;; offset=0x01F1
       mov      rdx, r14
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       jmp      G_M000_IG05
 
G_M000_IG29:                ;; offset=0x020B
       mov      eax, dword ptr [rcx+0x08]
       test     eax, eax
       jl       G_M000_IG39
       jmp      G_M000_IG06
 
G_M000_IG30:                ;; offset=0x021B
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
       xor      ebp, ebp
       jmp      G_M000_IG08
 
G_M000_IG31:                ;; offset=0x022C
       mov      rdx, gword ptr [rax]
       lea      rcx, [rsp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r15, gword ptr [rsp+0x20]
       mov      r8, qword ptr [rsp+0x28]
       jmp      G_M000_IG07
 
G_M000_IG32:                ;; offset=0x0249
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG38
       mov      edx, r14d
       mov      rdx, gword ptr [rax+8*rdx+0x10]
       lea      rcx, [rsp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      r15, gword ptr [rsp+0x30]
       mov      r8, qword ptr [rsp+0x38]
       jmp      G_M000_IG07
 
G_M000_IG33:                ;; offset=0x0275
       test     r14, r14
       je       SHORT G_M000_IG34
       lea      rdx, [rsp+0x40]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyTupleLike:TryGetItems(System.Object,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG34
       mov      rcx, gword ptr [rbx+0x08]
       mov      ebp, dword ptr [rcx+0x3C]
       mov      rcx, gword ptr [rsp+0x40]
       mov      r11, 0x7FFA02541B50
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       sub      ebp, eax
       sub      esi, ebp
       js       SHORT G_M000_IG34
       mov      rcx, gword ptr [rsp+0x40]
       mov      r11, 0x7FFA02541B58
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       cmp      eax, esi
       jle      SHORT G_M000_IG34
       mov      rcx, gword ptr [rsp+0x40]
       mov      edx, esi
       mov      r11, 0x7FFA02541B60
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, rax
       lea      rcx, [rsp+0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      ebp, 1
       jmp      G_M000_IG08
 
G_M000_IG34:                ;; offset=0x02ED
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x48], xmm0
       xor      ebp, ebp
       jmp      G_M000_IG08
 
G_M000_IG35:                ;; offset=0x02FE
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG13
 
G_M000_IG36:                ;; offset=0x0315
       xor      eax, eax
       mov      qword ptr [rdi], rax
 
G_M000_IG37:                ;; offset=0x031A
       add      rsp, 88
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       ret      
 
G_M000_IG38:                ;; offset=0x0327
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG39:                ;; offset=0x032D
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 819

; Assembly listing for method Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Dynamic PGO
; rsp based frame
; partially interruptible
; with Dynamic PGO: fgCalledCount is 66720
; 1 inlinees with PGO data; 12 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 40
       mov      rbx, rcx
       mov      esi, edx
 
G_M000_IG02:                ;; offset=0x000D
       mov      rdi, gword ptr [rbx+0x08]
       mov      ebp, dword ptr [rdi+0x40]
       test     ebp, ebp
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0018
       cmp      byte  ptr [rbx+0x20], 0
       je       SHORT G_M000_IG11
 
G_M000_IG04:                ;; offset=0x001E
       mov      rdx, gword ptr [rdi+0x28]
       mov      edx, dword ptr [rdx+0x08]
       sub      edx, dword ptr [rdi+0x38]
       cmp      edx, ebp
       jne      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x0030
       mov      edi, dword ptr [rdi+0x3C]
       cmp      esi, edi
       jg       G_M000_IG15
       mov      rdx, gword ptr [rbx+0x18]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0047
       mov      rcx, 0x7FFA02CEEAC0
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG12
 
G_M000_IG07:                ;; offset=0x0056
       test     rbx, rbx
       je       SHORT G_M000_IG13
 
G_M000_IG08:                ;; offset=0x005B
       mov      rax, gword ptr [rbx+0x08]
       test     rax, rax
       jne      SHORT G_M000_IG14
       mov      ecx, 1
 
G_M000_IG09:                ;; offset=0x0069
       sub      edi, ecx
       cmp      edi, esi
       setle    al
       movzx    rax, al
 
G_M000_IG10:                ;; offset=0x0073
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG11:                ;; offset=0x007C
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, 0x7FFA026028A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG15
       jmp      SHORT G_M000_IG04
 
G_M000_IG12:                ;; offset=0x0096
       mov      rcx, 0x7FFA02C41128
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       jmp      SHORT G_M000_IG07
 
G_M000_IG13:                ;; offset=0x00AA
       xor      ecx, ecx
       jmp      SHORT G_M000_IG09
 
G_M000_IG14:                ;; offset=0x00AE
       mov      ecx, dword ptr [rax+0x08]
       test     ecx, ecx
       jl       SHORT G_M000_IG17
       jmp      SHORT G_M000_IG09
 
G_M000_IG15:                ;; offset=0x00B7
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x00B9
       add      rsp, 40
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG17:                ;; offset=0x00C2
       call     CORINFO_HELP_OVERFLOW
       int3     
 
; Total bytes of code 200

