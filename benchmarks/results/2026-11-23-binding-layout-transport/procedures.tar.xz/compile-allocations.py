from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
bin=next((lab.parent/"dispatch-known-call-semantics-20261123/allocation-driver").glob("bin/**/Allocation.dll")).parent
driver=lab/"compilation-driver"
driver.mkdir()
manifest=json.loads((lab/"comparison/identity.json").read_text(encoding="utf-8"))
catalog=lab/"comparison/representative.json"
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
cases=[case["id"] for case in json.loads(catalog.read_text(encoding="utf-8"))["cases"]]
for role in ("reference","candidate"):
    image=driver/role
    image.mkdir()
    for name in ("Allocation.dll", "Allocation.deps.json", "Allocation.runtimeconfig.json"):
        shutil.copyfile(bin/name,image/name)
    core=lab/role/"Lokad.Lython.dll"
    assert hashlib.sha256(core.read_bytes()).hexdigest()==manifest["coreSHA256"][role]
    shutil.copyfile(core,image/core.name)
observations=[]
for step in range(2):
    for case in cases:
        for role in (("reference","candidate") if step==0 else ("candidate","reference")):
            result=subprocess.run([dotnet,driver/role/"Allocation.dll",catalog,case],env=env,
                capture_output=True,encoding="utf-8",timeout=25,check=True)
            observations.append(dict(role=role,run=step,stats=json.loads(result.stdout)))
summary=[]
for case in cases:
    roles={}
    for role in ("reference","candidate"):
        samples = [row["stats"] for row in observations if row["role"]==role and row["stats"]["id"]==case]
        assert len(samples)==2
        warm=[entry for row in samples for entry in row["warm"]]
        assert len(warm)==50
        roles[role]=dict(compiledAllocated=statistics.median(row["AllocatedBytes"] for row in warm),
            admitted=sorted({row["PeakAllowance"] for row in warm}))
    summary.append(dict(case=case,roles=roles))
    print(case,roles)
(lab/"compile-allocations.json").write_text(json.dumps(dict(rows=summary,observations=observations),indent=2)+"\n",
    encoding="utf-8",newline="\n")
