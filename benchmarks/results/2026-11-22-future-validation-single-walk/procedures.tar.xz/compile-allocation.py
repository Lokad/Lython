from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"short-borrowed-text-probe-20261122"/"comparison"
out=lab/"comparison"
out.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base=lab.parent/"module-leading-indentation-20261122"/"comparison/catalog.json"
catalog=read(base)
sources={r["id"]:r for r in catalog["cases"]}
for path in (lab.parent/"function-diagnostic-identity-20261122/comparison/quiet/representative.json",
             lab.parent/"current-cpython-refresh-20261122/representative.json"):
    sources.update({r["id"]:r for r in read(path)["cases"]})
ids=["scripts.annotated-rule-closures.nested-factories.postponed",
     "scripts.annotated-rule-closures.nested-factories","scripts.dataclass-inherited-configuration.generated",
     "scripts.config-generated-guards.medium.bad-0.sparse-lexical","compiler.generated-read-only-branches",
     "diagnostic.text-summary.nonlocal-computed-width.large","scripts.config-edit.small"]
catalog["cases"]=[sources[id] for id in ids]
catalog["performanceQualified"]=False
path=out/"catalog.json"
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
manifest=read(prior/"identity.json")
core="Lokad.Lython.dll"
diag=read(lab/"diagnostic-comparison.json")
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
assert sha(candidate)==diag["imageHashes"]["candidate"][core]
reference=prior/"frozen-reference"/core
assert sha(reference)==diag["imageHashes"]["reference"][core]==manifest["imageFiles"]["reference"][core]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
donor=lab.parent/"child-declaration-preparation-r668/compile-allocation/candidate"
results={}
for role in ("reference","candidate"):
    image=out/f"frozen-{role}"
    image.mkdir(exist_ok=True)
    paths={name:candidate if name==core and role=="candidate" else prior/"frozen-reference"/name
           for name in manifest["imageFiles"]["reference"]}
    assert all(sha(paths[n])==value for n,value in manifest["imageFiles"]["reference"].items() if n!=core)
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="CompileAllocation"+suffix
        paths[n]=donor/n
    for n,p in paths.items():
        shutil.copyfile(p,image/n)
    before={n:sha(p) for n,p in paths.items()}
    assert {n:sha(image/n) for n in paths}==before
    protocol=repo/"benchmarks/cpython-worker.py"
    assert sha(protocol)==manifest["protocolSHA256"]
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=90)
    assert read(proof)["caseCount"]==len(ids)
    report=out/f"{role}-allocation.json"
    with report.open("wb") as output:
        subprocess.run([dotnet,image/"CompileAllocation.dll",path],env=env,check=True,timeout=85,stdout=output)
    records=read(report)
    assert records["coreSha256"]==before[core]
    assert {n:sha(image/n) for n in paths}==before
    results[role]={r["id"]:r["bytes"] for r in records["rows"]}
    print(role,results[role],flush=True)
for id in ids:
    old,new=(results[r][id][-1] for r in ("reference","candidate"))
    print(id,old,new,100*(new/old-1),flush=True)
