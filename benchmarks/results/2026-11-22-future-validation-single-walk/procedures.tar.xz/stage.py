from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab.parent/"short-borrowed-text-probe-20261122/comparison"
out=lab/"comparison"
quiet=out/"quiet"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,indent=2)+"\n")
def verified(folder):
    base=f"origin/master:benchmarks/results/{folder}"
    receipt=json.loads(git("show",base+"/archive-receipt.json"))
    assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert receipt["archiveSHA256"]==sha(git("show",base+"/observations.tgz"))
    return base,receipt["archiveSHA256"]

before=read(old/"quiet/config.json")
base=read(old/"quiet/identity.json")
tree=repo/".git/agent-worktrees/future-annotations-single-walk-20261122"
candidate=git("-C",str(tree),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("fd7a59409") and not git("-C",str(tree),"status","--porcelain")
patch=git("diff","--binary",base["patchBase"],candidate,"--","src")
assert patch.count(b"diff --git ")==4
(out/"source.patch").write_bytes(patch)
assert not git("diff",base["reference"],base["patchBase"],"--","src")
diag=read(lab/"diagnostic-comparison.json")
assert diag["cases"]==1200 and not diag["diagnosticDifferences"] and diag["balanceDifferences"]==0
files={r:{n:h(out/f"frozen-{r}"/n) for n in base["imageFiles"]["reference"]} for r in ("reference","candidate")}
assert files["reference"]==base["imageFiles"]["reference"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
for role in files:
    assert diag["imageHashes"][role][core]==files[role][core]==read(out/f"{role}-allocation.json")["coreSha256"]
catalog=out/"catalog.json"
ids=[row["id"] for row in read(catalog)["cases"]]
for role in files:
    proof=read(out/f"{role}-verify.json")
    assert proof["catalogSha256"]==h(catalog) and proof["state"]=="Completed" and proof["caseCount"]==len(ids)
jobs=[*( (id,"compile") for id in ids[:5]),(ids[0],"compile-run")]
assert len(jobs)==6
save(out/"jobs.json",jobs)
staging,old_archive=verified("2026-11-22-short-borrowed-text-probe")
_,donor_archive=verified("2026-11-22-callable-checkpoint-cpython")
previous=gzip.decompress(git("show",staging+"/candidate-core.dll.gz"))
assert sha(previous)==base["imageFiles"]["candidate"][core]!=files["candidate"][core]
assert json.loads(git("show",staging+"/source.json"))["imageFiles"]==base["imageFiles"]
prior_name=Path(before["root"]).name
retire=[dict(paths=[prior_name+"/candidate/"+core],bytes=len(previous),sha256=sha(previous),links=1,
             archives={prior_name+"/observations.tgz":old_archive})]
identity=dict(sourceRevision=base["reference"]+" versus "+candidate,reference=base["reference"],patchBase=base["patchBase"],
              candidate=candidate,testedRevision=candidate,purpose="Validate postponed annotations and future placement during existing syntax traversal",
              normalAdapterPin="0.4.0",imageFiles=files,sourcePatchSHA256=sha(patch),protocolSHA256=base["protocolSHA256"],
              coreSHA256={role+suffix:m[core]for role,m in files.items()for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":h(catalog)}})
root="/home/lokad/lython-bench-checks/future-validation-b1421-20261122"
unit="lython-b1421-future-validation-20261122"
quiet.mkdir(exist_ok=False)
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir()
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(old/"quiet"/leaf).read_text(encoding="utf-8").replace(before["root"],root).replace(before["unit"],unit)
    s=s.replace("len(jobs)==8","len(jobs)==6").replace("len(raw['jobs'])==8","len(raw['jobs'])==6")
    s=s.replace("jobs=8,","jobs=6,").replace("['jobs']==8","['jobs']==6").replace("started < 450","started < 345")
    if leaf=="collect.py":
        a,b=s.index("\njob_catalog ="),s.index("\nassert len(jobs)")
        s=s[:a]+"\njob_catalog = "+repr({id:"representative.json"for id,_ in jobs})+"\njobs = "+repr(jobs)+s[b:]
    s=s.replace("Short UTF-8 probe","Future validation")
    write(quiet/leaf,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for leaf in parts:t.add(quiet/leaf,arcname=leaf)
cfg={**before,"root":root,"unit":unit,"identity":identity,"sourceFiles":files["reference"],
     "donorArchiveSHA256":donor_archive,"retireGroups":retire,"payloadBytes":payload.stat().st_size,
     "payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(old/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
write(quiet/"remote-launch.py",(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1420-fixtures","b1421-fixtures").replace("RuntimeMaxSec=525","RuntimeMaxSec=425"))
s=(old/"launch.py").read_text(encoding="utf-8").replace("Short UTF-8 probe","Future validation")
write(out/"launch.py",s.replace("seconds=485","seconds=380").replace("before 485 seconds","before 380 seconds"))
s=(old/"summarize.py").read_text(encoding="utf-8")
write(out/"summarize.py",s.replace("len(raw['jobs'])==8","len(raw['jobs'])==6"))
print(candidate,root,cfg["unpackedBytes"],flush=True)
