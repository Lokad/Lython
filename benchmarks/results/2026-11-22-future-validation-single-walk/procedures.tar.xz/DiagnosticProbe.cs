using System.Text.Json;
using Lokad.Lython;

var sources = JsonSerializer.Deserialize<string[]>(File.ReadAllBytes(args[0]))!;
var results = new List<object>();
var engine = new LythonEngine();
foreach (var source in sources)
{
    var budget = new LythonMemoryBudget();
    using (var script = engine.Compile(source, budget))
        results.Add(new { script.IsValid, script.Diagnostics, reservedBytes = budget.ReservedBytes });
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation owner retained its allowance.");
}
File.WriteAllText(args[1], JsonSerializer.Serialize(results));
