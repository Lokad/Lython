from itertools import product
from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
short=lab.parent/"short-borrowed-text-probe-20261122"/"comparison"
old=lab.parent/"module-leading-indentation-20261122"
core="Lokad.Lython.dll"
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
reference=short/"frozen-reference"/core
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
manifest=read(short/"identity.json")
assert sha(reference)==manifest["imageFiles"]["reference"][core]
assert not subprocess.check_output(["git","diff",manifest["reference"],manifest["patchBase"],"--","src"],cwd=repo)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
futures=["","from __future__ import annotations\n","from __future__ import division\n","from __future__ import division, annotations\n","from __future__ import division\nfrom __future__ import annotations\n"]
heads=["","'doc'\n","(('doc'))\n","x=0\n","f'doc'\n","pass\nfrom __future__ import annotations\n"]
bodies=["pass\n","x: (y := 1) = 0\n", "x: tuple[(left := 1), (right := 2)]\n",
        "def func(x: (a := 1), /, y: (b := 2) = 0, *, z: (c := 3) = 0) -> (d := 4):\n    pass\n",
        "def func(x: (lambda arg=(a := 1): (b := 2))) -> (lambda: (c := 3)):\n    return x\n",
        "if False:\n    from __future__ import annotations\n    x: (w := 0)\nelse:\n    from __future__ import division\n",
        "class C:\n    from __future__ import annotations\n    x: (w := 0)\n    def f(x: (p := 1)):\n        from __future__ import division\n        x: (q := 1)\n",
        "def gen(x: (a := 0)):\n    yield 0\n    return 2\n", "type T[A] = list[A]\nbreak\n",
        "with x:\n    from __future__ import annotations\nfor x in []:\n    from __future__ import division\n"]
tails=["","from __future__ import annotations\n","from __future__ import division\n","return 2\nfrom __future__ import annotations\nx: (t := 0)\n"]
matrix=list(dict.fromkeys(head+future+body+tail for head,future,body,tail in product(heads,futures,bodies,tails)))
source=lab/"annotation-inputs.json"
source.write_text(json.dumps(matrix,ensure_ascii=False),encoding="utf-8")
for file in ("DiagnosticProbe.cs","DiagnosticProbe.csproj"):
    shutil.copyfile(old/file,lab/file)
with (lab/"diagnostic-build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"DiagnosticProbe.csproj","-c","Release",f"-p:InspectionCorePath={reference}"],cwd=repo,
                   env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
details={}
hashes={}
for role,path in (("reference",reference),("candidate",candidate)):
    image=lab/"diagnostic-image"/role
    image.mkdir(parents=True,exist_ok=True)
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="DiagnosticProbe"+suffix
        shutil.copyfile(lab/"bin/Release/net11.0"/name,image/name)
    shutil.copyfile(path,image/core)
    hashes[role]={p.name:sha(p) for p in sorted(image.iterdir())}
    assert hashes[role][core]==sha(path)
    result=lab/f"{role}-diagnostics.json"
    subprocess.run([dotnet,image/"DiagnosticProbe.dll",source,result],check=True,env=env,timeout=40)
    assert {p.name:sha(p) for p in sorted(image.iterdir())}==hashes[role]
    details[role]=read(result)
def normalize(row):
    return (row["IsValid"],row["Diagnostics"])
differences=[dict(source=s,reference=r,candidate=c) for s,r,c in zip(matrix,details["reference"],details["candidate"],strict=True)
             if normalize(r)!=normalize(c)]
balance_differences=sum(r["reservedBytes"]!=c["reservedBytes"] for r,c in zip(details["reference"],details["candidate"],strict=True))
report=dict(cases=len(matrix),valid=sum(r["IsValid"] for r in details["reference"]),diagnosticDifferences=differences,
            balanceDifferences=balance_differences,imageHashes=hashes)
(lab/"diagnostic-comparison.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8",newline="\n")
print("cases =",len(matrix),"valid =",report["valid"],"diagnostic differences =",len(differences),
      "retained balance differences =",balance_differences,flush=True)
assert not differences,differences[:5]
