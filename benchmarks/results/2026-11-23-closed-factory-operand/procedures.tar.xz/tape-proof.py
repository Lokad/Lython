from pathlib import Path
import json,re

lab=Path(__file__).resolve().parent
root=lab.parents[3]
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
source=(root/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
opcodes=re.findall(r'^\s*(\w+),\s*$',source.split('enum ExecutableOpCode',1)[1].split('}',1)[0],re.M)
def opname(instruction):
    return opcodes[instruction['<OpCode>k__BackingField']]
reference=read(lab/'reference-tape.json')
candidate=read(lab/'candidate-tape.json')
proof=[]
for old,new in zip(reference['rows'],candidate['rows'],strict=True):
    assert old['id']==new['id']
    if 'nested-factories' not in old['id']:
        continue
    before,after=old['codes'][0],new['codes'][0]
    old_tape,new_tape=before['tape'],after['tape']
    assert before['locals']==after['locals']
    names=before['locals']
    target=names.index('compile_rule')
    seed=names.index('index')
    assert len(old_tape)-len(new_tape)==2
    old_call=next(i for i,ins in enumerate(old_tape) if opname(ins)=='Call' and ins['_primaryOperand']==2)
    new_call=next(i for i,ins in enumerate(new_tape) if opname(ins)=='Call' and ins['_primaryOperand']==2)
    assert new_call==old_call-2
    assert [opname(inst) for inst in old_tape[old_call-2:old_call]]==['LoadLocal','LoadLocal']
    assert [inst['_primaryOperand'] for inst in old_tape[old_call-2:old_call]]==[target,seed]
    assert new_tape[new_call]['_inputStart']==target and new_tape[new_call]['_secondaryOperand']==seed
    update=next(ins for ins in new_tape if opname(ins)=='IntegerCallUpdate')
    assert update['_primaryOperand']==names.index('total')
    assert new_tape[update['_secondaryOperand']]['_primaryOperand']==3
    callee={code['name']:code for code in new['codes']}
    assert callee['compile_rule']['directDefinitionReturn'] and callee['evaluate']['directIntegerReturn']
    proof.append(dict(script=old['id'],oldCall=old_call,forwardedCall=new_call,
        targetSlot=target,argumentSlot=seed,closedUpdateCall=update['_secondaryOperand']))
assert len(proof)==2
out=dict(proof=proof,candidateCore=candidate['coreSHA256'],referenceCore=reference['coreSHA256'])
(lab/'tape-proof.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(out)
