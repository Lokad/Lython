from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/closed-factory-operand-20261123'
prior = lab.parent / 'supplied-lexical-call-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
git = lambda *args: subprocess.check_output(['git','-C',tree,*args]).decode().strip()
reference, candidate = git('rev-parse','HEAD^'), git('rev-parse','HEAD')
assert not git('status','--porcelain')
assert reference.startswith('23756d1ea')
dotnet = Path.home() / '.dotnet11/dotnet.exe'
python = 'C:/Python313/python.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))

catalog = read(lab.parent/'closed-defaults-cpython-20261123/comparison/quiet/representative.json')
postponed, eager, supplied, quote = catalog['cases']
old = read(lab.parent/'unboxed-singleton-default-20261123/comparison-refined/representative.json')
observer = next(row for row in old['cases'] if '__defaults__' in row['source'])
assert 'postponed' in postponed['id'] and 'nested-factories' in eager['id']
assert supplied['id']=='scripts.ordinary-fully-supplied-helper'
catalog['cases']=[postponed,eager,observer,supplied,quote]
assert len({row['id'] for row in catalog['cases']})==5
write(comparison/'representative.json',catalog)
jobs = [(postponed['id'],'warm'), (postponed['id'],'compile-run'), (eager['id'],'warm'),
    (observer['id'],'warm'), (supplied['id'],'warm'), (quote['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})

protocol = repo/'benchmarks/cpython-worker.py'
proof = read(prior/'comparison/identity.json')
assert digest(protocol) == proof['cpythonWorkerSHA256']
core = 'Lokad.Lython.dll'
actual = {}
for role in ('reference','candidate'):
    image = lab/role
    image.mkdir(exist_ok=True)
    files = proof['imageFiles']['candidate']
    assert len(files) == 32
    for name, expected in files.items():
        donor = prior/'candidate'/name
        assert digest(donor) == expected
        if role == 'candidate' and name == core:
            donor = lab/'frozen/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(donor,image/name)
    actual[role] = {name:digest(image/name) for name in files}
    for helper in ('ValidatedAllocation','Inspect'):
        for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
            name = helper+suffix
            shutil.copyfile(prior/'candidate'/name,image/name)
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',lab/(role+'-tape.json')],
        env=env, check=True, timeout=35)
    verification = comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',verification],env=env,check=True,timeout=95)
    data = read(verification)
    assert data['state']=='Completed' and data['caseCount']==5
    assert data['launched']['library']['sha256']==actual[role][core]
    assert all(digest(image/name)==expected for name,expected in actual[role].items())
assert [name for name in files if actual['reference'][name]!=actual['candidate'][name]]==[core]
assert actual['reference'][core] == proof['imageFiles']['candidate'][core]
write(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1529 reuse the integer argument through computed definitions and omitted-default updates',
    imageFiles=actual,coreSHA256={k:rows[core] for role,rows in actual.items() for k in (role,role+'-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')}))

def adapt(name, replacements):
    source = (prior/name).read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in source, (name,before)
        source = source.replace(before, after)
    compile(source,str(lab/name),'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

adapt('allocations.py',())
adapt('stage.py',(
    ('supplied-lexical-call-b1526-20261123','closed-factory-operand-b1529-20261123'),
    ('supplied-operand-window-b1524-20261123','supplied-lexical-call-b1526-20261123'),
    ('lython-b1526-fixtures','lython-b1529-fixtures'),('len(jobs) == 5','len(jobs) == 6'),('< 270,','< 320,'),
))
adapt('quiet.py',(
    ('lython-b1526-supplied-lexical-call-20261123','lython-b1529-closed-factory-operand-20261123'),
    ('.+b1526-','.+b1529-'),('lython-b1526-stage-','lython-b1529-stage-'),
    ('Five bounded lanes write under 1 MiB of receipts. A 40 MiB',
     'Six bounded lanes write under 1 MiB of receipts. A 34 MiB'),
    ('40 * 1024 * 1024','34 * 1024 * 1024'),
    ('RuntimeMaxSec=320','RuntimeMaxSec=380'),('seconds=248','seconds=294'),
))
adapt('summarize.py',(
    ('== 5\nassert hashlib','== 6\nassert hashlib'),('len(warm["jobs"])==5','len(warm["jobs"])==6'),
    ('timedBatches=140','timedBatches=168'),
))
