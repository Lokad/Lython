from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.parent/'supplied-lexical-call-20261123'
source=(prior/'prepare.py').read_text(encoding='utf-8')
begin=source.index('catalog = read(')
end=source.index('protocol =',begin)
source=source[:begin]+"""catalog = read(lab.parent/'closed-defaults-cpython-20261123/comparison/quiet/representative.json')
postponed, eager, supplied, quote = catalog['cases']
old = read(lab.parent/'unboxed-singleton-default-20261123/comparison-refined/representative.json')
observer = next(row for row in old['cases'] if '__defaults__' in row['source'])
assert 'postponed' in postponed['id'] and 'nested-factories' in eager['id']
assert supplied['id']=='scripts.ordinary-fully-supplied-helper'
catalog['cases']=[postponed,eager,observer,supplied,quote]
assert len({row['id'] for row in catalog['cases']})==5
write(comparison/'representative.json',catalog)
jobs = [(postponed['id'],'warm'), (postponed['id'],'compile-run'), (eager['id'],'warm'),
    (observer['id'],'warm'), (supplied['id'],'warm'), (quote['id'],'warm')]
write(comparison/'jobs.json',{'warm':jobs})

"""+source[end:]
updates=(
    (".git/agent-worktrees/supplied-operand-window-20261123",".git/agent-worktrees/closed-factory-operand-20261123"),
    ("prior = lab.parent / 'supplied-operand-window-20261123'","prior = lab.parent / 'supplied-lexical-call-20261123'"),
    ("reference.startswith('faf86299e')","reference.startswith('23756d1ea')"),
    ("prior/'generic-entry/bin/Lokad.Lython/release_net11.0'/core","lab/'frozen/bin/Lokad.Lython/release_net11.0'/core"),
    ('B1526 use one prepared exact-integer update entry after ordinary and checked local reads',
     'B1529 reuse the integer argument through computed definitions and omitted-default updates'),
)
for a,b in updates:
    assert source.count(a)==1,a
    source=source.replace(a,b)
start=source.index("adapt('allocations.py'")
source=source[:start]+"""adapt('allocations.py',())
adapt('stage.py',(
    ('supplied-lexical-call-b1526-20261123','closed-factory-operand-b1529-20261123'),
    ('supplied-operand-window-b1524-20261123','supplied-lexical-call-b1526-20261123'),
    ('lython-b1526-fixtures','lython-b1529-fixtures'),('len(jobs) == 5','len(jobs) == 6'),('< 270,','< 320,'),
))
adapt('quiet.py',(
    ('lython-b1526-supplied-lexical-call-20261123','lython-b1529-closed-factory-operand-20261123'),
    ('.+b1526-','.+b1529-'),('lython-b1526-stage-','lython-b1529-stage-'),
    ('Five bounded lanes write under 1 MiB of receipts. A 40 MiB',
     'Six bounded lanes write under 1 MiB of receipts. A 34 MiB'),
    ('40 * 1024 * 1024','34 * 1024 * 1024'),
    ('RuntimeMaxSec=320','RuntimeMaxSec=380'),('seconds=248','seconds=294'),
))
adapt('summarize.py',(
    ('== 5\\nassert hashlib','== 6\\nassert hashlib'),('len(warm["jobs"])==5','len(warm["jobs"])==6'),
    ('timedBatches=140','timedBatches=168'),
))
"""
target=lab/'prepare.py'
compile(source,str(target),'exec')
target.write_text(source,encoding='utf-8',newline='\n')
