set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/closed-factory-operand-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-public" --filter 'FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~AssignmentTarget|FullyQualifiedName~Cancellation|FullyQualifiedName~MemoryOwnership' > "$lab/ubuntu-public.log" 2>&1 || { tail -36 "$lab/ubuntu-public.log"; exit 1; }
tail -5 "$lab/ubuntu-public.log"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu-white" --filter 'FullyQualifiedName~Executable|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Native|FullyQualifiedName~MemoryGovernor|FullyQualifiedName~Stack' > "$lab/ubuntu-white.log" 2>&1 || { tail -36 "$lab/ubuntu-white.log"; exit 1; }
tail -5 "$lab/ubuntu-white.log"
