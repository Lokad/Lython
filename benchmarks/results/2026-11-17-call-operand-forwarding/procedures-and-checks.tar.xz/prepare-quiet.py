from pathlib import Path
import ast,gzip,hashlib,io,json,subprocess,tarfile,shutil
r=Path(__file__).parent;base=Path('D:/code/Lython');old=r.parent/'json-tokens-r469';q=r/'quiet';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/call-operands-b876-20261117'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.text-normalization.helper-list','warm'],['scripts.text-normalization.helper-list','compile-run'],['calls.positional.large','warm'],['calls.positional.large','compile-run'],['scripts.numeric-squared-error.large','warm']]
collect=(old/'quiet/collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a);collect=collect[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)"+collect[b:]
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n');shutil.copyfile(old/'quiet/archive-owned.py',q/'archive-owned.py')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/json-token-scan-b875-20261117',remote),encoding='utf-8',newline='\n')
ref=frozen['imageFiles']['reference']['Lokad.Lython.dll'];cand=frozen['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifiedccf20ba3/frozen7a599347 versus privateR470 base71cd6ce1/frozen'+cand,purpose='R470 compiler-to-call pure argument forwarding; existing funded windows/binder/frame cleanup, no alternate engine/controller. Complete helper text warm/fresh, ordinary-call diagnostic warm/fresh, numeric complete-script control.',coreSHA256={'reference':ref,'reference-control':ref,'candidate':cand,'candidate-control':cand},auxiliaryFiles={n:h for n,h in frozen['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},imageFiles=frozen['imageFiles'],sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=frozen['productionFiles'],catalogSHA256=frozen['catalogSHA256'],catalogInitialization='Unchanged twelve-case catalog fromB875; current source snapshot is preserved locally in full, not duplicated into VM runtime metadata.',normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll')
canonical='benchmarks/results/2026-11-17-json-token-scan/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=base);assert blob==(base/canonical).read_bytes()
groups=[]
with tarfile.open(fileobj=io.BytesIO(blob))as a:
 for member in ['confirmation/confirmation.json','identity.json']:
  data=a.extractfile(member).read();groups.append(dict(paths=['json-token-scan-b875-20261117/'+member],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
canonical='benchmarks/results/2026-11-17-json-token-scan/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=base);assert blob==(base/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='0679738371863ca55aba32b340a80c5909ebbe54dff344e9467dc290781b4226'
groups.append(dict(paths=['json-token-scan-b875-20261117/candidate/Lokad.Lython.dll'],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,withdrawnPrototypeOnly=True))
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b876-call-operands-20261117',source='/home/lokad/lython-bench-checks/json-token-scan-b875-20261117',sourceRole='reference',sourceFiles=frozen['imageFiles']['reference'],sourceCatalogSHA256=frozen['catalogSHA256'],catalogSHA256=frozen['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("assert (root/'representative.json').is_file()","os.link(source/'representative.json',root/'representative.json')\n assert (root/'representative.json').is_file()").replace('lython-b875-fixtures','lython-b876-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
launch=(old/'launch.py').read_text(encoding='utf-8').replace('receiver calls source pair launched; do not observe before230seconds.','call operand source pair launched; do not observe before180seconds.')
(r/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B875','B876'),encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared five jobs; reuse immutable12case catalog and31fixed assets. Retire only archived withdrawn core/raw/metadata:',sum(g['bytes']for g in groups),'bytes; unpacked',c['unpackedBytes'])
