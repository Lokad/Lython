from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
base=Path('D:/code/Lython');r=Path(__file__).parent;old=r.parent/'receiver-calls-r464';work=base/'.git/agent-worktrees/call-operands-r470'
frozen=r/'frozen';frozen.mkdir(exist_ok=False)
prior=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for name,expected in prior['imageFiles']['candidate'].items():
  source=old/'frozen/candidate'/name
  assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
  shutil.copyfile(source,image/name)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
images={role:{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (frozen/role).iterdir()}for role in ['reference','candidate']}
assert [name for name in images['reference']if images['reference'][name]!=images['candidate'][name]]==['Lokad.Lython.dll']
inputs=json.loads((base/'benchmarks/results/2026-11-17-receiver-calls/delivery/inputs.json').read_text(encoding='utf-8'))['inputs']
sources={name:hashlib.sha256((work/name).read_bytes()).hexdigest()for name in inputs}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for name in sources:a.add(work/name,arcname=name)
production=[name for name in sources if name.startswith('src/Lokad.Lython/')]
different=[name for name in production if (work/name).read_text(encoding='utf-8-sig').replace('\r\n','\n')!=(base/name).read_text(encoding='utf-8-sig').replace('\r\n','\n')]
assert sorted(different)==sorted(['src/Lokad.Lython/Frontend/ExecutableScript.InputSpans.cs', 'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs', 'src/Lokad.Lython/Frontend/ExecutableScript.cs', 'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs', 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']),different
shutil.copyfile(r.parent/'json-tokens-r469/catalog.json',r/'catalog.json')
identity=dict(catalogInitialization='Unchanged existing twelve-case catalog fromB875, fixed for both source images',referenceSource='Committedccf20ba3,fully qualified combined delivery44000267422; frozen7a599347',candidateSource='PrivateR470 base71cd6ce1,eight production-file call operand forwarding into existing owned windows; two public missing-argument precedence cases',imageFiles=images,sourceInputs=sources,productionFiles=len(production),catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),normalAdapterPin='0.4.0',fullQualification=False,publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
allocation=r/'allocation-short/bin/Release/net11.0';allocation.mkdir(parents=True)
for p in (old/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):shutil.copyfile(p,allocation/p.name)
script=(old/'validate-images.py').read_text(encoding='utf-8').replace("old=r.parent/'scalar-index-r453'","old=r.parent/'scalar-index-r453'")
(r/'validate-images.py').write_text(script,encoding='utf-8',newline='\n')
print('Frozen copied32file images; only core differs. Eight changed production sources,',len(sources),'snapshot inputs.',images['candidate']['Lokad.Lython.dll'])
