from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r/'quiet';q=r/'confirmation';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/call-operands-b877-20261117'
collect=(old/'collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a)
collect=collect[:a]+"jobs=[['calls.positional.large','warm'],['scripts.numeric-squared-error.large','warm']]\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)"+collect[b:]
a=collect.index('            counts=[]; warmups=[]');b=collect.index('            time.sleep(1)',a)
collect=collect[:a]+'''            counts=[1]*len(workers); warmups=[[]for _ in workers]; warmed=[0.0]*len(workers);turn=0
            while min(warmed)<8:
                for offset in range(len(workers)):
                    i=(turn+offset)%len(workers)
                    if warmed[i]>=8:continue
                    response=workers[i].request('batch',counts[i]);warmups[i].append(response)
                    seconds=workers[i].last_request_seconds;warmed[i]+=seconds
                    counts[i]=max(1,min(100000,math.ceil(counts[i]*.5/max(seconds,.000001))))
                turn+=1
'''+collect[b:]
collect=collect.replace('warmupSeconds=4','warmupSeconds=8').replace("warmupBoundary='full request wall time; sum retained responses for guest totals'","warmupBoundary='rotated worker batches accumulate8seconds full-request time per process; no forced GC or runtime overrides; preserve original B876sequential4second condition'")
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/call-operands-b876-20261117',remote),encoding='utf-8',newline='\n')
c=json.loads((old/'config.json').read_text(encoding='utf-8'));c.update(root=remote,unit='lython-b877-call-operands-20261117',source='/home/lokad/lython-bench-checks/call-operands-b876-20261117')
c['identity']['purpose']='One bounded B876same-source confirmation: warm-call unstable decreasing process plus numeric control, rotated cumulative8second full-request warmups. No source change or replacement of original adverse observations.'
(q/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-17-helper-runtime-attribution/observations.tgz';base=Path('D:/code/Lython');blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=base);assert blob==(base/canonical).read_bytes()
c['retireGroups']=[dict(paths=['helper-pipeline-b874-20261117/observations.tgz'],bytes=len(blob),links=1,sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='archive-bytes',committedBlobVerified=True)]
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n","for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
launch=launch.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace('lython-b876-fixtures','lython-b877-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
launch=(r/'launch.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent/'quiet'","r=Path(__file__).parent/'confirmation'").replace('seconds=180','seconds=140').replace('Five-job call operand source pair launched; do not observe before180seconds.','Two-job same-source confirmation launched; do not observe before140seconds.')
(r/'launch-confirmation.py').write_text(launch,encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==2").replace('B876','B877'),encoding='utf-8',newline='\n')
summary=(r/'summarize.py').read_text(encoding='utf-8').replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'confirmation/retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace("r/'summary.json'","r/'confirmation-summary.json'")
(r/'summarize-confirmation.py').write_text(summary,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch-confirmation.py',r/'summarize-confirmation.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared two-job unchanged-source confirmation; rotate cumulative8second warmups; exact archived working replica',len(blob),'bytes.')
