from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/NativeTupleReturnTests.cs').read_text(encoding='utf-8')
programs=re.findall(r'\{\s*("(?:\\.|[^"\\])*")\s*,\s*("(?:\\.|[^"\\])*")\s*\}',text)
assert len(programs)==9,len(programs)
rows=[]
for source,expected in programs:
 source=json.loads(source);expected=json.loads(expected)
 p=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=10)
 rows.append(dict(source=source,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),expected=expected,stdout=p.stdout,stderr=p.stderr,exitCode=p.returncode))
 assert p.returncode==0 and p.stdout==expected and not p.stderr,rows[-1]
(r/'python-controls.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),isolated=True,allNineMatch=True,cases=rows),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print('Nine isolated CPython controls match independent expected values.')
