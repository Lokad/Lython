from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(v['returncode']==0 for v in checks)
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));assert allocation['complete'] and allocation['allGoldensAndBudgetBaselineChecksPassed'] and allocation['allWorkersJoinedAndFixturesRemoved']
decision=dict(status='Retained implementation after focused correctness/ownership and allocation checks; CPU comparison and full delivery pending, not fully qualified',
 source=identity['coreSHA256']['candidate'],reference=identity['coreSHA256']['reference'],
 sourceFiles=581,changedProductionInputs=identity['changedProductionInputs'],
 focusedChecks='10internal/181public per actual11/10,382total;9isolated CPython3.13.2 controls',
 allocation=allocation['summary'],cpuAndElapsedImprovementMeasured=False,
 uncertainty='Complete invoice is effectively flat: the source already used the small direct-return entry. Fulfillment eliminates its owned wide-return tuple. No percentage of CPU is inferred from allocation.',
 removed='Owned large native helpers no longer construct the unobservable dynamic tuple before immediate exact unpack. Small and owned callers share return-span preparation/publication/retirement; old empty-span-only owned entry is replaced.',
 retained='Existing eager tuple admission, compiler eligibility, bound arrays, caller slots and native continuation. No new frame, owner, arena, policy, result protocol or public API.',
 contract='Targets publish after child cleanup. Failure tracks/retires written output references; suspension keeps ordinary values and no borrowed return span. Exact mismatched/starred and escaping tuples retain general semantics.',
 next='One bounded quiet-VM source-pair warm/fresh comparison with unchanged controls, preserve adverse results; batch full platform/stress/installed consumers at a coherent delivery boundary. Current CPython guide remains exact previously qualified7e2/frozen72.',
 toolingCorrection='Initial private Python-control extractor also selected an unrelated two-string expected-value array; bound extraction to the MemberData section. Original script retained. No runtime/assertion/measurement condition changed.',
 publicationHeld=True,performanceObjectiveStillActive=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-14-owned-native-tuple-returns');out.mkdir(exist_ok=False)
for name in ['decision.json','prospective.json','candidate-identity.json','focused-checks.json','python-controls.json','allocation-summary.json','worker-verification.json']:
 assert (r/name).exists(),name
 shutil.copyfile(r/name,out/name)
with tarfile.open(out/'sources-checks-and-allocation.tar.xz','w:xz')as archive:
 for name in ['candidate-core.dll','candidate-sources.tar.xz','catalog.json','candidate-build.log']:
  archive.add(r/name,arcname=name)
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ('.py','.log','.json') and p.name not in ['candidate-identity.json','catalog.json']:
   archive.add(p,arcname=p.name)
 for p in sorted(r.glob('Lokad.Lython.*/*.trx')):archive.add(p,arcname=p.relative_to(r))
 for name in ['Allocation.dll','Allocation.deps.json','Allocation.runtimeconfig.json']:
  assert (r/'candidate'/name).exists(),name
  archive.add(r/'candidate'/name,arcname='allocation-tool/'+name)
 for name in ['Allocation.csproj','Program.cs']:
  archive.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/source/'+name)
(out/'README.md').write_text('''# Native tuple returns over admitted bound storage

2026-11-14UTC, R353. Prototype frozen `9cfb7d5b`, three production inputs changed
from qualified7e2f7cac/frozen72c9. Runtime/evidence commit recorded subsequently.
**Focused correctness and allocation checks pass; CPU comparison and full
Windows/Ubuntu/stress/installed-consumer qualification remain pending.**
Publication/tagging and optional-adapter promotion remain held.

Larger eligible native helpers already execute in their admitted bound arrays,
but their owned entry supplied no direct-unpack destination. They therefore
constructed a temporary dynamic tuple before an immediate exact unpack. Reuse
the existing convention and share caller preparation/publication/retirement with
the small-helper entry. No new result protocol, frame, owner, arena or memory policy.
Eager tuple admission/conservative element funding remain. Child cleanup finishes
before target publication; failure tracks all output references. Real suspension
uses the ordinary native continuation and retains no borrowed caller span.

10internal/181public focused cases pass per actual .NET11/10 (382total), including
aliases/defaults, target mutation order, mismatched unpacking, actual delayed I/O,
cancellation, terminal refusal and shared-budget reuse. Nine isolated CPython3.13.2
goldens match. Initial private Python extractor accidentally included an unrelated
expected-value array; original script and correction survive. No semantic assertion
or runtime condition was relaxed.

Existing whole-script allocation tooling, fixed worker/adapter/catalog and two
fresh processes per source, reversed role order, normal GC/no forced collection:

| Complete script | Reference B/invocation | Candidate B/invocation | Change |
| --- | ---: | ---: | ---: |
| CSV fulfillment,4,096records |6,775,007.875|6,316,237.625|−6.77%|
| CSV invoice,4,096records |5,245,606|5,245,602.125–5,245,609.5|Effectively flat|
| Captured text,3,072lines |447,869.75|447,869.75|Flat|

All independent stdout/files, image hashes, budget baseline and joined-user checks
pass. Invoice already used the small direct-return entry, so its original hypothesized
gain does not appear. Absolute totals depend on harness/path; compare only within
this collection. **No CPU or elapsed improvement is inferred.** One bounded quiet-VM
warm/fresh comparison remains, with unchanged controls and adverse results retained;
full qualification follows a coherent delivery checkpoint. The current CPython guide
still measures the separately qualified7e2/frozen72 source. This does not complete
the broader whole-script performance objective.

[Decision](decision.json),[allocation](allocation-summary.json),
[sources/core/tools/checks/observations](sources-checks-and-allocation.tar.xz).
Reference sources/bits and full qualification remain in
[R351](../2026-11-14-compiled-literal-tuples/README.md).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');anchor='[R351 compiled literal tuples]'
assert anchor in s
s=s.replace(anchor,'''[R353 owned native tuple returns](results/2026-11-14-owned-native-tuple-returns/README.md)
reuse the existing direct-unpack convention over admitted larger helper storage
and share caller completion instead of constructing a temporary tuple.382focused
actual11/10 checks/9Python controls pass; complete fulfillment allocation−6.77%,
invoice/text effectively flat. CPU comparison/full delivery remain pending;
no CPU improvement or broader objective completion is claimed.

'''+anchor,1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-retained-focused.md').write_text(s,encoding='utf-8',newline='\n')
anchor='| Withdrawn / unresolved |';assert anchor in s
s=s.replace(anchor,'| R353, retained implementation; focused-qualified only | Frozen9cfb7d5b, three production inputs. Existing direct-unpack convention now covers admitted large-helper storage; shared caller completion removes tuple construction/duplicate logic.382focused actual11/10checks/9Python controls pass. Fulfillment allocation−6.77%, invoice/text effectively flat. Quiet-VM CPU/fresh comparison and full delivery pending; no CPU claim. [Evidence](benchmarks/results/2026-11-14-owned-native-tuple-returns/README.md). |\n'+anchor,1)
a=s.index('1. **R351/R352 delivery closed;');b=s.index('2. **Advance a substantial',a)
s=s[:a]+'''1. **Close the R353 return-convention migration, then advance the roadmap.**
   Focused actual11/10 checks and existing allocation diagnostics pass at9cfb7d5b.
   Larger helpers reuse the admitted bound array and existing direct-unpack return;
   caller preparation/publication/retirement is shared. Fulfillment removes112Bper
   row (~459KB/invocation),−6.77%allocation. Invoice was already eligible and is flat;
   unchanged captured text flat. No CPU/elapsed claim. Nine independent Python
   goldens, aliases/defaults, target order, mismatched unpacking, actual I/O,
   refusal/cancellation, cleanup and retained funding pass (382focused total).
   Next: one bounded quiet-VM warm/fresh source pair with unchanged text control;
   preserve all adverse/variable results, decide regression debt explicitly. Batch
   full platform/stress/installed consumers at a coherent retained delivery boundary.
   Do not repeat R351qualification or relabel its green status as R353qualification.
   Current CPython table remains exact7e2/frozen72. No new owner/arena/protocol;
   pending work never retains a borrowed return span. Preserve full preflight.
   [Evidence/status](benchmarks/results/2026-11-14-owned-native-tuple-returns/README.md).

'''+s[b:]
a=s.index('   **R353 selected bounded migration:**');b=s.index('   | Area / representative scripts |',a)
s=s[:a]+'''   R353's concrete tuple-construction boundary was selected from that call trace;
   its retained focused state/remaining measurement are deliverable1. Module
   mirroring is already demand-driven, so no duplicate namespace design is justified.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Saved retained focused R353 evidence; remaining CPU/full delivery explicit.')
