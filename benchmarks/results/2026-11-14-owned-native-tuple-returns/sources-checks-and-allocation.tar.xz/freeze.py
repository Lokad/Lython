from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'literal-tuples-r351/corrected'
reference=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(v['returncode']==0 for v in checks)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={p:sha(p)for p in reference['sources']}
changed=[p for p in sources if sources[p]!=reference['sources'][p]];assert len(changed)==3,changed
env=dict(os.environ);old=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'}
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+old
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={p:sha(p)for p in sources}
assert sha(prior/'candidate/Lokad.Lython.dll')=='72c9a1e5787eeaaaceae43abc521be95b2b0a1a6ead5e30f9986e42bf6ac69ee'
for role in ['reference','candidate']:shutil.copytree(prior/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='7e2f7cac',referenceQualification='GREEN43579225278 Windows/Ubuntu actual11/10, original stress and installed consumers;581source proof/16summaries cached',
 coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,
 removedMechanisms=['temporary dynamic tuple shell/backing and immediate unpack for owned large native helper returns','duplicated small-only caller return publication/retirement preparation'],
 newStorage='Existing eager tuple admission and caller slots remain; existing bound array serves the synchronous producer. No new frame/arena/storage owner/policy. Pending work transfers through the same native continuation without a retained return span.',
 auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for role in ['reference','candidate']:shutil.copyfile(r/'catalog.json',r/('allocation-'+role+'-catalog.json'))
shutil.copyfile(prior/'measure-allocation.py',r/'measure-allocation.py')
verify=(prior/'verify-worker.py').read_text(encoding='utf-8').replace("r.parent.parent/'utf8-byte-ownership-r334", "r.parent/'utf8-byte-ownership-r334")
(r/'verify-worker.py').write_text(verify,encoding='utf-8',newline='\n')
print('Frozen owned-return prototype',identity['coreSHA256'],'581inputs/3changed.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True,env=env)
