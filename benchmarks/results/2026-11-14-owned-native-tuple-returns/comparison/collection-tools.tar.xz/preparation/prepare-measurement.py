from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b725';out.mkdir(exist_ok=False)
prior=r.parent/'literal-tuples-r351/b723'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
source_proof=json.loads((r/'source-proof.json').read_text(encoding='utf-8'))
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head==source_proof['commit'] and source_proof['productionInputs']==581
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='f5817a15/frozen9cfb7d5b vs qualified7e2f7cac/frozen72c9a1e5',
 purpose='Owned large-helper direct tuple returns: same-source fulfillment warm/fresh, unchanged invoice and captured-text controls. Allocation is established separately; no external timing or cross-collection attribution.',
 coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},
 referenceCase='scripts.csv-fulfillment.large',variantCase='scripts.csv-fulfillment.large',
 sourceProofCommit=head,sourceProofSHA256=hashlib.sha256((r/'source-proof.json').read_bytes()).hexdigest())
identity.pop('controlCatalogSHA256',None)
assert all(source['auxiliaryFiles'][role][n]==sha for role in ['reference','candidate']for n,sha in identity[role+'AuxiliaryFiles'].items())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'source-identity.json').write_text(json.dumps(source,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('literal-tuples-b723-20261114','owned-return-b725-20261114').replace('lython-b723-literal-tuples-20261114','lython-b725-owned-return-20261114').replace('B723','B725')
 if name=='collect.py':
  s=s.replace("control_catalog = root / 'return-control.json'\ncases = {c['id']: c for p in [catalog,control_catalog] for c in json.loads(p.read_text())['cases']}","cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}")
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
  s=s.replace('len(jobs)==6','len(jobs)==4').replace('started < 420','started < 300')
 elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==4").replace('jobs=6','jobs=4')
 elif name=='retrieve.py':s=s.replace("['jobs']==6","['jobs']==4").replace("['elapsedSeconds']<480","['elapsedSeconds']<360").replace('six-job','four-job')
 elif name=='summarize.py':
  s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==4").replace('jobs=6','jobs=4').replace('constant-return diagnostic has isolated CPython3.13.2 output.','no diagnostic-only case is included.')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
inspection=json.loads((r/'vm-space-inspection.json').read_text(encoding='utf-8'))
proof=[]
for item,artifact in zip(inspection['oldCoreAliases'],['2026-11-14-captured-scalar-storage','2026-11-14-indexed-sequence-cursors']):
 canonical=Path('benchmarks/results')/artifact/'sources-checks-and-observations.tar.xz'
 blob=subprocess.check_output(['git','show',head+':'+canonical.as_posix()])
 assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:
  body=t.extractfile('candidate-core.dll').read()
 assert len(body)==item['bytes'] and item['links']==len(item['aliases'])
 proof.append(dict(canonicalCommit=head,canonicalArchive=canonical.as_posix(),canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',
  coreSHA256=hashlib.sha256(body).hexdigest(),bytes=len(body),aliases=item['aliases'],
  reason='Retire only superseded frozen71ba/8ae working hardlinks, all exact bytes preserved in canonical Git. Keep current72c9 reference/new9cfb candidate, all worker/adapter auxiliaries, catalogs, toolchains and unchanged254/252MiBfloors.'))
(out/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
config=dict(root='/home/lokad/lython-bench-checks/owned-return-b725-20261114',sourceRoot='/home/lokad/lython-bench-checks/literal-tuples-b723-20261114',
 catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b725-owned-return-20261114',identity=identity,proof=proof,
 payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);catalog=Path(config['catalogRoot'])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and all(p.parent==base and p.resolve()==p for p in [source,catalog])
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert(source/'exit-code.txt').read_text().strip()=='0'and json.loads((source/'archive-receipt.json').read_text())['complete']
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,sha in config['identity']['referenceAuxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(catalog/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 retired=[]
 for proof in config['proof']:
  inodes=set()
  for alias in proof['aliases']:
   p=base/alias;s=p.lstat()
   assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
   assert s.st_nlink==len(proof['aliases'])and s.st_size==proof['bytes']and digest(p)==proof['coreSHA256']
   inodes.add((s.st_dev,s.st_ino));retired.append(p)
  assert len(inodes)==1
 before=shutil.disk_usage(base).free
 assert before+sum(p['bytes']for p in config['proof'])>254*1024*1024+config['unpackedBytes']+32768
 for p in retired:p.unlink()
 receipt=dict(proof=config['proof'],freshIdleLease=True,allPathsUidsHashesAndCompleteAliasesProvedBeforeMutation=True,
  retiredOnly=[str(p)for p in retired],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,
  current72c9ReferenceAndAllAuxiliariesCatalogsToolchainsPreserved=True,floorsUnchanged=True)
 (base/'b725-proved-core-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+chr(10))
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+32768
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 assert digest(root/'candidate-core.dll')==config['identity']['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in config['identity'][role+'AuxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'candidate-core.dll',root/role/'Lokad.Lython.dll')
 os.link(catalog/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir()
 assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,floorsUnchanged=True,retirementReceipt=receipt))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b725-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=360','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=330)).isoformat(),ownerSeconds=360,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],source=identity['sourceRevision'],jobs=jobs,bound='One360sowner/300sjob-startguard,12sfull-request warmups,five1srotating batches/four processes. No automatic restart.',stopping='One usable source-pair CPU/fresh observation with all controls/adverse medians and gates; no CPython refresh or unchanged qualification.',retirement='Only superseded71ba/8ae core hardlinks with canonical Git byte/all-alias proof; current72reference/new9cfb candidate and all auxiliaries/catalogs/toolchains/floors remain.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(out/'PLAN-before-collection.md').write_text(s,encoding='utf-8',newline='\n')
s=s.replace('   Next: one bounded quiet-VM warm/fresh source pair with unchanged text control;',
 '   B725quiet-VM source pair is active: fulfillment warm/fresh, unchanged invoice/\n   captured-text controls,360sowner/300sjob-startguard; earliest observation'+(now+datetime.timedelta(seconds=330)).strftime('%H:%M:%S')+'UTC.\n   Only canonical-proven superseded71ba/8ae cores retired; current72reference/new9cfb\n   and all auxiliaries/catalogs/toolchains/floors preserved. No automatic restart;')
p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=330)).isoformat(),flush=True)
