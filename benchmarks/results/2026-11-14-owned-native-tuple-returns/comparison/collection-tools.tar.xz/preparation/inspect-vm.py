from pathlib import Path
import base64,json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
sources=[base/'captured-scalar-b720-20261114/candidate/Lokad.Lython.dll',base/'iteration-checkpoint-b717-20261114/candidate/Lokad.Lython.dll']
rows=[]
for source in sources:
 if not source.exists():rows.append(dict(source=str(source),missing=True));continue
 s=source.stat();aliases=[]
 for pattern in ['*/candidate-core.dll','*/reference-core.dll','*/candidate/Lokad.Lython.dll','*/reference/Lokad.Lython.dll']:
  for p in base.glob(pattern):
   a=p.stat()
   if (a.st_dev,a.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(p.relative_to(base)))
 rows.append(dict(source=str(source),bytes=s.st_size,links=s.st_nlink,aliases=sorted(set(aliases))))
print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,readOnly=True,workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout,oldCoreAliases=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8',timeout=30)
assert p.returncode==0,p.stderr
(r/'vm-space-inspection.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
