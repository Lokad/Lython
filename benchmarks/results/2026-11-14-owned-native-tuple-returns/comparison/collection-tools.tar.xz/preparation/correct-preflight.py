from pathlib import Path
import ast,base64,datetime,json,subprocess
r=Path(__file__).parent;out=r/'b725'
config=json.loads((out/'config.json').read_text(encoding='utf-8'))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
def remote(code,payload=b''):
 command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
 return subprocess.run(ssh+[command],input=payload,capture_output=True,timeout=45)
inspect='''from pathlib import Path
import json,os,subprocess
base=Path('/home/lokad/lython-bench-checks')
print(json.dumps(dict(fixtures=[dict(path=str(p),mounted=os.path.ismount(p),empty=not any(p.iterdir()))for p in base.glob('*/guest-fixtures')],rootExists=(base/'owned-return-b725-20261114').exists(),unit=subprocess.check_output(['systemctl','show','lython-b725-owned-return-20261114.service','--property=LoadState,MainPID'],text=True))))
'''
p=remote(inspect);assert p.returncode==0,p.stderr
d=json.loads(p.stdout);assert not d['rootExists']and 'LoadState=not-found'in d['unit']and 'MainPID=0'in d['unit']and all(not v['mounted'] for v in d['fixtures'])
(out/'preflight-inspection.json').write_bytes(p.stdout)
code=(out/'launch-command.py').read_text(encoding='utf-8')
old=" assert not any(base.glob('*/guest-fixtures'))"
assert old in code
code=code.replace(old," assert not any(os.path.ismount(p) for p in base.glob('*/guest-fixtures'))")
ast.parse(code);(out/'launch-corrected-command.py').write_text(code,encoding='utf-8',newline='\n')
p=remote(code,(out/'payload.tgz').read_bytes());(out/'launch-corrected.log').write_bytes(p.stdout+p.stderr)
assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=330)).isoformat(),ownerSeconds=360,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=config['identity']['purpose'],source=config['identity']['sourceRevision'],jobs=4,bound='One360sowner/300sjob-startguard,12sfull-request warmups,five1srotating batches/four processes. No automatic restart.',preflightCorrection='Initial guard rejected legacy unmounted fixture directories before staging/deletion/mount/service. Fresh read-only inspection proves no mounted fixture/new root/unit. Correct guard to absence of mounted fixtures; original source/log/condition preserved. This is the first measurement owner.',retirement='Only superseded71ba/8ae core hardlinks with canonical Git byte/all-alias proof; current72reference/new9cfb candidate and all auxiliaries/catalogs/toolchains/floors remain.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(out/'PLAN-before-collection.md').write_text(s,encoding='utf-8',newline='\n')
old='   Next: one bounded quiet-VM warm/fresh source pair with unchanged text control;'
assert old in s
s=s.replace(old,'   B725quiet-VM pair is active: fulfillment warm/fresh and unchanged invoice/text,\n   360sowner/300sjob-startguard; earliest observation'+(now+datetime.timedelta(seconds=330)).strftime('%H:%M:%S')+'UTC.\n   Initial preflight rejected legacy unmounted fixture directories before staging;\n   actual mount absence verified, first owner launched. Original guard/log preserved.\n   Only canonical-proven superseded71ba/8ae cores retired; current72reference/new9cfb\n   and all auxiliaries/catalogs/toolchains/floors remain. No automatic restart;')
p.write_text(s,encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode()if hasattr(p,'stdout')else 'First B725 measurement owner launched.',flush=True)
print('Observe after',(now+datetime.timedelta(seconds=330)).isoformat(),flush=True)
