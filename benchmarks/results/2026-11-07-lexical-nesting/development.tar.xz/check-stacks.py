from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).parent;focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
checks={}
for tfm in ['net11.0','net10.0']:
 probe=Path(f'tools/LythonProbe/bin/Release/{tfm}/Lokad.Lython.dll');assert hashlib.sha256(probe.read_bytes()).hexdigest()==focused['cores'][tfm]
 log=r/('subprocess-stacks-'+tfm+'.log');start=time.monotonic()
 with log.open('w',encoding='utf-8')as stream:
  done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter','Category!=Stress&FullyQualifiedName~ReviewHardening3Regression','--logger','console;verbosity=minimal'],env=env,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text(encoding='utf-8');checks[tfm]=dict(exitCode=done.returncode,elapsedSeconds=time.monotonic()-start,probeCore=focused['cores'][tfm],tail=text[-1400:]);print(tfm,text.splitlines()[-1],flush=True);assert done.returncode==0,text[-4000:]
(r/'subprocess-stacks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
print('Matching fresh probe cores and pathological managed-parser subprocess checks passed; original deadlines unchanged.')
