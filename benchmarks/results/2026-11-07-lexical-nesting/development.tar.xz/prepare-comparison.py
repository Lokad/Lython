from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;home=r.parent
checks=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,h in checks['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
for role in ['before','candidate']:
 target=r/'images'/role;shutil.copytree(home/'admission-reentry-r53/images/candidate',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink()
 shutil.copy2(r/'net11.0.before.dll'if role=='before'else r/'cores/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
shutil.copy2(home/'module-bindings-r49/catalog.json',r/'catalog.json')
s=(home/'admission-reentry-r53/measure.py').read_text(encoding='utf-8').replace("[('warm','sync'),('warm','async')]","[('compile','sync'),('fresh','sync'),('warm','sync')]")
(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(home/'admission-reentry-r53/summarize.py').read_text(encoding='utf-8').replace("['warm-sync','warm-async']","['compile-sync','fresh-sync','warm-sync']")
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
identity=dict(baseline='d04024ee production, documentation parentb7aad281; R53 fully qualifiedCI42393422539',candidate='R55 one lexical nesting pass, exact focused source/core inventory',cores={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},driverSHA256=hashlib.sha256((home/'integer-utf8-r45/tool/out/complete-jobs.dll').read_bytes()).hexdigest(),boundary='Unchanged R45 five-script driver/catalog,32warmups/image,5rotated rounds*4jobs, isolatedALCs/sharedCoreLib/hashseed/processGC, normalGC/tiering. Compile/fresh/warm separately, sync only; publicRun/reset/mediatedIO/fullgoldens/resultcleanup in warm/fresh. Compile includes disposable public compilation, fresh adds one command; no startup/finalcachedteardown. Desktop clocks diagnostic; no speed prediction or substantial-warm-CPU claim.')
(r/'comparison-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('R55 checked sources frozen for one short compile/fresh/warm-control diagnostic.')
