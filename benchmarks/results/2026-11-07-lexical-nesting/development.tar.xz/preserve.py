from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-lexical-nesting');out.mkdir(exist_ok=True)
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for p,h in focused['productionSources'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
for name in ['baseline.json','baseline-red.log','focused.json','subprocess-stacks.json','cpython-oracle.log','comparison-identity.json','local-summary.json']:shutil.copy2(r/name,out/name)
snapshot=r/'source-current';snapshot.mkdir()
for p in ['src/Lokad.Lython/Frontend/LythonFrontend.cs','src/Lokad.Lython/Frontend/PythonTokenization.cs','tests/Lokad.Lython.PublicApi.Tests/ParserCompatibilityTests.cs']:shutil.copy2(p,snapshot/Path(p).name)
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if p.is_file()and relative.parts[0]!='images':a.add(p,arcname=str(relative).replace('\\','/'))
decision=dict(retained=True,removed='96-line ExceedsSyntaxNestingLimit and CompilationLimitExceeded factory; whole duplicate source pass/quote-comment scanner. Existing tokenizer depth owns the same512delimiter ceiling; parser64/unary256/f-string/runtime managed bounds remain.',correctness='Both same-quote nested f-string literal cases fail baseline and pass through Run/RunAsync; independent isolatedCPython3.13.2 agrees. All3delimiter families retain pre-parse refusal. Earlier indentation/lexical errors can win on already-invalid source; no public signatures changed.',validation='802internal/1555public per actual.NET11/.NET10 plus14fresh matching-probe pathological subprocess checks per target pass, original deadlines/assertions unchanged.',measurement='One existing five-script compile/fresh/warm diagnostic, two baseline/one current isolated image, normalGC/tiering. All15golden/ownership/isolation/cleanup gates pass. Allocation effectively flat; elapsed mixed/adverse and unstable, including warm text+8.27to+20.07%/9.82%identical-baseline drift. No CPU benefit established or debt repayment. Full original samples retained.',reason='Retain coherent source/safety-invariant simplification and demonstrated valid-Python correction; not a performance-speedup claim or closure of whole-script objective. No unchanged favorable retiming or another small-change VM campaign.',fullDelivery='Pending Windows/Ubuntu Release actual11/10, original Stress and installed core consumers at this coherent retained boundary.',publication='postponed',archiveSHA256=hashlib.sha256((out/'development.tar.xz').read_bytes()).hexdigest())
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archiveBytes=(out/'development.tar.xz').stat().st_size,archiveSHA256=decision['archiveSHA256'],sources=len(focused['productionSources']))),flush=True)
