from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent;assert not(r/'focused.json').exists()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
oracle='''import json,sys
results=[]
for quote in ['"',"'"]:
 text='('*513;source='value = f'+quote+'{'+quote+text+quote+'}'+quote+'\\n'
 data={};exec(compile(source,'<same-quote>','exec'),data);assert data['value']==text
 results.append(dict(quote=quote,source=source,value=data['value']))
print(json.dumps(dict(version=sys.version,cases=results)))
'''
# The source separator is an actual newline in the subprocess program's value.
oracle=oracle.replace("+'\\n'","+'\\n'")
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',oracle],capture_output=True,text=True,encoding='utf-8');(r/'cpython-oracle.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
checks={}
for tfm in ['net11.0','net10.0']:
 steps=[('probe-'+tfm,['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',tfm])]
 for project,selection in [
  ('Lokad.Lython.Tests','Category!=Stress&(FullyQualifiedName~Parser|FullyQualifiedName~Frontend|FullyQualifiedName~Lexical|FullyQualifiedName~FString|FullyQualifiedName~FormattedString|FullyQualifiedName~Compilation|FullyQualifiedName~Compile|FullyQualifiedName~Cancellation|FullyQualifiedName~Ownership)'),
  ('Lokad.Lython.PublicApi.Tests','Category!=Stress&(FullyQualifiedName~Parser|FullyQualifiedName~Lexer|FullyQualifiedName~Frontend|FullyQualifiedName~FString|FullyQualifiedName~Formatted|FullyQualifiedName~Compilation|FullyQualifiedName~Compile|FullyQualifiedName~Cancellation|FullyQualifiedName~Refusal|FullyQualifiedName~Memory|FullyQualifiedName~Ownership)')]:
  steps.append((project+'-'+tfm,['test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--filter',selection,'--logger','console;verbosity=minimal']))
 for name,args in steps:
  log=r/(name+'.log');start=time.monotonic()
  with log.open('w',encoding='utf-8')as stream:done=subprocess.run([env['DOTNET_HOST_PATH']]+args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text(encoding='utf-8');checks[name]=dict(exitCode=done.returncode,arguments=args,elapsedSeconds=time.monotonic()-start,tail=text[-1800:])
  (r/'progress.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8');print(name,text.splitlines()[-1],flush=True);assert done.returncode==0,text[-4000:]
cores={}
for tfm in ['net11.0','net10.0']:
 target=r/'cores'/tfm;target.mkdir(parents=True)
 p=Path(f'src/Lokad.Lython/bin/Release/{tfm}/Lokad.Lython.dll');shutil.copy2(p,target/p.name);cores[tfm]=hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in ['bin','obj']for x in p.parts)}
(r/'focused.json').write_text(json.dumps(dict(checks=checks,cores=cores,productionSources=sources),indent=2)+'\n',encoding='utf-8');print('R55 focused actual11/10 with freshly built matching probes passed.',flush=True)
