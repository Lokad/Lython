from pathlib import Path
import shutil
r=Path(__file__).parent
shutil.copy2('tests/Lokad.Lython.PublicApi.Tests/ParserCompatibilityTests.cs',r/'baseline-red-test.cs')
p=Path('src/Lokad.Lython/Frontend/LythonFrontend.cs');s=p.read_text(encoding='utf-8')
a=s.index('        if (ExceedsSyntaxNestingLimit(');b=s.index('        source = NormalizeSourceText(source);',a);s=s[:a]+s[b:]
a=s.index('    private static FrontendResult CompilationLimitExceeded(');b=s.index('    private static string NormalizeSourceText(',a);s=s[:a]+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Frontend/PythonTokenization.cs');s=p.read_text(encoding='utf-8')
old='                if (token is Token.OpenParen or Token.OpenBracket or Token.OpenBrace) _depth++;'
assert old in s
s=s.replace(old,'''                if (token is Token.OpenParen or Token.OpenBracket or Token.OpenBrace)
                {
                    // Reuse lexical depth before any recursive parsing. Strings
                    // and f-string fields are handled by the shared scanner.
                    if (++_depth > LythonEngine.MaxSyntaxNesting)
                    {
                        _lexicalDiagnostic = new("LA0003",
                            $"Syntax nesting exceeds the maximum of {LythonEngine.MaxSyntaxNesting} levels.",
                            LythonDiagnosticSeverity.Error, null);
                        break;
                    }
                }''')
p.write_text(s,encoding='utf-8',newline='\n');print('R55 deleted whole-source nesting scanner and diagnostic factory; existing tokenizer depth owns admission.')
