
def run():
    value=9223372036854775806
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    old=read()
    for i in range(4):
     step()
     print(read())
    print(old,read() is read())
run()
