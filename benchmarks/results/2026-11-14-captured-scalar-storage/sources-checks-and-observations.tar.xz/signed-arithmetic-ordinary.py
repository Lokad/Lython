
def run():
    value=-9
    def step():
        nonlocal value
        try:
            value//=2
            value%=3
            value*=7
            value-=4
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    for i in range(3):
     step()
     print(read())
run()
