
def run():
    value=1000
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    print(locals()['value'],read())
    step()
    print(locals()['value'],read())
run()
