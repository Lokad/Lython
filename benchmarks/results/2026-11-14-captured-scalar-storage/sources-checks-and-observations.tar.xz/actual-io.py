snapshots=[]

def run():
    value=1000
    def step():
        nonlocal value
        value+=1
        with open('offset.txt') as source:offset=int(source.read())
        snapshots.append(value)
        value+=offset
        value+=1
        return value
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    first=step()
    second=step()
    print(first,second,snapshots,read(),second is read())
run()
