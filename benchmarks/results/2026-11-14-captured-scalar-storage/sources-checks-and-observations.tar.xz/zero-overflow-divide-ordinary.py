
def run():
    value=-9223372036854775808
    def step():
        nonlocal value
        try:
            value//=-1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    print(read())
    step()
    print(read())
run()
