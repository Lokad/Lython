from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'streamed-cased-r348';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['returncode']==0 for x in checks)
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'))
paths=[p for p in reference['sources']if Path(p).exists()]+['src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs']
assert len(paths)==len(set(paths))==581
sources={p:sha(p)for p in paths};removed=[p for p in reference['sources']if p not in sources]
changed=[p for p in sources if sources[p]!=reference['sources'].get(p)]
assert removed==['src/Lokad.Lython/Frontend/ExecutableScript.DictionaryAccumulation.cs']and len(changed)==8,(removed,changed)
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-3500:]
assert sources=={p:sha(p)for p in sources}
shutil.copytree(r/'reference',r/'candidate');shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='009d236a',referenceQualification='GREEN43563853239 full Windows/Ubuntu actual11/10, original stress and installed consumers. Test-onlyfc11817c separately focused-qualified.',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedProductionInputs=removed,removedMechanisms=['per-update boxed integer operands/results for prepared captured arithmetic','three-instruction scalar temporary transport on the admitted native segment','separate proposed compiler pass; facts now share existing preparation walk','three separate48Bcell estimate literals'],newStorage='One machine integer and current observed immutable identity in the existing cell;96Bconservative cell/current-value preflight. Ordinary values, mirrored namespaces, unbound and overflow use genuine original operations. No new memory policy/ledger/owner or tagged-value VM.',auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for name in sources:t.add(name,arcname=name)
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
for name in ['verify-worker.py','measure-allocation.py']:shutil.copyfile(prior/name,r/name)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('   Qualified8ae reference is frozen; implementation begins next.', '   Implementation is complete as a prototype: one existing compiler preparation\n   pass now handles dictionary and cell segments; old dictionary-only preparation\n   file/method and proposed extra pass are gone.167internal/746public per actual11/10\n   pass (1,826total), including29independent Python controls, actual I/O, namespace\n   transitions, first refusal, cancellation and retained results. Freeze'+identity['coreSHA256']['candidate'][:8]+'\n   has581inputs (8changed/1oldfile retired); no CPU/allocation benefit claimed yet.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Frozen R349',identity['coreSHA256'],'581inputs; copied full immutable worker images.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True)
