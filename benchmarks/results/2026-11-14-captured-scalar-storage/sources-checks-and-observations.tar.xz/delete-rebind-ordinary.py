
def run():
    value=1234
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    def erase():
     nonlocal value
     del value
    erase()
    try:step()
    except NameError:print('missing')
    replace(2000)
    step()
    print(read())
run()
