from pathlib import Path
import json,subprocess
r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
jobs=[('Lokad.Lython.Tests','(FullyQualifiedName~CapturedScalar|FullyQualifiedName~NativeClosure|FullyQualifiedName~ClosureRetention|FullyQualifiedName~ExecutableFrameStorage|FullyQualifiedName~SharedInteger|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~ClassCell|FullyQualifiedName~Super|FullyQualifiedName~Lexical|FullyQualifiedName~Nonlocal|FullyQualifiedName~Comprehension|FullyQualifiedName~SimpleFunctionExecutionBoundary)&Category!=Stress'),('Lokad.Lython.PublicApi.Tests','(FullyQualifiedName~CapturedScalar|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Locals|FullyQualifiedName~ClassCell|FullyQualifiedName~Super|FullyQualifiedName~ClassMethod|FullyQualifiedName~Comprehension|FullyQualifiedName~NativeInteger|FullyQualifiedName~SharedInteger|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~ForHelper|FullyQualifiedName~WhileHelper|FullyQualifiedName~MemoryDenialAttribution|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~IntegerAliasOwnership|FullyQualifiedName~ReturnedIteration)&Category!=Stress')]
checks=[]
for framework in ['net11.0','net10.0']:
 with(r/('probe-build-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([dotnet,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework],stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0
 for project,filter_ in jobs:
  label=project+'-'+framework
  with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([dotnet,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--filter',filter_,'--logger','trx','--results-directory',str(r/label)],stdout=f,stderr=subprocess.STDOUT)
  checks.append(dict(project=project,target=framework,returncode=done.returncode,filter=filter_));(r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
  print((r/(label+'.log')).read_text(encoding='utf-8')[-3400:],flush=True);assert done.returncode==0,label
