
def run():
    value=1000
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    old=read()
    return step,read,old
step,read,old=run()
step()
print(old,read(),read() is read())
