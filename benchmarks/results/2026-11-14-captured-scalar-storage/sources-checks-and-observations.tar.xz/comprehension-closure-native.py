
def run():
    value=1000
    def step():
        nonlocal value
        value+=1
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    readers=[lambda:value for i in range(2)]
    old=read()
    step()
    print(old,[f() for f in readers],readers[0]() is read())
run()
