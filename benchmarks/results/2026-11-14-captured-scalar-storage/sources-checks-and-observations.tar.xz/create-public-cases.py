from pathlib import Path
import hashlib,json,subprocess,tempfile,textwrap
r=Path(__file__).parent
def program(initial,body,tail,guarded=False,prefix=''):
 if guarded:body='try:\n'+textwrap.indent(body,'    ')+'\nfinally:\n    pass'
 return prefix+'\ndef run():\n    value='+initial+'\n    def step():\n        nonlocal value\n'+textwrap.indent(body,'        ')+'\n    def read():return value\n    def replace(new):\n        nonlocal value\n        value=new\n'+textwrap.indent(tail,'    ')+'\nrun()\n'
specs=[
 ('stable-identities','1000','value+=1',"old=read()\nstep()\nfirst=read()\nstep()\nsecond=read()\nprint(old,first,second,first is read(),second is read())\nprint(old is first,first is second,id(read())==id(read()))\nreplace(old)\nprint(read() is old)"),
 ('promotion','9223372036854775806','value+=1',"old=read()\nfor i in range(4):\n step()\n print(read())\nprint(old,read() is read())"),
 ('signed-arithmetic','-9','value//=2\nvalue%=3\nvalue*=7\nvalue-=4\nvalue+=1',"for i in range(3):\n step()\n print(read())"),
 ('bool-to-integer','True','value+=1',"old=read()\nstep()\nfirst=read()\nstep()\nprint(old,first,read(),type(read()).__name__)") ,
 ('zero-overflow-divide','-9223372036854775808','value//=-1',"step()\nprint(read())\nstep()\nprint(read())"),
 ('modulo-minimum','-9223372036854775808','value%=-1',"step()\nprint(read())"),
 ('delete-rebind','1234','value+=1',"def erase():\n nonlocal value\n del value\nerase()\ntry:step()\nexcept NameError:print('missing')\nreplace(2000)\nstep()\nprint(read())"),
 ('lambda-publication','1000','value+=1',"step()\nold=read()\nreader=lambda:value\nstep()\nprint(old,reader(),reader() is read())\nreplace(old)\nprint(reader() is old)"),
 ('locals-observation','1000','value+=1',"step()\nprint(locals()['value'],read())\nstep()\nprint(locals()['value'],read())"),
 ('comprehension-closure','1000','value+=1',"step()\nreaders=[lambda:value for i in range(2)]\nold=read()\nstep()\nprint(old,[f() for f in readers],readers[0]() is read())"),
 ('observable-reads','1000','value+=1\nreturn value',"snapshots=[step() for i in range(4)]\nprint(snapshots,read(),snapshots[-1] is read())\nprint(snapshots[0],snapshots[0] is snapshots[1])"),
 ('protected-error-order','1000','value+=1\ntry:\n value//=0\nexcept ZeroDivisionError:\n print(value)',"step()\nprint(read())"),
]
cases=[]
for name,initial,body,tail in specs:
 for guarded in [False,True]:cases.append((name+('-ordinary'if guarded else'-native'),program(initial,body,tail,guarded)))
for guarded in [False,True]:
 cases.append(('dynamic-protocol'+('-ordinary'if guarded else'-native'),program('Start()','value+=1',"old=read()\nstep()\nstep()\nprint(read(),events,type(old).__name__)",guarded,"events=[]\nclass Start:\n def __iadd__(self,other):\n  events.append(other)\n  return 42\n")))
 for source_name,tail in [('escaping-counter',"step()\nold=read()\nreturn step,read,old")]:
  source=program('1000','value+=1',tail,guarded).removesuffix('run()\n')+'step,read,old=run()\nstep()\nprint(old,read(),read() is read())\n'
  cases.append((source_name+('-ordinary'if guarded else'-native'),source))
io_source=program('1000',"value+=1\nwith open('offset.txt') as source:offset=int(source.read())\nsnapshots.append(value)\nvalue+=offset\nvalue+=1\nreturn value", "first=step()\nsecond=step()\nprint(first,second,snapshots,read(),second is read())",prefix='snapshots=[]\n')
cases.append(('actual-io',io_source))
records=[]
for name,source in cases:
 (r/(name+'.py')).write_text(source,encoding='utf-8',newline='\n')
 with tempfile.TemporaryDirectory(prefix='r349-python-')as folder:
  Path(folder,'offset.txt').write_text('2',encoding='utf-8')
  done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr,(name,done.stderr)
 (r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n')
 records.append(dict(name=name,source=source,expected=done.stdout,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),reference='CPython3.13.2 isolated',actualIo=name=='actual-io'))
(r/'python-controls.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
quoted=lambda value:json.dumps(value,ensure_ascii=False)
body='\n'.join('        yield return ['+','.join([quoted(v['name']),quoted(v['source']),quoted(v['expected']),'true'if v['actualIo']else'false'])+'];'for v in records)
test='''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class CapturedScalarExecutionTests
{
    // Exact isolated CPython 3.13 output for identity, promotion, namespace
    // publication and genuine protocol/I/O paths.
    public static IEnumerable<object[]> PythonControls()
    {
BODY
    }

    [Theory]
    [MemberData(nameof(PythonControls))]
    public async Task CapturedUpdatesPreservePythonValuesAndAliases(string name, string source, string expected, bool actualIo)
    {
        _ = name;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            var immediate = new MockLythonHost(); immediate.SeedFile("/offset.txt", "2");
            var delayed = new DelayedLythonHost(); delayed.SeedFile("/offset.txt", "2");
            using (var result = script.Run(immediate))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(expected, result.StandardOutput);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
            using (var result = await script.RunAsync(delayed))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(expected, result.StandardOutput);
            }
            if (actualIo)
            {
                Assert.True(delayed.CompletedAsynchronously > 0);
                Assert.Equal(2, immediate.ClosedFileCount);
                Assert.Equal(2, delayed.ClosedFileCount);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''.replace('BODY',body)
Path('tests/Lokad.Lython.PublicApi.Tests/CapturedScalarExecutionTests.cs').write_text(test,encoding='utf-8',newline='\n')
print('Created',len(records),'independent Python controls; each exercises both public execution APIs.')
