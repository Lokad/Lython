from pathlib import Path
import subprocess
r=Path(__file__).parent
args=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--filter','(FullyQualifiedName~CapturedScalarExecution|FullyQualifiedName~CooperativeCancellation)&Category!=Stress','--logger','trx','--results-directory',str(r/'public-initial-check')]
with(r/'public-initial-check.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
print((r/'public-initial-check.log').read_text(encoding='utf-8')[-8500:],flush=True);raise SystemExit(done.returncode)
