from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-captured-scalar-storage');out.mkdir(exist_ok=False)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
timing=json.loads((r/'b720/summary.json').read_text(encoding='utf-8'));assert timing['complete']
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));reads=json.loads((r/'observed-reads/allocation-summary.json').read_text(encoding='utf-8'))
assert all(x['returncode']==0 for x in json.loads((r/'focused-checks.json').read_text(encoding='utf-8')))
decision=dict(date='2026-11-14',decision='Retain coherent captured-cell representation for established whole-script allocation reduction. Batch full delivery next; CPU magnitude/attribution remains uncertain.',reference='009d236a/frozen8ae1ae5f',candidate='frozen71ba421c',removed=identity['removedMechanisms'],allocation='Captured complete text545,989.75 to447,725.75B,−17.9974%; direct/CSV controls effectively flat. Observing every update546,677.75 to546,685.75B,+8B; no per-update saving when identity is exposed.',timing='Captured warm−5.20..−7.60%, widerCPU−4.81..−6.89%. Unchanged direct-text elapsed−2.60..−8.43%,CPU−3.47..−7.91%,candidate process spread5.58%; do not attribute the observed CPU gain to cell changes. CSV elapsed−2.11..+0.57%,CPU−1.68..+0.89%. All raw adverse points retained.',debt=['96Bcell/current scalar preflight replaces48B; conservative earlier denial and larger cell metadata accepted','Frequent observation still boxes each update; CPU cost for that variant remains unmeasured','No release-wide speedup, exact heap peak, embedding latency or CPython ratio change established','Full platform/stress/installed-consumer qualification pending'],stopping='Representation selected and one bounded allocation/CPU/control comparison complete; no unchanged retiming needed to retain its allocation value. Continue substantial roadmap after coherent delivery.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for src,dst in [('decision.json','decision.json'),('candidate-identity.json','candidate-identity.json'),('b720/summary.json','timing-summary.json'),('b720/terminal-status.json','terminal-status.json'),('focused-checks.json','focused-checks.json')]:shutil.copyfile(r/src,out/dst)
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(r)
  if rel.parts[0]in ['reference','candidate','delivery']or p.name=='payload.tgz':continue
  t.add(p,arcname=rel.as_posix(),recursive=False)
with tarfile.open(out/'sources-checks-and-observations.tar.xz')as t:
 assert hashlib.sha256(t.extractfile('candidate-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
(out/'README.md').write_text('''# Captured scalar storage and publication

2026-11-14, R349: qualified `009d236a` / frozen `8ae1ae5f` versus
`71ba421c`. Retain a representation that removes per-update integer boxes and
three-instruction object transport for prepared captured arithmetic. An existing
authoritative cell keeps an exact machine integer; observation creates one stable
immutable identity. Older aliases remain unchanged and funded. General values,
mirrored namespaces, unbound cells and overflow retain ordinary operations.

The existing compiler preparation walk now handles dictionary and cell segments;
the dictionary-only file/method and proposed extra pass disappear. An unused
instruction field records the fact; instruction size and public API stay unchanged.
Both execution forms share the existing checked arithmetic kernel. Exception
boundaries, clean operand extents and cancellation-before-store stay explicit.
Three48Bcell creation/retention estimates consolidate into96Bfunding for metadata
and an observed current scalar. Earlier tiny-budget denial is accepted. This adds
no identity accounting, ownership policy, tracer, pool, arena or execution engine.

| Complete script | Allocation change | Warm elapsed change | Wider process CPU change |
| --- | ---: | ---: | ---: |
| Captured text counter,3,072lines /35,840B | −18.00% | −5.20..−7.60% | −4.81..−6.89% |
| Direct text, unchanged control | 0% | −2.60..−8.43% | −3.47..−7.91% |
| CSV fulfillment,4,096records /126,821B, control | effectively0% | −2.11..+0.57% | −1.68..+0.89% |

**Allocation reduction is established; CPU attribution is uncertain.** Captured
allocation falls545,989.75→447,725.75B across four fresh allocation processes.
Unchanged direct text also runs faster and has5.58%candidate process spread.
Captured process spreads are0.48%candidate/2.11%reference. Ranges compare every
pair of fresh process medians, not confidence intervals. Do not subtract control
percentages or claim that this change explains the entire elapsed difference.

An exposure diagnostic runs the same complete captured script with an assertion
reading the counter after every update. Both sources execute the identical changed
script and preserve output/files. Allocation is546,677.75→546,685.75B, just+8B.
Frequent observation necessarily retains per-update boxing; CPU cost for this
variant is unmeasured. This control has no local elapsed claim.

B720 uses the quiet F4as_v7 Ubuntu24.04.4/.NET11RC3 VM, normal GC/tiering,
unchanged worker/optional0.4adapter and identical source-pair scripts. Four fresh
processes/job,12s complete-request warmups, five1s batches. Warm clocks include
mediated RAM I/O, output/file validation and prior-result cleanup; exclude
compilation/startup, fixture reset/protocol and final cache teardown. Wider CPU
includes reset/protocol. No CPython timing, physical heap peak or embedding-tail
claim.225.65s remains inside the300s owner. All image/auxiliary/output/budget/
quiet/join/archive gates pass; no worker or RAM fixture remains. Raw SHA256:
`2ad6b17caabbdb2b0fc16850e6891125caa389922fdfdf92ec744926e0f9e68f`.

Before staging, only withdrawn4311's three working aliases and a duplicate failed
B718archive were retired after canonicalfc11817c Git/SHA/path/UID/all-alias proof.
Current8ae images, catalogs, toolchains and unchanged254/252MiBfloors survived.
All withdrawn evidence remains immutable in its canonical result.

167internal/746public focused cases per actual .NET11/10 pass (1,826total).
Twenty-nine isolated Python controls cover values, identity, namespaces, aliases,
promotion, errors, callbacks and genuine I/O under both APIs. Admission observers,
cooperative loops and retained results preserve first refusal, current values,
funding through cleanup and shared-budget reuse. Frozen581inputs include8changed
and one retired old file. Full platform/stress/installed-consumer qualification is
pending; later delivery is recorded separately. The previous CPython checkpoint
still measures009d, not this candidate. Publication/tagging stay held.

[Decision](decision.json),[timing](timing-summary.json),
[all sources/cores/tools/checks/raw observations](sources-checks-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');anchor='[R348 private cased-word inventory]';assert anchor in s
s=s.replace(anchor,'''[R349 captured scalar storage](results/2026-11-14-captured-scalar-storage/README.md)
retains authoritative machine integers in existing captured cells and materializes
stable Python identities on read. Whole captured-text allocation falls18.00%;
frequent-read allocation is flat (+8B). CPU/elapsed improve in B720, but unchanged
direct-text controls also improve with process variation, so attribution stays
uncertain. Existing compiler preparation/arithmetic are shared; no new owner or
execution engine.1,826focused actual11/10 cases pass; full delivery follows.

'''+anchor,1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('| Active prototype |','| Retained prototype, delivery pending |').replace('CPU/elapsed and full delivery pending. B720 three-job quiet comparison has240s work/300s owner.', 'B720 completes225.65s with all gates; captured warm−5.20..−7.60%/CPU−4.81..−6.89%, but faster variable direct controls make attribution uncertain. Frequent-read allocation+8B. Full delivery pending.').replace('Finish B720 after its bound (2026-11-14T07:31:47.827882+00:00); never restart\n   merely because observation times out. Retain/refine/withdraw based on value,\n   complexity and explicit regression debt. Batch full platform/stress/consumer\n   checks only for a retained coherent delivery; update current runtime docs.', 'B720 and frequent-read exposure checks are complete; retain for18%allocation\n   removal, with CPU attribution/frequent-read timing debt explicit. Current runtime\n   docs describe the representation and conservative funding. Commit and batch full\n   platform/stress/consumer delivery next. No unchanged retiming is needed for this\n   allocation decision. [Evidence](benchmarks/results/2026-11-14-captured-scalar-storage/README.md).');p.write_text(s,encoding='utf-8',newline='\n')
print('R349 decision/evidence/current docs saved; full delivery still pending.',flush=True)
