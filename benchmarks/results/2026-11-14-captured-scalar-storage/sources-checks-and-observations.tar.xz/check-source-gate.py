from pathlib import Path
import json,re,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent
args=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter','FullyQualifiedName~CapturedScalarObservation','--logger','trx','--logger','console;verbosity=detailed','--results-directory',str(r/'source-gate-check')]
with(r/'source-gate-check.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
text=(r/'source-gate-check.log').read_text(encoding='utf-8');print(text[-7500:],flush=True);assert done.returncode==0
facts=[]
for file in (r/'source-gate-check').glob('*.trx'):
 for node in ET.parse(file).iter():
  if node.tag.endswith('StdOut') and node.text:
   for line in node.text.splitlines():
    if 'R349FACTS ' in line:facts.append(json.loads(line.split('R349FACTS ',1)[1]))
assert facts and all(not f['ownerMirrors']and not f['ownerMirrorStores']and f['CanRunNativeInstructions']for f in facts),facts
(r/'observed-source-gate.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Observed native helper with unmirrored owning cell; current/retained scalar identity passes both APIs.')
