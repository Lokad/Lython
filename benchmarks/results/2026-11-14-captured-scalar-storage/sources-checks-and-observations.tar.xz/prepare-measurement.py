from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'streamed-cased-r348/b719';out=r/'b720';out.mkdir(exist_ok=False)
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['referenceAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R349frozen71ba421c vs qualified009d236a/frozen8ae1ae5f',purpose='Authoritative captured integer storage/lazy stable publication removes per-update boxing and operand transport. Identical captured/direct text and fulfillment control; no CPython replay.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.text-summary-helpers.nonlocal-counter.large',variantCase='scripts.text-summary-helpers.nonlocal-counter.large',controlCases=['scripts.text-summary.inline.large','scripts.csv-fulfillment.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('streamed-cased-b719-20261114','captured-scalar-b720-20261114').replace('lython-b719-streamed-cased-20261114','lython-b720-captured-scalar-20261114').replace('B719','B720').replace('Indexed-cursor source comparison','Captured-scalar source comparison')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('candidate-core.dll','candidate-core.dll'),('candidate-identity.json','source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/captured-scalar-b720-20261114',sourceRoot='/home/lokad/lython-bench-checks/streamed-cased-b719-20261114',unit='lython-b720-captured-scalar-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();source=Path(config['sourceRoot']);root=Path(config['root']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert source.parent==base and source.resolve()==source and root.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert(source/'exit-code.txt').read_text().strip()=='0'and not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert digest(source/'reference/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 for name,sha in config['identity']['referenceAuxiliaryFiles'].items():assert digest(source/'reference'/name)==sha
 assert digest(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes'],(before,config['unpackedBytes'])
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
  assert set(t.getnames())=={'collect.py','archive-owned.py','run.sh','identity.json','candidate-core.dll','source-identity.json'};t.extractall(root,filter='data')
 assert digest(root/'candidate-core.dll')==config['identity']['coreSHA256']['candidate']
 for name in ['representative.json','cpython-worker.py','reference-source-identity.json']:os.link(source/name,root/name)
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in config['identity'][role+'AuxiliaryFiles']:os.link(source/'reference'/name,root/role/name)
  os.link(source/'reference/Lokad.Lython.dll'if role=='reference'else root/'candidate-core.dll',root/role/'Lokad.Lython.dll')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=after,freshIdleLease=True,onlyFrozenImageHardlinks=True,floorsUnchanged=True))+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b720-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=300,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('no CPU/allocation benefit claimed yet.', 'local whole-script allocation−18.00%captured and flat controls, all users joined.\n   B720quiet comparison is active:240swork/300sowner; observe after'+(now+datetime.timedelta(seconds=240)).strftime('%H:%M:%S')+'UTC.\n   CPU/elapsed and complete delivery are unqualified.');p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
