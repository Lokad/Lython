from pathlib import Path
import json
r=Path(__file__).parent
for rel in ['../iteration-checkpoint-r347/b717/retrieved/representative.json','../iteration-checkpoint-r347/b717/representative.json','catalog.json']:
 p=r/rel
 if p.exists():
  catalog=json.loads(p.read_text(encoding='utf-8'))
  for c in catalog['cases']:
   if any(s in c['id']for s in ['search','invoice','text-summary-helpers']):
    print(c['id'],list(c))
    print(c.get('source',c.get('script')))
  break
for name in ['allocation-summary.json','worker-verification.json']:
 d=json.loads((r/name).read_text(encoding='utf-8'));print(name,{k:v for k,v in d.items()if k in ['summary','complete','allWorkersJoinedAndFixturesRemoved','allGoldensAndBudgetBaselineChecksPassed','elapsedSeconds']})
