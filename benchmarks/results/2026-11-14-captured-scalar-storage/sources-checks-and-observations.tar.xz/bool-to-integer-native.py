
def run():
    value=True
    def step():
        nonlocal value
        value+=1
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    old=read()
    step()
    first=read()
    step()
    print(old,first,read(),type(read()).__name__)
run()
