events=[]
class Start:
 def __iadd__(self,other):
  events.append(other)
  return 42

def run():
    value=Start()
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    old=read()
    step()
    step()
    print(read(),events,type(old).__name__)
run()
