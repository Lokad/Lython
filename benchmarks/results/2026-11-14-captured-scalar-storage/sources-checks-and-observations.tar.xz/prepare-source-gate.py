from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'streamed-cased-r348';reference=json.loads((prior/'reference-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items())
subprocess.run(['git','diff','--exit-code','009d236a','--','src'],check=True)
shutil.copytree(prior/'reference',r/'reference')
shutil.copyfile(prior/'reference-core.dll',r/'reference-core.dll');shutil.copyfile(prior/'reference-sources.tar.xz',r/'reference-sources.tar.xz')
assert hashlib.sha256((r/'reference-core.dll').read_bytes()).hexdigest()=='8ae1ae5fdf7b4a30526a2472044c1c5996ea41cf8733d94dc717f452417b7238'
record=dict(date='2026-11-14',state='source selection gate, not a runtime prototype',referenceProductionCommit='009d236a',referenceQualification='GREEN43563853239 full Windows/Ubuntu actual11/10, original stress and installed consumers. Latestfc11817c adds evidence and an independent focused-qualified retirement fixture only.',hypothesis='Give the existing authoritative captured cell cheap exact machine-integer storage and materialize a stable boxed value only when read or exposed. A prepared callback-free literal arithmetic segment can update that cell without object operands and three-instruction transport. General reads/writes and mirrored namespaces retain their Python behavior; no universal tagged-value VM or new execution route.',evidence=[
 'The identical3072-line captured text case has545,974..545,978allocatedB/job versus446,150 for direct inline text on frozen8ae. The99,824..99,828B difference also includes helper metadata/work; it is not a CPU attribution.',
 'The captured script increments one nonlocal BigInteger per input line. Existing object-valued ExecutableCell.Value plus augmented arithmetic boxes each published result;3072*32=98,304B is a source-supported candidate removal, not a measured speedup.',
 'R327/R342 do not establish a dominant removable call packet. Current native/deferred entries already use final slots and no duplicate frame, so another call arena is unjustified.',
 'PyDict native counters already demonstrate deferred immutable integer publication. ExecutableCell currently has one object value and owner/name links; namespace access and lambda retention publish through Value.',
 'Captured cells have48B preflights in work-state construction and closure retention. Any wider representation must consolidate/increase those capacity estimates before allocation.'
],gate=[
 'Verify actual captured script owner stays unmirrored during its native helper increments, and enumerate every namespace transition/value publication before implementing.',
 'Prove one cached materialized identity per current scalar preserves retained old aliases, repeated reads, id/is and rebinding. No per-object identity accounting, weak registration, tracing or refund for retained values.',
 'Use the same existing exact machine arithmetic/promotion kernel and compiler facts across native/ordinary execution. Consider an unused instruction metadata field only after verifying final-slot/exception-boundary preparation; do not widen every instruction or add a second backend.',
 'Unbound cells, dynamic/protocol values, observable namespaces and exact overflow must retain ordinary semantics and diagnostics before any write. Keep actual cancellation/refusal checks and cleanup ordering.',
 'Compute conservative cell/current-value storage and escaping retention preflights. No hidden allowance, scalar coupon/refcount, policy switch, new owner registry or default cache.'
],acceptance=['Native and ordinary Run/RunAsync agree on nonlocal updates, aliases/identity, nested closures, lambdas/comprehensions, locals/namespace exposure and escaping helpers','Large/negative integers, exact overflow, bool/custom numeric protocols, unbound/delete/rebind and Python-shaped failures preserve evaluation order','Real I/O/admission callbacks can observe the correct current counter; cancellation/terminal first refusal prevent later writes and all users join cleanup','Retained scalar aliases/results stay funded and sequential/shared-budget executions return baseline'],comparison='Reuse complete captured text and direct-inline/fulfillment controls with immutable8ae reference and existing workers. Separate short allocation from CPU/elapsed, measure metadata overhead and observable-read cases, preserve every adverse point. No unchanged CPython/catalog/full qualification replay. Batch full platform/stress/consumer checks at a coherent retained delivery.',stopping='Select or reject this exact cell representation from owning layout/lifetime facts. If justified, implement one coherent scalar-storage/publication change, delete displaced update transport, then decide whole-script value and regression debt. If it requires a broader namespace/identity redesign, record that obstacle before proceeding; do not silently weaken contracts. Performance objective stays active.')
(r/'prospective.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
newreference=dict(reference,referenceProductionCommit='009d236a',referenceQualification=record['referenceQualification'],coreSHA256={'reference':hashlib.sha256((r/'reference-core.dll').read_bytes()).hexdigest()},auxiliaryFiles={'reference':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/'reference').iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}},changedProductionInputs=[])
(r/'reference-identity.json').write_text(json.dumps(newreference,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');shutil.copyfile(p,r/'PLAN-before-source-gate.md');s=p.read_text(encoding='utf-8')
a=s.index('2. **Select the next substantial redesign');b=s.index('   | Area |',a)
s=s[:a]+'''2. **R349 source gate: authoritative captured-scalar storage/publication.**
   Existing3072-line captured text allocates about99.8KBmore than direct inline;
  3072boxed nonlocal increments alone are a plausible98,304Bremoval. This is not
   CPU dominance or a speedup prediction. Assess cheap exact integer storage in
   the existing cell, with stable boxed identity materialized only on observation.
   A shared prepared callback-free update would remove object operands/temporary
   transport; general values, exposed namespaces and overflow keep real ordinary
   semantics. No universal tagged VM, arena, controller or memory ledger.
   First prove actual owner mirroring/lifetime and every namespace publication,
   preserve old aliases/id/is, nonlocals, unbound/delete/rebind, exact promotion and
   Python errors. Consolidate existing48Bcell preflights into conservative expanded
   metadata/current-value funding, including escaped retention. Keep cancellation,
   first refusal, actual I/O observers and joined cleanup effective. If broader
   namespace/identity machinery is required, record the obstacle before expanding.
   Source gate selected and immutable qualified8ae reference copied; implementation
   is not started. Stop the gate once this bounded representation is selected or
   rejected. If justified, compare complete captured text, direct text and CSV
   controls with allocation/CPU separate, including observable-read costs; retire
   displaced update transport and explicitly decide regression debt. B717 remains
   the current external guide; no unchanged catalog or full qualification replay.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('R349 bounded source gate recorded; qualified8ae source/bits copied, no runtime mutation or speedup claim.')
