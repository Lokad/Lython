from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
r=Path(__file__).parent
archive=Path('benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/prototypes-checks-and-observations.tar.xz')
committed=subprocess.check_output(['git','show','fc11817c:'+archive.as_posix()])
assert hashlib.sha256(committed).digest()==hashlib.sha256(archive.read_bytes()).digest()
with tarfile.open(archive)as t:
 core=t.extractfile('candidate-core.dll').read()
 failed=t.extractfile('b718/failed-observations.tgz').read()
proof=dict(canonicalCommit='fc11817c',canonicalArchive=archive.as_posix(),archiveSHA256=hashlib.sha256(committed).hexdigest(),coreSHA256=hashlib.sha256(core).hexdigest(),coreBytes=len(core),failedSHA256=hashlib.sha256(failed).hexdigest(),failedBytes=len(failed),reason='Both R348 prototypes are withdrawn, evidence immutable in Git, all B718/B719 workers and mounts closed. Retire only the three aliases of withdrawn4311 and duplicate failed archive; preserve qualified8ae and all current catalogs/toolchains/floors.')
assert proof['coreSHA256']=='4311a05351160129dc52edcec033c1c511a3f3a7f7cf63a64f618a6f6725acae'
(r/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve();receipt=base/'b720-proved-withdrawn-retirement-20261114.json'
assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 roots=[base/'streamed-cased-b718-20261114',base/'streamed-cased-b719-20261114']
 assert all(p.resolve()==p and p.is_dir()and not(p/'guest-fixtures').exists()for p in roots)
 assert json.loads((roots[0]/'failed-closure.json').read_text())['guestFixturesRemoved']
 assert(roots[1]/'exit-code.txt').read_text().strip()=='0'
 paths=[roots[0]/'candidate-core.dll',roots[0]/'candidate/Lokad.Lython.dll',roots[1]/'candidate/Lokad.Lython.dll']
 originals=[]
 for p in paths:
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert s.st_size==proof['coreBytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['coreSHA256']
  originals.append(dict(path=str(p),inode=s.st_ino,device=s.st_dev,links=s.st_nlink,size=s.st_size,sha256=proof['coreSHA256']))
 assert len({(x['device'],x['inode'])for x in originals})==1 and all(x['links']==3 for x in originals)
 old=roots[0]/'failed-observations.tgz';s=old.lstat()
 assert old.resolve()==old and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
 assert s.st_size==proof['failedBytes']and hashlib.sha256(old.read_bytes()).hexdigest()==proof['failedSHA256']
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 old.unlink()
 after=shutil.disk_usage(base).free;assert after>before
 record=dict(proof=proof,allAliasesProvedBeforeMutation=True,freshIdleLease=True,retiredOnly=originals,duplicateFailedArchive=str(old),beforeFreeBytes=before,afterFreeBytes=after,current8aeAndCatalogsAndToolchainPreserved=True,floorsUnchanged=True)
 receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
'''.replace('PROOF',repr(proof))
compile(code,'retirement-command','exec');(r/'retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
(r/'retirement.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'retirement-receipt.json').write_text(done.stdout,encoding='utf-8',newline='\n');print(done.stdout,flush=True)
