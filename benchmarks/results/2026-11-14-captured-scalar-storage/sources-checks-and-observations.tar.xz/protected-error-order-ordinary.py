
def run():
    value=1000
    def step():
        nonlocal value
        try:
            value+=1
            try:
             value//=0
            except ZeroDivisionError:
             print(value)
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    print(read())
run()
