
def run():
    value=1000
    def step():
        nonlocal value
        value+=1
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    old=read()
    reader=lambda:value
    step()
    print(old,reader(),reader() is read())
    replace(old)
    print(reader() is old)
run()
