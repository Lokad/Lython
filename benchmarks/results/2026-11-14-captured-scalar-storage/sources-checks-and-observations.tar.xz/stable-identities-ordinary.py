
def run():
    value=1000
    def step():
        nonlocal value
        try:
            value+=1
        finally:
            pass
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    old=read()
    step()
    first=read()
    step()
    second=read()
    print(old,first,second,first is read(),second is read())
    print(old is first,first is second,id(read())==id(read()))
    replace(old)
    print(read() is old)
run()
