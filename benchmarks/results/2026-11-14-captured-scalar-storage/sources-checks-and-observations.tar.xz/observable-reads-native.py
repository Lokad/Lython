
def run():
    value=1000
    def step():
        nonlocal value
        value+=1
        return value
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    snapshots=[step() for i in range(4)]
    print(snapshots,read(),snapshots[-1] is read())
    print(snapshots[0],snapshots[0] is snapshots[1])
run()
