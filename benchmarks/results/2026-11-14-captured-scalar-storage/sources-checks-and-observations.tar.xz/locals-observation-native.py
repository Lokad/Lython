
def run():
    value=1000
    def step():
        nonlocal value
        value+=1
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    print(locals()['value'],read())
    step()
    print(locals()['value'],read())
run()
