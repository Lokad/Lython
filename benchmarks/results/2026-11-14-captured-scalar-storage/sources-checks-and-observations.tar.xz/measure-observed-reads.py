from pathlib import Path
import ast,hashlib,json,subprocess
r=Path(__file__).parent;out=r/'observed-reads';out.mkdir(exist_ok=False)
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
case=next(c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large')
assert case['source'].count('        processed += 1\n')==1
case['source']=case['source'].replace('        processed += 1\n','        processed += 1\n        assert processed > 0\n')
case['sourceSha256']=hashlib.sha256(case['source'].encode('utf-8')).hexdigest();case['sourceUtf8Bytes']=len(case['source'].encode('utf-8'));catalog['cases']=[case]
for role in ['reference','candidate']:(out/('allocation-'+role+'-catalog.json')).write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
script=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("(r/'candidate-identity.json')","(r.parent/'candidate-identity.json')").replace("folder=(r/role).resolve()","folder=(r.parent/role).resolve()")
ast.parse(script);(out/'measure-allocation.py').write_text(script,encoding='utf-8',newline='\n')
(out/'reason.json').write_text(json.dumps(dict(purpose='Allocation exposure control: the same complete captured script reads the updated integer at every line through an assertion. This deliberately prevents deferred boxing; both runtimes execute identical changed source. Output/files goldens remain unchanged; no local elapsed/CPU claim.',sourceAndScriptDifferIntentionally=False,modifiedComparedWithMainCatalog=True,referenceCore='8ae1ae5f',candidateCore='71ba421c'),indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True)
