
def run():
    value=-9223372036854775808
    def step():
        nonlocal value
        value%=-1
    def read():return value
    def replace(new):
        nonlocal value
        value=new
    step()
    print(read())
run()
