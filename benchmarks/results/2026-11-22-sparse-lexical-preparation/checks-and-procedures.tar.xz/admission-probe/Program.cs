using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
var engine = new LythonEngine();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var requests = new List<object>();
    var measured = new ObservedBudget(null, false);
    using (var code = engine.Compile(source, measured))
    {
        if (!code.IsValid)
            throw new InvalidOperationException(string.Join(", ", code.Diagnostics));
    }
    CheckRefund(measured);
    if (measured.Peak == 0)
        throw new InvalidOperationException("Expected working-storage growth beyond the initial compiler allowance.");
    // Refuse or cancel from inside a real frontend working-storage request.
    foreach (bool refuse in measured.Growth == 0 ? [] : new[] { false, true })
    {
        using var cancellation = new CancellationTokenSource();
        var interrupted = new ObservedBudget(cancellation, refuse);
        using (var code = engine.Compile(source, interrupted, cancellation.Token))
        {
            var diagnostic = code.Diagnostics.Single();
            if (code.IsValid || !cancellation.IsCancellationRequested ||
                diagnostic.Code != (refuse ? "LA0008" : "LA2011"))
                throw new InvalidOperationException($"Unexpected result {diagnostic}.");
            requests.Add(new { diagnostic.Code, diagnostic.Span, interrupted.Requested, interrupted.CallbackCount });
        }
        CheckRefund(interrupted);
        using (var reused = engine.Compile("pass", interrupted.Root))
            if (!reused.IsValid) throw new InvalidOperationException("Compiler did not recover after disposal.");
        CheckRefund(interrupted);
    }
    rows.Add(new { id = item.GetProperty("id").GetString(), measured.Peak, measured.Growth, interrupted = requests });
}
var image = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { image, rows }, new JsonSerializerOptions { WriteIndented = true }));

static void CheckRefund(ObservedBudget budget)
{
    if (budget.Root.ReservedBytes != 0)
        throw new InvalidOperationException($"Compiler retained {budget.Root.ReservedBytes} bytes.");
}

sealed class ObservedBudget(CancellationTokenSource? cancellation, bool refuse) : ILythonMemoryBudget
{
    internal readonly LythonMemoryBudget Root = new();
    internal long Peak, Requested;
    internal int Growth, CallbackCount;
    public ILythonMemoryScope CreateScope() => new Owner(this, Root.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Wrap(Root, bytes, out reservation);

    private bool Wrap(ILythonMemoryBudget owner, long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!owner.TryReserve(bytes, out var lease))
        {
            reservation = null;
            return false;
        }
        Peak = Math.Max(Peak, Root.ReservedBytes);
        reservation = new Reservation(this, lease);
        return true;
    }

    private sealed class Owner(ObservedBudget budget, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Owner(budget, inner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => budget.Wrap(inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(ObservedBudget budget, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            if (bytes > inner.Bytes)
            {
                ++budget.Growth;
                if (cancellationActive())
                {
                    ++budget.CallbackCount;
                    budget.Requested = bytes;
                    if (refusalActive()) return false;
                }
            }
            if (!inner.TryResize(bytes)) return false;
            budget.Peak = Math.Max(budget.Peak, budget.Root.ReservedBytes);
            return true;

            bool cancellationActive()
            {
                if (budget.Cancellation is null || budget.Growth != 1) return false;
                budget.Cancellation.Cancel();
                return true;
            }
            bool refusalActive() => budget.Refuse;
        }
        public void Dispose() => inner.Dispose();
    }
    private CancellationTokenSource? Cancellation => cancellation;
    private bool Refuse => refuse;
}
