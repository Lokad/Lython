from pathlib import Path
import gzip, hashlib, json, shutil, subprocess
lab=Path(".git/agent-notes/review-20261031/sparse-lexical-work-20261122")
base=lab.parent
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path, text):
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path, value):
    write(path, json.dumps(value,indent=2)+"\n")
def sha(data):
    return hashlib.sha256(data).hexdigest()

donor=base/"csv-quoted-ranges-20261122"
donor_files=read(donor/"identity.json")["imageFiles"]["candidate"]
ids={}
for role in ("reference","candidate"):
    dest=lab/"frozen"/role
    dest.mkdir(parents=True, exist_ok=True)
    for name,want in donor_files.items():
        src=donor/"frozen/candidate"/name
        assert sha(src.read_bytes())==want
        if role=="candidate" and name=="Lokad.Lython.dll":
            src=lab/"frozen-candidate-core.dll"
        shutil.copyfile(src,dest/name)
    ids[role]={name:sha((dest/name).read_bytes()) for name in donor_files}
assert ids["reference"]==donor_files and [name for name in donor_files if ids["reference"][name]!=ids["candidate"][name]]==["Lokad.Lython.dll"]
save(lab/"identity.json",dict(reference="745f8833f",candidate="d5abc29d4",imageFiles=ids))

directory="benchmarks/results/2026-11-20-direct-dict-enumeration/"
retire=[]
for part,remote in (
    ("", "direct-dict-enumeration-b1254-20261120"),
    ("narrow-frame/", "direct-dict-enumeration-narrow-b1255-20261120"),
):
    core=gzip.decompress(subprocess.check_output(["git","show","origin/master:"+directory+part+"measured-candidate-core.dll.gz"]))
    tgz=subprocess.check_output(["git","show","origin/master:"+directory+part+"observations.tgz"])
    assert len(core)==5680640
    retire.append(dict(paths=[remote+"/candidate/Lokad.Lython.dll"],bytes=len(core),sha256=sha(core),
                    links=1,archives={remote+"/observations.tgz":sha(tgz)},optional=False))
save(lab/"retire-proof.json",dict(proof=retire, canonicalLocation=directory))

prior=base/"lexical-leaf-preparation-20261121"
catalog=read(prior/"representative.json")
identifier="scripts.config-generated-guards.medium.bad-0"
original=next(c for c in catalog["cases"] if c["id"]==identifier)
sparse=dict(original)
sparse["id"]=original["id"]+".sparse-lexical"
assert sparse["source"].count("len(errors)") == 1
sparse["source"]=sparse["source"].replace("len(errors)","sum(1 for error in errors if error)")
encoded=sparse["source"].encode("utf-8")
sparse["sourceUtf8Bytes"]=len(encoded)
sparse["sourceSha256"]=sha(encoded)
catalog["cases"].append(sparse)
save(lab/"representative.json",catalog)

source=(prior/"prepare-quiet.py").read_text(encoding="utf-8")
edits={
    'prior = lab.parent / "latest-checkpoint-cpython-20261121"':'prior = lab.parent / "csv-quoted-ranges-20261122"',
    'retire = [proof["proof"]]':'retire = proof["proof"]',
    'sha(prior / "frozen" / name)':'sha(prior / "frozen/candidate" / name)',
    '"scripts.dataclass-inherited-configuration.generated"]':'"scripts.dataclass-inherited-configuration.generated", "scripts.config-generated-guards.medium.bad-0.sparse-lexical"]',
    'reference.startswith("4337b7765") and candidate.startswith("b8359d01a")':'reference.startswith("745f8833f") and candidate.startswith("d5abc29d4")',
    '(("Lokad.Lython.Tests", 111), ("Lokad.Lython.PublicApi.Tests", 962))':'(("Lokad.Lython.Tests", 111), ("Lokad.Lython.PublicApi.Tests", 984))',
    'prior_config["cpythonWorkerSHA256"]':'prior_config["protocolSHA256"]',
    'proof["caseCount"] == 3':'proof["caseCount"] == 4',
    'Avoid redundant lexical walks for leaf scopes':'Single suite walk and sparse lexical expression preparation',
    'lexical-leaf-preparation-b1309-20261121':'sparse-lexical-work-b1315-20261122',
    'lython-b1309-lexical-leaf-preparation-20261121':'lython-b1315-sparse-lexical-work-20261122',
    '(cases[0], "compile-run")]':'(cases[3], "compile"), (cases[3], "compile-run")]',
    '"len(jobs)==4"':'"len(jobs)==5"',
    '"jobs=4,"':'"jobs=5,"',
    '"len(raw[\'jobs\'])==4"':'"len(raw[\'jobs\'])==5"',
    '"[\'jobs\']==4"':'"[\'jobs\']==5"',
    'lython-b1309-fixtures':'lython-b1315-fixtures',
    '"Lexical leaf preparation comparison"))':'"Sparse lexical preparation comparison").replace("300", "310"))',
    '"len(raw[\\\'jobs\\\'])==4", "len(raw[\\\'jobs\\\'])==4"':'"len(raw[\\\'jobs\\\'])==4", "len(raw[\\\'jobs\\\'])==5"',
    'Prepared four lanes':'Prepared five lanes',
}
for old,new in edits.items():
    assert old in source,old
    source=source.replace(old,new)
compile(source,"prepare-quiet.py","exec")
write(lab/"prepare-quiet.py",source)
