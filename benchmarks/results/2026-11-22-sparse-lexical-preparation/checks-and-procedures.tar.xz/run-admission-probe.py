from pathlib import Path
import hashlib, json, os, shutil, subprocess
p=Path(".git/agent-notes/review-20261031/sparse-lexical-work-20261122")
project=p/"admission-probe/bin/Release/net11.0"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
cases=json.loads((p/"inspect-catalog.json").read_text(encoding="utf-8"))["cases"]
cases=[c for c in cases if c["id"] in ("scripts.config-generated-guards.medium.bad-0","ordinary-scopes-under-protection","complex-scopes-under-protection","postponed-module-annotation")]
cases+=json.loads((p/"wide-suites/catalog.json").read_text(encoding="utf-8"))["cases"][-2:]
catalog=p/"admission-probe/catalog.json"
catalog.write_text(json.dumps(dict(cases=cases), indent=2)+"\n",encoding="utf-8",newline="\n")
out=[]
for role in ("reference","candidate"):
    target=p/"admission-probe"/(role+"-first-growth")
    target.mkdir(exist_ok=False)
    for file in project.glob("*"):
        if file.is_file():shutil.copyfile(file,target/file.name)
    core=p/role/"compile/Lokad.Lython.dll"
    shutil.copyfile(core,target/core.name)
    report=p/"admission-probe"/f"{role}-first-growth.json"
    subprocess.run([sdk/"dotnet.exe",target/"AdmissionProbe.dll",catalog,report],env=env,check=True,timeout=25)
    parsed=json.loads(report.read_text(encoding="utf-8-sig"))
    assert parsed["image"].lower()==hashlib.sha256(core.read_bytes()).hexdigest()
    out.append(parsed["rows"])
for a,b in zip(*out,strict=True):
    assert a==b,(a,b)
    print(a["id"],"peak",a["Peak"],"working growths",a["Growth"],"interruption",[(row["Code"],row["Span"])for row in a["interrupted"]],flush=True)

assert sum(len(row["interrupted"]) for row in out[0]) >= 4
