from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess
lab=Path(".git/agent-notes/review-20261031/sparse-lexical-work-20261122").resolve()
identity=json.loads((lab/"quiet/identity.json").read_text(encoding="utf-8"))
catalog=lab/"quiet/representative.json"
out=lab/"representative-allocation"
out.mkdir()
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(catalog)==identity["catalogSHA256"]
tool_image={}
for role in ("reference","candidate"):
    dest=out/role
    dest.mkdir()
    for src in (lab/role/"compile").iterdir():
        if src.is_file(): shutil.copyfile(src,dest/src.name)
    core=lab/"frozen"/role/"Lokad.Lython.dll"
    assert sha(core)==identity["coreSHA256"][role]
    shutil.copyfile(core,dest/core.name)
    tool_image[role]={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
(out/"hashes.json").write_text(json.dumps(tool_image,indent=2)+"\n",encoding="utf-8",newline="\n")
runs=[]
for i,role in enumerate(("reference","candidate","candidate","reference")):
    image=out/role
    proof=out/f"{role}-{i}.json"
    assert {p.name:sha(p) for p in image.iterdir() if p.is_file()}==tool_image[role]
    subprocess.run([sdk/"dotnet.exe",image/"Lokad.Lython.WhiteBox.Tests.dll",catalog,proof],env=env,check=True,timeout=50)
    raw=json.loads(proof.read_text(encoding="utf-8-sig"))
    assert raw["imageSHA256"]==identity["coreSHA256"][role] and raw["catalogSHA256"]==identity["catalogSHA256"]
    runs.append(raw["rows"])
summary=[]
for group in zip(*runs,strict=True):
    assert len({row["id"] for row in group})==1
    allocations=[statistics.median(s["compileBytes"] for s in row["samples"]) for row in group]
    before=statistics.mean(allocations[::3])
    after=statistics.mean(allocations[1:3])
    row=dict(id=group[0]["id"],bytes=allocations,changeBytes=after-before,changePercent=100*(after/before-1))
    summary.append(row)
    print(row,flush=True)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
