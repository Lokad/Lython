from pathlib import Path
import hashlib, json, os, statistics, subprocess

lab = Path(".git/agent-notes/review-20261031/sparse-lexical-work-20261122").resolve()
repo = lab.parents[3]
prior = json.loads((lab/"inspection-identity.json").read_text(encoding="utf-8"))
out = lab / "wide-suites"
out.mkdir(exist_ok=True)
catalog = out / "catalog.json"
cases = []
for branches, lines in ((16, 64), (32,128)):
    for complex_lexical in (False,True):
        suite = ["class Base:", " def value(self): return 1", "class Report(Base):",
                 " def run(self, n):", "  score = 0", "  try:"]
        for column in range(branches):
            suite.append(f"   if n == {column}:")
            suite.extend(f"    score += {i+column}" for i in range(lines))
        suite.extend(("  finally:", "   score += " + ("super().value()" if complex_lexical else "1"),
                      "  return score", "print(Report().run(0))"))
        cases.append(dict(id=f'wide-{branches*lines}-{"complex" if complex_lexical else "ordinary"}', source="\n".join(suite)+"\n"))
catalog.write_text(json.dumps(dict(cases=cases),indent=2)+"\n",encoding="utf-8",newline="\n")

sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
runs=[]
fresh=[]
for role in ("reference","candidate"):
    src=lab/role/"inspect"
    assert prior["workerImages"][role]["inspect"] == {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in src.iterdir() if p.is_file()}
    path=out/f"{role}-metadata.json"
    subprocess.run([dotnet,src/"Inspect.dll",catalog,path],env=env,check=True,timeout=35)
    fresh.append(json.loads(path.read_text(encoding="utf-8-sig"))["rows"])
assert fresh[0]==fresh[1]
print("Exact metadata for large ordinary and complex suites:",sum(len(r["codes"]) for r in fresh[0]),flush=True)
for i, role in enumerate(("reference","candidate","candidate","reference")):
    folder = lab / role / "compile"
    actual = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}
    assert actual == prior["workerImages"][role]["compile"]
    path = out/f"{role}-{i}.json"
    subprocess.run([dotnet,folder/"Lokad.Lython.WhiteBox.Tests.dll",catalog,path],env=env,check=True,timeout=60)
    raw=json.loads(path.read_text(encoding="utf-8-sig"))
    assert raw["imageSHA256"]==actual["Lokad.Lython.dll"] and raw["catalogSHA256"]==hashlib.sha256(catalog.read_bytes()).hexdigest()
    runs.append(raw["rows"])
rows=[]
for group in zip(*runs,strict=True):
    assert len({row["id"] for row in group})==1
    allocations=[statistics.median(s["compileBytes"] for s in row["samples"]) for row in group]
    before=statistics.mean(allocations[::3])
    after=statistics.mean(allocations[1:3])
    row=dict(id=group[0]["id"],bytes=allocations,changeBytes=after-before,changePercent=100*(after/before-1))
    rows.append(row)
    print(row,flush=True)
(out/"summary.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
