set -eu
root=/home/lokad/lython-bench-checks/sparse-lexical-work-b1315-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
