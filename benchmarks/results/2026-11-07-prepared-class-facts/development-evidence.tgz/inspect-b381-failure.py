from pathlib import Path
import json,subprocess
root=Path(__file__).parent
script=r'''from pathlib import Path
import json,subprocess
root=Path('/home/lokad/lython-bench-checks/prepared-class-facts-b381-20261107')
journal=subprocess.run(['journalctl','-u','lython-b381-prepared-class-facts-20261107.service','--no-pager','-n','65'],capture_output=True,text=True)
confirmation=root/'confirmation/confirmation.json'
data=json.loads(confirmation.read_text()) if confirmation.exists() else None
print(json.dumps(dict(journal=journal.stdout,complete=data.get('complete') if data else None,jobs=[dict(case=j.get('case'),lane=j.get('lane'),samples=len(j.get('samples',[]))) for j in data.get('jobs',[])] if data else [],files=[str(p.relative_to(root)) for p in (root/'confirmation').glob('*')])))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=script,text=True,encoding='utf-8',capture_output=True);assert result.returncode==0,result.stderr
(root/'b381/failure-inspection.json').write_text(result.stdout,encoding='utf-8',newline='\n')
data=json.loads(result.stdout);print(data['journal']);print({k:v for k,v in data.items() if k!='journal'})
