def make(value):
    class Base:
        def amount(self): return value
    class Row(Base):
        def amount(self): return super().amount() + 1
        def owner(self): return __class__
    return Row()
total = 0
for i in range(32):
    row = make(i)
    assert row.owner() is type(row)
    total += row.amount()
print(total)
