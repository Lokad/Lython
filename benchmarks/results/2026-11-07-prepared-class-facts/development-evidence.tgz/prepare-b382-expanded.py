from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home/'b382';root.mkdir()
old=home.parent/'execution-transport-r29/b378';prior='/home/lokad/lython-bench-checks/completed-helpers-b378-20261107';remote='/home/lokad/lython-bench-checks/prepared-class-facts-b382-20261107'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,s):
    with (root/name).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
baseline=json.loads((home/'baseline-full.json').read_text(encoding='utf-8'));priorid=json.loads((old/'identity.json').read_text(encoding='utf-8'))
assert baseline['sourceSHA256']==priorid['sourceSHA256'],'Reference binary must match all current baseline production source'
checks=json.loads((home/'focused-initial.json').read_text(encoding='utf-8'));core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
assert sha(core)==checks['coreSHA256']['net11.0']
identity=dict(sourceRevision='e9b55acd/81036f25 runtime plus R30 prepared class own-cell facts; frozen after focused checks',referenceSourceRevision='81036f25 runtime, frozen B37832dcf141; all baseline production source hashes identical',purpose='R30 prepared class facts: class-factory compile/warm/fresh and unchanged text compile/warm, two baseline/two current',qualification=checks,coreSHA256=dict(candidate=sha(core),control=sha(core),reference=priorid['coreSHA256']['candidate']),auxiliaryFiles=priorid['auxiliaryFiles'],sourceSHA256={str(p).replace('\\','/'):sha(p) for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)})
identity['coreSHA256']['reference-control']=identity['coreSHA256']['reference']
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/core.name);shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
write('contract.md','R30 computes the existing pure class-own-cell predicate with prepared lexical facts and removes its repeated runtime syntax walk. Fresh cells/enclosing captures remain separate. Focus382internal/1921public per actual11/10 pass, plus class factory32 iterations/two classes each independently matches CPython3.13.2 on both APIs/targets. Precise local diagnostic: compilation+1048B(+0.77%), warm allocation-29980B(-7.75%), admitted peaks unchanged. Unchanged desktop text clocks are adverse, preserved and not dismissed as noise. This single quiet confirmation decides retention/regression debt: five complete jobs, class-factory compile/warm/compile-run and text compile/warm. Same frozen R2932dcf141 reference, b94fa98c worker/host/optional0.4 adapter and normal GC/tiering. Two baseline/two current processes,5s warmup per role, seven rotated150ms rounds. Compilation separate from execution/I/O; warm/fresh include mediated RAM I/O, full checks and prior-result cleanup, fresh adds compilation/program disposal. Exclude startup/staging/reset/final teardown. All Ready/goldens/budget0/quiet/Closed/joins/fixture/persistent-under-lease archive gates required. No CPU prediction, source-pair compounding or claim that this closes the larger performance objective.210s owner+30s stop+40s margin: no SSH before280s after acknowledgment. No retries after refused admission.\n')
write('setup-contract.json',json.dumps(dict(reference=prior+'/candidate',roles=['candidate','reference','control','reference-control'],ownerSeconds=210,stopSeconds=30,observeAfterSeconds=280,controls=['scripts.text-summary-helpers.large compile','scripts.text-summary-helpers.large warm'],diskHeadroomBytes=2*1024*1024),indent=2)+'\n')
template=home.parent/'csv-record-values-r25/b372'
for name in ['collect.py','archive-owned.py','run.sh']:
    content=(template/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/csv-record-values-b372-20261107',remote)
    if name=='collect.py':
        lines=content.splitlines()
        jobline=next(line for line in lines if line.startswith('jobs=['))
        content=content.replace(jobline,"jobs=[('scripts.class-factory.small','compile'),('scripts.class-factory.small','warm'),('scripts.class-factory.small','compile-run'),('scripts.text-summary-helpers.large','compile'),('scripts.text-summary-helpers.large','warm')]")
    content=content.replace('len(jobs)==5','len(jobs)==5').replace("len(r['jobs'])==5","len(r['jobs'])==5").replace('jobs=5','jobs=5')
    content=content.replace('R25 direct completed-record values: ordinary/native CSV, public reader, text and JSON compile controls; not a CPython refresh',identity['purpose'])
    content=content.replace('time.monotonic()-started < 110','time.monotonic()-started < 140').replace('Reserve30 seconds for final owned work/cleanup.','Reserve40 seconds for final owned work/cleanup.')
    content=content.replace("labels=['candidate','reference','control']", "labels=['candidate','reference','control','reference-control']")
    content=content.replace("('reference' if label == 'reference' else 'candidate')", "('reference' if label.startswith('reference') else 'candidate')")
    content=content.replace('time.monotonic()-started < 140','time.monotonic()-started < 170').replace('Reserve40 seconds for final owned work/cleanup.','Reserve40 seconds for final owned work/cleanup.')
    write(name,content)
shutil.copyfile(home/'catalog.json',root/'representative.json')
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['representative.json','identity.json','pre-measurement-plan.md','source.patch','contract.md','setup-contract.json','collect.py','archive-owned.py','run.sh']:a.add(root/name,arcname=name)
data=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');prior=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+2*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['cpython-worker.py']:(root/name).symlink_to(prior/name)
 (root/'reference').symlink_to(prior/'candidate',target_is_directory=True)
 (root/'candidate').symlink_to(Path('/home/lokad/lython-bench-checks/prepared-class-facts-b381-20261107/candidate'),target_is_directory=True)
 identity=json.loads((root/'identity.json').read_text());cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert all(c in cases for c in ['scripts.class-factory.small','scripts.text-summary-helpers.large'])
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:
  text=(root/name).read_text();assert str(root) in text and 'b381' not in text;compile(text,str(root/name),'exec')
 assert str(root) in (root/'run.sh').read_text() and 'b381' not in (root/'run.sh').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>2*1024*1024
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allFiveCatalogJobsValidated=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b382-prepared-class-facts-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(data))).replace('PAYLOADHASH',hashlib.sha256(data).hexdigest())
write('launch.py',script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b382-launch.py'],capture_output=True);assert p.returncode==0,p.stderr
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b382-launch.py'],input=data,capture_output=True)
(root/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8');print((p.stdout+p.stderr).decode('utf-8'),flush=True)
