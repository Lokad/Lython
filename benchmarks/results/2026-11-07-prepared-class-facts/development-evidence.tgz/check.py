from pathlib import Path
import ast
root=Path(__file__).parent
source=(root.parent/'execution-transport-r29/check.py').read_text(encoding='utf-8')
start=source.index('families=[');end=source.index('\nselection=',start)
source=source[:start]+"families=['Class','Scope','Super','Annotation','Generator','SharedMemory','GovernedMemory','Cancellation']"+source[end:]
ast.parse(source);(root/'focused.py').write_text(source,encoding='utf-8',newline='\n')
exec(compile(source,str(root/'focused.py'),'exec'),{'__file__':str(root/'focused.py')})
