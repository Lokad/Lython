from pathlib import Path
import datetime,json,subprocess,sys
home=Path('.git/agent-notes/review-20261031/compiler-class-facts-r30')
b=json.loads((home/'b382/observe-not-before.json').read_text(encoding='utf-8'))
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(b['doNotObserveBeforeUTC'])
r=subprocess.run([sys.executable,'-X','utf8',str(home/'retrieve-b382.py')]);assert r.returncode==0
r=subprocess.run([sys.executable,'-X','utf8',str(home/'summarize-b382.py')]);assert r.returncode==0
