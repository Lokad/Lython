from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('.git/agent-notes/review-20261031/compiler-class-facts-r30');out=Path('benchmarks/results/2026-11-07-prepared-class-facts');out.mkdir()
checks=json.loads((root/'focused-initial.json').read_text(encoding='utf-8'))
for framework in ['net11.0','net10.0']:
    image=Path('src/Lokad.Lython/bin/Release')/framework/'Lokad.Lython.dll'
    assert hashlib.sha256(image.read_bytes()).hexdigest()==checks['coreSHA256'][framework]
for name in ['focused-initial.json','summary.json','comparison-summary.json','probes.json','catalog-verification.json']:
    shutil.copyfile(root/name,out/name)
for case,names in [('b381',['failed-observations.tgz','failed-receipt.json']),('b382',['observations.tgz','archive-receipt.json'])]:
    (out/case).mkdir()
    for name in names:shutil.copyfile(root/case/name,out/case/name)
(root/'runtime.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
with tarfile.open(out/'development-evidence.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.is_file():a.add(p,arcname=p.name)
    for name in ['compile','warm']:
        for p in (root/name).rglob('*'):
            if p.is_file():a.add(p,arcname=p.relative_to(root))
    for name in ['b381','b382']:
        for p in (root/name).iterdir():
            if p.is_file() and p.suffix not in ['.dll','.tgz']:a.add(p,arcname=p.relative_to(root))
    for framework in ['net11.0','net10.0']:
        a.add(Path('src/Lokad.Lython/bin/Release')/framework/'Lokad.Lython.dll',arcname=f'checked-images/{framework}/Lokad.Lython.dll')
    for name in ['Program.cs','CompleteJobDiagnostics.csproj']:
        p=root/'tool'/name
        if p.exists():a.add(p,arcname='tool/'+name)
archives={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*.tgz')}
(out/'sha256.json').write_text(json.dumps(archives,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Prepared class lexical facts — R30

2026-11-07. Retain the existing class-own-cell predicate in prepared lexical facts
and remove its repeated runtime syntax walk. Creating a class cell remains distinct
from capturing an enclosing one. Fresh function, class, closure and cell identity
stay invocation-owned. No new cache, execution route or memory mechanism.

Source: e9b55acd plus the two-file runtime patch in development-evidence.tgz.
Frozen candidate net11 75e60e66 / net10 89ee0097, reference R29 81036f25 / 32dcf141.
Complete source inventories and loaded-image hashes are preserved. Class-own-cell
analysis still exists in compilation; no dormant visitor is retained.

## Correctness and allocation

Release solution build: zero warnings/errors. Per actual .NET 11/.NET 10,
382 internal and 1,921 public focused cases pass: class/scope/super, annotations,
generators, cooperative cancellation and shared memory ownership. Four public
sync/async/actual-target probes independently match CPython 3.13.2.

The affected diagnostic constructs two classes per factory call, with 32 calls,
zero-argument super, an enclosing captured value and an explicit __class__ read.
Compilation allocation increases 1,048 B (+0.77%); warm execution removes 29,980 B
(7.75%). Admitted execution/root peaks stay unchanged. The unchanged text script's
allocation is flat. All output/file goldens, final balances and cleanup pass.

Precise process allocation uses existing complete-job diagnostics, 32 warmups,
five rotated rounds of 16 jobs, isolated before/current/identical-before images.
Desktop clocks remain diagnostic. The adverse text result (10.046 ms current vs
8.791–9.101 ms before) is preserved, not explained away or hidden.

## Bounded quiet-machine confirmation

B382: quiet Azure F4as_v7, Ubuntu 24.04.4, .NET 11 RC3, ordinary GC/tiering;
unchanged b94fa98c comparison worker/host and normal optional 0.4 adapter.
Five complete jobs, two before/two current processes, 5 s warmup per role,
seven rotated 150 ms rounds. 139.51 s; every Ready identity, output/file golden,
final funding, quiet endpoint, Closed/join/fixture and persistent archive gate passes.
Observation follows the full 210 s owner + 30 s stop + 40 s margin. No live work.

| Case / boundary | Before roles | Current roles | Elapsed change, all pairings |
| --- | ---: | ---: | ---: |
| Class factory, compile | 40.796–40.913 µs | 41.200–41.327 µs | +0.70–1.30% |
| Class factory, warm | 180.892–181.133 µs | 169.702–170.345 µs | −5.83–6.31% |
| Class factory, compile-to-result | 241.999–244.094 µs | 231.090–233.167 µs | −3.65–5.33% |
| Unchanged text, compile | 53.676–54.271 µs | 53.753–54.490 µs | −0.95 to +1.52% |
| Unchanged text, warm | 2.027–2.043 ms | 2.001–2.020 ms | −0.35–2.04% |

Compile is measured separately. Warm/fresh include mediated RAM I/O, full result
validation and prior-result cleanup; fresh adds compilation/program disposal.
Startup, staging/reset and final teardown are excluded. Class warm role spreads
are below 0.4%; fresh below 0.9%. Coarse external CPU is recorded, without a causal
or broad CPU claim. This synthetic class workload is not a representative CPython
refresh. The original desktop text adverse result is not reproduced here; its cause
remains unresolved. Retain the simplification and measured class-workload benefit;
accept the small compile cost. No broad speedup or compound debt repayment claim.

B381 failed before Ready: case size32 disagreed with embedded fixture size256.
It collected no timings; original catalog/source/failure archive are retained.
Correction changes metadata only, preserving Python source and empty file maps.
Normal supervised Lython/CPython catalog verification passes before B382. The local
allocation diagnostic used the original metadata but the identical script/fixtures;
its original identity is preserved separately. No runtime retiming refinement.

Full platform, original Stress and installed consumers are batched for the next
coherent runtime delivery. R29's completed qualification does not cover R30.
The complete-script performance objective remains active; publication postponed.
''',encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');old='module bindings never supply lexical class cells to child functions.';assert old in s;s=s.replace(old,old+'\nClass creation reads its prepared own-cell requirement; it does not repeat lexical\nsyntax analysis at execution. Each created class still owns its fresh cell.');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','## 0.11.0 - Unreleased\n\n- Prepare class own-cell requirements with lexical facts, removing repeated syntax\n  analysis during class creation while preserving fresh class/closure cells.\n',1);p.write_text(s,encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''
## Prepared class lexical facts (2026-11-07)

[R30/B382](results/2026-11-07-prepared-class-facts/README.md) moves the class-own-cell
syntax walk into existing prepared facts. Focused 382 internal/1,921 public per
actual target and independent Python probes pass. Class-factory allocation falls
7.75% warm; compile adds 1,048 B. Quiet warm elapsed improves 5.83–6.31%, fresh
3.65–5.33%, with compile +0.70–1.30%. Desktop text adverse remains unexplained but
is not reproduced in the unchanged quiet control. B381 metadata failure and all
original conditions remain archived. Retain; batch full delivery at the next
coherent boundary. No broad CPU gain or performance-objective completion claim.
''')
print('R30 evidence, immutable images and original failures archived.',flush=True)
