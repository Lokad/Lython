from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).parent
script=r'''from pathlib import Path
import fcntl,hashlib,json,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'prepared-class-facts-b381-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 journal=subprocess.run(['journalctl','-u','lython-b381-prepared-class-facts-20261107.service','--no-pager','-n','65'],capture_output=True,text=True).stdout
 (root/'journal.txt').write_text(journal)
 errors={str(p.relative_to(root)):p.read_text() for p in (root/'confirmation').glob('*.stderr')}
 with tarfile.open(root/'failed-observations.tgz','w:gz',dereference=True) as archive:
  for name in ['confirmation','identity.json','representative.json','collect.py','contract.md','setup-contract.json','pre-measurement-plan.md','source.patch','run.sh','journal.txt','started.utc','stopped.utc','exit-code.txt']:archive.add((root/name).resolve(),arcname=name)
 receipt=dict(complete=False,noActiveWorkersOrFixtures=True,noCompletedJobs=True,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest(),errors=errors)
 (root/'failed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
result=subprocess.run([*ssh,'lokad@20.166.121.73','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);assert result.returncode==0,result.stderr
scp=['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:]]
for name in ['failed-observations.tgz','failed-receipt.json']:
    result=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/prepared-class-facts-b381-20261107/'+name,str(root/'b381'/name)],capture_output=True);assert result.returncode==0,result.stderr
receipt=json.loads((root/'b381/failed-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'b381/failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(json.dumps(receipt,indent=2))
