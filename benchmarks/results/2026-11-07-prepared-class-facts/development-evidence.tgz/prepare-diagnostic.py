from pathlib import Path
import copy,hashlib,json,shutil
root=Path(__file__).parent;prior=root.parent/'fixed-text-construction-b194/tool';tool=root/'tool';tool.mkdir()
source=(prior/'Program.cs').read_text(encoding='utf-8')
source=source.replace('if (cases.Length != 8) throw new InvalidDataException("Require five complete jobs and three fixed-text controls.");',
                      'if (cases.Length != 2) throw new InvalidDataException("Require one class-factory job and one unchanged text control.");')
source=source.replace('B194 allocation/peak diagnostic ONLY; shared ALCs/process GC; elapsed/CPU not source-pair performance proof; five complete scripts and three fixed-text controls, both APIs',
                      'R30 bounded class-fact diagnostic; shared ALCs/process GC; precise allocation, desktop elapsed diagnostic only; compile/warm separate')
assert 'cases.Length != 2' in source
(tool/'Program.cs').write_text(source,encoding='utf-8',newline='\n')
for name in ['Directory.Build.props','complete-jobs.csproj']:shutil.copy2(prior/name,tool/name)
catalog=json.loads((root.parent/'compact-fragments-b205/catalog.json').read_text(encoding='utf-8'))
template=next(c for c in catalog['cases'] if c['id']=='scripts.fixed-text-padding.large')
fixture=json.loads(template['fixtureJson']);assert not fixture['inputFiles'] and not fixture['outputFiles']
affected=copy.deepcopy(template)
program='''def make(value):
    class Base:
        def amount(self): return value
    class Row(Base):
        def amount(self): return super().amount() + 1
        def owner(self): return __class__
    return Row()
total = 0
for i in range(32):
    row = make(i)
    assert row.owner() is type(row)
    total += row.amount()
print(total)
'''
affected.update(id='scripts.class-factory.small',scale='small',size=32,source=program,sourceUtf8Bytes=len(program.encode('utf-8')),
                sourceSha256=hashlib.sha256(program.encode('utf-8')).hexdigest(),expectedOutput='528\n',expectedOutputUtf8Bytes=4,
                expectedOutputSha256=hashlib.sha256(b'528\n').hexdigest())
control=next(c for c in catalog['cases'] if c['id']=='scripts.text-summary-helpers.large')
catalog['cases']=[affected,control]
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'class-factory.py').write_text(program,encoding='utf-8',newline='\n')
print('Reused complete-job driver with exactly two cases; class factory32 iterations, text control unchanged.')
