from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent
shutil.copy2(root/'catalog.json',root/'catalog-local-inconsistent.json')
data=json.loads((root/'catalog.json').read_text(encoding='utf-8'))
case=data['cases'][0];fixture=json.loads(case['fixtureJson'])
assert case['size']==32 and fixture['size']==256 and not fixture['inputFiles'] and not fixture['outputFiles']
fixture['size']=case['size'];case['fixtureJson']=json.dumps(fixture,separators=(',',':'))
case['fixtureSha256']=hashlib.sha256(case['fixtureJson'].encode('utf-8')).hexdigest()
case['category']='class-factory-control'
(root/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Size/fixture metadata and digest corrected; source, stdout and empty file maps unchanged.')
