from pathlib import Path
import ast,datetime,json,subprocess,sys
home=Path(__file__).parent;old=home.parent/'execution-transport-r29/b378'
priorid=json.loads((old/'identity.json').read_text(encoding='utf-8'))
localbase=json.loads((home/'baseline.json').read_text(encoding='utf-8'))
assert all(priorid['sourceSHA256'][name]==digest for name,digest in localbase['files'].items())
(home/'baseline-full.json').write_text(json.dumps(dict(sourceSHA256=priorid['sourceSHA256']),indent=2)+'\n',encoding='utf-8',newline='\n')
source=(home.parent/'execution-transport-r29/prepare-b378-expanded.py').read_text(encoding='utf-8')
source=source.replace("root=home/'b378'","root=home/'b381'")
source=source.replace("old=home.parent/'native-single-pass-r26/b374'","old=home.parent/'execution-transport-r29/b378'")
source=source.replace("prior='/home/lokad/lython-bench-checks/canonical-formatting-b374-20261107'","prior='/home/lokad/lython-bench-checks/completed-helpers-b378-20261107'")
source=source.replace('completed-helpers-b378-20261107\'\nsha=', 'prepared-class-facts-b381-20261107\'\nsha=')
source=source.replace('lython-b378-completed-helpers-20261107','lython-b381-prepared-class-facts-20261107').replace('b378-launch.py','b381-launch.py')
source=source.replace("home/'baseline.json'","home/'baseline-full.json'")
source=source.replace('ea4739d5/c4729a9f runtime plus R29 completed native helper dispatch; frozen after focused checks',
                      'e9b55acd/81036f25 runtime plus R30 prepared class own-cell facts; frozen after focused checks')
source=source.replace('c4729a9f runtime, frozen B3749e1dbc38; all baseline production source hashes identical',
                      '81036f25 runtime, frozen B37832dcf141; all baseline production source hashes identical')
source=source.replace('R29 completed helper calls with two reference/two current roles: text/report sync/async and CSV/JSON controls',
                      'R30 prepared class facts: class-factory compile/warm/fresh and unchanged text compile/warm, two baseline/two current')
start=source.index("write('contract.md'");end=source.index("write('setup-contract.json'",start)
contract='''R30 computes the existing pure class-own-cell predicate with prepared lexical facts and removes its repeated runtime syntax walk. Fresh cells/enclosing captures remain separate. Focus382internal/1921public per actual11/10 pass, plus class factory32 iterations/two classes each independently matches CPython3.13.2 on both APIs/targets. Precise local diagnostic: compilation+1048B(+0.77%), warm allocation-29980B(-7.75%), admitted peaks unchanged. Unchanged desktop text clocks are adverse, preserved and not dismissed as noise. This single quiet confirmation decides retention/regression debt: five complete jobs, class-factory compile/warm/compile-run and text compile/warm. Same frozen R2932dcf141 reference, b94fa98c worker/host/optional0.4 adapter and normal GC/tiering. Two baseline/two current processes,5s warmup per role, seven rotated150ms rounds. Compilation separate from execution/I/O; warm/fresh include mediated RAM I/O, full checks and prior-result cleanup, fresh adds compilation/program disposal. Exclude startup/staging/reset/final teardown. All Ready/goldens/budget0/quiet/Closed/joins/fixture/persistent-under-lease archive gates required. No CPU prediction, source-pair compounding or claim that this closes the larger performance objective.210s owner+30s stop+40s margin: no SSH before280s after acknowledgment. No retries after refused admission.\n'''
source=source[:start]+"write('contract.md',"+repr(contract)+")\n"+source[end:]
source=source.replace("['scripts.csv-summary-functions.large warm','scripts.json-summary-helpers.large warm']","['scripts.text-summary-helpers.large compile','scripts.text-summary-helpers.large warm']")
source=source.replace("roles=['candidate','reference','control','reference-control'],ownerSeconds=240", "roles=['candidate','reference','control','reference-control'],ownerSeconds=210").replace('observeAfterSeconds=310','observeAfterSeconds=280')
oldjobs="jobs=[('scripts.text-summary-helpers.large','warm'),('scripts.text-summary-helpers.large','warm-async'),('scripts.report-render.large','warm'),('scripts.report-render.large','warm-async'),('scripts.csv-summary-functions.large','warm'),('scripts.json-summary-helpers.large','warm')]"
newjobs="jobs=[('scripts.class-factory.small','compile'),('scripts.class-factory.small','warm'),('scripts.class-factory.small','compile-run'),('scripts.text-summary-helpers.large','compile'),('scripts.text-summary-helpers.large','warm')]"
assert oldjobs in source;source=source.replace(oldjobs,newjobs)
source=source.replace('len(jobs)==6','len(jobs)==5').replace("len(r['jobs'])==6","len(r['jobs'])==5").replace('jobs=6','jobs=5')
source=source.replace("home/'comparison-catalog.json'","home/'catalog.json'")
source=source.replace("['scripts.report-render.large','scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large']","['scripts.class-factory.small','scripts.text-summary-helpers.large']")
source=source.replace('allSixCatalogJobsValidated','allFiveCatalogJobsValidated').replace('time.monotonic()-started < 200','time.monotonic()-started < 170')
source=source.replace("'--property=RuntimeMaxSec=240'","'--property=RuntimeMaxSec=210'")
ast.parse(source)
assert "remote='/home/lokad/lython-bench-checks/prepared-class-facts-b381-20261107'" in source
(home/'prepare-comparison-expanded.py').write_text(source,encoding='utf-8',newline='\n')
result=subprocess.run([sys.executable,'-X','utf8',str(home/'prepare-comparison-expanded.py')])
if result.returncode:raise SystemExit(result.returncode)
now=datetime.datetime.now(datetime.timezone.utc)
bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=280)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=40)
(home/'b381/observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['retrieve-b378.py','summarize-b378.py']:
    content=(home.parent/'execution-transport-r29'/name).read_text(encoding='utf-8')
    content=content.replace('completed-helpers-b378-20261107','prepared-class-facts-b381-20261107').replace('lython-b378-completed-helpers-20261107','lython-b381-prepared-class-facts-20261107').replace('b378','b381')
    (home/name.replace('b378','b381')).write_text(content,encoding='utf-8',newline='\n')
print(bound,flush=True)
