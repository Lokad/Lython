from pathlib import Path
import ast,datetime,json,subprocess,sys
home=Path(__file__).parent
source=(home/'prepare-comparison-expanded.py').read_text(encoding='utf-8').replace('b381','b382')
source=source.replace("for name in ['representative.json','Lokad.Lython.dll','identity.json'", "for name in ['representative.json','identity.json'")
start=source.index(" folder=root/'candidate';folder.mkdir()")
end=source.index(" identity=json.loads",start)
source=source[:start]+" (root/'candidate').symlink_to(Path('/home/lokad/lython-bench-checks/prepared-class-facts-b381-20261107/candidate'),target_is_directory=True)\n"+source[end:]
source=source.replace(" for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')", " for name in ['collect.py','archive-owned.py']:\n  text=(root/name).read_text();assert str(root) in text and 'b381' not in text;compile(text,str(root/name),'exec')\n assert str(root) in (root/'run.sh').read_text() and 'b381' not in (root/'run.sh').read_text()")
ast.parse(source)
verification=json.loads((home/'catalog-verification.json').read_text(encoding='utf-8'))
assert verification['state']=='Completed' and verification['caseCount']==2
with (home/'prepare-b382-expanded.py').open('w',encoding='utf-8',newline='\n') as f:f.write(source)
r=subprocess.run([sys.executable,'-X','utf8',str(home/'prepare-b382-expanded.py')]);assert r.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=280)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=40)
(home/'b382/observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['retrieve-b381.py','summarize-b381.py']:
    content=(home/name).read_text(encoding='utf-8').replace('b381','b382').replace("status['receipt']['jobs']==6","status['receipt']['jobs']==5")
    if name.startswith('summarize'):content=content.replace('comparison-mask-summary.json','comparison-summary.json')
    (home/name.replace('b381','b382')).write_text(content,encoding='utf-8',newline='\n')
print(bound,flush=True)
