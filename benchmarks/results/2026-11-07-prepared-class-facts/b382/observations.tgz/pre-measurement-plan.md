# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvement.
Finishing an experiment does not finish that objective.

## Delivery status

- **Fully qualified:** R29 `81036f25`, terminal GREEN42333421800/all eight Windows/
  Ubuntu, actual .NET11/10, original Stress and installed-package gates. This
  includes R26's correctness fix. R26 `c4729a9f`, R25 `01aedc3b`, R23 `ec134e8c`
  and R22 `41c25958` were likewise fully qualified. All terminal receipts cached;
  never query or repeat unchanged qualification. Preserve the shared compiler-fact
  correction, direct UTF-8 formatting/storage and native helper returns.
- **Completed:** B380 representative CPython refresh on exact `81036f25`, frozen
 32dcf141. Every source hash verified against preserved R26 plus committed R29,
 excluding the current R30 prototype. All15jobs/goldens/funding/quiet/joins/archive
 pass in312s. Primary docs/BENCHMARKS.md now measures this source. Historical
 R25 measurements remain immutable; completed checkpoints are not rerun for dates.
- **Withdrawn:** R28 shared split-result storage and mask refinement. Allocation
 −6.94% is established; text elapsed inconclusive, report consistently adverse.
 Both runtime variants removed, Unicode regressions retained. All source/raw/
 initial overcharge/assertion failures and adverse observations remain preserved.
- **Active prototype, not delivery:** R30 prepared class own-cell fact75e60e66/
 89ee0097. Runtime syntax walk replaced by existing prepared facts. Focused382
 internal/1,921public per actual target pass, including class cells, generators,
 annotations, cancellation and shared ownership. Short compile/warm diagnostic
 remains; no performance claim or completed full qualification for this source.

## Established results / unresolved measurements

| Milestone | Established | Remaining qualification or uncertainty |
| --- | --- | --- |
| Shared compiler facts | Eliminates exponential traversal of shared inferred values; mutable aliases/diagnostics/cancellation preserved | Not a warm-execution result; keep corrected callback traversal too. |
| R29 completed calls | Synthetic pending/completion phase removed; qualified; text elapsed improves with allocation flat | Report/CSV debt and primary CPython variation remain explicit; no broad CPU claim. |
| Native helper returns | Allocation−19.92/−19.31%; qualified | Historical elapsed improvements are diagnostic, not established CPU gains or percentages transferable to HEAD. |
| Direct UTF-8 formatting | Allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms remains unexplained/preserved; reopen only for justified correction/refinement, not unchanged date-refresh retiming. |
| R20 shared record layout | JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8%; qualified | CSV coarse CPU mixed. Text−1.21 to+5.53% is accepted possible debt, not parity. |
| R21/R22 execution/setup | Shared resume path removes per-instruction pending return/error polling; immutable builtin metadata; factory−2,688B; qualified | Whole-script R22 allocation mostly<0.2%, config~1.17%; clocks/control movement prevent broad CPU attribution. |
| U04/R23 regex ownership/programs | Capture carriers removed; duplicate frontend/runtime compilation removed; qualified | U04 direct allocation−20.34%; R23 extraction warm−8.34–9.64%, fresh−6.47–6.53%. Earlier denial: compiled funding39,397→105,481B until script disposal. |
| R25 CSV values | Final funded row-array transfer removes second values array/per-field publication for exact unchanged native headers; qualified | Allocation−7.31/−6.55%; B372 ordinary warm−4.13–4.78%, native−7.72–8.04%; controls/coarse CPU limit attribution. |
| R26 canonical formatting | Corrects stale native proof/InvalidCastException after admission changes a receiver; removes duplicate formatted-body execution; qualified | Allocation flat; possible~3% async/text elapsed debt remains for the next coherent execution delivery. |

B380 separates compile-only44–72µs from warm execution: text1.71–1.75×, CSV
1.22×, JSON1.05–1.06×, report1.38–1.42× CPython. Fresh text1.62–1.66×; CSV,
text, JSON and report fresh cases remain variable. Warm text has2.50%role spread,
report3.21%/3.12%IQR. Boundary includes mediated RAM I/O, full checks and prior-result
cleanup; excludes startup, staging/reset and final teardown. No subtraction of
medians or compounding source pairs. Startup, truly suspended-I/O latency, heap/
RSS and embedding tails remain open. Refresh again for a meaningful runtime change.

## Priority 1 — R30 prepared class lexical facts

**Proposed simplification, implemented as a prototype:** compute class own-cell
demand once in the existing prepared ScopeDirectiveFacts. CreateClassBody reads
that immutable fact instead of walking ClassCellSyntaxFacts.RequiresCell for each
execution. This removes a runtime analysis phase on both APIs, without another
cache/owner/route. Creating a class cell remains distinct from capturing an enclosing
one; the existing lexical visitor is still needed by compilation, not dormant code.

**Compatibility/tradeoff:** same pure syntax predicate and fresh per-execution
class/cell ownership. Preparing it moves a walk to compilation and adds a temporary
facts-record copy per class. Do not claim warm savings as compile-to-result savings.
Preserve nested classes, super/direct reads, nonlocal/global/shadowing, lambdas,
comprehensions, annotations, cancellation and class-resource cleanup.

**Acceptance/stop:** focused actual-target checks pass. Use one short affected
class-definition/factory diagnostic plus unchanged helper control, separating
compilation, warm allocation/time and final budget reuse. Retain controls/adverse
data; no predicted whole-script CPU gain. Finish after the runtime walk is gone;
do not merge semantically different frontend analyses or open a broad campaign.
Batch full platform/original Stress/installed consumers at a meaningful subsequent
boundary. Keep R29's qualification separate from this prototype.

R30 local diagnostic complete:32 factory calls/two classes each, independent
CPython3.13.2 golden on sync/async and actual11/10. Compile allocation+1,048B
(+0.77%), warm−29,980B(−7.75%); admitted peaks unchanged; text allocation flat.
Desktop warm text is adverse (10.046ms versus8.791–9.101ms baseline roles), not
qualified CPU evidence or assumed noise. One bounded quiet-VM confirmation now
covers class compile/warm/fresh and text compile/warm with two baseline/two current
roles, unchanged runtime/profile. Preserve desktop adverse data and decide debt;
no automatic refinement/retiming series or implied whole-script objective closure.

## Following redesign roadmap

R29's completed-call phase is delivered: existing native helpers no longer
manufacture pending state or reenter the prefix. B378 warm text improves4.25–7.61%
sync/7.63–8.64%async versus R26 with allocation/peaks flat. Report varies, CSV
retains up to3.04%adverse against differing baselines; JSON improves. Accept that
uncertainty as explicit milestone debt, not parity or automatic percentage veto.
R26's possible earlier~3%text/async debt is not algebraically repaid by another run.

Destination source inspection: completed result publication already skips its
following store. Deleting that metadata alone does not remove normal dispatch;
pending disposal still needs its funded continuation/span. Do not add a pending
register/table merely to remove an instruction. Reopen for a coherent design that
eliminates actual work and preserves the GC-lifetime fence and cleanup semantics.

| Area / evidence | Work to eliminate / displaced implementation | Scripts and acceptance / decision |
| --- | --- | --- |
| Complete call/frame construction | R29 completed phase delivered. Target another complete argument/binding/context/continuation phase, preserving existing borrowed/native paths; remove its old driver/transport. | Helper-heavy text/CSV/report, constructors and genuine I/O. Defaults, dynamic keywords, protocol selection, frames, evaluation order, stack admission, cancellation and funded borrows. No arena merely because boxing exists. |
| Boxed values / operand transport | Assess integer object traffic together with reads, publication and retirement. Select a canonical representation only with a proved hot removable phase; delete displaced object/transport paths. | Counters/indexes/aggregation; Python identity/aliases/hash/projection, exact promotion and public storage funding. Small add's~3% CPU is insufficient by itself; do not start a universal migration speculatively. |
| Per-record construction | R20/R25 delivered. Earlier6–8% CSV bulk rejection was reconsidered through completed-array transfer, not automatically promoted. Select another phase only when an actual intermediate can disappear. | CSV/JSON/report; header reentry/admission mutation, short/rest/duplicate/custom keys, independent mutable rows, Clear capacity and overlap. Keep old adverse control results. |
| Remaining text conversions | Casing/split and unchanged UTF-8 file windows already direct. R28−6.94% allocation fails to justify universal window overhead/report debt; seek a different final-storage/conversion boundary. | Unicode expansion/context, indexing/hash/repr, regex scalar/byte offsets, retained aliases and cancellation. No new pool/owner ledger; allocations and CPU are distinct. |
| Repeated frontend analysis | Lexical/shared facts already reused. Consolidate a demonstrated duplicate walk or retained representation; remove it rather than add another cache. | Helper/comprehension compile-to-result controls, separate from warm text. Preserve corrected shared-graph analysis, scoping/class cells/annotations, diagnostics and compile cancellation/admission. |

## Independent regex track

Core Python semantics/native UTF-8, byte ranges, scalar original-subject windows,
captures/replacements/errors, ownership and current cancellation keep advancing.
U04/R23 delivered; core has zero backend dependency/type edges. Normal adapter
pin0.4 is nonpackable. Dev46 immutable source6957b35a passes85 internal/482 public
per actual target using the U04 bridge; evidence2026-11-06-regex-dev46-compatibility.
Do not repeat unchanged qualification or promote private producer bits silently.

Only affected final adapter qualification waits: DetailedData lacks independent
Prepare working ownership; native names cannot be enumerated; native cursors mix
creation/current tokens. Existing conservative preflight, adapter-local conversion
and qualified CTS bridge support development/current semantics. Normal0.4 reversed
windows fail explicitly. Development producers/bridges are acceptable; qualify the
released immutable package/managed safety separately. No sibling edits, silent
dialect fallback, work/time quotas or abandoned matching. This dependency never
blocks independent core implementation/correctness/performance work.

## Evidence, iteration and project constraints

Timeouts, unstable controls and inconclusive timings establish uncertainty. Allow
bounded confirmation/refinement/measurement correction when justified; preserve
original failed conditions and adverse results. Percentages inform decisions,
not automatic vetoes or permanent closures. Distinguish simplification, allocation,
elapsed and demonstrated CPU. Temporary regression debt needs an explicit
completion milestone/decision. Keep active plan concise; historical narratives/raw
sources/observations belong in benchmarks/results and benchmarks/EXPERIMENTS.md.
R28 all variants, failed conditions and exact images are preserved in committed
2026-11-07-owned-split-storage; original B205 binaries likewise have committed
backup before redundant expanded VM copies are retired after user/link/hash checks.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/native
probing. Preserve managed stack/recursion, host capabilities/contained paths, cycles,
cooperative cancellation and borrowed shared allowance for capacity/replacement/
escaping aliases. First admission refusal fails the command; never retry. Await
all users/cleanup. No fuel/quotas, hidden caps/default allowance, heap tracing,
weak reclamation or forced GC. Long streaming uses bounded host executions;
XML depth constraint remains. Do not alter supported semantics to simplify proof.

Focused Release iteration; no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Quiet VM lokad@20.166.121.73,
key~/.ssh/id_lython-bench.pem: owned lease, Ready identities, controls/quiet/goldens/
funding/Closed/joins and verified persistent archives. Observe only after recorded
owner+stop+margin bound. Disk nearly full: retire exact redundant expanded files
only after independent committed backup and current user/dependency checks. Keep
all raw evidence. Continue the roadmap; publication/tagging remain postponed.
