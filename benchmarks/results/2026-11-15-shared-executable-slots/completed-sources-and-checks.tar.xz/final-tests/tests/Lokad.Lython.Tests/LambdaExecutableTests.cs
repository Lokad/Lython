using Slot = Lokad.Lython.Runtime.LythonRuntime.ExecutableSlot;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;
using System.Numerics;
using System.Reflection;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;

namespace Lokad.Lython.Tests;

public sealed class LambdaExecutableTests
{
    [Fact]
    public void DeniedClosureCaptureDoesNotPublishFundingMarks()
    {
        var syntax = LythonFrontend.Compile("def outer(value):\n    return lambda:value",regexProvider:Utf8RegexProvider.Instance).Script!;
        var module = ExecutableScript.Compile(LoweredScript.Lower(syntax)).EntryPoint;
        var outer = Assert.Single(module.Functions).CodeObject!;
        var lambda = Assert.Single(outer.Constants.OfType<ExecutableCreateLambda>()).CodeObject!;
        var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(1024 * 1024) },regexProvider:Utf8RegexProvider.Instance);
        var values = new Slot[outer.LocalNames.Count];
        var cell = new LythonRuntime.ExecutableCell(BigInteger.One);
        values[outer.LocalNameToSlot["value"]].Object = cell;
        context._execution = new() { Code = outer, Locals = values };
        context.EnterExecutableSlots();
        var capture = typeof(LythonRuntime).GetMethod("CaptureExecutableClosures", BindingFlags.Static | BindingFlags.NonPublic)!
            .CreateDelegate<Func<ExecutableCodeObject, Context, LythonSourceSpan, LythonRuntime.ExecutableCell[]>>();
        var baseline = context.MemoryGovernor.CurrentAccountedBytes;
        var padding = 1024 * 1024 - baseline;
        context.MemoryGovernor.Reserve(padding, null);
        context.MemoryGovernor.Commit(padding);
        try
        {
            var failure = Assert.Throws<LythonRuntimeException>(() => capture(lambda, context, syntax.Statements[0].Span));
            Assert.Equal("MemoryError", failure.ExceptionType);
            Assert.False(cell.RetentionCharged);
            Assert.Equal(1024 * 1024, context.MemoryGovernor.CurrentAccountedBytes);
            context.MemoryGovernor.Release(padding);
            Assert.Same(failure, Assert.Throws<LythonRuntimeException>(() => capture(lambda, context, syntax.Statements[0].Span)));
            Assert.False(cell.RetentionCharged);
            Assert.Equal(baseline, context.MemoryGovernor.CurrentAccountedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
        finally { context.LeaveExecutableSlots(); }
    }

    [Theory]
    [InlineData("lambda value:value+1")]
    [InlineData("lambda value:f'{value:02d}'")]
    [InlineData("lambda target,values:target(*values)")]
    [InlineData("lambda value:lambda step:value+step")]
    public void LambdaBodiesAreExecutableWithoutForcedMirroring(string expression)
    {
        var syntax = LythonFrontend.Compile("result=" + expression,regexProvider:Utf8RegexProvider.Instance).Script!;
        var code = ExecutableScript.Compile(LoweredScript.Lower(syntax)).EntryPoint;
        Check(code);
        Assert.NotEmpty(code.Constants.OfType<ExecutableCreateLambda>());

        static void Check(ExecutableCodeObject code)
        {
            Assert.Empty(code.StatementFallbacks);
            Assert.False(code.RequiresLocalVariableMirroring);
            foreach (var lambda in code.Constants.OfType<ExecutableCreateLambda>())
            {
                // Defaults-only preparation with a lowered body does not qualify.
                Assert.NotNull(lambda.CodeObject);
                Check(lambda.CodeObject);
            }
        }
    }
}
