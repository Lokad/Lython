from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent.parent/'scalar-results-r370';base=json.loads((r/'baseline.json').read_text(encoding='utf-8'));checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==6 and all(x['exitCode']==0 for x in checks)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names={n for n in base['sources'] if Path(n).is_file()};names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','src/Lokad.Lython'],text=True).splitlines());sources={n:sha(n) for n in sorted(names)}
env={k:v for k,v in os.environ.items()if k.casefold()!='path'};sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
with (r/'final-freeze-build.log').open('w',encoding='utf-8')as f:done=subprocess.run([sdk+'/dotnet.exe','build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and all(sha(n)==h for n,h in sources.items())
for role in ['reference','candidate']:shutil.copytree(old/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==base['coreSHA256']
previous=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(r/role/n)==h for role in ['reference','candidate']for n,h in previous['auxiliaryFiles'].items())
identity=dict(headBeforeCommit=base['head'],runtimeBaseCommit=base['runtimeCommit'],sources=sources,productionFiles=len(sources),changedProductionInputs=[n for n,h in sources.items()if base['sources'].get(n)!=h],deletedProductionInputs=sorted(set(base['sources'])-set(sources)),coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},auxiliaryFiles=previous['auxiliaryFiles'],frozenFiles={role:{p.name:sha(p)for p in (r/role).iterdir()if p.is_file()}for role in ['reference','candidate']},qualified=False,status='Focused-checked active prototype, retention and CPU unestablished. Managed reference+payload final slots replace separate native integer bank. Compiled returns/completion retain final slots; true builtin/protocol/public observations and protected-cleanup aliases keep stable objects.')
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for n in sources:t.add(n,arcname=n)
for name in ['catalog.json','allocation-catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py','verify.py']:shutil.copyfile(old/name,r/name)
p=r/'verify.py';p.write_text(p.read_text(encoding='utf-8').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334"),encoding='utf-8',newline='\n')
assert all(sha(r/role/n)==h for role in identity['frozenFiles']for n,h in identity['frozenFiles'][role].items())
print(json.dumps(dict(coreSHA256=identity['coreSHA256'],inputs=len(sources),changed=len(identity['changedProductionInputs']),deleted=identity['deletedProductionInputs'])),flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify.py')],env=env,check=True,timeout=60)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],env=env,check=True,timeout=150)

import re,textwrap
controls=json.loads((old/'python-control-sources.json').read_text(encoding='utf-8'))
casefile=Path('tests/Lokad.Lython.PublicApi.Tests/IntegerPublicationTests.cs').read_text(encoding='utf-8')
for body in re.findall(r'yield return \["""\n(.*?)\n\s*"""\];',casefile,re.S):
 script=textwrap.dedent(body)+'\n'
 if script not in controls:controls.append(script)
(r/'python-control-sources.json').write_text(json.dumps(controls,ensure_ascii=False)+'\n',encoding='utf-8')
records=[]
for asynchronous in [False,True]:
 done=subprocess.run([sdk+'/dotnet.exe',str(Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve()),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else []),input=json.dumps(controls).encode('utf-8'),capture_output=True,env=env,timeout=90)
 (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr)
 assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8')[-2500:]
 records.append(dict(asynchronous=asynchronous,cases=len(controls),matched=True));print(records[-1],flush=True)
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,coreSHA256=identity['coreSHA256']['candidate'],controls=records,python='Isolated CPython3.13.2'),indent=2)+'\n',encoding='utf-8')
