from pathlib import Path
import json,os,subprocess,time
r=Path('.git/agent-notes/review-20261031/shared-slots-r373/refinement');env={k:v for k,v in os.environ.items()if k.casefold()!='path'};sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
fil='(Category!=Stress)&(FullyQualifiedName~DirectOperandOwnershipTests|FullyQualifiedName~ClassPatternOwnershipTests|FullyQualifiedName~ExecutionPathOwnershipParityTests|FullyQualifiedName~DeferredFunctionOwnershipTests|FullyQualifiedName~CompletedHelperCallOwnershipTests|FullyQualifiedName~ExecutableStackAdmissionTests|FullyQualifiedName~IntegerAliasOwnershipTests|FullyQualifiedName~IntegerViewOwnershipTests|FullyQualifiedName~IdentityAdmissionTests|FullyQualifiedName~GeneratorExpressionAdmissionTests|FullyQualifiedName~ComparisonBranchOwnershipTests)'
rows=[]
for tfm in ['net11.0','net10.0']:
 log=r/('ownership-'+tfm+'.log');start=time.monotonic()
 with log.open('w',encoding='utf-8')as f:done=subprocess.run([sdk+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter',fil,'--logger','trx;LogFileName=r373r-ownership-'+tfm+'.trx'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(framework=tfm,exitCode=done.returncode,elapsedSeconds=time.monotonic()-start));(r/'ownership-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(tfm,done.returncode,log.read_text(encoding='utf-8')[-1800:],flush=True)
 assert done.returncode==0
