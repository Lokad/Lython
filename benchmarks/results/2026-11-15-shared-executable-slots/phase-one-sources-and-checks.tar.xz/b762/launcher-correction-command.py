from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
p={'root': '/home/lokad/lython-bench-checks/shared-slots-b762-20261115', 'initialUnit': 'lython-b762-shared-slots-20261115', 'correctedUnit': 'lython-b762-shared-slots-20261115-lf', 'oldSHA256': '89a2ed5c41541f2d061dbf48525efda4c762f1e4378eb6492339c32895a30618', 'fixedSHA256': '50ffd1fc87c5deb4d98d74115dc594e0a3ea5f750cacda8002d5cbee163ba05a', 'oldHex': '736574202d65750d0a726f6f743d2f686f6d652f6c6f6b61642f6c7974686f6e2d62656e63682d636865636b732f7368617265642d736c6f74732d623736322d32303236313131350d0a747261702027726573756c743d243f3b207072696e7466202225735c6e22202224726573756c7422203e202224726f6f742f657869742d636f64652e747874222720455849540d0a707974686f6e33202224726f6f742f636f6c6c6563742e7079220d0a', 'fixedHex': '736574202d65750a726f6f743d2f686f6d652f6c6f6b61642f6c7974686f6e2d62656e63682d636865636b732f7368617265642d736c6f74732d623736322d32303236313131350a747261702027726573756c743d243f3b207072696e7466202225735c6e22202224726573756c7422203e202224726f6f742f657869742d636f64652e747874222720455849540a707974686f6e33202224726f6f742f636f6c6c6563742e7079220a', 'reason': 'Initial owner failed before collection: CRLF shell set option. Correct line endings only; preserve original launcher and attempt. No measurement settings or runtime source changed.'}
base=Path('/home/lokad/lython-bench-checks');root=Path(p['root'])
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.check_output(['systemctl','show',p['initialUnit']+'.service','--value','--property=ActiveState'],text=True).strip()=='failed'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not(root/'confirmation').exists() and (root/'guest-fixtures').is_mount() and not list((root/'guest-fixtures').iterdir())
 launcher=root/'run.sh';s=launcher.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and launcher.resolve()==launcher
 assert hashlib.sha256(launcher.read_bytes()).hexdigest()==p['oldSHA256']
 launcher.rename(root/'run.initial-crlf.sh');launcher.write_bytes(bytes.fromhex(p['fixedHex']))
 assert hashlib.sha256(launcher.read_bytes()).hexdigest()==p['fixedSHA256']
 subprocess.run(['/bin/sh','-n',str(launcher)],check=True)
 (root/'launcher-correction.json').write_text(json.dumps(p,indent=2)+'\n')
subprocess.run(['sudo','-n','systemd-run','--unit='+p['correctedUnit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(launcher)],check=True)
print(json.dumps(dict(corrected=True,onlyLauncherLineEndingsChanged=True,originalPreserved=True,unit=p['correctedUnit'])),flush=True)
