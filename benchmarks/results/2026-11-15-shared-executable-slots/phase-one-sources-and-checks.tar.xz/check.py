from pathlib import Path
import json,os,subprocess,time
r=Path('.git/agent-notes/review-20261031/shared-slots-r373');sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items() if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items() if k.casefold()=='path')
public='(Category!=Stress)&(FullyQualifiedName~Integer|FullyQualifiedName~Helper|FullyQualifiedName~Closure|FullyQualifiedName~Function|FullyQualifiedName~Call|FullyQualifiedName~Comprehension|FullyQualifiedName~Lambda|FullyQualifiedName~Generator|FullyQualifiedName~Pattern|FullyQualifiedName~Match|FullyQualifiedName~Dataclass|FullyQualifiedName~RegexAdapterSemanticsTests|FullyQualifiedName~BulkCasedSplitTests|FullyQualifiedName~Receiver)'
internal='(Category!=Stress)&(FullyQualifiedName~CallBindingSubsystemTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~FunctionClassCellBoundaryTests|FullyQualifiedName~KwargsKeyAccountingTests|FullyQualifiedName~ExecutableAsyncIteratorCleanupTests|FullyQualifiedName~NativeFunctionRefundTests|FullyQualifiedName~NativeIntegerChainTests|FullyQualifiedName~ManagedStackGuardTests|FullyQualifiedName~IntegerTextCancellationTests|FullyQualifiedName~OwnedFunctionLocalsTests|FullyQualifiedName~NativeTupleReturnTests|FullyQualifiedName~OwnedTupleReturnTests|FullyQualifiedName~ComposedNativeCallTests|FullyQualifiedName~FormattedStringExecutableTests|FullyQualifiedName~CompletedInvocationLifetimeTests|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~BoundBoxCleanupTests|FullyQualifiedName~LambdaExecutableTests|FullyQualifiedName~ComprehensionLambdaExecutableTests|FullyQualifiedName~SimpleFunctionExecutionBoundaryTests|FullyQualifiedName~TextPredicateCancellationTests)'
records=[]
for tfm in ['net11.0','net10.0']:
 commands=[('probe', ['build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',tfm,'-v','quiet'])]
 for project,fil in [('Lokad.Lython.Tests',internal),('Lokad.Lython.PublicApi.Tests',public)]:commands.append((project,['test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--filter',fil,'--logger',f'trx;LogFileName=r373-{tfm}-{project}.trx']))
 for name,args in commands:
  log=r/(tfm+'-'+name+'.log');assert not log.exists();start=time.monotonic()
  with log.open('w',encoding='utf-8')as f:done=subprocess.run([sdk+'/dotnet.exe']+args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
  records.append(dict(name=name,framework=tfm,exitCode=done.returncode,elapsedSeconds=time.monotonic()-start,log=str(log)))
  (r/'focused-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
  print(tfm,name,done.returncode,log.read_text(encoding='utf-8')[-450:],flush=True)
  assert done.returncode==0
