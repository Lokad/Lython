# Lokad.Lython 0.11.0

Updated 2026-11-14 UTC. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once. One experiment does not complete this objective.
Current contracts belong in docs; completed investigations and every adverse result
are preserved in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable results.

## Delivery status

| State | Evidence and limits |
| --- | --- |
| Fully qualified current runtime | Committed4beb9ecf/frozenbed6e57e, [43649993181 GREEN cached](benchmarks/results/2026-11-14-builtin-scalar-publication/delivery/README.md). Windows/Ubuntu actual11/10, each4,776internal+17,847public ordinary, original13/406stress, installedRelease consumers.582-input proof/16summaries/full logs retained. Never requery or repeat unchanged qualification. |
| R370 retained with debt | Shared typed int-text/len publication, existing parser/wrapper/private bank; no new API/pool/pass. [B759](benchmarks/results/2026-11-14-builtin-scalar-publication/README.md): fulfillment allocation−18.20%,invoice−5%, controls flat; fulfillment warm3–4%/fresh2.6–5.6%lower with CPU support. Invoice+.94–1.87%elapsed/+2–4%CPU remains regression debt. Text adverse/uncertain, short/observed controls variable.136Pythoncontrols/16goldens; all semantic/lifetime/refusal fixes retained. |
| Current external checkpoint | [B761guide](docs/BENCHMARKS.md), exact4beb/bed versus stockCPython3.13.16: ordinary invoice1.23×warm; fulfillment1.15–1.19×warm,1.19–1.20×fresh,1.11×compile; text1.46–1.53×with4.46%Lythonspread. Fulfillment warm2.53%spread. Five jobs200.366s/all gates. Other rows keep named earlier sources; no cross-collection causal gain/debt erasure. |
| Completed work | Shared compiler facts/nonlocal correction and retention cleanup; direct UTF8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable plain builtins; native/owned loops and tuple returns; shared arithmetic/primitive storage; bulk CSV/shared keys; UTF8 JSON/incremental XML. Preserve all fixes and cached qualification. |
| Investigations and prototypes | R371current invoice source gate is complete with no new call rewrite selected; no prototype active. Withdrawn R360side arrays, R364merged entry, R365cleanup, R355CSVranges, R343cased-buffer and R369stack deletion remain removed. Their evidence and useful regressions survive in history. |

Native helper returns established about19–20% less allocation; original elapsed
results remain diagnostic. Formatting established −8.67% allocation; [controlled
confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports
report CPU/elapsed −5–8%; original adverse15.125ms remains unexplained. These are
historical revisions. R368protected helpers, R365workspace reuse and R362ranges
are delivered/qualified; their magnitudes, controls and debt stay in history.
R371's [current profile](benchmarks/results/2026-11-14-call-publication-attribution/README.md)
finds mixed dispatch/call/CSV/arithmetic, not a proved dominant missing frame.
Final binding/slots, DictReader adoption, final split/case backing and bulk ASCII
mapping already exist. No unchanged arena/controller replay or permanent design ban.

## Prioritized deliverables

1. **R373: bounded design gate for shared operand storage.**
   Hypothesis: a single managed slot layout may keep small integer results private
   through ordinary execution and calls while replacing the native-only integer
   side bank. This is a candidate design, not a selected implementation or CPU
   forecast. Current profiles contain meaningful ordinary/native dispatch and
   scalar work, but do not prove boxing alone explains the remaining gap.

   Expected deletion: separate native long spans/loans/clears, parallel slot
   indexing, bank-capacity-only facts and the object→BigInteger→machine-value
   transport bridge. Preserve shared exact arithmetic and deferred contexts.
   Use only a sequential managed reference+payload layout; no pointer/Unsafe union,
   second arena/controller, new public option or memory subsystem.

   Gate before code: inspect actual final storage/binding consumers and alias/
   suspension boundaries. BoundCallArguments currently serves user functions AND
   object-array builtin/presence ABIs; merely changing its element type can introduce
   new array conversions and copies. Produce one coherent boundary/deletion map,
   not a new layer over old banks. Reject this form before implementation if it
   requires permanent parallel function representations or reintroduces packaging.
   Differentiate R360's measured slower per-frame side arrays and R268/R364's
   slower controller/entry designs; a wider slot is not automatically a solution.
   No broad heap/ownership audit or another sampling campaign to keep the gate open.

   Tradeoffs: wider nonnumeric frames/copies and conservative admission, earlier
   refusal, builtin/dynamic argument materialization, stable identity/aliases,
   exposed locals and actual async/generator retention. Exact Python integers and
   wider promotion remain. Before any selected migration, name its exact scope,
   displaced code and completion point; no obsolete bank retained for future use.

   Workloads: complete CSV validation/aggregation and invoice/fulfillment, with
   text/JSON and short/observed helper controls. Acceptance: argument/default/
   protocol order, closures/namespaces, exceptions/finally, identity/aliases, exact
   arithmetic, genuine suspension, cancellation, terminal refusal and funded users
   through cleanup. Temporary regressions need a completion decision, never a switch.

   Focused Release semantics/cancellation/ownership first. Then one bounded usable
   complete-script source pair with unchanged controls, separate allocation/CPU,
   compile and warm costs. Evidence can justify bounded refinement/confirmation.
   Finish with retention/debt, supported withdrawal or explicit uncertainty. Full
   platforms/stress/installed consumers only at a coherent retained boundary.

2. **Make the whole-script performance and regression-debt decision.**
   Architecture, allocation reduction and demonstrated CPU benefit are independent.
   R359/R361/R365/R368short-helper debt, R362materialization/text uncertainty and
   R370invoice regression stay open until corrected, accepted with concrete benefit/
   tradeoff, or withdrawn before release. B761does not erase source-pair evidence.
   Fixed improvement percentages inform decisions; they never automatically veto.
   Startup, contention, pending-I/O latency, heap/RSS peaks and embedding tails are
   unmeasured; fewer allocations establish none of them.

   Other redesign areas need a real removed stage. Bulk CSV already adopts final
   rows/shared keys; historical6–8% observations missed rigid thresholds, not
   semantics. R355raw ranges added scratch/state for limited benefit. A revised
   design must preserve malformed-record timing, custom headers, aliases, wide
   rows and admission/cancellation; do not rebuild removed list/copy/queue stages.
   Text/JSON already use final UTF8 fragments/output, decoded windows and bulk
   ASCII/managed transcoding. R343whole cased-buffer scans measured slower. Preserve
   Unicode/context/expansion, hooks/reentry and identify an entire remaining stage.
   Frontend shared facts/retention cleanup are complete: fulfillment compiles in
   ~.128ms versus~8ms execution; tiny config edits are host-dominated. Select a
   costly fresh-script shape before more analysis passes, JIT or broad redesign.

   B761current invoice/fulfillment/text and earlier named rows stay authoritative
   until materially changed source or an unresolved question warrants refresh.
   No unchanged nine-job rerun. Keep exact dates/image/runtime/reference/machine,
   compile/warm/fresh/startup, mediated I/O, validation, reset/protocol and result/
   cache cleanup boundaries explicit. Continue substantial design work after an
   isolated experiment; do not equate another local success with completion.

3. **Independent Lython-owned regex development/final adapter qualification.**
   Core owns Python semantics, native UTF8/original-subject windows, byte/scalar
   coordinates, captures/errors, explicit ownership and the current token. Continue
   useful contract/semantic work independently of producer publication; development
   producers/adapter-local bridges are allowed outside core. Separate contract
   controls, actual backend semantics/interruption and performance.

   Optional adapter remains nonpackable at0.4; dev80qualification cached. Read-only
   [source assessment throughe63770d1](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   leaves three final-adapter gaps: separate one-match scratch/escaping-result owners,
   native UTF8group-name enumeration/copy, token-independent cursor creation with
   cancellable preparation. Search filtering cannot replace anchored/fullmatch.
   Forward current tokens through actual work; cached state cannot retain prior
   caller tokens. Missing producer APIs postpone only affected released-adapter
   qualification, never independent Lython development. No unchanged producer
   qualification, silent dialect fallback or core dependency/pin promotion.

## Evidence policy and lasting constraints

Timeouts, unstable unchanged controls and inconclusive points establish uncertainty,
not failed design. Allow bounded confirmation/refinement/measurement correction
when evidence justifies it; retain original failed conditions and all adverse data.
No one-attempt/no-retiming/permanent-closure policy or open-ended campaign. Size
runs for usable quiet-VM observations. End milestones explicitly and keep the
complete-script goal active until its actual completion decision.

Use focused Release checks during iteration; batch Windows/Ubuntu, actual11/10,
original stress and installed consumers at retained boundaries. Force nonincremental
builds after restoration; freeze copies and prove full source/image identity.
Terminal CI is cached forever; live queries >=240s apart. Verify persistent raw
under lease before RAM teardown. Deduplicate only exact archived copies after
custody/path/UID/link/hash proof; preserve images/catalogs/toolchains and254/252MiB
floors. No active VM collection remains.

[AGENTS](AGENTS.md) remains binding: fully managed/memory-safe, no unsafe/Unsafe/
pointers/PInvoke/native probing; preserve managed stack safety, host mediation,
cancellation, checked bounds and bounded I/O. Shared allowance funds major capacity,
replacement overlap, retained aliases/results/caches and pending users through
awaited cleanup. First refused admission is terminal. No fuel/quotas, hidden caps/
allowances, tracing/weak reclamation/forced GC or abandoned operations. Long streams
use bounded host commands. Only core is packaged; adapter remains nonpackable.
Publication/tagging remain postponed.
