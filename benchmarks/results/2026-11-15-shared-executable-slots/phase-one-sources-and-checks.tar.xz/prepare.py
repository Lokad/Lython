from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;b=r/'b762';b.mkdir();old=r.parent/'scalar-results-r370/b759';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();frozen=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(sha(n)==h for n,h in frozen['sources'].items())
remote='/home/lokad/lython-bench-checks/shared-slots-b762-20261115';unit='lython-b762-shared-slots-20261115'
identity=dict(sourceRevision='R373uncommitted/frozen'+frozen['coreSHA256']['candidate'][:8]+' vs qualified4beb9ecf/frozenbed6e57e;43649993181GREENcached',purpose='One managed final-slot layout replaces native integer side bank; shared exact arithmetic and direct binding without conversion arrays. Observe wider nonnumeric/copy/view costs, separate architecture/allocation/CPU. Same complete scripts, workers, control shapes and settings.',coreSHA256={role:frozen['coreSHA256']['candidate'if role.startswith('candidate')else'reference']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=frozen['auxiliaryFiles'],catalogSHA256=sha(r/'catalog.json'),publicationHeld=True,fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),sourceFormComparison=False,runtimeComparison=True,qualification='Active prototype; focused actual11/10 only, not fully qualified or retained.')
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile'],['scripts.csv-fulfillment.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['diagnostic.loop-helper.observed.large','warm'],['scripts.json-summary-helpers.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('scalar-results-b759-20261114','shared-slots-b762-20261115').replace('lython-b759-scalar-results-20261114',unit).replace('B759','B762')
 if name=='collect.py':
  a=s.index('jobs=');end=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==8 and all(case in cases for case,lane in jobs)\n'+s[end:]
 elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace('jobs=7','jobs=8')
 elif name=='retrieve.py':s=s.replace("['jobs']==7","['jobs']==8").replace('seven-job','eight-job')
 elif name=='summarize.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace('jobs=7','jobs=8')
 if name.endswith('.py'):ast.parse(s)
 (b/name).write_text(s,encoding='utf-8')
(b/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='420sowner/350sstartguard;8completejobs,4freshprocesses/job,5sfullrequestwarmup/12stext,5rotating0.5sbatches. StocknormalGC/tiering; no disabled safety.',acceptance='Exact Python binding/protocol/identity/promotion; actual suspension, cooperative cancellation, first refused admission, retained funding through joined cleanup, existing managed stack. Full source/image/golden/file/budget/quiet/join/archive gates.',decision='Usable affected and unchanged-control source pair, then retain with justified debt, refine on evidence or withdraw. No fixed percentage veto, universal speedup or one-experiment completion claim.',storage='Copy locally frozen mutable outputs; on VM hardlink already immutable reference/aux/catalog/worker, upload only new core/scripts. No retirement planned; fresh lease/free-space checks enforce existing254/252MiB floors.'),indent=2)+'\n',encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(b/n,arcname=n)
 t.add(r/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(b/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/scalar-results-b759-20261114',unit=unit,identity=identity,payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('c=');end=s.index('\nbase=',a);s=s[:a]+'c='+repr(config)+s[end:];s=s.replace('lython-b759-fixtures','lython-b762-fixtures').replace('priorRetirementProof="b759-proved-withdrawn-prototype-retirement.json",','');ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8')
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
s=(old/'launch.py').read_text(encoding='utf-8').replace('native-entry-r369/b758/terminal-status.json','current-cpython-r372/terminal-status.json');ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8')
print(json.dumps(dict(prepared=True,core=frozen['coreSHA256'],jobs=jobs,unpackedBytes=unpacked)),flush=True)
