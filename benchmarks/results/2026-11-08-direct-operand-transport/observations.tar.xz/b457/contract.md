R96 one bounded source pair; no new benchmark framework or timing policy.
Baseline committedcb2b015e/core9d30623c (R95 full CI independent), candidate frozen
cb2 plus operand-carrier removal. Same unchanged worker7cf37ca5/optional0.4 and six
R95 complete jobs: CSV helper sync/async, returned records, JSON, rsplit text and
report async. All may be affected; duplicated baseline/current processes are the
unchanged controls. All sources/fixtures/goldens unchanged from R90. Five-second
warmup per process/job, normal GC/tiering,7x150ms rotated, coarse process CPU.
210s owner+30sstop+30smargin.240MiB OS floor+7MiB evidence headroom plus actual
payload preflight. Persistent raw/core/archive data;128MiB RAM only guest files.
Exact B456 candidate baseline/auxiliary bytes hardlinked after proof. No deletion.
All source/core/Ready/runtime/full golden/quiet/Closed/join/fixture/archive/local
verification gates required. Allocation neutrality can accompany removal; retain/
correct/reject CPU/control debt explicitly, with no automatic percentage veto.
Existing R95 text debt remains separate; no claim of repayment from unmatched
source pairs or sampling.62public/24internal focused Release peractual11/10 pass.
No new owner/pool/value carrier, unsafe code, quotas or lost cancellation.
