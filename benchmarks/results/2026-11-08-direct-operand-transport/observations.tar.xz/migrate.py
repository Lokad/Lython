from pathlib import Path
root=Path('src/Lokad.Lython')
p=root/'Runtime/LythonRuntime.Executable.Inputs.cs';s=p.read_text(encoding='utf-8')
a=s.index('    internal readonly struct ExecutableInputs(');z=s.index('    internal sealed partial class ExecutionContext',a)
s=s[:a]+s[z:]
a=s.index('        private static ExecutableInputs ReadInstructionInputs(');z=s.index('        // Keep transient guest references',a)
s=s[:a]+s[z:]
needle='''            var inputs = ReadInstructionInputs(ref execution, instruction, scope, invocation);'''
assert needle in s
s=s.replace(needle,'''            // Descriptor resumption uses the original receiver/key retained in
            // funded protocol slots. Otherwise read prepared positions once.
            var retained = instruction.OpCode == ExecutableOpCode.Subscript && invocation?._preparedCallValue is not null;
            var first = retained ? execution.Stack[instruction.ResultSlot]
                : ReadOperand(ref execution, instruction.InputStart, scope, 0);
            var second = instruction.OpCode == ExecutableOpCode.Unary ? null
                : retained ? execution.Stack[instruction.ResultSlot + 1]
                : ReadOperand(ref execution, instruction.SecondInput, scope, 1);
            var third = instruction.OpCode is ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast
                ? ReadOperand(ref execution, instruction.ThirdInput, scope, 2) : null;''')
s=s.replace('inputs.First','first').replace('inputs.Second','second').replace('inputs.Third','third')
s=s.replace('invocation.TrySuspendForTypeSubscription(instruction, inputs)','invocation.TrySuspendForTypeSubscription(instruction, first, second!)')
s=s.replace('invocation!.ExecuteCapturedValueOperationAsync(instruction, inputs)','invocation!.ExecuteCapturedValueOperationAsync(instruction, first, second)')
s=s.replace('ExecuteCapturedValueOperationAsync(ExecutableInstruction instruction, ExecutableInputs inputs)','ExecuteCapturedValueOperationAsync(ExecutableInstruction instruction, object first, object? second)')
assert 'ExecutableInputs'not in s and 'ValueInputCount'not in s
p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'Runtime/LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8')
s=s.replace(needle,'''            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);
            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);''')
s=s.replace('inputs.First','first').replace('inputs.Second!','second')
s=s.replace('invocation.ExecuteComparisonBranchAsync(instruction, inputs)','invocation.ExecuteComparisonBranchAsync(instruction, first, second)')
s=s.replace('ExecuteComparisonBranchAsync(ExecutableInstruction instruction, ExecutableInputs inputs)','ExecuteComparisonBranchAsync(ExecutableInstruction instruction, object first, object second)')
assert 'ExecutableInputs'not in s and 'inputs.'not in s
p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'Runtime/LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
a=s.index('        private bool TrySuspendForTypeSubscription(');z=s.index('        private bool TryPrepareSubscriptionCallable(',a)
segment=s[a:z].replace('ExecutableInstruction instruction, ExecutableInputs inputs','in ExecutableInstruction instruction, object receiver, object key')
segment=segment.replace('inputs.First','receiver').replace('inputs.Second!','key')
assert 'ExecutableInputs'not in segment
s=s[:a]+segment+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8')
old='public int ThirdInput => ValueInputCount == 3 ? _resultSlot : throw InvalidOperand(nameof(ThirdInput));'
assert old in s
s=s.replace(old,'''public int ThirdInput => OpCode is ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast
        ? _resultSlot : throw InvalidOperand(nameof(ThirdInput));''')
p.write_text(s,encoding='utf-8',newline='\r\n')
print('Removed operand carrier/reader and runtime general-arity decoding; retained explicit source reads and protocol snapshots.')

