from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'direct-comparison-r95/b455';b=r/'b457';b.mkdir()
source=json.loads((r/'identity.json').read_text());previous=json.loads((old/'identity.json').read_text())
identity={**previous,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification']}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('direct-comparison-b455-20261108','direct-operands-b457-20261108').replace('lython-b455-direct-comparison','lython-b457-direct-operands').replace('direct-comparison-b455-launch.py','direct-operands-b457-launch.py')
 if name=='collect.py':s=s.replace('R95 shared typed numeric comparison/ordered enum transport/direct comparison branches; CSV and JSON affected, text/report controls','R96 remove operand carrier/runtime arity reader and borrow synchronous metadata; same complete CSV/JSON/text/report scripts, current9d baseline with duplicated source controls')
 if name=='launch.py':s=s.replace("reference=base/'shared-cased-split-b453-20261108/candidate'","reference=base/'dedicated-comparison-b456-20261108/candidate'")
 if name=='archive-owned.py':s=s.replace(",'new-sources'","")
 (b/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json')]:shutil.copyfile(src,b/name)
contract='''R96 one bounded source pair; no new benchmark framework or timing policy.
Baseline committedcb2b015e/core9d30623c (R95 full CI independent), candidate frozen
cb2 plus operand-carrier removal. Same unchanged worker7cf37ca5/optional0.4 and six
R95 complete jobs: CSV helper sync/async, returned records, JSON, rsplit text and
report async. All may be affected; duplicated baseline/current processes are the
unchanged controls. All sources/fixtures/goldens unchanged from R90. Five-second
warmup per process/job, normal GC/tiering,7x150ms rotated, coarse process CPU.
210s owner+30sstop+30smargin.240MiB OS floor+7MiB evidence headroom plus actual
payload preflight. Persistent raw/core/archive data;128MiB RAM only guest files.
Exact B456 candidate baseline/auxiliary bytes hardlinked after proof. No deletion.
All source/core/Ready/runtime/full golden/quiet/Closed/join/fixture/archive/local
verification gates required. Allocation neutrality can accompany removal; retain/
correct/reject CPU/control debt explicitly, with no automatic percentage veto.
Existing R95 text debt remains separate; no claim of repayment from unmatched
source pairs or sampling.62public/24internal focused Release peractual11/10 pass.
No new owner/pool/value carrier, unsafe code, quotas or lost cancellation.
'''
(b/'contract.md').write_text(contract,encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/n,arcname=n)
print('R96 B457 same six complete jobs/current9d baseline prepared; no extra profiling or framework.')

