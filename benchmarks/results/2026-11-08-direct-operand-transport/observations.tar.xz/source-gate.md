# R96 gate: remove the operand bundle

Base committedcb2b015e/core9d30623c, full qualification in progress independently.
Gate accepted; no new storage/ownership or value representation is needed.

Audited all source/test/benchmark/tool callers. ExecutableInputs has only the
ordinary value handler, comparison control, their async continuations, and type
subscription preparation as consumers. It is a24B three-reference value returned
from ReadInstructionInputs and passed by value, including an unused third reference
in two-operand async work. The reader consults ValueInputCount again at runtime.
R93 input handling6.04%self identifies a measured area; JIT may remove some source
copies, so this is a performance hypothesis, not an instruction-cost claim.

Replacement/deletion:
- Delete ExecutableInputs and ReadInstructionInputs, without a tuple/new carrier.
- Read prepared positions into ordinary references in the two existing handlers.
  Only Unary lacks a second input; only subscript stores read the third. Preserve
  all leaf reads before operation try/cleanup, especially a failing third read.
- Keep the original receiver/key in existing type-subscription scratch after a
  descriptor rebound/suspended. Promotion remains pre-effect. No rereads after work.
- Pass two references directly into genuine async operations. Borrow immutable
  synchronous instruction metadata; retain its value in actual async operations.
- ThirdInput keeps its opcode validity check; runtime reads no general arity
  classification. Compiler ValueInputCount and all managed array bounds remain.

Ownership, pending borrows and source spans stay with the existing frame/state.
No early refund, new owner/cache/pool, options, root tracing or replacement policy.
Acceptance uses current direct-operand/type-subscription/rebinding/source-error,
comparison, real async/cancellation/refusal/cleanup and reusable-budget coverage.
One short unchanged-script allocation diagnostic and bounded source pair, with
explicit allocation/CPU/control/debt decisions. Do not claim R95 debt repayment
from unrelated or unmatched source measurements. No broad qualification replay;
batch platform/stress/package checks at a coherent retained delivery checkpoint.

Not selected: PyString layout. Prior R94 sampled actual object sizes are64B in
all1928text/1852CSV samples. Current source still has the same fields:8Binline,
three necessary ownership/backing/index references, scalar length/hash caches.
A new cold-state union would add cases/objects rather than remove a phase. No
prototype or predicted gain follows; this prevents a speculative storage redesign.
