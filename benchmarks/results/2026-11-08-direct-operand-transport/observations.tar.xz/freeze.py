from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'direct-comparison-r95/dedicated-handler'
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
shutil.copyfile(old/'catalog.json',r/'catalog.json')
checks={}
for name,expected in [('public-final11',62),('public-final10',62),('internal-final11',24),('internal-final10',24)]:
 text=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in text and re.search(r'Passed:\s+'+str(expected)+r'\b',text);checks[name]=expected
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
identity=dict(baselineSource='cb2b015e/core9d30623c; focused qualification passes, full CI42472284713 independent/in progress',candidateSource='cb2b015e plus R96 direct operand references, no carrier/runtime arity reader',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=json.loads((old/'identity.json').read_text())['productionSources'],focusedChecks=checks,qualification='62 public/24 internal focused Release peractual11/10, current source. Native snapshots, real suspension, errors, cancellation/refusal and funding/cleanup. Full candidate delivery pending.')
assert identity['coreSHA256']['before']=='9d30623cefedc5c97a86a3e9fc8200eeb9db54d6b8e524a0421ed85026a24a30'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:
 text=(old/name).read_text(encoding='utf-8').replace("old=r.parent.parent/'integer-utf8-r45'","old=r.parent/'integer-utf8-r45'")
 (r/name).write_text(text,encoding='utf-8')
print(json.dumps(identity['coreSHA256']),'Focused final source frozen; baseline R95 preserved.')

