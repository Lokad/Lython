from pathlib import Path
root=Path('src/Lokad.Lython')
p=root/'Runtime/LythonRuntime.Executable.Comparisons.cs';s=p.read_text(encoding='utf-8')
needle='''            var inputs = ReadInstructionInputs(ref execution, instruction, scope, invocation);'''
assert needle in s
s=s.replace(needle,'''            var first = ReadOperand(ref execution, instruction.InputStart, scope, 0);
            var second = ReadOperand(ref execution, instruction.SecondInput, scope, 1);''')
s=s.replace('inputs.First','first').replace('inputs.Second','second')
s=s.replace('invocation.ExecuteComparisonBranchAsync(instruction, inputs)','invocation.ExecuteComparisonBranchAsync(instruction, first, second)')
s=s.replace('ExecuteComparisonBranchAsync(ExecutableInstruction instruction, ExecutableInputs inputs)','ExecuteComparisonBranchAsync(ExecutableInstruction instruction, object first, object second)')
assert 'ExecutableInputs'not in s and 'inputs.'not in s
p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'Runtime/LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
a=s.index('        private bool TrySuspendForTypeSubscription(');z=s.index('        private bool TryPrepareSubscriptionCallable(',a)
segment=s[a:z].replace('ExecutableInstruction instruction, ExecutableInputs inputs','in ExecutableInstruction instruction, object receiver, object key')
segment=segment.replace('inputs.First','receiver').replace('inputs.Second!','key')
assert 'ExecutableInputs'not in segment
s=s[:a]+segment+s[z:];p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8')
old='public int ThirdInput => ValueInputCount == 3 ? _resultSlot : throw InvalidOperand(nameof(ThirdInput));';assert old in s
s=s.replace(old,'''public int ThirdInput => OpCode is ExecutableOpCode.StoreSubscript or ExecutableOpCode.StoreSubscriptLast
        ? _resultSlot : throw InvalidOperand(nameof(ThirdInput));''')
p.write_text(s,encoding='utf-8',newline='\r\n')
print('Completed remaining migration after the guard caught an unsuffixed Second reference; old source/error log preserved.')

