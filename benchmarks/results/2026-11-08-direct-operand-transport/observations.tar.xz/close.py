from pathlib import Path
import collections,hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-direct-operand-transport');out.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in identity['productionSources'].items())
checks={}
for name,expected in [('public-final11',62),('public-final10',62),('internal-final11',24),('internal-final10',24)]:
 text=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in text and re.search(r'Passed:\s+'+str(expected)+r'\b',text);checks[name]=expected
b=r/'b457';receipt=json.loads((b/'archive-receipt.json').read_text());assert receipt['complete']and receipt['jobs']==6
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(b/'observations.tgz')as archive:
 archived=json.loads((b/'identity.json').read_text())['coreSHA256']
 for member,role in [('current-core.dll','candidate'),('baseline-core.dll','reference')]:assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==archived[role]
baseline=json.loads(Path('benchmarks/results/2026-11-08-direct-comparison-branches/delivery-ci.json').read_text());assert baseline['conclusion']=='success'and baseline['headSha'].startswith('cb2b015e')
source=Path('src/Lokad.Lython/Runtime/Text/PyString.cs');old=r.parent/'allocation-selection-r94'
prior=json.loads((old/'identity.json').read_text())['productionSources'][source.as_posix()]
assert hashlib.sha256(source.read_bytes()).hexdigest()==prior
histograms={}
for label in ['text','csv']:
 rows=map(json.loads,(old/'allocation'/label/'allocation-ticks.jsonl').read_text(encoding='utf-8').splitlines())
 histograms[label]=dict(collections.Counter(row['objectBytes']for row in rows if row['type']=='Lokad.Lython.Runtime.Text.PyString'))
(r/'string-layout-source-gate.json').write_text(json.dumps(dict(source=str(source),sourceSHA256=prior,sameSourceAsR94=True,sampledObjectByteHistograms=histograms,decision='No cold-state wrapper/union selected; actual64B sampled strings with existing8Binline/owner/cache fields.',limitations='Individual sampled object sizes, not exact type-allocation totals/CPU attribution.'),indent=2)+'\n',encoding='utf-8')
(r/'original-conditions.txt').write_text('''Original conditions retained:
- First migration removed the bundle from the value file, then its guard caught an
  unsuffixed inputs.Second use before writing remaining files. The intermediate
  build failed with missing old type references. The finishing script updates all
  remaining callers; initial failing log and both scripts remain. No compatibility
  carrier or forwarding overload was retained.
- Final62public/24internal per actual11/10 pass; no architecture-only tests added.
- B457 all gates/archive/local verification pass. Allocation approximately neutral.
  Text baseline spread8.70% limits precision despite favorable direction. Report
  elapsed+0.88to+3.65% with2.72%old spread/mixed CPU is inconclusive/possible debt.
  Retain the component deletion and record those limits; no retiming to erase them.
- R95 text debt remains separate; unmatched source pairs do not prove repayment.
- PyString source gate used existing R94 samples, not another collection.64B
  samples contradict a speculative large cold-metadata footprint; no new layout.
- Baseline cb2 full CI42472284713 finished successfully independently after this
  collection. Original identity records its in-progress state at freeze time.
''',encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz',preset=6)as a:
 for file in sorted(r.rglob('*')):
  relative=file.relative_to(r)
  if not file.is_file()or any(part in {'images','retrieved','__pycache__'}for part in relative.parts)or file.name in {'payload.tgz','current-core.dll'}:continue
  a.add(file,arcname=relative.as_posix())
with tarfile.open(out/'observations.tar.xz')as a:
 for member in a.getmembers():assert member.isfile()and hashlib.sha256(a.extractfile(member).read()).digest()==hashlib.sha256((r/member.name).read_bytes()).digest()
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Retained source/focused checks pass, full candidate delivery pending',baselineSource='cb2b015e fully qualified CI42472284713',candidateSource=identity['candidateSource'],coreSHA256=identity['coreSHA256'],focusedChecks=checks,noRemainingVMUsersOrFixtures=True,limitations='Allocation neutral; variable text baseline and possible report elapsed debt; R95 text debt not repaid by inference.',archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest())
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
print('Operand removal/source/CPU/adverse diagnostics archived and verified;', (out/'observations.tar.xz').stat().st_size,'bytes. Baseline fully qualified, candidate delivery pending.')

