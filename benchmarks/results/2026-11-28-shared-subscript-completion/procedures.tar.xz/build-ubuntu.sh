#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/shared-subscript-b1977-20261128
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$HOME/.dotnet/dotnet" build src/Lokad.Lython -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental --disable-build-servers > "$lab/ubuntu-core-build.log" 2>&1