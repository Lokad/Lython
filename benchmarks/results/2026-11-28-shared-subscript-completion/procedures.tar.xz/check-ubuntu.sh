#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/shared-subscript-b1977-20261128
dotnet="$HOME/.dotnet/dotnet"
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
"$dotnet" test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~Subscript|FullyQualifiedName~Index|FullyQualifiedName~Descriptor|FullyQualifiedName~ClassSubscription|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~GeneratorRecordLookup|FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~AdmissionFailureCommandTests)' > "$lab/ubuntu-net11.0-public.log" 2>&1
"$dotnet" test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$lab/ubuntu-tests" \
  --filter 'Category!=Stress&(FullyQualifiedName~RecordFieldLookupOwnership|FullyQualifiedName~DescriptorMethodBinding|FullyQualifiedName~RawDescriptorGetDispatch|FullyQualifiedName~IterationIndexingSubsystem|FullyQualifiedName~ExecutableSubscriptStore|FullyQualifiedName~ExecutableAugmentedSubscript|FullyQualifiedName~StringIndexCacheCancellation|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~ExecutableStackAdmission)' > "$lab/ubuntu-net11.0-whitebox.log" 2>&1