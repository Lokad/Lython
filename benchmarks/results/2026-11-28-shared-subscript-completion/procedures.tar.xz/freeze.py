from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'closed-scalar-b1976-20261128/comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(prior / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('53b27d277')
assert digest(git('diff', '--binary', old['referenceRevision'], 'HEAD', '--', 'src', 'tests')) == old['sourcePatchSHA256']
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests')
patch = git('diff', '--binary', '--', 'src', 'tests')
assert patch.count(b'diff --git ') == 6
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(prior / 'candidate') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name in frozen if frozen[name] != images['candidate'][name]} == {core}

catalog_path = prior / 'representative.json'
assert hash_file(catalog_path) == old['catalogs'][catalog_path.name]['sha256']
catalog = read(catalog_path)
tuple_id = 'diagnostic.shipment-row-generator-reduction'
explicit_id = 'diagnostic.shipment-row-explicit-reduction'
iterable_id = 'diagnostic.shipment-starmap-iterable-rows'
indexed_id = 'diagnostic.shipment-row-generator-range-index'
original = next(case for case in catalog['cases'] if case['id'] == tuple_id)
needle = "row[key] == 'yes' for key in ('late', 'hold')"
assert original['source'].count(needle) == 1
assert original['source'].startswith('import csv\n\n')
source = original['source'].replace('import csv\n\n', 'import csv\n\noffsets = range(2)\n\n', 1)
source = source.replace(needle, "offsets[row[key] == 'yes'] for key in ('late', 'hold')")
encoded = source.encode('utf-8')
catalog['cases'].append(dict(original, id=indexed_id, source=source,
                             sourceUtf8Bytes=len(encoded), sourceSha256=digest(encoded)))
assert len(catalog['cases']) == 9
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': [[case, 'warm-async'] for case in (indexed_id, explicit_id, tuple_id, iterable_id)]})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
save(pair / 'identity.json', dict(sourceRevision=head, referenceRevision=head,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Share the complete receiver-first subscript stage and keep exact range indexing inline.'))
print('Froze exact 32-file images and nine CPython goldens.')