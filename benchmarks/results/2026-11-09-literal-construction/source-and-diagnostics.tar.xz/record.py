from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b489';dest=Path('benchmarks/results/2026-11-09-literal-construction');dest.mkdir(exist_ok=True)
for name in ['identity.json','assessment-local.json','compile-assessment.json']:shutil.copyfile(r/name,dest/name)
for name in ['assessment.json','observations.tgz']:shutil.copyfile(b/name,dest/name)
t=json.loads((b/'terminal.json').read_text(encoding='utf8'));assert hashlib.sha256((dest/'observations.tgz').read_bytes()).hexdigest()==t['receipt']['archiveSHA256']
(dest/'archive-receipt.json').write_text(json.dumps(t,indent=2)+'\n',encoding='utf8')
(dest/'focused-validation.json').write_text(json.dumps(dict(actualFrameworks=['net11.0','net10.0'],eachTarget=dict(internal=42,public=529),testsChanged=0,coverage='Escapes/raw/triple/adjacent/u/f/bytes, scalar diagnostics, annotation/pattern constants, cancellation/refusal and retained compile-owned aliases/cleanup',decision='Retain one source-to-literal pipeline; compilation allocation−2.94..−9.89%, quiet compilation/config compile-to-result gains; warm text+0.36..+1.01%possible debt, no universal CPU gain',fullDelivery='Pending coherent candidate delivery; previous CI qualifies847/coreac6b only'),indent=2)+'\n',encoding='utf8')
with tarfile.open(dest/'source-and-diagnostics.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.log','.json','.md','.patch','.before']:a.add(p,arcname=p.name)
 for name in ['warm-sync','warm-async','compile-sync']:a.add(r/name,arcname=name)
 a.add(r/'images-verified/candidate/Lokad.Lython.dll',arcname='candidate-core1be2.dll')
 for name in ['launch.py','launch.log','launch-command.py','terminal.json','terminal-observation.log','identity.json','observe-not-before.json']:a.add(b/name,arcname='b489/'+name)
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8');s+='''

## Source-to-literal construction consolidation (2026-11-09 Paris)

[R129/B489](results/2026-11-09-literal-construction/README.md), committed847/coreac6b
versus prototype1be2. Borrowed token spans, canonical literal/body decoder, direct
unescaped materialization, lazy adjacent concatenation/formatted parts. Removes
ordinary token copy/two-builder staging and synthetic f-string triple delimiters;
AST/static strings and runtime UTF8 storage/owners unchanged.42internal/529public
focused peractual11/10 pass; no tests/assertions changed. Compilation allocation
−2.94..−9.89% (config−11408B), warm neutralwithin0.023%; admission estimate unchanged.
Desktop textcompile+13.35..+15.03%/JSON+3.13..+6.93%adverse and warm/control drift
preserved. B489 six quiet jobs167.303s/allgates/archive/localpass: compileconfig
−4.79..−3.66%/CPU−5.54..−5.00%, text−1.37..+0.03%, JSON−3.03..−0.15%, report
−4.24..−2.60%; completeconfig−3.35..−1.08%, supportingCPU. Warmtext+0.36..+1.01%
possible debt, no warm gain/universalneutrality claim. Original large adverse
compile timings do not reproduce. Retain complete staging removal; no unchanged
retiming selected. Allusersjoined/RAMremoved/persistentarchive locallyverified,
terminalcached. Full candidate delivery pending; publication postponed.
''';p.write_text(s,encoding='utf8');print('R129 retained evidence archived; compilation gains and warm debt separate')
