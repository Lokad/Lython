from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'declaration-layout-r127';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(prior/'images-verified/candidate',r/'images-verified'/role)
assert sha(r/'images-verified/before/Lokad.Lython.dll')=='ac6bda6e26430beb475bacfc9abed4e560a55929dac26e7c95eb99b151479699'
shutil.copyfile(cores[0],r/'images-verified/candidate/Lokad.Lython.dll')
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf8'));config=json.loads((r.parent/'compile-phase-r128/catalog.json').read_text(encoding='utf8'))['cases'][1]
catalog['cases']=[c for c in catalog['cases']if c['id']!='scripts.csv-summary-functions.large']+[config]
assert len(catalog['cases'])==5
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf8')
for name in ['measure.py','compile-diagnostic.py']:shutil.copyfile(prior/name,r/name)
s=(prior/'assess-local.py').read_text(encoding='utf8');at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at)
s=s[:at]+"out['limitations']='R129 span-based literal/body decoding and lazy concatenation versus847/coreac6b. Five existing complete scripts/config; unchanged warm execution is control, compile measured separately. No public API/AST string/UTF8 runtime/allowance policy change. SharedCoreLib/processGC, elapsed diagnostic; allocation is actual CLR bytes, not admission reduction.'"+s[end:]
(r/'assess-local.py').write_text(s,encoding='utf8')
changed=subprocess.check_output(['git','diff','--name-only','--','src','tests'],text=True).splitlines()
i=dict(baseline='8472935f/coreac6b; full CI42543394041 pending separately',candidate='R129 working source-to-literal consolidation',coreSHA256={role:sha(r/'images-verified'/role/'Lokad.Lython.dll')for role in ['before','candidate']},changedSources={p:sha(Path(p))for p in changed},patchBase='8472935f',qualification='42internal/529public focused eachactual11/10 pass, no test changes',contract='AST/static strings and runtime UTF8 ownership unchanged; compilation admission estimate unchanged; warm execution expected unchanged')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');print(i['coreSHA256'])
