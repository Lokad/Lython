from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b489';b.mkdir();old=r.parent/'declaration-layout-r127/b487'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((r/'identity.json').read_text(encoding='utf8'))
for p,h in identity['changedSources'].items():assert sha(Path(p))==h
root='literal-construction-b489-20261109';unit='lython-b489-literal-construction-20261109'
for name in ['collect.py','archive-owned.py','run.sh','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('declaration-layout-b487-20261109',root).replace('lython-b487-declaration-layout-20261109',unit).replace('declaration-layout-b487-launch.py','literal-construction-b489-launch.py')
 if name=='collect.py':
  at=s.index('jobs=');end=s.index('\nassert len(jobs)',at)
  jobs=[[case,'compile']for case in ['scripts.config-edit.small','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']]+[['scripts.config-edit.small','compile-run'],['scripts.text-summary-helpers.large','warm']]
  s=s[:at]+'jobs='+repr(jobs)+s[end:]
  at=s.index("purpose='R127");end=s.index("',\n",at)
  s=s[:at]+"purpose='R129 source-to-literal consolidation. Committed847/coreac6b versus1be2, four compile jobs, complete config compile-to-result, unchanged warm text control. Original adverse desktop compile text/JSON retained; allocation is separate from CPU"+s[end:]
 if name=='launch.py':
  s=s.replace("reference=base/'dispatch-liveness-b486-20261109/candidate'","reference=base/'declaration-layout-b487-20261109/candidate'")
  at=s.index(" catalog_source=base/");end=s.index(" assert hashlib.sha256((reference/",at)
  s=s[:at]+''' identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'reference','reference-control','candidate','candidate-control'}
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
'''+s[end:]
 if name=='archive-owned.py':s=s.replace(",'space-plan.json','space-receipt.json'",'')
 (b/name).write_text(s,encoding='utf8',newline='\n')
shutil.copyfile(r/'images-verified/candidate/Lokad.Lython.dll',b/'current-core.dll');shutil.copyfile(r/'catalog.json',b/'representative.json')
i=dict(sourceRevision='R129 working source after8472935f, frozen1be2',coreSHA256={role:identity['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:sha(p)for p in (r/'images-verified/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=sha(b/'representative.json'))
(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
for name,path in [('pre-measurement-plan.md',Path('PLAN.md')),('source.patch',r/'source.patch')]:shutil.copyfile(path,b/name)
for name,data in {'baseline-source.json':identity,'focused.json':dict(eachTarget=dict(internal=42,public=529),actualTargets=['net11.0','net10.0'],testsChanged=0),'setup-contract.json':dict(roles=4,jobs=6,ownerSeconds=240,stopSeconds=30,marginSeconds=30,normalGcAndTiering=True,publication=False),'sizing.json':dict(jobs=6,warmupPerRoleSeconds=5,rounds=7,targetBatchSeconds=.15,expectedSeconds=180,ownerSeconds=240)}.items():(b/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('R129 one borrowed-span literal/body decoder; direct unescaped materialization, lazy adjacent concatenation/formatted parts, no synthetic triple wrappers. No public AST/runtime/ownership change or new framework. Four separate compile jobs, complete config compile-run, unchanged warm text control; four processes each, goldens/cleanup/balances checked.240sfiniteowner, joined users/RAM removal/archive under lease/localverification. Original adverse desktop text/JSON compilation preserved.\n',encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','focused.json','setup-contract.json','sizing.json','contract.md']:a.add(b/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py']:compile((b/name).read_text(encoding='utf8'),name,'exec')
s=(r.parent/'declaration-layout-r127/retrieve-b487.py').read_text(encoding='utf8').replace("b487","b489").replace('declaration-layout-b487-20261109',root).replace('lython-b487-declaration-layout-20261109',unit)
# The previous replacements change the numeric portion before root/unit names.
s=s.replace('declaration-layout-b489-20261109',root).replace('lython-b489-declaration-layout-20261109',unit).replace('B487','B489')
(r/'retrieve-b489.py').write_text(s,encoding='utf8');compile(s,'retrieve','exec')
print('Prepared B489',i['coreSHA256']['candidate'])
