from pathlib import Path
p=Path('src/Lokad.Lython/Frontend/Parser.StringLiterals.cs');s=p.read_text(encoding='utf8')
s=s.replace('TryDecodeStringLiteral(string literal,','TryDecodeStringLiteral(ReadOnlySpan<char> literal,').replace('        string literal,\n','        ReadOnlySpan<char> literal,\n')
start=s.index('        if (isRaw)\n');end=s.index('        var builder = new System.Text.StringBuilder(end - start);',start)
s=s[:start]+'''        return TryDecodeStringBody(literal[start..end], isRaw, out value, out message, decodeUnicodeEscapes);
    }

    private bool TryDecodeStringBody(ReadOnlySpan<char> literal, bool isRaw,
        [MaybeNullWhen(false)] out string value, out string message, bool decodeUnicodeEscapes = true)
    {
        CheckCancellation();
        value = string.Empty;
        var start = 0;
        var end = literal.Length;
        // Borrow the token body until its one AST value is materialized. Only
        // actual escape decoding needs mutable output storage.
        if (isRaw || literal.IndexOf('\\\\') < 0)
        {
            if (!ValidateScalarString(literal, out message)) return false;
            value = literal.ToString();
            return true;
        }

        message = "Invalid string literal. Malformed literal body.";
'''+s[end:]
s=s.replace('literal.AsSpan(i + 1, 2)','literal.Slice(i + 1, 2)')
s=s.replace('private bool ValidateScalarString(string text,','private bool ValidateScalarString(ReadOnlySpan<char> text,')
old='''        // This is an already-delimited f-string text segment, so synthetic
        // triple delimiters let the shared decoder process its body without
        // interpreting any quotes in the segment as token boundaries.
        return TryDecodeStringLiteral("\\"\\"\\"" + text + "\\"\\"\\"", out value, out message);'''
assert old in s
s=s.replace(old,'''        // A parsed f-string text segment already is a body, not another token.
        return TryDecodeStringBody(text, isRaw: false, out value, out message);''')
p.write_text(s,encoding='utf8')
p=Path('src/Lokad.Lython/Frontend/TokenizedSource.cs');s=p.read_text(encoding='utf8')
start=s.index('    public string GetString(int index)');end=s.index('\n    public void LineOfPosition',start)
s=s[:start]+'''    public string GetString(int index) => GetSpan(index).ToString();

    public ReadOnlySpan<char> GetSpan(int index)
    {
        var token = Tokens[index];
        return Buffer.AsSpan(token.Start, token.Length);
    }
'''+s[end:];p.write_text(s,encoding='utf8')
p=Path('src/Lokad.Lython/Frontend/Parser.Expressions.Primary.cs');s=p.read_text(encoding='utf8')
start=s.index('    private ExpressionSyntax? ParseStringLiteralExpression()');end=s.index('\n    private ExpressionSyntax? ParseLambdaExpression()',start)
original=s[start:end]
t=original.replace('var text = new System.Text.StringBuilder();\n        var parts = new List<FormattedStringPartSyntax>();\n        var hasFormatted = false;', '''var text = string.Empty;
        System.Text.StringBuilder? adjacent = null;
        List<FormattedStringPartSyntax>? parts = null;''')
# Ordinary and u-prefixed pieces share decoding and concatenation.
begin=t.index('            if (CurrentToken == Token.String)');finish=t.index('                if (!IsFormattedStringPrefix(prefix))',begin)
t=t[:begin]+'''            var prefix = IsNameToken(CurrentToken) && PeekToken(1) == Token.String
                ? _tokens.GetString(_position) : null;
            if (CurrentToken == Token.String || prefix is "u" or "U")
            {
                var pieceStart = _position;
                if (prefix is not null)
                {
                    var unicodePrefixToken = ReadToken();
                    if (_tokens.Tokens[unicodePrefixToken].Start + _tokens.Tokens[unicodePrefixToken].Length != _tokens.Tokens[_position].Start)
                    {
                        AddDiagnostic("LA1007", "String prefix must be adjacent to its literal.", unicodePrefixToken);
                        return null;
                    }
                }
                var tokenIndex = ReadToken();
                if (firstToken < 0) firstToken = pieceStart;
                if (!TryDecodeStringLiteral(_tokens.GetSpan(tokenIndex), out var value, out var message))
                {
                    AddDiagnostic(StringLiteralDiagnosticCode(message), message, tokenIndex);
                    return null;
                }
                if (adjacent is not null) adjacent.Append(value);
                else if (text.Length == 0) text = value;
                else adjacent = new System.Text.StringBuilder(text).Append(value);
                lastToken = tokenIndex;
                continue;
            }

            if (prefix is not null)
            {
'''+t[finish:]
old='''                if (text.Length > 0)
                {
                    parts.Add(new FormattedStringTextPartSyntax(text.ToString()));
                    text.Clear();
                }

                parts.AddRange(segmentParts);
                hasFormatted = true;'''
new='''                parts ??= [];
                if (adjacent is not null) { text = adjacent.ToString(); adjacent = null; }
                if (text.Length > 0)
                {
                    parts.Add(new FormattedStringTextPartSyntax(text));
                    text = string.Empty;
                }

                parts.AddRange(segmentParts);'''
assert old in t;t=t.replace(old,new)
t=t.replace('''        if (!hasFormatted)
        {''','''        if (adjacent is not null) text = adjacent.ToString();
        if (parts is null)
        {''')
t=t.replace('                text.ToString(),','                text,').replace('parts.Add(new FormattedStringTextPartSyntax(text.ToString()));\n            text.Clear();','parts.Add(new FormattedStringTextPartSyntax(text));')
s=s[:start]+t+s[end:];p.write_text(s,encoding='utf8')
print('One span decoder/body path; ordinary concatenation storage only when needed')
