# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts live in docs; historical conditions, failed/adverse results and
prototypes remain in [experimental history](benchmarks/EXPERIMENTS.md) and linked
immutable results. Completing an experiment does not complete this objective.

## Actual delivery status

- **Fully qualified reference:** R119 d05; R120/R121 runtime 6f76/core C617 with
  typed-fixture correction d97. Cached CI 42527042378 success, observed Nov8
  22:19:56 UTC: Windows/Ubuntu full Release actual .NET11/10, original stress
  both targets and installed-core consumers. Do not repeat unchanged qualification.
- **R125 fully qualified:** 3109c871/core004e. Requested text-reader
  cleanup waits for copy/decoder/append borrows, pending reads and awaited disposal.
  Qualified-reference regressions demonstrated premature342B refund including72B
  raw input.228 internal/140 public focused cases peractual11/10,16 new cases pass.
  B485 three jobs86.526s, all source/golden/quiet/ownership/cleanup/archive gates pass;
  no CPU gain claim. Cached CI42536319061 success observed Nov9 00:08:01UTC verifies
  Windows/Ubuntu full Release actual11/10, original stress both and installed-core
  consumers. Terminal cached, never requery; qualifies3109/core004e only.

- **R126 fully qualified:** 9f2e1f51/core85e.
  Five forced CLR-liveness NoInlining attributes/comments/imports removed:17 lines,
  same algorithms/owners/retirement.189 internal/229 public plus21 internal stack/
  60 public stack cases pass peractual11/10; matching probes rebuilt. Existing
  GC/lifetime tests unchanged. Allocation neutral within0.064%; no CPU gain claim.
  Desktop sync text/report improve diagnostically, JSON+5.69..+8.16% adverse;
  async controls drift17.54%. Retain development simplification with explicit debt;
  B486 three jobs87.001s/allgates/archive/localpass: JSON elapsed adverse does
  not reproduce, text supports possible gains with reference spread5.27%, report
  inconclusive/possible CPU debt. All24797ILbodies/signatures unchanged; five
  implementation bits differ. Cached CI42538659198 success observed Nov9
  00:35:33UTC: Windows/Ubuntu full Release actual11/10, original stress both and
  installed-core consumers. Terminal cached, never requery. R127 is separate.

- **R127 committed, candidate delivery running:** 8472935f/coreac6b, shared
  declaration signature/generator facts. Focused both targets and quiet B487 pass;
  compilation allocation−0.10..−0.32%, warm effectively neutral. CPU effects/debts
  remain separate. CI42543394041 dispatched01:02:27UTC for full platform/actual11+10/
  original stress both/installed-core. Second observation01:13:05UTC: both full jobs running; next>=01:18:05UTC.
  B488 compile attribution completed and verified; R129 separately selected below.

- **R124 held, not promoted:** compiler-owned named slots/shared defaults; extra
  registry/mapping/guard left general binding necessary. Warm allocation neutral,
  compile allocation+0.20–0.25%; B483/B484 no stable whole-script CPU gain, primary
  CSV candidate spread4.33%. Correctness/source/binaries/original adverse evidence
  preserved. Production restored with fresh builds; useful named/default/suspended/
  cancellation/refusal/alias tests retained. No permanent rejection or percentage veto.
- **Earlier completed work preserved:** shared compiler-fact correction, direct
  UTF-8 formatting/storage, native helper returns, native JSON construction, record
  capacity/adoption, primitive result facts, flat lookup storage and execution-owned
  function field facts. Native-return allocation−19.92/−19.31% is established;
  original elapsed improvements diagnostic. Delivered code qualified, no replay.

**Separate measurements/debts:** formatting allocation−8.67% established;
controlled B102 elapsed/CPU−5–8% supports retention, original adverse15.125ms remains
unexplained/preserved. R110 wide allocation−8.56–8.58%. R119 CSV/JSON~5–10% elapsed,
custom~3–6%, supporting CPU; text inconclusive, report CPU+1.53–6.25% possible debt.
R120 custom allocation−1.71%, no CPU claim. R121 confirmation report−6.09–6.66%,
validated CSV−3.30–5.45%, supporting CPU; inline control±0.60%, async float variable.
Earlier combined async-float+1–2% possible debt remains. Source pairs are not
additive and do not silently settle older custom/config/report debts.

**CPython baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R122/B481, measured6f76/C617
versus CPython3.13.16:15 jobs311.685s, all collection/archive gates pass. Compile-to-
result validated CSV1.17x, CSV1.01–1.03x variable, text1.52–1.53x, JSON0.91–0.96x
variable, report1.32–1.33x. Compilation/warm separate; mediated RAM-file I/O,
validation and prior-result cleanup included. Startup/pending I/O/RSS/embedding tails
unmeasured. Config/search/manifest remain historical726. Refresh after a substantial
coherent change; do not relabel historical measurements as current HEAD.

## Next deliverables: runtime/performance track

1. **R127 retained; coherent delivery checkpoint.** Commit canonical declaration
   metadata and its source-paired evidence. Focused 41internal/360public plus
   23internal/149public cases pass peractual11/10. Compilation allocation−0.10..−0.32%;
   warm allocation neutral within0.066%. B487 six quiet jobs168.433s/allgates/archive
   localpass: validated CSV+0.36..+1.06%, CSVsummary−0.25..+1.61%, text−3.50..−0.91%,
   JSON−1.79..+1.43%, report−3.02..−0.05%, async text−3.22..−1.00%; coarseCPU mixed.
   Preserve desktop CSV+13..15%/text+21..22% and possible small quiet CSV debt.
   Retain for work/storage removed, no universal gain/neutrality claim. Full candidate
   Windows/Ubuntu actual11/10, original stress both and installed-core checks next;
   keep working while CI runs. R125/R126 already fully qualified: no unchanged replay.

2. **Complete call/frame/operand simplification.** Hypothesis: consolidate canonical
   preparation/shared compiler facts to eliminate a COMPLETE repeated phase.
   R123 helper/inline~5.1/3.3ms includes useful calls/tuple work; binding/workspace
   4.97%leaf, preparation4.14%, tuple0.99%, context0. Inclusive frame work is not a
   removable tax. Existing BeginPendingCall/BeginBoundCall already uses a linear
   caller-return runner and lazy context promotion. Bound locals, tuple unpack and
   final tuple arrays already borrow/transfer; layouts are shared and ordinary
   presence bits inline. Do not recreate a VM stack, missing local array or context.
   Generic variadic staging exists but is absent from the measured primary helper;
   it is not demonstrated dominant work. R124 facts may serve broader consolidation.
   Source gate ~20min: name actual eliminated storage/work, displaced code and
   affected validated CSV/report/JSON/text helpers BEFORE implementation. Preserve
   native returns/direct operands, defaults/closures/recursion/order, real suspension
   and funded aliases. Do not revive slower R71 arenas/control/carriers or add an
   evaluator/owner/dispatcher. A justified temporary setback needs an explicit
   implementation-completion milestone and a remaining regression-debt decision.
   Acceptance: semantics/current cancellation/refusal/ownership; primary scripts and
   native controls, separate compile/warm/allocation/CPU, bounded quiet comparison.

   R127 removes role arrays/lowered parameter retention beside the flat names/index
   table, per-call frontend shape maps, repeated generator body scans and synthetic
   lowered wrappers for lexical names. Analysis/lowering/runtime share finalized
   declaration facts; captured flow states/defaults/annotations remain separate.
   No new registry/guard/cache/owner/carrier/option. Evidence/history linked above.
   R128/B488 attribution complete on847/coreac6b: two~6s compile-only samples,
   1172/1199 active-worker samples, parsing43.09/25.94%, abstract analysis19.11/29.19%,
   executable construction18.52/18.77%, lexical preparation7.25/8.42%, lowering2.30/3.59%.
   Unknown leaf13.74/15.93%; inlining/truncated stacks limit exact phase attribution.
   Existing compile lane includes prior-script cleanup; no guest I/O/warm timing.
   All source/quiet/golden/Closed/join/RAM/archive/local gates pass, terminal cached.
   No single dominant duplicate phase or evidence for deleting lowered evaluation.

   **R129 selected: consolidate source-to-string-literal construction.** Parsing is
   a measured material phase, not entirely removable work. Ordinary literal source
   currently becomes a token substring, a decoded builder/string, then a second
   concatenation builder/string; parts lists are allocated even without f-strings.
   Use borrowed source spans, one canonical body decoder, direct unescaped body
   materialization and lazy adjacent-piece concatenation; f-string text uses that
   body decoder directly instead of constructing synthetic triple delimiters.
   Delete displaced token copies, unconditional builders/parts storage and delimiter
   wrappers; keep AST/static string semantics and runtime UTF-8 ownership unchanged.
   Affected: new config, CSV/text/JSON/report scripts and imports, not an expected warm
   execution optimization. Acceptance: escapes/raw/triple/adjacent/u/f/bytes pieces,
   scalar rejection, source spans/diagnostic order, annotation/pattern literals,
   current parser cancellation and shared compilation-owner refusal/cleanup.
   Focused Release both targets; separate compile allocation/latency and complete
   compile-to-result comparison with unchanged warm controls. Keep adverse/uncertain
   observations. Completion: one decoder path, no synthetic delimiters or ordinary
   token copy/two-builder staging; no new representation/cache/framework/public API.
   Stop after one coherent implementation and bounded controlled comparison to decide
   retention/refinement and regression debt, then continue broader runtime priorities.

3. **Independent bulk/text/frontend work.** Each selected redesign must name its
   hypothesis, complete work/storage eliminated, affected scripts, semantic acceptance,
   displaced implementation and bounded controls before coding. Source gate ~20min;
   if no real phase is demonstrated, record uncertainty and pursue independent work.
   - Bulk CSV6–8% was reconsidered with its adverse control. Current CSV adopts row
     arrays and bulk-admits final fields; JSON constructs direct/shared-layout values.
     The old copying premise is gone. Preserve duplicates/order/rest fields/hooks/
     retained rows. R118 get/add/store would duplicate CFG/proofs; no prototype.
   - Text: native/inline UTF-8, casing split, final-buffer formatting and cached hashes
     delivered. Raw windows already borrow input; independent output protects refill.
     R125 fixes actual pending-borrow funding first. R54/R60 views had width/accessor/
     control debt; a new representation needs retained-page/identity/completion proof.
     Existing b1/core93e9 text CPU/PC evidence is named-source evidence, not HEAD:
     18.79%prefix,8.36%casing/split,4.31%monitor,0leafbinding/context. Hash walks,
     repeated proofs and per-fragment budget resizes were not present. R126 reassesses
     only the liveness-policy premise, not all useful work in those samples.
   - Frontend: ScopeDirectiveFacts already memoizes syntax, LexicalScopePreparation
     publishes before lowering. Repeated ForFunction callers are not duplicate walks.
     Identify actual repeated analysis and compile-to-result costs before consolidation.
   No open-ended audit/capture campaign. Boxing/inclusive samples alone do not justify
   universal tagged slots, a JIT or VM-stack replacement. The whole-script objective
   remains active after individual deletions or experiments.

## Independent regex track

Core owns Python/native UTF-8 names, byte captures/scalar positions/original-subject
windows, effective flags/errors/replacements, one frontend/runtime/import provider,
current tokens and existing explicit ownership. Continue core development independently
of publication. Adapter-local bridges/pinned development producers are allowed outside
core. Optional adapter nonpackable, ordinary selected pin0.4. Dev55/d6067925 focused
86 internal/514 public peractual11/10 already passed; no unchanged replay or sibling
edits/builds. Final selected-package qualification needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without an
earlier token. Only affected final adapter checks defer. Contract forwarding/unwind,
Python semantics and actual backend speed remain separate evidence.

## Iteration and containment

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable controls or inconclusive observations establish uncertainty, not
failed designs or permanent closure. Size runs for usable quiet-VM observations;
percentages inform decisions, not automatic vetoes. Preserve original failed/adverse
conditions. Simplification, allocation reduction and CPU gains are distinct claims.
Focused Release checks during development; batch full delivery at meaningful boundaries.

AGENTS.md governs fully managed safety/stack admission, host mediation, current-token
cancellation, coarse shared admission/preflights/overlap, funded aliases/results/
caches/pending users and awaited cleanup. Refusal is terminal. No unsafe/Unsafe/native
probes, tracing/weak reclaim/forced GC, caps/fuel/quotas, hidden allowance, silent regex
fallback or abandoned work. No local build/test/measurement overlap. Fresh nonincremental
builds after restoration; explicit UTF-8. Only core Release packages to artifacts/nuget.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent worker/catalog/raw
storage separate from owned RAM fixtures; join/verify/unmount/archive under lease,
verify locally. ThroughB488 terminal/cached/verified, no users/fixtures; never requery.
New active CI observations at least5min apart; cache terminal results. Space recovery
only fresh idle exact-byte links, permitted canonical ownership/writable parents,
all inode aliases/SHA proof and a persisted pre-mutation plan. Preserve every historical
path/byte/archive and original failed collection condition. Publication postponed.
