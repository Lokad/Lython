from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent/'b489';remote='/home/lokad/lython-bench-checks/literal-construction-b489-20261109'
assert not(r/'terminal.json').exists()
notbefore=json.loads((r/'observe-not-before.json').read_text(encoding='utf8'))['doNotObserveBeforeUTC']
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(notbefore)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code="""from pathlib import Path
import fcntl,hashlib,json,subprocess
root=Path(REMOTE)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 unit=subprocess.check_output(['systemctl','show','lython-b489-literal-construction-20261109.service','--property=LoadState,ActiveState,Result,MainPID,ExecMainStatus'],text=True)
 receipt=json.loads((root/'archive-receipt.json').read_text())
 exitcode=(root/'exit-code.txt').read_text().strip()
 assert exitcode=='0' and 'ActiveState=active' not in unit and 'MainPID=0' in unit,(unit,exitcode)
 assert receipt['complete'] and receipt['jobs']==6 and receipt['allWorkersJoined']
 assert not(root/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
 print(json.dumps(dict(unit=unit,exitcode=exitcode,receipt=receipt,noUsersOrFixtures=True)))
""".replace('REMOTE',repr(remote))
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True)
(r/'terminal-observation.log').write_bytes(done.stdout+b'\n'+done.stderr)
assert done.returncode==0,done.stderr.decode()
terminal=json.loads(done.stdout);(r/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf8')
archive=r/'observations.tgz'
scp=['C:/Windows/System32/OpenSSH/scp.exe','-q','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
subprocess.run(scp+['lokad@20.166.121.73:'+remote+'/observations.tgz',str(archive)],check=True)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==terminal['receipt']['archiveSHA256']
with tarfile.open(archive)as a:a.extractall(r/'retrieved',filter='data')
d=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf8'))
assert d['complete']and len(d['jobs'])==6 and all(j['workersJoinedAndFixturesRemoved']for j in d['jobs'])
for n in ['machine-before.json','machine-after.json']:
 assert json.loads((r/'retrieved/confirmation'/n).read_text(encoding='utf8'))['gate']['quiet']
assert hashlib.sha256((r/'retrieved/current-core.dll').read_bytes()).hexdigest()==json.loads((r/'identity.json').read_text())['coreSHA256']['candidate']
s=(r.parent.parent/'prepared-binding-r124/b483/assess-vm.py').read_text(encoding='utf8').replace("len(d['jobs'])==4","len(d['jobs'])==6")
(r/'assess-vm.py').write_text(s,encoding='utf8')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'assess-vm.py')],check=True)
print('B489 terminal/cached, archive verified locally:',terminal['receipt'])
