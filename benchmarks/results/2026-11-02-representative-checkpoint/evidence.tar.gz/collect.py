"""Bounded current representative checkpoint; compilation and public execution separate."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path('/home/lokad/lython-bench-checks')
tree = base / 'representative-b104-20261102'
dotnet = Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
python = Path('/home/lokad/lython-bench-toolchains/cpython/3.13.16/bin/python3.13')
relative = 'candidate/Lokad.Lython.Benchmarks.dll'
worker = tree / relative
baseline = worker
catalog = tree / 'representative.json'
output = Path(sys.argv[1]).resolve()
workloads = ['scripts.csv-summary-helpers.large','scripts.text-summary-helpers.large',
    'scripts.json-summary-helpers.large','scripts.config-edit.large','scripts.file-search.large',
    'scripts.file-manifest.large','scripts.report-render.large']
jobs = [(case, lane) for lane in ('compile-run','warm') for case in workloads]
jobs += [(case,'compile') for case in ['scripts.csv-summary-helpers.large','scripts.report-render.large']]
cases = [case for case, lane in jobs]

env = os.environ.copy()
env['DOTNET_ROOT'] = str(dotnet.parent)

with (base / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    output.mkdir(exist_ok=False)
    time.sleep(2)
    started = time.monotonic()
    record = dict(performanceQualified=False, revision=json.loads((tree / 'identity.json').read_text())['sourceRevision'],
        baselineRevision='identical current core/host control',
        lanes='seven compile-run, seven warm, CSV/report compile-only', wallBudgetSeconds=240, cases=cases, jobs=[])
    def save():
        (output / 'collection.json').write_text(json.dumps(record, indent=2)+'\n')
    def run(arguments, name):
        command = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--pipe', '--collect',
                   '--unit=lython-representative-b104-' + name + '-' + str(os.getpid()), '--uid=lokad',
                   '--working-directory=' + str(tree), '-p', 'RuntimeMaxSec=30',
                   '-p', 'TimeoutStopSec=0', '-p', 'KillMode=control-group',
                   '--setenv=DOTNET_ROOT=' + str(dotnet.parent), '--setenv=DOTNET_TieredCompilation=0',
                   str(dotnet), str(worker), *arguments]
        with (output / (name+'.log')).open('w') as log:
            result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=35)
        if result.returncode: raise RuntimeError((output / (name+'.log')).read_text())
    run(['--compare', 'check-machine', '--out', str(output / 'machine-before.json')], 'before')
    for i, (case, lane) in enumerate(jobs):
        if time.monotonic()-started > 200: raise TimeoutError('Reserve cleanup within the prospective budget.')
        stem = str(i).zfill(2)+'-'+lane+'-'+case
        run(['--compare', 'micro', '--catalog', str(catalog), '--dotnet', str(dotnet),
             '--baseline-worker', str(baseline), '--python', str(python), '--python-worker',
             str(tree / 'cpython-worker.py'), '--out', str(output / (stem+'.json')),
             '--case', case, '--lane', lane], stem)
        receipt = json.loads((output / (stem+'.json')).read_text())
        record['jobs'].append(dict(case=case, lane=lane, receipt=stem+'.json', state=receipt.get('state'), summaries=receipt.get('summaries')))
        save()
        print(stem, 'complete', flush=True)
    run(['--compare', 'check-machine', '--out', str(output / 'machine-after.json')], 'after')
    record['elapsedSeconds'] = time.monotonic()-started
    save()
    print('Bounded16-job checkpoint complete; lease released.', flush=True)
