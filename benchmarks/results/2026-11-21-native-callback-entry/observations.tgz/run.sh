set -eu
root=/home/lokad/lython-bench-checks/native-callback-entry-b1256-20261121-space-audited
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
