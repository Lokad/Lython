from pathlib import Path
import hashlib,json,tarfile

base=Path(__file__).resolve().parent
donor=base/'quiet-audited'
root=base/'confirmation'
q=root/'quiet'
q.mkdir(parents=True)
read=lambda path:path.read_text(encoding='utf-8')
load=lambda path:json.loads(read(path))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path, text):
    if path.suffix=='.py': compile(text,str(path),'exec')
    path.write_text(text,encoding='utf-8',newline='\n')

prior=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['archiveSHA256']==digest(donor/'observations.tgz')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
location='/home/lokad/lython-bench-checks/native-callback-entry-confirm-b1257-20261121'
unit='lython-b1257-native-callback-entry-confirm-20261121'
emit(q/'identity.json',read(donor/'identity.json'))
for name in ('collect.py','run.sh','archive-owned.py','retrieve.py'):
    text=read(donor/name).replace(prior['root'],location).replace(prior['unit'],unit)
    if name=='collect.py':
        a=text.index('\njobs = ')
        b=text.index('\nassert len(jobs)',a)
        text=text[:a]+"\njobs = [('scripts.text-summary-helpers.map-callback.large','warm')]"+text[b:]
        text=text.replace('if job_index % 2 == 0: labels.reverse()','if job_index % 2 != 0: labels.reverse()')
        text=text.replace('accumulate 12 seconds','accumulate 22 seconds').replace('warmupSeconds=12','warmupSeconds=22')
        text=text.replace('min(warmed)<12','min(warmed)<22').replace('warmed[i]>=12','warmed[i]>=22')
        text=text.replace('targetBatchSeconds=.8','targetBatchSeconds=1.0').replace('counts[i]*.8/','counts[i]/')
    if name in ('collect.py','archive-owned.py','retrieve.py'):
        text=text.replace('==3','==1').replace('jobs=3,','jobs=1,')
    emit(q/name,text)
assert b'\r' not in (q/'run.sh').read_bytes()
assert "status['receipt']['jobs']==1" in read(q/'retrieve.py')
parts=('identity.json','collect.py','archive-owned.py','run.sh')
payload=q/'payload.tgz'
with tarfile.open(payload,'w:gz') as stream:
    for name in parts: stream.add(q/name,arcname=name)
config=dict(prior,root=location,unit=unit,source=prior['root'],sourceRole='reference',retireGroups=[],
            sourceFiles=prior['identity']['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],
            donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=digest(payload),
            unpackedBytes=sum((q/name).stat().st_size for name in parts))
emit(q/'config.json',json.dumps(config,indent=2)+'\n')
text=read(donor/'remote-launch.py')
a=text.index('\nc=')+1
b=text.index('\nb=Path(',a)
text=text[:a]+'c='+repr(config)+text[b:]
text=text.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
text=text.replace('lython-b1256-fixtures','lython-b1257-fixtures')
assert "os.link(source/role/n,p)" in text
emit(q/'remote-launch.py',text)
emit(root/'launch.py',read(base/'launch-audited.py').replace('quiet-audited','quiet').replace('305','155').replace(
    'Native callback entry comparison','Native callback entry text confirmation'))
emit(root/'summarize.py',read(base/'summarize.py').replace("len(raw['jobs'])==3","len(raw['jobs'])==1"))
