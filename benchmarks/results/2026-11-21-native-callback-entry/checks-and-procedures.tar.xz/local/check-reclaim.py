import fcntl, hashlib, json, os, shutil, stat, sys
from pathlib import Path
base=Path('/home/lokad/lython-bench-checks').resolve()
groups=json.load(sys.stdin)
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    results=[]
    for group in groups:
        reasons=[]
        device_inode=None
        missing=[]
        for name in group['paths']:
            path=base/name
            try:
                info=path.lstat()
                current=(info.st_dev,info.st_ino)
                if (path.resolve()!=path or not path.is_relative_to(base) or not stat.S_ISREG(info.st_mode) or
                    info.st_uid!=os.getuid() or info.st_nlink!=group['links'] or info.st_size!=group['bytes'] or
                    (device_inode is not None and current!=device_inode) or digest(path)!=group['sha256']):
                    reasons.append(name+': image or link check failed')
                device_inode=current
            except OSError as error:
                reasons.append(name+': '+str(error))
        for name,expected in group['archives'].items():
            path=base/name
            if not path.is_file():
                missing.append(name)
            elif digest(path)!=expected:
                reasons.append(name+': archive hash differs')
        results.append(dict(imageSHA256=group['sha256'],errors=reasons,missingRemoteArchives=missing))
    print(json.dumps(dict(free=shutil.disk_usage(base).free,checked=results),indent=2))
