from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
notes = lab.parent
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(notes / 'native-dict-item-cursor/representative.json')
original = catalog['cases'][0]
assert original['id'] == 'scripts.json-normalized-records.large'
source = original['source'].replace('[normalize(row) for row in records]', 'list(map(normalize, records))')
assert source != original['source']
encoded = source.encode('utf-8')
mapped = dict(original, id='scripts.json-normalized-records.map-callback.large', source=source,
              sourceUtf8Bytes=len(encoded), sourceSha256=hashlib.sha256(encoded).hexdigest())
text_case = next(case for case in load(notes / 'callback-transport-r149/catalog.json')['cases']
                 if case['id'] == 'scripts.text-summary-helpers.map-callback.large')
catalog['cases'] = [mapped, text_case, original]
(lab / 'representative.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
