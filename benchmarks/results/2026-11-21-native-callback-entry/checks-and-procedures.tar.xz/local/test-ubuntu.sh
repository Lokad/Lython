#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/native-callback-entry"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/native-callback-entry"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Map|FullyQualifiedName~Sorted|FullyQualifiedName~Regex|FullyQualifiedName~Json)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter 'FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~SortKeyScenario' -v quiet 2>&1 | tee "$logs/suspension-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Binding|FullyQualifiedName~Closure|FullyQualifiedName~Stack)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"