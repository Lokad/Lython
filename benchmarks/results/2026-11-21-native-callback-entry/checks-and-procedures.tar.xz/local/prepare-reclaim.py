from collections import defaultdict
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
inventory = json.loads((lab/'inventory-quiet.json').read_text(encoding='utf-8'))
base = PurePosixPath('/home/lokad/lython-bench-checks')
names = [item for item in subprocess.check_output(['git','ls-files','-z','benchmarks/results'],cwd=repo).decode().split('\0') if item]
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
archives = {}
cores = {}
for name in names:
    path = repo/name
    if path.name == 'observations.tgz':
        receipt = path.with_name('archive-receipt.json')
        if not receipt.is_file(): continue
        record = read(receipt)
        if not all(record.get(key) for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease')): continue
        digest = record.get('archiveSHA256')
        if digest and digest == sha(path.read_bytes()):
            archives[digest] = name
    elif 'core.dll.gz' in path.name:
        try:
            raw=gzip.decompress(path.read_bytes())
        except OSError:
            continue
        cores[sha(raw)] = (name,len(raw))

roots = {}
for elem in subprocess.check_output(['rg','--files','--hidden','--no-ignore','-g','config.json',str(lab.parent)],cwd=repo).decode().splitlines():
    path = Path(elem)
    receipt = path.with_name('archive-receipt.json')
    if not receipt.is_file(): continue
    try:
        info = read(path)
        proof = read(receipt)
    except (OSError, ValueError):
        continue
    root = PurePosixPath(info.get('root',''))
    if root.parent != base or proof.get('archiveSHA256') not in archives: continue
    files = info.get('identity',{}).get('imageFiles',{})
    if not files or not all(isinstance(value,dict) for value in files.values()): continue
    roots[root.name] = (files,proof['archiveSHA256'])

groups = defaultdict(list)
for row in inventory['shares']:
    groups[(row['device'],row['inode'])].append(row)
options = []
protected = ('native-dict-item-cursor-b1251', 'normalize-json-cpython', 'direct-dict-enumeration-b1254',
             'direct-dict-enumeration-narrow-b1255','native-callback-entry')
for aliases in groups.values():
    if len(aliases) != aliases[0]['links'] or any(row['path'].startswith(protected) for row in aliases):
        continue
    digests = set()
    proofs = {}
    for row in aliases:
        root, role, _ = PurePosixPath(row['path']).parts
        if root not in roots: break
        images, archive = roots[root]
        digest = images.get(role,{}).get('Lokad.Lython.dll')
        if digest not in cores or cores[digest][1] != row['bytes']: break
        proofs[root+'/observations.tgz'] = archive
        digests.add(digest)
    else:
        if len(digests) != 1: continue
        digest, = digests
        options.append((min(row['mtime'] for row in aliases), dict(
            archives=proofs,paths=sorted(row['path'] for row in aliases),bytes=aliases[0]['bytes'],
            links=len(aliases),sha256=digest,verifiedCanonicalGitImage=cores[digest][0])))
options.sort()
selected = []
selected_bytes = 0
for _, option in options:
    selected.append(option)
    selected_bytes += option['bytes']
    if selected_bytes >= 160*1024**2: break
assert selected_bytes > 96*1024**2, (len(options), selected_bytes)
(lab/'reclaim-proof.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'Verified immutable archives for {len(options)} eligible inodes. Selected {len(selected)} inodes with {selected_bytes} bytes.')
