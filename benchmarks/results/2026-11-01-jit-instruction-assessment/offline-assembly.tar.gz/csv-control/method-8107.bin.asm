
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-8107.bin:     file format binary


Disassembly of section .data:

000071dc0186b360 <.data>:
    71dc0186b360:	55                   	push   rbp
    71dc0186b361:	41 57                	push   r15
    71dc0186b363:	41 56                	push   r14
    71dc0186b365:	41 55                	push   r13
    71dc0186b367:	41 54                	push   r12
    71dc0186b369:	53                   	push   rbx
    71dc0186b36a:	48 81 ec 18 01 00 00 	sub    rsp,0x118
    71dc0186b371:	48 8d ac 24 40 01 00 	lea    rbp,[rsp+0x140]
    71dc0186b378:	00 
    71dc0186b379:	33 c0                	xor    eax,eax
    71dc0186b37b:	48 89 85 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rax
    71dc0186b382:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    71dc0186b387:	62 71 7e 48 7f 85 f0 	vmovdqu32 ZMMWORD PTR [rbp-0x110],zmm8
    71dc0186b38e:	fe ff ff 
    71dc0186b391:	62 71 7e 48 7f 85 30 	vmovdqu32 ZMMWORD PTR [rbp-0xd0],zmm8
    71dc0186b398:	ff ff ff 
    71dc0186b39b:	62 71 7e 48 7f 85 70 	vmovdqu32 ZMMWORD PTR [rbp-0x90],zmm8
    71dc0186b3a2:	ff ff ff 
    71dc0186b3a5:	c5 7e 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm8
    71dc0186b3aa:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    71dc0186b3ae:	48 89 bd 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rdi
    71dc0186b3b5:	80 7f 60 00          	cmp    BYTE PTR [rdi+0x60],0x0
    71dc0186b3b9:	0f 84 60 05 00 00    	je     0x71dc0186b91f
    71dc0186b3bf:	48 8b 47 40          	mov    rax,QWORD PTR [rdi+0x40]
    71dc0186b3c3:	48 8b 58 10          	mov    rbx,QWORD PTR [rax+0x10]
    71dc0186b3c7:	48 85 db             	test   rbx,rbx
    71dc0186b3ca:	0f 84 d3 07 00 00    	je     0x71dc0186bba3
    71dc0186b3d0:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
    71dc0186b3d4:	44 8b 78 28          	mov    r15d,DWORD PTR [rax+0x28]
    71dc0186b3d8:	48 85 f6             	test   rsi,rsi
    71dc0186b3db:	0f 84 cb 05 00 00    	je     0x71dc0186b9ac
    71dc0186b3e1:	44 39 7e 08          	cmp    DWORD PTR [rsi+0x8],r15d
    71dc0186b3e5:	0f 82 c6 05 00 00    	jb     0x71dc0186b9b1
    71dc0186b3eb:	48 83 c6 10          	add    rsi,0x10
    71dc0186b3ef:	48 89 b5 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rsi
    71dc0186b3f6:	44 89 bd 5c ff ff ff 	mov    DWORD PTR [rbp-0xa4],r15d
    71dc0186b3fd:	48 89 9d 48 ff ff ff 	mov    QWORD PTR [rbp-0xb8],rbx
    71dc0186b404:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
    71dc0186b408:	48 89 95 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],rdx
    71dc0186b40f:	45 85 ff             	test   r15d,r15d
    71dc0186b412:	0f 84 aa 05 00 00    	je     0x71dc0186b9c2
    71dc0186b418:	45 8b f7             	mov    r14d,r15d
    71dc0186b41b:	49 81 c6 80 00 00 00 	add    r14,0x80
    71dc0186b422:	48 8b b5 48 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb8]
    71dc0186b429:	40 38 36             	cmp    BYTE PTR [rsi],sil
    71dc0186b42c:	48 bf 48 c7 f3 00 dc 	movabs rdi,0x71dc00f3c748
    71dc0186b433:	71 00 00 
    71dc0186b436:	e8 85 5e 7e 7c       	call   0x71dc7e0512c0
    71dc0186b43b:	4c 8b e8             	mov    r13,rax
    71dc0186b43e:	49 8d 7d 08          	lea    rdi,[r13+0x8]
    71dc0186b442:	48 8b b5 48 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb8]
    71dc0186b449:	e8 f2 4b 3b fd       	call   0x71dbfec20040
    71dc0186b44e:	4d 85 f6             	test   r14,r14
    71dc0186b451:	0f 8e 5c 01 00 00    	jle    0x71dc0186b5b3
    71dc0186b457:	48 8b 7b 18          	mov    rdi,QWORD PTR [rbx+0x18]
    71dc0186b45b:	48 85 ff             	test   rdi,rdi
    71dc0186b45e:	0f 85 70 05 00 00    	jne    0x71dc0186b9d4
    71dc0186b464:	4c 8b 63 20          	mov    r12,QWORD PTR [rbx+0x20]
    71dc0186b468:	4c 03 63 28          	add    r12,QWORD PTR [rbx+0x28]
    71dc0186b46c:	0f 80 4a 0a 00 00    	jo     0x71dc0186bebc
    71dc0186b472:	48 bf ff ff ff ff ff 	movabs rdi,0x7fffffffffffffff
    71dc0186b479:	ff ff 7f 
    71dc0186b47c:	49 33 fe             	xor    rdi,r14
    71dc0186b47f:	4c 3b e7             	cmp    r12,rdi
    71dc0186b482:	0f 8f 52 05 00 00    	jg     0x71dc0186b9da
    71dc0186b488:	4d 03 e6             	add    r12,r14
    71dc0186b48b:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc0186b48f:	48 89 85 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rax
    71dc0186b496:	48 bf c0 b3 f2 00 dc 	movabs rdi,0x71dc00f2b3c0
    71dc0186b49d:	71 00 00 
    71dc0186b4a0:	48 39 38             	cmp    QWORD PTR [rax],rdi
    71dc0186b4a3:	0f 85 c5 05 00 00    	jne    0x71dc0186ba6e
    71dc0186b4a9:	4d 85 e4             	test   r12,r12
    71dc0186b4ac:	0f 8c a8 05 00 00    	jl     0x71dc0186ba5a
    71dc0186b4b2:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc0186b4b6:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc0186b4ba:	48 89 bd 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rdi
    71dc0186b4c1:	33 ff                	xor    edi,edi
    71dc0186b4c3:	89 7d 84             	mov    DWORD PTR [rbp-0x7c],edi
    71dc0186b4c6:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
    71dc0186b4cd:	ff 15 ed b2 5e fe    	call   QWORD PTR [rip+0xfffffffffe5eb2ed]        # 0x71dbffe567c0
    71dc0186b4d3:	c7 45 84 01 00 00 00 	mov    DWORD PTR [rbp-0x7c],0x1
    71dc0186b4da:	48 8b 85 28 ff ff ff 	mov    rax,QWORD PTR [rbp-0xd8]
    71dc0186b4e1:	48 83 78 10 00       	cmp    QWORD PTR [rax+0x10],0x0
    71dc0186b4e6:	74 62                	je     0x71dc0186b54a
    71dc0186b4e8:	49 8b fc             	mov    rdi,r12
    71dc0186b4eb:	48 2b 78 28          	sub    rdi,QWORD PTR [rax+0x28]
    71dc0186b4ef:	48 85 ff             	test   rdi,rdi
    71dc0186b4f2:	7e 3b                	jle    0x71dc0186b52f
    71dc0186b4f4:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
    71dc0186b4f8:	38 09                	cmp    BYTE PTR [rcx],cl
    71dc0186b4fa:	48 8d 51 20          	lea    rdx,[rcx+0x20]
    71dc0186b4fe:	80 3a 00             	cmp    BYTE PTR [rdx],0x0
    71dc0186b501:	75 51                	jne    0x71dc0186b554
    71dc0186b503:	48 be ff ff ff ff ff 	movabs rsi,0x7fffffffffffffff
    71dc0186b50a:	ff ff 7f 
    71dc0186b50d:	48 8b 51 10          	mov    rdx,QWORD PTR [rcx+0x10]
    71dc0186b511:	48 2b f2             	sub    rsi,rdx
    71dc0186b514:	48 3b f7             	cmp    rsi,rdi
    71dc0186b517:	7c 41                	jl     0x71dc0186b55a
    71dc0186b519:	48 03 d7             	add    rdx,rdi
    71dc0186b51c:	48 89 51 10          	mov    QWORD PTR [rcx+0x10],rdx
    71dc0186b520:	48 8b 71 18          	mov    rsi,QWORD PTR [rcx+0x18]
    71dc0186b524:	48 3b f2             	cmp    rsi,rdx
    71dc0186b527:	48 0f 4c f2          	cmovl  rsi,rdx
    71dc0186b52b:	48 89 71 18          	mov    QWORD PTR [rcx+0x18],rsi
    71dc0186b52f:	48 85 ff             	test   rdi,rdi
    71dc0186b532:	7c 0c                	jl     0x71dc0186b540
    71dc0186b534:	4c 89 60 28          	mov    QWORD PTR [rax+0x28],r12
    71dc0186b538:	41 bc 01 00 00 00    	mov    r12d,0x1
    71dc0186b53e:	eb 1d                	jmp    0x71dc0186b55d
    71dc0186b540:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
    71dc0186b544:	48 01 79 10          	add    QWORD PTR [rcx+0x10],rdi
    71dc0186b548:	eb ea                	jmp    0x71dc0186b534
    71dc0186b54a:	48 8b f8             	mov    rdi,rax
    71dc0186b54d:	ff 15 7d 96 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7967d]        # 0x71dc017e4bd0
    71dc0186b553:	cc                   	int3
    71dc0186b554:	48 8b 72 08          	mov    rsi,QWORD PTR [rdx+0x8]
    71dc0186b558:	eb b3                	jmp    0x71dc0186b50d
    71dc0186b55a:	45 33 e4             	xor    r12d,r12d
    71dc0186b55d:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
    71dc0186b564:	ff 15 ce b2 5e fe    	call   QWORD PTR [rip+0xfffffffffe5eb2ce]        # 0x71dbffe56838
    71dc0186b56a:	45 85 e4             	test   r12d,r12d
    71dc0186b56d:	0f 84 16 05 00 00    	je     0x71dc0186ba89
    71dc0186b573:	49 8b fe             	mov    rdi,r14
    71dc0186b576:	48 03 7b 20          	add    rdi,QWORD PTR [rbx+0x20]
    71dc0186b57a:	48 89 7b 20          	mov    QWORD PTR [rbx+0x20],rdi
    71dc0186b57e:	48 03 7b 28          	add    rdi,QWORD PTR [rbx+0x28]
    71dc0186b582:	0f 80 34 09 00 00    	jo     0x71dc0186bebc
    71dc0186b588:	48 3b 7b 30          	cmp    rdi,QWORD PTR [rbx+0x30]
    71dc0186b58c:	7e 04                	jle    0x71dc0186b592
    71dc0186b58e:	48 89 7b 30          	mov    QWORD PTR [rbx+0x30],rdi
    71dc0186b592:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
    71dc0186b596:	48 b8 ff ff ff ff ff 	movabs rax,0x7fffffffffffffff
    71dc0186b59d:	ff ff 7f 
    71dc0186b5a0:	49 33 c6             	xor    rax,r14
    71dc0186b5a3:	48 3b f8             	cmp    rdi,rax
    71dc0186b5a6:	0f 8f 5d 05 00 00    	jg     0x71dc0186bb09
    71dc0186b5ac:	49 03 fe             	add    rdi,r14
    71dc0186b5af:	49 89 7d 10          	mov    QWORD PTR [r13+0x10],rdi
    71dc0186b5b3:	4c 89 ad 38 ff ff ff 	mov    QWORD PTR [rbp-0xc8],r13
    71dc0186b5ba:	41 8b f7             	mov    esi,r15d
    71dc0186b5bd:	48 bf d0 cc f7 ff db 	movabs rdi,0x71dbfff7ccd0
    71dc0186b5c4:	71 00 00 
    71dc0186b5c7:	e8 04 5e 7e 7c       	call   0x71dc7e0513d0
    71dc0186b5cc:	48 8b f0             	mov    rsi,rax
    71dc0186b5cf:	49 8b 7d 08          	mov    rdi,QWORD PTR [r13+0x8]
    71dc0186b5d3:	48 85 ff             	test   rdi,rdi
    71dc0186b5d6:	74 42                	je     0x71dc0186b61a
    71dc0186b5d8:	4d 85 f6             	test   r14,r14
    71dc0186b5db:	7c 6b                	jl     0x71dc0186b648
    71dc0186b5dd:	49 8b 45 10          	mov    rax,QWORD PTR [r13+0x10]
    71dc0186b5e1:	4c 3b f0             	cmp    r14,rax
    71dc0186b5e4:	7f 62                	jg     0x71dc0186b648
    71dc0186b5e6:	4d 85 f6             	test   r14,r14
    71dc0186b5e9:	7e 1f                	jle    0x71dc0186b60a
    71dc0186b5eb:	48 8b 4f 20          	mov    rcx,QWORD PTR [rdi+0x20]
    71dc0186b5ef:	48 8b d1             	mov    rdx,rcx
    71dc0186b5f2:	4c 3b f2             	cmp    r14,rdx
    71dc0186b5f5:	49 0f 4e d6          	cmovle rdx,r14
    71dc0186b5f9:	48 2b ca             	sub    rcx,rdx
    71dc0186b5fc:	48 89 4f 20          	mov    QWORD PTR [rdi+0x20],rcx
    71dc0186b600:	48 03 57 28          	add    rdx,QWORD PTR [rdi+0x28]
    71dc0186b604:	70 70                	jo     0x71dc0186b676
    71dc0186b606:	48 89 57 28          	mov    QWORD PTR [rdi+0x28],rdx
    71dc0186b60a:	49 2b c6             	sub    rax,r14
    71dc0186b60d:	49 89 45 10          	mov    QWORD PTR [r13+0x10],rax
    71dc0186b611:	48 89 b5 30 ff ff ff 	mov    QWORD PTR [rbp-0xd0],rsi
    71dc0186b618:	eb 62                	jmp    0x71dc0186b67c
    71dc0186b61a:	48 bf f0 db a7 00 dc 	movabs rdi,0x71dc00a7dbf0
    71dc0186b621:	71 00 00 
    71dc0186b624:	e8 97 5c 7e 7c       	call   0x71dc7e0512c0
    71dc0186b629:	48 8b d8             	mov    rbx,rax
    71dc0186b62c:	48 8b fb             	mov    rdi,rbx
    71dc0186b62f:	48 be b0 7e 65 fc db 	movabs rsi,0x71dbfc657eb0
    71dc0186b636:	71 00 00 
    71dc0186b639:	ff 15 31 30 d1 ff    	call   QWORD PTR [rip+0xffffffffffd13031]        # 0x71dc0157e670
    71dc0186b63f:	48 8b fb             	mov    rdi,rbx
    71dc0186b642:	e8 59 69 54 7c       	call   0x71dc7ddb1fa0
    71dc0186b647:	cc                   	int3
    71dc0186b648:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc0186b64f:	71 00 00 
    71dc0186b652:	e8 69 5c 7e 7c       	call   0x71dc7e0512c0
    71dc0186b657:	48 8b d8             	mov    rbx,rax
    71dc0186b65a:	48 8b fb             	mov    rdi,rbx
    71dc0186b65d:	48 be 00 7f 65 fc db 	movabs rsi,0x71dbfc657f00
    71dc0186b664:	71 00 00 
    71dc0186b667:	ff 15 03 ad 6d ff    	call   QWORD PTR [rip+0xffffffffff6dad03]        # 0x71dc00f46370
    71dc0186b66d:	48 8b fb             	mov    rdi,rbx
    71dc0186b670:	e8 2b 69 54 7c       	call   0x71dc7ddb1fa0
    71dc0186b675:	cc                   	int3
    71dc0186b676:	e8 75 5f 5e fe       	call   0x71dbffe515f0
    71dc0186b67b:	cc                   	int3
    71dc0186b67c:	e8 41 08 00 00       	call   0x71dc0186bec2
    71dc0186b681:	90                   	nop
    71dc0186b682:	48 83 bd 30 ff ff ff 	cmp    QWORD PTR [rbp-0xd0],0x0
    71dc0186b689:	00 
    71dc0186b68a:	0f 84 03 05 00 00    	je     0x71dc0186bb93
    71dc0186b690:	48 8b b5 30 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xd0]
    71dc0186b697:	48 8d 7e 10          	lea    rdi,[rsi+0x10]
    71dc0186b69b:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc0186b69e:	39 95 5c ff ff ff    	cmp    DWORD PTR [rbp-0xa4],edx
    71dc0186b6a4:	0f 8f f2 04 00 00    	jg     0x71dc0186bb9c
    71dc0186b6aa:	8b 95 5c ff ff ff    	mov    edx,DWORD PTR [rbp-0xa4]
    71dc0186b6b0:	48 8b b5 e8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x118]
    71dc0186b6b7:	ff 15 f3 9f 5e fe    	call   QWORD PTR [rip+0xfffffffffe5e9ff3]        # 0x71dbffe556b0
    71dc0186b6bd:	48 bf 28 1c 28 01 dc 	movabs rdi,0x71dc01281c28
    71dc0186b6c4:	71 00 00 
    71dc0186b6c7:	e8 f4 5b 7e 7c       	call   0x71dc7e0512c0
    71dc0186b6cc:	48 8b d8             	mov    rbx,rax
    71dc0186b6cf:	c7 43 38 ff ff ff ff 	mov    DWORD PTR [rbx+0x38],0xffffffff
    71dc0186b6d6:	48 8d 7b 08          	lea    rdi,[rbx+0x8]
    71dc0186b6da:	48 8b b5 30 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xd0]
    71dc0186b6e1:	e8 5a 49 3b fd       	call   0x71dbfec20040
    71dc0186b6e6:	48 8d 7b 10          	lea    rdi,[rbx+0x10]
    71dc0186b6ea:	48 8b b5 48 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb8]
    71dc0186b6f1:	e8 4a 49 3b fd       	call   0x71dbfec20040
    71dc0186b6f6:	48 8d 7b 18          	lea    rdi,[rbx+0x18]
    71dc0186b6fa:	48 8b b5 40 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xc0]
    71dc0186b701:	e8 3a 49 3b fd       	call   0x71dbfec20040
    71dc0186b706:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b70d:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
    71dc0186b711:	83 78 28 02          	cmp    DWORD PTR [rax+0x28],0x2
    71dc0186b715:	0f 84 b4 04 00 00    	je     0x71dc0186bbcf
    71dc0186b71b:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b722:	4c 8b fb             	mov    r15,rbx
    71dc0186b725:	48 8b 5f 38          	mov    rbx,QWORD PTR [rdi+0x38]
    71dc0186b729:	8b 43 10             	mov    eax,DWORD PTR [rbx+0x10]
    71dc0186b72c:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
    71dc0186b730:	3b 41 08             	cmp    eax,DWORD PTR [rcx+0x8]
    71dc0186b733:	0f 8d ea 04 00 00    	jge    0x71dc0186bc23
    71dc0186b739:	48 8b 47 38          	mov    rax,QWORD PTR [rdi+0x38]
    71dc0186b73d:	ff 40 14             	inc    DWORD PTR [rax+0x14]
    71dc0186b740:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
    71dc0186b744:	8b 50 10             	mov    edx,DWORD PTR [rax+0x10]
    71dc0186b747:	39 56 08             	cmp    DWORD PTR [rsi+0x8],edx
    71dc0186b74a:	0f 86 cd 05 00 00    	jbe    0x71dc0186bd1d
    71dc0186b750:	8d 4a 01             	lea    ecx,[rdx+0x1]
    71dc0186b753:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    71dc0186b756:	8b d2                	mov    edx,edx
    71dc0186b758:	48 8d 44 d6 10       	lea    rax,[rsi+rdx*8+0x10]
    71dc0186b75d:	48 8b 16             	mov    rdx,QWORD PTR [rsi]
    71dc0186b760:	48 8b 52 30          	mov    rdx,QWORD PTR [rdx+0x30]
    71dc0186b764:	4d 85 ff             	test   r15,r15
    71dc0186b767:	0f 84 a8 01 00 00    	je     0x71dc0186b915
    71dc0186b76d:	49 3b 17             	cmp    rdx,QWORD PTR [r15]
    71dc0186b770:	74 13                	je     0x71dc0186b785
    71dc0186b772:	48 b9 a0 27 e6 ff db 	movabs rcx,0x71dbffe627a0
    71dc0186b779:	71 00 00 
    71dc0186b77c:	48 39 0e             	cmp    QWORD PTR [rsi],rcx
    71dc0186b77f:	0f 85 84 05 00 00    	jne    0x71dc0186bd09
    71dc0186b785:	48 8b f8             	mov    rdi,rax
    71dc0186b788:	49 8b f7             	mov    rsi,r15
    71dc0186b78b:	e8 b0 48 3b fd       	call   0x71dbfec20040
    71dc0186b790:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b797:	48 8b 47 40          	mov    rax,QWORD PTR [rdi+0x40]
    71dc0186b79b:	33 c9                	xor    ecx,ecx
    71dc0186b79d:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    71dc0186b7a0:	66 c7 47 5d 00 00    	mov    WORD PTR [rdi+0x5d],0x0
    71dc0186b7a6:	c6 47 5f 00          	mov    BYTE PTR [rdi+0x5f],0x0
    71dc0186b7aa:	48 8b 5f 38          	mov    rbx,QWORD PTR [rdi+0x38]
    71dc0186b7ae:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
    71dc0186b7b2:	4c 8b 78 30          	mov    r15,QWORD PTR [rax+0x30]
    71dc0186b7b6:	48 bf 80 eb 60 01 dc 	movabs rdi,0x71dc0160eb80
    71dc0186b7bd:	71 00 00 
    71dc0186b7c0:	e8 fb 5a 7e 7c       	call   0x71dc7e0512c0
    71dc0186b7c5:	4c 8b f0             	mov    r14,rax
    71dc0186b7c8:	4d 8b bf 80 00 00 00 	mov    r15,QWORD PTR [r15+0x80]
    71dc0186b7cf:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b7d6:	4c 8b 6f 18          	mov    r13,QWORD PTR [rdi+0x18]
    71dc0186b7da:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc0186b7de:	49 8b f7             	mov    rsi,r15
    71dc0186b7e1:	e8 5a 48 3b fd       	call   0x71dbfec20040
    71dc0186b7e6:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    71dc0186b7ea:	49 8b f5             	mov    rsi,r13
    71dc0186b7ed:	e8 4e 48 3b fd       	call   0x71dbfec20040
    71dc0186b7f2:	48 8b fb             	mov    rdi,rbx
    71dc0186b7f5:	49 8b f7             	mov    rsi,r15
    71dc0186b7f8:	49 8b d5             	mov    rdx,r13
    71dc0186b7fb:	ff 15 ff 9c e7 ff    	call   QWORD PTR [rip+0xffffffffffe79cff]        # 0x71dc016e5500
    71dc0186b801:	48 8b f0             	mov    rsi,rax
    71dc0186b804:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc0186b808:	e8 33 48 3b fd       	call   0x71dbfec20040
    71dc0186b80d:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b814:	48 8b 5f 50          	mov    rbx,QWORD PTR [rdi+0x50]
    71dc0186b818:	8b 43 10             	mov    eax,DWORD PTR [rbx+0x10]
    71dc0186b81b:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
    71dc0186b81f:	3b 41 08             	cmp    eax,DWORD PTR [rcx+0x8]
    71dc0186b822:	0f 8d 06 05 00 00    	jge    0x71dc0186bd2e
    71dc0186b828:	48 8b 47 50          	mov    rax,QWORD PTR [rdi+0x50]
    71dc0186b82c:	ff 40 14             	inc    DWORD PTR [rax+0x14]
    71dc0186b82f:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
    71dc0186b833:	8b 48 10             	mov    ecx,DWORD PTR [rax+0x10]
    71dc0186b836:	39 4e 08             	cmp    DWORD PTR [rsi+0x8],ecx
    71dc0186b839:	0f 86 d5 05 00 00    	jbe    0x71dc0186be14
    71dc0186b83f:	8d 51 01             	lea    edx,[rcx+0x1]
    71dc0186b842:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    71dc0186b845:	8b c1                	mov    eax,ecx
    71dc0186b847:	48 8d 7c c6 10       	lea    rdi,[rsi+rax*8+0x10]
    71dc0186b84c:	49 8b f6             	mov    rsi,r14
    71dc0186b84f:	e8 ec 47 3b fd       	call   0x71dbfec20040
    71dc0186b854:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b85b:	48 8b 77 38          	mov    rsi,QWORD PTR [rdi+0x38]
    71dc0186b85f:	ff 46 14             	inc    DWORD PTR [rsi+0x14]
    71dc0186b862:	8b 46 10             	mov    eax,DWORD PTR [rsi+0x10]
    71dc0186b865:	33 c9                	xor    ecx,ecx
    71dc0186b867:	89 4e 10             	mov    DWORD PTR [rsi+0x10],ecx
    71dc0186b86a:	85 c0                	test   eax,eax
    71dc0186b86c:	7e 73                	jle    0x71dc0186b8e1
    71dc0186b86e:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    71dc0186b872:	48 85 f6             	test   rsi,rsi
    71dc0186b875:	0f 84 aa 05 00 00    	je     0x71dc0186be25
    71dc0186b87b:	48 8d 4e 10          	lea    rcx,[rsi+0x10]
    71dc0186b87f:	33 d2                	xor    edx,edx
    71dc0186b881:	4c 8b 06             	mov    r8,QWORD PTR [rsi]
    71dc0186b884:	41 83 78 04 18       	cmp    DWORD PTR [r8+0x4],0x18
    71dc0186b889:	0f 85 a2 05 00 00    	jne    0x71dc0186be31
    71dc0186b88f:	44 8b ca             	mov    r9d,edx
    71dc0186b892:	41 f7 d9             	neg    r9d
    71dc0186b895:	85 d2                	test   edx,edx
    71dc0186b897:	0f 8f b5 05 00 00    	jg     0x71dc0186be52
    71dc0186b89d:	45 85 c9             	test   r9d,r9d
    71dc0186b8a0:	0f 8c ac 05 00 00    	jl     0x71dc0186be52
    71dc0186b8a6:	41 8d 14 01          	lea    edx,[r9+rax*1]
    71dc0186b8aa:	3b 56 08             	cmp    edx,DWORD PTR [rsi+0x8]
    71dc0186b8ad:	0f 87 9f 05 00 00    	ja     0x71dc0186be52
    71dc0186b8b3:	41 0f b7 30          	movzx  esi,WORD PTR [r8]
    71dc0186b8b7:	41 8b d1             	mov    edx,r9d
    71dc0186b8ba:	48 0f af d6          	imul   rdx,rsi
    71dc0186b8be:	48 03 d1             	add    rdx,rcx
    71dc0186b8c1:	8b c0                	mov    eax,eax
    71dc0186b8c3:	48 0f af f0          	imul   rsi,rax
    71dc0186b8c7:	41 f7 00 00 00 00 01 	test   DWORD PTR [r8],0x1000000
    71dc0186b8ce:	0f 84 85 05 00 00    	je     0x71dc0186be59
    71dc0186b8d4:	48 c1 ee 03          	shr    rsi,0x3
    71dc0186b8d8:	48 8b fa             	mov    rdi,rdx
    71dc0186b8db:	ff 15 27 c4 2a ff    	call   QWORD PTR [rip+0xffffffffff2ac427]        # 0x71dc00b17d08
    71dc0186b8e1:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b8e8:	48 8b 47 38          	mov    rax,QWORD PTR [rdi+0x38]
    71dc0186b8ec:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    71dc0186b8f0:	81 78 08 00 04 00 00 	cmp    DWORD PTR [rax+0x8],0x400
    71dc0186b8f7:	0f 8f 6a 05 00 00    	jg     0x71dc0186be67
    71dc0186b8fd:	66 c7 47 5f 00 00    	mov    WORD PTR [rdi+0x5f],0x0
    71dc0186b903:	48 81 c4 18 01 00 00 	add    rsp,0x118
    71dc0186b90a:	5b                   	pop    rbx
    71dc0186b90b:	41 5c                	pop    r12
    71dc0186b90d:	41 5d                	pop    r13
    71dc0186b90f:	41 5e                	pop    r14
    71dc0186b911:	41 5f                	pop    r15
    71dc0186b913:	5d                   	pop    rbp
    71dc0186b914:	c3                   	ret
    71dc0186b915:	33 f6                	xor    esi,esi
    71dc0186b917:	48 89 30             	mov    QWORD PTR [rax],rsi
    71dc0186b91a:	e9 71 fe ff ff       	jmp    0x71dc0186b790
    71dc0186b91f:	80 7f 5d 00          	cmp    BYTE PTR [rdi+0x5d],0x0
    71dc0186b923:	0f 85 96 fa ff ff    	jne    0x71dc0186b3bf
    71dc0186b929:	48 8b 47 40          	mov    rax,QWORD PTR [rdi+0x40]
    71dc0186b92d:	83 78 28 00          	cmp    DWORD PTR [rax+0x28],0x0
    71dc0186b931:	0f 85 88 fa ff ff    	jne    0x71dc0186b3bf
    71dc0186b937:	48 8b 47 38          	mov    rax,QWORD PTR [rdi+0x38]
    71dc0186b93b:	83 78 10 00          	cmp    DWORD PTR [rax+0x10],0x0
    71dc0186b93f:	0f 85 7a fa ff ff    	jne    0x71dc0186b3bf
    71dc0186b945:	48 b8 a8 0f 80 21 d4 	movabs rax,0x71d421800fa8
    71dc0186b94c:	71 00 00 
    71dc0186b94f:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    71dc0186b952:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
    71dc0186b956:	4c 8b 78 30          	mov    r15,QWORD PTR [rax+0x30]
    71dc0186b95a:	48 bf 80 eb 60 01 dc 	movabs rdi,0x71dc0160eb80
    71dc0186b961:	71 00 00 
    71dc0186b964:	e8 57 59 7e 7c       	call   0x71dc7e0512c0
    71dc0186b969:	4c 8b f0             	mov    r14,rax
    71dc0186b96c:	49 8b 97 80 00 00 00 	mov    rdx,QWORD PTR [r15+0x80]
    71dc0186b973:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b97a:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
    71dc0186b97e:	49 8b fe             	mov    rdi,r14
    71dc0186b981:	48 8b f3             	mov    rsi,rbx
    71dc0186b984:	ff 15 5e 33 d8 ff    	call   QWORD PTR [rip+0xffffffffffd8335e]        # 0x71dc015eece8
    71dc0186b98a:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b991:	49 8b f6             	mov    rsi,r14
    71dc0186b994:	ff 15 16 9a e7 ff    	call   QWORD PTR [rip+0xffffffffffe79a16]        # 0x71dc016e53b0
    71dc0186b99a:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186b9a1:	ff 15 29 9b e7 ff    	call   QWORD PTR [rip+0xffffffffffe79b29]        # 0x71dc016e54d0
    71dc0186b9a7:	e9 57 ff ff ff       	jmp    0x71dc0186b903
    71dc0186b9ac:	45 85 ff             	test   r15d,r15d
    71dc0186b9af:	74 07                	je     0x71dc0186b9b8
    71dc0186b9b1:	ff 15 a9 98 d0 ff    	call   QWORD PTR [rip+0xffffffffffd098a9]        # 0x71dc01575260
    71dc0186b9b7:	cc                   	int3
    71dc0186b9b8:	33 f6                	xor    esi,esi
    71dc0186b9ba:	45 33 ff             	xor    r15d,r15d
    71dc0186b9bd:	e9 2d fa ff ff       	jmp    0x71dc0186b3ef
    71dc0186b9c2:	48 b8 58 35 80 21 d4 	movabs rax,0x71d421803558
    71dc0186b9c9:	71 00 00 
    71dc0186b9cc:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    71dc0186b9cf:	e9 32 fd ff ff       	jmp    0x71dc0186b706
    71dc0186b9d4:	e8 c7 65 54 7c       	call   0x71dc7ddb1fa0
    71dc0186b9d9:	cc                   	int3
    71dc0186b9da:	4c 89 73 38          	mov    QWORD PTR [rbx+0x38],r14
    71dc0186b9de:	48 8b fb             	mov    rdi,rbx
    71dc0186b9e1:	ff 15 21 93 d7 ff    	call   QWORD PTR [rip+0xffffffffffd79321]        # 0x71dc015e4d08
    71dc0186b9e7:	48 8b f0             	mov    rsi,rax
    71dc0186b9ea:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    71dc0186b9ee:	ff 15 74 28 61 ff    	call   QWORD PTR [rip+0xffffffffff612874]        # 0x71dc00e7e268
    71dc0186b9f4:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc0186b9f8:	49 8b f6             	mov    rsi,r14
    71dc0186b9fb:	ff 15 67 28 61 ff    	call   QWORD PTR [rip+0xffffffffff612867]        # 0x71dc00e7e268
    71dc0186ba01:	c5 f8 10 45 98       	vmovups xmm0,XMMWORD PTR [rbp-0x68]
    71dc0186ba06:	c5 f8 11 04 24       	vmovups XMMWORD PTR [rsp],xmm0
    71dc0186ba0b:	c5 f8 10 45 88       	vmovups xmm0,XMMWORD PTR [rbp-0x78]
    71dc0186ba10:	c5 f8 11 44 24 10    	vmovups XMMWORD PTR [rsp+0x10],xmm0
    71dc0186ba16:	45 33 c0             	xor    r8d,r8d
    71dc0186ba19:	45 33 c9             	xor    r9d,r9d
    71dc0186ba1c:	48 8b 95 40 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xc0]
    71dc0186ba23:	48 bf a0 b3 60 fc db 	movabs rdi,0x71dbfc60b3a0
    71dc0186ba2a:	71 00 00 
    71dc0186ba2d:	48 be e8 7b 65 fc db 	movabs rsi,0x71dbfc657be8
    71dc0186ba34:	71 00 00 
    71dc0186ba37:	b9 08 00 00 00       	mov    ecx,0x8
    71dc0186ba3c:	ff 15 66 2a 61 ff    	call   QWORD PTR [rip+0xffffffffff612a66]        # 0x71dc00e7e4a8
    71dc0186ba42:	4c 8b e8             	mov    r13,rax
    71dc0186ba45:	48 8d 7b 18          	lea    rdi,[rbx+0x18]
    71dc0186ba49:	49 8b f5             	mov    rsi,r13
    71dc0186ba4c:	e8 ef 45 3b fd       	call   0x71dbfec20040
    71dc0186ba51:	49 8b fd             	mov    rdi,r13
    71dc0186ba54:	e8 47 65 54 7c       	call   0x71dc7ddb1fa0
    71dc0186ba59:	cc                   	int3
    71dc0186ba5a:	49 8b fc             	mov    rdi,r12
    71dc0186ba5d:	48 be a0 1d 60 fc db 	movabs rsi,0x71dbfc601da0
    71dc0186ba64:	71 00 00 
    71dc0186ba67:	ff 15 1b 91 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7911b]        # 0x71dc017e4b88
    71dc0186ba6d:	cc                   	int3
    71dc0186ba6e:	48 8b f8             	mov    rdi,rax
    71dc0186ba71:	49 8b f4             	mov    rsi,r12
    71dc0186ba74:	49 bb d8 37 c4 fe db 	movabs r11,0x71dbfec437d8
    71dc0186ba7b:	71 00 00 
    71dc0186ba7e:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186ba81:	44 8b e0             	mov    r12d,eax
    71dc0186ba84:	e9 e1 fa ff ff       	jmp    0x71dc0186b56a
    71dc0186ba89:	4c 89 73 38          	mov    QWORD PTR [rbx+0x38],r14
    71dc0186ba8d:	48 8b fb             	mov    rdi,rbx
    71dc0186ba90:	ff 15 72 92 d7 ff    	call   QWORD PTR [rip+0xffffffffffd79272]        # 0x71dc015e4d08
    71dc0186ba96:	48 8b f0             	mov    rsi,rax
    71dc0186ba99:	48 8d 7d b8          	lea    rdi,[rbp-0x48]
    71dc0186ba9d:	ff 15 c5 27 61 ff    	call   QWORD PTR [rip+0xffffffffff6127c5]        # 0x71dc00e7e268
    71dc0186baa3:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    71dc0186baa7:	49 8b f6             	mov    rsi,r14
    71dc0186baaa:	ff 15 b8 27 61 ff    	call   QWORD PTR [rip+0xffffffffff6127b8]        # 0x71dc00e7e268
    71dc0186bab0:	c5 f8 10 45 b8       	vmovups xmm0,XMMWORD PTR [rbp-0x48]
    71dc0186bab5:	c5 f8 11 04 24       	vmovups XMMWORD PTR [rsp],xmm0
    71dc0186baba:	c5 f8 10 45 a8       	vmovups xmm0,XMMWORD PTR [rbp-0x58]
    71dc0186babf:	c5 f8 11 44 24 10    	vmovups XMMWORD PTR [rsp+0x10],xmm0
    71dc0186bac5:	45 33 c0             	xor    r8d,r8d
    71dc0186bac8:	45 33 c9             	xor    r9d,r9d
    71dc0186bacb:	48 8b 95 40 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xc0]
    71dc0186bad2:	48 bf a0 b3 60 fc db 	movabs rdi,0x71dbfc60b3a0
    71dc0186bad9:	71 00 00 
    71dc0186badc:	48 be 98 7b 65 fc db 	movabs rsi,0x71dbfc657b98
    71dc0186bae3:	71 00 00 
    71dc0186bae6:	b9 0b 00 00 00       	mov    ecx,0xb
    71dc0186baeb:	ff 15 b7 29 61 ff    	call   QWORD PTR [rip+0xffffffffff6129b7]        # 0x71dc00e7e4a8
    71dc0186baf1:	4c 8b f0             	mov    r14,rax
    71dc0186baf4:	48 8d 7b 18          	lea    rdi,[rbx+0x18]
    71dc0186baf8:	49 8b f6             	mov    rsi,r14
    71dc0186bafb:	e8 40 45 3b fd       	call   0x71dbfec20040
    71dc0186bb00:	49 8b fe             	mov    rdi,r14
    71dc0186bb03:	e8 98 64 54 7c       	call   0x71dc7ddb1fa0
    71dc0186bb08:	cc                   	int3
    71dc0186bb09:	4c 89 73 38          	mov    QWORD PTR [rbx+0x38],r14
    71dc0186bb0d:	48 8b fb             	mov    rdi,rbx
    71dc0186bb10:	ff 15 f2 91 d7 ff    	call   QWORD PTR [rip+0xffffffffffd791f2]        # 0x71dc015e4d08
    71dc0186bb16:	48 8b f0             	mov    rsi,rax
    71dc0186bb19:	48 8d bd 70 ff ff ff 	lea    rdi,[rbp-0x90]
    71dc0186bb20:	ff 15 42 27 61 ff    	call   QWORD PTR [rip+0xffffffffff612742]        # 0x71dc00e7e268
    71dc0186bb26:	48 8d bd 60 ff ff ff 	lea    rdi,[rbp-0xa0]
    71dc0186bb2d:	49 8b f6             	mov    rsi,r14
    71dc0186bb30:	ff 15 32 27 61 ff    	call   QWORD PTR [rip+0xffffffffff612732]        # 0x71dc00e7e268
    71dc0186bb36:	62 f1 7c 08 10 45 f7 	{evex} vmovups xmm0,XMMWORD PTR [rbp-0x90]
    71dc0186bb3d:	c5 f8 11 04 24       	vmovups XMMWORD PTR [rsp],xmm0
    71dc0186bb42:	62 f1 7c 08 10 45 f6 	{evex} vmovups xmm0,XMMWORD PTR [rbp-0xa0]
    71dc0186bb49:	c5 f8 11 44 24 10    	vmovups XMMWORD PTR [rsp+0x10],xmm0
    71dc0186bb4f:	45 33 c0             	xor    r8d,r8d
    71dc0186bb52:	45 33 c9             	xor    r9d,r9d
    71dc0186bb55:	48 8b 95 40 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xc0]
    71dc0186bb5c:	48 bf a0 b3 60 fc db 	movabs rdi,0x71dbfc60b3a0
    71dc0186bb63:	71 00 00 
    71dc0186bb66:	48 be e8 7b 65 fc db 	movabs rsi,0x71dbfc657be8
    71dc0186bb6d:	71 00 00 
    71dc0186bb70:	b9 08 00 00 00       	mov    ecx,0x8
    71dc0186bb75:	ff 15 2d 29 61 ff    	call   QWORD PTR [rip+0xffffffffff61292d]        # 0x71dc00e7e4a8
    71dc0186bb7b:	4c 8b f0             	mov    r14,rax
    71dc0186bb7e:	48 8d 7b 18          	lea    rdi,[rbx+0x18]
    71dc0186bb82:	49 8b f6             	mov    rsi,r14
    71dc0186bb85:	e8 b6 44 3b fd       	call   0x71dbfec20040
    71dc0186bb8a:	49 8b fe             	mov    rdi,r14
    71dc0186bb8d:	e8 0e 64 54 7c       	call   0x71dc7ddb1fa0
    71dc0186bb92:	cc                   	int3
    71dc0186bb93:	33 ff                	xor    edi,edi
    71dc0186bb95:	33 d2                	xor    edx,edx
    71dc0186bb97:	e9 02 fb ff ff       	jmp    0x71dc0186b69e
    71dc0186bb9c:	ff 15 d6 90 f7 ff    	call   QWORD PTR [rip+0xfffffffffff790d6]        # 0x71dc017e4c78
    71dc0186bba2:	cc                   	int3
    71dc0186bba3:	48 8b f8             	mov    rdi,rax
    71dc0186bba6:	ff 15 c4 98 e7 ff    	call   QWORD PTR [rip+0xffffffffffe798c4]        # 0x71dc016e5470
    71dc0186bbac:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
    71dc0186bbb0:	48 89 55 d0          	mov    QWORD PTR [rbp-0x30],rdx
    71dc0186bbb4:	48 8d 7d c8          	lea    rdi,[rbp-0x38]
    71dc0186bbb8:	ff 15 7a 17 2b ff    	call   QWORD PTR [rip+0xffffffffff2b177a]        # 0x71dc00b1d338
    71dc0186bbbe:	48 8b f8             	mov    rdi,rax
    71dc0186bbc1:	ff 15 01 8f a0 ff    	call   QWORD PTR [rip+0xffffffffffa08f01]        # 0x71dc01274ac8
    71dc0186bbc7:	48 8b d8             	mov    rbx,rax
    71dc0186bbca:	e9 37 fb ff ff       	jmp    0x71dc0186b706
    71dc0186bbcf:	80 7f 5e 00          	cmp    BYTE PTR [rdi+0x5e],0x0
    71dc0186bbd3:	0f 85 42 fb ff ff    	jne    0x71dc0186b71b
    71dc0186bbd9:	48 8b 47 40          	mov    rax,QWORD PTR [rdi+0x40]
    71dc0186bbdd:	83 78 28 00          	cmp    DWORD PTR [rax+0x28],0x0
    71dc0186bbe1:	0f 84 34 fb ff ff    	je     0x71dc0186b71b
    71dc0186bbe7:	48 bf 58 65 e9 ff db 	movabs rdi,0x71dbffe96558
    71dc0186bbee:	71 00 00 
    71dc0186bbf1:	e8 ca 56 7e 7c       	call   0x71dc7e0512c0
    71dc0186bbf6:	4c 8b f8             	mov    r15,rax
    71dc0186bbf9:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186bc00:	48 8b 57 18          	mov    rdx,QWORD PTR [rdi+0x18]
    71dc0186bc04:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc0186bc08:	48 8b fb             	mov    rdi,rbx
    71dc0186bc0b:	ff 15 17 98 e7 ff    	call   QWORD PTR [rip+0xffffffffffe79817]        # 0x71dc016e5428
    71dc0186bc11:	c4 c1 7b 11 47 08    	vmovsd QWORD PTR [r15+0x8],xmm0
    71dc0186bc17:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186bc1e:	e9 02 fb ff ff       	jmp    0x71dc0186b725
    71dc0186bc23:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc0186bc27:	44 8b 70 08          	mov    r14d,DWORD PTR [rax+0x8]
    71dc0186bc2b:	45 85 f6             	test   r14d,r14d
    71dc0186bc2e:	74 0c                	je     0x71dc0186bc3c
    71dc0186bc30:	45 6b ee 02          	imul   r13d,r14d,0x2
    71dc0186bc34:	0f 80 82 02 00 00    	jo     0x71dc0186bebc
    71dc0186bc3a:	eb 06                	jmp    0x71dc0186bc42
    71dc0186bc3c:	41 bd 04 00 00 00    	mov    r13d,0x4
    71dc0186bc42:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
    71dc0186bc46:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    71dc0186bc4a:	4c 8b a0 80 00 00 00 	mov    r12,QWORD PTR [rax+0x80]
    71dc0186bc51:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
    71dc0186bc55:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
    71dc0186bc5c:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc0186bc60:	48 bf 48 c7 f3 00 dc 	movabs rdi,0x71dc00f3c748
    71dc0186bc67:	71 00 00 
    71dc0186bc6a:	e8 51 56 7e 7c       	call   0x71dc7e0512c0
    71dc0186bc6f:	48 89 85 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],rax
    71dc0186bc76:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc0186bc7a:	49 8b f4             	mov    rsi,r12
    71dc0186bc7d:	e8 be 43 3b fd       	call   0x71dbfec20040
    71dc0186bc82:	4d 63 e5             	movsxd r12,r13d
    71dc0186bc85:	49 c1 e4 04          	shl    r12,0x4
    71dc0186bc89:	49 8b f4             	mov    rsi,r12
    71dc0186bc8c:	48 8b bd 08 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf8]
    71dc0186bc93:	48 8b 95 10 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xf0]
    71dc0186bc9a:	ff 15 a8 a7 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7a7a8]        # 0x71dc015e6448
    71dc0186bca0:	48 8b 85 08 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf8]
    71dc0186bca7:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
    71dc0186bcae:	48 8b fb             	mov    rdi,rbx
    71dc0186bcb1:	41 8b f5             	mov    esi,r13d
    71dc0186bcb4:	ff 15 c6 c0 5e fe    	call   QWORD PTR [rip+0xfffffffffe5ec0c6]        # 0x71dbffe57d80
    71dc0186bcba:	49 8b f4             	mov    rsi,r12
    71dc0186bcbd:	48 8b bd 08 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf8]
    71dc0186bcc4:	ff 15 6e 40 61 ff    	call   QWORD PTR [rip+0xffffffffff61406e]        # 0x71dc00e7fd38
    71dc0186bcca:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186bcd1:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc0186bcd5:	48 8b 76 30          	mov    rsi,QWORD PTR [rsi+0x30]
    71dc0186bcd9:	48 8b be 80 00 00 00 	mov    rdi,QWORD PTR [rsi+0x80]
    71dc0186bce0:	41 8b f6             	mov    esi,r14d
    71dc0186bce3:	48 c1 e6 04          	shl    rsi,0x4
    71dc0186bce7:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186bce9:	ff 15 79 ab d7 ff    	call   QWORD PTR [rip+0xffffffffffd7ab79]        # 0x71dc015e6868
    71dc0186bcef:	90                   	nop
    71dc0186bcf0:	48 8b bd 08 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf8]
    71dc0186bcf7:	ff 15 c3 0a 6d ff    	call   QWORD PTR [rip+0xffffffffff6d0ac3]        # 0x71dc00f3c7c0
    71dc0186bcfd:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186bd04:	e9 30 fa ff ff       	jmp    0x71dc0186b739
    71dc0186bd09:	48 8b f8             	mov    rdi,rax
    71dc0186bd0c:	48 8b f2             	mov    rsi,rdx
    71dc0186bd0f:	49 8b d7             	mov    rdx,r15
    71dc0186bd12:	ff 15 a0 41 b0 fe    	call   QWORD PTR [rip+0xfffffffffeb041a0]        # 0x71dc0036feb8
    71dc0186bd18:	e9 73 fa ff ff       	jmp    0x71dc0186b790
    71dc0186bd1d:	48 8b f8             	mov    rdi,rax
    71dc0186bd20:	49 8b f7             	mov    rsi,r15
    71dc0186bd23:	ff 15 3f c0 5e fe    	call   QWORD PTR [rip+0xfffffffffe5ec03f]        # 0x71dbffe57d68
    71dc0186bd29:	e9 62 fa ff ff       	jmp    0x71dc0186b790
    71dc0186bd2e:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc0186bd32:	44 8b 78 08          	mov    r15d,DWORD PTR [rax+0x8]
    71dc0186bd36:	45 85 ff             	test   r15d,r15d
    71dc0186bd39:	74 0c                	je     0x71dc0186bd47
    71dc0186bd3b:	45 6b ef 02          	imul   r13d,r15d,0x2
    71dc0186bd3f:	0f 80 77 01 00 00    	jo     0x71dc0186bebc
    71dc0186bd45:	eb 06                	jmp    0x71dc0186bd4d
    71dc0186bd47:	41 bd 04 00 00 00    	mov    r13d,0x4
    71dc0186bd4d:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
    71dc0186bd51:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    71dc0186bd55:	4c 8b a0 80 00 00 00 	mov    r12,QWORD PTR [rax+0x80]
    71dc0186bd5c:	48 8b 47 18          	mov    rax,QWORD PTR [rdi+0x18]
    71dc0186bd60:	48 89 85 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rax
    71dc0186bd67:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc0186bd6b:	48 bf 48 c7 f3 00 dc 	movabs rdi,0x71dc00f3c748
    71dc0186bd72:	71 00 00 
    71dc0186bd75:	e8 46 55 7e 7c       	call   0x71dc7e0512c0
    71dc0186bd7a:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
    71dc0186bd81:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc0186bd85:	49 8b f4             	mov    rsi,r12
    71dc0186bd88:	e8 b3 42 3b fd       	call   0x71dbfec20040
    71dc0186bd8d:	4d 63 e5             	movsxd r12,r13d
    71dc0186bd90:	49 c1 e4 04          	shl    r12,0x4
    71dc0186bd94:	49 8b f4             	mov    rsi,r12
    71dc0186bd97:	48 8b bd f0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x110]
    71dc0186bd9e:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
    71dc0186bda5:	ff 15 9d a6 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7a69d]        # 0x71dc015e6448
    71dc0186bdab:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
    71dc0186bdb2:	48 89 85 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rax
    71dc0186bdb9:	48 8b fb             	mov    rdi,rbx
    71dc0186bdbc:	41 8b f5             	mov    esi,r13d
    71dc0186bdbf:	ff 15 bb bf 5e fe    	call   QWORD PTR [rip+0xfffffffffe5ebfbb]        # 0x71dbffe57d80
    71dc0186bdc5:	49 8b f4             	mov    rsi,r12
    71dc0186bdc8:	48 8b bd f0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x110]
    71dc0186bdcf:	ff 15 63 3f 61 ff    	call   QWORD PTR [rip+0xffffffffff613f63]        # 0x71dc00e7fd38
    71dc0186bdd5:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186bddc:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc0186bde0:	48 8b 76 30          	mov    rsi,QWORD PTR [rsi+0x30]
    71dc0186bde4:	48 8b be 80 00 00 00 	mov    rdi,QWORD PTR [rsi+0x80]
    71dc0186bdeb:	41 8b f7             	mov    esi,r15d
    71dc0186bdee:	48 c1 e6 04          	shl    rsi,0x4
    71dc0186bdf2:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186bdf4:	ff 15 6e aa d7 ff    	call   QWORD PTR [rip+0xffffffffffd7aa6e]        # 0x71dc015e6868
    71dc0186bdfa:	90                   	nop
    71dc0186bdfb:	48 8b bd f0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x110]
    71dc0186be02:	ff 15 b8 09 6d ff    	call   QWORD PTR [rip+0xffffffffff6d09b8]        # 0x71dc00f3c7c0
    71dc0186be08:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186be0f:	e9 14 fa ff ff       	jmp    0x71dc0186b828
    71dc0186be14:	48 8b f8             	mov    rdi,rax
    71dc0186be17:	49 8b f6             	mov    rsi,r14
    71dc0186be1a:	ff 15 48 bf 5e fe    	call   QWORD PTR [rip+0xfffffffffe5ebf48]        # 0x71dbffe57d68
    71dc0186be20:	e9 2f fa ff ff       	jmp    0x71dc0186b854
    71dc0186be25:	bf 02 00 00 00       	mov    edi,0x2
    71dc0186be2a:	ff 15 b0 ad 73 ff    	call   QWORD PTR [rip+0xffffffffff73adb0]        # 0x71dc00fa6be0
    71dc0186be30:	cc                   	int3
    71dc0186be31:	45 8b 48 04          	mov    r9d,DWORD PTR [r8+0x4]
    71dc0186be35:	41 83 c1 e8          	add    r9d,0xffffffe8
    71dc0186be39:	41 c1 e9 03          	shr    r9d,0x3
    71dc0186be3d:	49 63 d1             	movsxd rdx,r9d
    71dc0186be40:	8b 14 91             	mov    edx,DWORD PTR [rcx+rdx*4]
    71dc0186be43:	41 c1 e1 03          	shl    r9d,0x3
    71dc0186be47:	4d 63 c9             	movsxd r9,r9d
    71dc0186be4a:	49 03 c9             	add    rcx,r9
    71dc0186be4d:	e9 3d fa ff ff       	jmp    0x71dc0186b88f
    71dc0186be52:	ff 15 e8 8c f7 ff    	call   QWORD PTR [rip+0xfffffffffff78ce8]        # 0x71dc017e4b40
    71dc0186be58:	cc                   	int3
    71dc0186be59:	48 8b fa             	mov    rdi,rdx
    71dc0186be5c:	ff 15 ce 34 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f34ce]        # 0x71dbffe5f330
    71dc0186be62:	e9 7a fa ff ff       	jmp    0x71dc0186b8e1
    71dc0186be67:	48 8b 47 38          	mov    rax,QWORD PTR [rdi+0x38]
    71dc0186be6b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    71dc0186be6f:	8b 58 08             	mov    ebx,DWORD PTR [rax+0x8]
    71dc0186be72:	48 8b 7f 38          	mov    rdi,QWORD PTR [rdi+0x38]
    71dc0186be76:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186be78:	ff 15 0a 99 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7990a]        # 0x71dc016e5788
    71dc0186be7e:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186be85:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
    71dc0186be89:	38 00                	cmp    BYTE PTR [rax],al
    71dc0186be8b:	48 8b 77 38          	mov    rsi,QWORD PTR [rdi+0x38]
    71dc0186be8f:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    71dc0186be93:	2b 5e 08             	sub    ebx,DWORD PTR [rsi+0x8]
    71dc0186be96:	48 63 f3             	movsxd rsi,ebx
    71dc0186be99:	48 c1 e6 04          	shl    rsi,0x4
    71dc0186be9d:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    71dc0186bea1:	48 8b b8 80 00 00 00 	mov    rdi,QWORD PTR [rax+0x80]
    71dc0186bea8:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186beaa:	ff 15 b8 a9 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7a9b8]        # 0x71dc015e6868
    71dc0186beb0:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc0186beb7:	e9 41 fa ff ff       	jmp    0x71dc0186b8fd
    71dc0186bebc:	e8 2f 57 5e fe       	call   0x71dbffe515f0
    71dc0186bec1:	cc                   	int3
    71dc0186bec2:	48 83 ec 28          	sub    rsp,0x28
    71dc0186bec6:	48 8b 85 38 ff ff ff 	mov    rax,QWORD PTR [rbp-0xc8]
    71dc0186becd:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc0186bed1:	33 f6                	xor    esi,esi
    71dc0186bed3:	48 87 37             	xchg   QWORD PTR [rdi],rsi
    71dc0186bed6:	48 85 f6             	test   rsi,rsi
    71dc0186bed9:	74 62                	je     0x71dc0186bf3d
    71dc0186bedb:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
    71dc0186bedf:	48 85 ff             	test   rdi,rdi
    71dc0186bee2:	7e 4c                	jle    0x71dc0186bf30
    71dc0186bee4:	48 8b 4e 20          	mov    rcx,QWORD PTR [rsi+0x20]
    71dc0186bee8:	48 2b cf             	sub    rcx,rdi
    71dc0186beeb:	33 ff                	xor    edi,edi
    71dc0186beed:	48 85 c9             	test   rcx,rcx
    71dc0186bef0:	48 0f 4f f9          	cmovg  rdi,rcx
    71dc0186bef4:	48 89 7e 20          	mov    QWORD PTR [rsi+0x20],rdi
    71dc0186bef8:	48 8b 7e 08          	mov    rdi,QWORD PTR [rsi+0x8]
    71dc0186befc:	48 8b 4e 20          	mov    rcx,QWORD PTR [rsi+0x20]
    71dc0186bf00:	48 03 4e 28          	add    rcx,QWORD PTR [rsi+0x28]
    71dc0186bf04:	70 3c                	jo     0x71dc0186bf42
    71dc0186bf06:	48 be c0 b3 f2 00 dc 	movabs rsi,0x71dc00f2b3c0
    71dc0186bf0d:	71 00 00 
    71dc0186bf10:	48 39 37             	cmp    QWORD PTR [rdi],rsi
    71dc0186bf13:	75 0b                	jne    0x71dc0186bf20
    71dc0186bf15:	48 8b f1             	mov    rsi,rcx
    71dc0186bf18:	ff 15 2a f5 6b ff    	call   QWORD PTR [rip+0xffffffffff6bf52a]        # 0x71dc00f2b448
    71dc0186bf1e:	eb 10                	jmp    0x71dc0186bf30
    71dc0186bf20:	48 8b f1             	mov    rsi,rcx
    71dc0186bf23:	49 bb e0 37 c4 fe db 	movabs r11,0x71dbfec437e0
    71dc0186bf2a:	71 00 00 
    71dc0186bf2d:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186bf30:	33 d2                	xor    edx,edx
    71dc0186bf32:	48 8b 85 38 ff ff ff 	mov    rax,QWORD PTR [rbp-0xc8]
    71dc0186bf39:	48 89 50 10          	mov    QWORD PTR [rax+0x10],rdx
    71dc0186bf3d:	48 83 c4 28          	add    rsp,0x28
    71dc0186bf41:	c3                   	ret
    71dc0186bf42:	e8 a9 56 5e fe       	call   0x71dbffe515f0
    71dc0186bf47:	cc                   	int3
    71dc0186bf48:	48 83 ec 28          	sub    rsp,0x28
    71dc0186bf4c:	83 7d 84 00          	cmp    DWORD PTR [rbp-0x7c],0x0
    71dc0186bf50:	74 0d                	je     0x71dc0186bf5f
    71dc0186bf52:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
    71dc0186bf59:	ff 15 d9 a8 5e fe    	call   QWORD PTR [rip+0xfffffffffe5ea8d9]        # 0x71dbffe56838
    71dc0186bf5f:	90                   	nop
    71dc0186bf60:	48 83 c4 28          	add    rsp,0x28
    71dc0186bf64:	c3                   	ret
    71dc0186bf65:	48 83 ec 28          	sub    rsp,0x28
    71dc0186bf69:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    71dc0186bf70:	ff 15 4a 08 6d ff    	call   QWORD PTR [rip+0xffffffffff6d084a]        # 0x71dc00f3c7c0
    71dc0186bf76:	90                   	nop
    71dc0186bf77:	48 83 c4 28          	add    rsp,0x28
    71dc0186bf7b:	c3                   	ret
    71dc0186bf7c:	48 83 ec 28          	sub    rsp,0x28
    71dc0186bf80:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc0186bf87:	ff 15 33 08 6d ff    	call   QWORD PTR [rip+0xffffffffff6d0833]        # 0x71dc00f3c7c0
    71dc0186bf8d:	90                   	nop
    71dc0186bf8e:	48 83 c4 28          	add    rsp,0x28
    71dc0186bf92:	c3                   	ret
