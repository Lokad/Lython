
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-10869.bin:     file format binary


Disassembly of section .data:

000071dc01b7e820 <.data>:
    71dc01b7e820:	55                   	push   rbp
    71dc01b7e821:	41 57                	push   r15
    71dc01b7e823:	41 56                	push   r14
    71dc01b7e825:	41 55                	push   r13
    71dc01b7e827:	41 54                	push   r12
    71dc01b7e829:	53                   	push   rbx
    71dc01b7e82a:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    71dc01b7e831:	48 8d ac 24 20 01 00 	lea    rbp,[rsp+0x120]
    71dc01b7e838:	00 
    71dc01b7e839:	33 c0                	xor    eax,eax
    71dc01b7e83b:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
    71dc01b7e842:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    71dc01b7e847:	62 71 7e 48 7f 85 20 	vmovdqu32 ZMMWORD PTR [rbp-0xe0],zmm8
    71dc01b7e84e:	ff ff ff 
    71dc01b7e851:	62 71 7e 48 7f 85 60 	vmovdqu32 ZMMWORD PTR [rbp-0xa0],zmm8
    71dc01b7e858:	ff ff ff 
    71dc01b7e85b:	62 71 7e 48 7f 85 90 	vmovdqu32 ZMMWORD PTR [rbp-0x70],zmm8
    71dc01b7e862:	ff ff ff 
    71dc01b7e865:	48 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rdi
    71dc01b7e86c:	ff 15 96 67 a6 ff    	call   QWORD PTR [rip+0xffffffffffa66796]        # 0x71dc015e5008
    71dc01b7e872:	eb 2f                	jmp    0x71dc01b7e8a3
    71dc01b7e874:	33 c0                	xor    eax,eax
    71dc01b7e876:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7e87d:	41 89 85 dc 00 00 00 	mov    DWORD PTR [r13+0xdc],eax
    71dc01b7e884:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7e88b:	41 80 bd e2 00 00 00 	cmp    BYTE PTR [r13+0xe2],0x0
    71dc01b7e892:	00 
    71dc01b7e893:	0f 85 9c 0c 00 00    	jne    0x71dc01b7f535
    71dc01b7e899:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    71dc01b7e89d:	0f 84 92 0c 00 00    	je     0x71dc01b7f535
    71dc01b7e8a3:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7e8aa:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    71dc01b7e8ae:	48 8b 76 50          	mov    rsi,QWORD PTR [rsi+0x50]
    71dc01b7e8b2:	44 8b 9f d8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xd8]
    71dc01b7e8b9:	48 b8 48 02 5b 01 dc 	movabs rax,0x71dc015b0248
    71dc01b7e8c0:	71 00 00 
    71dc01b7e8c3:	48 39 06             	cmp    QWORD PTR [rsi],rax
    71dc01b7e8c6:	0f 85 1d 0c 00 00    	jne    0x71dc01b7f4e9
    71dc01b7e8cc:	44 3b 5e 10          	cmp    r11d,DWORD PTR [rsi+0x10]
    71dc01b7e8d0:	0f 83 49 0c 00 00    	jae    0x71dc01b7f51f
    71dc01b7e8d6:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    71dc01b7e8da:	44 3b 5e 08          	cmp    r11d,DWORD PTR [rsi+0x8]
    71dc01b7e8de:	0f 83 4b 0c 00 00    	jae    0x71dc01b7f52f
    71dc01b7e8e4:	4a 8b 5c de 10       	mov    rbx,QWORD PTR [rsi+r11*8+0x10]
    71dc01b7e8e9:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7e8f0:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    71dc01b7e8f7:	83 78 08 00          	cmp    DWORD PTR [rax+0x8],0x0
    71dc01b7e8fb:	74 20                	je     0x71dc01b7e91d
    71dc01b7e8fd:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    71dc01b7e904:	8b 8f d8 00 00 00    	mov    ecx,DWORD PTR [rdi+0xd8]
    71dc01b7e90a:	3b 48 08             	cmp    ecx,DWORD PTR [rax+0x8]
    71dc01b7e90d:	0f 83 1c 0c 00 00    	jae    0x71dc01b7f52f
    71dc01b7e913:	48 8d 44 c8 10       	lea    rax,[rax+rcx*8+0x10]
    71dc01b7e918:	80 38 00             	cmp    BYTE PTR [rax],0x0
    71dc01b7e91b:	74 2b                	je     0x71dc01b7e948
    71dc01b7e91d:	33 c0                	xor    eax,eax
    71dc01b7e91f:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    71dc01b7e922:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc01b7e926:	48 89 85 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],rax
    71dc01b7e92d:	48 8b 85 08 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf8]
    71dc01b7e934:	8b 58 08             	mov    ebx,DWORD PTR [rax+0x8]
    71dc01b7e937:	39 9f dc 00 00 00    	cmp    DWORD PTR [rdi+0xdc],ebx
    71dc01b7e93d:	0f 8d 41 ff ff ff    	jge    0x71dc01b7e884
    71dc01b7e943:	e9 41 0b 00 00       	jmp    0x71dc01b7f489
    71dc01b7e948:	8b 8f 18 01 00 00    	mov    ecx,DWORD PTR [rdi+0x118]
    71dc01b7e94e:	c6 00 01             	mov    BYTE PTR [rax],0x1
    71dc01b7e951:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    71dc01b7e954:	eb c7                	jmp    0x71dc01b7e91d
    71dc01b7e956:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7e95d:	48 83 bf 88 00 00 00 	cmp    QWORD PTR [rdi+0x88],0x0
    71dc01b7e964:	00 
    71dc01b7e965:	0f 85 b3 01 00 00    	jne    0x71dc01b7eb1e
    71dc01b7e96b:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7e972:	8b 5e 10             	mov    ebx,DWORD PTR [rsi+0x10]
    71dc01b7e975:	83 fb 2f             	cmp    ebx,0x2f
    71dc01b7e978:	0f 87 ca 00 00 00    	ja     0x71dc01b7ea48
    71dc01b7e97e:	8b f3                	mov    esi,ebx
    71dc01b7e980:	48 8d 05 51 0d 00 00 	lea    rax,[rip+0xd51]        # 0x71dc01b7f6d8
    71dc01b7e987:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    71dc01b7e98a:	48 8d 0d db fe ff ff 	lea    rcx,[rip+0xfffffffffffffedb]        # 0x71dc01b7e86c
    71dc01b7e991:	48 03 c1             	add    rax,rcx
    71dc01b7e994:	ff e0                	jmp    rax
    71dc01b7e996:	4c 8d bf e8 00 00 00 	lea    r15,[rdi+0xe8]
    71dc01b7e99d:	4c 8b 77 08          	mov    r14,QWORD PTR [rdi+0x8]
    71dc01b7e9a1:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc01b7e9a5:	44 8b db             	mov    r11d,ebx
    71dc01b7e9a8:	41 83 fb 04          	cmp    r11d,0x4
    71dc01b7e9ac:	74 0a                	je     0x71dc01b7e9b8
    71dc01b7e9ae:	41 83 fb 0d          	cmp    r11d,0xd
    71dc01b7e9b2:	0f 85 a8 06 00 00    	jne    0x71dc01b7f060
    71dc01b7e9b8:	4c 8b 9d 00 ff ff ff 	mov    r11,QWORD PTR [rbp-0x100]
    71dc01b7e9bf:	41 8b 5b 08          	mov    ebx,DWORD PTR [r11+0x8]
    71dc01b7e9c3:	4c 8b 9d 00 ff ff ff 	mov    r11,QWORD PTR [rbp-0x100]
    71dc01b7e9ca:	4d 8b 2b             	mov    r13,QWORD PTR [r11]
    71dc01b7e9cd:	4c 8b 67 70          	mov    r12,QWORD PTR [rdi+0x70]
    71dc01b7e9d1:	45 33 db             	xor    r11d,r11d
    71dc01b7e9d4:	4c 89 9d 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],r11
    71dc01b7e9db:	4c 89 9d 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],r11
    71dc01b7e9e2:	3b 5e 08             	cmp    ebx,DWORD PTR [rsi+0x8]
    71dc01b7e9e5:	0f 83 4c 0a 00 00    	jae    0x71dc01b7f437
    71dc01b7e9eb:	44 8b db             	mov    r11d,ebx
    71dc01b7e9ee:	4a 8b 74 de 10       	mov    rsi,QWORD PTR [rsi+r11*8+0x10]
    71dc01b7e9f3:	49 bb 70 31 80 21 d4 	movabs r11,0x71d421803170
    71dc01b7e9fa:	71 00 00 
    71dc01b7e9fd:	49 3b 33             	cmp    rsi,QWORD PTR [r11]
    71dc01b7ea00:	0f 84 7a 06 00 00    	je     0x71dc01b7f080
    71dc01b7ea06:	33 c0                	xor    eax,eax
    71dc01b7ea08:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
    71dc01b7ea0f:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
    71dc01b7ea16:	49 8b ff             	mov    rdi,r15
    71dc01b7ea19:	ff 15 49 66 a6 ff    	call   QWORD PTR [rip+0xffffffffffa66649]        # 0x71dc015e5068
    71dc01b7ea1f:	e9 32 0a 00 00       	jmp    0x71dc01b7f456
    71dc01b7ea24:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ea2b:	ff 15 cf 67 a6 ff    	call   QWORD PTR [rip+0xffffffffffa667cf]        # 0x71dc015e5200
    71dc01b7ea31:	e9 20 0a 00 00       	jmp    0x71dc01b7f456
    71dc01b7ea36:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ea3d:	ff 15 a5 67 a6 ff    	call   QWORD PTR [rip+0xffffffffffa667a5]        # 0x71dc015e51e8
    71dc01b7ea43:	e9 0e 0a 00 00       	jmp    0x71dc01b7f456
    71dc01b7ea48:	c5 fc 57 c0          	vxorps ymm0,ymm0,ymm0
    71dc01b7ea4c:	62 f1 7e 28 7f 45 fb 	vmovdqu32 YMMWORD PTR [rbp-0xa0],ymm0
    71dc01b7ea53:	c5 fa 7f 85 78 ff ff 	vmovdqu XMMWORD PTR [rbp-0x88],xmm0
    71dc01b7ea5a:	ff 
    71dc01b7ea5b:	48 8d bd 60 ff ff ff 	lea    rdi,[rbp-0xa0]
    71dc01b7ea62:	be 1b 00 00 00       	mov    esi,0x1b
    71dc01b7ea67:	ba 01 00 00 00       	mov    edx,0x1
    71dc01b7ea6c:	ff 15 f6 00 30 ff    	call   QWORD PTR [rip+0xffffffffff3000f6]        # 0x71dc00e7eb68
    71dc01b7ea72:	62 f1 7e 28 6f 45 fb 	vmovdqu32 ymm0,YMMWORD PTR [rbp-0xa0]
    71dc01b7ea79:	c5 fe 7f 45 88       	vmovdqu YMMWORD PTR [rbp-0x78],ymm0
    71dc01b7ea7e:	48 8b 7d 80          	mov    rdi,QWORD PTR [rbp-0x80]
    71dc01b7ea82:	48 89 7d a8          	mov    QWORD PTR [rbp-0x58],rdi
    71dc01b7ea86:	8b 7d 98             	mov    edi,DWORD PTR [rbp-0x68]
    71dc01b7ea89:	3b 7d a8             	cmp    edi,DWORD PTR [rbp-0x58]
    71dc01b7ea8c:	0f 87 9e 09 00 00    	ja     0x71dc01b7f430
    71dc01b7ea92:	48 8b 75 a0          	mov    rsi,QWORD PTR [rbp-0x60]
    71dc01b7ea96:	8b c7                	mov    eax,edi
    71dc01b7ea98:	48 8d 34 46          	lea    rsi,[rsi+rax*2]
    71dc01b7ea9c:	8b 45 a8             	mov    eax,DWORD PTR [rbp-0x58]
    71dc01b7ea9f:	2b c7                	sub    eax,edi
    71dc01b7eaa1:	83 f8 1b             	cmp    eax,0x1b
    71dc01b7eaa4:	0f 82 93 09 00 00    	jb     0x71dc01b7f43d
    71dc01b7eaaa:	c5 fc 10 05 ee 0c 00 	vmovups ymm0,YMMWORD PTR [rip+0xcee]        # 0x71dc01b7f7a0
    71dc01b7eab1:	00 
    71dc01b7eab2:	c5 fc 11 06          	vmovups YMMWORD PTR [rsi],ymm0
    71dc01b7eab6:	c5 f8 10 05 02 0d 00 	vmovups xmm0,XMMWORD PTR [rip+0xd02]        # 0x71dc01b7f7c0
    71dc01b7eabd:	00 
    71dc01b7eabe:	c5 f8 11 46 20       	vmovups XMMWORD PTR [rsi+0x20],xmm0
    71dc01b7eac3:	c7 46 30 65 00 3a 00 	mov    DWORD PTR [rsi+0x30],0x3a0065
    71dc01b7eaca:	66 c7 46 34 20 00    	mov    WORD PTR [rsi+0x34],0x20
    71dc01b7ead0:	8b 7d 98             	mov    edi,DWORD PTR [rbp-0x68]
    71dc01b7ead3:	83 c7 1b             	add    edi,0x1b
    71dc01b7ead6:	89 7d 98             	mov    DWORD PTR [rbp-0x68],edi
    71dc01b7ead9:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7eae0:	8b 76 10             	mov    esi,DWORD PTR [rsi+0x10]
    71dc01b7eae3:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc01b7eae7:	ff 15 b3 e6 9f ff    	call   QWORD PTR [rip+0xffffffffff9fe6b3]        # 0x71dc0157d1a0
    71dc01b7eaed:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01b7eaf4:	71 00 00 
    71dc01b7eaf7:	e8 c4 27 4d 7c       	call   0x71dc7e0512c0
    71dc01b7eafc:	48 8b d8             	mov    rbx,rax
    71dc01b7eaff:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc01b7eb03:	ff 15 8f 00 30 ff    	call   QWORD PTR [rip+0xffffffffff30008f]        # 0x71dc00e7eb98
    71dc01b7eb09:	48 8b f0             	mov    rsi,rax
    71dc01b7eb0c:	48 8b fb             	mov    rdi,rbx
    71dc01b7eb0f:	ff 15 5b 78 3c ff    	call   QWORD PTR [rip+0xffffffffff3c785b]        # 0x71dc00f46370
    71dc01b7eb15:	48 8b fb             	mov    rdi,rbx
    71dc01b7eb18:	e8 83 34 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7eb1d:	cc                   	int3
    71dc01b7eb1e:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    71dc01b7eb25:	00 
    71dc01b7eb26:	0f 85 3f fe ff ff    	jne    0x71dc01b7e96b
    71dc01b7eb2c:	e9 16 05 00 00       	jmp    0x71dc01b7f047
    71dc01b7eb31:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    71dc01b7eb38:	00 
    71dc01b7eb39:	0f 85 dc 00 00 00    	jne    0x71dc01b7ec1b
    71dc01b7eb3f:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7eb46:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01b7eb49:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    71dc01b7eb50:	ff 15 d2 65 a6 ff    	call   QWORD PTR [rip+0xffffffffffa665d2]        # 0x71dc015e5128
    71dc01b7eb56:	48 8b d8             	mov    rbx,rax
    71dc01b7eb59:	48 bf a0 27 e6 ff db 	movabs rdi,0x71dbffe627a0
    71dc01b7eb60:	71 00 00 
    71dc01b7eb63:	be 01 00 00 00       	mov    esi,0x1
    71dc01b7eb68:	e8 e3 28 4d 7c       	call   0x71dc7e051450
    71dc01b7eb6d:	4c 8b f8             	mov    r15,rax
    71dc01b7eb70:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    71dc01b7eb74:	48 8b f3             	mov    rsi,rbx
    71dc01b7eb77:	e8 c4 14 0a fd       	call   0x71dbfec20040
    71dc01b7eb7c:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7eb83:	48 8b 57 70          	mov    rdx,QWORD PTR [rdi+0x70]
    71dc01b7eb87:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7eb8e:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01b7eb91:	49 8b ff             	mov    rdi,r15
    71dc01b7eb94:	ff 15 ee 06 a0 ff    	call   QWORD PTR [rip+0xffffffffffa006ee]        # 0x71dc0157f288
    71dc01b7eb9a:	48 8b d8             	mov    rbx,rax
    71dc01b7eb9d:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7eba4:	4c 8b 7f 70          	mov    r15,QWORD PTR [rdi+0x70]
    71dc01b7eba8:	48 bf c8 a0 5d 01 dc 	movabs rdi,0x71dc015da0c8
    71dc01b7ebaf:	71 00 00 
    71dc01b7ebb2:	e8 09 27 4d 7c       	call   0x71dc7e0512c0
    71dc01b7ebb7:	4c 8b f0             	mov    r14,rax
    71dc01b7ebba:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7ebc1:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    71dc01b7ebc4:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc01b7ebc8:	48 8b f3             	mov    rsi,rbx
    71dc01b7ebcb:	e8 70 14 0a fd       	call   0x71dbfec20040
    71dc01b7ebd0:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc01b7ebd4:	49 8b f7             	mov    rsi,r15
    71dc01b7ebd7:	e8 64 14 0a fd       	call   0x71dbfec20040
    71dc01b7ebdc:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    71dc01b7ebe0:	49 8b f5             	mov    rsi,r13
    71dc01b7ebe3:	e8 58 14 0a fd       	call   0x71dbfec20040
    71dc01b7ebe8:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc01b7ebef:	71 00 00 
    71dc01b7ebf2:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01b7ebf5:	49 8d 7e 20          	lea    rdi,[r14+0x20]
    71dc01b7ebf9:	e8 42 14 0a fd       	call   0x71dbfec20040
    71dc01b7ebfe:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7ec05:	48 8d bf 90 00 00 00 	lea    rdi,[rdi+0x90]
    71dc01b7ec0c:	49 8b f6             	mov    rsi,r14
    71dc01b7ec0f:	e8 2c 14 0a fd       	call   0x71dbfec20040
    71dc01b7ec14:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7ec1b:	48 8b 97 90 00 00 00 	mov    rdx,QWORD PTR [rdi+0x90]
    71dc01b7ec22:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    71dc01b7ec29:	4c 8b 87 88 00 00 00 	mov    r8,QWORD PTR [rdi+0x88]
    71dc01b7ec30:	38 12                	cmp    BYTE PTR [rdx],dl
    71dc01b7ec32:	48 8d b5 30 ff ff ff 	lea    rsi,[rbp-0xd0]
    71dc01b7ec39:	48 8b fa             	mov    rdi,rdx
    71dc01b7ec3c:	48 8b d1             	mov    rdx,rcx
    71dc01b7ec3f:	49 8b c8             	mov    rcx,r8
    71dc01b7ec42:	45 33 c0             	xor    r8d,r8d
    71dc01b7ec45:	ff 15 3d d9 b6 ff    	call   QWORD PTR [rip+0xffffffffffb6d93d]        # 0x71dc016ec588
    71dc01b7ec4b:	48 8b 9d 30 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd0]
    71dc01b7ec52:	4c 0f bf bd 38 ff ff 	movsx  r15,WORD PTR [rbp-0xc8]
    71dc01b7ec59:	ff 
    71dc01b7ec5a:	48 8b 85 40 ff ff ff 	mov    rax,QWORD PTR [rbp-0xc0]
    71dc01b7ec61:	0f b6 8d 48 ff ff ff 	movzx  ecx,BYTE PTR [rbp-0xb8]
    71dc01b7ec68:	48 85 db             	test   rbx,rbx
    71dc01b7ec6b:	0f 85 9b 06 00 00    	jne    0x71dc01b7f30c
    71dc01b7ec71:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc01b7ec75:	88 4d c8             	mov    BYTE PTR [rbp-0x38],cl
    71dc01b7ec78:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc01b7ec7f:	71 00 00 
    71dc01b7ec82:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01b7ec85:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7ec8c:	48 8d bf 80 00 00 00 	lea    rdi,[rdi+0x80]
    71dc01b7ec93:	e8 a8 13 0a fd       	call   0x71dbfec20040
    71dc01b7ec98:	33 ff                	xor    edi,edi
    71dc01b7ec9a:	48 8b 9d 10 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xf0]
    71dc01b7eca1:	48 89 bb 88 00 00 00 	mov    QWORD PTR [rbx+0x88],rdi
    71dc01b7eca8:	80 7d c8 00          	cmp    BYTE PTR [rbp-0x38],0x0
    71dc01b7ecac:	74 25                	je     0x71dc01b7ecd3
    71dc01b7ecae:	48 8d 7d c0          	lea    rdi,[rbp-0x40]
    71dc01b7ecb2:	ff 15 00 65 a6 ff    	call   QWORD PTR [rip+0xffffffffffa66500]        # 0x71dc015e51b8
    71dc01b7ecb8:	48 8b f0             	mov    rsi,rax
    71dc01b7ecbb:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    71dc01b7ecc2:	e8 79 13 0a fd       	call   0x71dbfec20040
    71dc01b7ecc7:	c6 83 e1 00 00 00 01 	mov    BYTE PTR [rbx+0xe1],0x1
    71dc01b7ecce:	e9 62 08 00 00       	jmp    0x71dc01b7f535
    71dc01b7ecd3:	48 8b b3 90 00 00 00 	mov    rsi,QWORD PTR [rbx+0x90]
    71dc01b7ecda:	48 8b 76 20          	mov    rsi,QWORD PTR [rsi+0x20]
    71dc01b7ecde:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    71dc01b7ece5:	ff 15 7d 63 a6 ff    	call   QWORD PTR [rip+0xffffffffffa6637d]        # 0x71dc015e5068
    71dc01b7eceb:	33 f6                	xor    esi,esi
    71dc01b7eced:	48 89 b3 90 00 00 00 	mov    QWORD PTR [rbx+0x90],rsi
    71dc01b7ecf4:	e9 5d 07 00 00       	jmp    0x71dc01b7f456
    71dc01b7ecf9:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ed00:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01b7ed03:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    71dc01b7ed0a:	ff 15 18 64 a6 ff    	call   QWORD PTR [rip+0xffffffffffa66418]        # 0x71dc015e5128
    71dc01b7ed10:	48 8b f0             	mov    rsi,rax
    71dc01b7ed13:	48 8b 9d 10 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xf0]
    71dc01b7ed1a:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    71dc01b7ed21:	e8 1a 13 0a fd       	call   0x71dbfec20040
    71dc01b7ed26:	66 c7 83 e0 00 00 00 	mov    WORD PTR [rbx+0xe0],0x101
    71dc01b7ed2d:	01 01 
    71dc01b7ed2f:	ff 83 dc 00 00 00    	inc    DWORD PTR [rbx+0xdc]
    71dc01b7ed35:	e9 fb 07 00 00       	jmp    0x71dc01b7f535
    71dc01b7ed3a:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ed41:	ff 15 31 65 a6 ff    	call   QWORD PTR [rip+0xffffffffffa66531]        # 0x71dc015e5278
    71dc01b7ed47:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    71dc01b7ed4a:	e9 07 07 00 00       	jmp    0x71dc01b7f456
    71dc01b7ed4f:	48 8b 85 00 ff ff ff 	mov    rax,QWORD PTR [rbp-0x100]
    71dc01b7ed56:	48 8d 3c 24          	lea    rdi,[rsp]
    71dc01b7ed5a:	48 8b f0             	mov    rsi,rax
    71dc01b7ed5d:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    71dc01b7ed60:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    71dc01b7ed64:	48 83 c6 08          	add    rsi,0x8
    71dc01b7ed68:	48 83 c7 08          	add    rdi,0x8
    71dc01b7ed6c:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    71dc01b7ed6e:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    71dc01b7ed70:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7ed77:	ff 15 e3 64 a6 ff    	call   QWORD PTR [rip+0xffffffffffa664e3]        # 0x71dc015e5260
    71dc01b7ed7d:	85 c0                	test   eax,eax
    71dc01b7ed7f:	0f 84 15 01 00 00    	je     0x71dc01b7ee9a
    71dc01b7ed85:	e9 ab 07 00 00       	jmp    0x71dc01b7f535
    71dc01b7ed8a:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ed91:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc01b7ed95:	c5 fa 7f 85 18 ff ff 	vmovdqu XMMWORD PTR [rbp-0xe8],xmm0
    71dc01b7ed9c:	ff 
    71dc01b7ed9d:	4c 8b 5e 10          	mov    r11,QWORD PTR [rsi+0x10]
    71dc01b7eda1:	4c 89 9d 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],r11
    71dc01b7eda8:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    71dc01b7edac:	48 8b 76 68          	mov    rsi,QWORD PTR [rsi+0x68]
    71dc01b7edb0:	83 bd 28 ff ff ff 1d 	cmp    DWORD PTR [rbp-0xd8],0x1d
    71dc01b7edb7:	0f 85 ae 05 00 00    	jne    0x71dc01b7f36b
    71dc01b7edbd:	44 8b 9d 20 ff ff ff 	mov    r11d,DWORD PTR [rbp-0xe0]
    71dc01b7edc4:	48 b8 a8 79 55 01 dc 	movabs rax,0x71dc015579a8
    71dc01b7edcb:	71 00 00 
    71dc01b7edce:	48 39 06             	cmp    QWORD PTR [rsi],rax
    71dc01b7edd1:	0f 85 b4 05 00 00    	jne    0x71dc01b7f38b
    71dc01b7edd7:	44 39 5e 08          	cmp    DWORD PTR [rsi+0x8],r11d
    71dc01b7eddb:	0f 86 a2 04 00 00    	jbe    0x71dc01b7f283
    71dc01b7ede1:	4a 8b 74 de 10       	mov    rsi,QWORD PTR [rsi+r11*8+0x10]
    71dc01b7ede6:	80 7e 25 00          	cmp    BYTE PTR [rsi+0x25],0x0
    71dc01b7edea:	0f 84 aa 00 00 00    	je     0x71dc01b7ee9a
    71dc01b7edf0:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7edf7:	48 8d 87 e8 00 00 00 	lea    rax,[rdi+0xe8]
    71dc01b7edfe:	8b 4e 20             	mov    ecx,DWORD PTR [rsi+0x20]
    71dc01b7ee01:	80 7e 24 00          	cmp    BYTE PTR [rsi+0x24],0x0
    71dc01b7ee05:	0f 95 c2             	setne  dl
    71dc01b7ee08:	0f b6 d2             	movzx  edx,dl
    71dc01b7ee0b:	8d 4c 11 01          	lea    ecx,[rcx+rdx*1+0x1]
    71dc01b7ee0f:	85 c9                	test   ecx,ecx
    71dc01b7ee11:	0f 8c 8f 05 00 00    	jl     0x71dc01b7f3a6
    71dc01b7ee17:	8b 58 30             	mov    ebx,DWORD PTR [rax+0x30]
    71dc01b7ee1a:	3b d9                	cmp    ebx,ecx
    71dc01b7ee1c:	0f 8c 84 05 00 00    	jl     0x71dc01b7f3a6
    71dc01b7ee22:	2b d9                	sub    ebx,ecx
    71dc01b7ee24:	48 8b 00             	mov    rax,QWORD PTR [rax]
    71dc01b7ee27:	03 d3                	add    edx,ebx
    71dc01b7ee29:	3b 50 08             	cmp    edx,DWORD PTR [rax+0x8]
    71dc01b7ee2c:	0f 83 05 06 00 00    	jae    0x71dc01b7f437
    71dc01b7ee32:	8b ca                	mov    ecx,edx
    71dc01b7ee34:	48 8b 44 c8 10       	mov    rax,QWORD PTR [rax+rcx*8+0x10]
    71dc01b7ee39:	48 85 c0             	test   rax,rax
    71dc01b7ee3c:	0f 84 81 05 00 00    	je     0x71dc01b7f3c3
    71dc01b7ee42:	48 b9 38 aa 5d 01 dc 	movabs rcx,0x71dc015daa38
    71dc01b7ee49:	71 00 00 
    71dc01b7ee4c:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01b7ee4f:	75 05                	jne    0x71dc01b7ee56
    71dc01b7ee51:	4c 8b f8             	mov    r15,rax
    71dc01b7ee54:	eb 03                	jmp    0x71dc01b7ee59
    71dc01b7ee56:	45 33 ff             	xor    r15d,r15d
    71dc01b7ee59:	45 33 f6             	xor    r14d,r14d
    71dc01b7ee5c:	48 b9 70 04 61 01 dc 	movabs rcx,0x71dc01610470
    71dc01b7ee63:	71 00 00 
    71dc01b7ee66:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01b7ee69:	75 26                	jne    0x71dc01b7ee91
    71dc01b7ee6b:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
    71dc01b7ee6f:	48 85 c9             	test   rcx,rcx
    71dc01b7ee72:	74 11                	je     0x71dc01b7ee85
    71dc01b7ee74:	48 ba 38 aa 5d 01 dc 	movabs rdx,0x71dc015daa38
    71dc01b7ee7b:	71 00 00 
    71dc01b7ee7e:	48 39 11             	cmp    QWORD PTR [rcx],rdx
    71dc01b7ee81:	74 02                	je     0x71dc01b7ee85
    71dc01b7ee83:	33 c9                	xor    ecx,ecx
    71dc01b7ee85:	48 85 c9             	test   rcx,rcx
    71dc01b7ee88:	74 07                	je     0x71dc01b7ee91
    71dc01b7ee8a:	4c 8b f9             	mov    r15,rcx
    71dc01b7ee8d:	4c 8b 70 08          	mov    r14,QWORD PTR [rax+0x8]
    71dc01b7ee91:	4d 85 ff             	test   r15,r15
    71dc01b7ee94:	0f 85 57 05 00 00    	jne    0x71dc01b7f3f1
    71dc01b7ee9a:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7eea1:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7eea8:	ff 15 9a 63 a6 ff    	call   QWORD PTR [rip+0xffffffffffa6639a]        # 0x71dc015e5248
    71dc01b7eeae:	e9 a3 05 00 00       	jmp    0x71dc01b7f456
    71dc01b7eeb3:	48 8d b7 e8 00 00 00 	lea    rsi,[rdi+0xe8]
    71dc01b7eeba:	48 8b 85 00 ff ff ff 	mov    rax,QWORD PTR [rbp-0x100]
    71dc01b7eec1:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    71dc01b7eec4:	8b 46 30             	mov    eax,DWORD PTR [rsi+0x30]
    71dc01b7eec7:	85 c0                	test   eax,eax
    71dc01b7eec9:	0f 84 08 03 00 00    	je     0x71dc01b7f1d7
    71dc01b7eecf:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01b7eed2:	ff c8                	dec    eax
    71dc01b7eed4:	3b 46 08             	cmp    eax,DWORD PTR [rsi+0x8]
    71dc01b7eed7:	0f 83 5a 05 00 00    	jae    0x71dc01b7f437
    71dc01b7eedd:	48 8b 74 c6 10       	mov    rsi,QWORD PTR [rsi+rax*8+0x10]
    71dc01b7eee2:	48 85 f6             	test   rsi,rsi
    71dc01b7eee5:	0f 84 a7 02 00 00    	je     0x71dc01b7f192
    71dc01b7eeeb:	4c 8b fe             	mov    r15,rsi
    71dc01b7eeee:	48 b8 e0 44 65 01 dc 	movabs rax,0x71dc016544e0
    71dc01b7eef5:	71 00 00 
    71dc01b7eef8:	49 39 07             	cmp    QWORD PTR [r15],rax
    71dc01b7eefb:	0f 85 bf 02 00 00    	jne    0x71dc01b7f1c0
    71dc01b7ef01:	4d 85 ff             	test   r15,r15
    71dc01b7ef04:	0f 84 cd 02 00 00    	je     0x71dc01b7f1d7
    71dc01b7ef0a:	48 b8 e0 44 65 01 dc 	movabs rax,0x71dc016544e0
    71dc01b7ef11:	71 00 00 
    71dc01b7ef14:	49 39 07             	cmp    QWORD PTR [r15],rax
    71dc01b7ef17:	0f 85 d6 02 00 00    	jne    0x71dc01b7f1f3
    71dc01b7ef1d:	49 8b ff             	mov    rdi,r15
    71dc01b7ef20:	ff 15 6a 56 ad ff    	call   QWORD PTR [rip+0xffffffffffad566a]        # 0x71dc01654590
    71dc01b7ef26:	85 c0                	test   eax,eax
    71dc01b7ef28:	0f 84 da 02 00 00    	je     0x71dc01b7f208
    71dc01b7ef2e:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7ef35:	49 8d 9d e8 00 00 00 	lea    rbx,[r13+0xe8]
    71dc01b7ef3c:	48 bf e0 44 65 01 dc 	movabs rdi,0x71dc016544e0
    71dc01b7ef43:	71 00 00 
    71dc01b7ef46:	49 39 3f             	cmp    QWORD PTR [r15],rdi
    71dc01b7ef49:	0f 85 fc 02 00 00    	jne    0x71dc01b7f24b
    71dc01b7ef4f:	49 8b 77 28          	mov    rsi,QWORD PTR [r15+0x28]
    71dc01b7ef53:	48 8b fb             	mov    rdi,rbx
    71dc01b7ef56:	ff 15 0c 61 a6 ff    	call   QWORD PTR [rip+0xffffffffffa6610c]        # 0x71dc015e5068
    71dc01b7ef5c:	33 db                	xor    ebx,ebx
    71dc01b7ef5e:	89 5d d4             	mov    DWORD PTR [rbp-0x2c],ebx
    71dc01b7ef61:	e9 f0 04 00 00       	jmp    0x71dc01b7f456
    71dc01b7ef66:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ef6d:	ff 15 a5 62 a6 ff    	call   QWORD PTR [rip+0xffffffffffa662a5]        # 0x71dc015e5218
    71dc01b7ef73:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    71dc01b7ef76:	e9 db 04 00 00       	jmp    0x71dc01b7f456
    71dc01b7ef7b:	83 fb 04             	cmp    ebx,0x4
    71dc01b7ef7e:	74 09                	je     0x71dc01b7ef89
    71dc01b7ef80:	83 fb 0d             	cmp    ebx,0xd
    71dc01b7ef83:	0f 85 d7 00 00 00    	jne    0x71dc01b7f060
    71dc01b7ef89:	48 8b 95 00 ff ff ff 	mov    rdx,QWORD PTR [rbp-0x100]
    71dc01b7ef90:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    71dc01b7ef93:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7ef9a:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    71dc01b7ef9d:	ff 15 dd 60 a6 ff    	call   QWORD PTR [rip+0xffffffffffa660dd]        # 0x71dc015e5080
    71dc01b7efa3:	e9 ae 04 00 00       	jmp    0x71dc01b7f456
    71dc01b7efa8:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
    71dc01b7efac:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
    71dc01b7efb0:	8b cb                	mov    ecx,ebx
    71dc01b7efb2:	83 f9 03             	cmp    ecx,0x3
    71dc01b7efb5:	0f 85 7e 00 00 00    	jne    0x71dc01b7f039
    71dc01b7efbb:	48 8b 8d 00 ff ff ff 	mov    rcx,QWORD PTR [rbp-0x100]
    71dc01b7efc2:	8b 71 08             	mov    esi,DWORD PTR [rcx+0x8]
    71dc01b7efc5:	48 b9 a0 27 e6 ff db 	movabs rcx,0x71dbffe627a0
    71dc01b7efcc:	71 00 00 
    71dc01b7efcf:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01b7efd2:	0f 85 b2 02 00 00    	jne    0x71dc01b7f28a
    71dc01b7efd8:	39 70 08             	cmp    DWORD PTR [rax+0x8],esi
    71dc01b7efdb:	0f 86 a2 02 00 00    	jbe    0x71dc01b7f283
    71dc01b7efe1:	8b ce                	mov    ecx,esi
    71dc01b7efe3:	48 8b 74 c8 10       	mov    rsi,QWORD PTR [rax+rcx*8+0x10]
    71dc01b7efe8:	48 8b c6             	mov    rax,rsi
    71dc01b7efeb:	48 85 c0             	test   rax,rax
    71dc01b7efee:	74 13                	je     0x71dc01b7f003
    71dc01b7eff0:	48 b9 f8 5b 56 01 dc 	movabs rcx,0x71dc01565bf8
    71dc01b7eff7:	71 00 00 
    71dc01b7effa:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01b7effd:	0f 85 9f 02 00 00    	jne    0x71dc01b7f2a2
    71dc01b7f003:	48 8b f0             	mov    rsi,rax
    71dc01b7f006:	48 8b 95 00 ff ff ff 	mov    rdx,QWORD PTR [rbp-0x100]
    71dc01b7f00d:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    71dc01b7f010:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7f017:	33 c9                	xor    ecx,ecx
    71dc01b7f019:	ff 15 c1 60 a6 ff    	call   QWORD PTR [rip+0xffffffffffa660c1]        # 0x71dc015e50e0
    71dc01b7f01f:	48 89 45 b0          	mov    QWORD PTR [rbp-0x50],rax
    71dc01b7f023:	48 89 55 b8          	mov    QWORD PTR [rbp-0x48],rdx
    71dc01b7f027:	48 8b 5d b0          	mov    rbx,QWORD PTR [rbp-0x50]
    71dc01b7f02b:	48 85 db             	test   rbx,rbx
    71dc01b7f02e:	0f 84 22 04 00 00    	je     0x71dc01b7f456
    71dc01b7f034:	e9 7d 02 00 00       	jmp    0x71dc01b7f2b6
    71dc01b7f039:	83 f9 08             	cmp    ecx,0x8
    71dc01b7f03c:	0f 84 79 ff ff ff    	je     0x71dc01b7efbb
    71dc01b7f042:	e9 1c 02 00 00       	jmp    0x71dc01b7f263
    71dc01b7f047:	48 8b 87 88 00 00 00 	mov    rax,QWORD PTR [rdi+0x88]
    71dc01b7f04e:	33 c9                	xor    ecx,ecx
    71dc01b7f050:	48 89 8f 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rcx
    71dc01b7f057:	48 8b f8             	mov    rdi,rax
    71dc01b7f05a:	e8 41 2f 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f05f:	cc                   	int3
    71dc01b7f060:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f067:	48 be e8 7f 65 fc db 	movabs rsi,0x71dbfc657fe8
    71dc01b7f06e:	71 00 00 
    71dc01b7f071:	ff 15 21 8a 9f ff    	call   QWORD PTR [rip+0xffffffffff9f8a21]        # 0x71dc01577a98
    71dc01b7f077:	48 8b f8             	mov    rdi,rax
    71dc01b7f07a:	e8 21 2f 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f07f:	cc                   	int3
    71dc01b7f080:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    71dc01b7f087:	00 
    71dc01b7f088:	0f 85 b1 00 00 00    	jne    0x71dc01b7f13f
    71dc01b7f08e:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01b7f092:	8b f3                	mov    esi,ebx
    71dc01b7f094:	49 bb 58 57 c4 fe db 	movabs r11,0x71dbfec45758
    71dc01b7f09b:	71 00 00 
    71dc01b7f09e:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f0a1:	48 8b f8             	mov    rdi,rax
    71dc01b7f0a4:	be 3c 00 00 00       	mov    esi,0x3c
    71dc01b7f0a9:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01b7f0ab:	ff 15 f7 f3 9f ff    	call   QWORD PTR [rip+0xffffffffff9ff3f7]        # 0x71dc0157e4a8
    71dc01b7f0b1:	85 c0                	test   eax,eax
    71dc01b7f0b3:	0f 85 86 00 00 00    	jne    0x71dc01b7f13f
    71dc01b7f0b9:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc01b7f0bd:	49 8b fc             	mov    rdi,r12
    71dc01b7f0c0:	ff 15 82 ff 9f ff    	call   QWORD PTR [rip+0xffffffffff9fff82]        # 0x71dc0157f048
    71dc01b7f0c6:	48 89 85 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rax
    71dc01b7f0cd:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01b7f0d1:	8b f3                	mov    esi,ebx
    71dc01b7f0d3:	49 bb 60 57 c4 fe db 	movabs r11,0x71dbfec45760
    71dc01b7f0da:	71 00 00 
    71dc01b7f0dd:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f0e0:	48 8b f0             	mov    rsi,rax
    71dc01b7f0e3:	48 8b bd f8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x108]
    71dc01b7f0ea:	48 8d 95 58 ff ff ff 	lea    rdx,[rbp-0xa8]
    71dc01b7f0f1:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01b7f0f3:	ff 15 67 e8 32 fe    	call   QWORD PTR [rip+0xfffffffffe32e867]        # 0x71dbffead960
    71dc01b7f0f9:	85 c0                	test   eax,eax
    71dc01b7f0fb:	74 0c                	je     0x71dc01b7f109
    71dc01b7f0fd:	48 8b b5 58 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xa8]
    71dc01b7f104:	e9 fd f8 ff ff       	jmp    0x71dc01b7ea06
    71dc01b7f109:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01b7f10d:	8b f3                	mov    esi,ebx
    71dc01b7f10f:	49 bb 68 57 c4 fe db 	movabs r11,0x71dbfec45768
    71dc01b7f116:	71 00 00 
    71dc01b7f119:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f11c:	48 8b f0             	mov    rsi,rax
    71dc01b7f11f:	48 8d 95 50 ff ff ff 	lea    rdx,[rbp-0xb0]
    71dc01b7f126:	49 8b fc             	mov    rdi,r12
    71dc01b7f129:	ff 15 91 82 a6 ff    	call   QWORD PTR [rip+0xffffffffffa68291]        # 0x71dc015e73c0
    71dc01b7f12f:	85 c0                	test   eax,eax
    71dc01b7f131:	74 0c                	je     0x71dc01b7f13f
    71dc01b7f133:	48 8b b5 50 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb0]
    71dc01b7f13a:	e9 c7 f8 ff ff       	jmp    0x71dc01b7ea06
    71dc01b7f13f:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    71dc01b7f146:	00 
    71dc01b7f147:	75 21                	jne    0x71dc01b7f16a
    71dc01b7f149:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01b7f14d:	8b f3                	mov    esi,ebx
    71dc01b7f14f:	49 bb 50 57 c4 fe db 	movabs r11,0x71dbfec45750
    71dc01b7f156:	71 00 00 
    71dc01b7f159:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f15c:	48 8b f8             	mov    rdi,rax
    71dc01b7f15f:	49 8b f5             	mov    rsi,r13
    71dc01b7f162:	ff 15 70 82 a6 ff    	call   QWORD PTR [rip+0xffffffffffa68270]        # 0x71dc015e73d8
    71dc01b7f168:	eb 1f                	jmp    0x71dc01b7f189
    71dc01b7f16a:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01b7f16e:	8b f3                	mov    esi,ebx
    71dc01b7f170:	49 bb 48 57 c4 fe db 	movabs r11,0x71dbfec45748
    71dc01b7f177:	71 00 00 
    71dc01b7f17a:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f17d:	48 8b f8             	mov    rdi,rax
    71dc01b7f180:	49 8b f5             	mov    rsi,r13
    71dc01b7f183:	ff 15 bf 81 a6 ff    	call   QWORD PTR [rip+0xffffffffffa681bf]        # 0x71dc015e7348
    71dc01b7f189:	48 8b f8             	mov    rdi,rax
    71dc01b7f18c:	e8 0f 2e 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f191:	cc                   	int3
    71dc01b7f192:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01b7f199:	71 00 00 
    71dc01b7f19c:	e8 1f 21 4d 7c       	call   0x71dc7e0512c0
    71dc01b7f1a1:	48 8b d8             	mov    rbx,rax
    71dc01b7f1a4:	48 8b fb             	mov    rdi,rbx
    71dc01b7f1a7:	48 be c0 e2 60 fc db 	movabs rsi,0x71dbfc60e2c0
    71dc01b7f1ae:	71 00 00 
    71dc01b7f1b1:	ff 15 b9 71 3c ff    	call   QWORD PTR [rip+0xffffffffff3c71b9]        # 0x71dc00f46370
    71dc01b7f1b7:	48 8b fb             	mov    rdi,rbx
    71dc01b7f1ba:	e8 e1 2d 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f1bf:	cc                   	int3
    71dc01b7f1c0:	48 bf f0 42 42 01 dc 	movabs rdi,0x71dc014242f0
    71dc01b7f1c7:	71 00 00 
    71dc01b7f1ca:	e8 d1 84 cc ff       	call   0x71dc018476a0
    71dc01b7f1cf:	4c 8b f8             	mov    r15,rax
    71dc01b7f1d2:	e9 2a fd ff ff       	jmp    0x71dc01b7ef01
    71dc01b7f1d7:	48 8b f3             	mov    rsi,rbx
    71dc01b7f1da:	48 bf a0 a5 65 fc db 	movabs rdi,0x71dbfc65a5a0
    71dc01b7f1e1:	71 00 00 
    71dc01b7f1e4:	ff 15 d6 7e a6 ff    	call   QWORD PTR [rip+0xffffffffffa67ed6]        # 0x71dc015e70c0
    71dc01b7f1ea:	48 8b f8             	mov    rdi,rax
    71dc01b7f1ed:	e8 ae 2d 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f1f2:	cc                   	int3
    71dc01b7f1f3:	49 8b ff             	mov    rdi,r15
    71dc01b7f1f6:	49 bb 70 57 c4 fe db 	movabs r11,0x71dbfec45770
    71dc01b7f1fd:	71 00 00 
    71dc01b7f200:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f203:	e9 1e fd ff ff       	jmp    0x71dc01b7ef26
    71dc01b7f208:	48 8b b5 00 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x100]
    71dc01b7f20f:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01b7f212:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7f219:	49 8d bd e8 00 00 00 	lea    rdi,[r13+0xe8]
    71dc01b7f220:	ff 15 02 5f a6 ff    	call   QWORD PTR [rip+0xffffffffffa65f02]        # 0x71dc015e5128
    71dc01b7f226:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f22d:	ff 15 9d 86 9f ff    	call   QWORD PTR [rip+0xffffffffff9f869d]        # 0x71dc015778d0
    71dc01b7f233:	41 89 85 d8 00 00 00 	mov    DWORD PTR [r13+0xd8],eax
    71dc01b7f23a:	bb 01 00 00 00       	mov    ebx,0x1
    71dc01b7f23f:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7f246:	e9 13 fd ff ff       	jmp    0x71dc01b7ef5e
    71dc01b7f24b:	49 8b ff             	mov    rdi,r15
    71dc01b7f24e:	49 bb 78 57 c4 fe db 	movabs r11,0x71dbfec45778
    71dc01b7f255:	71 00 00 
    71dc01b7f258:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f25b:	48 8b f0             	mov    rsi,rax
    71dc01b7f25e:	e9 f0 fc ff ff       	jmp    0x71dc01b7ef53
    71dc01b7f263:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f26a:	48 be 10 80 65 fc db 	movabs rsi,0x71dbfc658010
    71dc01b7f271:	71 00 00 
    71dc01b7f274:	ff 15 1e 88 9f ff    	call   QWORD PTR [rip+0xffffffffff9f881e]        # 0x71dc01577a98
    71dc01b7f27a:	48 8b f8             	mov    rdi,rax
    71dc01b7f27d:	e8 1e 2d 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f282:	cc                   	int3
    71dc01b7f283:	ff 15 27 02 30 ff    	call   QWORD PTR [rip+0xffffffffff300227]        # 0x71dc00e7f4b0
    71dc01b7f289:	cc                   	int3
    71dc01b7f28a:	48 8b f8             	mov    rdi,rax
    71dc01b7f28d:	49 bb 40 57 c4 fe db 	movabs r11,0x71dbfec45740
    71dc01b7f294:	71 00 00 
    71dc01b7f297:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f29a:	48 8b f0             	mov    rsi,rax
    71dc01b7f29d:	e9 46 fd ff ff       	jmp    0x71dc01b7efe8
    71dc01b7f2a2:	48 bf 30 a3 55 01 dc 	movabs rdi,0x71dc0155a330
    71dc01b7f2a9:	71 00 00 
    71dc01b7f2ac:	e8 af b1 cc ff       	call   0x71dc0184a460
    71dc01b7f2b1:	e9 4d fd ff ff       	jmp    0x71dc01b7f003
    71dc01b7f2b6:	48 8b f3             	mov    rsi,rbx
    71dc01b7f2b9:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc01b7f2c0:	71 00 00 
    71dc01b7f2c3:	e8 b8 5a cc ff       	call   0x71dc01844d80
    71dc01b7f2c8:	48 85 c0             	test   rax,rax
    71dc01b7f2cb:	74 25                	je     0x71dc01b7f2f2
    71dc01b7f2cd:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    71dc01b7f2d0:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01b7f2d6:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01b7f2dc:	0f 84 74 01 00 00    	je     0x71dc01b7f456
    71dc01b7f2e2:	48 8b f8             	mov    rdi,rax
    71dc01b7f2e5:	33 f6                	xor    esi,esi
    71dc01b7f2e7:	ff 15 2b 65 f9 fe    	call   QWORD PTR [rip+0xfffffffffef9652b]        # 0x71dc00b15818
    71dc01b7f2ed:	e9 64 01 00 00       	jmp    0x71dc01b7f456
    71dc01b7f2f2:	48 8b fb             	mov    rdi,rbx
    71dc01b7f2f5:	48 0f bf 75 b8       	movsx  rsi,WORD PTR [rbp-0x48]
    71dc01b7f2fa:	49 bb 80 57 c4 fe db 	movabs r11,0x71dbfec45780
    71dc01b7f301:	71 00 00 
    71dc01b7f304:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f307:	e9 4a 01 00 00       	jmp    0x71dc01b7f456
    71dc01b7f30c:	48 8b f3             	mov    rsi,rbx
    71dc01b7f30f:	48 bf 40 be 6f 01 dc 	movabs rdi,0x71dc016fbe40
    71dc01b7f316:	71 00 00 
    71dc01b7f319:	e8 62 5a cc ff       	call   0x71dc01844d80
    71dc01b7f31e:	4c 8b f0             	mov    r14,rax
    71dc01b7f321:	4d 85 f6             	test   r14,r14
    71dc01b7f324:	74 2b                	je     0x71dc01b7f351
    71dc01b7f326:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    71dc01b7f32a:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01b7f330:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01b7f336:	74 0b                	je     0x71dc01b7f343
    71dc01b7f338:	49 8b fe             	mov    rdi,r14
    71dc01b7f33b:	33 f6                	xor    esi,esi
    71dc01b7f33d:	ff 15 d5 64 f9 fe    	call   QWORD PTR [rip+0xfffffffffef964d5]        # 0x71dc00b15818
    71dc01b7f343:	49 8b 46 38          	mov    rax,QWORD PTR [r14+0x38]
    71dc01b7f347:	41 0f b6 4e 40       	movzx  ecx,BYTE PTR [r14+0x40]
    71dc01b7f34c:	e9 20 f9 ff ff       	jmp    0x71dc01b7ec71
    71dc01b7f351:	48 8b fb             	mov    rdi,rbx
    71dc01b7f354:	41 8b f7             	mov    esi,r15d
    71dc01b7f357:	49 bb 88 57 c4 fe db 	movabs r11,0x71dbfec45788
    71dc01b7f35e:	71 00 00 
    71dc01b7f361:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f364:	8b ca                	mov    ecx,edx
    71dc01b7f366:	e9 06 f9 ff ff       	jmp    0x71dc01b7ec71
    71dc01b7f36b:	48 8d bd 18 ff ff ff 	lea    rdi,[rbp-0xe8]
    71dc01b7f372:	48 be 10 81 65 fc db 	movabs rsi,0x71dbfc658110
    71dc01b7f379:	71 00 00 
    71dc01b7f37c:	ff 15 16 87 9f ff    	call   QWORD PTR [rip+0xffffffffff9f8716]        # 0x71dc01577a98
    71dc01b7f382:	48 8b f8             	mov    rdi,rax
    71dc01b7f385:	e8 16 2c 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f38a:	cc                   	int3
    71dc01b7f38b:	48 8b fe             	mov    rdi,rsi
    71dc01b7f38e:	41 8b f3             	mov    esi,r11d
    71dc01b7f391:	49 bb 90 57 c4 fe db 	movabs r11,0x71dbfec45790
    71dc01b7f398:	71 00 00 
    71dc01b7f39b:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f39e:	48 8b f0             	mov    rsi,rax
    71dc01b7f3a1:	e9 40 fa ff ff       	jmp    0x71dc01b7ede6
    71dc01b7f3a6:	48 8b 76 18          	mov    rsi,QWORD PTR [rsi+0x18]
    71dc01b7f3aa:	48 bf 98 7f 65 fc db 	movabs rdi,0x71dbfc657f98
    71dc01b7f3b1:	71 00 00 
    71dc01b7f3b4:	ff 15 06 7d a6 ff    	call   QWORD PTR [rip+0xffffffffffa67d06]        # 0x71dc015e70c0
    71dc01b7f3ba:	48 8b f8             	mov    rdi,rax
    71dc01b7f3bd:	e8 de 2b 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f3c2:	cc                   	int3
    71dc01b7f3c3:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01b7f3ca:	71 00 00 
    71dc01b7f3cd:	e8 ee 1e 4d 7c       	call   0x71dc7e0512c0
    71dc01b7f3d2:	48 8b d8             	mov    rbx,rax
    71dc01b7f3d5:	48 8b fb             	mov    rdi,rbx
    71dc01b7f3d8:	48 be c0 e2 60 fc db 	movabs rsi,0x71dbfc60e2c0
    71dc01b7f3df:	71 00 00 
    71dc01b7f3e2:	ff 15 88 6f 3c ff    	call   QWORD PTR [rip+0xffffffffff3c6f88]        # 0x71dc00f46370
    71dc01b7f3e8:	48 8b fb             	mov    rdi,rbx
    71dc01b7f3eb:	e8 b0 2b 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f3f0:	cc                   	int3
    71dc01b7f3f1:	41 80 7f 65 00       	cmp    BYTE PTR [r15+0x65],0x0
    71dc01b7f3f6:	0f 84 9e fa ff ff    	je     0x71dc01b7ee9a
    71dc01b7f3fc:	48 8d 7f 38          	lea    rdi,[rdi+0x38]
    71dc01b7f400:	e8 3b 0c 0a fd       	call   0x71dbfec20040
    71dc01b7f405:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7f40c:	49 8d 7d 40          	lea    rdi,[r13+0x40]
    71dc01b7f410:	49 8b f7             	mov    rsi,r15
    71dc01b7f413:	e8 28 0c 0a fd       	call   0x71dbfec20040
    71dc01b7f418:	49 8d 7d 48          	lea    rdi,[r13+0x48]
    71dc01b7f41c:	49 8b f6             	mov    rsi,r14
    71dc01b7f41f:	e8 1c 0c 0a fd       	call   0x71dbfec20040
    71dc01b7f424:	41 89 9d d0 00 00 00 	mov    DWORD PTR [r13+0xd0],ebx
    71dc01b7f42b:	e9 05 01 00 00       	jmp    0x71dc01b7f535
    71dc01b7f430:	ff 15 2a 5e 9f ff    	call   QWORD PTR [rip+0xffffffffff9f5e2a]        # 0x71dc01575260
    71dc01b7f436:	cc                   	int3
    71dc01b7f437:	e8 cc 21 2d fe       	call   0x71dbffe51608
    71dc01b7f43c:	cc                   	int3
    71dc01b7f43d:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc01b7f441:	48 be 60 7c 65 fc db 	movabs rsi,0x71dbfc657c60
    71dc01b7f448:	71 00 00 
    71dc01b7f44b:	ff 15 4f d1 b6 ff    	call   QWORD PTR [rip+0xffffffffffb6d14f]        # 0x71dc016ec5a0
    71dc01b7f451:	e9 83 f6 ff ff       	jmp    0x71dc01b7ead9
    71dc01b7f456:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    71dc01b7f45a:	0f 85 14 f4 ff ff    	jne    0x71dc01b7e874
    71dc01b7f460:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7f467:	41 8b 85 dc 00 00 00 	mov    eax,DWORD PTR [r13+0xdc]
    71dc01b7f46e:	ff c0                	inc    eax
    71dc01b7f470:	41 89 85 dc 00 00 00 	mov    DWORD PTR [r13+0xdc],eax
    71dc01b7f477:	48 8b 8d 08 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xf8]
    71dc01b7f47e:	8b 59 08             	mov    ebx,DWORD PTR [rcx+0x8]
    71dc01b7f481:	3b d8                	cmp    ebx,eax
    71dc01b7f483:	0f 8e fb f3 ff ff    	jle    0x71dc01b7e884
    71dc01b7f489:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7f490:	8b 87 dc 00 00 00    	mov    eax,DWORD PTR [rdi+0xdc]
    71dc01b7f496:	3b c3                	cmp    eax,ebx
    71dc01b7f498:	0f 83 91 00 00 00    	jae    0x71dc01b7f52f
    71dc01b7f49e:	48 8b 8d 08 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xf8]
    71dc01b7f4a5:	48 8d 04 40          	lea    rax,[rax+rax*2]
    71dc01b7f4a9:	48 8d 44 c1 10       	lea    rax,[rcx+rax*8+0x10]
    71dc01b7f4ae:	48 89 85 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rax
    71dc01b7f4b5:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    71dc01b7f4b9:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    71dc01b7f4bd:	48 8b 8d 00 ff ff ff 	mov    rcx,QWORD PTR [rbp-0x100]
    71dc01b7f4c4:	48 8b 09             	mov    rcx,QWORD PTR [rcx]
    71dc01b7f4c7:	48 8b 90 80 00 00 00 	mov    rdx,QWORD PTR [rax+0x80]
    71dc01b7f4ce:	48 8b 52 18          	mov    rdx,QWORD PTR [rdx+0x18]
    71dc01b7f4d2:	48 85 d2             	test   rdx,rdx
    71dc01b7f4d5:	75 4f                	jne    0x71dc01b7f526
    71dc01b7f4d7:	48 8b 80 68 01 00 00 	mov    rax,QWORD PTR [rax+0x168]
    71dc01b7f4de:	48 85 c0             	test   rax,rax
    71dc01b7f4e1:	0f 84 6f f4 ff ff    	je     0x71dc01b7e956
    71dc01b7f4e7:	eb 1b                	jmp    0x71dc01b7f504
    71dc01b7f4e9:	48 8b fe             	mov    rdi,rsi
    71dc01b7f4ec:	41 8b f3             	mov    esi,r11d
    71dc01b7f4ef:	49 bb 38 57 c4 fe db 	movabs r11,0x71dbfec45738
    71dc01b7f4f6:	71 00 00 
    71dc01b7f4f9:	41 ff 13             	call   QWORD PTR [r11]
    71dc01b7f4fc:	48 8b d8             	mov    rbx,rax
    71dc01b7f4ff:	e9 e5 f3 ff ff       	jmp    0x71dc01b7e8e9
    71dc01b7f504:	83 78 20 00          	cmp    DWORD PTR [rax+0x20],0x0
    71dc01b7f508:	0f 84 48 f4 ff ff    	je     0x71dc01b7e956
    71dc01b7f50e:	48 8b f9             	mov    rdi,rcx
    71dc01b7f511:	ff 15 69 55 a6 ff    	call   QWORD PTR [rip+0xffffffffffa65569]        # 0x71dc015e4a80
    71dc01b7f517:	e9 3a f4 ff ff       	jmp    0x71dc01b7e956
    71dc01b7f51c:	90                   	nop
    71dc01b7f51d:	eb 16                	jmp    0x71dc01b7f535
    71dc01b7f51f:	ff 15 8b ff 2f ff    	call   QWORD PTR [rip+0xffffffffff2fff8b]        # 0x71dc00e7f4b0
    71dc01b7f525:	cc                   	int3
    71dc01b7f526:	48 8b fa             	mov    rdi,rdx
    71dc01b7f529:	e8 72 2a 23 7c       	call   0x71dc7ddb1fa0
    71dc01b7f52e:	cc                   	int3
    71dc01b7f52f:	e8 d4 20 2d fe       	call   0x71dbffe51608
    71dc01b7f534:	cc                   	int3
    71dc01b7f535:	e8 f4 00 00 00       	call   0x71dc01b7f62e
    71dc01b7f53a:	90                   	nop
    71dc01b7f53b:	c5 f8 77             	vzeroupper
    71dc01b7f53e:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    71dc01b7f545:	5b                   	pop    rbx
    71dc01b7f546:	41 5c                	pop    r12
    71dc01b7f548:	41 5d                	pop    r13
    71dc01b7f54a:	41 5e                	pop    r14
    71dc01b7f54c:	41 5f                	pop    r15
    71dc01b7f54e:	5d                   	pop    rbp
    71dc01b7f54f:	c3                   	ret
    71dc01b7f550:	48 83 ec 18          	sub    rsp,0x18
    71dc01b7f554:	48 8b df             	mov    rbx,rdi
    71dc01b7f557:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f55e:	ff 15 6c dc 9f ff    	call   QWORD PTR [rip+0xffffffffff9fdc6c]        # 0x71dc0157d1d0
    71dc01b7f564:	48 8b d0             	mov    rdx,rax
    71dc01b7f567:	48 8b f3             	mov    rsi,rbx
    71dc01b7f56a:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7f571:	ff 15 19 5d a6 ff    	call   QWORD PTR [rip+0xffffffffffa65d19]        # 0x71dc015e5290
    71dc01b7f577:	85 c0                	test   eax,eax
    71dc01b7f579:	75 0f                	jne    0x71dc01b7f58a
    71dc01b7f57b:	48 8d 05 9a ff ff ff 	lea    rax,[rip+0xffffffffffffff9a]        # 0x71dc01b7f51c
    71dc01b7f582:	c5 f8 77             	vzeroupper
    71dc01b7f585:	48 83 c4 18          	add    rsp,0x18
    71dc01b7f589:	c3                   	ret
    71dc01b7f58a:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    71dc01b7f591:	48 8d 05 be fe ff ff 	lea    rax,[rip+0xfffffffffffffebe]        # 0x71dc01b7f456
    71dc01b7f598:	c5 f8 77             	vzeroupper
    71dc01b7f59b:	48 83 c4 18          	add    rsp,0x18
    71dc01b7f59f:	c3                   	ret
    71dc01b7f5a0:	48 83 ec 18          	sub    rsp,0x18
    71dc01b7f5a4:	48 8b df             	mov    rbx,rdi
    71dc01b7f5a7:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f5ae:	ff 15 1c dc 9f ff    	call   QWORD PTR [rip+0xffffffffff9fdc1c]        # 0x71dc0157d1d0
    71dc01b7f5b4:	48 8b d0             	mov    rdx,rax
    71dc01b7f5b7:	48 8b f3             	mov    rsi,rbx
    71dc01b7f5ba:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7f5c1:	ff 15 e1 5c a6 ff    	call   QWORD PTR [rip+0xffffffffffa65ce1]        # 0x71dc015e52a8
    71dc01b7f5c7:	85 c0                	test   eax,eax
    71dc01b7f5c9:	75 06                	jne    0x71dc01b7f5d1
    71dc01b7f5cb:	e8 90 2a 23 7c       	call   0x71dc7ddb2060
    71dc01b7f5d0:	cc                   	int3
    71dc01b7f5d1:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    71dc01b7f5d8:	48 8d 05 77 fe ff ff 	lea    rax,[rip+0xfffffffffffffe77]        # 0x71dc01b7f456
    71dc01b7f5df:	c5 f8 77             	vzeroupper
    71dc01b7f5e2:	48 83 c4 18          	add    rsp,0x18
    71dc01b7f5e6:	c3                   	ret
    71dc01b7f5e7:	48 83 ec 18          	sub    rsp,0x18
    71dc01b7f5eb:	48 8b df             	mov    rbx,rdi
    71dc01b7f5ee:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    71dc01b7f5f5:	ff 15 d5 db 9f ff    	call   QWORD PTR [rip+0xffffffffff9fdbd5]        # 0x71dc0157d1d0
    71dc01b7f5fb:	48 8b d0             	mov    rdx,rax
    71dc01b7f5fe:	48 8b f3             	mov    rsi,rbx
    71dc01b7f601:	48 8b bd 10 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf0]
    71dc01b7f608:	ff 15 b2 5c a6 ff    	call   QWORD PTR [rip+0xffffffffffa65cb2]        # 0x71dc015e52c0
    71dc01b7f60e:	85 c0                	test   eax,eax
    71dc01b7f610:	75 06                	jne    0x71dc01b7f618
    71dc01b7f612:	e8 49 2a 23 7c       	call   0x71dc7ddb2060
    71dc01b7f617:	cc                   	int3
    71dc01b7f618:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    71dc01b7f61f:	48 8d 05 30 fe ff ff 	lea    rax,[rip+0xfffffffffffffe30]        # 0x71dc01b7f456
    71dc01b7f626:	c5 f8 77             	vzeroupper
    71dc01b7f629:	48 83 c4 18          	add    rsp,0x18
    71dc01b7f62d:	c3                   	ret
    71dc01b7f62e:	48 83 ec 18          	sub    rsp,0x18
    71dc01b7f632:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01b7f639:	41 80 bd e1 00 00 00 	cmp    BYTE PTR [r13+0xe1],0x0
    71dc01b7f640:	00 
    71dc01b7f641:	75 0e                	jne    0x71dc01b7f651
    71dc01b7f643:	49 83 7d 38 00       	cmp    QWORD PTR [r13+0x38],0x0
    71dc01b7f648:	75 07                	jne    0x71dc01b7f651
    71dc01b7f64a:	49 83 7d 60 00       	cmp    QWORD PTR [r13+0x60],0x0
    71dc01b7f64f:	74 08                	je     0x71dc01b7f659
    71dc01b7f651:	c5 f8 77             	vzeroupper
    71dc01b7f654:	48 83 c4 18          	add    rsp,0x18
    71dc01b7f658:	c3                   	ret
    71dc01b7f659:	33 f6                	xor    esi,esi
    71dc01b7f65b:	49 89 75 68          	mov    QWORD PTR [r13+0x68],rsi
    71dc01b7f65f:	41 8b b5 18 01 00 00 	mov    esi,DWORD PTR [r13+0x118]
    71dc01b7f666:	49 8d bd e8 00 00 00 	lea    rdi,[r13+0xe8]
    71dc01b7f66d:	ff 15 95 5c a6 ff    	call   QWORD PTR [rip+0xffffffffffa65c95]        # 0x71dc015e5308
    71dc01b7f673:	49 81 c5 e8 00 00 00 	add    r13,0xe8
    71dc01b7f67a:	49 8b 7d 00          	mov    rdi,QWORD PTR [r13+0x0]
    71dc01b7f67e:	83 7f 08 00          	cmp    DWORD PTR [rdi+0x8],0x0
    71dc01b7f682:	74 0d                	je     0x71dc01b7f691
    71dc01b7f684:	8b 5f 08             	mov    ebx,DWORD PTR [rdi+0x8]
    71dc01b7f687:	48 c1 e3 04          	shl    rbx,0x4
    71dc01b7f68b:	48 83 c3 20          	add    rbx,0x20
    71dc01b7f68f:	eb 02                	jmp    0x71dc01b7f693
    71dc01b7f691:	33 db                	xor    ebx,ebx
    71dc01b7f693:	49 03 5d 28          	add    rbx,QWORD PTR [r13+0x28]
    71dc01b7f697:	70 37                	jo     0x71dc01b7f6d0
    71dc01b7f699:	48 bf a8 0f 80 21 d4 	movabs rdi,0x71d421800fa8
    71dc01b7f6a0:	71 00 00 
    71dc01b7f6a3:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01b7f6a6:	49 8b fd             	mov    rdi,r13
    71dc01b7f6a9:	e8 92 09 0a fd       	call   0x71dbfec20040
    71dc01b7f6ae:	33 ff                	xor    edi,edi
    71dc01b7f6b0:	49 89 7d 28          	mov    QWORD PTR [r13+0x28],rdi
    71dc01b7f6b4:	49 8b 7d 08          	mov    rdi,QWORD PTR [r13+0x8]
    71dc01b7f6b8:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    71dc01b7f6bc:	48 8b bf 80 00 00 00 	mov    rdi,QWORD PTR [rdi+0x80]
    71dc01b7f6c3:	48 8b f3             	mov    rsi,rbx
    71dc01b7f6c6:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01b7f6c8:	ff 15 9a 71 a6 ff    	call   QWORD PTR [rip+0xffffffffffa6719a]        # 0x71dc015e6868
    71dc01b7f6ce:	eb 81                	jmp    0x71dc01b7f651
    71dc01b7f6d0:	e8 1b 1f 2d fe       	call   0x71dbffe515f0
    71dc01b7f6d5:	cc                   	int3
