
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-8039.bin:     file format binary


Disassembly of section .data:

000071dc01860080 <.data>:
    71dc01860080:	55                   	push   rbp
    71dc01860081:	41 57                	push   r15
    71dc01860083:	41 56                	push   r14
    71dc01860085:	41 55                	push   r13
    71dc01860087:	41 54                	push   r12
    71dc01860089:	53                   	push   rbx
    71dc0186008a:	48 83 ec 78          	sub    rsp,0x78
    71dc0186008e:	48 8d ac 24 a0 00 00 	lea    rbp,[rsp+0xa0]
    71dc01860095:	00 
    71dc01860096:	33 c0                	xor    eax,eax
    71dc01860098:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    71dc0186009c:	48 8b df             	mov    rbx,rdi
    71dc0186009f:	4c 8b f6             	mov    r14,rsi
    71dc018600a2:	44 8b fa             	mov    r15d,edx
    71dc018600a5:	45 33 ed             	xor    r13d,r13d
    71dc018600a8:	45 33 e4             	xor    r12d,r12d
    71dc018600ab:	44 39 7d d0          	cmp    DWORD PTR [rbp-0x30],r15d
    71dc018600af:	0f 8c 4a 03 00 00    	jl     0x71dc018603ff
    71dc018600b5:	4c 8b 63 40          	mov    r12,QWORD PTR [rbx+0x40]
    71dc018600b9:	45 3b ef             	cmp    r13d,r15d
    71dc018600bc:	0f 87 41 0e 00 00    	ja     0x71dc01860f03
    71dc018600c2:	41 8b c5             	mov    eax,r13d
    71dc018600c5:	49 03 c6             	add    rax,r14
    71dc018600c8:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
    71dc018600cf:	41 8b cf             	mov    ecx,r15d
    71dc018600d2:	41 2b cd             	sub    ecx,r13d
    71dc018600d5:	44 8b e9             	mov    r13d,ecx
    71dc018600d8:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc018600dc:	45 85 ed             	test   r13d,r13d
    71dc018600df:	74 55                	je     0x71dc01860136
    71dc018600e1:	49 8b fc             	mov    rdi,r12
    71dc018600e4:	41 8b f5             	mov    esi,r13d
    71dc018600e7:	ff 15 db 52 e8 ff    	call   QWORD PTR [rip+0xffffffffffe852db]        # 0x71dc016e53c8
    71dc018600ed:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
    71dc018600f2:	41 8b 7c 24 28       	mov    edi,DWORD PTR [r12+0x28]
    71dc018600f7:	48 85 d2             	test   rdx,rdx
    71dc018600fa:	0f 84 37 0e 00 00    	je     0x71dc01860f37
    71dc01860100:	39 7a 08             	cmp    DWORD PTR [rdx+0x8],edi
    71dc01860103:	0f 82 fa 0d 00 00    	jb     0x71dc01860f03
    71dc01860109:	8b f7                	mov    esi,edi
    71dc0186010b:	48 8d 74 32 10       	lea    rsi,[rdx+rsi*1+0x10]
    71dc01860110:	8b 52 08             	mov    edx,DWORD PTR [rdx+0x8]
    71dc01860113:	2b d7                	sub    edx,edi
    71dc01860115:	44 3b ea             	cmp    r13d,edx
    71dc01860118:	0f 87 ec 0d 00 00    	ja     0x71dc01860f0a
    71dc0186011e:	41 8b d5             	mov    edx,r13d
    71dc01860121:	48 8b fe             	mov    rdi,rsi
    71dc01860124:	48 8b b5 60 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xa0]
    71dc0186012b:	ff 15 7f 55 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f557f]        # 0x71dbffe556b0
    71dc01860131:	45 01 6c 24 28       	add    DWORD PTR [r12+0x28],r13d
    71dc01860136:	48 8b 7b 10          	mov    rdi,QWORD PTR [rbx+0x10]
    71dc0186013a:	48 8b 43 18          	mov    rax,QWORD PTR [rbx+0x18]
    71dc0186013e:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    71dc01860142:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    71dc01860149:	48 8b 49 18          	mov    rcx,QWORD PTR [rcx+0x18]
    71dc0186014d:	48 85 c9             	test   rcx,rcx
    71dc01860150:	0f 85 ee 0d 00 00    	jne    0x71dc01860f44
    71dc01860156:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    71dc0186015d:	48 85 ff             	test   rdi,rdi
    71dc01860160:	0f 85 e7 0d 00 00    	jne    0x71dc01860f4d
    71dc01860166:	80 7b 5c 00          	cmp    BYTE PTR [rbx+0x5c],0x0
    71dc0186016a:	75 18                	jne    0x71dc01860184
    71dc0186016c:	45 85 ff             	test   r15d,r15d
    71dc0186016f:	0f 84 f0 0d 00 00    	je     0x71dc01860f65
    71dc01860175:	41 8d 7f ff          	lea    edi,[r15-0x1]
    71dc01860179:	41 80 3c 3e 0a       	cmp    BYTE PTR [r14+rdi*1],0xa
    71dc0186017e:	0f 85 30 0e 00 00    	jne    0x71dc01860fb4
    71dc01860184:	c5 f8 77             	vzeroupper
    71dc01860187:	48 83 c4 78          	add    rsp,0x78
    71dc0186018b:	5b                   	pop    rbx
    71dc0186018c:	41 5c                	pop    r12
    71dc0186018e:	41 5d                	pop    r13
    71dc01860190:	41 5e                	pop    r14
    71dc01860192:	41 5f                	pop    r15
    71dc01860194:	5d                   	pop    rbp
    71dc01860195:	c3                   	ret
    71dc01860196:	4c 8b 63 40          	mov    r12,QWORD PTR [rbx+0x40]
    71dc0186019a:	8b 45 d0             	mov    eax,DWORD PTR [rbp-0x30]
    71dc0186019d:	41 2b c5             	sub    eax,r13d
    71dc018601a0:	89 45 c8             	mov    DWORD PTR [rbp-0x38],eax
    71dc018601a3:	41 8b fd             	mov    edi,r13d
    71dc018601a6:	8b f0                	mov    esi,eax
    71dc018601a8:	48 03 fe             	add    rdi,rsi
    71dc018601ab:	41 8b f7             	mov    esi,r15d
    71dc018601ae:	48 3b fe             	cmp    rdi,rsi
    71dc018601b1:	0f 87 4c 0d 00 00    	ja     0x71dc01860f03
    71dc018601b7:	45 8b ed             	mov    r13d,r13d
    71dc018601ba:	4d 03 ee             	add    r13,r14
    71dc018601bd:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc018601c1:	85 c0                	test   eax,eax
    71dc018601c3:	74 55                	je     0x71dc0186021a
    71dc018601c5:	49 8b fc             	mov    rdi,r12
    71dc018601c8:	8b f0                	mov    esi,eax
    71dc018601ca:	ff 15 f8 51 e8 ff    	call   QWORD PTR [rip+0xffffffffffe851f8]        # 0x71dc016e53c8
    71dc018601d0:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
    71dc018601d5:	41 8b 7c 24 28       	mov    edi,DWORD PTR [r12+0x28]
    71dc018601da:	48 85 d2             	test   rdx,rdx
    71dc018601dd:	0f 84 a4 07 00 00    	je     0x71dc01860987
    71dc018601e3:	39 7a 08             	cmp    DWORD PTR [rdx+0x8],edi
    71dc018601e6:	0f 82 17 0d 00 00    	jb     0x71dc01860f03
    71dc018601ec:	8b f7                	mov    esi,edi
    71dc018601ee:	48 8d 74 32 10       	lea    rsi,[rdx+rsi*1+0x10]
    71dc018601f3:	8b 52 08             	mov    edx,DWORD PTR [rdx+0x8]
    71dc018601f6:	2b d7                	sub    edx,edi
    71dc018601f8:	8b 45 c8             	mov    eax,DWORD PTR [rbp-0x38]
    71dc018601fb:	3b c2                	cmp    eax,edx
    71dc018601fd:	0f 87 07 0d 00 00    	ja     0x71dc01860f0a
    71dc01860203:	8b d0                	mov    edx,eax
    71dc01860205:	48 8b fe             	mov    rdi,rsi
    71dc01860208:	49 8b f5             	mov    rsi,r13
    71dc0186020b:	ff 15 9f 54 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f549f]        # 0x71dbffe556b0
    71dc01860211:	44 8b 6d c8          	mov    r13d,DWORD PTR [rbp-0x38]
    71dc01860215:	45 01 6c 24 28       	add    DWORD PTR [r12+0x28],r13d
    71dc0186021a:	44 8b 6d d0          	mov    r13d,DWORD PTR [rbp-0x30]
    71dc0186021e:	48 8b 7b 10          	mov    rdi,QWORD PTR [rbx+0x10]
    71dc01860222:	48 8b 43 18          	mov    rax,QWORD PTR [rbx+0x18]
    71dc01860226:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    71dc0186022a:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    71dc01860231:	48 8b 49 18          	mov    rcx,QWORD PTR [rcx+0x18]
    71dc01860235:	48 85 c9             	test   rcx,rcx
    71dc01860238:	0f 85 d3 0c 00 00    	jne    0x71dc01860f11
    71dc0186023e:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    71dc01860245:	48 85 ff             	test   rdi,rdi
    71dc01860248:	0f 85 4a 07 00 00    	jne    0x71dc01860998
    71dc0186024e:	4c 63 65 d0          	movsxd r12,DWORD PTR [rbp-0x30]
    71dc01860252:	49 81 c4 00 10 00 00 	add    r12,0x1000
    71dc01860259:	e9 ae 01 00 00       	jmp    0x71dc0186040c
    71dc0186025e:	0f b7 3a             	movzx  edi,WORD PTR [rdx]
    71dc01860261:	45 0f b7 08          	movzx  r9d,WORD PTR [r8]
    71dc01860265:	41 2b f9             	sub    edi,r9d
    71dc01860268:	e9 72 02 00 00       	jmp    0x71dc018604df
    71dc0186026d:	48 83 c1 fc          	add    rcx,0xfffffffffffffffc
    71dc01860271:	8b 3a                	mov    edi,DWORD PTR [rdx]
    71dc01860273:	41 2b 38             	sub    edi,DWORD PTR [r8]
    71dc01860276:	8b 14 0a             	mov    edx,DWORD PTR [rdx+rcx*1]
    71dc01860279:	41 2b 14 08          	sub    edx,DWORD PTR [r8+rcx*1]
    71dc0186027d:	0b fa                	or     edi,edx
    71dc0186027f:	40 0f 94 c7          	sete   dil
    71dc01860283:	40 0f b6 ff          	movzx  edi,dil
    71dc01860287:	e9 6f 02 00 00       	jmp    0x71dc018604fb
    71dc0186028c:	48 3b fe             	cmp    rdi,rsi
    71dc0186028f:	0f 84 9b 0a 00 00    	je     0x71dc01860d30
    71dc01860295:	48 83 f9 40          	cmp    rcx,0x40
    71dc01860299:	0f 83 ad 09 00 00    	jae    0x71dc01860c4c
    71dc0186029f:	48 83 f9 20          	cmp    rcx,0x20
    71dc018602a3:	0f 83 ec 09 00 00    	jae    0x71dc01860c95
    71dc018602a9:	48 83 f9 10          	cmp    rcx,0x10
    71dc018602ad:	0f 83 34 0a 00 00    	jae    0x71dc01860ce7
    71dc018602b3:	48 83 c1 f8          	add    rcx,0xfffffffffffffff8
    71dc018602b7:	48 8b 3a             	mov    rdi,QWORD PTR [rdx]
    71dc018602ba:	49 2b 38             	sub    rdi,QWORD PTR [r8]
    71dc018602bd:	48 8b 34 0a          	mov    rsi,QWORD PTR [rdx+rcx*1]
    71dc018602c1:	49 2b 34 08          	sub    rsi,QWORD PTR [r8+rcx*1]
    71dc018602c5:	48 0b fe             	or     rdi,rsi
    71dc018602c8:	40 0f 94 c7          	sete   dil
    71dc018602cc:	40 0f b6 ff          	movzx  edi,dil
    71dc018602d0:	e9 26 02 00 00       	jmp    0x71dc018604fb
    71dc018602d5:	48 8b 43 40          	mov    rax,QWORD PTR [rbx+0x40]
    71dc018602d9:	48 89 45 88          	mov    QWORD PTR [rbp-0x78],rax
    71dc018602dd:	8b 4d d0             	mov    ecx,DWORD PTR [rbp-0x30]
    71dc018602e0:	41 2b cd             	sub    ecx,r13d
    71dc018602e3:	89 4d b0             	mov    DWORD PTR [rbp-0x50],ecx
    71dc018602e6:	41 8b fd             	mov    edi,r13d
    71dc018602e9:	8b f1                	mov    esi,ecx
    71dc018602eb:	48 03 fe             	add    rdi,rsi
    71dc018602ee:	41 8b f7             	mov    esi,r15d
    71dc018602f1:	48 3b fe             	cmp    rdi,rsi
    71dc018602f4:	0f 87 09 0c 00 00    	ja     0x71dc01860f03
    71dc018602fa:	45 8b ed             	mov    r13d,r13d
    71dc018602fd:	4d 03 ee             	add    r13,r14
    71dc01860300:	38 00                	cmp    BYTE PTR [rax],al
    71dc01860302:	85 c9                	test   ecx,ecx
    71dc01860304:	74 58                	je     0x71dc0186035e
    71dc01860306:	48 8b f8             	mov    rdi,rax
    71dc01860309:	8b f1                	mov    esi,ecx
    71dc0186030b:	ff 15 b7 50 e8 ff    	call   QWORD PTR [rip+0xffffffffffe850b7]        # 0x71dc016e53c8
    71dc01860311:	48 8b 45 88          	mov    rax,QWORD PTR [rbp-0x78]
    71dc01860315:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
    71dc01860319:	8b 78 28             	mov    edi,DWORD PTR [rax+0x28]
    71dc0186031c:	48 85 d2             	test   rdx,rdx
    71dc0186031f:	0f 84 23 0a 00 00    	je     0x71dc01860d48
    71dc01860325:	39 7a 08             	cmp    DWORD PTR [rdx+0x8],edi
    71dc01860328:	0f 82 d5 0b 00 00    	jb     0x71dc01860f03
    71dc0186032e:	8b f7                	mov    esi,edi
    71dc01860330:	48 8d 74 32 10       	lea    rsi,[rdx+rsi*1+0x10]
    71dc01860335:	8b 52 08             	mov    edx,DWORD PTR [rdx+0x8]
    71dc01860338:	2b d7                	sub    edx,edi
    71dc0186033a:	8b 4d b0             	mov    ecx,DWORD PTR [rbp-0x50]
    71dc0186033d:	3b ca                	cmp    ecx,edx
    71dc0186033f:	0f 87 c5 0b 00 00    	ja     0x71dc01860f0a
    71dc01860345:	8b d1                	mov    edx,ecx
    71dc01860347:	48 8b fe             	mov    rdi,rsi
    71dc0186034a:	49 8b f5             	mov    rsi,r13
    71dc0186034d:	ff 15 5d 53 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f535d]        # 0x71dbffe556b0
    71dc01860353:	4c 8b 6d 88          	mov    r13,QWORD PTR [rbp-0x78]
    71dc01860357:	8b 7d b0             	mov    edi,DWORD PTR [rbp-0x50]
    71dc0186035a:	41 01 7d 28          	add    DWORD PTR [r13+0x28],edi
    71dc0186035e:	48 8b fb             	mov    rdi,rbx
    71dc01860361:	ff 15 e9 4f e8 ff    	call   QWORD PTR [rip+0xffffffffffe84fe9]        # 0x71dc016e5350
    71dc01860367:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc0186036a:	48 8b 43 20          	mov    rax,QWORD PTR [rbx+0x20]
    71dc0186036e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    71dc01860372:	48 85 c0             	test   rax,rax
    71dc01860375:	0f 84 de 09 00 00    	je     0x71dc01860d59
    71dc0186037b:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    71dc0186037e:	8d 7c 07 ff          	lea    edi,[rdi+rax*1-0x1]
    71dc01860382:	89 7d d0             	mov    DWORD PTR [rbp-0x30],edi
    71dc01860385:	44 8b 6d d0          	mov    r13d,DWORD PTR [rbp-0x30]
    71dc01860389:	41 ff c5             	inc    r13d
    71dc0186038c:	66 c7 43 5f 00 01    	mov    WORD PTR [rbx+0x5f],0x100
    71dc01860392:	eb 59                	jmp    0x71dc018603ed
    71dc01860394:	0f b7 11             	movzx  edx,WORD PTR [rcx]
    71dc01860397:	44 0f b7 06          	movzx  r8d,WORD PTR [rsi]
    71dc0186039b:	41 2b d0             	sub    edx,r8d
    71dc0186039e:	eb 0b                	jmp    0x71dc018603ab
    71dc018603a0:	33 d2                	xor    edx,edx
    71dc018603a2:	48 8b f8             	mov    rdi,rax
    71dc018603a5:	48 83 e7 02          	and    rdi,0x2
    71dc018603a9:	75 e9                	jne    0x71dc01860394
    71dc018603ab:	a8 01                	test   al,0x1
    71dc018603ad:	74 0c                	je     0x71dc018603bb
    71dc018603af:	0f b6 04 39          	movzx  eax,BYTE PTR [rcx+rdi*1]
    71dc018603b3:	0f b6 0c 3e          	movzx  ecx,BYTE PTR [rsi+rdi*1]
    71dc018603b7:	2b c1                	sub    eax,ecx
    71dc018603b9:	0b d0                	or     edx,eax
    71dc018603bb:	85 d2                	test   edx,edx
    71dc018603bd:	40 0f 94 c7          	sete   dil
    71dc018603c1:	40 0f b6 ff          	movzx  edi,dil
    71dc018603c5:	85 ff                	test   edi,edi
    71dc018603c7:	0f 85 4a 02 00 00    	jne    0x71dc01860617
    71dc018603cd:	80 7b 5f 00          	cmp    BYTE PTR [rbx+0x5f],0x0
    71dc018603d1:	0f 85 43 0b 00 00    	jne    0x71dc01860f1a
    71dc018603d7:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc018603da:	48 83 7b 30 00       	cmp    QWORD PTR [rbx+0x30],0x0
    71dc018603df:	0f 85 d9 0a 00 00    	jne    0x71dc01860ebe
    71dc018603e5:	c6 43 5d 01          	mov    BYTE PTR [rbx+0x5d],0x1
    71dc018603e9:	c6 43 60 01          	mov    BYTE PTR [rbx+0x60],0x1
    71dc018603ed:	8b 75 d0             	mov    esi,DWORD PTR [rbp-0x30]
    71dc018603f0:	ff c6                	inc    esi
    71dc018603f2:	89 75 d0             	mov    DWORD PTR [rbp-0x30],esi
    71dc018603f5:	44 39 7d d0          	cmp    DWORD PTR [rbp-0x30],r15d
    71dc018603f9:	0f 8d b6 fc ff ff    	jge    0x71dc018600b5
    71dc018603ff:	48 63 7d d0          	movsxd rdi,DWORD PTR [rbp-0x30]
    71dc01860403:	49 3b fc             	cmp    rdi,r12
    71dc01860406:	0f 8d 8a fd ff ff    	jge    0x71dc01860196
    71dc0186040c:	44 39 7d d0          	cmp    DWORD PTR [rbp-0x30],r15d
    71dc01860410:	0f 83 bd 0b 00 00    	jae    0x71dc01860fd3
    71dc01860416:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860419:	41 0f b6 04 3e       	movzx  eax,BYTE PTR [r14+rdi*1]
    71dc0186041e:	89 45 cc             	mov    DWORD PTR [rbp-0x34],eax
    71dc01860421:	80 7b 5c 00          	cmp    BYTE PTR [rbx+0x5c],0x0
    71dc01860425:	0f 85 cf 02 00 00    	jne    0x71dc018606fa
    71dc0186042b:	83 f8 0a             	cmp    eax,0xa
    71dc0186042e:	0f 84 1e 02 00 00    	je     0x71dc01860652
    71dc01860434:	83 f8 0d             	cmp    eax,0xd
    71dc01860437:	0f 84 92 07 00 00    	je     0x71dc01860bcf
    71dc0186043d:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860440:	48 8b 4b 20          	mov    rcx,QWORD PTR [rbx+0x20]
    71dc01860444:	41 3b ff             	cmp    edi,r15d
    71dc01860447:	0f 87 b6 00 00 00    	ja     0x71dc01860503
    71dc0186044d:	8b d7                	mov    edx,edi
    71dc0186044f:	49 03 d6             	add    rdx,r14
    71dc01860452:	48 89 95 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rdx
    71dc01860459:	41 8b f7             	mov    esi,r15d
    71dc0186045c:	2b f7                	sub    esi,edi
    71dc0186045e:	89 75 b4             	mov    DWORD PTR [rbp-0x4c],esi
    71dc01860461:	48 8b 79 08          	mov    rdi,QWORD PTR [rcx+0x8]
    71dc01860465:	48 85 ff             	test   rdi,rdi
    71dc01860468:	0f 84 b3 07 00 00    	je     0x71dc01860c21
    71dc0186046e:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
    71dc01860471:	45 33 c0             	xor    r8d,r8d
    71dc01860474:	45 33 c9             	xor    r9d,r9d
    71dc01860477:	48 85 ff             	test   rdi,rdi
    71dc0186047a:	74 24                	je     0x71dc018604a0
    71dc0186047c:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    71dc0186047f:	41 f7 00 00 00 00 80 	test   DWORD PTR [r8],0x80000000
    71dc01860486:	0f 84 a4 07 00 00    	je     0x71dc01860c30
    71dc0186048c:	4c 8d 47 10          	lea    r8,[rdi+0x10]
    71dc01860490:	44 8b 4f 08          	mov    r9d,DWORD PTR [rdi+0x8]
    71dc01860494:	41 3b c9             	cmp    ecx,r9d
    71dc01860497:	0f 87 66 0a 00 00    	ja     0x71dc01860f03
    71dc0186049d:	44 8b c9             	mov    r9d,ecx
    71dc018604a0:	8b 75 b4             	mov    esi,DWORD PTR [rbp-0x4c]
    71dc018604a3:	44 3b ce             	cmp    r9d,esi
    71dc018604a6:	0f 8f 95 08 00 00    	jg     0x71dc01860d41
    71dc018604ac:	48 8b 95 70 ff ff ff 	mov    rdx,QWORD PTR [rbp-0x90]
    71dc018604b3:	48 8b fa             	mov    rdi,rdx
    71dc018604b6:	49 8b f0             	mov    rsi,r8
    71dc018604b9:	41 8b c9             	mov    ecx,r9d
    71dc018604bc:	48 83 f9 08          	cmp    rcx,0x8
    71dc018604c0:	0f 83 c6 fd ff ff    	jae    0x71dc0186028c
    71dc018604c6:	48 83 f9 04          	cmp    rcx,0x4
    71dc018604ca:	0f 83 9d fd ff ff    	jae    0x71dc0186026d
    71dc018604d0:	33 ff                	xor    edi,edi
    71dc018604d2:	48 8b f1             	mov    rsi,rcx
    71dc018604d5:	48 83 e6 02          	and    rsi,0x2
    71dc018604d9:	0f 85 7f fd ff ff    	jne    0x71dc0186025e
    71dc018604df:	f6 c1 01             	test   cl,0x1
    71dc018604e2:	74 0d                	je     0x71dc018604f1
    71dc018604e4:	0f b6 0c 32          	movzx  ecx,BYTE PTR [rdx+rsi*1]
    71dc018604e8:	41 0f b6 14 30       	movzx  edx,BYTE PTR [r8+rsi*1]
    71dc018604ed:	2b ca                	sub    ecx,edx
    71dc018604ef:	0b f9                	or     edi,ecx
    71dc018604f1:	85 ff                	test   edi,edi
    71dc018604f3:	40 0f 94 c7          	sete   dil
    71dc018604f7:	40 0f b6 ff          	movzx  edi,dil
    71dc018604fb:	85 ff                	test   edi,edi
    71dc018604fd:	0f 85 d2 fd ff ff    	jne    0x71dc018602d5
    71dc01860503:	48 8b 7b 08          	mov    rdi,QWORD PTR [rbx+0x8]
    71dc01860507:	80 7f 2d 00          	cmp    BYTE PTR [rdi+0x2d],0x0
    71dc0186050b:	0f 85 4f 08 00 00    	jne    0x71dc01860d60
    71dc01860511:	8b 45 d0             	mov    eax,DWORD PTR [rbp-0x30]
    71dc01860514:	83 7f 28 03          	cmp    DWORD PTR [rdi+0x28],0x3
    71dc01860518:	0f 84 af fe ff ff    	je     0x71dc018603cd
    71dc0186051e:	48 8b 7b 28          	mov    rdi,QWORD PTR [rbx+0x28]
    71dc01860522:	48 85 ff             	test   rdi,rdi
    71dc01860525:	0f 84 a2 fe ff ff    	je     0x71dc018603cd
    71dc0186052b:	41 3b c7             	cmp    eax,r15d
    71dc0186052e:	0f 87 7c 09 00 00    	ja     0x71dc01860eb0
    71dc01860534:	8b c8                	mov    ecx,eax
    71dc01860536:	49 03 ce             	add    rcx,r14
    71dc01860539:	48 89 8d 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rcx
    71dc01860540:	41 8b d7             	mov    edx,r15d
    71dc01860543:	2b d0                	sub    edx,eax
    71dc01860545:	89 55 ac             	mov    DWORD PTR [rbp-0x54],edx
    71dc01860548:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc0186054c:	48 85 ff             	test   rdi,rdi
    71dc0186054f:	0f 84 32 08 00 00    	je     0x71dc01860d87
    71dc01860555:	8b 57 08             	mov    edx,DWORD PTR [rdi+0x8]
    71dc01860558:	33 f6                	xor    esi,esi
    71dc0186055a:	45 33 c0             	xor    r8d,r8d
    71dc0186055d:	48 85 ff             	test   rdi,rdi
    71dc01860560:	74 23                	je     0x71dc01860585
    71dc01860562:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01860565:	f7 06 00 00 00 80    	test   DWORD PTR [rsi],0x80000000
    71dc0186056b:	0f 84 25 08 00 00    	je     0x71dc01860d96
    71dc01860571:	48 8d 77 10          	lea    rsi,[rdi+0x10]
    71dc01860575:	44 8b 47 08          	mov    r8d,DWORD PTR [rdi+0x8]
    71dc01860579:	41 3b d0             	cmp    edx,r8d
    71dc0186057c:	0f 87 81 09 00 00    	ja     0x71dc01860f03
    71dc01860582:	44 8b c2             	mov    r8d,edx
    71dc01860585:	8b 45 ac             	mov    eax,DWORD PTR [rbp-0x54]
    71dc01860588:	44 3b c0             	cmp    r8d,eax
    71dc0186058b:	0f 8f 18 09 00 00    	jg     0x71dc01860ea9
    71dc01860591:	48 8b 8d 68 ff ff ff 	mov    rcx,QWORD PTR [rbp-0x98]
    71dc01860598:	48 8b f9             	mov    rdi,rcx
    71dc0186059b:	48 8b d6             	mov    rdx,rsi
    71dc0186059e:	41 8b c0             	mov    eax,r8d
    71dc018605a1:	48 83 f8 08          	cmp    rax,0x8
    71dc018605a5:	73 27                	jae    0x71dc018605ce
    71dc018605a7:	48 83 f8 04          	cmp    rax,0x4
    71dc018605ab:	0f 82 ef fd ff ff    	jb     0x71dc018603a0
    71dc018605b1:	48 83 c0 fc          	add    rax,0xfffffffffffffffc
    71dc018605b5:	8b 39                	mov    edi,DWORD PTR [rcx]
    71dc018605b7:	2b 3e                	sub    edi,DWORD PTR [rsi]
    71dc018605b9:	8b 0c 01             	mov    ecx,DWORD PTR [rcx+rax*1]
    71dc018605bc:	2b 0c 06             	sub    ecx,DWORD PTR [rsi+rax*1]
    71dc018605bf:	0b f9                	or     edi,ecx
    71dc018605c1:	40 0f 94 c7          	sete   dil
    71dc018605c5:	40 0f b6 ff          	movzx  edi,dil
    71dc018605c9:	e9 f7 fd ff ff       	jmp    0x71dc018603c5
    71dc018605ce:	48 3b fa             	cmp    rdi,rdx
    71dc018605d1:	0f 84 c1 08 00 00    	je     0x71dc01860e98
    71dc018605d7:	48 83 f8 40          	cmp    rax,0x40
    71dc018605db:	0f 83 d0 07 00 00    	jae    0x71dc01860db1
    71dc018605e1:	48 83 f8 20          	cmp    rax,0x20
    71dc018605e5:	0f 83 12 08 00 00    	jae    0x71dc01860dfd
    71dc018605eb:	48 83 f8 10          	cmp    rax,0x10
    71dc018605ef:	0f 83 5a 08 00 00    	jae    0x71dc01860e4f
    71dc018605f5:	48 83 c0 f8          	add    rax,0xfffffffffffffff8
    71dc018605f9:	48 8b 39             	mov    rdi,QWORD PTR [rcx]
    71dc018605fc:	48 2b 3e             	sub    rdi,QWORD PTR [rsi]
    71dc018605ff:	48 8b 14 01          	mov    rdx,QWORD PTR [rcx+rax*1]
    71dc01860603:	48 2b 14 06          	sub    rdx,QWORD PTR [rsi+rax*1]
    71dc01860607:	48 0b fa             	or     rdi,rdx
    71dc0186060a:	40 0f 94 c7          	sete   dil
    71dc0186060e:	40 0f b6 ff          	movzx  edi,dil
    71dc01860612:	e9 ae fd ff ff       	jmp    0x71dc018603c5
    71dc01860617:	80 7b 5d 00          	cmp    BYTE PTR [rbx+0x5d],0x0
    71dc0186061b:	0f 85 ac fd ff ff    	jne    0x71dc018603cd
    71dc01860621:	c6 43 5c 01          	mov    BYTE PTR [rbx+0x5c],0x1
    71dc01860625:	66 c7 43 5d 01 01    	mov    WORD PTR [rbx+0x5d],0x101
    71dc0186062b:	c6 43 60 01          	mov    BYTE PTR [rbx+0x60],0x1
    71dc0186062f:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860632:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc01860636:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    71dc0186063a:	48 85 f6             	test   rsi,rsi
    71dc0186063d:	0f 84 74 08 00 00    	je     0x71dc01860eb7
    71dc01860643:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    71dc01860646:	8d 7c 37 ff          	lea    edi,[rdi+rsi*1-0x1]
    71dc0186064a:	89 7d d0             	mov    DWORD PTR [rbp-0x30],edi
    71dc0186064d:	e9 9c 00 00 00       	jmp    0x71dc018606ee
    71dc01860652:	48 8b 4b 40          	mov    rcx,QWORD PTR [rbx+0x40]
    71dc01860656:	48 89 4d 90          	mov    QWORD PTR [rbp-0x70],rcx
    71dc0186065a:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc0186065d:	41 2b d5             	sub    edx,r13d
    71dc01860660:	89 55 b8             	mov    DWORD PTR [rbp-0x48],edx
    71dc01860663:	41 8b fd             	mov    edi,r13d
    71dc01860666:	8b f2                	mov    esi,edx
    71dc01860668:	48 03 fe             	add    rdi,rsi
    71dc0186066b:	41 8b f7             	mov    esi,r15d
    71dc0186066e:	48 3b fe             	cmp    rdi,rsi
    71dc01860671:	0f 87 8c 08 00 00    	ja     0x71dc01860f03
    71dc01860677:	45 8b ed             	mov    r13d,r13d
    71dc0186067a:	4d 03 ee             	add    r13,r14
    71dc0186067d:	38 09                	cmp    BYTE PTR [rcx],cl
    71dc0186067f:	85 d2                	test   edx,edx
    71dc01860681:	74 58                	je     0x71dc018606db
    71dc01860683:	48 8b f9             	mov    rdi,rcx
    71dc01860686:	8b f2                	mov    esi,edx
    71dc01860688:	ff 15 3a 4d e8 ff    	call   QWORD PTR [rip+0xffffffffffe84d3a]        # 0x71dc016e53c8
    71dc0186068e:	48 8b 45 90          	mov    rax,QWORD PTR [rbp-0x70]
    71dc01860692:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
    71dc01860696:	8b 78 28             	mov    edi,DWORD PTR [rax+0x28]
    71dc01860699:	48 85 d2             	test   rdx,rdx
    71dc0186069c:	0f 84 35 05 00 00    	je     0x71dc01860bd7
    71dc018606a2:	39 7a 08             	cmp    DWORD PTR [rdx+0x8],edi
    71dc018606a5:	0f 82 58 08 00 00    	jb     0x71dc01860f03
    71dc018606ab:	8b f7                	mov    esi,edi
    71dc018606ad:	48 8d 74 32 10       	lea    rsi,[rdx+rsi*1+0x10]
    71dc018606b2:	8b 52 08             	mov    edx,DWORD PTR [rdx+0x8]
    71dc018606b5:	2b d7                	sub    edx,edi
    71dc018606b7:	8b 4d b8             	mov    ecx,DWORD PTR [rbp-0x48]
    71dc018606ba:	3b ca                	cmp    ecx,edx
    71dc018606bc:	0f 87 48 08 00 00    	ja     0x71dc01860f0a
    71dc018606c2:	8b d1                	mov    edx,ecx
    71dc018606c4:	48 8b fe             	mov    rdi,rsi
    71dc018606c7:	49 8b f5             	mov    rsi,r13
    71dc018606ca:	ff 15 e0 4f 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f4fe0]        # 0x71dbffe556b0
    71dc018606d0:	4c 8b 6d 90          	mov    r13,QWORD PTR [rbp-0x70]
    71dc018606d4:	8b 7d b8             	mov    edi,DWORD PTR [rbp-0x48]
    71dc018606d7:	41 01 7d 28          	add    DWORD PTR [r13+0x28],edi
    71dc018606db:	48 8b fb             	mov    rdi,rbx
    71dc018606de:	ff 15 54 4c e8 ff    	call   QWORD PTR [rip+0xffffffffffe84c54]        # 0x71dc016e5338
    71dc018606e4:	83 7d cc 0d          	cmp    DWORD PTR [rbp-0x34],0xd
    71dc018606e8:	0f 84 fa 04 00 00    	je     0x71dc01860be8
    71dc018606ee:	44 8b 6d d0          	mov    r13d,DWORD PTR [rbp-0x30]
    71dc018606f2:	41 ff c5             	inc    r13d
    71dc018606f5:	e9 f3 fc ff ff       	jmp    0x71dc018603ed
    71dc018606fa:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc018606fd:	48 83 7b 30 00       	cmp    QWORD PTR [rbx+0x30],0x0
    71dc01860702:	0f 85 a8 02 00 00    	jne    0x71dc018609b0
    71dc01860708:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc0186070b:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc0186070f:	83 78 28 03          	cmp    DWORD PTR [rax+0x28],0x3
    71dc01860713:	0f 84 d4 fc ff ff    	je     0x71dc018603ed
    71dc01860719:	48 8b 43 28          	mov    rax,QWORD PTR [rbx+0x28]
    71dc0186071d:	48 85 c0             	test   rax,rax
    71dc01860720:	0f 84 c7 fc ff ff    	je     0x71dc018603ed
    71dc01860726:	41 3b ff             	cmp    edi,r15d
    71dc01860729:	0f 87 03 04 00 00    	ja     0x71dc01860b32
    71dc0186072f:	8b cf                	mov    ecx,edi
    71dc01860731:	49 03 ce             	add    rcx,r14
    71dc01860734:	48 89 4d 80          	mov    QWORD PTR [rbp-0x80],rcx
    71dc01860738:	41 8b d7             	mov    edx,r15d
    71dc0186073b:	2b d7                	sub    edx,edi
    71dc0186073d:	89 55 c4             	mov    DWORD PTR [rbp-0x3c],edx
    71dc01860740:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc01860744:	48 85 ff             	test   rdi,rdi
    71dc01860747:	0f 84 bf 02 00 00    	je     0x71dc01860a0c
    71dc0186074d:	8b 47 08             	mov    eax,DWORD PTR [rdi+0x8]
    71dc01860750:	33 f6                	xor    esi,esi
    71dc01860752:	45 33 c0             	xor    r8d,r8d
    71dc01860755:	48 85 ff             	test   rdi,rdi
    71dc01860758:	74 23                	je     0x71dc0186077d
    71dc0186075a:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc0186075d:	f7 06 00 00 00 80    	test   DWORD PTR [rsi],0x80000000
    71dc01860763:	0f 84 b2 02 00 00    	je     0x71dc01860a1b
    71dc01860769:	48 8d 77 10          	lea    rsi,[rdi+0x10]
    71dc0186076d:	44 8b 47 08          	mov    r8d,DWORD PTR [rdi+0x8]
    71dc01860771:	41 3b c0             	cmp    eax,r8d
    71dc01860774:	0f 87 89 07 00 00    	ja     0x71dc01860f03
    71dc0186077a:	44 8b c0             	mov    r8d,eax
    71dc0186077d:	8b 55 c4             	mov    edx,DWORD PTR [rbp-0x3c]
    71dc01860780:	44 3b c2             	cmp    r8d,edx
    71dc01860783:	0f 8f a2 03 00 00    	jg     0x71dc01860b2b
    71dc01860789:	48 8b 4d 80          	mov    rcx,QWORD PTR [rbp-0x80]
    71dc0186078d:	48 8b d1             	mov    rdx,rcx
    71dc01860790:	48 8b fe             	mov    rdi,rsi
    71dc01860793:	41 8b c0             	mov    eax,r8d
    71dc01860796:	48 83 f8 08          	cmp    rax,0x8
    71dc0186079a:	0f 83 a0 01 00 00    	jae    0x71dc01860940
    71dc018607a0:	48 83 f8 04          	cmp    rax,0x4
    71dc018607a4:	0f 83 7b 01 00 00    	jae    0x71dc01860925
    71dc018607aa:	33 d2                	xor    edx,edx
    71dc018607ac:	48 8b f8             	mov    rdi,rax
    71dc018607af:	48 83 e7 02          	and    rdi,0x2
    71dc018607b3:	0f 85 5d 01 00 00    	jne    0x71dc01860916
    71dc018607b9:	a8 01                	test   al,0x1
    71dc018607bb:	74 0c                	je     0x71dc018607c9
    71dc018607bd:	0f b6 04 39          	movzx  eax,BYTE PTR [rcx+rdi*1]
    71dc018607c1:	0f b6 0c 3e          	movzx  ecx,BYTE PTR [rsi+rdi*1]
    71dc018607c5:	2b c1                	sub    eax,ecx
    71dc018607c7:	0b d0                	or     edx,eax
    71dc018607c9:	85 d2                	test   edx,edx
    71dc018607cb:	0f 94 c2             	sete   dl
    71dc018607ce:	0f b6 d2             	movzx  edx,dl
    71dc018607d1:	85 d2                	test   edx,edx
    71dc018607d3:	0f 84 14 fc ff ff    	je     0x71dc018603ed
    71dc018607d9:	48 8b 7b 40          	mov    rdi,QWORD PTR [rbx+0x40]
    71dc018607dd:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc018607e0:	41 2b d5             	sub    edx,r13d
    71dc018607e3:	41 8b f5             	mov    esi,r13d
    71dc018607e6:	8b c2                	mov    eax,edx
    71dc018607e8:	48 03 f0             	add    rsi,rax
    71dc018607eb:	41 8b c7             	mov    eax,r15d
    71dc018607ee:	48 3b f0             	cmp    rsi,rax
    71dc018607f1:	0f 87 0c 07 00 00    	ja     0x71dc01860f03
    71dc018607f7:	41 8b f5             	mov    esi,r13d
    71dc018607fa:	49 03 f6             	add    rsi,r14
    71dc018607fd:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc018607ff:	ff 15 a3 4a e8 ff    	call   QWORD PTR [rip+0xffffffffffe84aa3]        # 0x71dc016e52a8
    71dc01860805:	48 8b 7b 28          	mov    rdi,QWORD PTR [rbx+0x28]
    71dc01860809:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc0186080d:	48 85 ff             	test   rdi,rdi
    71dc01860810:	0f 84 23 03 00 00    	je     0x71dc01860b39
    71dc01860816:	44 8b 6f 08          	mov    r13d,DWORD PTR [rdi+0x8]
    71dc0186081a:	33 c0                	xor    eax,eax
    71dc0186081c:	33 c9                	xor    ecx,ecx
    71dc0186081e:	48 85 ff             	test   rdi,rdi
    71dc01860821:	74 30                	je     0x71dc01860853
    71dc01860823:	48 8b 07             	mov    rax,QWORD PTR [rdi]
    71dc01860826:	f7 00 00 00 00 80    	test   DWORD PTR [rax],0x80000000
    71dc0186082c:	0f 84 11 03 00 00    	je     0x71dc01860b43
    71dc01860832:	48 8d 47 10          	lea    rax,[rdi+0x10]
    71dc01860836:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
    71dc01860839:	44 3b e9             	cmp    r13d,ecx
    71dc0186083c:	0f 87 c1 06 00 00    	ja     0x71dc01860f03
    71dc01860842:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    71dc01860849:	41 8b cd             	mov    ecx,r13d
    71dc0186084c:	48 8b 85 78 ff ff ff 	mov    rax,QWORD PTR [rbp-0x88]
    71dc01860853:	48 8b 7b 08          	mov    rdi,QWORD PTR [rbx+0x8]
    71dc01860857:	80 7f 2c 00          	cmp    BYTE PTR [rdi+0x2c],0x0
    71dc0186085b:	0f 84 95 00 00 00    	je     0x71dc018608f6
    71dc01860861:	89 4d c0             	mov    DWORD PTR [rbp-0x40],ecx
    71dc01860864:	8b f9                	mov    edi,ecx
    71dc01860866:	03 7d d0             	add    edi,DWORD PTR [rbp-0x30]
    71dc01860869:	48 8b 53 28          	mov    rdx,QWORD PTR [rbx+0x28]
    71dc0186086d:	41 3b ff             	cmp    edi,r15d
    71dc01860870:	8b 4d c0             	mov    ecx,DWORD PTR [rbp-0x40]
    71dc01860873:	0f 87 7d 00 00 00    	ja     0x71dc018608f6
    71dc01860879:	44 8b ef             	mov    r13d,edi
    71dc0186087c:	4d 03 ee             	add    r13,r14
    71dc0186087f:	41 8b f7             	mov    esi,r15d
    71dc01860882:	2b f7                	sub    esi,edi
    71dc01860884:	89 75 bc             	mov    DWORD PTR [rbp-0x44],esi
    71dc01860887:	48 8b 7a 08          	mov    rdi,QWORD PTR [rdx+0x8]
    71dc0186088b:	48 85 ff             	test   rdi,rdi
    71dc0186088e:	0f 84 c0 02 00 00    	je     0x71dc01860b54
    71dc01860894:	8b 57 08             	mov    edx,DWORD PTR [rdi+0x8]
    71dc01860897:	45 33 c0             	xor    r8d,r8d
    71dc0186089a:	45 33 c9             	xor    r9d,r9d
    71dc0186089d:	48 85 ff             	test   rdi,rdi
    71dc018608a0:	74 24                	je     0x71dc018608c6
    71dc018608a2:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    71dc018608a5:	41 f7 00 00 00 00 80 	test   DWORD PTR [r8],0x80000000
    71dc018608ac:	0f 84 b1 02 00 00    	je     0x71dc01860b63
    71dc018608b2:	4c 8d 47 10          	lea    r8,[rdi+0x10]
    71dc018608b6:	44 8b 4f 08          	mov    r9d,DWORD PTR [rdi+0x8]
    71dc018608ba:	41 3b d1             	cmp    edx,r9d
    71dc018608bd:	0f 87 40 06 00 00    	ja     0x71dc01860f03
    71dc018608c3:	44 8b ca             	mov    r9d,edx
    71dc018608c6:	8b 75 bc             	mov    esi,DWORD PTR [rbp-0x44]
    71dc018608c9:	44 3b ce             	cmp    r9d,esi
    71dc018608cc:	0f 8f c1 02 00 00    	jg     0x71dc01860b93
    71dc018608d2:	89 4d c0             	mov    DWORD PTR [rbp-0x40],ecx
    71dc018608d5:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    71dc018608dc:	41 8b d1             	mov    edx,r9d
    71dc018608df:	49 8b fd             	mov    rdi,r13
    71dc018608e2:	49 8b f0             	mov    rsi,r8
    71dc018608e5:	ff 15 15 bd 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fbd15]        # 0x71dbffe5c600
    71dc018608eb:	8b 4d c0             	mov    ecx,DWORD PTR [rbp-0x40]
    71dc018608ee:	85 c0                	test   eax,eax
    71dc018608f0:	0f 85 ad 02 00 00    	jne    0x71dc01860ba3
    71dc018608f6:	c6 43 5c 00          	mov    BYTE PTR [rbx+0x5c],0x0
    71dc018608fa:	48 8b 73 08          	mov    rsi,QWORD PTR [rbx+0x8]
    71dc018608fe:	40 0f b6 76 2c       	rex movzx esi,BYTE PTR [rsi+0x2c]
    71dc01860903:	40 88 73 5f          	mov    BYTE PTR [rbx+0x5f],sil
    71dc01860907:	8b 75 d0             	mov    esi,DWORD PTR [rbp-0x30]
    71dc0186090a:	8d 74 0e ff          	lea    esi,[rsi+rcx*1-0x1]
    71dc0186090e:	89 75 d0             	mov    DWORD PTR [rbp-0x30],esi
    71dc01860911:	e9 d8 fd ff ff       	jmp    0x71dc018606ee
    71dc01860916:	0f b7 11             	movzx  edx,WORD PTR [rcx]
    71dc01860919:	44 0f b7 06          	movzx  r8d,WORD PTR [rsi]
    71dc0186091d:	41 2b d0             	sub    edx,r8d
    71dc01860920:	e9 94 fe ff ff       	jmp    0x71dc018607b9
    71dc01860925:	48 83 c0 fc          	add    rax,0xfffffffffffffffc
    71dc01860929:	8b 11                	mov    edx,DWORD PTR [rcx]
    71dc0186092b:	2b 16                	sub    edx,DWORD PTR [rsi]
    71dc0186092d:	8b 0c 01             	mov    ecx,DWORD PTR [rcx+rax*1]
    71dc01860930:	2b 0c 06             	sub    ecx,DWORD PTR [rsi+rax*1]
    71dc01860933:	0b d1                	or     edx,ecx
    71dc01860935:	0f 94 c2             	sete   dl
    71dc01860938:	0f b6 d2             	movzx  edx,dl
    71dc0186093b:	e9 91 fe ff ff       	jmp    0x71dc018607d1
    71dc01860940:	48 3b d7             	cmp    rdx,rdi
    71dc01860943:	0f 84 d1 01 00 00    	je     0x71dc01860b1a
    71dc01860949:	48 83 f8 40          	cmp    rax,0x40
    71dc0186094d:	0f 83 e3 00 00 00    	jae    0x71dc01860a36
    71dc01860953:	48 83 f8 20          	cmp    rax,0x20
    71dc01860957:	0f 83 22 01 00 00    	jae    0x71dc01860a7f
    71dc0186095d:	48 83 f8 10          	cmp    rax,0x10
    71dc01860961:	0f 83 6a 01 00 00    	jae    0x71dc01860ad1
    71dc01860967:	48 83 c0 f8          	add    rax,0xfffffffffffffff8
    71dc0186096b:	48 8b 11             	mov    rdx,QWORD PTR [rcx]
    71dc0186096e:	48 2b 16             	sub    rdx,QWORD PTR [rsi]
    71dc01860971:	48 8b 3c 01          	mov    rdi,QWORD PTR [rcx+rax*1]
    71dc01860975:	48 2b 3c 06          	sub    rdi,QWORD PTR [rsi+rax*1]
    71dc01860979:	48 0b d7             	or     rdx,rdi
    71dc0186097c:	0f 94 c2             	sete   dl
    71dc0186097f:	0f b6 d2             	movzx  edx,dl
    71dc01860982:	e9 4a fe ff ff       	jmp    0x71dc018607d1
    71dc01860987:	85 ff                	test   edi,edi
    71dc01860989:	0f 85 74 05 00 00    	jne    0x71dc01860f03
    71dc0186098f:	33 f6                	xor    esi,esi
    71dc01860991:	33 d2                	xor    edx,edx
    71dc01860993:	e9 60 f8 ff ff       	jmp    0x71dc018601f8
    71dc01860998:	83 7f 20 00          	cmp    DWORD PTR [rdi+0x20],0x0
    71dc0186099c:	0f 84 ac f8 ff ff    	je     0x71dc0186024e
    71dc018609a2:	48 8b f8             	mov    rdi,rax
    71dc018609a5:	ff 15 d5 40 d8 ff    	call   QWORD PTR [rip+0xffffffffffd840d5]        # 0x71dc015e4a80
    71dc018609ab:	e9 9e f8 ff ff       	jmp    0x71dc0186024e
    71dc018609b0:	49 8b fe             	mov    rdi,r14
    71dc018609b3:	41 8b f7             	mov    esi,r15d
    71dc018609b6:	48 8b 4b 30          	mov    rcx,QWORD PTR [rbx+0x30]
    71dc018609ba:	ff 15 60 49 e8 ff    	call   QWORD PTR [rip+0xffffffffffe84960]        # 0x71dc016e5320
    71dc018609c0:	85 c0                	test   eax,eax
    71dc018609c2:	0f 84 40 fd ff ff    	je     0x71dc01860708
    71dc018609c8:	48 8b 7b 40          	mov    rdi,QWORD PTR [rbx+0x40]
    71dc018609cc:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc018609cf:	41 2b d5             	sub    edx,r13d
    71dc018609d2:	41 8b f5             	mov    esi,r13d
    71dc018609d5:	8b c2                	mov    eax,edx
    71dc018609d7:	48 03 f0             	add    rsi,rax
    71dc018609da:	41 8b c7             	mov    eax,r15d
    71dc018609dd:	48 3b f0             	cmp    rsi,rax
    71dc018609e0:	0f 87 1d 05 00 00    	ja     0x71dc01860f03
    71dc018609e6:	41 8b f5             	mov    esi,r13d
    71dc018609e9:	49 03 f6             	add    rsi,r14
    71dc018609ec:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc018609ee:	ff 15 b4 48 e8 ff    	call   QWORD PTR [rip+0xffffffffffe848b4]        # 0x71dc016e52a8
    71dc018609f4:	49 8b f6             	mov    rsi,r14
    71dc018609f7:	41 8b d7             	mov    edx,r15d
    71dc018609fa:	48 8d 4d d0          	lea    rcx,[rbp-0x30]
    71dc018609fe:	48 8b fb             	mov    rdi,rbx
    71dc01860a01:	ff 15 d1 48 e8 ff    	call   QWORD PTR [rip+0xffffffffffe848d1]        # 0x71dc016e52d8
    71dc01860a07:	e9 e2 fc ff ff       	jmp    0x71dc018606ee
    71dc01860a0c:	33 ff                	xor    edi,edi
    71dc01860a0e:	33 c0                	xor    eax,eax
    71dc01860a10:	89 45 a8             	mov    DWORD PTR [rbp-0x58],eax
    71dc01860a13:	8b 45 a8             	mov    eax,DWORD PTR [rbp-0x58]
    71dc01860a16:	e9 35 fd ff ff       	jmp    0x71dc01860750
    71dc01860a1b:	89 45 a8             	mov    DWORD PTR [rbp-0x58],eax
    71dc01860a1e:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01860a21:	48 8b 76 40          	mov    rsi,QWORD PTR [rsi+0x40]
    71dc01860a25:	ff 56 28             	call   QWORD PTR [rsi+0x28]
    71dc01860a28:	48 8b f0             	mov    rsi,rax
    71dc01860a2b:	44 8b c2             	mov    r8d,edx
    71dc01860a2e:	8b 45 a8             	mov    eax,DWORD PTR [rbp-0x58]
    71dc01860a31:	e9 3b fd ff ff       	jmp    0x71dc01860771
    71dc01860a36:	33 f6                	xor    esi,esi
    71dc01860a38:	48 83 c0 c0          	add    rax,0xffffffffffffffc0
    71dc01860a3c:	74 23                	je     0x71dc01860a61
    71dc01860a3e:	62 f1 7c 48 10 04 32 	vmovups zmm0,ZMMWORD PTR [rdx+rsi*1]
    71dc01860a45:	62 f3 7d 48 3e 0c 37 	vpcmpnequb k1,zmm0,ZMMWORD PTR [rdi+rsi*1]
    71dc01860a4c:	04 
    71dc01860a4d:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860a52:	0f 85 cc 00 00 00    	jne    0x71dc01860b24
    71dc01860a58:	48 83 c6 40          	add    rsi,0x40
    71dc01860a5c:	48 3b c6             	cmp    rax,rsi
    71dc01860a5f:	77 dd                	ja     0x71dc01860a3e
    71dc01860a61:	62 f1 7c 48 10 04 02 	vmovups zmm0,ZMMWORD PTR [rdx+rax*1]
    71dc01860a68:	62 f1 7d 48 74 0c 07 	vpcmpeqb k1,zmm0,ZMMWORD PTR [rdi+rax*1]
    71dc01860a6f:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860a74:	0f 83 aa 00 00 00    	jae    0x71dc01860b24
    71dc01860a7a:	e9 9b 00 00 00       	jmp    0x71dc01860b1a
    71dc01860a7f:	33 f6                	xor    esi,esi
    71dc01860a81:	48 83 c0 e0          	add    rax,0xffffffffffffffe0
    71dc01860a85:	74 35                	je     0x71dc01860abc
    71dc01860a87:	c5 fc 10 02          	vmovups ymm0,YMMWORD PTR [rdx]
    71dc01860a8b:	62 f3 7d 28 3e 0f 04 	vpcmpnequb k1,ymm0,YMMWORD PTR [rdi]
    71dc01860a92:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860a97:	0f 85 87 00 00 00    	jne    0x71dc01860b24
    71dc01860a9d:	48 83 c6 20          	add    rsi,0x20
    71dc01860aa1:	48 3b c6             	cmp    rax,rsi
    71dc01860aa4:	76 16                	jbe    0x71dc01860abc
    71dc01860aa6:	c5 fc 10 04 32       	vmovups ymm0,YMMWORD PTR [rdx+rsi*1]
    71dc01860aab:	62 f3 7d 28 3e 0c 37 	vpcmpnequb k1,ymm0,YMMWORD PTR [rdi+rsi*1]
    71dc01860ab2:	04 
    71dc01860ab3:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860ab8:	75 6a                	jne    0x71dc01860b24
    71dc01860aba:	eb e1                	jmp    0x71dc01860a9d
    71dc01860abc:	c5 fc 10 04 02       	vmovups ymm0,YMMWORD PTR [rdx+rax*1]
    71dc01860ac1:	62 f1 7d 28 74 0c 07 	vpcmpeqb k1,ymm0,YMMWORD PTR [rdi+rax*1]
    71dc01860ac8:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860acd:	73 55                	jae    0x71dc01860b24
    71dc01860acf:	eb 49                	jmp    0x71dc01860b1a
    71dc01860ad1:	33 f6                	xor    esi,esi
    71dc01860ad3:	48 83 c0 f0          	add    rax,0xfffffffffffffff0
    71dc01860ad7:	74 2f                	je     0x71dc01860b08
    71dc01860ad9:	c5 f8 10 02          	vmovups xmm0,XMMWORD PTR [rdx]
    71dc01860add:	62 f3 7d 08 3e 0f 04 	vpcmpnequb k1,xmm0,XMMWORD PTR [rdi]
    71dc01860ae4:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860ae8:	75 3a                	jne    0x71dc01860b24
    71dc01860aea:	48 83 c6 10          	add    rsi,0x10
    71dc01860aee:	48 3b c6             	cmp    rax,rsi
    71dc01860af1:	76 15                	jbe    0x71dc01860b08
    71dc01860af3:	c5 f8 10 04 32       	vmovups xmm0,XMMWORD PTR [rdx+rsi*1]
    71dc01860af8:	62 f3 7d 08 3e 0c 37 	vpcmpnequb k1,xmm0,XMMWORD PTR [rdi+rsi*1]
    71dc01860aff:	04 
    71dc01860b00:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860b04:	75 1e                	jne    0x71dc01860b24
    71dc01860b06:	eb e2                	jmp    0x71dc01860aea
    71dc01860b08:	c5 f8 10 04 02       	vmovups xmm0,XMMWORD PTR [rdx+rax*1]
    71dc01860b0d:	62 f1 7d 08 74 0c 07 	vpcmpeqb k1,xmm0,XMMWORD PTR [rdi+rax*1]
    71dc01860b14:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860b18:	73 0a                	jae    0x71dc01860b24
    71dc01860b1a:	ba 01 00 00 00       	mov    edx,0x1
    71dc01860b1f:	e9 ad fc ff ff       	jmp    0x71dc018607d1
    71dc01860b24:	33 d2                	xor    edx,edx
    71dc01860b26:	e9 a6 fc ff ff       	jmp    0x71dc018607d1
    71dc01860b2b:	33 d2                	xor    edx,edx
    71dc01860b2d:	e9 9f fc ff ff       	jmp    0x71dc018607d1
    71dc01860b32:	33 d2                	xor    edx,edx
    71dc01860b34:	e9 98 fc ff ff       	jmp    0x71dc018607d1
    71dc01860b39:	33 ff                	xor    edi,edi
    71dc01860b3b:	45 33 ed             	xor    r13d,r13d
    71dc01860b3e:	e9 d7 fc ff ff       	jmp    0x71dc0186081a
    71dc01860b43:	48 8b 07             	mov    rax,QWORD PTR [rdi]
    71dc01860b46:	48 8b 40 40          	mov    rax,QWORD PTR [rax+0x40]
    71dc01860b4a:	ff 50 28             	call   QWORD PTR [rax+0x28]
    71dc01860b4d:	8b ca                	mov    ecx,edx
    71dc01860b4f:	e9 e5 fc ff ff       	jmp    0x71dc01860839
    71dc01860b54:	33 ff                	xor    edi,edi
    71dc01860b56:	33 d2                	xor    edx,edx
    71dc01860b58:	89 55 a4             	mov    DWORD PTR [rbp-0x5c],edx
    71dc01860b5b:	8b 55 a4             	mov    edx,DWORD PTR [rbp-0x5c]
    71dc01860b5e:	e9 34 fd ff ff       	jmp    0x71dc01860897
    71dc01860b63:	89 4d c0             	mov    DWORD PTR [rbp-0x40],ecx
    71dc01860b66:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    71dc01860b6d:	89 55 a4             	mov    DWORD PTR [rbp-0x5c],edx
    71dc01860b70:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    71dc01860b73:	4d 8b 40 40          	mov    r8,QWORD PTR [r8+0x40]
    71dc01860b77:	41 ff 50 28          	call   QWORD PTR [r8+0x28]
    71dc01860b7b:	4c 8b c0             	mov    r8,rax
    71dc01860b7e:	44 8b ca             	mov    r9d,edx
    71dc01860b81:	48 8b 85 78 ff ff ff 	mov    rax,QWORD PTR [rbp-0x88]
    71dc01860b88:	8b 4d c0             	mov    ecx,DWORD PTR [rbp-0x40]
    71dc01860b8b:	8b 55 a4             	mov    edx,DWORD PTR [rbp-0x5c]
    71dc01860b8e:	e9 27 fd ff ff       	jmp    0x71dc018608ba
    71dc01860b93:	33 ff                	xor    edi,edi
    71dc01860b95:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    71dc01860b9c:	8b c7                	mov    eax,edi
    71dc01860b9e:	e9 4b fd ff ff       	jmp    0x71dc018608ee
    71dc01860ba3:	48 8b 7b 40          	mov    rdi,QWORD PTR [rbx+0x40]
    71dc01860ba7:	48 8b b5 78 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x88]
    71dc01860bae:	89 4d c0             	mov    DWORD PTR [rbp-0x40],ecx
    71dc01860bb1:	8b d1                	mov    edx,ecx
    71dc01860bb3:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01860bb5:	ff 15 ed 46 e8 ff    	call   QWORD PTR [rip+0xffffffffffe846ed]        # 0x71dc016e52a8
    71dc01860bbb:	8b 75 d0             	mov    esi,DWORD PTR [rbp-0x30]
    71dc01860bbe:	44 8b 6d c0          	mov    r13d,DWORD PTR [rbp-0x40]
    71dc01860bc2:	42 8d 74 6e ff       	lea    esi,[rsi+r13*2-0x1]
    71dc01860bc7:	89 75 d0             	mov    DWORD PTR [rbp-0x30],esi
    71dc01860bca:	e9 1f fb ff ff       	jmp    0x71dc018606ee
    71dc01860bcf:	8b 45 cc             	mov    eax,DWORD PTR [rbp-0x34]
    71dc01860bd2:	e9 7b fa ff ff       	jmp    0x71dc01860652
    71dc01860bd7:	85 ff                	test   edi,edi
    71dc01860bd9:	0f 85 24 03 00 00    	jne    0x71dc01860f03
    71dc01860bdf:	33 f6                	xor    esi,esi
    71dc01860be1:	33 d2                	xor    edx,edx
    71dc01860be3:	e9 cf fa ff ff       	jmp    0x71dc018606b7
    71dc01860be8:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860beb:	ff c7                	inc    edi
    71dc01860bed:	41 3b ff             	cmp    edi,r15d
    71dc01860bf0:	0f 8d f8 fa ff ff    	jge    0x71dc018606ee
    71dc01860bf6:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860bf9:	ff c7                	inc    edi
    71dc01860bfb:	41 3b ff             	cmp    edi,r15d
    71dc01860bfe:	0f 83 cf 03 00 00    	jae    0x71dc01860fd3
    71dc01860c04:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860c07:	ff c7                	inc    edi
    71dc01860c09:	41 80 3c 3e 0a       	cmp    BYTE PTR [r14+rdi*1],0xa
    71dc01860c0e:	0f 85 da fa ff ff    	jne    0x71dc018606ee
    71dc01860c14:	8b 7d d0             	mov    edi,DWORD PTR [rbp-0x30]
    71dc01860c17:	ff c7                	inc    edi
    71dc01860c19:	89 7d d0             	mov    DWORD PTR [rbp-0x30],edi
    71dc01860c1c:	e9 cd fa ff ff       	jmp    0x71dc018606ee
    71dc01860c21:	33 ff                	xor    edi,edi
    71dc01860c23:	33 c9                	xor    ecx,ecx
    71dc01860c25:	89 4d a0             	mov    DWORD PTR [rbp-0x60],ecx
    71dc01860c28:	8b 4d a0             	mov    ecx,DWORD PTR [rbp-0x60]
    71dc01860c2b:	e9 41 f8 ff ff       	jmp    0x71dc01860471
    71dc01860c30:	89 4d a0             	mov    DWORD PTR [rbp-0x60],ecx
    71dc01860c33:	4c 8b 07             	mov    r8,QWORD PTR [rdi]
    71dc01860c36:	4d 8b 40 40          	mov    r8,QWORD PTR [r8+0x40]
    71dc01860c3a:	41 ff 50 28          	call   QWORD PTR [r8+0x28]
    71dc01860c3e:	4c 8b c0             	mov    r8,rax
    71dc01860c41:	44 8b ca             	mov    r9d,edx
    71dc01860c44:	8b 4d a0             	mov    ecx,DWORD PTR [rbp-0x60]
    71dc01860c47:	e9 48 f8 ff ff       	jmp    0x71dc01860494
    71dc01860c4c:	33 d2                	xor    edx,edx
    71dc01860c4e:	48 83 c1 c0          	add    rcx,0xffffffffffffffc0
    71dc01860c52:	74 23                	je     0x71dc01860c77
    71dc01860c54:	62 f1 7c 48 10 04 17 	vmovups zmm0,ZMMWORD PTR [rdi+rdx*1]
    71dc01860c5b:	62 f3 7d 48 3e 0c 16 	vpcmpnequb k1,zmm0,ZMMWORD PTR [rsi+rdx*1]
    71dc01860c62:	04 
    71dc01860c63:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860c68:	0f 85 cc 00 00 00    	jne    0x71dc01860d3a
    71dc01860c6e:	48 83 c2 40          	add    rdx,0x40
    71dc01860c72:	48 3b ca             	cmp    rcx,rdx
    71dc01860c75:	77 dd                	ja     0x71dc01860c54
    71dc01860c77:	62 f1 7c 48 10 04 0f 	vmovups zmm0,ZMMWORD PTR [rdi+rcx*1]
    71dc01860c7e:	62 f1 7d 48 74 0c 0e 	vpcmpeqb k1,zmm0,ZMMWORD PTR [rsi+rcx*1]
    71dc01860c85:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860c8a:	0f 83 aa 00 00 00    	jae    0x71dc01860d3a
    71dc01860c90:	e9 9b 00 00 00       	jmp    0x71dc01860d30
    71dc01860c95:	33 d2                	xor    edx,edx
    71dc01860c97:	48 83 c1 e0          	add    rcx,0xffffffffffffffe0
    71dc01860c9b:	74 35                	je     0x71dc01860cd2
    71dc01860c9d:	c5 fc 10 07          	vmovups ymm0,YMMWORD PTR [rdi]
    71dc01860ca1:	62 f3 7d 28 3e 0e 04 	vpcmpnequb k1,ymm0,YMMWORD PTR [rsi]
    71dc01860ca8:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860cad:	0f 85 87 00 00 00    	jne    0x71dc01860d3a
    71dc01860cb3:	48 83 c2 20          	add    rdx,0x20
    71dc01860cb7:	48 3b ca             	cmp    rcx,rdx
    71dc01860cba:	76 16                	jbe    0x71dc01860cd2
    71dc01860cbc:	c5 fc 10 04 17       	vmovups ymm0,YMMWORD PTR [rdi+rdx*1]
    71dc01860cc1:	62 f3 7d 28 3e 0c 16 	vpcmpnequb k1,ymm0,YMMWORD PTR [rsi+rdx*1]
    71dc01860cc8:	04 
    71dc01860cc9:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860cce:	75 6a                	jne    0x71dc01860d3a
    71dc01860cd0:	eb e1                	jmp    0x71dc01860cb3
    71dc01860cd2:	c5 fc 10 04 0f       	vmovups ymm0,YMMWORD PTR [rdi+rcx*1]
    71dc01860cd7:	62 f1 7d 28 74 0c 0e 	vpcmpeqb k1,ymm0,YMMWORD PTR [rsi+rcx*1]
    71dc01860cde:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860ce3:	73 55                	jae    0x71dc01860d3a
    71dc01860ce5:	eb 49                	jmp    0x71dc01860d30
    71dc01860ce7:	33 d2                	xor    edx,edx
    71dc01860ce9:	48 83 c1 f0          	add    rcx,0xfffffffffffffff0
    71dc01860ced:	74 2f                	je     0x71dc01860d1e
    71dc01860cef:	c5 f8 10 07          	vmovups xmm0,XMMWORD PTR [rdi]
    71dc01860cf3:	62 f3 7d 08 3e 0e 04 	vpcmpnequb k1,xmm0,XMMWORD PTR [rsi]
    71dc01860cfa:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860cfe:	75 3a                	jne    0x71dc01860d3a
    71dc01860d00:	48 83 c2 10          	add    rdx,0x10
    71dc01860d04:	48 3b ca             	cmp    rcx,rdx
    71dc01860d07:	76 15                	jbe    0x71dc01860d1e
    71dc01860d09:	c5 f8 10 04 17       	vmovups xmm0,XMMWORD PTR [rdi+rdx*1]
    71dc01860d0e:	62 f3 7d 08 3e 0c 16 	vpcmpnequb k1,xmm0,XMMWORD PTR [rsi+rdx*1]
    71dc01860d15:	04 
    71dc01860d16:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860d1a:	75 1e                	jne    0x71dc01860d3a
    71dc01860d1c:	eb e2                	jmp    0x71dc01860d00
    71dc01860d1e:	c5 f8 10 04 0f       	vmovups xmm0,XMMWORD PTR [rdi+rcx*1]
    71dc01860d23:	62 f1 7d 08 74 0c 0e 	vpcmpeqb k1,xmm0,XMMWORD PTR [rsi+rcx*1]
    71dc01860d2a:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860d2e:	73 0a                	jae    0x71dc01860d3a
    71dc01860d30:	bf 01 00 00 00       	mov    edi,0x1
    71dc01860d35:	e9 c1 f7 ff ff       	jmp    0x71dc018604fb
    71dc01860d3a:	33 ff                	xor    edi,edi
    71dc01860d3c:	e9 ba f7 ff ff       	jmp    0x71dc018604fb
    71dc01860d41:	33 ff                	xor    edi,edi
    71dc01860d43:	e9 b3 f7 ff ff       	jmp    0x71dc018604fb
    71dc01860d48:	85 ff                	test   edi,edi
    71dc01860d4a:	0f 85 b3 01 00 00    	jne    0x71dc01860f03
    71dc01860d50:	33 f6                	xor    esi,esi
    71dc01860d52:	33 d2                	xor    edx,edx
    71dc01860d54:	e9 e1 f5 ff ff       	jmp    0x71dc0186033a
    71dc01860d59:	33 c0                	xor    eax,eax
    71dc01860d5b:	e9 1e f6 ff ff       	jmp    0x71dc0186037e
    71dc01860d60:	80 7b 5d 00          	cmp    BYTE PTR [rbx+0x5d],0x0
    71dc01860d64:	0f 85 a7 f7 ff ff    	jne    0x71dc01860511
    71dc01860d6a:	48 8b 4b 40          	mov    rcx,QWORD PTR [rbx+0x40]
    71dc01860d6e:	83 79 28 00          	cmp    DWORD PTR [rcx+0x28],0x0
    71dc01860d72:	0f 85 99 f7 ff ff    	jne    0x71dc01860511
    71dc01860d78:	83 7d cc 20          	cmp    DWORD PTR [rbp-0x34],0x20
    71dc01860d7c:	0f 85 8f f7 ff ff    	jne    0x71dc01860511
    71dc01860d82:	e9 67 f9 ff ff       	jmp    0x71dc018606ee
    71dc01860d87:	33 ff                	xor    edi,edi
    71dc01860d89:	33 d2                	xor    edx,edx
    71dc01860d8b:	89 55 9c             	mov    DWORD PTR [rbp-0x64],edx
    71dc01860d8e:	8b 55 9c             	mov    edx,DWORD PTR [rbp-0x64]
    71dc01860d91:	e9 c2 f7 ff ff       	jmp    0x71dc01860558
    71dc01860d96:	89 55 9c             	mov    DWORD PTR [rbp-0x64],edx
    71dc01860d99:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01860d9c:	48 8b 76 40          	mov    rsi,QWORD PTR [rsi+0x40]
    71dc01860da0:	ff 56 28             	call   QWORD PTR [rsi+0x28]
    71dc01860da3:	48 8b f0             	mov    rsi,rax
    71dc01860da6:	44 8b c2             	mov    r8d,edx
    71dc01860da9:	8b 55 9c             	mov    edx,DWORD PTR [rbp-0x64]
    71dc01860dac:	e9 c8 f7 ff ff       	jmp    0x71dc01860579
    71dc01860db1:	33 f6                	xor    esi,esi
    71dc01860db3:	48 8d 48 c0          	lea    rcx,[rax-0x40]
    71dc01860db7:	48 85 c9             	test   rcx,rcx
    71dc01860dba:	74 23                	je     0x71dc01860ddf
    71dc01860dbc:	62 f1 7c 48 10 04 37 	vmovups zmm0,ZMMWORD PTR [rdi+rsi*1]
    71dc01860dc3:	62 f3 7d 48 3e 0c 32 	vpcmpnequb k1,zmm0,ZMMWORD PTR [rdx+rsi*1]
    71dc01860dca:	04 
    71dc01860dcb:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860dd0:	0f 85 cc 00 00 00    	jne    0x71dc01860ea2
    71dc01860dd6:	48 83 c6 40          	add    rsi,0x40
    71dc01860dda:	48 3b ce             	cmp    rcx,rsi
    71dc01860ddd:	77 dd                	ja     0x71dc01860dbc
    71dc01860ddf:	62 f1 7c 48 10 04 0f 	vmovups zmm0,ZMMWORD PTR [rdi+rcx*1]
    71dc01860de6:	62 f1 7d 48 74 0c 0a 	vpcmpeqb k1,zmm0,ZMMWORD PTR [rdx+rcx*1]
    71dc01860ded:	c4 e1 f8 98 c9       	kortestq k1,k1
    71dc01860df2:	0f 83 aa 00 00 00    	jae    0x71dc01860ea2
    71dc01860df8:	e9 9b 00 00 00       	jmp    0x71dc01860e98
    71dc01860dfd:	33 f6                	xor    esi,esi
    71dc01860dff:	48 83 c0 e0          	add    rax,0xffffffffffffffe0
    71dc01860e03:	74 35                	je     0x71dc01860e3a
    71dc01860e05:	c5 fc 10 07          	vmovups ymm0,YMMWORD PTR [rdi]
    71dc01860e09:	62 f3 7d 28 3e 0a 04 	vpcmpnequb k1,ymm0,YMMWORD PTR [rdx]
    71dc01860e10:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860e15:	0f 85 87 00 00 00    	jne    0x71dc01860ea2
    71dc01860e1b:	48 83 c6 20          	add    rsi,0x20
    71dc01860e1f:	48 3b c6             	cmp    rax,rsi
    71dc01860e22:	76 16                	jbe    0x71dc01860e3a
    71dc01860e24:	c5 fc 10 04 37       	vmovups ymm0,YMMWORD PTR [rdi+rsi*1]
    71dc01860e29:	62 f3 7d 28 3e 0c 32 	vpcmpnequb k1,ymm0,YMMWORD PTR [rdx+rsi*1]
    71dc01860e30:	04 
    71dc01860e31:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860e36:	75 6a                	jne    0x71dc01860ea2
    71dc01860e38:	eb e1                	jmp    0x71dc01860e1b
    71dc01860e3a:	c5 fc 10 04 07       	vmovups ymm0,YMMWORD PTR [rdi+rax*1]
    71dc01860e3f:	62 f1 7d 28 74 0c 02 	vpcmpeqb k1,ymm0,YMMWORD PTR [rdx+rax*1]
    71dc01860e46:	c4 e1 f9 98 c9       	kortestd k1,k1
    71dc01860e4b:	73 55                	jae    0x71dc01860ea2
    71dc01860e4d:	eb 49                	jmp    0x71dc01860e98
    71dc01860e4f:	33 f6                	xor    esi,esi
    71dc01860e51:	48 83 c0 f0          	add    rax,0xfffffffffffffff0
    71dc01860e55:	74 2f                	je     0x71dc01860e86
    71dc01860e57:	c5 f8 10 07          	vmovups xmm0,XMMWORD PTR [rdi]
    71dc01860e5b:	62 f3 7d 08 3e 0a 04 	vpcmpnequb k1,xmm0,XMMWORD PTR [rdx]
    71dc01860e62:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860e66:	75 3a                	jne    0x71dc01860ea2
    71dc01860e68:	48 83 c6 10          	add    rsi,0x10
    71dc01860e6c:	48 3b c6             	cmp    rax,rsi
    71dc01860e6f:	76 15                	jbe    0x71dc01860e86
    71dc01860e71:	c5 f8 10 04 37       	vmovups xmm0,XMMWORD PTR [rdi+rsi*1]
    71dc01860e76:	62 f3 7d 08 3e 0c 32 	vpcmpnequb k1,xmm0,XMMWORD PTR [rdx+rsi*1]
    71dc01860e7d:	04 
    71dc01860e7e:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860e82:	75 1e                	jne    0x71dc01860ea2
    71dc01860e84:	eb e2                	jmp    0x71dc01860e68
    71dc01860e86:	c5 f8 10 04 07       	vmovups xmm0,XMMWORD PTR [rdi+rax*1]
    71dc01860e8b:	62 f1 7d 08 74 0c 02 	vpcmpeqb k1,xmm0,XMMWORD PTR [rdx+rax*1]
    71dc01860e92:	c5 f8 98 c9          	kortestw k1,k1
    71dc01860e96:	73 0a                	jae    0x71dc01860ea2
    71dc01860e98:	bf 01 00 00 00       	mov    edi,0x1
    71dc01860e9d:	e9 23 f5 ff ff       	jmp    0x71dc018603c5
    71dc01860ea2:	33 ff                	xor    edi,edi
    71dc01860ea4:	e9 1c f5 ff ff       	jmp    0x71dc018603c5
    71dc01860ea9:	33 ff                	xor    edi,edi
    71dc01860eab:	e9 15 f5 ff ff       	jmp    0x71dc018603c5
    71dc01860eb0:	33 ff                	xor    edi,edi
    71dc01860eb2:	e9 0e f5 ff ff       	jmp    0x71dc018603c5
    71dc01860eb7:	33 f6                	xor    esi,esi
    71dc01860eb9:	e9 88 f7 ff ff       	jmp    0x71dc01860646
    71dc01860ebe:	49 8b fe             	mov    rdi,r14
    71dc01860ec1:	41 8b f7             	mov    esi,r15d
    71dc01860ec4:	48 8b 4b 30          	mov    rcx,QWORD PTR [rbx+0x30]
    71dc01860ec8:	ff 15 52 44 e8 ff    	call   QWORD PTR [rip+0xffffffffffe84452]        # 0x71dc016e5320
    71dc01860ece:	85 c0                	test   eax,eax
    71dc01860ed0:	0f 84 0f f5 ff ff    	je     0x71dc018603e5
    71dc01860ed6:	48 8b 7b 40          	mov    rdi,QWORD PTR [rbx+0x40]
    71dc01860eda:	8b 55 d0             	mov    edx,DWORD PTR [rbp-0x30]
    71dc01860edd:	41 2b d5             	sub    edx,r13d
    71dc01860ee0:	41 8b f5             	mov    esi,r13d
    71dc01860ee3:	8b c2                	mov    eax,edx
    71dc01860ee5:	48 03 f0             	add    rsi,rax
    71dc01860ee8:	41 8b c7             	mov    eax,r15d
    71dc01860eeb:	48 3b f0             	cmp    rsi,rax
    71dc01860eee:	77 13                	ja     0x71dc01860f03
    71dc01860ef0:	41 8b f5             	mov    esi,r13d
    71dc01860ef3:	49 03 f6             	add    rsi,r14
    71dc01860ef6:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01860ef8:	ff 15 aa 43 e8 ff    	call   QWORD PTR [rip+0xffffffffffe843aa]        # 0x71dc016e52a8
    71dc01860efe:	e9 f1 fa ff ff       	jmp    0x71dc018609f4
    71dc01860f03:	ff 15 57 43 d1 ff    	call   QWORD PTR [rip+0xffffffffffd14357]        # 0x71dc01575260
    71dc01860f09:	cc                   	int3
    71dc01860f0a:	ff 15 68 3d f8 ff    	call   QWORD PTR [rip+0xfffffffffff83d68]        # 0x71dc017e4c78
    71dc01860f10:	cc                   	int3
    71dc01860f11:	48 8b f9             	mov    rdi,rcx
    71dc01860f14:	e8 87 10 55 7c       	call   0x71dc7ddb1fa0
    71dc01860f19:	cc                   	int3
    71dc01860f1a:	48 8b 73 18          	mov    rsi,QWORD PTR [rbx+0x18]
    71dc01860f1e:	48 bf 98 a9 65 fc db 	movabs rdi,0x71dbfc65a998
    71dc01860f25:	71 00 00 
    71dc01860f28:	ff 15 6a 44 e8 ff    	call   QWORD PTR [rip+0xffffffffffe8446a]        # 0x71dc016e5398
    71dc01860f2e:	48 8b f8             	mov    rdi,rax
    71dc01860f31:	e8 6a 10 55 7c       	call   0x71dc7ddb1fa0
    71dc01860f36:	cc                   	int3
    71dc01860f37:	85 ff                	test   edi,edi
    71dc01860f39:	75 c8                	jne    0x71dc01860f03
    71dc01860f3b:	33 f6                	xor    esi,esi
    71dc01860f3d:	33 d2                	xor    edx,edx
    71dc01860f3f:	e9 d1 f1 ff ff       	jmp    0x71dc01860115
    71dc01860f44:	48 8b f9             	mov    rdi,rcx
    71dc01860f47:	e8 54 10 55 7c       	call   0x71dc7ddb1fa0
    71dc01860f4c:	cc                   	int3
    71dc01860f4d:	83 7f 20 00          	cmp    DWORD PTR [rdi+0x20],0x0
    71dc01860f51:	0f 84 0f f2 ff ff    	je     0x71dc01860166
    71dc01860f57:	48 8b f8             	mov    rdi,rax
    71dc01860f5a:	ff 15 20 3b d8 ff    	call   QWORD PTR [rip+0xffffffffffd83b20]        # 0x71dc015e4a80
    71dc01860f60:	e9 01 f2 ff ff       	jmp    0x71dc01860166
    71dc01860f65:	48 bf a8 0f 80 21 d4 	movabs rdi,0x71d421800fa8
    71dc01860f6c:	71 00 00 
    71dc01860f6f:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    71dc01860f72:	48 8b 7b 10          	mov    rdi,QWORD PTR [rbx+0x10]
    71dc01860f76:	4c 8b 77 30          	mov    r14,QWORD PTR [rdi+0x30]
    71dc01860f7a:	48 bf 80 eb 60 01 dc 	movabs rdi,0x71dc0160eb80
    71dc01860f81:	71 00 00 
    71dc01860f84:	e8 37 03 7f 7c       	call   0x71dc7e0512c0
    71dc01860f89:	4c 8b e8             	mov    r13,rax
    71dc01860f8c:	49 8b 96 80 00 00 00 	mov    rdx,QWORD PTR [r14+0x80]
    71dc01860f93:	48 8b 4b 18          	mov    rcx,QWORD PTR [rbx+0x18]
    71dc01860f97:	49 8b fd             	mov    rdi,r13
    71dc01860f9a:	49 8b f7             	mov    rsi,r15
    71dc01860f9d:	ff 15 45 dd d8 ff    	call   QWORD PTR [rip+0xffffffffffd8dd45]        # 0x71dc015eece8
    71dc01860fa3:	48 8b fb             	mov    rdi,rbx
    71dc01860fa6:	49 8b f5             	mov    rsi,r13
    71dc01860fa9:	ff 15 01 44 e8 ff    	call   QWORD PTR [rip+0xffffffffffe84401]        # 0x71dc016e53b0
    71dc01860faf:	e9 d0 f1 ff ff       	jmp    0x71dc01860184
    71dc01860fb4:	41 ff cf             	dec    r15d
    71dc01860fb7:	41 8b ff             	mov    edi,r15d
    71dc01860fba:	41 80 3c 3e 0d       	cmp    BYTE PTR [r14+rdi*1],0xd
    71dc01860fbf:	0f 84 bf f1 ff ff    	je     0x71dc01860184
    71dc01860fc5:	48 8b fb             	mov    rdi,rbx
    71dc01860fc8:	ff 15 6a 43 e8 ff    	call   QWORD PTR [rip+0xffffffffffe8436a]        # 0x71dc016e5338
    71dc01860fce:	e9 b1 f1 ff ff       	jmp    0x71dc01860184
    71dc01860fd3:	e8 30 06 5f fe       	call   0x71dbffe51608
    71dc01860fd8:	cc                   	int3
