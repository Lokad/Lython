
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-8099.bin:     file format binary


Disassembly of section .data:

000071dc01866880 <.data>:
    71dc01866880:	55                   	push   rbp
    71dc01866881:	41 57                	push   r15
    71dc01866883:	41 56                	push   r14
    71dc01866885:	41 55                	push   r13
    71dc01866887:	41 54                	push   r12
    71dc01866889:	53                   	push   rbx
    71dc0186688a:	48 81 ec d8 02 00 00 	sub    rsp,0x2d8
    71dc01866891:	48 8d ac 24 00 03 00 	lea    rbp,[rsp+0x300]
    71dc01866898:	00 
    71dc01866899:	33 c0                	xor    eax,eax
    71dc0186689b:	48 89 85 68 fd ff ff 	mov    QWORD PTR [rbp-0x298],rax
    71dc018668a2:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    71dc018668a7:	62 71 7d 08 7f 45 d7 	vmovdqa32 XMMWORD PTR [rbp-0x290],xmm8
    71dc018668ae:	62 71 7d 08 7f 45 d8 	vmovdqa32 XMMWORD PTR [rbp-0x280],xmm8
    71dc018668b5:	48 b8 c0 fd ff ff ff 	movabs rax,0xfffffffffffffdc0
    71dc018668bc:	ff ff ff 
    71dc018668bf:	c5 79 7f 44 05 d0    	vmovdqa XMMWORD PTR [rbp+rax*1-0x30],xmm8
    71dc018668c5:	c5 79 7f 44 05 e0    	vmovdqa XMMWORD PTR [rbp+rax*1-0x20],xmm8
    71dc018668cb:	c5 79 7f 44 05 f0    	vmovdqa XMMWORD PTR [rbp+rax*1-0x10],xmm8
    71dc018668d1:	48 83 c0 30          	add    rax,0x30
    71dc018668d5:	75 e8                	jne    0x71dc018668bf
    71dc018668d7:	48 89 bd b8 fd ff ff 	mov    QWORD PTR [rbp-0x248],rdi
    71dc018668de:	8b 47 28             	mov    eax,DWORD PTR [rdi+0x28]
    71dc018668e1:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    71dc018668e4:	48 8b 1f             	mov    rbx,QWORD PTR [rdi]
    71dc018668e7:	48 89 9d b0 fd ff ff 	mov    QWORD PTR [rbp-0x250],rbx
    71dc018668ee:	83 7d d4 0d          	cmp    DWORD PTR [rbp-0x2c],0xd
    71dc018668f2:	0f 86 fb 0e 00 00    	jbe    0x71dc018677f3
    71dc018668f8:	80 7f 34 00          	cmp    BYTE PTR [rdi+0x34],0x0
    71dc018668fc:	0f 85 ad 0f 00 00    	jne    0x71dc018678af
    71dc01866902:	4c 8b 7b 40          	mov    r15,QWORD PTR [rbx+0x40]
    71dc01866906:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc0186690d:	71 00 00 
    71dc01866910:	e8 ab a9 7e 7c       	call   0x71dc7e0512c0
    71dc01866915:	4c 8b f0             	mov    r14,rax
    71dc01866918:	48 bf 60 3d 80 21 d4 	movabs rdi,0x71d421803d60
    71dc0186691f:	71 00 00 
    71dc01866922:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    71dc01866925:	49 83 c5 08          	add    r13,0x8
    71dc01866929:	4d 8d 66 08          	lea    r12,[r14+0x8]
    71dc0186692d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
    71dc01866931:	49 8b fc             	mov    rdi,r12
    71dc01866934:	e8 07 97 3b fd       	call   0x71dbfec20040
    71dc01866939:	49 8b 75 08          	mov    rsi,QWORD PTR [r13+0x8]
    71dc0186693d:	49 89 74 24 08       	mov    QWORD PTR [r12+0x8],rsi
    71dc01866942:	4c 8b 6b 20          	mov    r13,QWORD PTR [rbx+0x20]
    71dc01866946:	4c 8b 63 28          	mov    r12,QWORD PTR [rbx+0x28]
    71dc0186694a:	48 8d b5 58 fe ff ff 	lea    rsi,[rbp-0x1a8]
    71dc01866951:	bf 0f 00 00 00       	mov    edi,0xf
    71dc01866956:	ff 15 94 93 d8 ff    	call   QWORD PTR [rip+0xffffffffffd89394]        # 0x71dc015efcf0
    71dc0186695c:	85 c0                	test   eax,eax
    71dc0186695e:	0f 85 02 11 00 00    	jne    0x71dc01867a66
    71dc01866964:	48 b8 c0 1a 80 21 d4 	movabs rax,0x71d421801ac0
    71dc0186696b:	71 00 00 
    71dc0186696e:	48 8b 00             	mov    rax,QWORD PTR [rax]
    71dc01866971:	33 ff                	xor    edi,edi
    71dc01866973:	33 f6                	xor    esi,esi
    71dc01866975:	48 89 b5 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rsi
    71dc0186697c:	48 89 b5 48 fe ff ff 	mov    QWORD PTR [rbp-0x1b8],rsi
    71dc01866983:	48 89 b5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rsi
    71dc0186698a:	85 ff                	test   edi,edi
    71dc0186698c:	0f 85 fd 11 00 00    	jne    0x71dc01867b8f
    71dc01866992:	49 8b ff             	mov    rdi,r15
    71dc01866995:	49 8b f6             	mov    rsi,r14
    71dc01866998:	49 8b d5             	mov    rdx,r13
    71dc0186699b:	49 8b cc             	mov    rcx,r12
    71dc0186699e:	ff 15 bc 92 d8 ff    	call   QWORD PTR [rip+0xffffffffffd892bc]        # 0x71dc015efc60
    71dc018669a4:	4c 8b f8             	mov    r15,rax
    71dc018669a7:	48 8b bd b8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x248]
    71dc018669ae:	80 7f 34 00          	cmp    BYTE PTR [rdi+0x34],0x0
    71dc018669b2:	0f 85 df 11 00 00    	jne    0x71dc01867b97
    71dc018669b8:	4c 8b 73 20          	mov    r14,QWORD PTR [rbx+0x20]
    71dc018669bc:	4c 8b 6b 28          	mov    r13,QWORD PTR [rbx+0x28]
    71dc018669c0:	4d 85 ff             	test   r15,r15
    71dc018669c3:	0f 85 43 0e 00 00    	jne    0x71dc0186780c
    71dc018669c9:	49 8b ff             	mov    rdi,r15
    71dc018669cc:	ff 15 ae dd e7 ff    	call   QWORD PTR [rip+0xffffffffffe7ddae]        # 0x71dc016e4780
    71dc018669d2:	33 d2                	xor    edx,edx
    71dc018669d4:	48 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],rdx
    71dc018669db:	85 c0                	test   eax,eax
    71dc018669dd:	0f 85 0c 13 00 00    	jne    0x71dc01867cef
    71dc018669e3:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc018669ea:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc018669ef:	0f 85 6c 14 00 00    	jne    0x71dc01867e61
    71dc018669f5:	4c 8b 73 30          	mov    r14,QWORD PTR [rbx+0x30]
    71dc018669f9:	4d 8b 6e 08          	mov    r13,QWORD PTR [r14+0x8]
    71dc018669fd:	41 8b 7d 58          	mov    edi,DWORD PTR [r13+0x58]
    71dc01866a01:	49 8b 45 50          	mov    rax,QWORD PTR [r13+0x50]
    71dc01866a05:	3b 78 10             	cmp    edi,DWORD PTR [rax+0x10]
    71dc01866a08:	7c 39                	jl     0x71dc01866a43
    71dc01866a0a:	49 8b 7d 48          	mov    rdi,QWORD PTR [r13+0x48]
    71dc01866a0e:	80 7f 38 00          	cmp    BYTE PTR [rdi+0x38],0x0
    71dc01866a12:	0f 85 f6 15 00 00    	jne    0x71dc0186800e
    71dc01866a18:	33 ff                	xor    edi,edi
    71dc01866a1a:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
    71dc01866a1e:	41 80 7e 38 00       	cmp    BYTE PTR [r14+0x38],0x0
    71dc01866a23:	0f 85 3d 16 00 00    	jne    0x71dc01868066
    71dc01866a29:	49 8b fe             	mov    rdi,r14
    71dc01866a2c:	ff 15 9e de e7 ff    	call   QWORD PTR [rip+0xffffffffffe7de9e]        # 0x71dc016e48d0
    71dc01866a32:	4d 8b 6e 08          	mov    r13,QWORD PTR [r14+0x8]
    71dc01866a36:	41 8b 7d 58          	mov    edi,DWORD PTR [r13+0x58]
    71dc01866a3a:	49 8b 55 50          	mov    rdx,QWORD PTR [r13+0x50]
    71dc01866a3e:	3b 7a 10             	cmp    edi,DWORD PTR [rdx+0x10]
    71dc01866a41:	7d c7                	jge    0x71dc01866a0a
    71dc01866a43:	49 8b 7d 50          	mov    rdi,QWORD PTR [r13+0x50]
    71dc01866a47:	48 8b d7             	mov    rdx,rdi
    71dc01866a4a:	41 8b 75 58          	mov    esi,DWORD PTR [r13+0x58]
    71dc01866a4e:	8b c6                	mov    eax,esi
    71dc01866a50:	8b 4a 10             	mov    ecx,DWORD PTR [rdx+0x10]
    71dc01866a53:	3b c1                	cmp    eax,ecx
    71dc01866a55:	0f 83 c1 15 00 00    	jae    0x71dc0186801c
    71dc01866a5b:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
    71dc01866a5f:	4c 8b c2             	mov    r8,rdx
    71dc01866a62:	41 3b 40 08          	cmp    eax,DWORD PTR [r8+0x8]
    71dc01866a66:	0f 83 9c 27 00 00    	jae    0x71dc01869208
    71dc01866a6c:	49 8b 44 c0 10       	mov    rax,QWORD PTR [r8+rax*8+0x10]
    71dc01866a71:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
    71dc01866a75:	48 8b c7             	mov    rax,rdi
    71dc01866a78:	44 8b c6             	mov    r8d,esi
    71dc01866a7b:	44 3b c1             	cmp    r8d,ecx
    71dc01866a7e:	0f 83 98 15 00 00    	jae    0x71dc0186801c
    71dc01866a84:	44 3b 42 08          	cmp    r8d,DWORD PTR [rdx+0x8]
    71dc01866a88:	0f 83 7a 27 00 00    	jae    0x71dc01869208
    71dc01866a8e:	45 33 c9             	xor    r9d,r9d
    71dc01866a91:	4e 89 4c c2 10       	mov    QWORD PTR [rdx+r8*8+0x10],r9
    71dc01866a96:	ff 40 14             	inc    DWORD PTR [rax+0x14]
    71dc01866a99:	8d 56 01             	lea    edx,[rsi+0x1]
    71dc01866a9c:	41 89 55 58          	mov    DWORD PTR [r13+0x58],edx
    71dc01866aa0:	81 fa 00 04 00 00    	cmp    edx,0x400
    71dc01866aa6:	0f 8f 77 15 00 00    	jg     0x71dc01868023
    71dc01866aac:	49 8b 7d 48          	mov    rdi,QWORD PTR [r13+0x48]
    71dc01866ab0:	80 7f 38 00          	cmp    BYTE PTR [rdi+0x38],0x0
    71dc01866ab4:	0f 85 8d 15 00 00    	jne    0x71dc01868047
    71dc01866aba:	48 8b 75 c8          	mov    rsi,QWORD PTR [rbp-0x38]
    71dc01866abe:	49 8d 7f 08          	lea    rdi,[r15+0x8]
    71dc01866ac2:	e8 39 9f 7e 7c       	call   0x71dc7e050a00
    71dc01866ac7:	49 83 7f 08 00       	cmp    QWORD PTR [r15+0x8],0x0
    71dc01866acc:	0f 84 a1 15 00 00    	je     0x71dc01868073
    71dc01866ad2:	48 8b 73 30          	mov    rsi,QWORD PTR [rbx+0x30]
    71dc01866ad6:	8b 76 34             	mov    esi,DWORD PTR [rsi+0x34]
    71dc01866ad9:	48 8d bd 88 fe ff ff 	lea    rdi,[rbp-0x178]
    71dc01866ae0:	ff 15 52 7d d8 ff    	call   QWORD PTR [rip+0xffffffffffd87d52]        # 0x71dc015ee838
    71dc01866ae6:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc01866aed:	71 00 00 
    71dc01866af0:	e8 cb a7 7e 7c       	call   0x71dc7e0512c0
    71dc01866af5:	4c 8b f0             	mov    r14,rax
    71dc01866af8:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc01866afc:	48 8b b5 88 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x178]
    71dc01866b03:	e8 38 95 3b fd       	call   0x71dbfec20040
    71dc01866b08:	8b bd 90 fe ff ff    	mov    edi,DWORD PTR [rbp-0x170]
    71dc01866b0e:	41 89 7e 10          	mov    DWORD PTR [r14+0x10],edi
    71dc01866b12:	48 8d 7b 40          	lea    rdi,[rbx+0x40]
    71dc01866b16:	49 8b f6             	mov    rsi,r14
    71dc01866b19:	e8 22 95 3b fd       	call   0x71dbfec20040
    71dc01866b1e:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc01866b22:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01866b26:	49 bb 10 8b 6f 01 dc 	movabs r11,0x71dc016f8b10
    71dc01866b2d:	71 00 00 
    71dc01866b30:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc01866b33:	0f 85 2e 17 00 00    	jne    0x71dc01868267
    71dc01866b39:	44 8b 77 18          	mov    r14d,DWORD PTR [rdi+0x18]
    71dc01866b3d:	45 85 f6             	test   r14d,r14d
    71dc01866b40:	0f 84 37 15 00 00    	je     0x71dc0186807d
    71dc01866b46:	41 0f b6 7f 34       	movzx  edi,BYTE PTR [r15+0x34]
    71dc01866b4b:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
    71dc01866b4f:	c5 fa 7f 85 08 fe ff 	vmovdqu XMMWORD PTR [rbp-0x1f8],xmm0
    71dc01866b56:	ff 
    71dc01866b57:	48 89 9d f8 fd ff ff 	mov    QWORD PTR [rbp-0x208],rbx
    71dc01866b5e:	40 88 bd 04 fe ff ff 	mov    BYTE PTR [rbp-0x1fc],dil
    71dc01866b65:	c7 85 00 fe ff ff ff 	mov    DWORD PTR [rbp-0x200],0xffffffff
    71dc01866b6c:	ff ff ff 
    71dc01866b6f:	48 bf f0 13 10 7e dc 	movabs rdi,0x71dc7e1013f0
    71dc01866b76:	71 00 00 
    71dc01866b79:	48 b8 20 f8 8b 7e dc 	movabs rax,0x71dc7e8bf820
    71dc01866b80:	71 00 00 
    71dc01866b83:	ff d0                	call   rax
    71dc01866b85:	83 38 05             	cmp    DWORD PTR [rax],0x5
    71dc01866b88:	0f 8e ee 16 00 00    	jle    0x71dc0186827c
    71dc01866b8e:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc01866b92:	48 8b 47 28          	mov    rax,QWORD PTR [rdi+0x28]
    71dc01866b96:	48 85 c0             	test   rax,rax
    71dc01866b99:	0f 84 dd 16 00 00    	je     0x71dc0186827c
    71dc01866b9f:	4c 8b 70 10          	mov    r14,QWORD PTR [rax+0x10]
    71dc01866ba3:	4d 85 f6             	test   r14,r14
    71dc01866ba6:	75 09                	jne    0x71dc01866bb1
    71dc01866ba8:	ff 15 e2 e6 2a ff    	call   QWORD PTR [rip+0xffffffffff2ae6e2]        # 0x71dc00b15290
    71dc01866bae:	4c 8b f0             	mov    r14,rax
    71dc01866bb1:	4c 89 b5 80 fd ff ff 	mov    QWORD PTR [rbp-0x280],r14
    71dc01866bb8:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
    71dc01866bbc:	48 89 b5 78 fd ff ff 	mov    QWORD PTR [rbp-0x288],rsi
    71dc01866bc3:	49 8b 76 10          	mov    rsi,QWORD PTR [r14+0x10]
    71dc01866bc7:	48 89 b5 70 fd ff ff 	mov    QWORD PTR [rbp-0x290],rsi
    71dc01866bce:	48 8d bd f8 fd ff ff 	lea    rdi,[rbp-0x208]
    71dc01866bd5:	ff 15 95 dc e7 ff    	call   QWORD PTR [rip+0xffffffffffe7dc95]        # 0x71dc016e4870
    71dc01866bdb:	90                   	nop
    71dc01866bdc:	48 8b b5 70 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x290]
    71dc01866be3:	49 3b 76 10          	cmp    rsi,QWORD PTR [r14+0x10]
    71dc01866be7:	0f 85 9e 16 00 00    	jne    0x71dc0186828b
    71dc01866bed:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
    71dc01866bf1:	48 39 95 78 fd ff ff 	cmp    QWORD PTR [rbp-0x288],rdx
    71dc01866bf8:	0f 85 9b 16 00 00    	jne    0x71dc01868299
    71dc01866bfe:	48 8b bd 08 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1f8]
    71dc01866c05:	48 b8 68 1b 80 21 d4 	movabs rax,0x71d421801b68
    71dc01866c0c:	71 00 00 
    71dc01866c0f:	48 3b 38             	cmp    rdi,QWORD PTR [rax]
    71dc01866c12:	0f 85 96 16 00 00    	jne    0x71dc018682ae
    71dc01866c18:	48 8b 85 10 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1f0]
    71dc01866c1f:	45 33 f6             	xor    r14d,r14d
    71dc01866c22:	4c 89 75 b0          	mov    QWORD PTR [rbp-0x50],r14
    71dc01866c26:	48 89 45 b8          	mov    QWORD PTR [rbp-0x48],rax
    71dc01866c2a:	66 c7 45 c0 00 00    	mov    WORD PTR [rbp-0x40],0x0
    71dc01866c30:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc01866c34:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01866c38:	4d 85 f6             	test   r14,r14
    71dc01866c3b:	0f 85 a2 16 00 00    	jne    0x71dc018682e3
    71dc01866c41:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01866c45:	4d 85 f6             	test   r14,r14
    71dc01866c48:	0f 85 66 17 00 00    	jne    0x71dc018683b4
    71dc01866c4e:	48 8b 75 b8          	mov    rsi,QWORD PTR [rbp-0x48]
    71dc01866c52:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    71dc01866c56:	e8 a5 9d 7e 7c       	call   0x71dc7e050a00
    71dc01866c5b:	49 8d 7f 50          	lea    rdi,[r15+0x50]
    71dc01866c5f:	48 89 bd a0 fd ff ff 	mov    QWORD PTR [rbp-0x260],rdi
    71dc01866c66:	48 8b 7b 20          	mov    rdi,QWORD PTR [rbx+0x20]
    71dc01866c6a:	4c 8b 77 30          	mov    r14,QWORD PTR [rdi+0x30]
    71dc01866c6e:	48 bf 50 0a 5d 01 dc 	movabs rdi,0x71dc015d0a50
    71dc01866c75:	71 00 00 
    71dc01866c78:	e8 43 a6 7e 7c       	call   0x71dc7e0512c0
    71dc01866c7d:	48 89 85 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],rax
    71dc01866c84:	4d 8b b6 80 00 00 00 	mov    r14,QWORD PTR [r14+0x80]
    71dc01866c8b:	4c 8b 6b 28          	mov    r13,QWORD PTR [rbx+0x28]
    71dc01866c8f:	48 8b 85 98 fd ff ff 	mov    rax,QWORD PTR [rbp-0x268]
    71dc01866c96:	48 8d 78 10          	lea    rdi,[rax+0x10]
    71dc01866c9a:	49 8b f6             	mov    rsi,r14
    71dc01866c9d:	e8 9e 93 3b fd       	call   0x71dbfec20040
    71dc01866ca2:	48 8b 85 98 fd ff ff 	mov    rax,QWORD PTR [rbp-0x268]
    71dc01866ca9:	48 8d 78 18          	lea    rdi,[rax+0x18]
    71dc01866cad:	49 8b f5             	mov    rsi,r13
    71dc01866cb0:	e8 8b 93 3b fd       	call   0x71dbfec20040
    71dc01866cb5:	48 bf 58 21 60 01 dc 	movabs rdi,0x71dc01602158
    71dc01866cbc:	71 00 00 
    71dc01866cbf:	e8 fc a5 7e 7c       	call   0x71dc7e0512c0
    71dc01866cc4:	48 89 85 68 fd ff ff 	mov    QWORD PTR [rbp-0x298],rax
    71dc01866ccb:	4d 85 f6             	test   r14,r14
    71dc01866cce:	0f 84 3d 17 00 00    	je     0x71dc01868411
    71dc01866cd4:	48 bf 48 c7 f3 00 dc 	movabs rdi,0x71dc00f3c748
    71dc01866cdb:	71 00 00 
    71dc01866cde:	e8 dd a5 7e 7c       	call   0x71dc7e0512c0
    71dc01866ce3:	4c 8b e0             	mov    r12,rax
    71dc01866ce6:	49 8d 7c 24 08       	lea    rdi,[r12+0x8]
    71dc01866ceb:	49 8b f6             	mov    rsi,r14
    71dc01866cee:	e8 4d 93 3b fd       	call   0x71dbfec20040
    71dc01866cf3:	4d 8b 74 24 08       	mov    r14,QWORD PTR [r12+0x8]
    71dc01866cf8:	49 8b fe             	mov    rdi,r14
    71dc01866cfb:	49 8b d5             	mov    rdx,r13
    71dc01866cfe:	be c0 00 00 00       	mov    esi,0xc0
    71dc01866d03:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01866d05:	ff 15 8d 8d d1 ff    	call   QWORD PTR [rip+0xffffffffffd18d8d]        # 0x71dc0157fa98
    71dc01866d0b:	49 8b 74 24 10       	mov    rsi,QWORD PTR [r12+0x10]
    71dc01866d10:	49 8b fe             	mov    rdi,r14
    71dc01866d13:	49 8b cd             	mov    rcx,r13
    71dc01866d16:	ba c0 00 00 00       	mov    edx,0xc0
    71dc01866d1b:	ff 15 ff df d7 ff    	call   QWORD PTR [rip+0xffffffffffd7dfff]        # 0x71dc015e4d20
    71dc01866d21:	49 89 44 24 10       	mov    QWORD PTR [r12+0x10],rax
    71dc01866d26:	4c 89 a5 60 fd ff ff 	mov    QWORD PTR [rbp-0x2a0],r12
    71dc01866d2d:	48 bf 08 4f 60 01 dc 	movabs rdi,0x71dc01604f08
    71dc01866d34:	71 00 00 
    71dc01866d37:	e8 84 a5 7e 7c       	call   0x71dc7e0512c0
    71dc01866d3c:	4c 8b f0             	mov    r14,rax
    71dc01866d3f:	48 bf 60 1b 80 21 d4 	movabs rdi,0x71d421801b60
    71dc01866d46:	71 00 00 
    71dc01866d49:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01866d4c:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc01866d50:	e8 eb 92 3b fd       	call   0x71dbfec20040
    71dc01866d55:	48 8b 85 68 fd ff ff 	mov    rax,QWORD PTR [rbp-0x298]
    71dc01866d5c:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc01866d60:	49 8b f6             	mov    rsi,r14
    71dc01866d63:	e8 d8 92 3b fd       	call   0x71dbfec20040
    71dc01866d68:	48 8b 85 68 fd ff ff 	mov    rax,QWORD PTR [rbp-0x298]
    71dc01866d6f:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
    71dc01866d73:	8b 7e 18             	mov    edi,DWORD PTR [rsi+0x18]
    71dc01866d76:	48 8b 76 18          	mov    rsi,QWORD PTR [rsi+0x18]
    71dc01866d7a:	48 85 f6             	test   rsi,rsi
    71dc01866d7d:	75 33                	jne    0x71dc01866db2
    71dc01866d7f:	33 ff                	xor    edi,edi
    71dc01866d81:	89 78 18             	mov    DWORD PTR [rax+0x18],edi
    71dc01866d84:	4d 85 e4             	test   r12,r12
    71dc01866d87:	74 3e                	je     0x71dc01866dc7
    71dc01866d89:	83 78 18 00          	cmp    DWORD PTR [rax+0x18],0x0
    71dc01866d8d:	75 28                	jne    0x71dc01866db7
    71dc01866d8f:	45 33 f6             	xor    r14d,r14d
    71dc01866d92:	49 81 c6 c0 00 00 00 	add    r14,0xc0
    71dc01866d99:	49 8b fc             	mov    rdi,r12
    71dc01866d9c:	49 8b f6             	mov    rsi,r14
    71dc01866d9f:	ff 15 93 8f 61 ff    	call   QWORD PTR [rip+0xffffffffff618f93]        # 0x71dc00e7fd38
    71dc01866da5:	48 8b 85 68 fd ff ff 	mov    rax,QWORD PTR [rbp-0x298]
    71dc01866dac:	4c 89 70 10          	mov    QWORD PTR [rax+0x10],r14
    71dc01866db0:	eb 15                	jmp    0x71dc01866dc7
    71dc01866db2:	8b 7e 08             	mov    edi,DWORD PTR [rsi+0x8]
    71dc01866db5:	eb ca                	jmp    0x71dc01866d81
    71dc01866db7:	8b 70 18             	mov    esi,DWORD PTR [rax+0x18]
    71dc01866dba:	33 ff                	xor    edi,edi
    71dc01866dbc:	ff 15 56 f6 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7f656]        # 0x71dc015e6418
    71dc01866dc2:	4c 8b f0             	mov    r14,rax
    71dc01866dc5:	eb cb                	jmp    0x71dc01866d92
    71dc01866dc7:	e8 db 25 00 00       	call   0x71dc018693a7
    71dc01866dcc:	90                   	nop
    71dc01866dcd:	48 8b 85 98 fd ff ff 	mov    rax,QWORD PTR [rbp-0x268]
    71dc01866dd4:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc01866dd8:	48 8b b5 68 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x298]
    71dc01866ddf:	e8 5c 92 3b fd       	call   0x71dbfec20040
    71dc01866de4:	48 8b bd a0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x260]
    71dc01866deb:	48 8b b5 98 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x268]
    71dc01866df2:	e8 09 9c 7e 7c       	call   0x71dc7e050a00
    71dc01866df7:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01866dfe:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc01866e03:	0f 85 10 16 00 00    	jne    0x71dc01868419
    71dc01866e09:	49 8b 7f 10          	mov    rdi,QWORD PTR [r15+0x10]
    71dc01866e0d:	48 8b 9d b0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x250]
    71dc01866e14:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc01866e18:	48 8b 53 20          	mov    rdx,QWORD PTR [rbx+0x20]
    71dc01866e1c:	ff 15 46 7d d8 ff    	call   QWORD PTR [rip+0xffffffffffd87d46]        # 0x71dc015eeb68
    71dc01866e22:	49 8d 7f 18          	lea    rdi,[r15+0x18]
    71dc01866e26:	48 8b f0             	mov    rsi,rax
    71dc01866e29:	e8 d2 9b 7e 7c       	call   0x71dc7e050a00
    71dc01866e2e:	33 f6                	xor    esi,esi
    71dc01866e30:	49 89 77 20          	mov    QWORD PTR [r15+0x20],rsi
    71dc01866e34:	41 89 77 2c          	mov    DWORD PTR [r15+0x2c],esi
    71dc01866e38:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01866e3f:	83 7d d4 07          	cmp    DWORD PTR [rbp-0x2c],0x7
    71dc01866e43:	0f 84 39 05 00 00    	je     0x71dc01867382
    71dc01866e49:	33 f6                	xor    esi,esi
    71dc01866e4b:	41 89 77 30          	mov    DWORD PTR [r15+0x30],esi
    71dc01866e4f:	e9 79 02 00 00       	jmp    0x71dc018670cd
    71dc01866e54:	41 c7 46 48 3f 00 00 	mov    DWORD PTR [r14+0x48],0x3f
    71dc01866e5b:	00 
    71dc01866e5c:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01866e60:	49 8b 46 10          	mov    rax,QWORD PTR [r14+0x10]
    71dc01866e64:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    71dc01866e68:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    71dc01866e6f:	48 8b 49 18          	mov    rcx,QWORD PTR [rcx+0x18]
    71dc01866e73:	48 85 c9             	test   rcx,rcx
    71dc01866e76:	0f 85 b4 05 00 00    	jne    0x71dc01867430
    71dc01866e7c:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    71dc01866e83:	48 85 ff             	test   rdi,rdi
    71dc01866e86:	0f 84 6a 02 00 00    	je     0x71dc018670f6
    71dc01866e8c:	e9 a8 05 00 00       	jmp    0x71dc01867439
    71dc01866e91:	49 8b 7e 08          	mov    rdi,QWORD PTR [r14+0x8]
    71dc01866e95:	49 8b 76 10          	mov    rsi,QWORD PTR [r14+0x10]
    71dc01866e99:	ff 15 39 7f d8 ff    	call   QWORD PTR [rip+0xffffffffffd87f39]        # 0x71dc015eedd8
    71dc01866e9f:	4c 8b e8             	mov    r13,rax
    71dc01866ea2:	48 bf 80 eb 60 01 dc 	movabs rdi,0x71dc0160eb80
    71dc01866ea9:	71 00 00 
    71dc01866eac:	49 39 7d 00          	cmp    QWORD PTR [r13+0x0],rdi
    71dc01866eb0:	0f 85 3b 06 00 00    	jne    0x71dc018674f1
    71dc01866eb6:	48 bf 78 a0 6f 01 dc 	movabs rdi,0x71dc016fa078
    71dc01866ebd:	71 00 00 
    71dc01866ec0:	e8 fb a3 7e 7c       	call   0x71dc7e0512c0
    71dc01866ec5:	4c 8b e0             	mov    r12,rax
    71dc01866ec8:	33 ff                	xor    edi,edi
    71dc01866eca:	41 89 7c 24 18       	mov    DWORD PTR [r12+0x18],edi
    71dc01866ecf:	49 8d 7c 24 10       	lea    rdi,[r12+0x10]
    71dc01866ed4:	49 8b f5             	mov    rsi,r13
    71dc01866ed7:	e8 64 91 3b fd       	call   0x71dbfec20040
    71dc01866edc:	49 8d 7e 28          	lea    rdi,[r14+0x28]
    71dc01866ee0:	49 8b f4             	mov    rsi,r12
    71dc01866ee3:	e8 58 91 3b fd       	call   0x71dbfec20040
    71dc01866ee8:	eb 32                	jmp    0x71dc01866f1c
    71dc01866eea:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc01866ef1:	71 00 00 
    71dc01866ef4:	48 8b 3f             	mov    rdi,QWORD PTR [rdi]
    71dc01866ef7:	48 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rdi
    71dc01866efe:	45 33 ed             	xor    r13d,r13d
    71dc01866f01:	45 33 e4             	xor    r12d,r12d
    71dc01866f04:	eb 66                	jmp    0x71dc01866f6c
    71dc01866f06:	33 ff                	xor    edi,edi
    71dc01866f08:	48 85 ff             	test   rdi,rdi
    71dc01866f0b:	0f 85 2a 02 00 00    	jne    0x71dc0186713b
    71dc01866f11:	49 83 7e 28 00       	cmp    QWORD PTR [r14+0x28],0x0
    71dc01866f16:	0f 84 75 ff ff ff    	je     0x71dc01866e91
    71dc01866f1c:	49 8b 7e 28          	mov    rdi,QWORD PTR [r14+0x28]
    71dc01866f20:	48 b8 78 a0 6f 01 dc 	movabs rax,0x71dc016fa078
    71dc01866f27:	71 00 00 
    71dc01866f2a:	48 39 07             	cmp    QWORD PTR [rdi],rax
    71dc01866f2d:	0f 85 d6 05 00 00    	jne    0x71dc01867509
    71dc01866f33:	ff 15 d7 31 e9 ff    	call   QWORD PTR [rip+0xffffffffffe931d7]        # 0x71dc016fa110
    71dc01866f39:	85 c0                	test   eax,eax
    71dc01866f3b:	74 ad                	je     0x71dc01866eea
    71dc01866f3d:	49 8b 7e 28          	mov    rdi,QWORD PTR [r14+0x28]
    71dc01866f41:	49 bb 78 a0 6f 01 dc 	movabs r11,0x71dc016fa078
    71dc01866f48:	71 00 00 
    71dc01866f4b:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc01866f4e:	0f 85 c7 05 00 00    	jne    0x71dc0186751b
    71dc01866f54:	4c 8b 77 08          	mov    r14,QWORD PTR [rdi+0x8]
    71dc01866f58:	4c 89 b5 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],r14
    71dc01866f5f:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    71dc01866f66:	41 bc 01 00 00 00    	mov    r12d,0x1
    71dc01866f6c:	45 84 e4             	test   r12b,r12b
    71dc01866f6f:	0f 84 fa 05 00 00    	je     0x71dc0186756f
    71dc01866f75:	45 8b 67 30          	mov    r12d,DWORD PTR [r15+0x30]
    71dc01866f79:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc01866f7d:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01866f81:	49 bb 10 8b 6f 01 dc 	movabs r11,0x71dc016f8b10
    71dc01866f88:	71 00 00 
    71dc01866f8b:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc01866f8e:	0f 85 9c 05 00 00    	jne    0x71dc01867530
    71dc01866f94:	44 8b 77 18          	mov    r14d,DWORD PTR [rdi+0x18]
    71dc01866f98:	45 3b e6             	cmp    r12d,r14d
    71dc01866f9b:	0f 8d ce 05 00 00    	jge    0x71dc0186756f
    71dc01866fa1:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc01866fa5:	41 8b 77 30          	mov    esi,DWORD PTR [r15+0x30]
    71dc01866fa9:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01866fad:	49 bb 10 8b 6f 01 dc 	movabs r11,0x71dc016f8b10
    71dc01866fb4:	71 00 00 
    71dc01866fb7:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc01866fba:	0f 85 85 05 00 00    	jne    0x71dc01867545
    71dc01866fc0:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01866fc4:	3b 77 08             	cmp    esi,DWORD PTR [rdi+0x8]
    71dc01866fc7:	0f 83 9c 05 00 00    	jae    0x71dc01867569
    71dc01866fcd:	4c 8b 74 f7 10       	mov    r14,QWORD PTR [rdi+rsi*8+0x10]
    71dc01866fd2:	4d 8d 67 50          	lea    r12,[r15+0x50]
    71dc01866fd6:	48 8b 43 20          	mov    rax,QWORD PTR [rbx+0x20]
    71dc01866fda:	48 89 85 48 fd ff ff 	mov    QWORD PTR [rbp-0x2b8],rax
    71dc01866fe1:	48 8b 4b 28          	mov    rcx,QWORD PTR [rbx+0x28]
    71dc01866fe5:	48 89 8d 40 fd ff ff 	mov    QWORD PTR [rbp-0x2c0],rcx
    71dc01866fec:	48 bf f0 13 10 7e dc 	movabs rdi,0x71dc7e1013f0
    71dc01866ff3:	71 00 00 
    71dc01866ff6:	48 ba 20 f8 8b 7e dc 	movabs rdx,0x71dc7e8bf820
    71dc01866ffd:	71 00 00 
    71dc01867000:	ff d2                	call   rdx
    71dc01867002:	83 38 13             	cmp    DWORD PTR [rax],0x13
    71dc01867005:	0f 8e 4f 05 00 00    	jle    0x71dc0186755a
    71dc0186700b:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc0186700f:	48 8b 87 98 00 00 00 	mov    rax,QWORD PTR [rdi+0x98]
    71dc01867016:	48 85 c0             	test   rax,rax
    71dc01867019:	0f 84 3b 05 00 00    	je     0x71dc0186755a
    71dc0186701f:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
    71dc01867023:	48 89 8d 50 fd ff ff 	mov    QWORD PTR [rbp-0x2b0],rcx
    71dc0186702a:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
    71dc0186702e:	48 89 95 58 fd ff ff 	mov    QWORD PTR [rbp-0x2a8],rdx
    71dc01867035:	48 89 85 10 fd ff ff 	mov    QWORD PTR [rbp-0x2f0],rax
    71dc0186703c:	48 8d 78 18          	lea    rdi,[rax+0x18]
    71dc01867040:	48 8b b5 48 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2b8]
    71dc01867047:	e8 f4 8f 3b fd       	call   0x71dbfec20040
    71dc0186704c:	48 8b 85 10 fd ff ff 	mov    rax,QWORD PTR [rbp-0x2f0]
    71dc01867053:	48 8d 78 20          	lea    rdi,[rax+0x20]
    71dc01867057:	48 8b b5 40 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2c0]
    71dc0186705e:	e8 dd 8f 3b fd       	call   0x71dbfec20040
    71dc01867063:	48 8b 85 50 fd ff ff 	mov    rax,QWORD PTR [rbp-0x2b0]
    71dc0186706a:	48 89 85 20 fd ff ff 	mov    QWORD PTR [rbp-0x2e0],rax
    71dc01867071:	48 8b 8d 58 fd ff ff 	mov    rcx,QWORD PTR [rbp-0x2a8]
    71dc01867078:	48 89 8d 18 fd ff ff 	mov    QWORD PTR [rbp-0x2e8],rcx
    71dc0186707f:	4d 8b 24 24          	mov    r12,QWORD PTR [r12]
    71dc01867083:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc01867087:	49 8b fd             	mov    rdi,r13
    71dc0186708a:	ff 15 a0 e7 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7e7a0]        # 0x71dc016e5830
    71dc01867090:	48 8b f0             	mov    rsi,rax
    71dc01867093:	49 8b fc             	mov    rdi,r12
    71dc01867096:	49 8b d6             	mov    rdx,r14
    71dc01867099:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186709b:	ff 15 c7 9a d6 ff    	call   QWORD PTR [rip+0xffffffffffd69ac7]        # 0x71dc015d0b68
    71dc018670a1:	90                   	nop
    71dc018670a2:	4c 8b b5 10 fd ff ff 	mov    r14,QWORD PTR [rbp-0x2f0]
    71dc018670a9:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    71dc018670ad:	48 8b b5 50 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2b0]
    71dc018670b4:	e8 87 8f 3b fd       	call   0x71dbfec20040
    71dc018670b9:	49 8d 7e 20          	lea    rdi,[r14+0x20]
    71dc018670bd:	48 8b b5 58 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2a8]
    71dc018670c4:	e8 77 8f 3b fd       	call   0x71dbfec20040
    71dc018670c9:	41 ff 47 30          	inc    DWORD PTR [r15+0x30]
    71dc018670cd:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc018670d2:	0f 85 a0 01 00 00    	jne    0x71dc01867278
    71dc018670d8:	4d 8b 77 18          	mov    r14,QWORD PTR [r15+0x18]
    71dc018670dc:	49 83 7e 20 00       	cmp    QWORD PTR [r14+0x20],0x0
    71dc018670e1:	74 13                	je     0x71dc018670f6
    71dc018670e3:	41 8b 7e 48          	mov    edi,DWORD PTR [r14+0x48]
    71dc018670e7:	8d 47 ff             	lea    eax,[rdi-0x1]
    71dc018670ea:	41 89 46 48          	mov    DWORD PTR [r14+0x48],eax
    71dc018670ee:	85 ff                	test   edi,edi
    71dc018670f0:	0f 84 5e fd ff ff    	je     0x71dc01866e54
    71dc018670f6:	49 83 7e 18 00       	cmp    QWORD PTR [r14+0x18],0x0
    71dc018670fb:	0f 85 50 03 00 00    	jne    0x71dc01867451
    71dc01867101:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
    71dc01867105:	48 8b fe             	mov    rdi,rsi
    71dc01867108:	48 85 ff             	test   rdi,rdi
    71dc0186710b:	0f 84 f7 fd ff ff    	je     0x71dc01866f08
    71dc01867111:	48 b8 80 eb 60 01 dc 	movabs rax,0x71dc0160eb80
    71dc01867118:	71 00 00 
    71dc0186711b:	48 39 07             	cmp    QWORD PTR [rdi],rax
    71dc0186711e:	0f 84 e2 fd ff ff    	je     0x71dc01866f06
    71dc01867124:	48 bf 00 44 61 01 dc 	movabs rdi,0x71dc01614400
    71dc0186712b:	71 00 00 
    71dc0186712e:	e8 6d dd fd ff       	call   0x71dc01844ea0
    71dc01867133:	48 8b f8             	mov    rdi,rax
    71dc01867136:	e9 cd fd ff ff       	jmp    0x71dc01866f08
    71dc0186713b:	48 be 60 61 61 01 dc 	movabs rsi,0x71dc01616160
    71dc01867142:	71 00 00 
    71dc01867145:	48 39 37             	cmp    QWORD PTR [rdi],rsi
    71dc01867148:	0f 85 87 03 00 00    	jne    0x71dc018674d5
    71dc0186714e:	80 7f 30 00          	cmp    BYTE PTR [rdi+0x30],0x0
    71dc01867152:	0f 85 14 03 00 00    	jne    0x71dc0186746c
    71dc01867158:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc0186715c:	40 0f b6 76 18       	rex movzx esi,BYTE PTR [rsi+0x18]
    71dc01867161:	85 f6                	test   esi,esi
    71dc01867163:	0f 85 03 03 00 00    	jne    0x71dc0186746c
    71dc01867169:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc0186716d:	48 85 ff             	test   rdi,rdi
    71dc01867170:	0f 84 b4 00 00 00    	je     0x71dc0186722a
    71dc01867176:	48 be 08 09 62 01 dc 	movabs rsi,0x71dc01620908
    71dc0186717d:	71 00 00 
    71dc01867180:	48 39 37             	cmp    QWORD PTR [rdi],rsi
    71dc01867183:	0f 85 a1 00 00 00    	jne    0x71dc0186722a
    71dc01867189:	be ff ff ff ff       	mov    esi,0xffffffff
    71dc0186718e:	ff 15 74 d8 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7d874]        # 0x71dc016e4a08
    71dc01867194:	83 78 38 00          	cmp    DWORD PTR [rax+0x38],0x0
    71dc01867198:	0f 8d 13 03 00 00    	jge    0x71dc018674b1
    71dc0186719e:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc018671a2:	33 c9                	xor    ecx,ecx
    71dc018671a4:	33 d2                	xor    edx,edx
    71dc018671a6:	8b 77 08             	mov    esi,DWORD PTR [rdi+0x8]
    71dc018671a9:	85 f6                	test   esi,esi
    71dc018671ab:	7e 1e                	jle    0x71dc018671cb
    71dc018671ad:	44 8b c2             	mov    r8d,edx
    71dc018671b0:	46 0f b6 44 07 10    	movzx  r8d,BYTE PTR [rdi+r8*1+0x10]
    71dc018671b6:	41 f6 c0 80          	test   r8b,0x80
    71dc018671ba:	75 37                	jne    0x71dc018671f3
    71dc018671bc:	41 b9 01 00 00 00    	mov    r9d,0x1
    71dc018671c2:	41 03 d1             	add    edx,r9d
    71dc018671c5:	ff c1                	inc    ecx
    71dc018671c7:	3b f2                	cmp    esi,edx
    71dc018671c9:	7f e2                	jg     0x71dc018671ad
    71dc018671cb:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    71dc018671ce:	8b f9                	mov    edi,ecx
    71dc018671d0:	85 ff                	test   edi,edi
    71dc018671d2:	0f 84 e1 02 00 00    	je     0x71dc018674b9
    71dc018671d8:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
    71dc018671df:	41 be 01 00 00 00    	mov    r14d,0x1
    71dc018671e5:	45 85 f6             	test   r14d,r14d
    71dc018671e8:	0f 85 71 fd ff ff    	jne    0x71dc01866f5f
    71dc018671ee:	e9 0b fd ff ff       	jmp    0x71dc01866efe
    71dc018671f3:	45 8b c8             	mov    r9d,r8d
    71dc018671f6:	41 81 e1 e0 00 00 00 	and    r9d,0xe0
    71dc018671fd:	41 81 f9 c0 00 00 00 	cmp    r9d,0xc0
    71dc01867204:	74 1c                	je     0x71dc01867222
    71dc01867206:	41 81 e0 f0 00 00 00 	and    r8d,0xf0
    71dc0186720d:	41 81 f8 e0 00 00 00 	cmp    r8d,0xe0
    71dc01867214:	0f 84 8c 02 00 00    	je     0x71dc018674a6
    71dc0186721a:	41 b9 04 00 00 00    	mov    r9d,0x4
    71dc01867220:	eb a0                	jmp    0x71dc018671c2
    71dc01867222:	41 b9 02 00 00 00    	mov    r9d,0x2
    71dc01867228:	eb 98                	jmp    0x71dc018671c2
    71dc0186722a:	48 bf d8 a6 f2 00 dc 	movabs rdi,0x71dc00f2a6d8
    71dc01867231:	71 00 00 
    71dc01867234:	e8 87 a0 7e 7c       	call   0x71dc7e0512c0
    71dc01867239:	4c 8b f0             	mov    r14,rax
    71dc0186723c:	48 bf b8 dc 62 fc db 	movabs rdi,0x71dbfc62dcb8
    71dc01867243:	71 00 00 
    71dc01867246:	48 be 00 dc 62 fc db 	movabs rsi,0x71dbfc62dc00
    71dc0186724d:	71 00 00 
    71dc01867250:	ff 15 f2 dc a0 ff    	call   QWORD PTR [rip+0xffffffffffa0dcf2]        # 0x71dc01274f48
    71dc01867256:	48 8b f0             	mov    rsi,rax
    71dc01867259:	49 8b fe             	mov    rdi,r14
    71dc0186725c:	48 b9 c0 a8 65 fc db 	movabs rcx,0x71dbfc65a8c0
    71dc01867263:	71 00 00 
    71dc01867266:	45 33 c0             	xor    r8d,r8d
    71dc01867269:	ff 15 b1 d7 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7d7b1]        # 0x71dc016e4a20
    71dc0186726f:	49 8b fe             	mov    rdi,r14
    71dc01867272:	e8 29 ad 54 7c       	call   0x71dc7ddb1fa0
    71dc01867277:	cc                   	int3
    71dc01867278:	49 8b 7f 18          	mov    rdi,QWORD PTR [r15+0x18]
    71dc0186727c:	48 8d b5 d0 fe ff ff 	lea    rsi,[rbp-0x130]
    71dc01867283:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01867285:	ff 15 05 87 d8 ff    	call   QWORD PTR [rip+0xffffffffffd88705]        # 0x71dc015ef990
    71dc0186728b:	48 8b b5 d0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x130]
    71dc01867292:	48 8b bd e0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x120]
    71dc01867299:	0f b6 85 e8 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x118]
    71dc018672a0:	48 0f bf 8d d8 fe ff 	movsx  rcx,WORD PTR [rbp-0x128]
    71dc018672a7:	ff 
    71dc018672a8:	48 89 b5 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rsi
    71dc018672af:	66 89 8d f8 fe ff ff 	mov    WORD PTR [rbp-0x108],cx
    71dc018672b6:	c6 85 fa fe ff ff 00 	mov    BYTE PTR [rbp-0x106],0x0
    71dc018672bd:	48 89 bd 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rdi
    71dc018672c4:	88 85 08 ff ff ff    	mov    BYTE PTR [rbp-0xf8],al
    71dc018672ca:	4c 8b b5 f0 fe ff ff 	mov    r14,QWORD PTR [rbp-0x110]
    71dc018672d1:	4d 85 f6             	test   r14,r14
    71dc018672d4:	74 20                	je     0x71dc018672f6
    71dc018672d6:	49 8b f6             	mov    rsi,r14
    71dc018672d9:	48 bf 40 be 6f 01 dc 	movabs rdi,0x71dc016fbe40
    71dc018672e0:	71 00 00 
    71dc018672e3:	e8 98 da fd ff       	call   0x71dc01844d80
    71dc018672e8:	48 85 c0             	test   rax,rax
    71dc018672eb:	74 2d                	je     0x71dc0186731a
    71dc018672ed:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc018672f4:	74 40                	je     0x71dc01867336
    71dc018672f6:	4c 8b b5 f0 fe ff ff 	mov    r14,QWORD PTR [rbp-0x110]
    71dc018672fd:	4d 85 f6             	test   r14,r14
    71dc01867300:	0f 85 bf 00 00 00    	jne    0x71dc018673c5
    71dc01867306:	4c 8b ad 00 ff ff ff 	mov    r13,QWORD PTR [rbp-0x100]
    71dc0186730d:	44 0f b6 a5 08 ff ff 	movzx  r12d,BYTE PTR [rbp-0xf8]
    71dc01867314:	ff 
    71dc01867315:	e9 52 fc ff ff       	jmp    0x71dc01866f6c
    71dc0186731a:	49 8b fe             	mov    rdi,r14
    71dc0186731d:	48 0f bf b5 f8 fe ff 	movsx  rsi,WORD PTR [rbp-0x108]
    71dc01867324:	ff 
    71dc01867325:	49 bb 38 36 c4 fe db 	movabs r11,0x71dbfec43638
    71dc0186732c:	71 00 00 
    71dc0186732f:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867332:	85 c0                	test   eax,eax
    71dc01867334:	75 c0                	jne    0x71dc018672f6
    71dc01867336:	c7 45 d4 07 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x7
    71dc0186733d:	41 c7 47 28 07 00 00 	mov    DWORD PTR [r15+0x28],0x7
    71dc01867344:	00 
    71dc01867345:	49 8d bf b0 00 00 00 	lea    rdi,[r15+0xb0]
    71dc0186734c:	48 8d b5 f0 fe ff ff 	lea    rsi,[rbp-0x110]
    71dc01867353:	ba 20 00 00 00       	mov    edx,0x20
    71dc01867358:	c5 f8 77             	vzeroupper
    71dc0186735b:	e8 e0 2f fe ff       	call   0x71dc0184a340
    71dc01867360:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01867364:	49 8b ff             	mov    rdi,r15
    71dc01867367:	ff 15 7b f3 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7f37b]        # 0x71dc017e66e8
    71dc0186736d:	48 8b f0             	mov    rsi,rax
    71dc01867370:	48 8d bd f0 fe ff ff 	lea    rdi,[rbp-0x110]
    71dc01867377:	ff 15 0b f6 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7f60b]        # 0x71dc017e6988
    71dc0186737d:	e9 e3 1e 00 00       	jmp    0x71dc01869265
    71dc01867382:	c4 c1 7e 6f 87 b0 00 	vmovdqu ymm0,YMMWORD PTR [r15+0xb0]
    71dc01867389:	00 00 
    71dc0186738b:	c5 fe 7f 85 f0 fe ff 	vmovdqu YMMWORD PTR [rbp-0x110],ymm0
    71dc01867392:	ff 
    71dc01867393:	33 f6                	xor    esi,esi
    71dc01867395:	49 89 b7 b0 00 00 00 	mov    QWORD PTR [r15+0xb0],rsi
    71dc0186739c:	49 89 b7 b8 00 00 00 	mov    QWORD PTR [r15+0xb8],rsi
    71dc018673a3:	49 89 b7 c0 00 00 00 	mov    QWORD PTR [r15+0xc0],rsi
    71dc018673aa:	49 89 b7 c8 00 00 00 	mov    QWORD PTR [r15+0xc8],rsi
    71dc018673b1:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc018673b8:	41 c7 47 28 ff ff ff 	mov    DWORD PTR [r15+0x28],0xffffffff
    71dc018673bf:	ff 
    71dc018673c0:	e9 31 ff ff ff       	jmp    0x71dc018672f6
    71dc018673c5:	49 8b f6             	mov    rsi,r14
    71dc018673c8:	48 bf 40 be 6f 01 dc 	movabs rdi,0x71dc016fbe40
    71dc018673cf:	71 00 00 
    71dc018673d2:	e8 a9 d9 fd ff       	call   0x71dc01844d80
    71dc018673d7:	4c 8b e0             	mov    r12,rax
    71dc018673da:	4d 85 e4             	test   r12,r12
    71dc018673dd:	74 2e                	je     0x71dc0186740d
    71dc018673df:	41 8b 7c 24 34       	mov    edi,DWORD PTR [r12+0x34]
    71dc018673e4:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc018673ea:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc018673f0:	74 0b                	je     0x71dc018673fd
    71dc018673f2:	49 8b fc             	mov    rdi,r12
    71dc018673f5:	33 f6                	xor    esi,esi
    71dc018673f7:	ff 15 1b e4 2a ff    	call   QWORD PTR [rip+0xffffffffff2ae41b]        # 0x71dc00b15818
    71dc018673fd:	4d 8b 6c 24 38       	mov    r13,QWORD PTR [r12+0x38]
    71dc01867402:	45 0f b6 64 24 40    	movzx  r12d,BYTE PTR [r12+0x40]
    71dc01867408:	e9 08 ff ff ff       	jmp    0x71dc01867315
    71dc0186740d:	49 8b fe             	mov    rdi,r14
    71dc01867410:	48 0f bf b5 f8 fe ff 	movsx  rsi,WORD PTR [rbp-0x108]
    71dc01867417:	ff 
    71dc01867418:	49 bb 40 36 c4 fe db 	movabs r11,0x71dbfec43640
    71dc0186741f:	71 00 00 
    71dc01867422:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867425:	4c 8b e8             	mov    r13,rax
    71dc01867428:	44 8b e2             	mov    r12d,edx
    71dc0186742b:	e9 e5 fe ff ff       	jmp    0x71dc01867315
    71dc01867430:	48 8b f9             	mov    rdi,rcx
    71dc01867433:	e8 68 ab 54 7c       	call   0x71dc7ddb1fa0
    71dc01867438:	cc                   	int3
    71dc01867439:	83 7f 20 00          	cmp    DWORD PTR [rdi+0x20],0x0
    71dc0186743d:	0f 84 b3 fc ff ff    	je     0x71dc018670f6
    71dc01867443:	48 8b f8             	mov    rdi,rax
    71dc01867446:	ff 15 34 d6 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7d634]        # 0x71dc015e4a80
    71dc0186744c:	e9 a5 fc ff ff       	jmp    0x71dc018670f6
    71dc01867451:	49 8b 7e 18          	mov    rdi,QWORD PTR [r14+0x18]
    71dc01867455:	48 8d b5 10 ff ff ff 	lea    rsi,[rbp-0xf0]
    71dc0186745c:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186745e:	ff 15 b4 7f de ff    	call   QWORD PTR [rip+0xffffffffffde7fb4]        # 0x71dc0164f418
    71dc01867464:	44 8b f0             	mov    r14d,eax
    71dc01867467:	e9 79 fd ff ff       	jmp    0x71dc018671e5
    71dc0186746c:	48 bf d8 a6 f2 00 dc 	movabs rdi,0x71dc00f2a6d8
    71dc01867473:	71 00 00 
    71dc01867476:	e8 45 9e 7e 7c       	call   0x71dc7e0512c0
    71dc0186747b:	4c 8b f0             	mov    r14,rax
    71dc0186747e:	49 8b fe             	mov    rdi,r14
    71dc01867481:	48 be 10 e8 64 fc db 	movabs rsi,0x71dbfc64e810
    71dc01867488:	71 00 00 
    71dc0186748b:	48 ba 70 91 65 fc db 	movabs rdx,0x71dbfc659170
    71dc01867492:	71 00 00 
    71dc01867495:	33 c9                	xor    ecx,ecx
    71dc01867497:	ff 15 bb df d7 ff    	call   QWORD PTR [rip+0xffffffffffd7dfbb]        # 0x71dc015e5458
    71dc0186749d:	49 8b fe             	mov    rdi,r14
    71dc018674a0:	e8 fb aa 54 7c       	call   0x71dc7ddb1fa0
    71dc018674a5:	cc                   	int3
    71dc018674a6:	41 b9 03 00 00 00    	mov    r9d,0x3
    71dc018674ac:	e9 11 fd ff ff       	jmp    0x71dc018671c2
    71dc018674b1:	8b 78 38             	mov    edi,DWORD PTR [rax+0x38]
    71dc018674b4:	e9 17 fd ff ff       	jmp    0x71dc018671d0
    71dc018674b9:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc018674c0:	71 00 00 
    71dc018674c3:	48 8b 3f             	mov    rdi,QWORD PTR [rdi]
    71dc018674c6:	48 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rdi
    71dc018674cd:	45 33 f6             	xor    r14d,r14d
    71dc018674d0:	e9 10 fd ff ff       	jmp    0x71dc018671e5
    71dc018674d5:	48 8d b5 10 ff ff ff 	lea    rsi,[rbp-0xf0]
    71dc018674dc:	49 bb 60 36 c4 fe db 	movabs r11,0x71dbfec43660
    71dc018674e3:	71 00 00 
    71dc018674e6:	41 ff 13             	call   QWORD PTR [r11]
    71dc018674e9:	44 8b f0             	mov    r14d,eax
    71dc018674ec:	e9 f4 fc ff ff       	jmp    0x71dc018671e5
    71dc018674f1:	49 8b fd             	mov    rdi,r13
    71dc018674f4:	49 bb 58 36 c4 fe db 	movabs r11,0x71dbfec43658
    71dc018674fb:	71 00 00 
    71dc018674fe:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867501:	4c 8b e0             	mov    r12,rax
    71dc01867504:	e9 d3 f9 ff ff       	jmp    0x71dc01866edc
    71dc01867509:	49 bb 48 36 c4 fe db 	movabs r11,0x71dbfec43648
    71dc01867510:	71 00 00 
    71dc01867513:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867516:	e9 1e fa ff ff       	jmp    0x71dc01866f39
    71dc0186751b:	49 bb 50 36 c4 fe db 	movabs r11,0x71dbfec43650
    71dc01867522:	71 00 00 
    71dc01867525:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867528:	4c 8b f0             	mov    r14,rax
    71dc0186752b:	e9 28 fa ff ff       	jmp    0x71dc01866f58
    71dc01867530:	49 bb 68 36 c4 fe db 	movabs r11,0x71dbfec43668
    71dc01867537:	71 00 00 
    71dc0186753a:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186753d:	44 8b f0             	mov    r14d,eax
    71dc01867540:	e9 53 fa ff ff       	jmp    0x71dc01866f98
    71dc01867545:	49 bb 70 36 c4 fe db 	movabs r11,0x71dbfec43670
    71dc0186754c:	71 00 00 
    71dc0186754f:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867552:	4c 8b f0             	mov    r14,rax
    71dc01867555:	e9 78 fa ff ff       	jmp    0x71dc01866fd2
    71dc0186755a:	bf 13 00 00 00       	mov    edi,0x13
    71dc0186755f:	e8 dc d9 fd ff       	call   0x71dc01844f40
    71dc01867564:	e9 b6 fa ff ff       	jmp    0x71dc0186701f
    71dc01867569:	e8 9a a0 5e fe       	call   0x71dbffe51608
    71dc0186756e:	cc                   	int3
    71dc0186756f:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01867576:	49 8b 7f 18          	mov    rdi,QWORD PTR [r15+0x18]
    71dc0186757a:	48 85 ff             	test   rdi,rdi
    71dc0186757d:	74 36                	je     0x71dc018675b5
    71dc0186757f:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01867581:	ff 15 69 14 d7 ff    	call   QWORD PTR [rip+0xffffffffffd71469]        # 0x71dc015d89f0
    71dc01867587:	48 89 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],rax
    71dc0186758e:	48 89 95 c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdx
    71dc01867595:	48 8b 9d c0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x140]
    71dc0186759c:	48 85 db             	test   rbx,rbx
    71dc0186759f:	0f 85 2c 10 00 00    	jne    0x71dc018685d1
    71dc018675a5:	48 8b 9d c0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x140]
    71dc018675ac:	48 85 db             	test   rbx,rbx
    71dc018675af:	0f 85 ee 10 00 00    	jne    0x71dc018686a3
    71dc018675b5:	49 8b 7f 20          	mov    rdi,QWORD PTR [r15+0x20]
    71dc018675b9:	48 8b df             	mov    rbx,rdi
    71dc018675bc:	48 85 db             	test   rbx,rbx
    71dc018675bf:	0f 85 37 11 00 00    	jne    0x71dc018686fc
    71dc018675c5:	33 ff                	xor    edi,edi
    71dc018675c7:	49 89 7f 20          	mov    QWORD PTR [r15+0x20],rdi
    71dc018675cb:	49 89 7f 18          	mov    QWORD PTR [r15+0x18],rdi
    71dc018675cf:	41 0f b6 7f 34       	movzx  edi,BYTE PTR [r15+0x34]
    71dc018675d4:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
    71dc018675d8:	62 f1 7e 08 7f 45 dd 	vmovdqu32 XMMWORD PTR [rbp-0x230],xmm0
    71dc018675df:	48 8b 9d b0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x250]
    71dc018675e6:	48 89 9d c0 fd ff ff 	mov    QWORD PTR [rbp-0x240],rbx
    71dc018675ed:	40 88 bd cc fd ff ff 	mov    BYTE PTR [rbp-0x234],dil
    71dc018675f4:	c7 85 c8 fd ff ff ff 	mov    DWORD PTR [rbp-0x238],0xffffffff
    71dc018675fb:	ff ff ff 
    71dc018675fe:	48 bf f0 13 10 7e dc 	movabs rdi,0x71dc7e1013f0
    71dc01867605:	71 00 00 
    71dc01867608:	48 b8 20 f8 8b 7e dc 	movabs rax,0x71dc7e8bf820
    71dc0186760f:	71 00 00 
    71dc01867612:	ff d0                	call   rax
    71dc01867614:	83 38 05             	cmp    DWORD PTR [rax],0x5
    71dc01867617:	0f 8e 17 11 00 00    	jle    0x71dc01868734
    71dc0186761d:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc01867621:	48 8b 47 28          	mov    rax,QWORD PTR [rdi+0x28]
    71dc01867625:	48 85 c0             	test   rax,rax
    71dc01867628:	0f 84 06 11 00 00    	je     0x71dc01868734
    71dc0186762e:	4c 8b 70 10          	mov    r14,QWORD PTR [rax+0x10]
    71dc01867632:	4d 85 f6             	test   r14,r14
    71dc01867635:	75 09                	jne    0x71dc01867640
    71dc01867637:	ff 15 53 dc 2a ff    	call   QWORD PTR [rip+0xffffffffff2adc53]        # 0x71dc00b15290
    71dc0186763d:	4c 8b f0             	mov    r14,rax
    71dc01867640:	4c 89 b5 38 fd ff ff 	mov    QWORD PTR [rbp-0x2c8],r14
    71dc01867647:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
    71dc0186764b:	48 89 b5 30 fd ff ff 	mov    QWORD PTR [rbp-0x2d0],rsi
    71dc01867652:	49 8b 76 10          	mov    rsi,QWORD PTR [r14+0x10]
    71dc01867656:	48 89 b5 28 fd ff ff 	mov    QWORD PTR [rbp-0x2d8],rsi
    71dc0186765d:	48 8d bd c0 fd ff ff 	lea    rdi,[rbp-0x240]
    71dc01867664:	ff 15 06 d2 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7d206]        # 0x71dc016e4870
    71dc0186766a:	90                   	nop
    71dc0186766b:	48 8b b5 28 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2d8]
    71dc01867672:	49 3b 76 10          	cmp    rsi,QWORD PTR [r14+0x10]
    71dc01867676:	0f 85 c7 10 00 00    	jne    0x71dc01868743
    71dc0186767c:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
    71dc01867680:	48 39 95 30 fd ff ff 	cmp    QWORD PTR [rbp-0x2d0],rdx
    71dc01867687:	0f 85 c4 10 00 00    	jne    0x71dc01868751
    71dc0186768d:	48 8b bd d0 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x230]
    71dc01867694:	48 b8 68 1b 80 21 d4 	movabs rax,0x71d421801b68
    71dc0186769b:	71 00 00 
    71dc0186769e:	48 3b 38             	cmp    rdi,QWORD PTR [rax]
    71dc018676a1:	0f 85 bf 10 00 00    	jne    0x71dc01868766
    71dc018676a7:	48 8b 85 d8 fd ff ff 	mov    rax,QWORD PTR [rbp-0x228]
    71dc018676ae:	45 33 f6             	xor    r14d,r14d
    71dc018676b1:	4c 89 75 b0          	mov    QWORD PTR [rbp-0x50],r14
    71dc018676b5:	48 89 45 b8          	mov    QWORD PTR [rbp-0x48],rax
    71dc018676b9:	66 c7 45 c0 00 00    	mov    WORD PTR [rbp-0x40],0x0
    71dc018676bf:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc018676c3:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc018676c7:	4d 85 f6             	test   r14,r14
    71dc018676ca:	0f 85 cb 10 00 00    	jne    0x71dc0186879b
    71dc018676d0:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc018676d4:	4d 85 f6             	test   r14,r14
    71dc018676d7:	0f 85 8f 11 00 00    	jne    0x71dc0186886c
    71dc018676dd:	48 8b 75 b8          	mov    rsi,QWORD PTR [rbp-0x48]
    71dc018676e1:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    71dc018676e5:	e8 16 93 7e 7c       	call   0x71dc7e050a00
    71dc018676ea:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc018676ef:	0f 85 d4 11 00 00    	jne    0x71dc018688c9
    71dc018676f5:	48 bf a0 27 e6 ff db 	movabs rdi,0x71dbffe627a0
    71dc018676fc:	71 00 00 
    71dc018676ff:	be 01 00 00 00       	mov    esi,0x1
    71dc01867704:	e8 47 9d 7e 7c       	call   0x71dc7e051450
    71dc01867709:	4c 8b f0             	mov    r14,rax
    71dc0186770c:	49 8b 77 10          	mov    rsi,QWORD PTR [r15+0x10]
    71dc01867710:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc01867714:	e8 27 89 3b fd       	call   0x71dbfec20040
    71dc01867719:	48 8b 53 20          	mov    rdx,QWORD PTR [rbx+0x20]
    71dc0186771d:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc01867721:	49 8b fe             	mov    rdi,r14
    71dc01867724:	ff 15 4e c9 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7c94e]        # 0x71dc015e4078
    71dc0186772a:	4c 8b f0             	mov    r14,rax
    71dc0186772d:	48 be d8 c5 28 01 dc 	movabs rsi,0x71dc0128c5d8
    71dc01867734:	71 00 00 
    71dc01867737:	49 39 36             	cmp    QWORD PTR [r14],rsi
    71dc0186773a:	74 12                	je     0x71dc0186774e
    71dc0186773c:	49 8b f6             	mov    rsi,r14
    71dc0186773f:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc01867746:	71 00 00 
    71dc01867749:	e8 a2 db fd ff       	call   0x71dc018452f0
    71dc0186774e:	4d 8b 6e 08          	mov    r13,QWORD PTR [r14+0x8]
    71dc01867752:	45 8b 66 10          	mov    r12d,DWORD PTR [r14+0x10]
    71dc01867756:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc0186775a:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc0186775e:	49 bb 10 8b 6f 01 dc 	movabs r11,0x71dc016f8b10
    71dc01867765:	71 00 00 
    71dc01867768:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc0186776b:	0f 85 f0 12 00 00    	jne    0x71dc01868a61
    71dc01867771:	44 8b 77 18          	mov    r14d,DWORD PTR [rdi+0x18]
    71dc01867775:	49 63 fe             	movsxd rdi,r14d
    71dc01867778:	4d 85 ed             	test   r13,r13
    71dc0186777b:	0f 85 f5 12 00 00    	jne    0x71dc01868a76
    71dc01867781:	4d 63 dc             	movsxd r11,r12d
    71dc01867784:	4c 3b df             	cmp    r11,rdi
    71dc01867787:	0f 9f c0             	setg   al
    71dc0186778a:	0f b6 c0             	movzx  eax,al
    71dc0186778d:	b9 ff ff ff ff       	mov    ecx,0xffffffff
    71dc01867792:	0f 4c c1             	cmovl  eax,ecx
    71dc01867795:	85 c0                	test   eax,eax
    71dc01867797:	0f 8c 2a 13 00 00    	jl     0x71dc01868ac7
    71dc0186779d:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc018677a1:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc018677a5:	49 bb 10 8b 6f 01 dc 	movabs r11,0x71dc016f8b10
    71dc018677ac:	71 00 00 
    71dc018677af:	4c 39 1f             	cmp    QWORD PTR [rdi],r11
    71dc018677b2:	0f 85 7f 13 00 00    	jne    0x71dc01868b37
    71dc018677b8:	44 8b 77 18          	mov    r14d,DWORD PTR [rdi+0x18]
    71dc018677bc:	49 63 fe             	movsxd rdi,r14d
    71dc018677bf:	4d 85 ed             	test   r13,r13
    71dc018677c2:	0f 85 84 13 00 00    	jne    0x71dc01868b4c
    71dc018677c8:	4d 63 dc             	movsxd r11,r12d
    71dc018677cb:	4c 3b df             	cmp    r11,rdi
    71dc018677ce:	0f 9f c0             	setg   al
    71dc018677d1:	0f b6 c0             	movzx  eax,al
    71dc018677d4:	b9 ff ff ff ff       	mov    ecx,0xffffffff
    71dc018677d9:	0f 4c c1             	cmovl  eax,ecx
    71dc018677dc:	85 c0                	test   eax,eax
    71dc018677de:	0f 8f bd 13 00 00    	jg     0x71dc01868ba1
    71dc018677e4:	49 8b 77 50          	mov    rsi,QWORD PTR [r15+0x50]
    71dc018677e8:	41 be 01 00 00 00    	mov    r14d,0x1
    71dc018677ee:	e9 3e 1a 00 00       	jmp    0x71dc01869231
    71dc018677f3:	8b 75 d4             	mov    esi,DWORD PTR [rbp-0x2c]
    71dc018677f6:	48 8d 05 af 1c 00 00 	lea    rax,[rip+0x1caf]        # 0x71dc018694ac
    71dc018677fd:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    71dc01867800:	48 8d 0d d7 f0 ff ff 	lea    rcx,[rip+0xfffffffffffff0d7]        # 0x71dc018668de
    71dc01867807:	48 03 c1             	add    rax,rcx
    71dc0186780a:	ff e0                	jmp    rax
    71dc0186780c:	48 be 90 7b 60 01 dc 	movabs rsi,0x71dc01607b90
    71dc01867813:	71 00 00 
    71dc01867816:	49 39 37             	cmp    QWORD PTR [r15],rsi
    71dc01867819:	0f 85 aa f1 ff ff    	jne    0x71dc018669c9
    71dc0186781f:	48 8d b5 30 fe ff ff 	lea    rsi,[rbp-0x1d0]
    71dc01867826:	49 8b ff             	mov    rdi,r15
    71dc01867829:	ff 15 69 cf e7 ff    	call   QWORD PTR [rip+0xffffffffffe7cf69]        # 0x71dc016e4798
    71dc0186782f:	44 8b e0             	mov    r12d,eax
    71dc01867832:	45 85 e4             	test   r12d,r12d
    71dc01867835:	74 6e                	je     0x71dc018678a5
    71dc01867837:	49 8b ff             	mov    rdi,r15
    71dc0186783a:	48 8b b5 30 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1d0]
    71dc01867841:	49 8b d6             	mov    rdx,r14
    71dc01867844:	49 8b cd             	mov    rcx,r13
    71dc01867847:	ff 15 7b 5e d8 ff    	call   QWORD PTR [rip+0xffffffffffd85e7b]        # 0x71dc015ed6c8
    71dc0186784d:	48 8b f8             	mov    rdi,rax
    71dc01867850:	49 8b f6             	mov    rsi,r14
    71dc01867853:	49 8b d5             	mov    rdx,r13
    71dc01867856:	ff 15 54 cf e7 ff    	call   QWORD PTR [rip+0xffffffffffe7cf54]        # 0x71dc016e47b0
    71dc0186785c:	4c 8b f8             	mov    r15,rax
    71dc0186785f:	48 bf 08 b3 82 01 dc 	movabs rdi,0x71dc0182b308
    71dc01867866:	71 00 00 
    71dc01867869:	e8 b2 d4 fd ff       	call   0x71dc01844d20
    71dc0186786e:	48 bf 88 1c 80 21 d4 	movabs rdi,0x71d421801c88
    71dc01867875:	71 00 00 
    71dc01867878:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc0186787b:	49 8b ff             	mov    rdi,r15
    71dc0186787e:	49 8b ce             	mov    rcx,r14
    71dc01867881:	49 8b d5             	mov    rdx,r13
    71dc01867884:	49 bb c8 35 c4 fe db 	movabs r11,0x71dbfec435c8
    71dc0186788b:	71 00 00 
    71dc0186788e:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867891:	48 8b f0             	mov    rsi,rax
    71dc01867894:	41 8b fc             	mov    edi,r12d
    71dc01867897:	49 8b d5             	mov    rdx,r13
    71dc0186789a:	ff 15 28 cf e7 ff    	call   QWORD PTR [rip+0xffffffffffe7cf28]        # 0x71dc016e47c8
    71dc018678a0:	e9 2d f1 ff ff       	jmp    0x71dc018669d2
    71dc018678a5:	b8 01 00 00 00       	mov    eax,0x1
    71dc018678aa:	e9 23 f1 ff ff       	jmp    0x71dc018669d2
    71dc018678af:	4c 8b 7b 40          	mov    r15,QWORD PTR [rbx+0x40]
    71dc018678b3:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc018678ba:	71 00 00 
    71dc018678bd:	e8 fe 99 7e 7c       	call   0x71dc7e0512c0
    71dc018678c2:	4c 8b f0             	mov    r14,rax
    71dc018678c5:	48 bf 60 3d 80 21 d4 	movabs rdi,0x71d421803d60
    71dc018678cc:	71 00 00 
    71dc018678cf:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    71dc018678d2:	49 83 c5 08          	add    r13,0x8
    71dc018678d6:	4d 8d 66 08          	lea    r12,[r14+0x8]
    71dc018678da:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
    71dc018678de:	49 8b fc             	mov    rdi,r12
    71dc018678e1:	e8 5a 87 3b fd       	call   0x71dbfec20040
    71dc018678e6:	49 8b 4d 08          	mov    rcx,QWORD PTR [r13+0x8]
    71dc018678ea:	49 89 4c 24 08       	mov    QWORD PTR [r12+0x8],rcx
    71dc018678ef:	49 8b ce             	mov    rcx,r14
    71dc018678f2:	4c 8b 4b 28          	mov    r9,QWORD PTR [rbx+0x28]
    71dc018678f6:	4c 8b 43 20          	mov    r8,QWORD PTR [rbx+0x20]
    71dc018678fa:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    71dc018678fe:	49 8b d7             	mov    rdx,r15
    71dc01867901:	be 0f 00 00 00       	mov    esi,0xf
    71dc01867906:	ff 15 94 7f d8 ff    	call   QWORD PTR [rip+0xffffffffffd87f94]        # 0x71dc015ef8a0
    71dc0186790c:	48 8b 75 98          	mov    rsi,QWORD PTR [rbp-0x68]
    71dc01867910:	48 8b 7d a0          	mov    rdi,QWORD PTR [rbp-0x60]
    71dc01867914:	48 0f bf 45 a8       	movsx  rax,WORD PTR [rbp-0x58]
    71dc01867919:	48 89 75 b0          	mov    QWORD PTR [rbp-0x50],rsi
    71dc0186791d:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
    71dc01867921:	66 89 45 c0          	mov    WORD PTR [rbp-0x40],ax
    71dc01867925:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc01867929:	4c 8b 7d b0          	mov    r15,QWORD PTR [rbp-0x50]
    71dc0186792d:	4d 85 ff             	test   r15,r15
    71dc01867930:	0f 84 c7 00 00 00    	je     0x71dc018679fd
    71dc01867936:	49 8b f7             	mov    rsi,r15
    71dc01867939:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01867940:	71 00 00 
    71dc01867943:	e8 38 d4 fd ff       	call   0x71dc01844d80
    71dc01867948:	48 85 c0             	test   rax,rax
    71dc0186794b:	74 11                	je     0x71dc0186795e
    71dc0186794d:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01867954:	41 0f 95 c6          	setne  r14b
    71dc01867958:	45 0f b6 f6          	movzx  r14d,r14b
    71dc0186795c:	eb 1f                	jmp    0x71dc0186797d
    71dc0186795e:	49 8b ff             	mov    rdi,r15
    71dc01867961:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01867966:	49 bb a8 35 c4 fe db 	movabs r11,0x71dbfec435a8
    71dc0186796d:	71 00 00 
    71dc01867970:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867973:	85 c0                	test   eax,eax
    71dc01867975:	41 0f 95 c6          	setne  r14b
    71dc01867979:	45 0f b6 f6          	movzx  r14d,r14b
    71dc0186797d:	45 85 f6             	test   r14d,r14d
    71dc01867980:	75 7b                	jne    0x71dc018679fd
    71dc01867982:	33 ff                	xor    edi,edi
    71dc01867984:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc0186798b:	41 89 7f 28          	mov    DWORD PTR [r15+0x28],edi
    71dc0186798f:	49 8d 7f 58          	lea    rdi,[r15+0x58]
    71dc01867993:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01867997:	ba 18 00 00 00       	mov    edx,0x18
    71dc0186799c:	c5 f8 77             	vzeroupper
    71dc0186799f:	e8 9c 29 fe ff       	call   0x71dc0184a340
    71dc018679a4:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc018679a8:	49 8b ff             	mov    rdi,r15
    71dc018679ab:	ff 15 37 ed f7 ff    	call   QWORD PTR [rip+0xfffffffffff7ed37]        # 0x71dc017e66e8
    71dc018679b1:	48 8b d0             	mov    rdx,rax
    71dc018679b4:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc018679b8:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc018679bf:	71 00 00 
    71dc018679c2:	ff 15 38 ed f7 ff    	call   QWORD PTR [rip+0xfffffffffff7ed38]        # 0x71dc017e6700
    71dc018679c8:	e9 98 18 00 00       	jmp    0x71dc01869265
    71dc018679cd:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc018679d1:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc018679d5:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc018679da:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc018679de:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc018679e2:	33 c0                	xor    eax,eax
    71dc018679e4:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc018679e7:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc018679eb:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc018679ef:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc018679f6:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc018679fd:	4c 8b 7d b0          	mov    r15,QWORD PTR [rbp-0x50]
    71dc01867a01:	4d 85 ff             	test   r15,r15
    71dc01867a04:	75 06                	jne    0x71dc01867a0c
    71dc01867a06:	4c 8b 7d b8          	mov    r15,QWORD PTR [rbp-0x48]
    71dc01867a0a:	eb 55                	jmp    0x71dc01867a61
    71dc01867a0c:	49 8b f7             	mov    rsi,r15
    71dc01867a0f:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01867a16:	71 00 00 
    71dc01867a19:	e8 62 d3 fd ff       	call   0x71dc01844d80
    71dc01867a1e:	4c 8b f0             	mov    r14,rax
    71dc01867a21:	4d 85 f6             	test   r14,r14
    71dc01867a24:	74 23                	je     0x71dc01867a49
    71dc01867a26:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    71dc01867a2a:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01867a30:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01867a36:	74 0b                	je     0x71dc01867a43
    71dc01867a38:	49 8b fe             	mov    rdi,r14
    71dc01867a3b:	33 f6                	xor    esi,esi
    71dc01867a3d:	ff 15 d5 dd 2a ff    	call   QWORD PTR [rip+0xffffffffff2addd5]        # 0x71dc00b15818
    71dc01867a43:	4d 8b 7e 38          	mov    r15,QWORD PTR [r14+0x38]
    71dc01867a47:	eb 18                	jmp    0x71dc01867a61
    71dc01867a49:	49 8b ff             	mov    rdi,r15
    71dc01867a4c:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01867a51:	49 bb b0 35 c4 fe db 	movabs r11,0x71dbfec435b0
    71dc01867a58:	71 00 00 
    71dc01867a5b:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867a5e:	4c 8b f8             	mov    r15,rax
    71dc01867a61:	e9 41 ef ff ff       	jmp    0x71dc018669a7
    71dc01867a66:	49 8b ff             	mov    rdi,r15
    71dc01867a69:	49 8b f6             	mov    rsi,r14
    71dc01867a6c:	48 8b 95 60 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a0]
    71dc01867a73:	ff 15 a7 82 d8 ff    	call   QWORD PTR [rip+0xffffffffffd882a7]        # 0x71dc015efd20
    71dc01867a79:	89 85 54 fe ff ff    	mov    DWORD PTR [rbp-0x1ac],eax
    71dc01867a7f:	85 c0                	test   eax,eax
    71dc01867a81:	74 50                	je     0x71dc01867ad3
    71dc01867a83:	4c 8d 8d 38 fe ff ff 	lea    r9,[rbp-0x1c8]
    71dc01867a8a:	49 8b fe             	mov    rdi,r14
    71dc01867a8d:	48 8b b5 60 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1a0]
    71dc01867a94:	49 8b d7             	mov    rdx,r15
    71dc01867a97:	49 8b cd             	mov    rcx,r13
    71dc01867a9a:	4d 8b c4             	mov    r8,r12
    71dc01867a9d:	ff 15 95 82 d8 ff    	call   QWORD PTR [rip+0xffffffffffd88295]        # 0x71dc015efd38
    71dc01867aa3:	85 c0                	test   eax,eax
    71dc01867aa5:	74 2c                	je     0x71dc01867ad3
    71dc01867aa7:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
    71dc01867aae:	48 bf 40 ab 5c 01 dc 	movabs rdi,0x71dc015cab40
    71dc01867ab5:	71 00 00 
    71dc01867ab8:	e8 c3 d2 fd ff       	call   0x71dc01844d80
    71dc01867abd:	48 85 c0             	test   rax,rax
    71dc01867ac0:	75 11                	jne    0x71dc01867ad3
    71dc01867ac2:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
    71dc01867ac9:	bf 01 00 00 00       	mov    edi,0x1
    71dc01867ace:	e9 a0 ee ff ff       	jmp    0x71dc01866973
    71dc01867ad3:	4c 8d 8d 48 fe ff ff 	lea    r9,[rbp-0x1b8]
    71dc01867ada:	49 8b ff             	mov    rdi,r15
    71dc01867add:	48 8b b5 58 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1a8]
    71dc01867ae4:	49 8b d6             	mov    rdx,r14
    71dc01867ae7:	49 8b cd             	mov    rcx,r13
    71dc01867aea:	4d 8b c4             	mov    r8,r12
    71dc01867aed:	ff 15 45 82 d8 ff    	call   QWORD PTR [rip+0xffffffffffd88245]        # 0x71dc015efd38
    71dc01867af3:	85 c0                	test   eax,eax
    71dc01867af5:	74 24                	je     0x71dc01867b1b
    71dc01867af7:	48 8b b5 48 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b8]
    71dc01867afe:	48 bf 40 ab 5c 01 dc 	movabs rdi,0x71dc015cab40
    71dc01867b05:	71 00 00 
    71dc01867b08:	e8 73 d2 fd ff       	call   0x71dc01844d80
    71dc01867b0d:	48 85 c0             	test   rax,rax
    71dc01867b10:	75 09                	jne    0x71dc01867b1b
    71dc01867b12:	48 8b 85 48 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b8]
    71dc01867b19:	eb ae                	jmp    0x71dc01867ac9
    71dc01867b1b:	83 bd 54 fe ff ff 00 	cmp    DWORD PTR [rbp-0x1ac],0x0
    71dc01867b22:	0f 85 3c ee ff ff    	jne    0x71dc01866964
    71dc01867b28:	49 8b ff             	mov    rdi,r15
    71dc01867b2b:	49 8b f6             	mov    rsi,r14
    71dc01867b2e:	ff 15 34 82 d8 ff    	call   QWORD PTR [rip+0xffffffffffd88234]        # 0x71dc015efd68
    71dc01867b34:	85 c0                	test   eax,eax
    71dc01867b36:	0f 85 28 ee ff ff    	jne    0x71dc01866964
    71dc01867b3c:	4c 8d 8d 40 fe ff ff 	lea    r9,[rbp-0x1c0]
    71dc01867b43:	49 8b fe             	mov    rdi,r14
    71dc01867b46:	48 8b b5 60 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1a0]
    71dc01867b4d:	49 8b d7             	mov    rdx,r15
    71dc01867b50:	49 8b cd             	mov    rcx,r13
    71dc01867b53:	4d 8b c4             	mov    r8,r12
    71dc01867b56:	ff 15 dc 81 d8 ff    	call   QWORD PTR [rip+0xffffffffffd881dc]        # 0x71dc015efd38
    71dc01867b5c:	85 c0                	test   eax,eax
    71dc01867b5e:	0f 84 00 ee ff ff    	je     0x71dc01866964
    71dc01867b64:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
    71dc01867b6b:	48 bf 40 ab 5c 01 dc 	movabs rdi,0x71dc015cab40
    71dc01867b72:	71 00 00 
    71dc01867b75:	e8 06 d2 fd ff       	call   0x71dc01844d80
    71dc01867b7a:	48 85 c0             	test   rax,rax
    71dc01867b7d:	0f 85 e1 ed ff ff    	jne    0x71dc01866964
    71dc01867b83:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
    71dc01867b8a:	e9 3a ff ff ff       	jmp    0x71dc01867ac9
    71dc01867b8f:	4c 8b f8             	mov    r15,rax
    71dc01867b92:	e9 10 ee ff ff       	jmp    0x71dc018669a7
    71dc01867b97:	48 8b 53 28          	mov    rdx,QWORD PTR [rbx+0x28]
    71dc01867b9b:	48 8b 73 20          	mov    rsi,QWORD PTR [rbx+0x20]
    71dc01867b9f:	49 8b ff             	mov    rdi,r15
    71dc01867ba2:	ff 15 e8 77 d8 ff    	call   QWORD PTR [rip+0xffffffffffd877e8]        # 0x71dc015ef390
    71dc01867ba8:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    71dc01867baf:	48 89 55 80          	mov    QWORD PTR [rbp-0x80],rdx
    71dc01867bb3:	48 8b b5 78 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x88]
    71dc01867bba:	40 0f b6 7d 82       	rex movzx edi,BYTE PTR [rbp-0x7e]
    71dc01867bbf:	48 0f bf 45 80       	movsx  rax,WORD PTR [rbp-0x80]
    71dc01867bc4:	48 89 75 88          	mov    QWORD PTR [rbp-0x78],rsi
    71dc01867bc8:	66 89 45 90          	mov    WORD PTR [rbp-0x70],ax
    71dc01867bcc:	40 88 7d 92          	mov    BYTE PTR [rbp-0x6e],dil
    71dc01867bd0:	c6 45 93 00          	mov    BYTE PTR [rbp-0x6d],0x0
    71dc01867bd4:	4c 8b 7d 88          	mov    r15,QWORD PTR [rbp-0x78]
    71dc01867bd8:	4d 85 ff             	test   r15,r15
    71dc01867bdb:	0f 84 a7 00 00 00    	je     0x71dc01867c88
    71dc01867be1:	49 8b f7             	mov    rsi,r15
    71dc01867be4:	48 bf 10 d2 e6 00 dc 	movabs rdi,0x71dc00e6d210
    71dc01867beb:	71 00 00 
    71dc01867bee:	e8 8d d1 fd ff       	call   0x71dc01844d80
    71dc01867bf3:	48 85 c0             	test   rax,rax
    71dc01867bf6:	74 0f                	je     0x71dc01867c07
    71dc01867bf8:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01867bff:	0f 85 83 00 00 00    	jne    0x71dc01867c88
    71dc01867c05:	eb 19                	jmp    0x71dc01867c20
    71dc01867c07:	49 8b ff             	mov    rdi,r15
    71dc01867c0a:	48 0f bf 75 90       	movsx  rsi,WORD PTR [rbp-0x70]
    71dc01867c0f:	49 bb b8 35 c4 fe db 	movabs r11,0x71dbfec435b8
    71dc01867c16:	71 00 00 
    71dc01867c19:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867c1c:	85 c0                	test   eax,eax
    71dc01867c1e:	75 68                	jne    0x71dc01867c88
    71dc01867c20:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01867c27:	41 c7 47 28 01 00 00 	mov    DWORD PTR [r15+0x28],0x1
    71dc01867c2e:	00 
    71dc01867c2f:	49 8d 5f 70          	lea    rbx,[r15+0x70]
    71dc01867c33:	48 8b 75 88          	mov    rsi,QWORD PTR [rbp-0x78]
    71dc01867c37:	48 8b fb             	mov    rdi,rbx
    71dc01867c3a:	e8 c1 8d 7e 7c       	call   0x71dc7e050a00
    71dc01867c3f:	48 8b 75 90          	mov    rsi,QWORD PTR [rbp-0x70]
    71dc01867c43:	48 89 73 08          	mov    QWORD PTR [rbx+0x8],rsi
    71dc01867c47:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01867c4b:	49 8b ff             	mov    rdi,r15
    71dc01867c4e:	ff 15 94 ea f7 ff    	call   QWORD PTR [rip+0xfffffffffff7ea94]        # 0x71dc017e66e8
    71dc01867c54:	48 8b f0             	mov    rsi,rax
    71dc01867c57:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc01867c5b:	ff 15 a7 eb f7 ff    	call   QWORD PTR [rip+0xfffffffffff7eba7]        # 0x71dc017e6808
    71dc01867c61:	e9 ff 15 00 00       	jmp    0x71dc01869265
    71dc01867c66:	c5 fa 6f 47 70       	vmovdqu xmm0,XMMWORD PTR [rdi+0x70]
    71dc01867c6b:	c5 fa 7f 45 88       	vmovdqu XMMWORD PTR [rbp-0x78],xmm0
    71dc01867c70:	33 f6                	xor    esi,esi
    71dc01867c72:	48 89 77 70          	mov    QWORD PTR [rdi+0x70],rsi
    71dc01867c76:	48 89 77 78          	mov    QWORD PTR [rdi+0x78],rsi
    71dc01867c7a:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01867c81:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01867c88:	4c 8b 7d 88          	mov    r15,QWORD PTR [rbp-0x78]
    71dc01867c8c:	4d 85 ff             	test   r15,r15
    71dc01867c8f:	75 06                	jne    0x71dc01867c97
    71dc01867c91:	0f b6 45 92          	movzx  eax,BYTE PTR [rbp-0x6e]
    71dc01867c95:	eb 53                	jmp    0x71dc01867cea
    71dc01867c97:	49 8b f7             	mov    rsi,r15
    71dc01867c9a:	48 bf 10 d2 e6 00 dc 	movabs rdi,0x71dc00e6d210
    71dc01867ca1:	71 00 00 
    71dc01867ca4:	e8 d7 d0 fd ff       	call   0x71dc01844d80
    71dc01867ca9:	4c 8b f0             	mov    r14,rax
    71dc01867cac:	4d 85 f6             	test   r14,r14
    71dc01867caf:	74 24                	je     0x71dc01867cd5
    71dc01867cb1:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    71dc01867cb5:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01867cbb:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01867cc1:	74 0b                	je     0x71dc01867cce
    71dc01867cc3:	49 8b fe             	mov    rdi,r14
    71dc01867cc6:	33 f6                	xor    esi,esi
    71dc01867cc8:	ff 15 4a db 2a ff    	call   QWORD PTR [rip+0xffffffffff2adb4a]        # 0x71dc00b15818
    71dc01867cce:	41 0f b6 46 38       	movzx  eax,BYTE PTR [r14+0x38]
    71dc01867cd3:	eb 15                	jmp    0x71dc01867cea
    71dc01867cd5:	49 8b ff             	mov    rdi,r15
    71dc01867cd8:	48 0f bf 75 90       	movsx  rsi,WORD PTR [rbp-0x70]
    71dc01867cdd:	49 bb c0 35 c4 fe db 	movabs r11,0x71dbfec435c0
    71dc01867ce4:	71 00 00 
    71dc01867ce7:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867cea:	e9 ec ec ff ff       	jmp    0x71dc018669db
    71dc01867cef:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01867cf6:	41 0f b6 57 34       	movzx  edx,BYTE PTR [r15+0x34]
    71dc01867cfb:	48 8d 75 98          	lea    rsi,[rbp-0x68]
    71dc01867cff:	48 8b fb             	mov    rdi,rbx
    71dc01867d02:	ff 15 c8 7b d8 ff    	call   QWORD PTR [rip+0xffffffffffd87bc8]        # 0x71dc015ef8d0
    71dc01867d08:	48 8b 75 98          	mov    rsi,QWORD PTR [rbp-0x68]
    71dc01867d0c:	48 8b 7d a0          	mov    rdi,QWORD PTR [rbp-0x60]
    71dc01867d10:	48 0f bf 45 a8       	movsx  rax,WORD PTR [rbp-0x58]
    71dc01867d15:	48 89 75 b0          	mov    QWORD PTR [rbp-0x50],rsi
    71dc01867d19:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
    71dc01867d1d:	66 89 45 c0          	mov    WORD PTR [rbp-0x40],ax
    71dc01867d21:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc01867d25:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01867d29:	4d 85 f6             	test   r14,r14
    71dc01867d2c:	0f 84 cc 00 00 00    	je     0x71dc01867dfe
    71dc01867d32:	49 8b f6             	mov    rsi,r14
    71dc01867d35:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01867d3c:	71 00 00 
    71dc01867d3f:	e8 3c d0 fd ff       	call   0x71dc01844d80
    71dc01867d44:	48 85 c0             	test   rax,rax
    71dc01867d47:	74 11                	je     0x71dc01867d5a
    71dc01867d49:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01867d50:	41 0f 95 c5          	setne  r13b
    71dc01867d54:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01867d58:	eb 1f                	jmp    0x71dc01867d79
    71dc01867d5a:	49 8b fe             	mov    rdi,r14
    71dc01867d5d:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01867d62:	49 bb d0 35 c4 fe db 	movabs r11,0x71dbfec435d0
    71dc01867d69:	71 00 00 
    71dc01867d6c:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867d6f:	85 c0                	test   eax,eax
    71dc01867d71:	41 0f 95 c5          	setne  r13b
    71dc01867d75:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01867d79:	45 85 ed             	test   r13d,r13d
    71dc01867d7c:	0f 85 7c 00 00 00    	jne    0x71dc01867dfe
    71dc01867d82:	41 c7 47 28 02 00 00 	mov    DWORD PTR [r15+0x28],0x2
    71dc01867d89:	00 
    71dc01867d8a:	49 8d 77 58          	lea    rsi,[r15+0x58]
    71dc01867d8e:	48 8b fe             	mov    rdi,rsi
    71dc01867d91:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01867d95:	ba 18 00 00 00       	mov    edx,0x18
    71dc01867d9a:	c5 f8 77             	vzeroupper
    71dc01867d9d:	e8 9e 25 fe ff       	call   0x71dc0184a340
    71dc01867da2:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01867da6:	49 8b ff             	mov    rdi,r15
    71dc01867da9:	ff 15 39 e9 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e939]        # 0x71dc017e66e8
    71dc01867daf:	48 8b d0             	mov    rdx,rax
    71dc01867db2:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01867db6:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc01867dbd:	71 00 00 
    71dc01867dc0:	ff 15 3a e9 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e93a]        # 0x71dc017e6700
    71dc01867dc6:	e9 9a 14 00 00       	jmp    0x71dc01869265
    71dc01867dcb:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc01867dcf:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc01867dd3:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc01867dd8:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc01867ddc:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc01867de0:	33 c0                	xor    eax,eax
    71dc01867de2:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc01867de5:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc01867de9:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc01867ded:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01867df4:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01867dfb:	4c 8b ff             	mov    r15,rdi
    71dc01867dfe:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01867e02:	4d 85 f6             	test   r14,r14
    71dc01867e05:	0f 84 d8 eb ff ff    	je     0x71dc018669e3
    71dc01867e0b:	49 8b f6             	mov    rsi,r14
    71dc01867e0e:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01867e15:	71 00 00 
    71dc01867e18:	e8 63 cf fd ff       	call   0x71dc01844d80
    71dc01867e1d:	48 85 c0             	test   rax,rax
    71dc01867e20:	74 25                	je     0x71dc01867e47
    71dc01867e22:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    71dc01867e25:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01867e2b:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01867e31:	0f 84 ac eb ff ff    	je     0x71dc018669e3
    71dc01867e37:	48 8b f8             	mov    rdi,rax
    71dc01867e3a:	33 f6                	xor    esi,esi
    71dc01867e3c:	ff 15 d6 d9 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad9d6]        # 0x71dc00b15818
    71dc01867e42:	e9 9c eb ff ff       	jmp    0x71dc018669e3
    71dc01867e47:	49 8b fe             	mov    rdi,r14
    71dc01867e4a:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01867e4f:	49 bb d8 35 c4 fe db 	movabs r11,0x71dbfec435d8
    71dc01867e56:	71 00 00 
    71dc01867e59:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867e5c:	e9 82 eb ff ff       	jmp    0x71dc018669e3
    71dc01867e61:	48 8b 7b 30          	mov    rdi,QWORD PTR [rbx+0x30]
    71dc01867e65:	48 8d b5 48 ff ff ff 	lea    rsi,[rbp-0xb8]
    71dc01867e6c:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01867e6e:	ff 15 8c 7a d8 ff    	call   QWORD PTR [rip+0xffffffffffd87a8c]        # 0x71dc015ef900
    71dc01867e74:	48 8b b5 48 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb8]
    71dc01867e7b:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc01867e82:	48 0f bf 85 58 ff ff 	movsx  rax,WORD PTR [rbp-0xa8]
    71dc01867e89:	ff 
    71dc01867e8a:	48 89 b5 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rsi
    71dc01867e91:	48 89 bd 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdi
    71dc01867e98:	66 89 85 70 ff ff ff 	mov    WORD PTR [rbp-0x90],ax
    71dc01867e9f:	c6 85 72 ff ff ff 00 	mov    BYTE PTR [rbp-0x8e],0x0
    71dc01867ea6:	4c 8b b5 60 ff ff ff 	mov    r14,QWORD PTR [rbp-0xa0]
    71dc01867ead:	4d 85 f6             	test   r14,r14
    71dc01867eb0:	0f 84 e6 00 00 00    	je     0x71dc01867f9c
    71dc01867eb6:	49 8b f6             	mov    rsi,r14
    71dc01867eb9:	48 bf f0 ba 82 01 dc 	movabs rdi,0x71dc0182baf0
    71dc01867ec0:	71 00 00 
    71dc01867ec3:	e8 b8 ce fd ff       	call   0x71dc01844d80
    71dc01867ec8:	48 85 c0             	test   rax,rax
    71dc01867ecb:	74 11                	je     0x71dc01867ede
    71dc01867ecd:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01867ed4:	41 0f 95 c5          	setne  r13b
    71dc01867ed8:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01867edc:	eb 22                	jmp    0x71dc01867f00
    71dc01867ede:	49 8b fe             	mov    rdi,r14
    71dc01867ee1:	48 0f bf b5 70 ff ff 	movsx  rsi,WORD PTR [rbp-0x90]
    71dc01867ee8:	ff 
    71dc01867ee9:	49 bb e0 35 c4 fe db 	movabs r11,0x71dbfec435e0
    71dc01867ef0:	71 00 00 
    71dc01867ef3:	41 ff 13             	call   QWORD PTR [r11]
    71dc01867ef6:	85 c0                	test   eax,eax
    71dc01867ef8:	41 0f 95 c5          	setne  r13b
    71dc01867efc:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01867f00:	45 85 ed             	test   r13d,r13d
    71dc01867f03:	0f 85 93 00 00 00    	jne    0x71dc01867f9c
    71dc01867f09:	41 c7 47 28 03 00 00 	mov    DWORD PTR [r15+0x28],0x3
    71dc01867f10:	00 
    71dc01867f11:	49 8d bf 80 00 00 00 	lea    rdi,[r15+0x80]
    71dc01867f18:	48 8d b5 60 ff ff ff 	lea    rsi,[rbp-0xa0]
    71dc01867f1f:	ba 18 00 00 00       	mov    edx,0x18
    71dc01867f24:	c5 f8 77             	vzeroupper
    71dc01867f27:	e8 14 24 fe ff       	call   0x71dc0184a340
    71dc01867f2c:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01867f30:	49 8b ff             	mov    rdi,r15
    71dc01867f33:	ff 15 af e7 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e7af]        # 0x71dc017e66e8
    71dc01867f39:	48 8b d0             	mov    rdx,rax
    71dc01867f3c:	48 8d b5 60 ff ff ff 	lea    rsi,[rbp-0xa0]
    71dc01867f43:	48 bf 98 43 8d 01 dc 	movabs rdi,0x71dc018d4398
    71dc01867f4a:	71 00 00 
    71dc01867f4d:	ff 15 ad e7 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e7ad]        # 0x71dc017e6700
    71dc01867f53:	e9 0d 13 00 00       	jmp    0x71dc01869265
    71dc01867f58:	62 f1 7e 08 6f 47 08 	vmovdqu32 xmm0,XMMWORD PTR [rdi+0x80]
    71dc01867f5f:	62 f1 7e 08 7f 45 f6 	vmovdqu32 XMMWORD PTR [rbp-0xa0],xmm0
    71dc01867f66:	48 8b b7 90 00 00 00 	mov    rsi,QWORD PTR [rdi+0x90]
    71dc01867f6d:	48 89 b5 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rsi
    71dc01867f74:	33 f6                	xor    esi,esi
    71dc01867f76:	48 89 b7 80 00 00 00 	mov    QWORD PTR [rdi+0x80],rsi
    71dc01867f7d:	48 89 b7 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rsi
    71dc01867f84:	48 89 b7 90 00 00 00 	mov    QWORD PTR [rdi+0x90],rsi
    71dc01867f8b:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01867f92:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01867f99:	4c 8b ff             	mov    r15,rdi
    71dc01867f9c:	4c 8b b5 60 ff ff ff 	mov    r14,QWORD PTR [rbp-0xa0]
    71dc01867fa3:	4d 85 f6             	test   r14,r14
    71dc01867fa6:	75 09                	jne    0x71dc01867fb1
    71dc01867fa8:	48 8b b5 68 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x98]
    71dc01867faf:	eb 58                	jmp    0x71dc01868009
    71dc01867fb1:	49 8b f6             	mov    rsi,r14
    71dc01867fb4:	48 bf f0 ba 82 01 dc 	movabs rdi,0x71dc0182baf0
    71dc01867fbb:	71 00 00 
    71dc01867fbe:	e8 bd cd fd ff       	call   0x71dc01844d80
    71dc01867fc3:	4c 8b e8             	mov    r13,rax
    71dc01867fc6:	4d 85 ed             	test   r13,r13
    71dc01867fc9:	74 23                	je     0x71dc01867fee
    71dc01867fcb:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc01867fcf:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01867fd5:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01867fdb:	74 0b                	je     0x71dc01867fe8
    71dc01867fdd:	49 8b fd             	mov    rdi,r13
    71dc01867fe0:	33 f6                	xor    esi,esi
    71dc01867fe2:	ff 15 30 d8 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad830]        # 0x71dc00b15818
    71dc01867fe8:	49 8b 75 38          	mov    rsi,QWORD PTR [r13+0x38]
    71dc01867fec:	eb 1b                	jmp    0x71dc01868009
    71dc01867fee:	49 8b fe             	mov    rdi,r14
    71dc01867ff1:	48 0f bf b5 70 ff ff 	movsx  rsi,WORD PTR [rbp-0x90]
    71dc01867ff8:	ff 
    71dc01867ff9:	49 bb e8 35 c4 fe db 	movabs r11,0x71dbfec435e8
    71dc01868000:	71 00 00 
    71dc01868003:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868006:	48 8b f0             	mov    rsi,rax
    71dc01868009:	e9 b0 ea ff ff       	jmp    0x71dc01866abe
    71dc0186800e:	49 8b fd             	mov    rdi,r13
    71dc01868011:	ff 15 e9 c8 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7c8e9]        # 0x71dc016e4900
    71dc01868017:	e9 fc e9 ff ff       	jmp    0x71dc01866a18
    71dc0186801c:	ff 15 8e 74 61 ff    	call   QWORD PTR [rip+0xffffffffff61748e]        # 0x71dc00e7f4b0
    71dc01868022:	cc                   	int3
    71dc01868023:	8b f1                	mov    esi,ecx
    71dc01868025:	c1 ee 1f             	shr    esi,0x1f
    71dc01868028:	03 f1                	add    esi,ecx
    71dc0186802a:	d1 fe                	sar    esi,1
    71dc0186802c:	3b f2                	cmp    esi,edx
    71dc0186802e:	0f 8f 78 ea ff ff    	jg     0x71dc01866aac
    71dc01868034:	33 f6                	xor    esi,esi
    71dc01868036:	ff 15 c4 c5 6d ff    	call   QWORD PTR [rip+0xffffffffff6dc5c4]        # 0x71dc00f44600
    71dc0186803c:	33 ff                	xor    edi,edi
    71dc0186803e:	41 89 7d 58          	mov    DWORD PTR [r13+0x58],edi
    71dc01868042:	e9 65 ea ff ff       	jmp    0x71dc01866aac
    71dc01868047:	41 8b 7d 58          	mov    edi,DWORD PTR [r13+0x58]
    71dc0186804b:	49 8b 45 50          	mov    rax,QWORD PTR [r13+0x50]
    71dc0186804f:	3b 78 10             	cmp    edi,DWORD PTR [rax+0x10]
    71dc01868052:	0f 8c 62 ea ff ff    	jl     0x71dc01866aba
    71dc01868058:	49 8b fd             	mov    rdi,r13
    71dc0186805b:	ff 15 9f c8 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7c89f]        # 0x71dc016e4900
    71dc01868061:	e9 54 ea ff ff       	jmp    0x71dc01866aba
    71dc01868066:	33 ff                	xor    edi,edi
    71dc01868068:	48 89 7d c8          	mov    QWORD PTR [rbp-0x38],rdi
    71dc0186806c:	33 f6                	xor    esi,esi
    71dc0186806e:	e9 4b ea ff ff       	jmp    0x71dc01866abe
    71dc01868073:	33 f6                	xor    esi,esi
    71dc01868075:	45 33 f6             	xor    r14d,r14d
    71dc01868078:	e9 b4 11 00 00       	jmp    0x71dc01869231
    71dc0186807d:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc01868082:	0f 84 aa 01 00 00    	je     0x71dc01868232
    71dc01868088:	48 8b 7b 30          	mov    rdi,QWORD PTR [rbx+0x30]
    71dc0186808c:	48 8d b5 48 ff ff ff 	lea    rsi,[rbp-0xb8]
    71dc01868093:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01868095:	ff 15 65 78 d8 ff    	call   QWORD PTR [rip+0xffffffffffd87865]        # 0x71dc015ef900
    71dc0186809b:	48 8b b5 48 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb8]
    71dc018680a2:	48 8b bd 50 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xb0]
    71dc018680a9:	48 0f bf 85 58 ff ff 	movsx  rax,WORD PTR [rbp-0xa8]
    71dc018680b0:	ff 
    71dc018680b1:	48 89 b5 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rsi
    71dc018680b8:	48 89 bd 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdi
    71dc018680bf:	66 89 85 70 ff ff ff 	mov    WORD PTR [rbp-0x90],ax
    71dc018680c6:	c6 85 72 ff ff ff 00 	mov    BYTE PTR [rbp-0x8e],0x0
    71dc018680cd:	4c 8b b5 60 ff ff ff 	mov    r14,QWORD PTR [rbp-0xa0]
    71dc018680d4:	4d 85 f6             	test   r14,r14
    71dc018680d7:	0f 84 e6 00 00 00    	je     0x71dc018681c3
    71dc018680dd:	49 8b f6             	mov    rsi,r14
    71dc018680e0:	48 bf f0 ba 82 01 dc 	movabs rdi,0x71dc0182baf0
    71dc018680e7:	71 00 00 
    71dc018680ea:	e8 91 cc fd ff       	call   0x71dc01844d80
    71dc018680ef:	48 85 c0             	test   rax,rax
    71dc018680f2:	74 11                	je     0x71dc01868105
    71dc018680f4:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc018680fb:	41 0f 95 c5          	setne  r13b
    71dc018680ff:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868103:	eb 22                	jmp    0x71dc01868127
    71dc01868105:	49 8b fe             	mov    rdi,r14
    71dc01868108:	48 0f bf b5 70 ff ff 	movsx  rsi,WORD PTR [rbp-0x90]
    71dc0186810f:	ff 
    71dc01868110:	49 bb f0 35 c4 fe db 	movabs r11,0x71dbfec435f0
    71dc01868117:	71 00 00 
    71dc0186811a:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186811d:	85 c0                	test   eax,eax
    71dc0186811f:	41 0f 95 c5          	setne  r13b
    71dc01868123:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868127:	45 85 ed             	test   r13d,r13d
    71dc0186812a:	0f 85 93 00 00 00    	jne    0x71dc018681c3
    71dc01868130:	41 c7 47 28 04 00 00 	mov    DWORD PTR [r15+0x28],0x4
    71dc01868137:	00 
    71dc01868138:	49 8d bf 80 00 00 00 	lea    rdi,[r15+0x80]
    71dc0186813f:	48 8d b5 60 ff ff ff 	lea    rsi,[rbp-0xa0]
    71dc01868146:	ba 18 00 00 00       	mov    edx,0x18
    71dc0186814b:	c5 f8 77             	vzeroupper
    71dc0186814e:	e8 ed 21 fe ff       	call   0x71dc0184a340
    71dc01868153:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01868157:	49 8b ff             	mov    rdi,r15
    71dc0186815a:	ff 15 88 e5 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e588]        # 0x71dc017e66e8
    71dc01868160:	48 8b d0             	mov    rdx,rax
    71dc01868163:	48 8d b5 60 ff ff ff 	lea    rsi,[rbp-0xa0]
    71dc0186816a:	48 bf 98 43 8d 01 dc 	movabs rdi,0x71dc018d4398
    71dc01868171:	71 00 00 
    71dc01868174:	ff 15 86 e5 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e586]        # 0x71dc017e6700
    71dc0186817a:	e9 e6 10 00 00       	jmp    0x71dc01869265
    71dc0186817f:	62 f1 7e 08 6f 47 08 	vmovdqu32 xmm0,XMMWORD PTR [rdi+0x80]
    71dc01868186:	62 f1 7e 08 7f 45 f6 	vmovdqu32 XMMWORD PTR [rbp-0xa0],xmm0
    71dc0186818d:	48 8b b7 90 00 00 00 	mov    rsi,QWORD PTR [rdi+0x90]
    71dc01868194:	48 89 b5 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rsi
    71dc0186819b:	33 f6                	xor    esi,esi
    71dc0186819d:	48 89 b7 80 00 00 00 	mov    QWORD PTR [rdi+0x80],rsi
    71dc018681a4:	48 89 b7 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rsi
    71dc018681ab:	48 89 b7 90 00 00 00 	mov    QWORD PTR [rdi+0x90],rsi
    71dc018681b2:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc018681b9:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc018681c0:	4c 8b ff             	mov    r15,rdi
    71dc018681c3:	4c 8b b5 60 ff ff ff 	mov    r14,QWORD PTR [rbp-0xa0]
    71dc018681ca:	4d 85 f6             	test   r14,r14
    71dc018681cd:	75 09                	jne    0x71dc018681d8
    71dc018681cf:	48 8b b5 68 ff ff ff 	mov    rsi,QWORD PTR [rbp-0x98]
    71dc018681d6:	eb 58                	jmp    0x71dc01868230
    71dc018681d8:	49 8b f6             	mov    rsi,r14
    71dc018681db:	48 bf f0 ba 82 01 dc 	movabs rdi,0x71dc0182baf0
    71dc018681e2:	71 00 00 
    71dc018681e5:	e8 96 cb fd ff       	call   0x71dc01844d80
    71dc018681ea:	4c 8b e8             	mov    r13,rax
    71dc018681ed:	4d 85 ed             	test   r13,r13
    71dc018681f0:	74 23                	je     0x71dc01868215
    71dc018681f2:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc018681f6:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc018681fc:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01868202:	74 0b                	je     0x71dc0186820f
    71dc01868204:	49 8b fd             	mov    rdi,r13
    71dc01868207:	33 f6                	xor    esi,esi
    71dc01868209:	ff 15 09 d6 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad609]        # 0x71dc00b15818
    71dc0186820f:	49 8b 75 38          	mov    rsi,QWORD PTR [r13+0x38]
    71dc01868213:	eb 1b                	jmp    0x71dc01868230
    71dc01868215:	49 8b fe             	mov    rdi,r14
    71dc01868218:	48 0f bf b5 70 ff ff 	movsx  rsi,WORD PTR [rbp-0x90]
    71dc0186821f:	ff 
    71dc01868220:	49 bb f8 35 c4 fe db 	movabs r11,0x71dbfec435f8
    71dc01868227:	71 00 00 
    71dc0186822a:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186822d:	48 8b f0             	mov    rsi,rax
    71dc01868230:	eb 1c                	jmp    0x71dc0186824e
    71dc01868232:	48 8b 7b 30          	mov    rdi,QWORD PTR [rbx+0x30]
    71dc01868236:	48 8d 75 c8          	lea    rsi,[rbp-0x38]
    71dc0186823a:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186823c:	ff 15 d6 76 d8 ff    	call   QWORD PTR [rip+0xffffffffffd876d6]        # 0x71dc015ef918
    71dc01868242:	85 c0                	test   eax,eax
    71dc01868244:	75 04                	jne    0x71dc0186824a
    71dc01868246:	33 f6                	xor    esi,esi
    71dc01868248:	eb 04                	jmp    0x71dc0186824e
    71dc0186824a:	48 8b 75 c8          	mov    rsi,QWORD PTR [rbp-0x38]
    71dc0186824e:	49 8d 7f 08          	lea    rdi,[r15+0x8]
    71dc01868252:	e8 a9 87 7e 7c       	call   0x71dc7e050a00
    71dc01868257:	49 83 7f 08 00       	cmp    QWORD PTR [r15+0x8],0x0
    71dc0186825c:	0f 84 11 fe ff ff    	je     0x71dc01868073
    71dc01868262:	e9 b7 e8 ff ff       	jmp    0x71dc01866b1e
    71dc01868267:	49 bb 00 36 c4 fe db 	movabs r11,0x71dbfec43600
    71dc0186826e:	71 00 00 
    71dc01868271:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868274:	44 8b f0             	mov    r14d,eax
    71dc01868277:	e9 c1 e8 ff ff       	jmp    0x71dc01866b3d
    71dc0186827c:	bf 05 00 00 00       	mov    edi,0x5
    71dc01868281:	e8 ba cc fd ff       	call   0x71dc01844f40
    71dc01868286:	e9 14 e9 ff ff       	jmp    0x71dc01866b9f
    71dc0186828b:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc0186828f:	e8 ac 7d 3b fd       	call   0x71dbfec20040
    71dc01868294:	e9 54 e9 ff ff       	jmp    0x71dc01866bed
    71dc01868299:	49 8b fe             	mov    rdi,r14
    71dc0186829c:	48 8b b5 78 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x288]
    71dc018682a3:	ff 15 cf cf 2a ff    	call   QWORD PTR [rip+0xffffffffff2acfcf]        # 0x71dc00b15278
    71dc018682a9:	e9 50 e9 ff ff       	jmp    0x71dc01866bfe
    71dc018682ae:	4c 8b b5 08 fe ff ff 	mov    r14,QWORD PTR [rbp-0x1f8]
    71dc018682b5:	4d 85 f6             	test   r14,r14
    71dc018682b8:	75 22                	jne    0x71dc018682dc
    71dc018682ba:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc018682c1:	71 00 00 
    71dc018682c4:	e8 f7 8f 7e 7c       	call   0x71dc7e0512c0
    71dc018682c9:	4c 8b f0             	mov    r14,rax
    71dc018682cc:	49 8b fe             	mov    rdi,r14
    71dc018682cf:	ff 15 c3 ca f7 ff    	call   QWORD PTR [rip+0xfffffffffff7cac3]        # 0x71dc017e4d98
    71dc018682d5:	4c 89 b5 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],r14
    71dc018682dc:	33 c0                	xor    eax,eax
    71dc018682de:	e9 3f e9 ff ff       	jmp    0x71dc01866c22
    71dc018682e3:	49 8b f6             	mov    rsi,r14
    71dc018682e6:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc018682ed:	71 00 00 
    71dc018682f0:	e8 8b ca fd ff       	call   0x71dc01844d80
    71dc018682f5:	48 85 c0             	test   rax,rax
    71dc018682f8:	74 11                	je     0x71dc0186830b
    71dc018682fa:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01868301:	41 0f 95 c5          	setne  r13b
    71dc01868305:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868309:	eb 1f                	jmp    0x71dc0186832a
    71dc0186830b:	49 8b fe             	mov    rdi,r14
    71dc0186830e:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01868313:	49 bb 08 36 c4 fe db 	movabs r11,0x71dbfec43608
    71dc0186831a:	71 00 00 
    71dc0186831d:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868320:	85 c0                	test   eax,eax
    71dc01868322:	41 0f 95 c5          	setne  r13b
    71dc01868326:	45 0f b6 ed          	movzx  r13d,r13b
    71dc0186832a:	45 85 ed             	test   r13d,r13d
    71dc0186832d:	0f 85 0e e9 ff ff    	jne    0x71dc01866c41
    71dc01868333:	41 c7 47 28 05 00 00 	mov    DWORD PTR [r15+0x28],0x5
    71dc0186833a:	00 
    71dc0186833b:	49 8d 77 58          	lea    rsi,[r15+0x58]
    71dc0186833f:	48 8b fe             	mov    rdi,rsi
    71dc01868342:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01868346:	ba 18 00 00 00       	mov    edx,0x18
    71dc0186834b:	c5 f8 77             	vzeroupper
    71dc0186834e:	e8 ed 1f fe ff       	call   0x71dc0184a340
    71dc01868353:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01868357:	49 8b ff             	mov    rdi,r15
    71dc0186835a:	ff 15 88 e3 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e388]        # 0x71dc017e66e8
    71dc01868360:	48 8b d0             	mov    rdx,rax
    71dc01868363:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01868367:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc0186836e:	71 00 00 
    71dc01868371:	ff 15 89 e3 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e389]        # 0x71dc017e6700
    71dc01868377:	e9 e9 0e 00 00       	jmp    0x71dc01869265
    71dc0186837c:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc01868380:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc01868384:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc01868389:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc0186838d:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc01868391:	33 c0                	xor    eax,eax
    71dc01868393:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc01868396:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc0186839a:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc0186839e:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc018683a5:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc018683ac:	4c 8b ff             	mov    r15,rdi
    71dc018683af:	e9 8d e8 ff ff       	jmp    0x71dc01866c41
    71dc018683b4:	49 8b f6             	mov    rsi,r14
    71dc018683b7:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc018683be:	71 00 00 
    71dc018683c1:	e8 ba c9 fd ff       	call   0x71dc01844d80
    71dc018683c6:	4c 8b e8             	mov    r13,rax
    71dc018683c9:	4d 85 ed             	test   r13,r13
    71dc018683cc:	74 26                	je     0x71dc018683f4
    71dc018683ce:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc018683d2:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc018683d8:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc018683de:	74 0b                	je     0x71dc018683eb
    71dc018683e0:	49 8b fd             	mov    rdi,r13
    71dc018683e3:	33 f6                	xor    esi,esi
    71dc018683e5:	ff 15 2d d4 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad42d]        # 0x71dc00b15818
    71dc018683eb:	49 8b 75 38          	mov    rsi,QWORD PTR [r13+0x38]
    71dc018683ef:	e9 5e e8 ff ff       	jmp    0x71dc01866c52
    71dc018683f4:	49 8b fe             	mov    rdi,r14
    71dc018683f7:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc018683fc:	49 bb 10 36 c4 fe db 	movabs r11,0x71dbfec43610
    71dc01868403:	71 00 00 
    71dc01868406:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868409:	48 8b f0             	mov    rsi,rax
    71dc0186840c:	e9 41 e8 ff ff       	jmp    0x71dc01866c52
    71dc01868411:	45 33 e4             	xor    r12d,r12d
    71dc01868414:	e9 0d e9 ff ff       	jmp    0x71dc01866d26
    71dc01868419:	49 8b 77 10          	mov    rsi,QWORD PTR [r15+0x10]
    71dc0186841d:	48 8b 9d b0 fd ff ff 	mov    rbx,QWORD PTR [rbp-0x250]
    71dc01868424:	48 8b 53 28          	mov    rdx,QWORD PTR [rbx+0x28]
    71dc01868428:	48 8b 4b 20          	mov    rcx,QWORD PTR [rbx+0x20]
    71dc0186842c:	48 8d bd 18 ff ff ff 	lea    rdi,[rbp-0xe8]
    71dc01868433:	ff 15 17 67 d8 ff    	call   QWORD PTR [rip+0xffffffffffd86717]        # 0x71dc015eeb50
    71dc01868439:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    71dc01868440:	48 8b bd 20 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe0]
    71dc01868447:	48 0f bf 85 28 ff ff 	movsx  rax,WORD PTR [rbp-0xd8]
    71dc0186844e:	ff 
    71dc0186844f:	48 89 b5 30 ff ff ff 	mov    QWORD PTR [rbp-0xd0],rsi
    71dc01868456:	48 89 bd 38 ff ff ff 	mov    QWORD PTR [rbp-0xc8],rdi
    71dc0186845d:	66 89 85 40 ff ff ff 	mov    WORD PTR [rbp-0xc0],ax
    71dc01868464:	c6 85 42 ff ff ff 00 	mov    BYTE PTR [rbp-0xbe],0x0
    71dc0186846b:	4c 8b b5 30 ff ff ff 	mov    r14,QWORD PTR [rbp-0xd0]
    71dc01868472:	4d 85 f6             	test   r14,r14
    71dc01868475:	0f 84 e7 00 00 00    	je     0x71dc01868562
    71dc0186847b:	49 8b f6             	mov    rsi,r14
    71dc0186847e:	48 bf a0 49 8d 01 dc 	movabs rdi,0x71dc018d49a0
    71dc01868485:	71 00 00 
    71dc01868488:	e8 f3 c8 fd ff       	call   0x71dc01844d80
    71dc0186848d:	48 85 c0             	test   rax,rax
    71dc01868490:	74 11                	je     0x71dc018684a3
    71dc01868492:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01868499:	41 0f 95 c5          	setne  r13b
    71dc0186849d:	45 0f b6 ed          	movzx  r13d,r13b
    71dc018684a1:	eb 22                	jmp    0x71dc018684c5
    71dc018684a3:	49 8b fe             	mov    rdi,r14
    71dc018684a6:	48 0f bf b5 40 ff ff 	movsx  rsi,WORD PTR [rbp-0xc0]
    71dc018684ad:	ff 
    71dc018684ae:	49 bb 28 36 c4 fe db 	movabs r11,0x71dbfec43628
    71dc018684b5:	71 00 00 
    71dc018684b8:	41 ff 13             	call   QWORD PTR [r11]
    71dc018684bb:	85 c0                	test   eax,eax
    71dc018684bd:	41 0f 95 c5          	setne  r13b
    71dc018684c1:	45 0f b6 ed          	movzx  r13d,r13b
    71dc018684c5:	45 85 ed             	test   r13d,r13d
    71dc018684c8:	0f 85 94 00 00 00    	jne    0x71dc01868562
    71dc018684ce:	41 c7 47 28 06 00 00 	mov    DWORD PTR [r15+0x28],0x6
    71dc018684d5:	00 
    71dc018684d6:	49 8d bf 98 00 00 00 	lea    rdi,[r15+0x98]
    71dc018684dd:	48 8d b5 30 ff ff ff 	lea    rsi,[rbp-0xd0]
    71dc018684e4:	ba 18 00 00 00       	mov    edx,0x18
    71dc018684e9:	c5 f8 77             	vzeroupper
    71dc018684ec:	e8 4f 1e fe ff       	call   0x71dc0184a340
    71dc018684f1:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc018684f5:	49 8b ff             	mov    rdi,r15
    71dc018684f8:	ff 15 ea e1 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e1ea]        # 0x71dc017e66e8
    71dc018684fe:	48 8b d0             	mov    rdx,rax
    71dc01868501:	48 8d b5 30 ff ff ff 	lea    rsi,[rbp-0xd0]
    71dc01868508:	48 bf 38 4e 8d 01 dc 	movabs rdi,0x71dc018d4e38
    71dc0186850f:	71 00 00 
    71dc01868512:	ff 15 e8 e1 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e1e8]        # 0x71dc017e6700
    71dc01868518:	e9 48 0d 00 00       	jmp    0x71dc01869265
    71dc0186851d:	c5 fa 6f 87 98 00 00 	vmovdqu xmm0,XMMWORD PTR [rdi+0x98]
    71dc01868524:	00 
    71dc01868525:	62 f1 7e 08 7f 45 f3 	vmovdqu32 XMMWORD PTR [rbp-0xd0],xmm0
    71dc0186852c:	48 8b b7 a8 00 00 00 	mov    rsi,QWORD PTR [rdi+0xa8]
    71dc01868533:	48 89 b5 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],rsi
    71dc0186853a:	33 f6                	xor    esi,esi
    71dc0186853c:	48 89 b7 98 00 00 00 	mov    QWORD PTR [rdi+0x98],rsi
    71dc01868543:	48 89 b7 a0 00 00 00 	mov    QWORD PTR [rdi+0xa0],rsi
    71dc0186854a:	48 89 b7 a8 00 00 00 	mov    QWORD PTR [rdi+0xa8],rsi
    71dc01868551:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01868558:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc0186855f:	4c 8b ff             	mov    r15,rdi
    71dc01868562:	4c 8b b5 30 ff ff ff 	mov    r14,QWORD PTR [rbp-0xd0]
    71dc01868569:	4d 85 f6             	test   r14,r14
    71dc0186856c:	75 09                	jne    0x71dc01868577
    71dc0186856e:	48 8b 85 38 ff ff ff 	mov    rax,QWORD PTR [rbp-0xc8]
    71dc01868575:	eb 55                	jmp    0x71dc018685cc
    71dc01868577:	49 8b f6             	mov    rsi,r14
    71dc0186857a:	48 bf a0 49 8d 01 dc 	movabs rdi,0x71dc018d49a0
    71dc01868581:	71 00 00 
    71dc01868584:	e8 f7 c7 fd ff       	call   0x71dc01844d80
    71dc01868589:	4c 8b e8             	mov    r13,rax
    71dc0186858c:	4d 85 ed             	test   r13,r13
    71dc0186858f:	74 23                	je     0x71dc018685b4
    71dc01868591:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc01868595:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc0186859b:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc018685a1:	74 0b                	je     0x71dc018685ae
    71dc018685a3:	49 8b fd             	mov    rdi,r13
    71dc018685a6:	33 f6                	xor    esi,esi
    71dc018685a8:	ff 15 6a d2 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad26a]        # 0x71dc00b15818
    71dc018685ae:	49 8b 45 38          	mov    rax,QWORD PTR [r13+0x38]
    71dc018685b2:	eb 18                	jmp    0x71dc018685cc
    71dc018685b4:	49 8b fe             	mov    rdi,r14
    71dc018685b7:	48 0f bf b5 40 ff ff 	movsx  rsi,WORD PTR [rbp-0xc0]
    71dc018685be:	ff 
    71dc018685bf:	49 bb 30 36 c4 fe db 	movabs r11,0x71dbfec43630
    71dc018685c6:	71 00 00 
    71dc018685c9:	41 ff 13             	call   QWORD PTR [r11]
    71dc018685cc:	e9 51 e8 ff ff       	jmp    0x71dc01866e22
    71dc018685d1:	48 8b f3             	mov    rsi,rbx
    71dc018685d4:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc018685db:	71 00 00 
    71dc018685de:	e8 9d c7 fd ff       	call   0x71dc01844d80
    71dc018685e3:	48 85 c0             	test   rax,rax
    71dc018685e6:	74 11                	je     0x71dc018685f9
    71dc018685e8:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc018685ef:	41 0f 95 c6          	setne  r14b
    71dc018685f3:	45 0f b6 f6          	movzx  r14d,r14b
    71dc018685f7:	eb 22                	jmp    0x71dc0186861b
    71dc018685f9:	48 8b fb             	mov    rdi,rbx
    71dc018685fc:	48 0f bf b5 c8 fe ff 	movsx  rsi,WORD PTR [rbp-0x138]
    71dc01868603:	ff 
    71dc01868604:	49 bb 78 36 c4 fe db 	movabs r11,0x71dbfec43678
    71dc0186860b:	71 00 00 
    71dc0186860e:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868611:	85 c0                	test   eax,eax
    71dc01868613:	41 0f 95 c6          	setne  r14b
    71dc01868617:	45 0f b6 f6          	movzx  r14d,r14b
    71dc0186861b:	45 85 f6             	test   r14d,r14d
    71dc0186861e:	0f 85 81 ef ff ff    	jne    0x71dc018675a5
    71dc01868624:	41 c7 47 28 08 00 00 	mov    DWORD PTR [r15+0x28],0x8
    71dc0186862b:	00 
    71dc0186862c:	49 8d 9f d0 00 00 00 	lea    rbx,[r15+0xd0]
    71dc01868633:	48 8b b5 c0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x140]
    71dc0186863a:	48 8b fb             	mov    rdi,rbx
    71dc0186863d:	e8 be 83 7e 7c       	call   0x71dc7e050a00
    71dc01868642:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
    71dc01868649:	48 89 73 08          	mov    QWORD PTR [rbx+0x8],rsi
    71dc0186864d:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01868651:	49 8b ff             	mov    rdi,r15
    71dc01868654:	ff 15 8e e0 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e08e]        # 0x71dc017e66e8
    71dc0186865a:	48 8b f0             	mov    rsi,rax
    71dc0186865d:	48 8d bd c0 fe ff ff 	lea    rdi,[rbp-0x140]
    71dc01868664:	ff 15 7e e3 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7e37e]        # 0x71dc017e69e8
    71dc0186866a:	e9 f6 0b 00 00       	jmp    0x71dc01869265
    71dc0186866f:	62 f1 7e 08 6f 47 0d 	vmovdqu32 xmm0,XMMWORD PTR [rdi+0xd0]
    71dc01868676:	62 f1 7e 08 7f 45 ec 	vmovdqu32 XMMWORD PTR [rbp-0x140],xmm0
    71dc0186867d:	33 f6                	xor    esi,esi
    71dc0186867f:	48 89 b7 d0 00 00 00 	mov    QWORD PTR [rdi+0xd0],rsi
    71dc01868686:	48 89 b7 d8 00 00 00 	mov    QWORD PTR [rdi+0xd8],rsi
    71dc0186868d:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01868694:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc0186869b:	4c 8b ff             	mov    r15,rdi
    71dc0186869e:	e9 02 ef ff ff       	jmp    0x71dc018675a5
    71dc018686a3:	48 8b f3             	mov    rsi,rbx
    71dc018686a6:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc018686ad:	71 00 00 
    71dc018686b0:	e8 cb c6 fd ff       	call   0x71dc01844d80
    71dc018686b5:	48 85 c0             	test   rax,rax
    71dc018686b8:	74 25                	je     0x71dc018686df
    71dc018686ba:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    71dc018686bd:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc018686c3:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc018686c9:	0f 84 e6 ee ff ff    	je     0x71dc018675b5
    71dc018686cf:	48 8b f8             	mov    rdi,rax
    71dc018686d2:	33 f6                	xor    esi,esi
    71dc018686d4:	ff 15 3e d1 2a ff    	call   QWORD PTR [rip+0xffffffffff2ad13e]        # 0x71dc00b15818
    71dc018686da:	e9 d6 ee ff ff       	jmp    0x71dc018675b5
    71dc018686df:	48 8b fb             	mov    rdi,rbx
    71dc018686e2:	48 0f bf b5 c8 fe ff 	movsx  rsi,WORD PTR [rbp-0x138]
    71dc018686e9:	ff 
    71dc018686ea:	49 bb 80 36 c4 fe db 	movabs r11,0x71dbfec43680
    71dc018686f1:	71 00 00 
    71dc018686f4:	41 ff 13             	call   QWORD PTR [r11]
    71dc018686f7:	e9 b9 ee ff ff       	jmp    0x71dc018675b5
    71dc018686fc:	48 8b f3             	mov    rsi,rbx
    71dc018686ff:	48 bf e8 18 ea ff db 	movabs rdi,0x71dbffea18e8
    71dc01868706:	71 00 00 
    71dc01868709:	e8 72 c6 fd ff       	call   0x71dc01844d80
    71dc0186870e:	48 85 c0             	test   rax,rax
    71dc01868711:	4c 8b f3             	mov    r14,rbx
    71dc01868714:	75 09                	jne    0x71dc0186871f
    71dc01868716:	49 8b fe             	mov    rdi,r14
    71dc01868719:	e8 82 98 54 7c       	call   0x71dc7ddb1fa0
    71dc0186871e:	cc                   	int3
    71dc0186871f:	48 8b f8             	mov    rdi,rax
    71dc01868722:	ff 15 b0 66 d1 ff    	call   QWORD PTR [rip+0xffffffffffd166b0]        # 0x71dc0157edd8
    71dc01868728:	48 8b f8             	mov    rdi,rax
    71dc0186872b:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186872d:	ff 15 9d 65 d1 ff    	call   QWORD PTR [rip+0xffffffffffd1659d]        # 0x71dc0157ecd0
    71dc01868733:	cc                   	int3
    71dc01868734:	bf 05 00 00 00       	mov    edi,0x5
    71dc01868739:	e8 02 c8 fd ff       	call   0x71dc01844f40
    71dc0186873e:	e9 eb ee ff ff       	jmp    0x71dc0186762e
    71dc01868743:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc01868747:	e8 f4 78 3b fd       	call   0x71dbfec20040
    71dc0186874c:	e9 2b ef ff ff       	jmp    0x71dc0186767c
    71dc01868751:	49 8b fe             	mov    rdi,r14
    71dc01868754:	48 8b b5 30 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2d0]
    71dc0186875b:	ff 15 17 cb 2a ff    	call   QWORD PTR [rip+0xffffffffff2acb17]        # 0x71dc00b15278
    71dc01868761:	e9 27 ef ff ff       	jmp    0x71dc0186768d
    71dc01868766:	4c 8b b5 d0 fd ff ff 	mov    r14,QWORD PTR [rbp-0x230]
    71dc0186876d:	4d 85 f6             	test   r14,r14
    71dc01868770:	75 22                	jne    0x71dc01868794
    71dc01868772:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868779:	71 00 00 
    71dc0186877c:	e8 3f 8b 7e 7c       	call   0x71dc7e0512c0
    71dc01868781:	4c 8b f0             	mov    r14,rax
    71dc01868784:	49 8b fe             	mov    rdi,r14
    71dc01868787:	ff 15 0b c6 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7c60b]        # 0x71dc017e4d98
    71dc0186878d:	4c 89 b5 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],r14
    71dc01868794:	33 c0                	xor    eax,eax
    71dc01868796:	e9 16 ef ff ff       	jmp    0x71dc018676b1
    71dc0186879b:	49 8b f6             	mov    rsi,r14
    71dc0186879e:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc018687a5:	71 00 00 
    71dc018687a8:	e8 d3 c5 fd ff       	call   0x71dc01844d80
    71dc018687ad:	48 85 c0             	test   rax,rax
    71dc018687b0:	74 11                	je     0x71dc018687c3
    71dc018687b2:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc018687b9:	41 0f 95 c5          	setne  r13b
    71dc018687bd:	45 0f b6 ed          	movzx  r13d,r13b
    71dc018687c1:	eb 1f                	jmp    0x71dc018687e2
    71dc018687c3:	49 8b fe             	mov    rdi,r14
    71dc018687c6:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc018687cb:	49 bb 88 36 c4 fe db 	movabs r11,0x71dbfec43688
    71dc018687d2:	71 00 00 
    71dc018687d5:	41 ff 13             	call   QWORD PTR [r11]
    71dc018687d8:	85 c0                	test   eax,eax
    71dc018687da:	41 0f 95 c5          	setne  r13b
    71dc018687de:	45 0f b6 ed          	movzx  r13d,r13b
    71dc018687e2:	45 85 ed             	test   r13d,r13d
    71dc018687e5:	0f 85 e5 ee ff ff    	jne    0x71dc018676d0
    71dc018687eb:	41 c7 47 28 09 00 00 	mov    DWORD PTR [r15+0x28],0x9
    71dc018687f2:	00 
    71dc018687f3:	49 8d 77 58          	lea    rsi,[r15+0x58]
    71dc018687f7:	48 8b fe             	mov    rdi,rsi
    71dc018687fa:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc018687fe:	ba 18 00 00 00       	mov    edx,0x18
    71dc01868803:	c5 f8 77             	vzeroupper
    71dc01868806:	e8 35 1b fe ff       	call   0x71dc0184a340
    71dc0186880b:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc0186880f:	49 8b ff             	mov    rdi,r15
    71dc01868812:	ff 15 d0 de f7 ff    	call   QWORD PTR [rip+0xfffffffffff7ded0]        # 0x71dc017e66e8
    71dc01868818:	48 8b d0             	mov    rdx,rax
    71dc0186881b:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc0186881f:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc01868826:	71 00 00 
    71dc01868829:	ff 15 d1 de f7 ff    	call   QWORD PTR [rip+0xfffffffffff7ded1]        # 0x71dc017e6700
    71dc0186882f:	e9 31 0a 00 00       	jmp    0x71dc01869265
    71dc01868834:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc01868838:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc0186883c:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc01868841:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc01868845:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc01868849:	33 c0                	xor    eax,eax
    71dc0186884b:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc0186884e:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc01868852:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc01868856:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc0186885d:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01868864:	4c 8b ff             	mov    r15,rdi
    71dc01868867:	e9 64 ee ff ff       	jmp    0x71dc018676d0
    71dc0186886c:	49 8b f6             	mov    rsi,r14
    71dc0186886f:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868876:	71 00 00 
    71dc01868879:	e8 02 c5 fd ff       	call   0x71dc01844d80
    71dc0186887e:	4c 8b e8             	mov    r13,rax
    71dc01868881:	4d 85 ed             	test   r13,r13
    71dc01868884:	74 26                	je     0x71dc018688ac
    71dc01868886:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc0186888a:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01868890:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01868896:	74 0b                	je     0x71dc018688a3
    71dc01868898:	49 8b fd             	mov    rdi,r13
    71dc0186889b:	33 f6                	xor    esi,esi
    71dc0186889d:	ff 15 75 cf 2a ff    	call   QWORD PTR [rip+0xffffffffff2acf75]        # 0x71dc00b15818
    71dc018688a3:	49 8b 75 38          	mov    rsi,QWORD PTR [r13+0x38]
    71dc018688a7:	e9 35 ee ff ff       	jmp    0x71dc018676e1
    71dc018688ac:	49 8b fe             	mov    rdi,r14
    71dc018688af:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc018688b4:	49 bb 90 36 c4 fe db 	movabs r11,0x71dbfec43690
    71dc018688bb:	71 00 00 
    71dc018688be:	41 ff 13             	call   QWORD PTR [r11]
    71dc018688c1:	48 8b f0             	mov    rsi,rax
    71dc018688c4:	e9 18 ee ff ff       	jmp    0x71dc018676e1
    71dc018688c9:	48 bf a0 27 e6 ff db 	movabs rdi,0x71dbffe627a0
    71dc018688d0:	71 00 00 
    71dc018688d3:	be 01 00 00 00       	mov    esi,0x1
    71dc018688d8:	e8 73 8b 7e 7c       	call   0x71dc7e051450
    71dc018688dd:	4c 8b f0             	mov    r14,rax
    71dc018688e0:	49 8b 77 10          	mov    rsi,QWORD PTR [r15+0x10]
    71dc018688e4:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc018688e8:	e8 53 77 3b fd       	call   0x71dbfec20040
    71dc018688ed:	48 8b 4b 20          	mov    rcx,QWORD PTR [rbx+0x20]
    71dc018688f1:	48 8b 53 28          	mov    rdx,QWORD PTR [rbx+0x28]
    71dc018688f5:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    71dc018688f9:	49 8b f6             	mov    rsi,r14
    71dc018688fc:	ff 15 8e b7 d7 ff    	call   QWORD PTR [rip+0xffffffffffd7b78e]        # 0x71dc015e4090
    71dc01868902:	48 8b 75 98          	mov    rsi,QWORD PTR [rbp-0x68]
    71dc01868906:	48 8b 7d a0          	mov    rdi,QWORD PTR [rbp-0x60]
    71dc0186890a:	48 0f bf 45 a8       	movsx  rax,WORD PTR [rbp-0x58]
    71dc0186890f:	48 89 75 b0          	mov    QWORD PTR [rbp-0x50],rsi
    71dc01868913:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
    71dc01868917:	66 89 45 c0          	mov    WORD PTR [rbp-0x40],ax
    71dc0186891b:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc0186891f:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01868923:	4d 85 f6             	test   r14,r14
    71dc01868926:	0f 84 cc 00 00 00    	je     0x71dc018689f8
    71dc0186892c:	49 8b f6             	mov    rsi,r14
    71dc0186892f:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868936:	71 00 00 
    71dc01868939:	e8 42 c4 fd ff       	call   0x71dc01844d80
    71dc0186893e:	48 85 c0             	test   rax,rax
    71dc01868941:	74 11                	je     0x71dc01868954
    71dc01868943:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc0186894a:	41 0f 95 c5          	setne  r13b
    71dc0186894e:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868952:	eb 1f                	jmp    0x71dc01868973
    71dc01868954:	49 8b fe             	mov    rdi,r14
    71dc01868957:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc0186895c:	49 bb 98 36 c4 fe db 	movabs r11,0x71dbfec43698
    71dc01868963:	71 00 00 
    71dc01868966:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868969:	85 c0                	test   eax,eax
    71dc0186896b:	41 0f 95 c5          	setne  r13b
    71dc0186896f:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868973:	45 85 ed             	test   r13d,r13d
    71dc01868976:	0f 85 7c 00 00 00    	jne    0x71dc018689f8
    71dc0186897c:	41 c7 47 28 0a 00 00 	mov    DWORD PTR [r15+0x28],0xa
    71dc01868983:	00 
    71dc01868984:	49 8d 77 58          	lea    rsi,[r15+0x58]
    71dc01868988:	48 8b fe             	mov    rdi,rsi
    71dc0186898b:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc0186898f:	ba 18 00 00 00       	mov    edx,0x18
    71dc01868994:	c5 f8 77             	vzeroupper
    71dc01868997:	e8 a4 19 fe ff       	call   0x71dc0184a340
    71dc0186899c:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc018689a0:	49 8b ff             	mov    rdi,r15
    71dc018689a3:	ff 15 3f dd f7 ff    	call   QWORD PTR [rip+0xfffffffffff7dd3f]        # 0x71dc017e66e8
    71dc018689a9:	48 8b d0             	mov    rdx,rax
    71dc018689ac:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc018689b0:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc018689b7:	71 00 00 
    71dc018689ba:	ff 15 40 dd f7 ff    	call   QWORD PTR [rip+0xfffffffffff7dd40]        # 0x71dc017e6700
    71dc018689c0:	e9 a0 08 00 00       	jmp    0x71dc01869265
    71dc018689c5:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc018689c9:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc018689cd:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc018689d2:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc018689d6:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc018689da:	33 c0                	xor    eax,eax
    71dc018689dc:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc018689df:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc018689e3:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc018689e7:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc018689ee:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc018689f5:	4c 8b ff             	mov    r15,rdi
    71dc018689f8:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc018689fc:	4d 85 f6             	test   r14,r14
    71dc018689ff:	75 06                	jne    0x71dc01868a07
    71dc01868a01:	4c 8b 75 b8          	mov    r14,QWORD PTR [rbp-0x48]
    71dc01868a05:	eb 55                	jmp    0x71dc01868a5c
    71dc01868a07:	49 8b f6             	mov    rsi,r14
    71dc01868a0a:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868a11:	71 00 00 
    71dc01868a14:	e8 67 c3 fd ff       	call   0x71dc01844d80
    71dc01868a19:	4c 8b e8             	mov    r13,rax
    71dc01868a1c:	4d 85 ed             	test   r13,r13
    71dc01868a1f:	74 23                	je     0x71dc01868a44
    71dc01868a21:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc01868a25:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01868a2b:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01868a31:	74 0b                	je     0x71dc01868a3e
    71dc01868a33:	49 8b fd             	mov    rdi,r13
    71dc01868a36:	33 f6                	xor    esi,esi
    71dc01868a38:	ff 15 da cd 2a ff    	call   QWORD PTR [rip+0xffffffffff2acdda]        # 0x71dc00b15818
    71dc01868a3e:	4d 8b 75 38          	mov    r14,QWORD PTR [r13+0x38]
    71dc01868a42:	eb 18                	jmp    0x71dc01868a5c
    71dc01868a44:	49 8b fe             	mov    rdi,r14
    71dc01868a47:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01868a4c:	49 bb a0 36 c4 fe db 	movabs r11,0x71dbfec436a0
    71dc01868a53:	71 00 00 
    71dc01868a56:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868a59:	4c 8b f0             	mov    r14,rax
    71dc01868a5c:	e9 cc ec ff ff       	jmp    0x71dc0186772d
    71dc01868a61:	49 bb a8 36 c4 fe db 	movabs r11,0x71dbfec436a8
    71dc01868a68:	71 00 00 
    71dc01868a6b:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868a6e:	44 8b f0             	mov    r14d,eax
    71dc01868a71:	e9 ff ec ff ff       	jmp    0x71dc01867775
    71dc01868a76:	49 63 c4             	movsxd rax,r12d
    71dc01868a79:	48 33 c7             	xor    rax,rdi
    71dc01868a7c:	7c 07                	jl     0x71dc01868a85
    71dc01868a7e:	41 83 7d 08 01       	cmp    DWORD PTR [r13+0x8],0x1
    71dc01868a83:	7e 08                	jle    0x71dc01868a8d
    71dc01868a85:	41 8b c4             	mov    eax,r12d
    71dc01868a88:	e9 08 ed ff ff       	jmp    0x71dc01867795
    71dc01868a8d:	4c 8b df             	mov    r11,rdi
    71dc01868a90:	49 f7 db             	neg    r11
    71dc01868a93:	48 85 ff             	test   rdi,rdi
    71dc01868a96:	4c 0f 4d df          	cmovge r11,rdi
    71dc01868a9a:	41 83 7d 08 00       	cmp    DWORD PTR [r13+0x8],0x0
    71dc01868a9f:	0f 86 63 07 00 00    	jbe    0x71dc01869208
    71dc01868aa5:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
    71dc01868aa9:	49 3b fb             	cmp    rdi,r11
    71dc01868aac:	73 07                	jae    0x71dc01868ab5
    71dc01868aae:	b8 ff ff ff ff       	mov    eax,0xffffffff
    71dc01868ab3:	eb 09                	jmp    0x71dc01868abe
    71dc01868ab5:	49 3b fb             	cmp    rdi,r11
    71dc01868ab8:	0f 97 c0             	seta   al
    71dc01868abb:	0f b6 c0             	movzx  eax,al
    71dc01868abe:	41 0f af c4          	imul   eax,r12d
    71dc01868ac2:	e9 ce ec ff ff       	jmp    0x71dc01867795
    71dc01868ac7:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc01868ace:	71 00 00 
    71dc01868ad1:	e8 ea 87 7e 7c       	call   0x71dc7e0512c0
    71dc01868ad6:	4c 8b f0             	mov    r14,rax
    71dc01868ad9:	48 8b 43 10          	mov    rax,QWORD PTR [rbx+0x10]
    71dc01868add:	48 89 85 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],rax
    71dc01868ae4:	49 8b 4f 08          	mov    rcx,QWORD PTR [r15+0x8]
    71dc01868ae8:	48 89 8d 88 fd ff ff 	mov    QWORD PTR [rbp-0x278],rcx
    71dc01868aef:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc01868af3:	49 8b f5             	mov    rsi,r13
    71dc01868af6:	e8 45 75 3b fd       	call   0x71dbfec20040
    71dc01868afb:	45 89 66 10          	mov    DWORD PTR [r14+0x10],r12d
    71dc01868aff:	49 8b f6             	mov    rsi,r14
    71dc01868b02:	4c 8b 4b 20          	mov    r9,QWORD PTR [rbx+0x20]
    71dc01868b06:	4c 8b 43 28          	mov    r8,QWORD PTR [rbx+0x28]
    71dc01868b0a:	48 8b bd 88 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x278]
    71dc01868b11:	33 d2                	xor    edx,edx
    71dc01868b13:	33 c9                	xor    ecx,ecx
    71dc01868b15:	ff 15 65 6f d8 ff    	call   QWORD PTR [rip+0xffffffffffd86f65]        # 0x71dc015efa80
    71dc01868b1b:	48 8b d0             	mov    rdx,rax
    71dc01868b1e:	49 8d 4f 50          	lea    rcx,[r15+0x50]
    71dc01868b22:	48 8b b5 90 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x270]
    71dc01868b29:	48 8b fb             	mov    rdi,rbx
    71dc01868b2c:	ff 15 1e 6f d8 ff    	call   QWORD PTR [rip+0xffffffffffd86f1e]        # 0x71dc015efa50
    71dc01868b32:	e9 ad ec ff ff       	jmp    0x71dc018677e4
    71dc01868b37:	49 bb b0 36 c4 fe db 	movabs r11,0x71dbfec436b0
    71dc01868b3e:	71 00 00 
    71dc01868b41:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868b44:	44 8b f0             	mov    r14d,eax
    71dc01868b47:	e9 70 ec ff ff       	jmp    0x71dc018677bc
    71dc01868b4c:	49 63 c4             	movsxd rax,r12d
    71dc01868b4f:	48 33 c7             	xor    rax,rdi
    71dc01868b52:	7c 07                	jl     0x71dc01868b5b
    71dc01868b54:	41 83 7d 08 01       	cmp    DWORD PTR [r13+0x8],0x1
    71dc01868b59:	7e 08                	jle    0x71dc01868b63
    71dc01868b5b:	41 8b c4             	mov    eax,r12d
    71dc01868b5e:	e9 79 ec ff ff       	jmp    0x71dc018677dc
    71dc01868b63:	4c 8b df             	mov    r11,rdi
    71dc01868b66:	49 f7 db             	neg    r11
    71dc01868b69:	48 85 ff             	test   rdi,rdi
    71dc01868b6c:	4c 0f 4d df          	cmovge r11,rdi
    71dc01868b70:	41 83 7d 08 00       	cmp    DWORD PTR [r13+0x8],0x0
    71dc01868b75:	0f 86 8d 06 00 00    	jbe    0x71dc01869208
    71dc01868b7b:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
    71dc01868b7f:	49 3b fb             	cmp    rdi,r11
    71dc01868b82:	73 07                	jae    0x71dc01868b8b
    71dc01868b84:	bf ff ff ff ff       	mov    edi,0xffffffff
    71dc01868b89:	eb 0b                	jmp    0x71dc01868b96
    71dc01868b8b:	49 3b fb             	cmp    rdi,r11
    71dc01868b8e:	40 0f 97 c7          	seta   dil
    71dc01868b92:	40 0f b6 ff          	movzx  edi,dil
    71dc01868b96:	41 8b c4             	mov    eax,r12d
    71dc01868b99:	0f af c7             	imul   eax,edi
    71dc01868b9c:	e9 3b ec ff ff       	jmp    0x71dc018677dc
    71dc01868ba1:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc01868ba6:	0f 84 d3 01 00 00    	je     0x71dc01868d7f
    71dc01868bac:	4d 8b 6f 10          	mov    r13,QWORD PTR [r15+0x10]
    71dc01868bb0:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc01868bb4:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01868bb8:	49 bb b8 36 c4 fe db 	movabs r11,0x71dbfec436b8
    71dc01868bbf:	71 00 00 
    71dc01868bc2:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868bc5:	8b f0                	mov    esi,eax
    71dc01868bc7:	48 8d bd 68 fe ff ff 	lea    rdi,[rbp-0x198]
    71dc01868bce:	ff 15 64 5c d8 ff    	call   QWORD PTR [rip+0xffffffffffd85c64]        # 0x71dc015ee838
    71dc01868bd4:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc01868bdb:	71 00 00 
    71dc01868bde:	e8 dd 86 7e 7c       	call   0x71dc7e0512c0
    71dc01868be3:	4c 8b e0             	mov    r12,rax
    71dc01868be6:	49 8d 7c 24 08       	lea    rdi,[r12+0x8]
    71dc01868beb:	48 8b b5 68 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x198]
    71dc01868bf2:	e8 49 74 3b fd       	call   0x71dbfec20040
    71dc01868bf7:	8b 95 70 fe ff ff    	mov    edx,DWORD PTR [rbp-0x190]
    71dc01868bfd:	41 89 54 24 10       	mov    DWORD PTR [r12+0x10],edx
    71dc01868c02:	48 8b 53 20          	mov    rdx,QWORD PTR [rbx+0x20]
    71dc01868c06:	48 89 14 24          	mov    QWORD PTR [rsp],rdx
    71dc01868c0a:	49 8b d4             	mov    rdx,r12
    71dc01868c0d:	4c 8b 4b 28          	mov    r9,QWORD PTR [rbx+0x28]
    71dc01868c11:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    71dc01868c15:	49 8b f5             	mov    rsi,r13
    71dc01868c18:	33 c9                	xor    ecx,ecx
    71dc01868c1a:	45 33 c0             	xor    r8d,r8d
    71dc01868c1d:	ff 15 75 6e d8 ff    	call   QWORD PTR [rip+0xffffffffffd86e75]        # 0x71dc015efa98
    71dc01868c23:	48 8b 75 98          	mov    rsi,QWORD PTR [rbp-0x68]
    71dc01868c27:	48 8b 7d a0          	mov    rdi,QWORD PTR [rbp-0x60]
    71dc01868c2b:	48 0f bf 45 a8       	movsx  rax,WORD PTR [rbp-0x58]
    71dc01868c30:	48 89 75 b0          	mov    QWORD PTR [rbp-0x50],rsi
    71dc01868c34:	48 89 7d b8          	mov    QWORD PTR [rbp-0x48],rdi
    71dc01868c38:	66 89 45 c0          	mov    WORD PTR [rbp-0x40],ax
    71dc01868c3c:	c6 45 c2 00          	mov    BYTE PTR [rbp-0x3e],0x0
    71dc01868c40:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01868c44:	4d 85 f6             	test   r14,r14
    71dc01868c47:	0f 84 cc 00 00 00    	je     0x71dc01868d19
    71dc01868c4d:	49 8b f6             	mov    rsi,r14
    71dc01868c50:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868c57:	71 00 00 
    71dc01868c5a:	e8 21 c1 fd ff       	call   0x71dc01844d80
    71dc01868c5f:	48 85 c0             	test   rax,rax
    71dc01868c62:	74 11                	je     0x71dc01868c75
    71dc01868c64:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01868c6b:	41 0f 95 c5          	setne  r13b
    71dc01868c6f:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868c73:	eb 1f                	jmp    0x71dc01868c94
    71dc01868c75:	49 8b fe             	mov    rdi,r14
    71dc01868c78:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01868c7d:	49 bb c0 36 c4 fe db 	movabs r11,0x71dbfec436c0
    71dc01868c84:	71 00 00 
    71dc01868c87:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868c8a:	85 c0                	test   eax,eax
    71dc01868c8c:	41 0f 95 c5          	setne  r13b
    71dc01868c90:	45 0f b6 ed          	movzx  r13d,r13b
    71dc01868c94:	45 85 ed             	test   r13d,r13d
    71dc01868c97:	0f 85 7c 00 00 00    	jne    0x71dc01868d19
    71dc01868c9d:	41 c7 47 28 0b 00 00 	mov    DWORD PTR [r15+0x28],0xb
    71dc01868ca4:	00 
    71dc01868ca5:	49 8d 77 58          	lea    rsi,[r15+0x58]
    71dc01868ca9:	48 8b fe             	mov    rdi,rsi
    71dc01868cac:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01868cb0:	ba 18 00 00 00       	mov    edx,0x18
    71dc01868cb5:	c5 f8 77             	vzeroupper
    71dc01868cb8:	e8 83 16 fe ff       	call   0x71dc0184a340
    71dc01868cbd:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01868cc1:	49 8b ff             	mov    rdi,r15
    71dc01868cc4:	ff 15 1e da f7 ff    	call   QWORD PTR [rip+0xfffffffffff7da1e]        # 0x71dc017e66e8
    71dc01868cca:	48 8b d0             	mov    rdx,rax
    71dc01868ccd:	48 8d 75 b0          	lea    rsi,[rbp-0x50]
    71dc01868cd1:	48 bf 30 33 8d 01 dc 	movabs rdi,0x71dc018d3330
    71dc01868cd8:	71 00 00 
    71dc01868cdb:	ff 15 1f da f7 ff    	call   QWORD PTR [rip+0xfffffffffff7da1f]        # 0x71dc017e6700
    71dc01868ce1:	e9 7f 05 00 00       	jmp    0x71dc01869265
    71dc01868ce6:	48 8d 77 58          	lea    rsi,[rdi+0x58]
    71dc01868cea:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc01868cee:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    71dc01868cf3:	48 8b 46 10          	mov    rax,QWORD PTR [rsi+0x10]
    71dc01868cf7:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    71dc01868cfb:	33 c0                	xor    eax,eax
    71dc01868cfd:	48 89 06             	mov    QWORD PTR [rsi],rax
    71dc01868d00:	48 89 46 08          	mov    QWORD PTR [rsi+0x8],rax
    71dc01868d04:	48 89 46 10          	mov    QWORD PTR [rsi+0x10],rax
    71dc01868d08:	c7 45 d4 ff ff ff ff 	mov    DWORD PTR [rbp-0x2c],0xffffffff
    71dc01868d0f:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01868d16:	4c 8b ff             	mov    r15,rdi
    71dc01868d19:	4c 8b 75 b0          	mov    r14,QWORD PTR [rbp-0x50]
    71dc01868d1d:	4d 85 f6             	test   r14,r14
    71dc01868d20:	75 06                	jne    0x71dc01868d28
    71dc01868d22:	4c 8b 75 b8          	mov    r14,QWORD PTR [rbp-0x48]
    71dc01868d26:	eb 55                	jmp    0x71dc01868d7d
    71dc01868d28:	49 8b f6             	mov    rsi,r14
    71dc01868d2b:	48 bf f8 c9 60 01 dc 	movabs rdi,0x71dc0160c9f8
    71dc01868d32:	71 00 00 
    71dc01868d35:	e8 46 c0 fd ff       	call   0x71dc01844d80
    71dc01868d3a:	4c 8b e8             	mov    r13,rax
    71dc01868d3d:	4d 85 ed             	test   r13,r13
    71dc01868d40:	74 23                	je     0x71dc01868d65
    71dc01868d42:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc01868d46:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01868d4c:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01868d52:	74 0b                	je     0x71dc01868d5f
    71dc01868d54:	49 8b fd             	mov    rdi,r13
    71dc01868d57:	33 f6                	xor    esi,esi
    71dc01868d59:	ff 15 b9 ca 2a ff    	call   QWORD PTR [rip+0xffffffffff2acab9]        # 0x71dc00b15818
    71dc01868d5f:	4d 8b 75 38          	mov    r14,QWORD PTR [r13+0x38]
    71dc01868d63:	eb 18                	jmp    0x71dc01868d7d
    71dc01868d65:	49 8b fe             	mov    rdi,r14
    71dc01868d68:	48 0f bf 75 c0       	movsx  rsi,WORD PTR [rbp-0x40]
    71dc01868d6d:	49 bb c8 36 c4 fe db 	movabs r11,0x71dbfec436c8
    71dc01868d74:	71 00 00 
    71dc01868d77:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868d7a:	4c 8b f0             	mov    r14,rax
    71dc01868d7d:	eb 6f                	jmp    0x71dc01868dee
    71dc01868d7f:	4d 8b 77 10          	mov    r14,QWORD PTR [r15+0x10]
    71dc01868d83:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    71dc01868d87:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc01868d8b:	49 bb d0 36 c4 fe db 	movabs r11,0x71dbfec436d0
    71dc01868d92:	71 00 00 
    71dc01868d95:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868d98:	8b f0                	mov    esi,eax
    71dc01868d9a:	48 8d bd 78 fe ff ff 	lea    rdi,[rbp-0x188]
    71dc01868da1:	ff 15 91 5a d8 ff    	call   QWORD PTR [rip+0xffffffffffd85a91]        # 0x71dc015ee838
    71dc01868da7:	48 bf d8 c5 28 01 dc 	movabs rdi,0x71dc0128c5d8
    71dc01868dae:	71 00 00 
    71dc01868db1:	e8 0a 85 7e 7c       	call   0x71dc7e0512c0
    71dc01868db6:	4c 8b e8             	mov    r13,rax
    71dc01868db9:	49 8d 7d 08          	lea    rdi,[r13+0x8]
    71dc01868dbd:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
    71dc01868dc4:	e8 77 72 3b fd       	call   0x71dbfec20040
    71dc01868dc9:	8b b5 80 fe ff ff    	mov    esi,DWORD PTR [rbp-0x180]
    71dc01868dcf:	41 89 75 10          	mov    DWORD PTR [r13+0x10],esi
    71dc01868dd3:	49 8b f5             	mov    rsi,r13
    71dc01868dd6:	4c 8b 4b 20          	mov    r9,QWORD PTR [rbx+0x20]
    71dc01868dda:	4c 8b 43 28          	mov    r8,QWORD PTR [rbx+0x28]
    71dc01868dde:	49 8b fe             	mov    rdi,r14
    71dc01868de1:	33 d2                	xor    edx,edx
    71dc01868de3:	33 c9                	xor    ecx,ecx
    71dc01868de5:	ff 15 95 6c d8 ff    	call   QWORD PTR [rip+0xffffffffffd86c95]        # 0x71dc015efa80
    71dc01868deb:	4c 8b f0             	mov    r14,rax
    71dc01868dee:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    71dc01868df3:	0f 84 a5 03 00 00    	je     0x71dc0186919e
    71dc01868df9:	48 8b 53 20          	mov    rdx,QWORD PTR [rbx+0x20]
    71dc01868dfd:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc01868e01:	49 8b fe             	mov    rdi,r14
    71dc01868e04:	ff 15 2e dd f7 ff    	call   QWORD PTR [rip+0xfffffffffff7dd2e]        # 0x71dc017e6b38
    71dc01868e0a:	48 8b d0             	mov    rdx,rax
    71dc01868e0d:	48 8d bd a8 fe ff ff 	lea    rdi,[rbp-0x158]
    71dc01868e14:	48 be 30 6c 65 01 dc 	movabs rsi,0x71dc01656c30
    71dc01868e1b:	71 00 00 
    71dc01868e1e:	33 c9                	xor    ecx,ecx
    71dc01868e20:	ff 15 02 6a d8 ff    	call   QWORD PTR [rip+0xffffffffffd86a02]        # 0x71dc015ef828
    71dc01868e26:	4d 8d b7 e0 00 00 00 	lea    r14,[r15+0xe0]
    71dc01868e2d:	48 8d bd a8 fe ff ff 	lea    rdi,[rbp-0x158]
    71dc01868e34:	48 be f0 64 65 01 dc 	movabs rsi,0x71dc016564f0
    71dc01868e3b:	71 00 00 
    71dc01868e3e:	ff 15 84 6c d8 ff    	call   QWORD PTR [rip+0xffffffffffd86c84]        # 0x71dc015efac8
    71dc01868e44:	44 8b ea             	mov    r13d,edx
    71dc01868e47:	49 8b fe             	mov    rdi,r14
    71dc01868e4a:	48 8b f0             	mov    rsi,rax
    71dc01868e4d:	e8 ae 7b 7e 7c       	call   0x71dc7e050a00
    71dc01868e52:	45 88 6e 08          	mov    BYTE PTR [r14+0x8],r13b
    71dc01868e56:	33 f6                	xor    esi,esi
    71dc01868e58:	49 89 77 20          	mov    QWORD PTR [r15+0x20],rsi
    71dc01868e5c:	41 89 77 2c          	mov    DWORD PTR [r15+0x2c],esi
    71dc01868e60:	49 8b ff             	mov    rdi,r15
    71dc01868e63:	83 7d d4 0c          	cmp    DWORD PTR [rbp-0x2c],0xc
    71dc01868e67:	75 59                	jne    0x71dc01868ec2
    71dc01868e69:	c5 fa 6f 47 70       	vmovdqu xmm0,XMMWORD PTR [rdi+0x70]
    71dc01868e6e:	c5 fa 7f 45 88       	vmovdqu XMMWORD PTR [rbp-0x78],xmm0
    71dc01868e73:	33 f6                	xor    esi,esi
    71dc01868e75:	48 89 77 70          	mov    QWORD PTR [rdi+0x70],rsi
    71dc01868e79:	48 89 77 78          	mov    QWORD PTR [rdi+0x78],rsi
    71dc01868e7d:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc01868e84:	e9 fc 00 00 00       	jmp    0x71dc01868f85
    71dc01868e89:	48 8b bd b8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x248]
    71dc01868e90:	48 8b bf e0 00 00 00 	mov    rdi,QWORD PTR [rdi+0xe0]
    71dc01868e97:	49 bb d8 36 c4 fe db 	movabs r11,0x71dbfec436d8
    71dc01868e9e:	71 00 00 
    71dc01868ea1:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868ea4:	48 8b f0             	mov    rsi,rax
    71dc01868ea7:	48 8b 53 18          	mov    rdx,QWORD PTR [rbx+0x18]
    71dc01868eab:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01868eb2:	49 8d 4f 50          	lea    rcx,[r15+0x50]
    71dc01868eb6:	48 8b fb             	mov    rdi,rbx
    71dc01868eb9:	ff 15 91 6b d8 ff    	call   QWORD PTR [rip+0xffffffffffd86b91]        # 0x71dc015efa50
    71dc01868ebf:	49 8b ff             	mov    rdi,r15
    71dc01868ec2:	48 81 c7 e0 00 00 00 	add    rdi,0xe0
    71dc01868ec9:	48 be 08 5d 65 01 dc 	movabs rsi,0x71dc01655d08
    71dc01868ed0:	71 00 00 
    71dc01868ed3:	ff 15 1f 6c d8 ff    	call   QWORD PTR [rip+0xffffffffffd86c1f]        # 0x71dc015efaf8
    71dc01868ed9:	48 89 45 88          	mov    QWORD PTR [rbp-0x78],rax
    71dc01868edd:	48 89 55 90          	mov    QWORD PTR [rbp-0x70],rdx
    71dc01868ee1:	4c 8b 7d 88          	mov    r15,QWORD PTR [rbp-0x78]
    71dc01868ee5:	4d 85 ff             	test   r15,r15
    71dc01868ee8:	0f 84 97 00 00 00    	je     0x71dc01868f85
    71dc01868eee:	49 8b f7             	mov    rsi,r15
    71dc01868ef1:	48 bf 10 d2 e6 00 dc 	movabs rdi,0x71dc00e6d210
    71dc01868ef8:	71 00 00 
    71dc01868efb:	e8 80 be fd ff       	call   0x71dc01844d80
    71dc01868f00:	48 85 c0             	test   rax,rax
    71dc01868f03:	74 11                	je     0x71dc01868f16
    71dc01868f05:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc01868f0c:	40 0f 95 c7          	setne  dil
    71dc01868f10:	40 0f b6 ff          	movzx  edi,dil
    71dc01868f14:	eb 1f                	jmp    0x71dc01868f35
    71dc01868f16:	49 8b ff             	mov    rdi,r15
    71dc01868f19:	48 0f bf 75 90       	movsx  rsi,WORD PTR [rbp-0x70]
    71dc01868f1e:	49 bb e0 36 c4 fe db 	movabs r11,0x71dbfec436e0
    71dc01868f25:	71 00 00 
    71dc01868f28:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868f2b:	85 c0                	test   eax,eax
    71dc01868f2d:	40 0f 95 c7          	setne  dil
    71dc01868f31:	40 0f b6 ff          	movzx  edi,dil
    71dc01868f35:	85 ff                	test   edi,edi
    71dc01868f37:	75 4c                	jne    0x71dc01868f85
    71dc01868f39:	48 8b bd b8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x248]
    71dc01868f40:	c7 47 28 0c 00 00 00 	mov    DWORD PTR [rdi+0x28],0xc
    71dc01868f47:	48 8d 5f 70          	lea    rbx,[rdi+0x70]
    71dc01868f4b:	48 8b 75 88          	mov    rsi,QWORD PTR [rbp-0x78]
    71dc01868f4f:	48 8b fb             	mov    rdi,rbx
    71dc01868f52:	e8 a9 7a 7e 7c       	call   0x71dc7e050a00
    71dc01868f57:	48 8b 75 90          	mov    rsi,QWORD PTR [rbp-0x70]
    71dc01868f5b:	48 89 73 08          	mov    QWORD PTR [rbx+0x8],rsi
    71dc01868f5f:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01868f66:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc01868f6a:	49 8b ff             	mov    rdi,r15
    71dc01868f6d:	ff 15 75 d7 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7d775]        # 0x71dc017e66e8
    71dc01868f73:	48 8b f0             	mov    rsi,rax
    71dc01868f76:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    71dc01868f7a:	ff 15 88 d8 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7d888]        # 0x71dc017e6808
    71dc01868f80:	e9 e0 02 00 00       	jmp    0x71dc01869265
    71dc01868f85:	4c 8b 7d 88          	mov    r15,QWORD PTR [rbp-0x78]
    71dc01868f89:	4d 85 ff             	test   r15,r15
    71dc01868f8c:	75 07                	jne    0x71dc01868f95
    71dc01868f8e:	44 0f b6 75 92       	movzx  r14d,BYTE PTR [rbp-0x6e]
    71dc01868f93:	eb 56                	jmp    0x71dc01868feb
    71dc01868f95:	49 8b f7             	mov    rsi,r15
    71dc01868f98:	48 bf 10 d2 e6 00 dc 	movabs rdi,0x71dc00e6d210
    71dc01868f9f:	71 00 00 
    71dc01868fa2:	e8 d9 bd fd ff       	call   0x71dc01844d80
    71dc01868fa7:	4c 8b e8             	mov    r13,rax
    71dc01868faa:	4d 85 ed             	test   r13,r13
    71dc01868fad:	74 24                	je     0x71dc01868fd3
    71dc01868faf:	41 8b 7d 34          	mov    edi,DWORD PTR [r13+0x34]
    71dc01868fb3:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01868fb9:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01868fbf:	74 0b                	je     0x71dc01868fcc
    71dc01868fc1:	49 8b fd             	mov    rdi,r13
    71dc01868fc4:	33 f6                	xor    esi,esi
    71dc01868fc6:	ff 15 4c c8 2a ff    	call   QWORD PTR [rip+0xffffffffff2ac84c]        # 0x71dc00b15818
    71dc01868fcc:	45 0f b6 75 38       	movzx  r14d,BYTE PTR [r13+0x38]
    71dc01868fd1:	eb 18                	jmp    0x71dc01868feb
    71dc01868fd3:	49 8b ff             	mov    rdi,r15
    71dc01868fd6:	48 0f bf 75 90       	movsx  rsi,WORD PTR [rbp-0x70]
    71dc01868fdb:	49 bb e8 36 c4 fe db 	movabs r11,0x71dbfec436e8
    71dc01868fe2:	71 00 00 
    71dc01868fe5:	41 ff 13             	call   QWORD PTR [r11]
    71dc01868fe8:	44 8b f0             	mov    r14d,eax
    71dc01868feb:	45 85 f6             	test   r14d,r14d
    71dc01868fee:	0f 85 95 fe ff ff    	jne    0x71dc01868e89
    71dc01868ff4:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01868ffb:	49 8d bf e0 00 00 00 	lea    rdi,[r15+0xe0]
    71dc01869002:	48 be 08 5d 65 01 dc 	movabs rsi,0x71dc01655d08
    71dc01869009:	71 00 00 
    71dc0186900c:	ff 15 fe 6a d8 ff    	call   QWORD PTR [rip+0xffffffffffd86afe]        # 0x71dc015efb10
    71dc01869012:	48 89 85 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rax
    71dc01869019:	48 89 95 a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rdx
    71dc01869020:	48 8b 9d 98 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x168]
    71dc01869027:	48 85 db             	test   rbx,rbx
    71dc0186902a:	0f 84 c3 00 00 00    	je     0x71dc018690f3
    71dc01869030:	48 8b f3             	mov    rsi,rbx
    71dc01869033:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc0186903a:	71 00 00 
    71dc0186903d:	e8 3e bd fd ff       	call   0x71dc01844d80
    71dc01869042:	48 85 c0             	test   rax,rax
    71dc01869045:	74 11                	je     0x71dc01869058
    71dc01869047:	f7 40 34 00 00 60 01 	test   DWORD PTR [rax+0x34],0x1600000
    71dc0186904e:	41 0f 95 c6          	setne  r14b
    71dc01869052:	45 0f b6 f6          	movzx  r14d,r14b
    71dc01869056:	eb 22                	jmp    0x71dc0186907a
    71dc01869058:	48 8b fb             	mov    rdi,rbx
    71dc0186905b:	48 0f bf b5 a0 fe ff 	movsx  rsi,WORD PTR [rbp-0x160]
    71dc01869062:	ff 
    71dc01869063:	49 bb f0 36 c4 fe db 	movabs r11,0x71dbfec436f0
    71dc0186906a:	71 00 00 
    71dc0186906d:	41 ff 13             	call   QWORD PTR [r11]
    71dc01869070:	85 c0                	test   eax,eax
    71dc01869072:	41 0f 95 c6          	setne  r14b
    71dc01869076:	45 0f b6 f6          	movzx  r14d,r14b
    71dc0186907a:	45 85 f6             	test   r14d,r14d
    71dc0186907d:	75 74                	jne    0x71dc018690f3
    71dc0186907f:	41 c7 47 28 0d 00 00 	mov    DWORD PTR [r15+0x28],0xd
    71dc01869086:	00 
    71dc01869087:	49 8d 9f f0 00 00 00 	lea    rbx,[r15+0xf0]
    71dc0186908e:	48 8b b5 98 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x168]
    71dc01869095:	48 8b fb             	mov    rdi,rbx
    71dc01869098:	e8 63 79 7e 7c       	call   0x71dc7e050a00
    71dc0186909d:	48 8b b5 a0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x160]
    71dc018690a4:	48 89 73 08          	mov    QWORD PTR [rbx+0x8],rsi
    71dc018690a8:	49 8d 77 38          	lea    rsi,[r15+0x38]
    71dc018690ac:	49 8b ff             	mov    rdi,r15
    71dc018690af:	ff 15 33 d6 f7 ff    	call   QWORD PTR [rip+0xfffffffffff7d633]        # 0x71dc017e66e8
    71dc018690b5:	48 8b f0             	mov    rsi,rax
    71dc018690b8:	48 8d bd 98 fe ff ff 	lea    rdi,[rbp-0x168]
    71dc018690bf:	ff 15 2b da f7 ff    	call   QWORD PTR [rip+0xfffffffffff7da2b]        # 0x71dc017e6af0
    71dc018690c5:	e9 9b 01 00 00       	jmp    0x71dc01869265
    71dc018690ca:	62 f1 7e 08 6f 47 0f 	vmovdqu32 xmm0,XMMWORD PTR [rdi+0xf0]
    71dc018690d1:	c5 fa 7f 85 98 fe ff 	vmovdqu XMMWORD PTR [rbp-0x168],xmm0
    71dc018690d8:	ff 
    71dc018690d9:	33 f6                	xor    esi,esi
    71dc018690db:	48 89 b7 f0 00 00 00 	mov    QWORD PTR [rdi+0xf0],rsi
    71dc018690e2:	48 89 b7 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],rsi
    71dc018690e9:	c7 47 28 ff ff ff ff 	mov    DWORD PTR [rdi+0x28],0xffffffff
    71dc018690f0:	4c 8b ff             	mov    r15,rdi
    71dc018690f3:	48 8b 9d 98 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x168]
    71dc018690fa:	48 85 db             	test   rbx,rbx
    71dc018690fd:	74 4d                	je     0x71dc0186914c
    71dc018690ff:	48 8b f3             	mov    rsi,rbx
    71dc01869102:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc01869109:	71 00 00 
    71dc0186910c:	e8 6f bc fd ff       	call   0x71dc01844d80
    71dc01869111:	48 85 c0             	test   rax,rax
    71dc01869114:	74 1e                	je     0x71dc01869134
    71dc01869116:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    71dc01869119:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc0186911f:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01869125:	74 25                	je     0x71dc0186914c
    71dc01869127:	48 8b f8             	mov    rdi,rax
    71dc0186912a:	33 f6                	xor    esi,esi
    71dc0186912c:	ff 15 e6 c6 2a ff    	call   QWORD PTR [rip+0xffffffffff2ac6e6]        # 0x71dc00b15818
    71dc01869132:	eb 18                	jmp    0x71dc0186914c
    71dc01869134:	48 8b fb             	mov    rdi,rbx
    71dc01869137:	48 0f bf b5 a0 fe ff 	movsx  rsi,WORD PTR [rbp-0x160]
    71dc0186913e:	ff 
    71dc0186913f:	49 bb f8 36 c4 fe db 	movabs r11,0x71dbfec436f8
    71dc01869146:	71 00 00 
    71dc01869149:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186914c:	4d 8b 77 20          	mov    r14,QWORD PTR [r15+0x20]
    71dc01869150:	4d 85 f6             	test   r14,r14
    71dc01869153:	74 30                	je     0x71dc01869185
    71dc01869155:	49 8b f6             	mov    rsi,r14
    71dc01869158:	48 bf e8 18 ea ff db 	movabs rdi,0x71dbffea18e8
    71dc0186915f:	71 00 00 
    71dc01869162:	e8 19 bc fd ff       	call   0x71dc01844d80
    71dc01869167:	48 85 c0             	test   rax,rax
    71dc0186916a:	0f 84 a6 f5 ff ff    	je     0x71dc01868716
    71dc01869170:	48 8b f8             	mov    rdi,rax
    71dc01869173:	ff 15 5f 5c d1 ff    	call   QWORD PTR [rip+0xffffffffffd15c5f]        # 0x71dc0157edd8
    71dc01869179:	48 8b f8             	mov    rdi,rax
    71dc0186917c:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc0186917e:	ff 15 4c 5b d1 ff    	call   QWORD PTR [rip+0xffffffffffd15b4c]        # 0x71dc0157ecd0
    71dc01869184:	cc                   	int3
    71dc01869185:	33 d2                	xor    edx,edx
    71dc01869187:	49 89 57 20          	mov    QWORD PTR [r15+0x20],rdx
    71dc0186918b:	49 89 97 e0 00 00 00 	mov    QWORD PTR [r15+0xe0],rdx
    71dc01869192:	49 89 97 e8 00 00 00 	mov    QWORD PTR [r15+0xe8],rdx
    71dc01869199:	e9 46 e6 ff ff       	jmp    0x71dc018677e4
    71dc0186919e:	48 8b 53 20          	mov    rdx,QWORD PTR [rbx+0x20]
    71dc018691a2:	48 8b 73 28          	mov    rsi,QWORD PTR [rbx+0x28]
    71dc018691a6:	49 8b fe             	mov    rdi,r14
    71dc018691a9:	ff 15 19 63 d8 ff    	call   QWORD PTR [rip+0xffffffffffd86319]        # 0x71dc015ef4c8
    71dc018691af:	48 8b f8             	mov    rdi,rax
    71dc018691b2:	49 bb 88 35 c4 fe db 	movabs r11,0x71dbfec43588
    71dc018691b9:	71 00 00 
    71dc018691bc:	41 ff 13             	call   QWORD PTR [r11]
    71dc018691bf:	48 89 85 a8 fd ff ff 	mov    QWORD PTR [rbp-0x258],rax
    71dc018691c6:	48 8b bd a8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x258]
    71dc018691cd:	49 bb 90 35 c4 fe db 	movabs r11,0x71dbfec43590
    71dc018691d4:	71 00 00 
    71dc018691d7:	41 ff 13             	call   QWORD PTR [r11]
    71dc018691da:	85 c0                	test   eax,eax
    71dc018691dc:	74 30                	je     0x71dc0186920e
    71dc018691de:	48 8b bd a8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x258]
    71dc018691e5:	49 bb 98 35 c4 fe db 	movabs r11,0x71dbfec43598
    71dc018691ec:	71 00 00 
    71dc018691ef:	41 ff 13             	call   QWORD PTR [r11]
    71dc018691f2:	48 8b f0             	mov    rsi,rax
    71dc018691f5:	49 8d 4f 50          	lea    rcx,[r15+0x50]
    71dc018691f9:	48 8b 53 18          	mov    rdx,QWORD PTR [rbx+0x18]
    71dc018691fd:	48 8b fb             	mov    rdi,rbx
    71dc01869200:	ff 15 4a 68 d8 ff    	call   QWORD PTR [rip+0xffffffffffd8684a]        # 0x71dc015efa50
    71dc01869206:	eb be                	jmp    0x71dc018691c6
    71dc01869208:	e8 fb 83 5e fe       	call   0x71dbffe51608
    71dc0186920d:	cc                   	int3
    71dc0186920e:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    71dc01869212:	0f 8d cc e5 ff ff    	jge    0x71dc018677e4
    71dc01869218:	48 8b bd a8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x258]
    71dc0186921f:	49 bb a0 35 c4 fe db 	movabs r11,0x71dbfec435a0
    71dc01869226:	71 00 00 
    71dc01869229:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186922c:	e9 b3 e5 ff ff       	jmp    0x71dc018677e4
    71dc01869231:	41 c7 47 28 fe ff ff 	mov    DWORD PTR [r15+0x28],0xfffffffe
    71dc01869238:	ff 
    71dc01869239:	49 83 c7 38          	add    r15,0x38
    71dc0186923d:	49 83 3f 00          	cmp    QWORD PTR [r15],0x0
    71dc01869241:	75 38                	jne    0x71dc0186927b
    71dc01869243:	49 8d 7f 08          	lea    rdi,[r15+0x8]
    71dc01869247:	e8 b4 77 7e 7c       	call   0x71dc7e050a00
    71dc0186924c:	45 88 77 10          	mov    BYTE PTR [r15+0x10],r14b
    71dc01869250:	48 bf d0 1b 80 21 d4 	movabs rdi,0x71d421801bd0
    71dc01869257:	71 00 00 
    71dc0186925a:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc0186925d:	49 8b ff             	mov    rdi,r15
    71dc01869260:	e8 9b 77 7e 7c       	call   0x71dc7e050a00
    71dc01869265:	90                   	nop
    71dc01869266:	c5 f8 77             	vzeroupper
    71dc01869269:	48 81 c4 d8 02 00 00 	add    rsp,0x2d8
    71dc01869270:	5b                   	pop    rbx
    71dc01869271:	41 5c                	pop    r12
    71dc01869273:	41 5d                	pop    r13
    71dc01869275:	41 5e                	pop    r14
    71dc01869277:	41 5f                	pop    r15
    71dc01869279:	5d                   	pop    rbp
    71dc0186927a:	c3                   	ret
    71dc0186927b:	41 8b d6             	mov    edx,r14d
    71dc0186927e:	49 8b 3f             	mov    rdi,QWORD PTR [r15]
    71dc01869281:	ff 15 71 c7 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7c771]        # 0x71dc016e59f8
    71dc01869287:	eb dc                	jmp    0x71dc01869265
    71dc01869289:	50                   	push   rax
    71dc0186928a:	48 bf f0 13 10 7e dc 	movabs rdi,0x71dc7e1013f0
    71dc01869291:	71 00 00 
    71dc01869294:	48 b8 20 f8 8b 7e dc 	movabs rax,0x71dc7e8bf820
    71dc0186929b:	71 00 00 
    71dc0186929e:	ff d0                	call   rax
    71dc018692a0:	83 38 13             	cmp    DWORD PTR [rax],0x13
    71dc018692a3:	7e 10                	jle    0x71dc018692b5
    71dc018692a5:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc018692a9:	48 8b 87 98 00 00 00 	mov    rax,QWORD PTR [rdi+0x98]
    71dc018692b0:	48 85 c0             	test   rax,rax
    71dc018692b3:	75 0a                	jne    0x71dc018692bf
    71dc018692b5:	bf 13 00 00 00       	mov    edi,0x13
    71dc018692ba:	e8 81 bc fd ff       	call   0x71dc01844f40
    71dc018692bf:	48 8b d8             	mov    rbx,rax
    71dc018692c2:	48 8d 7b 18          	lea    rdi,[rbx+0x18]
    71dc018692c6:	48 8b b5 20 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2e0]
    71dc018692cd:	e8 6e 6d 3b fd       	call   0x71dbfec20040
    71dc018692d2:	48 8d 7b 20          	lea    rdi,[rbx+0x20]
    71dc018692d6:	48 8b b5 18 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2e8]
    71dc018692dd:	e8 5e 6d 3b fd       	call   0x71dbfec20040
    71dc018692e2:	90                   	nop
    71dc018692e3:	c5 f8 77             	vzeroupper
    71dc018692e6:	48 83 c4 08          	add    rsp,0x8
    71dc018692ea:	c3                   	ret
    71dc018692eb:	50                   	push   rax
    71dc018692ec:	48 8b f7             	mov    rsi,rdi
    71dc018692ef:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc018692f6:	49 8d 7f 20          	lea    rdi,[r15+0x20]
    71dc018692fa:	e8 01 77 7e 7c       	call   0x71dc7e050a00
    71dc018692ff:	48 8d 05 69 e2 ff ff 	lea    rax,[rip+0xffffffffffffe269]        # 0x71dc0186756f
    71dc01869306:	c5 f8 77             	vzeroupper
    71dc01869309:	48 83 c4 08          	add    rsp,0x8
    71dc0186930d:	c3                   	ret
    71dc0186930e:	50                   	push   rax
    71dc0186930f:	48 8b f7             	mov    rsi,rdi
    71dc01869312:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc01869319:	49 8d 7f 20          	lea    rdi,[r15+0x20]
    71dc0186931d:	e8 de 76 7e 7c       	call   0x71dc7e050a00
    71dc01869322:	48 8d 05 cb fc ff ff 	lea    rax,[rip+0xfffffffffffffccb]        # 0x71dc01868ff4
    71dc01869329:	c5 f8 77             	vzeroupper
    71dc0186932c:	48 83 c4 08          	add    rsp,0x8
    71dc01869330:	c3                   	ret
    71dc01869331:	50                   	push   rax
    71dc01869332:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    71dc01869336:	7d 1e                	jge    0x71dc01869356
    71dc01869338:	48 83 bd a8 fd ff ff 	cmp    QWORD PTR [rbp-0x258],0x0
    71dc0186933f:	00 
    71dc01869340:	74 14                	je     0x71dc01869356
    71dc01869342:	48 8b bd a8 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x258]
    71dc01869349:	49 bb a0 35 c4 fe db 	movabs r11,0x71dbfec435a0
    71dc01869350:	71 00 00 
    71dc01869353:	41 ff 13             	call   QWORD PTR [r11]
    71dc01869356:	90                   	nop
    71dc01869357:	c5 f8 77             	vzeroupper
    71dc0186935a:	48 83 c4 08          	add    rsp,0x8
    71dc0186935e:	c3                   	ret
    71dc0186935f:	50                   	push   rax
    71dc01869360:	48 8b b5 70 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x290]
    71dc01869367:	48 8b bd 80 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x280]
    71dc0186936e:	48 3b 77 10          	cmp    rsi,QWORD PTR [rdi+0x10]
    71dc01869372:	74 10                	je     0x71dc01869384
    71dc01869374:	48 8d 7f 10          	lea    rdi,[rdi+0x10]
    71dc01869378:	e8 c3 6c 3b fd       	call   0x71dbfec20040
    71dc0186937d:	48 8b bd 80 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x280]
    71dc01869384:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
    71dc01869388:	48 39 95 78 fd ff ff 	cmp    QWORD PTR [rbp-0x288],rdx
    71dc0186938f:	74 0d                	je     0x71dc0186939e
    71dc01869391:	48 8b b5 78 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x288]
    71dc01869398:	ff 15 da be 2a ff    	call   QWORD PTR [rip+0xffffffffff2abeda]        # 0x71dc00b15278
    71dc0186939e:	90                   	nop
    71dc0186939f:	c5 f8 77             	vzeroupper
    71dc018693a2:	48 83 c4 08          	add    rsp,0x8
    71dc018693a6:	c3                   	ret
    71dc018693a7:	50                   	push   rax
    71dc018693a8:	48 83 bd 60 fd ff ff 	cmp    QWORD PTR [rbp-0x2a0],0x0
    71dc018693af:	00 
    71dc018693b0:	74 77                	je     0x71dc01869429
    71dc018693b2:	48 8b 85 60 fd ff ff 	mov    rax,QWORD PTR [rbp-0x2a0]
    71dc018693b9:	48 8d 78 08          	lea    rdi,[rax+0x8]
    71dc018693bd:	33 f6                	xor    esi,esi
    71dc018693bf:	48 87 37             	xchg   QWORD PTR [rdi],rsi
    71dc018693c2:	48 85 f6             	test   rsi,rsi
    71dc018693c5:	74 62                	je     0x71dc01869429
    71dc018693c7:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
    71dc018693cb:	48 85 ff             	test   rdi,rdi
    71dc018693ce:	7e 4c                	jle    0x71dc0186941c
    71dc018693d0:	48 8b 4e 20          	mov    rcx,QWORD PTR [rsi+0x20]
    71dc018693d4:	48 2b cf             	sub    rcx,rdi
    71dc018693d7:	33 ff                	xor    edi,edi
    71dc018693d9:	48 85 c9             	test   rcx,rcx
    71dc018693dc:	48 0f 4f f9          	cmovg  rdi,rcx
    71dc018693e0:	48 89 7e 20          	mov    QWORD PTR [rsi+0x20],rdi
    71dc018693e4:	48 8b 7e 08          	mov    rdi,QWORD PTR [rsi+0x8]
    71dc018693e8:	48 8b 4e 20          	mov    rcx,QWORD PTR [rsi+0x20]
    71dc018693ec:	48 03 4e 28          	add    rcx,QWORD PTR [rsi+0x28]
    71dc018693f0:	70 3f                	jo     0x71dc01869431
    71dc018693f2:	48 be c0 b3 f2 00 dc 	movabs rsi,0x71dc00f2b3c0
    71dc018693f9:	71 00 00 
    71dc018693fc:	48 39 37             	cmp    QWORD PTR [rdi],rsi
    71dc018693ff:	75 0b                	jne    0x71dc0186940c
    71dc01869401:	48 8b f1             	mov    rsi,rcx
    71dc01869404:	ff 15 3e 20 6c ff    	call   QWORD PTR [rip+0xffffffffff6c203e]        # 0x71dc00f2b448
    71dc0186940a:	eb 10                	jmp    0x71dc0186941c
    71dc0186940c:	48 8b f1             	mov    rsi,rcx
    71dc0186940f:	49 bb 20 36 c4 fe db 	movabs r11,0x71dbfec43620
    71dc01869416:	71 00 00 
    71dc01869419:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186941c:	33 ff                	xor    edi,edi
    71dc0186941e:	48 8b 85 60 fd ff ff 	mov    rax,QWORD PTR [rbp-0x2a0]
    71dc01869425:	48 89 78 10          	mov    QWORD PTR [rax+0x10],rdi
    71dc01869429:	c5 f8 77             	vzeroupper
    71dc0186942c:	48 83 c4 08          	add    rsp,0x8
    71dc01869430:	c3                   	ret
    71dc01869431:	e8 ba 81 5e fe       	call   0x71dbffe515f0
    71dc01869436:	cc                   	int3
    71dc01869437:	50                   	push   rax
    71dc01869438:	48 8b b5 28 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2d8]
    71dc0186943f:	48 8b bd 38 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x2c8]
    71dc01869446:	48 3b 77 10          	cmp    rsi,QWORD PTR [rdi+0x10]
    71dc0186944a:	74 10                	je     0x71dc0186945c
    71dc0186944c:	48 8d 7f 10          	lea    rdi,[rdi+0x10]
    71dc01869450:	e8 eb 6b 3b fd       	call   0x71dbfec20040
    71dc01869455:	48 8b bd 38 fd ff ff 	mov    rdi,QWORD PTR [rbp-0x2c8]
    71dc0186945c:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
    71dc01869460:	48 39 95 30 fd ff ff 	cmp    QWORD PTR [rbp-0x2d0],rdx
    71dc01869467:	74 0d                	je     0x71dc01869476
    71dc01869469:	48 8b b5 30 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x2d0]
    71dc01869470:	ff 15 02 be 2a ff    	call   QWORD PTR [rip+0xffffffffff2abe02]        # 0x71dc00b15278
    71dc01869476:	90                   	nop
    71dc01869477:	c5 f8 77             	vzeroupper
    71dc0186947a:	48 83 c4 08          	add    rsp,0x8
    71dc0186947e:	c3                   	ret
    71dc0186947f:	50                   	push   rax
    71dc01869480:	48 8b f7             	mov    rsi,rdi
    71dc01869483:	4c 8b bd b8 fd ff ff 	mov    r15,QWORD PTR [rbp-0x248]
    71dc0186948a:	41 c7 47 28 fe ff ff 	mov    DWORD PTR [r15+0x28],0xfffffffe
    71dc01869491:	ff 
    71dc01869492:	49 8d 7f 38          	lea    rdi,[r15+0x38]
    71dc01869496:	ff 15 a4 66 d8 ff    	call   QWORD PTR [rip+0xffffffffffd866a4]        # 0x71dc015efb40
    71dc0186949c:	48 8d 05 c2 fd ff ff 	lea    rax,[rip+0xfffffffffffffdc2]        # 0x71dc01869265
    71dc018694a3:	c5 f8 77             	vzeroupper
    71dc018694a6:	48 83 c4 08          	add    rsp,0x8
    71dc018694aa:	c3                   	ret
