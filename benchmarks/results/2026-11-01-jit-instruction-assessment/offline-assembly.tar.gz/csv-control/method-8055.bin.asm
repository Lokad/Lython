
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-8055.bin:     file format binary


Disassembly of section .data:

000071dc01861880 <.data>:
    71dc01861880:	55                   	push   rbp
    71dc01861881:	41 57                	push   r15
    71dc01861883:	41 56                	push   r14
    71dc01861885:	41 55                	push   r13
    71dc01861887:	41 54                	push   r12
    71dc01861889:	53                   	push   rbx
    71dc0186188a:	48 81 ec d8 00 00 00 	sub    rsp,0xd8
    71dc01861891:	48 8d ac 24 00 01 00 	lea    rbp,[rsp+0x100]
    71dc01861898:	00 
    71dc01861899:	33 c0                	xor    eax,eax
    71dc0186189b:	48 89 85 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rax
    71dc018618a2:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    71dc018618a7:	62 71 7e 48 7f 85 70 	vmovdqu32 ZMMWORD PTR [rbp-0x90],zmm8
    71dc018618ae:	ff ff ff 
    71dc018618b1:	c5 7e 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm8
    71dc018618b6:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    71dc018618ba:	4c 8b ff             	mov    r15,rdi
    71dc018618bd:	4c 8b f6             	mov    r14,rsi
    71dc018618c0:	48 8b da             	mov    rbx,rdx
    71dc018618c3:	84 c9                	test   cl,cl
    71dc018618c5:	74 27                	je     0x71dc018618ee
    71dc018618c7:	4c 8b 6b 18          	mov    r13,QWORD PTR [rbx+0x18]
    71dc018618cb:	4d 85 ed             	test   r13,r13
    71dc018618ce:	0f 85 a9 07 00 00    	jne    0x71dc0186207d
    71dc018618d4:	80 bb 95 00 00 00 00 	cmp    BYTE PTR [rbx+0x95],0x0
    71dc018618db:	0f 85 11 08 00 00    	jne    0x71dc018620f2
    71dc018618e1:	80 bb 96 00 00 00 00 	cmp    BYTE PTR [rbx+0x96],0x0
    71dc018618e8:	0f 85 04 08 00 00    	jne    0x71dc018620f2
    71dc018618ee:	48 8b 7b 60          	mov    rdi,QWORD PTR [rbx+0x60]
    71dc018618f2:	4c 8b 6f 08          	mov    r13,QWORD PTR [rdi+0x8]
    71dc018618f6:	48 bf a0 fb 4d 00 dc 	movabs rdi,0x71dc004dfba0
    71dc018618fd:	71 00 00 
    71dc01861900:	49 39 7d 00          	cmp    QWORD PTR [r13+0x0],rdi
    71dc01861904:	0f 85 6d 08 00 00    	jne    0x71dc01862177
    71dc0186190a:	49 8b f7             	mov    rsi,r15
    71dc0186190d:	49 83 7d 08 00       	cmp    QWORD PTR [r13+0x8],0x0
    71dc01861912:	0f 84 ae 00 00 00    	je     0x71dc018619c6
    71dc01861918:	4d 8b 65 10          	mov    r12,QWORD PTR [r13+0x10]
    71dc0186191c:	33 c0                	xor    eax,eax
    71dc0186191e:	89 45 ac             	mov    DWORD PTR [rbp-0x54],eax
    71dc01861921:	49 8b 4d 18          	mov    rcx,QWORD PTR [r13+0x18]
    71dc01861925:	48 89 8d 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rcx
    71dc0186192c:	48 85 f6             	test   rsi,rsi
    71dc0186192f:	0f 84 ed 07 00 00    	je     0x71dc01862122
    71dc01861935:	48 8b f9             	mov    rdi,rcx
    71dc01861938:	49 bb 60 34 c4 fe db 	movabs r11,0x71dbfec43460
    71dc0186193f:	71 00 00 
    71dc01861942:	41 ff 13             	call   QWORD PTR [r11]
    71dc01861945:	48 8b 8d 50 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xb0]
    71dc0186194c:	89 45 a8             	mov    DWORD PTR [rbp-0x58],eax
    71dc0186194f:	49 8b 75 08          	mov    rsi,QWORD PTR [r13+0x8]
    71dc01861953:	8b f8                	mov    edi,eax
    71dc01861955:	49 0f af 7d 20       	imul   rdi,QWORD PTR [r13+0x20]
    71dc0186195a:	48 c1 ef 20          	shr    rdi,0x20
    71dc0186195e:	48 ff c7             	inc    rdi
    71dc01861961:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc01861964:	48 0f af fa          	imul   rdi,rdx
    71dc01861968:	48 c1 ef 20          	shr    rdi,0x20
    71dc0186196c:	3b 7e 08             	cmp    edi,DWORD PTR [rsi+0x8]
    71dc0186196f:	0f 83 d7 0c 00 00    	jae    0x71dc0186264c
    71dc01861975:	8b ff                	mov    edi,edi
    71dc01861977:	48 8d 74 be 10       	lea    rsi,[rsi+rdi*4+0x10]
    71dc0186197c:	44 8b 06             	mov    r8d,DWORD PTR [rsi]
    71dc0186197f:	41 ff c8             	dec    r8d
    71dc01861982:	45 8b 6c 24 08       	mov    r13d,DWORD PTR [r12+0x8]
    71dc01861987:	45 3b e8             	cmp    r13d,r8d
    71dc0186198a:	76 3a                	jbe    0x71dc018619c6
    71dc0186198c:	41 8b f0             	mov    esi,r8d
    71dc0186198f:	48 c1 e6 04          	shl    rsi,0x4
    71dc01861993:	4d 8d 44 34 10       	lea    r8,[r12+rsi*1+0x10]
    71dc01861998:	4c 89 85 48 ff ff ff 	mov    QWORD PTR [rbp-0xb8],r8
    71dc0186199f:	41 39 40 08          	cmp    DWORD PTR [r8+0x8],eax
    71dc018619a3:	0f 84 86 07 00 00    	je     0x71dc0186212f
    71dc018619a9:	45 8b 40 0c          	mov    r8d,DWORD PTR [r8+0xc]
    71dc018619ad:	8b 7d ac             	mov    edi,DWORD PTR [rbp-0x54]
    71dc018619b0:	ff c7                	inc    edi
    71dc018619b2:	44 3b ef             	cmp    r13d,edi
    71dc018619b5:	0f 82 b5 07 00 00    	jb     0x71dc01862170
    71dc018619bb:	45 3b e8             	cmp    r13d,r8d
    71dc018619be:	89 7d ac             	mov    DWORD PTR [rbp-0x54],edi
    71dc018619c1:	8b 45 a8             	mov    eax,DWORD PTR [rbp-0x58]
    71dc018619c4:	77 c6                	ja     0x71dc0186198c
    71dc018619c6:	4c 8b 6b 68          	mov    r13,QWORD PTR [rbx+0x68]
    71dc018619ca:	45 38 6d 00          	cmp    BYTE PTR [r13+0x0],r13b
    71dc018619ce:	4d 85 ff             	test   r15,r15
    71dc018619d1:	0f 84 2f 08 00 00    	je     0x71dc01862206
    71dc018619d7:	49 83 7d 08 00       	cmp    QWORD PTR [r13+0x8],0x0
    71dc018619dc:	0f 84 ed 00 00 00    	je     0x71dc01861acf
    71dc018619e2:	4d 8b 65 18          	mov    r12,QWORD PTR [r13+0x18]
    71dc018619e6:	48 bf d8 84 f3 ff db 	movabs rdi,0x71dbfff384d8
    71dc018619ed:	71 00 00 
    71dc018619f0:	49 39 3c 24          	cmp    QWORD PTR [r12],rdi
    71dc018619f4:	0f 85 29 08 00 00    	jne    0x71dc01862223
    71dc018619fa:	49 8d 7f 0c          	lea    rdi,[r15+0xc]
    71dc018619fe:	48 89 7d 98          	mov    QWORD PTR [rbp-0x68],rdi
    71dc01861a02:	bf 05 15 05 15       	mov    edi,0x15051505
    71dc01861a07:	be 05 15 05 15       	mov    esi,0x15051505
    71dc01861a0c:	4c 8b 5d 98          	mov    r11,QWORD PTR [rbp-0x68]
    71dc01861a10:	41 8b 47 08          	mov    eax,DWORD PTR [r15+0x8]
    71dc01861a14:	83 f8 02             	cmp    eax,0x2
    71dc01861a17:	7e 21                	jle    0x71dc01861a3a
    71dc01861a19:	83 c0 fc             	add    eax,0xfffffffc
    71dc01861a1c:	8b cf                	mov    ecx,edi
    71dc01861a1e:	c1 c1 05             	rol    ecx,0x5
    71dc01861a21:	03 f9                	add    edi,ecx
    71dc01861a23:	41 33 3b             	xor    edi,DWORD PTR [r11]
    71dc01861a26:	8b ce                	mov    ecx,esi
    71dc01861a28:	c1 c1 05             	rol    ecx,0x5
    71dc01861a2b:	03 f1                	add    esi,ecx
    71dc01861a2d:	41 33 73 04          	xor    esi,DWORD PTR [r11+0x4]
    71dc01861a31:	49 83 c3 08          	add    r11,0x8
    71dc01861a35:	83 f8 02             	cmp    eax,0x2
    71dc01861a38:	7f df                	jg     0x71dc01861a19
    71dc01861a3a:	85 c0                	test   eax,eax
    71dc01861a3c:	0f 8f d0 07 00 00    	jg     0x71dc01862212
    71dc01861a42:	69 c6 65 8b 58 5d    	imul   eax,esi,0x5d588b65
    71dc01861a48:	03 c7                	add    eax,edi
    71dc01861a4a:	33 ff                	xor    edi,edi
    71dc01861a4c:	48 89 7d 98          	mov    QWORD PTR [rbp-0x68],rdi
    71dc01861a50:	89 45 a4             	mov    DWORD PTR [rbp-0x5c],eax
    71dc01861a53:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
    71dc01861a57:	8b f0                	mov    esi,eax
    71dc01861a59:	49 0f af 75 30       	imul   rsi,QWORD PTR [r13+0x30]
    71dc01861a5e:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861a62:	48 ff c6             	inc    rsi
    71dc01861a65:	8b 7a 08             	mov    edi,DWORD PTR [rdx+0x8]
    71dc01861a68:	8b cf                	mov    ecx,edi
    71dc01861a6a:	48 0f af f1          	imul   rsi,rcx
    71dc01861a6e:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861a72:	3b f7                	cmp    esi,edi
    71dc01861a74:	0f 83 d2 0b 00 00    	jae    0x71dc0186264c
    71dc01861a7a:	8b f6                	mov    esi,esi
    71dc01861a7c:	48 8d 54 b2 10       	lea    rdx,[rdx+rsi*4+0x10]
    71dc01861a81:	8b 12                	mov    edx,DWORD PTR [rdx]
    71dc01861a83:	4d 8b 6d 10          	mov    r13,QWORD PTR [r13+0x10]
    71dc01861a87:	33 c9                	xor    ecx,ecx
    71dc01861a89:	89 4d a0             	mov    DWORD PTR [rbp-0x60],ecx
    71dc01861a8c:	ff ca                	dec    edx
    71dc01861a8e:	41 39 55 08          	cmp    DWORD PTR [r13+0x8],edx
    71dc01861a92:	76 3b                	jbe    0x71dc01861acf
    71dc01861a94:	8b d2                	mov    edx,edx
    71dc01861a96:	48 8d 14 52          	lea    rdx,[rdx+rdx*2]
    71dc01861a9a:	4d 8d 44 d5 10       	lea    r8,[r13+rdx*8+0x10]
    71dc01861a9f:	4c 89 85 40 ff ff ff 	mov    QWORD PTR [rbp-0xc0],r8
    71dc01861aa6:	41 39 40 10          	cmp    DWORD PTR [r8+0x10],eax
    71dc01861aaa:	0f 84 10 01 00 00    	je     0x71dc01861bc0
    71dc01861ab0:	41 8b 50 14          	mov    edx,DWORD PTR [r8+0x14]
    71dc01861ab4:	8b 4d a0             	mov    ecx,DWORD PTR [rbp-0x60]
    71dc01861ab7:	ff c1                	inc    ecx
    71dc01861ab9:	41 39 4d 08          	cmp    DWORD PTR [r13+0x8],ecx
    71dc01861abd:	0f 82 ad 06 00 00    	jb     0x71dc01862170
    71dc01861ac3:	41 39 55 08          	cmp    DWORD PTR [r13+0x8],edx
    71dc01861ac7:	89 4d a0             	mov    DWORD PTR [rbp-0x60],ecx
    71dc01861aca:	8b 45 a4             	mov    eax,DWORD PTR [rbp-0x5c]
    71dc01861acd:	77 c5                	ja     0x71dc01861a94
    71dc01861acf:	4c 8b eb             	mov    r13,rbx
    71dc01861ad2:	4d 85 ed             	test   r13,r13
    71dc01861ad5:	0f 85 70 01 00 00    	jne    0x71dc01861c4b
    71dc01861adb:	48 8b 7b 30          	mov    rdi,QWORD PTR [rbx+0x30]
    71dc01861adf:	4c 8b a7 e0 00 00 00 	mov    r12,QWORD PTR [rdi+0xe0]
    71dc01861ae6:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc01861aea:	49 83 7c 24 08 00    	cmp    QWORD PTR [r12+0x8],0x0
    71dc01861af0:	0f 84 b5 00 00 00    	je     0x71dc01861bab
    71dc01861af6:	49 8b 5c 24 18       	mov    rbx,QWORD PTR [r12+0x18]
    71dc01861afb:	48 bf d8 84 f3 ff db 	movabs rdi,0x71dbfff384d8
    71dc01861b02:	71 00 00 
    71dc01861b05:	48 39 3b             	cmp    QWORD PTR [rbx],rdi
    71dc01861b08:	0f 85 02 0b 00 00    	jne    0x71dc01862610
    71dc01861b0e:	49 8b ff             	mov    rdi,r15
    71dc01861b11:	ff 15 e1 4a 5f fe    	call   QWORD PTR [rip+0xfffffffffe5f4ae1]        # 0x71dbffe565f8
    71dc01861b17:	44 8b e8             	mov    r13d,eax
    71dc01861b1a:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
    71dc01861b1f:	41 8b f5             	mov    esi,r13d
    71dc01861b22:	49 0f af 74 24 30    	imul   rsi,QWORD PTR [r12+0x30]
    71dc01861b28:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861b2c:	48 ff c6             	inc    rsi
    71dc01861b2f:	8b 7a 08             	mov    edi,DWORD PTR [rdx+0x8]
    71dc01861b32:	8b c7                	mov    eax,edi
    71dc01861b34:	48 0f af f0          	imul   rsi,rax
    71dc01861b38:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861b3c:	3b f7                	cmp    esi,edi
    71dc01861b3e:	0f 83 08 0b 00 00    	jae    0x71dc0186264c
    71dc01861b44:	8b f6                	mov    esi,esi
    71dc01861b46:	48 8d 54 b2 10       	lea    rdx,[rdx+rsi*4+0x10]
    71dc01861b4b:	8b 12                	mov    edx,DWORD PTR [rdx]
    71dc01861b4d:	4d 8b 64 24 10       	mov    r12,QWORD PTR [r12+0x10]
    71dc01861b52:	33 c0                	xor    eax,eax
    71dc01861b54:	89 85 64 ff ff ff    	mov    DWORD PTR [rbp-0x9c],eax
    71dc01861b5a:	ff ca                	dec    edx
    71dc01861b5c:	41 8b 4c 24 08       	mov    ecx,DWORD PTR [r12+0x8]
    71dc01861b61:	89 8d 60 ff ff ff    	mov    DWORD PTR [rbp-0xa0],ecx
    71dc01861b67:	3b ca                	cmp    ecx,edx
    71dc01861b69:	76 40                	jbe    0x71dc01861bab
    71dc01861b6b:	8b d2                	mov    edx,edx
    71dc01861b6d:	48 8d 14 52          	lea    rdx,[rdx+rdx*2]
    71dc01861b71:	4d 8d 44 d4 10       	lea    r8,[r12+rdx*8+0x10]
    71dc01861b76:	4c 89 85 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],r8
    71dc01861b7d:	45 39 68 10          	cmp    DWORD PTR [r8+0x10],r13d
    71dc01861b81:	0f 84 53 04 00 00    	je     0x71dc01861fda
    71dc01861b87:	41 8b 50 14          	mov    edx,DWORD PTR [r8+0x14]
    71dc01861b8b:	8b 85 64 ff ff ff    	mov    eax,DWORD PTR [rbp-0x9c]
    71dc01861b91:	ff c0                	inc    eax
    71dc01861b93:	8b 8d 60 ff ff ff    	mov    ecx,DWORD PTR [rbp-0xa0]
    71dc01861b99:	3b c8                	cmp    ecx,eax
    71dc01861b9b:	0f 82 cf 05 00 00    	jb     0x71dc01862170
    71dc01861ba1:	3b ca                	cmp    ecx,edx
    71dc01861ba3:	89 85 64 ff ff ff    	mov    DWORD PTR [rbp-0x9c],eax
    71dc01861ba9:	77 c0                	ja     0x71dc01861b6b
    71dc01861bab:	49 8b ff             	mov    rdi,r15
    71dc01861bae:	49 8b f6             	mov    rsi,r14
    71dc01861bb1:	ff 15 21 58 d8 ff    	call   QWORD PTR [rip+0xffffffffffd85821]        # 0x71dc015e73d8
    71dc01861bb7:	48 8b f8             	mov    rdi,rax
    71dc01861bba:	e8 e1 03 55 7c       	call   0x71dc7ddb1fa0
    71dc01861bbf:	cc                   	int3
    71dc01861bc0:	49 8b 30             	mov    rsi,QWORD PTR [r8]
    71dc01861bc3:	48 ba d8 84 f3 ff db 	movabs rdx,0x71dbfff384d8
    71dc01861bca:	71 00 00 
    71dc01861bcd:	49 39 14 24          	cmp    QWORD PTR [r12],rdx
    71dc01861bd1:	0f 85 6d 06 00 00    	jne    0x71dc01862244
    71dc01861bd7:	49 3b f7             	cmp    rsi,r15
    71dc01861bda:	74 66                	je     0x71dc01861c42
    71dc01861bdc:	48 85 f6             	test   rsi,rsi
    71dc01861bdf:	0f 84 56 06 00 00    	je     0x71dc0186223b
    71dc01861be5:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc01861be8:	41 3b 57 08          	cmp    edx,DWORD PTR [r15+0x8]
    71dc01861bec:	0f 85 49 06 00 00    	jne    0x71dc0186223b
    71dc01861bf2:	48 8d 7e 0c          	lea    rdi,[rsi+0xc]
    71dc01861bf6:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc01861bf9:	03 d2                	add    edx,edx
    71dc01861bfb:	49 8d 77 0c          	lea    rsi,[r15+0xc]
    71dc01861bff:	ff 15 fb a9 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa9fb]        # 0x71dbffe5c600
    71dc01861c05:	85 c0                	test   eax,eax
    71dc01861c07:	4c 8b 85 40 ff ff ff 	mov    r8,QWORD PTR [rbp-0xc0]
    71dc01861c0e:	0f 84 9c fe ff ff    	je     0x71dc01861ab0
    71dc01861c14:	48 8d 55 b0          	lea    rdx,[rbp-0x50]
    71dc01861c18:	48 8b fb             	mov    rdi,rbx
    71dc01861c1b:	49 8b f7             	mov    rsi,r15
    71dc01861c1e:	ff 15 cc 57 d8 ff    	call   QWORD PTR [rip+0xffffffffffd857cc]        # 0x71dc015e73f0
    71dc01861c24:	85 c0                	test   eax,eax
    71dc01861c26:	0f 84 30 06 00 00    	je     0x71dc0186225c
    71dc01861c2c:	48 8b 45 b0          	mov    rax,QWORD PTR [rbp-0x50]
    71dc01861c30:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    71dc01861c37:	5b                   	pop    rbx
    71dc01861c38:	41 5c                	pop    r12
    71dc01861c3a:	41 5d                	pop    r13
    71dc01861c3c:	41 5e                	pop    r14
    71dc01861c3e:	41 5f                	pop    r15
    71dc01861c40:	5d                   	pop    rbp
    71dc01861c41:	c3                   	ret
    71dc01861c42:	bf 01 00 00 00       	mov    edi,0x1
    71dc01861c47:	8b c7                	mov    eax,edi
    71dc01861c49:	eb ba                	jmp    0x71dc01861c05
    71dc01861c4b:	41 80 bd 95 00 00 00 	cmp    BYTE PTR [r13+0x95],0x0
    71dc01861c52:	00 
    71dc01861c53:	0f 85 18 06 00 00    	jne    0x71dc01862271
    71dc01861c59:	80 bb 95 00 00 00 00 	cmp    BYTE PTR [rbx+0x95],0x0
    71dc01861c60:	0f 85 26 06 00 00    	jne    0x71dc0186228c
    71dc01861c66:	4c 3b eb             	cmp    r13,rbx
    71dc01861c69:	0f 85 67 06 00 00    	jne    0x71dc018622d6
    71dc01861c6f:	4d 8b 65 70          	mov    r12,QWORD PTR [r13+0x70]
    71dc01861c73:	4d 85 e4             	test   r12,r12
    71dc01861c76:	0f 84 24 01 00 00    	je     0x71dc01861da0
    71dc01861c7c:	33 ff                	xor    edi,edi
    71dc01861c7e:	89 7d 90             	mov    DWORD PTR [rbp-0x70],edi
    71dc01861c81:	89 7d 88             	mov    DWORD PTR [rbp-0x78],edi
    71dc01861c84:	49 8b 7c 24 08       	mov    rdi,QWORD PTR [r12+0x8]
    71dc01861c89:	48 8b 47 28          	mov    rax,QWORD PTR [rdi+0x28]
    71dc01861c8d:	48 bf 30 b8 17 01 dc 	movabs rdi,0x71dc0117b830
    71dc01861c94:	71 00 00 
    71dc01861c97:	48 39 38             	cmp    QWORD PTR [rax],rdi
    71dc01861c9a:	0f 85 56 07 00 00    	jne    0x71dc018623f6
    71dc01861ca0:	48 89 85 38 ff ff ff 	mov    QWORD PTR [rbp-0xc8],rax
    71dc01861ca7:	48 83 78 08 00       	cmp    QWORD PTR [rax+0x8],0x0
    71dc01861cac:	0f 84 dd 00 00 00    	je     0x71dc01861d8f
    71dc01861cb2:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
    71dc01861cb6:	48 89 8d 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rcx
    71dc01861cbd:	48 bf d8 84 f3 ff db 	movabs rdi,0x71dbfff384d8
    71dc01861cc4:	71 00 00 
    71dc01861cc7:	48 39 39             	cmp    QWORD PTR [rcx],rdi
    71dc01861cca:	0f 85 5c 06 00 00    	jne    0x71dc0186232c
    71dc01861cd0:	49 8d 7f 0c          	lea    rdi,[r15+0xc]
    71dc01861cd4:	48 89 bd 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rdi
    71dc01861cdb:	bf 05 15 05 15       	mov    edi,0x15051505
    71dc01861ce0:	be 05 15 05 15       	mov    esi,0x15051505
    71dc01861ce5:	4c 8b 9d 78 ff ff ff 	mov    r11,QWORD PTR [rbp-0x88]
    71dc01861cec:	41 8b 57 08          	mov    edx,DWORD PTR [r15+0x8]
    71dc01861cf0:	83 fa 02             	cmp    edx,0x2
    71dc01861cf3:	7e 27                	jle    0x71dc01861d1c
    71dc01861cf5:	83 c2 fc             	add    edx,0xfffffffc
    71dc01861cf8:	44 8b c7             	mov    r8d,edi
    71dc01861cfb:	41 c1 c0 05          	rol    r8d,0x5
    71dc01861cff:	41 03 f8             	add    edi,r8d
    71dc01861d02:	41 33 3b             	xor    edi,DWORD PTR [r11]
    71dc01861d05:	44 8b c6             	mov    r8d,esi
    71dc01861d08:	41 c1 c0 05          	rol    r8d,0x5
    71dc01861d0c:	41 03 f0             	add    esi,r8d
    71dc01861d0f:	41 33 73 04          	xor    esi,DWORD PTR [r11+0x4]
    71dc01861d13:	49 83 c3 08          	add    r11,0x8
    71dc01861d17:	83 fa 02             	cmp    edx,0x2
    71dc01861d1a:	7f d9                	jg     0x71dc01861cf5
    71dc01861d1c:	85 d2                	test   edx,edx
    71dc01861d1e:	0f 8f f7 05 00 00    	jg     0x71dc0186231b
    71dc01861d24:	69 d6 65 8b 58 5d    	imul   edx,esi,0x5d588b65
    71dc01861d2a:	03 d7                	add    edx,edi
    71dc01861d2c:	33 ff                	xor    edi,edi
    71dc01861d2e:	48 89 bd 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rdi
    71dc01861d35:	89 55 84             	mov    DWORD PTR [rbp-0x7c],edx
    71dc01861d38:	48 8b 85 38 ff ff ff 	mov    rax,QWORD PTR [rbp-0xc8]
    71dc01861d3f:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    71dc01861d43:	8b f2                	mov    esi,edx
    71dc01861d45:	48 0f af 70 30       	imul   rsi,QWORD PTR [rax+0x30]
    71dc01861d4a:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861d4e:	48 ff c6             	inc    rsi
    71dc01861d51:	44 8b 47 08          	mov    r8d,DWORD PTR [rdi+0x8]
    71dc01861d55:	45 8b c8             	mov    r9d,r8d
    71dc01861d58:	49 0f af f1          	imul   rsi,r9
    71dc01861d5c:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861d60:	41 3b f0             	cmp    esi,r8d
    71dc01861d63:	0f 83 e3 08 00 00    	jae    0x71dc0186264c
    71dc01861d69:	8b f6                	mov    esi,esi
    71dc01861d6b:	48 8d 7c b7 10       	lea    rdi,[rdi+rsi*4+0x10]
    71dc01861d70:	8b 3f                	mov    edi,DWORD PTR [rdi]
    71dc01861d72:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
    71dc01861d76:	48 89 85 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rax
    71dc01861d7d:	45 33 c0             	xor    r8d,r8d
    71dc01861d80:	44 89 45 80          	mov    DWORD PTR [rbp-0x80],r8d
    71dc01861d84:	ff cf                	dec    edi
    71dc01861d86:	39 78 08             	cmp    DWORD PTR [rax+0x8],edi
    71dc01861d89:	0f 87 be 05 00 00    	ja     0x71dc0186234d
    71dc01861d8f:	33 d2                	xor    edx,edx
    71dc01861d91:	89 55 90             	mov    DWORD PTR [rbp-0x70],edx
    71dc01861d94:	49 83 7c 24 20 00    	cmp    QWORD PTR [r12+0x20],0x0
    71dc01861d9a:	0f 85 a6 06 00 00    	jne    0x71dc01862446
    71dc01861da0:	80 bb 96 00 00 00 00 	cmp    BYTE PTR [rbx+0x96],0x0
    71dc01861da7:	0f 85 f6 06 00 00    	jne    0x71dc018624a3
    71dc01861dad:	4d 8b 65 08          	mov    r12,QWORD PTR [r13+0x8]
    71dc01861db1:	4d 85 e4             	test   r12,r12
    71dc01861db4:	0f 84 f7 06 00 00    	je     0x71dc018624b1
    71dc01861dba:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc01861dbe:	49 83 7c 24 08 00    	cmp    QWORD PTR [r12+0x8],0x0
    71dc01861dc4:	0f 84 25 01 00 00    	je     0x71dc01861eef
    71dc01861dca:	49 8b 44 24 18       	mov    rax,QWORD PTR [r12+0x18]
    71dc01861dcf:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
    71dc01861dd6:	48 bf d8 84 f3 ff db 	movabs rdi,0x71dbfff384d8
    71dc01861ddd:	71 00 00 
    71dc01861de0:	48 39 38             	cmp    QWORD PTR [rax],rdi
    71dc01861de3:	0f 85 ef 06 00 00    	jne    0x71dc018624d8
    71dc01861de9:	49 8d 7f 0c          	lea    rdi,[r15+0xc]
    71dc01861ded:	48 89 bd 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdi
    71dc01861df4:	bf 05 15 05 15       	mov    edi,0x15051505
    71dc01861df9:	be 05 15 05 15       	mov    esi,0x15051505
    71dc01861dfe:	4c 8b 9d 68 ff ff ff 	mov    r11,QWORD PTR [rbp-0x98]
    71dc01861e05:	41 8b 4f 08          	mov    ecx,DWORD PTR [r15+0x8]
    71dc01861e09:	83 f9 02             	cmp    ecx,0x2
    71dc01861e0c:	7e 21                	jle    0x71dc01861e2f
    71dc01861e0e:	83 c1 fc             	add    ecx,0xfffffffc
    71dc01861e11:	8b d7                	mov    edx,edi
    71dc01861e13:	c1 c2 05             	rol    edx,0x5
    71dc01861e16:	03 fa                	add    edi,edx
    71dc01861e18:	41 33 3b             	xor    edi,DWORD PTR [r11]
    71dc01861e1b:	8b d6                	mov    edx,esi
    71dc01861e1d:	c1 c2 05             	rol    edx,0x5
    71dc01861e20:	03 f2                	add    esi,edx
    71dc01861e22:	41 33 73 04          	xor    esi,DWORD PTR [r11+0x4]
    71dc01861e26:	49 83 c3 08          	add    r11,0x8
    71dc01861e2a:	83 f9 02             	cmp    ecx,0x2
    71dc01861e2d:	7f df                	jg     0x71dc01861e0e
    71dc01861e2f:	85 c9                	test   ecx,ecx
    71dc01861e31:	0f 8f 90 06 00 00    	jg     0x71dc018624c7
    71dc01861e37:	69 ce 65 8b 58 5d    	imul   ecx,esi,0x5d588b65
    71dc01861e3d:	03 cf                	add    ecx,edi
    71dc01861e3f:	33 ff                	xor    edi,edi
    71dc01861e41:	48 89 bd 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdi
    71dc01861e48:	89 8d 74 ff ff ff    	mov    DWORD PTR [rbp-0x8c],ecx
    71dc01861e4e:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
    71dc01861e53:	8b f1                	mov    esi,ecx
    71dc01861e55:	49 0f af 74 24 30    	imul   rsi,QWORD PTR [r12+0x30]
    71dc01861e5b:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861e5f:	48 ff c6             	inc    rsi
    71dc01861e62:	8b 7a 08             	mov    edi,DWORD PTR [rdx+0x8]
    71dc01861e65:	44 8b c7             	mov    r8d,edi
    71dc01861e68:	49 0f af f0          	imul   rsi,r8
    71dc01861e6c:	48 c1 ee 20          	shr    rsi,0x20
    71dc01861e70:	3b f7                	cmp    esi,edi
    71dc01861e72:	0f 83 d4 07 00 00    	jae    0x71dc0186264c
    71dc01861e78:	8b f6                	mov    esi,esi
    71dc01861e7a:	48 8d 54 b2 10       	lea    rdx,[rdx+rsi*4+0x10]
    71dc01861e7f:	8b 12                	mov    edx,DWORD PTR [rdx]
    71dc01861e81:	4d 8b 64 24 10       	mov    r12,QWORD PTR [r12+0x10]
    71dc01861e86:	45 33 c0             	xor    r8d,r8d
    71dc01861e89:	44 89 85 70 ff ff ff 	mov    DWORD PTR [rbp-0x90],r8d
    71dc01861e90:	ff ca                	dec    edx
    71dc01861e92:	45 8b 4c 24 08       	mov    r9d,DWORD PTR [r12+0x8]
    71dc01861e97:	44 89 8d 5c ff ff ff 	mov    DWORD PTR [rbp-0xa4],r9d
    71dc01861e9e:	44 3b ca             	cmp    r9d,edx
    71dc01861ea1:	76 4c                	jbe    0x71dc01861eef
    71dc01861ea3:	8b d2                	mov    edx,edx
    71dc01861ea5:	48 8d 14 52          	lea    rdx,[rdx+rdx*2]
    71dc01861ea9:	4d 8d 54 d4 10       	lea    r10,[r12+rdx*8+0x10]
    71dc01861eae:	4c 89 95 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],r10
    71dc01861eb5:	41 39 4a 10          	cmp    DWORD PTR [r10+0x10],ecx
    71dc01861eb9:	0f 84 82 00 00 00    	je     0x71dc01861f41
    71dc01861ebf:	41 8b 52 14          	mov    edx,DWORD PTR [r10+0x14]
    71dc01861ec3:	44 8b 85 70 ff ff ff 	mov    r8d,DWORD PTR [rbp-0x90]
    71dc01861eca:	41 ff c0             	inc    r8d
    71dc01861ecd:	44 8b 8d 5c ff ff ff 	mov    r9d,DWORD PTR [rbp-0xa4]
    71dc01861ed4:	45 3b c8             	cmp    r9d,r8d
    71dc01861ed7:	0f 82 93 02 00 00    	jb     0x71dc01862170
    71dc01861edd:	44 3b ca             	cmp    r9d,edx
    71dc01861ee0:	44 89 85 70 ff ff ff 	mov    DWORD PTR [rbp-0x90],r8d
    71dc01861ee7:	8b 8d 74 ff ff ff    	mov    ecx,DWORD PTR [rbp-0x8c]
    71dc01861eed:	77 b4                	ja     0x71dc01861ea3
    71dc01861eef:	49 83 7d 48 00       	cmp    QWORD PTR [r13+0x48],0x0
    71dc01861ef4:	0f 85 27 06 00 00    	jne    0x71dc01862521
    71dc01861efa:	41 80 bd 95 00 00 00 	cmp    BYTE PTR [r13+0x95],0x0
    71dc01861f01:	00 
    71dc01861f02:	75 0b                	jne    0x71dc01861f0f
    71dc01861f04:	49 83 7d 58 00       	cmp    QWORD PTR [r13+0x58],0x0
    71dc01861f09:	0f 85 34 06 00 00    	jne    0x71dc01862543
    71dc01861f0f:	80 bb 96 00 00 00 00 	cmp    BYTE PTR [rbx+0x96],0x0
    71dc01861f16:	0f 85 47 06 00 00    	jne    0x71dc01862563
    71dc01861f1c:	49 8b 75 10          	mov    rsi,QWORD PTR [r13+0x10]
    71dc01861f20:	4c 8b ee             	mov    r13,rsi
    71dc01861f23:	4d 85 ed             	test   r13,r13
    71dc01861f26:	74 14                	je     0x71dc01861f3c
    71dc01861f28:	48 bf c0 0c 28 01 dc 	movabs rdi,0x71dc01280cc0
    71dc01861f2f:	71 00 00 
    71dc01861f32:	49 39 7d 00          	cmp    QWORD PTR [r13+0x0],rdi
    71dc01861f36:	0f 85 5f 06 00 00    	jne    0x71dc0186259b
    71dc01861f3c:	e9 91 fb ff ff       	jmp    0x71dc01861ad2
    71dc01861f41:	49 8b 32             	mov    rsi,QWORD PTR [r10]
    71dc01861f44:	48 ba d8 84 f3 ff db 	movabs rdx,0x71dbfff384d8
    71dc01861f4b:	71 00 00 
    71dc01861f4e:	48 39 10             	cmp    QWORD PTR [rax],rdx
    71dc01861f51:	0f 85 ab 05 00 00    	jne    0x71dc01862502
    71dc01861f57:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
    71dc01861f5e:	49 3b f7             	cmp    rsi,r15
    71dc01861f61:	74 6e                	je     0x71dc01861fd1
    71dc01861f63:	48 85 f6             	test   rsi,rsi
    71dc01861f66:	0f 84 8d 05 00 00    	je     0x71dc018624f9
    71dc01861f6c:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc01861f6f:	41 3b 57 08          	cmp    edx,DWORD PTR [r15+0x8]
    71dc01861f73:	0f 85 80 05 00 00    	jne    0x71dc018624f9
    71dc01861f79:	48 8d 7e 0c          	lea    rdi,[rsi+0xc]
    71dc01861f7d:	03 d2                	add    edx,edx
    71dc01861f7f:	49 8d 77 0c          	lea    rsi,[r15+0xc]
    71dc01861f83:	ff 15 77 a6 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa677]        # 0x71dbffe5c600
    71dc01861f89:	85 c0                	test   eax,eax
    71dc01861f8b:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
    71dc01861f92:	4c 8b 95 18 ff ff ff 	mov    r10,QWORD PTR [rbp-0xe8]
    71dc01861f99:	0f 84 20 ff ff ff    	je     0x71dc01861ebf
    71dc01861f9f:	49 83 c2 08          	add    r10,0x8
    71dc01861fa3:	49 8b 02             	mov    rax,QWORD PTR [r10]
    71dc01861fa6:	48 b9 f8 ec 60 fc db 	movabs rcx,0x71dbfc60ecf8
    71dc01861fad:	71 00 00 
    71dc01861fb0:	4c 3b f9             	cmp    r15,rcx
    71dc01861fb3:	0f 85 86 00 00 00    	jne    0x71dc0186203f
    71dc01861fb9:	48 b9 70 31 80 21 d4 	movabs rcx,0x71d421803170
    71dc01861fc0:	71 00 00 
    71dc01861fc3:	48 3b 01             	cmp    rax,QWORD PTR [rcx]
    71dc01861fc6:	0f 84 90 02 00 00    	je     0x71dc0186225c
    71dc01861fcc:	e9 5f fc ff ff       	jmp    0x71dc01861c30
    71dc01861fd1:	bf 01 00 00 00       	mov    edi,0x1
    71dc01861fd6:	8b c7                	mov    eax,edi
    71dc01861fd8:	eb af                	jmp    0x71dc01861f89
    71dc01861fda:	49 8b 30             	mov    rsi,QWORD PTR [r8]
    71dc01861fdd:	48 ba d8 84 f3 ff db 	movabs rdx,0x71dbfff384d8
    71dc01861fe4:	71 00 00 
    71dc01861fe7:	48 39 13             	cmp    QWORD PTR [rbx],rdx
    71dc01861fea:	0f 85 44 06 00 00    	jne    0x71dc01862634
    71dc01861ff0:	49 3b f7             	cmp    rsi,r15
    71dc01861ff3:	74 41                	je     0x71dc01862036
    71dc01861ff5:	48 85 f6             	test   rsi,rsi
    71dc01861ff8:	0f 84 2d 06 00 00    	je     0x71dc0186262b
    71dc01861ffe:	8b 56 08             	mov    edx,DWORD PTR [rsi+0x8]
    71dc01862001:	41 3b 57 08          	cmp    edx,DWORD PTR [r15+0x8]
    71dc01862005:	0f 85 20 06 00 00    	jne    0x71dc0186262b
    71dc0186200b:	48 8d 7e 0c          	lea    rdi,[rsi+0xc]
    71dc0186200f:	03 d2                	add    edx,edx
    71dc01862011:	49 8d 77 0c          	lea    rsi,[r15+0xc]
    71dc01862015:	ff 15 e5 a5 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa5e5]        # 0x71dbffe5c600
    71dc0186201b:	85 c0                	test   eax,eax
    71dc0186201d:	4c 8b 85 08 ff ff ff 	mov    r8,QWORD PTR [rbp-0xf8]
    71dc01862024:	0f 84 5d fb ff ff    	je     0x71dc01861b87
    71dc0186202a:	49 83 c0 08          	add    r8,0x8
    71dc0186202e:	49 8b 00             	mov    rax,QWORD PTR [r8]
    71dc01862031:	e9 fa fb ff ff       	jmp    0x71dc01861c30
    71dc01862036:	bf 01 00 00 00       	mov    edi,0x1
    71dc0186203b:	8b c7                	mov    eax,edi
    71dc0186203d:	eb dc                	jmp    0x71dc0186201b
    71dc0186203f:	41 83 7f 08 09       	cmp    DWORD PTR [r15+0x8],0x9
    71dc01862044:	75 86                	jne    0x71dc01861fcc
    71dc01862046:	c4 c1 78 10 47 0c    	vmovups xmm0,XMMWORD PTR [r15+0xc]
    71dc0186204c:	c4 c1 78 10 4f 0e    	vmovups xmm1,XMMWORD PTR [r15+0xe]
    71dc01862052:	c5 f1 ef 0d 06 06 00 	vpxor  xmm1,xmm1,XMMWORD PTR [rip+0x606]        # 0x71dc01862660
    71dc01862059:	00 
    71dc0186205a:	62 f3 f5 08 25 05 0b 	vpternlogq xmm0,xmm1,XMMWORD PTR [rip+0x60b],0xde        # 0x71dc01862670
    71dc01862061:	06 00 00 de 
    71dc01862065:	c4 e2 79 17 c0       	vptest xmm0,xmm0
    71dc0186206a:	0f 94 c1             	sete   cl
    71dc0186206d:	0f b6 c9             	movzx  ecx,cl
    71dc01862070:	85 c9                	test   ecx,ecx
    71dc01862072:	0f 84 54 ff ff ff    	je     0x71dc01861fcc
    71dc01862078:	e9 3c ff ff ff       	jmp    0x71dc01861fb9
    71dc0186207d:	49 8b 7d 20          	mov    rdi,QWORD PTR [r13+0x20]
    71dc01862081:	48 8b 7f 60          	mov    rdi,QWORD PTR [rdi+0x60]
    71dc01862085:	48 8b 7f 18          	mov    rdi,QWORD PTR [rdi+0x18]
    71dc01862089:	49 8b f7             	mov    rsi,r15
    71dc0186208c:	49 bb 50 34 c4 fe db 	movabs r11,0x71dbfec43450
    71dc01862093:	71 00 00 
    71dc01862096:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862099:	85 c0                	test   eax,eax
    71dc0186209b:	75 0e                	jne    0x71dc018620ab
    71dc0186209d:	4d 8b 6d 18          	mov    r13,QWORD PTR [r13+0x18]
    71dc018620a1:	4d 85 ed             	test   r13,r13
    71dc018620a4:	75 d7                	jne    0x71dc0186207d
    71dc018620a6:	e9 29 f8 ff ff       	jmp    0x71dc018618d4
    71dc018620ab:	49 8b 7d 20          	mov    rdi,QWORD PTR [r13+0x20]
    71dc018620af:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
    71dc018620b3:	48 85 c0             	test   rax,rax
    71dc018620b6:	75 06                	jne    0x71dc018620be
    71dc018620b8:	ff 15 8a 4c d8 ff    	call   QWORD PTR [rip+0xffffffffffd84c8a]        # 0x71dc015e6d48
    71dc018620be:	48 8d 55 d0          	lea    rdx,[rbp-0x30]
    71dc018620c2:	48 8b f8             	mov    rdi,rax
    71dc018620c5:	49 8b f7             	mov    rsi,r15
    71dc018620c8:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc018620ca:	ff 15 90 b8 64 fe    	call   QWORD PTR [rip+0xfffffffffe64b890]        # 0x71dbffead960
    71dc018620d0:	85 c0                	test   eax,eax
    71dc018620d2:	74 09                	je     0x71dc018620dd
    71dc018620d4:	48 8b 45 d0          	mov    rax,QWORD PTR [rbp-0x30]
    71dc018620d8:	e9 53 fb ff ff       	jmp    0x71dc01861c30
    71dc018620dd:	49 8b ff             	mov    rdi,r15
    71dc018620e0:	49 8b f6             	mov    rsi,r14
    71dc018620e3:	ff 15 5f 52 d8 ff    	call   QWORD PTR [rip+0xffffffffffd8525f]        # 0x71dc015e7348
    71dc018620e9:	48 8b f8             	mov    rdi,rax
    71dc018620ec:	e8 af fe 54 7c       	call   0x71dc7ddb1fa0
    71dc018620f1:	cc                   	int3
    71dc018620f2:	48 8b 7b 18          	mov    rdi,QWORD PTR [rbx+0x18]
    71dc018620f6:	48 85 ff             	test   rdi,rdi
    71dc018620f9:	0f 84 ef f7 ff ff    	je     0x71dc018618ee
    71dc018620ff:	48 8b 57 20          	mov    rdx,QWORD PTR [rdi+0x20]
    71dc01862103:	48 85 d2             	test   rdx,rdx
    71dc01862106:	0f 84 e2 f7 ff ff    	je     0x71dc018618ee
    71dc0186210c:	49 8b ff             	mov    rdi,r15
    71dc0186210f:	49 8b f6             	mov    rsi,r14
    71dc01862112:	b9 01 00 00 00       	mov    ecx,0x1
    71dc01862117:	ff 15 fb 51 d8 ff    	call   QWORD PTR [rip+0xffffffffffd851fb]        # 0x71dc015e7318
    71dc0186211d:	e9 0e fb ff ff       	jmp    0x71dc01861c30
    71dc01862122:	33 f6                	xor    esi,esi
    71dc01862124:	45 33 c0             	xor    r8d,r8d
    71dc01862127:	41 8b c0             	mov    eax,r8d
    71dc0186212a:	e9 1d f8 ff ff       	jmp    0x71dc0186194c
    71dc0186212f:	49 8b 30             	mov    rsi,QWORD PTR [r8]
    71dc01862132:	48 8b f9             	mov    rdi,rcx
    71dc01862135:	49 8b d7             	mov    rdx,r15
    71dc01862138:	49 bb 68 34 c4 fe db 	movabs r11,0x71dbfec43468
    71dc0186213f:	71 00 00 
    71dc01862142:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862145:	85 c0                	test   eax,eax
    71dc01862147:	48 8b 8d 50 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xb0]
    71dc0186214e:	4c 8b 85 48 ff ff ff 	mov    r8,QWORD PTR [rbp-0xb8]
    71dc01862155:	0f 84 4e f8 ff ff    	je     0x71dc018619a9
    71dc0186215b:	48 8b fb             	mov    rdi,rbx
    71dc0186215e:	ff 15 2c 52 d8 ff    	call   QWORD PTR [rip+0xffffffffffd8522c]        # 0x71dc015e7390
    71dc01862164:	4c 8b e8             	mov    r13,rax
    71dc01862167:	49 83 7d 70 00       	cmp    QWORD PTR [r13+0x70],0x0
    71dc0186216c:	74 46                	je     0x71dc018621b4
    71dc0186216e:	eb 24                	jmp    0x71dc01862194
    71dc01862170:	ff 15 4a a8 54 ff    	call   QWORD PTR [rip+0xffffffffff54a84a]        # 0x71dc00dac9c0
    71dc01862176:	cc                   	int3
    71dc01862177:	49 8b fd             	mov    rdi,r13
    71dc0186217a:	49 8b f7             	mov    rsi,r15
    71dc0186217d:	49 bb 58 34 c4 fe db 	movabs r11,0x71dbfec43458
    71dc01862184:	71 00 00 
    71dc01862187:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186218a:	85 c0                	test   eax,eax
    71dc0186218c:	0f 84 34 f8 ff ff    	je     0x71dc018619c6
    71dc01862192:	eb c7                	jmp    0x71dc0186215b
    71dc01862194:	49 8b 7d 70          	mov    rdi,QWORD PTR [r13+0x70]
    71dc01862198:	48 8d 55 c8          	lea    rdx,[rbp-0x38]
    71dc0186219c:	49 8b f7             	mov    rsi,r15
    71dc0186219f:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc018621a1:	ff 15 01 52 d8 ff    	call   QWORD PTR [rip+0xffffffffffd85201]        # 0x71dc015e73a8
    71dc018621a7:	85 c0                	test   eax,eax
    71dc018621a9:	74 09                	je     0x71dc018621b4
    71dc018621ab:	48 8b 45 c8          	mov    rax,QWORD PTR [rbp-0x38]
    71dc018621af:	e9 7c fa ff ff       	jmp    0x71dc01861c30
    71dc018621b4:	49 8b 7d 08          	mov    rdi,QWORD PTR [r13+0x8]
    71dc018621b8:	48 85 ff             	test   rdi,rdi
    71dc018621bb:	75 0c                	jne    0x71dc018621c9
    71dc018621bd:	49 8b fd             	mov    rdi,r13
    71dc018621c0:	ff 15 82 4b d8 ff    	call   QWORD PTR [rip+0xffffffffffd84b82]        # 0x71dc015e6d48
    71dc018621c6:	48 8b f8             	mov    rdi,rax
    71dc018621c9:	48 8d 55 c0          	lea    rdx,[rbp-0x40]
    71dc018621cd:	49 8b f7             	mov    rsi,r15
    71dc018621d0:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc018621d2:	ff 15 88 b7 64 fe    	call   QWORD PTR [rip+0xfffffffffe64b788]        # 0x71dbffead960
    71dc018621d8:	85 c0                	test   eax,eax
    71dc018621da:	74 09                	je     0x71dc018621e5
    71dc018621dc:	48 8b 45 c0          	mov    rax,QWORD PTR [rbp-0x40]
    71dc018621e0:	e9 4b fa ff ff       	jmp    0x71dc01861c30
    71dc018621e5:	48 8d 55 b8          	lea    rdx,[rbp-0x48]
    71dc018621e9:	48 8b fb             	mov    rdi,rbx
    71dc018621ec:	49 8b f7             	mov    rsi,r15
    71dc018621ef:	ff 15 cb 51 d8 ff    	call   QWORD PTR [rip+0xffffffffffd851cb]        # 0x71dc015e73c0
    71dc018621f5:	85 c0                	test   eax,eax
    71dc018621f7:	0f 84 ae f9 ff ff    	je     0x71dc01861bab
    71dc018621fd:	48 8b 45 b8          	mov    rax,QWORD PTR [rbp-0x48]
    71dc01862201:	e9 2a fa ff ff       	jmp    0x71dc01861c30
    71dc01862206:	bf 04 00 00 00       	mov    edi,0x4
    71dc0186220b:	ff 15 cf 49 74 ff    	call   QWORD PTR [rip+0xffffffffff7449cf]        # 0x71dc00fa6be0
    71dc01862211:	cc                   	int3
    71dc01862212:	8b c6                	mov    eax,esi
    71dc01862214:	c1 c0 05             	rol    eax,0x5
    71dc01862217:	03 c6                	add    eax,esi
    71dc01862219:	8b f0                	mov    esi,eax
    71dc0186221b:	41 33 33             	xor    esi,DWORD PTR [r11]
    71dc0186221e:	e9 1f f8 ff ff       	jmp    0x71dc01861a42
    71dc01862223:	49 8b fc             	mov    rdi,r12
    71dc01862226:	49 8b f7             	mov    rsi,r15
    71dc01862229:	49 bb 70 34 c4 fe db 	movabs r11,0x71dbfec43470
    71dc01862230:	71 00 00 
    71dc01862233:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862236:	e9 15 f8 ff ff       	jmp    0x71dc01861a50
    71dc0186223b:	33 ff                	xor    edi,edi
    71dc0186223d:	8b c7                	mov    eax,edi
    71dc0186223f:	e9 c1 f9 ff ff       	jmp    0x71dc01861c05
    71dc01862244:	49 8b fc             	mov    rdi,r12
    71dc01862247:	49 8b d7             	mov    rdx,r15
    71dc0186224a:	49 bb 78 34 c4 fe db 	movabs r11,0x71dbfec43478
    71dc01862251:	71 00 00 
    71dc01862254:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862257:	e9 a9 f9 ff ff       	jmp    0x71dc01861c05
    71dc0186225c:	49 8b ff             	mov    rdi,r15
    71dc0186225f:	49 8b f6             	mov    rsi,r14
    71dc01862262:	ff 15 a0 51 d8 ff    	call   QWORD PTR [rip+0xffffffffffd851a0]        # 0x71dc015e7408
    71dc01862268:	48 8b f8             	mov    rdi,rax
    71dc0186226b:	e8 30 fd 54 7c       	call   0x71dc7ddb1fa0
    71dc01862270:	cc                   	int3
    71dc01862271:	4c 3b eb             	cmp    r13,rbx
    71dc01862274:	0f 84 df f9 ff ff    	je     0x71dc01861c59
    71dc0186227a:	80 bb 96 00 00 00 00 	cmp    BYTE PTR [rbx+0x96],0x0
    71dc01862281:	0f 84 95 fc ff ff    	je     0x71dc01861f1c
    71dc01862287:	e9 cd f9 ff ff       	jmp    0x71dc01861c59
    71dc0186228c:	4c 3b eb             	cmp    r13,rbx
    71dc0186228f:	0f 84 d1 f9 ff ff    	je     0x71dc01861c66
    71dc01862295:	48 8b 7b 60          	mov    rdi,QWORD PTR [rbx+0x60]
    71dc01862299:	48 8b 7f 18          	mov    rdi,QWORD PTR [rdi+0x18]
    71dc0186229d:	49 8b f7             	mov    rsi,r15
    71dc018622a0:	49 bb 48 34 c4 fe db 	movabs r11,0x71dbfec43448
    71dc018622a7:	71 00 00 
    71dc018622aa:	41 ff 13             	call   QWORD PTR [r11]
    71dc018622ad:	85 c0                	test   eax,eax
    71dc018622af:	0f 84 b1 f9 ff ff    	je     0x71dc01861c66
    71dc018622b5:	49 8b 75 10          	mov    rsi,QWORD PTR [r13+0x10]
    71dc018622b9:	48 bf c0 0c 28 01 dc 	movabs rdi,0x71dc01280cc0
    71dc018622c0:	71 00 00 
    71dc018622c3:	e8 98 81 fe ff       	call   0x71dc0184a460
    71dc018622c8:	48 85 c0             	test   rax,rax
    71dc018622cb:	0f 85 4b fc ff ff    	jne    0x71dc01861f1c
    71dc018622d1:	e9 90 f9 ff ff       	jmp    0x71dc01861c66
    71dc018622d6:	49 8b 7d 60          	mov    rdi,QWORD PTR [r13+0x60]
    71dc018622da:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    71dc018622de:	49 8b f7             	mov    rsi,r15
    71dc018622e1:	49 bb 80 34 c4 fe db 	movabs r11,0x71dbfec43480
    71dc018622e8:	71 00 00 
    71dc018622eb:	41 ff 13             	call   QWORD PTR [r11]
    71dc018622ee:	85 c0                	test   eax,eax
    71dc018622f0:	0f 85 ab 02 00 00    	jne    0x71dc018625a1
    71dc018622f6:	49 8b 7d 60          	mov    rdi,QWORD PTR [r13+0x60]
    71dc018622fa:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
    71dc018622fe:	49 8b f7             	mov    rsi,r15
    71dc01862301:	49 bb 88 34 c4 fe db 	movabs r11,0x71dbfec43488
    71dc01862308:	71 00 00 
    71dc0186230b:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186230e:	85 c0                	test   eax,eax
    71dc01862310:	0f 84 59 f9 ff ff    	je     0x71dc01861c6f
    71dc01862316:	e9 86 02 00 00       	jmp    0x71dc018625a1
    71dc0186231b:	8b d6                	mov    edx,esi
    71dc0186231d:	c1 c2 05             	rol    edx,0x5
    71dc01862320:	03 d6                	add    edx,esi
    71dc01862322:	8b f2                	mov    esi,edx
    71dc01862324:	41 33 33             	xor    esi,DWORD PTR [r11]
    71dc01862327:	e9 f8 f9 ff ff       	jmp    0x71dc01861d24
    71dc0186232c:	48 8b f9             	mov    rdi,rcx
    71dc0186232f:	49 8b f7             	mov    rsi,r15
    71dc01862332:	49 bb a8 34 c4 fe db 	movabs r11,0x71dbfec434a8
    71dc01862339:	71 00 00 
    71dc0186233c:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186233f:	8b d0                	mov    edx,eax
    71dc01862341:	48 8b 8d 28 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xd8]
    71dc01862348:	e9 e8 f9 ff ff       	jmp    0x71dc01861d35
    71dc0186234d:	8b ff                	mov    edi,edi
    71dc0186234f:	48 8d 3c 7f          	lea    rdi,[rdi+rdi*2]
    71dc01862353:	4c 8d 4c f8 10       	lea    r9,[rax+rdi*8+0x10]
    71dc01862358:	4c 89 8d 30 ff ff ff 	mov    QWORD PTR [rbp-0xd0],r9
    71dc0186235f:	41 39 51 08          	cmp    DWORD PTR [r9+0x8],edx
    71dc01862363:	74 1e                	je     0x71dc01862383
    71dc01862365:	eb 5a                	jmp    0x71dc018623c1
    71dc01862367:	39 7a 08             	cmp    DWORD PTR [rdx+0x8],edi
    71dc0186236a:	44 89 45 80          	mov    DWORD PTR [rbp-0x80],r8d
    71dc0186236e:	48 8b c2             	mov    rax,rdx
    71dc01862371:	48 8b 8d 28 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xd8]
    71dc01862378:	0f 86 11 fa ff ff    	jbe    0x71dc01861d8f
    71dc0186237e:	8b 55 84             	mov    edx,DWORD PTR [rbp-0x7c]
    71dc01862381:	eb ca                	jmp    0x71dc0186234d
    71dc01862383:	49 8b 31             	mov    rsi,QWORD PTR [r9]
    71dc01862386:	48 bf d8 84 f3 ff db 	movabs rdi,0x71dbfff384d8
    71dc0186238d:	71 00 00 
    71dc01862390:	48 39 39             	cmp    QWORD PTR [rcx],rdi
    71dc01862393:	75 0e                	jne    0x71dc018623a3
    71dc01862395:	48 8b fe             	mov    rdi,rsi
    71dc01862398:	49 8b f7             	mov    rsi,r15
    71dc0186239b:	ff 15 47 a2 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa247]        # 0x71dbffe5c5e8
    71dc018623a1:	eb 1a                	jmp    0x71dc018623bd
    71dc018623a3:	48 8b 8d 28 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xd8]
    71dc018623aa:	48 8b f9             	mov    rdi,rcx
    71dc018623ad:	49 8b d7             	mov    rdx,r15
    71dc018623b0:	49 bb b0 34 c4 fe db 	movabs r11,0x71dbfec434b0
    71dc018623b7:	71 00 00 
    71dc018623ba:	41 ff 13             	call   QWORD PTR [r11]
    71dc018623bd:	85 c0                	test   eax,eax
    71dc018623bf:	75 23                	jne    0x71dc018623e4
    71dc018623c1:	48 8b 95 30 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xd0]
    71dc018623c8:	8b 7a 0c             	mov    edi,DWORD PTR [rdx+0xc]
    71dc018623cb:	44 8b 45 80          	mov    r8d,DWORD PTR [rbp-0x80]
    71dc018623cf:	41 ff c0             	inc    r8d
    71dc018623d2:	48 8b 95 20 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe0]
    71dc018623d9:	44 39 42 08          	cmp    DWORD PTR [rdx+0x8],r8d
    71dc018623dd:	73 88                	jae    0x71dc01862367
    71dc018623df:	e9 8c fd ff ff       	jmp    0x71dc01862170
    71dc018623e4:	48 8b 95 30 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xd0]
    71dc018623eb:	48 83 c2 10          	add    rdx,0x10
    71dc018623ef:	8b 12                	mov    edx,DWORD PTR [rdx]
    71dc018623f1:	89 55 90             	mov    DWORD PTR [rbp-0x70],edx
    71dc018623f4:	eb 1f                	jmp    0x71dc01862415
    71dc018623f6:	48 8d 55 90          	lea    rdx,[rbp-0x70]
    71dc018623fa:	48 8b f8             	mov    rdi,rax
    71dc018623fd:	49 8b f7             	mov    rsi,r15
    71dc01862400:	49 bb 90 34 c4 fe db 	movabs r11,0x71dbfec43490
    71dc01862407:	71 00 00 
    71dc0186240a:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186240d:	85 c0                	test   eax,eax
    71dc0186240f:	0f 84 7f f9 ff ff    	je     0x71dc01861d94
    71dc01862415:	49 8b 7c 24 10       	mov    rdi,QWORD PTR [r12+0x10]
    71dc0186241a:	8b 57 08             	mov    edx,DWORD PTR [rdi+0x8]
    71dc0186241d:	39 55 90             	cmp    DWORD PTR [rbp-0x70],edx
    71dc01862420:	0f 83 26 02 00 00    	jae    0x71dc0186264c
    71dc01862426:	8b 55 90             	mov    edx,DWORD PTR [rbp-0x70]
    71dc01862429:	48 8b 44 d7 10       	mov    rax,QWORD PTR [rdi+rdx*8+0x10]
    71dc0186242e:	48 bf 70 31 80 21 d4 	movabs rdi,0x71d421803170
    71dc01862435:	71 00 00 
    71dc01862438:	48 3b 07             	cmp    rax,QWORD PTR [rdi]
    71dc0186243b:	0f 84 53 f9 ff ff    	je     0x71dc01861d94
    71dc01862441:	e9 71 01 00 00       	jmp    0x71dc018625b7
    71dc01862446:	49 8b 7c 24 08       	mov    rdi,QWORD PTR [r12+0x8]
    71dc0186244b:	48 8b 7f 40          	mov    rdi,QWORD PTR [rdi+0x40]
    71dc0186244f:	48 8d 55 88          	lea    rdx,[rbp-0x78]
    71dc01862453:	49 8b f7             	mov    rsi,r15
    71dc01862456:	49 bb 98 34 c4 fe db 	movabs r11,0x71dbfec43498
    71dc0186245d:	71 00 00 
    71dc01862460:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862463:	85 c0                	test   eax,eax
    71dc01862465:	0f 84 35 f9 ff ff    	je     0x71dc01861da0
    71dc0186246b:	49 8b 7c 24 20       	mov    rdi,QWORD PTR [r12+0x20]
    71dc01862470:	8b 75 88             	mov    esi,DWORD PTR [rbp-0x78]
    71dc01862473:	49 bb a0 34 c4 fe db 	movabs r11,0x71dbfec434a0
    71dc0186247a:	71 00 00 
    71dc0186247d:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862480:	48 8b f8             	mov    rdi,rax
    71dc01862483:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01862485:	ff 15 25 50 d8 ff    	call   QWORD PTR [rip+0xffffffffffd85025]        # 0x71dc015e74b0
    71dc0186248b:	48 bf 70 31 80 21 d4 	movabs rdi,0x71d421803170
    71dc01862492:	71 00 00 
    71dc01862495:	48 3b 07             	cmp    rax,QWORD PTR [rdi]
    71dc01862498:	0f 84 02 f9 ff ff    	je     0x71dc01861da0
    71dc0186249e:	e9 19 01 00 00       	jmp    0x71dc018625bc
    71dc018624a3:	4d 8b 65 40          	mov    r12,QWORD PTR [r13+0x40]
    71dc018624a7:	4d 85 e4             	test   r12,r12
    71dc018624aa:	75 16                	jne    0x71dc018624c2
    71dc018624ac:	e9 fc f8 ff ff       	jmp    0x71dc01861dad
    71dc018624b1:	49 8b fd             	mov    rdi,r13
    71dc018624b4:	ff 15 8e 48 d8 ff    	call   QWORD PTR [rip+0xffffffffffd8488e]        # 0x71dc015e6d48
    71dc018624ba:	4c 8b e0             	mov    r12,rax
    71dc018624bd:	e9 f8 f8 ff ff       	jmp    0x71dc01861dba
    71dc018624c2:	e9 f3 f8 ff ff       	jmp    0x71dc01861dba
    71dc018624c7:	8b ce                	mov    ecx,esi
    71dc018624c9:	c1 c1 05             	rol    ecx,0x5
    71dc018624cc:	03 ce                	add    ecx,esi
    71dc018624ce:	8b f1                	mov    esi,ecx
    71dc018624d0:	41 33 33             	xor    esi,DWORD PTR [r11]
    71dc018624d3:	e9 5f f9 ff ff       	jmp    0x71dc01861e37
    71dc018624d8:	48 8b f8             	mov    rdi,rax
    71dc018624db:	49 8b f7             	mov    rsi,r15
    71dc018624de:	49 bb b8 34 c4 fe db 	movabs r11,0x71dbfec434b8
    71dc018624e5:	71 00 00 
    71dc018624e8:	41 ff 13             	call   QWORD PTR [r11]
    71dc018624eb:	8b c8                	mov    ecx,eax
    71dc018624ed:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
    71dc018624f4:	e9 4f f9 ff ff       	jmp    0x71dc01861e48
    71dc018624f9:	33 ff                	xor    edi,edi
    71dc018624fb:	8b c7                	mov    eax,edi
    71dc018624fd:	e9 87 fa ff ff       	jmp    0x71dc01861f89
    71dc01862502:	48 8b 85 10 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf0]
    71dc01862509:	48 8b f8             	mov    rdi,rax
    71dc0186250c:	49 8b d7             	mov    rdx,r15
    71dc0186250f:	49 bb c0 34 c4 fe db 	movabs r11,0x71dbfec434c0
    71dc01862516:	71 00 00 
    71dc01862519:	41 ff 13             	call   QWORD PTR [r11]
    71dc0186251c:	e9 68 fa ff ff       	jmp    0x71dc01861f89
    71dc01862521:	49 8b 7d 60          	mov    rdi,QWORD PTR [r13+0x60]
    71dc01862525:	48 8b 7f 18          	mov    rdi,QWORD PTR [rdi+0x18]
    71dc01862529:	49 8b f7             	mov    rsi,r15
    71dc0186252c:	49 bb 40 34 c4 fe db 	movabs r11,0x71dbfec43440
    71dc01862533:	71 00 00 
    71dc01862536:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862539:	85 c0                	test   eax,eax
    71dc0186253b:	0f 84 b9 f9 ff ff    	je     0x71dc01861efa
    71dc01862541:	eb 7b                	jmp    0x71dc018625be
    71dc01862543:	49 8b ff             	mov    rdi,r15
    71dc01862546:	48 be f8 ec 60 fc db 	movabs rsi,0x71dbfc60ecf8
    71dc0186254d:	71 00 00 
    71dc01862550:	ff 15 92 a0 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa092]        # 0x71dbffe5c5e8
    71dc01862556:	85 c0                	test   eax,eax
    71dc01862558:	0f 84 b1 f9 ff ff    	je     0x71dc01861f0f
    71dc0186255e:	e9 f9 fc ff ff       	jmp    0x71dc0186225c
    71dc01862563:	41 80 bd 95 00 00 00 	cmp    BYTE PTR [r13+0x95],0x0
    71dc0186256a:	00 
    71dc0186256b:	0f 84 ab f9 ff ff    	je     0x71dc01861f1c
    71dc01862571:	4d 8b 65 58          	mov    r12,QWORD PTR [r13+0x58]
    71dc01862575:	4d 85 e4             	test   r12,r12
    71dc01862578:	0f 84 9e f9 ff ff    	je     0x71dc01861f1c
    71dc0186257e:	49 8b ff             	mov    rdi,r15
    71dc01862581:	48 be f8 ec 60 fc db 	movabs rsi,0x71dbfc60ecf8
    71dc01862588:	71 00 00 
    71dc0186258b:	ff 15 57 a0 5f fe    	call   QWORD PTR [rip+0xfffffffffe5fa057]        # 0x71dbffe5c5e8
    71dc01862591:	85 c0                	test   eax,eax
    71dc01862593:	0f 84 83 f9 ff ff    	je     0x71dc01861f1c
    71dc01862599:	eb 4b                	jmp    0x71dc018625e6
    71dc0186259b:	e8 c0 7e fe ff       	call   0x71dc0184a460
    71dc018625a0:	cc                   	int3
    71dc018625a1:	49 8b ff             	mov    rdi,r15
    71dc018625a4:	49 8b f6             	mov    rsi,r14
    71dc018625a7:	49 8b d5             	mov    rdx,r13
    71dc018625aa:	33 c9                	xor    ecx,ecx
    71dc018625ac:	ff 15 66 4d d8 ff    	call   QWORD PTR [rip+0xffffffffffd84d66]        # 0x71dc015e7318
    71dc018625b2:	e9 79 f6 ff ff       	jmp    0x71dc01861c30
    71dc018625b7:	e9 74 f6 ff ff       	jmp    0x71dc01861c30
    71dc018625bc:	eb f9                	jmp    0x71dc018625b7
    71dc018625be:	4c 3b eb             	cmp    r13,rbx
    71dc018625c1:	74 0e                	je     0x71dc018625d1
    71dc018625c3:	49 8b ff             	mov    rdi,r15
    71dc018625c6:	49 8b f6             	mov    rsi,r14
    71dc018625c9:	ff 15 39 4e d8 ff    	call   QWORD PTR [rip+0xffffffffffd84e39]        # 0x71dc015e7408
    71dc018625cf:	eb 0c                	jmp    0x71dc018625dd
    71dc018625d1:	49 8b ff             	mov    rdi,r15
    71dc018625d4:	49 8b f6             	mov    rsi,r14
    71dc018625d7:	ff 15 6b 4d d8 ff    	call   QWORD PTR [rip+0xffffffffffd84d6b]        # 0x71dc015e7348
    71dc018625dd:	48 8b f8             	mov    rdi,rax
    71dc018625e0:	e8 bb f9 54 7c       	call   0x71dc7ddb1fa0
    71dc018625e5:	cc                   	int3
    71dc018625e6:	49 8b fc             	mov    rdi,r12
    71dc018625e9:	ff 15 c1 4e d8 ff    	call   QWORD PTR [rip+0xffffffffffd84ec1]        # 0x71dc015e74b0
    71dc018625ef:	48 bf 70 31 80 21 d4 	movabs rdi,0x71d421803170
    71dc018625f6:	71 00 00 
    71dc018625f9:	48 3b 07             	cmp    rax,QWORD PTR [rdi]
    71dc018625fc:	0f 84 5a fc ff ff    	je     0x71dc0186225c
    71dc01862602:	49 8b fc             	mov    rdi,r12
    71dc01862605:	ff 15 a5 4e d8 ff    	call   QWORD PTR [rip+0xffffffffffd84ea5]        # 0x71dc015e74b0
    71dc0186260b:	e9 20 f6 ff ff       	jmp    0x71dc01861c30
    71dc01862610:	48 8b fb             	mov    rdi,rbx
    71dc01862613:	49 8b f7             	mov    rsi,r15
    71dc01862616:	49 bb c8 34 c4 fe db 	movabs r11,0x71dbfec434c8
    71dc0186261d:	71 00 00 
    71dc01862620:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862623:	44 8b e8             	mov    r13d,eax
    71dc01862626:	e9 ef f4 ff ff       	jmp    0x71dc01861b1a
    71dc0186262b:	33 ff                	xor    edi,edi
    71dc0186262d:	8b c7                	mov    eax,edi
    71dc0186262f:	e9 e7 f9 ff ff       	jmp    0x71dc0186201b
    71dc01862634:	48 8b fb             	mov    rdi,rbx
    71dc01862637:	49 8b d7             	mov    rdx,r15
    71dc0186263a:	49 bb d0 34 c4 fe db 	movabs r11,0x71dbfec434d0
    71dc01862641:	71 00 00 
    71dc01862644:	41 ff 13             	call   QWORD PTR [r11]
    71dc01862647:	e9 cf f9 ff ff       	jmp    0x71dc0186201b
    71dc0186264c:	e8 b7 ef 5e fe       	call   0x71dbffe51608
    71dc01862651:	cc                   	int3
