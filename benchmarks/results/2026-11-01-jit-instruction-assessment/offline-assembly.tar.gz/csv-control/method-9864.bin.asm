
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/csv-control/method-9864.bin:     file format binary


Disassembly of section .data:

000071dc01a52740 <.data>:
    71dc01a52740:	50                   	push   rax
    71dc01a52741:	48 8b 45 00          	mov    rax,QWORD PTR [rbp+0x0]
    71dc01a52745:	50                   	push   rax
    71dc01a52746:	48 81 ec c0 00 00 00 	sub    rsp,0xc0
    71dc01a5274d:	4c 89 bc 24 a8 03 00 	mov    QWORD PTR [rsp+0x3a8],r15
    71dc01a52754:	00 
    71dc01a52755:	4c 89 b4 24 a0 03 00 	mov    QWORD PTR [rsp+0x3a0],r14
    71dc01a5275c:	00 
    71dc01a5275d:	4c 89 ac 24 98 03 00 	mov    QWORD PTR [rsp+0x398],r13
    71dc01a52764:	00 
    71dc01a52765:	4c 89 a4 24 90 03 00 	mov    QWORD PTR [rsp+0x390],r12
    71dc01a5276c:	00 
    71dc01a5276d:	48 89 9c 24 88 03 00 	mov    QWORD PTR [rsp+0x388],rbx
    71dc01a52774:	00 
    71dc01a52775:	48 8d ac 24 c0 00 00 	lea    rbp,[rsp+0xc0]
    71dc01a5277c:	00 
    71dc01a5277d:	33 c0                	xor    eax,eax
    71dc01a5277f:	48 89 85 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rax
    71dc01a52786:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    71dc01a5278b:	62 71 7e 48 7f 85 70 	vmovdqu32 ZMMWORD PTR [rbp-0x90],zmm8
    71dc01a52792:	ff ff ff 
    71dc01a52795:	c5 7e 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm8
    71dc01a5279a:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    71dc01a5279e:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a527a5:	eb 1e                	jmp    0x71dc01a527c5
    71dc01a527a7:	83 bd bc 02 00 00 00 	cmp    DWORD PTR [rbp+0x2bc],0x0
    71dc01a527ae:	0f 85 8d 0b 00 00    	jne    0x71dc01a53341
    71dc01a527b4:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a527bb:	41 ff 85 dc 00 00 00 	inc    DWORD PTR [r13+0xdc]
    71dc01a527c2:	49 8b fd             	mov    rdi,r13
    71dc01a527c5:	8b 87 dc 00 00 00    	mov    eax,DWORD PTR [rdi+0xdc]
    71dc01a527cb:	48 8b 8d b0 02 00 00 	mov    rcx,QWORD PTR [rbp+0x2b0]
    71dc01a527d2:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    71dc01a527d5:	3b c1                	cmp    eax,ecx
    71dc01a527d7:	0f 8d 77 0b 00 00    	jge    0x71dc01a53354
    71dc01a527dd:	3b c1                	cmp    eax,ecx
    71dc01a527df:	0f 83 64 0c 00 00    	jae    0x71dc01a53449
    71dc01a527e5:	48 8b 8d b0 02 00 00 	mov    rcx,QWORD PTR [rbp+0x2b0]
    71dc01a527ec:	8b c0                	mov    eax,eax
    71dc01a527ee:	48 8d 04 40          	lea    rax,[rax+rax*2]
    71dc01a527f2:	48 8d 44 c1 10       	lea    rax,[rcx+rax*8+0x10]
    71dc01a527f7:	48 89 85 98 02 00 00 	mov    QWORD PTR [rbp+0x298],rax
    71dc01a527fe:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    71dc01a52802:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    71dc01a52806:	48 8b 8d 98 02 00 00 	mov    rcx,QWORD PTR [rbp+0x298]
    71dc01a5280d:	48 8b 09             	mov    rcx,QWORD PTR [rcx]
    71dc01a52810:	48 8b 90 80 00 00 00 	mov    rdx,QWORD PTR [rax+0x80]
    71dc01a52817:	48 8b 52 18          	mov    rdx,QWORD PTR [rdx+0x18]
    71dc01a5281b:	48 85 d2             	test   rdx,rdx
    71dc01a5281e:	0f 85 1c 0c 00 00    	jne    0x71dc01a53440
    71dc01a52824:	48 8b 80 68 01 00 00 	mov    rax,QWORD PTR [rax+0x168]
    71dc01a5282b:	48 85 c0             	test   rax,rax
    71dc01a5282e:	0f 85 ea 0b 00 00    	jne    0x71dc01a5341e
    71dc01a52834:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a5283b:	48 83 bf 88 00 00 00 	cmp    QWORD PTR [rdi+0x88],0x0
    71dc01a52842:	00 
    71dc01a52843:	0f 85 ad 00 00 00    	jne    0x71dc01a528f6
    71dc01a52849:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52850:	8b 5e 10             	mov    ebx,DWORD PTR [rsi+0x10]
    71dc01a52853:	83 fb 2f             	cmp    ebx,0x2f
    71dc01a52856:	0f 87 74 02 00 00    	ja     0x71dc01a52ad0
    71dc01a5285c:	8b f3                	mov    esi,ebx
    71dc01a5285e:	48 8d 05 9b 0d 00 00 	lea    rax,[rip+0xd9b]        # 0x71dc01a53600
    71dc01a52865:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    71dc01a52868:	48 8d 0d 36 ff ff ff 	lea    rcx,[rip+0xffffffffffffff36]        # 0x71dc01a527a5
    71dc01a5286f:	48 03 c1             	add    rax,rcx
    71dc01a52872:	ff e0                	jmp    rax
    71dc01a52874:	4c 8d bf e8 00 00 00 	lea    r15,[rdi+0xe8]
    71dc01a5287b:	4c 8b 77 08          	mov    r14,QWORD PTR [rdi+0x8]
    71dc01a5287f:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
    71dc01a52883:	44 8b db             	mov    r11d,ebx
    71dc01a52886:	41 83 fb 04          	cmp    r11d,0x4
    71dc01a5288a:	74 0a                	je     0x71dc01a52896
    71dc01a5288c:	41 83 fb 0d          	cmp    r11d,0xd
    71dc01a52890:	0f 85 bf 06 00 00    	jne    0x71dc01a52f55
    71dc01a52896:	4c 8b 9d 98 02 00 00 	mov    r11,QWORD PTR [rbp+0x298]
    71dc01a5289d:	41 8b 5b 08          	mov    ebx,DWORD PTR [r11+0x8]
    71dc01a528a1:	4c 8b 9d 98 02 00 00 	mov    r11,QWORD PTR [rbp+0x298]
    71dc01a528a8:	4d 8b 2b             	mov    r13,QWORD PTR [r11]
    71dc01a528ab:	4c 8b 67 70          	mov    r12,QWORD PTR [rdi+0x70]
    71dc01a528af:	45 33 db             	xor    r11d,r11d
    71dc01a528b2:	4c 89 5d a8          	mov    QWORD PTR [rbp-0x58],r11
    71dc01a528b6:	4c 89 5d a0          	mov    QWORD PTR [rbp-0x60],r11
    71dc01a528ba:	3b 5e 08             	cmp    ebx,DWORD PTR [rsi+0x8]
    71dc01a528bd:	0f 83 5c 0a 00 00    	jae    0x71dc01a5331f
    71dc01a528c3:	44 8b db             	mov    r11d,ebx
    71dc01a528c6:	4a 8b 74 de 10       	mov    rsi,QWORD PTR [rsi+r11*8+0x10]
    71dc01a528cb:	49 bb 70 31 80 21 d4 	movabs r11,0x71d421803170
    71dc01a528d2:	71 00 00 
    71dc01a528d5:	49 3b 33             	cmp    rsi,QWORD PTR [r11]
    71dc01a528d8:	0f 84 97 06 00 00    	je     0x71dc01a52f75
    71dc01a528de:	33 c0                	xor    eax,eax
    71dc01a528e0:	48 89 45 a8          	mov    QWORD PTR [rbp-0x58],rax
    71dc01a528e4:	48 89 45 a0          	mov    QWORD PTR [rbp-0x60],rax
    71dc01a528e8:	49 8b ff             	mov    rdi,r15
    71dc01a528eb:	ff 15 77 27 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92777]        # 0x71dc015e5068
    71dc01a528f1:	e9 b1 fe ff ff       	jmp    0x71dc01a527a7
    71dc01a528f6:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    71dc01a528fd:	00 
    71dc01a528fe:	0f 85 45 ff ff ff    	jne    0x71dc01a52849
    71dc01a52904:	e9 33 06 00 00       	jmp    0x71dc01a52f3c
    71dc01a52909:	48 8d b7 e8 00 00 00 	lea    rsi,[rdi+0xe8]
    71dc01a52910:	48 8b 85 98 02 00 00 	mov    rax,QWORD PTR [rbp+0x298]
    71dc01a52917:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    71dc01a5291a:	8b 46 30             	mov    eax,DWORD PTR [rsi+0x30]
    71dc01a5291d:	85 c0                	test   eax,eax
    71dc01a5291f:	0f 84 97 07 00 00    	je     0x71dc01a530bc
    71dc01a52925:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01a52928:	ff c8                	dec    eax
    71dc01a5292a:	3b 46 08             	cmp    eax,DWORD PTR [rsi+0x8]
    71dc01a5292d:	0f 83 ec 09 00 00    	jae    0x71dc01a5331f
    71dc01a52933:	48 8b 74 c6 10       	mov    rsi,QWORD PTR [rsi+rax*8+0x10]
    71dc01a52938:	48 85 f6             	test   rsi,rsi
    71dc01a5293b:	0f 84 36 07 00 00    	je     0x71dc01a53077
    71dc01a52941:	4c 8b fe             	mov    r15,rsi
    71dc01a52944:	48 b8 e0 44 65 01 dc 	movabs rax,0x71dc016544e0
    71dc01a5294b:	71 00 00 
    71dc01a5294e:	49 39 07             	cmp    QWORD PTR [r15],rax
    71dc01a52951:	0f 85 4e 07 00 00    	jne    0x71dc01a530a5
    71dc01a52957:	4d 85 ff             	test   r15,r15
    71dc01a5295a:	0f 84 5c 07 00 00    	je     0x71dc01a530bc
    71dc01a52960:	48 b8 e0 44 65 01 dc 	movabs rax,0x71dc016544e0
    71dc01a52967:	71 00 00 
    71dc01a5296a:	49 39 07             	cmp    QWORD PTR [r15],rax
    71dc01a5296d:	0f 85 65 07 00 00    	jne    0x71dc01a530d8
    71dc01a52973:	49 8b ff             	mov    rdi,r15
    71dc01a52976:	ff 15 14 1c c0 ff    	call   QWORD PTR [rip+0xffffffffffc01c14]        # 0x71dc01654590
    71dc01a5297c:	85 c0                	test   eax,eax
    71dc01a5297e:	0f 84 69 07 00 00    	je     0x71dc01a530ed
    71dc01a52984:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a5298b:	49 8d 9d e8 00 00 00 	lea    rbx,[r13+0xe8]
    71dc01a52992:	48 bf e0 44 65 01 dc 	movabs rdi,0x71dc016544e0
    71dc01a52999:	71 00 00 
    71dc01a5299c:	49 39 3f             	cmp    QWORD PTR [r15],rdi
    71dc01a5299f:	0f 85 8b 07 00 00    	jne    0x71dc01a53130
    71dc01a529a5:	49 8b 77 28          	mov    rsi,QWORD PTR [r15+0x28]
    71dc01a529a9:	48 8b fb             	mov    rdi,rbx
    71dc01a529ac:	ff 15 b6 26 b9 ff    	call   QWORD PTR [rip+0xffffffffffb926b6]        # 0x71dc015e5068
    71dc01a529b2:	33 db                	xor    ebx,ebx
    71dc01a529b4:	89 9d bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],ebx
    71dc01a529ba:	e9 e8 fd ff ff       	jmp    0x71dc01a527a7
    71dc01a529bf:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a529c6:	ff 15 4c 28 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9284c]        # 0x71dc015e5218
    71dc01a529cc:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    71dc01a529d2:	e9 d0 fd ff ff       	jmp    0x71dc01a527a7
    71dc01a529d7:	83 fb 04             	cmp    ebx,0x4
    71dc01a529da:	74 09                	je     0x71dc01a529e5
    71dc01a529dc:	83 fb 0d             	cmp    ebx,0xd
    71dc01a529df:	0f 85 70 05 00 00    	jne    0x71dc01a52f55
    71dc01a529e5:	48 8b 95 98 02 00 00 	mov    rdx,QWORD PTR [rbp+0x298]
    71dc01a529ec:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    71dc01a529ef:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a529f6:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    71dc01a529f9:	ff 15 81 26 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92681]        # 0x71dc015e5080
    71dc01a529ff:	e9 a3 fd ff ff       	jmp    0x71dc01a527a7
    71dc01a52a04:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
    71dc01a52a08:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
    71dc01a52a0c:	8b cb                	mov    ecx,ebx
    71dc01a52a0e:	83 f9 03             	cmp    ecx,0x3
    71dc01a52a11:	0f 85 87 00 00 00    	jne    0x71dc01a52a9e
    71dc01a52a17:	48 8b 8d 98 02 00 00 	mov    rcx,QWORD PTR [rbp+0x298]
    71dc01a52a1e:	8b 71 08             	mov    esi,DWORD PTR [rcx+0x8]
    71dc01a52a21:	48 b9 a0 27 e6 ff db 	movabs rcx,0x71dbffe627a0
    71dc01a52a28:	71 00 00 
    71dc01a52a2b:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01a52a2e:	0f 85 3b 07 00 00    	jne    0x71dc01a5316f
    71dc01a52a34:	39 70 08             	cmp    DWORD PTR [rax+0x8],esi
    71dc01a52a37:	0f 86 2b 07 00 00    	jbe    0x71dc01a53168
    71dc01a52a3d:	8b ce                	mov    ecx,esi
    71dc01a52a3f:	48 8b 74 c8 10       	mov    rsi,QWORD PTR [rax+rcx*8+0x10]
    71dc01a52a44:	48 8b c6             	mov    rax,rsi
    71dc01a52a47:	48 85 c0             	test   rax,rax
    71dc01a52a4a:	74 13                	je     0x71dc01a52a5f
    71dc01a52a4c:	48 b9 f8 5b 56 01 dc 	movabs rcx,0x71dc01565bf8
    71dc01a52a53:	71 00 00 
    71dc01a52a56:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01a52a59:	0f 85 28 07 00 00    	jne    0x71dc01a53187
    71dc01a52a5f:	48 8b f0             	mov    rsi,rax
    71dc01a52a62:	48 8b 95 98 02 00 00 	mov    rdx,QWORD PTR [rbp+0x298]
    71dc01a52a69:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    71dc01a52a6c:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52a73:	33 c9                	xor    ecx,ecx
    71dc01a52a75:	ff 15 65 26 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92665]        # 0x71dc015e50e0
    71dc01a52a7b:	48 89 85 60 02 00 00 	mov    QWORD PTR [rbp+0x260],rax
    71dc01a52a82:	48 89 95 68 02 00 00 	mov    QWORD PTR [rbp+0x268],rdx
    71dc01a52a89:	48 8b 9d 60 02 00 00 	mov    rbx,QWORD PTR [rbp+0x260]
    71dc01a52a90:	48 85 db             	test   rbx,rbx
    71dc01a52a93:	0f 84 0e fd ff ff    	je     0x71dc01a527a7
    71dc01a52a99:	e9 fd 06 00 00       	jmp    0x71dc01a5319b
    71dc01a52a9e:	83 f9 08             	cmp    ecx,0x8
    71dc01a52aa1:	0f 84 70 ff ff ff    	je     0x71dc01a52a17
    71dc01a52aa7:	e9 9c 06 00 00       	jmp    0x71dc01a53148
    71dc01a52aac:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52ab3:	ff 15 47 27 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92747]        # 0x71dc015e5200
    71dc01a52ab9:	e9 e9 fc ff ff       	jmp    0x71dc01a527a7
    71dc01a52abe:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52ac5:	ff 15 1d 27 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9271d]        # 0x71dc015e51e8
    71dc01a52acb:	e9 d7 fc ff ff       	jmp    0x71dc01a527a7
    71dc01a52ad0:	c5 fc 57 c0          	vxorps ymm0,ymm0,ymm0
    71dc01a52ad4:	c5 fe 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm0
    71dc01a52ad9:	c5 fa 7f 45 c8       	vmovdqu XMMWORD PTR [rbp-0x38],xmm0
    71dc01a52ade:	48 8d 7d b0          	lea    rdi,[rbp-0x50]
    71dc01a52ae2:	be 1b 00 00 00       	mov    esi,0x1b
    71dc01a52ae7:	ba 01 00 00 00       	mov    edx,0x1
    71dc01a52aec:	ff 15 76 c0 42 ff    	call   QWORD PTR [rip+0xffffffffff42c076]        # 0x71dc00e7eb68
    71dc01a52af2:	c5 fe 6f 45 b0       	vmovdqu ymm0,YMMWORD PTR [rbp-0x50]
    71dc01a52af7:	c5 fe 7f 85 28 02 00 	vmovdqu YMMWORD PTR [rbp+0x228],ymm0
    71dc01a52afe:	00 
    71dc01a52aff:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    71dc01a52b03:	48 89 bd 48 02 00 00 	mov    QWORD PTR [rbp+0x248],rdi
    71dc01a52b0a:	8b bd 38 02 00 00    	mov    edi,DWORD PTR [rbp+0x238]
    71dc01a52b10:	3b bd 48 02 00 00    	cmp    edi,DWORD PTR [rbp+0x248]
    71dc01a52b16:	0f 87 fc 07 00 00    	ja     0x71dc01a53318
    71dc01a52b1c:	48 8b b5 40 02 00 00 	mov    rsi,QWORD PTR [rbp+0x240]
    71dc01a52b23:	8b c7                	mov    eax,edi
    71dc01a52b25:	48 8d 34 46          	lea    rsi,[rsi+rax*2]
    71dc01a52b29:	8b 85 48 02 00 00    	mov    eax,DWORD PTR [rbp+0x248]
    71dc01a52b2f:	2b c7                	sub    eax,edi
    71dc01a52b31:	83 f8 1b             	cmp    eax,0x1b
    71dc01a52b34:	0f 82 eb 07 00 00    	jb     0x71dc01a53325
    71dc01a52b3a:	c5 fc 10 05 7e 0b 00 	vmovups ymm0,YMMWORD PTR [rip+0xb7e]        # 0x71dc01a536c0
    71dc01a52b41:	00 
    71dc01a52b42:	c5 fc 11 06          	vmovups YMMWORD PTR [rsi],ymm0
    71dc01a52b46:	c5 f8 10 05 92 0b 00 	vmovups xmm0,XMMWORD PTR [rip+0xb92]        # 0x71dc01a536e0
    71dc01a52b4d:	00 
    71dc01a52b4e:	c5 f8 11 46 20       	vmovups XMMWORD PTR [rsi+0x20],xmm0
    71dc01a52b53:	c7 46 30 65 00 3a 00 	mov    DWORD PTR [rsi+0x30],0x3a0065
    71dc01a52b5a:	66 c7 46 34 20 00    	mov    WORD PTR [rsi+0x34],0x20
    71dc01a52b60:	8b bd 38 02 00 00    	mov    edi,DWORD PTR [rbp+0x238]
    71dc01a52b66:	83 c7 1b             	add    edi,0x1b
    71dc01a52b69:	89 bd 38 02 00 00    	mov    DWORD PTR [rbp+0x238],edi
    71dc01a52b6f:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52b76:	8b 76 10             	mov    esi,DWORD PTR [rsi+0x10]
    71dc01a52b79:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    71dc01a52b80:	ff 15 1a a6 b2 ff    	call   QWORD PTR [rip+0xffffffffffb2a61a]        # 0x71dc0157d1a0
    71dc01a52b86:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01a52b8d:	71 00 00 
    71dc01a52b90:	e8 2b e7 5f 7c       	call   0x71dc7e0512c0
    71dc01a52b95:	48 8b d8             	mov    rbx,rax
    71dc01a52b98:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    71dc01a52b9f:	ff 15 f3 bf 42 ff    	call   QWORD PTR [rip+0xffffffffff42bff3]        # 0x71dc00e7eb98
    71dc01a52ba5:	48 8b f0             	mov    rsi,rax
    71dc01a52ba8:	48 8b fb             	mov    rdi,rbx
    71dc01a52bab:	ff 15 bf 37 4f ff    	call   QWORD PTR [rip+0xffffffffff4f37bf]        # 0x71dc00f46370
    71dc01a52bb1:	48 8b fb             	mov    rdi,rbx
    71dc01a52bb4:	e8 e7 f3 35 7c       	call   0x71dc7ddb1fa0
    71dc01a52bb9:	cc                   	int3
    71dc01a52bba:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    71dc01a52bc1:	00 
    71dc01a52bc2:	0f 85 dc 00 00 00    	jne    0x71dc01a52ca4
    71dc01a52bc8:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52bcf:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01a52bd2:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    71dc01a52bd9:	ff 15 49 25 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92549]        # 0x71dc015e5128
    71dc01a52bdf:	48 8b d8             	mov    rbx,rax
    71dc01a52be2:	48 bf a0 27 e6 ff db 	movabs rdi,0x71dbffe627a0
    71dc01a52be9:	71 00 00 
    71dc01a52bec:	be 01 00 00 00       	mov    esi,0x1
    71dc01a52bf1:	e8 5a e8 5f 7c       	call   0x71dc7e051450
    71dc01a52bf6:	4c 8b f8             	mov    r15,rax
    71dc01a52bf9:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    71dc01a52bfd:	48 8b f3             	mov    rsi,rbx
    71dc01a52c00:	e8 3b d4 1c fd       	call   0x71dbfec20040
    71dc01a52c05:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52c0c:	48 8b 57 70          	mov    rdx,QWORD PTR [rdi+0x70]
    71dc01a52c10:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52c17:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01a52c1a:	49 8b ff             	mov    rdi,r15
    71dc01a52c1d:	ff 15 65 c6 b2 ff    	call   QWORD PTR [rip+0xffffffffffb2c665]        # 0x71dc0157f288
    71dc01a52c23:	48 8b d8             	mov    rbx,rax
    71dc01a52c26:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52c2d:	4c 8b 7f 70          	mov    r15,QWORD PTR [rdi+0x70]
    71dc01a52c31:	48 bf c8 a0 5d 01 dc 	movabs rdi,0x71dc015da0c8
    71dc01a52c38:	71 00 00 
    71dc01a52c3b:	e8 80 e6 5f 7c       	call   0x71dc7e0512c0
    71dc01a52c40:	4c 8b f0             	mov    r14,rax
    71dc01a52c43:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a52c4a:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    71dc01a52c4d:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    71dc01a52c51:	48 8b f3             	mov    rsi,rbx
    71dc01a52c54:	e8 e7 d3 1c fd       	call   0x71dbfec20040
    71dc01a52c59:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    71dc01a52c5d:	49 8b f7             	mov    rsi,r15
    71dc01a52c60:	e8 db d3 1c fd       	call   0x71dbfec20040
    71dc01a52c65:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    71dc01a52c69:	49 8b f5             	mov    rsi,r13
    71dc01a52c6c:	e8 cf d3 1c fd       	call   0x71dbfec20040
    71dc01a52c71:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc01a52c78:	71 00 00 
    71dc01a52c7b:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01a52c7e:	49 8d 7e 20          	lea    rdi,[r14+0x20]
    71dc01a52c82:	e8 b9 d3 1c fd       	call   0x71dbfec20040
    71dc01a52c87:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52c8e:	48 8d bf 90 00 00 00 	lea    rdi,[rdi+0x90]
    71dc01a52c95:	49 8b f6             	mov    rsi,r14
    71dc01a52c98:	e8 a3 d3 1c fd       	call   0x71dbfec20040
    71dc01a52c9d:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52ca4:	48 8b 97 90 00 00 00 	mov    rdx,QWORD PTR [rdi+0x90]
    71dc01a52cab:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    71dc01a52cb2:	4c 8b 87 88 00 00 00 	mov    r8,QWORD PTR [rdi+0x88]
    71dc01a52cb9:	38 12                	cmp    BYTE PTR [rdx],dl
    71dc01a52cbb:	48 8d 75 80          	lea    rsi,[rbp-0x80]
    71dc01a52cbf:	48 8b fa             	mov    rdi,rdx
    71dc01a52cc2:	48 8b d1             	mov    rdx,rcx
    71dc01a52cc5:	49 8b c8             	mov    rcx,r8
    71dc01a52cc8:	45 33 c0             	xor    r8d,r8d
    71dc01a52ccb:	ff 15 b7 98 c9 ff    	call   QWORD PTR [rip+0xffffffffffc998b7]        # 0x71dc016ec588
    71dc01a52cd1:	48 8b 5d 80          	mov    rbx,QWORD PTR [rbp-0x80]
    71dc01a52cd5:	4c 0f bf 7d 88       	movsx  r15,WORD PTR [rbp-0x78]
    71dc01a52cda:	48 8b 45 90          	mov    rax,QWORD PTR [rbp-0x70]
    71dc01a52cde:	0f b6 4d 98          	movzx  ecx,BYTE PTR [rbp-0x68]
    71dc01a52ce2:	48 85 db             	test   rbx,rbx
    71dc01a52ce5:	0f 85 09 05 00 00    	jne    0x71dc01a531f4
    71dc01a52ceb:	48 89 85 88 02 00 00 	mov    QWORD PTR [rbp+0x288],rax
    71dc01a52cf2:	88 8d 90 02 00 00    	mov    BYTE PTR [rbp+0x290],cl
    71dc01a52cf8:	48 bf c0 1a 80 21 d4 	movabs rdi,0x71d421801ac0
    71dc01a52cff:	71 00 00 
    71dc01a52d02:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01a52d05:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52d0c:	48 8d bf 80 00 00 00 	lea    rdi,[rdi+0x80]
    71dc01a52d13:	e8 28 d3 1c fd       	call   0x71dbfec20040
    71dc01a52d18:	33 ff                	xor    edi,edi
    71dc01a52d1a:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    71dc01a52d21:	48 89 bb 88 00 00 00 	mov    QWORD PTR [rbx+0x88],rdi
    71dc01a52d28:	80 bd 90 02 00 00 00 	cmp    BYTE PTR [rbp+0x290],0x0
    71dc01a52d2f:	74 28                	je     0x71dc01a52d59
    71dc01a52d31:	48 8d bd 88 02 00 00 	lea    rdi,[rbp+0x288]
    71dc01a52d38:	ff 15 7a 24 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9247a]        # 0x71dc015e51b8
    71dc01a52d3e:	48 8b f0             	mov    rsi,rax
    71dc01a52d41:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    71dc01a52d48:	e8 f3 d2 1c fd       	call   0x71dbfec20040
    71dc01a52d4d:	c6 83 e1 00 00 00 01 	mov    BYTE PTR [rbx+0xe1],0x1
    71dc01a52d54:	e9 f6 06 00 00       	jmp    0x71dc01a5344f
    71dc01a52d59:	48 8b b3 90 00 00 00 	mov    rsi,QWORD PTR [rbx+0x90]
    71dc01a52d60:	48 8b 76 20          	mov    rsi,QWORD PTR [rsi+0x20]
    71dc01a52d64:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    71dc01a52d6b:	ff 15 f7 22 b9 ff    	call   QWORD PTR [rip+0xffffffffffb922f7]        # 0x71dc015e5068
    71dc01a52d71:	33 f6                	xor    esi,esi
    71dc01a52d73:	48 89 b3 90 00 00 00 	mov    QWORD PTR [rbx+0x90],rsi
    71dc01a52d7a:	e9 28 fa ff ff       	jmp    0x71dc01a527a7
    71dc01a52d7f:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52d86:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01a52d89:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    71dc01a52d90:	ff 15 92 23 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92392]        # 0x71dc015e5128
    71dc01a52d96:	48 8b f0             	mov    rsi,rax
    71dc01a52d99:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    71dc01a52da0:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    71dc01a52da7:	e8 94 d2 1c fd       	call   0x71dbfec20040
    71dc01a52dac:	66 c7 83 e0 00 00 00 	mov    WORD PTR [rbx+0xe0],0x101
    71dc01a52db3:	01 01 
    71dc01a52db5:	ff 83 dc 00 00 00    	inc    DWORD PTR [rbx+0xdc]
    71dc01a52dbb:	e9 8f 06 00 00       	jmp    0x71dc01a5344f
    71dc01a52dc0:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52dc7:	ff 15 ab 24 b9 ff    	call   QWORD PTR [rip+0xffffffffffb924ab]        # 0x71dc015e5278
    71dc01a52dcd:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    71dc01a52dd3:	e9 cf f9 ff ff       	jmp    0x71dc01a527a7
    71dc01a52dd8:	48 8b 85 98 02 00 00 	mov    rax,QWORD PTR [rbp+0x298]
    71dc01a52ddf:	48 8d 3c 24          	lea    rdi,[rsp]
    71dc01a52de3:	48 8b f0             	mov    rsi,rax
    71dc01a52de6:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    71dc01a52de9:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    71dc01a52ded:	48 83 c6 08          	add    rsi,0x8
    71dc01a52df1:	48 83 c7 08          	add    rdi,0x8
    71dc01a52df5:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    71dc01a52df7:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    71dc01a52df9:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52e00:	ff 15 5a 24 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9245a]        # 0x71dc015e5260
    71dc01a52e06:	85 c0                	test   eax,eax
    71dc01a52e08:	0f 84 15 01 00 00    	je     0x71dc01a52f23
    71dc01a52e0e:	e9 3c 06 00 00       	jmp    0x71dc01a5344f
    71dc01a52e13:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52e1a:	c5 fa 6f 06          	vmovdqu xmm0,XMMWORD PTR [rsi]
    71dc01a52e1e:	c5 fa 7f 85 68 ff ff 	vmovdqu XMMWORD PTR [rbp-0x98],xmm0
    71dc01a52e25:	ff 
    71dc01a52e26:	4c 8b 5e 10          	mov    r11,QWORD PTR [rsi+0x10]
    71dc01a52e2a:	4c 89 9d 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],r11
    71dc01a52e31:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    71dc01a52e35:	48 8b 76 68          	mov    rsi,QWORD PTR [rsi+0x68]
    71dc01a52e39:	83 bd 78 ff ff ff 1d 	cmp    DWORD PTR [rbp-0x88],0x1d
    71dc01a52e40:	0f 85 0d 04 00 00    	jne    0x71dc01a53253
    71dc01a52e46:	44 8b 9d 70 ff ff ff 	mov    r11d,DWORD PTR [rbp-0x90]
    71dc01a52e4d:	48 b8 a8 79 55 01 dc 	movabs rax,0x71dc015579a8
    71dc01a52e54:	71 00 00 
    71dc01a52e57:	48 39 06             	cmp    QWORD PTR [rsi],rax
    71dc01a52e5a:	0f 85 13 04 00 00    	jne    0x71dc01a53273
    71dc01a52e60:	44 39 5e 08          	cmp    DWORD PTR [rsi+0x8],r11d
    71dc01a52e64:	0f 86 fe 02 00 00    	jbe    0x71dc01a53168
    71dc01a52e6a:	4a 8b 74 de 10       	mov    rsi,QWORD PTR [rsi+r11*8+0x10]
    71dc01a52e6f:	80 7e 25 00          	cmp    BYTE PTR [rsi+0x25],0x0
    71dc01a52e73:	0f 84 aa 00 00 00    	je     0x71dc01a52f23
    71dc01a52e79:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52e80:	48 8d 87 e8 00 00 00 	lea    rax,[rdi+0xe8]
    71dc01a52e87:	8b 4e 20             	mov    ecx,DWORD PTR [rsi+0x20]
    71dc01a52e8a:	80 7e 24 00          	cmp    BYTE PTR [rsi+0x24],0x0
    71dc01a52e8e:	0f 95 c2             	setne  dl
    71dc01a52e91:	0f b6 d2             	movzx  edx,dl
    71dc01a52e94:	8d 4c 11 01          	lea    ecx,[rcx+rdx*1+0x1]
    71dc01a52e98:	85 c9                	test   ecx,ecx
    71dc01a52e9a:	0f 8c ee 03 00 00    	jl     0x71dc01a5328e
    71dc01a52ea0:	8b 58 30             	mov    ebx,DWORD PTR [rax+0x30]
    71dc01a52ea3:	3b d9                	cmp    ebx,ecx
    71dc01a52ea5:	0f 8c e3 03 00 00    	jl     0x71dc01a5328e
    71dc01a52eab:	2b d9                	sub    ebx,ecx
    71dc01a52ead:	48 8b 00             	mov    rax,QWORD PTR [rax]
    71dc01a52eb0:	03 d3                	add    edx,ebx
    71dc01a52eb2:	3b 50 08             	cmp    edx,DWORD PTR [rax+0x8]
    71dc01a52eb5:	0f 83 64 04 00 00    	jae    0x71dc01a5331f
    71dc01a52ebb:	8b ca                	mov    ecx,edx
    71dc01a52ebd:	48 8b 44 c8 10       	mov    rax,QWORD PTR [rax+rcx*8+0x10]
    71dc01a52ec2:	48 85 c0             	test   rax,rax
    71dc01a52ec5:	0f 84 e0 03 00 00    	je     0x71dc01a532ab
    71dc01a52ecb:	48 b9 38 aa 5d 01 dc 	movabs rcx,0x71dc015daa38
    71dc01a52ed2:	71 00 00 
    71dc01a52ed5:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01a52ed8:	75 05                	jne    0x71dc01a52edf
    71dc01a52eda:	4c 8b f8             	mov    r15,rax
    71dc01a52edd:	eb 03                	jmp    0x71dc01a52ee2
    71dc01a52edf:	45 33 ff             	xor    r15d,r15d
    71dc01a52ee2:	45 33 f6             	xor    r14d,r14d
    71dc01a52ee5:	48 b9 70 04 61 01 dc 	movabs rcx,0x71dc01610470
    71dc01a52eec:	71 00 00 
    71dc01a52eef:	48 39 08             	cmp    QWORD PTR [rax],rcx
    71dc01a52ef2:	75 26                	jne    0x71dc01a52f1a
    71dc01a52ef4:	48 8b 48 10          	mov    rcx,QWORD PTR [rax+0x10]
    71dc01a52ef8:	48 85 c9             	test   rcx,rcx
    71dc01a52efb:	74 11                	je     0x71dc01a52f0e
    71dc01a52efd:	48 ba 38 aa 5d 01 dc 	movabs rdx,0x71dc015daa38
    71dc01a52f04:	71 00 00 
    71dc01a52f07:	48 39 11             	cmp    QWORD PTR [rcx],rdx
    71dc01a52f0a:	74 02                	je     0x71dc01a52f0e
    71dc01a52f0c:	33 c9                	xor    ecx,ecx
    71dc01a52f0e:	48 85 c9             	test   rcx,rcx
    71dc01a52f11:	74 07                	je     0x71dc01a52f1a
    71dc01a52f13:	4c 8b f9             	mov    r15,rcx
    71dc01a52f16:	4c 8b 70 08          	mov    r14,QWORD PTR [rax+0x8]
    71dc01a52f1a:	4d 85 ff             	test   r15,r15
    71dc01a52f1d:	0f 85 b6 03 00 00    	jne    0x71dc01a532d9
    71dc01a52f23:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a52f2a:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a52f31:	ff 15 11 23 b9 ff    	call   QWORD PTR [rip+0xffffffffffb92311]        # 0x71dc015e5248
    71dc01a52f37:	e9 6b f8 ff ff       	jmp    0x71dc01a527a7
    71dc01a52f3c:	48 8b 87 88 00 00 00 	mov    rax,QWORD PTR [rdi+0x88]
    71dc01a52f43:	33 c9                	xor    ecx,ecx
    71dc01a52f45:	48 89 8f 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rcx
    71dc01a52f4c:	48 8b f8             	mov    rdi,rax
    71dc01a52f4f:	e8 4c f0 35 7c       	call   0x71dc7ddb1fa0
    71dc01a52f54:	cc                   	int3
    71dc01a52f55:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a52f5c:	48 be e8 7f 65 fc db 	movabs rsi,0x71dbfc657fe8
    71dc01a52f63:	71 00 00 
    71dc01a52f66:	ff 15 2c 4b b2 ff    	call   QWORD PTR [rip+0xffffffffffb24b2c]        # 0x71dc01577a98
    71dc01a52f6c:	48 8b f8             	mov    rdi,rax
    71dc01a52f6f:	e8 2c f0 35 7c       	call   0x71dc7ddb1fa0
    71dc01a52f74:	cc                   	int3
    71dc01a52f75:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    71dc01a52f7c:	00 
    71dc01a52f7d:	0f 85 a1 00 00 00    	jne    0x71dc01a53024
    71dc01a52f83:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01a52f87:	8b f3                	mov    esi,ebx
    71dc01a52f89:	49 bb 10 4b c4 fe db 	movabs r11,0x71dbfec44b10
    71dc01a52f90:	71 00 00 
    71dc01a52f93:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a52f96:	48 8b f8             	mov    rdi,rax
    71dc01a52f99:	be 3c 00 00 00       	mov    esi,0x3c
    71dc01a52f9e:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01a52fa0:	ff 15 02 b5 b2 ff    	call   QWORD PTR [rip+0xffffffffffb2b502]        # 0x71dc0157e4a8
    71dc01a52fa6:	85 c0                	test   eax,eax
    71dc01a52fa8:	75 7a                	jne    0x71dc01a53024
    71dc01a52faa:	45 38 24 24          	cmp    BYTE PTR [r12],r12b
    71dc01a52fae:	49 8b fc             	mov    rdi,r12
    71dc01a52fb1:	ff 15 91 c0 b2 ff    	call   QWORD PTR [rip+0xffffffffffb2c091]        # 0x71dc0157f048
    71dc01a52fb7:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
    71dc01a52fbe:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01a52fc2:	8b f3                	mov    esi,ebx
    71dc01a52fc4:	49 bb 18 4b c4 fe db 	movabs r11,0x71dbfec44b18
    71dc01a52fcb:	71 00 00 
    71dc01a52fce:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a52fd1:	48 8b f0             	mov    rsi,rax
    71dc01a52fd4:	48 8b bd 60 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xa0]
    71dc01a52fdb:	48 8d 55 a8          	lea    rdx,[rbp-0x58]
    71dc01a52fdf:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01a52fe1:	ff 15 79 a9 45 fe    	call   QWORD PTR [rip+0xfffffffffe45a979]        # 0x71dbffead960
    71dc01a52fe7:	85 c0                	test   eax,eax
    71dc01a52fe9:	74 09                	je     0x71dc01a52ff4
    71dc01a52feb:	48 8b 75 a8          	mov    rsi,QWORD PTR [rbp-0x58]
    71dc01a52fef:	e9 ea f8 ff ff       	jmp    0x71dc01a528de
    71dc01a52ff4:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01a52ff8:	8b f3                	mov    esi,ebx
    71dc01a52ffa:	49 bb 20 4b c4 fe db 	movabs r11,0x71dbfec44b20
    71dc01a53001:	71 00 00 
    71dc01a53004:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53007:	48 8b f0             	mov    rsi,rax
    71dc01a5300a:	48 8d 55 a0          	lea    rdx,[rbp-0x60]
    71dc01a5300e:	49 8b fc             	mov    rdi,r12
    71dc01a53011:	ff 15 a9 43 b9 ff    	call   QWORD PTR [rip+0xffffffffffb943a9]        # 0x71dc015e73c0
    71dc01a53017:	85 c0                	test   eax,eax
    71dc01a53019:	74 09                	je     0x71dc01a53024
    71dc01a5301b:	48 8b 75 a0          	mov    rsi,QWORD PTR [rbp-0x60]
    71dc01a5301f:	e9 ba f8 ff ff       	jmp    0x71dc01a528de
    71dc01a53024:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    71dc01a5302b:	00 
    71dc01a5302c:	75 21                	jne    0x71dc01a5304f
    71dc01a5302e:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01a53032:	8b f3                	mov    esi,ebx
    71dc01a53034:	49 bb 08 4b c4 fe db 	movabs r11,0x71dbfec44b08
    71dc01a5303b:	71 00 00 
    71dc01a5303e:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53041:	48 8b f8             	mov    rdi,rax
    71dc01a53044:	49 8b f5             	mov    rsi,r13
    71dc01a53047:	ff 15 8b 43 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9438b]        # 0x71dc015e73d8
    71dc01a5304d:	eb 1f                	jmp    0x71dc01a5306e
    71dc01a5304f:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    71dc01a53053:	8b f3                	mov    esi,ebx
    71dc01a53055:	49 bb 00 4b c4 fe db 	movabs r11,0x71dbfec44b00
    71dc01a5305c:	71 00 00 
    71dc01a5305f:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53062:	48 8b f8             	mov    rdi,rax
    71dc01a53065:	49 8b f5             	mov    rsi,r13
    71dc01a53068:	ff 15 da 42 b9 ff    	call   QWORD PTR [rip+0xffffffffffb942da]        # 0x71dc015e7348
    71dc01a5306e:	48 8b f8             	mov    rdi,rax
    71dc01a53071:	e8 2a ef 35 7c       	call   0x71dc7ddb1fa0
    71dc01a53076:	cc                   	int3
    71dc01a53077:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01a5307e:	71 00 00 
    71dc01a53081:	e8 3a e2 5f 7c       	call   0x71dc7e0512c0
    71dc01a53086:	48 8b d8             	mov    rbx,rax
    71dc01a53089:	48 8b fb             	mov    rdi,rbx
    71dc01a5308c:	48 be c0 e2 60 fc db 	movabs rsi,0x71dbfc60e2c0
    71dc01a53093:	71 00 00 
    71dc01a53096:	ff 15 d4 32 4f ff    	call   QWORD PTR [rip+0xffffffffff4f32d4]        # 0x71dc00f46370
    71dc01a5309c:	48 8b fb             	mov    rdi,rbx
    71dc01a5309f:	e8 fc ee 35 7c       	call   0x71dc7ddb1fa0
    71dc01a530a4:	cc                   	int3
    71dc01a530a5:	48 bf f0 42 42 01 dc 	movabs rdi,0x71dc014242f0
    71dc01a530ac:	71 00 00 
    71dc01a530af:	e8 ec 45 df ff       	call   0x71dc018476a0
    71dc01a530b4:	4c 8b f8             	mov    r15,rax
    71dc01a530b7:	e9 9b f8 ff ff       	jmp    0x71dc01a52957
    71dc01a530bc:	48 8b f3             	mov    rsi,rbx
    71dc01a530bf:	48 bf a0 a5 65 fc db 	movabs rdi,0x71dbfc65a5a0
    71dc01a530c6:	71 00 00 
    71dc01a530c9:	ff 15 f1 3f b9 ff    	call   QWORD PTR [rip+0xffffffffffb93ff1]        # 0x71dc015e70c0
    71dc01a530cf:	48 8b f8             	mov    rdi,rax
    71dc01a530d2:	e8 c9 ee 35 7c       	call   0x71dc7ddb1fa0
    71dc01a530d7:	cc                   	int3
    71dc01a530d8:	49 8b ff             	mov    rdi,r15
    71dc01a530db:	49 bb 28 4b c4 fe db 	movabs r11,0x71dbfec44b28
    71dc01a530e2:	71 00 00 
    71dc01a530e5:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a530e8:	e9 8f f8 ff ff       	jmp    0x71dc01a5297c
    71dc01a530ed:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    71dc01a530f4:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    71dc01a530f7:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a530fe:	49 8d bd e8 00 00 00 	lea    rdi,[r13+0xe8]
    71dc01a53105:	ff 15 1d 20 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9201d]        # 0x71dc015e5128
    71dc01a5310b:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a53112:	ff 15 b8 47 b2 ff    	call   QWORD PTR [rip+0xffffffffffb247b8]        # 0x71dc015778d0
    71dc01a53118:	41 89 85 d8 00 00 00 	mov    DWORD PTR [r13+0xd8],eax
    71dc01a5311f:	bb 01 00 00 00       	mov    ebx,0x1
    71dc01a53124:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a5312b:	e9 84 f8 ff ff       	jmp    0x71dc01a529b4
    71dc01a53130:	49 8b ff             	mov    rdi,r15
    71dc01a53133:	49 bb 30 4b c4 fe db 	movabs r11,0x71dbfec44b30
    71dc01a5313a:	71 00 00 
    71dc01a5313d:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53140:	48 8b f0             	mov    rsi,rax
    71dc01a53143:	e9 61 f8 ff ff       	jmp    0x71dc01a529a9
    71dc01a53148:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a5314f:	48 be 10 80 65 fc db 	movabs rsi,0x71dbfc658010
    71dc01a53156:	71 00 00 
    71dc01a53159:	ff 15 39 49 b2 ff    	call   QWORD PTR [rip+0xffffffffffb24939]        # 0x71dc01577a98
    71dc01a5315f:	48 8b f8             	mov    rdi,rax
    71dc01a53162:	e8 39 ee 35 7c       	call   0x71dc7ddb1fa0
    71dc01a53167:	cc                   	int3
    71dc01a53168:	ff 15 42 c3 42 ff    	call   QWORD PTR [rip+0xffffffffff42c342]        # 0x71dc00e7f4b0
    71dc01a5316e:	cc                   	int3
    71dc01a5316f:	48 8b f8             	mov    rdi,rax
    71dc01a53172:	49 bb f8 4a c4 fe db 	movabs r11,0x71dbfec44af8
    71dc01a53179:	71 00 00 
    71dc01a5317c:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a5317f:	48 8b f0             	mov    rsi,rax
    71dc01a53182:	e9 bd f8 ff ff       	jmp    0x71dc01a52a44
    71dc01a53187:	48 bf 30 a3 55 01 dc 	movabs rdi,0x71dc0155a330
    71dc01a5318e:	71 00 00 
    71dc01a53191:	e8 ca 72 df ff       	call   0x71dc0184a460
    71dc01a53196:	e9 c4 f8 ff ff       	jmp    0x71dc01a52a5f
    71dc01a5319b:	48 8b f3             	mov    rsi,rbx
    71dc01a5319e:	48 bf 60 8f fa ff db 	movabs rdi,0x71dbfffa8f60
    71dc01a531a5:	71 00 00 
    71dc01a531a8:	e8 d3 1b df ff       	call   0x71dc01844d80
    71dc01a531ad:	48 85 c0             	test   rax,rax
    71dc01a531b0:	74 25                	je     0x71dc01a531d7
    71dc01a531b2:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    71dc01a531b5:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01a531bb:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01a531c1:	0f 84 e0 f5 ff ff    	je     0x71dc01a527a7
    71dc01a531c7:	48 8b f8             	mov    rdi,rax
    71dc01a531ca:	33 f6                	xor    esi,esi
    71dc01a531cc:	ff 15 46 26 0c ff    	call   QWORD PTR [rip+0xffffffffff0c2646]        # 0x71dc00b15818
    71dc01a531d2:	e9 d0 f5 ff ff       	jmp    0x71dc01a527a7
    71dc01a531d7:	48 8b fb             	mov    rdi,rbx
    71dc01a531da:	48 0f bf b5 68 02 00 	movsx  rsi,WORD PTR [rbp+0x268]
    71dc01a531e1:	00 
    71dc01a531e2:	49 bb 38 4b c4 fe db 	movabs r11,0x71dbfec44b38
    71dc01a531e9:	71 00 00 
    71dc01a531ec:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a531ef:	e9 b3 f5 ff ff       	jmp    0x71dc01a527a7
    71dc01a531f4:	48 8b f3             	mov    rsi,rbx
    71dc01a531f7:	48 bf 40 be 6f 01 dc 	movabs rdi,0x71dc016fbe40
    71dc01a531fe:	71 00 00 
    71dc01a53201:	e8 7a 1b df ff       	call   0x71dc01844d80
    71dc01a53206:	4c 8b f0             	mov    r14,rax
    71dc01a53209:	4d 85 f6             	test   r14,r14
    71dc01a5320c:	74 2b                	je     0x71dc01a53239
    71dc01a5320e:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    71dc01a53212:	81 e7 00 00 00 11    	and    edi,0x11000000
    71dc01a53218:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    71dc01a5321e:	74 0b                	je     0x71dc01a5322b
    71dc01a53220:	49 8b fe             	mov    rdi,r14
    71dc01a53223:	33 f6                	xor    esi,esi
    71dc01a53225:	ff 15 ed 25 0c ff    	call   QWORD PTR [rip+0xffffffffff0c25ed]        # 0x71dc00b15818
    71dc01a5322b:	49 8b 46 38          	mov    rax,QWORD PTR [r14+0x38]
    71dc01a5322f:	41 0f b6 4e 40       	movzx  ecx,BYTE PTR [r14+0x40]
    71dc01a53234:	e9 b2 fa ff ff       	jmp    0x71dc01a52ceb
    71dc01a53239:	48 8b fb             	mov    rdi,rbx
    71dc01a5323c:	41 8b f7             	mov    esi,r15d
    71dc01a5323f:	49 bb 40 4b c4 fe db 	movabs r11,0x71dbfec44b40
    71dc01a53246:	71 00 00 
    71dc01a53249:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a5324c:	8b ca                	mov    ecx,edx
    71dc01a5324e:	e9 98 fa ff ff       	jmp    0x71dc01a52ceb
    71dc01a53253:	48 8d bd 68 ff ff ff 	lea    rdi,[rbp-0x98]
    71dc01a5325a:	48 be 10 81 65 fc db 	movabs rsi,0x71dbfc658110
    71dc01a53261:	71 00 00 
    71dc01a53264:	ff 15 2e 48 b2 ff    	call   QWORD PTR [rip+0xffffffffffb2482e]        # 0x71dc01577a98
    71dc01a5326a:	48 8b f8             	mov    rdi,rax
    71dc01a5326d:	e8 2e ed 35 7c       	call   0x71dc7ddb1fa0
    71dc01a53272:	cc                   	int3
    71dc01a53273:	48 8b fe             	mov    rdi,rsi
    71dc01a53276:	41 8b f3             	mov    esi,r11d
    71dc01a53279:	49 bb 48 4b c4 fe db 	movabs r11,0x71dbfec44b48
    71dc01a53280:	71 00 00 
    71dc01a53283:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53286:	48 8b f0             	mov    rsi,rax
    71dc01a53289:	e9 e1 fb ff ff       	jmp    0x71dc01a52e6f
    71dc01a5328e:	48 8b 76 18          	mov    rsi,QWORD PTR [rsi+0x18]
    71dc01a53292:	48 bf 98 7f 65 fc db 	movabs rdi,0x71dbfc657f98
    71dc01a53299:	71 00 00 
    71dc01a5329c:	ff 15 1e 3e b9 ff    	call   QWORD PTR [rip+0xffffffffffb93e1e]        # 0x71dc015e70c0
    71dc01a532a2:	48 8b f8             	mov    rdi,rax
    71dc01a532a5:	e8 f6 ec 35 7c       	call   0x71dc7ddb1fa0
    71dc01a532aa:	cc                   	int3
    71dc01a532ab:	48 bf 88 2f 31 00 dc 	movabs rdi,0x71dc00312f88
    71dc01a532b2:	71 00 00 
    71dc01a532b5:	e8 06 e0 5f 7c       	call   0x71dc7e0512c0
    71dc01a532ba:	48 8b d8             	mov    rbx,rax
    71dc01a532bd:	48 8b fb             	mov    rdi,rbx
    71dc01a532c0:	48 be c0 e2 60 fc db 	movabs rsi,0x71dbfc60e2c0
    71dc01a532c7:	71 00 00 
    71dc01a532ca:	ff 15 a0 30 4f ff    	call   QWORD PTR [rip+0xffffffffff4f30a0]        # 0x71dc00f46370
    71dc01a532d0:	48 8b fb             	mov    rdi,rbx
    71dc01a532d3:	e8 c8 ec 35 7c       	call   0x71dc7ddb1fa0
    71dc01a532d8:	cc                   	int3
    71dc01a532d9:	41 80 7f 65 00       	cmp    BYTE PTR [r15+0x65],0x0
    71dc01a532de:	0f 84 3f fc ff ff    	je     0x71dc01a52f23
    71dc01a532e4:	48 8d 7f 38          	lea    rdi,[rdi+0x38]
    71dc01a532e8:	e8 53 cd 1c fd       	call   0x71dbfec20040
    71dc01a532ed:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a532f4:	49 8d 7d 40          	lea    rdi,[r13+0x40]
    71dc01a532f8:	49 8b f7             	mov    rsi,r15
    71dc01a532fb:	e8 40 cd 1c fd       	call   0x71dbfec20040
    71dc01a53300:	49 8d 7d 48          	lea    rdi,[r13+0x48]
    71dc01a53304:	49 8b f6             	mov    rsi,r14
    71dc01a53307:	e8 34 cd 1c fd       	call   0x71dbfec20040
    71dc01a5330c:	41 89 9d d0 00 00 00 	mov    DWORD PTR [r13+0xd0],ebx
    71dc01a53313:	e9 37 01 00 00       	jmp    0x71dc01a5344f
    71dc01a53318:	ff 15 42 1f b2 ff    	call   QWORD PTR [rip+0xffffffffffb21f42]        # 0x71dc01575260
    71dc01a5331e:	cc                   	int3
    71dc01a5331f:	e8 e4 e2 3f fe       	call   0x71dbffe51608
    71dc01a53324:	cc                   	int3
    71dc01a53325:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    71dc01a5332c:	48 be 60 7c 65 fc db 	movabs rsi,0x71dbfc657c60
    71dc01a53333:	71 00 00 
    71dc01a53336:	ff 15 64 92 c9 ff    	call   QWORD PTR [rip+0xffffffffffc99264]        # 0x71dc016ec5a0
    71dc01a5333c:	e9 2e f8 ff ff       	jmp    0x71dc01a52b6f
    71dc01a53341:	33 ff                	xor    edi,edi
    71dc01a53343:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a5334a:	41 89 bd dc 00 00 00 	mov    DWORD PTR [r13+0xdc],edi
    71dc01a53351:	49 8b fd             	mov    rdi,r13
    71dc01a53354:	80 bf e2 00 00 00 00 	cmp    BYTE PTR [rdi+0xe2],0x0
    71dc01a5335b:	0f 85 ee 00 00 00    	jne    0x71dc01a5344f
    71dc01a53361:	83 bd bc 02 00 00 00 	cmp    DWORD PTR [rbp+0x2bc],0x0
    71dc01a53368:	0f 84 e1 00 00 00    	je     0x71dc01a5344f
    71dc01a5336e:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    71dc01a53372:	48 8b 76 50          	mov    rsi,QWORD PTR [rsi+0x50]
    71dc01a53376:	44 8b 9f d8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xd8]
    71dc01a5337d:	48 b8 48 02 5b 01 dc 	movabs rax,0x71dc015b0248
    71dc01a53384:	71 00 00 
    71dc01a53387:	48 39 06             	cmp    QWORD PTR [rsi],rax
    71dc01a5338a:	75 7a                	jne    0x71dc01a53406
    71dc01a5338c:	44 3b 5e 10          	cmp    r11d,DWORD PTR [rsi+0x10]
    71dc01a53390:	0f 83 a3 00 00 00    	jae    0x71dc01a53439
    71dc01a53396:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    71dc01a5339a:	44 3b 5e 08          	cmp    r11d,DWORD PTR [rsi+0x8]
    71dc01a5339e:	0f 83 a5 00 00 00    	jae    0x71dc01a53449
    71dc01a533a4:	4a 8b 5c de 10       	mov    rbx,QWORD PTR [rsi+r11*8+0x10]
    71dc01a533a9:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a533b0:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    71dc01a533b7:	83 78 08 00          	cmp    DWORD PTR [rax+0x8],0x0
    71dc01a533bb:	74 1c                	je     0x71dc01a533d9
    71dc01a533bd:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    71dc01a533c4:	8b 8f d8 00 00 00    	mov    ecx,DWORD PTR [rdi+0xd8]
    71dc01a533ca:	3b 48 08             	cmp    ecx,DWORD PTR [rax+0x8]
    71dc01a533cd:	73 7a                	jae    0x71dc01a53449
    71dc01a533cf:	48 8d 44 c8 10       	lea    rax,[rax+rcx*8+0x10]
    71dc01a533d4:	80 38 00             	cmp    BYTE PTR [rax],0x0
    71dc01a533d7:	74 18                	je     0x71dc01a533f1
    71dc01a533d9:	33 c0                	xor    eax,eax
    71dc01a533db:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    71dc01a533e1:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    71dc01a533e5:	48 89 85 b0 02 00 00 	mov    QWORD PTR [rbp+0x2b0],rax
    71dc01a533ec:	e9 d4 f3 ff ff       	jmp    0x71dc01a527c5
    71dc01a533f1:	8b 8f 18 01 00 00    	mov    ecx,DWORD PTR [rdi+0x118]
    71dc01a533f7:	c6 00 01             	mov    BYTE PTR [rax],0x1
    71dc01a533fa:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    71dc01a533fd:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a53404:	eb d3                	jmp    0x71dc01a533d9
    71dc01a53406:	48 8b fe             	mov    rdi,rsi
    71dc01a53409:	41 8b f3             	mov    esi,r11d
    71dc01a5340c:	49 bb f0 4a c4 fe db 	movabs r11,0x71dbfec44af0
    71dc01a53413:	71 00 00 
    71dc01a53416:	41 ff 13             	call   QWORD PTR [r11]
    71dc01a53419:	48 8b d8             	mov    rbx,rax
    71dc01a5341c:	eb 8b                	jmp    0x71dc01a533a9
    71dc01a5341e:	83 78 20 00          	cmp    DWORD PTR [rax+0x20],0x0
    71dc01a53422:	0f 84 0c f4 ff ff    	je     0x71dc01a52834
    71dc01a53428:	48 8b f9             	mov    rdi,rcx
    71dc01a5342b:	ff 15 4f 16 b9 ff    	call   QWORD PTR [rip+0xffffffffffb9164f]        # 0x71dc015e4a80
    71dc01a53431:	e9 fe f3 ff ff       	jmp    0x71dc01a52834
    71dc01a53436:	90                   	nop
    71dc01a53437:	eb 16                	jmp    0x71dc01a5344f
    71dc01a53439:	ff 15 71 c0 42 ff    	call   QWORD PTR [rip+0xffffffffff42c071]        # 0x71dc00e7f4b0
    71dc01a5343f:	cc                   	int3
    71dc01a53440:	48 8b fa             	mov    rdi,rdx
    71dc01a53443:	e8 58 eb 35 7c       	call   0x71dc7ddb1fa0
    71dc01a53448:	cc                   	int3
    71dc01a53449:	e8 ba e1 3f fe       	call   0x71dbffe51608
    71dc01a5344e:	cc                   	int3
    71dc01a5344f:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a53456:	e8 fd 00 00 00       	call   0x71dc01a53558
    71dc01a5345b:	90                   	nop
    71dc01a5345c:	c5 f8 77             	vzeroupper
    71dc01a5345f:	48 81 c4 88 03 00 00 	add    rsp,0x388
    71dc01a53466:	5b                   	pop    rbx
    71dc01a53467:	41 5c                	pop    r12
    71dc01a53469:	41 5d                	pop    r13
    71dc01a5346b:	41 5e                	pop    r14
    71dc01a5346d:	41 5f                	pop    r15
    71dc01a5346f:	5d                   	pop    rbp
    71dc01a53470:	c3                   	ret
    71dc01a53471:	48 83 ec 18          	sub    rsp,0x18
    71dc01a53475:	48 8b df             	mov    rbx,rdi
    71dc01a53478:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a5347f:	ff 15 4b 9d b2 ff    	call   QWORD PTR [rip+0xffffffffffb29d4b]        # 0x71dc0157d1d0
    71dc01a53485:	48 8b d0             	mov    rdx,rax
    71dc01a53488:	48 8b f3             	mov    rsi,rbx
    71dc01a5348b:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a53492:	ff 15 f8 1d b9 ff    	call   QWORD PTR [rip+0xffffffffffb91df8]        # 0x71dc015e5290
    71dc01a53498:	85 c0                	test   eax,eax
    71dc01a5349a:	75 0f                	jne    0x71dc01a534ab
    71dc01a5349c:	48 8d 05 93 ff ff ff 	lea    rax,[rip+0xffffffffffffff93]        # 0x71dc01a53436
    71dc01a534a3:	c5 f8 77             	vzeroupper
    71dc01a534a6:	48 83 c4 18          	add    rsp,0x18
    71dc01a534aa:	c3                   	ret
    71dc01a534ab:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    71dc01a534b2:	00 00 00 
    71dc01a534b5:	48 8d 05 eb f2 ff ff 	lea    rax,[rip+0xfffffffffffff2eb]        # 0x71dc01a527a7
    71dc01a534bc:	c5 f8 77             	vzeroupper
    71dc01a534bf:	48 83 c4 18          	add    rsp,0x18
    71dc01a534c3:	c3                   	ret
    71dc01a534c4:	48 83 ec 18          	sub    rsp,0x18
    71dc01a534c8:	48 8b df             	mov    rbx,rdi
    71dc01a534cb:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a534d2:	ff 15 f8 9c b2 ff    	call   QWORD PTR [rip+0xffffffffffb29cf8]        # 0x71dc0157d1d0
    71dc01a534d8:	48 8b d0             	mov    rdx,rax
    71dc01a534db:	48 8b f3             	mov    rsi,rbx
    71dc01a534de:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a534e5:	ff 15 bd 1d b9 ff    	call   QWORD PTR [rip+0xffffffffffb91dbd]        # 0x71dc015e52a8
    71dc01a534eb:	85 c0                	test   eax,eax
    71dc01a534ed:	75 06                	jne    0x71dc01a534f5
    71dc01a534ef:	e8 6c eb 35 7c       	call   0x71dc7ddb2060
    71dc01a534f4:	cc                   	int3
    71dc01a534f5:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    71dc01a534fc:	00 00 00 
    71dc01a534ff:	48 8d 05 a1 f2 ff ff 	lea    rax,[rip+0xfffffffffffff2a1]        # 0x71dc01a527a7
    71dc01a53506:	c5 f8 77             	vzeroupper
    71dc01a53509:	48 83 c4 18          	add    rsp,0x18
    71dc01a5350d:	c3                   	ret
    71dc01a5350e:	48 83 ec 18          	sub    rsp,0x18
    71dc01a53512:	48 8b df             	mov    rbx,rdi
    71dc01a53515:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    71dc01a5351c:	ff 15 ae 9c b2 ff    	call   QWORD PTR [rip+0xffffffffffb29cae]        # 0x71dc0157d1d0
    71dc01a53522:	48 8b d0             	mov    rdx,rax
    71dc01a53525:	48 8b f3             	mov    rsi,rbx
    71dc01a53528:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    71dc01a5352f:	ff 15 8b 1d b9 ff    	call   QWORD PTR [rip+0xffffffffffb91d8b]        # 0x71dc015e52c0
    71dc01a53535:	85 c0                	test   eax,eax
    71dc01a53537:	75 06                	jne    0x71dc01a5353f
    71dc01a53539:	e8 22 eb 35 7c       	call   0x71dc7ddb2060
    71dc01a5353e:	cc                   	int3
    71dc01a5353f:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    71dc01a53546:	00 00 00 
    71dc01a53549:	48 8d 05 57 f2 ff ff 	lea    rax,[rip+0xfffffffffffff257]        # 0x71dc01a527a7
    71dc01a53550:	c5 f8 77             	vzeroupper
    71dc01a53553:	48 83 c4 18          	add    rsp,0x18
    71dc01a53557:	c3                   	ret
    71dc01a53558:	48 83 ec 18          	sub    rsp,0x18
    71dc01a5355c:	4c 8b ad c0 02 00 00 	mov    r13,QWORD PTR [rbp+0x2c0]
    71dc01a53563:	41 80 bd e1 00 00 00 	cmp    BYTE PTR [r13+0xe1],0x0
    71dc01a5356a:	00 
    71dc01a5356b:	75 0e                	jne    0x71dc01a5357b
    71dc01a5356d:	49 83 7d 38 00       	cmp    QWORD PTR [r13+0x38],0x0
    71dc01a53572:	75 07                	jne    0x71dc01a5357b
    71dc01a53574:	49 83 7d 60 00       	cmp    QWORD PTR [r13+0x60],0x0
    71dc01a53579:	74 08                	je     0x71dc01a53583
    71dc01a5357b:	c5 f8 77             	vzeroupper
    71dc01a5357e:	48 83 c4 18          	add    rsp,0x18
    71dc01a53582:	c3                   	ret
    71dc01a53583:	33 f6                	xor    esi,esi
    71dc01a53585:	49 89 75 68          	mov    QWORD PTR [r13+0x68],rsi
    71dc01a53589:	41 8b b5 18 01 00 00 	mov    esi,DWORD PTR [r13+0x118]
    71dc01a53590:	49 8d bd e8 00 00 00 	lea    rdi,[r13+0xe8]
    71dc01a53597:	ff 15 6b 1d b9 ff    	call   QWORD PTR [rip+0xffffffffffb91d6b]        # 0x71dc015e5308
    71dc01a5359d:	49 81 c5 e8 00 00 00 	add    r13,0xe8
    71dc01a535a4:	49 8b 7d 00          	mov    rdi,QWORD PTR [r13+0x0]
    71dc01a535a8:	83 7f 08 00          	cmp    DWORD PTR [rdi+0x8],0x0
    71dc01a535ac:	74 0d                	je     0x71dc01a535bb
    71dc01a535ae:	8b 5f 08             	mov    ebx,DWORD PTR [rdi+0x8]
    71dc01a535b1:	48 c1 e3 04          	shl    rbx,0x4
    71dc01a535b5:	48 83 c3 20          	add    rbx,0x20
    71dc01a535b9:	eb 02                	jmp    0x71dc01a535bd
    71dc01a535bb:	33 db                	xor    ebx,ebx
    71dc01a535bd:	49 03 5d 28          	add    rbx,QWORD PTR [r13+0x28]
    71dc01a535c1:	70 37                	jo     0x71dc01a535fa
    71dc01a535c3:	48 bf a8 0f 80 21 d4 	movabs rdi,0x71d421800fa8
    71dc01a535ca:	71 00 00 
    71dc01a535cd:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    71dc01a535d0:	49 8b fd             	mov    rdi,r13
    71dc01a535d3:	e8 68 ca 1c fd       	call   0x71dbfec20040
    71dc01a535d8:	33 ff                	xor    edi,edi
    71dc01a535da:	49 89 7d 28          	mov    QWORD PTR [r13+0x28],rdi
    71dc01a535de:	49 8b 7d 08          	mov    rdi,QWORD PTR [r13+0x8]
    71dc01a535e2:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    71dc01a535e6:	48 8b bf 80 00 00 00 	mov    rdi,QWORD PTR [rdi+0x80]
    71dc01a535ed:	48 8b f3             	mov    rsi,rbx
    71dc01a535f0:	39 3f                	cmp    DWORD PTR [rdi],edi
    71dc01a535f2:	ff 15 70 32 b9 ff    	call   QWORD PTR [rip+0xffffffffffb93270]        # 0x71dc015e6868
    71dc01a535f8:	eb 81                	jmp    0x71dc01a5357b
    71dc01a535fa:	e8 f1 df 3f fe       	call   0x71dbffe515f0
    71dc01a535ff:	cc                   	int3
