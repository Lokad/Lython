
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5758.bin:     file format binary


Disassembly of section .data:

00007130796f4840 <.data>:
    7130796f4840:	55                   	push   rbp
    7130796f4841:	41 57                	push   r15
    7130796f4843:	41 56                	push   r14
    7130796f4845:	41 55                	push   r13
    7130796f4847:	41 54                	push   r12
    7130796f4849:	53                   	push   rbx
    7130796f484a:	48 81 ec 38 01 00 00 	sub    rsp,0x138
    7130796f4851:	48 8d ac 24 60 01 00 	lea    rbp,[rsp+0x160]
    7130796f4858:	00 
    7130796f4859:	33 c0                	xor    eax,eax
    7130796f485b:	48 89 85 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rax
    7130796f4862:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    7130796f4867:	62 71 7e 48 7f 45 fc 	vmovdqu32 ZMMWORD PTR [rbp-0x100],zmm8
    7130796f486e:	62 71 7e 48 7f 45 fd 	vmovdqu32 ZMMWORD PTR [rbp-0xc0],zmm8
    7130796f4875:	62 71 7e 48 7f 45 fe 	vmovdqu32 ZMMWORD PTR [rbp-0x80],zmm8
    7130796f487c:	c5 79 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm8
    7130796f4881:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    7130796f4885:	4c 8b ff             	mov    r15,rdi
    7130796f4888:	4c 8b ee             	mov    r13,rsi
    7130796f488b:	8b da                	mov    ebx,edx
    7130796f488d:	4c 8b e1             	mov    r12,rcx
    7130796f4890:	4d 8b f0             	mov    r14,r8
    7130796f4893:	85 db                	test   ebx,ebx
    7130796f4895:	75 53                	jne    0x7130796f48ea
    7130796f4897:	4d 85 ff             	test   r15,r15
    7130796f489a:	74 4e                	je     0x7130796f48ea
    7130796f489c:	49 b8 90 f0 68 79 30 	movabs r8,0x71307968f090
    7130796f48a3:	71 00 00 
    7130796f48a6:	4d 39 07             	cmp    QWORD PTR [r15],r8
    7130796f48a9:	75 3f                	jne    0x7130796f48ea
    7130796f48ab:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    7130796f48af:	41 8b 77 10          	mov    esi,DWORD PTR [r15+0x10]
    7130796f48b3:	4d 85 ed             	test   r13,r13
    7130796f48b6:	74 32                	je     0x7130796f48ea
    7130796f48b8:	49 b8 90 f0 68 79 30 	movabs r8,0x71307968f090
    7130796f48bf:	71 00 00 
    7130796f48c2:	4d 39 45 00          	cmp    QWORD PTR [r13+0x0],r8
    7130796f48c6:	75 22                	jne    0x7130796f48ea
    7130796f48c8:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
    7130796f48cc:	41 8b 4d 10          	mov    ecx,DWORD PTR [r13+0x10]
    7130796f48d0:	4d 8b 44 24 30       	mov    r8,QWORD PTR [r12+0x30]
    7130796f48d5:	4d 8b 80 80 00 00 00 	mov    r8,QWORD PTR [r8+0x80]
    7130796f48dc:	4d 8b ce             	mov    r9,r14
    7130796f48df:	ff 15 73 b2 15 00    	call   QWORD PTR [rip+0x15b273]        # 0x71307984fb58
    7130796f48e5:	e9 b0 07 00 00       	jmp    0x7130796f509a
    7130796f48ea:	83 fb 03             	cmp    ebx,0x3
    7130796f48ed:	0f 84 b9 07 00 00    	je     0x7130796f50ac
    7130796f48f3:	8b fb                	mov    edi,ebx
    7130796f48f5:	ff 15 8d b2 15 00    	call   QWORD PTR [rip+0x15b28d]        # 0x71307984fb88
    7130796f48fb:	48 85 c0             	test   rax,rax
    7130796f48fe:	74 40                	je     0x7130796f4940
    7130796f4900:	4c 8d 4d d0          	lea    r9,[rbp-0x30]
    7130796f4904:	49 8b ff             	mov    rdi,r15
    7130796f4907:	48 8b f0             	mov    rsi,rax
    7130796f490a:	49 8b d5             	mov    rdx,r13
    7130796f490d:	49 8b cc             	mov    rcx,r12
    7130796f4910:	4d 8b c6             	mov    r8,r14
    7130796f4913:	ff 15 87 b2 15 00    	call   QWORD PTR [rip+0x15b287]        # 0x71307984fba0
    7130796f4919:	85 c0                	test   eax,eax
    7130796f491b:	74 23                	je     0x7130796f4940
    7130796f491d:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796f4921:	48 85 ff             	test   rdi,rdi
    7130796f4924:	74 11                	je     0x7130796f4937
    7130796f4926:	48 b8 e0 53 ac 79 30 	movabs rax,0x713079ac53e0
    7130796f492d:	71 00 00 
    7130796f4930:	48 39 07             	cmp    QWORD PTR [rdi],rax
    7130796f4933:	74 02                	je     0x7130796f4937
    7130796f4935:	33 ff                	xor    edi,edi
    7130796f4937:	48 85 ff             	test   rdi,rdi
    7130796f493a:	0f 84 81 01 00 00    	je     0x7130796f4ac1
    7130796f4940:	83 fb 02             	cmp    ebx,0x2
    7130796f4943:	0f 85 80 00 00 00    	jne    0x7130796f49c9
    7130796f4949:	49 8b ff             	mov    rdi,r15
    7130796f494c:	ff 15 66 b2 15 00    	call   QWORD PTR [rip+0x15b266]        # 0x71307984fbb8
    7130796f4952:	85 c0                	test   eax,eax
    7130796f4954:	74 73                	je     0x7130796f49c9
    7130796f4956:	4d 8b cd             	mov    r9,r13
    7130796f4959:	4d 85 c9             	test   r9,r9
    7130796f495c:	74 12                	je     0x7130796f4970
    7130796f495e:	48 be 58 a6 ad 79 30 	movabs rsi,0x713079ada658
    7130796f4965:	71 00 00 
    7130796f4968:	49 39 31             	cmp    QWORD PTR [r9],rsi
    7130796f496b:	74 03                	je     0x7130796f4970
    7130796f496d:	45 33 c9             	xor    r9d,r9d
    7130796f4970:	4d 85 c9             	test   r9,r9
    7130796f4973:	74 54                	je     0x7130796f49c9
    7130796f4975:	4c 8d 8d 70 ff ff ff 	lea    r9,[rbp-0x90]
    7130796f497c:	49 8b f7             	mov    rsi,r15
    7130796f497f:	49 8b d5             	mov    rdx,r13
    7130796f4982:	49 8b cc             	mov    rcx,r12
    7130796f4985:	4d 8b c6             	mov    r8,r14
    7130796f4988:	bf 04 00 00 00       	mov    edi,0x4
    7130796f498d:	ff 15 3d b2 15 00    	call   QWORD PTR [rip+0x15b23d]        # 0x71307984fbd0
    7130796f4993:	85 c0                	test   eax,eax
    7130796f4995:	0f 85 2f 01 00 00    	jne    0x7130796f4aca
    7130796f499b:	49 8b fd             	mov    rdi,r13
    7130796f499e:	49 8b f4             	mov    rsi,r12
    7130796f49a1:	49 8b d6             	mov    rdx,r14
    7130796f49a4:	ff 15 26 a3 15 00    	call   QWORD PTR [rip+0x15a326]        # 0x71307984ecd0
    7130796f49aa:	48 89 85 a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rax
    7130796f49b1:	48 8b f8             	mov    rdi,rax
    7130796f49b4:	ff 15 2e b2 15 00    	call   QWORD PTR [rip+0x15b22e]        # 0x71307984fbe8
    7130796f49ba:	85 c0                	test   eax,eax
    7130796f49bc:	0f 84 6f 07 00 00    	je     0x7130796f5131
    7130796f49c2:	4c 8b ad a0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x160]
    7130796f49c9:	85 db                	test   ebx,ebx
    7130796f49cb:	75 56                	jne    0x7130796f4a23
    7130796f49cd:	4d 8b cf             	mov    r9,r15
    7130796f49d0:	4d 85 c9             	test   r9,r9
    7130796f49d3:	74 12                	je     0x7130796f49e7
    7130796f49d5:	48 bf 30 b2 ad 79 30 	movabs rdi,0x713079adb230
    7130796f49dc:	71 00 00 
    7130796f49df:	49 39 39             	cmp    QWORD PTR [r9],rdi
    7130796f49e2:	74 03                	je     0x7130796f49e7
    7130796f49e4:	45 33 c9             	xor    r9d,r9d
    7130796f49e7:	49 8b c1             	mov    rax,r9
    7130796f49ea:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
    7130796f49f1:	48 85 c0             	test   rax,rax
    7130796f49f4:	0f 85 39 01 00 00    	jne    0x7130796f4b33
    7130796f49fa:	49 8b c7             	mov    rax,r15
    7130796f49fd:	48 85 c0             	test   rax,rax
    7130796f4a00:	74 11                	je     0x7130796f4a13
    7130796f4a02:	48 bf 58 5b af 79 30 	movabs rdi,0x713079af5b58
    7130796f4a09:	71 00 00 
    7130796f4a0c:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4a0f:	74 02                	je     0x7130796f4a13
    7130796f4a11:	33 c0                	xor    eax,eax
    7130796f4a13:	48 89 85 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rax
    7130796f4a1a:	48 85 c0             	test   rax,rax
    7130796f4a1d:	0f 85 b3 00 00 00    	jne    0x7130796f4ad6
    7130796f4a23:	83 fb 02             	cmp    ebx,0x2
    7130796f4a26:	0f 85 80 00 00 00    	jne    0x7130796f4aac
    7130796f4a2c:	49 8b c7             	mov    rax,r15
    7130796f4a2f:	48 85 c0             	test   rax,rax
    7130796f4a32:	74 11                	je     0x7130796f4a45
    7130796f4a34:	48 b9 30 b2 ad 79 30 	movabs rcx,0x713079adb230
    7130796f4a3b:	71 00 00 
    7130796f4a3e:	48 39 08             	cmp    QWORD PTR [rax],rcx
    7130796f4a41:	74 02                	je     0x7130796f4a45
    7130796f4a43:	33 c0                	xor    eax,eax
    7130796f4a45:	48 89 85 e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rax
    7130796f4a4c:	48 85 c0             	test   rax,rax
    7130796f4a4f:	74 1b                	je     0x7130796f4a6c
    7130796f4a51:	48 8d 4d c0          	lea    rcx,[rbp-0x40]
    7130796f4a55:	49 8b fd             	mov    rdi,r13
    7130796f4a58:	49 8b f4             	mov    rsi,r12
    7130796f4a5b:	49 8b d6             	mov    rdx,r14
    7130796f4a5e:	ff 15 e4 b1 15 00    	call   QWORD PTR [rip+0x15b1e4]        # 0x71307984fc48
    7130796f4a64:	85 c0                	test   eax,eax
    7130796f4a66:	0f 85 fb 00 00 00    	jne    0x7130796f4b67
    7130796f4a6c:	49 8b c7             	mov    rax,r15
    7130796f4a6f:	48 85 c0             	test   rax,rax
    7130796f4a72:	74 11                	je     0x7130796f4a85
    7130796f4a74:	48 b9 58 5b af 79 30 	movabs rcx,0x713079af5b58
    7130796f4a7b:	71 00 00 
    7130796f4a7e:	48 39 08             	cmp    QWORD PTR [rax],rcx
    7130796f4a81:	74 02                	je     0x7130796f4a85
    7130796f4a83:	33 c0                	xor    eax,eax
    7130796f4a85:	48 89 85 d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rax
    7130796f4a8c:	48 85 c0             	test   rax,rax
    7130796f4a8f:	74 1b                	je     0x7130796f4aac
    7130796f4a91:	48 8d 4d b0          	lea    rcx,[rbp-0x50]
    7130796f4a95:	49 8b fd             	mov    rdi,r13
    7130796f4a98:	49 8b f4             	mov    rsi,r12
    7130796f4a9b:	49 8b d6             	mov    rdx,r14
    7130796f4a9e:	ff 15 a4 b1 15 00    	call   QWORD PTR [rip+0x15b1a4]        # 0x71307984fc48
    7130796f4aa4:	85 c0                	test   eax,eax
    7130796f4aa6:	0f 85 29 01 00 00    	jne    0x7130796f4bd5
    7130796f4aac:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    7130796f4ab0:	49 8b f4             	mov    rsi,r12
    7130796f4ab3:	49 8b d6             	mov    rdx,r14
    7130796f4ab6:	ff 15 ec b1 15 00    	call   QWORD PTR [rip+0x15b1ec]        # 0x71307984fca8
    7130796f4abc:	e9 7a 01 00 00       	jmp    0x7130796f4c3b
    7130796f4ac1:	48 8b 45 d0          	mov    rax,QWORD PTR [rbp-0x30]
    7130796f4ac5:	e9 d0 05 00 00       	jmp    0x7130796f509a
    7130796f4aca:	48 8b 85 70 ff ff ff 	mov    rax,QWORD PTR [rbp-0x90]
    7130796f4ad1:	e9 c4 05 00 00       	jmp    0x7130796f509a
    7130796f4ad6:	48 8b f8             	mov    rdi,rax
    7130796f4ad9:	49 8b f5             	mov    rsi,r13
    7130796f4adc:	49 8b d6             	mov    rdx,r14
    7130796f4adf:	49 8b cc             	mov    rcx,r12
    7130796f4ae2:	45 33 c0             	xor    r8d,r8d
    7130796f4ae5:	ff 15 45 b1 15 00    	call   QWORD PTR [rip+0x15b145]        # 0x71307984fc30
    7130796f4aeb:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
    7130796f4af2:	48 89 95 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdx
    7130796f4af9:	48 8d bd 60 ff ff ff 	lea    rdi,[rbp-0xa0]
    7130796f4b00:	ff 15 8a 8d 15 00    	call   QWORD PTR [rip+0x158d8a]        # 0x71307984d890
    7130796f4b06:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
    7130796f4b0d:	48 89 95 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rdx
    7130796f4b14:	4c 8b ad 50 ff ff ff 	mov    r13,QWORD PTR [rbp-0xb0]
    7130796f4b1b:	4d 85 ed             	test   r13,r13
    7130796f4b1e:	0f 85 22 06 00 00    	jne    0x7130796f5146
    7130796f4b24:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
    7130796f4b2b:	49 8b c6             	mov    rax,r14
    7130796f4b2e:	e9 67 05 00 00       	jmp    0x7130796f509a
    7130796f4b33:	49 8b fd             	mov    rdi,r13
    7130796f4b36:	49 8b f6             	mov    rsi,r14
    7130796f4b39:	49 8b d4             	mov    rdx,r12
    7130796f4b3c:	ff 15 6e a6 15 00    	call   QWORD PTR [rip+0x15a66e]        # 0x71307984f1b0
    7130796f4b42:	48 8b f0             	mov    rsi,rax
    7130796f4b45:	48 8b bd f0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x110]
    7130796f4b4c:	49 8b d4             	mov    rdx,r12
    7130796f4b4f:	49 8b ce             	mov    rcx,r14
    7130796f4b52:	ff 15 c0 b0 15 00    	call   QWORD PTR [rip+0x15b0c0]        # 0x71307984fc18
    7130796f4b58:	48 8b 9d f0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x110]
    7130796f4b5f:	48 8b c3             	mov    rax,rbx
    7130796f4b62:	e9 33 05 00 00       	jmp    0x7130796f509a
    7130796f4b67:	48 8b 7d c0          	mov    rdi,QWORD PTR [rbp-0x40]
    7130796f4b6b:	48 8b 75 c8          	mov    rsi,QWORD PTR [rbp-0x38]
    7130796f4b6f:	49 8b d6             	mov    rdx,r14
    7130796f4b72:	ff 15 e8 b0 15 00    	call   QWORD PTR [rip+0x15b0e8]        # 0x71307984fc60
    7130796f4b78:	8b f0                	mov    esi,eax
    7130796f4b7a:	48 8b bd e0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x120]
    7130796f4b81:	49 8b d6             	mov    rdx,r14
    7130796f4b84:	ff 15 ee b0 15 00    	call   QWORD PTR [rip+0x15b0ee]        # 0x71307984fc78
    7130796f4b8a:	49 8b 7c 24 30       	mov    rdi,QWORD PTR [r12+0x30]
    7130796f4b8f:	48 8b 87 80 00 00 00 	mov    rax,QWORD PTR [rdi+0x80]
    7130796f4b96:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
    7130796f4b9a:	48 85 c0             	test   rax,rax
    7130796f4b9d:	0f 85 fc 05 00 00    	jne    0x7130796f519f
    7130796f4ba3:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    7130796f4baa:	48 89 bd 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rdi
    7130796f4bb1:	48 8d bd 00 ff ff ff 	lea    rdi,[rbp-0x100]
    7130796f4bb8:	ff 15 7a 96 db ff    	call   QWORD PTR [rip+0xffffffffffdb967a]        # 0x7130794ae238
    7130796f4bbe:	85 c0                	test   eax,eax
    7130796f4bc0:	0f 85 e2 05 00 00    	jne    0x7130796f51a8
    7130796f4bc6:	4c 8b bd e0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x120]
    7130796f4bcd:	49 8b c7             	mov    rax,r15
    7130796f4bd0:	e9 c5 04 00 00       	jmp    0x7130796f509a
    7130796f4bd5:	48 8b 75 b0          	mov    rsi,QWORD PTR [rbp-0x50]
    7130796f4bd9:	48 8b 55 b8          	mov    rdx,QWORD PTR [rbp-0x48]
    7130796f4bdd:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
    7130796f4be4:	49 8b ce             	mov    rcx,r14
    7130796f4be7:	4d 8b c4             	mov    r8,r12
    7130796f4bea:	ff 15 a0 b0 15 00    	call   QWORD PTR [rip+0x15b0a0]        # 0x71307984fc90
    7130796f4bf0:	49 8b 7c 24 30       	mov    rdi,QWORD PTR [r12+0x30]
    7130796f4bf5:	48 8b 87 80 00 00 00 	mov    rax,QWORD PTR [rdi+0x80]
    7130796f4bfc:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
    7130796f4c00:	48 85 c0             	test   rax,rax
    7130796f4c03:	0f 85 ad 05 00 00    	jne    0x7130796f51b6
    7130796f4c09:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    7130796f4c10:	48 89 bd f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdi
    7130796f4c17:	48 8d bd f8 fe ff ff 	lea    rdi,[rbp-0x108]
    7130796f4c1e:	ff 15 14 96 db ff    	call   QWORD PTR [rip+0xffffffffffdb9614]        # 0x7130794ae238
    7130796f4c24:	85 c0                	test   eax,eax
    7130796f4c26:	0f 85 93 05 00 00    	jne    0x7130796f51bf
    7130796f4c2c:	4c 8b a5 d8 fe ff ff 	mov    r12,QWORD PTR [rbp-0x128]
    7130796f4c33:	49 8b c4             	mov    rax,r12
    7130796f4c36:	e9 5f 04 00 00       	jmp    0x7130796f509a
    7130796f4c3b:	49 8b c7             	mov    rax,r15
    7130796f4c3e:	48 85 c0             	test   rax,rax
    7130796f4c41:	74 11                	je     0x7130796f4c54
    7130796f4c43:	48 bf b0 67 af 79 30 	movabs rdi,0x713079af67b0
    7130796f4c4a:	71 00 00 
    7130796f4c4d:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4c50:	74 02                	je     0x7130796f4c54
    7130796f4c52:	33 c0                	xor    eax,eax
    7130796f4c54:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
    7130796f4c5b:	48 85 c0             	test   rax,rax
    7130796f4c5e:	74 79                	je     0x7130796f4cd9
    7130796f4c60:	49 8b f5             	mov    rsi,r13
    7130796f4c63:	48 85 f6             	test   rsi,rsi
    7130796f4c66:	74 11                	je     0x7130796f4c79
    7130796f4c68:	48 bf b0 67 af 79 30 	movabs rdi,0x713079af67b0
    7130796f4c6f:	71 00 00 
    7130796f4c72:	48 39 3e             	cmp    QWORD PTR [rsi],rdi
    7130796f4c75:	74 02                	je     0x7130796f4c79
    7130796f4c77:	33 f6                	xor    esi,esi
    7130796f4c79:	48 85 f6             	test   rsi,rsi
    7130796f4c7c:	74 5b                	je     0x7130796f4cd9
    7130796f4c7e:	83 fb 01             	cmp    ebx,0x1
    7130796f4c81:	74 41                	je     0x7130796f4cc4
    7130796f4c83:	8d 7b f8             	lea    edi,[rbx-0x8]
    7130796f4c86:	83 ff 02             	cmp    edi,0x2
    7130796f4c89:	77 4e                	ja     0x7130796f4cd9
    7130796f4c8b:	8b ff                	mov    edi,edi
    7130796f4c8d:	48 8d 0d f8 05 00 00 	lea    rcx,[rip+0x5f8]        # 0x7130796f528c
    7130796f4c94:	8b 0c b9             	mov    ecx,DWORD PTR [rcx+rdi*4]
    7130796f4c97:	48 8d 15 f5 fb ff ff 	lea    rdx,[rip+0xfffffffffffffbf5]        # 0x7130796f4893
    7130796f4c9e:	48 03 ca             	add    rcx,rdx
    7130796f4ca1:	ff e1                	jmp    rcx
    7130796f4ca3:	48 8b f8             	mov    rdi,rax
    7130796f4ca6:	ff 15 2c b0 15 00    	call   QWORD PTR [rip+0x15b02c]        # 0x71307984fcd8
    7130796f4cac:	eb 1f                	jmp    0x7130796f4ccd
    7130796f4cae:	48 8b f8             	mov    rdi,rax
    7130796f4cb1:	ff 15 39 b0 15 00    	call   QWORD PTR [rip+0x15b039]        # 0x71307984fcf0
    7130796f4cb7:	eb 14                	jmp    0x7130796f4ccd
    7130796f4cb9:	48 8b f8             	mov    rdi,rax
    7130796f4cbc:	ff 15 fe af 15 00    	call   QWORD PTR [rip+0x15affe]        # 0x71307984fcc0
    7130796f4cc2:	eb 09                	jmp    0x7130796f4ccd
    7130796f4cc4:	48 8b f8             	mov    rdi,rax
    7130796f4cc7:	ff 15 3b b0 15 00    	call   QWORD PTR [rip+0x15b03b]        # 0x71307984fd08
    7130796f4ccd:	4c 8b ad d0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x130]
    7130796f4cd4:	e9 b4 03 00 00       	jmp    0x7130796f508d
    7130796f4cd9:	83 fb 08             	cmp    ebx,0x8
    7130796f4cdc:	0f 85 3c 03 00 00    	jne    0x7130796f501e
    7130796f4ce2:	49 8b c7             	mov    rax,r15
    7130796f4ce5:	48 85 c0             	test   rax,rax
    7130796f4ce8:	74 11                	je     0x7130796f4cfb
    7130796f4cea:	48 bf d0 b1 ac 79 30 	movabs rdi,0x713079acb1d0
    7130796f4cf1:	71 00 00 
    7130796f4cf4:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4cf7:	74 02                	je     0x7130796f4cfb
    7130796f4cf9:	33 c0                	xor    eax,eax
    7130796f4cfb:	48 89 85 c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rax
    7130796f4d02:	48 85 c0             	test   rax,rax
    7130796f4d05:	0f 84 cb 00 00 00    	je     0x7130796f4dd6
    7130796f4d0b:	4d 8b 7c 24 30       	mov    r15,QWORD PTR [r12+0x30]
    7130796f4d10:	48 bf d0 b1 ac 79 30 	movabs rdi,0x713079acb1d0
    7130796f4d17:	71 00 00 
    7130796f4d1a:	e8 a1 c5 f5 7c       	call   0x7130f66512c0
    7130796f4d1f:	48 8b d8             	mov    rbx,rax
    7130796f4d22:	49 8b b7 80 00 00 00 	mov    rsi,QWORD PTR [r15+0x80]
    7130796f4d29:	48 8b fb             	mov    rdi,rbx
    7130796f4d2c:	49 8b d6             	mov    rdx,r14
    7130796f4d2f:	ff 15 e3 81 15 00    	call   QWORD PTR [rip+0x1581e3]        # 0x71307984cf18
    7130796f4d35:	48 8b fb             	mov    rdi,rbx
    7130796f4d38:	49 8b f5             	mov    rsi,r13
    7130796f4d3b:	49 8b d4             	mov    rdx,r12
    7130796f4d3e:	49 8b ce             	mov    rcx,r14
    7130796f4d41:	ff 15 d9 af 15 00    	call   QWORD PTR [rip+0x15afd9]        # 0x71307984fd20
    7130796f4d47:	48 8d bd 38 ff ff ff 	lea    rdi,[rbp-0xc8]
    7130796f4d4e:	49 8b f4             	mov    rsi,r12
    7130796f4d51:	49 8b d6             	mov    rdx,r14
    7130796f4d54:	ff 15 4e af 15 00    	call   QWORD PTR [rip+0x15af4e]        # 0x71307984fca8
    7130796f4d5a:	90                   	nop
    7130796f4d5b:	48 8b fb             	mov    rdi,rbx
    7130796f4d5e:	ff 15 b4 65 3d 00    	call   QWORD PTR [rip+0x3d65b4]        # 0x713079acb318
    7130796f4d64:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
    7130796f4d6b:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4d72:	49 bb d0 1c 27 77 30 	movabs r11,0x713077271cd0
    7130796f4d79:	71 00 00 
    7130796f4d7c:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4d7f:	85 c0                	test   eax,eax
    7130796f4d81:	74 26                	je     0x7130796f4da9
    7130796f4d83:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4d8a:	49 bb d8 1c 27 77 30 	movabs r11,0x713077271cd8
    7130796f4d91:	71 00 00 
    7130796f4d94:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4d97:	48 8b f0             	mov    rsi,rax
    7130796f4d9a:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
    7130796f4da1:	ff 15 41 65 3d 00    	call   QWORD PTR [rip+0x3d6541]        # 0x713079acb2e8
    7130796f4da7:	eb c2                	jmp    0x7130796f4d6b
    7130796f4da9:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4db0:	49 bb e0 1c 27 77 30 	movabs r11,0x713077271ce0
    7130796f4db7:	71 00 00 
    7130796f4dba:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4dbd:	4c 8b ad c8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x138]
    7130796f4dc4:	48 8d bd 38 ff ff ff 	lea    rdi,[rbp-0xc8]
    7130796f4dcb:	ff 15 27 b0 15 00    	call   QWORD PTR [rip+0x15b027]        # 0x71307984fdf8
    7130796f4dd1:	e9 b7 02 00 00       	jmp    0x7130796f508d
    7130796f4dd6:	49 8b c7             	mov    rax,r15
    7130796f4dd9:	48 85 c0             	test   rax,rax
    7130796f4ddc:	74 11                	je     0x7130796f4def
    7130796f4dde:	48 bf d0 6d af 79 30 	movabs rdi,0x713079af6dd0
    7130796f4de5:	71 00 00 
    7130796f4de8:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4deb:	74 02                	je     0x7130796f4def
    7130796f4ded:	33 c0                	xor    eax,eax
    7130796f4def:	48 89 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],rax
    7130796f4df6:	48 85 c0             	test   rax,rax
    7130796f4df9:	0f 84 d1 00 00 00    	je     0x7130796f4ed0
    7130796f4dff:	4d 8b 7c 24 30       	mov    r15,QWORD PTR [r12+0x30]
    7130796f4e04:	48 bf d0 b1 ac 79 30 	movabs rdi,0x713079acb1d0
    7130796f4e0b:	71 00 00 
    7130796f4e0e:	e8 ad c4 f5 7c       	call   0x7130f66512c0
    7130796f4e13:	48 8b d8             	mov    rbx,rax
    7130796f4e16:	49 8b b7 80 00 00 00 	mov    rsi,QWORD PTR [r15+0x80]
    7130796f4e1d:	48 8b fb             	mov    rdi,rbx
    7130796f4e20:	49 8b d6             	mov    rdx,r14
    7130796f4e23:	ff 15 ef 80 15 00    	call   QWORD PTR [rip+0x1580ef]        # 0x71307984cf18
    7130796f4e29:	48 8b fb             	mov    rdi,rbx
    7130796f4e2c:	49 8b f5             	mov    rsi,r13
    7130796f4e2f:	49 8b d4             	mov    rdx,r12
    7130796f4e32:	49 8b ce             	mov    rcx,r14
    7130796f4e35:	ff 15 e5 ae 15 00    	call   QWORD PTR [rip+0x15aee5]        # 0x71307984fd20
    7130796f4e3b:	48 8d bd 20 ff ff ff 	lea    rdi,[rbp-0xe0]
    7130796f4e42:	49 8b f4             	mov    rsi,r12
    7130796f4e45:	49 8b d6             	mov    rdx,r14
    7130796f4e48:	ff 15 5a ae 15 00    	call   QWORD PTR [rip+0x15ae5a]        # 0x71307984fca8
    7130796f4e4e:	90                   	nop
    7130796f4e4f:	48 8b fb             	mov    rdi,rbx
    7130796f4e52:	ff 15 c0 64 3d 00    	call   QWORD PTR [rip+0x3d64c0]        # 0x713079acb318
    7130796f4e58:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
    7130796f4e5f:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4e66:	49 bb b8 1c 27 77 30 	movabs r11,0x713077271cb8
    7130796f4e6d:	71 00 00 
    7130796f4e70:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4e73:	85 c0                	test   eax,eax
    7130796f4e75:	74 2c                	je     0x7130796f4ea3
    7130796f4e77:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4e7e:	49 bb c0 1c 27 77 30 	movabs r11,0x713077271cc0
    7130796f4e85:	71 00 00 
    7130796f4e88:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4e8b:	48 8b f0             	mov    rsi,rax
    7130796f4e8e:	4c 8b ad c0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x140]
    7130796f4e95:	49 8b 7d 08          	mov    rdi,QWORD PTR [r13+0x8]
    7130796f4e99:	39 3f                	cmp    DWORD PTR [rdi],edi
    7130796f4e9b:	ff 15 47 64 3d 00    	call   QWORD PTR [rip+0x3d6447]        # 0x713079acb2e8
    7130796f4ea1:	eb bc                	jmp    0x7130796f4e5f
    7130796f4ea3:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4eaa:	49 bb c8 1c 27 77 30 	movabs r11,0x713077271cc8
    7130796f4eb1:	71 00 00 
    7130796f4eb4:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4eb7:	4c 8b ad c0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x140]
    7130796f4ebe:	48 8d bd 20 ff ff ff 	lea    rdi,[rbp-0xe0]
    7130796f4ec5:	ff 15 2d af 15 00    	call   QWORD PTR [rip+0x15af2d]        # 0x71307984fdf8
    7130796f4ecb:	e9 bd 01 00 00       	jmp    0x7130796f508d
    7130796f4ed0:	49 8b c7             	mov    rax,r15
    7130796f4ed3:	48 85 c0             	test   rax,rax
    7130796f4ed6:	74 11                	je     0x7130796f4ee9
    7130796f4ed8:	48 bf 40 73 af 79 30 	movabs rdi,0x713079af7340
    7130796f4edf:	71 00 00 
    7130796f4ee2:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4ee5:	74 02                	je     0x7130796f4ee9
    7130796f4ee7:	33 c0                	xor    eax,eax
    7130796f4ee9:	48 89 85 b8 fe ff ff 	mov    QWORD PTR [rbp-0x148],rax
    7130796f4ef0:	48 85 c0             	test   rax,rax
    7130796f4ef3:	74 33                	je     0x7130796f4f28
    7130796f4ef5:	49 8b fd             	mov    rdi,r13
    7130796f4ef8:	ff 15 82 ae 15 00    	call   QWORD PTR [rip+0x15ae82]        # 0x71307984fd80
    7130796f4efe:	85 c0                	test   eax,eax
    7130796f4f00:	0f 84 5b 01 00 00    	je     0x7130796f5061
    7130796f4f06:	48 8b bd b8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x148]
    7130796f4f0d:	49 8b f5             	mov    rsi,r13
    7130796f4f10:	49 8b d6             	mov    rdx,r14
    7130796f4f13:	49 8b cc             	mov    rcx,r12
    7130796f4f16:	ff 15 7c ae 15 00    	call   QWORD PTR [rip+0x15ae7c]        # 0x71307984fd98
    7130796f4f1c:	4c 8b ad b8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x148]
    7130796f4f23:	e9 65 01 00 00       	jmp    0x7130796f508d
    7130796f4f28:	49 8b c7             	mov    rax,r15
    7130796f4f2b:	48 85 c0             	test   rax,rax
    7130796f4f2e:	74 13                	je     0x7130796f4f43
    7130796f4f30:	48 bf c8 0c af 79 30 	movabs rdi,0x713079af0cc8
    7130796f4f37:	71 00 00 
    7130796f4f3a:	48 39 38             	cmp    QWORD PTR [rax],rdi
    7130796f4f3d:	0f 85 43 01 00 00    	jne    0x7130796f5086
    7130796f4f43:	48 89 85 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rax
    7130796f4f4a:	48 85 c0             	test   rax,rax
    7130796f4f4d:	0f 84 cb 00 00 00    	je     0x7130796f501e
    7130796f4f53:	49 8b 5c 24 30       	mov    rbx,QWORD PTR [r12+0x30]
    7130796f4f58:	48 bf d0 b1 ac 79 30 	movabs rdi,0x713079acb1d0
    7130796f4f5f:	71 00 00 
    7130796f4f62:	e8 59 c3 f5 7c       	call   0x7130f66512c0
    7130796f4f67:	4c 8b f8             	mov    r15,rax
    7130796f4f6a:	48 8b b3 80 00 00 00 	mov    rsi,QWORD PTR [rbx+0x80]
    7130796f4f71:	49 8b ff             	mov    rdi,r15
    7130796f4f74:	49 8b d6             	mov    rdx,r14
    7130796f4f77:	ff 15 9b 7f 15 00    	call   QWORD PTR [rip+0x157f9b]        # 0x71307984cf18
    7130796f4f7d:	49 8b ff             	mov    rdi,r15
    7130796f4f80:	49 8b f5             	mov    rsi,r13
    7130796f4f83:	49 8b d4             	mov    rdx,r12
    7130796f4f86:	49 8b ce             	mov    rcx,r14
    7130796f4f89:	ff 15 91 ad 15 00    	call   QWORD PTR [rip+0x15ad91]        # 0x71307984fd20
    7130796f4f8f:	48 8d bd 08 ff ff ff 	lea    rdi,[rbp-0xf8]
    7130796f4f96:	49 8b f4             	mov    rsi,r12
    7130796f4f99:	49 8b d6             	mov    rdx,r14
    7130796f4f9c:	ff 15 06 ad 15 00    	call   QWORD PTR [rip+0x15ad06]        # 0x71307984fca8
    7130796f4fa2:	90                   	nop
    7130796f4fa3:	49 8b ff             	mov    rdi,r15
    7130796f4fa6:	ff 15 6c 63 3d 00    	call   QWORD PTR [rip+0x3d636c]        # 0x713079acb318
    7130796f4fac:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
    7130796f4fb3:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4fba:	49 bb a0 1c 27 77 30 	movabs r11,0x713077271ca0
    7130796f4fc1:	71 00 00 
    7130796f4fc4:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4fc7:	85 c0                	test   eax,eax
    7130796f4fc9:	74 29                	je     0x7130796f4ff4
    7130796f4fcb:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4fd2:	49 bb a8 1c 27 77 30 	movabs r11,0x713077271ca8
    7130796f4fd9:	71 00 00 
    7130796f4fdc:	41 ff 13             	call   QWORD PTR [r11]
    7130796f4fdf:	48 8b f0             	mov    rsi,rax
    7130796f4fe2:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
    7130796f4fe9:	49 8b ce             	mov    rcx,r14
    7130796f4fec:	ff 15 be bd 3f 00    	call   QWORD PTR [rip+0x3fbdbe]        # 0x713079af0db0
    7130796f4ff2:	eb bf                	jmp    0x7130796f4fb3
    7130796f4ff4:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f4ffb:	49 bb b0 1c 27 77 30 	movabs r11,0x713077271cb0
    7130796f5002:	71 00 00 
    7130796f5005:	41 ff 13             	call   QWORD PTR [r11]
    7130796f5008:	4c 8b ad b0 fe ff ff 	mov    r13,QWORD PTR [rbp-0x150]
    7130796f500f:	48 8d bd 08 ff ff ff 	lea    rdi,[rbp-0xf8]
    7130796f5016:	ff 15 dc ad 15 00    	call   QWORD PTR [rip+0x15addc]        # 0x71307984fdf8
    7130796f501c:	eb 6f                	jmp    0x7130796f508d
    7130796f501e:	8b fb                	mov    edi,ebx
    7130796f5020:	ff 15 a2 ad 15 00    	call   QWORD PTR [rip+0x15ada2]        # 0x71307984fdc8
    7130796f5026:	8b f8                	mov    edi,eax
    7130796f5028:	4c 8d 4d 90          	lea    r9,[rbp-0x70]
    7130796f502c:	49 8b f7             	mov    rsi,r15
    7130796f502f:	49 8b d5             	mov    rdx,r13
    7130796f5032:	49 8b cc             	mov    rcx,r12
    7130796f5035:	4d 8b c6             	mov    r8,r14
    7130796f5038:	ff 15 92 ab 15 00    	call   QWORD PTR [rip+0x15ab92]        # 0x71307984fbd0
    7130796f503e:	85 c0                	test   eax,eax
    7130796f5040:	74 06                	je     0x7130796f5048
    7130796f5042:	4c 8b 6d 90          	mov    r13,QWORD PTR [rbp-0x70]
    7130796f5046:	eb 45                	jmp    0x7130796f508d
    7130796f5048:	49 8b ff             	mov    rdi,r15
    7130796f504b:	49 8b f5             	mov    rsi,r13
    7130796f504e:	8b d3                	mov    edx,ebx
    7130796f5050:	49 8b cc             	mov    rcx,r12
    7130796f5053:	4d 8b c6             	mov    r8,r14
    7130796f5056:	ff 15 84 ad 15 00    	call   QWORD PTR [rip+0x15ad84]        # 0x71307984fde0
    7130796f505c:	4c 8b e8             	mov    r13,rax
    7130796f505f:	eb 2c                	jmp    0x7130796f508d
    7130796f5061:	49 8b fd             	mov    rdi,r13
    7130796f5064:	49 8b cc             	mov    rcx,r12
    7130796f5067:	49 8b d6             	mov    rdx,r14
    7130796f506a:	48 be a0 f6 e0 74 30 	movabs rsi,0x713074e0f6a0
    7130796f5071:	71 00 00 
    7130796f5074:	45 33 c0             	xor    r8d,r8d
    7130796f5077:	ff 15 db 8c 15 00    	call   QWORD PTR [rip+0x158cdb]        # 0x71307984dd58
    7130796f507d:	48 8b f8             	mov    rdi,rax
    7130796f5080:	e8 1b cf cb 7c       	call   0x7130f63b1fa0
    7130796f5085:	cc                   	int3
    7130796f5086:	33 c0                	xor    eax,eax
    7130796f5088:	e9 b6 fe ff ff       	jmp    0x7130796f4f43
    7130796f508d:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    7130796f5091:	ff 15 61 ad 15 00    	call   QWORD PTR [rip+0x15ad61]        # 0x71307984fdf8
    7130796f5097:	49 8b c5             	mov    rax,r13
    7130796f509a:	48 81 c4 38 01 00 00 	add    rsp,0x138
    7130796f50a1:	5b                   	pop    rbx
    7130796f50a2:	41 5c                	pop    r12
    7130796f50a4:	41 5d                	pop    r13
    7130796f50a6:	41 5e                	pop    r14
    7130796f50a8:	41 5f                	pop    r15
    7130796f50aa:	5d                   	pop    rbp
    7130796f50ab:	c3                   	ret
    7130796f50ac:	48 8d bd 78 ff ff ff 	lea    rdi,[rbp-0x88]
    7130796f50b3:	49 8b f7             	mov    rsi,r15
    7130796f50b6:	49 8b d5             	mov    rdx,r13
    7130796f50b9:	49 8b cc             	mov    rcx,r12
    7130796f50bc:	4d 8b c6             	mov    r8,r14
    7130796f50bf:	45 33 c9             	xor    r9d,r9d
    7130796f50c2:	ff 15 a8 aa 15 00    	call   QWORD PTR [rip+0x15aaa8]        # 0x71307984fb70
    7130796f50c8:	48 8b 9d 78 ff ff ff 	mov    rbx,QWORD PTR [rbp-0x88]
    7130796f50cf:	48 8b 45 80          	mov    rax,QWORD PTR [rbp-0x80]
    7130796f50d3:	4c 0f bf 7d 88       	movsx  r15,WORD PTR [rbp-0x78]
    7130796f50d8:	48 85 db             	test   rbx,rbx
    7130796f50db:	75 02                	jne    0x7130796f50df
    7130796f50dd:	eb bb                	jmp    0x7130796f509a
    7130796f50df:	48 8b f3             	mov    rsi,rbx
    7130796f50e2:	48 bf 30 f2 ad 79 30 	movabs rdi,0x713079adf230
    7130796f50e9:	71 00 00 
    7130796f50ec:	e8 2f 76 ff ff       	call   0x7130796ec720
    7130796f50f1:	4c 8b f0             	mov    r14,rax
    7130796f50f4:	4d 85 f6             	test   r14,r14
    7130796f50f7:	74 23                	je     0x7130796f511c
    7130796f50f9:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    7130796f50fd:	81 e7 00 00 00 11    	and    edi,0x11000000
    7130796f5103:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    7130796f5109:	74 0b                	je     0x7130796f5116
    7130796f510b:	49 8b fe             	mov    rdi,r14
    7130796f510e:	33 f6                	xor    esi,esi
    7130796f5110:	ff 15 02 07 a5 ff    	call   QWORD PTR [rip+0xffffffffffa50702]        # 0x713079145818
    7130796f5116:	49 8b 46 38          	mov    rax,QWORD PTR [r14+0x38]
    7130796f511a:	eb c1                	jmp    0x7130796f50dd
    7130796f511c:	48 8b fb             	mov    rdi,rbx
    7130796f511f:	41 8b f7             	mov    esi,r15d
    7130796f5122:	49 bb e8 1c 27 77 30 	movabs r11,0x713077271ce8
    7130796f5129:	71 00 00 
    7130796f512c:	41 ff 13             	call   QWORD PTR [r11]
    7130796f512f:	eb ac                	jmp    0x7130796f50dd
    7130796f5131:	49 8b fd             	mov    rdi,r13
    7130796f5134:	49 8b f6             	mov    rsi,r14
    7130796f5137:	ff 15 c3 aa 15 00    	call   QWORD PTR [rip+0x15aac3]        # 0x71307984fc00
    7130796f513d:	48 8b f8             	mov    rdi,rax
    7130796f5140:	e8 5b ce cb 7c       	call   0x7130f63b1fa0
    7130796f5145:	cc                   	int3
    7130796f5146:	49 8b f5             	mov    rsi,r13
    7130796f5149:	48 bf 60 8f 5d 78 30 	movabs rdi,0x7130785d8f60
    7130796f5150:	71 00 00 
    7130796f5153:	e8 c8 75 ff ff       	call   0x7130796ec720
    7130796f5158:	48 85 c0             	test   rax,rax
    7130796f515b:	74 25                	je     0x7130796f5182
    7130796f515d:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    7130796f5160:	81 e7 00 00 00 11    	and    edi,0x11000000
    7130796f5166:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    7130796f516c:	0f 84 b2 f9 ff ff    	je     0x7130796f4b24
    7130796f5172:	48 8b f8             	mov    rdi,rax
    7130796f5175:	33 f6                	xor    esi,esi
    7130796f5177:	ff 15 9b 06 a5 ff    	call   QWORD PTR [rip+0xffffffffffa5069b]        # 0x713079145818
    7130796f517d:	e9 a2 f9 ff ff       	jmp    0x7130796f4b24
    7130796f5182:	49 8b fd             	mov    rdi,r13
    7130796f5185:	48 0f bf b5 58 ff ff 	movsx  rsi,WORD PTR [rbp-0xa8]
    7130796f518c:	ff 
    7130796f518d:	49 bb f0 1c 27 77 30 	movabs r11,0x713077271cf0
    7130796f5194:	71 00 00 
    7130796f5197:	41 ff 13             	call   QWORD PTR [r11]
    7130796f519a:	e9 85 f9 ff ff       	jmp    0x7130796f4b24
    7130796f519f:	48 8b f8             	mov    rdi,rax
    7130796f51a2:	e8 f9 cd cb 7c       	call   0x7130f63b1fa0
    7130796f51a7:	cc                   	int3
    7130796f51a8:	49 8b fe             	mov    rdi,r14
    7130796f51ab:	ff 15 8f 7f 15 00    	call   QWORD PTR [rip+0x157f8f]        # 0x71307984d140
    7130796f51b1:	e9 10 fa ff ff       	jmp    0x7130796f4bc6
    7130796f51b6:	48 8b f8             	mov    rdi,rax
    7130796f51b9:	e8 e2 cd cb 7c       	call   0x7130f63b1fa0
    7130796f51be:	cc                   	int3
    7130796f51bf:	49 8b fe             	mov    rdi,r14
    7130796f51c2:	ff 15 78 7f 15 00    	call   QWORD PTR [rip+0x157f78]        # 0x71307984d140
    7130796f51c8:	e9 5f fa ff ff       	jmp    0x7130796f4c2c
    7130796f51cd:	50                   	push   rax
    7130796f51ce:	48 83 bd a8 fe ff ff 	cmp    QWORD PTR [rbp-0x158],0x0
    7130796f51d5:	00 
    7130796f51d6:	74 14                	je     0x7130796f51ec
    7130796f51d8:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f51df:	49 bb e0 1c 27 77 30 	movabs r11,0x713077271ce0
    7130796f51e6:	71 00 00 
    7130796f51e9:	41 ff 13             	call   QWORD PTR [r11]
    7130796f51ec:	90                   	nop
    7130796f51ed:	48 83 c4 08          	add    rsp,0x8
    7130796f51f1:	c3                   	ret
    7130796f51f2:	50                   	push   rax
    7130796f51f3:	48 8d bd 38 ff ff ff 	lea    rdi,[rbp-0xc8]
    7130796f51fa:	ff 15 f8 ab 15 00    	call   QWORD PTR [rip+0x15abf8]        # 0x71307984fdf8
    7130796f5200:	90                   	nop
    7130796f5201:	48 83 c4 08          	add    rsp,0x8
    7130796f5205:	c3                   	ret
    7130796f5206:	50                   	push   rax
    7130796f5207:	48 83 bd a8 fe ff ff 	cmp    QWORD PTR [rbp-0x158],0x0
    7130796f520e:	00 
    7130796f520f:	74 14                	je     0x7130796f5225
    7130796f5211:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f5218:	49 bb c8 1c 27 77 30 	movabs r11,0x713077271cc8
    7130796f521f:	71 00 00 
    7130796f5222:	41 ff 13             	call   QWORD PTR [r11]
    7130796f5225:	90                   	nop
    7130796f5226:	48 83 c4 08          	add    rsp,0x8
    7130796f522a:	c3                   	ret
    7130796f522b:	50                   	push   rax
    7130796f522c:	48 8d bd 20 ff ff ff 	lea    rdi,[rbp-0xe0]
    7130796f5233:	ff 15 bf ab 15 00    	call   QWORD PTR [rip+0x15abbf]        # 0x71307984fdf8
    7130796f5239:	90                   	nop
    7130796f523a:	48 83 c4 08          	add    rsp,0x8
    7130796f523e:	c3                   	ret
    7130796f523f:	50                   	push   rax
    7130796f5240:	48 83 bd a8 fe ff ff 	cmp    QWORD PTR [rbp-0x158],0x0
    7130796f5247:	00 
    7130796f5248:	74 14                	je     0x7130796f525e
    7130796f524a:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
    7130796f5251:	49 bb b0 1c 27 77 30 	movabs r11,0x713077271cb0
    7130796f5258:	71 00 00 
    7130796f525b:	41 ff 13             	call   QWORD PTR [r11]
    7130796f525e:	90                   	nop
    7130796f525f:	48 83 c4 08          	add    rsp,0x8
    7130796f5263:	c3                   	ret
    7130796f5264:	50                   	push   rax
    7130796f5265:	48 8d bd 08 ff ff ff 	lea    rdi,[rbp-0xf8]
    7130796f526c:	ff 15 86 ab 15 00    	call   QWORD PTR [rip+0x15ab86]        # 0x71307984fdf8
    7130796f5272:	90                   	nop
    7130796f5273:	48 83 c4 08          	add    rsp,0x8
    7130796f5277:	c3                   	ret
    7130796f5278:	50                   	push   rax
    7130796f5279:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    7130796f527d:	ff 15 75 ab 15 00    	call   QWORD PTR [rip+0x15ab75]        # 0x71307984fdf8
    7130796f5283:	90                   	nop
    7130796f5284:	48 83 c4 08          	add    rsp,0x8
    7130796f5288:	c3                   	ret
