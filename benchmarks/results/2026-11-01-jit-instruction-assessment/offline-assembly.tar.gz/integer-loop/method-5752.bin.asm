
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5752.bin:     file format binary


Disassembly of section .data:

00007130796f3e00 <.data>:
    7130796f3e00:	55                   	push   rbp
    7130796f3e01:	41 57                	push   r15
    7130796f3e03:	41 56                	push   r14
    7130796f3e05:	41 55                	push   r13
    7130796f3e07:	41 54                	push   r12
    7130796f3e09:	53                   	push   rbx
    7130796f3e0a:	48 83 ec 38          	sub    rsp,0x38
    7130796f3e0e:	48 8d 6c 24 60       	lea    rbp,[rsp+0x60]
    7130796f3e13:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    7130796f3e18:	c5 7a 7f 45 b8       	vmovdqu XMMWORD PTR [rbp-0x48],xmm8
    7130796f3e1d:	33 c0                	xor    eax,eax
    7130796f3e1f:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
    7130796f3e23:	48 89 7d b0          	mov    QWORD PTR [rbp-0x50],rdi
    7130796f3e27:	48 8b de             	mov    rbx,rsi
    7130796f3e2a:	8b b7 18 01 00 00    	mov    esi,DWORD PTR [rdi+0x118]
    7130796f3e30:	8b 43 10             	mov    eax,DWORD PTR [rbx+0x10]
    7130796f3e33:	8b c8                	mov    ecx,eax
    7130796f3e35:	83 f9 1f             	cmp    ecx,0x1f
    7130796f3e38:	0f 84 fa 05 00 00    	je     0x7130796f4438
    7130796f3e3e:	ba 02 00 00 00       	mov    edx,0x2
    7130796f3e43:	41 b8 01 00 00 00    	mov    r8d,0x1
    7130796f3e49:	83 f9 23             	cmp    ecx,0x23
    7130796f3e4c:	41 0f 44 d0          	cmove  edx,r8d
    7130796f3e50:	2b f2                	sub    esi,edx
    7130796f3e52:	89 75 d4             	mov    DWORD PTR [rbp-0x2c],esi
    7130796f3e55:	83 c0 e2             	add    eax,0xffffffe2
    7130796f3e58:	83 f8 04             	cmp    eax,0x4
    7130796f3e5b:	0f 85 b6 01 00 00    	jne    0x7130796f4017
    7130796f3e61:	8b 43 08             	mov    eax,DWORD PTR [rbx+0x8]
    7130796f3e64:	4c 8b b7 e8 00 00 00 	mov    r14,QWORD PTR [rdi+0xe8]
    7130796f3e6b:	49 8b ce             	mov    rcx,r14
    7130796f3e6e:	44 8b 69 08          	mov    r13d,DWORD PTR [rcx+0x8]
    7130796f3e72:	8b 75 d4             	mov    esi,DWORD PTR [rbp-0x2c]
    7130796f3e75:	41 3b f5             	cmp    esi,r13d
    7130796f3e78:	0f 83 95 05 00 00    	jae    0x7130796f4413
    7130796f3e7e:	8b d6                	mov    edx,esi
    7130796f3e80:	4c 8b 7c d1 10       	mov    r15,QWORD PTR [rcx+rdx*8+0x10]
    7130796f3e85:	4d 85 ff             	test   r15,r15
    7130796f3e88:	0f 84 e4 03 00 00    	je     0x7130796f4272
    7130796f3e8e:	49 8b ce             	mov    rcx,r14
    7130796f3e91:	44 8d 66 01          	lea    r12d,[rsi+0x1]
    7130796f3e95:	45 3b e5             	cmp    r12d,r13d
    7130796f3e98:	0f 83 75 05 00 00    	jae    0x7130796f4413
    7130796f3e9e:	41 8b d4             	mov    edx,r12d
    7130796f3ea1:	4c 8b 74 d1 10       	mov    r14,QWORD PTR [rcx+rdx*8+0x10]
    7130796f3ea6:	4d 85 f6             	test   r14,r14
    7130796f3ea9:	0f 84 f1 03 00 00    	je     0x7130796f42a0
    7130796f3eaf:	4c 8b 6f 70          	mov    r13,QWORD PTR [rdi+0x70]
    7130796f3eb3:	48 8b 1b             	mov    rbx,QWORD PTR [rbx]
    7130796f3eb6:	8b f8                	mov    edi,eax
    7130796f3eb8:	ff 15 3a bc 15 00    	call   QWORD PTR [rip+0x15bc3a]        # 0x71307984faf8
    7130796f3ebe:	8b d0                	mov    edx,eax
    7130796f3ec0:	49 8b f6             	mov    rsi,r14
    7130796f3ec3:	49 8b ff             	mov    rdi,r15
    7130796f3ec6:	49 8b cd             	mov    rcx,r13
    7130796f3ec9:	4c 8b c3             	mov    r8,rbx
    7130796f3ecc:	ff 15 3e bc 15 00    	call   QWORD PTR [rip+0x15bc3e]        # 0x71307984fb10
    7130796f3ed2:	48 8b d8             	mov    rbx,rax
    7130796f3ed5:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f3ed9:	4c 8d bf e8 00 00 00 	lea    r15,[rdi+0xe8]
    7130796f3ee0:	41 8b 77 30          	mov    esi,DWORD PTR [r15+0x30]
    7130796f3ee4:	44 8b f6             	mov    r14d,esi
    7130796f3ee7:	44 2b 75 d4          	sub    r14d,DWORD PTR [rbp-0x2c]
    7130796f3eeb:	41 ff ce             	dec    r14d
    7130796f3eee:	0f 84 d3 00 00 00    	je     0x7130796f3fc7
    7130796f3ef4:	44 8b ee             	mov    r13d,esi
    7130796f3ef7:	45 2b ee             	sub    r13d,r14d
    7130796f3efa:	ff ce                	dec    esi
    7130796f3efc:	44 8b e6             	mov    r12d,esi
    7130796f3eff:	45 3b e5             	cmp    r12d,r13d
    7130796f3f02:	7c 4b                	jl     0x7130796f3f4f
    7130796f3f04:	41 80 7f 34 00       	cmp    BYTE PTR [r15+0x34],0x0
    7130796f3f09:	0f 85 24 04 00 00    	jne    0x7130796f4333
    7130796f3f0f:	49 8b 37             	mov    rsi,QWORD PTR [r15]
    7130796f3f12:	44 3b 66 08          	cmp    r12d,DWORD PTR [rsi+0x8]
    7130796f3f16:	0f 83 f7 04 00 00    	jae    0x7130796f4413
    7130796f3f1c:	4a 8b 74 e6 10       	mov    rsi,QWORD PTR [rsi+r12*8+0x10]
    7130796f3f21:	48 8b c6             	mov    rax,rsi
    7130796f3f24:	48 85 c0             	test   rax,rax
    7130796f3f27:	74 15                	je     0x7130796f3f3e
    7130796f3f29:	48 b9 90 f0 68 79 30 	movabs rcx,0x71307968f090
    7130796f3f30:	71 00 00 
    7130796f3f33:	48 39 08             	cmp    QWORD PTR [rax],rcx
    7130796f3f36:	0f 85 6c 04 00 00    	jne    0x7130796f43a8
    7130796f3f3c:	33 c0                	xor    eax,eax
    7130796f3f3e:	48 85 c0             	test   rax,rax
    7130796f3f41:	0f 85 75 04 00 00    	jne    0x7130796f43bc
    7130796f3f47:	41 ff cc             	dec    r12d
    7130796f3f4a:	45 3b e5             	cmp    r12d,r13d
    7130796f3f4d:	7d b5                	jge    0x7130796f3f04
    7130796f3f4f:	49 8b 37             	mov    rsi,QWORD PTR [r15]
    7130796f3f52:	48 85 f6             	test   rsi,rsi
    7130796f3f55:	0f 84 76 04 00 00    	je     0x7130796f43d1
    7130796f3f5b:	48 8d 46 10          	lea    rax,[rsi+0x10]
    7130796f3f5f:	33 c9                	xor    ecx,ecx
    7130796f3f61:	48 8b 16             	mov    rdx,QWORD PTR [rsi]
    7130796f3f64:	83 7a 04 18          	cmp    DWORD PTR [rdx+0x4],0x18
    7130796f3f68:	0f 85 6f 04 00 00    	jne    0x7130796f43dd
    7130796f3f6e:	45 8b c5             	mov    r8d,r13d
    7130796f3f71:	44 2b c1             	sub    r8d,ecx
    7130796f3f74:	44 3b e9             	cmp    r13d,ecx
    7130796f3f77:	0f 8c 4d 01 00 00    	jl     0x7130796f40ca
    7130796f3f7d:	41 8b c8             	mov    ecx,r8d
    7130796f3f80:	41 0b ce             	or     ecx,r14d
    7130796f3f83:	0f 8c 41 01 00 00    	jl     0x7130796f40ca
    7130796f3f89:	43 8d 0c 30          	lea    ecx,[r8+r14*1]
    7130796f3f8d:	3b 4e 08             	cmp    ecx,DWORD PTR [rsi+0x8]
    7130796f3f90:	0f 87 34 01 00 00    	ja     0x7130796f40ca
    7130796f3f96:	0f b7 32             	movzx  esi,WORD PTR [rdx]
    7130796f3f99:	41 8b c8             	mov    ecx,r8d
    7130796f3f9c:	48 0f af ce          	imul   rcx,rsi
    7130796f3fa0:	48 03 c8             	add    rcx,rax
    7130796f3fa3:	41 8b c6             	mov    eax,r14d
    7130796f3fa6:	48 0f af f0          	imul   rsi,rax
    7130796f3faa:	f7 02 00 00 00 01    	test   DWORD PTR [rdx],0x1000000
    7130796f3fb0:	0f 84 48 04 00 00    	je     0x7130796f43fe
    7130796f3fb6:	48 c1 ee 03          	shr    rsi,0x3
    7130796f3fba:	48 8b f9             	mov    rdi,rcx
    7130796f3fbd:	ff 15 45 3d a5 ff    	call   QWORD PTR [rip+0xffffffffffa53d45]        # 0x713079147d08
    7130796f3fc3:	45 89 6f 30          	mov    DWORD PTR [r15+0x30],r13d
    7130796f3fc7:	49 8b 37             	mov    rsi,QWORD PTR [r15]
    7130796f3fca:	48 63 55 d4          	movsxd rdx,DWORD PTR [rbp-0x2c]
    7130796f3fce:	8b 46 08             	mov    eax,DWORD PTR [rsi+0x8]
    7130796f3fd1:	48 3b c2             	cmp    rax,rdx
    7130796f3fd4:	0f 86 32 04 00 00    	jbe    0x7130796f440c
    7130796f3fda:	48 8d 44 d6 10       	lea    rax,[rsi+rdx*8+0x10]
    7130796f3fdf:	48 8b 16             	mov    rdx,QWORD PTR [rsi]
    7130796f3fe2:	48 8b 52 30          	mov    rdx,QWORD PTR [rdx+0x30]
    7130796f3fe6:	48 85 db             	test   rbx,rbx
    7130796f3fe9:	0f 84 e2 00 00 00    	je     0x7130796f40d1
    7130796f3fef:	48 3b 13             	cmp    rdx,QWORD PTR [rbx]
    7130796f3ff2:	74 13                	je     0x7130796f4007
    7130796f3ff4:	48 b9 a0 27 49 78 30 	movabs rcx,0x7130784927a0
    7130796f3ffb:	71 00 00 
    7130796f3ffe:	48 39 0e             	cmp    QWORD PTR [rsi],rcx
    7130796f4001:	0f 85 12 04 00 00    	jne    0x7130796f4419
    7130796f4007:	48 8b f8             	mov    rdi,rax
    7130796f400a:	48 8b f3             	mov    rsi,rbx
    7130796f400d:	e8 2e c0 b5 fd       	call   0x713077250040
    7130796f4012:	e9 12 04 00 00       	jmp    0x7130796f4429
    7130796f4017:	83 f8 05             	cmp    eax,0x5
    7130796f401a:	0f 87 bb 00 00 00    	ja     0x7130796f40db
    7130796f4020:	8b f0                	mov    esi,eax
    7130796f4022:	48 8d 05 4b 04 00 00 	lea    rax,[rip+0x44b]        # 0x7130796f4474
    7130796f4029:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    7130796f402c:	48 8d 0d f7 fd ff ff 	lea    rcx,[rip+0xfffffffffffffdf7]        # 0x7130796f3e2a
    7130796f4033:	48 03 c1             	add    rax,rcx
    7130796f4036:	ff e0                	jmp    rax
    7130796f4038:	48 83 7f 68 00       	cmp    QWORD PTR [rdi+0x68],0x0
    7130796f403d:	0f 85 c6 00 00 00    	jne    0x7130796f4109
    7130796f4043:	4c 8b b7 e8 00 00 00 	mov    r14,QWORD PTR [rdi+0xe8]
    7130796f404a:	49 8b f6             	mov    rsi,r14
    7130796f404d:	44 8b 6e 08          	mov    r13d,DWORD PTR [rsi+0x8]
    7130796f4051:	8b 45 d4             	mov    eax,DWORD PTR [rbp-0x2c]
    7130796f4054:	41 3b c5             	cmp    eax,r13d
    7130796f4057:	0f 83 b6 03 00 00    	jae    0x7130796f4413
    7130796f405d:	8b c8                	mov    ecx,eax
    7130796f405f:	48 8b 74 ce 10       	mov    rsi,QWORD PTR [rsi+rcx*8+0x10]
    7130796f4064:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f406b:	71 00 00 
    7130796f406e:	ff 15 f4 00 e8 ff    	call   QWORD PTR [rip+0xffffffffffe800f4]        # 0x713079574168
    7130796f4074:	4c 8b f0             	mov    r14,rax
    7130796f4077:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f407b:	48 8b b7 e8 00 00 00 	mov    rsi,QWORD PTR [rdi+0xe8]
    7130796f4082:	8b 45 d4             	mov    eax,DWORD PTR [rbp-0x2c]
    7130796f4085:	44 8d 60 01          	lea    r12d,[rax+0x1]
    7130796f4089:	44 3b 66 08          	cmp    r12d,DWORD PTR [rsi+0x8]
    7130796f408d:	0f 83 80 03 00 00    	jae    0x7130796f4413
    7130796f4093:	41 8b cc             	mov    ecx,r12d
    7130796f4096:	48 8b 74 ce 10       	mov    rsi,QWORD PTR [rsi+rcx*8+0x10]
    7130796f409b:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f40a2:	71 00 00 
    7130796f40a5:	ff 15 bd 00 e8 ff    	call   QWORD PTR [rip+0xffffffffffe800bd]        # 0x713079574168
    7130796f40ab:	48 8b f0             	mov    rsi,rax
    7130796f40ae:	49 8b fe             	mov    rdi,r14
    7130796f40b1:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f40b4:	48 8b 45 b0          	mov    rax,QWORD PTR [rbp-0x50]
    7130796f40b8:	48 8b 48 70          	mov    rcx,QWORD PTR [rax+0x70]
    7130796f40bc:	ff 15 76 b9 15 00    	call   QWORD PTR [rip+0x15b976]        # 0x71307984fa38
    7130796f40c2:	48 8b d8             	mov    rbx,rax
    7130796f40c5:	e9 0b fe ff ff       	jmp    0x7130796f3ed5
    7130796f40ca:	ff 15 b0 0f 49 00    	call   QWORD PTR [rip+0x490fb0]        # 0x713079b85080
    7130796f40d0:	cc                   	int3
    7130796f40d1:	33 c9                	xor    ecx,ecx
    7130796f40d3:	48 89 08             	mov    QWORD PTR [rax],rcx
    7130796f40d6:	e9 4e 03 00 00       	jmp    0x7130796f4429
    7130796f40db:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f40e2:	71 00 00 
    7130796f40e5:	e8 d6 d1 f5 7c       	call   0x7130f66512c0
    7130796f40ea:	48 8b d8             	mov    rbx,rax
    7130796f40ed:	48 8b fb             	mov    rdi,rbx
    7130796f40f0:	48 be 48 49 e1 74 30 	movabs rsi,0x713074e14948
    7130796f40f7:	71 00 00 
    7130796f40fa:	ff 15 d8 1d e8 ff    	call   QWORD PTR [rip+0xffffffffffe81dd8]        # 0x713079575ed8
    7130796f4100:	48 8b fb             	mov    rdi,rbx
    7130796f4103:	e8 98 de cb 7c       	call   0x7130f63b1fa0
    7130796f4108:	cc                   	int3
    7130796f4109:	4c 8b b7 e8 00 00 00 	mov    r14,QWORD PTR [rdi+0xe8]
    7130796f4110:	49 8b f6             	mov    rsi,r14
    7130796f4113:	8b 45 d4             	mov    eax,DWORD PTR [rbp-0x2c]
    7130796f4116:	44 8d 60 01          	lea    r12d,[rax+0x1]
    7130796f411a:	44 8b 6e 08          	mov    r13d,DWORD PTR [rsi+0x8]
    7130796f411e:	45 3b e5             	cmp    r12d,r13d
    7130796f4121:	0f 83 ec 02 00 00    	jae    0x7130796f4413
    7130796f4127:	41 8b cc             	mov    ecx,r12d
    7130796f412a:	48 8b 74 ce 10       	mov    rsi,QWORD PTR [rsi+rcx*8+0x10]
    7130796f412f:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f4136:	71 00 00 
    7130796f4139:	ff 15 29 00 e8 ff    	call   QWORD PTR [rip+0xffffffffffe80029]        # 0x713079574168
    7130796f413f:	48 8b d0             	mov    rdx,rax
    7130796f4142:	48 8b 0b             	mov    rcx,QWORD PTR [rbx]
    7130796f4145:	48 8d 75 b8          	lea    rsi,[rbp-0x48]
    7130796f4149:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f414d:	45 33 c0             	xor    r8d,r8d
    7130796f4150:	ff 15 fa b8 15 00    	call   QWORD PTR [rip+0x15b8fa]        # 0x71307984fa50
    7130796f4156:	48 8b 5d b8          	mov    rbx,QWORD PTR [rbp-0x48]
    7130796f415a:	48 8b 45 c0          	mov    rax,QWORD PTR [rbp-0x40]
    7130796f415e:	4c 0f bf 7d c8       	movsx  r15,WORD PTR [rbp-0x38]
    7130796f4163:	48 85 db             	test   rbx,rbx
    7130796f4166:	75 05                	jne    0x7130796f416d
    7130796f4168:	48 8b d8             	mov    rbx,rax
    7130796f416b:	eb 53                	jmp    0x7130796f41c0
    7130796f416d:	48 8b f3             	mov    rsi,rbx
    7130796f4170:	48 bf 30 f2 ad 79 30 	movabs rdi,0x713079adf230
    7130796f4177:	71 00 00 
    7130796f417a:	e8 a1 85 ff ff       	call   0x7130796ec720
    7130796f417f:	4c 8b f0             	mov    r14,rax
    7130796f4182:	4d 85 f6             	test   r14,r14
    7130796f4185:	74 23                	je     0x7130796f41aa
    7130796f4187:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    7130796f418b:	81 e7 00 00 00 11    	and    edi,0x11000000
    7130796f4191:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    7130796f4197:	74 0b                	je     0x7130796f41a4
    7130796f4199:	49 8b fe             	mov    rdi,r14
    7130796f419c:	33 f6                	xor    esi,esi
    7130796f419e:	ff 15 74 16 a5 ff    	call   QWORD PTR [rip+0xffffffffffa51674]        # 0x713079145818
    7130796f41a4:	49 8b 5e 38          	mov    rbx,QWORD PTR [r14+0x38]
    7130796f41a8:	eb 16                	jmp    0x7130796f41c0
    7130796f41aa:	48 8b fb             	mov    rdi,rbx
    7130796f41ad:	41 8b f7             	mov    esi,r15d
    7130796f41b0:	49 bb 90 1c 27 77 30 	movabs r11,0x713077271c90
    7130796f41b7:	71 00 00 
    7130796f41ba:	41 ff 13             	call   QWORD PTR [r11]
    7130796f41bd:	48 8b d8             	mov    rbx,rax
    7130796f41c0:	e9 00 ff ff ff       	jmp    0x7130796f40c5
    7130796f41c5:	8b 73 08             	mov    esi,DWORD PTR [rbx+0x8]
    7130796f41c8:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f41cb:	48 8b 4f 70          	mov    rcx,QWORD PTR [rdi+0x70]
    7130796f41cf:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    7130796f41d6:	ff 15 8c b8 15 00    	call   QWORD PTR [rip+0x15b88c]        # 0x71307984fa68
    7130796f41dc:	48 8b d8             	mov    rbx,rax
    7130796f41df:	e9 f1 fc ff ff       	jmp    0x7130796f3ed5
    7130796f41e4:	44 8b 7b 08          	mov    r15d,DWORD PTR [rbx+0x8]
    7130796f41e8:	4c 8b b7 e8 00 00 00 	mov    r14,QWORD PTR [rdi+0xe8]
    7130796f41ef:	49 8b f6             	mov    rsi,r14
    7130796f41f2:	44 8b 6e 08          	mov    r13d,DWORD PTR [rsi+0x8]
    7130796f41f6:	8b 45 d4             	mov    eax,DWORD PTR [rbp-0x2c]
    7130796f41f9:	41 3b c5             	cmp    eax,r13d
    7130796f41fc:	0f 83 11 02 00 00    	jae    0x7130796f4413
    7130796f4202:	8b c8                	mov    ecx,eax
    7130796f4204:	48 8b 74 ce 10       	mov    rsi,QWORD PTR [rsi+rcx*8+0x10]
    7130796f4209:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f4210:	71 00 00 
    7130796f4213:	ff 15 4f ff e7 ff    	call   QWORD PTR [rip+0xffffffffffe7ff4f]        # 0x713079574168
    7130796f4219:	4c 8b f0             	mov    r14,rax
    7130796f421c:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f4220:	48 8b b7 e8 00 00 00 	mov    rsi,QWORD PTR [rdi+0xe8]
    7130796f4227:	8b 45 d4             	mov    eax,DWORD PTR [rbp-0x2c]
    7130796f422a:	44 8d 60 01          	lea    r12d,[rax+0x1]
    7130796f422e:	44 3b 66 08          	cmp    r12d,DWORD PTR [rsi+0x8]
    7130796f4232:	0f 83 db 01 00 00    	jae    0x7130796f4413
    7130796f4238:	41 8b cc             	mov    ecx,r12d
    7130796f423b:	48 8b 74 ce 10       	mov    rsi,QWORD PTR [rsi+rcx*8+0x10]
    7130796f4240:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f4247:	71 00 00 
    7130796f424a:	ff 15 18 ff e7 ff    	call   QWORD PTR [rip+0xffffffffffe7ff18]        # 0x713079574168
    7130796f4250:	48 8b d0             	mov    rdx,rax
    7130796f4253:	49 8b f6             	mov    rsi,r14
    7130796f4256:	41 8b ff             	mov    edi,r15d
    7130796f4259:	48 8b 45 b0          	mov    rax,QWORD PTR [rbp-0x50]
    7130796f425d:	48 8b 48 70          	mov    rcx,QWORD PTR [rax+0x70]
    7130796f4261:	4c 8b 03             	mov    r8,QWORD PTR [rbx]
    7130796f4264:	ff 15 16 b8 15 00    	call   QWORD PTR [rip+0x15b816]        # 0x71307984fa80
    7130796f426a:	48 8b d8             	mov    rbx,rax
    7130796f426d:	e9 63 fc ff ff       	jmp    0x7130796f3ed5
    7130796f4272:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f4279:	71 00 00 
    7130796f427c:	e8 3f d0 f5 7c       	call   0x7130f66512c0
    7130796f4281:	48 8b d8             	mov    rbx,rax
    7130796f4284:	48 8b fb             	mov    rdi,rbx
    7130796f4287:	48 be 18 d2 e0 74 30 	movabs rsi,0x713074e0d218
    7130796f428e:	71 00 00 
    7130796f4291:	ff 15 41 1c e8 ff    	call   QWORD PTR [rip+0xffffffffffe81c41]        # 0x713079575ed8
    7130796f4297:	48 8b fb             	mov    rdi,rbx
    7130796f429a:	e8 01 dd cb 7c       	call   0x7130f63b1fa0
    7130796f429f:	cc                   	int3
    7130796f42a0:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f42a7:	71 00 00 
    7130796f42aa:	e8 11 d0 f5 7c       	call   0x7130f66512c0
    7130796f42af:	4c 8b e0             	mov    r12,rax
    7130796f42b2:	49 8b fc             	mov    rdi,r12
    7130796f42b5:	48 be 18 d2 e0 74 30 	movabs rsi,0x713074e0d218
    7130796f42bc:	71 00 00 
    7130796f42bf:	ff 15 13 1c e8 ff    	call   QWORD PTR [rip+0xffffffffffe81c13]        # 0x713079575ed8
    7130796f42c5:	49 8b fc             	mov    rdi,r12
    7130796f42c8:	e8 d3 dc cb 7c       	call   0x7130f63b1fa0
    7130796f42cd:	cc                   	int3
    7130796f42ce:	44 8b 7b 08          	mov    r15d,DWORD PTR [rbx+0x8]
    7130796f42d2:	4c 8b b7 e8 00 00 00 	mov    r14,QWORD PTR [rdi+0xe8]
    7130796f42d9:	45 8b 6e 08          	mov    r13d,DWORD PTR [r14+0x8]
    7130796f42dd:	8b 75 d4             	mov    esi,DWORD PTR [rbp-0x2c]
    7130796f42e0:	41 3b f5             	cmp    esi,r13d
    7130796f42e3:	0f 83 2a 01 00 00    	jae    0x7130796f4413
    7130796f42e9:	8b c6                	mov    eax,esi
    7130796f42eb:	49 8b 44 c6 10       	mov    rax,QWORD PTR [r14+rax*8+0x10]
    7130796f42f0:	48 8b f0             	mov    rsi,rax
    7130796f42f3:	48 bf e8 82 ad 79 30 	movabs rdi,0x713079ad82e8
    7130796f42fa:	71 00 00 
    7130796f42fd:	ff 15 65 fe e7 ff    	call   QWORD PTR [rip+0xffffffffffe7fe65]        # 0x713079574168
    7130796f4303:	4c 8b e8             	mov    r13,rax
    7130796f4306:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f430a:	4c 8b 77 70          	mov    r14,QWORD PTR [rdi+0x70]
    7130796f430e:	48 8b 1b             	mov    rbx,QWORD PTR [rbx]
    7130796f4311:	41 8b ff             	mov    edi,r15d
    7130796f4314:	ff 15 5e 18 49 00    	call   QWORD PTR [rip+0x49185e]        # 0x713079b85b78
    7130796f431a:	8b f8                	mov    edi,eax
    7130796f431c:	49 8b f5             	mov    rsi,r13
    7130796f431f:	49 8b d6             	mov    rdx,r14
    7130796f4322:	48 8b cb             	mov    rcx,rbx
    7130796f4325:	ff 15 65 18 49 00    	call   QWORD PTR [rip+0x491865]        # 0x713079b85b90
    7130796f432b:	48 8b d8             	mov    rbx,rax
    7130796f432e:	e9 a2 fb ff ff       	jmp    0x7130796f3ed5
    7130796f4333:	49 8b 37             	mov    rsi,QWORD PTR [r15]
    7130796f4336:	44 3b 66 08          	cmp    r12d,DWORD PTR [rsi+0x8]
    7130796f433a:	0f 83 d3 00 00 00    	jae    0x7130796f4413
    7130796f4340:	4a 8b 74 e6 10       	mov    rsi,QWORD PTR [rsi+r12*8+0x10]
    7130796f4345:	48 bf 58 56 ad 79 30 	movabs rdi,0x713079ad5658
    7130796f434c:	71 00 00 
    7130796f434f:	e8 cc 83 ff ff       	call   0x7130796ec720
    7130796f4354:	48 89 45 a8          	mov    QWORD PTR [rbp-0x58],rax
    7130796f4358:	48 85 c0             	test   rax,rax
    7130796f435b:	0f 84 ae fb ff ff    	je     0x7130796f3f0f
    7130796f4361:	49 83 7f 20 00       	cmp    QWORD PTR [r15+0x20],0x0
    7130796f4366:	75 0e                	jne    0x7130796f4376
    7130796f4368:	49 8d 7f 18          	lea    rdi,[r15+0x18]
    7130796f436c:	48 8b f0             	mov    rsi,rax
    7130796f436f:	e8 cc bc b5 fd       	call   0x713077250040
    7130796f4374:	eb 10                	jmp    0x7130796f4386
    7130796f4376:	49 8b 7f 20          	mov    rdi,QWORD PTR [r15+0x20]
    7130796f437a:	48 8d 7f 40          	lea    rdi,[rdi+0x40]
    7130796f437e:	48 8b f0             	mov    rsi,rax
    7130796f4381:	e8 ba bc b5 fd       	call   0x713077250040
    7130796f4386:	49 8d 7f 20          	lea    rdi,[r15+0x20]
    7130796f438a:	48 8b 75 a8          	mov    rsi,QWORD PTR [rbp-0x58]
    7130796f438e:	e8 ad bc b5 fd       	call   0x713077250040
    7130796f4393:	49 8b 37             	mov    rsi,QWORD PTR [r15]
    7130796f4396:	44 3b 66 08          	cmp    r12d,DWORD PTR [rsi+0x8]
    7130796f439a:	73 77                	jae    0x7130796f4413
    7130796f439c:	33 ff                	xor    edi,edi
    7130796f439e:	4a 89 7c e6 10       	mov    QWORD PTR [rsi+r12*8+0x10],rdi
    7130796f43a3:	e9 9f fb ff ff       	jmp    0x7130796f3f47
    7130796f43a8:	48 bf 70 51 ad 79 30 	movabs rdi,0x713079ad5170
    7130796f43af:	71 00 00 
    7130796f43b2:	e8 e9 af ff ff       	call   0x7130796ef3a0
    7130796f43b7:	e9 82 fb ff ff       	jmp    0x7130796f3f3e
    7130796f43bc:	48 8b f8             	mov    rdi,rax
    7130796f43bf:	49 bb 98 1c 27 77 30 	movabs r11,0x713077271c98
    7130796f43c6:	71 00 00 
    7130796f43c9:	41 ff 13             	call   QWORD PTR [r11]
    7130796f43cc:	e9 76 fb ff ff       	jmp    0x7130796f3f47
    7130796f43d1:	bf 02 00 00 00       	mov    edi,0x2
    7130796f43d6:	ff 15 cc 08 ef ff    	call   QWORD PTR [rip+0xffffffffffef08cc]        # 0x7130795e4ca8
    7130796f43dc:	cc                   	int3
    7130796f43dd:	44 8b 42 04          	mov    r8d,DWORD PTR [rdx+0x4]
    7130796f43e1:	41 83 c0 e8          	add    r8d,0xffffffe8
    7130796f43e5:	41 c1 e8 03          	shr    r8d,0x3
    7130796f43e9:	49 63 c8             	movsxd rcx,r8d
    7130796f43ec:	8b 0c 88             	mov    ecx,DWORD PTR [rax+rcx*4]
    7130796f43ef:	41 c1 e0 03          	shl    r8d,0x3
    7130796f43f3:	4d 63 c0             	movsxd r8,r8d
    7130796f43f6:	49 03 c0             	add    rax,r8
    7130796f43f9:	e9 70 fb ff ff       	jmp    0x7130796f3f6e
    7130796f43fe:	48 8b f9             	mov    rdi,rcx
    7130796f4401:	ff 15 29 af d9 fe    	call   QWORD PTR [rip+0xfffffffffed9af29]        # 0x71307848f330
    7130796f4407:	e9 b7 fb ff ff       	jmp    0x7130796f3fc3
    7130796f440c:	ff 15 1e 05 49 00    	call   QWORD PTR [rip+0x49051e]        # 0x713079b84930
    7130796f4412:	cc                   	int3
    7130796f4413:	e8 f0 d1 d8 fe       	call   0x713078481608
    7130796f4418:	cc                   	int3
    7130796f4419:	48 8b f8             	mov    rdi,rax
    7130796f441c:	48 8b f2             	mov    rsi,rdx
    7130796f441f:	48 8b d3             	mov    rdx,rbx
    7130796f4422:	ff 15 90 ba 2a ff    	call   QWORD PTR [rip+0xffffffffff2aba90]        # 0x71307899feb8
    7130796f4428:	90                   	nop
    7130796f4429:	48 83 c4 38          	add    rsp,0x38
    7130796f442d:	5b                   	pop    rbx
    7130796f442e:	41 5c                	pop    r12
    7130796f4430:	41 5d                	pop    r13
    7130796f4432:	41 5e                	pop    r14
    7130796f4434:	41 5f                	pop    r15
    7130796f4436:	5d                   	pop    rbp
    7130796f4437:	c3                   	ret
    7130796f4438:	33 d2                	xor    edx,edx
    7130796f443a:	f3 0f b8 53 08       	popcnt edx,DWORD PTR [rbx+0x8]
    7130796f443f:	ff c2                	inc    edx
    7130796f4441:	e9 0a fa ff ff       	jmp    0x7130796f3e50
    7130796f4446:	50                   	push   rax
    7130796f4447:	48 8b 7d b0          	mov    rdi,QWORD PTR [rbp-0x50]
    7130796f444b:	48 8d 9f e8 00 00 00 	lea    rbx,[rdi+0xe8]
    7130796f4452:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    7130796f4459:	ff 15 59 93 15 00    	call   QWORD PTR [rip+0x159359]        # 0x71307984d7b8
    7130796f445f:	8b f0                	mov    esi,eax
    7130796f4461:	2b 75 d4             	sub    esi,DWORD PTR [rbp-0x2c]
    7130796f4464:	48 8b fb             	mov    rdi,rbx
    7130796f4467:	ff 15 33 96 15 00    	call   QWORD PTR [rip+0x159633]        # 0x71307984daa0
    7130796f446d:	e8 ee db cb 7c       	call   0x7130f63b2060
    7130796f4472:	cc                   	int3
