
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5691.bin:     file format binary


Disassembly of section .data:

00007130796ef7b0 <.data>:
    7130796ef7b0:	55                   	push   rbp
    7130796ef7b1:	41 57                	push   r15
    7130796ef7b3:	41 56                	push   r14
    7130796ef7b5:	41 55                	push   r13
    7130796ef7b7:	41 54                	push   r12
    7130796ef7b9:	53                   	push   rbx
    7130796ef7ba:	48 83 ec 18          	sub    rsp,0x18
    7130796ef7be:	48 8d 6c 24 40       	lea    rbp,[rsp+0x40]
    7130796ef7c3:	8b de                	mov    ebx,esi
    7130796ef7c5:	48 8b f2             	mov    rsi,rdx
    7130796ef7c8:	4c 8b 7f 08          	mov    r15,QWORD PTR [rdi+0x8]
    7130796ef7cc:	4c 8b 77 10          	mov    r14,QWORD PTR [rdi+0x10]
    7130796ef7d0:	4c 8b 6f 18          	mov    r13,QWORD PTR [rdi+0x18]
    7130796ef7d4:	4c 8b 67 70          	mov    r12,QWORD PTR [rdi+0x70]
    7130796ef7d8:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    7130796ef7df:	8b 47 30             	mov    eax,DWORD PTR [rdi+0x30]
    7130796ef7e2:	85 c0                	test   eax,eax
    7130796ef7e4:	0f 84 00 01 00 00    	je     0x7130796ef8ea
    7130796ef7ea:	ff c8                	dec    eax
    7130796ef7ec:	48 8b 0f             	mov    rcx,QWORD PTR [rdi]
    7130796ef7ef:	48 8b d1             	mov    rdx,rcx
    7130796ef7f2:	8b 72 08             	mov    esi,DWORD PTR [rdx+0x8]
    7130796ef7f5:	3b c6                	cmp    eax,esi
    7130796ef7f7:	0f 83 c5 01 00 00    	jae    0x7130796ef9c2
    7130796ef7fd:	8b f0                	mov    esi,eax
    7130796ef7ff:	48 8b 54 f2 10       	mov    rdx,QWORD PTR [rdx+rsi*8+0x10]
    7130796ef804:	48 89 55 c8          	mov    QWORD PTR [rbp-0x38],rdx
    7130796ef808:	48 85 d2             	test   rdx,rdx
    7130796ef80b:	0f 84 f2 00 00 00    	je     0x7130796ef903
    7130796ef811:	8b f0                	mov    esi,eax
    7130796ef813:	45 33 c0             	xor    r8d,r8d
    7130796ef816:	4c 89 44 f1 10       	mov    QWORD PTR [rcx+rsi*8+0x10],r8
    7130796ef81b:	89 47 30             	mov    DWORD PTR [rdi+0x30],eax
    7130796ef81e:	49 8b 7f 20          	mov    rdi,QWORD PTR [r15+0x20]
    7130796ef822:	48 b8 c0 be 56 78 30 	movabs rax,0x71307856bec0
    7130796ef829:	71 00 00 
    7130796ef82c:	48 39 07             	cmp    QWORD PTR [rdi],rax
    7130796ef82f:	0f 85 03 01 00 00    	jne    0x7130796ef938
    7130796ef835:	8b 47 08             	mov    eax,DWORD PTR [rdi+0x8]
    7130796ef838:	3b c3                	cmp    eax,ebx
    7130796ef83a:	0f 86 f1 00 00 00    	jbe    0x7130796ef931
    7130796ef840:	8b c3                	mov    eax,ebx
    7130796ef842:	48 8b 44 c7 10       	mov    rax,QWORD PTR [rdi+rax*8+0x10]
    7130796ef847:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    7130796ef84b:	66 83 78 0c 3c       	cmp    WORD PTR [rax+0xc],0x3c
    7130796ef850:	0f 95 c1             	setne  cl
    7130796ef853:	0f b6 c9             	movzx  ecx,cl
    7130796ef856:	89 4d d4             	mov    DWORD PTR [rbp-0x2c],ecx
    7130796ef859:	49 83 7c 24 20 00    	cmp    QWORD PTR [r12+0x20],0x0
    7130796ef85f:	40 0f 95 c7          	setne  dil
    7130796ef863:	40 0f b6 ff          	movzx  edi,dil
    7130796ef867:	85 f9                	test   ecx,edi
    7130796ef869:	0f 85 dd 00 00 00    	jne    0x7130796ef94c
    7130796ef86f:	48 63 fb             	movsxd rdi,ebx
    7130796ef872:	41 8b 76 08          	mov    esi,DWORD PTR [r14+0x8]
    7130796ef876:	48 3b f7             	cmp    rsi,rdi
    7130796ef879:	0f 86 e6 00 00 00    	jbe    0x7130796ef965
    7130796ef87f:	49 8d 7c fe 10       	lea    rdi,[r14+rdi*8+0x10]
    7130796ef884:	49 8b 36             	mov    rsi,QWORD PTR [r14]
    7130796ef887:	48 8b 76 30          	mov    rsi,QWORD PTR [rsi+0x30]
    7130796ef88b:	48 8b 55 c8          	mov    rdx,QWORD PTR [rbp-0x38]
    7130796ef88f:	48 3b 32             	cmp    rsi,QWORD PTR [rdx]
    7130796ef892:	74 13                	je     0x7130796ef8a7
    7130796ef894:	49 b8 a0 27 49 78 30 	movabs r8,0x7130784927a0
    7130796ef89b:	71 00 00 
    7130796ef89e:	4d 39 06             	cmp    QWORD PTR [r14],r8
    7130796ef8a1:	0f 85 c5 00 00 00    	jne    0x7130796ef96c
    7130796ef8a7:	48 8b f2             	mov    rsi,rdx
    7130796ef8aa:	e8 91 07 b6 fd       	call   0x713077250040
    7130796ef8af:	4d 85 ed             	test   r13,r13
    7130796ef8b2:	0f 85 bf 00 00 00    	jne    0x7130796ef977
    7130796ef8b8:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    7130796ef8bc:	74 1d                	je     0x7130796ef8db
    7130796ef8be:	41 80 bf 94 00 00 00 	cmp    BYTE PTR [r15+0x94],0x0
    7130796ef8c5:	00 
    7130796ef8c6:	0f 85 d0 00 00 00    	jne    0x7130796ef99c
    7130796ef8cc:	41 80 bc 24 99 00 00 	cmp    BYTE PTR [r12+0x99],0x0
    7130796ef8d3:	00 00 
    7130796ef8d5:	0f 85 c1 00 00 00    	jne    0x7130796ef99c
    7130796ef8db:	48 83 c4 18          	add    rsp,0x18
    7130796ef8df:	5b                   	pop    rbx
    7130796ef8e0:	41 5c                	pop    r12
    7130796ef8e2:	41 5d                	pop    r13
    7130796ef8e4:	41 5e                	pop    r14
    7130796ef8e6:	41 5f                	pop    r15
    7130796ef8e8:	5d                   	pop    rbp
    7130796ef8e9:	c3                   	ret
    7130796ef8ea:	48 bf 68 44 e1 74 30 	movabs rdi,0x713074e14468
    7130796ef8f1:	71 00 00 
    7130796ef8f4:	ff 15 7e e5 15 00    	call   QWORD PTR [rip+0x15e57e]        # 0x71307984de78
    7130796ef8fa:	48 8b f8             	mov    rdi,rax
    7130796ef8fd:	e8 9e 26 cc 7c       	call   0x7130f63b1fa0
    7130796ef902:	cc                   	int3
    7130796ef903:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796ef90a:	71 00 00 
    7130796ef90d:	e8 ae 19 f6 7c       	call   0x7130f66512c0
    7130796ef912:	48 8b d8             	mov    rbx,rax
    7130796ef915:	48 8b fb             	mov    rdi,rbx
    7130796ef918:	48 be 18 d2 e0 74 30 	movabs rsi,0x713074e0d218
    7130796ef91f:	71 00 00 
    7130796ef922:	ff 15 b0 65 e8 ff    	call   QWORD PTR [rip+0xffffffffffe865b0]        # 0x713079575ed8
    7130796ef928:	48 8b fb             	mov    rdi,rbx
    7130796ef92b:	e8 70 26 cc 7c       	call   0x7130f63b1fa0
    7130796ef930:	cc                   	int3
    7130796ef931:	ff 15 c1 fb db ff    	call   QWORD PTR [rip+0xffffffffffdbfbc1]        # 0x7130794af4f8
    7130796ef937:	cc                   	int3
    7130796ef938:	8b f3                	mov    esi,ebx
    7130796ef93a:	49 bb 18 1c 27 77 30 	movabs r11,0x713077271c18
    7130796ef941:	71 00 00 
    7130796ef944:	41 ff 13             	call   QWORD PTR [r11]
    7130796ef947:	e9 fb fe ff ff       	jmp    0x7130796ef847
    7130796ef94c:	48 8b 45 c0          	mov    rax,QWORD PTR [rbp-0x40]
    7130796ef950:	49 8b fc             	mov    rdi,r12
    7130796ef953:	48 8b f0             	mov    rsi,rax
    7130796ef956:	48 8b 55 c8          	mov    rdx,QWORD PTR [rbp-0x38]
    7130796ef95a:	ff 15 d0 d5 15 00    	call   QWORD PTR [rip+0x15d5d0]        # 0x71307984cf30
    7130796ef960:	e9 76 ff ff ff       	jmp    0x7130796ef8db
    7130796ef965:	ff 15 c5 4f 49 00    	call   QWORD PTR [rip+0x494fc5]        # 0x713079b84930
    7130796ef96b:	cc                   	int3
    7130796ef96c:	ff 15 46 05 2b ff    	call   QWORD PTR [rip+0xffffffffff2b0546]        # 0x71307899feb8
    7130796ef972:	e9 38 ff ff ff       	jmp    0x7130796ef8af
    7130796ef977:	41 3b 5d 08          	cmp    ebx,DWORD PTR [r13+0x8]
    7130796ef97b:	73 45                	jae    0x7130796ef9c2
    7130796ef97d:	8b fb                	mov    edi,ebx
    7130796ef97f:	49 8b 7c fd 10       	mov    rdi,QWORD PTR [r13+rdi*8+0x10]
    7130796ef984:	48 85 ff             	test   rdi,rdi
    7130796ef987:	0f 84 2b ff ff ff    	je     0x7130796ef8b8
    7130796ef98d:	48 8b 75 c8          	mov    rsi,QWORD PTR [rbp-0x38]
    7130796ef991:	ff 15 11 d9 15 00    	call   QWORD PTR [rip+0x15d911]        # 0x71307984d2a8
    7130796ef997:	e9 1c ff ff ff       	jmp    0x7130796ef8b8
    7130796ef99c:	49 8b fc             	mov    rdi,r12
    7130796ef99f:	ff 15 b3 7b 15 00    	call   QWORD PTR [rip+0x157bb3]        # 0x713079847558
    7130796ef9a5:	38 00                	cmp    BYTE PTR [rax],al
    7130796ef9a7:	48 8b f8             	mov    rdi,rax
    7130796ef9aa:	48 8b 75 c0          	mov    rsi,QWORD PTR [rbp-0x40]
    7130796ef9ae:	48 8b 55 c8          	mov    rdx,QWORD PTR [rbp-0x38]
    7130796ef9b2:	b9 01 00 00 00       	mov    ecx,0x1
    7130796ef9b7:	ff 15 0b 6c d9 fe    	call   QWORD PTR [rip+0xfffffffffed96c0b]        # 0x7130784865c8
    7130796ef9bd:	e9 19 ff ff ff       	jmp    0x7130796ef8db
    7130796ef9c2:	e8 41 1c d9 fe       	call   0x713078481608
    7130796ef9c7:	cc                   	int3
