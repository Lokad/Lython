
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-7283.bin:     file format binary


Disassembly of section .data:

0000713079c8f960 <.data>:
    713079c8f960:	55                   	push   rbp
    713079c8f961:	41 57                	push   r15
    713079c8f963:	41 56                	push   r14
    713079c8f965:	41 55                	push   r13
    713079c8f967:	41 54                	push   r12
    713079c8f969:	53                   	push   rbx
    713079c8f96a:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    713079c8f971:	48 8d ac 24 20 01 00 	lea    rbp,[rsp+0x120]
    713079c8f978:	00 
    713079c8f979:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    713079c8f97e:	62 71 7e 48 7f 85 30 	vmovdqu32 ZMMWORD PTR [rbp-0xd0],zmm8
    713079c8f985:	ff ff ff 
    713079c8f988:	62 71 7e 48 7f 85 70 	vmovdqu32 ZMMWORD PTR [rbp-0x90],zmm8
    713079c8f98f:	ff ff ff 
    713079c8f992:	c5 7e 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm8
    713079c8f997:	48 89 bd 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rdi
    713079c8f99e:	ff 15 fc dd bb ff    	call   QWORD PTR [rip+0xffffffffffbbddfc]        # 0x71307984d7a0
    713079c8f9a4:	e9 bf 00 00 00       	jmp    0x713079c8fa68
    713079c8f9a9:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    713079c8f9ad:	0f 85 88 00 00 00    	jne    0x713079c8fa3b
    713079c8f9b3:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c8f9ba:	8b 83 dc 00 00 00    	mov    eax,DWORD PTR [rbx+0xdc]
    713079c8f9c0:	ff c0                	inc    eax
    713079c8f9c2:	89 83 dc 00 00 00    	mov    DWORD PTR [rbx+0xdc],eax
    713079c8f9c8:	48 8b 8d 20 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe0]
    713079c8f9cf:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    713079c8f9d2:	3b c8                	cmp    ecx,eax
    713079c8f9d4:	7e 74                	jle    0x713079c8fa4a
    713079c8f9d6:	48 8b fb             	mov    rdi,rbx
    713079c8f9d9:	8b d9                	mov    ebx,ecx
    713079c8f9db:	8b 87 dc 00 00 00    	mov    eax,DWORD PTR [rdi+0xdc]
    713079c8f9e1:	3b c3                	cmp    eax,ebx
    713079c8f9e3:	0f 83 ce 0b 00 00    	jae    0x713079c905b7
    713079c8f9e9:	48 8b 8d 20 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe0]
    713079c8f9f0:	48 8d 04 40          	lea    rax,[rax+rax*2]
    713079c8f9f4:	48 8d 44 c1 10       	lea    rax,[rcx+rax*8+0x10]
    713079c8f9f9:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
    713079c8fa00:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    713079c8fa04:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    713079c8fa08:	48 8b 8d 18 ff ff ff 	mov    rcx,QWORD PTR [rbp-0xe8]
    713079c8fa0f:	48 8b 09             	mov    rcx,QWORD PTR [rcx]
    713079c8fa12:	48 8b 90 80 00 00 00 	mov    rdx,QWORD PTR [rax+0x80]
    713079c8fa19:	48 8b 52 18          	mov    rdx,QWORD PTR [rdx+0x18]
    713079c8fa1d:	48 85 d2             	test   rdx,rdx
    713079c8fa20:	0f 85 88 0b 00 00    	jne    0x713079c905ae
    713079c8fa26:	48 8b 80 68 01 00 00 	mov    rax,QWORD PTR [rax+0x168]
    713079c8fa2d:	48 85 c0             	test   rax,rax
    713079c8fa30:	0f 84 e5 00 00 00    	je     0x713079c8fb1b
    713079c8fa36:	e9 51 0b 00 00       	jmp    0x713079c9058c
    713079c8fa3b:	33 c0                	xor    eax,eax
    713079c8fa3d:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c8fa44:	89 83 dc 00 00 00    	mov    DWORD PTR [rbx+0xdc],eax
    713079c8fa4a:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c8fa51:	80 bb e2 00 00 00 00 	cmp    BYTE PTR [rbx+0xe2],0x0
    713079c8fa58:	0f 85 5f 0b 00 00    	jne    0x713079c905bd
    713079c8fa5e:	83 7d d4 00          	cmp    DWORD PTR [rbp-0x2c],0x0
    713079c8fa62:	0f 84 55 0b 00 00    	je     0x713079c905bd
    713079c8fa68:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fa6f:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    713079c8fa73:	48 8b 76 50          	mov    rsi,QWORD PTR [rsi+0x50]
    713079c8fa77:	44 8b 9f d8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xd8]
    713079c8fa7e:	48 b8 48 bc 82 79 30 	movabs rax,0x71307982bc48
    713079c8fa85:	71 00 00 
    713079c8fa88:	48 39 06             	cmp    QWORD PTR [rsi],rax
    713079c8fa8b:	0f 85 e0 0a 00 00    	jne    0x713079c90571
    713079c8fa91:	44 3b 5e 10          	cmp    r11d,DWORD PTR [rsi+0x10]
    713079c8fa95:	0f 83 0c 0b 00 00    	jae    0x713079c905a7
    713079c8fa9b:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    713079c8fa9f:	44 3b 5e 08          	cmp    r11d,DWORD PTR [rsi+0x8]
    713079c8faa3:	0f 83 0e 0b 00 00    	jae    0x713079c905b7
    713079c8faa9:	4a 8b 5c de 10       	mov    rbx,QWORD PTR [rsi+r11*8+0x10]
    713079c8faae:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fab5:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    713079c8fabc:	83 78 08 00          	cmp    DWORD PTR [rax+0x8],0x0
    713079c8fac0:	75 2b                	jne    0x713079c8faed
    713079c8fac2:	33 c0                	xor    eax,eax
    713079c8fac4:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    713079c8fac7:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    713079c8facb:	48 89 85 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rax
    713079c8fad2:	48 8b 85 20 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe0]
    713079c8fad9:	8b 58 08             	mov    ebx,DWORD PTR [rax+0x8]
    713079c8fadc:	39 9f dc 00 00 00    	cmp    DWORD PTR [rdi+0xdc],ebx
    713079c8fae2:	0f 8d 62 ff ff ff    	jge    0x713079c8fa4a
    713079c8fae8:	e9 ee fe ff ff       	jmp    0x713079c8f9db
    713079c8faed:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    713079c8faf4:	8b 8f d8 00 00 00    	mov    ecx,DWORD PTR [rdi+0xd8]
    713079c8fafa:	3b 48 08             	cmp    ecx,DWORD PTR [rax+0x8]
    713079c8fafd:	0f 83 b4 0a 00 00    	jae    0x713079c905b7
    713079c8fb03:	48 8d 44 c8 10       	lea    rax,[rax+rcx*8+0x10]
    713079c8fb08:	80 38 00             	cmp    BYTE PTR [rax],0x0
    713079c8fb0b:	75 b5                	jne    0x713079c8fac2
    713079c8fb0d:	8b 8f 18 01 00 00    	mov    ecx,DWORD PTR [rdi+0x118]
    713079c8fb13:	c6 00 01             	mov    BYTE PTR [rax],0x1
    713079c8fb16:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    713079c8fb19:	eb a7                	jmp    0x713079c8fac2
    713079c8fb1b:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fb22:	48 83 bf 88 00 00 00 	cmp    QWORD PTR [rdi+0x88],0x0
    713079c8fb29:	00 
    713079c8fb2a:	75 7b                	jne    0x713079c8fba7
    713079c8fb2c:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fb33:	8b 5e 10             	mov    ebx,DWORD PTR [rsi+0x10]
    713079c8fb36:	83 fb 2f             	cmp    ebx,0x2f
    713079c8fb39:	0f 87 4e 05 00 00    	ja     0x713079c9008d
    713079c8fb3f:	8b f3                	mov    esi,ebx
    713079c8fb41:	48 8d 05 f8 0c 00 00 	lea    rax,[rip+0xcf8]        # 0x713079c90840
    713079c8fb48:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    713079c8fb4b:	48 8d 0d 4c fe ff ff 	lea    rcx,[rip+0xfffffffffffffe4c]        # 0x713079c8f99e
    713079c8fb52:	48 03 c1             	add    rax,rcx
    713079c8fb55:	ff e0                	jmp    rax
    713079c8fb57:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fb5e:	ff 15 ac de bb ff    	call   QWORD PTR [rip+0xffffffffffbbdeac]        # 0x71307984da10
    713079c8fb64:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    713079c8fb67:	e9 3d fe ff ff       	jmp    0x713079c8f9a9
    713079c8fb6c:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
    713079c8fb73:	48 8d 3c 24          	lea    rdi,[rsp]
    713079c8fb77:	48 8b f0             	mov    rsi,rax
    713079c8fb7a:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    713079c8fb7d:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    713079c8fb81:	48 83 c6 08          	add    rsi,0x8
    713079c8fb85:	48 83 c7 08          	add    rdi,0x8
    713079c8fb89:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c8fb8b:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c8fb8d:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fb94:	ff 15 5e de bb ff    	call   QWORD PTR [rip+0xffffffffffbbde5e]        # 0x71307984d9f8
    713079c8fb9a:	85 c0                	test   eax,eax
    713079c8fb9c:	0f 84 f7 05 00 00    	je     0x713079c90199
    713079c8fba2:	e9 16 0a 00 00       	jmp    0x713079c905bd
    713079c8fba7:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    713079c8fbae:	00 
    713079c8fbaf:	0f 85 77 ff ff ff    	jne    0x713079c8fb2c
    713079c8fbb5:	e9 c2 06 00 00       	jmp    0x713079c9027c
    713079c8fbba:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    713079c8fbc1:	00 
    713079c8fbc2:	0f 85 dc 00 00 00    	jne    0x713079c8fca4
    713079c8fbc8:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fbcf:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c8fbd2:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    713079c8fbd9:	ff 15 e1 dc bb ff    	call   QWORD PTR [rip+0xffffffffffbbdce1]        # 0x71307984d8c0
    713079c8fbdf:	48 8b d8             	mov    rbx,rax
    713079c8fbe2:	48 bf a0 27 49 78 30 	movabs rdi,0x7130784927a0
    713079c8fbe9:	71 00 00 
    713079c8fbec:	be 01 00 00 00       	mov    esi,0x1
    713079c8fbf1:	e8 5a 18 9c 7c       	call   0x7130f6651450
    713079c8fbf6:	4c 8b f8             	mov    r15,rax
    713079c8fbf9:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    713079c8fbfd:	48 8b f3             	mov    rsi,rbx
    713079c8fc00:	e8 3b 04 5c fd       	call   0x713077250040
    713079c8fc05:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fc0c:	48 8b 57 70          	mov    rdx,QWORD PTR [rdi+0x70]
    713079c8fc10:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fc17:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c8fc1a:	49 8b ff             	mov    rdi,r15
    713079c8fc1d:	ff 15 75 7b bb ff    	call   QWORD PTR [rip+0xffffffffffbb7b75]        # 0x713079847798
    713079c8fc23:	48 8b d8             	mov    rbx,rax
    713079c8fc26:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fc2d:	4c 8b 7f 70          	mov    r15,QWORD PTR [rdi+0x70]
    713079c8fc31:	48 bf a0 6f ad 79 30 	movabs rdi,0x713079ad6fa0
    713079c8fc38:	71 00 00 
    713079c8fc3b:	e8 80 16 9c 7c       	call   0x7130f66512c0
    713079c8fc40:	4c 8b f0             	mov    r14,rax
    713079c8fc43:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c8fc4a:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    713079c8fc4d:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    713079c8fc51:	48 8b f3             	mov    rsi,rbx
    713079c8fc54:	e8 e7 03 5c fd       	call   0x713077250040
    713079c8fc59:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    713079c8fc5d:	49 8b f7             	mov    rsi,r15
    713079c8fc60:	e8 db 03 5c fd       	call   0x713077250040
    713079c8fc65:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    713079c8fc69:	49 8b f5             	mov    rsi,r13
    713079c8fc6c:	e8 cf 03 5c fd       	call   0x713077250040
    713079c8fc71:	48 bf b8 16 80 99 28 	movabs rdi,0x7128998016b8
    713079c8fc78:	71 00 00 
    713079c8fc7b:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c8fc7e:	49 8d 7e 20          	lea    rdi,[r14+0x20]
    713079c8fc82:	e8 b9 03 5c fd       	call   0x713077250040
    713079c8fc87:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fc8e:	48 8d bf 90 00 00 00 	lea    rdi,[rdi+0x90]
    713079c8fc95:	49 8b f6             	mov    rsi,r14
    713079c8fc98:	e8 a3 03 5c fd       	call   0x713077250040
    713079c8fc9d:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fca4:	48 8b 97 90 00 00 00 	mov    rdx,QWORD PTR [rdi+0x90]
    713079c8fcab:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    713079c8fcb2:	4c 8b 87 88 00 00 00 	mov    r8,QWORD PTR [rdi+0x88]
    713079c8fcb9:	38 12                	cmp    BYTE PTR [rdx],dl
    713079c8fcbb:	48 8d b5 30 ff ff ff 	lea    rsi,[rbp-0xd0]
    713079c8fcc2:	48 8b fa             	mov    rdi,rdx
    713079c8fcc5:	48 8b d1             	mov    rdx,rcx
    713079c8fcc8:	49 8b c8             	mov    rcx,r8
    713079c8fccb:	45 33 c0             	xor    r8d,r8d
    713079c8fcce:	ff 15 9c 48 e8 ff    	call   QWORD PTR [rip+0xffffffffffe8489c]        # 0x713079b14570
    713079c8fcd4:	48 8b 9d 30 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd0]
    713079c8fcdb:	4c 0f bf bd 38 ff ff 	movsx  r15,WORD PTR [rbp-0xc8]
    713079c8fce2:	ff 
    713079c8fce3:	4c 8b b5 40 ff ff ff 	mov    r14,QWORD PTR [rbp-0xc0]
    713079c8fcea:	44 0f b6 ad 48 ff ff 	movzx  r13d,BYTE PTR [rbp-0xb8]
    713079c8fcf1:	ff 
    713079c8fcf2:	48 85 db             	test   rbx,rbx
    713079c8fcf5:	0f 84 bb 00 00 00    	je     0x713079c8fdb6
    713079c8fcfb:	48 8b f3             	mov    rsi,rbx
    713079c8fcfe:	48 bf 48 7c b0 79 30 	movabs rdi,0x713079b07c48
    713079c8fd05:	71 00 00 
    713079c8fd08:	e8 13 ca a5 ff       	call   0x7130796ec720
    713079c8fd0d:	4c 8b f0             	mov    r14,rax
    713079c8fd10:	4d 85 f6             	test   r14,r14
    713079c8fd13:	0f 84 82 00 00 00    	je     0x713079c8fd9b
    713079c8fd19:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    713079c8fd1d:	81 e7 00 00 00 11    	and    edi,0x11000000
    713079c8fd23:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    713079c8fd29:	0f 85 0c 08 00 00    	jne    0x713079c9053b
    713079c8fd2f:	4d 8b 66 38          	mov    r12,QWORD PTR [r14+0x38]
    713079c8fd33:	45 0f b6 76 40       	movzx  r14d,BYTE PTR [r14+0x40]
    713079c8fd38:	4c 89 65 c0          	mov    QWORD PTR [rbp-0x40],r12
    713079c8fd3c:	44 88 75 c8          	mov    BYTE PTR [rbp-0x38],r14b
    713079c8fd40:	48 bf b8 16 80 99 28 	movabs rdi,0x7128998016b8
    713079c8fd47:	71 00 00 
    713079c8fd4a:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c8fd4d:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fd54:	48 8d bf 80 00 00 00 	lea    rdi,[rdi+0x80]
    713079c8fd5b:	e8 e0 02 5c fd       	call   0x713077250040
    713079c8fd60:	33 ff                	xor    edi,edi
    713079c8fd62:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c8fd69:	48 89 bb 88 00 00 00 	mov    QWORD PTR [rbx+0x88],rdi
    713079c8fd70:	80 7d c8 00          	cmp    BYTE PTR [rbp-0x38],0x0
    713079c8fd74:	74 4c                	je     0x713079c8fdc2
    713079c8fd76:	48 8d 7d c0          	lea    rdi,[rbp-0x40]
    713079c8fd7a:	ff 15 d0 db bb ff    	call   QWORD PTR [rip+0xffffffffffbbdbd0]        # 0x71307984d950
    713079c8fd80:	48 8b f0             	mov    rsi,rax
    713079c8fd83:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    713079c8fd8a:	e8 b1 02 5c fd       	call   0x713077250040
    713079c8fd8f:	c6 83 e1 00 00 00 01 	mov    BYTE PTR [rbx+0xe1],0x1
    713079c8fd96:	e9 22 08 00 00       	jmp    0x713079c905bd
    713079c8fd9b:	48 8b fb             	mov    rdi,rbx
    713079c8fd9e:	41 8b f7             	mov    esi,r15d
    713079c8fda1:	49 bb b0 2c 27 77 30 	movabs r11,0x713077272cb0
    713079c8fda8:	71 00 00 
    713079c8fdab:	41 ff 13             	call   QWORD PTR [r11]
    713079c8fdae:	4c 8b e0             	mov    r12,rax
    713079c8fdb1:	44 8b f2             	mov    r14d,edx
    713079c8fdb4:	eb 82                	jmp    0x713079c8fd38
    713079c8fdb6:	4d 8b e6             	mov    r12,r14
    713079c8fdb9:	45 0f b6 f5          	movzx  r14d,r13b
    713079c8fdbd:	e9 76 ff ff ff       	jmp    0x713079c8fd38
    713079c8fdc2:	48 8b b3 90 00 00 00 	mov    rsi,QWORD PTR [rbx+0x90]
    713079c8fdc9:	48 8b 76 20          	mov    rsi,QWORD PTR [rsi+0x20]
    713079c8fdcd:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c8fdd4:	ff 15 26 da bb ff    	call   QWORD PTR [rip+0xffffffffffbbda26]        # 0x71307984d800
    713079c8fdda:	33 f6                	xor    esi,esi
    713079c8fddc:	48 89 b3 90 00 00 00 	mov    QWORD PTR [rbx+0x90],rsi
    713079c8fde3:	e9 c1 fb ff ff       	jmp    0x713079c8f9a9
    713079c8fde8:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fdef:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c8fdf2:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    713079c8fdf9:	ff 15 c1 da bb ff    	call   QWORD PTR [rip+0xffffffffffbbdac1]        # 0x71307984d8c0
    713079c8fdff:	48 8b f0             	mov    rsi,rax
    713079c8fe02:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c8fe09:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    713079c8fe10:	e8 2b 02 5c fd       	call   0x713077250040
    713079c8fe15:	66 c7 83 e0 00 00 00 	mov    WORD PTR [rbx+0xe0],0x101
    713079c8fe1c:	01 01 
    713079c8fe1e:	ff 83 dc 00 00 00    	inc    DWORD PTR [rbx+0xdc]
    713079c8fe24:	e9 94 07 00 00       	jmp    0x713079c905bd
    713079c8fe29:	83 fb 04             	cmp    ebx,0x4
    713079c8fe2c:	74 09                	je     0x713079c8fe37
    713079c8fe2e:	83 fb 0d             	cmp    ebx,0xd
    713079c8fe31:	0f 85 5e 04 00 00    	jne    0x713079c90295
    713079c8fe37:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
    713079c8fe3e:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    713079c8fe41:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fe48:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    713079c8fe4b:	ff 15 c7 d9 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd9c7]        # 0x71307984d818
    713079c8fe51:	e9 53 fb ff ff       	jmp    0x713079c8f9a9
    713079c8fe56:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    713079c8fe5a:	4c 8b 5e 10          	mov    r11,QWORD PTR [rsi+0x10]
    713079c8fe5e:	8b f3                	mov    esi,ebx
    713079c8fe60:	83 fe 03             	cmp    esi,0x3
    713079c8fe63:	0f 85 36 06 00 00    	jne    0x713079c9049f
    713079c8fe69:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fe70:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    713079c8fe73:	49 8b fb             	mov    rdi,r11
    713079c8fe76:	49 bb 68 2c 27 77 30 	movabs r11,0x713077272c68
    713079c8fe7d:	71 00 00 
    713079c8fe80:	41 ff 13             	call   QWORD PTR [r11]
    713079c8fe83:	48 8b f0             	mov    rsi,rax
    713079c8fe86:	48 bf 60 d1 66 79 30 	movabs rdi,0x71307966d160
    713079c8fe8d:	71 00 00 
    713079c8fe90:	e8 4b 0a a7 ff       	call   0x7130797008e0
    713079c8fe95:	48 8b f0             	mov    rsi,rax
    713079c8fe98:	48 8b 95 18 ff ff ff 	mov    rdx,QWORD PTR [rbp-0xe8]
    713079c8fe9f:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    713079c8fea2:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c8fea9:	33 c9                	xor    ecx,ecx
    713079c8feab:	ff 15 c7 d9 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd9c7]        # 0x71307984d878
    713079c8feb1:	48 89 45 b0          	mov    QWORD PTR [rbp-0x50],rax
    713079c8feb5:	48 89 55 b8          	mov    QWORD PTR [rbp-0x48],rdx
    713079c8feb9:	48 8b 5d b0          	mov    rbx,QWORD PTR [rbp-0x50]
    713079c8febd:	48 85 db             	test   rbx,rbx
    713079c8fec0:	0f 84 e3 fa ff ff    	je     0x713079c8f9a9
    713079c8fec6:	48 8b f3             	mov    rsi,rbx
    713079c8fec9:	48 bf 60 8f 5d 78 30 	movabs rdi,0x7130785d8f60
    713079c8fed0:	71 00 00 
    713079c8fed3:	e8 48 c8 a5 ff       	call   0x7130796ec720
    713079c8fed8:	48 85 c0             	test   rax,rax
    713079c8fedb:	74 1a                	je     0x713079c8fef7
    713079c8fedd:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    713079c8fee0:	81 e7 00 00 00 11    	and    edi,0x11000000
    713079c8fee6:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    713079c8feec:	0f 84 b7 fa ff ff    	je     0x713079c8f9a9
    713079c8fef2:	e9 d1 05 00 00       	jmp    0x713079c904c8
    713079c8fef7:	48 bf 40 77 55 79 30 	movabs rdi,0x713079557740
    713079c8fefe:	71 00 00 
    713079c8ff01:	48 39 3b             	cmp    QWORD PTR [rbx],rdi
    713079c8ff04:	0f 85 17 06 00 00    	jne    0x713079c90521
    713079c8ff0a:	48 89 9d 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],rbx
    713079c8ff11:	48 0f bf 7d b8       	movsx  rdi,WORD PTR [rbp-0x48]
    713079c8ff16:	48 8d 43 18          	lea    rax,[rbx+0x18]
    713079c8ff1a:	48 8b c8             	mov    rcx,rax
    713079c8ff1d:	48 0f bf 51 24       	movsx  rdx,WORD PTR [rcx+0x24]
    713079c8ff22:	3b fa                	cmp    edi,edx
    713079c8ff24:	75 19                	jne    0x713079c8ff3f
    713079c8ff26:	48 8b 39             	mov    rdi,QWORD PTR [rcx]
    713079c8ff29:	48 ba 08 13 80 99 28 	movabs rdx,0x712899801308
    713079c8ff30:	71 00 00 
    713079c8ff33:	48 3b 3a             	cmp    rdi,QWORD PTR [rdx]
    713079c8ff36:	75 07                	jne    0x713079c8ff3f
    713079c8ff38:	48 83 79 18 00       	cmp    QWORD PTR [rcx+0x18],0x0
    713079c8ff3d:	74 0a                	je     0x713079c8ff49
    713079c8ff3f:	48 8b f9             	mov    rdi,rcx
    713079c8ff42:	ff 15 10 4f 0b 00    	call   QWORD PTR [rip+0xb4f10]        # 0x713079d44e58
    713079c8ff48:	cc                   	int3
    713079c8ff49:	33 ff                	xor    edi,edi
    713079c8ff4b:	48 89 7b 40          	mov    QWORD PTR [rbx+0x40],rdi
    713079c8ff4f:	48 89 7b 48          	mov    QWORD PTR [rbx+0x48],rdi
    713079c8ff53:	48 89 7b 50          	mov    QWORD PTR [rbx+0x50],rdi
    713079c8ff57:	48 89 7b 58          	mov    QWORD PTR [rbx+0x58],rdi
    713079c8ff5b:	48 89 7b 60          	mov    QWORD PTR [rbx+0x60],rdi
    713079c8ff5f:	48 89 7b 68          	mov    QWORD PTR [rbx+0x68],rdi
    713079c8ff63:	48 89 7b 70          	mov    QWORD PTR [rbx+0x70],rdi
    713079c8ff67:	48 89 7b 78          	mov    QWORD PTR [rbx+0x78],rdi
    713079c8ff6b:	48 89 bb 80 00 00 00 	mov    QWORD PTR [rbx+0x80],rdi
    713079c8ff72:	48 89 bb 88 00 00 00 	mov    QWORD PTR [rbx+0x88],rdi
    713079c8ff79:	48 89 7b 10          	mov    QWORD PTR [rbx+0x10],rdi
    713079c8ff7d:	48 8b f8             	mov    rdi,rax
    713079c8ff80:	ff 15 3a df 81 ff    	call   QWORD PTR [rip+0xffffffffff81df3a]        # 0x7130794adec0
    713079c8ff86:	48 bf f0 13 70 f6 30 	movabs rdi,0x7130f67013f0
    713079c8ff8d:	71 00 00 
    713079c8ff90:	48 b8 20 d8 fe f6 30 	movabs rax,0x7130f6fed820
    713079c8ff97:	71 00 00 
    713079c8ff9a:	ff d0                	call   rax
    713079c8ff9c:	83 38 0f             	cmp    DWORD PTR [rax],0xf
    713079c8ff9f:	0f 8e 33 05 00 00    	jle    0x713079c904d8
    713079c8ffa5:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    713079c8ffa9:	48 8b 47 78          	mov    rax,QWORD PTR [rdi+0x78]
    713079c8ffad:	48 85 c0             	test   rax,rax
    713079c8ffb0:	0f 84 22 05 00 00    	je     0x713079c904d8
    713079c8ffb6:	48 83 78 10 00       	cmp    QWORD PTR [rax+0x10],0x0
    713079c8ffbb:	0f 85 26 05 00 00    	jne    0x713079c904e7
    713079c8ffc1:	48 8d 78 10          	lea    rdi,[rax+0x10]
    713079c8ffc5:	48 8b f3             	mov    rsi,rbx
    713079c8ffc8:	e8 73 00 5c fd       	call   0x713077250040
    713079c8ffcd:	e9 d7 f9 ff ff       	jmp    0x713079c8f9a9
    713079c8ffd2:	4c 8d bf e8 00 00 00 	lea    r15,[rdi+0xe8]
    713079c8ffd9:	4c 8b 77 08          	mov    r14,QWORD PTR [rdi+0x8]
    713079c8ffdd:	4c 8b 6f 10          	mov    r13,QWORD PTR [rdi+0x10]
    713079c8ffe1:	8b f3                	mov    esi,ebx
    713079c8ffe3:	83 fe 04             	cmp    esi,0x4
    713079c8ffe6:	74 09                	je     0x713079c8fff1
    713079c8ffe8:	83 fe 0d             	cmp    esi,0xd
    713079c8ffeb:	0f 85 a4 02 00 00    	jne    0x713079c90295
    713079c8fff1:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c8fff8:	8b 5e 08             	mov    ebx,DWORD PTR [rsi+0x8]
    713079c8fffb:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c90002:	4c 8b 26             	mov    r12,QWORD PTR [rsi]
    713079c90005:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c9000c:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    713079c90010:	48 89 85 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],rax
    713079c90017:	33 f6                	xor    esi,esi
    713079c90019:	48 89 b5 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rsi
    713079c90020:	48 89 b5 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rsi
    713079c90027:	41 3b 5d 08          	cmp    ebx,DWORD PTR [r13+0x8]
    713079c9002b:	0f 83 21 05 00 00    	jae    0x713079c90552
    713079c90031:	8b f3                	mov    esi,ebx
    713079c90033:	49 8b 74 f5 10       	mov    rsi,QWORD PTR [r13+rsi*8+0x10]
    713079c90038:	49 bb a8 32 80 99 28 	movabs r11,0x7128998032a8
    713079c9003f:	71 00 00 
    713079c90042:	49 3b 33             	cmp    rsi,QWORD PTR [r11]
    713079c90045:	0f 84 6a 02 00 00    	je     0x713079c902b5
    713079c9004b:	33 c0                	xor    eax,eax
    713079c9004d:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
    713079c90054:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
    713079c9005b:	49 8b ff             	mov    rdi,r15
    713079c9005e:	ff 15 9c d7 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd79c]        # 0x71307984d800
    713079c90064:	e9 40 f9 ff ff       	jmp    0x713079c8f9a9
    713079c90069:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c90070:	ff 15 22 d9 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd922]        # 0x71307984d998
    713079c90076:	e9 2e f9 ff ff       	jmp    0x713079c8f9a9
    713079c9007b:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c90082:	ff 15 f8 d8 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd8f8]        # 0x71307984d980
    713079c90088:	e9 1c f9 ff ff       	jmp    0x713079c8f9a9
    713079c9008d:	c5 fc 57 c0          	vxorps ymm0,ymm0,ymm0
    713079c90091:	62 f1 7e 28 7f 45 fb 	vmovdqu32 YMMWORD PTR [rbp-0xa0],ymm0
    713079c90098:	c5 fa 7f 85 78 ff ff 	vmovdqu XMMWORD PTR [rbp-0x88],xmm0
    713079c9009f:	ff 
    713079c900a0:	48 8d bd 60 ff ff ff 	lea    rdi,[rbp-0xa0]
    713079c900a7:	be 1b 00 00 00       	mov    esi,0x1b
    713079c900ac:	ba 01 00 00 00       	mov    edx,0x1
    713079c900b1:	ff 15 b1 ea 81 ff    	call   QWORD PTR [rip+0xffffffffff81eab1]        # 0x7130794aeb68
    713079c900b7:	62 f1 7e 28 6f 45 fb 	vmovdqu32 ymm0,YMMWORD PTR [rbp-0xa0]
    713079c900be:	c5 fe 7f 45 88       	vmovdqu YMMWORD PTR [rbp-0x78],ymm0
    713079c900c3:	48 8b 7d 80          	mov    rdi,QWORD PTR [rbp-0x80]
    713079c900c7:	48 89 7d a8          	mov    QWORD PTR [rbp-0x58],rdi
    713079c900cb:	8b 7d 98             	mov    edi,DWORD PTR [rbp-0x68]
    713079c900ce:	3b 7d a8             	cmp    edi,DWORD PTR [rbp-0x58]
    713079c900d1:	0f 87 74 04 00 00    	ja     0x713079c9054b
    713079c900d7:	48 8b 75 a0          	mov    rsi,QWORD PTR [rbp-0x60]
    713079c900db:	8b c7                	mov    eax,edi
    713079c900dd:	48 8d 34 46          	lea    rsi,[rsi+rax*2]
    713079c900e1:	8b 45 a8             	mov    eax,DWORD PTR [rbp-0x58]
    713079c900e4:	2b c7                	sub    eax,edi
    713079c900e6:	83 f8 1b             	cmp    eax,0x1b
    713079c900e9:	0f 82 69 04 00 00    	jb     0x713079c90558
    713079c900ef:	c5 fc 10 05 09 08 00 	vmovups ymm0,YMMWORD PTR [rip+0x809]        # 0x713079c90900
    713079c900f6:	00 
    713079c900f7:	c5 fc 11 06          	vmovups YMMWORD PTR [rsi],ymm0
    713079c900fb:	c5 f8 10 05 1d 08 00 	vmovups xmm0,XMMWORD PTR [rip+0x81d]        # 0x713079c90920
    713079c90102:	00 
    713079c90103:	c5 f8 11 46 20       	vmovups XMMWORD PTR [rsi+0x20],xmm0
    713079c90108:	c7 46 30 65 00 3a 00 	mov    DWORD PTR [rsi+0x30],0x3a0065
    713079c9010f:	66 c7 46 34 20 00    	mov    WORD PTR [rsi+0x34],0x20
    713079c90115:	8b 7d 98             	mov    edi,DWORD PTR [rbp-0x68]
    713079c90118:	83 c7 1b             	add    edi,0x1b
    713079c9011b:	89 7d 98             	mov    DWORD PTR [rbp-0x68],edi
    713079c9011e:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c90125:	8b 76 10             	mov    esi,DWORD PTR [rsi+0x10]
    713079c90128:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    713079c9012c:	ff 15 5e f5 9e ff    	call   QWORD PTR [rip+0xffffffffff9ef55e]        # 0x71307967f690
    713079c90132:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    713079c90139:	71 00 00 
    713079c9013c:	e8 7f 11 9c 7c       	call   0x7130f66512c0
    713079c90141:	48 8b d8             	mov    rbx,rax
    713079c90144:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    713079c90148:	ff 15 4a ea 81 ff    	call   QWORD PTR [rip+0xffffffffff81ea4a]        # 0x7130794aeb98
    713079c9014e:	48 8b f0             	mov    rsi,rax
    713079c90151:	48 8b fb             	mov    rdi,rbx
    713079c90154:	ff 15 7e 5d 8e ff    	call   QWORD PTR [rip+0xffffffffff8e5d7e]        # 0x713079575ed8
    713079c9015a:	48 8b fb             	mov    rdi,rbx
    713079c9015d:	e8 3e 1e 72 7c       	call   0x7130f63b1fa0
    713079c90162:	cc                   	int3
    713079c90163:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
    713079c9016a:	48 8d 3c 24          	lea    rdi,[rsp]
    713079c9016e:	48 8b f0             	mov    rsi,rax
    713079c90171:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    713079c90174:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    713079c90178:	48 83 c6 08          	add    rsi,0x8
    713079c9017c:	48 83 c7 08          	add    rdi,0x8
    713079c90180:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c90182:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c90184:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c9018b:	ff 15 37 d8 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd837]        # 0x71307984d9c8
    713079c90191:	85 c0                	test   eax,eax
    713079c90193:	0f 85 24 04 00 00    	jne    0x713079c905bd
    713079c90199:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c901a0:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c901a7:	ff 15 33 d8 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd833]        # 0x71307984d9e0
    713079c901ad:	e9 f7 f7 ff ff       	jmp    0x713079c8f9a9
    713079c901b2:	48 8d b7 e8 00 00 00 	lea    rsi,[rdi+0xe8]
    713079c901b9:	48 8b 85 18 ff ff ff 	mov    rax,QWORD PTR [rbp-0xe8]
    713079c901c0:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    713079c901c3:	8b 46 30             	mov    eax,DWORD PTR [rsi+0x30]
    713079c901c6:	85 c0                	test   eax,eax
    713079c901c8:	0f 84 45 02 00 00    	je     0x713079c90413
    713079c901ce:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c901d1:	ff c8                	dec    eax
    713079c901d3:	3b 46 08             	cmp    eax,DWORD PTR [rsi+0x8]
    713079c901d6:	0f 83 76 03 00 00    	jae    0x713079c90552
    713079c901dc:	48 8b 74 c6 10       	mov    rsi,QWORD PTR [rsi+rax*8+0x10]
    713079c901e1:	48 85 f6             	test   rsi,rsi
    713079c901e4:	0f 84 e4 01 00 00    	je     0x713079c903ce
    713079c901ea:	4c 8b fe             	mov    r15,rsi
    713079c901ed:	48 b8 70 23 af 79 30 	movabs rax,0x713079af2370
    713079c901f4:	71 00 00 
    713079c901f7:	49 39 07             	cmp    QWORD PTR [r15],rax
    713079c901fa:	0f 85 fc 01 00 00    	jne    0x713079c903fc
    713079c90200:	4d 85 ff             	test   r15,r15
    713079c90203:	0f 84 0a 02 00 00    	je     0x713079c90413
    713079c90209:	48 b8 70 23 af 79 30 	movabs rax,0x713079af2370
    713079c90210:	71 00 00 
    713079c90213:	49 39 07             	cmp    QWORD PTR [r15],rax
    713079c90216:	0f 85 13 02 00 00    	jne    0x713079c9042f
    713079c9021c:	49 8b ff             	mov    rdi,r15
    713079c9021f:	ff 15 f3 21 e6 ff    	call   QWORD PTR [rip+0xffffffffffe621f3]        # 0x713079af2418
    713079c90225:	85 c0                	test   eax,eax
    713079c90227:	0f 84 17 02 00 00    	je     0x713079c90444
    713079c9022d:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c90234:	4c 8d b3 e8 00 00 00 	lea    r14,[rbx+0xe8]
    713079c9023b:	48 bf 70 23 af 79 30 	movabs rdi,0x713079af2370
    713079c90242:	71 00 00 
    713079c90245:	49 39 3f             	cmp    QWORD PTR [r15],rdi
    713079c90248:	0f 85 39 02 00 00    	jne    0x713079c90487
    713079c9024e:	49 8b 77 08          	mov    rsi,QWORD PTR [r15+0x8]
    713079c90252:	49 8b fe             	mov    rdi,r14
    713079c90255:	ff 15 a5 d5 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd5a5]        # 0x71307984d800
    713079c9025b:	45 33 ff             	xor    r15d,r15d
    713079c9025e:	44 89 7d d4          	mov    DWORD PTR [rbp-0x2c],r15d
    713079c90262:	e9 42 f7 ff ff       	jmp    0x713079c8f9a9
    713079c90267:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c9026e:	ff 15 3c d7 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd73c]        # 0x71307984d9b0
    713079c90274:	89 45 d4             	mov    DWORD PTR [rbp-0x2c],eax
    713079c90277:	e9 2d f7 ff ff       	jmp    0x713079c8f9a9
    713079c9027c:	48 8b 87 88 00 00 00 	mov    rax,QWORD PTR [rdi+0x88]
    713079c90283:	33 c9                	xor    ecx,ecx
    713079c90285:	48 89 8f 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rcx
    713079c9028c:	48 8b f8             	mov    rdi,rax
    713079c9028f:	e8 0c 1d 72 7c       	call   0x7130f63b1fa0
    713079c90294:	cc                   	int3
    713079c90295:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c9029c:	48 be 40 44 e1 74 30 	movabs rsi,0x713074e14440
    713079c902a3:	71 00 00 
    713079c902a6:	ff 15 8c dc 9e ff    	call   QWORD PTR [rip+0xffffffffff9edc8c]        # 0x71307967df38
    713079c902ac:	48 8b f8             	mov    rdi,rax
    713079c902af:	e8 ec 1c 72 7c       	call   0x7130f63b1fa0
    713079c902b4:	cc                   	int3
    713079c902b5:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    713079c902bc:	00 
    713079c902bd:	0f 85 b8 00 00 00    	jne    0x713079c9037b
    713079c902c3:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c902c7:	8b f3                	mov    esi,ebx
    713079c902c9:	49 bb 80 2c 27 77 30 	movabs r11,0x713077272c80
    713079c902d0:	71 00 00 
    713079c902d3:	41 ff 13             	call   QWORD PTR [r11]
    713079c902d6:	48 8b f8             	mov    rdi,rax
    713079c902d9:	be 3c 00 00 00       	mov    esi,0x3c
    713079c902de:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c902e0:	ff 15 da db bb ff    	call   QWORD PTR [rip+0xffffffffffbbdbda]        # 0x71307984dec0
    713079c902e6:	85 c0                	test   eax,eax
    713079c902e8:	0f 85 8d 00 00 00    	jne    0x713079c9037b
    713079c902ee:	4c 8b ad 10 ff ff ff 	mov    r13,QWORD PTR [rbp-0xf0]
    713079c902f5:	45 38 6d 00          	cmp    BYTE PTR [r13+0x0],r13b
    713079c902f9:	49 8b fd             	mov    rdi,r13
    713079c902fc:	ff 15 56 72 bb ff    	call   QWORD PTR [rip+0xffffffffffbb7256]        # 0x713079847558
    713079c90302:	48 89 85 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rax
    713079c90309:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c9030d:	8b f3                	mov    esi,ebx
    713079c9030f:	49 bb 88 2c 27 77 30 	movabs r11,0x713077272c88
    713079c90316:	71 00 00 
    713079c90319:	41 ff 13             	call   QWORD PTR [r11]
    713079c9031c:	48 8b f0             	mov    rsi,rax
    713079c9031f:	48 8b bd 00 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x100]
    713079c90326:	48 8d 95 58 ff ff ff 	lea    rdx,[rbp-0xa8]
    713079c9032d:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c9032f:	ff 15 2b d6 84 fe    	call   QWORD PTR [rip+0xfffffffffe84d62b]        # 0x7130784dd960
    713079c90335:	85 c0                	test   eax,eax
    713079c90337:	74 0c                	je     0x713079c90345
    713079c90339:	48 8b b5 58 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xa8]
    713079c90340:	e9 06 fd ff ff       	jmp    0x713079c9004b
    713079c90345:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c90349:	8b f3                	mov    esi,ebx
    713079c9034b:	49 bb 90 2c 27 77 30 	movabs r11,0x713077272c90
    713079c90352:	71 00 00 
    713079c90355:	41 ff 13             	call   QWORD PTR [r11]
    713079c90358:	48 8b f0             	mov    rsi,rax
    713079c9035b:	48 8d 95 50 ff ff ff 	lea    rdx,[rbp-0xb0]
    713079c90362:	49 8b fd             	mov    rdi,r13
    713079c90365:	ff 15 2d dc bb ff    	call   QWORD PTR [rip+0xffffffffffbbdc2d]        # 0x71307984df98
    713079c9036b:	85 c0                	test   eax,eax
    713079c9036d:	74 0c                	je     0x713079c9037b
    713079c9036f:	48 8b b5 50 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xb0]
    713079c90376:	e9 d0 fc ff ff       	jmp    0x713079c9004b
    713079c9037b:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    713079c90382:	00 
    713079c90383:	75 21                	jne    0x713079c903a6
    713079c90385:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c90389:	8b f3                	mov    esi,ebx
    713079c9038b:	49 bb 78 2c 27 77 30 	movabs r11,0x713077272c78
    713079c90392:	71 00 00 
    713079c90395:	41 ff 13             	call   QWORD PTR [r11]
    713079c90398:	48 8b f8             	mov    rdi,rax
    713079c9039b:	49 8b f4             	mov    rsi,r12
    713079c9039e:	ff 15 0c dc bb ff    	call   QWORD PTR [rip+0xffffffffffbbdc0c]        # 0x71307984dfb0
    713079c903a4:	eb 1f                	jmp    0x713079c903c5
    713079c903a6:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c903aa:	8b f3                	mov    esi,ebx
    713079c903ac:	49 bb 70 2c 27 77 30 	movabs r11,0x713077272c70
    713079c903b3:	71 00 00 
    713079c903b6:	41 ff 13             	call   QWORD PTR [r11]
    713079c903b9:	48 8b f8             	mov    rdi,rax
    713079c903bc:	49 8b f4             	mov    rsi,r12
    713079c903bf:	ff 15 5b db bb ff    	call   QWORD PTR [rip+0xffffffffffbbdb5b]        # 0x71307984df20
    713079c903c5:	48 8b f8             	mov    rdi,rax
    713079c903c8:	e8 d3 1b 72 7c       	call   0x7130f63b1fa0
    713079c903cd:	cc                   	int3
    713079c903ce:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    713079c903d5:	71 00 00 
    713079c903d8:	e8 e3 0e 9c 7c       	call   0x7130f66512c0
    713079c903dd:	48 8b d8             	mov    rbx,rax
    713079c903e0:	48 8b fb             	mov    rdi,rbx
    713079c903e3:	48 be 18 d2 e0 74 30 	movabs rsi,0x713074e0d218
    713079c903ea:	71 00 00 
    713079c903ed:	ff 15 e5 5a 8e ff    	call   QWORD PTR [rip+0xffffffffff8e5ae5]        # 0x713079575ed8
    713079c903f3:	48 8b fb             	mov    rdi,rbx
    713079c903f6:	e8 a5 1b 72 7c       	call   0x7130f63b1fa0
    713079c903fb:	cc                   	int3
    713079c903fc:	48 bf 58 37 83 79 30 	movabs rdi,0x713079833758
    713079c90403:	71 00 00 
    713079c90406:	e8 f5 f0 a5 ff       	call   0x7130796ef500
    713079c9040b:	4c 8b f8             	mov    r15,rax
    713079c9040e:	e9 ed fd ff ff       	jmp    0x713079c90200
    713079c90413:	48 8b f3             	mov    rsi,rbx
    713079c90416:	48 bf e8 48 e1 74 30 	movabs rdi,0x713074e148e8
    713079c9041d:	71 00 00 
    713079c90420:	ff 15 52 da bb ff    	call   QWORD PTR [rip+0xffffffffffbbda52]        # 0x71307984de78
    713079c90426:	48 8b f8             	mov    rdi,rax
    713079c90429:	e8 72 1b 72 7c       	call   0x7130f63b1fa0
    713079c9042e:	cc                   	int3
    713079c9042f:	49 8b ff             	mov    rdi,r15
    713079c90432:	49 bb 98 2c 27 77 30 	movabs r11,0x713077272c98
    713079c90439:	71 00 00 
    713079c9043c:	41 ff 13             	call   QWORD PTR [r11]
    713079c9043f:	e9 e1 fd ff ff       	jmp    0x713079c90225
    713079c90444:	48 8b b5 18 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xe8]
    713079c9044b:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c9044e:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c90455:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c9045c:	ff 15 5e d4 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd45e]        # 0x71307984d8c0
    713079c90462:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c90469:	ff 15 59 d8 9e ff    	call   QWORD PTR [rip+0xffffffffff9ed859]        # 0x71307967dcc8
    713079c9046f:	89 83 d8 00 00 00    	mov    DWORD PTR [rbx+0xd8],eax
    713079c90475:	41 bf 01 00 00 00    	mov    r15d,0x1
    713079c9047b:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c90482:	e9 d7 fd ff ff       	jmp    0x713079c9025e
    713079c90487:	49 8b ff             	mov    rdi,r15
    713079c9048a:	49 bb a0 2c 27 77 30 	movabs r11,0x713077272ca0
    713079c90491:	71 00 00 
    713079c90494:	41 ff 13             	call   QWORD PTR [r11]
    713079c90497:	48 8b f0             	mov    rsi,rax
    713079c9049a:	e9 b3 fd ff ff       	jmp    0x713079c90252
    713079c9049f:	83 fe 08             	cmp    esi,0x8
    713079c904a2:	0f 84 c1 f9 ff ff    	je     0x713079c8fe69
    713079c904a8:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c904af:	48 be 68 43 e1 74 30 	movabs rsi,0x713074e14368
    713079c904b6:	71 00 00 
    713079c904b9:	ff 15 79 da 9e ff    	call   QWORD PTR [rip+0xffffffffff9eda79]        # 0x71307967df38
    713079c904bf:	48 8b f8             	mov    rdi,rax
    713079c904c2:	e8 d9 1a 72 7c       	call   0x7130f63b1fa0
    713079c904c7:	cc                   	int3
    713079c904c8:	48 8b f8             	mov    rdi,rax
    713079c904cb:	33 f6                	xor    esi,esi
    713079c904cd:	ff 15 45 53 4b ff    	call   QWORD PTR [rip+0xffffffffff4b5345]        # 0x713079145818
    713079c904d3:	e9 d1 f4 ff ff       	jmp    0x713079c8f9a9
    713079c904d8:	bf 0f 00 00 00       	mov    edi,0xf
    713079c904dd:	e8 6e 0b a8 ff       	call   0x713079711050
    713079c904e2:	e9 cf fa ff ff       	jmp    0x713079c8ffb6
    713079c904e7:	c5 f8 77             	vzeroupper
    713079c904ea:	e8 51 2d 7e fd       	call   0x713077473240
    713079c904ef:	83 e0 03             	and    eax,0x3
    713079c904f2:	48 bf f8 12 80 99 28 	movabs rdi,0x7128998012f8
    713079c904f9:	71 00 00 
    713079c904fc:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    713079c904ff:	8b f8                	mov    edi,eax
    713079c90501:	48 c1 e7 06          	shl    rdi,0x6
    713079c90505:	49 8d 7c 3f 10       	lea    rdi,[r15+rdi*1+0x10]
    713079c9050a:	48 83 3f 00          	cmp    QWORD PTR [rdi],0x0
    713079c9050e:	0f 85 95 f4 ff ff    	jne    0x713079c8f9a9
    713079c90514:	48 8b f3             	mov    rsi,rbx
    713079c90517:	e8 24 fb 5b fd       	call   0x713077250040
    713079c9051c:	e9 88 f4 ff ff       	jmp    0x713079c8f9a9
    713079c90521:	48 8b fb             	mov    rdi,rbx
    713079c90524:	48 0f bf 75 b8       	movsx  rsi,WORD PTR [rbp-0x48]
    713079c90529:	49 bb a8 2c 27 77 30 	movabs r11,0x713077272ca8
    713079c90530:	71 00 00 
    713079c90533:	41 ff 13             	call   QWORD PTR [r11]
    713079c90536:	e9 6e f4 ff ff       	jmp    0x713079c8f9a9
    713079c9053b:	49 8b fe             	mov    rdi,r14
    713079c9053e:	33 f6                	xor    esi,esi
    713079c90540:	ff 15 d2 52 4b ff    	call   QWORD PTR [rip+0xffffffffff4b52d2]        # 0x713079145818
    713079c90546:	e9 e4 f7 ff ff       	jmp    0x713079c8fd2f
    713079c9054b:	ff 15 97 70 9e ff    	call   QWORD PTR [rip+0xffffffffff9e7097]        # 0x7130796775e8
    713079c90551:	cc                   	int3
    713079c90552:	e8 b1 10 7f fe       	call   0x713078481608
    713079c90557:	cc                   	int3
    713079c90558:	48 8d 7d 88          	lea    rdi,[rbp-0x78]
    713079c9055c:	48 be 48 42 e1 74 30 	movabs rsi,0x713074e14248
    713079c90563:	71 00 00 
    713079c90566:	ff 15 1c 40 e8 ff    	call   QWORD PTR [rip+0xffffffffffe8401c]        # 0x713079b14588
    713079c9056c:	e9 ad fb ff ff       	jmp    0x713079c9011e
    713079c90571:	48 8b fe             	mov    rdi,rsi
    713079c90574:	41 8b f3             	mov    esi,r11d
    713079c90577:	49 bb 60 2c 27 77 30 	movabs r11,0x713077272c60
    713079c9057e:	71 00 00 
    713079c90581:	41 ff 13             	call   QWORD PTR [r11]
    713079c90584:	48 8b d8             	mov    rbx,rax
    713079c90587:	e9 22 f5 ff ff       	jmp    0x713079c8faae
    713079c9058c:	83 78 20 00          	cmp    DWORD PTR [rax+0x20],0x0
    713079c90590:	0f 84 85 f5 ff ff    	je     0x713079c8fb1b
    713079c90596:	48 8b f9             	mov    rdi,rcx
    713079c90599:	ff 15 a1 cb bb ff    	call   QWORD PTR [rip+0xffffffffffbbcba1]        # 0x71307984d140
    713079c9059f:	e9 77 f5 ff ff       	jmp    0x713079c8fb1b
    713079c905a4:	90                   	nop
    713079c905a5:	eb 16                	jmp    0x713079c905bd
    713079c905a7:	ff 15 4b ef 81 ff    	call   QWORD PTR [rip+0xffffffffff81ef4b]        # 0x7130794af4f8
    713079c905ad:	cc                   	int3
    713079c905ae:	48 8b fa             	mov    rdi,rdx
    713079c905b1:	e8 ea 19 72 7c       	call   0x7130f63b1fa0
    713079c905b6:	cc                   	int3
    713079c905b7:	e8 4c 10 7f fe       	call   0x713078481608
    713079c905bc:	cc                   	int3
    713079c905bd:	e8 d7 01 00 00       	call   0x713079c90799
    713079c905c2:	90                   	nop
    713079c905c3:	c5 f8 77             	vzeroupper
    713079c905c6:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    713079c905cd:	5b                   	pop    rbx
    713079c905ce:	41 5c                	pop    r12
    713079c905d0:	41 5d                	pop    r13
    713079c905d2:	41 5e                	pop    r14
    713079c905d4:	41 5f                	pop    r15
    713079c905d6:	5d                   	pop    rbp
    713079c905d7:	c3                   	ret
    713079c905d8:	48 83 ec 18          	sub    rsp,0x18
    713079c905dc:	48 8b bd 08 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf8]
    713079c905e3:	33 c0                	xor    eax,eax
    713079c905e5:	48 89 47 40          	mov    QWORD PTR [rdi+0x40],rax
    713079c905e9:	48 89 47 48          	mov    QWORD PTR [rdi+0x48],rax
    713079c905ed:	48 89 47 50          	mov    QWORD PTR [rdi+0x50],rax
    713079c905f1:	48 89 47 58          	mov    QWORD PTR [rdi+0x58],rax
    713079c905f5:	48 89 47 60          	mov    QWORD PTR [rdi+0x60],rax
    713079c905f9:	48 89 47 68          	mov    QWORD PTR [rdi+0x68],rax
    713079c905fd:	48 89 47 70          	mov    QWORD PTR [rdi+0x70],rax
    713079c90601:	48 89 47 78          	mov    QWORD PTR [rdi+0x78],rax
    713079c90605:	48 89 87 80 00 00 00 	mov    QWORD PTR [rdi+0x80],rax
    713079c9060c:	48 89 87 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rax
    713079c90613:	48 8b bd 08 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xf8]
    713079c9061a:	48 89 47 10          	mov    QWORD PTR [rdi+0x10],rax
    713079c9061e:	48 8b 85 08 ff ff ff 	mov    rax,QWORD PTR [rbp-0xf8]
    713079c90625:	48 83 c0 18          	add    rax,0x18
    713079c90629:	48 8b f8             	mov    rdi,rax
    713079c9062c:	ff 15 8e d8 81 ff    	call   QWORD PTR [rip+0xffffffffff81d88e]        # 0x7130794adec0
    713079c90632:	48 bf f0 13 70 f6 30 	movabs rdi,0x7130f67013f0
    713079c90639:	71 00 00 
    713079c9063c:	48 b8 20 d8 fe f6 30 	movabs rax,0x7130f6fed820
    713079c90643:	71 00 00 
    713079c90646:	ff d0                	call   rax
    713079c90648:	83 38 0f             	cmp    DWORD PTR [rax],0xf
    713079c9064b:	7e 0d                	jle    0x713079c9065a
    713079c9064d:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
    713079c90651:	48 8b 47 78          	mov    rax,QWORD PTR [rdi+0x78]
    713079c90655:	48 85 c0             	test   rax,rax
    713079c90658:	75 0a                	jne    0x713079c90664
    713079c9065a:	bf 0f 00 00 00       	mov    edi,0xf
    713079c9065f:	e8 ec 09 a8 ff       	call   0x713079711050
    713079c90664:	48 83 78 10 00       	cmp    QWORD PTR [rax+0x10],0x0
    713079c90669:	75 12                	jne    0x713079c9067d
    713079c9066b:	48 8d 78 10          	lea    rdi,[rax+0x10]
    713079c9066f:	48 8b b5 08 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xf8]
    713079c90676:	e8 c5 f9 5b fd       	call   0x713077250040
    713079c9067b:	eb 35                	jmp    0x713079c906b2
    713079c9067d:	c5 f8 77             	vzeroupper
    713079c90680:	e8 bb 2b 7e fd       	call   0x713077473240
    713079c90685:	83 e0 03             	and    eax,0x3
    713079c90688:	48 bf f8 12 80 99 28 	movabs rdi,0x7128998012f8
    713079c9068f:	71 00 00 
    713079c90692:	4c 8b 3f             	mov    r15,QWORD PTR [rdi]
    713079c90695:	8b f8                	mov    edi,eax
    713079c90697:	48 c1 e7 06          	shl    rdi,0x6
    713079c9069b:	49 8d 7c 3f 10       	lea    rdi,[r15+rdi*1+0x10]
    713079c906a0:	48 83 3f 00          	cmp    QWORD PTR [rdi],0x0
    713079c906a4:	75 0c                	jne    0x713079c906b2
    713079c906a6:	48 8b b5 08 ff ff ff 	mov    rsi,QWORD PTR [rbp-0xf8]
    713079c906ad:	e8 8e f9 5b fd       	call   0x713077250040
    713079c906b2:	90                   	nop
    713079c906b3:	c5 f8 77             	vzeroupper
    713079c906b6:	48 83 c4 18          	add    rsp,0x18
    713079c906ba:	c3                   	ret
    713079c906bb:	48 83 ec 18          	sub    rsp,0x18
    713079c906bf:	48 8b df             	mov    rbx,rdi
    713079c906c2:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c906c9:	ff 15 f1 ef 9e ff    	call   QWORD PTR [rip+0xffffffffff9eeff1]        # 0x71307967f6c0
    713079c906cf:	48 8b d0             	mov    rdx,rax
    713079c906d2:	48 8b f3             	mov    rsi,rbx
    713079c906d5:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c906dc:	ff 15 46 d3 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd346]        # 0x71307984da28
    713079c906e2:	85 c0                	test   eax,eax
    713079c906e4:	75 0f                	jne    0x713079c906f5
    713079c906e6:	48 8d 05 b7 fe ff ff 	lea    rax,[rip+0xfffffffffffffeb7]        # 0x713079c905a4
    713079c906ed:	c5 f8 77             	vzeroupper
    713079c906f0:	48 83 c4 18          	add    rsp,0x18
    713079c906f4:	c3                   	ret
    713079c906f5:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    713079c906fc:	48 8d 05 a6 f2 ff ff 	lea    rax,[rip+0xfffffffffffff2a6]        # 0x713079c8f9a9
    713079c90703:	c5 f8 77             	vzeroupper
    713079c90706:	48 83 c4 18          	add    rsp,0x18
    713079c9070a:	c3                   	ret
    713079c9070b:	48 83 ec 18          	sub    rsp,0x18
    713079c9070f:	48 8b df             	mov    rbx,rdi
    713079c90712:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c90719:	ff 15 a1 ef 9e ff    	call   QWORD PTR [rip+0xffffffffff9eefa1]        # 0x71307967f6c0
    713079c9071f:	48 8b d0             	mov    rdx,rax
    713079c90722:	48 8b f3             	mov    rsi,rbx
    713079c90725:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c9072c:	ff 15 0e d3 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd30e]        # 0x71307984da40
    713079c90732:	85 c0                	test   eax,eax
    713079c90734:	75 06                	jne    0x713079c9073c
    713079c90736:	e8 25 19 72 7c       	call   0x7130f63b2060
    713079c9073b:	cc                   	int3
    713079c9073c:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    713079c90743:	48 8d 05 5f f2 ff ff 	lea    rax,[rip+0xfffffffffffff25f]        # 0x713079c8f9a9
    713079c9074a:	c5 f8 77             	vzeroupper
    713079c9074d:	48 83 c4 18          	add    rsp,0x18
    713079c90751:	c3                   	ret
    713079c90752:	48 83 ec 18          	sub    rsp,0x18
    713079c90756:	48 8b df             	mov    rbx,rdi
    713079c90759:	48 8b bd 18 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xe8]
    713079c90760:	ff 15 5a ef 9e ff    	call   QWORD PTR [rip+0xffffffffff9eef5a]        # 0x71307967f6c0
    713079c90766:	48 8b d0             	mov    rdx,rax
    713079c90769:	48 8b f3             	mov    rsi,rbx
    713079c9076c:	48 8b bd 28 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xd8]
    713079c90773:	ff 15 df d2 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd2df]        # 0x71307984da58
    713079c90779:	85 c0                	test   eax,eax
    713079c9077b:	75 06                	jne    0x713079c90783
    713079c9077d:	e8 de 18 72 7c       	call   0x7130f63b2060
    713079c90782:	cc                   	int3
    713079c90783:	c7 45 d4 01 00 00 00 	mov    DWORD PTR [rbp-0x2c],0x1
    713079c9078a:	48 8d 05 18 f2 ff ff 	lea    rax,[rip+0xfffffffffffff218]        # 0x713079c8f9a9
    713079c90791:	c5 f8 77             	vzeroupper
    713079c90794:	48 83 c4 18          	add    rsp,0x18
    713079c90798:	c3                   	ret
    713079c90799:	48 83 ec 18          	sub    rsp,0x18
    713079c9079d:	48 8b 9d 28 ff ff ff 	mov    rbx,QWORD PTR [rbp-0xd8]
    713079c907a4:	80 bb e1 00 00 00 00 	cmp    BYTE PTR [rbx+0xe1],0x0
    713079c907ab:	75 0e                	jne    0x713079c907bb
    713079c907ad:	48 83 7b 38 00       	cmp    QWORD PTR [rbx+0x38],0x0
    713079c907b2:	75 07                	jne    0x713079c907bb
    713079c907b4:	48 83 7b 60 00       	cmp    QWORD PTR [rbx+0x60],0x0
    713079c907b9:	74 08                	je     0x713079c907c3
    713079c907bb:	c5 f8 77             	vzeroupper
    713079c907be:	48 83 c4 18          	add    rsp,0x18
    713079c907c2:	c3                   	ret
    713079c907c3:	33 f6                	xor    esi,esi
    713079c907c5:	48 89 73 68          	mov    QWORD PTR [rbx+0x68],rsi
    713079c907c9:	8b b3 18 01 00 00    	mov    esi,DWORD PTR [rbx+0x118]
    713079c907cf:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c907d6:	ff 15 c4 d2 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd2c4]        # 0x71307984daa0
    713079c907dc:	48 81 c3 e8 00 00 00 	add    rbx,0xe8
    713079c907e3:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    713079c907e6:	83 7f 08 00          	cmp    DWORD PTR [rdi+0x8],0x0
    713079c907ea:	74 0e                	je     0x713079c907fa
    713079c907ec:	44 8b 7f 08          	mov    r15d,DWORD PTR [rdi+0x8]
    713079c907f0:	49 c1 e7 04          	shl    r15,0x4
    713079c907f4:	49 83 c7 20          	add    r15,0x20
    713079c907f8:	eb 03                	jmp    0x713079c907fd
    713079c907fa:	45 33 ff             	xor    r15d,r15d
    713079c907fd:	4c 03 7b 28          	add    r15,QWORD PTR [rbx+0x28]
    713079c90801:	70 37                	jo     0x713079c9083a
    713079c90803:	48 bf a8 0f 80 99 28 	movabs rdi,0x712899800fa8
    713079c9080a:	71 00 00 
    713079c9080d:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c90810:	48 8b fb             	mov    rdi,rbx
    713079c90813:	e8 28 f8 5b fd       	call   0x713077250040
    713079c90818:	33 ff                	xor    edi,edi
    713079c9081a:	48 89 7b 28          	mov    QWORD PTR [rbx+0x28],rdi
    713079c9081e:	48 8b 7b 08          	mov    rdi,QWORD PTR [rbx+0x8]
    713079c90822:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    713079c90826:	48 8b bf 80 00 00 00 	mov    rdi,QWORD PTR [rdi+0x80]
    713079c9082d:	49 8b f7             	mov    rsi,r15
    713079c90830:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c90832:	ff 15 10 d6 bb ff    	call   QWORD PTR [rip+0xffffffffffbbd610]        # 0x71307984de48
    713079c90838:	eb 81                	jmp    0x713079c907bb
    713079c9083a:	e8 b1 0d 7f fe       	call   0x7130784815f0
    713079c9083f:	cc                   	int3
