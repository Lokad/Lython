
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5700.bin:     file format binary


Disassembly of section .data:

00007130796efdc0 <.data>:
    7130796efdc0:	55                   	push   rbp
    7130796efdc1:	41 57                	push   r15
    7130796efdc3:	41 56                	push   r14
    7130796efdc5:	41 55                	push   r13
    7130796efdc7:	41 54                	push   r12
    7130796efdc9:	53                   	push   rbx
    7130796efdca:	48 83 ec 58          	sub    rsp,0x58
    7130796efdce:	48 8d ac 24 80 00 00 	lea    rbp,[rsp+0x80]
    7130796efdd5:	00 
    7130796efdd6:	33 c0                	xor    eax,eax
    7130796efdd8:	48 89 45 98          	mov    QWORD PTR [rbp-0x68],rax
    7130796efddc:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    7130796efde1:	c5 7e 7f 45 a0       	vmovdqu YMMWORD PTR [rbp-0x60],ymm8
    7130796efde6:	c5 79 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm8
    7130796efdeb:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    7130796efdef:	4c 8b ff             	mov    r15,rdi
    7130796efdf2:	48 8b de             	mov    rbx,rsi
    7130796efdf5:	44 8b 73 10          	mov    r14d,DWORD PTR [rbx+0x10]
    7130796efdf9:	41 8d 7e dc          	lea    edi,[r14-0x24]
    7130796efdfd:	85 ff                	test   edi,edi
    7130796efdff:	75 2b                	jne    0x7130796efe2c
    7130796efe01:	41 83 fe 25          	cmp    r14d,0x25
    7130796efe05:	0f 8f 07 01 00 00    	jg     0x7130796eff12
    7130796efe0b:	8b 43 08             	mov    eax,DWORD PTR [rbx+0x8]
    7130796efe0e:	41 89 87 d8 00 00 00 	mov    DWORD PTR [r15+0xd8],eax
    7130796efe15:	b8 01 00 00 00       	mov    eax,0x1
    7130796efe1a:	c5 f8 77             	vzeroupper
    7130796efe1d:	48 83 c4 58          	add    rsp,0x58
    7130796efe21:	5b                   	pop    rbx
    7130796efe22:	41 5c                	pop    r12
    7130796efe24:	41 5d                	pop    r13
    7130796efe26:	41 5e                	pop    r14
    7130796efe28:	41 5f                	pop    r15
    7130796efe2a:	5d                   	pop    rbp
    7130796efe2b:	c3                   	ret
    7130796efe2c:	83 ff 0b             	cmp    edi,0xb
    7130796efe2f:	77 18                	ja     0x7130796efe49
    7130796efe31:	8b ff                	mov    edi,edi
    7130796efe33:	48 8d 05 8e 05 00 00 	lea    rax,[rip+0x58e]        # 0x7130796f03c8
    7130796efe3a:	8b 04 b8             	mov    eax,DWORD PTR [rax+rdi*4]
    7130796efe3d:	48 8d 0d b1 ff ff ff 	lea    rcx,[rip+0xffffffffffffffb1]        # 0x7130796efdf5
    7130796efe44:	48 03 c1             	add    rax,rcx
    7130796efe47:	ff e0                	jmp    rax
    7130796efe49:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    7130796efe4d:	be 1b 00 00 00       	mov    esi,0x1b
    7130796efe52:	ba 01 00 00 00       	mov    edx,0x1
    7130796efe57:	ff 15 0b ed db ff    	call   QWORD PTR [rip+0xffffffffffdbed0b]        # 0x7130794aeb68
    7130796efe5d:	8b 7d b8             	mov    edi,DWORD PTR [rbp-0x48]
    7130796efe60:	3b 7d c8             	cmp    edi,DWORD PTR [rbp-0x38]
    7130796efe63:	0f 86 b1 04 00 00    	jbe    0x7130796f031a
    7130796efe69:	e9 a5 04 00 00       	jmp    0x7130796f0313
    7130796efe6e:	48 8b fb             	mov    rdi,rbx
    7130796efe71:	ff 15 51 de f8 ff    	call   QWORD PTR [rip+0xfffffffffff8de51]        # 0x71307967dcc8
    7130796efe77:	44 8b f0             	mov    r14d,eax
    7130796efe7a:	48 bf d8 2d af 79 30 	movabs rdi,0x713079af2dd8
    7130796efe81:	71 00 00 
    7130796efe84:	e8 37 14 f6 7c       	call   0x7130f66512c0
    7130796efe89:	4c 8b e8             	mov    r13,rax
    7130796efe8c:	48 8b fb             	mov    rdi,rbx
    7130796efe8f:	ff 15 13 f8 f8 ff    	call   QWORD PTR [rip+0xfffffffffff8f813]        # 0x71307967f6a8
    7130796efe95:	8b d0                	mov    edx,eax
    7130796efe97:	41 8b f6             	mov    esi,r14d
    7130796efe9a:	49 8b fd             	mov    rdi,r13
    7130796efe9d:	ff 15 a5 f7 15 00    	call   QWORD PTR [rip+0x15f7a5]        # 0x71307984f648
    7130796efea3:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796efea6:	49 8b ff             	mov    rdi,r15
    7130796efea9:	49 8b f5             	mov    rsi,r13
    7130796efeac:	ff 15 ae f7 15 00    	call   QWORD PTR [rip+0x15f7ae]        # 0x71307984f660
    7130796efeb2:	e9 fa 04 00 00       	jmp    0x7130796f03b1
    7130796efeb7:	45 38 3f             	cmp    BYTE PTR [r15],r15b
    7130796efeba:	49 8d bf e8 00 00 00 	lea    rdi,[r15+0xe8]
    7130796efec1:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
    7130796efec4:	ff 15 f6 d9 15 00    	call   QWORD PTR [rip+0x15d9f6]        # 0x71307984d8c0
    7130796efeca:	48 8b f8             	mov    rdi,rax
    7130796efecd:	49 8b 77 70          	mov    rsi,QWORD PTR [r15+0x70]
    7130796efed1:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796efed4:	ff 15 9e f7 15 00    	call   QWORD PTR [rip+0x15f79e]        # 0x71307984f678
    7130796efeda:	85 c0                	test   eax,eax
    7130796efedc:	0f 84 d7 03 00 00    	je     0x7130796f02b9
    7130796efee2:	33 c0                	xor    eax,eax
    7130796efee4:	c5 f8 77             	vzeroupper
    7130796efee7:	48 83 c4 58          	add    rsp,0x58
    7130796efeeb:	5b                   	pop    rbx
    7130796efeec:	41 5c                	pop    r12
    7130796efeee:	41 5d                	pop    r13
    7130796efef0:	41 5e                	pop    r14
    7130796efef2:	41 5f                	pop    r15
    7130796efef4:	5d                   	pop    rbp
    7130796efef5:	c3                   	ret
    7130796efef6:	48 8b fb             	mov    rdi,rbx
    7130796efef9:	48 be 50 fa e0 74 30 	movabs rsi,0x713074e0fa50
    7130796eff00:	71 00 00 
    7130796eff03:	ff 15 2f e0 f8 ff    	call   QWORD PTR [rip+0xfffffffffff8e02f]        # 0x71307967df38
    7130796eff09:	48 8b f8             	mov    rdi,rax
    7130796eff0c:	e8 8f 20 cc 7c       	call   0x7130f63b1fa0
    7130796eff11:	cc                   	int3
    7130796eff12:	41 83 fe 2a          	cmp    r14d,0x2a
    7130796eff16:	0f 84 ef fe ff ff    	je     0x7130796efe0b
    7130796eff1c:	41 83 fe 2f          	cmp    r14d,0x2f
    7130796eff20:	75 d4                	jne    0x7130796efef6
    7130796eff22:	e9 e4 fe ff ff       	jmp    0x7130796efe0b
    7130796eff27:	48 8b fb             	mov    rdi,rbx
    7130796eff2a:	be 29 00 00 00       	mov    esi,0x29
    7130796eff2f:	48 ba 30 5b e1 74 30 	movabs rdx,0x713074e15b30
    7130796eff36:	71 00 00 
    7130796eff39:	ff 15 11 e3 15 00    	call   QWORD PTR [rip+0x15e311]        # 0x71307984e250
    7130796eff3f:	85 c0                	test   eax,eax
    7130796eff41:	7c 5b                	jl     0x7130796eff9e
    7130796eff43:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    7130796eff47:	4c 8b 77 18          	mov    r14,QWORD PTR [rdi+0x18]
    7130796eff4b:	48 8b fb             	mov    rdi,rbx
    7130796eff4e:	be 29 00 00 00       	mov    esi,0x29
    7130796eff53:	48 ba 30 5b e1 74 30 	movabs rdx,0x713074e15b30
    7130796eff5a:	71 00 00 
    7130796eff5d:	ff 15 ed e2 15 00    	call   QWORD PTR [rip+0x15e2ed]        # 0x71307984e250
    7130796eff63:	8b f0                	mov    esi,eax
    7130796eff65:	49 8b fe             	mov    rdi,r14
    7130796eff68:	49 bb 28 1c 27 77 30 	movabs r11,0x713077271c28
    7130796eff6f:	71 00 00 
    7130796eff72:	41 ff 13             	call   QWORD PTR [r11]
    7130796eff75:	48 8b f8             	mov    rdi,rax
    7130796eff78:	49 8b 77 70          	mov    rsi,QWORD PTR [r15+0x70]
    7130796eff7c:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796eff7f:	ff 15 23 f7 15 00    	call   QWORD PTR [rip+0x15f723]        # 0x71307984f6a8
    7130796eff85:	49 8b 7f 70          	mov    rdi,QWORD PTR [r15+0x70]
    7130796eff89:	48 8b 7f 78          	mov    rdi,QWORD PTR [rdi+0x78]
    7130796eff8d:	48 85 ff             	test   rdi,rdi
    7130796eff90:	74 0c                	je     0x7130796eff9e
    7130796eff92:	83 7f 10 00          	cmp    DWORD PTR [rdi+0x10],0x0
    7130796eff96:	7e 06                	jle    0x7130796eff9e
    7130796eff98:	ff 15 52 f7 15 00    	call   QWORD PTR [rip+0x15f752]        # 0x71307984f6f0
    7130796eff9e:	49 8b bf a8 00 00 00 	mov    rdi,QWORD PTR [r15+0xa8]
    7130796effa5:	48 85 ff             	test   rdi,rdi
    7130796effa8:	74 39                	je     0x7130796effe3
    7130796effaa:	83 7f 10 00          	cmp    DWORD PTR [rdi+0x10],0x0
    7130796effae:	7e 33                	jle    0x7130796effe3
    7130796effb0:	ff 15 42 57 f8 ff    	call   QWORD PTR [rip+0xfffffffffff85742]        # 0x7130796756f8
    7130796effb6:	48 8b d8             	mov    rbx,rax
    7130796effb9:	49 8b 7f 70          	mov    rdi,QWORD PTR [r15+0x70]
    7130796effbd:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    7130796effc1:	48 8b 73 08          	mov    rsi,QWORD PTR [rbx+0x8]
    7130796effc5:	48 8d bf 40 01 00 00 	lea    rdi,[rdi+0x140]
    7130796effcc:	e8 6f 00 b6 fd       	call   0x713077250040
    7130796effd1:	48 8b 73 10          	mov    rsi,QWORD PTR [rbx+0x10]
    7130796effd5:	49 8d 7f 78          	lea    rdi,[r15+0x78]
    7130796effd9:	e8 62 00 b6 fd       	call   0x713077250040
    7130796effde:	e9 ff fe ff ff       	jmp    0x7130796efee2
    7130796effe3:	49 8b 7f 70          	mov    rdi,QWORD PTR [r15+0x70]
    7130796effe7:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    7130796effeb:	33 f6                	xor    esi,esi
    7130796effed:	48 89 b7 40 01 00 00 	mov    QWORD PTR [rdi+0x140],rsi
    7130796efff4:	e9 e9 fe ff ff       	jmp    0x7130796efee2
    7130796efff9:	49 8b 77 70          	mov    rsi,QWORD PTR [r15+0x70]
    7130796efffd:	48 8b 76 30          	mov    rsi,QWORD PTR [rsi+0x30]
    7130796f0001:	4c 8b b6 40 01 00 00 	mov    r14,QWORD PTR [rsi+0x140]
    7130796f0008:	4d 85 f6             	test   r14,r14
    7130796f000b:	75 2e                	jne    0x7130796f003b
    7130796f000d:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f0014:	71 00 00 
    7130796f0017:	e8 a4 12 f6 7c       	call   0x7130f66512c0
    7130796f001c:	48 8b d8             	mov    rbx,rax
    7130796f001f:	48 8b fb             	mov    rdi,rbx
    7130796f0022:	48 be f8 47 e1 74 30 	movabs rsi,0x713074e147f8
    7130796f0029:	71 00 00 
    7130796f002c:	ff 15 a6 5e e8 ff    	call   QWORD PTR [rip+0xffffffffffe85ea6]        # 0x713079575ed8
    7130796f0032:	48 8b fb             	mov    rdi,rbx
    7130796f0035:	e8 66 1f cc 7c       	call   0x7130f63b1fa0
    7130796f003a:	cc                   	int3
    7130796f003b:	4d 8d af e8 00 00 00 	lea    r13,[r15+0xe8]
    7130796f0042:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
    7130796f0045:	49 8d bf e8 00 00 00 	lea    rdi,[r15+0xe8]
    7130796f004c:	ff 15 6e d8 15 00    	call   QWORD PTR [rip+0x15d86e]        # 0x71307984d8c0
    7130796f0052:	4c 8b e0             	mov    r12,rax
    7130796f0055:	49 8b 46 50          	mov    rax,QWORD PTR [r14+0x50]
    7130796f0059:	48 89 45 88          	mov    QWORD PTR [rbp-0x78],rax
    7130796f005d:	4d 8b 76 58          	mov    r14,QWORD PTR [r14+0x58]
    7130796f0061:	4d 8b 7f 70          	mov    r15,QWORD PTR [r15+0x70]
    7130796f0065:	48 bf c8 35 49 78 30 	movabs rdi,0x7130784935c8
    7130796f006c:	71 00 00 
    7130796f006f:	e8 4c 12 f6 7c       	call   0x7130f66512c0
    7130796f0074:	48 89 45 90          	mov    QWORD PTR [rbp-0x70],rax
    7130796f0078:	4c 8b 03             	mov    r8,QWORD PTR [rbx]
    7130796f007b:	48 8b 75 88          	mov    rsi,QWORD PTR [rbp-0x78]
    7130796f007f:	49 8b d6             	mov    rdx,r14
    7130796f0082:	49 8b fc             	mov    rdi,r12
    7130796f0085:	49 8b cf             	mov    rcx,r15
    7130796f0088:	ff 15 da f6 15 00    	call   QWORD PTR [rip+0x15f6da]        # 0x71307984f768
    7130796f008e:	48 8b 5d 90          	mov    rbx,QWORD PTR [rbp-0x70]
    7130796f0092:	88 43 08             	mov    BYTE PTR [rbx+0x8],al
    7130796f0095:	48 8b f3             	mov    rsi,rbx
    7130796f0098:	49 8b fd             	mov    rdi,r13
    7130796f009b:	ff 15 5f d7 15 00    	call   QWORD PTR [rip+0x15d75f]        # 0x71307984d800
    7130796f00a1:	e9 3c fe ff ff       	jmp    0x7130796efee2
    7130796f00a6:	49 8b 57 70          	mov    rdx,QWORD PTR [r15+0x70]
    7130796f00aa:	48 8b 52 30          	mov    rdx,QWORD PTR [rdx+0x30]
    7130796f00ae:	4c 8b b2 40 01 00 00 	mov    r14,QWORD PTR [rdx+0x140]
    7130796f00b5:	4d 85 f6             	test   r14,r14
    7130796f00b8:	75 2e                	jne    0x7130796f00e8
    7130796f00ba:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f00c1:	71 00 00 
    7130796f00c4:	e8 f7 11 f6 7c       	call   0x7130f66512c0
    7130796f00c9:	48 8b d8             	mov    rbx,rax
    7130796f00cc:	48 8b fb             	mov    rdi,rbx
    7130796f00cf:	48 be 70 48 e1 74 30 	movabs rsi,0x713074e14870
    7130796f00d6:	71 00 00 
    7130796f00d9:	ff 15 f9 5d e8 ff    	call   QWORD PTR [rip+0xffffffffffe85df9]        # 0x713079575ed8
    7130796f00df:	48 8b fb             	mov    rdi,rbx
    7130796f00e2:	e8 b9 1e cc 7c       	call   0x7130f63b1fa0
    7130796f00e7:	cc                   	int3
    7130796f00e8:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f00eb:	49 8b 77 70          	mov    rsi,QWORD PTR [r15+0x70]
    7130796f00ef:	49 8b fe             	mov    rdi,r14
    7130796f00f2:	ff 15 88 f6 15 00    	call   QWORD PTR [rip+0x15f688]        # 0x71307984f780
    7130796f00f8:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    7130796f00fc:	4c 8b 6f 18          	mov    r13,QWORD PTR [rdi+0x18]
    7130796f0100:	48 8b fb             	mov    rdi,rbx
    7130796f0103:	ff 15 8f db 15 00    	call   QWORD PTR [rip+0x15db8f]        # 0x71307984dc98
    7130796f0109:	8b f0                	mov    esi,eax
    7130796f010b:	49 8b fd             	mov    rdi,r13
    7130796f010e:	49 bb 30 1c 27 77 30 	movabs r11,0x713077271c30
    7130796f0115:	71 00 00 
    7130796f0118:	41 ff 13             	call   QWORD PTR [r11]
    7130796f011b:	4c 8b e8             	mov    r13,rax
    7130796f011e:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    7130796f0121:	48 89 3c 24          	mov    QWORD PTR [rsp],rdi
    7130796f0125:	49 8b 7f 08          	mov    rdi,QWORD PTR [r15+0x8]
    7130796f0129:	49 8b 77 10          	mov    rsi,QWORD PTR [r15+0x10]
    7130796f012d:	49 8b 57 18          	mov    rdx,QWORD PTR [r15+0x18]
    7130796f0131:	4d 8b 4f 70          	mov    r9,QWORD PTR [r15+0x70]
    7130796f0135:	49 8b cd             	mov    rcx,r13
    7130796f0138:	4d 8b c6             	mov    r8,r14
    7130796f013b:	ff 15 a7 dc 15 00    	call   QWORD PTR [rip+0x15dca7]        # 0x71307984dde8
    7130796f0141:	49 8b ff             	mov    rdi,r15
    7130796f0144:	ff 15 4e f6 15 00    	call   QWORD PTR [rip+0x15f64e]        # 0x71307984f798
    7130796f014a:	48 8b f8             	mov    rdi,rax
    7130796f014d:	39 3f                	cmp    DWORD PTR [rdi],edi
    7130796f014f:	ff 15 5b f6 15 00    	call   QWORD PTR [rip+0x15f65b]        # 0x71307984f7b0
    7130796f0155:	48 8b d8             	mov    rbx,rax
    7130796f0158:	4d 8b 77 70          	mov    r14,QWORD PTR [r15+0x70]
    7130796f015c:	49 83 7e 78 00       	cmp    QWORD PTR [r14+0x78],0x0
    7130796f0161:	75 27                	jne    0x7130796f018a
    7130796f0163:	48 bf 80 3f af 79 30 	movabs rdi,0x713079af3f80
    7130796f016a:	71 00 00 
    7130796f016d:	e8 4e 11 f6 7c       	call   0x7130f66512c0
    7130796f0172:	4c 8b e0             	mov    r12,rax
    7130796f0175:	49 8b fc             	mov    rdi,r12
    7130796f0178:	ff 15 4a f6 15 00    	call   QWORD PTR [rip+0x15f64a]        # 0x71307984f7c8
    7130796f017e:	49 8d 7e 78          	lea    rdi,[r14+0x78]
    7130796f0182:	49 8b f4             	mov    rsi,r12
    7130796f0185:	e8 b6 fe b5 fd       	call   0x713077250040
    7130796f018a:	49 8b 7f 70          	mov    rdi,QWORD PTR [r15+0x70]
    7130796f018e:	4c 8b 7f 78          	mov    r15,QWORD PTR [rdi+0x78]
    7130796f0192:	48 8b 7b 18          	mov    rdi,QWORD PTR [rbx+0x18]
    7130796f0196:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
    7130796f019a:	44 8b 75 d4          	mov    r14d,DWORD PTR [rbp-0x2c]
    7130796f019e:	48 8b 7b 20          	mov    rdi,QWORD PTR [rbx+0x20]
    7130796f01a2:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
    7130796f01a6:	48 8d 7d d0          	lea    rdi,[rbp-0x30]
    7130796f01aa:	be ff ff ff 7f       	mov    esi,0x7fffffff
    7130796f01af:	ff 15 9b c8 15 00    	call   QWORD PTR [rip+0x15c89b]        # 0x71307984ca50
    7130796f01b5:	44 8b c0             	mov    r8d,eax
    7130796f01b8:	48 8d 7d 98          	lea    rdi,[rbp-0x68]
    7130796f01bc:	49 8b d5             	mov    rdx,r13
    7130796f01bf:	41 8b ce             	mov    ecx,r14d
    7130796f01c2:	48 be 50 37 af 79 30 	movabs rsi,0x713079af3750
    7130796f01c9:	71 00 00 
    7130796f01cc:	ff 15 56 f6 15 00    	call   QWORD PTR [rip+0x15f656]        # 0x71307984f828
    7130796f01d2:	48 8b 75 98          	mov    rsi,QWORD PTR [rbp-0x68]
    7130796f01d6:	48 8b 55 a0          	mov    rdx,QWORD PTR [rbp-0x60]
    7130796f01da:	49 8b ff             	mov    rdi,r15
    7130796f01dd:	39 3f                	cmp    DWORD PTR [rdi],edi
    7130796f01df:	ff 15 5b f6 15 00    	call   QWORD PTR [rip+0x15f65b]        # 0x71307984f840
    7130796f01e5:	e9 f8 fc ff ff       	jmp    0x7130796efee2
    7130796f01ea:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    7130796f01ed:	49 8b 77 70          	mov    rsi,QWORD PTR [r15+0x70]
    7130796f01f1:	ff 15 61 f6 15 00    	call   QWORD PTR [rip+0x15f661]        # 0x71307984f858
    7130796f01f7:	cc                   	int3
    7130796f01f8:	49 83 7f 78 00       	cmp    QWORD PTR [r15+0x78],0x0
    7130796f01fd:	74 30                	je     0x7130796f022f
    7130796f01ff:	49 8b 7f 78          	mov    rdi,QWORD PTR [r15+0x78]
    7130796f0203:	48 8b 7f 08          	mov    rdi,QWORD PTR [rdi+0x8]
    7130796f0207:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
    7130796f020b:	48 8d 7d d0          	lea    rdi,[rbp-0x30]
    7130796f020f:	be ff ff ff ff       	mov    esi,0xffffffff
    7130796f0214:	ff 15 36 c8 15 00    	call   QWORD PTR [rip+0x15c836]        # 0x71307984ca50
    7130796f021a:	44 8b f0             	mov    r14d,eax
    7130796f021d:	48 8b fb             	mov    rdi,rbx
    7130796f0220:	ff 15 e2 f4 f8 ff    	call   QWORD PTR [rip+0xfffffffffff8f4e2]        # 0x71307967f708
    7130796f0226:	44 3b f0             	cmp    r14d,eax
    7130796f0229:	0f 85 8a 00 00 00    	jne    0x7130796f02b9
    7130796f022f:	49 8b 77 78          	mov    rsi,QWORD PTR [r15+0x78]
    7130796f0233:	48 bf d8 2d af 79 30 	movabs rdi,0x713079af2dd8
    7130796f023a:	71 00 00 
    7130796f023d:	e8 de c4 ff ff       	call   0x7130796ec720
    7130796f0242:	48 85 c0             	test   rax,rax
    7130796f0245:	74 14                	je     0x7130796f025b
    7130796f0247:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f024a:	49 8b ff             	mov    rdi,r15
    7130796f024d:	48 8b f0             	mov    rsi,rax
    7130796f0250:	ff 15 0a f4 15 00    	call   QWORD PTR [rip+0x15f40a]        # 0x71307984f660
    7130796f0256:	e9 56 01 00 00       	jmp    0x7130796f03b1
    7130796f025b:	49 8b 77 78          	mov    rsi,QWORD PTR [r15+0x78]
    7130796f025f:	48 bf 78 45 af 79 30 	movabs rdi,0x713079af4578
    7130796f0266:	71 00 00 
    7130796f0269:	e8 b2 c4 ff ff       	call   0x7130796ec720
    7130796f026e:	48 85 c0             	test   rax,rax
    7130796f0271:	74 34                	je     0x7130796f02a7
    7130796f0273:	49 8b 7f 70          	mov    rdi,QWORD PTR [r15+0x70]
    7130796f0277:	4c 8b 77 30          	mov    r14,QWORD PTR [rdi+0x30]
    7130796f027b:	49 8b bf a8 00 00 00 	mov    rdi,QWORD PTR [r15+0xa8]
    7130796f0282:	48 85 ff             	test   rdi,rdi
    7130796f0285:	74 06                	je     0x7130796f028d
    7130796f0287:	83 7f 10 00          	cmp    DWORD PTR [rdi+0x10],0x0
    7130796f028b:	7f 04                	jg     0x7130796f0291
    7130796f028d:	33 f6                	xor    esi,esi
    7130796f028f:	eb 0a                	jmp    0x7130796f029b
    7130796f0291:	ff 15 61 54 f8 ff    	call   QWORD PTR [rip+0xfffffffffff85461]        # 0x7130796756f8
    7130796f0297:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
    7130796f029b:	49 8d be 40 01 00 00 	lea    rdi,[r14+0x140]
    7130796f02a2:	e8 99 fd b5 fd       	call   0x713077250040
    7130796f02a7:	49 83 7f 78 00       	cmp    QWORD PTR [r15+0x78],0x0
    7130796f02ac:	74 0b                	je     0x7130796f02b9
    7130796f02ae:	49 8b 7f 78          	mov    rdi,QWORD PTR [r15+0x78]
    7130796f02b2:	ff 15 d0 f5 15 00    	call   QWORD PTR [rip+0x15f5d0]        # 0x71307984f888
    7130796f02b8:	cc                   	int3
    7130796f02b9:	48 8b fb             	mov    rdi,rbx
    7130796f02bc:	ff 15 06 da f8 ff    	call   QWORD PTR [rip+0xfffffffffff8da06]        # 0x71307967dcc8
    7130796f02c2:	41 89 87 d8 00 00 00 	mov    DWORD PTR [r15+0xd8],eax
    7130796f02c9:	e9 47 fb ff ff       	jmp    0x7130796efe15
    7130796f02ce:	45 38 3f             	cmp    BYTE PTR [r15],r15b
    7130796f02d1:	49 8d bf e8 00 00 00 	lea    rdi,[r15+0xe8]
    7130796f02d8:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
    7130796f02db:	ff 15 df d5 15 00    	call   QWORD PTR [rip+0x15d5df]        # 0x71307984d8c0
    7130796f02e1:	48 8b f0             	mov    rsi,rax
    7130796f02e4:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f02e7:	49 8b ff             	mov    rdi,r15
    7130796f02ea:	ff 15 b0 f5 15 00    	call   QWORD PTR [rip+0x15f5b0]        # 0x71307984f8a0
    7130796f02f0:	e9 bc 00 00 00       	jmp    0x7130796f03b1
    7130796f02f5:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
    7130796f02f8:	48 be b8 16 80 99 28 	movabs rsi,0x7128998016b8
    7130796f02ff:	71 00 00 
    7130796f0302:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    7130796f0305:	49 8b ff             	mov    rdi,r15
    7130796f0308:	ff 15 92 f5 15 00    	call   QWORD PTR [rip+0x15f592]        # 0x71307984f8a0
    7130796f030e:	e9 9e 00 00 00       	jmp    0x7130796f03b1
    7130796f0313:	ff 15 cf 72 f8 ff    	call   QWORD PTR [rip+0xfffffffffff872cf]        # 0x7130796775e8
    7130796f0319:	cc                   	int3
    7130796f031a:	48 8b 75 c0          	mov    rsi,QWORD PTR [rbp-0x40]
    7130796f031e:	8b c7                	mov    eax,edi
    7130796f0320:	48 8d 34 46          	lea    rsi,[rsi+rax*2]
    7130796f0324:	8b 45 c8             	mov    eax,DWORD PTR [rbp-0x38]
    7130796f0327:	2b c7                	sub    eax,edi
    7130796f0329:	83 f8 1b             	cmp    eax,0x1b
    7130796f032c:	72 31                	jb     0x7130796f035f
    7130796f032e:	c5 fc 10 05 ca 00 00 	vmovups ymm0,YMMWORD PTR [rip+0xca]        # 0x7130796f0400
    7130796f0335:	00 
    7130796f0336:	c5 fc 11 06          	vmovups YMMWORD PTR [rsi],ymm0
    7130796f033a:	c5 f8 10 05 de 00 00 	vmovups xmm0,XMMWORD PTR [rip+0xde]        # 0x7130796f0420
    7130796f0341:	00 
    7130796f0342:	c5 f8 11 46 20       	vmovups XMMWORD PTR [rsi+0x20],xmm0
    7130796f0347:	c7 46 30 65 00 3a 00 	mov    DWORD PTR [rsi+0x30],0x3a0065
    7130796f034e:	66 c7 46 34 20 00    	mov    WORD PTR [rsi+0x34],0x20
    7130796f0354:	8b 7d b8             	mov    edi,DWORD PTR [rbp-0x48]
    7130796f0357:	83 c7 1b             	add    edi,0x1b
    7130796f035a:	89 7d b8             	mov    DWORD PTR [rbp-0x48],edi
    7130796f035d:	eb 14                	jmp    0x7130796f0373
    7130796f035f:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    7130796f0363:	48 be 48 42 e1 74 30 	movabs rsi,0x713074e14248
    7130796f036a:	71 00 00 
    7130796f036d:	ff 15 15 42 42 00    	call   QWORD PTR [rip+0x424215]        # 0x713079b14588
    7130796f0373:	8b 73 10             	mov    esi,DWORD PTR [rbx+0x10]
    7130796f0376:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    7130796f037a:	ff 15 10 f3 f8 ff    	call   QWORD PTR [rip+0xfffffffffff8f310]        # 0x71307967f690
    7130796f0380:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    7130796f0387:	71 00 00 
    7130796f038a:	e8 31 0f f6 7c       	call   0x7130f66512c0
    7130796f038f:	48 8b d8             	mov    rbx,rax
    7130796f0392:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    7130796f0396:	ff 15 fc e7 db ff    	call   QWORD PTR [rip+0xffffffffffdbe7fc]        # 0x7130794aeb98
    7130796f039c:	48 8b f0             	mov    rsi,rax
    7130796f039f:	48 8b fb             	mov    rdi,rbx
    7130796f03a2:	ff 15 30 5b e8 ff    	call   QWORD PTR [rip+0xffffffffffe85b30]        # 0x713079575ed8
    7130796f03a8:	48 8b fb             	mov    rdi,rbx
    7130796f03ab:	e8 f0 1b cc 7c       	call   0x7130f63b1fa0
    7130796f03b0:	cc                   	int3
    7130796f03b1:	0f b6 c0             	movzx  eax,al
    7130796f03b4:	c5 f8 77             	vzeroupper
    7130796f03b7:	48 83 c4 58          	add    rsp,0x58
    7130796f03bb:	5b                   	pop    rbx
    7130796f03bc:	41 5c                	pop    r12
    7130796f03be:	41 5d                	pop    r13
    7130796f03c0:	41 5e                	pop    r14
    7130796f03c2:	41 5f                	pop    r15
    7130796f03c4:	5d                   	pop    rbp
    7130796f03c5:	c3                   	ret
