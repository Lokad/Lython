
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5706.bin:     file format binary


Disassembly of section .data:

00007130796f0580 <.data>:
    7130796f0580:	55                   	push   rbp
    7130796f0581:	41 57                	push   r15
    7130796f0583:	41 56                	push   r14
    7130796f0585:	41 55                	push   r13
    7130796f0587:	41 54                	push   r12
    7130796f0589:	53                   	push   rbx
    7130796f058a:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    7130796f0591:	48 8d ac 24 b0 00 00 	lea    rbp,[rsp+0xb0]
    7130796f0598:	00 
    7130796f0599:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    7130796f059e:	62 71 7e 48 7f 85 70 	vmovdqu32 ZMMWORD PTR [rbp-0x90],zmm8
    7130796f05a5:	ff ff ff 
    7130796f05a8:	c5 79 7f 45 b0       	vmovdqa XMMWORD PTR [rbp-0x50],xmm8
    7130796f05ad:	33 c0                	xor    eax,eax
    7130796f05af:	48 89 45 c0          	mov    QWORD PTR [rbp-0x40],rax
    7130796f05b3:	4c 89 8d 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r9
    7130796f05ba:	48 8b df             	mov    rbx,rdi
    7130796f05bd:	44 8b f6             	mov    r14d,esi
    7130796f05c0:	4c 8b fa             	mov    r15,rdx
    7130796f05c3:	44 8b e9             	mov    r13d,ecx
    7130796f05c6:	4d 8b e0             	mov    r12,r8
    7130796f05c9:	4d 85 e4             	test   r12,r12
    7130796f05cc:	0f 84 6d 04 00 00    	je     0x7130796f0a3f
    7130796f05d2:	45 85 f6             	test   r14d,r14d
    7130796f05d5:	0f 84 9c 00 00 00    	je     0x7130796f0677
    7130796f05db:	48 85 db             	test   rbx,rbx
    7130796f05de:	0f 84 c6 02 00 00    	je     0x7130796f08aa
    7130796f05e4:	41 83 fe ff          	cmp    r14d,0xffffffff
    7130796f05e8:	0f 84 7c 02 00 00    	je     0x7130796f086a
    7130796f05ee:	33 c0                	xor    eax,eax
    7130796f05f0:	8b 4b 08             	mov    ecx,DWORD PTR [rbx+0x8]
    7130796f05f3:	ff c9                	dec    ecx
    7130796f05f5:	3b 4b 08             	cmp    ecx,DWORD PTR [rbx+0x8]
    7130796f05f8:	0f 83 d3 03 00 00    	jae    0x7130796f09d1
    7130796f05fe:	8b f9                	mov    edi,ecx
    7130796f0600:	4c 8b 44 fb 10       	mov    r8,QWORD PTR [rbx+rdi*8+0x10]
    7130796f0605:	8b f8                	mov    edi,eax
    7130796f0607:	33 f6                	xor    esi,esi
    7130796f0609:	f3 49 0f bd f0       	lzcnt  rsi,r8
    7130796f060e:	c1 ee 03             	shr    esi,0x3
    7130796f0611:	8b d6                	mov    edx,esi
    7130796f0613:	f7 da                	neg    edx
    7130796f0615:	83 c2 07             	add    edx,0x7
    7130796f0618:	33 f6                	xor    esi,esi
    7130796f061a:	85 d2                	test   edx,edx
    7130796f061c:	0f 4f f2             	cmovg  esi,edx
    7130796f061f:	8d 14 f5 00 00 00 00 	lea    edx,[rsi*8+0x0]
    7130796f0626:	c4 c2 eb f7 d0       	shrx   rdx,r8,rdx
    7130796f062b:	0f b6 d2             	movzx  edx,dl
    7130796f062e:	81 e2 80 00 00 00    	and    edx,0x80
    7130796f0634:	81 e7 80 00 00 00    	and    edi,0x80
    7130796f063a:	3b d7                	cmp    edx,edi
    7130796f063c:	40 0f 95 c7          	setne  dil
    7130796f0640:	40 0f b6 ff          	movzx  edi,dil
    7130796f0644:	85 ff                	test   edi,edi
    7130796f0646:	40 0f 95 c7          	setne  dil
    7130796f064a:	40 0f b6 ff          	movzx  edi,dil
    7130796f064e:	8d 7c 3e 01          	lea    edi,[rsi+rdi*1+0x1]
    7130796f0652:	48 85 db             	test   rbx,rbx
    7130796f0655:	74 17                	je     0x7130796f066e
    7130796f0657:	8b 53 08             	mov    edx,DWORD PTR [rbx+0x8]
    7130796f065a:	83 ea 01             	sub    edx,0x1
    7130796f065d:	6b d2 08             	imul   edx,edx,0x8
    7130796f0660:	0f 80 71 03 00 00    	jo     0x7130796f09d7
    7130796f0666:	03 fa                	add    edi,edx
    7130796f0668:	0f 80 69 03 00 00    	jo     0x7130796f09d7
    7130796f066e:	83 ff 08             	cmp    edi,0x8
    7130796f0671:	0f 8d f9 02 00 00    	jge    0x7130796f0970
    7130796f0677:	45 85 ed             	test   r13d,r13d
    7130796f067a:	0f 84 97 00 00 00    	je     0x7130796f0717
    7130796f0680:	4d 85 ff             	test   r15,r15
    7130796f0683:	0f 85 5c 02 00 00    	jne    0x7130796f08e5
    7130796f0689:	b8 ff 00 00 00       	mov    eax,0xff
    7130796f068e:	45 33 c0             	xor    r8d,r8d
    7130796f0691:	45 85 ed             	test   r13d,r13d
    7130796f0694:	41 0f 4d c0          	cmovge eax,r8d
    7130796f0698:	8b f8                	mov    edi,eax
    7130796f069a:	4d 63 c5             	movsxd r8,r13d
    7130796f069d:	85 ff                	test   edi,edi
    7130796f069f:	0f 85 ac 02 00 00    	jne    0x7130796f0951
    7130796f06a5:	33 c0                	xor    eax,eax
    7130796f06a7:	f3 49 0f bd c0       	lzcnt  rax,r8
    7130796f06ac:	c1 e8 03             	shr    eax,0x3
    7130796f06af:	8b f0                	mov    esi,eax
    7130796f06b1:	f7 de                	neg    esi
    7130796f06b3:	83 c6 07             	add    esi,0x7
    7130796f06b6:	33 c0                	xor    eax,eax
    7130796f06b8:	85 f6                	test   esi,esi
    7130796f06ba:	0f 4f c6             	cmovg  eax,esi
    7130796f06bd:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7130796f06c4:	c4 c2 cb f7 f0       	shrx   rsi,r8,rsi
    7130796f06c9:	40 0f b6 f6          	movzx  esi,sil
    7130796f06cd:	81 e6 80 00 00 00    	and    esi,0x80
    7130796f06d3:	81 e7 80 00 00 00    	and    edi,0x80
    7130796f06d9:	3b f7                	cmp    esi,edi
    7130796f06db:	40 0f 95 c7          	setne  dil
    7130796f06df:	40 0f b6 ff          	movzx  edi,dil
    7130796f06e3:	85 ff                	test   edi,edi
    7130796f06e5:	40 0f 95 c7          	setne  dil
    7130796f06e9:	40 0f b6 ff          	movzx  edi,dil
    7130796f06ed:	8d 7c 38 01          	lea    edi,[rax+rdi*1+0x1]
    7130796f06f1:	4d 85 ff             	test   r15,r15
    7130796f06f4:	74 18                	je     0x7130796f070e
    7130796f06f6:	41 8b 77 08          	mov    esi,DWORD PTR [r15+0x8]
    7130796f06fa:	83 ee 01             	sub    esi,0x1
    7130796f06fd:	6b f6 08             	imul   esi,esi,0x8
    7130796f0700:	0f 80 d1 02 00 00    	jo     0x7130796f09d7
    7130796f0706:	03 fe                	add    edi,esi
    7130796f0708:	0f 80 c9 02 00 00    	jo     0x7130796f09d7
    7130796f070e:	83 ff 08             	cmp    edi,0x8
    7130796f0711:	0f 8d 59 02 00 00    	jge    0x7130796f0970
    7130796f0717:	45 33 e4             	xor    r12d,r12d
    7130796f071a:	4c 89 a5 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],r12
    7130796f0721:	48 8b f3             	mov    rsi,rbx
    7130796f0724:	49 0b f7             	or     rsi,r15
    7130796f0727:	75 53                	jne    0x7130796f077c
    7130796f0729:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
    7130796f072d:	c5 fa 7f 45 90       	vmovdqu XMMWORD PTR [rbp-0x70],xmm0
    7130796f0732:	49 63 f6             	movsxd rsi,r14d
    7130796f0735:	49 63 fd             	movsxd rdi,r13d
    7130796f0738:	48 03 f7             	add    rsi,rdi
    7130796f073b:	48 8d 7d 90          	lea    rdi,[rbp-0x70]
    7130796f073f:	ff 15 eb f7 15 00    	call   QWORD PTR [rip+0x15f7eb]        # 0x71307984ff30
    7130796f0745:	4c 8b 7d 90          	mov    r15,QWORD PTR [rbp-0x70]
    7130796f0749:	8b 5d 98             	mov    ebx,DWORD PTR [rbp-0x68]
    7130796f074c:	4d 85 e4             	test   r12,r12
    7130796f074f:	0f 85 af 00 00 00    	jne    0x7130796f0804
    7130796f0755:	48 bf 90 f0 68 79 30 	movabs rdi,0x71307968f090
    7130796f075c:	71 00 00 
    7130796f075f:	e8 5c 0b f6 7c       	call   0x7130f66512c0
    7130796f0764:	4c 8b f0             	mov    r14,rax
    7130796f0767:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    7130796f076b:	49 8b f7             	mov    rsi,r15
    7130796f076e:	e8 cd f8 b5 fd       	call   0x713077250040
    7130796f0773:	41 89 5e 10          	mov    DWORD PTR [r14+0x10],ebx
    7130796f0777:	e9 e0 00 00 00       	jmp    0x7130796f085c
    7130796f077c:	41 8b fe             	mov    edi,r14d
    7130796f077f:	c1 ef 1f             	shr    edi,0x1f
    7130796f0782:	41 8b f5             	mov    esi,r13d
    7130796f0785:	c1 ee 1f             	shr    esi,0x1f
    7130796f0788:	3b fe                	cmp    edi,esi
    7130796f078a:	75 39                	jne    0x7130796f07c5
    7130796f078c:	48 85 db             	test   rbx,rbx
    7130796f078f:	75 06                	jne    0x7130796f0797
    7130796f0791:	33 ff                	xor    edi,edi
    7130796f0793:	33 f6                	xor    esi,esi
    7130796f0795:	eb 07                	jmp    0x7130796f079e
    7130796f0797:	48 8d 7b 10          	lea    rdi,[rbx+0x10]
    7130796f079b:	8b 73 08             	mov    esi,DWORD PTR [rbx+0x8]
    7130796f079e:	4d 85 ff             	test   r15,r15
    7130796f07a1:	75 07                	jne    0x7130796f07aa
    7130796f07a3:	33 c9                	xor    ecx,ecx
    7130796f07a5:	45 33 c0             	xor    r8d,r8d
    7130796f07a8:	eb 08                	jmp    0x7130796f07b2
    7130796f07aa:	49 8d 4f 10          	lea    rcx,[r15+0x10]
    7130796f07ae:	45 8b 47 08          	mov    r8d,DWORD PTR [r15+0x8]
    7130796f07b2:	41 8b d6             	mov    edx,r14d
    7130796f07b5:	45 8b cd             	mov    r9d,r13d
    7130796f07b8:	ff 15 32 48 49 00    	call   QWORD PTR [rip+0x494832]        # 0x713079b84ff0
    7130796f07be:	4c 8b f8             	mov    r15,rax
    7130796f07c1:	8b da                	mov    ebx,edx
    7130796f07c3:	eb 87                	jmp    0x7130796f074c
    7130796f07c5:	48 85 db             	test   rbx,rbx
    7130796f07c8:	75 06                	jne    0x7130796f07d0
    7130796f07ca:	33 ff                	xor    edi,edi
    7130796f07cc:	33 f6                	xor    esi,esi
    7130796f07ce:	eb 07                	jmp    0x7130796f07d7
    7130796f07d0:	48 8d 7b 10          	lea    rdi,[rbx+0x10]
    7130796f07d4:	8b 73 08             	mov    esi,DWORD PTR [rbx+0x8]
    7130796f07d7:	4d 85 ff             	test   r15,r15
    7130796f07da:	75 07                	jne    0x7130796f07e3
    7130796f07dc:	33 c9                	xor    ecx,ecx
    7130796f07de:	45 33 c0             	xor    r8d,r8d
    7130796f07e1:	eb 08                	jmp    0x7130796f07eb
    7130796f07e3:	49 8d 4f 10          	lea    rcx,[r15+0x10]
    7130796f07e7:	45 8b 47 08          	mov    r8d,DWORD PTR [r15+0x8]
    7130796f07eb:	45 8b cd             	mov    r9d,r13d
    7130796f07ee:	41 f7 d9             	neg    r9d
    7130796f07f1:	41 8b d6             	mov    edx,r14d
    7130796f07f4:	ff 15 0e 48 49 00    	call   QWORD PTR [rip+0x49480e]        # 0x713079b85008
    7130796f07fa:	4c 8b f8             	mov    r15,rax
    7130796f07fd:	8b da                	mov    ebx,edx
    7130796f07ff:	e9 48 ff ff ff       	jmp    0x7130796f074c
    7130796f0804:	49 8b ff             	mov    rdi,r15
    7130796f0807:	8b f3                	mov    esi,ebx
    7130796f0809:	ff 15 e1 e8 15 00    	call   QWORD PTR [rip+0x15e8e1]        # 0x71307984f0f0
    7130796f080f:	48 89 45 80          	mov    QWORD PTR [rbp-0x80],rax
    7130796f0813:	48 89 55 88          	mov    QWORD PTR [rbp-0x78],rdx
    7130796f0817:	48 8d 7d 80          	lea    rdi,[rbp-0x80]
    7130796f081b:	ff 15 e7 e8 15 00    	call   QWORD PTR [rip+0x15e8e7]        # 0x71307984f108
    7130796f0821:	48 83 f8 40          	cmp    rax,0x40
    7130796f0825:	0f 8e 2a ff ff ff    	jle    0x7130796f0755
    7130796f082b:	4c 89 bd 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],r15
    7130796f0832:	89 9d 78 ff ff ff    	mov    DWORD PTR [rbp-0x88],ebx
    7130796f0838:	48 8d bd 70 ff ff ff 	lea    rdi,[rbp-0x90]
    7130796f083f:	33 f6                	xor    esi,esi
    7130796f0841:	ff 15 e1 f5 15 00    	call   QWORD PTR [rip+0x15f5e1]        # 0x71307984fe28
    7130796f0847:	48 63 f0             	movsxd rsi,eax
    7130796f084a:	48 83 c6 20          	add    rsi,0x20
    7130796f084e:	49 8b fc             	mov    rdi,r12
    7130796f0851:	ff 15 d1 f2 db ff    	call   QWORD PTR [rip+0xffffffffffdbf2d1]        # 0x7130794afb28
    7130796f0857:	e9 f9 fe ff ff       	jmp    0x7130796f0755
    7130796f085c:	4d 85 e4             	test   r12,r12
    7130796f085f:	0f 84 ec 01 00 00    	je     0x7130796f0a51
    7130796f0865:	e9 dd 01 00 00       	jmp    0x7130796f0a47
    7130796f086a:	c7 45 cc ff 00 00 00 	mov    DWORD PTR [rbp-0x34],0xff
    7130796f0871:	48 8d 7b 10          	lea    rdi,[rbx+0x10]
    7130796f0875:	8b 53 08             	mov    edx,DWORD PTR [rbx+0x8]
    7130796f0878:	33 f6                	xor    esi,esi
    7130796f087a:	ff 15 98 43 49 00    	call   QWORD PTR [rip+0x494398]        # 0x713079b84c18
    7130796f0880:	8b 4b 08             	mov    ecx,DWORD PTR [rbx+0x8]
    7130796f0883:	ff c9                	dec    ecx
    7130796f0885:	3b 4b 08             	cmp    ecx,DWORD PTR [rbx+0x8]
    7130796f0888:	0f 83 43 01 00 00    	jae    0x7130796f09d1
    7130796f088e:	8b f9                	mov    edi,ecx
    7130796f0890:	48 8b 7c fb 10       	mov    rdi,QWORD PTR [rbx+rdi*8+0x10]
    7130796f0895:	4c 8b c7             	mov    r8,rdi
    7130796f0898:	49 f7 d0             	not    r8
    7130796f089b:	49 8d 78 01          	lea    rdi,[r8+0x1]
    7130796f089f:	3b c8                	cmp    ecx,eax
    7130796f08a1:	4c 0f 44 c7          	cmove  r8,rdi
    7130796f08a5:	8b 7d cc             	mov    edi,DWORD PTR [rbp-0x34]
    7130796f08a8:	eb 14                	jmp    0x7130796f08be
    7130796f08aa:	b8 ff 00 00 00       	mov    eax,0xff
    7130796f08af:	45 33 c0             	xor    r8d,r8d
    7130796f08b2:	45 85 f6             	test   r14d,r14d
    7130796f08b5:	41 0f 4d c0          	cmovge eax,r8d
    7130796f08b9:	8b f8                	mov    edi,eax
    7130796f08bb:	4d 63 c6             	movsxd r8,r14d
    7130796f08be:	85 ff                	test   edi,edi
    7130796f08c0:	0f 84 41 fd ff ff    	je     0x7130796f0607
    7130796f08c6:	49 8b d0             	mov    rdx,r8
    7130796f08c9:	48 f7 d2             	not    rdx
    7130796f08cc:	f3 48 0f bd d2       	lzcnt  rdx,rdx
    7130796f08d1:	c1 ea 03             	shr    edx,0x3
    7130796f08d4:	f7 da                	neg    edx
    7130796f08d6:	83 c2 07             	add    edx,0x7
    7130796f08d9:	33 f6                	xor    esi,esi
    7130796f08db:	85 d2                	test   edx,edx
    7130796f08dd:	0f 4f f2             	cmovg  esi,edx
    7130796f08e0:	e9 3a fd ff ff       	jmp    0x7130796f061f
    7130796f08e5:	41 83 fd ff          	cmp    r13d,0xffffffff
    7130796f08e9:	74 20                	je     0x7130796f090b
    7130796f08eb:	33 c0                	xor    eax,eax
    7130796f08ed:	41 8b 4f 08          	mov    ecx,DWORD PTR [r15+0x8]
    7130796f08f1:	ff c9                	dec    ecx
    7130796f08f3:	41 3b 4f 08          	cmp    ecx,DWORD PTR [r15+0x8]
    7130796f08f7:	0f 83 d4 00 00 00    	jae    0x7130796f09d1
    7130796f08fd:	8b f9                	mov    edi,ecx
    7130796f08ff:	4d 8b 44 ff 10       	mov    r8,QWORD PTR [r15+rdi*8+0x10]
    7130796f0904:	8b f8                	mov    edi,eax
    7130796f0906:	e9 9a fd ff ff       	jmp    0x7130796f06a5
    7130796f090b:	c7 45 c8 ff 00 00 00 	mov    DWORD PTR [rbp-0x38],0xff
    7130796f0912:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    7130796f0916:	41 8b 57 08          	mov    edx,DWORD PTR [r15+0x8]
    7130796f091a:	33 f6                	xor    esi,esi
    7130796f091c:	ff 15 f6 42 49 00    	call   QWORD PTR [rip+0x4942f6]        # 0x713079b84c18
    7130796f0922:	41 8b 4f 08          	mov    ecx,DWORD PTR [r15+0x8]
    7130796f0926:	ff c9                	dec    ecx
    7130796f0928:	41 3b 4f 08          	cmp    ecx,DWORD PTR [r15+0x8]
    7130796f092c:	0f 83 9f 00 00 00    	jae    0x7130796f09d1
    7130796f0932:	8b f9                	mov    edi,ecx
    7130796f0934:	49 8b 7c ff 10       	mov    rdi,QWORD PTR [r15+rdi*8+0x10]
    7130796f0939:	4c 8b c7             	mov    r8,rdi
    7130796f093c:	49 f7 d0             	not    r8
    7130796f093f:	49 8d 78 01          	lea    rdi,[r8+0x1]
    7130796f0943:	3b c8                	cmp    ecx,eax
    7130796f0945:	4c 0f 44 c7          	cmove  r8,rdi
    7130796f0949:	8b 7d c8             	mov    edi,DWORD PTR [rbp-0x38]
    7130796f094c:	e9 4c fd ff ff       	jmp    0x7130796f069d
    7130796f0951:	49 8b f0             	mov    rsi,r8
    7130796f0954:	48 f7 d6             	not    rsi
    7130796f0957:	f3 48 0f bd f6       	lzcnt  rsi,rsi
    7130796f095c:	c1 ee 03             	shr    esi,0x3
    7130796f095f:	f7 de                	neg    esi
    7130796f0961:	83 c6 07             	add    esi,0x7
    7130796f0964:	33 c0                	xor    eax,eax
    7130796f0966:	85 f6                	test   esi,esi
    7130796f0968:	0f 4f c6             	cmovg  eax,esi
    7130796f096b:	e9 4d fd ff ff       	jmp    0x7130796f06bd
    7130796f0970:	48 8b fb             	mov    rdi,rbx
    7130796f0973:	41 8b f6             	mov    esi,r14d
    7130796f0976:	ff 15 74 e7 15 00    	call   QWORD PTR [rip+0x15e774]        # 0x71307984f0f0
    7130796f097c:	48 89 45 b8          	mov    QWORD PTR [rbp-0x48],rax
    7130796f0980:	48 89 55 c0          	mov    QWORD PTR [rbp-0x40],rdx
    7130796f0984:	48 8d 7d b8          	lea    rdi,[rbp-0x48]
    7130796f0988:	ff 15 7a e7 15 00    	call   QWORD PTR [rip+0x15e77a]        # 0x71307984f108
    7130796f098e:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    7130796f0992:	49 8b ff             	mov    rdi,r15
    7130796f0995:	41 8b f5             	mov    esi,r13d
    7130796f0998:	ff 15 52 e7 15 00    	call   QWORD PTR [rip+0x15e752]        # 0x71307984f0f0
    7130796f099e:	48 89 45 a8          	mov    QWORD PTR [rbp-0x58],rax
    7130796f09a2:	48 89 55 b0          	mov    QWORD PTR [rbp-0x50],rdx
    7130796f09a6:	48 8d 7d a8          	lea    rdi,[rbp-0x58]
    7130796f09aa:	ff 15 58 e7 15 00    	call   QWORD PTR [rip+0x15e758]        # 0x71307984f108
    7130796f09b0:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796f09b4:	48 3b f8             	cmp    rdi,rax
    7130796f09b7:	48 0f 4c f8          	cmovl  rdi,rax
    7130796f09bb:	be 01 00 00 00       	mov    esi,0x1
    7130796f09c0:	ff 15 7a f4 15 00    	call   QWORD PTR [rip+0x15f47a]        # 0x71307984fe40
    7130796f09c6:	48 83 f8 40          	cmp    rax,0x40
    7130796f09ca:	7f 11                	jg     0x7130796f09dd
    7130796f09cc:	e9 46 fd ff ff       	jmp    0x7130796f0717
    7130796f09d1:	e8 32 0c d9 fe       	call   0x713078481608
    7130796f09d6:	cc                   	int3
    7130796f09d7:	e8 14 0c d9 fe       	call   0x7130784815f0
    7130796f09dc:	cc                   	int3
    7130796f09dd:	48 8b f8             	mov    rdi,rax
    7130796f09e0:	be 01 00 00 00       	mov    esi,0x1
    7130796f09e5:	ff 15 55 f4 15 00    	call   QWORD PTR [rip+0x15f455]        # 0x71307984fe40
    7130796f09eb:	48 8b f8             	mov    rdi,rax
    7130796f09ee:	ff 15 64 f4 15 00    	call   QWORD PTR [rip+0x15f464]        # 0x71307984fe58
    7130796f09f4:	48 8b f0             	mov    rsi,rax
    7130796f09f7:	bf 02 00 00 00       	mov    edi,0x2
    7130796f09fc:	ff 15 6e f4 15 00    	call   QWORD PTR [rip+0x15f46e]        # 0x71307984fe70
    7130796f0a02:	48 89 45 a0          	mov    QWORD PTR [rbp-0x60],rax
    7130796f0a06:	48 bf 98 bd 56 79 30 	movabs rdi,0x71307956bd98
    7130796f0a0d:	71 00 00 
    7130796f0a10:	e8 ab 08 f6 7c       	call   0x7130f66512c0
    7130796f0a15:	48 89 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rax
    7130796f0a1c:	48 8b f8             	mov    rdi,rax
    7130796f0a1f:	49 8b f4             	mov    rsi,r12
    7130796f0a22:	48 8b 55 a0          	mov    rdx,QWORD PTR [rbp-0x60]
    7130796f0a26:	48 8b 8d 68 ff ff ff 	mov    rcx,QWORD PTR [rbp-0x98]
    7130796f0a2d:	ff 15 cd 44 42 00    	call   QWORD PTR [rip+0x4244cd]        # 0x713079b14f00
    7130796f0a33:	4c 8b a5 58 ff ff ff 	mov    r12,QWORD PTR [rbp-0xa8]
    7130796f0a3a:	e9 db fc ff ff       	jmp    0x7130796f071a
    7130796f0a3f:	45 33 e4             	xor    r12d,r12d
    7130796f0a42:	e9 d3 fc ff ff       	jmp    0x7130796f071a
    7130796f0a47:	49 8b fc             	mov    rdi,r12
    7130796f0a4a:	ff 15 c0 b3 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7b3c0]        # 0x71307956be10
    7130796f0a50:	90                   	nop
    7130796f0a51:	49 8b c6             	mov    rax,r14
    7130796f0a54:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7130796f0a5b:	5b                   	pop    rbx
    7130796f0a5c:	41 5c                	pop    r12
    7130796f0a5e:	41 5d                	pop    r13
    7130796f0a60:	41 5e                	pop    r14
    7130796f0a62:	41 5f                	pop    r15
    7130796f0a64:	5d                   	pop    rbp
    7130796f0a65:	c3                   	ret
    7130796f0a66:	50                   	push   rax
    7130796f0a67:	48 83 bd 60 ff ff ff 	cmp    QWORD PTR [rbp-0xa0],0x0
    7130796f0a6e:	00 
    7130796f0a6f:	74 0d                	je     0x7130796f0a7e
    7130796f0a71:	48 8b bd 60 ff ff ff 	mov    rdi,QWORD PTR [rbp-0xa0]
    7130796f0a78:	ff 15 92 b3 e7 ff    	call   QWORD PTR [rip+0xffffffffffe7b392]        # 0x71307956be10
    7130796f0a7e:	90                   	nop
    7130796f0a7f:	48 83 c4 08          	add    rsp,0x8
    7130796f0a83:	c3                   	ret
    7130796f0a84:	50                   	push   rax
    7130796f0a85:	4c 8b f7             	mov    r14,rdi
    7130796f0a88:	48 bf d8 a6 55 79 30 	movabs rdi,0x71307955a6d8
    7130796f0a8f:	71 00 00 
    7130796f0a92:	e8 29 08 f6 7c       	call   0x7130f66512c0
    7130796f0a97:	48 8b d8             	mov    rbx,rax
    7130796f0a9a:	49 8b fe             	mov    rdi,r14
    7130796f0a9d:	49 8b 06             	mov    rax,QWORD PTR [r14]
    7130796f0aa0:	48 8b 40 40          	mov    rax,QWORD PTR [rax+0x40]
    7130796f0aa4:	ff 50 20             	call   QWORD PTR [rax+0x20]
    7130796f0aa7:	48 8b d0             	mov    rdx,rax
    7130796f0aaa:	48 8b 8d 68 ff ff ff 	mov    rcx,QWORD PTR [rbp-0x98]
    7130796f0ab1:	48 8b fb             	mov    rdi,rbx
    7130796f0ab4:	48 be 40 0b e1 74 30 	movabs rsi,0x713074e10b40
    7130796f0abb:	71 00 00 
    7130796f0abe:	ff 15 2c d1 15 00    	call   QWORD PTR [rip+0x15d12c]        # 0x71307984dbf0
    7130796f0ac4:	48 8b fb             	mov    rdi,rbx
    7130796f0ac7:	e8 d4 14 cc 7c       	call   0x7130f63b1fa0
    7130796f0acc:	cc                   	int3
