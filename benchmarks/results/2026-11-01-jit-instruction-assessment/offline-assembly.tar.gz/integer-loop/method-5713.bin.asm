
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5713.bin:     file format binary


Disassembly of section .data:

00007130796f14f0 <.data>:
    7130796f14f0:	55                   	push   rbp
    7130796f14f1:	41 57                	push   r15
    7130796f14f3:	41 56                	push   r14
    7130796f14f5:	41 55                	push   r13
    7130796f14f7:	41 54                	push   r12
    7130796f14f9:	53                   	push   rbx
    7130796f14fa:	48 83 ec 48          	sub    rsp,0x48
    7130796f14fe:	48 8d 6c 24 70       	lea    rbp,[rsp+0x70]
    7130796f1503:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    7130796f1508:	c5 7e 7f 45 a0       	vmovdqu YMMWORD PTR [rbp-0x60],ymm8
    7130796f150d:	c5 79 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm8
    7130796f1512:	48 8b df             	mov    rbx,rdi
    7130796f1515:	8b 7b 38             	mov    edi,DWORD PTR [rbx+0x38]
    7130796f1518:	4c 8b 7b 30          	mov    r15,QWORD PTR [rbx+0x30]
    7130796f151c:	85 ff                	test   edi,edi
    7130796f151e:	0f 84 18 02 00 00    	je     0x7130796f173c
    7130796f1524:	83 ff 01             	cmp    edi,0x1
    7130796f1527:	0f 85 fe 01 00 00    	jne    0x7130796f172b
    7130796f152d:	c7 43 38 ff ff ff ff 	mov    DWORD PTR [rbx+0x38],0xffffffff
    7130796f1534:	8b 7b 40             	mov    edi,DWORD PTR [rbx+0x40]
    7130796f1537:	8d 47 ff             	lea    eax,[rdi-0x1]
    7130796f153a:	89 43 40             	mov    DWORD PTR [rbx+0x40],eax
    7130796f153d:	85 ff                	test   edi,edi
    7130796f153f:	0f 84 78 01 00 00    	je     0x7130796f16bd
    7130796f1545:	4c 8b 73 48          	mov    r14,QWORD PTR [rbx+0x48]
    7130796f1549:	8b 53 50             	mov    edx,DWORD PTR [rbx+0x50]
    7130796f154c:	4d 8b 6f 38          	mov    r13,QWORD PTR [r15+0x38]
    7130796f1550:	45 8b 4f 40          	mov    r9d,DWORD PTR [r15+0x40]
    7130796f1554:	49 8b f6             	mov    rsi,r14
    7130796f1557:	49 0b f5             	or     rsi,r13
    7130796f155a:	0f 85 21 03 00 00    	jne    0x7130796f1881
    7130796f1560:	c5 f8 57 c0          	vxorps xmm0,xmm0,xmm0
    7130796f1564:	c5 fa 7f 45 b0       	vmovdqu XMMWORD PTR [rbp-0x50],xmm0
    7130796f1569:	48 63 f2             	movsxd rsi,edx
    7130796f156c:	49 63 f9             	movsxd rdi,r9d
    7130796f156f:	48 03 f7             	add    rsi,rdi
    7130796f1572:	48 8d 7d b0          	lea    rdi,[rbp-0x50]
    7130796f1576:	ff 15 b4 e9 15 00    	call   QWORD PTR [rip+0x15e9b4]        # 0x71307984ff30
    7130796f157c:	48 8b 75 b0          	mov    rsi,QWORD PTR [rbp-0x50]
    7130796f1580:	44 8b 65 b8          	mov    r12d,DWORD PTR [rbp-0x48]
    7130796f1584:	48 8d 7b 48          	lea    rdi,[rbx+0x48]
    7130796f1588:	e8 b3 ea b5 fd       	call   0x713077250040
    7130796f158d:	44 89 63 50          	mov    DWORD PTR [rbx+0x50],r12d
    7130796f1591:	49 8b 7f 38          	mov    rdi,QWORD PTR [r15+0x38]
    7130796f1595:	41 8b 77 40          	mov    esi,DWORD PTR [r15+0x40]
    7130796f1599:	48 85 ff             	test   rdi,rdi
    7130796f159c:	0f 85 61 03 00 00    	jne    0x7130796f1903
    7130796f15a2:	48 63 f6             	movsxd rsi,esi
    7130796f15a5:	48 85 f6             	test   rsi,rsi
    7130796f15a8:	0f 9f c2             	setg   dl
    7130796f15ab:	0f b6 d2             	movzx  edx,dl
    7130796f15ae:	bf ff ff ff ff       	mov    edi,0xffffffff
    7130796f15b3:	48 85 f6             	test   rsi,rsi
    7130796f15b6:	0f 4c d7             	cmovl  edx,edi
    7130796f15b9:	85 d2                	test   edx,edx
    7130796f15bb:	0f 8e 38 01 00 00    	jle    0x7130796f16f9
    7130796f15c1:	48 8b 7b 48          	mov    rdi,QWORD PTR [rbx+0x48]
    7130796f15c5:	44 8b 73 50          	mov    r14d,DWORD PTR [rbx+0x50]
    7130796f15c9:	49 8b 77 28          	mov    rsi,QWORD PTR [r15+0x28]
    7130796f15cd:	41 8b 57 30          	mov    edx,DWORD PTR [r15+0x30]
    7130796f15d1:	41 8b ce             	mov    ecx,r14d
    7130796f15d4:	33 ca                	xor    ecx,edx
    7130796f15d6:	0f 8c 5b 03 00 00    	jl     0x7130796f1937
    7130796f15dc:	48 85 ff             	test   rdi,rdi
    7130796f15df:	0f 85 72 03 00 00    	jne    0x7130796f1957
    7130796f15e5:	48 85 f6             	test   rsi,rsi
    7130796f15e8:	0f 85 61 03 00 00    	jne    0x7130796f194f
    7130796f15ee:	44 3b f2             	cmp    r14d,edx
    7130796f15f1:	0f 8d 49 03 00 00    	jge    0x7130796f1940
    7130796f15f7:	4c 8b 73 48          	mov    r14,QWORD PTR [rbx+0x48]
    7130796f15fb:	44 8b 6b 50          	mov    r13d,DWORD PTR [rbx+0x50]
    7130796f15ff:	48 bf 90 f0 68 79 30 	movabs rdi,0x71307968f090
    7130796f1606:	71 00 00 
    7130796f1609:	e8 b2 fc f5 7c       	call   0x7130f66512c0
    7130796f160e:	4c 8b e0             	mov    r12,rax
    7130796f1611:	49 8d 7c 24 08       	lea    rdi,[r12+0x8]
    7130796f1616:	49 8b f6             	mov    rsi,r14
    7130796f1619:	e8 22 ea b5 fd       	call   0x713077250040
    7130796f161e:	45 89 6c 24 10       	mov    DWORD PTR [r12+0x10],r13d
    7130796f1623:	4d 8b 77 08          	mov    r14,QWORD PTR [r15+0x8]
    7130796f1627:	4d 85 f6             	test   r14,r14
    7130796f162a:	74 6a                	je     0x7130796f1696
    7130796f162c:	4d 8b 7f 10          	mov    r15,QWORD PTR [r15+0x10]
    7130796f1630:	4d 8b 6c 24 08       	mov    r13,QWORD PTR [r12+0x8]
    7130796f1635:	41 8b 44 24 10       	mov    eax,DWORD PTR [r12+0x10]
    7130796f163a:	89 45 9c             	mov    DWORD PTR [rbp-0x64],eax
    7130796f163d:	8b f8                	mov    edi,eax
    7130796f163f:	c1 ff 1f             	sar    edi,0x1f
    7130796f1642:	48 63 ff             	movsxd rdi,edi
    7130796f1645:	8b f0                	mov    esi,eax
    7130796f1647:	33 f7                	xor    esi,edi
    7130796f1649:	2b f7                	sub    esi,edi
    7130796f164b:	4d 85 ed             	test   r13,r13
    7130796f164e:	0f 85 58 01 00 00    	jne    0x7130796f17ac
    7130796f1654:	bf 01 00 00 00       	mov    edi,0x1
    7130796f1659:	8b ce                	mov    ecx,esi
    7130796f165b:	f7 d9                	neg    ecx
    7130796f165d:	85 f6                	test   esi,esi
    7130796f165f:	0f 4d ce             	cmovge ecx,esi
    7130796f1662:	48 63 c9             	movsxd rcx,ecx
    7130796f1665:	8b d7                	mov    edx,edi
    7130796f1667:	48 c1 e2 06          	shl    rdx,0x6
    7130796f166b:	45 33 c0             	xor    r8d,r8d
    7130796f166e:	f3 4c 0f bd c1       	lzcnt  r8,rcx
    7130796f1673:	45 8b c0             	mov    r8d,r8d
    7130796f1676:	49 2b d0             	sub    rdx,r8
    7130796f1679:	48 89 55 d0          	mov    QWORD PTR [rbp-0x30],rdx
    7130796f167d:	85 f6                	test   esi,esi
    7130796f167f:	0f 8c 45 01 00 00    	jl     0x7130796f17ca
    7130796f1685:	48 8b 55 d0          	mov    rdx,QWORD PTR [rbp-0x30]
    7130796f1689:	48 8b fa             	mov    rdi,rdx
    7130796f168c:	48 83 ff 40          	cmp    rdi,0x40
    7130796f1690:	0f 8f 8b 01 00 00    	jg     0x7130796f1821
    7130796f1696:	48 8d 7b 08          	lea    rdi,[rbx+0x8]
    7130796f169a:	49 8b f4             	mov    rsi,r12
    7130796f169d:	e8 9e e9 b5 fd       	call   0x713077250040
    7130796f16a2:	c7 43 38 01 00 00 00 	mov    DWORD PTR [rbx+0x38],0x1
    7130796f16a9:	b8 01 00 00 00       	mov    eax,0x1
    7130796f16ae:	48 83 c4 48          	add    rsp,0x48
    7130796f16b2:	5b                   	pop    rbx
    7130796f16b3:	41 5c                	pop    r12
    7130796f16b5:	41 5d                	pop    r13
    7130796f16b7:	41 5e                	pop    r14
    7130796f16b9:	41 5f                	pop    r15
    7130796f16bb:	5d                   	pop    rbp
    7130796f16bc:	c3                   	ret
    7130796f16bd:	c7 43 40 3f 00 00 00 	mov    DWORD PTR [rbx+0x40],0x3f
    7130796f16c4:	48 8b 7b 10          	mov    rdi,QWORD PTR [rbx+0x10]
    7130796f16c8:	48 8b 43 20          	mov    rax,QWORD PTR [rbx+0x20]
    7130796f16cc:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    7130796f16d0:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    7130796f16d7:	48 8b 49 18          	mov    rcx,QWORD PTR [rcx+0x18]
    7130796f16db:	48 85 c9             	test   rcx,rcx
    7130796f16de:	0f 85 7c 01 00 00    	jne    0x7130796f1860
    7130796f16e4:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    7130796f16eb:	48 85 ff             	test   rdi,rdi
    7130796f16ee:	0f 84 51 fe ff ff    	je     0x7130796f1545
    7130796f16f4:	e9 70 01 00 00       	jmp    0x7130796f1869
    7130796f16f9:	48 8b 73 48          	mov    rsi,QWORD PTR [rbx+0x48]
    7130796f16fd:	8b 53 50             	mov    edx,DWORD PTR [rbx+0x50]
    7130796f1700:	49 8b 7f 28          	mov    rdi,QWORD PTR [r15+0x28]
    7130796f1704:	41 8b 47 30          	mov    eax,DWORD PTR [r15+0x30]
    7130796f1708:	48 89 75 a0          	mov    QWORD PTR [rbp-0x60],rsi
    7130796f170c:	89 55 a8             	mov    DWORD PTR [rbp-0x58],edx
    7130796f170f:	48 8b f7             	mov    rsi,rdi
    7130796f1712:	8b d0                	mov    edx,eax
    7130796f1714:	48 8d 7d a0          	lea    rdi,[rbp-0x60]
    7130796f1718:	ff 15 ba e2 15 00    	call   QWORD PTR [rip+0x15e2ba]        # 0x71307984f9d8
    7130796f171e:	85 c0                	test   eax,eax
    7130796f1720:	0f 8f d1 fe ff ff    	jg     0x7130796f15f7
    7130796f1726:	e9 15 02 00 00       	jmp    0x7130796f1940
    7130796f172b:	33 c0                	xor    eax,eax
    7130796f172d:	48 83 c4 48          	add    rsp,0x48
    7130796f1731:	5b                   	pop    rbx
    7130796f1732:	41 5c                	pop    r12
    7130796f1734:	41 5d                	pop    r13
    7130796f1736:	41 5e                	pop    r14
    7130796f1738:	41 5f                	pop    r15
    7130796f173a:	5d                   	pop    rbp
    7130796f173b:	c3                   	ret
    7130796f173c:	c7 43 38 ff ff ff ff 	mov    DWORD PTR [rbx+0x38],0xffffffff
    7130796f1743:	48 8b 7b 10          	mov    rdi,QWORD PTR [rbx+0x10]
    7130796f1747:	48 8b 43 20          	mov    rax,QWORD PTR [rbx+0x20]
    7130796f174b:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    7130796f174f:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    7130796f1756:	48 8b 49 18          	mov    rcx,QWORD PTR [rcx+0x18]
    7130796f175a:	48 85 c9             	test   rcx,rcx
    7130796f175d:	74 09                	je     0x7130796f1768
    7130796f175f:	48 8b f9             	mov    rdi,rcx
    7130796f1762:	e8 39 08 cc 7c       	call   0x7130f63b1fa0
    7130796f1767:	cc                   	int3
    7130796f1768:	48 8b bf 68 01 00 00 	mov    rdi,QWORD PTR [rdi+0x168]
    7130796f176f:	48 85 ff             	test   rdi,rdi
    7130796f1772:	74 06                	je     0x7130796f177a
    7130796f1774:	83 7f 20 00          	cmp    DWORD PTR [rdi+0x20],0x0
    7130796f1778:	75 27                	jne    0x7130796f17a1
    7130796f177a:	c7 43 40 3f 00 00 00 	mov    DWORD PTR [rbx+0x40],0x3f
    7130796f1781:	4d 8d 77 18          	lea    r14,[r15+0x18]
    7130796f1785:	4c 8d 6b 48          	lea    r13,[rbx+0x48]
    7130796f1789:	49 8b 36             	mov    rsi,QWORD PTR [r14]
    7130796f178c:	49 8b fd             	mov    rdi,r13
    7130796f178f:	e8 ac e8 b5 fd       	call   0x713077250040
    7130796f1794:	49 8b 7e 08          	mov    rdi,QWORD PTR [r14+0x8]
    7130796f1798:	49 89 7d 08          	mov    QWORD PTR [r13+0x8],rdi
    7130796f179c:	e9 f0 fd ff ff       	jmp    0x7130796f1591
    7130796f17a1:	48 8b f8             	mov    rdi,rax
    7130796f17a4:	ff 15 96 b9 15 00    	call   QWORD PTR [rip+0x15b996]        # 0x71307984d140
    7130796f17aa:	eb ce                	jmp    0x7130796f177a
    7130796f17ac:	41 8b 7d 08          	mov    edi,DWORD PTR [r13+0x8]
    7130796f17b0:	8d 4f ff             	lea    ecx,[rdi-0x1]
    7130796f17b3:	41 3b 4d 08          	cmp    ecx,DWORD PTR [r13+0x8]
    7130796f17b7:	0f 83 da 01 00 00    	jae    0x7130796f1997
    7130796f17bd:	8d 4f ff             	lea    ecx,[rdi-0x1]
    7130796f17c0:	49 8b 4c cd 10       	mov    rcx,QWORD PTR [r13+rcx*8+0x10]
    7130796f17c5:	e9 9b fe ff ff       	jmp    0x7130796f1665
    7130796f17ca:	c4 e2 c8 f3 c9       	blsr   rsi,rcx
    7130796f17cf:	0f 85 b0 fe ff ff    	jne    0x7130796f1685
    7130796f17d5:	ff cf                	dec    edi
    7130796f17d7:	8b f7                	mov    esi,edi
    7130796f17d9:	4d 85 ed             	test   r13,r13
    7130796f17dc:	75 11                	jne    0x7130796f17ef
    7130796f17de:	85 f6                	test   esi,esi
    7130796f17e0:	74 07                	je     0x7130796f17e9
    7130796f17e2:	ff 15 00 5e f8 ff    	call   QWORD PTR [rip+0xfffffffffff85e00]        # 0x7130796775e8
    7130796f17e8:	cc                   	int3
    7130796f17e9:	33 ff                	xor    edi,edi
    7130796f17eb:	33 f6                	xor    esi,esi
    7130796f17ed:	eb 0a                	jmp    0x7130796f17f9
    7130796f17ef:	41 39 75 08          	cmp    DWORD PTR [r13+0x8],esi
    7130796f17f3:	72 ed                	jb     0x7130796f17e2
    7130796f17f5:	49 8d 7d 10          	lea    rdi,[r13+0x10]
    7130796f17f9:	ff 15 f1 61 f8 ff    	call   QWORD PTR [rip+0xfffffffffff861f1]        # 0x7130796779f0
    7130796f17ff:	48 8b f8             	mov    rdi,rax
    7130796f1802:	33 f6                	xor    esi,esi
    7130796f1804:	ff 15 0e 34 49 00    	call   QWORD PTR [rip+0x49340e]        # 0x713079b84c18
    7130796f180a:	85 c0                	test   eax,eax
    7130796f180c:	0f 8d 73 fe ff ff    	jge    0x7130796f1685
    7130796f1812:	48 8b 45 d0          	mov    rax,QWORD PTR [rbp-0x30]
    7130796f1816:	48 ff c8             	dec    rax
    7130796f1819:	48 8b f8             	mov    rdi,rax
    7130796f181c:	e9 6b fe ff ff       	jmp    0x7130796f168c
    7130796f1821:	4c 89 6d c0          	mov    QWORD PTR [rbp-0x40],r13
    7130796f1825:	8b 45 9c             	mov    eax,DWORD PTR [rbp-0x64]
    7130796f1828:	89 45 c8             	mov    DWORD PTR [rbp-0x38],eax
    7130796f182b:	48 8d 7d c0          	lea    rdi,[rbp-0x40]
    7130796f182f:	33 f6                	xor    esi,esi
    7130796f1831:	ff 15 f1 e5 15 00    	call   QWORD PTR [rip+0x15e5f1]        # 0x71307984fe28
    7130796f1837:	4c 63 e8             	movsxd r13,eax
    7130796f183a:	49 83 c5 20          	add    r13,0x20
    7130796f183e:	49 8b fe             	mov    rdi,r14
    7130796f1841:	49 8b f5             	mov    rsi,r13
    7130796f1844:	49 8b d7             	mov    rdx,r15
    7130796f1847:	39 3f                	cmp    DWORD PTR [rdi],edi
    7130796f1849:	ff 15 71 67 15 00    	call   QWORD PTR [rip+0x156771]        # 0x713079847fc0
    7130796f184f:	49 8b fe             	mov    rdi,r14
    7130796f1852:	49 8b f5             	mov    rsi,r13
    7130796f1855:	ff 15 7d 67 15 00    	call   QWORD PTR [rip+0x15677d]        # 0x713079847fd8
    7130796f185b:	e9 36 fe ff ff       	jmp    0x7130796f1696
    7130796f1860:	48 8b f9             	mov    rdi,rcx
    7130796f1863:	e8 38 07 cc 7c       	call   0x7130f63b1fa0
    7130796f1868:	cc                   	int3
    7130796f1869:	83 7f 20 00          	cmp    DWORD PTR [rdi+0x20],0x0
    7130796f186d:	0f 84 d2 fc ff ff    	je     0x7130796f1545
    7130796f1873:	48 8b f8             	mov    rdi,rax
    7130796f1876:	ff 15 c4 b8 15 00    	call   QWORD PTR [rip+0x15b8c4]        # 0x71307984d140
    7130796f187c:	e9 c4 fc ff ff       	jmp    0x7130796f1545
    7130796f1881:	8b fa                	mov    edi,edx
    7130796f1883:	c1 ef 1f             	shr    edi,0x1f
    7130796f1886:	41 8b f1             	mov    esi,r9d
    7130796f1889:	c1 ee 1f             	shr    esi,0x1f
    7130796f188c:	3b fe                	cmp    edi,esi
    7130796f188e:	75 38                	jne    0x7130796f18c8
    7130796f1890:	4d 85 f6             	test   r14,r14
    7130796f1893:	75 06                	jne    0x7130796f189b
    7130796f1895:	33 ff                	xor    edi,edi
    7130796f1897:	33 f6                	xor    esi,esi
    7130796f1899:	eb 08                	jmp    0x7130796f18a3
    7130796f189b:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    7130796f189f:	41 8b 76 08          	mov    esi,DWORD PTR [r14+0x8]
    7130796f18a3:	4d 85 ed             	test   r13,r13
    7130796f18a6:	75 07                	jne    0x7130796f18af
    7130796f18a8:	33 c9                	xor    ecx,ecx
    7130796f18aa:	45 33 c0             	xor    r8d,r8d
    7130796f18ad:	eb 08                	jmp    0x7130796f18b7
    7130796f18af:	49 8d 4d 10          	lea    rcx,[r13+0x10]
    7130796f18b3:	45 8b 45 08          	mov    r8d,DWORD PTR [r13+0x8]
    7130796f18b7:	ff 15 33 37 49 00    	call   QWORD PTR [rip+0x493733]        # 0x713079b84ff0
    7130796f18bd:	48 8b f0             	mov    rsi,rax
    7130796f18c0:	44 8b e2             	mov    r12d,edx
    7130796f18c3:	e9 bc fc ff ff       	jmp    0x7130796f1584
    7130796f18c8:	4d 85 f6             	test   r14,r14
    7130796f18cb:	75 06                	jne    0x7130796f18d3
    7130796f18cd:	33 ff                	xor    edi,edi
    7130796f18cf:	33 f6                	xor    esi,esi
    7130796f18d1:	eb 08                	jmp    0x7130796f18db
    7130796f18d3:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    7130796f18d7:	41 8b 76 08          	mov    esi,DWORD PTR [r14+0x8]
    7130796f18db:	4d 85 ed             	test   r13,r13
    7130796f18de:	75 07                	jne    0x7130796f18e7
    7130796f18e0:	33 c9                	xor    ecx,ecx
    7130796f18e2:	45 33 c0             	xor    r8d,r8d
    7130796f18e5:	eb 08                	jmp    0x7130796f18ef
    7130796f18e7:	49 8d 4d 10          	lea    rcx,[r13+0x10]
    7130796f18eb:	45 8b 45 08          	mov    r8d,DWORD PTR [r13+0x8]
    7130796f18ef:	41 f7 d9             	neg    r9d
    7130796f18f2:	ff 15 10 37 49 00    	call   QWORD PTR [rip+0x493710]        # 0x713079b85008
    7130796f18f8:	48 8b f0             	mov    rsi,rax
    7130796f18fb:	44 8b e2             	mov    r12d,edx
    7130796f18fe:	e9 81 fc ff ff       	jmp    0x7130796f1584
    7130796f1903:	48 63 d6             	movsxd rdx,esi
    7130796f1906:	48 85 d2             	test   rdx,rdx
    7130796f1909:	7c 06                	jl     0x7130796f1911
    7130796f190b:	83 7f 08 01          	cmp    DWORD PTR [rdi+0x8],0x1
    7130796f190f:	7e 07                	jle    0x7130796f1918
    7130796f1911:	8b d6                	mov    edx,esi
    7130796f1913:	e9 a1 fc ff ff       	jmp    0x7130796f15b9
    7130796f1918:	83 7f 08 00          	cmp    DWORD PTR [rdi+0x8],0x0
    7130796f191c:	76 79                	jbe    0x7130796f1997
    7130796f191e:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
    7130796f1922:	48 85 ff             	test   rdi,rdi
    7130796f1925:	40 0f 95 c7          	setne  dil
    7130796f1929:	40 0f b6 ff          	movzx  edi,dil
    7130796f192d:	8b d6                	mov    edx,esi
    7130796f192f:	0f af d7             	imul   edx,edi
    7130796f1932:	e9 82 fc ff ff       	jmp    0x7130796f15b9
    7130796f1937:	45 85 f6             	test   r14d,r14d
    7130796f193a:	0f 8c b7 fc ff ff    	jl     0x7130796f15f7
    7130796f1940:	33 c0                	xor    eax,eax
    7130796f1942:	48 89 43 48          	mov    QWORD PTR [rbx+0x48],rax
    7130796f1946:	48 89 43 50          	mov    QWORD PTR [rbx+0x50],rax
    7130796f194a:	e9 dc fd ff ff       	jmp    0x7130796f172b
    7130796f194f:	44 8b f2             	mov    r14d,edx
    7130796f1952:	41 f7 de             	neg    r14d
    7130796f1955:	eb 35                	jmp    0x7130796f198c
    7130796f1957:	48 85 f6             	test   rsi,rsi
    7130796f195a:	75 02                	jne    0x7130796f195e
    7130796f195c:	eb 2e                	jmp    0x7130796f198c
    7130796f195e:	48 8d 57 10          	lea    rdx,[rdi+0x10]
    7130796f1962:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
    7130796f1965:	48 8d 46 10          	lea    rax,[rsi+0x10]
    7130796f1969:	44 8b 46 08          	mov    r8d,DWORD PTR [rsi+0x8]
    7130796f196d:	48 8b fa             	mov    rdi,rdx
    7130796f1970:	8b f1                	mov    esi,ecx
    7130796f1972:	48 8b d0             	mov    rdx,rax
    7130796f1975:	41 8b c8             	mov    ecx,r8d
    7130796f1978:	ff 15 4a 37 49 00    	call   QWORD PTR [rip+0x49374a]        # 0x713079b850c8
    7130796f197e:	8b f0                	mov    esi,eax
    7130796f1980:	f7 de                	neg    esi
    7130796f1982:	45 85 f6             	test   r14d,r14d
    7130796f1985:	44 8b f0             	mov    r14d,eax
    7130796f1988:	44 0f 4c f6          	cmovl  r14d,esi
    7130796f198c:	45 85 f6             	test   r14d,r14d
    7130796f198f:	0f 8c 62 fc ff ff    	jl     0x7130796f15f7
    7130796f1995:	eb a9                	jmp    0x7130796f1940
    7130796f1997:	e8 6c fc d8 fe       	call   0x713078481608
    7130796f199c:	cc                   	int3
