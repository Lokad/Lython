
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-6445.bin:     file format binary


Disassembly of section .data:

0000713079c370a0 <.data>:
    713079c370a0:	50                   	push   rax
    713079c370a1:	48 8b 45 00          	mov    rax,QWORD PTR [rbp+0x0]
    713079c370a5:	50                   	push   rax
    713079c370a6:	48 81 ec b0 00 00 00 	sub    rsp,0xb0
    713079c370ad:	4c 89 bc 24 98 03 00 	mov    QWORD PTR [rsp+0x398],r15
    713079c370b4:	00 
    713079c370b5:	4c 89 b4 24 90 03 00 	mov    QWORD PTR [rsp+0x390],r14
    713079c370bc:	00 
    713079c370bd:	4c 89 ac 24 88 03 00 	mov    QWORD PTR [rsp+0x388],r13
    713079c370c4:	00 
    713079c370c5:	4c 89 a4 24 80 03 00 	mov    QWORD PTR [rsp+0x380],r12
    713079c370cc:	00 
    713079c370cd:	48 89 9c 24 78 03 00 	mov    QWORD PTR [rsp+0x378],rbx
    713079c370d4:	00 
    713079c370d5:	48 8d ac 24 b0 00 00 	lea    rbp,[rsp+0xb0]
    713079c370dc:	00 
    713079c370dd:	c4 41 38 57 c0       	vxorps xmm8,xmm8,xmm8
    713079c370e2:	62 71 7e 48 7f 45 fe 	vmovdqu32 ZMMWORD PTR [rbp-0x80],zmm8
    713079c370e9:	c5 79 7f 45 c0       	vmovdqa XMMWORD PTR [rbp-0x40],xmm8
    713079c370ee:	33 c0                	xor    eax,eax
    713079c370f0:	48 89 45 d0          	mov    QWORD PTR [rbp-0x30],rax
    713079c370f4:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c370fb:	eb 1d                	jmp    0x713079c3711a
    713079c370fd:	83 bd bc 02 00 00 00 	cmp    DWORD PTR [rbp+0x2bc],0x0
    713079c37104:	0f 85 c1 09 00 00    	jne    0x713079c37acb
    713079c3710a:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c37111:	ff 83 dc 00 00 00    	inc    DWORD PTR [rbx+0xdc]
    713079c37117:	48 8b fb             	mov    rdi,rbx
    713079c3711a:	8b 87 dc 00 00 00    	mov    eax,DWORD PTR [rdi+0xdc]
    713079c37120:	48 8b 8d b0 02 00 00 	mov    rcx,QWORD PTR [rbp+0x2b0]
    713079c37127:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    713079c3712a:	3b c1                	cmp    eax,ecx
    713079c3712c:	0f 8d ab 09 00 00    	jge    0x713079c37add
    713079c37132:	3b c1                	cmp    eax,ecx
    713079c37134:	0f 83 9f 0a 00 00    	jae    0x713079c37bd9
    713079c3713a:	48 8b 8d b0 02 00 00 	mov    rcx,QWORD PTR [rbp+0x2b0]
    713079c37141:	8b c0                	mov    eax,eax
    713079c37143:	48 8d 04 40          	lea    rax,[rax+rax*2]
    713079c37147:	48 8d 44 c1 10       	lea    rax,[rcx+rax*8+0x10]
    713079c3714c:	48 89 85 98 02 00 00 	mov    QWORD PTR [rbp+0x298],rax
    713079c37153:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    713079c37157:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
    713079c3715b:	48 8b 8d 98 02 00 00 	mov    rcx,QWORD PTR [rbp+0x298]
    713079c37162:	48 8b 09             	mov    rcx,QWORD PTR [rcx]
    713079c37165:	48 8b 90 80 00 00 00 	mov    rdx,QWORD PTR [rax+0x80]
    713079c3716c:	48 8b 52 18          	mov    rdx,QWORD PTR [rdx+0x18]
    713079c37170:	48 85 d2             	test   rdx,rdx
    713079c37173:	0f 85 57 0a 00 00    	jne    0x713079c37bd0
    713079c37179:	48 8b 80 68 01 00 00 	mov    rax,QWORD PTR [rax+0x168]
    713079c37180:	48 85 c0             	test   rax,rax
    713079c37183:	0f 85 1e 0a 00 00    	jne    0x713079c37ba7
    713079c37189:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37190:	48 83 bf 88 00 00 00 	cmp    QWORD PTR [rdi+0x88],0x0
    713079c37197:	00 
    713079c37198:	75 43                	jne    0x713079c371dd
    713079c3719a:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c371a1:	8b 5e 10             	mov    ebx,DWORD PTR [rsi+0x10]
    713079c371a4:	83 fb 2f             	cmp    ebx,0x2f
    713079c371a7:	0f 87 99 01 00 00    	ja     0x713079c37346
    713079c371ad:	8b f3                	mov    esi,ebx
    713079c371af:	48 8d 05 d2 0b 00 00 	lea    rax,[rip+0xbd2]        # 0x713079c37d88
    713079c371b6:	8b 04 b0             	mov    eax,DWORD PTR [rax+rsi*4]
    713079c371b9:	48 8d 0d 3b ff ff ff 	lea    rcx,[rip+0xffffffffffffff3b]        # 0x713079c370fb
    713079c371c0:	48 03 c1             	add    rax,rcx
    713079c371c3:	ff e0                	jmp    rax
    713079c371c5:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c371cc:	ff 15 3e 68 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1683e]        # 0x71307984da10
    713079c371d2:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    713079c371d8:	e9 20 ff ff ff       	jmp    0x713079c370fd
    713079c371dd:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    713079c371e4:	00 
    713079c371e5:	75 b3                	jne    0x713079c3719a
    713079c371e7:	e9 1d 06 00 00       	jmp    0x713079c37809
    713079c371ec:	83 fb 04             	cmp    ebx,0x4
    713079c371ef:	74 09                	je     0x713079c371fa
    713079c371f1:	83 fb 0d             	cmp    ebx,0xd
    713079c371f4:	0f 85 28 06 00 00    	jne    0x713079c37822
    713079c371fa:	48 8b 95 98 02 00 00 	mov    rdx,QWORD PTR [rbp+0x298]
    713079c37201:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    713079c37204:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c3720b:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    713079c3720e:	ff 15 04 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc16604]        # 0x71307984d818
    713079c37214:	e9 e4 fe ff ff       	jmp    0x713079c370fd
    713079c37219:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    713079c3721d:	4c 8b 5e 10          	mov    r11,QWORD PTR [rsi+0x10]
    713079c37221:	8b f3                	mov    esi,ebx
    713079c37223:	83 fe 03             	cmp    esi,0x3
    713079c37226:	0f 85 f4 07 00 00    	jne    0x713079c37a20
    713079c3722c:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c37233:	8b 76 08             	mov    esi,DWORD PTR [rsi+0x8]
    713079c37236:	49 8b fb             	mov    rdi,r11
    713079c37239:	49 bb f0 22 27 77 30 	movabs r11,0x7130772722f0
    713079c37240:	71 00 00 
    713079c37243:	41 ff 13             	call   QWORD PTR [r11]
    713079c37246:	48 8b f0             	mov    rsi,rax
    713079c37249:	48 bf 60 d1 66 79 30 	movabs rdi,0x71307966d160
    713079c37250:	71 00 00 
    713079c37253:	e8 88 96 ac ff       	call   0x7130797008e0
    713079c37258:	48 8b f0             	mov    rsi,rax
    713079c3725b:	48 8b 95 98 02 00 00 	mov    rdx,QWORD PTR [rbp+0x298]
    713079c37262:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
    713079c37265:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c3726c:	33 c9                	xor    ecx,ecx
    713079c3726e:	ff 15 04 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc16604]        # 0x71307984d878
    713079c37274:	48 89 85 60 02 00 00 	mov    QWORD PTR [rbp+0x260],rax
    713079c3727b:	48 89 95 68 02 00 00 	mov    QWORD PTR [rbp+0x268],rdx
    713079c37282:	48 8b 9d 60 02 00 00 	mov    rbx,QWORD PTR [rbp+0x260]
    713079c37289:	48 85 db             	test   rbx,rbx
    713079c3728c:	0f 84 6b fe ff ff    	je     0x713079c370fd
    713079c37292:	e9 b2 07 00 00       	jmp    0x713079c37a49
    713079c37297:	4c 8d bf e8 00 00 00 	lea    r15,[rdi+0xe8]
    713079c3729e:	4c 8b 77 08          	mov    r14,QWORD PTR [rdi+0x8]
    713079c372a2:	4c 8b 6f 10          	mov    r13,QWORD PTR [rdi+0x10]
    713079c372a6:	8b f3                	mov    esi,ebx
    713079c372a8:	83 fe 04             	cmp    esi,0x4
    713079c372ab:	74 09                	je     0x713079c372b6
    713079c372ad:	83 fe 0d             	cmp    esi,0xd
    713079c372b0:	0f 85 6c 05 00 00    	jne    0x713079c37822
    713079c372b6:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c372bd:	8b 5e 08             	mov    ebx,DWORD PTR [rsi+0x8]
    713079c372c0:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c372c7:	4c 8b 26             	mov    r12,QWORD PTR [rsi]
    713079c372ca:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c372d1:	48 8b 47 70          	mov    rax,QWORD PTR [rdi+0x70]
    713079c372d5:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
    713079c372dc:	33 f6                	xor    esi,esi
    713079c372de:	48 89 75 a8          	mov    QWORD PTR [rbp-0x58],rsi
    713079c372e2:	48 89 75 a0          	mov    QWORD PTR [rbp-0x60],rsi
    713079c372e6:	41 3b 5d 08          	cmp    ebx,DWORD PTR [r13+0x8]
    713079c372ea:	0f 83 b9 07 00 00    	jae    0x713079c37aa9
    713079c372f0:	8b f3                	mov    esi,ebx
    713079c372f2:	49 8b 74 f5 10       	mov    rsi,QWORD PTR [r13+rsi*8+0x10]
    713079c372f7:	49 bb a8 32 80 99 28 	movabs r11,0x7128998032a8
    713079c372fe:	71 00 00 
    713079c37301:	49 3b 33             	cmp    rsi,QWORD PTR [r11]
    713079c37304:	0f 84 38 05 00 00    	je     0x713079c37842
    713079c3730a:	33 c0                	xor    eax,eax
    713079c3730c:	48 89 45 a8          	mov    QWORD PTR [rbp-0x58],rax
    713079c37310:	48 89 45 a0          	mov    QWORD PTR [rbp-0x60],rax
    713079c37314:	49 8b ff             	mov    rdi,r15
    713079c37317:	ff 15 e3 64 c1 ff    	call   QWORD PTR [rip+0xffffffffffc164e3]        # 0x71307984d800
    713079c3731d:	e9 db fd ff ff       	jmp    0x713079c370fd
    713079c37322:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c37329:	ff 15 69 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc16669]        # 0x71307984d998
    713079c3732f:	e9 c9 fd ff ff       	jmp    0x713079c370fd
    713079c37334:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c3733b:	ff 15 3f 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1663f]        # 0x71307984d980
    713079c37341:	e9 b7 fd ff ff       	jmp    0x713079c370fd
    713079c37346:	c5 fc 57 c0          	vxorps ymm0,ymm0,ymm0
    713079c3734a:	c5 fe 7f 45 b0       	vmovdqu YMMWORD PTR [rbp-0x50],ymm0
    713079c3734f:	c5 fa 7f 45 c8       	vmovdqu XMMWORD PTR [rbp-0x38],xmm0
    713079c37354:	48 8d 7d b0          	lea    rdi,[rbp-0x50]
    713079c37358:	be 1b 00 00 00       	mov    esi,0x1b
    713079c3735d:	ba 01 00 00 00       	mov    edx,0x1
    713079c37362:	ff 15 00 78 87 ff    	call   QWORD PTR [rip+0xffffffffff877800]        # 0x7130794aeb68
    713079c37368:	c5 fe 6f 45 b0       	vmovdqu ymm0,YMMWORD PTR [rbp-0x50]
    713079c3736d:	c5 fe 7f 85 28 02 00 	vmovdqu YMMWORD PTR [rbp+0x228],ymm0
    713079c37374:	00 
    713079c37375:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    713079c37379:	48 89 bd 48 02 00 00 	mov    QWORD PTR [rbp+0x248],rdi
    713079c37380:	8b bd 38 02 00 00    	mov    edi,DWORD PTR [rbp+0x238]
    713079c37386:	3b bd 48 02 00 00    	cmp    edi,DWORD PTR [rbp+0x248]
    713079c3738c:	0f 87 10 07 00 00    	ja     0x713079c37aa2
    713079c37392:	48 8b b5 40 02 00 00 	mov    rsi,QWORD PTR [rbp+0x240]
    713079c37399:	8b c7                	mov    eax,edi
    713079c3739b:	48 8d 34 46          	lea    rsi,[rsi+rax*2]
    713079c3739f:	8b 85 48 02 00 00    	mov    eax,DWORD PTR [rbp+0x248]
    713079c373a5:	2b c7                	sub    eax,edi
    713079c373a7:	83 f8 1b             	cmp    eax,0x1b
    713079c373aa:	0f 82 ff 06 00 00    	jb     0x713079c37aaf
    713079c373b0:	c5 fc 10 05 a8 0a 00 	vmovups ymm0,YMMWORD PTR [rip+0xaa8]        # 0x713079c37e60
    713079c373b7:	00 
    713079c373b8:	c5 fc 11 06          	vmovups YMMWORD PTR [rsi],ymm0
    713079c373bc:	c5 f8 10 05 bc 0a 00 	vmovups xmm0,XMMWORD PTR [rip+0xabc]        # 0x713079c37e80
    713079c373c3:	00 
    713079c373c4:	c5 f8 11 46 20       	vmovups XMMWORD PTR [rsi+0x20],xmm0
    713079c373c9:	c7 46 30 65 00 3a 00 	mov    DWORD PTR [rsi+0x30],0x3a0065
    713079c373d0:	66 c7 46 34 20 00    	mov    WORD PTR [rsi+0x34],0x20
    713079c373d6:	8b bd 38 02 00 00    	mov    edi,DWORD PTR [rbp+0x238]
    713079c373dc:	83 c7 1b             	add    edi,0x1b
    713079c373df:	89 bd 38 02 00 00    	mov    DWORD PTR [rbp+0x238],edi
    713079c373e5:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c373ec:	8b 76 10             	mov    esi,DWORD PTR [rsi+0x10]
    713079c373ef:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    713079c373f6:	ff 15 94 82 a4 ff    	call   QWORD PTR [rip+0xffffffffffa48294]        # 0x71307967f690
    713079c373fc:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    713079c37403:	71 00 00 
    713079c37406:	e8 b5 9e a1 7c       	call   0x7130f66512c0
    713079c3740b:	48 8b d8             	mov    rbx,rax
    713079c3740e:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    713079c37415:	ff 15 7d 77 87 ff    	call   QWORD PTR [rip+0xffffffffff87777d]        # 0x7130794aeb98
    713079c3741b:	48 8b f0             	mov    rsi,rax
    713079c3741e:	48 8b fb             	mov    rdi,rbx
    713079c37421:	ff 15 b1 ea 93 ff    	call   QWORD PTR [rip+0xffffffffff93eab1]        # 0x713079575ed8
    713079c37427:	48 8b fb             	mov    rdi,rbx
    713079c3742a:	e8 71 ab 77 7c       	call   0x7130f63b1fa0
    713079c3742f:	cc                   	int3
    713079c37430:	48 83 bf 90 00 00 00 	cmp    QWORD PTR [rdi+0x90],0x0
    713079c37437:	00 
    713079c37438:	0f 85 dc 00 00 00    	jne    0x713079c3751a
    713079c3743e:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c37445:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c37448:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    713079c3744f:	ff 15 6b 64 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1646b]        # 0x71307984d8c0
    713079c37455:	48 8b d8             	mov    rbx,rax
    713079c37458:	48 bf a0 27 49 78 30 	movabs rdi,0x7130784927a0
    713079c3745f:	71 00 00 
    713079c37462:	be 01 00 00 00       	mov    esi,0x1
    713079c37467:	e8 e4 9f a1 7c       	call   0x7130f6651450
    713079c3746c:	4c 8b f8             	mov    r15,rax
    713079c3746f:	49 8d 7f 10          	lea    rdi,[r15+0x10]
    713079c37473:	48 8b f3             	mov    rsi,rbx
    713079c37476:	e8 c5 8b 61 fd       	call   0x713077250040
    713079c3747b:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37482:	48 8b 57 70          	mov    rdx,QWORD PTR [rdi+0x70]
    713079c37486:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c3748d:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c37490:	49 8b ff             	mov    rdi,r15
    713079c37493:	ff 15 ff 02 c1 ff    	call   QWORD PTR [rip+0xffffffffffc102ff]        # 0x713079847798
    713079c37499:	48 8b d8             	mov    rbx,rax
    713079c3749c:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c374a3:	4c 8b 7f 70          	mov    r15,QWORD PTR [rdi+0x70]
    713079c374a7:	48 bf a0 6f ad 79 30 	movabs rdi,0x713079ad6fa0
    713079c374ae:	71 00 00 
    713079c374b1:	e8 0a 9e a1 7c       	call   0x7130f66512c0
    713079c374b6:	4c 8b f0             	mov    r14,rax
    713079c374b9:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c374c0:	4c 8b 2f             	mov    r13,QWORD PTR [rdi]
    713079c374c3:	49 8d 7e 08          	lea    rdi,[r14+0x8]
    713079c374c7:	48 8b f3             	mov    rsi,rbx
    713079c374ca:	e8 71 8b 61 fd       	call   0x713077250040
    713079c374cf:	49 8d 7e 10          	lea    rdi,[r14+0x10]
    713079c374d3:	49 8b f7             	mov    rsi,r15
    713079c374d6:	e8 65 8b 61 fd       	call   0x713077250040
    713079c374db:	49 8d 7e 18          	lea    rdi,[r14+0x18]
    713079c374df:	49 8b f5             	mov    rsi,r13
    713079c374e2:	e8 59 8b 61 fd       	call   0x713077250040
    713079c374e7:	48 bf b8 16 80 99 28 	movabs rdi,0x7128998016b8
    713079c374ee:	71 00 00 
    713079c374f1:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c374f4:	49 8d 7e 20          	lea    rdi,[r14+0x20]
    713079c374f8:	e8 43 8b 61 fd       	call   0x713077250040
    713079c374fd:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37504:	48 8d bf 90 00 00 00 	lea    rdi,[rdi+0x90]
    713079c3750b:	49 8b f6             	mov    rsi,r14
    713079c3750e:	e8 2d 8b 61 fd       	call   0x713077250040
    713079c37513:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c3751a:	48 8b 97 90 00 00 00 	mov    rdx,QWORD PTR [rdi+0x90]
    713079c37521:	48 8b 8f 80 00 00 00 	mov    rcx,QWORD PTR [rdi+0x80]
    713079c37528:	4c 8b 87 88 00 00 00 	mov    r8,QWORD PTR [rdi+0x88]
    713079c3752f:	38 12                	cmp    BYTE PTR [rdx],dl
    713079c37531:	48 8d 75 80          	lea    rsi,[rbp-0x80]
    713079c37535:	48 8b fa             	mov    rdi,rdx
    713079c37538:	48 8b d1             	mov    rdx,rcx
    713079c3753b:	49 8b c8             	mov    rcx,r8
    713079c3753e:	45 33 c0             	xor    r8d,r8d
    713079c37541:	ff 15 29 d0 ed ff    	call   QWORD PTR [rip+0xffffffffffedd029]        # 0x713079b14570
    713079c37547:	48 8b 5d 80          	mov    rbx,QWORD PTR [rbp-0x80]
    713079c3754b:	4c 0f bf 7d 88       	movsx  r15,WORD PTR [rbp-0x78]
    713079c37550:	4c 8b 75 90          	mov    r14,QWORD PTR [rbp-0x70]
    713079c37554:	44 0f b6 6d 98       	movzx  r13d,BYTE PTR [rbp-0x68]
    713079c37559:	48 85 db             	test   rbx,rbx
    713079c3755c:	0f 84 d4 00 00 00    	je     0x713079c37636
    713079c37562:	48 8b f3             	mov    rsi,rbx
    713079c37565:	48 bf 48 7c b0 79 30 	movabs rdi,0x713079b07c48
    713079c3756c:	71 00 00 
    713079c3756f:	e8 ac 51 ab ff       	call   0x7130796ec720
    713079c37574:	4c 8b f0             	mov    r14,rax
    713079c37577:	4d 85 f6             	test   r14,r14
    713079c3757a:	0f 84 98 00 00 00    	je     0x713079c37618
    713079c37580:	41 8b 7e 34          	mov    edi,DWORD PTR [r14+0x34]
    713079c37584:	81 e7 00 00 00 11    	and    edi,0x11000000
    713079c3758a:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    713079c37590:	74 0b                	je     0x713079c3759d
    713079c37592:	49 8b fe             	mov    rdi,r14
    713079c37595:	33 f6                	xor    esi,esi
    713079c37597:	ff 15 7b e2 50 ff    	call   QWORD PTR [rip+0xffffffffff50e27b]        # 0x713079145818
    713079c3759d:	4d 8b 66 38          	mov    r12,QWORD PTR [r14+0x38]
    713079c375a1:	45 0f b6 76 40       	movzx  r14d,BYTE PTR [r14+0x40]
    713079c375a6:	4c 89 a5 88 02 00 00 	mov    QWORD PTR [rbp+0x288],r12
    713079c375ad:	44 88 b5 90 02 00 00 	mov    BYTE PTR [rbp+0x290],r14b
    713079c375b4:	48 bf b8 16 80 99 28 	movabs rdi,0x7128998016b8
    713079c375bb:	71 00 00 
    713079c375be:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c375c1:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c375c8:	48 8d bf 80 00 00 00 	lea    rdi,[rdi+0x80]
    713079c375cf:	e8 6c 8a 61 fd       	call   0x713077250040
    713079c375d4:	33 ff                	xor    edi,edi
    713079c375d6:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c375dd:	48 89 bb 88 00 00 00 	mov    QWORD PTR [rbx+0x88],rdi
    713079c375e4:	80 bd 90 02 00 00 00 	cmp    BYTE PTR [rbp+0x290],0x0
    713079c375eb:	74 55                	je     0x713079c37642
    713079c375ed:	48 8d bd 88 02 00 00 	lea    rdi,[rbp+0x288]
    713079c375f4:	ff 15 56 63 c1 ff    	call   QWORD PTR [rip+0xffffffffffc16356]        # 0x71307984d950
    713079c375fa:	48 8b f0             	mov    rsi,rax
    713079c375fd:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    713079c37604:	e8 37 8a 61 fd       	call   0x713077250040
    713079c37609:	c6 83 e1 00 00 00 01 	mov    BYTE PTR [rbx+0xe1],0x1
    713079c37610:	48 8b fb             	mov    rdi,rbx
    713079c37613:	e9 c7 05 00 00       	jmp    0x713079c37bdf
    713079c37618:	48 8b fb             	mov    rdi,rbx
    713079c3761b:	41 8b f7             	mov    esi,r15d
    713079c3761e:	49 bb 38 23 27 77 30 	movabs r11,0x713077272338
    713079c37625:	71 00 00 
    713079c37628:	41 ff 13             	call   QWORD PTR [r11]
    713079c3762b:	4c 8b e0             	mov    r12,rax
    713079c3762e:	44 8b f2             	mov    r14d,edx
    713079c37631:	e9 70 ff ff ff       	jmp    0x713079c375a6
    713079c37636:	4d 8b e6             	mov    r12,r14
    713079c37639:	45 0f b6 f5          	movzx  r14d,r13b
    713079c3763d:	e9 64 ff ff ff       	jmp    0x713079c375a6
    713079c37642:	48 8b b3 90 00 00 00 	mov    rsi,QWORD PTR [rbx+0x90]
    713079c37649:	48 8b 76 20          	mov    rsi,QWORD PTR [rsi+0x20]
    713079c3764d:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c37654:	ff 15 a6 61 c1 ff    	call   QWORD PTR [rip+0xffffffffffc161a6]        # 0x71307984d800
    713079c3765a:	33 f6                	xor    esi,esi
    713079c3765c:	48 89 b3 90 00 00 00 	mov    QWORD PTR [rbx+0x90],rsi
    713079c37663:	e9 95 fa ff ff       	jmp    0x713079c370fd
    713079c37668:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c3766f:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c37672:	48 81 c7 e8 00 00 00 	add    rdi,0xe8
    713079c37679:	ff 15 41 62 c1 ff    	call   QWORD PTR [rip+0xffffffffffc16241]        # 0x71307984d8c0
    713079c3767f:	48 8b f0             	mov    rsi,rax
    713079c37682:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c37689:	48 8d bb 98 00 00 00 	lea    rdi,[rbx+0x98]
    713079c37690:	e8 ab 89 61 fd       	call   0x713077250040
    713079c37695:	66 c7 83 e0 00 00 00 	mov    WORD PTR [rbx+0xe0],0x101
    713079c3769c:	01 01 
    713079c3769e:	ff 83 dc 00 00 00    	inc    DWORD PTR [rbx+0xdc]
    713079c376a4:	48 8b fb             	mov    rdi,rbx
    713079c376a7:	e9 33 05 00 00       	jmp    0x713079c37bdf
    713079c376ac:	48 8b 85 98 02 00 00 	mov    rax,QWORD PTR [rbp+0x298]
    713079c376b3:	48 8d 3c 24          	lea    rdi,[rsp]
    713079c376b7:	48 8b f0             	mov    rsi,rax
    713079c376ba:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    713079c376bd:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    713079c376c1:	48 83 c6 08          	add    rsi,0x8
    713079c376c5:	48 83 c7 08          	add    rdi,0x8
    713079c376c9:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c376cb:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c376cd:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c376d4:	ff 15 1e 63 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1631e]        # 0x71307984d9f8
    713079c376da:	85 c0                	test   eax,eax
    713079c376dc:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c376e3:	74 42                	je     0x713079c37727
    713079c376e5:	e9 f5 04 00 00       	jmp    0x713079c37bdf
    713079c376ea:	48 8b 85 98 02 00 00 	mov    rax,QWORD PTR [rbp+0x298]
    713079c376f1:	48 8d 3c 24          	lea    rdi,[rsp]
    713079c376f5:	48 8b f0             	mov    rsi,rax
    713079c376f8:	48 8b 0e             	mov    rcx,QWORD PTR [rsi]
    713079c376fb:	48 89 0c 24          	mov    QWORD PTR [rsp],rcx
    713079c376ff:	48 83 c6 08          	add    rsi,0x8
    713079c37703:	48 83 c7 08          	add    rdi,0x8
    713079c37707:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c37709:	48 a5                	movs   QWORD PTR es:[rdi],QWORD PTR ds:[rsi]
    713079c3770b:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37712:	ff 15 b0 62 c1 ff    	call   QWORD PTR [rip+0xffffffffffc162b0]        # 0x71307984d9c8
    713079c37718:	85 c0                	test   eax,eax
    713079c3771a:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37721:	0f 85 b8 04 00 00    	jne    0x713079c37bdf
    713079c37727:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c3772e:	ff 15 ac 62 c1 ff    	call   QWORD PTR [rip+0xffffffffffc162ac]        # 0x71307984d9e0
    713079c37734:	e9 c4 f9 ff ff       	jmp    0x713079c370fd
    713079c37739:	48 8d b7 e8 00 00 00 	lea    rsi,[rdi+0xe8]
    713079c37740:	48 8b 85 98 02 00 00 	mov    rax,QWORD PTR [rbp+0x298]
    713079c37747:	48 8b 18             	mov    rbx,QWORD PTR [rax]
    713079c3774a:	8b 46 30             	mov    eax,DWORD PTR [rsi+0x30]
    713079c3774d:	85 c0                	test   eax,eax
    713079c3774f:	0f 84 3f 02 00 00    	je     0x713079c37994
    713079c37755:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c37758:	ff c8                	dec    eax
    713079c3775a:	3b 46 08             	cmp    eax,DWORD PTR [rsi+0x8]
    713079c3775d:	0f 83 46 03 00 00    	jae    0x713079c37aa9
    713079c37763:	48 8b 74 c6 10       	mov    rsi,QWORD PTR [rsi+rax*8+0x10]
    713079c37768:	48 85 f6             	test   rsi,rsi
    713079c3776b:	0f 84 de 01 00 00    	je     0x713079c3794f
    713079c37771:	4c 8b fe             	mov    r15,rsi
    713079c37774:	48 b8 70 23 af 79 30 	movabs rax,0x713079af2370
    713079c3777b:	71 00 00 
    713079c3777e:	49 39 07             	cmp    QWORD PTR [r15],rax
    713079c37781:	0f 85 f6 01 00 00    	jne    0x713079c3797d
    713079c37787:	4d 85 ff             	test   r15,r15
    713079c3778a:	0f 84 04 02 00 00    	je     0x713079c37994
    713079c37790:	48 b8 70 23 af 79 30 	movabs rax,0x713079af2370
    713079c37797:	71 00 00 
    713079c3779a:	49 39 07             	cmp    QWORD PTR [r15],rax
    713079c3779d:	0f 85 0d 02 00 00    	jne    0x713079c379b0
    713079c377a3:	49 8b ff             	mov    rdi,r15
    713079c377a6:	ff 15 6c ac eb ff    	call   QWORD PTR [rip+0xffffffffffebac6c]        # 0x713079af2418
    713079c377ac:	85 c0                	test   eax,eax
    713079c377ae:	0f 84 11 02 00 00    	je     0x713079c379c5
    713079c377b4:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c377bb:	4c 8d b3 e8 00 00 00 	lea    r14,[rbx+0xe8]
    713079c377c2:	48 bf 70 23 af 79 30 	movabs rdi,0x713079af2370
    713079c377c9:	71 00 00 
    713079c377cc:	49 39 3f             	cmp    QWORD PTR [r15],rdi
    713079c377cf:	0f 85 33 02 00 00    	jne    0x713079c37a08
    713079c377d5:	49 8b 77 08          	mov    rsi,QWORD PTR [r15+0x8]
    713079c377d9:	49 8b fe             	mov    rdi,r14
    713079c377dc:	ff 15 1e 60 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1601e]        # 0x71307984d800
    713079c377e2:	45 33 ff             	xor    r15d,r15d
    713079c377e5:	44 89 bd bc 02 00 00 	mov    DWORD PTR [rbp+0x2bc],r15d
    713079c377ec:	e9 0c f9 ff ff       	jmp    0x713079c370fd
    713079c377f1:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c377f8:	ff 15 b2 61 c1 ff    	call   QWORD PTR [rip+0xffffffffffc161b2]        # 0x71307984d9b0
    713079c377fe:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    713079c37804:	e9 f4 f8 ff ff       	jmp    0x713079c370fd
    713079c37809:	48 8b 87 88 00 00 00 	mov    rax,QWORD PTR [rdi+0x88]
    713079c37810:	33 c9                	xor    ecx,ecx
    713079c37812:	48 89 8f 88 00 00 00 	mov    QWORD PTR [rdi+0x88],rcx
    713079c37819:	48 8b f8             	mov    rdi,rax
    713079c3781c:	e8 7f a7 77 7c       	call   0x7130f63b1fa0
    713079c37821:	cc                   	int3
    713079c37822:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c37829:	48 be 40 44 e1 74 30 	movabs rsi,0x713074e14440
    713079c37830:	71 00 00 
    713079c37833:	ff 15 ff 66 a4 ff    	call   QWORD PTR [rip+0xffffffffffa466ff]        # 0x71307967df38
    713079c37839:	48 8b f8             	mov    rdi,rax
    713079c3783c:	e8 5f a7 77 7c       	call   0x7130f63b1fa0
    713079c37841:	cc                   	int3
    713079c37842:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    713079c37849:	00 
    713079c3784a:	0f 85 ac 00 00 00    	jne    0x713079c378fc
    713079c37850:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c37854:	8b f3                	mov    esi,ebx
    713079c37856:	49 bb 08 23 27 77 30 	movabs r11,0x713077272308
    713079c3785d:	71 00 00 
    713079c37860:	41 ff 13             	call   QWORD PTR [r11]
    713079c37863:	48 8b f8             	mov    rdi,rax
    713079c37866:	be 3c 00 00 00       	mov    esi,0x3c
    713079c3786b:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c3786d:	ff 15 4d 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1664d]        # 0x71307984dec0
    713079c37873:	85 c0                	test   eax,eax
    713079c37875:	0f 85 81 00 00 00    	jne    0x713079c378fc
    713079c3787b:	4c 8b ad 78 ff ff ff 	mov    r13,QWORD PTR [rbp-0x88]
    713079c37882:	45 38 6d 00          	cmp    BYTE PTR [r13+0x0],r13b
    713079c37886:	49 8b fd             	mov    rdi,r13
    713079c37889:	ff 15 c9 fc c0 ff    	call   QWORD PTR [rip+0xffffffffffc0fcc9]        # 0x713079847558
    713079c3788f:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
    713079c37896:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c3789a:	8b f3                	mov    esi,ebx
    713079c3789c:	49 bb 10 23 27 77 30 	movabs r11,0x713077272310
    713079c378a3:	71 00 00 
    713079c378a6:	41 ff 13             	call   QWORD PTR [r11]
    713079c378a9:	48 8b f0             	mov    rsi,rax
    713079c378ac:	48 8b bd 70 ff ff ff 	mov    rdi,QWORD PTR [rbp-0x90]
    713079c378b3:	48 8d 55 a8          	lea    rdx,[rbp-0x58]
    713079c378b7:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c378b9:	ff 15 a1 60 8a fe    	call   QWORD PTR [rip+0xfffffffffe8a60a1]        # 0x7130784dd960
    713079c378bf:	85 c0                	test   eax,eax
    713079c378c1:	74 09                	je     0x713079c378cc
    713079c378c3:	48 8b 75 a8          	mov    rsi,QWORD PTR [rbp-0x58]
    713079c378c7:	e9 3e fa ff ff       	jmp    0x713079c3730a
    713079c378cc:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c378d0:	8b f3                	mov    esi,ebx
    713079c378d2:	49 bb 18 23 27 77 30 	movabs r11,0x713077272318
    713079c378d9:	71 00 00 
    713079c378dc:	41 ff 13             	call   QWORD PTR [r11]
    713079c378df:	48 8b f0             	mov    rsi,rax
    713079c378e2:	48 8d 55 a0          	lea    rdx,[rbp-0x60]
    713079c378e6:	49 8b fd             	mov    rdi,r13
    713079c378e9:	ff 15 a9 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc166a9]        # 0x71307984df98
    713079c378ef:	85 c0                	test   eax,eax
    713079c378f1:	74 09                	je     0x713079c378fc
    713079c378f3:	48 8b 75 a0          	mov    rsi,QWORD PTR [rbp-0x60]
    713079c378f7:	e9 0e fa ff ff       	jmp    0x713079c3730a
    713079c378fc:	41 80 be 95 00 00 00 	cmp    BYTE PTR [r14+0x95],0x0
    713079c37903:	00 
    713079c37904:	75 21                	jne    0x713079c37927
    713079c37906:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c3790a:	8b f3                	mov    esi,ebx
    713079c3790c:	49 bb 00 23 27 77 30 	movabs r11,0x713077272300
    713079c37913:	71 00 00 
    713079c37916:	41 ff 13             	call   QWORD PTR [r11]
    713079c37919:	48 8b f8             	mov    rdi,rax
    713079c3791c:	49 8b f4             	mov    rsi,r12
    713079c3791f:	ff 15 8b 66 c1 ff    	call   QWORD PTR [rip+0xffffffffffc1668b]        # 0x71307984dfb0
    713079c37925:	eb 1f                	jmp    0x713079c37946
    713079c37927:	49 8b 7e 20          	mov    rdi,QWORD PTR [r14+0x20]
    713079c3792b:	8b f3                	mov    esi,ebx
    713079c3792d:	49 bb f8 22 27 77 30 	movabs r11,0x7130772722f8
    713079c37934:	71 00 00 
    713079c37937:	41 ff 13             	call   QWORD PTR [r11]
    713079c3793a:	48 8b f8             	mov    rdi,rax
    713079c3793d:	49 8b f4             	mov    rsi,r12
    713079c37940:	ff 15 da 65 c1 ff    	call   QWORD PTR [rip+0xffffffffffc165da]        # 0x71307984df20
    713079c37946:	48 8b f8             	mov    rdi,rax
    713079c37949:	e8 52 a6 77 7c       	call   0x7130f63b1fa0
    713079c3794e:	cc                   	int3
    713079c3794f:	48 bf 88 2f 94 78 30 	movabs rdi,0x713078942f88
    713079c37956:	71 00 00 
    713079c37959:	e8 62 99 a1 7c       	call   0x7130f66512c0
    713079c3795e:	48 8b d8             	mov    rbx,rax
    713079c37961:	48 8b fb             	mov    rdi,rbx
    713079c37964:	48 be 18 d2 e0 74 30 	movabs rsi,0x713074e0d218
    713079c3796b:	71 00 00 
    713079c3796e:	ff 15 64 e5 93 ff    	call   QWORD PTR [rip+0xffffffffff93e564]        # 0x713079575ed8
    713079c37974:	48 8b fb             	mov    rdi,rbx
    713079c37977:	e8 24 a6 77 7c       	call   0x7130f63b1fa0
    713079c3797c:	cc                   	int3
    713079c3797d:	48 bf 58 37 83 79 30 	movabs rdi,0x713079833758
    713079c37984:	71 00 00 
    713079c37987:	e8 74 7b ab ff       	call   0x7130796ef500
    713079c3798c:	4c 8b f8             	mov    r15,rax
    713079c3798f:	e9 f3 fd ff ff       	jmp    0x713079c37787
    713079c37994:	48 8b f3             	mov    rsi,rbx
    713079c37997:	48 bf e8 48 e1 74 30 	movabs rdi,0x713074e148e8
    713079c3799e:	71 00 00 
    713079c379a1:	ff 15 d1 64 c1 ff    	call   QWORD PTR [rip+0xffffffffffc164d1]        # 0x71307984de78
    713079c379a7:	48 8b f8             	mov    rdi,rax
    713079c379aa:	e8 f1 a5 77 7c       	call   0x7130f63b1fa0
    713079c379af:	cc                   	int3
    713079c379b0:	49 8b ff             	mov    rdi,r15
    713079c379b3:	49 bb 20 23 27 77 30 	movabs r11,0x713077272320
    713079c379ba:	71 00 00 
    713079c379bd:	41 ff 13             	call   QWORD PTR [r11]
    713079c379c0:	e9 e7 fd ff ff       	jmp    0x713079c377ac
    713079c379c5:	48 8b b5 98 02 00 00 	mov    rsi,QWORD PTR [rbp+0x298]
    713079c379cc:	48 8b 36             	mov    rsi,QWORD PTR [rsi]
    713079c379cf:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c379d6:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c379dd:	ff 15 dd 5e c1 ff    	call   QWORD PTR [rip+0xffffffffffc15edd]        # 0x71307984d8c0
    713079c379e3:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c379ea:	ff 15 d8 62 a4 ff    	call   QWORD PTR [rip+0xffffffffffa462d8]        # 0x71307967dcc8
    713079c379f0:	89 83 d8 00 00 00    	mov    DWORD PTR [rbx+0xd8],eax
    713079c379f6:	41 bf 01 00 00 00    	mov    r15d,0x1
    713079c379fc:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c37a03:	e9 dd fd ff ff       	jmp    0x713079c377e5
    713079c37a08:	49 8b ff             	mov    rdi,r15
    713079c37a0b:	49 bb 28 23 27 77 30 	movabs r11,0x713077272328
    713079c37a12:	71 00 00 
    713079c37a15:	41 ff 13             	call   QWORD PTR [r11]
    713079c37a18:	48 8b f0             	mov    rsi,rax
    713079c37a1b:	e9 b9 fd ff ff       	jmp    0x713079c377d9
    713079c37a20:	83 fe 08             	cmp    esi,0x8
    713079c37a23:	0f 84 03 f8 ff ff    	je     0x713079c3722c
    713079c37a29:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c37a30:	48 be 68 43 e1 74 30 	movabs rsi,0x713074e14368
    713079c37a37:	71 00 00 
    713079c37a3a:	ff 15 f8 64 a4 ff    	call   QWORD PTR [rip+0xffffffffffa464f8]        # 0x71307967df38
    713079c37a40:	48 8b f8             	mov    rdi,rax
    713079c37a43:	e8 58 a5 77 7c       	call   0x7130f63b1fa0
    713079c37a48:	cc                   	int3
    713079c37a49:	48 8b f3             	mov    rsi,rbx
    713079c37a4c:	48 bf 60 8f 5d 78 30 	movabs rdi,0x7130785d8f60
    713079c37a53:	71 00 00 
    713079c37a56:	e8 c5 4c ab ff       	call   0x7130796ec720
    713079c37a5b:	48 85 c0             	test   rax,rax
    713079c37a5e:	74 25                	je     0x713079c37a85
    713079c37a60:	8b 78 34             	mov    edi,DWORD PTR [rax+0x34]
    713079c37a63:	81 e7 00 00 00 11    	and    edi,0x11000000
    713079c37a69:	81 ff 00 00 00 01    	cmp    edi,0x1000000
    713079c37a6f:	0f 84 88 f6 ff ff    	je     0x713079c370fd
    713079c37a75:	48 8b f8             	mov    rdi,rax
    713079c37a78:	33 f6                	xor    esi,esi
    713079c37a7a:	ff 15 98 dd 50 ff    	call   QWORD PTR [rip+0xffffffffff50dd98]        # 0x713079145818
    713079c37a80:	e9 78 f6 ff ff       	jmp    0x713079c370fd
    713079c37a85:	48 8b fb             	mov    rdi,rbx
    713079c37a88:	48 0f bf b5 68 02 00 	movsx  rsi,WORD PTR [rbp+0x268]
    713079c37a8f:	00 
    713079c37a90:	49 bb 30 23 27 77 30 	movabs r11,0x713077272330
    713079c37a97:	71 00 00 
    713079c37a9a:	41 ff 13             	call   QWORD PTR [r11]
    713079c37a9d:	e9 5b f6 ff ff       	jmp    0x713079c370fd
    713079c37aa2:	ff 15 40 fb a3 ff    	call   QWORD PTR [rip+0xffffffffffa3fb40]        # 0x7130796775e8
    713079c37aa8:	cc                   	int3
    713079c37aa9:	e8 5a 9b 84 fe       	call   0x713078481608
    713079c37aae:	cc                   	int3
    713079c37aaf:	48 8d bd 28 02 00 00 	lea    rdi,[rbp+0x228]
    713079c37ab6:	48 be 48 42 e1 74 30 	movabs rsi,0x713074e14248
    713079c37abd:	71 00 00 
    713079c37ac0:	ff 15 c2 ca ed ff    	call   QWORD PTR [rip+0xffffffffffedcac2]        # 0x713079b14588
    713079c37ac6:	e9 1a f9 ff ff       	jmp    0x713079c373e5
    713079c37acb:	33 ff                	xor    edi,edi
    713079c37acd:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c37ad4:	89 bb dc 00 00 00    	mov    DWORD PTR [rbx+0xdc],edi
    713079c37ada:	48 8b fb             	mov    rdi,rbx
    713079c37add:	80 bf e2 00 00 00 00 	cmp    BYTE PTR [rdi+0xe2],0x0
    713079c37ae4:	0f 85 f5 00 00 00    	jne    0x713079c37bdf
    713079c37aea:	83 bd bc 02 00 00 00 	cmp    DWORD PTR [rbp+0x2bc],0x0
    713079c37af1:	0f 84 e8 00 00 00    	je     0x713079c37bdf
    713079c37af7:	48 8b 77 08          	mov    rsi,QWORD PTR [rdi+0x8]
    713079c37afb:	48 8b 76 50          	mov    rsi,QWORD PTR [rsi+0x50]
    713079c37aff:	44 8b 9f d8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xd8]
    713079c37b06:	48 b8 48 bc 82 79 30 	movabs rax,0x71307982bc48
    713079c37b0d:	71 00 00 
    713079c37b10:	48 39 06             	cmp    QWORD PTR [rsi],rax
    713079c37b13:	75 7a                	jne    0x713079c37b8f
    713079c37b15:	44 3b 5e 10          	cmp    r11d,DWORD PTR [rsi+0x10]
    713079c37b19:	0f 83 aa 00 00 00    	jae    0x713079c37bc9
    713079c37b1f:	48 8b 76 08          	mov    rsi,QWORD PTR [rsi+0x8]
    713079c37b23:	44 3b 5e 08          	cmp    r11d,DWORD PTR [rsi+0x8]
    713079c37b27:	0f 83 ac 00 00 00    	jae    0x713079c37bd9
    713079c37b2d:	4a 8b 5c de 10       	mov    rbx,QWORD PTR [rsi+r11*8+0x10]
    713079c37b32:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37b39:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    713079c37b40:	83 78 08 00          	cmp    DWORD PTR [rax+0x8],0x0
    713079c37b44:	75 18                	jne    0x713079c37b5e
    713079c37b46:	33 c0                	xor    eax,eax
    713079c37b48:	89 85 bc 02 00 00    	mov    DWORD PTR [rbp+0x2bc],eax
    713079c37b4e:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
    713079c37b52:	48 89 85 b0 02 00 00 	mov    QWORD PTR [rbp+0x2b0],rax
    713079c37b59:	e9 bc f5 ff ff       	jmp    0x713079c3711a
    713079c37b5e:	48 8b 87 c0 00 00 00 	mov    rax,QWORD PTR [rdi+0xc0]
    713079c37b65:	8b 8f d8 00 00 00    	mov    ecx,DWORD PTR [rdi+0xd8]
    713079c37b6b:	3b 48 08             	cmp    ecx,DWORD PTR [rax+0x8]
    713079c37b6e:	73 69                	jae    0x713079c37bd9
    713079c37b70:	48 8d 44 c8 10       	lea    rax,[rax+rcx*8+0x10]
    713079c37b75:	80 38 00             	cmp    BYTE PTR [rax],0x0
    713079c37b78:	75 cc                	jne    0x713079c37b46
    713079c37b7a:	8b 8f 18 01 00 00    	mov    ecx,DWORD PTR [rdi+0x118]
    713079c37b80:	c6 00 01             	mov    BYTE PTR [rax],0x1
    713079c37b83:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    713079c37b86:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37b8d:	eb b7                	jmp    0x713079c37b46
    713079c37b8f:	48 8b fe             	mov    rdi,rsi
    713079c37b92:	41 8b f3             	mov    esi,r11d
    713079c37b95:	49 bb e8 22 27 77 30 	movabs r11,0x7130772722e8
    713079c37b9c:	71 00 00 
    713079c37b9f:	41 ff 13             	call   QWORD PTR [r11]
    713079c37ba2:	48 8b d8             	mov    rbx,rax
    713079c37ba5:	eb 8b                	jmp    0x713079c37b32
    713079c37ba7:	83 78 20 00          	cmp    DWORD PTR [rax+0x20],0x0
    713079c37bab:	0f 84 d8 f5 ff ff    	je     0x713079c37189
    713079c37bb1:	48 8b f9             	mov    rdi,rcx
    713079c37bb4:	ff 15 86 55 c1 ff    	call   QWORD PTR [rip+0xffffffffffc15586]        # 0x71307984d140
    713079c37bba:	e9 ca f5 ff ff       	jmp    0x713079c37189
    713079c37bbf:	90                   	nop
    713079c37bc0:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37bc7:	eb 16                	jmp    0x713079c37bdf
    713079c37bc9:	ff 15 29 79 87 ff    	call   QWORD PTR [rip+0xffffffffff877929]        # 0x7130794af4f8
    713079c37bcf:	cc                   	int3
    713079c37bd0:	48 8b fa             	mov    rdi,rdx
    713079c37bd3:	e8 c8 a3 77 7c       	call   0x7130f63b1fa0
    713079c37bd8:	cc                   	int3
    713079c37bd9:	e8 2a 9a 84 fe       	call   0x713078481608
    713079c37bde:	cc                   	int3
    713079c37bdf:	e8 fd 00 00 00       	call   0x713079c37ce1
    713079c37be4:	90                   	nop
    713079c37be5:	c5 f8 77             	vzeroupper
    713079c37be8:	48 81 c4 78 03 00 00 	add    rsp,0x378
    713079c37bef:	5b                   	pop    rbx
    713079c37bf0:	41 5c                	pop    r12
    713079c37bf2:	41 5d                	pop    r13
    713079c37bf4:	41 5e                	pop    r14
    713079c37bf6:	41 5f                	pop    r15
    713079c37bf8:	5d                   	pop    rbp
    713079c37bf9:	c3                   	ret
    713079c37bfa:	48 83 ec 18          	sub    rsp,0x18
    713079c37bfe:	48 8b df             	mov    rbx,rdi
    713079c37c01:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c37c08:	ff 15 b2 7a a4 ff    	call   QWORD PTR [rip+0xffffffffffa47ab2]        # 0x71307967f6c0
    713079c37c0e:	48 8b d0             	mov    rdx,rax
    713079c37c11:	48 8b f3             	mov    rsi,rbx
    713079c37c14:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37c1b:	ff 15 07 5e c1 ff    	call   QWORD PTR [rip+0xffffffffffc15e07]        # 0x71307984da28
    713079c37c21:	85 c0                	test   eax,eax
    713079c37c23:	75 0f                	jne    0x713079c37c34
    713079c37c25:	48 8d 05 93 ff ff ff 	lea    rax,[rip+0xffffffffffffff93]        # 0x713079c37bbf
    713079c37c2c:	c5 f8 77             	vzeroupper
    713079c37c2f:	48 83 c4 18          	add    rsp,0x18
    713079c37c33:	c3                   	ret
    713079c37c34:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    713079c37c3b:	00 00 00 
    713079c37c3e:	48 8d 05 b8 f4 ff ff 	lea    rax,[rip+0xfffffffffffff4b8]        # 0x713079c370fd
    713079c37c45:	c5 f8 77             	vzeroupper
    713079c37c48:	48 83 c4 18          	add    rsp,0x18
    713079c37c4c:	c3                   	ret
    713079c37c4d:	48 83 ec 18          	sub    rsp,0x18
    713079c37c51:	48 8b df             	mov    rbx,rdi
    713079c37c54:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c37c5b:	ff 15 5f 7a a4 ff    	call   QWORD PTR [rip+0xffffffffffa47a5f]        # 0x71307967f6c0
    713079c37c61:	48 8b d0             	mov    rdx,rax
    713079c37c64:	48 8b f3             	mov    rsi,rbx
    713079c37c67:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37c6e:	ff 15 cc 5d c1 ff    	call   QWORD PTR [rip+0xffffffffffc15dcc]        # 0x71307984da40
    713079c37c74:	85 c0                	test   eax,eax
    713079c37c76:	75 06                	jne    0x713079c37c7e
    713079c37c78:	e8 e3 a3 77 7c       	call   0x7130f63b2060
    713079c37c7d:	cc                   	int3
    713079c37c7e:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    713079c37c85:	00 00 00 
    713079c37c88:	48 8d 05 6e f4 ff ff 	lea    rax,[rip+0xfffffffffffff46e]        # 0x713079c370fd
    713079c37c8f:	c5 f8 77             	vzeroupper
    713079c37c92:	48 83 c4 18          	add    rsp,0x18
    713079c37c96:	c3                   	ret
    713079c37c97:	48 83 ec 18          	sub    rsp,0x18
    713079c37c9b:	48 8b df             	mov    rbx,rdi
    713079c37c9e:	48 8b bd 98 02 00 00 	mov    rdi,QWORD PTR [rbp+0x298]
    713079c37ca5:	ff 15 15 7a a4 ff    	call   QWORD PTR [rip+0xffffffffffa47a15]        # 0x71307967f6c0
    713079c37cab:	48 8b d0             	mov    rdx,rax
    713079c37cae:	48 8b f3             	mov    rsi,rbx
    713079c37cb1:	48 8b bd c0 02 00 00 	mov    rdi,QWORD PTR [rbp+0x2c0]
    713079c37cb8:	ff 15 9a 5d c1 ff    	call   QWORD PTR [rip+0xffffffffffc15d9a]        # 0x71307984da58
    713079c37cbe:	85 c0                	test   eax,eax
    713079c37cc0:	75 06                	jne    0x713079c37cc8
    713079c37cc2:	e8 99 a3 77 7c       	call   0x7130f63b2060
    713079c37cc7:	cc                   	int3
    713079c37cc8:	c7 85 bc 02 00 00 01 	mov    DWORD PTR [rbp+0x2bc],0x1
    713079c37ccf:	00 00 00 
    713079c37cd2:	48 8d 05 24 f4 ff ff 	lea    rax,[rip+0xfffffffffffff424]        # 0x713079c370fd
    713079c37cd9:	c5 f8 77             	vzeroupper
    713079c37cdc:	48 83 c4 18          	add    rsp,0x18
    713079c37ce0:	c3                   	ret
    713079c37ce1:	48 83 ec 18          	sub    rsp,0x18
    713079c37ce5:	48 8b 9d c0 02 00 00 	mov    rbx,QWORD PTR [rbp+0x2c0]
    713079c37cec:	80 bb e1 00 00 00 00 	cmp    BYTE PTR [rbx+0xe1],0x0
    713079c37cf3:	75 0e                	jne    0x713079c37d03
    713079c37cf5:	48 83 7b 38 00       	cmp    QWORD PTR [rbx+0x38],0x0
    713079c37cfa:	75 07                	jne    0x713079c37d03
    713079c37cfc:	48 83 7b 60 00       	cmp    QWORD PTR [rbx+0x60],0x0
    713079c37d01:	74 08                	je     0x713079c37d0b
    713079c37d03:	c5 f8 77             	vzeroupper
    713079c37d06:	48 83 c4 18          	add    rsp,0x18
    713079c37d0a:	c3                   	ret
    713079c37d0b:	33 f6                	xor    esi,esi
    713079c37d0d:	48 89 73 68          	mov    QWORD PTR [rbx+0x68],rsi
    713079c37d11:	8b b3 18 01 00 00    	mov    esi,DWORD PTR [rbx+0x118]
    713079c37d17:	48 8d bb e8 00 00 00 	lea    rdi,[rbx+0xe8]
    713079c37d1e:	ff 15 7c 5d c1 ff    	call   QWORD PTR [rip+0xffffffffffc15d7c]        # 0x71307984daa0
    713079c37d24:	48 81 c3 e8 00 00 00 	add    rbx,0xe8
    713079c37d2b:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    713079c37d2e:	83 7f 08 00          	cmp    DWORD PTR [rdi+0x8],0x0
    713079c37d32:	74 0e                	je     0x713079c37d42
    713079c37d34:	44 8b 7f 08          	mov    r15d,DWORD PTR [rdi+0x8]
    713079c37d38:	49 c1 e7 04          	shl    r15,0x4
    713079c37d3c:	49 83 c7 20          	add    r15,0x20
    713079c37d40:	eb 03                	jmp    0x713079c37d45
    713079c37d42:	45 33 ff             	xor    r15d,r15d
    713079c37d45:	4c 03 7b 28          	add    r15,QWORD PTR [rbx+0x28]
    713079c37d49:	70 37                	jo     0x713079c37d82
    713079c37d4b:	48 bf a8 0f 80 99 28 	movabs rdi,0x712899800fa8
    713079c37d52:	71 00 00 
    713079c37d55:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
    713079c37d58:	48 8b fb             	mov    rdi,rbx
    713079c37d5b:	e8 e0 82 61 fd       	call   0x713077250040
    713079c37d60:	33 ff                	xor    edi,edi
    713079c37d62:	48 89 7b 28          	mov    QWORD PTR [rbx+0x28],rdi
    713079c37d66:	48 8b 7b 08          	mov    rdi,QWORD PTR [rbx+0x8]
    713079c37d6a:	48 8b 7f 30          	mov    rdi,QWORD PTR [rdi+0x30]
    713079c37d6e:	48 8b bf 80 00 00 00 	mov    rdi,QWORD PTR [rdi+0x80]
    713079c37d75:	49 8b f7             	mov    rsi,r15
    713079c37d78:	39 3f                	cmp    DWORD PTR [rdi],edi
    713079c37d7a:	ff 15 c8 60 c1 ff    	call   QWORD PTR [rip+0xffffffffffc160c8]        # 0x71307984de48
    713079c37d80:	eb 81                	jmp    0x713079c37d03
    713079c37d82:	e8 69 98 84 fe       	call   0x7130784815f0
    713079c37d87:	cc                   	int3
