
/home/lokad/lython-bench-checks/jit-origins-b77-20261101/integer-loop/method-5683.bin:     file format binary


Disassembly of section .data:

00007130796ef040 <.data>:
    7130796ef040:	55                   	push   rbp
    7130796ef041:	41 57                	push   r15
    7130796ef043:	41 56                	push   r14
    7130796ef045:	41 55                	push   r13
    7130796ef047:	53                   	push   rbx
    7130796ef048:	48 83 ec 10          	sub    rsp,0x10
    7130796ef04c:	48 8d 6c 24 30       	lea    rbp,[rsp+0x30]
    7130796ef051:	48 8b df             	mov    rbx,rdi
    7130796ef054:	4c 8b fe             	mov    r15,rsi
    7130796ef057:	8b 7b 30             	mov    edi,DWORD PTR [rbx+0x30]
    7130796ef05a:	48 8b 03             	mov    rax,QWORD PTR [rbx]
    7130796ef05d:	3b 78 08             	cmp    edi,DWORD PTR [rax+0x8]
    7130796ef060:	74 64                	je     0x7130796ef0c6
    7130796ef062:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    7130796ef065:	8b 73 30             	mov    esi,DWORD PTR [rbx+0x30]
    7130796ef068:	8d 56 01             	lea    edx,[rsi+0x1]
    7130796ef06b:	89 53 30             	mov    DWORD PTR [rbx+0x30],edx
    7130796ef06e:	48 63 f6             	movsxd rsi,esi
    7130796ef071:	8b 57 08             	mov    edx,DWORD PTR [rdi+0x8]
    7130796ef074:	48 3b d6             	cmp    rdx,rsi
    7130796ef077:	0f 86 fe 00 00 00    	jbe    0x7130796ef17b
    7130796ef07d:	48 8d 44 f7 10       	lea    rax,[rdi+rsi*8+0x10]
    7130796ef082:	48 8b 3f             	mov    rdi,QWORD PTR [rdi]
    7130796ef085:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
    7130796ef089:	4d 85 ff             	test   r15,r15
    7130796ef08c:	74 31                	je     0x7130796ef0bf
    7130796ef08e:	49 3b 37             	cmp    rsi,QWORD PTR [r15]
    7130796ef091:	74 13                	je     0x7130796ef0a6
    7130796ef093:	48 ba a0 27 49 78 30 	movabs rdx,0x7130784927a0
    7130796ef09a:	71 00 00 
    7130796ef09d:	48 3b fa             	cmp    rdi,rdx
    7130796ef0a0:	0f 85 dc 00 00 00    	jne    0x7130796ef182
    7130796ef0a6:	48 8b f8             	mov    rdi,rax
    7130796ef0a9:	49 8b f7             	mov    rsi,r15
    7130796ef0ac:	e8 8f 0f b6 fd       	call   0x713077250040
    7130796ef0b1:	90                   	nop
    7130796ef0b2:	48 83 c4 10          	add    rsp,0x10
    7130796ef0b6:	5b                   	pop    rbx
    7130796ef0b7:	41 5d                	pop    r13
    7130796ef0b9:	41 5e                	pop    r14
    7130796ef0bb:	41 5f                	pop    r15
    7130796ef0bd:	5d                   	pop    rbp
    7130796ef0be:	c3                   	ret
    7130796ef0bf:	33 c9                	xor    ecx,ecx
    7130796ef0c1:	48 89 08             	mov    QWORD PTR [rax],rcx
    7130796ef0c4:	eb eb                	jmp    0x7130796ef0b1
    7130796ef0c6:	48 8b 3b             	mov    rdi,QWORD PTR [rbx]
    7130796ef0c9:	44 6b 77 08 02       	imul   r14d,DWORD PTR [rdi+0x8],0x2
    7130796ef0ce:	0f 80 bf 00 00 00    	jo     0x7130796ef193
    7130796ef0d4:	49 63 f6             	movsxd rsi,r14d
    7130796ef0d7:	48 c1 e6 04          	shl    rsi,0x4
    7130796ef0db:	48 83 c6 20          	add    rsi,0x20
    7130796ef0df:	48 89 75 d8          	mov    QWORD PTR [rbp-0x28],rsi
    7130796ef0e3:	48 8b fb             	mov    rdi,rbx
    7130796ef0e6:	ff 15 2c ed 15 00    	call   QWORD PTR [rip+0x15ed2c]        # 0x71307984de18
    7130796ef0ec:	4c 8b e8             	mov    r13,rax
    7130796ef0ef:	48 8b 73 08          	mov    rsi,QWORD PTR [rbx+0x8]
    7130796ef0f3:	48 8b 76 30          	mov    rsi,QWORD PTR [rsi+0x30]
    7130796ef0f7:	48 8b be 80 00 00 00 	mov    rdi,QWORD PTR [rsi+0x80]
    7130796ef0fe:	48 89 7d d0          	mov    QWORD PTR [rbp-0x30],rdi
    7130796ef102:	48 8b 73 08          	mov    rsi,QWORD PTR [rbx+0x8]
    7130796ef106:	48 8b 76 70          	mov    rsi,QWORD PTR [rsi+0x70]
    7130796ef10a:	48 bf 90 30 ad 79 30 	movabs rdi,0x713079ad3090
    7130796ef111:	71 00 00 
    7130796ef114:	e8 07 d6 ff ff       	call   0x7130796ec720
    7130796ef119:	48 85 c0             	test   rax,rax
    7130796ef11c:	74 11                	je     0x7130796ef12f
    7130796ef11e:	48 8b f8             	mov    rdi,rax
    7130796ef121:	ff 15 09 ed 15 00    	call   QWORD PTR [rip+0x15ed09]        # 0x71307984de30
    7130796ef127:	48 8b d0             	mov    rdx,rax
    7130796ef12a:	48 85 d2             	test   rdx,rdx
    7130796ef12d:	75 04                	jne    0x7130796ef133
    7130796ef12f:	48 8b 53 10          	mov    rdx,QWORD PTR [rbx+0x10]
    7130796ef133:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796ef137:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
    7130796ef13b:	39 3f                	cmp    DWORD PTR [rdi],edi
    7130796ef13d:	ff 15 7d 8e 15 00    	call   QWORD PTR [rip+0x158e7d]        # 0x713079847fc0
    7130796ef143:	90                   	nop
    7130796ef144:	41 8b d6             	mov    edx,r14d
    7130796ef147:	48 8b f3             	mov    rsi,rbx
    7130796ef14a:	48 bf a8 6d 43 79 30 	movabs rdi,0x713079436da8
    7130796ef151:	71 00 00 
    7130796ef154:	ff 15 5e f8 d9 fe    	call   QWORD PTR [rip+0xfffffffffed9f85e]        # 0x71307848e9b8
    7130796ef15a:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796ef15e:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
    7130796ef162:	ff 15 70 8e 15 00    	call   QWORD PTR [rip+0x158e70]        # 0x713079847fd8
    7130796ef168:	90                   	nop
    7130796ef169:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796ef16d:	49 8b f5             	mov    rsi,r13
    7130796ef170:	ff 15 d2 ec 15 00    	call   QWORD PTR [rip+0x15ecd2]        # 0x71307984de48
    7130796ef176:	e9 e7 fe ff ff       	jmp    0x7130796ef062
    7130796ef17b:	ff 15 af 57 49 00    	call   QWORD PTR [rip+0x4957af]        # 0x713079b84930
    7130796ef181:	cc                   	int3
    7130796ef182:	48 8b f8             	mov    rdi,rax
    7130796ef185:	49 8b d7             	mov    rdx,r15
    7130796ef188:	ff 15 2a 0d 2b ff    	call   QWORD PTR [rip+0xffffffffff2b0d2a]        # 0x71307899feb8
    7130796ef18e:	e9 1e ff ff ff       	jmp    0x7130796ef0b1
    7130796ef193:	e8 58 24 d9 fe       	call   0x7130784815f0
    7130796ef198:	cc                   	int3
    7130796ef199:	50                   	push   rax
    7130796ef19a:	48 8b 7d d0          	mov    rdi,QWORD PTR [rbp-0x30]
    7130796ef19e:	48 8b 75 d8          	mov    rsi,QWORD PTR [rbp-0x28]
    7130796ef1a2:	ff 15 c8 e2 15 00    	call   QWORD PTR [rip+0x15e2c8]        # 0x71307984d470
    7130796ef1a8:	e8 b3 2e cc 7c       	call   0x7130f63b2060
    7130796ef1ad:	cc                   	int3
