from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()

def pushed(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)

copies = {}
for name, directory, archived_core in [
    ("machine-arithmetic-cpython-20261122", "2026-11-22-machine-arithmetic-cpython", True),
]:
    prior = lab.parent / name
    tracked = f"benchmarks/results/{directory}/"
    root = Path(read(prior / "quiet/config.json")["root"]).name
    receipt = read(prior / "quiet/archive-receipt.json")
    image = prior / "frozen"
    files = read(prior / "quiet/identity.json")["imageFiles"]["candidate"]
    assert len(files) == 32
    assert all(hash_bytes((image / file).read_bytes()) == expected for file, expected in files.items())
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
    raw = hash_bytes(pushed(tracked + "observations.tgz"))
    assert raw == receipt["archiveSHA256"]
    if archived_core:
        assert hash_bytes(gzip.decompress(pushed(tracked + "candidate-core.dll.gz"))) == files[core]
    copies[root] = dict(archive=tracked, bytes=(image / core).stat().st_size, coreSHA256=files[core],
        archiveSHA256=raw, authoritativeImageSHA256=files, authoritativeImage=str(image))

profile = lab.parent / "post-arithmetic-invocation-profile-20261122"
profile_config = read(profile/"config.json")
profile_receipt = read(profile/"archive-receipt.json")
assert profile_receipt["complete"] and profile_receipt["persistentTraceArchivedAndVerifiedBeforeUnmount"]
profile_hash = hash_bytes(pushed("benchmarks/results/2026-11-22-post-arithmetic-invocation-profile/observations.tgz"))
assert profile_hash == profile_receipt["archiveSHA256"]
extra_archive = Path(profile_config["root"]).name + "/observations.tgz"
for root,witness in copies.items():
    witness["allowedArchives"] = {root+"/observations.tgz":witness["archiveSHA256"],extra_archive:profile_hash}
    for local_run,receipt_path,result_path in [
        ("module-helper-placement-20261122/quiet","archive-receipt.json","2026-11-22-matched-helper-placement/observations.tgz"),
        ("checked-augmented-local-20261122/quiet","archive-receipt.json","2026-11-22-checked-augmented-local/observations.tgz"),
        ("checked-augmented-local-20261122/invoice-quiet","archive-receipt.json","2026-11-22-checked-augmented-local/invoice-observations.tgz"),
    ]:
        path=lab.parent/local_run
        run_root=Path(read(path/"config.json")["root"]).name
        run_receipt=read(path/receipt_path)
        digest=hash_bytes(pushed("benchmarks/results/"+result_path))
        assert all(run_receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
        assert run_receipt["archiveSHA256"]==digest
        witness["allowedArchives"][run_root+"/observations.tgz"]=digest


source = '''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
base=Path('/home/lokad/lython-bench-checks')
copies=OWNED_COPIES
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    proofs=[]
    for root_name,witness in copies.items():
        root=base/root_name
        core=root/'candidate/Lokad.Lython.dll'
        if not core.exists(): continue
        archive=root/'observations.tgz'
        assert core.resolve()==core and sha(core)==witness['coreSHA256']
        assert sha(archive)==witness['archiveSHA256']
        info=core.lstat()
        assert info.st_size==witness['bytes']
        paths=[]
        for folder,_,names in os.walk(base):
            for name in names:
                path=Path(folder)/name
                record=path.lstat()
                if (record.st_dev,record.st_ino)!=(info.st_dev,info.st_ino): continue
                assert path.resolve()==path and stat.S_ISREG(record.st_mode) and record.st_uid==os.getuid()
                paths.append(str(path.relative_to(base)))
        assert len(paths)==info.st_nlink
        if not all(name.split('/', 1)[0]+'/observations.tgz' in witness['allowedArchives'] for name in paths):
            print(json.dumps(dict(free=shutil.disk_usage(base).free,proof=[],unapprovedAliases=sorted(paths)),indent=2));break
        archives={name.split('/', 1)[0]+'/observations.tgz' for name in paths}
        verified_archives={name:witness['allowedArchives'][name] for name in archives}
        for name,digest in verified_archives.items():assert sha(base/name)==digest
        proofs.append(dict(paths=sorted(paths),bytes=info.st_size,links=info.st_nlink,sha256=witness['coreSHA256'],
            archives=verified_archives,optional=False))
    else:print(json.dumps(dict(free=shutil.disk_usage(base).free,proof=proofs),indent=2))
'''.replace("OWNED_COPIES", repr(copies))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
proof = json.loads(subprocess.check_output(ssh, input=source, encoding="utf-8", timeout=35))
proof["witnesses"] = copies
(lab/"retire-proof.json").write_text(json.dumps(proof, indent=2)+"\n", encoding="utf-8", newline="\n")
print(proof["free"], proof["proof"])
