from pathlib import Path
import json


out = Path("benchmarks/results/2026-11-22-retained-call-transport-cpython")
summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
names = {
    "scripts.annotated-rule-closures.literal-positional-dynamic-keyword": "Mixed literal-default factory",
    "scripts.csv-invoice.helper-accumulation": "Nested-helper CSV invoice",
    "diagnostic.helper-placement.function-call": "Function-scoped arithmetic helper",
    "scripts.csv-invoice.method-policy.quoted-control": "Quoted policy invoice",
}
boundaries = {"warm": "Warm", "compile": "Compilation", "compile-run": "Compile to result"}


def extent(values, digits):
    first, last = (f"{value:.{digits}f}" for value in values)
    return first if first == last else f"{first}–{last}"


rows = [
    "| Complete script | Boundary | Lython | CPython | Lython / CPython | Controls L/C | Maximum IQR |",
    "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    digits = {"compile": 5, "warm": 4, "compile-run": 3}[row["lane"]]
    controls = f"{row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.3f}%"
    rows.append(f"| {names[row['case']]} | {boundaries[row['lane']]} | "
                f"{extent(row['lythonMs'], digits)} ms | {extent(row['cpythonMs'], digits)} ms | "
                f"{extent(row['ratio'], 3)}× | {controls} | {row['maxIQRPercent']:.2f}% |")
report = f"""# B1369 Retained call transport against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu
24.04.4 and .NET 11 RC3. The frozen Lython image from
`{summary['builtImageSource'][:9]}` matches the retained runtime
`{summary['retainedSource'][:9]}` at `{summary['source'][:9]}`.
The external baseline is stock CPython 3.13.16. The two invoices
each read 4,096 records, from 127,031 and 174,147 input bytes
respectively. The function-scoped helper has 2,048 calls. The
mixed factory creates 4,096 functions for 2,048 inputs.

"""
report += "\n".join(rows)
report += f"""

Ratios divide Lython elapsed by CPython elapsed and span all pairings
of two process medians per engine. Above one means Lython takes longer.
Two workers per engine and phase warmed for at least eight seconds
and supplied seven rotated timed batches each. Controls show the spread
of the two process medians for each engine.

Warm execution includes mediated RAM-backed input and output, captured
stdout, golden verification and prior-result disposal.
Time to result covers compilation and execution with their cleanup. Process startup and
final teardown have separate boundaries.

All 140 timed batches and both quiet gates passed in
{summary['elapsedSeconds']:.0f} seconds. Stdout and output files matched their CPython goldens. The 32-file Lython image and both CPython worker identities
verified. Every worker joined and the persistent archive was checked
before releasing the VM lease.

Mixed first-use debt from the source comparison remains open. The
mixed tape has no unpack or dictionary store. The native function
bodies contain no call opcode. The new fixed-return and dictionary
branches do no additional guest work on that script. Its allocations
and peak allowance match in B1368. That leaves the elapsed and CPU
difference unexplained.

The first attempt stopped at the existing disk floor before staging
or sampling. The retry retired working copies of one older DLL only
after verifying every alias, the canonical archived core and all five
affected records. The inputs, toolchains and floor stayed the same.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Previous factory and CSV comparison](../2026-11-22-construction-csv-cpython/README.md) ·
[Native transport source pair](../2026-11-22-native-fixed-returns-refined/README.md) ·
[Image verification and procedures](procedures.tar.xz).
"""
(out / "README.md").write_text(report, encoding="utf-8", newline="\n")
