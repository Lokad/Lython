from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('compiled-regex-receivers-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
reference='fixed-return-ownership-b1566-20261124'
root='regex-index-resumption-b1569-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path,value):
    write(path,json.dumps(value,indent=2)+'\n')


replicas=[]
for archive, remote in [
    ('benchmarks/results/2026-11-24-direct-match-expand/','direct-match-expand-b1558-20261124'),
]:
    def tracked(file):
        return subprocess.check_output(['git','show','origin/master:'+archive+file],cwd=repo)
    receipt=json.loads(tracked('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
    binary=sha(gzip.decompress(tracked('candidate-core.dll.gz')))
    assert json.loads(tracked('identity.json'))['imageFiles']['candidate'][core]==binary
    replicas.append(dict(path=remote+'/candidate/'+core,sha256=binary,
        observationSHA256=receipt['archiveSHA256'],trackedArchive=archive))
save(lab/'verified-replicas.json',replicas)

original=donor/'comparison/quiet'
collector=(original/'collect.py').read_text(encoding='utf-8')
assert collector.count("'exact-unicode-float-b1560-20261124'/'candidate'")==1
collector=collector.replace("'exact-unicode-float-b1560-20261124'/'candidate'",repr(reference)+"/'candidate'")
collector=collector.replace('b1564-','b1569-')
assert 'assert len(jobs) == 4' in collector
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(lab/'candidate'/core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1564-compiled-regex-receivers','b1569-regex-index-resumption').replace('b1564-','b1569-')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
shutil.copyfile(donor/'summarize.py',lab/'summarize.py')
