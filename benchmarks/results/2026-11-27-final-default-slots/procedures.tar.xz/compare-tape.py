from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import re
import shutil
import subprocess
import textwrap

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
run=lab/'local'
old=lab.with_name('compiled-prefix-search-20261126')/'tape-image'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(run/'identity.json')
original={row['id']:row['source'] for row in read(run/'representative.json')['cases'] if row['id'] in (
    'diagnostic.generated-ordinary-definitions','scripts.rule-default-closures'
)}
regression=(repo/'tests/Lokad.Lython.PublicApi.Tests/PreparedFunctionDefaultsTests.cs').read_text(encoding='utf-8')
for name in ('DefinitionDefaultsSurviveTransferDuringKeywordEvaluation','DefaultCanObserveTheParameterThatItsDefinitionReplaces'):
    body=regression.split(f'public async Task {name}',1)[1]
    found=re.search(r'const string source = """\n(.*?)\n\s*""";',body,re.S)
    original[name]=textwrap.dedent(found.group(1))

def record(role):
    images=run/role
    assert {p.name:digest(p) for p in images.iterdir()}==identity['imageFiles'][role]
    root=lab/'tape'/role
    root.mkdir(parents=True)
    for name in ('Tape.dll','Tape.deps.json','Tape.runtimeconfig.json'):
        shutil.copyfile(old/name,root/name)
    shutil.copyfile(images/'Lokad.Lython.dll',root/'Lokad.Lython.dll')
    summary=[]
    for name,text in original.items():
        src=root/'case.json'
        dst=root/(name+'.json')
        src.write_text(json.dumps({'cases':[{'source':text}]}),encoding='utf-8')
        subprocess.run([Path.home()/'.dotnet11/dotnet.exe',root/'Tape.dll',src,dst],check=True,timeout=15)
        for code in read(dst):
            kinds=Counter()
            for step in code['steps']:
                if step['op']=='StartFunctionDefaults':
                    kinds['defaultStarts']+=1
                    if step['second']!=2147483647:
                        assert step['input']<step['output']
                        kinds['directStarts']+=1
                if step['op']=='ApplyDeferredDefinition':
                    kinds['deferredPlacements']+=1
            if kinds:
                summary.append(dict(case=name, code=code['name'], sourceSha256=sha256(text.encode()).hexdigest(), counts=dict(kinds)))
    return summary

summary={role:record(role) for role in ('reference','candidate')}
path=lab/'tape/summary.json'
path.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary,indent=2))