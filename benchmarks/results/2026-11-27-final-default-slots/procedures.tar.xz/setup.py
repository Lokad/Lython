from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.with_name('staged-list-yield-20261127')
source=(prior/'prepare.py').read_text(encoding='utf-8')
changes = {
    "image_base=previous/'corrected'": "image_base=lab.with_name('staged-list-yield-20261127')/'local'",
    "assert head.startswith('36f7b175b')\nassert not subprocess.check_output(['git','diff','c10f06884',head,'--','src'],cwd=repo)": "assert head=='489fde50e0e774162eab5a4db9ec0bffe2210d27'",
    "lython-staged-list-fixture-": "lython-final-default-fixture-",
    "[[short,'warm-async'],[bound,'warm-async'],[wide,'warm-async'],[file_fed,'warm'],[wide,'warm']]":
        "[[ordinary,'warm'],[rules,'warm-async'],[ordinary,'warm-async'],[search,'compile'],[ordinary,'compile']]",
    "Transfer existing generator list-display operands once into the real callback workspace.":
        "Write deferred function defaults directly into their final slots in the native prefix.",
    "peak=[r['peakExecutionMemoryBytes'] for r in (before,after)])":
        "peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],compiled=[r['compiledReservedBytes'] for r in (before,after)])",
}
for before,after in changes.items():
    assert source.count(before)==1,before
    source=source.replace(before,after)
start=source.index("file_fed=")
end=source.index("for name in",start)
source=source[:start]+"""ordinary='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
invoice='scripts.csv-invoice.large'
search='scripts.file-search.large'
catalog=read(lab.with_name('current-callable-profile-20261126')/'local/representative.json')
assert set(row['id'] for row in catalog['cases'])=={ordinary,rules,invoice,search}
write(run/'representative.json',catalog)
"""+source[end:]
(lab/'prepare.py').write_text(source,encoding='utf-8',newline='\n')