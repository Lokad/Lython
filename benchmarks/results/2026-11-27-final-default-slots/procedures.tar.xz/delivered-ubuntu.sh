set -eu
source_root=/mnt/d/code/Lython
target_root=/home/vermorel/lython-starmap-rows-8066Vm
test -d "$target_root/src/Lokad.Lython"
cd "$source_root"
cat "$source_root/.git/agent-notes/review-20261031/final-default-slots-20261127/changed-source-files.txt" |
while IFS= read -r file; do
    cp -- "$file" "$target_root/$file"
    cmp -- "$file" "$target_root/$file"
done
cd "$target_root"
project=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
"$HOME/.dotnet/dotnet" build "$project" -c Release -f net10.0 --no-restore --no-incremental
"$HOME/.dotnet/dotnet" test "$project" -c Release -f net10.0 --no-build --filter 'Category!=Stress&(FullyQualifiedName~DefinitionDefaultsSurviveTransfer|FullyQualifiedName~DefaultCanObserveTheParameter)'
