from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
q = lab / "quiet"
source = notes / "private-compiled-annotation-payload"
source_quiet = source / "quiet"
template = notes / "private-json-property-layout/cpython-corrected"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def archive_hash(source_tree, archive_dir, remote):
    archive = git("cat-file", "blob", source_tree + archive_dir + "observations.tgz")
    receipt = json.loads(git("cat-file", "blob", source_tree + archive_dir + "archive-receipt.json"))
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
    assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(archive)
    return (remote + "/observations.tgz", sha(archive))


assert not git("status", "--porcelain")
revision = git("rev-parse", "HEAD").decode().strip()
assert revision.startswith("785640f8e")
donor = load(source_quiet / "config.json")
donor_receipt = load(source_quiet / "archive-receipt.json")
assert donor_receipt["complete"] and donor_receipt["archiveSHA256"] == file_sha(source_quiet / "observations.tgz")
assert donor_receipt["archivedAndVerifiedUnderLease"]
donor_files = donor["identity"]["imageFiles"]["candidate"]
donor_image = source / "frozen/candidate"
assert len(donor_files) == 32 and {name: file_sha(donor_image / name) for name in donor_files} == donor_files

evidence = "benchmarks/results/2026-11-20-compiled-annotation-payload/"
tree = "785640f8e:" + evidence
candidate_replica = donor["root"].rsplit("/", 1)[1]
repeat_replica = load(source / "confirmation/quiet/config.json")["root"].rsplit("/", 1)[1]
old_core = gzip.decompress(git("cat-file", "blob", tree + "measured-reference-core.dll.gz"))
assert sha(old_core) == donor["identity"]["coreSHA256"]["reference"]
archives = dict((archive_hash(tree, "", candidate_replica), archive_hash(tree, "confirmation/", repeat_replica)))
retire = dict(archives=archives, paths=[f"{r}/reference/{core}" for r in (candidate_replica, repeat_replica)],
              bytes=len(old_core), links=2, sha256=sha(old_core), verifiedCanonicalGitImage=evidence+"measured-reference-core.dll.gz")

catalog = load(source / "representative.json")
nested = "scripts.annotated-rule-closures.nested-factories.postponed"
mapping = "scripts.report-render.format-map.large"
cases = [next(v for v in catalog["cases"] if v["id"] == nested),
         next(v for v in load(notes / "private-format-map-keys/representative.json")["cases"] if v["id"] == mapping)]
catalog["cases"] = cases
q.mkdir()
manifest = q / "representative.json"
save(manifest, catalog)
manifest_hash = file_sha(manifest)
worker = repo / "benchmarks/cpython-worker.py"
protocol_sha = file_sha(worker)
assert protocol_sha == donor["protocolSHA256"] == file_sha(template / "cpython-worker.py")
shutil.copyfile(worker, q / worker.name)

image = lab / "frozen/candidate"
image.mkdir(parents=True)
for name in donor_files:
    origin = repo / "src/Lokad.Lython/bin/Release/net11.0" / core if name == core else donor_image / name
    shutil.copyfile(origin, image / name)
files = {n: file_sha(image / n) for n in donor_files}
assert [n for n in donor_files if files[n] != donor_files[n]] == [core]
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
verify = lab / "verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", worker, "--out", verify],
    env=env, check=True, timeout=100)
assert load(verify)["state"] == "Completed" and load(verify)["catalogSha256"] == manifest_hash
assert files == {n: file_sha(image / n) for n in files}
identity = dict(sourceRevision=revision, imageSource=revision, purpose="Postponed factories and mapping reports against stock CPython",
                imageFiles={"candidate":files}, catalogSHA256=manifest_hash, cpythonWorkerSHA256=protocol_sha,
                auxiliaryFiles={name:h for name,h in files.items() if name!=core},
                coreSHA256={label:files[core] for label in ("candidate","candidate-control")})
save(q / "identity.json", identity)
prior = load(template / "config.json")
remote = "/home/lokad/lython-bench-checks/annotation-shipment-cpython-b1240-20261120"
unit = "lython-b1240-annotation-shipment-cpython-20261120"
for name in ("collect.py", "archive-owned.py", "retrieve.py", "run.sh"):
    text = read(template / name).replace(prior["root"],remote).replace(prior["unit"],unit).replace("B1233", "B1240")
    if name == "collect.py":
        start = text.index("    for case_id,diagnostic in ")
        end = text.index("\n", start)
        text = text[:start] + f"    for case_id,diagnostic in {[(row['id'], False) for row in cases]!r}:" + text[end:]
        text = text.replace('case_id != "scripts.report-render.named-format-selectors.large"', f'case_id != "{nested}"')
        text = text.replace(" else 8 if lane=='warm' else 6", " else 12 if lane=='warm' else 6")
        text = text.replace("for round in range(5)", "for round in range(7)")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
assert f'case_id != "{nested}"' in read(q / "collect.py")
(q / "candidate").mkdir()
shutil.copyfile(image / core, q / "candidate" / core)
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", worker.name, manifest.name, "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for name in parts:
        archive.add(q / name, arcname=name)
config = dict(root=remote, unit=unit, identity=identity, source=donor["root"], sourceRole="candidate",
              sourceFiles=donor_files, sourceCatalogSHA256=donor["catalogSHA256"], catalogSHA256=manifest_hash, cpythonWorkerSHA256=protocol_sha,
              retireGroups=[retire], donorArchiveSHA256=donor_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
text = read(template / "remote-launch.py")
start = text.index("\nc=")+1
end = text.index("\nb=Path(", start)
text = (text[:start]+"c="+repr(config)+text[end:]).replace("lython-b1233-fixtures","lython-b1240-fixtures")
text = text.replace(" for proof in c['retireGroups']:\n", " for proof in c['retireGroups']:\n  for name,h in proof['archives'].items():assert sha(b/name)==h,name\n")
assert "+64*1024*1024" in text and "proof['archives']" in text
emit(q / "remote-launch.py", text)
launch = read(template / "launch.py").replace("r=Path(__file__).parent;", "r=Path(__file__).parent/'quiet';")
assert "parent/'quiet'" in launch
launch=launch.replace("seconds=190","seconds=250").replace("before 190","before 250")
launch=launch.replace("B1233 JSON shipment", "B1240 annotation and shipment")
emit(lab / "launch.py", launch)
print("Prepared the verified exact release source and CPython goldens for four lanes.")
