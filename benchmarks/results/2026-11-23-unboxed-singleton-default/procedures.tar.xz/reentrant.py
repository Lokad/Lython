def factory(seed):
    def ordinary(value=seed+10000, /, *, adjustment):
        return value, adjustment
    return ordinary

target = factory(3)
saved = []
class Key:
    def __hash__(self):
        return hash("adjustment")
    def __eq__(self, other):
        saved.append(target.__defaults__)
        target.__defaults__ = (20000,)
        return other == "adjustment"

target.__kwdefaults__ = {Key(): 42}
value, adjustment = target()
print(value, adjustment, value is saved[0][0])
print(target(value) if False else target()[0], target.__defaults__)

capture = []
def observe(function):
    capture.append(function.__defaults__)
    return function

def create(seed):
    @observe
    def decorated(value=seed*11, /):
        return value
    def generator(value=seed+10000, /):
        yield value
    return decorated, generator

decorated, generator = create(101)
result = decorated()
emitted = next(generator())
print(result, result is capture[0][0], capture[0] is decorated.__defaults__)
print(emitted, emitted is generator.__defaults__[0])

def more(seed):
    def closed(value=seed-10000, /):
        return value + 1
    return closed

print([more(n)() for n in [9998, 9999, 10000, 10001]])
