#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/unboxed-singleton-default-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/unboxed-singleton-default-20261123
filter='Category!=Stress&(FullyQualifiedName~DefaultMetadata|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~DefaultConstruction|FullyQualifiedName~NativeCall|FullyQualifiedName~IntegerReturn|FullyQualifiedName~IntegerChain|FullyQualifiedName~CallBinding|FullyQualifiedName~Recursion|FullyQualifiedName~NativeUnpack|FullyQualifiedName~ExecutableCall|FullyQualifiedName~FunctionCancellation|FullyQualifiedName~OrdinaryFunctionTransport|FullyQualifiedName~GeneralBoundMethodDefaultLifetime|FullyQualifiedName~FunctionDefaultsAccounting|FullyQualifiedName~SynchronousGeneratorAdvance)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/white-refined-ubuntu.log" 2>&1 || { tail -45 "$lab/white-refined-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/public-refined-ubuntu.log" 2>&1 || { tail -45 "$lab/public-refined-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-refined-ubuntu.log" "$lab/public-refined-ubuntu.log"

