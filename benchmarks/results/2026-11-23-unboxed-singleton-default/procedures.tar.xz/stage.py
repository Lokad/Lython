from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/unboxed-singleton-default-20261123"
out = lab / "comparison-refined"
previous = lab.parent / "direct-bound-integer-refined-20261123" / "comparison"
quiet = out / "quiet"
quiet.mkdir()
core = "Lokad.Lython.dll"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): write(p, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def write(p, source):
    if p.suffix == ".py": compile(source, str(p), "exec")
    p.write_text(source, encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)
def published(folder, name): return git("show", f"origin/master:benchmarks/results/{folder}/{name}")
def archive(folder):
    receipt = json.loads(published(folder, "archive-receipt.json"))
    data = published(folder, "observations.tgz")
    assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
    assert sha(data) == receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

template = read(previous / "quiet/config.json")
prior_archive = archive("2026-11-23-direct-bound-integer-refined")
prior = json.loads(published("2026-11-23-direct-bound-integer-refined", "source.json"))
assert prior["imageFiles"] == template["identity"]["imageFiles"]
before = read(out / "identity.json")
candidate = git("rev-parse", "HEAD", cwd=tree).decode().strip()
assert not git("status", "--porcelain", cwd=tree)
patch = git("diff", "--binary", before["patchBase"], candidate, "--", "src", "tests")
assert sha(patch) == before["sourcePatchSHA256"] and patch == (out/"source.patch").read_bytes()
files = before["imageFiles"]
assert prior["imageFiles"]["candidate"] == files["reference"] and len(files["reference"]) == 32
assert [n for n in files["reference"] if files["reference"][n] != files["candidate"][n]] == [core]

old_folder = "2026-11-23-retained-cpython-checkpoint"
old = json.loads(published(old_folder, "source.json"))
blob = gzip.decompress(published(old_folder, "candidate-core.dll.gz"))
assert sha(blob) == old["imageFiles"]["candidate"][core]
retire = [dict(paths=[
    "direct-bound-integer-b1430-20261123/reference/" + core,
    "direct-bound-integer-b1431-20261123/reference/" + core,
    "retained-current-cpython-b1429-20261123/candidate/" + core],
    bytes=len(blob), sha256=sha(blob), links=3,
    archives={"retained-current-cpython-b1429-20261123/observations.tgz": archive(old_folder)})]

older_folder = "2026-11-21-cpython-retained-checkpoint"
old_config = read(lab.parent / "latest-checkpoint-cpython-20261121/quiet/config.json")
blob = gzip.decompress(published(older_folder, "measured-core.dll.gz"))
assert len(blob) == 5713920 and sha(blob) == old_config["identity"]["imageFiles"]["candidate"][core]
retire.append(dict(paths=[
    "direct-float-text-b1312-20261122/reference/" + core,
    "retained-factory-attribution-b1310-20261122/candidate/" + core,
    "single-positional-default-b1311-20261122/reference/" + core,
    "joint-default-preflight-b1308-20261121/reference/" + core,
    "checkpoint-cpython-b1307-20261121/candidate/" + core,
    "lexical-leaf-preparation-b1309-20261122/reference/" + core],
    bytes=len(blob), sha256=sha(blob), links=6,
    archives={"checkpoint-cpython-b1307-20261121/observations.tgz": archive(older_folder)}))

catalog = out / "representative.json"
ids = [row["id"] for row in read(catalog)["cases"]]
jobs = [(ids[0], "warm"), (ids[0], "compile-run")] + [(id, "warm") for id in ids[1:]]
assert len(jobs) == 6
save(out / "jobs.json", jobs)
shutil.copyfile(catalog, quiet / "representative.json")
for role, manifest in files.items():
    image = out / f"frozen-{role}"
    proof = read(out / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["catalogSha256"] == digest(catalog) and proof["caseCount"] == len(ids)
    assert {n: digest(image / n) for n in manifest} == manifest

(quiet / "candidate").mkdir()
shutil.copyfile(out / "frozen-candidate" / core, quiet / "candidate" / core)
identity = {**before, "sourceRevision": before["reference"] + " versus " + candidate, "candidate": candidate,
    "purpose": "Keep an admitted unboxed singleton positional integer in the callable until identity needs its tuple.",
    "normalAdapterPin": "0.4.0", "coreSHA256": {r+s:m[core] for r,m in files.items() for s in ("", "-control")},
    "catalogs": {"representative.json": {"sha256": digest(catalog)}}}
save(quiet / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/unboxed-singleton-default-b1432-20261123"
unit = "lython-b1432-unboxed-singleton-default-20261123"
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    source = (previous / "quiet" / name).read_text(encoding="utf-8").replace(template["root"], root).replace(template["unit"], unit)
    if name == "collect.py":
        start, end = source.index("\njob_catalog ="), source.index("\nassert len(jobs)")
        source = source[:start] + "\njob_catalog = " + repr({id:"representative.json" for id in ids}) + "\njobs = " + repr(jobs) + source[end:]
        source = source.replace("if job_index % 2 == 0: labels.reverse()", "if job_index % 2 != 0: labels.reverse()")
    write(quiet / name, source.replace("Direct bound integers", "Deferred singleton integers"))
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "run.sh", "archive-owned.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts: bundle.add(quiet / name, arcname=name)
cfg = {**template, "root": root, "unit": unit, "identity": identity, "source": template["root"], "sourceRole": "candidate",
       "sourceFiles": files["reference"], "sourceCatalogSHA256": digest(catalog), "donorArchiveSHA256": prior_archive,
       "retireGroups": retire, "payloadBytes": payload.stat().st_size, "payloadSHA256": digest(payload),
       "unpackedBytes": sum((quiet / n).stat().st_size for n in parts)}
save(quiet / "config.json", cfg)
seed = (previous / "quiet/remote-launch.py").read_text(encoding="utf-8")
a,b = seed.index("\nc=")+1, seed.index("\nb=Path(")
write(quiet / "remote-launch.py", (seed[:a] + "c=" + repr(cfg) + seed[b:]).replace("b1431-fixtures", "b1432-fixtures"))
write(out / "launch.py", (previous / "launch.py").read_text(encoding="utf-8").replace("Direct bound integers", "Deferred singleton integers"))
write(out / "summarize.py", (previous / "summarize.py").read_text(encoding="utf-8"))
print(candidate, root, cfg["unpackedBytes"], sum(group["bytes"] for group in retire))
