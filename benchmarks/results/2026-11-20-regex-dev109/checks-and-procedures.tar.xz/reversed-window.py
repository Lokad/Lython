import re
p=re.compile(r'(?P<empty>)')
m=p.match('xé',2,1)
print(None if m is None else (m.regs,m.lastindex,m.pos,m.endpos))
