from pathlib import Path
import hashlib, json, os, shutil, subprocess, xml.etree.ElementTree as ET, zipfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
version = '0.5.0-dev.109'
revision = '18c1e0e20b372e85ab3aaebd22fc627a69d19cf5'
producer = Path('D:/code/utf8regex/artifacts')
candidate = producer / 'package-candidates' / version
acceptance = producer / 'package-acceptance' / version
previous = lab.parent / 'regex-dev108-r691'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
inputs = load(candidate / 'candidate.json')
assert inputs['PackageVersion'] == version and inputs['SourceRevision'] == revision
assert inputs['CleanSource'] and inputs['Configuration'] == 'Release' and not inputs['Published']
base = load(previous / 'result.json')
assert not subprocess.check_output(['git','status','--porcelain'])
runtime = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert runtime.startswith('7ddb8be02')
for path in ('src/Lokad.Lython/Host/ILythonRegexProvider.cs','src/Lokad.Lython/Public/ILythonMemoryBudget.cs'):
    def signature(commit):
        text = subprocess.check_output(['git','show',f'{commit}:{path}']).decode('utf-8')
        return [line for line in text.splitlines() if line.strip() and not line.lstrip().startswith('//')]
    assert signature(runtime) == signature(base['coreSource'])
shutil.copyfile(candidate/'candidate.json',lab/'producer-candidate.json')
shutil.copyfile(acceptance/'host-inputs.json',lab/'producer-host-inputs.json')
host_revision = load(lab/'producer-host-inputs.json')['lython']['Commit']
assert host_revision.startswith('98b9f87f7')

semantics = (previous/'semantics.py').read_text(encoding='utf-8')
before = '\n]\ndef detail'
assert semantics.count(before) == 1
semantics = semantics.replace(before, '\n    (r"(?P<é>é)(?=(😀))😀", "aé😀é😀!", 1, 5),\n]\ndef detail')
(lab/'semantics.py').write_text(semantics,encoding='utf-8',newline='\n')
(lab/'reversed-window.py').write_text(
    "import re\np=re.compile(r'(?P<empty>)')\nm=p.match('xé',2,1)\nprint(None if m is None else (m.regs,m.lastindex,m.pos,m.endpos))\n",
    encoding='utf-8',newline='\n')
sdk = Path.home()/'.dotnet11'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
result = dict(version=version,producerRevision=revision,lythonSource=runtime,developmentAdapterImageFrom=base['coreSource'],
              producerHostSource=host_revision,published=False,images={},producerHostChecks=[],probes=[])
for target in ('net10.0','net11.0'):
    prior = previous/'probes'/target
    files = base['files'][target]['imageHashes']
    assert {f.name:sha(f.read_bytes()) for f in prior.iterdir() if f.is_file()} == files
    image=lab/'probes'/target
    shutil.copytree(prior,image,copy_function=shutil.copyfile,dirs_exist_ok=True)
    shutil.copyfile(lab/f'reference/bin/Lokad.Lython/release_{target}/Lokad.Lython.dll',image/'Lokad.Lython.dll')
    packages = {}
    for item in inputs['Packages']:
        name=item['Id']
        if name not in ('Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe') or item['TargetFramework'] != target:
            continue
        path = candidate/item['RelativePath']
        payload = path.read_bytes()
        assert sha(payload) == item['PackageSha256'].lower()
        with zipfile.ZipFile(path) as z:
            dll = z.read(f'lib/{target}/{name}.dll')
        assert sha(dll) == item['AssemblySha256'].lower()
        (image/f'{name}.dll').write_bytes(dll)
        packages[name] = dict(packageSha256=sha(payload),assemblySha256=sha(dll))
    assert len(packages) == 2
    for platform,part in (('Windows','windows'),('Linux','linux/host-tests')):
        host = acceptance/part
        receipt = load(host/'host-acceptance.json')
        assert receipt['SourceRevision'] == revision
        record = next(row for row in receipt['Records'] if row['Host']=='lython' and row['Framework']==target)
        assert packages == {row['Id']:dict(packageSha256=row['PackageSha256'],assemblySha256=row['AssemblySha256'])
                            for row in record['Packages']}
        trx = host/f'lython-{target}/accepted.trx'
        digest = sha(trx.read_bytes())
        assert digest == record['TrxSha256']
        tests = ET.parse(trx).findall('.//{*}UnitTestResult')
        assert len(tests) == record['Passed'] == 405 and all(test.attrib['outcome']=='Passed' for test in tests)
        cancellation = [test.attrib['testName'] for test in tests if 'ActualBackendWorkObservesInFlightCancellationAndUnwinds' in test.attrib['testName']]
        assert len(cancellation) == 3 and all(any(stage in name for name in cancellation) for stage in ('compile','match','cursor'))
        shutil.copyfile(trx,lab/f'producer-{platform}-{target}.trx')
        shutil.copyfile(host/'host-acceptance.json',lab/f'producer-{platform}-host-acceptance.json')
        result['producerHostChecks'].append(dict(platform=platform, target=target, count=len(tests), trxSha256=digest, cancellation=cancellation))
    def hashes():
        return {f.name:sha(f.read_bytes()) for f in image.iterdir() if f.is_file()}
    identity=hashes()
    assert len(identity)==11 and identity['Lokad.Lython.Utf8Regex.dll']==files['Lokad.Lython.Utf8Regex.dll']
    result['images'][target]=dict(files=identity,packages=packages)
    for api in ('sync','async'):
        for case in ('semantics','reversed-window'):
            assert hashes()==identity
            args=[sdk/'dotnet.exe',image/'LythonProbe.dll',lab/f'{case}.py','--json','--compare-python',
                  '--python','C:/Python313/python.exe','--max-memory-bytes','4194304']
            if api=='async':
                args.append('--async')
            run=subprocess.run(args,env=env,capture_output=True,timeout=35)
            (lab/f'{target}-{api}-{case}.json').write_bytes(run.stdout)
            (lab/f'{target}-{api}-{case}.stderr').write_bytes(run.stderr)
            summary=json.loads(run.stdout.decode('utf-8'))
            compared=summary['Matches']
            if case=='semantics':
                assert run.returncode==0 and compared and not run.stderr
            result['probes'].append(dict(target=target,api=api,case=case,matches=compared,exitCode=run.returncode))
            print(target, api, case, compared, flush=True)
    assert hashes()==identity
(lab/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
