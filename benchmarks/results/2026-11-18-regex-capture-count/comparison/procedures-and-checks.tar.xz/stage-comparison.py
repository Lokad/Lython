from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
sha = lambda value: hashlib.sha256(value).hexdigest()
choices = []
for relative, archive_member, remote in (
    ('2026-11-07-json-input-windows/development.tar.xz', 'b411/current-core.dll',
     'json-input-storage-b411-20261107/candidate/Lokad.Lython.dll'),
    ('2026-11-07-json-input-windows/development.tar.xz', 'b411/current-core.dll',
     'json-input-storage-b412-20261107/candidate/Lokad.Lython.dll'),
    ('2026-11-16-native-consumer-consolidation/initial/cores-and-procedures.tar.xz',
     'candidate/Lokad.Lython.dll', 'native-consumers-b852-20261116/candidate/Lokad.Lython.dll'),
):
    canonical = 'benchmarks/results/' + relative
    blob = (repo / canonical).read_bytes()
    assert blob == subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        value = archive.extractfile(archive_member).read()
    digest = sha(value)
    assert digest.startswith(('aa367953', '5755fa15')), digest
    choices.append(dict(kind='archived superseded prototype core replica', canonical=canonical,
                        canonicalSHA256=sha(blob), member=archive_member, sha256=digest,
                        bytes=len(value), paths=[remote], links=1, committedBlobVerified=True))

ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
check_space = '''from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
root = Path('/home/lokad/lython-bench-checks').resolve()
choices = CHOICES
verified, mismatches = [], []
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for group in choices:
        path = root / group['paths'][0]
        st = path.lstat()
        assert path.resolve() == path and stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid()
        assert st.st_size == group['bytes'] and st.st_nlink == group['links']
        if hashlib.sha256(path.read_bytes()).hexdigest() == group['sha256']:
            verified.append(group)
        else:
            mismatches.append(group['paths'][0])
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=verified, mismatches=mismatches)))
'''.replace('CHOICES', repr(choices))
space = subprocess.run(ssh + ['python3 -'], input=check_space, text=True, encoding='utf-8',
                       capture_output=True, timeout=30, check=True).stdout
(lab / 'space.json').write_text(space, encoding='utf-8')
print('Read-only verification:', json.loads(space)['freeBytes'],
      [record['paths'] for record in json.loads(space)['choices']], flush=True)

identity_path = lab / 'frozen-identity.json'
identity = json.loads(identity_path.read_text(encoding='utf-8'))
identity.update(sourceRevision='925397f65 frozen 2c6b304b versus isolated R533/56a28440',
                purpose='Shared UTF-8 scalar counting for capture positions in complete warm scripts')
identity_path.write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')

stage = (lab.parent / 'result-transport-r531' / 'stage.py').read_text(encoding='utf-8')
start, end = stage.index("jobs = [('scripts.text-"), stage.index('collect =')
jobs = [
    ('diagnostic.regex.unicode-interior.4096', 'warm'),
    ('diagnostic.regex.ascii-interior.4096', 'warm'),
    ('diagnostic.regex.unicode-tail.4096', 'warm'),
    ('diagnostic.regex.unicode-short.4096', 'warm'),
]
stage = stage[:start] + 'jobs = ' + repr(jobs) + '\n' + stage[end:]
stage = stage.replace('result-transport-b961-20261118', 'regex-capture-b963-20261118')
stage = stage.replace('lython-b961-result-transport-20261118', 'lython-b963-regex-capture-20261118')
stage = stage.replace('lython-b961-fixtures', 'lython-b963-fixtures')
stage = stage.replace("'len(jobs)==5'", "'len(jobs)==4'").replace('"len(raw[\'jobs\'])==5"', '"len(raw[\'jobs\'])==4"')
stage = stage.replace("'jobs=5,elapsedSeconds'", "'jobs=4,elapsedSeconds'").replace('"[\'jobs\']==5"', '"[\'jobs\']==4"')
stage = stage.replace('Result transport', 'Regex capture counting').replace('result transport source pair', 'regex capture counting source pair')
ast.parse(stage)
(lab / 'stage.py').write_text(stage, encoding='utf-8', newline='\n')
exec(compile(stage, str(lab / 'stage.py'), 'exec'), {'__file__': str(lab / 'stage.py')})
