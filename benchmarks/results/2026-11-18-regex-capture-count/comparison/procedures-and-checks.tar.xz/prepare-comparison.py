from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
latest = lab.parent / 'numeric-compiler-facts-r532'
work = repo / '.git/agent-worktrees/regex-capture-count'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sha_text = lambda value: hashlib.sha256(value.encode('utf-8')).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n',
                    encoding='utf-8', newline='\n')


core = 'Lokad.Lython.dll'
qualified = lab.parent / 'frontend-dispatch-r527' / 'frozen/candidate'
candidate = work / 'src/Lokad.Lython/bin/Release/net11.0' / core
base = read(qualified.parent / 'identity.json')['imageFiles']['candidate']
expected = read(repo / 'benchmarks/results/2026-11-18-regex-capture-count/identity.json')
assert expected['base'].startswith('925397f65')
assert len(base) == 32 and base[core].startswith('2c6b304b')
assert sha(candidate) == expected['cores']['net11.0']
images = {}
for side in ('reference', 'candidate'):
    target = lab / 'frozen' / side
    target.mkdir(parents=True, exist_ok=True)
    for name, digest in base.items():
        original = qualified / name
        assert sha(original) == digest, name
        source = candidate if name == core and side == 'candidate' else original
        shutil.copyfile(source, target / name)
    images[side] = {name: sha(target / name) for name in base}
assert images['reference'] == base
assert images['candidate'] == base | {core: expected['cores']['net11.0']}

evidence = repo / 'benchmarks/results/2026-11-16-regex-known-boundaries/observations.tgz'
with tarfile.open(evidence) as archive:
    member, = [member for member in archive if member.name.endswith('representative.json')]
    catalog = json.load(archive.extractfile(member))
sources = {row['id']: row for row in catalog['cases']}
tail = sources['diagnostic.regex.unicode-tail.4096']
short = sources['diagnostic.regex.unicode-short.4096']
ascii_tail = sources['diagnostic.regex.ascii-tail.4096']


def interior(template, pattern, case_name):
    size = template['size']
    count = size - 512 + 1
    # m.start() is the current scalar index; m.end(1) is 512 scalars ahead.
    output = f'{count} {count * (count - 1 + 512)}\n'
    source = template['source'].replace('(?=(.*))', pattern)
    assert source != template['source']
    return template | {
        'id': case_name,
        'source': source,
        'sourceSha256': sha_text(source),
        'expectedOutput': output,
        'expectedOutputSha256': sha_text(output),
    }


cases = [
    interior(tail, '(?=(.{512}))', 'diagnostic.regex.unicode-interior.4096'),
    interior(ascii_tail, '(?=(.{512}))', 'diagnostic.regex.ascii-interior.4096'),
    tail,
    short,
]
catalog_path = lab / 'representative.json'
write(catalog_path, catalog | {'cases': cases})
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']

for side, hashes in images.items():
    folder = lab / 'frozen' / side
    for name in ('ValidatedAllocation.dll', 'ValidatedAllocation.deps.json',
                 'ValidatedAllocation.runtimeconfig.json'):
        source = qualified / name
        if source.is_file():
            shutil.copyfile(source, folder / name)
    output = lab / (side + '-verification.json')
    command = [str(dotnet), str(folder / 'Lokad.Lython.Benchmarks.dll'),
               '--compare', 'verify', '--catalog', str(catalog_path),
               '--dotnet', str(dotnet), '--python', 'C:/Python313/python.exe',
               '--python-worker', str(repo / 'benchmarks/cpython-worker.py'),
               '--out', str(output)]
    with (lab / (side + '-verification.log')).open('w', encoding='utf-8') as log:
        subprocess.run(command, cwd=repo, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=120)
    assert all(sha(folder / name) == digest for name, digest in hashes.items())
    print(side, 'passed actual worker and CPython verification', flush=True)

write(lab / 'frozen-identity.json', {
    'baseSource': expected['base'],
    'imageFiles': images,
    'catalogSHA256': sha(catalog_path),
    'coreSHA256': {name: images[role][core] for role in images
                   for name in (role, role + '-control')},
    'normalAdapterPin': '0.4.0',
})
