from pathlib import Path
import hashlib
import gzip
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/regex-capture-count'
evidence = repo / 'benchmarks/results/2026-11-18-regex-capture-count'
out = evidence / 'comparison'
quiet = lab / 'quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert status['exitCode'] == '0' and not status['remainingTrace'] and not status['remainingWorkers']
assert receipt['complete'] and receipt['jobs'] == 4 and receipt['archivedAndVerifiedUnderLease']
assert receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['quietBeforeAndAfter']
assert sha(quiet / 'observations.tgz') == receipt['archiveSHA256']

out.mkdir()
for name in ('archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
    shutil.copyfile(quiet / name, out / name)
for name in ('frozen-identity.json', 'reference-verification.json', 'candidate-verification.json',
             'allocation-summary.json'):
    shutil.copyfile(lab / name, out / name)
summary = read(lab / 'summary.json')
summary['retentionDecisionPending'] = False
summary['retentionDecision'] = 'Retain shared managed scalar counting, preserve Unicode tail debt.'
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n',
                                  encoding='utf-8', newline='\n')
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for name in ('prepare-comparison.py', 'stage-comparison.py', 'stage.py', 'launch.py',
                 'summarize.py', 'archive-and-integrate.py', 'space.json',
                 'representative.json', 'reference-verification.log', 'candidate-verification.log',
                 'reference-allocation.json', 'candidate-allocation.json',
                 'quiet/config.json', 'quiet/collect.py', 'quiet/archive-owned.py', 'quiet/run.sh',
                 'quiet/remote-launch.py', 'quiet/retrieve.py', 'quiet/launch.log'):
        archive.add(lab / name, arcname=name)

patch = subprocess.check_output(['git', '-C', str(work), 'diff', '--binary'], cwd=repo)
archived_patch = gzip.decompress((evidence / 'candidate.patch.gz').read_bytes())
assert patch.replace(b'\r\n', b'\n') == archived_patch.replace(b'\r\n', b'\n')
subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=repo, check=True)
subprocess.run(['git', 'apply', '-'], input=patch, cwd=repo, check=True)
paths = subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', '-z'], cwd=repo)
files = paths.decode().split('\0')[:-1]
assert len(files) == 3
for path in files:
    assert (repo / path).read_bytes().replace(b'\r\n', b'\n') == (work / path).read_bytes().replace(b'\r\n', b'\n'), path
print('Archived the four complete observations and integrated exactly the tested regex changes.')
