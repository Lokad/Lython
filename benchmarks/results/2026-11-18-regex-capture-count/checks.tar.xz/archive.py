from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
work = repo / '.git/agent-worktrees/regex-capture-count'
out = repo / 'benchmarks/results/2026-11-18-regex-capture-count'
assert not (out / 'candidate.patch.gz').exists()
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=work)
(out / 'candidate.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
identity = dict(
    base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
    cores={target: hashlib.sha256((work / f'src/Lokad.Lython/bin/Release/{target}/Lokad.Lython.dll').read_bytes()).hexdigest()
           for target in ('net11.0', 'net10.0')},
    note='Private development prototype. Complete-image timing and Linux qualification are pending.')
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
with tarfile.open(out / 'checks.tar.xz', 'w:xz') as archive:
    for name in ('initial', 'refined', 'check.py', 'archive.py'):
        archive.add(lab / name, arcname=name)
