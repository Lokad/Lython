from pathlib import Path
import json
import os
import subprocess
import sys

lab = Path(__file__).resolve().parent
work = Path('D:/code/Lython/.git/agent-worktrees/regex-capture-count')
dotnet = Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env = os.environ.copy()
env.update(DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
env['PATH'] = str(dotnet.parent) + os.pathsep + env['PATH']
checks = {
    'Lokad.Lython.Tests': '(FullyQualifiedName~Regex|FullyQualifiedName~PyString|FullyQualifiedName~ProjectionWidth)&Category!=Stress',
    'Lokad.Lython.PublicApi.Tests': '(FullyQualifiedName~Regex|FullyQualifiedName~Utf8Regex|FullyQualifiedName~Unicode|FullyQualifiedName~ProjectionBudget)&Category!=Stress',
}
if '--refined' in sys.argv:
    lab = lab / 'refined'
    lab.mkdir(exist_ok=False)
    checks = {
        'Lokad.Lython.Tests': '(FullyQualifiedName~RegexScalarCursorCancellationTests|FullyQualifiedName~Utf8ScalarWidthTests)&Category!=Stress',
    }
rows = []
for framework in ('net11.0', 'net10.0'):
    for suite, filter_expression in checks.items():
        result = subprocess.run([str(dotnet), 'test', f'tests/{suite}/{suite}.csproj', '-c', 'Release', '-f', framework,
                                 '--no-build', '--filter', filter_expression], cwd=work, env=env, text=True,
                                encoding='utf-8', errors='replace', stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        log = lab / f'{suite}-{framework}.log'
        log.write_text(result.stdout, encoding='utf-8')
        summary = result.stdout.splitlines()[-1]
        rows.append(dict(framework=framework, suite=suite, filter=filter_expression, exitCode=result.returncode, summary=summary))
        print(framework, suite, summary, flush=True)
(lab / 'checks.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
assert all(row['exitCode'] == 0 for row in rows)
