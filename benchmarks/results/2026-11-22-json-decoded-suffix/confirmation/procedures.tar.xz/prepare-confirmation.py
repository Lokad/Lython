from pathlib import Path
import hashlib, json, shutil, tarfile
p=Path(".git/agent-notes/review-20261031/json-decoded-suffix-20261122").resolve()
donor=p/"quiet"
out=p/"confirmation"
out.mkdir()
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, data):
    if path.suffix==".py": compile(data,str(path),"exec")
    path.write_text(data,encoding="utf-8",newline="\n")

old=read(donor/"config.json")
receipt=read(donor/"archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(donor/"observations.tgz")==receipt["archiveSHA256"]
ident=old["identity"]
for role,files in ident["imageFiles"].items():
    assert len(files)==32 and {name:sha(p/"frozen"/role/name) for name in files}==files
    proof=read(p/f"quiet-{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==4 and proof["catalogSha256"]==ident["catalogSHA256"]
assert sha(donor/"representative.json")==ident["catalogSHA256"]

root="/home/lokad/lython-bench-checks/json-decoded-suffix-b1318-confirmation-20261122"
unit="lython-b1318-json-decoded-suffix-confirmation-20261122"
cases=["diagnostic.report-render.escaped-unicode.large",
       "scripts.report-render.large", "scripts.text-summary-helpers.map-callback.large.mixed-unicode"]
jobs=[(case,"warm") for case in cases]
write(out/"identity.json",(donor/"identity.json").read_text(encoding="utf-8"))
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source=(donor/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        start=source.index("\njobs = ")
        end=source.index("\nassert len(jobs)",start)
        source=source[:start]+"\njobs = "+repr(jobs)+source[end:]
        source=source.replace("len(jobs)==4","len(jobs)==3")
        source=source.replace("warmupSeconds=8","warmupSeconds=16").replace("min(warmed)<8","min(warmed)<16").replace("warmed[i]>=8","warmed[i]>=16")
        source=source.replace("accumulate 8 seconds", "accumulate 16 seconds")
        # Reverse the original role order for the two common report lanes.
        source=source.replace("if job_index % 2 == 0:", "if job_index % 2 != 0:")
    elif name=="archive-owned.py":
        source=source.replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace("jobs=4,","jobs=3,")
    elif name=="retrieve.py":
        source=source.replace("['jobs']==4","['jobs']==3")
    write(out/name,source)
assert b"\r" not in (out/"run.sh").read_bytes()

parts=("identity.json","collect.py","archive-owned.py","run.sh")
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as tar:
    for name in parts: tar.add(out/name,arcname=name)
config=dict(old,root=root,unit=unit,source=old["root"],
            sourceFiles=ident["imageFiles"]["candidate"],sourceRole="candidate",
            sourceCatalogSHA256=ident["catalogSHA256"],donorArchiveSHA256=receipt["archiveSHA256"],
            protocolSource=old["root"]+"/cpython-worker.py",retireGroups=[],
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
            unpackedBytes=sum((out/name).stat().st_size for name in parts))
write(out/"config.json",json.dumps(config,indent=2)+"\n")
source=(donor/"remote-launch.py").read_text(encoding="utf-8")
i=source.index("\nc=")+1;j=source.index("\nb=Path(",i)
source=source[:i]+"c="+repr(config)+source[j:]
source=source.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    " for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
source=source.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
source=source.replace("lython-b1317-fixtures","lython-b1318-fixtures")
write(out/"remote-launch.py",source)
source=(p/"launch.py").read_text(encoding="utf-8").replace("Path(__file__).parent/'quiet'","Path(__file__).parent")
source=source.replace("JSON decoded suffix comparison","JSON decoded suffix confirmation").replace("310","285")
write(out/"launch.py",source)
source=(p/"summarize.py").read_text(encoding="utf-8").replace("r=Path(__file__).parent","r=Path(__file__).parent.parent")
source=source.replace("/'quiet/","/'confirmation/").replace("len(raw['jobs'])==4","len(raw['jobs'])==3")
write(out/"summarize.py",source)
print("Prepared three lanes from the same verified worker images and catalog.")
