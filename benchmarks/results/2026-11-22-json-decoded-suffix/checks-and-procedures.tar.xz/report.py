from pathlib import Path
import json

lab=Path(__file__).resolve().parent
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
data=load(lab/"quiet/quiet-summary.json")
decision=load(lab/"decision.json")
rows=[
    "| Whole warm script | Elapsed change | Process CPU change | Reference / candidate elapsed spread |",
    "| --- | ---: | ---: | ---: |",
]
names={
    "diagnostic.report-render.escaped-unicode.large":"Escaped-Unicode formatted report",
    "scripts.report-render.large":"Plain formatted report",
    "scripts.json-normalized-records.large":"JSON normalization",
    "scripts.text-summary-helpers.map-callback.large.mixed-unicode":"Unchanged mixed-Unicode text report",
}
def extent(values):
    lo=f"{min(values):+.2f}".replace("-","−")
    hi=f"{max(values):+.2f}".replace("-","−")
    return lo+"%" if lo==hi else lo+" to "+hi+"%"
for row in data["rows"]:
    rows.append(f"| {names[row['case']]} | {extent(row['elapsedChangePercent'])} | "
                f"{extent(row['cpuChangePercent'])} | {row['referenceSpreadPercent']:.2f} / "
                f"{row['candidateSpreadPercent']:.2f}% |")

report="""# B1317 Reuse decoded JSON string suffixes

The scanner validates UTF-8 in bounded raw runs as it locates quotes,
controls and escapes. It keeps the decoded suffix after the first
escape in bounded managed scratch when it fits. It admits one exact
final string after complete syntax validation. Wide suffixes replay
into final storage. Plain strings still reuse funded input ranges or
copy borrowed data. The candidate retains the original error
precedence and admission timing.

Compared `8c81fb8d2` with `e5316a8de` on November 22, 2026 UTC on
the quiet Azure F4as_v7 running Ubuntu 24.04.4 and .NET 11 RC3.
Two independently warmed processes per revision supplied seven
rotated batches each. Ranges cover all process-median pairings.
Elapsed includes mediated RAM-backed I/O and prior-result disposal.
Process CPU includes worker request handling. Negative changes
favor the candidate.

"""
report+="\n".join(rows)+"\n\n"
report+=decision["explanation"]+"\n\n"
report+=f"""Local allocation differs by less than 0.01% across the four cases.
Accounted peaks match and each allowance refunds to its baseline.
Windows .NET 11 and Ubuntu .NET 10 each pass 217 white-box and 906
public focused Release checks. A 220-case CPython compatibility
matrix matches on both run paths, covering Unicode around scan
and suffix boundaries, malformed escapes, permissive and strict
controls and original scalar error coordinates.

Both 32-file images match four CPython goldens before timing. All
112 batches verify. Workers join, RAM fixtures retire and the
persistent archive verifies under the lease in {data['elapsedSeconds']:.0f} seconds.

[Timing](summary.json) · [Allocation](allocation-summary.json) ·
[Raw observations](observations.tgz) · [Source and checks](checks-and-procedures.tar.xz) ·
[Reference core](../2026-11-22-sparse-lexical-preparation/candidate-core.dll.gz).
"""
(lab/"README.md").write_text(report,encoding="utf-8",newline="\n")
