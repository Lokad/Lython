import json

suffixes = [
    '',
    r'\n\t\r\u0000\u00e9\ud83d\ude00',
    r'\n' + 'z' * 121 + 'é' + r'\u00e9\/',
    r'\n' + 'z' * 122 + 'é' + r'\u00e9\/',
    r'\n' + 'z' * 123 + 'é' + r'\u00e9\/',
    r'\n' + 'z' * 4095 + '😀' + r'\u00e9',
    r'\n\invalid',
    '\x00' + r'\ud83d\ude00',
    '\x1f' + r'\u4000',
    r'\u00q9',
    r'\n' + 'z' * 127 + r'\u00q9',
]
count = 0
for width in (0, 1, 127, 128, 129, 4092, 4093, 4094, 4095, 4096):
    for suffix in suffixes:
        text = 'λ"' + 'x' * width + '😀' + suffix + '" tail'
        for strict in (True, False):
            try:
                value, end = json.JSONDecoder(strict=strict).raw_decode(text, 1)
                print(len(value), end, json.dumps(value[-12:], ensure_ascii=True))
            except json.JSONDecodeError as error:
                print(error.msg, error.pos, error.lineno, error.colno)
            count += 1
print(count)
