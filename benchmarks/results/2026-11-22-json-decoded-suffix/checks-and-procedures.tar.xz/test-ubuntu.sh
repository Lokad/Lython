set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/json-decoded-suffix-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/json-decoded-suffix-20261122
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Json' > "$logs/white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Json' > "$logs/public-ubuntu.log" 2>&1
if command -v rg >/dev/null; then
    rg 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
else
    grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
fi
