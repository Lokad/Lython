from pathlib import Path
import gzip, hashlib, json, subprocess
p=Path(".git/agent-notes/review-20261031/json-decoded-suffix-20261122")
base=p.parent
def load(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def save(path, obj): path.write_text(json.dumps(obj,indent=2)+"\n",encoding="utf-8",newline="\n")
def sha(data): return hashlib.sha256(data).hexdigest()

catalog=load(base/"json-string-escape-descriptors/catalog.json")
selected=[
    "diagnostic.report-render.escaped-unicode.large",
    "scripts.report-render.large",
    "scripts.json-normalized-records.large",
    "scripts.text-summary-helpers.map-callback.large.mixed-unicode",
]
lookup={case["id"]:case for case in catalog["cases"]}
catalog["cases"]=[lookup[name] for name in selected]
save(p/"representative.json",catalog)

old=base/"regex-capture-count-r533"
proof=load(old/"quiet/config.json")
root="regex-capture-b963-20261118"
assert proof["root"].endswith("/"+root)
local_identity=load(old/"frozen-identity.json")["imageFiles"]["candidate"]
local=old/"frozen/candidate"
assert len(local_identity)==32 and all(sha((local/name).read_bytes())==h for name,h in local_identity.items())
core=(local/"Lokad.Lython.dll").read_bytes()
assert len(core)==5752832 and sha(core)==sha((old/"quiet/candidate/Lokad.Lython.dll").read_bytes())
db=load(old/"quiet/archive-receipt.json")
assert db["complete"] and db["archivedAndVerifiedUnderLease"]
tar=subprocess.check_output(["git","show","origin/master:benchmarks/results/2026-11-18-regex-capture-count/comparison/observations.tgz"])
assert sha(tar)==db["archiveSHA256"]
recover=p/"recovered-b963-core.dll.gz"
recover.write_bytes(gzip.compress(core,mtime=0))
assert gzip.decompress(recover.read_bytes())==core
save(p/"retire-proof.json",dict(proof=[dict(paths=[root+"/candidate/Lokad.Lython.dll"],
    bytes=len(core),links=1,sha256=sha(core),archives={root+"/observations.tgz":sha(tar)},optional=False)],
    recoveredCoreSHA256=sha(core),archiveOrigin="benchmarks/results/2026-11-18-regex-capture-count/comparison/observations.tgz",
    localFullImageIdentity=str(old/"frozen-identity.json")))

prior=base/"csv-quoted-ranges-20261122"
src=(prior/"measure.py").read_text(encoding="utf-8")
for a,b in (
    ('baseline = "ac2728ce7"','baseline = "8c81fb8d2"'),
    ('candidate = "e75ba4118"','candidate = "e5316a8de"'),
    ('agent-worktrees/csv-quoted-ranges-20261122','agent-worktrees/json-decoded-suffix-20261122'),
    ('lab.parent / "direct-float-text-20261122"','lab.parent / "sparse-lexical-work-20261122"'),
    ('assert len(cases) == 5','assert len(cases) == 4'),
    ('root / "src/Lokad.Lython/bin/Release/net11.0" / name','lab / "frozen-candidate-core.dll"'),
):
    assert a in src,a
    src=src.replace(a,b)
compile(src,"measure.py","exec")
(p/"measure.py").write_text(src,encoding="utf-8",newline="\n")

src=(base/"sparse-lexical-work-20261122/prepare-quiet.py").read_text(encoding="utf-8")
start=src.index("cases = [")
end=src.index("\ncatalog[",start)
src=src[:start]+"cases = "+repr(selected)+src[end:]
for a,b in (
    ('prior = lab.parent / "csv-quoted-ranges-20261122"','prior = lab.parent / "sparse-lexical-work-20261122"'),
    ('reference.startswith("745f8833f") and candidate.startswith("d5abc29d4")',
     'reference.startswith("8c81fb8d2") and candidate.startswith("e5316a8de")'),
    ('("Lokad.Lython.Tests", 111), ("Lokad.Lython.PublicApi.Tests", 984)',
     '("white", 217), ("public", 906)'),
    ("Single suite walk and sparse lexical expression preparation","Bounded JSON text runs and short decoded suffix reuse"),
    ('jobs = [(cases[0], "compile"), (cases[1], "compile"), (cases[2], "compile"), (cases[3], "compile"), (cases[3], "compile-run")]',
     'jobs = [(case, "warm") for case in cases]'),
    ('sparse-lexical-work-b1315-20261122','json-decoded-suffix-b1317-20261122'),
    ('lython-b1315-sparse-lexical-work-20261122','lython-b1317-json-decoded-suffix-20261122'),
    ('"len(jobs)==5"','"len(jobs)==4"'),
    ('"jobs=5,"','"jobs=4,"'),
    ('==5"', '==4"'),
    ('lython-b1315-fixtures','lython-b1317-fixtures'),
    ('Sparse lexical preparation comparison','JSON decoded suffix comparison'),
    ('Prepared five lanes','Prepared four lanes'),
):
    assert a in src,a
    src=src.replace(a,b)
compile(src,"prepare-quiet.py","exec")
(p/"prepare-quiet.py").write_text(src,encoding="utf-8",newline="\n")
