from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
checkpoint = 'benchmarks/results/2026-11-26-post-ascii-cpython'
archive = 'observations.tar.xz'
pushed = subprocess.check_output(['git', 'show', 'origin/master:'+checkpoint+'/'+archive], cwd=repo)
local = repo/checkpoint/archive
assert local.read_bytes() == pushed
sha = lambda b: hashlib.sha256(b).hexdigest()
receipt = json.loads((local.parent/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete'] and receipt['archiveSHA256'] == sha(pushed)
with tarfile.open(local) as bundle:
    members = {item.name: sha(bundle.extractfile(item).read())
               for item in bundle.getmembers() if item.isfile() and item.name.startswith('confirmation/')}
assert set(members)=={'confirmation/confirmation.json','confirmation/fixture-filesystem.txt',
                      'confirmation/machine-after.json','confirmation/machine-before.json'}
script = r"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, tarfile

base = Path('/home/lokad/lython-bench-checks')
root = base/'post-ascii-cpython-b1791-20261126'
expanded = root/'confirmation'
archive = root/'observations.tar.xz'
assert base.resolve()==base and root.resolve()==root and expanded.resolve()==expanded
sha = lambda b: hashlib.sha256(b).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (root/'guest-fixtures').exists()
    state = subprocess.check_output(['systemctl','show','lython-b1791-post-ascii-cpython-20261126.service',
                                     '--property=ActiveState,MainPID'],text=True).splitlines()
    assert 'ActiveState=inactive' in state and 'MainPID=0' in state
    assert sha(archive.read_bytes())==archive_sha
    receipt = json.loads((root/'archive-receipt.json').read_text())
    assert receipt['archiveSHA256']==archive_sha and receipt['complete']
    assert receipt['guestFixturesRemoved'] and receipt['allWorkersJoined']
    with tarfile.open(archive) as bundle:
        assert {p.relative_to(root).as_posix() for p in expanded.iterdir()}==set(expected)
        for name,digest in expected.items():
            path = root/name
            assert path.parent==expanded and path.resolve()==path and path.is_file()
            assert sha(path.read_bytes())==digest==sha(bundle.extractfile(name).read())
    before = shutil.disk_usage(base).free
    for name in expected:
        (root/name).unlink()
    expanded.rmdir()
    assert sha(archive.read_bytes())==archive_sha
    print(json.dumps(dict(before=before,after=shutil.disk_usage(base).free,
                          preservedArchive=archive_sha,removedExpanded=expected)))
"""
prefix = f'archive_sha={sha(pushed)!r}\nexpected={members!r}\n'
key = Path.home()/'.ssh/id_lython-bench.pem'
report = subprocess.check_output(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
                                  'lokad@20.166.121.73','python3 -'],
                                 input=prefix+script,encoding='utf-8',timeout=54)
(lab/'comparison/quiet/disk-custody.json').write_text(report,encoding='utf-8')
print(report)
